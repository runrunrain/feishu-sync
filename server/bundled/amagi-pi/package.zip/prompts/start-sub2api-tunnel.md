---
description: 在 Mac mini 环境中启动、停止或检查 sub2api Docker Compose 服务、FRP 隧道与 CLIProxyAPI
argument-hint: "[start|stop|status，默认 start]"
---


# 管理 sub2api、FRP 隧道与 CLIProxyAPI（Mac mini）

$ARGUMENTS

这是 Mac mini 专用的运维命令，接受 `start`、`stop`、`status` 三种模式，默认 `start`。收到其他参数时停下来向主上确认意图。

这些服务的配置里有数据库密码、JWT、FRP token、API key 等 secret。检查和报告只需要状态信息，所以请不要从 prompt、日志或报告里读取或输出这些值。

## 部署形态（从 Windows 迁移而来）

| 组件 | 位置 | 常驻方式 |
|---|---|---|
| sub2api compose | `~/sub2api/docker-compose.yml`（三服务：sub2api:0.2.8 / postgres:16 / redis:8） | Docker Desktop `restart: unless-stopped` |
| Docker 引擎 | `/Applications/Docker.app`（docker CLI 链接在 `~/.local/bin/`） | GUI app / 开机自启（Docker Desktop 设置） |
| frpc 0.71.0 | `~/frp/frpc` + `~/frp/frpc.toml` | launchd `com.sub2api.frpc`（RunAtLoad + KeepAlive） |
| CLIProxyAPI 8.0.23 | `~/cliproxyapi/`（监听 8317，出站代理 127.0.0.1:5800） | launchd `com.cliproxyapi`（RunAtLoad + KeepAlive） |

- 端点：本地健康 `http://127.0.0.1:8080/health`；公网 `http://47.103.109.56:8081/health`；frps `47.103.109.56:7000`
- 两条隧道：`sub2api-http`（本地 8080 → 公网 8081）、`cc-switch-remote`（本地 8680 → 公网 8680）。**8680 是 amagi-codebox 的远程 API**，Mac mini 上的 codebox 启动并监听 8680 后自动可用
- Windows 上的旧部署已停止（compose down 未删卷，frpc/cpa 进程已停），数据卷仍保留在 Windows Docker 中，可用于回滚
- 迁移留存：pg_dump 逻辑备份 420MB 加三个卷的 tar，位于本机 `/tmp/s2a-mig/`（临时目录，不宜长期依赖）和 Mac mini `~/s2a-mig/`

## `status`：只读检查

1. `docker info --format "{{.ServerVersion}}"`：引擎在线
2. `docker compose -f ~/sub2api/docker-compose.yml ps`：三个服务都是 Up/healthy
3. 本地健康 URL：HTTP 状态与是否超时
4. `launchctl list | grep -E "frpc|cliproxyapi"`：PID 不是 `-`，退出码为 0
5. frpc 到 `47.103.109.56:7000` 有 TCP Established 连接：`lsof -nP -iTCP -sTCP:ESTABLISHED | grep 7000`
6. 公网健康 URL
7. cpa：`lsof -nP -iTCP:8317 -sTCP:LISTEN`

判断 FRP 是否正常，需要 TCP Established 和公网 HTTP 2xx 同时满足。frpc.log 可能因缓冲而为空，不适合作为成功的依据。

## `start`：启动并验证

1. Docker 引擎不在线时执行 `open -a Docker`，最多等 120 秒（每 5 秒用 `docker info` 探测一次）。
2. `docker compose -f ~/sub2api/docker-compose.yml up -d`，轮询本地健康 URL，最多 120 秒。
3. frpc 没在运行时执行 `launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/com.sub2api.frpc.plist`；如果已经 load 过，改用 `launchctl kickstart -k gui/$(id -u)/com.sub2api.frpc`。
4. cpa 同理（label 为 `com.cliproxyapi`）。
5. 验证 TCP Established 和公网 2xx。任一项失败，总体就判为失败，并报告各项状态。

## `stop`：停止但保留数据

1. `launchctl bootout gui/$(id -u)/com.sub2api.frpc` 和 `com.cliproxyapi`（只停这两个 label，其他服务不动）。
2. `docker compose -f ~/sub2api/docker-compose.yml down`。
3. 不使用 `down -v`：它会删除数据卷，删了无法恢复。只有用户明确授权了具体项目和数据范围，才执行删卷。

## 坑位记录（迁移实战沉淀）

- **frpc.toml 里 log 段的位置**：`log.*` 段写在文件末尾（`[[proxies]]` 之后）会被解析进最后一个 proxy，导致 `unknown field "log"` 拒绝启动。把 log 段放在第一个 `[[proxies]]` 之前。
- **proxy already exists**：说明同名 proxy 还被另一台机器的 frpc 占着（迁移切换期间常见）。停掉旧端后，用 `launchctl kickstart -k` 重启本端 frpc 即可接管。
- **Docker CLI 凭据**：SSH 会话的 PATH 需要包含 `~/.local/bin`（docker、docker-compose、docker-credential-desktop 三个符号链接都在这里），否则 `docker pull` 会报 credential-desktop not found。
- **macOS 的 find 不支持 `-perm +111`**：BSD find 用 `-perm -111`。
- **Windows → Mac 的迁移通道**：用 paramiko（因为中文用户名）拉到本机，再 rsync 推到 Mac mini。ps1 脚本请保持**纯 ASCII**，PowerShell 5.1 解析无 BOM 的 UTF-8 中文会出错。

## 报告

```text
【sub2api/FRP/CPA 报告（Mac mini）】
- 模式：start|stop|status
- Docker/Compose：{PASS/FAIL + 版本与服务状态}
- 本地健康：{URL + status}
- frpc：{PID + TCP Established 与否}
- 公网健康：{URL + status}
- cpa(8317)：{监听状态}
- 总体：PASS/FAIL
- 保留数据：是（未执行 down -v）
- 风险/失败恢复：{可复核事实}
```
