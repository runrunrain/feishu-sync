---
description: 管理已定位的 sub2api、FRP 与 CLIProxyAPI 服务，按模式检查、启动或停止
argument-hint: "[start|stop|status，默认 start]"
---

# sub2api、FRP 与 CLIProxyAPI

$ARGUMENTS

读取 [部署资料](../resources/prompt-guides/device-profiles.md) 对应节，核对实际宿主、配置与服务标识。路径相对本 prompt 文件解析。当前在其他设备时使用已验证远程入口，不把本地命令误当远端操作。

解析 start / stop / status，默认 start；未知模式说明支持值。仅查看诊断必要的配置键，不输出数据库密码、JWT、FRP token 或 API key。

## status

只读核对 Docker、Compose 服务及健康状态、两个 launchd job、端口与健康端点。FRP TCP 连接及公网 HTTP 均需验证，并确认响应属于目标服务；空日志不等于失败，其他程序监听端口不等于目标服务正常。

## start

1. 核对配置属于目标部署，版本以当前配置为准，本命令不升级版本。
2. Docker 不在线时按当前宿主方式启动；每个等待阶段最多 120 秒，分段探测并报告进度。
3. 对确认的 Compose 文件执行 up -d，核对本地健康。
4. job 未加载时 bootstrap；已加载但需要恢复时 kickstart。label 和 plist 来自核实配置，健康服务不重复重启。
5. 验证服务、隧道和端点；部分成功逐项报告。proxy 名被占用时查归属，不自动停止另一台设备。

## stop

停止本部署两个 job，对确认的 Compose 项目执行 down，保留卷。回读 job、容器与监听确认已停止；已停止视为目标已满足。本命令不删除数据卷。

## 结果

按模式报告实际宿主、动作、状态、健康或停止证据及失败恢复入口。超时后先查现场再重试，不把未知状态当已停止；未验证备份时不承诺可回滚。
