---
description: 扫描当前代码库，生成或改进 AGENTS.md / CLAUDE.md 上下文文件，为后续 Agent 会话提供高频命令与宏观架构指引
argument-hint: "[optional: 指定目标文件（agents/claude）或需要强调的侧重点]"
---


# 初始化仓库上下文文件（AGENTS.md / CLAUDE.md）

$ARGUMENTS

根据仓库实际约定更新 Agent 上下文。文字遵循 [共用规则](../skills/agent-document-output/reference/writing-rules.md)，相对路径以本 prompt 文件为基准。

## 先确定写哪个文件

pi 启动时按目录加载 `AGENTS.md`（缺失时回退到 `CLAUDE.md`；存在 `AGENTS.override.md` 时它覆盖二者）。据此确定本次目标：

- 仓库已有文件：优先使用用户指定目标；未指定时沿用当前实际生效文件。先完整读一遍，在原文件上**增量改进**，保留用户已有的内容与结构；
- 两者都没有：默认创建 `AGENTS.md`（pi 的主上下文文件）；
- 参数指定 `agents` 或 `claude`：只处理对应文件；两者都指定时共用仓库事实，保留各宿主特有规则，不要求全文相同；
- 存在 `AGENTS.override.md`：核对当前宿主的加载顺序；用户已指定目标时直接处理，若“更新生效指引”与目标冲突才说明并澄清。

参数之外的文件不用新建，免得仓库里多出没人维护的副本。

## 写什么：两类内容

1. **高频命令**：构建、lint、测试怎么跑，包括怎么跑单个测试，以及在本仓库开发需要的其他关键命令。每条命令都从 package.json、Makefile、脚本或现有文档里查证得来——查不到的就不写，后来者会照着它直接执行。
2. **宏观架构**：需要读多个文件才能拼出来的大图景，比如模块边界、数据流、关键约定。单个文件一眼能看懂的内容不必写。

## 先扫描已有资料

- 有 `README.md`：提炼其中的关键信息；
- 有 Cursor 规则（`.cursor/rules/`、`.cursorrules`）或 Copilot 规则（`.github/copilot-instructions.md`）：吸收其中的重要规则；
- 仓库里其他 AI 指引（如 `docs/` 中的 agent 说明）：只取仍然有效的约定；过时的内容不写入，在报告里注明。

## 哪些内容不写

这些内容不携带本仓库的特有信息，写进去只会稀释真正有用的部分：

- 通用建议，如「提供友好的错误提示」「为新工具写单测」「不要在代码或提交中包含密钥」；
- 通用开发实践和套话；
- 看文件树就能发现的浅层组件或目录罗列；
- 重复表达的同一信息；
- 读到的文件里找不到依据的内容，如套路化的「常见开发任务」「开发小贴士」「支持与文档」章节。每一条都应能在读取过的文件中找到出处。

## 文件头部

新建文件可采用以下头部，沿用项目语言和既有格式，不强制固定前缀：

`AGENTS.md`：
```markdown
# AGENTS.md

This file provides guidance to coding agents (pi and compatible agents) when working with code in this repository.
```

`CLAUDE.md`：
```markdown
# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.
```

已有自定义头部保留。只整理影响后续工作的实际信息，不因模板存在就补空章节。

## 输出

检查引用路径及命令来源；“已找到命令”与“已运行通过”分开。报告按实际内容裁剪。

```text
【init 报告】
- 目标文件：{创建/改进的文件路径}
- 依据来源：{实际读取并采纳的文件清单}
- 收录命令：{build/lint/test/单测等}
- 架构要点：{摘要}
- 未采纳内容：{过时/无法证实的来源与原因}
- 改进建议：{仅改进模式下，本次未落笔但建议主上决策的项}
```
