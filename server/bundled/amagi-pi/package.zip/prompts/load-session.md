---
description: 会话启动时加载项目状态、知识体系和待办事项，快速进入工作状态
argument-hint: "[optional: 指定关注领域或额外加载指令]"
---


# 加载会话状态

$ARGUMENTS

这一步帮你在会话开始时快速接上项目的上下文：当前是哪个项目、有哪些约定和知识、手头还有什么待办。目标是用最少的读取进入状态——先加载索引标记为高优先级的内容，其余等任务需要时再展开。

## 定位项目

从当前目录逐级向上找 `projects-memory/projects/registry.json`。找到后，它所在的工作区就是 `WORKSPACE_ROOT`；读取 `activeProject` 和对应的 `projectPath`，得到：

- `PROJECT_META_ROOT={WORKSPACE_ROOT}/projects-memory/projects/{activeProject}`
- `PROJECT_CODE_PATH=registry.projects[activeProject].projectPath`
- `TODOS_DIR={WORKSPACE_ROOT}/projects-memory/todos`

如果 registry 不存在、JSON 无效、activeProject 未注册或项目路径不存在，就在这里停下，准确报告缺的是哪一项。猜出来的路径很可能加载到别的项目，反而误导后续工作。环境变量可以作为兼容回退，用到时在报告里注明。

## 启动时加载

按存在性依次读取：

1. `{PROJECT_META_ROOT}/context.json`：项目类型、技术栈、加载策略；
2. `{PROJECT_META_ROOT}/memory-map.json`：静态/半静态的项目状态、关键路径、技术要点、风险、快速启动和协作约定；
3. `{PROJECT_META_ROOT}/knowledge-base/index.json`：只加载索引中 `priority: high` 且 `autoLoad: true` 的知识文件，通常是 glossary、development-specs、conventions；
4. `{PROJECT_META_ROOT}/knowledge-base/domains/index.json`：只读领域注册表，领域内容先不展开；
5. `{PROJECT_META_ROOT}/tactical-book/index.json`：只加载索引指定的高优先级条目；条目结构以索引实际内容为准（例如不要预设存在 percentile 字段）；
6. `{TODOS_DIR}/待办事项概览.md`，以及存在时的 `{PROJECT_META_ROOT}/project-context.md`。

**按需再展开**：

- 参数或当前任务涉及活跃任务时，再读 `task-index.json`，并选择性读取 `tasks/task-*.json`；`task-archive.json` 只在用户要求查看历史时读；
- 领域知识在以下任一情况下展开：任务文件命中领域的 `modules`、任务关键词命中 `tags`、或 $ARGUMENTS 指定了领域。只读命中领域里需要的文件。

## 输出

报告实际发现的内容就好，不需要固定的宣传式文案：

```text
【会话加载报告】
- 当前项目：{id/name}
- 代码路径：{PROJECT_CODE_PATH}
- 已加载：{文件与知识分类}
- 未加载/缺失：{可选文件或原因}
- 活跃待办：{按优先级列出；无则写无}
- 阻塞：{阻塞项}
- 建议下步：{与当前任务最相关的一项}
```

报告只描述当前 runtime 真实提供、且本任务已经选用的协作模式或 Agent；没有启用的就不提，免得后续按不存在的能力规划。
