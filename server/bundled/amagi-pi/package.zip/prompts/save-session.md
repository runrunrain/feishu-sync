---
description: 会话结束时保存项目状态、更新任务记录和记忆地图，准备下次会话
argument-hint: "[optional: 额外备注或需要强调的事项]"
---


# 保存会话状态

$ARGUMENTS

这一步把本次会话的进展写回项目记忆，让下一次会话（可能是你，也可能是别的 Agent）能直接从断点继续。写进去的内容会被当作事实使用，所以只记录本次会话里有证据的事；拿不准的写成待确认，比写成结论更有帮助。

## 定位与写入前检查

从当前目录逐级向上找 `projects-memory/projects/registry.json`，读取 `activeProject`，得到：

- `PROJECT_META_ROOT={WORKSPACE_ROOT}/projects-memory/projects/{activeProject}`
- `TODOS_DIR={WORKSPACE_ROOT}/projects-memory/todos`

registry、activeProject 或目标 JSON 无效时，停下来报告问题，不猜路径、不覆盖文件——写错位置的记忆比没有记忆更难发现。环境变量可以作为兼容回退。

写入每个文件前先读取它的现有结构，保留你不认识的字段。

## 保存步骤

1. **待办概览** `{TODOS_DIR}/待办事项概览.md`：只改本次确实完成、推进或阻塞的事项。新增断点时写清文件路径、必要的行号、状态和下一步，方便下次直接接上。
2. **任务索引** `{PROJECT_META_ROOT}/task-index.json`：同步活跃任务状态。完成或取消的任务从活跃列表移到 `task-archive.json`（去重追加），并按现有 schema 更新 `summary.archiveStats`。schema 和预期对不上时，这一项迁移先不做，在报告里说明——自行发明结构会让后续读取出错。
3. **任务详情**：新任务按现有命名约定写入 `tasks/task-{YYYYMMDD}-{seq}.json`；已有任务原位更新，不重复创建。
4. **记忆地图** `memory-map.json`：只写静态/半静态信息，如关键路径、feature flag、技术要点、已验证的风险和快速启动方式；动态的任务进度留在 task 文件里。路径用项目变量或可迁移的项目相对路径。
5. **项目上下文** `context.json`：写入 `lastAccessDate`；`progress`、`currentPhase` 只在有事实依据时更新。

每个 JSON 写完后重新解析一遍确认有效。发现文件被并发修改或内容冲突时，停止写这个文件并报告，保留别人的改动。

这个命令只更新项目记忆，不提交 Git、不推送、不发布。

## 输出

```text
【会话保存报告】
- 项目：{项目}
- 已更新文件：{路径与字段摘要}
- 完成任务：{列表}
- 进行中/断点：{列表}
- 阻塞：{列表}
- JSON 验证：PASS/FAIL
- 未写入项：{原因}
- 建议下步：{下一动作}
```
