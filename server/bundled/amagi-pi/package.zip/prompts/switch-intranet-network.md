---
description: 在不同网络间切换 battle-simulator 内网部署的监听 IP（公司↔家↔热点等），自动探测当前私网 IP 并重新发布
argument-hint: "[可选：显式私网 IP；留空则自动探测当前主网卡地址] [--no-deploy：只改配置不发布]"
---


# 切换 battle-simulator 内网网络

$ARGUMENTS

这个命令把 battle-simulator 的内网部署从一个网络迁到另一个网络。

背景是这样的：内网服务只监听 `deploy/intranet.env` 里写定的那个私网 IP。换了网络（公司带回家、连热点、换 Wi-Fi）之后 IP 变了，就会出现「容器在跑，但谁也连不上」。根因只有这一个，所以处理也很直接：更新配置里的 IP，然后重新发布。数据库数据不受影响。

## 直接执行

主上调用这个命令，就是授权你直接完成整个流程：探测 → 改配置 → 发布 → 验证。不需要逐步确认，也不用先复述计划等回复——一路做完再给报告，对主上最省事。

只有遇到下文列出的「停止条件」时才停下，并在报告里说明停在哪里、为什么。

## 项目位置

项目根目录：`/Users/maorun/maorun-workpace/battle-sim/battle-simulator`。关键文件：

- `deploy/intranet.env`：内网配置，这个命令要改的就是其中三行 IP。文件里还有密码和令牌，**只改 IP，其他行不回显、不改动**（密码、SESSION_SECRET、各种 token）。
- `deploy/production.sh`：发布脚本，使用 `release --profile intranet` 子命令。
- `docs/内网部署指南（macOS 与 Windows）.md`：完整的人工流程，命令走不通时可以参考。

如果 `deploy/intranet.env` 不存在，停下来报告：可能不在正确的项目里，不要创建空配置。

## 参数

- 第一个非 flag 参数如果形如私网 IP，就作为**显式 IP** 使用（跳过自动探测，但仍要校验）。
- `--no-deploy`：只改配置并打印新值，不发布。适合想先改好、稍后手动发布的场景。

两者可以组合。遇到其他不认识的参数，停下来报告，不去猜意图。

## 1. 确定目标 IP

有显式 IP 就直接用；否则探测当前主网卡的私网地址：

```bash
ipconfig getifaddr en0
```

`en0` 没有地址时再试 `en1`；仍然没有就停下报告（可能是有线网卡或其他网卡，请用户用显式 IP 重跑）。

**校验 IP**（不满足就停下）：

- 是合法的 IPv4，并且属于 RFC1918 私网段（`10/8`、`172.16/12`、`192.168/16`）。可以用 `python3 -c "import ipaddress; print(ipaddress.ip_address(IP).is_private)"` 校验。
- 不是 `127.0.0.1`（loopback）、Docker/WSL 虚拟网卡地址或公网地址。
- 如果和 `deploy/intranet.env` 里现有的 IP **相同**，说明不需要切换：打印状态后正常结束（退出码 0），省掉一次发布。

## 2. 改配置

读取 `deploy/intranet.env`，用 Edit 把下面三行中的**旧 IP** 换成**新 IP**（三行的旧 IP 相同，用 `replace_all` 一次替换即可）：

- `INTRANET_HOST`
- `INTRANET_BIND_ADDRESS`
- `PUBLIC_ORIGIN`（形如 `http://<旧 IP>:8080`，只替换 IP，端口 `8080` 不变）

**保持不变**：`POSTGRES_PASSWORD`、`DATABASE_URL`（它的 host 是内部服务名 `postgres`，和本机 IP 无关）、`SESSION_SECRET`、`DRAIN_TOKEN`、`METRICS_TOKEN`，以及其他所有行。

改完用 `grep` 复核三行一致：`INTRANET_HOST` 和 `INTRANET_BIND_ADDRESS` 相同，`PUBLIC_ORIGIN` 恰好等于 `http://$INTRANET_HOST:$INTRANET_HTTP_PORT`。不一致就停下报告。发布脚本的预检也会发现这个问题，但在这里提前发现能省下一次构建的时间。

如果带了 `--no-deploy`，打印新配置的三行后结束。

## 3. 重新发布

在项目根执行（**末尾不带 `--sync-bundled-content`**，原因见下）：

```bash
bash deploy/production.sh release --profile intranet \
  --env-file deploy/intranet.env \
  --backup-dir "$HOME/.battle-simulator-backups" --apply
```

这是长任务（包含镜像构建，首次或代码有变动时需要几分钟），建议后台执行并轮询日志。脚本内部依次：备份数据库到 `~/.battle-simulator-backups` → 构建 → 排空并重建 authority → 重建 proxy（这一步让端口绑定到新 IP）→ 等待 healthy → 观察 15 秒确认稳定。数据库卷 `battle-simulator-intranet-pg` 会保留，不会被删除。

**为什么不带 `--sync-bundled-content`**：切换网络只是改 IP 绑定，不需要它。这个参数用于同步内置场景（襄阳/江汉），是更新地图的独立步骤；如果数据库里某个内置场景缺少已发布的修订，它会抛出 `seed refuses upgrade`，让脚本返回非零退出码（服务其实已经起来了，但脚本判为失败）。需要更新地图时，单独按日常更新流程执行。

**停止条件**：

- 发布脚本退出码非 0，**并且** proxy 容器没有成功重建、没有绑定到新 IP（见第 4 步验证）。如果退出码非 0，但 proxy 已正确绑定新 IP 且 `/healthz` 返回 200，说明是脚本在后续无关步骤报错、切换目标已经达成——按「切换成功 + 附带告警」报告，不判为失败。
- 构建或健康检查阶段失败。保留终端日志供排查。请不要执行 `docker compose down -v`：它会删除数据库卷，数据无法恢复。

## 4. 验证

依次确认（都是只读操作）：

1. `docker ps --filter name=intranet --format ...`：三个容器都在，proxy 的端口列显示 `<新 IP>:8080->80/tcp`，authority 和 postgres 为 healthy。
2. `lsof -nP -iTCP:8080 -sTCP:LISTEN`：监听地址是 `<新 IP>:8080`。
3. `curl -s -o /dev/null -w "%{http_code}" --max-time 8 http://<新 IP>:8080/healthz` 返回 200，body 含 `"ok":true,"phase":"serving"`。
4. 可选：用旧 IP `curl` 应当超时（旧地址自然失效，这是正常的）。

## 5. 在报告里提醒主上

- 浏览器 cookie 按主机名绑定，旧地址的登录状态不会带到新地址，**需要在新地址重新登录一次**——这是浏览器行为，不是数据丢失。
- 账号、房间、对局和历史数据全部保留。
- 新的访问地址：`http://<新 IP>:8080/`。

## 报告

```text
【内网网络切换报告】
- 项目：battle-simulator 内网部署
- 旧 IP：{旧值}（来源：deploy/intranet.env）
- 新 IP：{新值}（来源：{自动探测en0/显式参数}）
- 校验：RFC1918 私网 {PASS/FAIL}
- 配置改动：{三行已更新/无需变更（新旧相同）}
- 发布：{--no-deploy 未发布 / 退出码 / proxy 重建结果}
- 验证：容器 {3/3} / 监听 {新IP:8080} / healthz {状态}
- 新访问地址：http://{新 IP}:8080/
- 提醒：需在新地址重新登录一次（非数据丢失）
- 附带告警：{若有，如脚本非零退出但服务已正常 / 无}
```
