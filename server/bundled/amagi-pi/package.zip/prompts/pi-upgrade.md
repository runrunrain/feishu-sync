---
description: pi 宿主新版本发布后迭代适配 amagi-pi——版本差异取证、兼容排查修复、版本锚/图片准入随升、新能力强化分析与落地（编排模式）
argument-hint: "[目标 pi 版本；缺省核对 npm latest]"
---

# pi 宿主升级适配（pi-upgrade）

$ARGUMENTS

## 目标

pi 宿主发布了新版本，这一轮把 amagi-pi 的开发基线从当前版本升到目标版本。要做的事分两类：

- **适配**：逐项排查兼容变更并从根因修复，同步版本锚和文档口径，按真实取证扩充图片宿主准入；
- **强化**：分析新版本带来的能力，看插件能借此为模型做得更好的地方，其中高价值、低风险的项经 Gate 裁定后落地。

读取 [workflow](../skills/workflow/SKILL.md) 组织实际依赖，资源路径相对本 prompt 文件解析；已有适配计划复用节点与证据，不另造重复状态。下面阶段按变更规模裁剪，强化分析没有实质价值时可省略。

## 全程保持不变的几件事

- **保留当前仓库声明的最低兼容基线**：先读 AGENTS.md 与 package.json，不能把提升开发依赖等同于提高最低兼容版本。新字段、新 API 按实际载荷和 typeof 探测降级使用；不要经私有 deep import 取包根没有导出的符号——它们随时可能改名，老用户也没有。
- **不升级全局 pi、不 git commit、不发布**。改动放在适合当前任务的隔离 worktree，已有适用 checkout 可复用；集成遵循当前任务已有指令，不重复询问已明确的决定。主树原有改动保持原样。
- **权限设计不因宿主适配而放宽**：TaskSpec、四方交集、三轴语义、显式 `--tools` 名单都保持现状。
- **图片宿主准入只凭真实取证**：实测通过的版本才加入 `IMAGE_DECODE_VERIFIED_HOST_VERSIONS`。强化项也一样，宁少勿虚——没有真实收益的功能不必为凑数而做。

## Phase 0：Leader 取证（直接处理，产物落 `agent-outputs/workflow/pi-<目标版本>-adapt/`）

1. 确认版本：`npm view @earendil-works/pi-coding-agent dist-tags`；当前基线读 `package.json` devDependencies；`pi --version` 只说明全局宿主。
2. 拉新包到临时目录：先读取目标宿主的依赖清单，分别核对 coding-agent / ai / agent-core / tui 的实际配套版本，不假定所有包同版本号。使用 npm pack 下载到系统唯一临时目录并记录包版本与校验信息；Windows 不硬编码 /tmp。
3. 产出两份证据文件：
   - `pi-<目标版本>-changelog.md`：从新包 `CHANGELOG.md` 截取「当前基线（不含）→ 目标版本」之间所有节（跨多个版本时全部保留）。
   - `pi-<目标版本>-api-diff.txt`：使用当前平台可用的 diff 工具对比仓内 `node_modules/@earendil-works/<pkg>/dist` 与新包 dist（公共 d.ts），外加 `pi-coding-agent/docs` 目录 diff。
4. Leader 初筛：逐条 changelog（Breaking / New Features / Changed / Fixed）+ d.ts 删除/新增导出，grep `extensions/amagi-core/**/*.ts` 与 `tests/` 找消费点，列出「变更 → 潜在影响点」表（I1..In）。高频风险面优先核：
   - 子进程 spawn 参数（`--model` / `--tools` / `--mode json` / resume）：task-run、json-execution-adapter、rpc-pool(-tool)、task-resume、task-background、task-tool；
   - 选模与诊断：model-resolver（normalizeModelSpec）、configuration-diagnostics、compaction-*；
   - 事件/钩子形态：guards、edit-guard、before_agent_start、session_start、tool_call；
   - 错误分类与重试：reliability（TRANSIENT_PROVIDER_RE / CHANNEL_DISCONNECT_RE）、child-network-recovery；
   - UI：workflow-board overlay、status-ui；图片：image-decoder；MCP：mcp-native；codemode：codemode-adapter；
   - 被删除/改名的导出是否有直接 import。
5. 建 `workflow.md`（目标与总验收、输入证据、初筛表、Phase 表、跨边界链路、决策日志），按 workflow 技能最小结构。

## Phase 1（并行，无共享写入）

### P1a 适配（luban，隔离 worktree）

依赖安装在适配 checkout 中，不通过共享可写 node_modules 改变旧基线；工作目录、依赖可见性和报告路径在任务书中明确。
任务书包含以下内容：
1. devDependencies 三包（pi-coding-agent / pi-agent-core / pi-ai）精确锁已核实的目标配套版本，`npm install` 更新 lockfile。
2. 初筛表逐项排查：有影响→修根因 + 正/负成对测试；无影响→文件:行证据（源码 grep + 新包 dist 实现 + 旧基线主树只读对照）。
3. 版本锚随升：检索旧版本号及实际消费点，现有入口包括 `tests/helpers/pi-099-dispatch-fixtures.mjs`、`tests/helpers/pi-099-opportunity-fixtures.mjs`、`tests/host-constrained-sampling.test.mjs` 的 `EXPECTED_PI_VERSION`，`tests/pi-099-codex-composer.test.mjs` 受测包版本锚，以及读 node_modules provider 目录数据的测试（如 `tests/b5-sampling-tiering.test.mjs`）。锚点失败时，先对照旧基线确认它是「目录/版本随新包变化」而不是真实回归，再改锚。
4. 图片准入取证：`node --test tests/c14-image-evidence.test.mjs`——宿主版本取自仓内 devDependency（`detectHostPackageVersion`），无需全局 pi。加入前应先看到 host-version-unverified 拒绝（负向证据），加入目标版本后全套通过才算准入；同步 image-decoder.ts 集合与取证注释、c14 断言。
5. 文档口径：AGENTS.md「pi 版本口径」（开发类型基线 / 图片宿主准入集）、README、CONTRIBUTING 同口径；`package.json` version 升补丁位并新增 CHANGELOG 同版本节（中文，参照既往「pi x.y.z 开发基线升级」节：适配项 + 逐项结论 + 版本锚 + 准入取证）。
6. 真实入口：用 worktree 内适配当前平台的 pi 可执行入口（如 Windows 的 pi.cmd，先 --version 确认目标版本）验证 amagi spawn 参数形态（`--mode json -p --model provider/id --tools a,b,c --name x`）可被解析，并以至少一个负例证明新行为；无凭据时以「鉴权后置失败」为解析成功的边界证据，说明证据强度。
7. 验证：`npm run typecheck`、`npm run depcruise`、`npm run docs:check`、`npm test` 全量；有失败时逐条归因。
8. 报告：`agent-outputs/workflow/pi-<目标版本>-adapt/p1a-adapt-report.md`（改动清单、I1..In 结论+证据、取证、命令真实输出摘要、残留风险、附拓展线索、回滚）。注：worktree 任务报告可能落在 worktree 内同相对路径，Leader 收口时复制回主树。

### P1b 强化分析（fuxi 设计态，只写报告）
对每项新能力/行为变更与新增 d.ts API：现状（文件:行）→ 可做什么 → 可观察收益 → 风险与旧宿主降级 → 成本；区分「包根正式导出」与「仅 d.ts 可见」；不建议做的项也如实列出，这同样能帮 Leader 做取舍。分级 P0（本次落地，含改动范围、验收矩阵、回滚）/ P1（进入条件）/ 不做；末尾单列「交给 P1a 的适配风险摘要」。
产物：`agent-outputs/workflow/pi-<目标版本>-adapt/p1b-expansion-analysis.md`。

P1b 先完成时：accept 后把其「适配风险摘要」经 `task_control steer` 注入运行中的 P1a。

## Phase 2：Leader Gate → 强化落地

- 核验 P1a 的报告和 diff（抽查关键 diff，不只看摘要），确认后 accept。
- 对 P1b 的 P0 做裁定：采纳则 `task_resume` P1a 会话在同 worktree 落地（验收矩阵逐行对应测试名、经真实入口如 `registerAmagiCommands` handler 断言内容关键词、全量测试）；无 P0 则跳过并记决策。
- 报告：`p2-report.md`。

## Phase 3：集成审核（diting quick）

- 生成集成 diff 到 `p3-integrated.diff`，派 diting quick 审：新增拒单/校验是否误伤不相关路径、错误分类是否误把确定性错误归瞬时、诊断是否冒充结论或泄凭据、版本/文档口径一致。产物 `p3-review.md` + VERDICT。锁文件可用依赖变更摘要辅助阅读，但必须核对实际依赖与锁文件一致，不从审核范围中排除。
- findings 少而明确时，Leader 直接修复并补回归测试；多时一次性回派。只有出现 Critical/Major 或修改范围实质变化时，才增量复审一次。修正后按受影响范围重跑检查；最终集成按仓库要求执行全部门禁。长命令使用当前 runtime 提供的后台机制，不假设存在 run_bg。

## 收口

- 更新 workflow.md 状态与决策日志；主会话汇报：适配结论、强化落地、审核与修复、全量验证数字、残留风险、后续 P1 方向。
- 报告 worktree、变更、真实验证及未完成项。用户已明确要求集成时按其指令处理；仅做适配时保留可审阅结果，不自动提交或发布。
