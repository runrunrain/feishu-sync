---
description: 更新选定 SVN 工作副本，保留本地变更并报告合并或冲突
argument-hint: "[工作副本名或路径] [--username 用户名]"
---

# 批量更新 SVN 工作副本

$ARGUMENTS

读取 [仓库操作规则](../resources/prompt-guides/repository-operations.md)，路径相对本 prompt 文件解析。本命令只执行更新，不 add、delete 或 commit。

1. 用 svn info 识别工作副本及实际根目录，按参数精确筛选、去重；不依赖每个子目录都存在 .svn。
2. 分别读取 URL、revision 及 status，优先使用 XML 等结构化输出。已有文本、属性、树冲突或锁异常时跳过，不自动 resolve 或 revert。
3. 记录本地修改和未跟踪项。svn update 可将远端变化合并进本地文件；保留用户修改不意味着文件字节不变。未跟踪项若阻挡远端新增路径，报告障碍，不删除。
4. 对确认的工作副本执行 update，保留退出码及 U/A/D/G/C 结果；外部引用未明确纳入时加 `--ignore-externals`，不默认跨入其他副本。
5. 更新后再次读取 status、revision；发现冲突时列出路径和辅助文件，保留现场，不自动选择 mine/theirs。单个副本失败不影响其他独立副本。

网络或认证失败有界重试，状态不明先回读。默认使用缓存凭证，可指定用户名，不把密码放进参数。中文输出优先读取 XML 并按实际编码解析，不预判乱码一定只影响显示。

报告旧/新 revision、本地修改的合并结果、冲突和失败阶段；不能把更新后的文件称为“完全未变”。
