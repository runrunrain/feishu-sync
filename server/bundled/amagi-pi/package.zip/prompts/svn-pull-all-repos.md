---
description: 安全更新工作区内一个或多个 SVN 工作副本；保留本地修改，冲突时停止并报告
argument-hint: "[optional: 工作副本名；可附加 --username <用户名>，密码从缓存/安全环境读取]"
---


# 批量更新 SVN 工作副本

$ARGUMENTS

这个命令把工作区里的 SVN 工作副本更新到远端最新 revision。

SVN 是集中式版本控制，**「拉取」就是 `svn update`**。它和 Git 有一个关键区别值得先了解：SVN 没有 stash/rebase，本地未提交的修改没法先暂存起来。`update` 会直接把远端变更和本地修改做三路合并，合不上时产生冲突（`C` 状态），等人来处理。所以这个命令保留本地修改、让它参与合并；一旦出现冲突，就停下交给用户，不自动选择 mine/theirs，也不清理冲突。

这个命令只更新，不执行 add/delete/commit。

## 直接执行

主上调用这个命令，就是授权你一次性串行处理全部选中的工作副本。不需要逐个副本或逐步确认，也不用先复述计划等回复——处理完给一份汇总报告。

遇到以下情况，该副本停下并记入报告，然后继续下一个：

- update 之前已经存在 `C`、树冲突或工作副本锁异常；
- update 之后产生了文本/属性/树冲突（列出冲突路径，不自动 resolve）；
- 网络或认证失败。

本地未提交的修改和未跟踪文件（`?`）**不需要停下**：前者参与三路合并，后者不受 update 影响。记录受影响的路径后继续即可。

## 范围与认证

从当前目录向上找 `projects-memory/projects/registry.json`，扫描它所在工作区的直接子目录和 registry 的 `projectPath`；找不到就用当前工作区根。根目录存在 `.svn` 且 `svn info` 成功的，识别为工作副本，规范化路径后去重。有参数时只处理名称/路径精确匹配的项。

默认使用 SVN 缓存的凭证，也可以传 `--username <name>`。密码只能来自交互认证、权限受限的 SVN 配置/认证缓存，或运行环境的安全注入——不要出现在 $ARGUMENTS、命令文档、报告或进程参数里，因为这些地方都可能被别人看到。无法安全认证时，停下来报告。

## 三路合并会发生什么

- 文本文件：本地是 `M`，远端也改了这个文件 → `update` 自动三路合并，可能产生冲突 `C`；
- 二进制文件：本地是 `M`，远端也改了 → 二进制没法合并，`update` 直接标记冲突；
- 本地未跟踪文件（`?`）：不受 `update` 影响。

## `svn update` 输出怎么读

每行开头的字母表示该条目的处理结果：

| 标识 | 含义 |
|---|---|
| `U` | Updated：远端改动干净地更新到本地 |
| `A` | Added：远端新增的文件/目录 |
| `D` | Deleted：远端已删除的文件/目录 |
| `G` | merGed：自动三路合并成功 |
| `C` | Conflict：冲突，需要手动解决 |

最后一行形如 `Updated to revision 566.`，给出新的 revision。

## 每个工作副本怎么处理

串行处理：

1. 读取 `svn info --show-item url/revision` 和 `svn status`，记录 `M/A/D/?/!/C/~`。已经有 `C`、树冲突或工作副本锁异常时，不执行 update，直接报告。
2. 先把有本地修改的路径记入报告。本地修改保持原样：不 revert、不 resolve、不删除、不覆盖。
3. 执行 `svn update <path>`，保留完整的退出码和状态摘要。失败时停止该副本，不做覆盖式的自动恢复。
4. 再运行一次 `svn status` 和 `svn info --show-item revision`。出现文本、属性或树冲突（树冲突在 `svn info` 里会有 `Tree conflict` 描述）时，把该副本标为失败，列出冲突路径以及 `.mine/.rOLD/.rNEW` 等辅助文件。冲突怎么解由用户决定，所以不执行 `svn resolve --accept ...`。
5. 没有冲突时，报告 old/new revision 和 `U/A/D/G` 摘要。

网络或认证失败时报告并继续下一个副本；报告里不出现凭据。首次 checkout 不在这个命令的范围内。

## 查看中文 log

在中文 Windows 的 GBK 终端里，`svn log` 默认输出的中文会显示为乱码。这只是**终端显示问题，存储的内容没有损坏**（和提交时编码不对造成的存储损坏是两回事）。正确查看方式：

- 用 `svn log --xml` 直接读取 UTF-8 存储的内容；或
- 先执行 `chcp 65001` 把终端切到 UTF-8，再查看。

## 报告

```text
【SVN 批量更新报告】
- 扫描根/选中范围：{roots/wcs}
- 已更新：{wc: rOLD -> rNEW, U/A/D/G 摘要}
- 已最新：{wcs}
- 保留的本地修改：{wc: paths}
- 冲突待决策：{wc: text/property/tree + paths}
- 跳过/失败：{wc: 阶段与错误}
- 安全确认：未 revert、未自动 resolve、未提交
```

## 和 Git 版本的差异速查

| 维度 | `pull-all-repos`（Git） | `svn-pull-all-repos`（SVN） |
|---|---|---|
| 核心动作 | `git fetch` + 快进 merge | `svn update` |
| 本地变更处理 | 工作区干净才快进，有变更就跳过 | 不 stash，本地修改直接参与三路合并 |
| 冲突单元 | 行级 / hunk | 文件级 / 属性级 / 树冲突 |
| 远程差异感知 | `git fetch` + behind/ahead 比较 | 没有本地差异概念，update 直接到位 |
| 离线操作 | 支持 fetch/merge 分离 | 不支持，update 必须连远端 |
| 网络代理 fallback | 命令级 `git -c http.proxy` | 通过 `~/.subversion/servers` 配置 |
