---
description: 快速准备 Windows 工作机（desktop-naalpfc）的连接：paramiko 通道验证、Tailscale 状态核查、故障排查路径
argument-hint: "[可选：diagnose 深度诊断模式]"
---


# Windows 工作机连接准备

$ARGUMENTS

这个命令帮你建立和 Windows 工作机的远程执行通道，并输出一份环境快照。

先说最重要的一点：**这台机器连不上 ssh 直连，请直接用下文的 paramiko 通道。** 原因是账户名是中文，OpenSSH 10.x 客户端会以 `remote username contains invalid characters` 拒绝它（系统自带版和 brew 版都是如此）。`~/.ssh/config` 里的 `winpc`/`win` 别名因此不可用，不必在这上面花时间。

## 设备事实（2026-10 实测）

- **主机**：DESKTOP-NAALPFC（Tailscale 设备名 `desktop-naalpfc`）
- **Tailscale IP**：`100.92.3.34`（内外网统一入口）
- **局域网 IP**：`192.168.5.11`（DHCP，可能漂移；可通过 SMB 445 端口识别）
- **账户**：`毛润`（中文 SAM 名，**管理员**，SSH 会话自带提权）。机器上没有 maorun 之类的英文账户——用这类名字认证时，防枚举机制同样会返回 Permission denied，看起来像密钥问题，其实是账户名不对
- **密钥**：`~/.ssh/id_ed25519_winpc`（已安装在毛润账户）
- **系统**：Windows 11（build 26200）/ 默认 shell 是 **PowerShell** / OpenSSH 服务端监听 22 / RDP 3389 关闭
- **v2rayN**：常驻运行，本地代理 `127.0.0.1:5800`（socks/http 混合端口），用户级系统代理已开启
- **Tailscale**：1.104.x（MSI 版）。服务级 `HTTP_PROXY/HTTPS_PROXY=http://127.0.0.1:5800` 已写入注册表（`HKLM\SYSTEM\CurrentControlSet\Services\Tailscale\Environment`，REG_MULTI_SZ），以 `--unattended` 模式运行（SSH 会话断开也不会停）
- **WSL**：已安装，但其中的 sshd（2222）没有运行，所以 config 里的 `win` 别名目前也不可用

## 连接通道

```bash
~/tools/sshvenv/bin/python ~/tools/win_ssh.py '<PowerShell 命令>'
```

- venv 和脚本已持久化在 `~/tools/`。venv 丢失时重建：`python3 -m venv ~/tools/sshvenv && ~/tools/sshvenv/bin/pip install paramiko`
- 复杂命令（嵌套引号、多条语句）建议先写成 `.ps1`，经 SFTP 上传到 `C:/Windows/Temp/`，再用 `powershell -ExecutionPolicy Bypass -File` 执行，省去层层转义的麻烦

## 连接验证

1. **快速验证**（默认，只读）：

   ```bash
   ~/tools/sshvenv/bin/python ~/tools/win_ssh.py 'whoami; hostname'
   ```

   预期输出包含 `desktop-naalpfc\毛润` 和 `DESKTOP-NAALPFC`。

2. **诊断模式**（参数为 `diagnose` 时）：
   - 本机 `tailscale status`：看 desktop-naalpfc 是否在线
   - `nc -z -G 2 192.168.5.11 22 / 445`：SSH/SMB 端口
   - 远端 `tailscale status --json`：取 BackendState（Running/NoState/NeedsLogin）
   - 远端 `Get-Process v2rayN`：确认代理在运行

## 故障排查（按命中概率排序）

1. **Tailscale 又离线了**（这台机器最常见的问题）：BackendState 不是 Running 时执行 `tailscale up --unattended`。服务级代理已注入，通常能自动恢复登录态。查询时尽量在一次会话里连续执行，避免反复短连接。如果 v2rayN 没在运行，先确认 5800 端口可用：`(Invoke-WebRequest -Uri "https://controlplane.tailscale.com" -Proxy "http://127.0.0.1:5800" -UseBasicParsing -TimeoutSec 15).StatusCode` 应返回 200。
2. **paramiko 认证失败**：多半是公钥丢了（如重装系统）。需要重新安装密钥时，用密码认证一次性注入公钥（密码不要写进脚本保存），完成后恢复为纯密钥认证。
3. **局域网 IP 漂移**：用 `nc -z` 扫描 `192.168.5.1-30` 的 445（SMB）端口找到 Windows 机器，然后更新本提示词里的 IP 记录（Tailscale IP 不受影响）。
4. **Windows 上的 sshd 停了**：22 不通但 445 通 → 执行 `Start-Service sshd`（管理员会话可以执行）。

## Windows 上 Tailscale 的坑位（实战沉淀）

- **服务进程不读用户代理**：tailscaled 作为服务运行，v2rayN 设置的系统代理对它无效。需要把代理写进服务的注册表 Environment：`reg add ... /v Environment /t REG_MULTI_SZ /d "HTTP_PROXY=http://127.0.0.1:5800\0HTTPS_PROXY=http://127.0.0.1:5800" /f`，然后 `Restart-Service Tailscale`。
- **断开即停机**：不是 unattended 模式时，SSH 会话里的 CLI 一断开就会触发 `client disconnected: disconnecting Tailscale`，相当于每查一次状态就把它关一次。所以请用 `tailscale up --unattended`。
- **两个 tailscaled 进程是正常的**：服务父进程加一个工作子进程，不是重复运行，不需要处理。
- **MSI 下载地址是小写**：`https://pkgs.tailscale.com/stable/tailscale-setup-latest-amd64.msi`。大写 Tailscale 开头的地址返回 404，会下到一个 10 字节的假文件。
- **静默升级**：`Start-Process msiexec -ArgumentList '/i','C:\Windows\Temp\tailscale.msi','/qn','/norestart' -PassThru -Wait`，ExitCode 为 0 即成功。MSI 先在本机（经 v2rayN 代理）下载，再用 SFTP 推过去。
- **PowerShell 语法**：`&` 不是命令连接符（`whoami & hostname` 会把 whoami 放进后台 Job），多条语句用 `;` 分隔。
- **登录链接**：auth URL 不一定出现在 CLI 输出里，从 `tailscale status --json` 的 AuthURL 字段取更可靠。

## 输出

```text
【Windows 工作机连接报告】
- paramiko 通道：PASS/FAIL
- Tailscale：{在线/离线，IP 100.92.3.34，BackendState}
- 局域网：{在线/离线，实际 IP}
- 系统信息：{Windows 版本/build}
- v2rayN 代理(5800)：运行中/停止
- WSL(2222)：可用/未运行
- 异常与建议：{排查项结论或"无"}
```
