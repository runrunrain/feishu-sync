---
description: 经测试与提交前敏感文件守卫确认后执行单仓库 GitHub Release：PATCH 版本、提交、tag、推送、Actions 与资产验证
argument-hint: "[version=<版本号> message=<无空格短slug> tag=<v版本> branch=<分支> plugin=<插件名>]"
---


# GitHub Release

$ARGUMENTS

这是一个显式的发布命令，处理当前这一个 Git 仓库。主上调用它，就授权你在全部检查通过后完成提交、打 tag、推送和创建 Release。

发布的特点是：tag、Release 和已推送的提交一旦公开就很难撤回，别人可能已经在引用它们。所以这个流程的思路是「每一步先确认再前进，出了问题就用新版本修，而不是改写已发布的东西」。以下几件事不在授权范围内：force push、覆盖已有的 tag 或资产、泄露 secret、发布归属不明的仓库。

## 参数

接受 `version`、`message`、`tag`、`branch`、`plugin` 五个键。出现未知键或互相冲突的值时，停下来向主上确认。`message` 只是一个无空格的 slug 候选，最终的提交信息根据实际 diff 来写。

- 没有指定版本：从唯一的发布目标读取当前 SemVer，目标版本为 PATCH +1；
- 指定了 `version`：它应当恰好等于当前 PATCH +1；
- `tag` 应等于 `v{target_version}`；只给了 tag 时，从中反推版本，再做同样的校验；
- 多插件仓库有多个候选时，用 `plugin=<name>` 指明是哪一个。

## 发布前检查

1. **仓库与权限**：确认仓库根、当前/目标分支、origin、上游、`git status` 和近期的提交风格。用 `gh auth status` 和 `gh repo view --json nameWithOwner` 核对当前身份对 origin 有写权限（owner 从这里读，不写死）。没有权限、没有 origin、处于 detached HEAD，或者是首次在远端发布该分支时，停下来报告。
2. **工作区状态与敏感内容**：检查是否有进行中的 merge/rebase/cherry-pick/bisect。读取变更路径后，先按路径和字段名排查敏感内容（`.env*`、私钥/证书、credentials、token/secret）；命中时只列出路径并停下，不打印内容。然后读完整 diff，确认所有变更都属于这次发布。
3. **和远端的关系**：`git fetch origin <branch> --tags`。只有远端与本地同点、或本地单向领先时才继续。远端领先或已分叉、且本地有变更时停下；即使工作区干净，是否 `pull --ff-only` 也由用户决定，不自动 rebase 或 merge。
4. **tag 与 Release 是否已存在**：本地和远端都不应有目标 tag，GitHub 上也不应有对应的 Release。如果已存在，停下来改用下一个 PATCH 版本，不删除、覆盖或重写已有的。
5. **保护用户现场**：不使用 `--force`/`--force-with-lease`、`git reset --hard`、覆盖式 `git checkout`、`git clean`，也不自动丢弃用户变更——这些操作会不可逆地丢掉现场。

## 测试与版本

**先跑验证，再改版本。** 优先读贡献/发布文档和 package scripts，找出仓库定义的验证方式，执行适用的 lint、typecheck、test、build；Python 项目用其声明的 pytest/构建入口，Makefile 用实际的 target。只有仓库流程明确需要时才安装依赖——用 `npm install` 来探测会改动锁文件。任何一项失败就停下。

**需要更新的版本字段**（按实际存在的文件）：

- `package.json`，以及存在时 `package-lock.json` 的根版本和 `packages[""].version`；
- 根目录 `.claude-plugin/plugin.json` 或 `plugins/<plugin>/.claude-plugin/plugin.json`；
- `.claude-plugin/marketplace.json` 中目标插件的条目；`metadata.version` 只在仓库现行约定要求时更新。

同一发布目标的各处现有版本应当一致，且符合 `MAJOR.MINOR.PATCH`。用 JSON 解析器把它们精确更新到 PATCH +1，保留未知字段和原有合法格式。不要用字符串全局替换——依赖版本之类相似的数字会被误改。更新后重新解析，逐字段核对。

**改完版本再验一遍**：重跑关键的 lint/typecheck/test/build，复查完整 diff、敏感路径，以及生成文件和锁文件是否一致。失败就停下，保留变更方便诊断。

## 提交前确认

发布提交不额外设审核环节：功能变更的审核已经在编排审核链里完成（见 `resources/core/collaboration/workflow-rules.md`），这里不重复。

提交前确认**最终要提交的 diff** 里不含以下内容：`.env*`/私钥/凭据/secret 类文件、`node_modules/`、`.git/` 内部文件、超过 10MB 的大文件；命中任何一项就停止发布。amagi 的提交守卫会始终拦下敏感文件和 `.git/`，但对 `node_modules/` 和大文件默认只是放行加提示，所以发布时由你在这一步把关。这一步和「发布前检查」第 2 步是同一道防线，不需要重复扫描，也不打印内容。

## 提交、tag 与推送

1. 精确暂存这次确认过的路径，再核对一遍 staged diff、测试证据和版本字段。没有变更就停下，不创建空提交。
2. 参照仓库历史写一条准确的 Conventional Commit：通常是 `chore(release): 发布 vX.Y.Z`；如果实际 diff 以功能或修复为主，就按实际选择 type/scope。正文列出真实的变更和验证结果，不固定添加署名。
3. 创建 annotated tag `v{version}`，指向刚才的 release commit。
4. 先普通推送分支，再普通推送 tag。网络失败时，只用用户已有的配置或单次命令级的代理重试，不修改全局或仓库的 Git 配置，也不 force。

某个阶段失败时，保留现状并停下：本地 tag 已创建的不删除；分支已推送而 tag 推送失败的，之后只做受控的补推；tag 已经到了远端的，任何修复都走新的 PATCH 版本。

## Release 与 Actions

用已认证的 `gh`：这个 tag 还没有 Release 时，按仓库的发布惯例创建（默认非 draft、非 prerelease）；如果已经存在，视为前置冲突，不去修改它。Release 的 target 应等于 release commit。

用 `gh run list` 找到 `headSha == release commit`、且由这次发布触发的 run，用 `gh run watch <id> --exit-status` 等待结果。成功的报告里要附上 workflow URL。以下情况发布不能算完成：找不到匹配的 run；run 失败；仓库声明使用其他 CI，却拿不到和这个 commit/tag 绑定的成功证据。

## 资产验证

Actions 成功后，用 `gh release view/download` 把资产下载到临时目录，记录资产名，然后验证：

1. Release 的 tag、target、draft、prerelease 都符合预期；
2. 资产命名符合仓库惯例，没有旧版本残留；zip 里的 manifest/plugin/package/update metadata 版本等于目标版本；
3. 有 checksum 文件时执行 SHA256 校验；没有时计算每个资产的 SHA256 写进报告；
4. 发现过期资产、版本错误或重复资产时停下，不删除或覆盖 Release 和资产；修复后发布新的 PATCH。

验证完清理本地临时下载目录，不影响仓库。最后核对 `git status`、HEAD/tag、远端分支、Release URL 和资产清单。工作区不干净时，如实报告剩下的内容，不要宣称已完成。

## 报告

```text
【GitHub Release 报告】
- 仓库/分支：{owner/repo @ branch}
- 版本：{old -> new}
- Commit/Tag：{sha / tag}
- Release URL：{url}
- Workflow URL：{url；成功必填}
- 敏感文件守卫：{通过 或 命中路径}
- 验证：{commands/results}
- 资产：{name -> sha256；manifest/update 版本}
- 工作区：{clean/剩余变更}
- 总体：PASS/FAIL（失败阶段与可恢复动作）
```

出问题时的恢复原则，汇总如下：测试、版本或提交前确认失败时不推送；commit 失败时保留暂存；本地 tag 不删除；已推送的 tag 和 Release 不改写，后续修复用新的 PATCH 版本。如实报告停在了哪一步、现场是什么状态，主上就能从断点继续。
