---
description: 敏感文件扫描与验证通过后将工作区内授权 SVN 工作副本的本地变更提交到远程；冲突或归属不明时停止
argument-hint: "[optional: 工作副本名；可附加 --username <用户名>，密码从缓存/安全环境读取]"
---


# 批量提交 SVN 工作副本

$ARGUMENTS

这个命令把工作区里授权 SVN 工作副本的本地变更提交到远端。

SVN 是集中式版本控制：`commit` 直接写入远端并生成新的 revision，没有「本地提交、稍后推送」这一层，也没有 branch/rebase/stash。提交一旦完成，其他人 update 就会拿到。所以每个副本都先过一遍检查（冲突、secret、归属、验证），全部通过才提交；有一项不过，就跳过这个副本、记入报告，继续下一个。

## 直接执行

主上调用这个命令，就是授权你直接处理选中的工作副本。不需要逐个副本或逐步确认，也不用先复述计划等回复；检查都通过就一路提交到底。

**审核**：功能变更的审核已经在编排审核链里完成（见 `resources/core/collaboration/workflow-rules.md`），提交时不重复审核，也不需要请主上手动确认或逐项询问是否提交。

**敏感文件**：amagi 的 `commit-guard` 只覆盖 Git，SVN 提交的敏感文件防线由这个命令自己的扫描承担，口径与它一致：`.env*`/私钥/凭据/secret 类文件、`node_modules/` 等依赖产物、超过 10MB 的大文件不进入提交。

**遇到以下情况，跳过该副本并记入报告**（不用问「是否继续」）：存在 `C`/`~`/树冲突/工作副本锁异常、命中疑似 secret、验证失败、update 时 out-of-date（`E160024`）或出现冲突、归属不明。提交归属不明、敏感或冲突的文件，不在这次授权范围内。

## 范围、归属与认证

从当前目录向上找 `projects-memory/projects/registry.json`，扫描它所在工作区的直接子目录和 registry 的 `projectPath`；找不到就用当前工作区根。用 `.svn` + `svn info` 识别并去重，按参数精确筛选。

提交前读取 `svn info --show-item url`，根据当前项目或用户维护的 allowlist、或明确的配置，核对 URL 前缀和负责的路径。不要把某个 IP、成员名或「主上」账号写死成通用的归属规则。归属不明确时只报告。

默认使用 SVN 缓存的凭证，也可以传 `--username <name>`。密码只能来自交互认证、受限的配置/缓存或安全的环境注入，不要出现在 $ARGUMENTS、命令行、临时提交信息文件或报告里。

## `svn status` 状态码

第一列状态码决定该条目怎么处理：

| 状态码 | 含义 | 处理方式 |
|---|---|---|
| `A` | 已标记新增（schedule add） | 在本次确认范围内，可直接 commit |
| `M` | 已修改 | 在本次确认范围内，可直接 commit |
| `D` | 已标记删除（schedule delete） | 在本次确认范围内，可直接 commit |
| `?` | 未纳入版本控制 | 不批量 add；只有被本次请求明确纳入、通过 ignore/敏感检查并复核后，才精确 `svn add` |
| `!` | 文件缺失（误删/丢失） | 不批量 delete；只有被本次请求明确纳入并复核后，才精确 `svn delete` |
| `C` | 冲突 | 跳过，不 commit，不自动 resolve |
| `X` | 外部引用（svn:externals） | 跳过 |
| `~` | 类型切换异常 | 记录并交给用户 |

`svn:ignore` 是防止误提交的第一道防线：依赖和构建产物（`node_modules/`、`dist/`、`*.log` 等）最好提前用 `svn propset svn:ignore` 配好，被忽略的项不会显示为 `?`，也就不会被误纳入。提交前仍然看一遍 `svn status` 的输出。

## 每个工作副本的检查

串行处理：

1. 读取 `svn status`、URL 和 revision。有 `C`、`~`、树冲突或工作副本锁异常时，跳过该副本，不自动 resolve 或 revert。
2. 对 `M/A/D/?/!` 读取实际变更，确认它们属于用户这次的请求。按路径排查 `.env*`、私钥/证书、credentials、token/secret 文件：只报告路径，不读取也不打印内容；命中就跳过。
3. `?` 和 `!` 不批量处理：只有路径已被这次请求明确纳入、通过 ignore/敏感检查并复核了内容，才分别精确执行 `svn add --parents -- <path>` 或 `svn delete -- <path>`。其余的保持原样并报告。
4. 运行项目能找到的 lint/typecheck/test/build；失败就跳过。读取最终的 `svn diff` 和 status，按仓库历史风格写提交信息。
5. 提交前最后确认一次：待提交的路径（包括第 3 步新 `svn add` 的）里没有 `.env*`/私钥/凭据/secret 类文件、`node_modules/` 等依赖产物、超过 10MB 的大文件；命中就跳过。
6. 提交前先 `svn update <path>`。出现 out-of-date（错误码 `E160024`，说明远端已有更新）或任何冲突时，跳过并报告：不替用户选择 mine/theirs，也不自动 update 后重试。没有冲突时，重跑 status、diff、关键验证和敏感文件扫描，确认合并进来的内容没有带来新问题。

## 提交信息与编码

**提交信息**基于真实 diff 生成，遵循仓库现有的历史风格（中文 conventional commits）。

格式模板：

```text
<type>(<scope>): <简短描述>

- <变更项1>: <说明>
- <变更项2>: <说明>

<补充说明（可选）>

Co-Authored-By: pi <noreply@pi.dev>
```

type：feat（新功能）/ fix（修复 bug）/ docs（文档变更）/ style（代码格式）/ refactor（重构）/ perf（性能优化）/ test（测试相关）/ chore（构建/工具/依赖）。

生成步骤：

1. 分析 `svn status` 和变更内容，确定 type 和 scope；
2. 写一句简短的中文描述（不超过 50 字符）；
3. 用 `-` 列表列出主要变更项；
4. 按仓库历史约定追加 `Co-Authored-By` 署名；用户明确不要时去掉。

**中文编码：这一步决定 log 会不会乱码。** 中文 Windows 上，SVN 客户端按系统 locale（GBK）解读提交信息，再转成 UTF-8 入库。如果直接用 `-m` 传参，或用 UTF-8 编码的 `-F` 文件，内容会被当作 GBK 误读，入库后 `svn log` 里的中文就是乱码——而且这是**存储损坏，不只是显示问题**。正确做法是写一个 GBK 编码、LF 行尾的临时文件，经 `-F` 传入，再用 `--xml` 验证存储：

```bash
# 1. 写 GBK + LF 临时文件（msg 为提交信息字符串，须 LF 行尾）
python -c "open('$msgfile','wb').write(msg.replace('\r\n','\n').encode('gbk'))"
# 2. 经 -F 提交（svn 按 GBK 读，正确转 UTF-8 入库）
svn commit <paths...> -F "$msgfile"
# 3. 验证存储无损，清理临时文件
svn log -r <rev> --xml
rm -f "$msgfile"
```

临时文件用受限权限，放在工作副本的待提交范围之外；无论成功失败都清理掉。

## 提交与验证

只提交这次确认范围内的路径：`svn commit <paths...> -F <message-file>`。提交后验证 `svn status`、新的 revision 和 `svn log --xml`。

**事后修正已损坏的中文 log**：如果 `svn log -r <rev> --xml` 显示中文存储已经损坏，可以在取得授权后用 `svn propset --revprop -r <rev> svn:log -F <GBK+LF 文件> <url>` 重写（需要服务器开启 pre-revprop-change 钩子；文件同样要是 GBK + LF，否则报 `E135000`）。这是事后补救，不属于常规提交流程。

大体积的二进制资源（如 PNG）首次提交时网络传输较慢；之后的增量提交不会重传已入库的文件。

不在这次范围内的用户变更可以继续留在工作副本里，在报告中列出即可；不要宣称整个工作副本是干净的。某个副本失败后继续下一个，不撤销用户的变更。

## 报告

```text
【SVN 批量提交报告】
- 范围/归属：{wc -> URL/allowlist 结论}
- 成功：{wc: rOLD -> rNEW, summary}
- 跳过：{无变更/非授权/敏感文件命中}
- 冲突/失败：{wc: 阶段与路径}
- 验证：{commands/results}
- 敏感文件守卫：{通过 或 命中路径}
- 保留的范围外变更：{paths}
```
