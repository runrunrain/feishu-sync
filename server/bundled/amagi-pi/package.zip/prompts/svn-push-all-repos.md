---
description: 核对并提交选定 SVN 工作副本的实际变更，验证修订号与提交说明
argument-hint: "[工作副本名或路径] [--username 用户名]"
---

# 批量提交 SVN 工作副本

$ARGUMENTS

读取 [仓库操作规则](../resources/prompt-guides/repository-operations.md)，路径相对本 prompt 文件解析。SVN commit 直接写远端，不存在 Git 式的本地 commit 后另行 push 阶段。

## 核对范围

通过 svn info 确认工作副本根、URL 与负责路径；读取 status 和 diff。检查文本、属性、树冲突及锁异常，不能只看 status 第一列。读取安全的变更内容，敏感值不输出。

A/M/D 在任务范围内可提交；? 只有明确纳入且通过内容及忽略规则检查时才精确 add；! 先核对是否为本次有意删除，再精确 delete。不批量处理未知项，不自动提交 externals。

## 更新与提交

1. 执行适用验证，按实际变更编写提交说明，不预填署名或成功结果。
2. 提交前按当前任务范围更新工作副本；外部引用未明确纳入时加 `--ignore-externals`。update 会合并远端内容，合并后重新核对 diff、路径与受影响验证；产生冲突则停止该副本，保留现场。
3. 将提交说明写为 UTF-8、LF 的临时文件，位于提交范围外。先核对当前客户端 `svn help commit` 的参数；支持时显式使用 `--encoding UTF-8 -F <file>`，不依赖系统 locale 猜编码。
4. 只 commit 已核对的路径，目录递归范围同样要检查；保留真实退出结果及新 revision。
5. 回读 status 和对应 revision 的 `svn log --xml`，核对提交目标、作者与中文说明。网络中断不明是否提交成功时，先查日志和远端状态，不直接重复 commit。

不因显示乱码直接改写历史 svn:log。先分清终端解码与存储内容；历史修订属性修复属于独立任务，不随常规提交自动执行。

临时文件只清理本次创建的文件；失败不撤销用户改动。报告 revision、提交范围、验证、范围外保留项与恢复入口。
