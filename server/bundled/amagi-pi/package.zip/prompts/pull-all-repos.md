---
description: 安全拉取工作区内一个或多个 Git 仓库；仅允许干净工作区快进更新，冲突或分叉时停止报告
argument-hint: "[optional: 指定仓库名，留空则处理扫描到的全部仓库]"
---


# 批量拉取 Git 仓库

$ARGUMENTS

这个命令把工作区里的 Git 仓库同步到远端最新状态。它只做一件事：在安全的前提下快进。凡是可能动到用户本地工作的情况（未提交的修改、分叉、进行中的操作），都跳过并报告，交给用户决定。这个命令只读同步，不提交、不推送。

## 直接执行

主上调用这个命令，就是授权你一次性串行处理全部选中的仓库。不需要逐个仓库或逐步确认，也不用先复述计划等回复——处理完给一份汇总报告，对主上最省事。

遇到下面这些情况时，该仓库停下、记入报告，然后继续下一个仓库：

- 仓库处于进行中的 merge/rebase/cherry-pick/bisect；
- 工作区有 tracked/untracked 变更或未完成的操作；
- 分叉：behind>0 且 ahead>0；
- fetch 遇到网络/认证失败，按已有代理配置重试一次后仍失败。

没有 origin、处于 detached HEAD、没有远程跟踪分支的仓库，标记为「跳过」后继续。

## 找到要处理的仓库

从当前目录向上找 `projects-memory/projects/registry.json`，用它所在的工作区根作为默认扫描根；找不到就用当前工作区根。`AMAGI_WORKSPACE_ROOT` 只作为兼容回退。扫描根从这些线索推导，不写死设备路径。

扫描根目录的直接子目录，加上 registry 里注册的 `projectPath`，用 `git -C <path> rev-parse --show-toplevel` 去重识别仓库。排除 `projects-memory`、`.claude`、`node_modules`、`dist`、`tmp/temp` 等非项目目录。

有参数时，只保留名称或规范化路径精确匹配的仓库；一个都没匹配上就停下报告。

## 每个仓库怎么处理

串行处理，每个仓库单独记录结果：

1. 读取 `git status --porcelain=v1`、当前分支、origin URL 和上游。没有 origin、detached HEAD 或没有远程跟踪时，跳过并报告。
2. 有 tracked/untracked 变更，或有进行中的 merge/rebase/cherry-pick/bisect 时，跳过该仓库并报告状态。用户的工作保持原样：不 stash、不清理、不覆盖。
3. `git fetch --prune origin <branch>`。遇到网络错误，可以用用户已有的代理配置，或用单次命令级的 `git -c http.proxy=... -c https.proxy=...` 指向已配置的本地端口重试；不修改全局或仓库配置。
4. 计算 `behind/ahead`：

| 状态 | 动作 |
|---|---|
| 0/0 | 已是最新 |
| behind>0, ahead=0 | `git merge --ff-only origin/<branch>` |
| behind=0, ahead>0 | 不改动，只报告本地领先 |
| behind>0, ahead>0 | 分叉；停下报告，由用户选择策略，不自动 rebase/merge/checkout |

5. 更新后复查 `git status --porcelain=v1`、`git rev-parse HEAD` 和最近的提交。出现失败时停止该仓库（不尝试自动解决冲突），继续处理下一个。

## 标注仓库归属

第 1 步读到的 origin URL 同时用来标注归属：和当前认证身份（`gh api user`）或用户配置的 allowlist 核对，识别仓库的 owner。拉取不影响远端，所以别人的仓库也可以照常只读同步，在报告里标出它的 owner 即可。不要把某个具体账号写死成通用的归属规则。

## 报告

```text
【Git 批量拉取报告】
- 扫描根与选中范围：{roots/repos}
- 已快进：{repo: old..new, commits}
- 已最新：{repos}
- 本地领先：{repo: ahead}
- 跳过：{repo: dirty/无上游/操作进行中}
- 分叉：{repo: ahead/behind，需用户选择策略}
- 失败：{repo: command/error}
- 用户变更：均未 stash、覆盖或清理
```
