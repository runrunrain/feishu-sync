---
description: 将选定 Git 仓库快进到已核对的上游，保留本地变更
argument-hint: "[仓库名或路径；留空处理已定位工作区的仓库]"
---

# 批量拉取 Git 仓库

$ARGUMENTS

读取 [仓库操作规则](../resources/prompt-guides/repository-operations.md)，路径相对本 prompt 文件解析。本命令更新本地工作区，不提交或推送。

1. 定位并去重仓库，核对工作区、当前分支、origin 和实际上游。无上游或 detached HEAD 时跳过；有进行中的 Git 操作、tracked/untracked 变更时保留现场并跳过。
2. fetch 实际上游 remote/ref，不假设上游与本地分支同名。只使用已核实远端。
3. 比较本地与上游：同点则已最新；仅落后则 fast-forward；仅领先则报告本地领先；分叉则停止该仓库，不自动 rebase 或普通 merge。
4. 快进后核对 HEAD、工作区状态和更新范围。失败保留现场并继续其他仓库。

报告 old/new 提交、领先/落后、跳过原因及失败恢复入口。能读取的其他 owner 仓库可拉取，不把 owner 一致当作读取条件。
