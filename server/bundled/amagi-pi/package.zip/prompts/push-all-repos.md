---
description: 敏感文件守卫与验证通过后，将工作区内授权 Git 仓库的本地变更提交并推送；插件类仓库会同步版本号，独立 OpenCode 插件会发布不可变 SemVer tag
argument-hint: "[optional: 指定仓库名，留空则处理扫描到的全部仓库]"
---


# 批量提交并推送 Git 仓库

$ARGUMENTS

这个命令把工作区里授权仓库的本地变更提交并推送到远端。对插件类仓库，还会顺带把版本号同步好；对独立的 OpenCode 插件，会发布一个不可变的 SemVer tag。

推送出去的东西别人可能马上就会用到，而且很难撤回。所以整个流程的思路是：每个仓库先过一遍检查（secret、归属、验证、和远端的关系），都通过了才提交推送；有一项不过，就跳过这个仓库、记入报告，继续下一个。

## 直接执行

主上调用这个命令，就是授权你直接处理选中的仓库。不需要逐个仓库或逐步确认，也不用先复述计划等回复；检查都通过就一路提交推送到底。

**审核**：功能变更的审核已经在编排审核链里完成（见 `resources/core/collaboration/workflow-rules.md`），提交时不重复审核，也不需要请主上手动确认审核。

**提交守卫**：amagi 的 `commit-guard` 会始终拦下 `.env`/私钥/凭据/secret 类文件和 `.git/` 内部文件；对 `node_modules/` 和超过 10MB 的大文件，它默认放行并在结果里提示。这个命令对后两类更严格（见下文第 5 步），因为批量推送时没有人逐项看，这些内容一旦入库就很难清理。

**遇到以下情况，跳过该仓库并记入报告**（不用问「是否继续」，直接处理下一个）：进行中的 Git 操作、命中疑似 secret、lint/typecheck/test/build 失败、远端领先或已分叉、归属不明或不是授权的 owner、没有变更。覆盖冲突、泄露凭据、推送到归属不明的远端，都不在这次授权范围内。

## 范围与归属

从当前目录向上找 `projects-memory/projects/registry.json`，扫描它所在工作区的直接子目录和 registry 里的 `projectPath`；找不到 registry 就用当前工作区根。环境变量只作为兼容回退，不写死设备路径。按参数精确筛选，列出最终的仓库集合。

每个仓库需要有 origin、当前分支和明确的归属。优先用 `gh repo view --json nameWithOwner` 和当前认证身份或用户配置的 allowlist 核对；SSH 或非 GitHub 的远端，用本地受信的配置核对。归属不明、没有写权限或不是授权 owner 的，只报告，不提交也不推送。origin URL 用于在报告中标注，不要把某个具体账号写死成通用的归属规则。

## 每个仓库的检查

串行执行：

1. **Git 状态**：检查进行中的操作、`git status --porcelain=v1`、未跟踪文件、上游和 origin。有 merge/rebase/cherry-pick/bisect 在进行时，跳过该仓库。
2. **secret 与变更归属**：只按路径和字段名排查疑似 secret（`.env*`、私钥/证书、credentials、token/secret 文件），命中就跳过，不打印内容。然后读完整 diff，确认所有变更都属于用户这次的请求——其他会话或其他人的改动不要混进提交。
3. **验证**：运行仓库能找到的 lint/typecheck/test/build。失败就跳过，不提交。没有标准入口时，报告你实际执行了哪些替代验证。
4. **和远端的关系**：`git fetch origin <branch>`。只有远端与本地同点、或本地单向领先时才继续。远端领先或已分叉时跳过，不自动 stash、rebase、merge、checkout，也不丢弃变更。
5. **最终提交集合**：提交前确认最终要提交的文件里不含 `.env*`/私钥/凭据/secret 类文件、`node_modules/`、`.git/` 内部文件、超过 10MB 的大文件；命中就跳过该仓库。这和第 2 步是同一道防线，不需要重复扫描，也不打印内容。

## 插件仓库的版本同步

在 fetch 和远端关系检查通过之后、提交之前执行。识别插件仓库看信号，不按仓库名写死；出现以下任一信号即视为插件类仓库：

- 根目录或 `plugins/<name>/` 下有 `.claude-plugin/plugin.json` 或 `.codex-plugin/plugin.json`；
- 有 `.claude-plugin/marketplace.json` 或 `.agents/plugins/marketplace.json`；
- 根 `package.json` 的名称、exports/files、OpenCode 依赖或仓库说明明确表明它是独立的 OpenCode/npm 插件。

普通的 npm 应用、库，或只是恰好有个无关 `package.json` 的仓库，跳过本节。

### 1. 建立远端基线和完整变更集

以 fetch 后的 `origin/<当前分支>` 作为 `BASE_REF`。变更路径要覆盖全：

- `git diff --name-status "$BASE_REF" --`：包含本地已提交未推送、已暂存和未暂存的变更；
- `git ls-files --others --exclude-standard`：补上未跟踪的文件。

被删除的源文件也算受影响——只看当前还存在的文件，会漏掉删除型变更。

从变更集里识别发布单元：

- marketplace 仓库：变更命中 `plugins/<name>/` 时，这个 `<name>` 是一个发布单元；
- 独立插件仓库：根插件入口、prompt/agent/command/skill/resource/rule/hook/MCP、转换器、测试或发布文件有变化时，根包是一个发布单元；`npm pack --dry-run` 或发布清单会包含的 README 等文件也算发布物；
- 只改了仓库级 CI、通用文档或和插件包无关的工具时，不提升插件版本；拿不准归属时，跳过该仓库并报告。

同一个发布单元在一次执行中只更新一次版本。

### 2. 找到所有版本字段

对每个发布单元，读取实际存在、且属于同一发布物的版本字段：

- `.claude-plugin/plugin.json` 的 `version`；
- `.codex-plugin/plugin.json` 的 `version`；
- `.claude-plugin/marketplace.json` 中对应 `plugins[]` 条目的 `version`；
- 独立 npm/OpenCode 插件的根 `package.json`，以及 `package-lock.json` 的根 `version` 和 `packages[""].version`；
- 仓库发布文档里明确声明的其他 release manifest/lock 字段。

`.agents/plugins/marketplace.json` 目前没有版本字段时，不要新增。`manifest/upstream.json` 之类的上游来源版本记录的是出处，不是目标包的版本，除非目标仓库明确规定二者同步。

读写都用 JSON 解析器，精确写回并保留未知字段。不要用正则或全局字符串替换来改版本号——会误伤依赖版本等相似的数字。涉及凭据的字段不输出。

### 3. 以远端版本为基准确定目标版本

对已有的发布单元，从 `BASE_REF` 读出上述字段作为 `base_version`（看字段的值，而不只是看文件是否出现在 diff 里）：

1. 基线的各版本字段应一致，且符合严格的 `MAJOR.MINOR.PATCH`；不一致或解析不了就跳过该仓库并报告。
2. 自动目标固定为 `PATCH + 1`。
3. 当前各字段仍等于 `base_version`：自动写成目标 PATCH。
4. 当前各字段已经等于目标 PATCH：说明改动者已经正确升级过，保留，不再递增。
5. 当前版本高于基线、但不等于目标 PATCH：只有用户参数或仓库发布规范明确允许这次 MAJOR/MINOR 升级或跳号时才保留，否则跳过并报告歧义。
6. 当前版本低于或等于远端基线、且各字段互不一致：跳过并报告。不要擅自挑一个文件当作准。

新插件在 `BASE_REF` 里还不存在时，保留它显式声明且彼此一致的初始 SemVer，首次推送前不再自动加 PATCH；缺少版本或缺少相应的 registry 条目时，跳过并报告。

注意：「版本文件被修改了」不等于「版本已经提升了」，判断要比较 JSON 字段的基线值和当前值。

### 4. Marketplace 自身的版本

当 `.claude-plugin/marketplace.json` 有 `metadata.version`，并且这次新增/删除了插件、修改了插件条目或更新了任一插件版本时，把 marketplace 当作一个独立的发布单元：

- 以 `BASE_REF` 的 `metadata.version` 为基线，按同样的 PATCH 规则更新一次；
- 多个插件同时变化，也只递增一次；
- 已经手工提升到正确目标的，保留，不再递增。

仓库明确声明 metadata 不随插件更新时，遵循仓库的发布规范，并在报告里说明依据。

### 5. 版本更新后的检查

1. 重新解析 JSON，逐字段核对同一发布单元的所有版本字段一致；
2. 确认 package-lock 只改了根包版本，没有误改依赖版本；
3. 重跑关键的 lint/typecheck/test/build 或插件校验；失败就跳过该仓库；
4. 复查完整 diff、敏感文件和 staged 范围，确保新改的版本文件进入同一个提交；
5. 在报告里写清每个发布单元的 `base -> target`，属于自动更新、已预先更新还是新插件保留，以及 marketplace metadata 的变化。

### 6. 独立 OpenCode 插件的不可变发布 tag

只有根 `package.json` 明确是独立 OpenCode/npm 插件、且这次根包被识别为发布单元时，才执行本节。Marketplace 里位于 `plugins/<name>/` 的 pi/Codex 插件，不会因此创建仓库级 tag。

1. 以版本同步后的根 `package.json.version` 作为 `release_version`。它应当和根 `package-lock.json` 的两个根版本字段，以及仓库声明的同包版本字段一致。
2. 从仓库已有的 SemVer tag 推断唯一的命名规范；没有历史 tag 时用 `v${release_version}`。历史 tag 同时存在多种冲突的规范时，跳过并报告，不去猜。
3. 提交前，同时检查本地和远端是否已有这个 tag：
   - 本地：`git show-ref --verify --quiet "refs/tags/$RELEASE_TAG"`；
   - 远端：`git ls-remote --exit-code --tags origin "refs/tags/$RELEASE_TAG"`；
   - tag 已存在时，不删除、移动、覆盖或复用它。除非它已经指向这次要推送的同一个提交、且远端内容一致，否则跳过该仓库；
   - `git ls-remote` 返回「无匹配」和网络/认证失败要分清楚，只有确认是无匹配才继续。
4. 所有验证、提交前检查和 staged diff 复核都通过、并创建了提交之后，执行：

   ```bash
   git tag -a "$RELEASE_TAG" "$NEW_COMMIT" -m "Release $RELEASE_TAG"
   ```

   tag 应指向这次新建的提交。请用 annotated tag（不要用 lightweight tag），不要强制更新 tag，也不要把它打在提交前的旧 HEAD 上。
5. 推送前复核 `package.json.version` 和 tag 里的 SemVer 完全一致，并确认 tag 指向 `NEW_COMMIT`。
6. 用一次非强制的原子推送，同时发布分支和这个 tag：

   ```bash
   git push --atomic origin "HEAD:$BRANCH" "refs/tags/$RELEASE_TAG"
   ```

   远端不支持原子推送，或任一 ref 被拒绝时，整体视为失败，不要退回分步推送——分步推送可能留下「分支已推送、tag 没发布」的中间状态。普通仓库仍按下文方式只推当前分支。
7. tag 是不可变的发布标识，别人可能已经固定引用了它。之后发现问题，提升到新版本并创建新 tag，不删除远端 tag 后同名重发。

### 7. OpenCode 安装引用与升级提示

发布新 tag **不会**自动改动用户机器上已固定的旧 tag，也不会让仍在用 `#main` 的缓存自动刷新。OpenCode 只有在配置引用切换到新 tag 之后，才会在安装/启动时解析新版本。

独立 OpenCode 插件的 tag 推送成功后：

1. 从已核验的 GitHub origin 推出 `<owner>/<repo>`，在报告里给出准确的升级命令：

   ```bash
   opencode plugin 'github:<owner>/<repo>#<RELEASE_TAG>' --global --force
   ```

2. 不要把 `#main` 说成正式的升级方式，也不要说「重启就会自动更新」。
3. 推送授权不包括修改本机的全局 OpenCode 配置。除非主上同时明确要求安装/升级当前设备，否则只在报告里给出命令，不执行。
4. 主上明确授权升级当前设备时，在 tag 推送成功后执行上面的命令，核对全局 `opencode.json` 已引用新 tag，并验证已安装的包版本等于 `release_version`。失败时如实报告，不要改用手工复制缓存的方式。

## 提交信息

基于真实 diff 生成，遵循仓库现有的历史风格（中文 conventional commits）。

格式模板：

```text
<type>(<scope>): <简短描述>

- <变更项1>: <说明>
- <变更项2>: <说明>

<补充说明（可选）>

Co-Authored-By: pi <noreply@pi.dev>
```

| type | 说明 |
|---|---|
| feat | 新功能 |
| fix | 修复 bug |
| docs | 文档变更 |
| style | 代码格式（不影响功能） |
| refactor | 重构 |
| perf | 性能优化 |
| test | 测试相关 |
| chore | 构建/工具/依赖 |

生成步骤：

1. 分析变更内容，确定 type 和 scope；
2. 写一句简短的中文描述（不超过 50 字符）；
3. 用 `-` 列表列出主要变更项；
4. 按仓库历史约定追加 `Co-Authored-By` 署名；用户明确不要时去掉。

## 提交与推送

检查都通过后，按确认过的清单精确执行 `git add -- <paths>`，复核 staged diff 和确认的变更范围一致。**没有变更就不创建空提交。**

`git commit` 之后再核对一次 HEAD 和工作区。普通仓库只用 `git push origin <branch>`；独立 OpenCode 插件按「不可变发布 tag」一节用 `git push --atomic` 同时推送分支和 tag。

- **不使用 force push，也不强制更新 tag**：它们会改写别人可能已经拉取的历史；
- 网络重试只用已有配置，或用单次命令级的 `git -c http.proxy=... -c https.proxy=...` 指向已配置的本地端口，不修改 Git 全局配置；
- 某个仓库失败后，停止该仓库、继续下一个，不撤销用户的改动；
- 如果 tag 已在本地创建但原子推送失败，保留这个 tag，并在报告里写明它只存在于本地。

## 报告

```text
【Git 批量推送报告】
- 范围/归属：{repo -> owner}
- 成功：{repo: commit SHA, branch, remote}
- 版本更新：{repo/release-unit: base -> target；自动更新/已预先更新/新插件保留；marketplace metadata}
- 发布 Tag：{repo: tag -> commit；远端已发布/仅本地/不适用}
- OpenCode 升级：{固定 tag 的正式升级命令；已执行并验证/未获设备升级授权而未执行/不适用}
- 跳过：{无变更/非授权/敏感文件命中}
- 失败：{repo: 阶段、命令与错误}
- 验证：{repo -> commands/results}
- 敏感文件守卫：{通过 或 命中路径}
- 工作区：{clean 或保留的用户变更}
```
