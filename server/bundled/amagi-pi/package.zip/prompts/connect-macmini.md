---
description: 核对Mac mini连接配置并验证通道；diagnose 追加只读诊断
argument-hint: "[目标或 diagnose；可补充连接信息]"
---

# Mac mini连接准备

$ARGUMENTS

读取 [连接规则](../resources/prompt-guides/remote-access.md) 和 [设备资料](../resources/prompt-guides/device-profiles.md) 的 Mac mini 节，路径相对本 prompt 文件解析。

1. 使用当前可信配置或已核实目标，历史地址、账号和工具仅作线索；不盲试账号或扫描旧网段。
2. 默认验证主机身份、认证及最小命令通道。原生 SSH 与封装客户端都需核对身份验证、总超时与退出码；实际系统和 shell 以本次检查为准。
3. diagnose 追加与故障有关的只读检查：Tailscale、已知端口和所需服务。未检查项不能填历史状态。
4. 按实际错误区分网络、身份、认证、命令执行问题；不直接归因于密钥丢失或设备休眠。
5. 仅在当前任务已包含修复时执行服务、网络或密钥变更；诊断本身不自动安装、重装或替换信任记录。

返回实际目标、客户端、身份与命令通道结果、检查状态和下一步。SSH 成功不代表 GUI 可操作。复杂远端命令按实际 shell 编写脚本并安全传输，非零退出码不得截断为成功。
