---
description: 快速准备 Mac mini 的 SSH 连接：验证可达性、核对环境状态、给出故障排查路径
argument-hint: "[可选：diagnose 深度诊断模式]"
---


# Mac mini 连接准备

$ARGUMENTS

这个命令帮你建立和 Mac mini 的远程工作连接，并输出一份环境快照，作为后续远端操作的起点。下面的设备事实和坑位都来自实测，照着用可以省去大部分摸索。

## 设备事实（2026-10 复核）

- **主机**：run.mao 的 Mac Mini（Bonjour 名 `run.mao的Mac Mini`，Tailscale 设备名 `run`）
- **Tailscale IP**：`100.92.24.117`（首选，内外网统一入口；SSH 别名 `macmini` 指向它）
- **局域网 IP**：`192.168.5.3`（DHCP 分配，曾从 .14 漂移过，之后仍可能变化；en0 没有 IP，地址在无线接口上；备用别名 `macmini-lan` 目前指向 .3）
- **SSH 别名**：`macmini`（Tailscale）/ `macmini-lan`（局域网），都已配好免密（密钥 `~/.ssh/id_ed25519`）
- **硬件/系统**：Apple M6 / 16GB 内存 / arm64 / macOS 27.0，磁盘约 228G
- **没有 Homebrew，没有 pi CLI**
- **Tailscale**：官方 pkg 安装的 1.104.x（io.tailscale.ipn.macsys），系统扩展已批准，账号 maorun1996@
- **屏幕共享**：5900 端口常开；外网可用 `vnc://100.92.24.117`
- **v2rayN**：`/Applications/v2rayN.app`（arm64），节点订阅已迁移，本地代理 `127.0.0.1:5800` 常开。内核是 **sing-box**，经 sudo 以 **root** 运行，配置在 `~/Library/Application Support/v2rayN/binConfigs/config.json`；旧的 xray 仍留在 `~/Library/Application Support/v2rayN/bin`

## 连接验证

1. **快速验证**（默认，只读）：

   ```bash
   ssh -o BatchMode=yes -o ConnectTimeout=5 macmini "echo CONNECTION_OK && uname -m"
   ```

   成功就输出快照报告；失败进入下方排查。

2. **诊断模式**（参数为 `diagnose` 时）：
   - `ssh -o BatchMode=yes macmini 'ifconfig -a | grep "inet "'`：首选。经 Tailscale 直接读远端实际的局域网 IP，比 Bonjour 发现更可靠
   - `nc -z -G 2 <实测IP> 22`：端口通但 SSH 被拒时，查 IP 是否漂移（见排查第 4 条）
   - `nc -z -G 2 <实测IP> 5900`：屏幕共享是否在线
   - `dns-sd -B _rfb._tcp local.`（3 秒）：用 Bonjour 发现当前 IP
   - `dns-sd -B _ssh._tcp local.`：确认远程登录是否开启

## 故障排查（按命中概率排序）

1. **本机 Tailscale 没运行**（外出时最常见）：`ssh macmini` 超时，且 `tailscale status` 报连接失败 → 本机 `open -a Tailscale` 后重试。可以建议主上开启本机「Launch Tailscale at login」，以后就不会再遇到。
2. **Mac mini 睡眠**：`ssh macmini`、局域网和屏幕共享都不通 → 设备睡了。目前已设为永不睡眠（sleep 0 + womp 1），只有设置被改过才会出现。
3. **远端 Tailscale 掉线**：`macmini` 不通但 `macmini-lan` 通（在内网时）→ 经内网修复：`ssh macmini-lan 'open -a Tailscale'`。
4. **局域网 IP 漂移**（DHCP，只影响 `macmini-lan`）：先用 `ssh macmini 'ifconfig -a | grep "inet "'` 读远端实际 IP；Tailscale 也不通时，退回 `dns-sd -B _rfb._tcp local.` 做 Bonjour 发现。如果和 `~/.ssh/config` 里 `macmini-lan` 的 HostName 不一致，更新它。Tailscale IP 固定，不受影响。
5. **远程登录被关闭**：22 端口不通但 5900 通 → 请主上在屏幕共享里打开「系统设置 → 通用 → 共享 → 远程登录」。
6. **密钥失效**（比如 Mac mini 重装了系统）：重新安装公钥（`~/.ssh/id_ed25519.pub` 追加到远端 `~/.ssh/authorized_keys`，权限 700/600）。如果需要用 expect 自动输入密码，匹配密码提示时请用 `-nocase`：`-re "(?i)password:"` 里的大小写不敏感对 expect 的预筛不生效，遇到 `Password:`（大写 P）会一直匹配不上，密码发不出去，表现为发送后静默超时。
7. **重装 Tailscale**：请用官方 pkg（有 Apple 公证签名）。rsync 复制再 ad-hoc 重签的版本，VPN 配置授权会静默失败（点 Grant permissions 没有反应）。卸载旧版后执行 `curl -sL -x socks5h://127.0.0.1:5800 -o /tmp/Tailscale.pkg https://pkgs.tailscale.com/stable/Tailscale-latest-macos.pkg && sudo installer -pkg /tmp/Tailscale.pkg -target /`（经 Mac mini 本机的 v2rayN 代理下载）。
8. **需要 GUI 授权的操作**：系统扩展、VPN 授权的弹窗需要 GUI 登录会话，SSH 拉起的应用弹不出授权框（表现为按钮点击无响应）。这类操作请主上在屏幕共享里手动完成，或在安装官方签名版后引导主上到「系统设置 → 通用 → 登录项与扩展」批准。

## 远端操作的习惯与坑位

- **每条远端命令都用 `ssh -o BatchMode=yes macmini "..."`**。bash 工具没有 TTY，缺少 BatchMode 时 ssh 可能停在密码或主机密钥询问上；amagi 守卫在命令没有 timeout 时会直接拦下这类 ssh，有 timeout 时放行但会提示风险。加上 BatchMode，两种情况都顺畅。
- **远端路径带空格**（如 `Application Support`）：rsync 的远端地址会被空格拆成多个参数，报 `server receiver mode requires two argument`。改用 `tar -C ... -cf - | ssh ... 'tar -C ... -xf -'` 管道传输。
- **rsync 复制 .app 之后**：签名资源校验可能失败（"code has no resources but signature indicates they must be present"）。先 `xattr -dr com.apple.quarantine`，再 `codesign --force --deep --sign -` 重签，避免 Gatekeeper 报「已损坏」。
- **GUI**：SSH 会话本身操作不了 GUI；已有 GUI 登录会话时，`open -a <应用>` 可以拉起应用窗口（主上在屏幕共享里能看到）。
- **BSD 工具链**：macOS 上没有 GNU xargs/sed 的扩展，脚本按 BSD 语法写。
- **探测远端端口时，非 root 的 lsof 不可靠**：sing-box 以 root 运行，SSH 会话（非 root）的 `lsof -iTCP` 看不到 root 进程的监听，会误报「未监听」。改用 `netstat -an -p tcp | grep LISTEN`，或在远端执行 `nc -z -G 2 127.0.0.1 <port>` 复核。
- **远端 zsh 的等号展开**：以 `=` 开头的词（如 `echo ==X==`）会被 zsh 当作 `=cmd` 去 PATH 里查找，报 `zsh:1: =X== not found`。分隔标记加上引号：`echo "==X=="`。

## 输出

```text
【Mac mini 连接报告】
- 连接：PASS/FAIL（ssh macmini，Tailscale）
- Tailscale：{在线/离线，IP 100.92.24.117}
- 局域网：{在线/离线，IP 实际值}
- 硬件系统：{芯片} {内存} {macOS 版本}
- 屏幕共享 5900：在线/离线（外网 vnc://100.92.24.117）
- v2rayN：运行中/未运行/未安装（监听 127.0.0.1:5800 与否）
- 异常与建议：{排查项结论或"无"}
```

## 外网使用速查

- SSH：`ssh macmini`（Tailscale 自动穿透，不需要在内网）
- 屏幕：访达 ⌘K 连接 `vnc://100.92.24.117`，或直接点访达边栏里的 Mac mini
