---
description: 获取指定飞书文档并保存为离线 Markdown，下载资源、展开同步块、导出表格 CSV 并验证完整性
argument-hint: <飞书文档URL或token> <本地保存目录>
---


# 获取飞书文档离线副本

$ARGUMENTS

这个命令把一篇飞书文档完整搬到本地：正文转成 Markdown，图片、附件、画板下载到本地，同步块展开成真实内容，表格导出为 CSV。目标是一份离线也能完整阅读、且能被 feishu-sync 回读的副本。

整个过程只读取飞书源文档，不会修改它。

## 准备

**参数。** 需要文档 URL 或 token，以及本地保存的根目录。路径含空格时按参数边界解析，避免不安全的 shell 单词拆分。

**输出目录。** 按文档标题创建。同名目录已存在时进入增量补全模式：先建立资源清单，再补齐缺失项；用户已编辑的内容和 CSV 原件保持不动。

**读技能说明。** lark-cli 的子命令随版本变化，先读与已安装 CLI 同版本的技能说明，可以避免用到过时的参数：

```bash
lark-cli skills read lark-doc
lark-cli skills read lark-doc references/lark-doc-fetch.md
```

遇到 wiki、sheet/base、whiteboard 或认证问题时，分别读取 `lark-wiki`、`lark-sheets`、`lark-base`、`lark-whiteboard`、`lark-shared` 的同版本技能。确认 `lark-cli --version` 和认证状态；未认证或权限不足时，按 skill 里的流程引导认证或停下说明，不去猜测 API。

## 读取正文与结构

用 v2 shortcut 先探测 outline，再获取 Markdown 正文（`--api-version v2` 可以作为显式兼容参数保留）：

```bash
lark-cli docs +fetch --api-version v2 --doc "$doc_ref" --scope outline --max-depth 3 --format pretty
lark-cli docs +fetch --api-version v2 --doc "$doc_ref" --scope full --doc-format markdown --detail simple --format json
```

- 保存 JSON 响应里的正文部分，协议包装不要写进 Markdown；
- 需要 block id 时改用 XML `with-ids/full`，因为 Markdown 格式只支持 `detail=simple`；
- 大文档按 outline 用 `section/range` 分段获取，并核对首尾和章节数，确认没有漏段。

接着建立待处理清单：图片、附件、`synced_reference`、sheet/bitable、whiteboard，以及无权限的节点。保留 token 和正文位置的对应关系，但最终报告里不要出现敏感的认证信息。

## 采集元数据（兼容 feishu-sync 的 frontmatter）

正文拉取后，采集 frontmatter 需要的元数据，让生成的 Markdown 能被 [feishu-sync](https://github.com/maorun/feishu-sync) 的 `IndexScanner.parseMetadata` 正确解析，形成往返闭环。

### Wiki URL

从 URL 取出 `wiki_node_token`（路径末段），调用：

```bash
lark-cli wiki spaces get_node --params '{"token":"<wiki_node_token>"}' --as user --format json
```

从返回的 `data.node` 中提取：

| frontmatter 字段 | 来源字段 |
|---|---|
| `obj_token` | `obj_token` |
| `wiki_node_token` | `node_token`（或 `origin_node_token`） |
| `space_id` | `space_id`（或 `origin_space_id`） |
| `obj_type` | `obj_type`（通常 `"docx"`） |
| `original_link` | 用户 URL 去掉 query 参数，格式 `https://{host}/wiki/{wiki_node_token}` |
| `last_synced_modify_time` | `obj_edit_time`（Unix 时间戳）转 ISO 8601：`date -r <ts> '+%Y-%m-%dT%H:%M:%SZ'` |

### Docx URL

从 URL 取出 `obj_token`（路径末段）；`docs +fetch` 返回的 `document_id` 就是 `obj_token`。`wiki_node_token` 和 `space_id` 为空时不写入。`original_link` 格式为 `https://{host}/docx/{obj_token}`。

### 通用规则

- `fetch_date`：当天日期，格式 `YYYY-MM-DD`；
- `obj_type` 只写具体类型（`docx` / `sheet` / `slides`），`unknown` 不写；
- `wiki_node_token`、`space_id`、`original_link`、`last_synced_modify_time` 为空时不写入；
- `original_link` 只保留基础 URL，**去掉 query 参数**（如 `?fromScene=spaceOverview`），这样同一篇文档的链接才稳定一致。

## 同步块与资源

- **同步块** `synced_reference`：按 `src-token/src-block-id` 读取源范围，递归下钻，用 visited-token/block 去重并设深度上限防止循环。把真实内容内联到原位置，不留空标签。
- **图片**：有有效的临时 URL 就直接下载；只有 token 时用 `docs +media-download`；遇到跨源权限问题，按当前 lark-doc/lark-shared 的指引尝试 `+media-preview`。按阅读顺序命名，存到 `images/`，每张都验证 HTTP 状态、文件类型和非零大小。
- **附件**：用 `docs +media-download --token ... --output ...` 保存到 `attachments/`，保留安全化后的原始文件名和扩展名，并防止 `../` 路径穿越。
- **画板**：读 `lark-whiteboard` 技能后，用 `whiteboard +query --output_as image --output ...` 导出预览；没有权限时，写一段说明（含源链接和错误码），不留空目录。

临时 URL 会过期且带认证信息，不写进最终 Markdown；本地引用一律用相对路径。下载失败的资源如实记入报告和验证清单，不用空文件占位——空文件会让验证误判为成功。

## 电子表格：CSV 是数据的原始依据

wiki 里的 sheet 先通过 `lark-wiki` 解析出 `obj_token`；正文中的 `<sheet>` 交给 `lark-sheets` 处理：

```bash
lark-cli sheets +workbook-info --spreadsheet-token "$sheet_token" --format json
lark-cli sheets +workbook-export --spreadsheet-token "$sheet_token" --file-extension csv \
  --sheet-id "$sheet_id" --output-path "$csv_path"
```

- 每个子表原样保存到 `<文档名>.csv-data/<安全子表名>.csv`，作为不再改动的原始数据；正文里标注对应 CSV 的相对路径；
- 导出的 CSV 数量应等于可访问的子表数量；
- 读 CSV 时按 RFC 4180 解析、使用 `utf-8-sig` 编码。不要逐行按字符串切割：带引号的字段里可能有换行，逐行切会把字段切坏；
- 不要无依据地全局替换双引号。只有解析后确认某个字段确实存在导出转义异常时，才在派生的 Markdown 里修正，CSV 原件保持不动。

## 表格布局重构

飞书表格常被当作排版工具使用，直接转成宽表会得到满是空格子的空壳。所以先按空行和合并语义切成 block，再分类处理：

| 类型 | 判据 | Markdown |
|---|---|---|
| 元数据 | 作者、更新时间等键值 | 小表或 details |
| 层级布局 | 各行首个非空列索引变化 | 按列索引生成嵌套列表 |
| 数据表 | ≥3 行、从第 0 列起、短表头≥3；数据行平均非空≥2.5 且有效区域填充率≥40% | 裁掉全空列后的表格 |
| 段落 | 单列长文本 | 普通段落 |
| 稀疏宽表 | 填充率<40% 或列多值少 | 键值/分组列表 |

拿不准怎么分类时，优先选可读的列表，并保留 CSV 出处。重构结果请由你自己用独立统计复核——任何 Agent 自报「已完成」都不能代替这份证据。

## 生成与验证

输出目录至少包含正文 `README.md`（或同名 `.md`）；有资源时还有 `images/`、`attachments/`；以及同级的 `.csv-data/`。

### Frontmatter 格式

正文文件开头使用下面这种 YAML-in-HTML-comment 格式（与 feishu-sync 的 `generateHtmlHeader` / `renderDocumentMarkdown` 一致）：

```yaml
<!--
feishu_sync:
  obj_token: "{obj_token}"
  wiki_node_token: "{wiki_node_token}"
  space_id: "{space_id}"
  obj_type: "docx"
  original_link: "https://{host}/wiki/{wiki_node_token}"
  fetch_date: "YYYY-MM-DD"
  last_synced_modify_time: "YYYY-MM-DDTHH:MM:SSZ"
-->
```

字段按上文「采集元数据」的规则填写，空值字段直接省略。frontmatter 之后紧接正文（lark-cli 输出的 `<title>` 标签保留在正文中）。同步块已内联，图片、附件、CSV 都用相对路径。

### 验证清单

1. 所有本地 Markdown 引用都存在，且位于输出根目录内；没有 0 字节文件。
2. 图片的引用数、文件数和内容类型一致，没有残留的临时认证 URL。
3. 同步块总数 = 成功展开数 + 循环/权限失败数，没有空标签。
4. 可访问的 sheet 数等于 CSV 数；CSV 能按 RFC 4180 解析，原件未被改写。
5. Markdown 里没有整行都是空单元格的表格行；抽查层级布局、稀疏表和长文本的语义是否保留。

有项目没通过时，如实写进报告的「未覆盖风险」——一份标明缺口的副本，比一份看似完整的副本更可信。

```text
【飞书文档离线报告】
- 来源/本地路径：{source -> path}
- 正文章节：{count}
- 图片/附件：{success/failure}
- 同步块：{expanded/failed}
- 表格：{sheets/csv/reconstructed}
- 画板/无权限节点：{results}
- 完整性验证：{checks + PASS/FAIL}
- 未覆盖风险：{明确列表}
```
