#!/usr/bin/env node
/**
 * fix-terminal-bold-color.mjs — iTerm2 Bold 色板过暗一键修复（v1.5.175）。
 *
 * 机理：pi markdown `**粗体**` 发标准 SGR 1（无颜色）；iTerm2 对 default-FG 粗体使用
 * profile 的 "Bold Color" 色板渲染。色板过暗（实战：#101010 近黑）→ 粗体不可读。
 *
 * 本脚本（幂等）：
 *   1. 备份当前活动 profile 到 /tmp/iterm2-bold-backup-<日期>.json
 *   2. 完整复制 profile + 仅改 Bold Color（默认 #f2ecdc 暖亮白，可用 --bold=#rrggbb 覆盖）
 *   3. 写入 ~/Library/Application Support/iTerm2/DynamicProfiles/amagi-bold-fix.json
 *      （Dynamic Profile 同 GUID 覆盖原 profile，iTerm2 热加载立即生效，无需重启）
 *
 * 回滚：删除该 DynamicProfiles 文件即可恢复原色板。
 * 仅支持 macOS + iTerm2。
 */
import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { pathToFileURL } from "node:url";

/** #rrggbb → [r,g,b]（0-1 浮点）；非法输入返回 undefined。（导出供测试回归 off-by-one） */
export function parseBoldHex(input) {
	const m = /^#?([0-9a-f]{6})$/i.exec((input || "").trim());
	if (!m) return undefined;
	return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16) / 255);
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (!isMain) { /* 被测试 import 时不执行 CLI */ } else {

const PLIST = path.join(os.homedir(), "Library/Preferences/com.googlecode.iterm2.plist");
const DYN_DIR = path.join(os.homedir(), "Library/Application Support/iTerm2/DynamicProfiles");
const DYN_FILE = path.join(DYN_DIR, "amagi-bold-fix.json");

const argBold = process.argv.find((a) => a.startsWith("--bold="));
const parsed = parseBoldHex(argBold?.split("=")[1] || "#f2ecdc");
if (!parsed) { console.error(`--bold 需为 #rrggbb，收到: ${argBold?.split("=")[1]}`); process.exit(2); }
const [r, g, b] = parsed;
const boldHex = argBold?.split("=")[1] || "#f2ecdc";

if (process.platform !== "darwin" || process.env.TERM_PROGRAM !== "iTerm.app") {
	console.error("仅支持 macOS + iTerm2（当前 TERM_PROGRAM=" + (process.env.TERM_PROGRAM || "?") + "）");
	process.exit(1);
}

function plutil(args) {
	return execFileSync("plutil", [...args, PLIST], { encoding: "utf8", timeout: 5000 });
}

const bookmarks = JSON.parse(plutil(["-extract", "New Bookmarks", "json", "-o", "-"]));
let defaultGuid;
try { defaultGuid = plutil(["-extract", "Default Bookmark Guid", "raw", "-o", "-"]).trim(); } catch {}
const name = process.env.ITERM_PROFILE;
const profile = (name && bookmarks.find((b) => b.Name === name))
	|| (defaultGuid && bookmarks.find((b) => b.Guid === defaultGuid))
	|| bookmarks[0];
if (!profile) { console.error("未找到活动 profile"); process.exit(1); }

const day = new Date().toISOString().slice(0, 10);
const bak = `/tmp/iterm2-bold-backup-${day}.json`;
fs.writeFileSync(bak, JSON.stringify(profile, null, 1));

const fixed = { ...profile };
const swatch = { "Alpha Component": 1, "Red Component": r, "Green Component": g, "Blue Component": b, "Color Space": "sRGB" };
fixed["Bold Color"] = swatch;
fixed["Bold Color (Dark)"] = swatch;

fs.mkdirSync(DYN_DIR, { recursive: true });
fs.writeFileSync(DYN_FILE, JSON.stringify({ Profiles: [fixed] }, null, 1));
console.log(`✓ profile "${profile.Name}" Bold Color → ${boldHex}（备份: ${bak}）`);
console.log(`✓ Dynamic Profile 已写入: ${DYN_FILE}（iTerm2 热加载，立即生效）`);
console.log("回滚：删除该文件即可恢复原色板");
}
