// 配置参考只从 canonical schema 派生；--check 用于 CI，绝不在检查时写文件。
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export function configurationReference(schema) {
	const rows = [];
	const cell = (value) => String(value ?? "").replaceAll("|", "\\|").replace(/\s+/g, " ");
	function visit(properties, prefix = "") {
		for (const [key, field] of Object.entries(properties ?? {})) {
			const name = prefix ? `${prefix}.${key}` : key;
			rows.push(`| \`${name}\` | ${cell(field.type)} | ${cell(field.description)} |`);
			visit(field.properties, name);
			if (field.additionalProperties?.properties) visit(field.additionalProperties.properties, `${name}.[名称]`);
		}
	}
	visit(schema.properties);
	return ["# amagi 配置字段参考", "", "<!-- generated: schemas/amagi-config.json; node scripts/generate-harness-reference.mjs -->", "",
		"字段与说明从配置 schema 生成。修改源 schema 后重新生成；CI 检查文档是否同步。", "",
		"用 `/amagi config explain [角色]` 查看当前选模来源，`/amagi doctor` 检查文件字段、模型目录与认证配置。两者只读且不发模型或 MCP 请求。", "",
		"`/amagi config init inherit` 创建 `{\"profile\":\"inherit\",\"agents\":{}}`，适合继承当前 pi 模型；`init tiered` 创建分层预设。已有文件或符号链接均不覆盖。未创建项目预设时沿用既有默认 tiered。", "",
		"pi settings/models/auth/MCP 的设置与登录仍由宿主管理。amagi.json 表达协作策略；起步预设不重置权限、身份或恢复数据。", "",
		"| 字段 | 类型 | 说明 |", "| --- | --- | --- |", ...rows, ""].join("\n");
}

export function updateConfigurationReference({ check = false, projectRoot = root } = {}) {
	const schema = JSON.parse(fs.readFileSync(path.join(projectRoot, "schemas/amagi-config.json"), "utf8"));
	const target = path.join(projectRoot, "resources/core/configuration-reference.md");
	const expected = configurationReference(schema);
	if (check) {
		if (!fs.existsSync(target) || fs.readFileSync(target, "utf8") !== expected) throw new Error("配置参考未同步：node scripts/generate-harness-reference.mjs");
	} else fs.writeFileSync(target, expected);
	return target;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
	try { updateConfigurationReference({ check: process.argv.includes("--check") }); console.log("配置参考与 schema 一致"); }
	catch (error) { console.error(error.message); process.exitCode = 1; }
}
