/**
 * task-reconcile.ts — ev-20261021-a8de95：恢复记录的工具化对账闭环。
 *
 * 痛点（battle-sim 会话 01a156d5 真实三次拒绝）：启动恢复对账把跨重启残留任务标为
 * needs-reconciliation，task_query 也宣称 nextActions=[reconcile,…]，但工具面没有任何 reconcile
 * 动作——task_control cancel 只查本会话 registry（报 unknown-handle「registry 无记录」），
 * task_resume 对 execution=running 报「运行中」；唯一给出的出口 /amagi recovery adopt 是交互命令，
 * 且语义是 foreign-owner 采纳，与本机 owner 记录的对账无关。可查记录与可执行动作没有闭环。
 *
 * 本模块提供：
 *   ① describeStoredControlTarget：控制面句柄解析失败时回落契约存储，声明 historical/live/stale/
 *      unknown、owner 与**真实可用动作**（替代「registry 无记录」的误导性结论）；
 *   ② reconcileStoredTask：task_control reconcile 的单任务执行体——
 *      - 本会话持有的任务（registry 有记录）→ 拒绝（不是对账对象，用 wait/cancel）；
 *      - foreign-owner → 拒绝，如实说明须主上 /amagi recovery adopt 显式确认（N1 单写者：工具面不隐式采纳）；
 *      - 退出证明（launch-anchor.ts：持久启动锚点的 rootPid/进程组/出生令牌 + 原 Leader 存活，只读不发信号）：
 *        live → 拒绝关闭，列 pid；unknown（无锚点/令牌不可比对/ps 不可用）→ fail-closed 拒绝——
 *        环境标签缺席不是退出证据（diting F-01）；无锚点记录只能经主上 TUI confirm-exited 人工确认；
 *      - 证明已退出 → stale：确认物理退出（reconcile confirm-exited）后按未完成关闭（cancel——
 *        不猜成功、不改接受轴、不重放任何副作用；已写产物以盘面为准，续接走 task_resume）。
 *   内核命令走 applyQuiet 恢复档（零 settle 钩子——diting F-03；只同步本会话已有投影，不新建）——
 *   跨会话记录不收编进本会话看板（与 v2.0.1 启动对账同口径）。提交前复核本会话持有状态（探测期间
 *   本会话若已重新占用该任务则拒绝）。权限：只对本机 owner（ownerId 匹配/machineId 匹配/已采纳）记录生效。
 */

import { registry } from "./task-registry.ts";
import { admissionStateOf } from "./admission.ts";
import { getTaskKernel, resolveStoredTaskHandle } from "./task-service.ts";
import { proveTaskExited, writeExitAttestation, type ExitProof } from "./launch-anchor.ts";
import type { TaskView } from "./contracts/task.ts";

export type ReconcileState =
	| "session-owned" // 本会话 registry 持有：不是对账对象
	| "foreign-owner" // 他人 owner：须主上显式 adopt
	| "not-found"
	| "already-closed" // 终态且物理退出事实已在：无需对账
	| "live" // 仍有存活进程：拒绝关闭
	| "unknown" // 存活探测不可用：fail-closed
	| "closed" // stale → 已确认退出并按未完成关闭
	| "kernel-rejected";

export interface ReconcileOutcome {
	taskId: string;
	ok: boolean;
	state: ReconcileState;
	message: string;
}

export type ExitProver = (taskId: string) => Promise<ExitProof>;

export interface ReconcileDeps {
	ownerId?: string;
	/** 退出证明（缺省 = launch-anchor proveTaskExited；测试注入）。 */
	prove?: ExitProver;
	now?: () => number;
	/** ev-20261026-165da9：仅接受跨 boot 退出证明（proof.crossBoot）——无人值守启动恢复门控：
	 *  同 boot 进程表缺席/人工确认的 exited 不是重启证明，退回人工面（显式 reconcile 不受此限）。 */
	requireCrossBootProof?: boolean;
}

const TERMINAL = new Set(["done", "error", "answered", "cancelled", "truncated", "resolved-external"]);
/** 对账后无需改执行轴的状态：终态 + blocked（等待答复——本就可经 task_resume 续接，只补物理退出事实）。
 *  其余（queued/running/answering）宿主已退出即不可能再推进，按未完成关闭。 */
const SETTLED_EXEC = new Set([...TERMINAL, "blocked"]);


function axes(v: Pick<TaskView["run"], "execution" | "processState" | "settlement" | "acceptance" | "recovery">): string {
	return `execution=${v.execution} process=${v.processState} settlement=${v.settlement} acceptance=${v.acceptance} recovery=${v.recovery}`;
}

/** 本进程是否持有该任务的运行实体（运行中子进程或准入队列/槽位）。 */
export function sessionOwnsRun(taskId: string): boolean {
	return registry.getRunningChildren().some((c) => c.taskId === taskId) || admissionStateOf(taskId) !== undefined;
}

/** 句柄 → 本机可写的契约记录（registry 缺席时）。返回 undefined=存储也无此任务。 */
async function loadStored(handle: string, ownerId: string | undefined) {
	return resolveStoredTaskHandle(handle, ownerId);
}

/**
 * 控制面句柄解析失败的回落说明（cancel/resolve-external/steer/wait/resume 共用）。
 * 存储里有该任务 → 返回声明 historical 状态、owner 与真实可用动作的说明；无 → undefined（保持原错误）。
 */
export async function describeStoredControlTarget(handle: string, action: string, ownerId?: string): Promise<string | undefined> {
	const stored = await loadStored(handle, ownerId);
	if (!stored.ok) {
		if (stored.error.code === "foreign-owner") {
			return `该任务是契约存储中的历史记录，但属 foreign-owner——${stored.error.message}。工具面不隐式采纳；须主上在 TUI 执行该 adopt 命令确认后再 task_control reconcile。`;
		}
		return undefined;
	}
	const s = stored.value;
	if (!s) return undefined;
	const run = s.run;
	const id = run.taskId;
	const closed = TERMINAL.has(run.execution) && run.processState === "exited";
	const actions = closed
		? `历史终态，无需控制；续接走 task_resume({ handle: "${id}", message })，三轴用 task_query`
		: `本会话不持有其运行进程，${action} 无法作用于它——先 task_control({ action: "reconcile", handles: ["${id}"], reason: "<理由>" })：按启动锚点证明运行实体是否退出，仍存活则拒绝并列 pid，证据不足则拒绝（fail-closed），证明已退出则确认退出并按未完成关闭（不猜成功），之后可 task_resume 续接`;
	return `任务 ${id} 是契约存储中的历史记录（非本会话运行；owner=${run.ownerId}；${axes(run)}）。${actions}。`;
}

/** task_control reconcile 单任务执行体（见模块头）。 */
export async function reconcileStoredTask(handle: string, reason: string, deps: ReconcileDeps = {}): Promise<ReconcileOutcome> {
	let rec: { taskId: string } | undefined;
	try { rec = registry.resolveSession(handle); } catch (e) {
		return { taskId: handle, ok: false, state: "not-found", message: `句柄歧义：${e instanceof Error ? e.message : String(e)}——用完整 taskId` };
	}
	// 本会话真实持有 = 本进程有运行中子进程或占着准入队列/槽位；仅有 registry 投影（磁盘回填/续接收编）
	// 而无本进程运行实体的记录，正是对账对象（task_resume「运行中」拒绝的来源）。
	if (rec && (sessionOwnsRun(rec.taskId))) {
		const r = registry.get(rec.taskId);
		return { taskId: rec.taskId, ok: false, state: "session-owned", message: `本会话持有该任务的运行实体（status=${r?.status ?? "?"}）——不是恢复对账对象；用 task_control wait/cancel` };
	}
	const kernel = getTaskKernel(deps.ownerId !== undefined ? { ownerId: deps.ownerId } : undefined);
	const stored = await loadStored(rec?.taskId ?? handle, deps.ownerId ?? kernel.ownerId);
	if (!stored.ok) {
		if (stored.error.code === "foreign-owner") {
			return { taskId: handle, ok: false, state: "foreign-owner", message: `${stored.error.message}——工具面不隐式采纳（N1 单写者）；须主上在 TUI 执行 adopt 命令显式确认后再 reconcile` };
		}
		return { taskId: handle, ok: false, state: "not-found", message: `契约存储读取失败（${stored.error.code}）：${stored.error.message}` };
	}
	if (!stored.value) return { taskId: handle, ok: false, state: "not-found", message: "契约存储中无此任务（registry 与存储均未命中）" };
	const taskId = stored.value.run.taskId;
	if (!(await kernel.seedFromStoreIfAbsent(taskId))) {
		return { taskId, ok: false, state: "kernel-rejected", message: "内核无法从存储种子该任务（记录不可读）——人工核对契约目录" };
	}
	let view = kernel.get(taskId);
	if (!view) return { taskId, ok: false, state: "kernel-rejected", message: "内核视图缺失" };
	if (SETTLED_EXEC.has(view.run.execution) && view.run.processState === "exited") {
		return { taskId, ok: true, state: "already-closed", message: `已是终态且有物理退出事实（${axes(view.run)}）——无需对账；续接走 task_resume，验收按回执走 accept/reject` };
	}
	const latestRunId = view.run.backendRunId;
	const proof = await (deps.prove ?? ((id: string) => proveTaskExited(id, latestRunId ? { backendRunId: latestRunId } : {})))(taskId);
	// ev-20261026-165da9：无人值守门控——同 boot 退出证据（进程表干净/人工确认）不构成重启证明，
	// 不自动关闭（显式 task_control reconcile 仍接受完整退出证据，不受此门控限制）。
	if (deps.requireCrossBootProof && proof.state === "exited" && proof.crossBoot !== true) {
		return { taskId, ok: false, state: "unknown", message: `统一证明为同 boot 完整退出（非跨 boot 重启证据）——无人值守关闭只接受系统重启证明；显式收口走 task_control({ action: "reconcile" })（无锚点旧记录可先 /amagi recovery confirm-exited）` };
	}
	if (proof.state === "unknown") {
		return { taskId, ok: false, state: "unknown", message: `无法证明运行实体已退出（${proof.reason}）——看不见不等于已退出，不关闭（fail-closed）；断点明细：TUI /amagi recovery show ${taskId}` };
	}
	if (proof.state === "live") {
		return { taskId, ok: false, state: "live", message: `仍有存活进程（pid ${proof.pids.join(", ")}；${proof.detail}）——不关闭、不重复派发；本会话不持有该进程，等待其退出后再 reconcile，或主上确认后手动终止` };
	}
	// 探测期间本会话可能已重新占用该任务（并发派发/续接）——提交前复核，避免关闭本会话刚持有的运行
	if (sessionOwnsRun(taskId)) {
		return { taskId, ok: false, state: "session-owned", message: "退出证明完成后本会话已重新持有该任务的运行实体——不关闭；用 task_control wait/cancel" };
	}
	// 恢复档：零 settle 钩子（不重放终态副作用）；只同步本会话已有投影，不把跨会话记录收编进看板
	const exec = (c: Parameters<typeof kernel.apply>[0]) => kernel.applyQuiet(c, { syncExistingProjection: true });
	const at = (deps.now ?? Date.now)();
	const ownerId = kernel.ownerId;
	const facts = [
		{ code: "a8de95-exit-proven", detail: `${proof.evidence.join("；").slice(0, 600)}（${new Date(at).toISOString()}）` },
		{ code: "a8de95-reason", detail: reason.slice(0, 400) },
	];
	const steps: string[] = [];
	if (view.run.processState !== "exited") {
		const r = await exec({ type: "reconcile", key: { ownerId, taskId, revision: view.revision }, facts, disposition: "confirm-exited" });
		if (!r.ok) return { taskId, ok: false, state: "kernel-rejected", message: `确认退出被内核拒绝（${r.error.code}）：${r.error.message}` };
		view = r.value;
		steps.push("确认物理退出（processState→exited）");
	}
	if (!SETTLED_EXEC.has(view.run.execution)) {
		const unexecuted = view.run.execution === "queued" && !view.run.launchIntent;
		const r = unexecuted
			? await exec({ type: "reconcile", key: { ownerId, taskId, revision: view.revision }, facts, disposition: "close-unexecuted" })
			: await exec({ type: "cancel", key: { ownerId, taskId, revision: view.revision }, reason: `[恢复对账] ${reason}——宿主已退出、无存活进程，按未完成关闭（不猜成功；已写产物以盘面为准）` });
		if (!r.ok) return { taskId, ok: false, state: "kernel-rejected", message: `${steps.length ? `${steps.join("；")}后，` : ""}关闭被内核拒绝（${r.error.code}）：${r.error.message}` };
		view = r.value;
		steps.push(unexecuted ? "关闭为未执行" : `按未完成关闭（execution→${view.run.execution}）`);
	}
	return {
		taskId, ok: true, state: "closed",
		message: `stale（运行实体已证明退出：${proof.evidence.join("；")}）：${steps.join("；")}——不猜成功、接受轴不变（${axes(view.run)}）。已写产物以盘面为准；续接用 task_resume({ handle: "${taskId}", message: "先核对已有产物再继续" })`,
	};
}

/** TUI /amagi recovery confirm-exited：主上人工确认无残留进程（无启动锚点记录的唯一收口证据）。
 *  只接受本机 owner 且本会话不持有运行实体的未收口记录；只写确认注记，不改状态——之后仍须 reconcile。 */
export async function attestTaskExited(handle: string, deps: { ownerId?: string } = {}): Promise<{ ok: boolean; message: string }> {
	const kernel = getTaskKernel(deps.ownerId !== undefined ? { ownerId: deps.ownerId } : undefined);
	const stored = await loadStored(handle, deps.ownerId ?? kernel.ownerId);
	if (!stored.ok) return { ok: false, message: `[confirm-exited 拒绝] ${stored.error.message}` };
	if (!stored.value) return { ok: false, message: `[confirm-exited 拒绝] 契约存储中无此任务：${handle}` };
	const run = stored.value.run;
	if (sessionOwnsRun(run.taskId)) return { ok: false, message: `[confirm-exited 拒绝] 本会话持有该任务的运行实体——用 task_control wait/cancel` };
	if (SETTLED_EXEC.has(run.execution) && run.processState === "exited") return { ok: true, message: `[confirm-exited 无需] 已有物理退出事实（${axes(run)}）` };
	try {
		writeExitAttestation(run.taskId, "主上（TUI /amagi recovery confirm-exited）", "人工核对无残留进程");
	} catch (e) {
		return { ok: false, message: `[confirm-exited 失败] 确认注记落盘失败（${e instanceof Error ? e.message : String(e)}）——未记录，可重试` };
	}
	return { ok: true, message: `[confirm-exited 已记录] ${run.taskId} 人工退出确认已写入契约目录；状态未改——下一步 task_control({ action: "reconcile", handles: ["${run.taskId}"], reason }) 收口（env 血统/进程组仍见存活时照常拒绝）` };
}
