/**
 * env-flip.ts — ev-20260903-191473（P1/capability）：Electron 桌面构建后原生模块 ABI 切换的运行期感知提醒。
 *
 * 实战背景（复盘 reviews/feishu-sync-连续迭代-amagi-pi复盘-2026-09-03.md §1.1）：`node scripts/
 * build-desktop-target.cjs`（内部走 @electron/rebuild）等桌面构建把 node_modules 原生模块 ABI 切到
 * Electron，随后 vitest/npm test 成片报 `NODE_MODULE_VERSION 125 vs 137`（单次 20-71 用例失败）；
 * 同类摔绊 4+ 次，每次靠 1 轮 `npm rebuild better-sqlite3` 恢复。CLAUDE.md 有记录，但「正确信息在
 * 项目文档、不在执行时刻的脑内」——本模块把恢复指引搬到执行时刻：
 *
 * 机制（纯软提示，绝不阻断）：
 *  - bash 命令**成功执行后** recordEnvFlip()：flip 命令落 marker、restore 命令删 marker、其余 no-op；
 *  - 测试类命令成功后 abiReminderNote()：该 cwd 存在未过期 marker → 返回一行恢复指引
 *    （bash-override 与 P2-6 长驻提示合并追加在结果尾部，先 ABI 后长驻）；
 *  - marker 落 `<amagiDataDir>/env-abi-flip.json`（Record<cwd, {at, command}>），TTL 默认 48h，
 *    `AMAGI_ABI_FLIP_TTL_MS` 覆盖（<=0 禁用整个机制）；读写失败一律静默（可观测性不阻断主流程）。
 *
 * 独立模块（同 task-write-log 纪律）：检测/记录/提醒零 pi 依赖，只依赖 data-dir；bash-override
 * 接线，未来 amagi env doctor 等消费方可直接复用。
 *
 * ev-20261031-a25f7a（P3，复盘 §2.6）：① 提醒接会话计次降频（bash-override 侧
 *  abiReminderCompactNote——首次全文、第 2 次起一行折叠，计数由 marker 有效身份驱动、与显示
 *  判定分离）；② 新增 abiFlipMarkerAt（条件实例身份）；③ session 生命周期复位（index.ts 接线）。
 *
 * 既有分类启发式边界（诚实披露，登记待核验不处理）：flip/restore 判定对命令文本正则匹配，
 * 不理解参数语义——①字符串字面量（echo 参数、node -e 脚本、检索词）里提及的命令名会被保守
 * 命中（如 `echo npm rebuild` 误删 marker）；②查阅形态（--help/--version）同样命中（查看帮助
 * 会删 marker）；③命令替换深层形态有漏报面。曾两度评估收紧：「数据命令参数剔除」因无法排除
 * awk system()/sed e/JS child_process 内嵌真实执行而撤回；「查阅/演练旗标段剔除」因独立审核
 * 实执行反例否定（payload 中作为输出数据的旗标会吞真实动作段；npm rebuild --dry-run 实际
 * 仍执行 install 生命周期）而撤回——不再猜跨工具参数语义，误报面由提醒计次降噪与 TTL 兑底。
 */

import * as fs from "node:fs";
import { amagiDataFile } from "./data-dir.ts";
import { executableDomainOf } from "./shell-lexer.ts";

export { executableDomainOf };

/** marker 单条命令字段上限（有界：超长命令截断留存，防状态文件被超长命令撑爆）。 */
const MARKER_COMMAND_MAX_CHARS = 256;

/** 提醒文案中的命令摘要长度上限（复盘诉求口径：≤60 字）。 */
const REMINDER_SUMMARY_MAX_CHARS = 60;

/** TTL 默认 48h：覆盖「一次桌面构建 → 数天内多轮测试」的典型衰减窗口。 */
const ABI_FLIP_TTL_DEFAULT_MS = 48 * 60 * 60 * 1000;

/** env AMAGI_ABI_FLIP_TTL_MS 读取（无效值回默认；<=0 由调用方解释为禁用整个机制）。 */
function flipTtlMs(): number {
	const raw = process.env.AMAGI_ABI_FLIP_TTL_MS;
	if (raw === undefined || raw.trim() === "") return ABI_FLIP_TTL_DEFAULT_MS;
	const v = Number(raw);
	return Number.isFinite(v) ? v : ABI_FLIP_TTL_DEFAULT_MS;
}

/**
 * 纯函数：命令是否会把 node_modules 原生模块 ABI 切到 Electron（大小写不敏感）。
 * 命中口径（ev-20260903-191473 规格）：
 *  - @electron/rebuild / electron-rebuild（任意出现）；
 *  - electron-builder 且同命令含 install-app-deps；独立 install-app-deps（如 `npx install-app-deps`）
 *    ——统一为 install-app-deps 词级命中（electron-builder 单纯打包不重编原生模块，不算 flip）；
 *  - --runtime=electron 或 --runtime electron（node-gyp/prebuild-install 等通用 runtime 标记）；
 *  - prebuild-install 且含 electron；
 *  - node-gyp 且含 --runtime=electron（已被通用 runtime 标记覆盖，按规格显式保留便于对读）。
 */
export function isElectronAbiFlipCommand(command: string): boolean {
	const cmd = executableDomainOf(command).toLowerCase();
	return (
		cmd.includes("@electron/rebuild") ||
		/\belectron-rebuild\b/.test(cmd) ||
		/\binstall-app-deps\b/.test(cmd) ||
		/--runtime(?:=|\s+)electron\b/.test(cmd) ||
		(/\bprebuild-install\b/.test(cmd) && /\belectron\b/.test(cmd)) ||
		(/\bnode-gyp\b/.test(cmd) && /--runtime=electron\b/.test(cmd))
	);
}

/** Node ABI 恢复命令形态：(npm|pnpm|yarn|bun) rebuild / node-gyp rebuild / prebuild-install。 */
const NODE_ABI_RESTORE_RE = /\b(?:npm|pnpm|yarn|bun)\s+rebuild\b|\bnode-gyp\s+rebuild\b|\bprebuild-install\b/i;

/**
 * 纯函数：命令是否恢复 Node ABI——命中恢复形态，且不含任何 electron runtime 标记。
 * 组合命令同时命中 flip 与 restore 时 flip 优先（如 `electron-builder install-app-deps … && npm rebuild x`）：
 * 含 flip 标记的组合命令按 flip 处理，此处直接判非 restore。
 */
export function isNodeAbiRestoreCommand(command: string): boolean {
	if (isElectronAbiFlipCommand(command)) return false; // flip 优先
	return NODE_ABI_RESTORE_RE.test(executableDomainOf(command));
}

/** 测试运行命令特征（自持扩展版，口径宽于 bash-override 的 env 清洗版：补 jest/mocha/playwright）。 */
const ABI_TEST_RUNNER_RE = new RegExp(
	[
		"\\bnode\\s+--test\\b", // node --test（含 env 前缀 / 多参数形态）
		"\\b(?:npm|pnpm|yarn|bun)\\s+(?:run\\s+)?test[\\w:.-]*", // npm test / pnpm run test:ci / yarn test:unit …
		"\\bvitest\\b", // vitest / npx vitest / pnpm exec vitest
		"\\bjest\\b", // jest / npx jest
		"\\bmocha\\b", // mocha / npx mocha
		"\\bplaywright\\s+test\\b", // playwright test
	].join("|"),
	"i",
);

/** marker 结构：Record<cwd, { at: epoch ms, command: 触发命令（截断） }>。 */
export interface AbiFlipMarker {
	at: number;
	command: string;
}

type AbiFlipState = Record<string, AbiFlipMarker>;

/** 状态文件路径：<amagiDataDir>/env-abi-flip.json。 */
export function abiFlipStateFile(): string {
	return amagiDataFile("env-abi-flip.json");
}

/** 该 cwd 未过期 marker 的 at 时间戳（无 marker/过期/禁用 → null）——供调用方做「条件实例」
 *  身份判定：同一 marker 存续期计次持续，新 flip 覆盖（at 变化）后可重新首次全文。 */
export function abiFlipMarkerAt(cwd: string): number | null {
	try {
		const ttl = flipTtlMs();
		if (ttl <= 0) return null;
		const marker = readState()[cwd];
		if (!marker) return null;
		const elapsed = Date.now() - marker.at;
		if (!(elapsed >= 0) || elapsed > ttl) return null;
		return marker.at;
	} catch { /* lint-exempt:状态读取失败静默降级（同 readState 口径），可观测性不阻断主流程 */ return null; }
}

/** 读状态（文件不存在/损坏/单条结构非法 → 整体或单条跳过；弱断言数据口径）。 */
function readState(): AbiFlipState {
	try {
		const parsed: unknown = JSON.parse(fs.readFileSync(abiFlipStateFile(), "utf8"));
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
		const out: AbiFlipState = {};
		for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
			const m = v as { at?: unknown; command?: unknown } | null;
			if (m && typeof m === "object" && typeof m.at === "number" && typeof m.command === "string") {
				out[k] = { at: m.at, command: m.command };
			}
		}
		return out;
	} catch {
		return {};
	}
}

/** 写状态（顺带按 TTL 修剪过期 cwd 条目，防长期累积无界）；失败由调用方静默。 */
function persistState(state: AbiFlipState, ttlMs: number): void {
	const now = Date.now();
	const pruned: AbiFlipState = {};
	for (const [k, m] of Object.entries(state)) {
		if (ttlMs > 0 && m.at <= now && now - m.at <= ttlMs) pruned[k] = m;
	}
	fs.writeFileSync(abiFlipStateFile(), JSON.stringify(pruned, null, "\t"), "utf8");
}

/**
 * 记录 ABI 翻转状态（供 bash-override 在命令成功执行后调用）：
 * flip 命中写 marker（覆盖同 cwd 旧值）；restore 命中删除该 cwd marker；其余 no-op。
 * 整个机制禁用（TTL<=0）、参数异常或读写失败时静默 no-op——可观测性绝不影响执行路径。
 */
export function recordEnvFlip(command: string, cwd: string): void {
	try {
		if (flipTtlMs() <= 0) return; // AMAGI_ABI_FLIP_TTL_MS<=0：禁用整个机制
		if (typeof command !== "string" || typeof cwd !== "string" || !cwd) return;
		if (isElectronAbiFlipCommand(command)) {
			const state = readState();
			state[cwd] = { at: Date.now(), command: executableDomainOf(command).slice(0, MARKER_COMMAND_MAX_CHARS) };
			persistState(state, flipTtlMs());
			return;
		}
		if (isNodeAbiRestoreCommand(command)) {
			const state = readState();
			if (!(cwd in state)) return;
			delete state[cwd];
			persistState(state, flipTtlMs());
		}
	} catch { /* 静默：marker 读写失败不影响主流程 */ }
}

/** 命令摘要：压平空白后截断（≤60 字），供提醒文案内嵌。 */
function commandSummary(cmd: string): string {
	return cmd.replace(/\s+/g, " ").trim().slice(0, REMINDER_SUMMARY_MAX_CHARS);
}

/**
 * 测试类命令的 ABI 提醒（纯函数，供 bash-override 成功路径与测试直接断言）：
 * 命令命中测试运行特征，且该 cwd 存在未过期 flip marker → 返回单行恢复指引；否则 null。
 * 恢复指引为弱断言软提示（不阻断、不代跑 rebuild）。
 */
export function abiReminderNote(command: string, cwd: string): string | null {
	try {
		const ttl = flipTtlMs();
		if (ttl <= 0) return null;
		if (typeof command !== "string" || !ABI_TEST_RUNNER_RE.test(executableDomainOf(command))) return null;
		const marker = readState()[cwd];
		if (!marker) return null;
		const elapsed = Date.now() - marker.at;
		if (!(elapsed >= 0) || elapsed > ttl) return null; // 未来时间戳/已过期 → 不提醒
		const minutes = Math.max(1, Math.round(elapsed / 60_000));
		return `[amagi env] 本目录 ${minutes} 分钟前执行过 Electron ABI 构建（${commandSummary(marker.command)}）——若测试报 NODE_MODULE_VERSION 不匹配，先恢复 Node ABI（如 npm rebuild <原生模块>）再跑测试`;
	} catch {
		return null;
	}
}
