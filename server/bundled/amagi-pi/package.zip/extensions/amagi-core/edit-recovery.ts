/** Editing failures carry an explicit write state; only a known pre-write miss is recoverable. */
export type EditFailureCode = "not-found" | "ambiguous" | "overlap" | "no-change" | "aborted" | "permission" | "io" | "unknown"
	| "stale-snapshot" | "snapshot-expired" | "unobserved-range" | "path-mismatch" | "scope-mismatch" | "unsupported-content" | "invalid-input";
export type EditWriteState = "not-written" | "written" | "unknown";

export class EditFailure extends Error {
	readonly code: EditFailureCode;
	readonly writeState: EditWriteState;
	constructor(code: EditFailureCode, message: string, writeState: EditWriteState = "not-written") {
		super(`[amagi edit:${code} write=${writeState}] ${message}`);
		this.name = "EditFailure";
		this.code = code;
		this.writeState = writeState;
	}
}

export function classifyEditFailure(error: unknown, writeState: EditWriteState): EditFailure {
	if (error instanceof EditFailure) return new EditFailure(error.code, error.message.replace(/^\[amagi edit:[^\]]+\] /, ""), writeState);
	const message = error instanceof Error ? error.message : String(error);
	const ioCode = (error as NodeJS.ErrnoException | undefined)?.code;
	const code: EditFailureCode = /abort/i.test(message) || (error as Error | undefined)?.name === "AbortError" ? "aborted"
		: /^(Could not find the exact text in |Could not find edits\[\d+\] in )/.test(message) ? "not-found"
		: /^Found \d+ occurrences/.test(message) ? "ambiguous"
		: /overlap/i.test(message) ? "overlap"
		: /^No changes made to /.test(message) ? "no-change"
		: ioCode === "EACCES" || ioCode === "EPERM" || /permission denied|deny 禁入|写围栏/.test(message) ? "permission"
		: typeof ioCode === "string" || /^Could not edit file:/.test(message) ? "io" : "unknown";
	return new EditFailure(code, message, writeState);
}

export function canRecoverEdit(error: unknown): error is EditFailure {
	return error instanceof EditFailure && error.code === "not-found" && error.writeState === "not-written";
}
