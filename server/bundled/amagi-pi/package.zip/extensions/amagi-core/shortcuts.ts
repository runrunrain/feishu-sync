/**
 * shortcuts.ts — P4-5：amagi 快捷键（§8.1 高频编排操作肌肉记忆化）。
 *
 * 两个交互（v1.5.218 键位迁移，面板与交互优化 M1-03）：
 *   ⌥R（alt+r，兼容旧 ctrl+shift+r）—— 一键派发 diting 审当前 diff
 *   ⌥B（alt+b，兼容旧 ctrl+shift+b）—— 后台任务列表 widget 开/关
 * 根因（调研01）：mac 终端 legacy 模式不区分 ctrl+shift+字母 与 ctrl+字母，
 * 旧键在 Terminal.app/iTerm2/codebox 默认配置退化为内建键位被吞 → alt/⌥ 系为主键，
 * 旧键保留兼容注册（Kitty/ghostty 用户肌肉记忆不断裂）；键位可经 amagi.json ui.keys 覆盖。
 * 描述与回流文案统一走 ui-shared fmtKey（R4：mac 符号显示）。
 *
 * dist 机制证据（node_modules/@earendil-works/pi-coding-agent/dist）：
 * - types.d.ts:886-891 `registerShortcut(shortcut: KeyId, { description?, handler(ctx): Promise<void>|void })`
 * - docs/keybindings.md:21 键位格式 `ctrl+shift+x`；内建键位表 L31-139（ctrl+shift+r / ctrl+shift+b 均未被占用）
 * - 冲突检测：runner.js getShortcuts()——保留内建（app.interrupt/clear/exit/suspend/model 系/thinking 系等，
 *   runner.js:8-26 RESERVED 列表）冲突时跳过并产生 warning diagnostic；非保留冲突后者覆盖前者并告警。
 *   本模块键位不在任何内建默认绑定上，dist 检测为额外兜底。
 * - 任务列表展示：types.d.ts:95-99 setWidget(key, string[]|undefined, {placement})（与 status-ui 同机制，独立 key 互不干扰）
 * - review 回流：pi.sendUserMessage（types.d.ts:905-908，与 input-router 回流同路径）
 * - widget 跨 session 生命周期（P4 终审 M5-b，dist interactive-mode.js 确证）：
 *   L268-270 `setBeforeSessionInvalidate(() => this.resetExtensionUI())`——session 失效
 *   （newSession/switchSession/reload）时 pi **自动** clearExtensionWidgets()（L1489-1498）
 *   并清 statuses/footer（L1500-1527 resetExtensionUI）；reload 同路径（L4423）。
 *   即 widget 视觉状态 pi 自清，**泄漏的是 extension 侧闭包状态**（listVisible）：
 *   本模块在 session_start 内部订阅重置（并防御性再清 widget），session_shutdown 同步复位，
 *   无需 index.ts 新增接线。
 *
 * 接线说明（index.ts 统一接线需要的最小改动，本任务不改 index.ts）：
 *   1) import：import { registerAmagiShortcuts } from "./shortcuts.ts";
 *   2) amagiCore() 内（createTaskTool 之后，复用同一批 agents 与 runTask 注入）：
 *        registerAmagiShortcuts(pi, { agents, runTask: (agent, task, opts) => runTask(agent, task, opts), taskRegistry: registry });
 *      —— runTask 直接用 task-tool.ts 已 export 的 runTask（签名兼容：(agent, task, opts:{cwd,signal?})）。
 *      实际一行：registerAmagiShortcuts(pi, { agents, runTask, taskRegistry: registry });
 *   3) package.json 的 pi manifest 需含 "themes": ["./themes"]（本任务已加，主题方可被发现：
 *      package-manager.js collectPackageResources——manifest 存在时仅收集 manifest 条目）。
 *   无额外生命周期接线：session_start/shutdown 自清已在模块内部订阅（M5-b 修复）。
 */

import type { AgentConfig } from "./agents-loader.ts";
import type { TaskRecord } from "./task-registry.ts";
import { buildReviewTask } from "./input-router.ts";
import { formatDuration, trimDisplay, modelWithThinking, resolveWidgetWidth } from "./status-ui.ts";
import { fmtKey } from "./ui-shared.ts";
import { DEFAULT_UI_KEYS, readUiConfig } from "./ui-config.ts";
import { sendTaskCompletion, sendMachineNotice, MACHINE_NOTICE_TYPE, type TaskCompletionSink } from "./evidence-context.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 类型（结构子集，mock 友好）
// ─────────────────────────────────────────────────────────────────────────────

/** runTask 返回的最小结构（与 input-router DispatchResult 同形）。 */
export interface ShortcutDispatchResult {
	status: string;
	output: string;
	errorMessage?: string;
	blocked?: boolean;
	/** v2 批次B：统一收尾链所需的任务 id（RunResult 携带；旧注入源缺省时无机器回源标识）。 */
	taskId?: string;
	/** v1.5.188 P1-3②：E1/E3 完成契约标注后缀（runTask finalize 透出）。 */
	completionAnnotation?: string;
	/** v1.5.188 P1-4⑤：派发前熔断警告（runTask 透出）。 */
	fuseWarning?: string;
}

export interface ShortcutCtx {
	cwd: string;
	mode: string;
	ui: {
		notify(message: string, type?: "info" | "warning" | "error"): void;
		setWidget(key: string, content: string[] | undefined, options?: { placement?: "aboveEditor" | "belowEditor" }): void;
	};
}

export interface ShortcutPi extends TaskCompletionSink {
	registerShortcut(shortcut: string, options: { description?: string; handler: (ctx: ShortcutCtx) => Promise<void> | void }): void;
	sendUserMessage(content: string): void;
	/** 事件订阅（P4 终审 M5-b：session_start/shutdown 内部重置 widget 开关状态）。 */
	on(event: string, handler: (event: unknown, ctx: ShortcutCtx) => void): void;
}

export interface ShortcutDeps {
	agents: AgentConfig[];
	/** 注入 task-tool 的 sync runTask（与 input-router 同一注入点）。 */
	runTask: (agent: AgentConfig, task: string, opts: { cwd: string; signal?: AbortSignal }) => Promise<ShortcutDispatchResult>;
	taskRegistry: {
		list(): Readonly<TaskRecord>[];
		onChange?(fn: () => void): () => void;
	};
	/** 键位覆盖（测试显式注入）；生产从 amagi.json ui.keys 读取（cwd 发现）。 */
	reviewKey?: string;
	tasksKey?: string;
	/** 键位配置发现目录（缺省 process.cwd()）。 */
	configCwd?: string;
	/** 测试注入完整键位组（绕过 amagi.json 发现）。 */
	uiKeys?: { review?: string[]; tasks?: string[] };
	/** 任务列表时长心跳；默认 2s。 */
	listRefreshMs?: number;
}

/** v1.5.218：主键 alt/⌥ 系（mac 可达优先），legacy 键兼容注册。 */
export const DEFAULT_REVIEW_KEY = DEFAULT_UI_KEYS.review[0];
export const LEGACY_REVIEW_KEYS = DEFAULT_UI_KEYS.review.slice(1);
export const DEFAULT_TASKS_KEY = DEFAULT_UI_KEYS.tasks[0];
export const LEGACY_TASKS_KEYS = DEFAULT_UI_KEYS.tasks.slice(1);
const TASK_LIST_WIDGET_KEY = "amagi:task-list";
const MAX_WIDTH = 96;
const MAX_DONE = 8;
const TASK_LIST_REFRESH_MS = 2000;

// ─────────────────────────────────────────────────────────────────────────────
// 任务列表渲染（纯函数，可测）
// ─────────────────────────────────────────────────────────────────────────────

function taskSummaryOf(rec: Readonly<TaskRecord>): string {
	return rec.goal || rec.name || rec.taskId.slice(0, 12);
}

/**
 * 全量任务列表行：在途任务双行（角色/摘要/时长 + 最近动作），结算态单行（最近 maxDone 条）。
 * 无任务时返回单行说明（不返回空数组——快捷键场景需要明确反馈）。
 */
export function buildTaskListLines(
	tasks: Readonly<TaskRecord>[],
	now: number = Date.now(),
	opts: { maxWidth?: number; maxDone?: number; maxLines?: number } = {},
): string[] {
	const maxWidth = opts.maxWidth ?? MAX_WIDTH;
	const maxDone = opts.maxDone ?? MAX_DONE;
	const maxLines = Math.max(3, opts.maxLines ?? 10);
	const running = tasks.filter((r) => r.status === "running" || r.status === "queued").sort((a, b) => a.startedAt - b.startedAt);
	const done = tasks
		.filter((r) => r.status !== "running" && r.status !== "queued")
		.sort((a, b) => (b.endedAt || b.blockedAt || b.startedAt || 0) - (a.endedAt || a.blockedAt || a.startedAt || 0));
	if (running.length === 0 && done.length === 0) {
		return [trimDisplay("amagi 任务实况 · 当前无任何任务记录", maxWidth)];
	}
	const queued = running.filter((r) => r.status === "queued").length;
	const header = trimDisplay(`amagi 任务实况 · ${running.length} 在途${queued > 0 ? `（${queued} 排队）` : ""} · ${done.length} 已结算`, maxWidth);
	const runningLines = running.map((rec) => {
		const dur = formatDuration(now - rec.startedAt);
		const head = rec.mode === "background" ? `${rec.agent} [bg]` : rec.agent;
		const modelSeg = rec.model ? `${modelWithThinking(rec.model)} · ` : "";
		const last = rec.activityWindow?.at(-1);
		const detail = rec.status === "queued"
			? "排队中（等待执行槽位）"
			: last
				? (last.summary && last.summary !== last.type ? `${last.type}: ${last.summary}` : last.type)
				: "等待首个动作…";
		return [
			trimDisplay(`${head} · ${trimDisplay(taskSummaryOf(rec), 28)} · ${modelSeg}${dur}`, maxWidth),
			trimDisplay(`  └ ${detail}`, maxWidth),
		];
	});
	const doneLines = done.slice(0, maxDone).map((rec) => {
		const settledAt = rec.endedAt ?? rec.blockedAt;
		const total = settledAt ? formatDuration(settledAt - rec.startedAt) : "?";
		return trimDisplay(`  [${rec.status}] ${rec.agent} · ${taskSummaryOf(rec)} · ${total}`, maxWidth);
	});
	const hasDoneOverflow = done.length > maxDone;
	const unfoldedLength = 1 + runningLines.length * 2 + doneLines.length + (hasDoneOverflow ? 1 : 0);
	if (unfoldedLength <= maxLines) {
		const lines = [header, ...runningLines.flat(), ...doneLines];
		if (hasDoneOverflow) lines.push(trimDisplay(`  …另有 ${done.length - maxDone} 条结算记录（query_task 可查）`, maxWidth));
		return lines;
	}

	const bodyBudget = Math.max(0, maxLines - 2);
	const shownRunning = Math.min(runningLines.length, Math.floor(bodyBudget / 2));
	const shownDone = Math.min(doneLines.length, Math.max(0, bodyBudget - shownRunning * 2));
	const hiddenRunning = running.length - shownRunning;
	const hiddenDone = done.length - shownDone;
	const lines = [header, ...runningLines.slice(0, shownRunning).flat(), ...doneLines.slice(0, shownDone)];
	lines.push(trimDisplay(`  …另有 ${hiddenRunning} 个在途任务 · ${hiddenDone} 条结算记录（看板/query_task 可查）`, maxWidth));
	return lines;
}

// ─────────────────────────────────────────────────────────────────────────────
// 注册
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 注册 amagi 快捷键。内部订阅 session_start/shutdown 自清任务列表状态（dist 语义：
 * widget 视觉 pi 自动清，extension 只须重置自有开关状态），返回实际键位与 reset()。
 */
export function registerAmagiShortcuts(pi: ShortcutPi, deps: ShortcutDeps): { reviewKey: string; tasksKey: string; reviewKeys: string[]; tasksKeys: string[]; reset: (ctx?: ShortcutCtx) => void } {
	// v1.5.218 键位迁移：amagi.json ui.keys（项目优先）→ deps 显式注入 → 默认 ⌥ 主键 + legacy 兼容键。
	const cfg = deps.uiKeys
		? { review: deps.uiKeys.review ?? DEFAULT_UI_KEYS.review, tasks: deps.uiKeys.tasks ?? DEFAULT_UI_KEYS.tasks }
		: readUiConfig(deps.configCwd ?? process.cwd()).keys;
	const reviewKeys = deps.reviewKey ? [deps.reviewKey, ...cfg.review.filter((k) => k !== deps.reviewKey)] : cfg.review;
	const tasksKeys = deps.tasksKey ? [deps.tasksKey, ...cfg.tasks.filter((k) => k !== deps.tasksKey)] : cfg.tasks;
	const reviewKey = reviewKeys[0];
	const tasksKey = tasksKeys[0];
	const listRefreshMs = deps.listRefreshMs ?? TASK_LIST_REFRESH_MS;
	let listVisible = false;
	let listCtx: ShortcutCtx | undefined;
	let listTimer: NodeJS.Timeout | undefined;
	let unsubscribeList: (() => void) | undefined;

	function refreshList(): void {
		if (!listVisible || !listCtx || listCtx.mode !== "tui") return;
		try {
			listCtx.ui.setWidget(TASK_LIST_WIDGET_KEY, buildTaskListLines(deps.taskRegistry.list(), Date.now(), {
				maxWidth: resolveWidgetWidth(MAX_WIDTH, process.stdout.columns),
			}), { placement: "aboveEditor" });
		} catch {}
	}

	/** 重置任务列表开关、订阅与心跳；TUI ctx 可用时防御性清 widget。 */
	function reset(ctx?: ShortcutCtx): void {
		const clearCtx = ctx ?? listCtx;
		unsubscribeList?.();
		unsubscribeList = undefined;
		clearInterval(listTimer);
		listTimer = undefined;
		listVisible = false;
		listCtx = undefined;
		if (clearCtx?.mode === "tui") {
			try { clearCtx.ui.setWidget(TASK_LIST_WIDGET_KEY, undefined); } catch {}
		}
	}

	// session 切换：pi 自动清 widget；这里同时释放 registry 订阅与时长心跳。
	pi.on("session_start", (_event: unknown, ctx: ShortcutCtx) => reset(ctx));
	pi.on("session_shutdown", () => reset());

	// ── 一键 diting 审当前 diff（主键 ⌥R + legacy 兼容键，同一 handler） ──
	const reviewHandler = (ctx: ShortcutCtx) => {
		const agent = deps.agents.find((a) => a.name === "diting");
		if (!agent) {
			try { ctx.ui.notify("amagi: diting 角色未注册（agents/diting.md 缺失）", "error"); } catch {}
			return;
		}
		// 日志佐证：快捷键确定性派发，不经 Leader LLM 路由（与 input-router 同约定）
		console.error(`[amagi-shortcut] ${fmtKey(reviewKey)} → 直接派发 diting 审 diff（不经 LLM 路由）`);
		try { ctx.ui.notify("amagi: 已派发 diting 审核当前 diff，完成后自动回流", "info"); } catch {}
		// 异步派发不阻塞 handler（handler promise 悬挂不影响 TUI；与 input-router dispatchAndReport 同模式）
		void (async () => {
			try {
				const res = await deps.runTask(agent, buildReviewTask(""), { cwd: ctx.cwd });
				const status = res.blocked ? "blocked" : res.status;
				// v1.5.188 P1-3②/P1-4⑤：快捷键旁路天然覆盖——标注/熔断已由 runTask finalize 计算，此处仅拼接
				// ev-20261101-7fffc6：回流通 custom 机器通道（amagi:task-completion + details.taskId）。
				const notice = `${res.fuseWarning || ""}[快捷键派发 diting · ${status}]\n\n${res.output || res.errorMessage || "(无输出)"}${res.completionAnnotation || ""}`;
				if (res.taskId) sendTaskCompletion(pi, notice, res.taskId);
				else sendMachineNotice(pi, MACHINE_NOTICE_TYPE, notice);
			} catch (e) {
				const msg = e instanceof Error ? e.message : String(e);
				try { sendMachineNotice(pi, MACHINE_NOTICE_TYPE, `[快捷键派发 diting] 异常：${msg}`); } catch {}
			}
		})();
	};
	for (const key of reviewKeys) {
		pi.registerShortcut(key, {
			description: `amagi: 派发 diting 审当前 git diff（${fmtKey(key)}；或 /amagi review）`,
			handler: reviewHandler,
		});
	}

	// ── 一键后台任务列表（实时 widget 开/关；主键 ⌥B + legacy 兼容键，同一 handler） ──
	const tasksHandler = (ctx: ShortcutCtx) => {
		if (ctx.mode !== "tui") return;
		if (listVisible) {
			reset(ctx);
			return;
		}
		listVisible = true;
		listCtx = ctx;
		refreshList();
		unsubscribeList = deps.taskRegistry.onChange?.(refreshList);
		listTimer = setInterval(refreshList, listRefreshMs);
		listTimer.unref?.();
	};
	for (const key of tasksKeys) {
		pi.registerShortcut(key, {
			description: `amagi: 后台任务列表（开/关）（${fmtKey(key)}；或 /amagi tasks）`,
			handler: tasksHandler,
		});
	}

	return { reviewKey, tasksKey, reviewKeys, tasksKeys, reset };
}
