/**
 * evolution-evidence.ts — B9（ev-20261012-04b7b9，v2.19.3）：evolution 条目证据留存。
 *
 * 设计规格：.agent-outputs/evolve/2.19.3/04b7b9-evidence-persistence-design.md（fuxi 已接受）。
 * 布局（状态无关——open/resolved 同深度，相对链接 ../evidence/<id>/<digest>.txt 两态同形）：
 *   <evolutionRoot>/evidence/<id>/<64hex>.txt   脱敏后内容寻址副本（目录 0700 / 文件 0600）
 *   <evolutionRoot>/.locks/<id>.lock            条目迁移排他锁（仅防并发迁移，非全局锁）
 *   <exportDir>/<id>.evidence/<64hex>.txt       导出自包含包（manifest 路径重写为包内相对）
 *
 * 不变量（设计「存储、动作与失败语义」）：
 *  - 单个证据缺失/超限/被拒 → 条目仍落盘，该项降级为 omitted 记录并披露原因（不阻断沉淀）；
 *  - 只有实际留存并校验过的字节才标 retained；digest 覆盖脱敏后的 UTF-8 留存字节（LF 规范化）；
 *  - resolve 前后证据身份不变（路径/digest 原样带入，不搬移不重采）；export 后 retained 引用
 *    可从导出包自身解析；
 *  - 证据文件损坏时现象可展示但报告 invalid-manifest；resolve/export 拒绝（不伪装 legacy）。
 *
 * 安全（设计「凭据与路径安全」）：敏感文件名/目录读前拒收；最终链接文件与受管根内链接组件拒收；
 * 契约存储禁写；凭据形态经 redactCredentials（task-query-wire 单源复用）全文脱敏后才计算 digest
 * 与落盘；PEM/OpenSSH 私钥块 → 附件 sensitive-content 遗漏。无活动 enforcer 时敏感路径/契约存储/
 * 类型与根内包含检查仍执行（undefined 不跳过安全规则）；有活动 enforcer 时来源 read 过 checkRead
 * （deny 禁入护读）。受管写入逐目标接活动 enforcer 的 deny 检查（F01 终裁：条目 md/.tmp/索引行/
 * evidence/<id> 及副本/锁文件每个目标点单独过，官方沉淀根窄豁免仅免 tool-enforced 工作区围栏、
 * 不免 deny）；export 走完整 checkWrite 含围栏；契约存储/敏感路径/链接等硬区由本模块自执法。
 */
import { createHash } from "node:crypto";
import * as os from "node:os";
import * as fs from "node:fs";
import * as path from "node:path";
import { realpathNearestExisting, getActiveFilePermissionEnforcer } from "./file-permission.ts";
import { contractStoreRoot } from "./artifact.ts";
import { redactCredentials } from "./task-query-wire.ts";
import { resolveGitRoot } from "./task-export.ts";

// ── 常量（首期固定上限，不新增配置——设计「布局与上限」） ─────────────────────

/** 每次 log / 首次 resolve 各最多 3 个文件；两阶段合计 ≤6 个记录。 */
export const EVIDENCE_INPUT_MAX = 3;
/** 单文件（原文与脱敏后）最大 65,536 字节；读取经 fd 最多 65,537 字节（不无限读入再判断）。 */
export const EVIDENCE_MAX_BYTES = 65_536;
const EVIDENCE_READ_LIMIT = EVIDENCE_MAX_BYTES + 1;
/** 输入路径最多 4096 字符；条目内新增 JSON 元数据合计最多 96 KiB。 */
export const EVIDENCE_PATH_MAX_CHARS = 4096;
const EVIDENCE_MANIFEST_MAX_CHARS = 96 * 1024;
/** 条目内记录数上限（log ≤3 + resolve ≤3）。 */
export const EVIDENCE_RECORDS_MAX = 6;
/** summary 脱敏后最多 240 字；warnings 最多 16 项。 */
export const EVIDENCE_SUMMARY_MAX_CHARS = 240;
const WARNINGS_MAX = 16;

// ── 类型（设计「元数据定义」——对象封闭，运行时同样校验） ──────────────────────

export type EvidenceOmissionCode =
	| "missing" | "denied" | "sensitive-path" | "symlink" | "not-regular"
	| "unsupported-text" | "too-large" | "unreadable" | "source-changed"
	| "sensitive-content" | "write-failed";

export const EVIDENCE_OMISSION_CODES: readonly EvidenceOmissionCode[] = [
	"missing", "denied", "sensitive-path", "symlink", "not-regular",
	"unsupported-text", "too-large", "unreadable", "source-changed",
	"sensitive-content", "write-failed",
];

export interface EvidenceInput {
	/** 相对调用时会话 cwd 解析（绝不先试 git root）；不接受模型传入 cwd 参数。 */
	path: string;
	/** 可选用途说明（脱敏后 ≤240 字，超出明示截断；工具不编造用途）。 */
	summary?: string;
	/** 可选行锚（1-based 闭区间，指向规范化+脱敏后副本；失效即清除并告警）。 */
	lines?: { start: number; end: number };
}

export interface EvidenceOrigin {
	base: "cwd" | "git-root" | "absolute" | "redacted";
	path: string | null;
	cwd: string | null;
	gitRoot: string | null;
}

export interface RetainedEvidenceRecord {
	key: string;
	phase: "log" | "resolve";
	origin: EvidenceOrigin;
	summary?: string;
	state: "retained";
	/** 相对承载条目 md 的 POSIX 路径：全局 ../evidence/<id>/<64hex>.txt；导出 <id>.evidence/<64hex>.txt。 */
	path: string;
	/** sha256:<64 位小写 hex>，对最终 UTF-8 留存字节计算。 */
	digest: string;
	bytes: number;
	redacted: boolean;
	lines?: { start: number; end: number };
	/** 仅导出重脱敏改变字节时填写（指向此前留存内容摘要）；全局新捕获禁止。 */
	derivedFromDigest?: string;
}

export interface OmittedEvidenceRecord {
	key: string;
	phase: "log" | "resolve";
	origin: EvidenceOrigin;
	summary?: string;
	state: "omitted";
	reason: EvidenceOmissionCode;
}

export type EvidenceRecord = RetainedEvidenceRecord | OmittedEvidenceRecord;

export type EvidenceHealth = "verified" | "missing" | "drifted" | "denied" | "unreadable";

/** 采集 state 与当前 health 分离：retained 的 health 来自实际校验；omitted 恒 null。 */
export interface EvidenceResult {
	record: EvidenceRecord;
	health: EvidenceHealth | null;
}

export interface EvidenceCaptureOptions {
	/** evolution 根 canonical 形态（resolveManagedEvolutionRoot.canonical）。 */
	canonicalRoot: string;
	id: string;
	phase: "log" | "resolve";
	/** canonical cwd（相对输入的解析基准）。 */
	cwd: string;
	/** canonical git root；探测失败 null。 */
	gitRoot: string | null;
}

/** 捕获中间产物（留存字节仅在进程内短暂持有，发布后即弃）。 */
export interface CapturedEvidence {
	record: RetainedEvidenceRecord;
	content: string;
}

/** 安全拒斥（根/目录级）：调用方映射为 operation 错误，不与单项遗漏混同。 */
export class EvidenceSecurityError extends Error {}

// ── 小件：路径包含 / digest 工具 / 敏感与私钥识别 ────────────────────────────

function isWithinAbs(child: string, parent: string): boolean {
	if (child === parent) return true;
	const p = parent.endsWith(path.sep) ? parent : parent + path.sep;
	return child.startsWith(p);
}

const HEX64_RE = /^[0-9a-f]{64}$/;

/** digest（sha256:<hex>）→ 文件名 hex；非法 digest 返回 null。 */
export function digestHexOf(digest: string): string | null {
	if (!digest.startsWith("sha256:")) return null;
	const hex = digest.slice(7);
	return HEX64_RE.test(hex) ? hex : null;
}

export function sha256OfText(text: string): string {
	return `sha256:${createHash("sha256").update(text, "utf8").digest("hex")}`;
}

/** 全局布局证据相对路径（相对条目 md 所在目录，open/resolved 同深度同形）。 */
export function globalEvidencePathFor(id: string, digestHex: string): string {
	return `../evidence/${id}/${digestHex}.txt`;
}

/** 导出布局证据相对路径（相对导出 md 所在目录）。 */
export function exportEvidencePathFor(id: string, digestHex: string): string {
	return `${id}.evidence/${digestHex}.txt`;
}

const SENSITIVE_DIR_SEGMENTS = new Set([".ssh", ".aws", ".gnupg"]);

function isSensitiveBasename(base: string): boolean {
	if (base === ".env" || base === "auth.json" || base === ".npmrc") return true;
	if (/^\.env\./i.test(base)) return true;
	if (/\.(pem|key)$/i.test(base)) return true;
	if (/^id_(rsa|dsa|ecdsa|ed25519)(\.\d+)?$/.test(base)) return true;
	if (/(credential|secret)/i.test(base)) return true;
	return false;
}

/** 敏感路径词法识别（逐段目录名 + 基名模式；真实落点由调用方另行同检）。 */
export function isSensitivePathLexical(p: string): boolean {
	const segs = p.split(/[\\/]/).filter((s) => s.length > 0);
	if (segs.some((s) => SENSITIVE_DIR_SEGMENTS.has(s.toLowerCase()))) return true;
	const base = segs[segs.length - 1] ?? "";
	return base.length > 0 ? isSensitiveBasename(base) : false;
}

const PRIVATE_KEY_BLOCK_RE = /-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----/;

/** PEM/OpenSSH 私钥块识别（窄拒收——须在任何截断前检查完整输入）。 */
export function containsPrivateKeyBlock(text: string): boolean {
	return PRIVATE_KEY_BLOCK_RE.test(text);
}

function withinContractStore(target: string): boolean {
	try {
		const root = contractStoreRoot();
		return root ? isWithinAbs(target, path.resolve(root)) : false;
	} catch { /* lint-exempt:存储根不可解析：跳过重叠检查（与 file-permission 同口径） */
		return false;
	}
}

/** warnings 有界收集（≤16 项，溢出加汇总标记，不静默丢弃缺口）。 */
export function pushWarning(warnings: string[], text: string): void {
	const v = redactCredentials(text).slice(0, 300);
	if (warnings.length < WARNINGS_MAX) warnings.push(v);
	else if (warnings.length === WARNINGS_MAX) warnings.push(`[警告溢出] 另有警告被截断（上限 ${WARNINGS_MAX} 项）`);
}

// ── 受管安全 I/O 原语（B9 修复轮 F04：不跟随最终链接/不读特殊文件/不重写预存链接目标） ──

/** 受管安全读：O_NOFOLLOW + fstat 普通文件（ELOOP/特殊对象上抛，不把链接目标当副本内容）。 */
export function safeReadRegularFile(target: string): string {
	const fd = fs.openSync(target, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW ?? 0));
	try {
		const st = fs.fstatSync(fd);
		if (!st.isFile()) throw new EvidenceSecurityError(`目标非普通文件，拒绝读取: ${target}`);
		const buf = Buffer.alloc(Math.max(st.size, 1));
		let off = 0;
		while (off < st.size) {
			const n = fs.readSync(fd, buf, off, st.size - off, null);
			if (n <= 0) break;
			off += n;
		}
		return buf.subarray(0, off).toString("utf8");
	} finally {
		try { fs.closeSync(fd); } catch { /* lint-exempt:关闭失败不掩盖读取结果 */ }
	}
}

/** 受管安全写：预存链接/非普通文件拒绝重写 + O_NOFOLLOW 打开（md 的 .tmp-<pid> 已存在为链接时拒绝）。 */
export function safeWriteRegularFile(target: string, content: string, mode?: number): void {
	let pre: fs.Stats | undefined;
	try { pre = fs.lstatSync(target); } catch { /* lint-exempt:不存在 → 创建 */ }
	if (pre !== undefined && pre.isSymbolicLink()) throw new EvidenceSecurityError(`写入目标已存在为符号链接，拒绝重写: ${target}`);
	if (pre !== undefined && !pre.isFile()) throw new EvidenceSecurityError(`写入目标已存在且非普通文件: ${target}`);
	const fd = fs.openSync(target, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_TRUNC | (fs.constants.O_NOFOLLOW ?? 0), mode);
	try {
		fs.writeSync(fd, content);
	} finally {
		try { fs.closeSync(fd); } catch { /* lint-exempt:关闭失败不掩盖写入结果 */ }
	}
}

/** 受管安全追加（索引行）：O_APPEND|O_CREAT|O_NOFOLLOW——不跟随替换后的链接。 */
function safeAppendRegularLine(target: string, line: string): void {
	const fd = fs.openSync(target, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_APPEND | (fs.constants.O_NOFOLLOW ?? 0));
	try { fs.writeSync(fd, line); } finally { try { fs.closeSync(fd); } catch { /* lint-exempt:关闭失败不掩盖追加结果 */ } }
}

/** 逐目标冻结权限校验（B9 终裁 F01 收口）：目录级/顶层六路径检查不能代表具体文件 deny——
 *  每个实际写入/改名/链接目标点（条目 md、.tmp、索引行、evidence/<id> 及其副本、锁文件、导出文件）
 *  单独过校验。受管根内用 checkRead（deny 读写双禁，延续官方沉淀根窄豁免口径）；导出面
 *  full=true 走完整 checkWrite（含 tool-enforced 工作区围栏，不享豁免）。无活动 enforcer 时跳过。 */
export function enforceWriteTarget(target: string, opts?: { full?: boolean }): void {
	const enforcer = getActiveFilePermissionEnforcer();
	if (!enforcer) return;
	const v = opts?.full === true ? enforcer.checkWrite(target) : enforcer.checkRead(target);
	if (!v.ok) throw new EvidenceSecurityError(`写入目标在冻结权限禁入区（逐目标检查），拒绝写入: ${target}`);
}

/** 索引事件写入（F05：结果返回供回执 warnings 披露——条目已发布不回滚）。 */
export function appendIndexEvent(root: string, event: Record<string, unknown>): { ok: boolean; error?: string } {
	try {
		fs.mkdirSync(root, { recursive: true });
		enforceWriteTarget(path.join(root, "index.ndjson")); // F01 终裁：逐目标 deny（索引行目标点）
		safeAppendRegularLine(path.join(root, "index.ndjson"), JSON.stringify({ at: new Date().toISOString(), ...event }) + "\n");
		return { ok: true };
	} catch (e) {
		return { ok: false, error: e instanceof Error ? e.message : String(e) };
	}
}

/** 相对路径（POSIX 形态）沿途组件的首个符号链接（不含最终文件；受管回读组件检查）。 */
function firstLinkComponent(from: string, relPosix: string): string | null {
	let cur = from;
	const segs = relPosix.split("/");
	for (let i = 0; i < segs.length - 1; i++) {
		if (segs[i] === "") continue;
		cur = path.join(cur, segs[i]);
		try { if (fs.lstatSync(cur).isSymbolicLink()) return cur; } catch { return null; }
	}
	return null;
}

// ── 输入结构校验（整次预写入拒绝项：文件数超限/错类型/非法 lines/路径形态） ────

export type EvidenceInputValidation = { ok: true; value: EvidenceInput[] } | { ok: false; error: string };

const CONTROL_CHARS_RE = /[\u0000-\u001f\u007f]/;
const URL_FORM_RE = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//;

export function validateEvidenceInputs(raw: unknown): EvidenceInputValidation {
	if (!Array.isArray(raw)) return { ok: false, error: "evidence 须为对象数组（{path, summary?, lines?}）" };
	if (raw.length > EVIDENCE_INPUT_MAX) {
		return { ok: false, error: `evidence 最多 ${EVIDENCE_INPUT_MAX} 个文件（收到 ${raw.length}）——超出部分请并入仓内耐久目录（.agent-outputs/evolve/<fixVersion>/）` };
	}
	const value: EvidenceInput[] = [];
	for (const item of raw) {
		if (typeof item !== "object" || item === null) return { ok: false, error: "evidence 每项须为对象 {path, summary?, lines?}" };
		const keys = Object.keys(item);
		const known = new Set(["path", "summary", "lines"]);
		if (keys.some((k) => !known.has(k))) return { ok: false, error: `evidence 对象封闭（只接受 path/summary/lines，收到: ${keys.join(",")}）` };
		const { path: p, summary, lines } = item as Record<string, unknown>;
		if (typeof p !== "string" || p.length === 0) return { ok: false, error: "evidence[].path 须为非空字符串" };
		if (p.length > EVIDENCE_PATH_MAX_CHARS) return { ok: false, error: `evidence[].path 超过 ${EVIDENCE_PATH_MAX_CHARS} 字符上限` };
		if (CONTROL_CHARS_RE.test(p) || URL_FORM_RE.test(p)) return { ok: false, error: "evidence[].path 拒绝控制字符/URL 形态" };
		const rec: EvidenceInput = { path: p };
		if (summary !== undefined) {
			if (typeof summary !== "string") return { ok: false, error: "evidence[].summary 须为字符串" };
			if (summary.length > 1000) return { ok: false, error: "evidence[].summary 过长（>1000 字）——请精简用途说明" };
			rec.summary = summary;
		}
		if (lines !== undefined) {
			const l = lines as { start?: unknown; end?: unknown };
			if (typeof l !== "object" || l === null) return { ok: false, error: "evidence[].lines 须为 {start, end}" };
			const { start, end } = l as Record<string, unknown>;
			if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || (start as number) < 1 || (end as number) < (start as number)) {
				return { ok: false, error: "evidence[].lines 须为 1-based 闭区间（正安全整数且 end ≥ start）" };
			}
			rec.lines = { start: start as number, end: end as number };
		}
		value.push(rec);
	}
	return { ok: true, value };
}

// ── 受管根解析与安全（固定根先解析校验；受管根内后续组件拒绝链接） ─────────────

export interface ManagedEvolutionRoot {
	/** 词法根（回执/路径槽沿用既有契约）。 */
	root: string;
	/** canonical 根（安全检查与组件链接判定基准）。 */
	canonical: string;
}

function statNearestExistingAncestor(target: string): { dir: string; st: fs.Stats } {
	let probe = path.normalize(target);
	for (let hops = 0; hops < 256; hops++) {
		try {
			return { dir: probe, st: fs.statSync(probe) };
		} catch { /* lint-exempt:ENOENT 逐级上探定位最近存在祖先 */ }
		const parent = path.dirname(probe);
		if (parent === probe) break;
		probe = parent;
	}
	throw new EvidenceSecurityError(`无法定位已存在祖先目录：${target}`);
}

/** 受管子路径链接/类型检查：open/resolved/evidence/.locks（存在时须为目录且非链接）；index.ndjson 须普通文件。 */
function assertManagedSubpathsRegular(canonicalRoot: string): void {
	for (const name of ["open", "resolved", "evidence", ".locks"]) {
		const p = path.join(canonicalRoot, name);
		let lst: fs.Stats;
		try { lst = fs.lstatSync(p); } catch { /* lint-exempt:不存在 → 后续创建 */ continue; } // 不存在 → 后续创建
		if (lst.isSymbolicLink()) throw new EvidenceSecurityError(`受管路径为符号链接，拒绝 I/O: ${p}`);
		if (!lst.isDirectory()) throw new EvidenceSecurityError(`受管路径不是目录，拒绝 I/O: ${p}`);
	}
	const idx = path.join(canonicalRoot, "index.ndjson");
	try {
		const lst = fs.lstatSync(idx);
		if (lst.isSymbolicLink() || !lst.isFile()) throw new EvidenceSecurityError(`索引文件须为普通文件，拒绝 I/O: ${idx}`);
	} catch (e) {
		if (e instanceof EvidenceSecurityError) throw e; // 不存在 → 后续创建
	}
}

/** 解析并校验 evolution 根：词法/真实落点均过敏感路径与契约存储检查；属主与组/其他写位检查；
 *  受管子路径拒绝链接。失败抛 EvidenceSecurityError（调用方映射 operation）。 */
export function resolveManagedEvolutionRoot(root: string): ManagedEvolutionRoot {
	let canonical: string;
	try {
		canonical = realpathNearestExisting(root);
	} catch (e) {
		throw new EvidenceSecurityError(`evolution 根真实落点无法解析（fail-closed 拒绝 I/O）：${e instanceof Error ? e.message : String(e)}`);
	}
	const lexical = path.normalize(root);
	for (const p of [lexical, canonical]) {
		if (withinContractStore(p)) throw new EvidenceSecurityError(`evolution 根与契约存储（v2-store）重叠，拒绝 I/O: ${p}`);
		if (isSensitivePathLexical(p)) throw new EvidenceSecurityError(`evolution 根位于敏感路径（凭据/密钥形态），拒绝 I/O: ${p}`);
	}
	const anchor = statNearestExistingAncestor(canonical);
	if (!anchor.st.isDirectory()) throw new EvidenceSecurityError(`evolution 根路径经过非目录对象: ${anchor.dir}`);
	if (typeof anchor.st.uid === "number" && typeof process.getuid === "function" && anchor.st.uid !== process.getuid()) {
		throw new EvidenceSecurityError(`evolution 根须为当前用户拥有（属主 uid ${anchor.st.uid} ≠ 进程 ${process.getuid()}），请人工处理——不静默修权限: ${anchor.dir}`);
	}
	if (anchor.st.mode & 0o022) {
		throw new EvidenceSecurityError(`evolution 根对组/其他用户可写（mode ${anchor.st.mode.toString(8)}），请人工收紧后重试: ${anchor.dir}`);
	}
	assertManagedSubpathsRegular(canonical);
	// B9 修复轮 F01（diting 终裁）：受管写路径接入活动 enforcer——与 guarded 等强（deny 自执法）。
	// 官方沉淀根窄豁免仅限 evolution root 自身：tool-enforced 工作区围栏不适用（checkRead 无读围栏，
	// 恰好承载 deny 读写双禁语义），deny/非法注入 fail-closed 仍拒绝整次 I/O；export.dir 不享此豁免
	//（prepareExportDir 走完整 checkWrite，含围栏）。
	const enforcer = getActiveFilePermissionEnforcer();
	if (enforcer) {
		for (const target of [lexical, path.join(lexical, "open"), path.join(lexical, "resolved"), path.join(lexical, "evidence"), path.join(lexical, ".locks"), path.join(lexical, "index.ndjson")]) {
			const v = enforcer.checkRead(target);
			if (!v.ok) throw new EvidenceSecurityError(`evolution 根受管写路径在 deny 禁入区（冻结权限），拒绝整次 I/O: ${target}`);
		}
	}
	return { root: lexical, canonical };
}

/** 条目级排他锁（仅防多 Leader 并发迁移同一条目；finally 只删自己持有的锁）。 */
export function withItemLock<T>(canonicalRoot: string, id: string, fn: () => T): T {
	const lockDir = path.join(canonicalRoot, ".locks");
	fs.mkdirSync(lockDir, { recursive: true, mode: 0o700 });
	const lockPath = path.join(lockDir, `${id}.lock`);
	enforceWriteTarget(lockPath); // F01 终裁：锁文件目标点逐 deny
	let fd: number;
	try {
		fd = fs.openSync(lockPath, "wx");
	} catch (e) {
		const code = (e as NodeJS.ErrnoException).code;
		if (code === "EEXIST") {
			throw new EvidenceSecurityError(`条目 ${id} 迁移锁被占用（.locks/${id}.lock）——可重试；崩溃遗留须确认进程已结束后人工删除，不按时间偷锁`);
		}
		throw e;
	}
	try {
		return fn();
	} finally {
		try { fs.closeSync(fd); } catch { /* lint-exempt:锁 fd 已关/关闭失败不掩盖迁移结果 */ }
		try { fs.unlinkSync(lockPath); } catch { /* lint-exempt:只删自己持有的锁；删除失败保留（诚实遗留） */ }
	}
}

// ── 捕获（逐项降级：单项失败转脱敏 omitted 记录，不阻断条目落盘） ─────────────

function clipSummary(summary: string): string {
	const r = redactCredentials(summary).replace(/[\r\n]+/g, " ");
	return r.length > EVIDENCE_SUMMARY_MAX_CHARS ? `${r.slice(0, EVIDENCE_SUMMARY_MAX_CHARS)}…（截断）` : r;
}

function originFor(abs: string, opts: EvidenceCaptureOptions): EvidenceOrigin {
	if (opts.gitRoot && isWithinAbs(abs, opts.gitRoot)) {
		return { base: "git-root", path: path.relative(opts.gitRoot, abs).split(path.sep).join("/"), cwd: opts.cwd, gitRoot: opts.gitRoot };
	}
	if (isWithinAbs(abs, opts.cwd)) {
		return { base: "cwd", path: path.relative(opts.cwd, abs).split(path.sep).join("/"), cwd: opts.cwd, gitRoot: opts.gitRoot };
	}
	return { base: "absolute", path: abs, cwd: opts.cwd, gitRoot: opts.gitRoot };
}

/** base 之下（不含 base）到 target 的组件是否含符号链接（base 须为 canonical）。 */
function hasSymlinkComponentBelow(base: string, target: string): boolean {
	const rel = path.relative(base, target);
	if (rel === "" || rel.startsWith("..") || path.isAbsolute(rel)) return false;
	let cur = base;
	for (const seg of rel.split(path.sep)) {
		if (seg === "") continue;
		cur = path.join(cur, seg);
		try {
			if (fs.lstatSync(cur).isSymbolicLink()) return true;
		} catch { /* lint-exempt:缺失组件由后续 lstat/open 兜底 */
			return false;
		}
	}
	return false;
}

function isErrno(e: unknown, code: string): boolean {
	return Boolean(e) && typeof e === "object" && (e as NodeJS.ErrnoException).code === code;
}

function captureOne(input: EvidenceInput, key: string, opts: EvidenceCaptureOptions, warnings: string[]): CapturedEvidence | OmittedEvidenceRecord {
	const omit = (reason: EvidenceOmissionCode, abs: string): OmittedEvidenceRecord => {
		const rec: OmittedEvidenceRecord = { key, phase: opts.phase, origin: originFor(abs, opts), state: "omitted", reason };
		if (input.summary !== undefined) rec.summary = clipSummary(input.summary);
		return rec;
	};
	// ① 词法敏感路径（读前拒收——.env/.pem/.key/SSH 私钥名/credentials/secrets/.ssh/.aws/.gnupg）
	if (isSensitivePathLexical(input.path)) return omit("sensitive-path", path.resolve(opts.cwd, input.path));
	const abs = path.resolve(opts.cwd, input.path);
	// ② 最终对象：缺失 / 符号链接（指向 deny/敏感 → 对应原因；其余最终链接同样拒收）/ 非普通文件
	let lst: fs.Stats;
	try {
		lst = fs.lstatSync(abs);
	} catch (e) {
		return omit(isErrno(e, "ENOENT") ? "missing" : "unreadable", abs);
	}
	if (lst.isSymbolicLink()) {
		try {
			const linkTarget = path.resolve(path.dirname(abs), fs.readlinkSync(abs));
			if (isSensitivePathLexical(linkTarget) || isSensitivePathLexical(realpathNearestExisting(linkTarget))) return omit("sensitive-path", abs);
			const enforcer0 = getActiveFilePermissionEnforcer();
			if (enforcer0 && (!enforcer0.checkRead(linkTarget, opts.cwd).ok || !enforcer0.checkRead(realpathNearestExisting(linkTarget), opts.cwd).ok)) {
				return omit("denied", abs);
			}
		} catch { /* lint-exempt:落点不可解析 → 按最终链接拒收 */ }
		return omit("symlink", abs);
	}
	if (!lst.isFile()) return omit("not-regular", abs);
	// ③ 基准下组件链接（cwd/gitRoot 内；外部绝对输入只校父目录真实落点+最终文件）
	const underGit = opts.gitRoot !== null && isWithinAbs(abs, opts.gitRoot);
	const base = underGit ? (opts.gitRoot as string) : opts.cwd;
	if ((underGit || isWithinAbs(abs, opts.cwd)) && hasSymlinkComponentBelow(base, path.dirname(abs))) return omit("symlink", abs);
	// ④ 契约存储 / 真实落点敏感 / enforcer deny（词法与真实双查）
	if (withinContractStore(abs)) return omit("denied", abs);
	let real: string;
	try {
		real = fs.realpathSync.native(abs);
	} catch (e) {
		return omit(isErrno(e, "ENOENT") ? "missing" : "unreadable", abs);
	}
	if (isSensitivePathLexical(real) || withinContractStore(real)) return omit("denied", abs);
	const enforcer = getActiveFilePermissionEnforcer();
	if (enforcer) {
		const v1 = enforcer.checkRead(abs, opts.cwd);
		const v2 = enforcer.checkRead(real, opts.cwd);
		if (!v1.ok || !v2.ok) return omit("denied", abs);
	}
	// ⑤ 打开（O_NOFOLLOW 防最终链接竞态）→ fstat 身份 → 有界读 65,537 字节
	let fd: number | undefined;
	try {
		fd = fs.openSync(abs, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW ?? 0));
	} catch (e) {
		if (isErrno(e, "ENOENT")) return omit("missing", abs);
		if (isErrno(e, "ELOOP")) return omit("symlink", abs);
		if (isErrno(e, "EACCES") || isErrno(e, "EPERM")) return omit("denied", abs);
		return omit("unreadable", abs);
	}
	try {
		const st1 = fs.fstatSync(fd);
		if (!st1.isFile()) return omit("not-regular", abs);
		const buf = Buffer.alloc(EVIDENCE_READ_LIMIT);
		let total = 0;
		for (;;) {
			if (total >= EVIDENCE_READ_LIMIT) break;
			const n = fs.readSync(fd, buf, total, EVIDENCE_READ_LIMIT - total, null);
			if (n <= 0) break;
			total += n;
		}
		if (total > EVIDENCE_MAX_BYTES) return omit("too-large", abs); // 不自动截断
		const st2 = fs.fstatSync(fd);
		if (st1.size !== st2.size || st1.mtimeMs !== st2.mtimeMs) return omit("source-changed", abs);
		// ⑥ 严格 UTF-8 文本 + NUL 拒收 + LF 规范化
		let text: string;
		try {
			text = new TextDecoder("utf-8", { fatal: true }).decode(buf.subarray(0, total));
		} catch { /* lint-exempt:非法 UTF-8 → unsupported-text 遗漏 */
			return omit("unsupported-text", abs);
		}
		if (text.includes("\u0000")) return omit("unsupported-text", abs);
		const normalized = text.replace(/\r\n?/g, "\n");
		// ⑦ 私钥块 → sensitive-content；凭据形态全文脱敏（幂等标记）
		if (containsPrivateKeyBlock(normalized)) return omit("sensitive-content", abs);
		const retained = redactCredentials(normalized);
		const redacted = retained !== normalized;
		const bytes = Buffer.byteLength(retained, "utf8");
		if (bytes > EVIDENCE_MAX_BYTES) return omit("too-large", abs);
		const digest = sha256OfText(retained);
		// ⑧ 行锚校验（指向规范化+脱敏后副本；越界不阻止留存，但清除锚并告警）
		let lines = input.lines;
		if (lines !== undefined) {
			const lineCount = retained.split("\n").length;
			if (lines.start < 1 || lines.end > lineCount) {
				pushWarning(warnings, `证据 ${key} 行锚越界（脱敏后副本共 ${lineCount} 行，请求 ${lines.start}-${lines.end}）——已清除行锚（anchor-invalidated）`);
				lines = undefined;
			}
		}
		const record: RetainedEvidenceRecord = { key, phase: opts.phase, origin: originFor(abs, opts), state: "retained", path: globalEvidencePathFor(opts.id, digestHexOf(digest) as string), digest, bytes, redacted };
		if (input.summary !== undefined) record.summary = clipSummary(input.summary);
		if (lines !== undefined) record.lines = lines;
		return { record, content: retained };
	} finally {
		try { if (fd !== undefined) fs.closeSync(fd); } catch { /* lint-exempt:关闭失败不掩盖主结果 */ }
	}
}

/** 发布留存副本（先副本后条目 md；同 digest 已存在则验证复用，不覆盖异内容）。
 *  B9 修复轮 F04：evidence/<id> 预存链接/异类对象整组拒绝（lstat 非链接才 mkdir，不写穿受管根）；
 *  临时与回读走 safeWrite/safeRead（O_NOFOLLOW——最终链接目标不读不写）。 */
function publishRetained(canonicalRoot: string, id: string, items: (CapturedEvidence | OmittedEvidenceRecord)[], results: EvidenceResult[], warnings: string[]): void {
	const dir = path.join(canonicalRoot, "evidence", id);
	const degrade = (i: number, key: string, phase: "log" | "resolve", origin: EvidenceOrigin, summary: string | undefined, msg: string): void => {
		const rec: OmittedEvidenceRecord = { key, phase, origin, state: "omitted", reason: "write-failed" };
		if (summary !== undefined) rec.summary = summary;
		results[i] = { record: rec, health: null };
		pushWarning(warnings, `证据 ${key} 留存写失败（${msg}）——条目照常落盘，副本可能遗留孤立文件`);
	};
	// 目录级预检（F04）：已知 <id> 子目录为链接/异类对象 → 拒绝任何写穿，整组降级
	// F01 终裁：evidence/<id> 条目级子目录逐目标 deny 检查（顶层六路径不覆盖子目录/file 规则）
	try {
		enforceWriteTarget(dir);
	} catch (e) {
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			if (!("record" in item)) { results[i] = { record: item, health: null }; continue; }
			degrade(i, item.record.key, item.record.phase, item.record.origin, item.record.summary, e instanceof Error ? e.message : String(e));
		}
		return;
	}
	let dirBlocked: string | null = null;
	try {
		const lst = fs.lstatSync(dir);
		if (lst.isSymbolicLink()) dirBlocked = "evidence/<id> 为符号链接（拒绝写穿受管根）";
		else if (!lst.isDirectory()) dirBlocked = "evidence/<id> 非目录";
	} catch { /* lint-exempt:不存在 → 创建 */ }
	if (dirBlocked !== null) {
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			if (!("record" in item)) { results[i] = { record: item, health: null }; continue; }
			degrade(i, item.record.key, item.record.phase, item.record.origin, item.record.summary, dirBlocked);
		}
		return;
	}
	let dirReady = false;
	const ensureDir = (): void => {
		if (!dirReady) {
			fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
			dirReady = true;
		}
	};	for (let i = 0; i < items.length; i++) {
		const item = items[i];
		if (!("record" in item)) {
			results[i] = { record: item, health: null };
			continue;
		}
		const hex = digestHexOf(item.record.digest) as string;
		const fail = (msg: string): void => degrade(i, item.record.key, item.record.phase, item.record.origin, item.record.summary, msg);
		try {
			ensureDir();
			const target = path.join(dir, `${hex}.txt`);
			enforceWriteTarget(target); // F01 终裁：副本目标点逐 deny（file 规则不被子目录检查代表）
			const verifyExisting = (): boolean => {
				try {
					const cur = safeReadRegularFile(target);
					return sha256OfText(cur) === item.record.digest;
				} catch {
					return false; // 链接/不可读目标 → 内容不符口径处理（不覆盖异内容）
				}
			};
			const tmp = path.join(dir, `.${hex}.tmp-${process.pid}-${createHash("sha1").update(`${Date.now()}-${Math.random()}`).digest("hex").slice(0, 8)}`);
			enforceWriteTarget(tmp); // F01 终裁：临时目标点逐 deny
			safeWriteRegularFile(tmp, item.content, 0o600);
			let linked = false;
			try {
				fs.linkSync(tmp, target); // 排他发布：同名存在即 EEXIST，不覆盖异内容
				linked = true;
			} catch (e) {
				if (isErrno(e, "EEXIST")) {
					if (verifyExisting()) linked = true; // 同内容去重复用
					else { try { fs.unlinkSync(tmp); } catch { /* lint-exempt:孤立临时文件披露于警告 */ } fail("同 digest 文件已存在但内容不符或不可安全读取，拒绝覆盖"); continue; }
				} else {
					throw e;
				}
			} finally {
				if (linked) { try { fs.unlinkSync(tmp); } catch { /* lint-exempt:临时文件已并入目标 */ } }
			}
			if (!linked) { fail("副本未能发布"); continue; }
			// 发布后安全回读校验：只有实际留存并校验过的字节才标 retained/verified
			if (sha256OfText(safeReadRegularFile(target)) !== item.record.digest) {
				fail("发布后回读 digest 不一致");
				continue;
			}
			results[i] = { record: item.record, health: "verified" };
		} catch (e) {
			fail(e instanceof Error ? e.message : String(e));
		}
	}
}

/** 捕获 + 发布（logItem / 首次 resolve 共用）：单项失败降级为 omitted，条目照常。 */
export function captureEvidence(inputs: readonly EvidenceInput[], opts: EvidenceCaptureOptions): { results: EvidenceResult[]; warnings: string[] } {
	const warnings: string[] = [];
	const items = inputs.map((input, i) => captureOne(input, `${opts.phase}-${i + 1}`, opts, warnings));
	const results: EvidenceResult[] = new Array<EvidenceResult>(items.length);
	publishRetained(opts.canonicalRoot, opts.id, items, results, warnings);
	return { results, warnings };
}

// ── 校验（show/resolve/export 只读健康检查；不更新 digest、不落缓存、不触发自愈） ──

export function verifyEvidenceAt(mdDir: string, records: readonly EvidenceRecord[], pathFor: (digestHex: string) => string): { results: EvidenceResult[]; warnings: string[] } {
	const warnings: string[] = [];
	const enforcer = getActiveFilePermissionEnforcer();
	const results: EvidenceResult[] = records.map((record) => {
		if (record.state === "omitted") return { record, health: null };
		const hex = digestHexOf(record.digest);
		if (hex === null || record.path !== pathFor(hex)) {
			pushWarning(warnings, `证据 ${record.key} 清单路径与 id/digest 推导位置不符（invalid-manifest 迹象）：${record.path}`);
			return { record, health: "unreadable" as EvidenceHealth };
		}
		// B9 修复轮 F04：沿途组件链接检查（evidence/<id> 等受管中间对象为链接 → 不读）
		const linkComp = firstLinkComponent(mdDir, record.path);
		if (linkComp !== null) {
			pushWarning(warnings, `证据 ${record.key} 受管路径组件为符号链接，拒绝读取: ${linkComp}`);
			return { record, health: "unreadable" as EvidenceHealth };
		}
		const target = path.resolve(mdDir, record.path);
		try {
			const lst = fs.lstatSync(target);
			if (lst.isSymbolicLink() || !lst.isFile()) {
				pushWarning(warnings, `证据 ${record.key} 副本不是普通文件: ${record.path}`);
				return { record, health: "unreadable" as EvidenceHealth };
			}
		} catch (e) {
			return { record, health: (isErrno(e, "ENOENT") ? "missing" : "unreadable") as EvidenceHealth };
		}
		// B9 修复轮 F01/F04：受管回读经活动 enforcer（deny 禁入 → denied）
		if (enforcer && !enforcer.checkRead(target).ok) return { record, health: "denied" as EvidenceHealth };
		let content: string;
		try {
			content = safeReadRegularFile(target);
		} catch (e) {
			if (isErrno(e, "ELOOP")) return { record, health: "unreadable" as EvidenceHealth };
			return { record, health: (isErrno(e, "EACCES") || isErrno(e, "EPERM") ? "denied" : "unreadable") as EvidenceHealth };
		}
		const bytes = Buffer.byteLength(content, "utf8");
		if (bytes !== record.bytes || sha256OfText(content) !== record.digest) return { record, health: "drifted" };
		return { record, health: "verified" };
	});
	return { results, warnings };
}
// ── 清单校验（parse 侧封闭校验：损坏 → invalid-manifest，不伪装 legacy） ──────

export type EvidenceManifestValidation = { ok: true; value: EvidenceRecord[] } | { ok: false; error: string };

const KEY_RE = /^(log|resolve)-[1-3]$/;
const ORIGIN_BASES = new Set(["cwd", "git-root", "absolute", "redacted"]);
const RETAINED_KEYS = new Set(["key", "phase", "origin", "summary", "state", "path", "digest", "bytes", "redacted", "lines", "derivedFromDigest"]);
const OMITTED_KEYS = new Set(["key", "phase", "origin", "summary", "state", "reason"]);

function validLines(v: unknown): v is { start: number; end: number } {
	if (typeof v !== "object" || v === null) return false;
	const { start, end } = v as Record<string, unknown>;
	return Number.isSafeInteger(start) && Number.isSafeInteger(end) && (start as number) >= 1 && (end as number) >= (start as number);
}

function validOrigin(v: unknown): v is EvidenceOrigin {
	if (typeof v !== "object" || v === null) return false;
	const keys = Object.keys(v);
	if (keys.some((k) => !["base", "path", "cwd", "gitRoot"].includes(k))) return false;
	const o = v as Record<string, unknown>;
	if (typeof o.base !== "string" || !ORIGIN_BASES.has(o.base)) return false;
	for (const slot of ["path", "cwd", "gitRoot"]) {
		const val = o[slot];
		if (val !== null && typeof val !== "string") return false;
	}
	return true;
}

/** 校验磁盘上的 evidence 记录数组（封闭键集/枚举/路径推导位置/上限；≤6 条）。 */
export function validateEvidenceManifest(id: string, raw: unknown): EvidenceManifestValidation {
	if (!Array.isArray(raw)) return { ok: false, error: "evidence 须为 JSON 数组" };
	if (raw.length > EVIDENCE_RECORDS_MAX) return { ok: false, error: `条目内记录数超过 ${EVIDENCE_RECORDS_MAX}` };
	const seenKeys = new Set<string>();
	for (const item of raw) {
		if (typeof item !== "object" || item === null) return { ok: false, error: "evidence 记录须为对象" };
		const rec = item as Record<string, unknown>;
		if (typeof rec.key !== "string" || !KEY_RE.test(rec.key)) return { ok: false, error: `记录 key 非法: ${String(rec.key)}` };
		if (seenKeys.has(rec.key)) return { ok: false, error: `记录 key 重复: ${rec.key}` };
		seenKeys.add(rec.key);
		if (rec.phase !== "log" && rec.phase !== "resolve") return { ok: false, error: `${rec.key}: phase 非法` };
		if (rec.phase !== rec.key.split("-")[0]) return { ok: false, error: `${rec.key}: phase 与 key 前缀不一致` };
		if (!validOrigin(rec.origin)) return { ok: false, error: `${rec.key}: origin 非法` };
		if (rec.summary !== undefined && typeof rec.summary !== "string") return { ok: false, error: `${rec.key}: summary 须为字符串` };
		if (rec.state === "retained") {
			if (Object.keys(rec).some((k) => !RETAINED_KEYS.has(k))) return { ok: false, error: `${rec.key}: retained 记录含未知键` };
			if (typeof rec.digest !== "string" || digestHexOf(rec.digest) === null) return { ok: false, error: `${rec.key}: digest 须为 sha256:<64hex>` };
			const hex = digestHexOf(rec.digest) as string;
			if (rec.path !== globalEvidencePathFor(id, hex) && rec.path !== exportEvidencePathFor(id, hex)) {
				return { ok: false, error: `${rec.key}: path 与 id/digest 推导位置不符（拒绝路径穿越/跨条目引用）` };
			}
			if (!Number.isSafeInteger(rec.bytes) || (rec.bytes as number) < 1 || (rec.bytes as number) > EVIDENCE_MAX_BYTES) return { ok: false, error: `${rec.key}: bytes 越界` };
			if (typeof rec.redacted !== "boolean") return { ok: false, error: `${rec.key}: redacted 须为布尔` };
			if (rec.lines !== undefined && !validLines(rec.lines)) return { ok: false, error: `${rec.key}: lines 非法` };
			if (rec.derivedFromDigest !== undefined && (typeof rec.derivedFromDigest !== "string" || digestHexOf(rec.derivedFromDigest) === null)) {
				return { ok: false, error: `${rec.key}: derivedFromDigest 须为合法摘要` };
			}
		} else if (rec.state === "omitted") {
			if (Object.keys(rec).some((k) => !OMITTED_KEYS.has(k))) return { ok: false, error: `${rec.key}: omitted 记录含未知键` };
			if (typeof rec.reason !== "string" || !(EVIDENCE_OMISSION_CODES as readonly string[]).includes(rec.reason)) {
				return { ok: false, error: `${rec.key}: omission 原因不在封闭清单` };
			}
		} else {
			return { ok: false, error: `${rec.key}: state 须为 retained/omitted` };
		}
	}
	return { ok: true, value: raw as EvidenceRecord[] };
}

/** 新增 JSON 元数据合计 ≤96 KiB（防手改条目绕过限额——超限按 invalid-manifest 处理）。 */
export function evidenceManifestCharsOk(parts: readonly (string | undefined)[]): boolean {
	const total = parts.reduce((acc, p) => acc + (p?.length ?? 0), 0);
	return total <= EVIDENCE_MANIFEST_MAX_CHARS;
}

// ── 渲染（show/export 的「留存证据」章节——只从元数据生成，不执行夹具/不回源） ──

export type EvidenceState = "legacy" | "recorded" | "invalid";

/** 无 evidence 字段（历史条目或本次未请求留存）的展示行。 */
export const LEGACY_EVIDENCE_NOTE = "未记录留存清单（历史条目或本次未请求留存）";

/** evidence 字段损坏（invalid-manifest）的展示行。 */
export const INVALID_MANIFEST_NOTE = "证据清单损坏（invalid-manifest）：字段存在但未通过校验，须人工核对——resolve/export 已拒绝";

export function renderEvidenceSection(results: readonly EvidenceResult[]): string {
	if (results.length === 0) return `\n## 留存证据\n\n（清单为空——请求了留存但无记录）\n`;
	const lines: string[] = ["", "## 留存证据", ""];
	for (const { record, health } of results) {
		if (record.state === "retained") {
			lines.push(`- ${record.key} · retained · ${record.digest} · ${record.path} · ${record.redacted ? "已脱敏（副本可能无法直接运行）" : "未脱敏"} · origin 未复核 · ${health ?? "未校验"}`);
		} else {
			lines.push(`- ${record.key} · omitted · 未留存原因：${record.reason}`);
		}
		if (record.summary !== undefined) lines.push(`  用途：${record.summary}`);
	}
	lines.push("");
	return lines.join("\n");
}

// ── 导出（自包含包：先验原 digest → 重脱敏 → 重写清单路径 → 副本先行 → md 为提交点） ──

export interface ExportEvidencePlan {
	records: EvidenceRecord[];
	results: EvidenceResult[];
	evidenceBytes: number;
	warnings: string[];
	evidenceState: EvidenceState;
	evidenceComplete: boolean | null;
}

/** 导出目录预检（B9 修复轮 F01：整单安全预检零写入——全部判定先于任何 mkdir）：
 *  ① enforcer 完整 checkWrite（含 tool-enforced 工作区围栏——export.dir 不享官方沉淀根窄豁免）；
 *  ② 敏感区/契约存储（词法+真实落点双查）；③ 拒绝系统临时根/文件系统根；④ 通过后才 mkdir
 *  并绑定 canonical，子对象（<id>.md / <id>.evidence/）非链接。失败抛 EvidenceSecurityError。 */
export function prepareExportDir(dir: string, id: string): { root: string; canonical: string } {
	const lexical = path.resolve(dir);
	const canonicalPre = realpathNearestExisting(lexical); // 目标不存在也可解析（mkdir 前判定）
	for (const p of [lexical, canonicalPre]) {
		if (withinContractStore(p)) throw new EvidenceSecurityError(`export 目标与契约存储重叠，拒绝: ${p}`);
		if (isSensitivePathLexical(p)) throw new EvidenceSecurityError(`export 目标位于敏感路径，拒绝: ${p}`);
	}
	const enforcer = getActiveFilePermissionEnforcer();
	if (enforcer) {
		for (const p of [lexical, canonicalPre]) {
			const v = enforcer.checkWrite(p);
			if (!v.ok) throw new EvidenceSecurityError(`export 目标未通过冻结权限校验（完整 checkWrite，含工作区围栏），拒绝导出: ${p}`);
		}
	}
	if (canonicalPre === fs.realpathSync.native(os.tmpdir())) {
		throw new EvidenceSecurityError("export 拒绝直接以系统临时根为目的根——可用其下私有子目录");
	}
	if (canonicalPre === path.parse(canonicalPre).root) {
		throw new EvidenceSecurityError("export 拒绝以文件系统根为目的根");
	}
	// F01 终裁确认：预检零 mkdir——目录实体创建延迟到全部目标点预检之后（ensureExportDir）。
	return { root: lexical, canonical: canonicalPre };
}

/** 导出目录实体化（预检全部通过后）：mkdir + canonical 绑定 + 子对象（<id>.md / <id>.evidence/）
 *  链接/类型检查（不存在 → 本次创建）。失败抛 EvidenceSecurityError。 */
export function ensureExportDir(ex: { root: string }, id: string): string {
	fs.mkdirSync(ex.root, { recursive: true });
	const canonical = fs.realpathSync.native(ex.root);
	for (const rel of [`${id}.md`, `${id}.evidence`]) {
		const p = path.join(canonical, rel);
		try {
			const lst = fs.lstatSync(p);
			if (lst.isSymbolicLink()) throw new EvidenceSecurityError(`export 目标子对象为符号链接，拒绝: ${p}`);
			if (rel.endsWith(".md") ? !lst.isFile() : !lst.isDirectory()) {
				throw new EvidenceSecurityError(`export 目标子对象类型不符（${rel}），拒绝: ${p}`);
			}
		} catch (e) {
			if (e instanceof EvidenceSecurityError) throw e; // 不存在 → 本次创建
		}
	}
	return canonical;
}

/** origin 导出清洗：absolute → redacted/path=null；一律去除自动记录的本机绝对根（cwd/gitRoot）。 */
function scrubOriginForExport(origin: EvidenceOrigin): EvidenceOrigin {
	return {
		base: origin.base === "absolute" ? "redacted" : origin.base,
		path: origin.base === "absolute" ? null : origin.path,
		cwd: null,
		gitRoot: null,
	};
}

/** 导出计划（先规划后发布——F01 终裁确认：全部写入目标点在预检阶段可枚举，发布阶段才落盘）。 */
export interface ExportPackagePlan extends ExportEvidencePlan {
	evDir: string;
	copies: ReadonlyArray<{ target: string; tmp: string; content: string }>;
}

/** 导出计划阶段（零导出写入）：retained 异常预发布失败（旧目标不变）；重脱敏改变字节则重算 digest 并记
 *  derivedFromDigest；origin 去自动记录的本机绝对根（absolute → redacted，cwd/gitRoot 置 null）。 */
export function planExportEvidencePackage(evolutionCanonicalRoot: string, exportRoot: string, id: string, records: EvidenceRecord[] | undefined): ExportPackagePlan {
	const warnings: string[] = [];
	const copies: { target: string; tmp: string; content: string }[] = [];
	if (records === undefined) {
		return { records: [], results: [], evidenceBytes: 0, warnings, evidenceState: "legacy", evidenceComplete: null, evDir: "", copies };
	}
	// ① 先验原 digest：任一 retained 异常（missing/drifted/denied/unreadable）预发布失败
	const globalVerify = verifyEvidenceAt(path.join(evolutionCanonicalRoot, "open"), records, (hex) => globalEvidencePathFor(id, hex));
	for (const { record, health } of globalVerify.results) {
		if (record.state === "retained" && health !== "verified") {
			throw new EvidenceSecurityError(`导出预发布失败：证据 ${record.key} 全局副本状态 ${health}——先核对/修复全局副本再导出（旧目标不变）`);
		}
	}
	warnings.push(...globalVerify.warnings);
	// ② 逐份读出 → 私钥块拒输出 → 当前脱敏器重脱敏 → 需要时重算 digest/清除行锚
	const exported: EvidenceRecord[] = [];
	const results: EvidenceResult[] = [];
	let evidenceBytes = 0;
	for (const record of records) {
		if (record.state === "omitted") {
			// B9 修复轮（F02 静态注）：omitted 分支同样去除自动记录的本机绝对根——不随包扩散
			const scrubbed: OmittedEvidenceRecord = { ...record, origin: scrubOriginForExport(record.origin) };
			if (record.summary !== undefined) scrubbed.summary = redactCredentials(record.summary);
			exported.push(scrubbed);
			results.push({ record: scrubbed, health: null });
			continue;
		}
		const hex = digestHexOf(record.digest) as string;
		const src = safeReadRegularFile(path.join(evolutionCanonicalRoot, "evidence", id, `${hex}.txt`));
		if (containsPrivateKeyBlock(src)) {
			throw new EvidenceSecurityError(`导出拒绝：证据 ${record.key} 副本含私钥块（不原样扩散，不自动擦除）——需人工脱敏摘录`);
		}
		const reRedacted = redactCredentials(src);
		const changed = reRedacted !== src;
		const newDigest = changed ? sha256OfText(reRedacted) : record.digest;
		const newHex = digestHexOf(newDigest) as string;
		const outRecord: RetainedEvidenceRecord = {
			key: record.key,
			phase: record.phase,
			origin: scrubOriginForExport(record.origin),
			state: "retained",
			path: exportEvidencePathFor(id, newHex),
			digest: newDigest,
			bytes: Buffer.byteLength(reRedacted, "utf8"),
			redacted: record.redacted || changed,
		};
		if (record.summary !== undefined) outRecord.summary = redactCredentials(record.summary);
		if (record.lines !== undefined) {
			const oldCount = src.split("\n").length;
			const newCount = reRedacted.split("\n").length;
			if (changed && newCount !== oldCount) {
				pushWarning(warnings, `导出证据 ${record.key} 重脱敏改变行数（${oldCount} → ${newCount}）——已清除行锚`);
			} else {
				outRecord.lines = record.lines;
			}
		}
		if (changed) outRecord.derivedFromDigest = record.digest;
		// ③ 副本目标点仅入计划（发布阶段统一落盘——先规划后发布，预检先于任何 mkdir）
		const evDir = path.join(exportRoot, `${id}.evidence`);
		const target = path.join(evDir, `${newHex}.txt`);
		const tmp = path.join(evDir, `.${newHex}.tmp-${process.pid}-${createHash("sha1").update(`${Date.now()}-${Math.random()}`).digest("hex").slice(0, 8)}`);
		copies.push({ target, tmp, content: reRedacted });
		evidenceBytes += outRecord.bytes;
		exported.push(outRecord);
		results.push({ record: outRecord, health: "verified" });
	}
	const allRetained = exported.every((r) => r.state === "retained");
	return {
		records: exported,
		results,
		evidenceBytes,
		warnings,
		evidenceState: "recorded",
		evidenceComplete: exported.length === 0 ? null : allRetained,
		evDir: path.join(exportRoot, `${id}.evidence`),
		copies,
	};
}

/** 导出包目标点前置预检（F01 终裁二轮：先于 ensureExportDir 的根 mkdir——拒绝时零目录创建）。 */
export function preflightExportPackageTargets(plan: ExportPackagePlan): void {
	enforceWriteTarget(plan.evDir, { full: true });
	for (const c of plan.copies) {
		enforceWriteTarget(c.target, { full: true });
		enforceWriteTarget(c.tmp, { full: true });
	}
}

/** 导出发布阶段：逐目标预检（full 完整 checkWrite 含围栏）再 mkdir/写/链接；同名异内容拒绝覆盖。
 *  （预检幂等——发布阶段再查一次作为纵深，不依赖调用方已过 preflight。） */
export function publishExportEvidencePackage(plan: ExportPackagePlan): ExportEvidencePlan {
	// F01 终裁确认：包内全部目标点预检先于任何 mkdir/写入（file/子目录 deny 不被父目录检查代表）
	preflightExportPackageTargets(plan);
	if (plan.copies.length > 0) fs.mkdirSync(plan.evDir, { recursive: true, mode: 0o700 });
	for (const c of plan.copies) {
		safeWriteRegularFile(c.tmp, c.content, 0o600);
		try {
			fs.linkSync(c.tmp, c.target);
		} catch (e) {
			if (isErrno(e, "EEXIST")) {
				const cur = safeReadRegularFile(c.target);
				if (sha256OfText(cur) !== sha256OfText(c.content)) {
					try { fs.unlinkSync(c.tmp); } catch { /* lint-exempt:临时文件遗留披露于抛错路径 */ }
					throw new EvidenceSecurityError(`导出拒绝：${c.target} 已存在同名异内容副本，不覆盖`);
				}
			} else {
				throw e;
			}
		} finally {
			try { fs.unlinkSync(c.tmp); } catch { /* lint-exempt:已并入目标 */ }
		}
	}
	return {
		records: plan.records,
		results: plan.results,
		evidenceBytes: plan.evidenceBytes,
		warnings: plan.warnings,
		evidenceState: plan.evidenceState,
		evidenceComplete: plan.evidenceComplete,
	};
}
