/**
 * mcp-client.ts — v1.5.198 通用 MCP 消费：mcpServers 声明式配置 → pi 工具。
 *
 * 背景：原 mcp-tools.ts（P4-4）硬编码重实现了智谱三个 Remote MCP 的零配置工具；v1.5.198 起
 * 完整 MCP 能力（智谱视觉理解 Local stdio server、tavily/firecrawl 等）统一走本文件的通用
 * `mcpServers` 配置消费（Claude Code 同款 JSON 形态）。v1.5.245 清理：旧自实现工具层删除，
 * 其底层协议件（rpcRequest/parseSseResult/isSessionError/truncateMcpText/resolveMcpCallTimeoutMs）
 * 迁入本文件作为唯一实现；v1.5.251 修复：响应解析支持协议允许的 application/json 单响应，
 * 智谱网关 auth 失败（HTTP 200 + 非 JSON-RPC 业务体 {"code":1000,"msg":"身份验证失败。"}）
 * 原被误报为"无匹配 reqId"，现抛 McpGatewayError 携带原始原因并可被 isSessionError 归类：
 *
 *   { "mcpServers": { "web-search-prime": { "type": "http", "url": "...", "headers": { "Authorization": "Bearer ${ZHIPU_API_KEY}" } },
 *                     "vision": { "command": "npx", "args": ["-y", "@z_ai/mcp-server"], "env": { "Z_AI_API_KEY": "${Z_AI_API_KEY}" } } } }
 *
 * 配置来源（低→高优先级，同名后者覆盖）：
 *   1. ~/.pi/agent/mcp.json（{ mcpServers } 或裸 server map）
 *   2. ~/.pi/agent/settings.json 的 mcpServers 键
 *   3. ~/.agents/.mcp.json（跨工具共享的全局 MCP 配置）
 *   4. cwd 及祖先目录（至 git root）的 .mcp.json（同上两种形态）
 *   5. cwd 及祖先目录的 .agents/.mcp.json（项目共享 MCP 配置）
 *   6. 项目 .pi/settings.json 的 mcpServers 键
 * 插值：url/headers/env 值中的 ${VAR} / ${VAR:-default}（未设置且无默认 → 省略该键 + warning）。
 *
 * 架构（v1.5.250 单通道化，主上裁定：识图链 read→skill→MCP 的优先级被直连工具破坏——
 *   实战 2026-08-25 Database 会话：无视觉模型 read 图被守卫拦截后，模型误判 skill 不在清单、
 *   直取工具清单里的一等直连工具 analyze_image，识图优先级链被短路 + 90s stdio 超时）：
 *   - HttpMcpServer：streamable HTTP（SSE JSON-RPC，initialize 取 mcp-session-id → initialized → 调用；
 *     sid 缓存复用，session/auth 错误重建一次）。
 *   - StdioMcpServer：spawn 子进程 NDJSON JSON-RPC；懒启动（首个调用才 spawn）；崩溃重启一次；
 *     close() 在 session_shutdown 清理（防孤儿进程）。
 *   - 工具发现：tools/list 结果缓存 <amagiData>/mcp-tool-cache.json，仅供 mcp_list_tools 展示；
 *     主进程后台刷新缓存。**远端工具不再直连注册为一等 pi 工具**（v1.5.250 删除 makeServerTool：
 *     远端工具以一等身份出现在工具清单，会绕过上层引导的优先级链、并把 MCP 内部细节提升为
 *     模型的一等能力面）。
 *   - 元工具（无条件注册，角色白名单可稳定引用，MCP 唯一通道）：mcp_call（免发现通用调用，
 *     随调随握手）+ mcp_list_tools（配置/发现清单）。
 *   - mcp_list_tools 展示名：远端工具名与内置工具名冲突时预览为 `${server}__${tool}`（仅展示，不注册）。
 *   - 超时：v1.5.245 起按远端工具分类 per-call 生效（视觉类 90s，其余默认 60s，env 可调）——修复视觉工具
 *     经本通道 30s 超时假失败（服务端实测 ~36s）；RegisterMcpOpts.callTimeoutMs 显式注入优先。
 *
 * 错误模型：execute 永不 throw；凭据值不进日志（headers/env 只写键名）。
 */

import { spawn, type ChildProcess } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { Type, type Static } from "typebox";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { nativeMcpRegistrationAvailable } from "./host-capabilities.ts";
import { amagiDataFile } from "./data-dir.ts";
import { imageReadCapability } from "./guards.ts";
import { defaultHostImageDecoder, IMAGE_DECODE_LIMIT_BYTES, IMAGE_DECODE_PROBE_BUDGET_MS } from "./image-decoder.ts";
// B3（自建面处置设计 §B3）：stdio 行帧迁移共享 LF 行帧模块（增量 UTF-8 解码 + 逐 child 生命周期）。
import { createLfFramer, type LfFramer } from "./jsonl-framing.ts";
import { withArgumentArtifactNormalization } from "./tool-result-adapter.ts"; // ev-20260920：server 位 "null" 伪影剥离（列全部而非误报未配置）
// P2-mcp-connect（设计 §3.1–§3.3 + §9 P2 行）：mcp_call/mcp_list_tools 结构化输出 wire 接线。
// mcp-wire 为纯 schema/投影模块（P1），本文件在其上映射——投影落点裁定见 mcp-override.ts 头注：
// wire 只能在远端结果/发现数据/异常实例的持有处（native execute）同次构造（single-read 纪律），
// 经 details 透传原始载荷会造成未脱敏第二副本。权限语义零变化：M3 grant/discovery 筛选/call 重验
// 逐次判定不因 wire 存在而改变；wire tools 恒用权限过滤后的可见集（不泄漏未授权能力）。
import {
	McpCallOutputSchema, McpListOutputSchema,
	toMcpCallResultWire, toMcpCallErrorWire, toMcpListResultWire, toMcpListErrorWire,
	classifyMcpWireError, type McpListServerSource, type McpListResultSource,
} from "./mcp-wire.ts";
// B6a（十月迭代 M3，设计 §5.3/§7）：混合路线基座消费面——owner=host 的 server 不进自研连接列表，
// mcp_call 收到 host owner 返回「请使用原生工具」指引（不双通道转发）；无计划/非 mixed 零行为变化。
import { canonicalMcpServerName, hostOwnerGuidanceText, ownerOfServerInPlan, type McpOwnershipPlan } from "./mcp-host-bridge.ts";
import { builtinMcpExplicitlyDisabled } from "./mcp-host-bridge.ts";
import { registerNativeMcpTools } from "./mcp-native.ts";

/** 宿主 AgentToolResult.structuredContent 的 JSON 值面（JsonValue；宿主未从包根导出，经索引
 *  访问提取）。P1 wire 接口是封闭命名接口（缺字符串索引签名）放不进 JsonValue——值本身恒为
 *  JSON-safe（P1 测试 Value.Check + 属性键静态对照已证），桥接仅类型层，零运行时动作。 */
export type McpWireStructuredContent = NonNullable<import("@earendil-works/pi-coding-agent").AgentToolResult["structuredContent"]>;
/** 同上桥接小件：wire → 宿主 structuredContent 载面（接线处统一用，注释集中于此）。 */
const asWireContent = (w: unknown): McpWireStructuredContent => w as McpWireStructuredContent;
export {
	MCP_ENV_BUNDLE_VAR, MCP_UNIFIED_CHANNEL_SERVER, clearMcpEnvBundle, envReferences, interpolateEnv,
	loadMcpRouting, loadMcpServerConfigs, resolveAgentMcpEnvKeys, resolveAgentMcpServers,
	checkMcpCallPermission, concreteServersReferenced, filterDiscoveredToolsForPermission, normalizeMcpPermission,
} from "./mcp-config.ts";
import {
	checkMcpCallPermission, concreteServersReferenced, filterDiscoveredToolsForPermission,
	describeMcpRouteDenial, loadMcpRouting, loadMcpServerConfigs, MCP_UNIFIED_CHANNEL_SERVER,
	type McpPermission, type McpRouteIdentity, type McpServerConfig,
} from "./mcp-config.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 协议件（v1.5.245 自原 mcp-tools.ts 迁入，唯一实现）：SSE JSON-RPC 解析/请求/超时分类/截断
// ─────────────────────────────────────────────────────────────────────────────

/** 依赖注入（测试可注入 fetch / apiKey / 超时；生产走 env + globalThis.fetch）。 */
export interface McpToolsDeps {
	/** fetch 注入点；默认 globalThis.fetch。 */
	fetch?: typeof fetch;
	/** API key 覆盖。 */
	apiKey?: string;
	/** 单次 HTTP 请求超时（ms）覆盖。 */
	timeoutMs?: number;
}

export interface JsonRpcResult {
	content?: { type: string; text?: string }[];
	isError?: boolean;
	[key: string]: unknown;
}

/** JSON-RPC 层错误（code/message 保留，用于判定是否需重建 session）。 */
export class McpRpcError extends Error {
	readonly rpcCode: number | string;
	readonly rpcMessage: string;
	constructor(message: string, code: number | string, rpcMessage: string) {
		super(message);
		this.name = "McpRpcError";
		this.rpcCode = code;
		this.rpcMessage = rpcMessage;
	}
}

/** 网关/代理层业务错误：HTTP 200 + application/json 但响应体非 JSON-RPC（智谱网关 auth 失败形态，v1.5.251）。 */
export class McpGatewayError extends Error {
	readonly detail: string;
	constructor(message: string, detail: string) {
		super(message);
		this.name = "McpGatewayError";
		this.detail = detail;
	}
}

/** 单条 JSON-RPC 消息按 reqId 匹配：error → McpRpcError；result 命中 → 返回；未命中 → undefined。 */
function matchRpcMessage(msg: any, reqId: number): JsonRpcResult | undefined {
	if (!msg || msg.id !== reqId) return undefined;
	if (msg.error) {
		const code = msg.error.code;
		const message = String(msg.error.message ?? "");
		throw new McpRpcError(`MCP JSON-RPC error ${code}: ${message}`, code, message);
	}
	return msg.result !== undefined ? (msg.result as JsonRpcResult) : undefined;
}

/** 非 JSON-RPC 的网关业务错误体 → 抛 McpGatewayError（消息含网关原始 msg/code，可被 isSessionError 归类）。 */
function throwGatewayError(payload: any): never {
	const detail = String(payload?.msg ?? payload?.message ?? payload?.detail ?? JSON.stringify(payload).slice(0, 200));
	const code = payload?.code ?? payload?.status;
	throw new McpGatewayError(`MCP 网关返回非 JSON-RPC 响应: ${detail}${code !== undefined && code !== "" ? ` (code=${code})` : ""}`, detail);
}

/**
 * 解析 MCP streamable HTTP 响应体，提取匹配 reqId 的 JSON-RPC result。协议允许两种形态：
 * text/event-stream（SSE 块以空行分隔；一个块内可能有多行 data:，按 SSE 规范拼接为一条消息）
 * 或 application/json（单个 JSON-RPC 响应）。v1.5.251 前只支持前者——智谱网关 auth 失败时返回
 * HTTP 200 + application/json 的非 JSON-RPC 业务体（{"code":1000,"msg":"身份验证失败。"}），
 * 被误报为"无匹配 reqId"且真实原因被掩盖；现在整体 JSON 先试解，非 JSON-RPC 形状 → McpGatewayError。
 */
export function parseSseResult(body: string, reqId: number): JsonRpcResult {
	const trimmed = body.trim();
	if (trimmed.startsWith("{")) {
		try {
			const whole: any = JSON.parse(trimmed);
			const hit = matchRpcMessage(whole, reqId);
			if (hit !== undefined) return hit;
			// JSON-RPC 形状但 id 不匹配 → 落到 SSE 分支统一报"无匹配"；非 JSON-RPC → 网关业务错误
			const isRpcShape = whole !== null && typeof whole === "object" &&
				("jsonrpc" in whole || "result" in whole || "error" in whole || "method" in whole || "id" in whole);
			if (!isRpcShape) throwGatewayError(whole);
		} catch (e) {
			if (e instanceof McpGatewayError || e instanceof McpRpcError) throw e;
			// 整体非合法 JSON → 落回 SSE 解析（body 可能是截断 JSON 或真 SSE 流）
		}
	}
	const blocks = body.split(/\r?\n\r?\n/);
	let last: JsonRpcResult | undefined;
	for (const block of blocks) {
		const dataLines = block.split(/\r?\n/).filter((l) => l.startsWith("data:"));
		if (dataLines.length === 0) continue;
		// SSE data: 行内容为去除 "data:" 前缀后单个前导空格（SSE 规范）。
		const payload = dataLines.map((l) => l.slice(5).replace(/^ /, "")).join("");
		if (!payload) continue;
		let msg: any;
		try {
			msg = JSON.parse(payload);
		} catch {
			continue; // 非目标/非 JSON 行跳过
		}
		const hit = matchRpcMessage(msg, reqId);
		if (hit !== undefined) last = hit;
	}
	if (last === undefined) throw new Error(`MCP 响应无匹配 reqId=${reqId} 的 result（可能 session 失效或响应被截断）`);
	return last;
}

async function safeText(res: Response): Promise<string> {
	try {
		const t = await res.text();
		return t.slice(0, 500);
	} catch {
		return "";
	}
}

class McpHttpError extends Error {
	readonly status: number;
	readonly bodySnippet: string;
	constructor(message: string, status: number, bodySnippet: string) {
		super(message);
		this.name = "McpHttpError";
		this.status = status;
		this.bodySnippet = bodySnippet;
	}
}

interface RpcResponse {
	result: JsonRpcResult | undefined;
	/** 响应头（小写键），用于提取 mcp-session-id。 */
	headers: Record<string, string>;
}

/**
 * 发起一次 SSE JSON-RPC 请求（fetch + 超时 + abort 合并）。
 * @param reqId undefined 表示 notification（无 id，不解析 result）。
 */
export async function rpcRequest(
	fetchFn: typeof fetch,
	url: string,
	authHeaders: Record<string, string>,
	body: object,
	reqId: number | undefined,
	parentSignal: AbortSignal | undefined,
	timeoutMs: number,
): Promise<RpcResponse> {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(new Error(`MCP 请求超时（${timeoutMs}ms）`)), timeoutMs);
	const onParentAbort = () => ctrl.abort(parentSignal?.reason);
	if (parentSignal) {
		if (parentSignal.aborted) ctrl.abort(parentSignal.reason);
		else parentSignal.addEventListener("abort", onParentAbort, { once: true });
	}
	try {
		const res = await fetchFn(url, {
			method: "POST",
			headers: { "Content-Type": "application/json", "Accept": "application/json, text/event-stream", ...authHeaders },
			body: JSON.stringify(body),
			signal: ctrl.signal,
		});
		const headers: Record<string, string> = {};
		res.headers.forEach((v, k) => { headers[k.toLowerCase()] = v; });
		if (!res.ok) {
			const detail = await safeText(res);
			throw new McpHttpError(`MCP HTTP ${res.status} ${res.statusText}`, res.status, detail);
		}
		const text = await res.text();
		const result = reqId === undefined ? undefined : parseSseResult(text, reqId);
		return { result, headers };
	} finally {
		clearTimeout(timer);
		if (parentSignal) parentSignal.removeEventListener("abort", onParentAbort);
	}
}

/** 业务层认证/session 错误（智谱把 -401 放在 result.isError:true 的 content 文本里，非 JSON-RPC error）。 */
class McpBusinessAuthError extends Error {
	readonly remoteResult: JsonRpcResult;
	constructor(message: string, remoteResult: JsonRpcResult) {
		super(message);
		this.name = "McpBusinessAuthError";
		this.remoteResult = remoteResult;
	}
}

/** auth/session 错误关键词（v1.5.251 增加中文网关文案，如智谱"身份验证失败。"；避免误判普通业务错误如"无结果"）。 */
const AUTH_SESSION_TEXT = /api key not found|invalid api key|unauthorized|not authenticated|session expired|invalid session|\b401\b|身份验证|鉴权失败|鉴权异常|未授权|密钥无效|令牌无效/i;

/** 严格匹配远端业务文本中的 auth/session 错误。 */
function isAuthSessionBusinessError(text: string): boolean {
	return AUTH_SESSION_TEXT.test(text);
}

/** 判定错误是否为 session/认证类（可重建重试）。 */
export function isSessionError(e: unknown): boolean {
	if (e instanceof McpBusinessAuthError) return true; // M4: 业务层 auth 错误也触发重建
	// v1.5.251: 网关业务错误体按 detail 归类——auth 类（如"身份验证失败。"）触发重建重试，普通业务错误不重试
	if (e instanceof McpGatewayError) return isAuthSessionBusinessError(e.detail);
	if (e instanceof McpHttpError) return e.status === 401 || e.status === 403;
	if (e instanceof McpRpcError) {
		const m = e.rpcMessage.toLowerCase();
		// 智谱无 sid 时返回 "MCP error -401: Api key not found"；session 过期类似。
		return /api key not found|unauthorized|session|invalid session|not authenticated|401/.test(m);
	}
	const msg = e instanceof Error ? e.message.toLowerCase() : "";
	return /session|unauthorized|401|api key not found/.test(msg);
}

/** 业务结果文本拼接（远端 content 数组 → 单文本；供 callTool 透传与 mcp_call 使用）。 */
export function mcpResultText(result: JsonRpcResult): { text: string; isError: boolean } {
	const text = (result.content || [])
		.filter((c) => c?.type === "text" && typeof c.text === "string")
		.map((c) => c.text)
		.join("\n");
	const isError = result.isError === true;
	// M4: 智谱把认证失败放在业务 isError:true 的 content 文本里 → 抛出触发 session 重建重试一次；
	// 普通业务错误（如"无结果"）不匹配，原样透传不重试。
	if (isError && isAuthSessionBusinessError(text)) throw new McpBusinessAuthError(text.slice(0, 200), result);
	return { text, isError };
}

/** 兼容旧导出名；显式 MCP 调用正文不再由插件限幅或折叠。 */
export function truncateMcpText(_server: string, _remoteTool: string, text: string): { text: string; truncated?: boolean; dumpPath?: string } {
	return { text };
}

// ev-20260804-bffbf0：视觉类工具服务端实测 ~36s 完成（双图 ui_diff_check 几乎必超默认档），
// 响应在超时后到达被丢弃——假失败。视觉类独立超时档（默认 90s）。
const VISION_TOOL_TIMEOUT_MS = 90_000;
const VISION_REMOTE_TOOLS = new Set([
	"analyze_image", "ui_to_artifact", "ui_diff_check", "extract_text_from_screenshot",
	"diagnose_error_screenshot", "understand_technical_diagram", "analyze_data_visualization", "analyze_video",
]);

/** 注册时记录的项目 cwd（resolveMcpCallTimeoutMs 定位项目 amagi.json；未注册时回退 process.cwd()）。 */
let registeredCwd: string | null = null;

/**
 * 按工具类别解析单次调用超时（v1.5.246 优先级链）：
 *   explicitTimeoutMs（测试/调用方显式注入）
 *   > amagi.json `mcp.callTimeoutMs` / `mcp.visionCallTimeoutMs`（项目键优先于全局；每次读盘，改动即时生效）
 *   > env AMAGI_MCP_TIMEOUT_MS / AMAGI_MCP_VISION_TIMEOUT_MS（兼容保留）
 *   > 默认：常规 60s / 视觉类 90s。
 */
export function resolveMcpCallTimeoutMs(remoteTool: string, explicitTimeoutMs?: number, cwd?: string): number {
	const envNum = (v: string | undefined): number | undefined => {
		const n = Number(v);
		return Number.isFinite(n) && n > 0 ? n : undefined;
	};
	if (explicitTimeoutMs !== undefined) return explicitTimeoutMs;
	const isVision = VISION_REMOTE_TOOLS.has(remoteTool);
	try {
		const routing = loadMcpRouting(cwd ?? registeredCwd ?? process.cwd());
		if (isVision && routing.visionCallTimeoutMs !== undefined) return routing.visionCallTimeoutMs;
		if (!isVision && routing.callTimeoutMs !== undefined) return routing.callTimeoutMs;
	} catch { /* 配置读取失败回退 env/默认 */ }
	if (isVision) return envNum(process.env.AMAGI_MCP_VISION_TIMEOUT_MS) ?? VISION_TOOL_TIMEOUT_MS;
	return envNum(process.env.AMAGI_MCP_TIMEOUT_MS) ?? DEFAULT_CALL_TIMEOUT_MS;
}

const PROTOCOL_VERSION = "2024-11-05";
const CLIENT_INFO = { name: "amagi-pi", version: "1.0.0" } as const;
const DEFAULT_CALL_TIMEOUT_MS = 60_000; // v1.5.246：30s→60s（主上裁定默认档）
const DEFAULT_DISCOVERY_TIMEOUT_MS = 30_000; // v2.11.1：8s→30s。pi 全局 fetch 走 EnvHttpProxyAgent（env 代理），
// HTTP server discovery 需 initialize→initialized→tools/list 三次串行往返；启动繁忙期经本地代理实测
// 单轮累计 4.3s（冷启动/DNS/TLS 全落在 serverNames 首位），8s 余量不足、抖动即超（ev-实战：
// web-search-prime 首位冷启动反复 discovery 超时告警）。discovery 为后台缓存刷新不阻塞交互，宽预算无副作用。
// npx 首次下载 server 包可能耗时 1-2 分钟（实测 @z_ai/mcp-server 冷装 ~40-90s），默认 120s 免首战超时
const STDIO_START_TIMEOUT_MS = Number(process.env.AMAGI_MCP_STDIO_START_MS) || 120_000;

// ─────────────────────────────────────────────────────────────────────────────
// Transport：HTTP（streamable HTTP；协议件见本文件上方「协议件」段）
// ─────────────────────────────────────────────────────────────────────────────

export interface McpCallResult {
	content?: { type: string; text?: string; [k: string]: unknown }[];
	isError?: boolean;
	[k: string]: unknown;
}

/** 发现面工具条目（tools/list 缓存/展示共用形状；annotations 为 MCP 协议工具注解——
 *  readOnlyHint 是 P3 只读执法的唯一性质证据来源，未知性质不得当只读）。
 *  P2-mcp-connect（§3.1）：补远端 outputSchema 采集槽——若 server 的 tools/list 响应携带则
 *  整条目透传入缓存（input/output 分离采集：inputSchema 是调用参数说明，outputSchema 是
 *  远端输出声明）；旧缓存无该字段合法（wire 槽投影 null、call 分支 schemaSource=none）。 */
export interface McpDiscoveredTool {
	name: string;
	description?: string;
	inputSchema?: object;
	/** 远端输出声明（不可信 schema 数据——只声明发现，不动态替换宿主 mcp_call 定义）。 */
	outputSchema?: object;
	annotations?: { readOnlyHint?: boolean; [k: string]: unknown };
}

interface Transport {
	listTools(signal?: AbortSignal): Promise<McpDiscoveredTool[]>;
	callTool(tool: string, args: Record<string, unknown>, signal?: AbortSignal): Promise<McpCallResult>;
	close(): void;
}

export class HttpMcpServer implements Transport {
	private sid: string | null = null;
	private ready = false;
	private helloPromise: Promise<void> | null = null;
	constructor(private cfg: McpServerConfig, private fetchFn: typeof fetch, private timeoutMs: number, private explicitTimeoutMs?: number) {}

	private async rpc(method: string, params: object | undefined, reqId: number | undefined, signal?: AbortSignal, timeoutMs = this.timeoutMs): Promise<JsonRpcResult | undefined> {
		// AMAGI_MCP_DEBUG=1：HTTP transport 每步 RPC 打点（→/← 耗时）——discovery/调用超时排障用（stderr）。
		const dbg = process.env.AMAGI_MCP_DEBUG === "1";
		const t0 = dbg ? Date.now() : 0;
		if (dbg) console.error(`[mcp-debug] ${this.cfg.name || this.cfg.url} ${method} →`);
		// v1.5.245 修复：请求头附加已建 session 的 mcp-session-id（原实现只发 cfg.headers，
		// 对强制 sid 的 server 一直失效——智谱靠 Authorization 容忍了它）；per-call timeoutMs 生效。
		const headers = { ...(this.cfg.headers || {}), ...(this.sid ? { "mcp-session-id": this.sid } : {}) };
		const res = await rpcRequest(this.fetchFn, this.cfg.url!, headers, { jsonrpc: "2.0", ...(reqId !== undefined ? { id: reqId } : {}), method, ...(params ? { params } : {}) }, reqId, signal, timeoutMs);
		const sid = res.headers["mcp-session-id"];
		if (sid) this.sid = sid;
		if (dbg) console.error(`[mcp-debug] ${this.cfg.name || this.cfg.url} ${method} ← ${Date.now() - t0}ms`);
		return res.result;
	}

	private async ensureHello(signal?: AbortSignal, force = false): Promise<void> {
		if (this.helloPromise && !force) return this.helloPromise;
		this.helloPromise = (async () => {
			this.sid = null;
			await this.rpc("initialize", { protocolVersion: PROTOCOL_VERSION, capabilities: {}, clientInfo: CLIENT_INFO }, 1, signal);
			await this.rpc("notifications/initialized", undefined, undefined, signal);
			this.ready = true; // 与 sid 解耦：无 mcp-session-id 响应头的 server 同样只握手一次
		})();
		try { await this.helloPromise; } catch (e) { this.ready = false; this.helloPromise = null; throw e; }
	}

	private async withSession<T>(fn: () => Promise<T>, signal?: AbortSignal, retry = true): Promise<T> {
		try {
			await this.ensureHello(signal, !this.ready);
			return await fn();
		} catch (e) {
			if (!isSessionError(e) || signal?.aborted) throw e;
			// session/auth 类错误：重建一次
			this.ready = false;
			this.helloPromise = null;
			if (!retry) throw e; // 下次调用重新握手；本次工具请求绝不重放。
			await this.ensureHello(signal, true);
			return await fn();
		}
	}

	async listTools(signal?: AbortSignal) {
		return this.withSession(async () => {
			const tools: McpDiscoveredTool[] = [];
			let cursor: string | undefined;
			for (let page = 0; page < 10; page++) {
				const result = await this.rpc("tools/list", cursor ? { cursor } : {}, 3, signal);
				const list = (result as any)?.tools;
				if (Array.isArray(list)) tools.push(...list.filter((t: any) => t && typeof t.name === "string"));
				cursor = (result as any)?.nextCursor;
				if (!cursor) break;
			}
			return tools;
		}, signal);
	}

	async callTool(tool: string, args: Record<string, unknown>, signal?: AbortSignal): Promise<McpCallResult> {
		// v1.5.245 per-call 超时：视觉类 90s / 常规 30s（env 可调）；explicitTimeoutMs（测试/调用方显式注入）优先。
		const callMs = resolveMcpCallTimeoutMs(tool, this.explicitTimeoutMs);
		try {
			return await this.withSession(async () => {
				const result = (await this.rpc("tools/call", { name: tool, arguments: args }, 3, signal, callMs)) as McpCallResult;
				// auth 业务错标记 session 失效；默认重试策略保持，false 时不重放。
				mcpResultText(result as JsonRpcResult);
				return result;
			}, signal, this.cfg.retryToolCalls !== false);
		} catch (e) {
			// 已收到的业务结果不是纯 transport 异常：保留完整结果，让既有媒体/wire
			// 管线处理其错误状态、图片与 structuredContent，不能用 200 字摘要代替。
			if (e instanceof McpBusinessAuthError) return e.remoteResult as McpCallResult;
			throw e;
		}
	}

	close(): void { this.sid = null; this.ready = false; this.helloPromise = null; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Transport：stdio（NDJSON JSON-RPC 子进程）
// ─────────────────────────────────────────────────────────────────────────────

/** stdio 子进程基础 env（白名单 + 代理 + npm 系 + server.env；凭据只经 server.env 插值进入）。 */
function buildStdioEnv(serverEnv: Record<string, string>): Record<string, string> {
	const env: Record<string, string> = {};
	for (const k of ["PATH", "HOME", "USER", "SHELL", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR", "TERM", "TZ",
		"HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "all_proxy", "no_proxy"]) {
		const v = process.env[k];
		if (v !== undefined) env[k] = v;
	}
	for (const k of Object.keys(process.env)) {
		if (/^(npm_config_|NPM_|NODE)/i.test(k)) env[k] = process.env[k]!;
	}
	Object.assign(env, serverEnv);
	return env;
}

interface PendingReq { resolve: (v: any) => void; reject: (e: Error) => void; timer: NodeJS.Timeout; cleanup: () => void }

/** cmd 引号规则：含空白才包引号，内部双引号双写转义（cmd 风格）。 */
function quoteForCmd(s: string): string {
	return /\s/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/**
 * stdio spawn 参数的平台适配（ev-20260925）：win32 下 shell:false 的裸 spawn 不做 PATHEXT
 * 解析，`npx`/`npm` 等无扩展名命令直接 ENOENT；Node ≥18.20（CVE-2024-27980）又禁止
 * 不经 shell 直接 spawn .cmd/.bat shim。统一经 `cmd.exe /d /s /c` 包装：整条命令行拼成
 * 单个参数传入（Node 对含空格参数自动加引号，配合 /s 取首尾引号间内容），stdin/stdout
 * 透传不受影响。.exe 等原生可执行不受 CVE 限制，原样 spawn。非 win32 原样返回。
 */
export function buildStdioSpawnSpec(command: string, args: readonly string[], platform: NodeJS.Platform = process.platform): { command: string; args: string[] } {
	if (platform !== "win32") return { command, args: [...args] };
	const ext = path.extname(command).toLowerCase();
	if (ext && ext !== ".cmd" && ext !== ".bat") return { command, args: [...args] };
	const line = [command, ...args].map(quoteForCmd).join(" ");
	return { command: "cmd.exe", args: ["/d", "/s", "/c", line] };
}

export class StdioMcpServer implements Transport {
	private child: ChildProcess | null = null;
	private stderrTail = "";
	private pending = new Map<number, PendingReq>();
	private nextId = 1;
	private helloPromise: Promise<void> | null = null;
	private restarted = false;
	/** B3：当前代 child 的 stdio 附件（独立行帧器 + 逐 child 监听器）。退出/主动关闭时整体解绑——
	 *  旧 child 迟到的 data/exit/stderr 不再进入新代状态（半帧缓冲生命周期随 framer dispose 闭合）。 */
	private stdio: {
		child: ChildProcess;
		framer: LfFramer;
		onStdoutData: (d: Buffer) => void;
		onStderrData: (d: Buffer) => void;
		onExit: (code: number | null, signal: string | null) => void;
		onError: (e: Error) => void;
	} | null = null;

	constructor(private cfg: McpServerConfig, private timeoutMs: number, private explicitTimeoutMs?: number) {}

	private onLine(line: string): void {
		if (!line.trim()) return;
		let msg: any;
		try { msg = JSON.parse(line); } catch { return; }
		if (msg && typeof msg.id === "number" && (msg.result !== undefined || msg.error !== undefined)) {
			const p = this.pending.get(msg.id);
			if (!p) return;
			this.pending.delete(msg.id);
			p.cleanup();
			if (msg.error) p.reject(new Error(`MCP JSON-RPC error ${msg.error.code}: ${msg.error.message}`));
			else p.resolve(msg.result);
		}
		// notifications（无 id）忽略
	}

	/** B3：解绑当前代 child 的 stdout/stderr/exit 业务监听并 dispose 行帧器（半帧随之丢弃，不流入
	 *  下一代；迟到 exit 因 exit 监听已解绑成为 no-op，不清算新代 pending）。
	 *  P0-F1（B3 复验 REJECT 唯一 Major）：error 监听解绑后必须补挂有限吸收的兜底接收者直至 exit
	 *  确认后解除——spawn 失败（如 ENOENT）的 'error' 事件由 Node 在后续 tick 异步派发，主动关闭若
	 *  抢在到达前解绑唯一接收者，EventEmitter 无人接收的 'error' 直接抛 Unhandled 'error' event
	 *  （承载进程级崩溃，违反冻结判据「JSON-RPC 请求与失败语义必须保持」）。兜底接收者无状态：
	 *  不触碰 pending/新代状态（在途请求已由 closeChild/teardown 的 failPending 按对应语义拒绝），
	 *  只吸收迟到 error；exit 确认后解除，未达 exit（spawn 失败无 exit）则随 child 引用回收。 */
	private detachStdio(): void {
		const a = this.stdio;
		this.stdio = null;
		if (!a) return;
		a.child.stdout?.removeListener("data", a.onStdoutData);
		a.child.stderr?.removeListener("data", a.onStderrData);
		a.child.removeListener("exit", a.onExit);
		a.child.removeListener("error", a.onError);
		a.framer.dispose();
		const lateErrorSink = (): void => {};
		a.child.once("exit", () => a.child.removeListener("error", lateErrorSink));
		a.child.once("error", lateErrorSink);
	}

	/** 失败全部在途请求（child 退出/主动关闭共用；语义不变：clearTimeout + reject + 清表）。 */
	private failPending(err: Error): void {
		for (const [, p] of this.pending) { p.cleanup(); p.reject(err); }
		this.pending.clear();
	}

	private async ensureStarted(): Promise<void> {
		if (this.helloPromise) return this.helloPromise;
		this.helloPromise = (async () => {
			const spec = buildStdioSpawnSpec(this.cfg.command!, this.cfg.args || []);
			const child = spawn(spec.command, spec.args, {
				env: buildStdioEnv(this.cfg.env || {}), stdio: ["pipe", "pipe", "pipe"], shell: false, // stdin 必须 pipe（NDJSON 请求通道）；误用 ignore 会使 stdin=null（曾致全部 stdio server 不可用）
			});
			// B3（设计 §B3）：每个 child 独立行帧器——① StringDecoder 增量解码（旧每 chunk d.toString()
			// 在多字节 UTF-8 字符跨界处拆出 U+FFFD，中文/增补字符载荷即损坏）；② 半帧生命周期随 child
			// 闭合（旧实例字段 buffer 跨重启存留，旧 child 半帧混入新 child 首行致代际串帧）。
			const framer = createLfFramer((line) => this.onLine(line));
			const onStdoutData = (d: Buffer) => framer.push(d);
			const onStderrData = (d: Buffer) => { this.stderrTail = (this.stderrTail + d.toString()).slice(-4096); };
			const teardown = (err: Error): void => {
				if (this.stdio?.child === child) this.detachStdio();
				if (this.child === child) { this.child = null; this.helloPromise = null; }
				this.failPending(err);
			};
			const onExit = (code: number | null, signal: string | null) => {
				if (this.child !== child) return; // 旧代迟到 exit：该代清理已随重启/关闭完成，不清算新代
				teardown(new Error(`MCP stdio server "${this.cfg.name}" 退出（code=${code} signal=${signal}）${this.stderrTail ? `：${this.stderrTail.slice(-300)}` : ""}`));
			};
			const onError = (e: Error) => {
				if (this.child !== child) return;
				teardown(new Error(`MCP stdio server "${this.cfg.name}" 退出（code=null signal=spawn error: ${e.message}）${this.stderrTail ? `：${this.stderrTail.slice(-300)}` : ""}`));
			};
			this.stdio = { child, framer, onStdoutData, onStderrData, onExit, onError };
			this.child = child;
			child.on("error", onError);
			child.on("exit", onExit);
			child.stdout!.on("data", onStdoutData);
			child.stderr!.on("data", onStderrData);
			// initialize 握手（启动超时较长：npx 首次下载）
			await this.request("initialize", { protocolVersion: PROTOCOL_VERSION, capabilities: {}, clientInfo: CLIENT_INFO }, STDIO_START_TIMEOUT_MS);
			this.notify("notifications/initialized");
		})();
		try { await this.helloPromise; }
		catch (e) { this.helloPromise = null; throw e; }
	}

	private send(msg: object): void {
		if (!this.child?.stdin?.writable) throw new Error(`MCP stdio server "${this.cfg.name}" 未运行`);
		this.child.stdin.write(JSON.stringify(msg) + "\n");
	}

	private request(method: string, params: object | undefined, timeoutMs: number, signal?: AbortSignal): Promise<any> {
		if (signal?.aborted) return Promise.reject(new Error("MCP stdio 请求 aborted（未提交）"));
		const id = this.nextId++;
		return new Promise((resolve, reject) => {
			const cancelRemote = (reason: string): void => {
				if (method === "initialize") return;
				try { this.send({ jsonrpc: "2.0", method: "notifications/cancelled", params: { requestId: id, reason } }); } catch { /* 仅尽力通知，不冒充已停止输入。 */ }
			};
			const cleanup = (): void => {
				clearTimeout(timer);
				signal?.removeEventListener("abort", onAbort);
			};
			const onAbort = (): void => {
				if (!this.pending.delete(id)) return;
				cleanup();
				cancelRemote("caller aborted");
				reject(new Error(`MCP stdio "${this.cfg.name}" ${method} aborted；后端输入停止未确认`));
			};
			const timer = setTimeout(() => {
				if (!this.pending.delete(id)) return;
				cleanup();
				cancelRemote("request timed out");
				reject(new Error(`MCP stdio "${this.cfg.name}" ${method} 超时（${timeoutMs}ms）；后端输入停止未确认${this.stderrTail ? `：${this.stderrTail.slice(-300)}` : ""}`));
			}, timeoutMs);
			this.pending.set(id, { resolve, reject, timer, cleanup });
			signal?.addEventListener("abort", onAbort, { once: true });
			if (signal?.aborted) { onAbort(); return; }
			try { this.send({ jsonrpc: "2.0", id, method, ...(params ? { params } : {}) }); }
			catch (e) { this.pending.delete(id); cleanup(); reject(e); }
		});
	}

	private notify(method: string): void {
		try { this.send({ jsonrpc: "2.0", method }); } catch { /* 握手通知失败不致命 */ }
	}

	private async rpc(method: string, params: object | undefined, timeoutMs: number, signal?: AbortSignal): Promise<any> {
		if (signal?.aborted) throw new Error("MCP stdio 请求 aborted（未提交）");
		const startup = this.ensureStarted();
		// 握手可以由多调用共享；取消当前等待不关闭其他调用的连接。
		const waitStartup = (promise: Promise<void>): Promise<void> => !signal ? promise : new Promise((resolve, reject) => {
			const onAbort = (): void => { signal.removeEventListener("abort", onAbort); reject(new Error("MCP stdio 启动等待 aborted（未提交工具请求）")); };
			signal.addEventListener("abort", onAbort, { once: true });
			promise.then(() => { signal.removeEventListener("abort", onAbort); resolve(); }, (e) => { signal.removeEventListener("abort", onAbort); reject(e); });
			if (signal.aborted) onAbort();
		});
		try {
			await waitStartup(startup);
		} catch (e) {
			if (signal?.aborted) throw e;
			// 崩溃后重启一次（如 npx 缓存损坏/瞬时失败）
			if (this.restarted) throw e;
			this.restarted = true;
			this.closeChild();
			await waitStartup(this.ensureStarted());
		}
		return this.request(method, params, timeoutMs, signal);
	}

	async listTools(signal?: AbortSignal) {
		const result = await this.rpc("tools/list", {}, this.timeoutMs, signal);
		const list = (result as any)?.tools;
		return Array.isArray(list) ? list.filter((t: any) => t && typeof t.name === "string") : [];
	}

	async callTool(tool: string, args: Record<string, unknown>, signal?: AbortSignal): Promise<McpCallResult> {
		if (signal?.aborted) throw new Error("aborted");
		// v1.5.245 per-call 超时：视觉类 90s / 常规 30s（env 可调）；explicitTimeoutMs 优先。
		return (await this.rpc("tools/call", { name: tool, arguments: args }, resolveMcpCallTimeoutMs(tool, this.explicitTimeoutMs), signal)) as McpCallResult;
	}

	private closeChild(): void {
		const child = this.child;
		if (!child) { this.helloPromise = null; return; }
		// B3：主动关闭同步解绑监听 + dispose 行帧器 + 失败在途请求。旧实现不清理监听，依赖 kill 后
		// exit 事件异步 reject——SIGTERM 到 exit 之间新 child 可能已建立，旧代 exit 会误杀新代 pending
		// （跨代竞态）；同步清算后旧 child 迟到 exit 因监听器已解绑成为 no-op，失败语义不变（不悬挂）。
		this.detachStdio();
		this.child = null;
		this.helloPromise = null;
		this.failPending(new Error(`MCP stdio server "${this.cfg.name}" 已关闭（重启或 session 清理）`));
		// P0 F1-R：spawn 失败（如 ENOENT）时 child.pid === undefined——ChildProcess.kill 仍经 _handle
		// 以 pid=0 调 uv_kill，POSIX kill(0, sig) 向自身进程组全体发信号，承载进程被 SIGTERM 终止
		// （平台行为，裸 Node 对照组证实；jiti 链下 pi 包 signal-exit 拦截后延迟重发，仍致死）。
		// 无 pid 即无进程可杀（child 对象仅承载迟到 error 事件，由 detachStdio 兜底接收者吸收）——
		// 跳过 kill 与后续 SIGKILL 安排；其余关闭语义（pending 清算/监听解绑/请求按关闭拒绝）不变。
		if (child.pid === undefined) return;
		try { child.kill("SIGTERM"); } catch {}
		setTimeout(() => { try { child.kill("SIGKILL"); } catch {} }, 1000).unref();
	}

	close(): void { this.closeChild(); }
}

// ─────────────────────────────────────────────────────────────────────────────
// 工具发现缓存
// ─────────────────────────────────────────────────────────────────────────────

interface ToolCacheEntry { tools: McpDiscoveredTool[]; at: number }
type ToolCache = Record<string, ToolCacheEntry>;

function toolCachePath(): string { return amagiDataFile("mcp-tool-cache.json"); }

export function loadToolCache(): ToolCache {
	try { return JSON.parse(fs.readFileSync(toolCachePath(), "utf8")) as ToolCache; } catch { return {}; }
}

function saveToolCache(cache: ToolCache): void {
	try {
		const file = toolCachePath();
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.writeFileSync(file, JSON.stringify(cache, null, 2), "utf8");
	} catch { /* 缓存写失败不致命 */ }
}

// ─────────────────────────────────────────────────────────────────────────────
// 工具注册
// ─────────────────────────────────────────────────────────────────────────────

/** 本地已占用工具名（v1.5.250：mcp_list_tools 重名标注用；直连注册已删，不再做名称避让）。 */
const KNOWN_TAKEN_NAMES = new Set([
	"read", "bash", "edit", "write", "grep", "find", "ls",
	"task", "query_task", "rpc_task", "amagi_resource", "amagi_evolution", "amagi_handbook",
	"web_search", "web_reader", "zread_search_doc", "zread_read_file", "zread_get_repo_structure",
	"mcp_call", "mcp_list_tools",
]);

export function sanitizeToolName(name: string): string {
	const s = name.replace(/[^a-zA-Z0-9_-]/g, "_").replace(/^_+|_+$/g, "") || "tool";
	return s.slice(0, 64);
}

/** MCP content 数组 → 文本（非 text 块转元信息摘要；tool result 只承载文本）。 */
function contentToText(content: McpCallResult["content"]): string {
	if (!Array.isArray(content) || content.length === 0) return "(无内容)";
	const parts: string[] = [];
	for (const c of content) {
		if (!c || typeof c !== "object") continue;
		if (c.type === "text" && typeof c.text === "string") parts.push(c.text);
		else if (c.type === "image") parts.push("[image 内容块]"); // 图片只走 image block，不将 base64 写入正文/截断文件。
		else parts.push(`[${c.type || "unknown"} 内容块：${JSON.stringify(c)}]`);
	}
	return parts.join("\n") || "(无文本内容)";
}

/** 只补 MCP 图片接线；能力判断与真实解码复用现有机制，不创建媒体服务。 */
async function forwardMcpImages(content: McpCallResult["content"], model: unknown, signal?: AbortSignal) {
	const images: { type: "image"; data: string; mimeType: string }[] = [];
	const notes: string[] = [];
	const capability = imageReadCapability(model);
	const deadlineAtMonotonic = performance.now() + IMAGE_DECODE_PROBE_BUDGET_MS;
	for (const block of Array.isArray(content) ? content : []) {
		if (block?.type !== "image") continue;
		if (capability !== "image-capable") {
			notes.push(`[image-unavailable: ${capability}] 未交付像素；请沿现有识图流程处理。`);
			continue;
		}
		if (typeof block.data !== "string" || typeof block.mimeType !== "string"
			|| block.data.length > 4 * Math.ceil(IMAGE_DECODE_LIMIT_BYTES / 3)
			|| block.data.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(block.data)) {
			notes.push("[image-unavailable: invalid-image-block] 未交付像素；远端图片字段或编码无效。");
			continue;
		}
		const bytes = Buffer.from(block.data, "base64");
		if (bytes.toString("base64") !== block.data) {
			notes.push("[image-unavailable: invalid-base64] 未交付像素。");
			continue;
		}
		const observation = await defaultHostImageDecoder.probe(bytes, block.mimeType, { deadlineAtMonotonic, signal });
		if (observation.status !== "passed" || signal?.aborted) {
			notes.push(`[image-unavailable: ${signal?.aborted ? "cancelled" : observation.status === "not-assessed" ? observation.reason : "unknown"}] 未交付像素；保留远端已返回的操作事实。`);
			continue;
		}
		// 解码成功不代表输出消费者可用：只交付公共 codemode 与宿主均接受的交集。
		if (!["image/png", "image/jpeg", "image/gif"].includes(block.mimeType)) {
			notes.push("[image-unavailable: unsupported-output-format] 图片已解码但当前输出不支持该格式；保留远端操作事实，不重放。");
			continue;
		}
		images.push({ type: "image", data: block.data, mimeType: block.mimeType });
	}
	return { images, notes };
}

export interface RegisterMcpOpts {
	/** native 为宿主 API 在场时默认；custom 为显式兼容入口。 */
	backend?: "native" | "custom";
	cwd: string;
	deps?: McpToolsDeps;
	/** 发现刷新超时（默认 30000；P3-D 冻结常量，原 AMAGI_MCP_DISCOVERY_MS env 读取已移除；
	 * v2.11.1 8s→30s：pi 全局 fetch 走 EnvHttpProxyAgent 代理，HTTP server 三步串行握手启动期实测 4.3s）。 */
	discoveryTimeoutMs?: number;
	/** v1.5.218 子进程修复：跳过注册期后台 discovery 与 mcp_list_tools 实时发现
	 * （子进程仅展示缓存；缓存由主进程刷新）。子进程场景 stdio server 的 discovery 会 spawn npx
	 * 常驻子进程：①npx 冷启动拖慢子任务；②stdio 管道挂住 print 模式事件循环——turn 完成后进程
	 * 永不退出（实战 baize settle 后挂 16min）。v1.5.250 单通道化后远端工具不再注册，注册期
	 * discovery 只剩刷缓存价值，子进程连这个也可省。 */
	lazyDiscovery?: boolean;
	/** 单次调用超时（默认 60000，视觉类 90000；amagi.json mcp 段可配，见 loadMcpRouting）。 */
	callTimeoutMs?: number;
	/** 仅加载这些 server（角色路由过滤；缺省加载全部）。 */
	onlyServers?: string[];
	/** v2 P3（方案 §5.2 MCP 行）：按具体 server/tool 的调用权限执法面。注入后：
	 *  server 路由被权限引用收窄、mcp_list_tools 只展示授权工具（发现面不泄漏未授权能力）、
	 *  mcp_call 每次调用前重验（防 TOCTOU；未声明工具拒绝，拒绝零副作用——不碰 transport）。
	 *  P4 接线点：子进程从 spec.permission.mcp 经 normalizeMcpPermission 构造；主进程从用户/角色名单。 */
	permission?: McpPermission;
	/** B6a（设计 §7.2-3）：混合 owner 计划（会话冻结；mode=mixed 时生效）——owner=host 的 server
	 *  从自研连接列表剔除；mcp_call 收到 host owner 返回原生工具指引。缺省/非 mixed → 零行为变化。 */
	ownershipPlan?: McpOwnershipPlan;
	/** ev-20261019-a50ce4：路由身份（Leader/子 Agent 角色）——仅用于路由拒绝的可行动说明，不参与判定。 */
	route?: McpRouteIdentity;
}

export interface RegisterMcpHandle {
	servers: string[];
	close(): void;
}

/**
 * 优先委托原生 MCP 注册与执行，仅保留 mcp_call/mcp_list_tools 兼容入口。
 * 旧宿主、明确禁用原生或 mixed 分工才使用下方自研发现/transport，退出关闭其拥有的子进程。
 */
export function registerConfiguredMcpServers(pi: ExtensionAPI, opts: RegisterMcpOpts): RegisterMcpHandle {
	const nativeApi = nativeMcpRegistrationAvailable(pi);
	// 复用宿主连接/认证/发现，不另开自研后台发现；显式 mixed 计划保留逐 server 试点。
	const builtinDisabled = builtinMcpExplicitlyDisabled();
	if (nativeApi && !opts.ownershipPlan && opts.backend === "custom" && !builtinDisabled) throw new Error("自研 MCP 后端须显式禁用原生 MCP 或提供逐 server 所有权计划，拒绝重复连接");
	if (nativeApi && !opts.ownershipPlan && opts.backend !== "custom" && !builtinDisabled) {
		return registerNativeMcpTools(pi, opts);
	}
	const loaded = loadMcpServerConfigs(opts.cwd);
	const warnings = loaded.warnings;
	let servers = loaded.servers;
	// ev-20260903-mcp-noise：告警允许集（实际加载的 server）——仅对命中 server 输出配置告警。
	const allow = opts.onlyServers ? new Set(opts.onlyServers) : null;
	if (opts.onlyServers) {
		servers = Object.fromEntries(Object.entries(servers).filter(([n]) => (allow as Set<string>).has(n)));
	}
	// v2 P3（§5.2 MCP 行）：server 路由校验——权限面引用的具体 server 收窄路由（通配引用不收窄）；
	// 路由≠副作用授权：加载不等于可调用，工具级授权在发现面与 call 重验（见下）。
	const permission = opts.permission;
	const permissionServers = concreteServersReferenced(permission);
	if (permissionServers) {
		const allowPerm = new Set(permissionServers);
		servers = Object.fromEntries(Object.entries(servers).filter(([n]) => allowPerm.has(n)));
	}
	// B6a（设计 §7.2-3 配置所有权）：owner=host 的 server 不进自研连接列表（宿主原生通道专属；
	// 不连接、不发现、不列举）。缺省无计划/非 mixed → 过滤空操作，自研单通道行为不变。
	const ownershipPlan = opts.ownershipPlan;
	if (ownershipPlan?.mode === "mixed") {
		servers = Object.fromEntries(Object.entries(servers).filter(([n]) => ownerOfServerInPlan(ownershipPlan, n) !== "host"));
	}
	for (const w of warnings) {
		// ev-20260903-mcp-noise（实战：luoshen 子任务 abort 失败回流里混入 tavily/firecrawl 的
		// 「引用的变量未设置，已省略」告警，被误认为疑似失败原因）：env/header 省略类告警只对本进程
		// 实际加载的 server 有意义——子进程凭据按角色路由最小透传（buildMinimalEnv 只传命中 server 的
		// envRefs），未路由 server 的变量在子进程未设置是设计内，server 本身也不会被加载使用，
		// 省略零功能影响。对未加载 server 输出告警只会成为失败回流里的无关噪音误导排障。
		// onlyServers 缺省（Leader 主进程全量加载）不过滤；无 server 上下文的告警（JSON 解析失败）不过滤。
		if (allow && w.server && !allow.has(w.server)) continue;
		console.warn(`[amagi-mcp] ${w.file}: ${w.message}`);
	}
	// P3-D 冻结：discovery 超时原为 AMAGI_MCP_DISCOVERY_MS 调参开关，冻结为常量；
	// v1.5.246：调用超时改为可配置（优先级链同 resolveMcpCallTimeoutMs）——amagi.json
	// mcp.callTimeoutMs（项目键优先）> 常量默认 60s；opts.callTimeoutMs 为测试/调用方显式注入。
	registeredCwd = opts.cwd;
	let routingCallTimeoutMs: number | undefined;
	try { routingCallTimeoutMs = loadMcpRouting(opts.cwd).callTimeoutMs; } catch { /* 配置读取失败回退默认 */ }
	const callTimeoutMs = opts.callTimeoutMs ?? routingCallTimeoutMs ?? DEFAULT_CALL_TIMEOUT_MS;
	const discoveryTimeoutMs = opts.discoveryTimeoutMs ?? DEFAULT_DISCOVERY_TIMEOUT_MS;
	const fetchFn = opts.deps?.fetch ?? globalThis.fetch;
	const transports = new Map<string, Transport>();
	const taken = (n: string) => KNOWN_TAKEN_NAMES.has(n); // v1.5.250：仅用于 mcp_list_tools 重名标注（不再有名称避让注册）

	const getTransport = (name: string): Transport => {
		let t = transports.get(name);
		if (!t) {
			const cfg = servers[name];
			if (!cfg && opts.route && Object.keys(loaded.servers).some((n) => n === name) && allow && !allow.has(name)) {
				throw new Error(`权限拒绝：server 未在当前路由中 (${name})——${describeMcpRouteDenial(opts.cwd, name, opts.route)}`);
			}
			if (!cfg) throw new Error(`未配置的 MCP server "${name}"（可用: ${Object.keys(servers).join(", ") || "无"}；配置见 ~/.pi/agent/mcp.json、~/.agents/.mcp.json 或项目 .mcp.json）`);
			if (cfg.nativeConfig?.auth || cfg.nativeConfig?.oauth) throw new Error(`MCP server "${name}" 配置需要 pi 原生认证；兼容后端不实现 auth/OAuth，请启用原生 MCP`);
			if (cfg.nativeManaged && [...Object.values(cfg.headers ?? {}), ...Object.values(cfg.env ?? {})].some((value) => value.startsWith("!") || value.includes("$"))) {
				throw new Error(`MCP server "${name}" 使用原生配置值解析；兼容后端不执行原生命令/模板，请启用原生 MCP 或迁移到兼容配置来源`);
			}
			t = cfg.type === "http"
				? new HttpMcpServer(cfg, fetchFn, callTimeoutMs, opts.callTimeoutMs)
				: new StdioMcpServer(cfg, callTimeoutMs, opts.callTimeoutMs);
			transports.set(name, t);
		}
		return t;
	};

	// ── 元工具：mcp_call（免发现通用调用，MCP 唯一通道）+ mcp_list_tools ──
	// v1.5.250：远端工具不再直连注册为一等工具（makeServerTool 已删）——远端工具以一等身份
	// 出现在工具清单会破坏上层引导的优先级链（识图：read→skill→MCP；调研：官方原文→MCP 搜索），
	// 且名称冲突消解（server__tool）成为模型可见的一等事实。全部调用经 mcp_call。
	// v2 P3：工具性质证据来自发现面缓存（annotations.readOnlyHint）——只读执法下通配条目仅凭该证据放行。
	const toolNatureOf = (server: string, tool: string): "read-only" | "unknown" => {
		try {
			const entry = loadToolCache()[server]?.tools.find((t) => t && t.name === tool);
			return entry?.annotations?.readOnlyHint === true ? "read-only" : "unknown";
		} catch { return "unknown"; }
	};
	// P2（§3.2 call 分支 schemaSource）：发现缓存中该工具是否携带远端输出声明（outputSchema 对象）。
	// 只声明发现事实，不表示本地已验证符合声明；旧缓存缺字段 → none（不臆造）。只读与这里互不干涉。
	const hasRemoteOutputSchema = (server: string, tool: string): boolean => {
		try {
			const entry = loadToolCache()[server]?.tools.find((t) => t && t.name === tool);
			return !!entry && typeof entry.outputSchema === "object" && entry.outputSchema !== null;
		} catch { return false; /* lint-exempt:发现缓存读取失败按无远端输出声明处理（同 toolNatureOf 缺省口径） */ }
	};
	const permNote = permission ? `（当前任务权限过滤已启用：仅授权工具可调用；server 路由不等于工具授权）` : "";
	const McpCallParams = Type.Object({
		server: Type.String({ description: `MCP server 名（配置于 mcp.json/.mcp.json；当前: ${Object.keys(servers).join(", ") || "未配置"}）` }),
		tool: Type.String({ description: "远端工具名（用 mcp_list_tools 查看）" }),
		arguments: Type.Optional(Type.Record(Type.String(), Type.Any(), { description: "工具参数对象（按远端 inputSchema）" })),
	});
	pi.registerTool({
		name: "mcp_call",
		label: "MCP Call",
		description: `调用已配置 MCP server 的工具（MCP 唯一通道）。server 清单与工具发现用 mcp_list_tools；业务字段必须全部放进 arguments，不要放参数顶层。${permNote}`,
		parameters: McpCallParams,
		// P2（§3.3）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema）——两封闭分支 Union。
		// 原生注册面即挂（捕获覆盖失败静默保持原生时 schema 不丢）；mcp-override 同名覆盖版携同款
		// （P1 schema 唯一规格）。文字结果保持原口径；图片路径补原生 content 与 call v2 images。
		outputSchema: McpCallOutputSchema,
		async execute(_id: string, p: Static<typeof McpCallParams>, signal: AbortSignal | undefined, _onUpdate, ctx) {
			try {
				// B6a（设计 §7.2-3）：host owner 分流——自研 mcp_call 不向宿主拥有的 server 转发（避免双通道
				// 嵌套重试），返回「请使用原生工具」指引。预 transport 零副作用；wire 载体复用 permission
				// code（通道路由拒绝，effects=none），details 加 hostOwnerRedirect 标记观测面。
				if (ownerOfServerInPlan(ownershipPlan, p.server) === "host") {
					const text = hostOwnerGuidanceText(p.server, p.tool);
					return { content: [{ type: "text" as const, text }], isError: true as const, details: { mcpServer: p.server, remoteTool: p.tool, isError: true, hostOwnerRedirect: true as boolean | undefined, permissionDenied: false, truncated: false, dumpPath: undefined }, structuredContent: asWireContent(toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code: "permission", message: text, repairExamples: [] } })) };
				}
				// v2 P3（§5.2）：call 前重验（防 TOCTOU）——不信任发现面过滤，逐次调用重新校验；
				// 拒绝零副作用：检查先于 getTransport（不握手、不 spawn stdio 子进程、不发 tools/call）。
				const decision = checkMcpCallPermission(permission, p.server, p.tool, toolNatureOf);
				if (!decision.allowed) {
					// P2：权限拒绝双载体——正文照旧 + Failure wire（code=permission，预 transport 零副作用 → effects=none 缺省）。
					const text = `[amagi-mcp] 权限拒绝：${decision.reason}`;
					return { content: [{ type: "text" as const, text }], isError: true as const, details: { mcpServer: p.server, remoteTool: p.tool, isError: true, permissionDenied: true as boolean, hostOwnerRedirect: undefined as boolean | undefined, truncated: false, dumpPath: undefined }, structuredContent: asWireContent(toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code: "permission", message: text, repairExamples: [{ server: p.server, tool: p.tool, arguments: {} }] } })) };
				}
				const args = (p.arguments && typeof p.arguments === "object" ? p.arguments : {}) as Record<string, unknown>;
				const result = await getTransport(p.server).callTool(p.tool, args, signal);
				const media = await forwardMcpImages(result?.content, ctx?.model, signal);
				const text = [contentToText(result?.content), ...media.notes].join("\n");
				const { text: capped, truncated, dumpPath } = truncateMcpText(p.server, p.tool, text);
				// P2：同次结果双载体（single-read）——同一远端返回对象喂正文渲染（content）与 wire 映射：
				// text=同次截断后文本、远端 structuredContent 子层、发现缓存 outputSchema 声明事实。
				const payloadFields = {
					text: capped,
					images: media.images,
					textTruncated: truncated === true,
					textDumpPath: dumpPath ?? null,
					structuredContent: (result as { structuredContent?: unknown } | undefined)?.structuredContent,
					remoteOutputSchema: hasRemoteOutputSchema(p.server, p.tool),
				};
				// 远端业务错（result.isError，如配额/无结果）是远端已应答的错误 → Failure 分支 code=remote，
				// remoteResult 捕获同次远端载荷（P1 McpCallErrorWire.remoteResult 语义）；正文/正常返回口径不变。
				const wire = result?.isError === true
					? toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code: "remote", message: capped, repairExamples: [{ server: p.server, tool: p.tool, arguments: {} }] }, remoteResult: payloadFields })
					: toMcpCallResultWire({ server: p.server, tool: p.tool, ...payloadFields });
				return {
					content: [{ type: "text" as const, text: capped }, ...media.images],
					isError: result?.isError === true ? true : undefined,
					details: { mcpServer: p.server, remoteTool: p.tool, isError: result?.isError === true, permissionDenied: false, hostOwnerRedirect: undefined as boolean | undefined, truncated, dumpPath },
					structuredContent: asWireContent(wire),
				};
			} catch (e) {
				const msg = e instanceof Error ? e.message : String(e);
				// P2：运行时错误分类进 wire——未配置 server 是预 transport 调用方错（零副作用 → shape），
				// 其余按 P1 classifyMcpWireError（McpRpcError/McpGatewayError/McpBusinessAuthError→remote；
				// 超时/abort/HTTP 状态/stdio 退出/会话→transport；兜底 internal）。message 用同次正文文本（双载体同源）。
				const text = `[amagi-mcp] ${p.server}/${p.tool} 调用失败: ${msg}`;
				const code = /^未配置的 MCP server /.test(msg) ? "shape" : classifyMcpWireError(e);
				return { content: [{ type: "text" as const, text }], isError: true as const, details: { mcpServer: p.server, remoteTool: p.tool, isError: true, permissionDenied: false, hostOwnerRedirect: undefined as boolean | undefined, truncated: false, dumpPath: undefined }, structuredContent: asWireContent(toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code, message: text, repairExamples: [{ server: "<已配置 server 名>", tool: "<远端工具名>", arguments: {} }] } })) };
			}
		},
	});

	const McpListParams = Type.Object({ server: Type.Optional(Type.String({ description: "只看指定 server；缺省列全部" })) });
	// ev-20260920：mcp_list_tools 注册接伪影接线（server 位自动补 null 后端串化为 "null" → 剥离后列全部）；
	// mcp_call 不入此通道——arguments 是任意业务载荷，"null" 可以是合法字段值，不能批量视为缺席。
	pi.registerTool(withArgumentArtifactNormalization({
		name: "mcp_list_tools",
		label: "MCP List Tools",
		description: "实时发现并列出已配置 MCP server 的工具（失败时回退缓存；名称/描述/参数 schema 摘要）。",
		parameters: McpListParams,
		// P2（§3.2 list 分支）：定义挂 McpListOutputSchema + 成功/错误双载体——逐 server 发现数据（状态/
		// observedAt/权限过滤后可见集/失败原因）与正文行同一次遍历采集（single-read）；tools 恒用权限
		// 过滤后的可见集（不泄漏未授权能力）。正文 content/details 契约字节不变（展开+加键）。
		outputSchema: McpListOutputSchema,
		async execute(_id: string, p: Static<typeof McpListParams>, signal: AbortSignal | undefined) {
			try {
				const cache = loadToolCache();
				const lines: string[] = [];
				const wireServers: McpListServerSource[] = [];
				const names = p.server ? [p.server] : Object.keys(servers);
				if (names.length === 0) lines.push("（未配置任何 MCP server；支持 ~/.pi/agent/mcp.json、~/.pi/agent/settings.json mcpServers 键、~/.agents/.mcp.json、项目 .mcp.json、项目 .agents/.mcp.json、项目 .pi/settings.json mcpServers 键）");
				for (const n of names) {
					const cfg = servers[n];
					if (!cfg) {
						// B6a：显式点名 host-owner server（已被 §7.2-3 过滤出连接列表）→ 明确 owner=host 指引，
						// 不误报「未配置」（混合模式下该 server 存在，只是不在自研通道）。
						if (ownerOfServerInPlan(ownershipPlan, n) === "host") {
							const why = `宿主原生通道（owner=host）——自研通道不连接不列举；工具用原生 mcp__${canonicalMcpServerName(n)}__<tool>（/mcp 查看连接与登录）`;
							lines.push(`## ${n}: ${why}`);
							wireServers.push({ name: n, status: "error", observedAt: null, tools: [], error: why });
							continue;
						}
						const why = permissionServers && !permissionServers.includes(n) ? "未加载（任务权限未引用该 server）" : "未配置";
						lines.push(`## ${n}: ${why}`);
						wireServers.push({ name: n, status: "error", observedAt: cache[n]?.at ?? null, tools: [], error: why });
						continue;
					}
					lines.push(`## ${n}（${cfg.type}，来源 ${cfg.source}）${cfg.description ? ` — ${cfg.description}` : ""}`);
					let discovered = cache[n]?.tools || [];
					// v1.5.219 修复：lazyDiscovery（子进程）跳过实时 discovery——此处 getTransport().listTools()
					// 对 stdio server 会 spawn npx 常驻子进程并挂住 print 模式事件循环（实战：LSP 会话 8/8 settle 收口，
					// 全部经 mcp_list_tools 触发）。子进程只展示缓存；需要实时发现时在主进程（TUI）调用。
					const skipLive = !!opts.lazyDiscovery;
					if (skipLive && discovered.length > 0) lines.push(`  （缓存 ${discovered.length} 工具；实时发现已在子进程禁用）`);
					// P2 wire 状态采集：live=本次实时发现成功；cached=回退缓存展示；error=发现失败且无缓存。
					// lazyDiscovery 跳过是信息性说明（非发现失败）：有缓存时 error=null。
					let liveOk = false;
					let skipInfo = false;
					let failReason: string | null = null;
					try {
						if (skipLive) throw new Error("lazyDiscovery: skipped");
						const ctrl = new AbortController();
						const relayAbort = () => ctrl.abort(signal?.reason);
						if (signal?.aborted) relayAbort(); else signal?.addEventListener("abort", relayAbort, { once: true });
						const timer = setTimeout(() => ctrl.abort(new Error("discovery 超时")), discoveryTimeoutMs);
						try { discovered = await getTransport(n).listTools(ctrl.signal); }
						finally { clearTimeout(timer); signal?.removeEventListener("abort", relayAbort); }
						cache[n] = { tools: discovered, at: Date.now() };
						saveToolCache(cache);
						liveOk = true;
					} catch (e) {
						const reason = e instanceof Error && e.message === "lazyDiscovery: skipped"
							? "子进程禁用实时发现"
							: `实时发现失败: ${e instanceof Error ? e.message : String(e)}`;
						if (reason === "子进程禁用实时发现") skipInfo = true; else failReason = reason;
						lines.push(`  （${reason}${discovered.length > 0 ? "；以下为缓存" : ""}）`);
					}
					if (discovered.length === 0) lines.push("  （未发现工具）");
					// v2 P3（§5.2「未声明工具拒绝，发现面不泄漏未授权能力」）：展示前按权限面筛选——
					// 未授权工具不进发现面（名字/schema 均不泄漏）；只读执法下通配条目仅展示只读证明工具。
					const filtered = filterDiscoveredToolsForPermission(permission, n, discovered);
					if (filtered.hidden > 0) lines.push(`  （任务权限过滤：${filtered.visible.length}/${discovered.length} 工具授权可见）`);
					// v1.5.250：直接展示远端名——它就是 mcp_call 的 tool 合法值；重名时标注防混淆，
					// 不再展示幻影本地名（直连注册已删，server__tool 前缀名不再对应任何可调用工具）。
					for (const t of filtered.visible) {
						const clash = taken(t.name) ? "（与本地工具重名；mcp_call 的 tool 值仍用此远端名）" : "";
						const req = Array.isArray((t.inputSchema as any)?.required) ? (t.inputSchema as any).required.join(",") : "";
						lines.push(`  - ${t.name}${clash}${t.description ? ` — ${String(t.description).slice(0, 120)}` : ""}${req ? ` [必填: ${req}]` : ""}`);
					}
					// P2 wire 条目（同遍历采集）：observedAt 取 try 后缓存值（live 成功=刚写入时刻；失败=旧缓存时刻，不编造）。
					const status: McpListServerSource["status"] = liveOk ? "live" : discovered.length > 0 ? "cached" : "error";
					const wireError = liveOk || (skipInfo && discovered.length > 0) ? null : skipInfo ? "子进程禁用实时发现" : failReason;
					wireServers.push({ name: n, status, observedAt: cache[n]?.at ?? null, tools: filtered.visible, error: wireError });
				}
				return { content: [{ type: "text" as const, text: lines.join("\n") }], details: undefined, structuredContent: asWireContent(toMcpListResultWire({ servers: wireServers })) };
			} catch (e) {
				// P2 异常兑底（P4 模式）：正文复刻宿主对抛错的归一形状（content=message、details={}、isError），
				// 只加 structuredContent（Failure code=internal）——旧消费者面零变化。
				const message = e instanceof Error ? e.message : String(e);
				return {
					content: [{ type: "text" as const, text: message }],
					details: {},
					isError: true,
					structuredContent: asWireContent(toMcpListErrorWire({ error: { code: "internal", message: `mcp_list_tools 执行异常: ${message}` } })),
				};
			}
		},
	}));

	// ── 后台工具发现（v1.5.250：仅刷新缓存供 mcp_list_tools 展示，不做工具注册）──
	const serverNames = Object.keys(servers);
	if (serverNames.length > 0 && !opts.lazyDiscovery) {
		void (async () => {
			const cache = loadToolCache();
			let changed = false;
			for (const name of serverNames) {
				try {
					const ctrl = new AbortController();
					const timer = setTimeout(() => ctrl.abort(new Error("discovery 超时")), discoveryTimeoutMs);
					// P2：发现缓存补远端 outputSchema 采集槽（input/output 分离采集）——listTools 透传远端
					// tools/list 条目全量字段（含 outputSchema，若 server 携带）；旧缓存无该字段合法。
					let tools: McpDiscoveredTool[];
					try { tools = await getTransport(name).listTools(ctrl.signal); }
					finally { clearTimeout(timer); }
					if (JSON.stringify((cache[name]?.tools || []).map((t) => t.name).sort()) !== JSON.stringify(tools.map((t) => t.name).sort())) {
						cache[name] = { tools, at: Date.now() };
						changed = true;
					}
				} catch (e) {
					console.warn(`[amagi-mcp] ${name}: 工具发现失败（不影响 mcp_call 兜底）: ${e instanceof Error ? e.message : e}`);
				}
			}
			if (changed) saveToolCache(cache);
		})();
	}

	const close = () => { for (const t of transports.values()) t.close(); };
	try { pi.on("session_shutdown", () => close()); } catch { /* 非 TUI 环境防御 */ }
	return { servers: serverNames, close };
}

// ─────────────────────────────────────────────────────────────────────────────
// v2 P3（方案 §8.3-P3）：缺必要服务派发前给具体缺项（不静默空名单）。
// 派发预检面：server 级查配置、tool 级查发现缓存（缓存缺位不臆断缺项——只报可证实的事实）；
// P4 接线点：dispatch-preflight/task-run 在派发前用冻结 grant.mcp 名单调用，向用户回具体缺项。
// ─────────────────────────────────────────────────────────────────────────────

export interface McpRequirementGap {
	server: string;
	tool: string;
	/** 具体缺项说明（含任务要求的目标与实际不可用原因，不静默空名单）。 */
	reason: string;
}

/** 检查任务声明的 MCP server/tool 是否可兑现：server 未配置/通道禁用为硬缺项；
 *  server 已配置但发现缓存无该工具为可证实缺项（无缓存不臆断——发现后可证实）。 */
export function findMcpRequirementGaps(cwd: string, required: ReadonlyArray<{ server: string; tool: string }>): McpRequirementGap[] {
	const gaps: McpRequirementGap[] = [];
	if (!Array.isArray(required) || required.length === 0) return gaps;
	const { servers } = loadMcpServerConfigs(cwd);
	const cache = loadToolCache();
	const names = Object.keys(servers);
	const disabled = process.env.AMAGI_MCP_DISABLE === "1";
	for (const req of required) {
		if (!req || typeof req.server !== "string" || typeof req.tool !== "string") continue;
		const server = req.server === MCP_UNIFIED_CHANNEL_SERVER ? "*" : req.server;
		if (server !== "*" && !servers[server]) {
			gaps.push({
				server: req.server,
				tool: req.tool,
				reason: disabled
					? `任务要求 mcp:${req.server}/${req.tool}，但 MCP 通道已禁用（AMAGI_MCP_DISABLE=1）`
					: `任务要求 mcp:${req.server}/${req.tool}，但配置无 server "${req.server}"（已配置: ${names.join(", ") || "无"}）`,
			});
			continue;
		}
		if (req.tool === "*") continue; // 通配不检查 tool 级
		const scopes = server === "*" ? names : [server];
		const cachedScopes = scopes.filter((s) => Array.isArray(cache[s]?.tools) && (cache[s]?.tools?.length ?? 0) > 0);
		if (cachedScopes.length === 0) continue; // 无发现缓存：不臆断缺项（发现后可证实）
		const found = cachedScopes.some((s) => cache[s]!.tools.some((t) => t && t.name === req.tool));
		if (!found) {
			gaps.push({
				server: req.server,
				tool: req.tool,
				reason: `任务要求 mcp:${server === "*" ? "*" : server}/${req.tool}，但已发现的 server 工具清单均无该工具（已发现: ${cachedScopes.map((s) => `${s}(${cache[s]!.tools.length})`).join(", ")}）`,
			});
		}
	}
	return gaps;
}
