/**
 * verification-temp-gc.ts — 验证对象临时目录生命周期回收（ev-20261105-0a2e43）。
 *
 * 根因：验证对象（amagi-vo-*）捕获根在检查结束后「保留供复核」（§7.1.5），但「复核」只需要
 * manifest.json / dependency-manifest.json / checks/*.json（小体积事实与日志）；源码镜像、
 * copy-local 依赖副本（node_modules 可达数百 MB）、runner 缓存（-cache-*）、Go 私有模块缓存
 * （amagi-gomod-*）在检查结束后再无消费者，却没有任何回收环节，TMPDIR 单调增长。
 *
 * 两层回收（均不要求模型/用户手工清理）：
 *  ① 检查结束即时回收（reclaimCheckArtifacts，runStructuredCheck 出口调用）：删内容镜像与依赖副本，
 *     保留 manifest/dependency-manifest/checks 日志（回执 check.log.path 仍可回源）；
 *  ② 启动期清扫（sweepVerificationTemp）：历史残留与异常中断遗留——超过内容保留期（6h）的目录回收
 *     内容，超过整体保留期（7d）的整目录删除。只动本进程用户拥有的、名称严格匹配的目录。
 *
 * 同一清扫还承担 rm 守卫「移动保留区」（amagi-trash.*，ev-20261105-e4d22a ③）的保留期回收：
 * mv 保留不释放空间，超过整体保留期（7d）整目录删除，避免无限累积。
 *
 * 零 pi 依赖；全部操作尽力而为（失败只计入返回值，不影响检查/会话）。
 */
import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";

/** 捕获根保留项：小体积、回执/复核需要的事实文件。 */
const KEEP_IN_CAPTURE_ROOT = new Set(["manifest.json", "dependency-manifest.json", "checks"]);

/** 内容回收阈值（目录 mtime 距今）：超过即删除源码镜像与依赖副本，只留日志与清单。 */
export const VO_CONTENT_TTL_MS = 6 * 60 * 60 * 1000;
/** 整体保留期：超过即整目录删除（回执 check.log 之后回源失败，finalizer 已按缺失降级）。 */
export const VO_REMOVE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

const VO_NAME = /^amagi-vo-[A-Za-z0-9]+$/;
const VO_CACHE_NAME = /^amagi-vo-[A-Za-z0-9]+-cache-[A-Za-z0-9]+$/;
const GOMOD_NAME = /^amagi-gomod-(?:empty-)?[A-Za-z0-9]+$/;
/** rm 守卫建议的移动保留区（ev-20261105-e4d22a ③：mv 保留不释放空间且无限累积，补保留期回收）。 */
const TRASH_NAME = /^amagi-trash\.[A-Za-z0-9]+$/;

/** 只读目录（Go 模块缓存为 0555）使其可删：仅对目录（非符号链接）补 u+rwx——不跟随符号链接、不触碰文件
 *  inode（硬链接指向外部文件的权限不变）。异步分片，不阻塞事件循环。 */
async function makeDirsWritable(root: string): Promise<void> {
	const stack = [root];
	while (stack.length) {
		const dir = stack.pop()!;
		try {
			const st = await fsp.lstat(dir);
			if (!st.isDirectory()) continue;
			if ((st.mode & 0o700) !== 0o700) await fsp.chmod(dir, st.mode | 0o700);
			for (const name of await fsp.readdir(dir)) stack.push(path.join(dir, name));
		} catch { /* lint-exempt:尽力而为 */ }
	}
}

/** 递归删除（异步，走线程池，不阻塞主事件循环——ev-20261105-0a2e43 diting F1）；只读目录首次失败后补目录权限再试一次。
 *  返回是否已不存在。 */
export async function removeTreeBestEffort(target: string): Promise<boolean> {
	try { await fsp.rm(target, { recursive: true, force: true }); } catch { /* lint-exempt:下面补权限重试 */ }
	if (fs.existsSync(target)) {
		await makeDirsWritable(target);
		try { await fsp.rm(target, { recursive: true, force: true }); } catch { /* lint-exempt:尽力而为，下次启动清扫再试 */ }
	}
	return !fs.existsSync(target);
}

/** 回收捕获根内的内容镜像与依赖副本，保留清单与检查日志。返回回收的顶层条目数。 */
export async function reclaimCaptureRootContent(captureRoot: string): Promise<number> {
	if (!VO_NAME.test(path.basename(captureRoot))) return 0; // 名称护栏：只处理验证对象捕获根
	let reclaimed = 0;
	let names: string[];
	try { names = await fsp.readdir(captureRoot); } catch { /* lint-exempt:GC 尽力而为，失败按保守分支处理 */ return 0; }
	for (const name of names) {
		if (KEEP_IN_CAPTURE_ROOT.has(name)) continue;
		if (await removeTreeBestEffort(path.join(captureRoot, name))) reclaimed++;
	}
	return reclaimed;
}

/** 检查结束出口：回收内容镜像 + runner 缓存 + Go 私有模块缓存（日志与清单保留）。 */
export async function reclaimCheckArtifacts(art: { captureRoot?: string | null; cacheRoot?: string | null; goModuleCacheRoot?: string | null }): Promise<{ reclaimedEntries: number; removedDirs: number }> {
	let reclaimedEntries = 0;
	let removedDirs = 0;
	if (art.captureRoot) reclaimedEntries += await reclaimCaptureRootContent(art.captureRoot);
	if (art.cacheRoot && VO_CACHE_NAME.test(path.basename(art.cacheRoot)) && await removeTreeBestEffort(art.cacheRoot)) removedDirs++;
	if (art.goModuleCacheRoot && GOMOD_NAME.test(path.basename(art.goModuleCacheRoot)) && await removeTreeBestEffort(art.goModuleCacheRoot)) removedDirs++;
	return { reclaimedEntries, removedDirs };
}

export interface VerificationTempSweepResult {
	scanned: number;
	contentReclaimed: number;
	removed: number;
	skipped: number;
}

/** 目录「最近活动」年龄：顶层 mtime 与一级子项 mtime 取最新者（trash 内后续 mv 不刷新顶层 mtime；
 *  捕获根的 checks/ 追加日志同理）。ev-20261105-0a2e43 diting F4。 */
async function latestActivityMs(abs: string, topMtimeMs: number): Promise<number> {
	let latest = topMtimeMs;
	try {
		for (const name of await fsp.readdir(abs)) {
			try { latest = Math.max(latest, (await fsp.lstat(path.join(abs, name))).mtimeMs); } catch { /* lint-exempt:竞态消失 */ }
		}
	} catch { /* lint-exempt:不可读按顶层 mtime */ }
	return latest;
}

/** 启动期清扫（只扫 tmpDir 一级，名称严格匹配 + 本用户拥有 + 非符号链接）。全程异步分片（逐目录让出事件循环、
 *  删除走线程池），积压再大也不冻结会话。 */
export async function sweepVerificationTemp(opts: { tmpDir?: string; now?: number; contentTtlMs?: number; removeTtlMs?: number } = {}): Promise<VerificationTempSweepResult> {
	const dir = opts.tmpDir ?? os.tmpdir();
	const now = opts.now ?? Date.now();
	const contentTtl = opts.contentTtlMs ?? VO_CONTENT_TTL_MS;
	const removeTtl = opts.removeTtlMs ?? VO_REMOVE_TTL_MS;
	const res: VerificationTempSweepResult = { scanned: 0, contentReclaimed: 0, removed: 0, skipped: 0 };
	let names: string[];
	try { names = await fsp.readdir(dir); } catch { /* lint-exempt:GC 尽力而为，失败按保守分支处理 */ return res; }
	const uid = typeof process.getuid === "function" ? process.getuid() : undefined;
	for (const name of names) {
		const isCapture = VO_NAME.test(name);
		const isTrash = TRASH_NAME.test(name);
		const isTransient = VO_CACHE_NAME.test(name) || GOMOD_NAME.test(name);
		if (!isCapture && !isTransient && !isTrash) continue;
		res.scanned++;
		const abs = path.join(dir, name);
		let st: fs.Stats;
		try { st = await fsp.lstat(abs); } catch { /* lint-exempt:GC 尽力而为，失败按保守分支处理 */ res.skipped++; continue; }
		if (!st.isDirectory() || (uid !== undefined && st.uid !== uid)) { res.skipped++; continue; }
		const age = now - await latestActivityMs(abs, st.mtimeMs);
		if (age >= removeTtl) {
			if (await removeTreeBestEffort(abs)) res.removed++; else res.skipped++;
		} else if (isTrash) {
			continue; // 移动保留区只做整体保留期回收（内容即保留物，无「只留日志」的中间态）
		} else if (age >= contentTtl) {
			// 运行期缓存/Go 私有缓存无复核价值：到内容保留期即整删；捕获根只回收内容保留日志
			if (isTransient) { if (await removeTreeBestEffort(abs)) res.removed++; else res.skipped++; }
			else if (await reclaimCaptureRootContent(abs) > 0) res.contentReclaimed++;
		}
	}
	return res;
}

export interface VerificationTempUsage {
	dirs: number;
	/** 估算占用（du -sk，KiB→字节）；du 不可用/超时为 undefined。 */
	bytes?: number;
}

/** doctor 披露：当前 tmpDir 下验证临时目录数量与估算占用（只读）。 */
export function inspectVerificationTemp(tmpDir: string = os.tmpdir()): VerificationTempUsage {
	let names: string[];
	try { names = fs.readdirSync(tmpDir); } catch { /* lint-exempt:GC 尽力而为，失败按保守分支处理 */ return { dirs: 0 }; }
	const dirs = names.filter((n) => VO_NAME.test(n) || VO_CACHE_NAME.test(n) || GOMOD_NAME.test(n) || TRASH_NAME.test(n)).map((n) => path.join(tmpDir, n));
	if (dirs.length === 0) return { dirs: 0 };
	try {
		let total = 0;
		// 总预算 2s：doctor 是同步入口，积压再大也不拖住——超预算只报目录数，占用标「未统计」（ev-20261105-0a2e43 diting F2）。
		const deadline = Date.now() + 2_000;
		for (let i = 0; i < dirs.length; i += 50) {
			const left = deadline - Date.now();
			if (left <= 0) return { dirs: dirs.length };
			let out = "";
			try { out = execFileSync("du", ["-sk", ...dirs.slice(i, i + 50)], { encoding: "utf8", timeout: left, stdio: ["ignore", "pipe", "ignore"] }); }
			catch (e: any) {
				if (e?.code === "ETIMEDOUT" || e?.signal) return { dirs: dirs.length };
				out = typeof e?.stdout === "string" ? e.stdout : "";
			}
			for (const line of out.split("\n")) {
				const m = /^(\d+)\s/.exec(line);
				if (m) total += Number(m[1]) * 1024;
			}
		}
		return { dirs: dirs.length, bytes: total };
	} catch { /* lint-exempt:GC 尽力而为，失败按保守分支处理 */
		return { dirs: dirs.length };
	}
}
