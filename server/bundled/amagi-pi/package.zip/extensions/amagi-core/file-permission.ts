/**
 * file-permission.ts — amagi-pi v2 P2（方案 §5.2 read/write/edit 通道执行点 / §8.3-P2）：
 * 文件工具执行前逐次权限校验器（运行时执法层）。
 *
 * 上游（P1 冻结面，本模块只读消费）：spec.permission（PermissionGrant，四方交集计算产物，
 * 提交前已过 validatePermissionGrant fail-closed 校验）。本模块把冻结授予变成**执行点判定**：
 *  - write/edit 通道：edit-override.ts / write-override.ts 在委托原生操作之前校验**全部**目标
 *    （files[] 多文件整单、新目录最近存在父目录解析），任一越界零写入（先全部校验后执行）；
 *  - read 通道：读不设范围限制（ev-20260919 主上裁定：定量读限制对 Agent 纯摩擦、对安全无增益）
 *    ——仅 deny 禁入区拒绝（guards.ts tool_call 挂钩消费 checkRead，词法或落点任一命中 deny 即 block）；
 *  - 权限只校验**目标**，不重写内容匹配（edit 的 fuzzy/regex oldText 匹配逻辑零干预）。
 *
 * 路径判定语义（§5.2）：
 *  - 匹配器复用 P1 冻结面 matchPathRule（file 精确 / directory 目录边界 value+sep /
 *    glob 通配（* 不跨 /，** 跨）/ prefix 显式字符串前缀——prefix 不隐式当目录）；
 *  - 目标解析：已有目标 realpath 后校验；新目标解析**最近存在父目录** realpath 再拼回剩余段——
 *    符号链接越界（realpath 落点在授予范围外）、`..` 逃逸（归一化后落点越界）、跨根（盘符/UNC）
 *    一律拒绝；授予规则值同样经 realpath 归一（darwin /var→/private/var 别名下不误伤）；
 *  - 覆盖判定锚定**真实落点**（resolved）：词法路径在范围内但符号链接解析后落点越界 → 拒绝；
 *    deny 恒优先（词法或落点任一命中 deny 即拒绝）；写入落点与契约存储（v2-store，K2）重叠 →
 *    拒绝（内核单写者面，任务工具不可触碰）；reportFiles 授予成立时报告路径可写（write/edit 均可）。
 *
 * 权限上下文建立（§5.1：权限清单由父端冻结、经专用只读契约引用 + digest 传给子端）：
 *  - 子进程：bootstrapFilePermissionContextFromEnv（P4 在 task-run/index 接线）——
 *    AMAGI_PERMISSION_GRANT（冻结授权 JSON）× AMAGI_PERMISSION_CWD（冻结工作目录）×
 *    AMAGI_PERMISSION_DIGEST（sha256(rawGrantJson)，可选防篡改）；校验失败**抛错即退出**，
 *    不从环境变量缺失/非法回退到无限制（fail-closed）；
 *  - TaskStore 接缝：activateFilePermissionContextFromSpec（P4 从 v2-store load spec 后注入）；
 *  - 主进程：index.ts 注册的 edit/write override 同一 getActiveFilePermissionEnforcer 接线
 *    （懒引导 env，非法值 → deny-all 哨兵，写读全拒）。
 *
 * 严格任务（assurance=tool-enforced ⇒ shell=deny）override 注册失败 → failStrictTaskStartup
 * （stderr + exit 1）：不静默降级为无包装器原生工具（edit-override/write-override 注册器消费）。
 * 未注入权限上下文时（legacy 主进程）本模块零干预——AMAGI_PROTECTED_PATHS/AMAGI_ALLOWED_PATHS
 * 既有边界机制照常生效（§5.2 P4 接线前两制并行，P4 收口后 v1 面退役）。
 */
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { resolveBuiltinFileTarget, resolveBuiltinReadTarget } from "./builtin-file-target.ts";
import { contractStoreRoot } from "./artifact.ts";
import { isAgentOutputsPath, matchPathRule, pathPatternToRule } from "./task-permission.ts";
import { validatePermissionGrant, type PathRule, type PermissionGrant } from "./contracts/permission.ts";

// ── 环境接缝（P4 在 task-run.ts spawn env / index.ts 子进程启动接线） ───────────

/** 冻结授权 JSON（PermissionGrant 序列化；父端 submitTaskKernel 冻结后注入）。 */
export const PERMISSION_GRANT_ENV = "AMAGI_PERMISSION_GRANT";
/** 冻结工作目录（模式串绝对化基准；缺省 process.cwd()）。 */
export const PERMISSION_CWD_ENV = "AMAGI_PERMISSION_CWD";
/** 授权清单摘要（sha256 hex of raw grant JSON——防传输篡改；可选）。 */
export const PERMISSION_DIGEST_ENV = "AMAGI_PERMISSION_DIGEST";

export function permissionGrantDigest(rawGrantJson: string): string {
	return createHash("sha256").update(rawGrantJson, "utf8").digest("hex");
}

// ── 判定形状 ──────────────────────────────────────────────────────────────────

export interface PermissionTargetVerdict {
	ok: boolean;
	/** ok=false 时的阻断 reason（含目标、越界原因与当前授予摘要；可直接用于 block/throw）。 */
	reason?: string;
}

export interface FilePermissionEnforcer {
	readonly grant?: Readonly<PermissionGrant>;
	/** 冻结保证等级（tool-enforced ⇒ 严格任务：override 注册失败即拒启动）。 */
	readonly assurance: PermissionGrant["assurance"];
	/** 懒引导遇到非法注入时的 fail-closed 哨兵原因（deny-all 上下文非空）。 */
	readonly bootstrapError?: string;
	/** read 通道逐次校验（targetRaw 相对 sessionCwd 解析；缺省相对冻结 cwd）。 */
	checkRead(targetRaw: string, sessionCwd?: string): PermissionTargetVerdict;
	/** write 通道单目标校验（realpath/最近父目录解析后判定）。 */
	checkWrite(targetRaw: string, sessionCwd?: string): PermissionTargetVerdict;
	/** write 通道整单校验：全部目标先校验后执行，任一越界 → 整单拒绝（零写入语义由调用方保证）。 */
	checkWriteAll(targetsRaw: ReadonlyArray<string>, sessionCwd?: string): PermissionTargetVerdict;
}

// ── 路径原语：realpath 最近存在父目录 / 跨根判定 ─────────────────────────────

function isNoent(e: unknown): boolean {
	return Boolean(e) && typeof e === "object" && (e as NodeJS.ErrnoException).code === "ENOENT";
}

/** realpath 目标；目标不存在时逐级回退到最近存在的祖先 realpath 后拼回剩余段（mkdir 边界用）。
 *  非存在性错误（EACCES 等）向上抛——调用方 fail-closed 拒绝，不猜测落点。上探深度有界（防病态深路径）。 */
export function realpathNearestExisting(targetAbs: string): string {
	let probe = path.normalize(targetAbs);
	const tail: string[] = [];
	for (let hops = 0; hops < 256; hops++) {
		try {
			return path.join(fs.realpathSync.native(probe), ...tail);
		} catch (e) {
			if (!isNoent(e)) throw e;
			// ENOENT 也可能来自 dangling symlink：必须沿链接落点解析（writeFile 可创建该外部落点）。
			try {
				if (fs.lstatSync(probe).isSymbolicLink()) {
					probe = path.resolve(path.dirname(probe), fs.readlinkSync(probe));
					continue;
				}
			} catch (linkError) { if (!isNoent(linkError)) throw linkError; }
			const parent = path.dirname(probe);
			if (parent === probe) throw new Error("无法证明文件系统根的真实落点（拒绝词法猜测）");
			tail.unshift(path.basename(probe));
			probe = parent;
		}
	}
	throw new Error("真实路径解析超过 256 层（拒绝猜测落点）");
}

/** 文件系统根签名：Windows 盘符/UNC 显式识别（跨平台字符串判定），其余按宿主 path.parse。
 *  统一大写 + 反斜杠归一，保证 C:\x 与 c:/x、\\srv\sh 与 //srv/sh 同根。 */
export function fileSystemRootOf(p: string): string {
	const m = /^([a-zA-Z]:[\\/]|\\\\[^/\\]+[\\/][^/\\]+[\\/]|\/\/[^/]+\/[^/]+\/)/.exec(p);
	if (m) return m[1].toUpperCase().replaceAll("/", "\\");
	return path.parse(p).root;
}

/** 跨根判定（§5.2：拒绝跨盘符/UNC 根目标）。 */
export function isCrossRoot(targetAbs: string, baseAbs: string): boolean {
	return fileSystemRootOf(targetAbs) !== fileSystemRootOf(baseAbs);
}

// ── 授予面归一（规则 realpath 化 + 摘要文案） ────────────────────────────────

/** 规则值 realpath 归一（darwin /var→/private/var 别名下词法规则仍可命中真实落点）；
 *  解析失败（EACCES）保留词法值（best effort——deny 规则宁可保留词法面也不丢）。 */
function realpathRule(rule: Readonly<PathRule>): PathRule {
	try {
		return { kind: rule.kind, value: realpathNearestExisting(rule.value) };
	} catch {
		return { kind: rule.kind, value: path.normalize(rule.value) };
	}
}

function matchAny(targetAbs: string, rules: ReadonlyArray<PathRule>): boolean {
	return rules.some((r) => matchPathRule(targetAbs, r));
}

function describeRules(rules: ReadonlyArray<PathRule>): string {
	if (rules.length === 0) return "（空）";
	const head = rules.slice(0, 4).map((r) => `${r.kind}:${r.value}`).join("、");
	return rules.length > 4 ? `${head} 等 ${rules.length} 条` : head;
}

/** 目录边界包含（含根等值；path.relative 不跨 `..`）。 */
function isWithin(targetAbs: string, rootAbs: string): boolean {
	const rel = path.relative(rootAbs, targetAbs);
	return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
}

// ── 校验器工厂 ────────────────────────────────────────────────────────────────

export interface FilePermissionEnforcerDeps {
	/** 契约存储根（缺省 contractStoreRoot()——AMAGI_CONTRACT_ROOT/agentDir 派生，测试注入）。 */
	contractRoot?: string;
}

/** 从冻结 PermissionGrant 建立执行点校验器（grant 须已过 validatePermissionGrant——
 *  工厂内再自校验一次，非法即抛，绝不构造半开放校验器）。 */
export function createFilePermissionEnforcer(
	grant: Readonly<PermissionGrant>,
	workspaceCwd: string,
	deps: FilePermissionEnforcerDeps = {},
): FilePermissionEnforcer {
	const self = validatePermissionGrant(grant);
	if (!self.ok) {
		throw new Error(`[amagi 文件权限] 授权授予未通过契约校验（fail-closed，不构造校验器）：${self.error.message}`);
	}
	const cwd = path.resolve(workspaceCwd);
	const realCwd = realpathNearestExisting(cwd);
	const writeRules = grant.write.map(realpathRule);
	// deny 同时冻结声明路径与真实落点；重定向符号链接不能抹掉声明路径的禁入约束。
	const denyRules = grant.deny.flatMap(rule => [{ kind: rule.kind, value: path.normalize(rule.value) }, realpathRule(rule)]);
	const reportRules = grant.reportFiles.map((p) => realpathRule(pathPatternToRule(p, cwd)));
	let contractRoot: string;
	try {
		contractRoot = path.resolve(deps.contractRoot ?? contractStoreRoot());
	} catch {
		contractRoot = ""; // 存储根不可解析：跳过重叠检查（其余判定不受影响）
	}
	let realContractRoot = contractRoot;
	try { if (contractRoot) realContractRoot = realpathNearestExisting(contractRoot); }
	catch { /* 真实落点不可解析时仍保留声明路径保护。 */ }

	const resolveTarget = (targetRaw: string, sessionCwd?: string): string => {
		const t = targetRaw; // preserve filesystem identity: leading/trailing spaces are valid filename bytes
		const base = sessionCwd !== undefined && sessionCwd.trim() !== "" ? sessionCwd : cwd;
		return path.normalize(path.isAbsolute(t) ? t : path.resolve(base, t));
	};

	const checkWrite = (targetRaw: string, sessionCwd?: string): PermissionTargetVerdict => {
		if (!targetRaw) return { ok: true }; // 空目标交原生参数校验报错（无写点可言）
		const lexical = resolveTarget(targetRaw, sessionCwd);
		let resolved: string;
		try {
			resolved = realpathNearestExisting(lexical);
		} catch (e) {
			return { ok: false, reason: `[amagi 文件权限] write 目标无法解析真实路径（${e instanceof Error ? e.message : String(e)}）——fail-closed 拒绝写入：${lexical}` };
		}
		const viaLink = resolved !== lexical;
		const suffix = viaLink ? `（词法路径 ${lexical}，符号链接/别名解析后真实落点 ${resolved}）` : `（${resolved}）`;
		if (isCrossRoot(resolved, cwd) || isCrossRoot(lexical, cwd)) {
			return { ok: false, reason: `[amagi 文件权限] write 目标跨文件系统根（盘符/UNC）越界：${lexical}（工作区根 ${fileSystemRootOf(cwd)}）——已拒绝，零写入。` };
		}
		if (contractRoot !== "" && [contractRoot, realContractRoot].some(root => isWithin(resolved, root) || isWithin(lexical, root))) {
			return { ok: false, reason: `[amagi 文件权限] write 目标与契约存储（v2-store：${contractRoot}）重叠：${lexical}——任务工具不可写内核契约存储（单写者面），已拒绝，零写入。` };
		}
		if (matchAny(resolved, denyRules) || matchAny(lexical, denyRules)) {
			return { ok: false, reason: `[amagi 文件权限] write 目标在 deny 禁入区（deny 恒优先，任何授予不得覆盖）${suffix}——当前 deny=[${describeRules(denyRules)}]，已拒绝，零写入。` };
		}
		// v2.5.1（diting MJ-1）：tool-enforced（shell=deny ⇒ 无 bash 通道）保留粗写围栏——工作区根外
		// 写入须 write/reportFiles 显式声明或落 agent-outputs 报告目录。ev-20260919 门禁减重的
		// 「bash 写不受拦，执法不对称=纯摩擦」论据只对 guarded（有 bash）成立；tool-enforced 任务
		// 文件工具是唯一写通道，授予面执法对称成立且是其容器性底线（非 git 路径上「git 回滚 +
		// evidence diff 归因」兑底不成立）。guarded 面维持 2.5.0 声明性裁定不变（下方注释）。
		if (grant.assurance === "tool-enforced") {
			// F3：词法位置不能授予外部真实落点写权（包括 agent-outputs 别名）；只按真实目标放行。
			const inWorkspace = isWithin(resolved, realCwd);
			const declared = matchAny(resolved, writeRules)
				|| matchAny(resolved, reportRules) || isAgentOutputsPath(resolved);
			if (!inWorkspace && !declared) {
				return {
					ok: false,
					reason: `[amagi 文件权限] tool-enforced 写围栏：write 目标在任务工作区根（${cwd}）之外且未声明（write/reportFiles 授予面与 agent-outputs 报告目录均未覆盖）${suffix}——严格任务无 bash 通道，文件工具是唯一写面，越界即拒绝（零写入）。若产物内容已完整、仅目标路径在围栏外：不要丢弃已完成内容，把完整产物写入 agent-outputs/ 报告目录（围栏认可的官方中转通道，如任务工作区下 agent-outputs/），并在最终汇报中声明文件位置与「可由 Leader 落盘」（产物中转，ev-20260929-02b8e0）。`,
				};
			}
		}
		// ev-20260919（主上裁定：门禁减重）：guarded 面 write 授予面执法退役（对称 read 声明性化）——不在
		// 授予范围内的写入不再拦截（原「write 目标越界」硬拦是实战最大摩擦源：目录请求无 /** 全拒、
		// worktree/主树锚定越界，子 Agent 只能中断报告 Leader 调 scope 重派；且 bash 写不受拦，执法
		// 不对称=纯摩擦）。硬保护保留：deny 禁入/契约存储重叠/跨根（在前）；误写兑底靠 git worktree
		// 可回滚 + evidence diff 归因 + 审核链。write 授予面仍冻结进 grant（声明性，供回执/审计展示）。
		return { ok: true };
	};

	const checkRead = (targetRaw: string, sessionCwd?: string): PermissionTargetVerdict => {
		if (!targetRaw) return { ok: true };
		const lexical = resolveTarget(targetRaw, sessionCwd);
		let resolved: string;
		try {
			resolved = realpathNearestExisting(lexical);
		} catch (e) {
			return { ok: false, reason: `[amagi 文件权限] read 目标无法解析真实路径（${e instanceof Error ? e.message : String(e)}）——fail-closed 拒绝读取：${lexical}` };
		}
		// ev-20260919：读范围限制退役——原「read 目标不在读范围」硬拦被移除（worktree/邻包路径误伤，
		// 纯摩擦）；deny 禁入护读保留（词法或落点任一命中即拒，secret 保护语义不变）。
		if (matchAny(resolved, denyRules) || matchAny(lexical, denyRules)) {
			return { ok: false, reason: `[amagi 文件权限] read 目标在 deny 禁入区（deny 恒优先）：${lexical}——当前 deny=[${describeRules(denyRules)}]，已拒绝。\n[修复指引] deny 读写双禁（含 read）——若本文件是任务必读输入，说明派发时 deny 误伤（常见误用：把写保护路径放进 scope.deny）：不要用 bash/MCP 旁路禁令，向 Leader 报告请求移除对应 deny 条目重派（防写无需 deny：未授予 write/reportFiles 即零写入）；若确属禁入（密钥/凭据），改用任务书指定的替代来源。` };
		}
		return { ok: true };
	};

	return {
		grant,
		assurance: grant.assurance,
		checkRead,
		checkWrite,
		checkWriteAll(targetsRaw, sessionCwd) {
			const seen = new Set<string>();
			for (const t of targetsRaw) {
				if (typeof t !== "string" || !t) continue;
				const key = path.normalize(path.isAbsolute(t) ? t : path.resolve(sessionCwd ?? cwd, t));
				if (seen.has(key)) continue;
				seen.add(key);
				const v = checkWrite(t, sessionCwd);
				if (!v.ok) {
					return { ok: false, reason: `${v.reason}\n[amagi 文件权限] 整单拒绝：本次调用共 ${seen.size} 个写入目标，任一越界即全部零写入（修正后可原参数重跑）。` };
				}
			}
			return { ok: true };
		},
	};
}

// ── 活动上下文（主进程 override / guards read 挂钩共用；env 懒引导） ─────────

let activeEnforcer: FilePermissionEnforcer | undefined;
let bootstrapped = false;

/** 显式激活权限上下文（测试/P4 TaskStore 接缝；幂等覆盖）。 */
export function activateFilePermissionContext(grant: Readonly<PermissionGrant>, workspaceCwd: string): FilePermissionEnforcer {
	activeEnforcer = createFilePermissionEnforcer(grant, workspaceCwd);
	bootstrapped = true;
	return activeEnforcer;
}

/** TaskStore 接缝（P4）：从 v2-store load 的 spec（或含 permission 字段的冻结形状）建立上下文。
 *  非法 permission → 抛错（任务启动即拒，不回退无限制）。 */
export function activateFilePermissionContextFromSpec(spec: { permission?: unknown }, workspaceCwd: string): FilePermissionEnforcer {
	const v = validatePermissionGrant(spec?.permission);
	if (!v.ok) {
		throw new Error(`[amagi 文件权限] spec.permission 未通过契约校验（任务启动即拒，不回退无限制）：${v.error.message}`);
	}
	return activateFilePermissionContext(v.value, workspaceCwd);
}

/** 仅供测试复位模块态（生产不调用）。 */
export function deactivateFilePermissionContextForTest(): void {
	activeEnforcer = undefined;
	bootstrapped = false;
}

/** 当前活动校验器；未注入权限上下文时 undefined（legacy 零干预）。
 *  首次调用懒引导 env：注入存在但非法 → deny-all 哨兵（fail-closed：读/写全拒并留原因）。 */
export function getActiveFilePermissionEnforcer(env: NodeJS.ProcessEnv = process.env): FilePermissionEnforcer | undefined {
	if (activeEnforcer !== undefined) return activeEnforcer;
	if (!bootstrapped) {
		bootstrapped = true;
		try {
			const bootstrappedEnforcer = bootstrapFilePermissionContextFromEnv(env);
			activeEnforcer = bootstrappedEnforcer ?? undefined;
		} catch (e) {
			const cause = e instanceof Error ? e.message : String(e);
			// 空授予仍允许工作区写与任意读，不能充当 deny-all。哨兵无需文件系统即可拒绝全部调用。
			const blocked = (): PermissionTargetVerdict => ({ ok: false, reason: "[amagi 文件权限] 权限上下文注入非法，已拒绝所有文件读写（fail-closed）。" });
			activeEnforcer = { assurance: "tool-enforced", bootstrapError: cause, checkRead: blocked, checkWrite: blocked, checkWriteAll: blocked };
			console.error(`[amagi 文件权限] 权限上下文注入非法，进入 deny-all 哨兵（fail-closed）：${cause}`);
		}
	}
	return activeEnforcer;
}

/** 严格任务判定（assurance=tool-enforced）：override 注册失败即拒启动的执法开关。 */
export function strictEnforcementActive(env: NodeJS.ProcessEnv = process.env): boolean {
	return getActiveFilePermissionEnforcer(env)?.assurance === "tool-enforced";
}

/** 活动权限上下文判定（严格或 guarded——diting-M3-A1）：只要存在冻结授权上下文，
 *  write/edit 通道逐次校验执法点就必须注册（诊断开关只降级诊断不降级执法）。 */
export function filePermissionContextActive(env: NodeJS.ProcessEnv = process.env): boolean {
	return getActiveFilePermissionEnforcer(env) !== undefined;
}

// ── 子端启动引导（P4 接线：task-run spawn env / index.ts 子进程启动） ─────────

/** 从 env 建立权限上下文（§5.1：父端冻结 + 只读契约引用 + digest）。
 *  - 未注入 → undefined（legacy：AMAGI_PROTECTED_PATHS/AMAGI_ALLOWED_PATHS 既有机制继续生效）；
 *  - 注入非法（JSON/契约/digest 不一致，或 digest 在而清单缺）→ 抛错——子端启动校验失败即退出，
 *    不从环境变量缺失回退到无限制。
 *  digest 语义：sha256(AMAGI_PERMISSION_GRANT 原始字符串)——父端对注入原文取摘要，避免序列化次序歧义。 */
export function bootstrapFilePermissionContextFromEnv(env: NodeJS.ProcessEnv = process.env): FilePermissionEnforcer | undefined {
	const raw = env[PERMISSION_GRANT_ENV];
	const digest = (env[PERMISSION_DIGEST_ENV] ?? "").trim().toLowerCase();
	if (digest !== "") {
		if (!raw || !raw.trim()) {
			throw new Error(`[amagi 文件权限] 启动失败：${PERMISSION_DIGEST_ENV} 已注入但 ${PERMISSION_GRANT_ENV} 缺失（fail-closed，不从缺失回退到无限制）。`);
		}
		if (!/^[0-9a-f]{64}$/.test(digest)) {
			throw new Error(`[amagi 文件权限] 启动失败：${PERMISSION_DIGEST_ENV} 不是合法 sha256 hex（fail-closed）。`);
		}
		if (permissionGrantDigest(raw) !== digest) {
			throw new Error(`[amagi 文件权限] 启动失败：${PERMISSION_DIGEST_ENV} 与 ${PERMISSION_GRANT_ENV} 摘要不一致（授权清单疑被篡改/截断，fail-closed 拒绝启动）。`);
		}
	}
	if (raw === undefined || raw.trim() === "") return undefined;
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch (e) {
		throw new Error(`[amagi 文件权限] 启动失败：${PERMISSION_GRANT_ENV} 不是合法 JSON（${e instanceof Error ? e.message : String(e)}）——子端启动校验失败即退出，不回退无限制。`);
	}
	const v = validatePermissionGrant(parsed);
	if (!v.ok) {
		throw new Error(`[amagi 文件权限] 启动失败：授权授予未通过契约校验（${v.error.message}）——子端启动校验失败即退出，不回退无限制。`);
	}
	const cwd = env[PERMISSION_CWD_ENV]?.trim() || process.cwd();
	return activateFilePermissionContext(v.value, cwd);
}

// ── 执行点接线（edit-override / write-override / guards read 消费） ──────────

/** write/edit 通道执行点：无活动上下文零干预；任一目标越界 → throw（调用方在原生操作之前调用，
 *  throw 即零写入）。targets 为本次调用的**全部**写入目标（files[]/多目标整单）。 */
export function enforceFileWriteTargets(cwd: string, targets: ReadonlyArray<string>): void {
	const enforcer = getActiveFilePermissionEnforcer();
	if (enforcer === undefined) return;
	const verdict = enforcer.checkWriteAll(targets, cwd);
	if (!verdict.ok) throw new Error(verdict.reason ?? "[amagi 文件权限] write 目标越界，已拒绝。");
}

/** read 通道执行点（guards tool_call 消费，ev-20260919 读范围限制退役）：无活动上下文/允许 → null；
 *  仅 deny 禁入命中 → block reason（读不设范围限制，deny 护读恒存）。 */
export function fileReadPermissionBlockReason(cwd: string, targetRaw: string, readFallback = true): string | null {
	const enforcer = getActiveFilePermissionEnforcer();
	if (enforcer === undefined) return null;
	// read 按原生文件名回退；grep/find 仅解析路径，不能套用 read 专属回退。
	let target = targetRaw;
	try { if (targetRaw !== "") target = (readFallback ? resolveBuiltinReadTarget : resolveBuiltinFileTarget)(targetRaw, cwd); }
	catch (e) { return `[amagi 文件权限] 无法解析 read 目标：${e instanceof Error ? e.message : String(e)}`; }
	const verdict = enforcer.checkRead(target, cwd);
	return verdict.ok ? null : (verdict.reason ?? `[amagi 文件权限] read 目标越界：${targetRaw}`);
}

// ── 严格任务启动执法（override 注册失败禁止静默降级） ─────────────────────────

/** 严格任务（tool-enforced）启动失败：stderr 单行 + exit(1)——process.exit 不可被调用方 try/catch
 *  吞掉，保证「任务启动即拒，不静默降级为无包装器原生工具」。 */
export function failStrictTaskStartup(reason: string): never {
	const message = `[amagi] 严格任务（tool-enforced）启动失败：${reason}`;
	console.error(message);
	process.exit(1);
}
