import { freezeSelectedEvidence } from "./dispatch-handoff.ts";
import { advisorAuthorityOf } from "./advisor-config.ts";
import { captureLeaderContext, prepareDispatchContext, validateDispatchContext, type DispatchContextRequest, type DispatchContextSession } from "./dispatch-context.ts";
/**
 * task-facets.ts — amagi-pi v2 I1（方案 §4.1/§4.2/§8.2-I1）：五个稳定分面工具定义（注册就绪）。
 * H3（§8.4-H3/§6.1）：四分面加 constrainedSampling prefer 档（保留执行前运行校验，不引入 grammar）。
 *
 * 本模块只做「工具面」：object schema（StringEnum 枚举）+ 执行前字段组合/业务校验（互斥组整单拒绝、
 * effects=none）+ Result 适配（tool-result-adapter）。真实执行全部委托既有应用链——
 *  - task_submit：SubmitInput 校验 → runTask（sync）/runBackgroundTask（handle）——两者内部经
 *    submitTaskKernel 冻结真实 TaskSpec 并 register（M1 内核链）→ 共享准入 → grant-start → 引擎启动。
 *  - task_resume：resolveSessionWithBackfill → runResumeTask（K5b 父链/lease 语义）。
 *  - task_control：wait→waitTasks；cancel→cancelTask；resolve-external→resolveExternalTask；
 *    accept/reject→decideTaskReceipt（K7；actor 取 CallerContext，模型参数不能伪造身份）+
 *    暂停组 resumeGroupAfterAcceptance（K8b 接缝）。歧义/未知句柄与非法组合在任何动作前整单拒绝。
 *  - task_query：queryTaskViews（K8c 三轴只读）thin 适配。
 *
 * 命名（I1 裁量）：legacy `task`/`query_task` 仍在注册（task-tool.ts/task-query.ts 保留兼容定义），
 * 新分面以 `task_submit`/`task_resume`/`task_control`/`task_query` 落名，避免同会话同名冲突；
 * 注册接线与旧工具切换策略属 I2（组合根独占 index.ts）；W1.2 起旧工具模型面单轨翻转（见上）。
 *
 * CallerContext 仅由组合根提供（factory 注入，factory 内校验）；子进程/模型参数不能构造。
 * surfaceVersion 在 factory 创建时刻定格（会话固定工具面，I2 appendEntry 留档用 taskFacetSurfaceStamp）。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { sendTaskCompletion, type TaskCompletionSink } from "./evidence-context.ts";
import { StringEnum, type ConstrainedSamplingConfig } from "@earendil-works/pi-ai";
import type { ToolAnnotations } from "@earendil-works/pi-coding-agent";
import type { AgentConfig } from "./agents-loader.ts";
import { registry } from "./task-registry.ts";
import { extractBlockedQuestions } from "./task-jsonl.ts";
import { runTask, resolveProjectTrusted, fullRepoCheckoutNote } from "./task-tool.ts";
// ev-20261031-7110a8：稳定面可选临时 model 覆盖——复用 legacy paramModel 的归一/提示链，不加平行体系。
import { parseStringifiedModelArray, modelOverrideNote, resolveModelWithSource, normalizeModelSpec, type ModelRegistryLike } from "./model-resolver.ts";
import { formatRuntimeObservation } from "./runtime-fingerprint.ts";
import { steerTask } from "./task-steer.ts";
// ev-20260930-0dd26f（R6）：steer 通道精确投影（summary 一行状态）+ 生命周期 GC 触发（新 steer 写入后低频）
import { formatSteerChannelLine, readSteerChannelSnapshot } from "./task-steer.ts";
import { maybeSweepSteerChannels } from "./task-recovery.ts";
import { submitPathDriftHints } from "./path-drift.ts";
import { runBackgroundTask } from "./task-background.ts";
import { runResumeTask, resolveSessionWithBackfill, resolveSessionForResume, loadResumeParentContract, resumeAdmissionCodeOf, recoveryActionOfRecord } from "./task-resume.ts";
// D2（ev-20260922-727096）：恢复指引单源消费——判断/渲染都在 reliability，本模块只装配事实并固定稳定面渲染。
import { recoveryActionOf, renderRecoveryAdvice, RECOVERY_RESUME_MESSAGE, type RecoveryAction } from "./reliability.ts";
import {
	cancelTask, resolveExternalTask, waitTasks, decideTaskReceipt,
	queryTaskViews, kernelViewLine, peekTaskKernel, getTaskKernel, resolveStoredTaskHandle, listPendingAcceptance, type WorktreeDispatchFacts,
} from "./task-service.ts";

/** ev-20261028-b3ba43：同一待接受任务在后续任务工具返回里至多提醒的次数。 */
export const PENDING_REMINDER_CAP = 2;

/** ev-20261028-965993：accept/reject 的 receiptId 引用当前回执的词元（大小写不敏感）；缺省同义。 */
export const LATEST_RECEIPT_TOKENS: readonly string[] = ["latest", "current"];

/** 转录畸变容忍上限：等长且逐位不同字符数 ≤ 此值视为同一 id 的手抄误差。 */
const NEAR_MISS_MAX = 2;

function nearMiss(a: string, b: string): boolean {
	if (a === b || a.length !== b.length || a.length < 12) return false;
	let diff = 0;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i] && ++diff > NEAR_MISS_MAX) return false;
	return diff > 0;
}

/** ev-20261028-965993：accept/reject 决策引用归一（纯函数）。
 *  - receiptId：latest/current（大小写不敏感）→ 当前回执；与当前回执仅差 ≤NEAR_MISS_MAX 字符 → 纠正为当前值；
 *    其余原样返回（真正的旧回执仍走 stale-receipt 诊断）。
 *  - waivedCheckIds：不在可 waive 集合且唯一近似某个可 waive id 的项 → 纠正；无唯一候选原样交内核裁决。 */
export function normalizeDecisionRefs(
	receiptId: string,
	waivedCheckIds: readonly string[] | undefined,
	current: { receiptId: string; waivable: readonly string[] },
): { receiptId: string; waivedCheckIds?: readonly string[]; notes: string[] } {
	const notes: string[] = [];
	let rid = receiptId;
	if (LATEST_RECEIPT_TOKENS.includes(receiptId.trim().toLowerCase())) {
		rid = current.receiptId;
		notes.push(`receiptId="${receiptId}" → 当前回执 ${current.receiptId}`);
	} else if (isValidReceiptIdShape(receiptId) && isValidReceiptIdShape(current.receiptId) && nearMiss(receiptId, current.receiptId)) {
		// 仅生产形态 receipt-<uuid>：随机 uuid 间不会只差 1~2 字符；合成/历史形态（如 -1/-2 序号）不纠正，保留 stale 栅栏。
		rid = current.receiptId;
		notes.push(`receiptId 转录误差已纠正（收到 ${receiptId} → 当前 ${current.receiptId}）`);
	}
	if (waivedCheckIds === undefined) return { receiptId: rid, notes };
	const fixed = waivedCheckIds.map((id) => {
		if (current.waivable.includes(id)) return id;
		const cands = current.waivable.filter((w) => nearMiss(id, w));
		if (cands.length !== 1) return id;
		notes.push(`waivedCheckIds 转录误差已纠正（${id} → ${cands[0]}）`);
		return cands[0];
	});
	return { receiptId: rid, waivedCheckIds: [...new Set(fixed)], notes };
}
import { describeStoredControlTarget, reconcileStoredTask, sessionOwnsRun } from "./task-reconcile.ts";
import { resumeGroupAfterAcceptance, getGroup } from "./group-scheduler.ts";
import { describeBaselinePreflight, finalizeTerminal } from "./finalizer.ts";
// ev-20261108-m3（diting 审 m3）：「自动基线探测级环境缺口降级」展示判据单源——task_query 视图行、
// task_control accept 附注与 [待接受] 提示共用（finalizer 一次性提示触发同源），禁止复制判据。
import { baselineEnvGapOf, type BaselineEnvGapFact } from "./evidence.ts";
// Batch 3（§9.5 成本进入 footer）：终态用量 footer 只读渲染（writeStats 漏斗已聚合终值，幂等）
import { renderUsageFooter } from "./usage-footer.ts";
// B8（设计 §5.5）：task_control wait / handle 后台任务 / resume 后台的保温窗口标记——
// 开始/刷新在窗 lease（cache-warming 决策器消费；未决任务超时返回后保留，见 wait 路径注释）。
import { beginCacheWarmingLease, endCacheWarmingLease } from "./cache-warming.ts";
import { appendCancellationReason, appendDeclaredOutputsSection, blockedReplyDirective, genTaskId, type RunResult, type BackgroundStart } from "./task-run.ts";
import { archivedTaskContextRefs, contractRefBaseHint, contractRefInlineNote, contractStoreRoot } from "./artifact.ts";
// D1（ev-20260922-c896f8）：旧回执 id:status 形态的展示适配（拆出的 id 须精确匹配本回执 checks id）。
import { splitLegacyCheckGapId } from "./contracts/evidence.ts";
import {
	validateSubmitInput, validateControlCommand, validateCallerContext,
	CONTROL_ACTIONS, receiptIdMismatchHint, isValidReceiptIdShape, ERROR_EXECUTION_COVERAGE_GAP_ID,
	type CallerContext,
} from "./contracts/command.ts";
import { CONTRACT_ERROR_CODES, normalizeToolArgumentArtifacts, err, ok, validateTaskQuery, type ContractError, type Result, type TaskViewLevel } from "./contracts/view.ts";
// O3b（pi-0.99.1 机会批 §4.7.2）：task_query 结构化输出 wire——outputSchema 挂载 + execute 双载体返回。
// 纯投影模块（O3a：零 I/O/零宿主依赖）；归档与恢复说明由本接线处一次读取/计算后喂映射
// （single-read、双载体同源，§4.5）——正文/details 契约字节不变，wire 仅出现在 structuredContent 新增键。
import {
	TaskQueryOutputSchema, toSummaryWire, toReceiptWire, toOutputWire, toFailureWire,
	redactCredentials, redactContractError,
	type TaskQueryWireSource, type TaskQueryWireOutput,
} from "./task-query-wire.ts";
import { dispatchAcceptableAgentIds, findAgentByRequest, resolveAgentRequest, withModeHeader } from "./agent-aliases.ts";
import { computeEffectiveGrant, unlimitedUserAuthority, JSON_BACKEND_CAPS, findAssignmentDenyConflicts, roleChannelCapsSummary, optionalShellDowngradeNotice, matchPathRule } from "./task-permission.ts";
import { guardRuleOf } from "./guard-policy.ts";
// ev-20261007-ef07e6：workspace.mode=worktree 派发口统一——复用 worktree.ts 既有原语
// （setupWorktree 创建/复用 + lease 唯一所有权 + 约定路径 <root>/.amagi-worktrees/<name>），
// 与 legacy task 工具 worktree 参数 / /amagi 清理语义互操作，不另造第二套路径。
import {
	setupWorktree, probeWorktreePlan, prepareWorktreeDependencies, acquireWorktreeAtPath,
	attachWorktreeLease, releaseWorktreeLease, worktreeOwnership,
	worktreeSummary, worktreePatch, inspectWorktreeRemoval,
	probeWorktreeDeclaredInput, convertWorktreeDeclaredOutput, rollbackWorktreeCreation, snapshotMainBaseline,
	type WorktreeSetup, type WorktreePlanProbe, type WorktreeBaseMode, type WorktreeInputProbe,
} from "./worktree.ts";
import { declaredOutputWriteHint, findDispatchRequirementGaps } from "./dispatch-preflight.ts";
// ev-20260930-08a8e7 切片2：升级窗口提示（派发/完成通知接缝；同版本对只提示一次，未知不假报）
import { versionDriftNotice } from "./version-drift.ts";
import type { SubmitScope } from "./contracts/command.ts";
import type { ShellPolicy } from "./contracts/permission.ts";
import { createFilePermissionEnforcer } from "./file-permission.ts";
import { awaitPendingFileMutations, fileMutationSessionId } from "./file-mutation-tracker.ts";
import {
	InputReferenceSchema, OutputReferenceSchema, normalizeInputReferences, normalizeOutputReferences,
	validateTaskSource, readTaskFile, appendInputsSection, prepareDispatchArguments, DISPATCH_TASK_GUIDELINES, type DispatchInput, type DispatchOutput,
} from "./dispatch-input.ts";
import {
	adaptThrown, aggregateDetailsBlock, contractErrorReturn, detailsBlockOf, guardedExecute, okReturn,
	type FacetToolReturn,
} from "./tool-result-adapter.ts";

// ── 工具面版本（会话固定：注册时刻定格；I2 组合根 appendEntry 留档） ─────────────

/** 分面工具面版本（§1.1.5 少数稳定工具；升版须同步 I2 会话留档策略）。
 *  v2（W1.2 单轨翻转）：legacy task/query_task 新会话默认剔除出活跃集——双轨留档（v1）会话
 *  resume 或 AMAGI_SURFACE_LEGACY=1 保留（判定与剔除逻辑在 tool-surface.ts）；注册面不变。 */
export const TASK_FACET_SURFACE_VERSION = 2;
/** 分面工具名（legacy task/query_task 保留注册；新名避免同会话同名冲突——I2 决定切换）。 */
export const TASK_FACET_NAMES = ["task_submit", "task_resume", "task_control", "task_query"] as const;

/**
 * 分面工具 constrainedSampling 档位（H3，方案 §6.1：先 prefer，保留运行校验，不引入 grammar）。
 * prefer 语义（pi-ai dist/api/constrained-sampling.js resolveJsonSchemaStrictSampling 实证）：
 *  - 供应商支持 strict 且 schema 可转 strict 子集 → 约束采样启用；
 *  - 供应商不支持或 schema 不可转 → 静默降级为普通采样（undefined，不假装约束）；
 *  - 非法参数的拒绝始终由执行前契约校验（rejectUnknownParams + validate*）整单承担，与供应商能力无关。
 * 硬约束（require）在供应商不支持时会明确抛错拒绝——本工具面不启用（退路见 facetSamplingFallbackNote）。
 */
export const TASK_FACET_CONSTRAINED_SAMPLING: ConstrainedSamplingConfig = { type: "json_schema", strict: "prefer" };

/**
 * 不支持该能力的模型/供应商的可解释退路说明（guided 文档；不改任务权限——采样档位与权限面正交）。
 * 供诊断/报告/测试引用；运行时不注入对话（避免噪声）。
 */
export function facetSamplingFallbackNote(): string {
	return [
		"constrainedSampling=json_schema/prefer：供应商与 schema 均可转 strict 时启用约束采样；",
		"任一不支持时降级为普通采样（不假装约束）——参数合法性始终由执行前契约校验整单拒绝（effects=none），与供应商采样能力无关；",
		"需要硬约束的调用方可自选 require 档（供应商不支持时明确拒绝），本分面固定 prefer。",
	].join("");
}

/** 会话启动留档戳（I2 组合根用 appendEntry 固定工具面说明；本模块不写会话）。 */
export function taskFacetSurfaceStamp(): string {
	return `amagi-task-facets/v${TASK_FACET_SURFACE_VERSION}（${TASK_FACET_NAMES.join(",")}）`;
}

/** runBackgroundTask 返回分流：BackgroundStart（queued/running 句柄）与 RunResult（启动失败）在
 *  status 上重叠（TaskStatus 含 queued/running），TS 无法自动窄化——用显式判别（RunResult 终态不含此二者）。 */
function isBackgroundStart(s: BackgroundStart | RunResult): s is BackgroundStart {
	return s.status === "queued" || s.status === "running";
}

/** 路径等价判定（realpath 优先，resolve 兑底——macOS /var、/tmp 符号链接前缀差异；与 worktree.ts samePath 同语义的本地副本，避免新增反向依赖）。 */
function sameFacetPath(a: string, b: string): boolean {
	const rp = (p: string): string => { try { return fs.realpathSync(p); } catch { return path.resolve(p); } }; /* lint-exempt:realpath 失败退 resolve（与 worktree.ts samePath 同语义） */
	return rp(a) === rp(b);
}

// ── U5/F2（pi-099 D 片：diting F3/F2 实施）：task_query wire 载体脱敏 + 异常兜底带 wire ──

/** Failure wire 的 view 投影（§4.4）：合法三档字面原样；缺省（view 未传）summary；
 *  显式非法值 null（不 echo 任意原参数）。O3b 起为 execute 内局部函数，D 片提升为模块级
 *  供错误路径与异常兜底共用（行为零变化）。 */
function taskQueryWireViewOf(p: { view?: unknown }): TaskViewLevel | null {
	if (p.view === "summary" || p.view === "receipt" || p.view === "output") return p.view;
	return p.view === undefined ? "summary" : null;
}

/** F2（diting F2 → D 片；O3b §六登记缺口闭合）：task_query 异常兜底带 wire——正文与 adaptThrown
 *  完全同形状（internal-tool-error 契约块字节不变，I1 异常兜底断言同源），额外携带 Failure 分支
 *  structuredContent（contractErrorOfThrown 语义：code=internal-error、message=凭据脱敏后的错误
 *  摘录 ≤400 字符（不含原始 stack）、effects=unknown（副作用不可确认）、fields=[]、repairExamples=[]）。
 *  接线在分面兜底处而非 adapter 层（O3b 报告 §六方案：view 上下文 params 在 execute 签名内可达；
 *  guardedExecute/adaptThrown 通用路径不动——其它工具异常路径零影响，pi-099-d 测试深相等对照）。 */
async function guardedTaskQueryExecute(
	params: { view?: unknown },
	fn: () => Promise<FacetToolReturn>,
): Promise<FacetToolReturn> {
	try {
		return await fn();
	} catch (e) {
		const thrown: ContractError = {
			code: "internal-error",
			message: redactCredentials(`[task_query] 工具执行异常（已捕获，未上抛宿主）：${(e instanceof Error ? e.message : String(e)).slice(0, 400)}`),
			fields: [],
			effects: "unknown",
			repairExamples: [],
		};
		try {
			return { ...adaptThrown(e, "task_query"), structuredContent: toFailureWire(thrown, taskQueryWireViewOf(params)) };
		} catch { /* lint-exempt:兜底 wire 构造异常退回 adaptThrown——永不因兜底失败上抛宿主 */
			return adaptThrown(e, "task_query");
		}
	}
}

// ── 依赖注入面（组合根/测试装配；真实链为缺省实现） ─────────────────────────────

export interface TaskFacetServices {
	runTask: typeof runTask;
	runBackgroundTask: typeof runBackgroundTask;
	runResumeTask: typeof runResumeTask;
	decide: typeof decideTaskReceipt;
	resumeGroup: typeof resumeGroupAfterAcceptance;
	queryViews: typeof queryTaskViews;
	wait: typeof waitTasks;
	cancel: typeof cancelTask;
	resolveExternal: typeof resolveExternalTask;
	steer: typeof steerTask;
}

export interface TaskFacetsDeps {
	agents: AgentConfig[];
	/** 受信调用者上下文（组合根提供；模型参数不能构造——factory 创建时校验，非法即接线错误抛出）。 */
	caller: CallerContext;
	/** 完成通知通道（delivery=handle 的终态推送；缺省无通知只有 registry/查询可观察）。 */
	pi?: TaskCompletionSink;
	/** 测试注入（fake 子进程命令/确定性证据；生产不传）。 */
	testOpts?: { testCommand?: { command: string; args: string[] }; evidence?: (cwd: string) => Promise<string> };
	/** 服务覆写（默认真实链；测试注入抛错函数断言异常兜底）。 */
	services?: Partial<TaskFacetServices>;
}

/** 分面 execute 的宿主 ctx（与 legacy 工具同形状子集）。 */
interface FacetCtx {
	sessionManager?: DispatchContextSession;
	cwd: string;
	modelRegistry?: unknown;
	isProjectTrusted?: () => boolean;
}

// ── ev-20261031-7110a8：稳定面 model 参数小件（submit/resume 共用） ──────────────

/** 稳定面 model 参数归一（单 spec；字符串化 JSON 数组宽容恢复取首元素并披露——同 legacy ev-20260912-90c1ca 语义）。 */
function normalizeFacetModelParam(raw: unknown): { model?: string; notes: string[]; error?: string } {
	if (typeof raw !== "string" || !raw.trim()) return { notes: [] };
	const trimmed = raw.trim();
	const pa = parseStringifiedModelArray(trimmed);
	if (pa.kind === "invalid") return { notes: [], error: `${pa.error}——task_submit/task_resume 的 model 接受单个 "provider/model[:thinking]" spec 字符串` };
	if (pa.kind === "ok") return { model: pa.values[0]!, notes: [`[model] 字符串化数组已宽容恢复——稳定面 model 为单 spec，已取首元素 ${pa.values[0]}（需要降级链时请显式逐轮指定）`] };
	return { model: trimmed, notes: [] };
}

export interface FacetToolDefinition<P> {
	name: string;
	label: string;
	description: string;
	promptSnippet?: string;
	promptGuidelines?: string[];
	parameters: object;
	prepareArguments?: (args: unknown) => unknown;
	/** 宿主 0.83+ ToolDefinition.constrainedSampling（H3：prefer 档；宿主 wrapToolDefinition 原样转发到模型层）。 */
	constrainedSampling?: false | ConstrainedSamplingConfig;
	/** 宿主 ToolDefinition.annotations（O1/pi-0.99 机会批）：作者性用途提示（readOnly/destructive/idempotent/openWorld），
	 *  权限扩展可作确认参考、非校验事实；本面只对确证纯读的工具声明（task_query），不按工具名自动生成。 */
	annotations?: ToolAnnotations;
	/** O3b（pi-0.99 机会批 §4.7.2）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema：TSchema）。
	 *  声明后 execute 应始终携带 structuredContent（宿主文义；codemode 脚本面收到结构化值而非文本）。
	 *  仅 task_query 挂载（四分支 Union，含 error 分支）；其余分面缺省不带。 */
	outputSchema?: object;
	execute: (toolCallId: string, params: P, signal: AbortSignal | undefined, onUpdate: undefined, ctx: FacetCtx) => Promise<FacetToolReturn>;
}

// ── 校验小件 ──────────────────────────────────────────────────────────────────

/** err(...) → 失败返回的薄包装（err 返回 Result<never>，实际恒为失败分支；本面构造点经此收敛，附录正文供引擎失败根因上下文）。 */
const fail = (r: Result<never>, appendix?: string): FacetToolReturn => contractErrorReturn((r as { error: ContractError }).error, appendix);

/** 参数封闭规格：schema 外字段（含 legacy task 参数混用）整单拒绝（§4.2 不自动删字段后执行）。 */
function rejectUnknownParams(params: Record<string, unknown>, known: readonly string[]): ContractError | null {
	const unknown = Object.keys(params).filter((k) => !known.includes(k) && params[k] !== undefined);
	return unknown.length
		? (err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, `参数含未知字段 ${unknown.join(",")}（分面封闭规格；legacy task 编排参数不属于本工具面——最小合法调用见 repairExamples）`, [`params.${unknown[0]}`]) as { error: ContractError }).error
		: null;
}

/** 契约校验错误补最小合法调用样例（验证器不携带 repairExamples——工具面统一补）。 */
function withRepair(e: Readonly<ContractError>, repairExamples: readonly object[]): ContractError {
	return { code: e.code, message: e.message, fields: [...e.fields], effects: e.effects, repairExamples };
}

// ── D2（ev-20260922-727096）：恢复指引单源接线（稳定面）────────────────────────

/** 终态事实（RunResult 兑底 + registry 权威覆盖）→ 稳定面恢复指引文本。
 *  判断/文案单源在 reliability.recoveryActionOf/renderRecoveryAdvice；本装配优先读 registry 当前
 *  记录（通知/返回均在 finalize 后计算，记录已定格；迟到旧进程事件由 finalizer 幂等/stale 防护拦下），
 *  无记录时兑底 RunResult 事实。只作描述性建议——错误回执仍保持 error coverage 缺口。
 *  ev-20261031-7110a8：quota 类建议经 recoveryActionOfRecord 装配换模候选（modelRegistry 由调用方
 *  透传，缺席时候选诚实标注未探测）。 */
function stableRecoveryNoteOf(facts: {
	taskId: string; status?: string; errorMessage?: string; spawnError?: string; stopReason?: string;
	sessionId?: string; timedOut?: boolean; aborted?: boolean; model?: string; cwd?: string;
}, opts?: { modelRegistry?: unknown }): string | undefined {
	const rec = registry.get(facts.taskId);
	if (rec) return renderRecoveryAdvice(recoveryActionOfRecord(rec, { spawnError: facts.spawnError, modelRegistry: opts?.modelRegistry }), { surfaceVersion: TASK_FACET_SURFACE_VERSION });
	if (facts.status === undefined) return undefined;
	const action: RecoveryAction | undefined = recoveryActionOf({
		taskId: facts.taskId,
		status: facts.status,
		errorMessage: facts.errorMessage,
		spawnError: facts.spawnError,
		stopReason: facts.stopReason,
		userAborted: facts.aborted === true,
		timedOut: facts.timedOut === true,
		processExited: true, // wait 返回/完成通知均在 finalize（close 已达）后计算
		sessionId: facts.sessionId,
		cwdAvailable: facts.cwd ? fs.existsSync(facts.cwd) : true, // diting F6：有 cwd 实查（与 task-resume recoveryActionOfRecord 同口径），无 cwd 可查时按已知事实声明
		model: facts.model,
	});
	return renderRecoveryAdvice(action, { surfaceVersion: TASK_FACET_SURFACE_VERSION });
}

/** 句柄解析（wait/cancel/resolve-external/steer/accept 共用）：歧义/未知在任何动作前整单拒绝。
 *  ev-20260930-2b34b2（R4b）：未解析句柄在整单拒绝前精确探测组身份（getGroup 精确命中 + registry
 *  runId 扫描），误用组句柄给出当前真实可执行去向（节点 taskId / accept 续跑 / task_query），消除首次
 *  试错。正常解析（完整 taskId/唯一前缀/name/runId/name）与歧义路径零变化（歧义仍返回完整候选清单，
 *  不另查组抢占身份）；拒绝语义不变：仍 unknown-handle + effects=none，不实现组控制语义。 */
async function resolveControlHandles(handles: readonly string[], action: string, ownerId?: string): Promise<Result<readonly string[]>> {
	const ids: string[] = [];
	for (const h of handles) {
		let resolved: { taskId: string } | undefined;
		try {
			resolved = registry.resolveSession(h);
		} catch (e) {
			return err("ambiguous-handle", `句柄 "${h}" 命中多条记录（歧义）：${e instanceof Error ? e.message : String(e)}`, ["handles"], "none", [{ handles: ["<完整 taskId（歧义候选其一）>"] }]);
		}
		if (!resolved && (action === "accept" || action === "reject")) {
			const stored = await resolveStoredTaskHandle(h, ownerId);
			if (!stored.ok) return stored;
			if (stored.value) resolved = { taskId: stored.value.run.taskId };
		}
		if (!resolved) {
			// ev-20261021-a8de95：registry 未持有但契约存储有记录（跨重启/跨会话残留）——如实声明
			// historical 状态、owner 与真实可用动作（reconcile），不再给「registry 无记录」的误导结论。
			const storedNote = action === "accept" || action === "reject" ? undefined : await describeStoredControlTarget(h, action, ownerId);
			if (storedNote) {
				return err("historical-task", storedNote, ["handles"], "none", [{ action: "reconcile", handles: [h], reason: "<可追溯理由>" }]);
			}
			const probe = probeGroupHandle(h);
			if (probe) {
				const { advice, repair } = groupHandleGuidance(h, action, probe);
				return err("unknown-handle", `未找到任务 "${h}"（registry 无记录——句柄须为 taskId/sessionId 前缀、稳定 name 或 runId/name）。${advice}`, ["handles"], "none", repair);
			}
			return err("unknown-handle", `未找到任务 "${h}"（registry 无记录——句柄须为 taskId/sessionId 前缀、稳定 name 或 runId/name）`, ["handles"], "none", [{ handles: ["<task_submit 返回的 taskId>"] }]);
		}
		ids.push(resolved.taskId);
	}
	return ok(ids);
}

// ── ev-20260930-2b34b2（R4b）：unknown-handle 对组句柄的专属引导（§⑥ 第 2~7 条）────────

/** 严格批次组句柄形态（tool-surface.ts `batch-${randomUUID().slice(0,8)}`——batch- + 8 位十六进制）。
 *  仅用于保守形态提示：匹配不证明类型/存在性（稳定 name 可同名、历史组可陈旧），不用于控制或选
 *  任务；orch- 旧模板组不在此形态内——组身份只能经 getGroup 精确判定（§⑥ 第 4 条）。 */
const BATCH_GROUP_ID_RE = /^batch-[0-9a-f]{8}$/;

/** 组句柄引导所需的最少节点事实（已有完整节点 taskId；未启动节点只列 nodeId，不编造 taskId）。 */
interface GroupHandleNodes {
	/** 已有完整 taskId 的节点（nodeId → 真实 taskId）。 */
	started: ReadonlyArray<{ nodeId: string; taskId: string }>;
	/** 组内已声明但未启动的节点 nodeId（无 taskId，如实列出不编造）。 */
	pending: readonly string[];
}

/** 未解析句柄的组探测（只读，不改任何状态）三分档：
 *  - group：getGroup(h) 精确命中（orch- 旧模板与 batch- 批次共用 groups 表——身份判定不靠形态猜测）；
 *  - run-nodes-only：无活跃组记录但 registry 存在 runId===h 节点（组已终局收口或跨会话不可见）；
 *  - batch-shaped：两者皆无且严格匹配批次形态——仅保守提示，不构成身份断言；
 *  - null：无组相关材料（保持通用诊断）。 */
function probeGroupHandle(h: string): {
	kind: "group" | "run-nodes-only" | "batch-shaped";
	nodes: GroupHandleNodes;
	paused?: boolean;
	done?: boolean;
} | null {
	const g = getGroup(h);
	if (g.found) {
		const started = g.nodeStats.flatMap((n) => (typeof n.taskId === "string" ? [{ nodeId: n.nodeId, taskId: n.taskId }] : []));
		const pending = g.nodeStats.flatMap((n) => (typeof n.taskId === "string" ? [] : [n.nodeId]));
		return { kind: "group", nodes: { started, pending }, ...(g.paused ? { paused: true } : {}), ...(g.done ? { done: true } : {}) };
	}
	const runNodes = registry.list().filter((r) => r.runId === h);
	if (runNodes.length > 0) {
		return { kind: "run-nodes-only", nodes: { started: runNodes.map((r) => ({ nodeId: r.nodeId ?? r.taskId, taskId: r.taskId })), pending: [] } };
	}
	if (BATCH_GROUP_ID_RE.test(h)) return { kind: "batch-shaped", nodes: { started: [], pending: [] } };
	return null;
}

/** 组句柄误用的专属引导（§⑥ 第 5/6 条）：wait 给「节点/组终局自动通知，无需对组 wait」去向；非 wait
 *  同样说明组不是可控制的契约任务，但不给「不用 wait」的无关主提示；暂停组给可执行去向（对上游节点
 *  回执 accept 后自动续跑——不说「什么都不必做」）。repairExamples 保持合法 task_control 调用（§⑥
 *  第 7 条）：存在节点时填真实完整 taskId；无节点 id 给明确占位说明（不被误当真实 id）+ task_query 查询引导。 */
function groupHandleGuidance(h: string, action: string, probe: NonNullable<ReturnType<typeof probeGroupHandle>>): { advice: string; repair: readonly object[] } {
	const idList = probe.nodes.started.length > 0
		? `已有节点 taskId（最多列 3 个）: ${probe.nodes.started.slice(0, 3).map((n) => `${n.nodeId}=${n.taskId}`).join("、")}${probe.nodes.pending.length > 0 ? `；另有 ${probe.nodes.pending.length} 个节点未启动（无 taskId）: ${probe.nodes.pending.join("、")}` : ""}`
		: probe.nodes.pending.length > 0
			? `组内 ${probe.nodes.pending.length} 个节点均未启动（暂无节点 taskId）: ${probe.nodes.pending.join("、")}`
			: "";
	const firstTaskId = probe.nodes.started[0]?.taskId;
	const repair = firstTaskId !== undefined
		? controlRepairExamples(action, { handle: firstTaskId })
		: [...controlRepairExamples(action, { handle: "<节点 taskId（组内已启动节点——见正文或 task_query 查询）>" }), { hint: "列出任务与句柄：task_query({ view: 'summary' })" }];
	if (probe.kind === "group") {
		const pausedNote = probe.paused === true ? "；组现暂停等待人工接受（requires=accepted 边）——对上游节点回执 task_control accept 后组自动续跑" : "";
		if (action === "wait") {
			return {
				advice: `"${h}" 是组句柄（orchestrate/task_batch 的 runId）——不是契约任务的 taskId，wait 不接受组句柄：批次节点逐个终态自动通知、组终局自动通知，无需对组 wait；单节点控制/查询用该节点 taskId${probe.done === true ? "；该组已终局（组终局通知已发）" : ""}${pausedNote}${idList ? `。${idList}` : ""}`,
				repair,
			};
		}
		return {
			advice: `"${h}" 是组句柄（orchestrate/task_batch 的 runId）——组不是可控制的契约任务，"${action}" 不接受组句柄；对单节点操作用该节点 taskId${pausedNote}${idList ? `。${idList}` : ""}`,
			repair,
		};
	}
	if (probe.kind === "run-nodes-only") {
		return {
			advice: `registry 存在 runId="${h}" 的节点记录，当前无活跃组记录（组已终局收口或跨会话不可见）——组句柄不能用于节点控制，请改用节点 taskId；本 runId 不再承诺组自动通知${idList ? `。${idList}` : ""}`,
			repair,
		};
	}
	return {
		advice: `"${h}" 形似批次组句柄（batch- + 8 位十六进制）但当前组未找到（无活跃组记录、无该 runId 节点）——形态匹配不证明组存在；列出当前任务用 task_query({ view: "summary" })`,
		repair,
	};
}

/** 回执归档只读展开（receipt 档：checks/outputs 来自归档回执 JSON；读失败如实标注不臆造）。 */
function readReceiptArchive(refPath: string): { checks?: unknown[]; outputs?: unknown[] } | null {
	try {
		const abs = path.isAbsolute(refPath) ? refPath : path.join(contractStoreRoot(), refPath);
		const raw: unknown = JSON.parse(fs.readFileSync(abs, "utf8"));
		return raw && typeof raw === "object" ? raw as { checks?: unknown[]; outputs?: unknown[] } : null;
	} catch {
		return null;
	}
}

/** ev-20261108-m3（diting 审 m3）：从回执归档 ref 派生「自动基线探测级环境缺口降级」事实
 *  （判据单源 baselineEnvGapOf；ref 缺失/读失败/无降级 → null）。只读，不种子内核、不改变三轴——
 *  accept 返回附注与 [待接受] 提示共用（task_query 渲染处用页内 single-read 缓存另行取 checks）。 */
function baselineEnvGapOfView(receipt: Readonly<{ ref?: { path?: unknown } }> | undefined): BaselineEnvGapFact | null {
	const refPath = typeof receipt?.ref?.path === "string" ? receipt.ref.path : undefined;
	return refPath ? baselineEnvGapOf(readReceiptArchive(refPath)?.checks) : null;
}

// ── task_submit ───────────────────────────────────────────────────────────────

interface SubmitParams extends DispatchContextRequest {
	agent: string;
	task?: string;
	taskFile?: string;
	delivery?: "wait" | "handle";
	inputs?: DispatchInput[];
	outputs?: DispatchOutput[];
	inputPaths?: string[];
	outputPaths?: string[];
	scope?: {
		read?: string[]; write?: string[]; deny?: string[]; reportFiles?: string[];
		shell?: "deny" | "guarded" | "optional"; mcp?: string[];
		lsp?: Array<"diagnostics" | "definition" | "references" | "hover" | "rename">;
		/** B5A：codemode 只读受控请求面（仅 "read-only"；必需通道——交集任一缺口整单拒绝）。 */
		codemode?: "read-only";
		advisor?: "consult";
	};
	workspace?: { cwd?: string; mode?: "existing" | "worktree"; worktreeName?: string; dependencyVisibility?: "portable" | "main-tree" | "unknown"; base?: "head" | "dirty-snapshot" };
	profile?: string;
	/** ev-20261031-7110a8：本次派发临时模型覆盖（单 spec；沿既有解析/归一/冻结链，不改配置不扩权）。 */
	model?: string;
	/** ev-20260919（P2-4）：预检模式——全量校验不 spawn 不入队。 */
	dryRun?: boolean;
}

const SUBMIT_MINIMAL_EXAMPLES: readonly object[] = [
	{ agent: "<角色名>", task: "任务书正文（目标/边界/验收）" },
	{ agent: "<角色名>", taskFile: "docs/task.md", delivery: "handle" },
];

/** pi 1.1 strict 子集不接受 object Union：模型面提供字符串数组快捷字段，预处理提升为完整对象。
 *  直接 inputs/outputs 字符串简写也在此提升；坏组合保留，执行点明确拒绝，不丢字段后执行。 */
function prepareSubmitArguments(args: unknown): unknown {
	return prepareDispatchArguments(args);
}

function statusLabelOf(res: Readonly<RunResult>): string {
	if (res.blocked) return "blocked";
	if (res.status === "truncated") return "truncated（输出截断，非失败）";
	return res.status;
}

// ── ev-20260924-3b5444：验证要求∩shell 通道缺口防呆（纯函数，警告不阻断） ─────────

/** 验证命令特征（保守白名单）：npm/npx/pnpm/yarn/bun/go/node --test/cargo/pytest/gradle/mvn 等
 *  常见安装/测试/构建/类型检查形态。命中≠阻断——只提示 Leader 补 shell 通道或注明代验；
 *  冷门命令（如 make check）宁可漏提示不误报（见 shellVerificationGapHint）。 */
const SHELL_VERIFICATION_COMMAND_PATTERNS: readonly RegExp[] = [
	/\bnpm\s+(?:install|ci|run|test|exec|--prefix)\b/, // npm install/ci/run/test/exec/--prefix（tsc/vitest 多经 npm run 触发）
	/\bnpx\s+(?:vitest|tsc|tsx|vite|jest|mocha|playwright|cypress|eslint|prettier|turbo|nx|next|webpack|rollup|esbuild)\b/,
	/\b(?:pnpm|yarn|bun)\s+(?:install|ci|run|test|build)\b/,
	/\bgo\s+(?:test|build|vet)\b/,
	/\bnode\s+--test\b/,
	/\bcargo\s+(?:test|build|check|clippy)\b/,
	/\b(?:python\s+-m\s+)?pytest\b/,
	/\b(?:gradle|gradlew|mvn)\s+(?:test|verify)\b/,
	/\bdotnet\s+test\b/,
	/\bdeno\s+(?:test|lint)\b/,
	/\bgit\s+diff\b/,
];

/** 任务书正文是否含验证命令形态：命中返回首个匹配串（供提示引用原文），否则 null。纯函数可测。
 *  两层召回（ev-20261012-80be52）：①命令字面量层（上述白名单）；②验证执行语义层（散文形态）——
 *  实战（任务框架对齐八阶段 P1 faf09e27）任务书只写「自验+跑六组验证命令」无命令字面量，
 *  ①层零命中 → 缺口提示不亮 → 子进程无命令通道静默降级、验证全部转嫁 Leader（+4~5 轮）。
 *  ②层保守集合：自验/自行验证；（跑|运行|执行）＋短距（测试|验证|用例）；（全量|回归|全部）（测试|验证）。
 *  边界：仅提及验证概念而无执行动词（如「不能代替目标行为验证」「整理测试用例文档」「分析测试
 *  失败根因」）不命中——宁可漏提示不误报的口径不变；命中≠阻断，语义与命令层一致。 */
/** 语义层召回（ev-20261012-80be52）：命令层未命中再查散文形态——实战任务书只写「自验+跑六组
 *  验证命令」无命令字面量，①层零命中 → 缺口提示不亮 → 子进程无命令通道静默降级（+4~5 轮）。
 *  保守集合：自验/自行验证；（跑|运行|执行）＋短距（测试|验证|用例）；（全量|回归|全部）（测试|验证）。
 *  ev-20261012-0f097a（B6③）：语义与命令两层命中统一过语境过滤（否定句/被调查对象不命中）。 */
const SHELL_VERIFICATION_SEMANTIC_PATTERNS: readonly RegExp[] = [
	/自验|自行验证/,
	/(?:跑|运行|执行)[^，。；、\n]{0,12}?(?:测试|验证|用例)/,
	/(?:全量|回归|全部)(?:测试|验证)/,
	/实测/,
];

/** 子句切分标点（中英文逗号/分号/句号/顿号/感叹问号/换行）——语境排除的最小判定单元：
 *  触发词所在子句的否定/对象语境只豁免该子句，不放大到整篇任务书。 */
const SENTENCE_SPLIT_RE = /[，。；、！？!?,;\n]/;
/** 否定语境：否定词后短距内跟执行动词/自验触发词——「不运行任何测试」「无需自验」。
 *  动词集不含测试/验证/用例等名词性触发词：防「运行测试确保不遗漏用例」类真验证要求被误排除。 */
const NEGATED_EXECUTION_RE = /(?:无需|无须|禁止|不得|不会|不能|不|别|未)[^，。；、！？!?,;\n]{0,6}?(?:跑|运行|执行|自验|实测|git\s+diff)/;
/** 对象语境认知动词：触发词是其宾语（被说明/分析/调查的内容），不是执行要求。 */
const OBJECT_CONTEXT_VERBS_RE = /说明|分析|调查|解释|讲解|研究|调研/;

/** 触发词命中所在子句是否为真实执行要求（0f097a 语境排除：否定句与被调查对象不命中）。
 *  两级排除（都在命中所在子句内判，宁可漏提示不误报）：
 *  ① 否定语境：否定词＋短距执行动词（不/无需/禁止/不得/不会/别/未）；
 *  ② 对象语境：认知动词（说明/分析/调查…）位于命中之前且之间无执行动词——触发词是被调查对象。 */
function verificationHitInExecutionContext(text: string, hitIndex: number): boolean {
	let start = 0;
	for (let i = hitIndex - 1; i >= 0; i--) {
		if (SENTENCE_SPLIT_RE.test(text[i]!)) { start = i + 1; break; }
	}
	let end = text.length;
	for (let i = hitIndex; i < text.length; i++) {
		if (SENTENCE_SPLIT_RE.test(text[i]!)) { end = i; break; }
	}
	const clause = text.slice(start, end);
	if (NEGATED_EXECUTION_RE.test(clause)) return false;
	const hitRel = hitIndex - start;
	for (const m of clause.matchAll(new RegExp(OBJECT_CONTEXT_VERBS_RE.source, "g"))) {
		const verbIndex = m.index ?? 0;
		if (verbIndex < hitRel && !/(?:跑|运行|执行)/.test(clause.slice(verbIndex, hitRel))) return false;
	}
	return true;
}

export function matchAssignmentVerificationCommand(assignment: string): string | null {
	if (typeof assignment !== "string" || !assignment) return null;
	for (const re of [...SHELL_VERIFICATION_COMMAND_PATTERNS, ...SHELL_VERIFICATION_SEMANTIC_PATTERNS]) {
		const global = new RegExp(re.source, re.flags.includes("g") ? re.flags : `${re.flags}g`);
		for (let m = global.exec(assignment); m; m = global.exec(assignment)) {
			if (m[0].length === 0) { global.lastIndex++; continue; }
			if (verificationHitInExecutionContext(assignment, m.index)) return m[0];
		}
	}
	return null;
}

/** ev-20261012-0f097a（B6③）：免责出口单源——提示文案推荐的免责写法与判定识别的形态共用同一
 *  常量（防漂移：文案教 Leader 写什么，判定就识别什么）。结构化免责行（独立成行）＋文案旧推荐
 *  短语（句内）双形态：文案历史上推荐「验证由 Leader 代跑」，该短语继续有效。 */
export const SHELL_VERIFICATION_WAIVERS: ReadonlyArray<{ re: RegExp; sample: string }> = [
	{ re: /(^|\n)[ \t]*验证[ \t]*[:：][ \t]*Leader[ \t]*代跑[ \t]*(?=\n|$)/, sample: "验证: Leader 代跑" },
	{ re: /(^|\n)[ \t]*无需子进程验证[ \t]*(?=\n|$)/, sample: "无需子进程验证" },
	{ re: /验证由[ \t]*Leader[ \t]*代跑/, sample: "验证由 Leader 代跑" },
];

/** 任务书含约定免责声明 → Leader 已明确接手验证，缺口提示不再出现（出口可达）。 */
export function assignmentHasVerificationWaiver(assignment: string): boolean {
	return SHELL_VERIFICATION_WAIVERS.some((w) => w.re.test(assignment));
}

/** ev-20261031-1e0a8f：隐式 shell 需求归一化——scope.shell 缺省且任务书含验证执行要求时自动按
 *  optional 请求（识别面与 shellVerificationGapHint 单源：命令/语义两层召回＋语境过滤＋免责出口）。
 *  显式值（deny/guarded/optional）一律不动；任务书验证命令视为隐式 shell 需求声明。optional
 *  交集空自动降级 deny 是既有机制（ev-20260930-c703e3，零新拒单），降级分支提示文案由
 *  shellVerificationGapHint 的 autoInferred 形态改写。 */
export function inferImplicitShellRequest(
	assignment: string,
	scopeShell: "deny" | "guarded" | "optional" | undefined,
): "optional" | undefined {
	if (scopeShell !== undefined) return undefined;
	if (assignmentHasVerificationWaiver(assignment)) return undefined;
	return matchAssignmentVerificationCommand(assignment) !== null ? "optional" : undefined;
}

/** 验证要求∩shell 通道缺口提示（ev-20260924-3b5444：两个 luban 切片任务书要求 npm install/tsc/
 *  vitest/build 验证但派发未申请 shell 通道 → 子进程无 bash → 代码全部落盘后在自验处 blocked，
 *  Leader 被迫代跑 12+ 次命令并 resume×2 收口）。判定面是**求值后授予面** grantedShell（ev-20260930-c703e3：
 *  scope.shell 新增 optional 三态后，请求面不再等价于授予事实——optional 交集全过=有 bash 无缺口，
 *  optional 降级 deny=无 bash 照常提示）；guarded 请求被拒不会到达本函数（已整单拒）。
 *  ev-20261031-1e0a8f：第四参 autoInferred——scope.shell 由 inferImplicitShellRequest 自动注入后
 *  交集仍空降级 deny 时，原文案「可用 optional」出口已失效（已是 optional），改指 guarded 请求/换
 *  角色/代验出口。返回提示行文本或 undefined；只警告不阻断——Leader 可能确实计划代验。 */
export function shellVerificationGapHint(
	assignment: string,
	grantedShell: ShellPolicy | undefined,
	requestedShell?: "deny" | "guarded" | "optional",
	autoInferred?: boolean,
): string | undefined {
	if (grantedShell === "guarded") return undefined;
	// ev-20261012-0f097a（B6③）：文案承诺的出口在判定中可达——①结构化免责行/免责短语（与文案
	// 共用 SHELL_VERIFICATION_WAIVERS 常量）→ Leader 已明确接手验证；②请求面显式 scope.shell=
	// 'deny'（Leader 主动选择无 shell）——区别于角色上限缺省降级的 deny（未请求≠明确选择，保持提示）。
	if (assignmentHasVerificationWaiver(assignment)) return undefined;
	if (requestedShell === "deny") return undefined;
	const hit = matchAssignmentVerificationCommand(assignment);
	if (!hit) return undefined;
	if (autoInferred) {
		return `[派发提示] 任务书含验证执行要求（${hit}）——已自动按 optional 请求但交集为空降级 shell=deny，子进程将无法自验；确需自验请显式 scope.shell="guarded"（可 guarded 角色）或改派具备 shell 通道的角色；计划代验请显式 scope.shell="deny" 或在任务书独立一行注明「${SHELL_VERIFICATION_WAIVERS[0]!.sample}」`;
	}
	return `[派发提示] 任务书含验证执行要求（${hit}）但子进程未获 shell 通道（授予 shell=${grantedShell ?? "deny"}）——子进程将无法自验；请申请 guarded 通道（非必需可用 optional）、在任务书独立一行注明「${SHELL_VERIFICATION_WAIVERS[0]!.sample}」，或显式 scope.shell="deny" 声明代验（被否定/仅调查提及的验证词不触发本提示）`;
}

/** 仅在终态明确指出工具/权限缺失时提示新派；普通问题仍续接答复。 */
function resumePermissionGap(text: string): "shell" | "other" | undefined {
	const prose = text.replace(/```[\s\S]*?```/g, " ")
		.replace(/`(shell|bash|mcp|lsp|tool|permission)`/gi, "$1")
		.replace(/`[^`\n]*`|“[^”\n]*”|‘[^’\n]*’|"[^"\n]*"|'[^'\n]*'/g, " ");
	for (const clause of prose.split(/[\n。；;，,]/)) {
		if (/(?:不缺(?:少|失)?|无需|不是|非|不涉及)(?:任何)?\s*(?:工具|权限|shell|bash)(?:方面的?)?(?:问题|故障|限制)?/i.test(clause)
			|| /(?:无|没有|不存在)(?:任何)?\s*(?:工具|权限|shell|bash)(?:方面的?)?(?:问题|故障|限制)/i.test(clause)) continue;
		const shell = /\b(?:shell|bash)\b|命令(?:执行)?工具/i;
		const other = /权限|工具(?:面|通道)?|\b(?:tool|permission|mcp|lsp)\b/i;
		const missingBefore = /(?:缺少|缺失|未获|未提供|未挂载|不具备|没有|无|missing|denied|请实际挂载)\s*(?:(?:所需|必要的?|任何|使用|执行)\s*)?(?:shell|bash|命令(?:执行)?工具|权限|工具(?:面|通道)?|tool|permission|mcp|lsp)(?=$|[\s，,。；;:：]|工具|通道|权限|执行工具)/i;
		const missingAfter = /(?:shell|bash|命令(?:执行)?工具|权限|工具(?:面|通道)?|tool|permission|mcp|lsp)\s*(?:工具|通道|权限|执行工具)?\s*(?:未获|未提供|未挂载|缺失|缺少|不可用|无法使用|不足|被拒绝|not available|missing|denied|unavailable)/i;
		const gap = missingBefore.exec(clause) ?? missingAfter.exec(clause);
		if (!gap || /\b(?:not|never)\s*$/i.test(clause.slice(0, gap.index))) continue;
		if (shell.test(gap[0])) return "shell";
		if (other.test(gap[0])) return "other";
	}
	return undefined;
}

function resumePermissionExample(agent: string, gap: "shell" | "other"): object {
	return { agent, task: "承接原 artifact（填入路径），继续未完成工作；核对已完成写入与副作用", scope: gap === "shell" ? { shell: "guarded" } : { read: ["<原 artifact 路径>"], write: ["<所需写入范围>"] } };
}
function resumePermissionAdvice(agent: string, gap: "shell" | "other"): string {
	return `\n\n【工具/权限出口】resume 继承原授权，不能扩权。核对已有产物与副作用后，请新派 task_submit 并按实际需要声明 scope；示例（替换占位路径并核对角色上限）：task_submit(${JSON.stringify(resumePermissionExample(agent, gap))})`;
}

// ── task_control ──────────────────────────────────────────────────────────────

interface ControlParams {
	action: "wait" | "cancel" | "resolve-external" | "steer" | "accept" | "reject" | "reconcile";
	handles?: string[];
	handle?: string;
	mode?: "any" | "all";
	timeoutMs?: number;
	reason?: string;
	message?: string;
	receiptId?: string;
	expectedRevision?: number;
	waivedCheckIds?: string[];
}

interface ResumeParams { handle: string; message: string; delivery?: "wait" | "handle"; model?: string }

/** ev-20261017-589e6d：task_control 结果 details 单源——单句柄取内核当前视图（与正文同时刻；视图缺位
 *  如实 null），多句柄显式 scope=multi。此前 wait/steer/cancel 手写全 null 块，details 行恒
 *  revision=? execution=?，与正文及随后 task_query 的 revision=0 execution=done 矛盾。
 *  nextActions 传入即覆盖（wait 超时的「继续 wait 或 cancel」是本次控制动作的下一步）。 */
/** wait 的 blocked 待答问题渲染——逐层兜底（ev-20261105-b0ca1a）：结构化问题缺失时不再只给
 *  「未记录结构化问题」查询指引（问题正文曾要等完成通知才可见）：①旧记录重提取（修复前落库的
 *  标记变体形态）；②终稿 BLOCKED marker/STATUS 行之后的有界正文摘要（≤1500 字符，截断处标注并
 *  以 task_query 回源）；③两层均不可得才回到查询指引。needs-handoff 分支不经此函数（语义不变）。 */
const WAIT_BLOCKED_EXCERPT_CAP = 1500;
function blockedQuestionsTextForWait(rec: Readonly<{ blockedQuestions?: string[]; result?: string }> | undefined): string {
	const recorded = rec?.blockedQuestions;
	if (recorded?.length) return recorded.map((q, i) => `${i + 1}. ${q}`).join("\n");
	const result = typeof rec?.result === "string" ? rec.result : "";
	if (result) {
		const reextracted = extractBlockedQuestions(result);
		if (reextracted?.length) return reextracted.map((q, i) => `${i + 1}. ${q}`).join("\n");
	}
	const marker = "<!--AMAGI:BLOCKED-->";
	const at = result.lastIndexOf(marker);
	let body = at >= 0 ? result.slice(at + marker.length) : result;
	body = body.replace(/^\s*STATUS[ \t]*[：:][^\n]*\n?/i, "").trim();
	if (!body) return "（未记录结构化问题；task_query output 查看本轮终稿）";
	const chars = Array.from(body);
	return chars.length > WAIT_BLOCKED_EXCERPT_CAP
		? `${chars.slice(0, WAIT_BLOCKED_EXCERPT_CAP).join("")}…（已截断；完整终稿经 task_query({ view: "output" }) 查看）`
		: body;
}

function singleOrMultiDetails(surfaceVersion: number, taskIds: readonly string[], nextActions?: readonly string[]) {
	if (taskIds.length !== 1) return aggregateDetailsBlock(surfaceVersion, "multi", nextActions ?? []);
	const block = detailsBlockOf(peekTaskKernel()?.get(taskIds[0]!), surfaceVersion, taskIds[0]);
	return nextActions ? { ...block, nextActions } : block;
}

function controlRepairExamples(action: unknown, known: { handle?: string; receiptId?: string; expectedRevision?: number }): readonly object[] {
	if (action === "accept" || action === "reject") {
		return [
			{ action, handle: known.handle ?? "<taskId>", receiptId: known.receiptId ?? "<当前回执 receiptId>", expectedRevision: known.expectedRevision ?? "<当前 revision>", reason: "<接受/拒绝理由>" },
			{ action: "wait", handles: [known.handle ?? "<taskId>"], mode: "all", timeoutMs: 5000 },
		];
	}
	if (action === "wait") return [{ action: "wait", handles: [known.handle ?? "<taskId>"], mode: "all", timeoutMs: 30000 }];
	if (action === "reconcile") return [{ action: "reconcile", handles: [known.handle ?? "<taskId>"], reason: "<可追溯理由>" }];
	if (action === "steer") return [{ action: "steer", handle: known.handle ?? "<taskId>", message: "<运行中调整指令（任务书边界不变，按此修正方向继续）>" }];
	return [{ action: action === "cancel" ? "cancel" : "resolve-external", handles: ["<taskId>"], reason: "<可追溯理由>" }];
}

// ── 分面工厂 ─────────────────────────────────────────────────────────────────

/**
 * 创建四个稳定分面工具（注册就绪；I2 组合根 registerTool 消费）。
 * CallerContext 非法即抛（组合根接线错误，不是模型可修复错误）。
 */
export function createTaskFacets(deps: TaskFacetsDeps): {
	taskSubmit: FacetToolDefinition<SubmitParams>;
	taskResume: FacetToolDefinition<ResumeParams>;
	taskControl: FacetToolDefinition<ControlParams>;
	taskQuery: FacetToolDefinition<{ handle?: string; view?: "summary" | "receipt" | "output"; cursor?: string; limit?: number }>;
	surfaceVersion: number;
} {
	const callerCheck = validateCallerContext(deps.caller);
	if (!callerCheck.ok) {
		throw new Error(`[task-facets] CallerContext 非法（组合根接线错误；CallerContext 不能从模型参数构造）：${callerCheck.error.message}`);
	}
	const surfaceVersion = TASK_FACET_SURFACE_VERSION; // 注册时刻定格（会话固定工具面）
	const notifiedTasks = new Set<string>();
	// ev-20261101-cbf452：wait 已交付终态的任务集（LRU 上限 256）——handle 交付的完成通知在 wait 已消费
	// 终态后只发摘要+可回源 artifact+内核视图，不再重复整段报告全文（evidence：4/4 次通知在 wait 返回
	// done 之后重复全文）；未消费（从未 wait / 超时未决 / blocked / artifact 不可回源）保留完整可用交付。
	const waitConsumedTerminal = new Set<string>();
	const noteWaitConsumed = (taskId: string): void => {
		waitConsumedTerminal.delete(taskId);
		waitConsumedTerminal.add(taskId);
		if (waitConsumedTerminal.size > 256) waitConsumedTerminal.delete(waitConsumedTerminal.keys().next().value!);
	};
	/** 摘要适用：执行轴终态（blocked 是可 resume 中间态，通知需完整交付；cancelled/resolved-external
	 * 由 Leader 主动触发，正文短且含取消原因，保留全文）。 */
	const waitSummarizable = (r: Readonly<{ status: string; blocked: boolean }>): boolean =>
		!r.blocked && (r.status === "done" || r.status === "error" || r.status === "truncated" || r.status === "answered");
	const waitTimeouts = new Map<string, number>();
	const shownWaitAdvice = new Set<string>();
	const baselineHints = new Map<string, string>();
	const baselineHint = (cwd: string, trusted: boolean, dryRun: boolean, sessionId = "default"): string => {
		let full: string;
		try { full = describeBaselinePreflight(cwd, trusted); }
		catch (e) { full = `[验证预检] 诊断失败，执行性未知：${e instanceof Error ? e.message : String(e)}；以最终回执为准。`; }
		if (dryRun) return full;
		const key = JSON.stringify([sessionId, cwd]);
		const previous = baselineHints.get(key);
		if (!baselineHints.has(key) && baselineHints.size >= 128) baselineHints.delete(baselineHints.keys().next().value!);
		baselineHints.set(key, full);
		if (previous !== full) return full;
		// ev-20261101-cbf452：同项目未变时压为一行（旧版保留 5 行 essentials，8 次派发仍逐字重复）；
		// 首行携带入口/来源/runner 解析关键事实，其余见首次预检；预检文本变化（真实新警告/预算/入口变化）
		// 时上方分支已返回全文，新警告不会被折叠遮盖。
		const head = (full.split("\n")[0] ?? "").replace(/^\[验证预检\]\s*/, "");
		return `[验证预检] 同一项目较上次预检未变（${head}）；详细配置见首次预检；捕获/依赖/runner 运行时仍为 unknown，最终以回执为准。`;
	};
	const svc: TaskFacetServices = {
		runTask, runBackgroundTask, runResumeTask,
		decide: decideTaskReceipt, resumeGroup: resumeGroupAfterAcceptance,
		queryViews: queryTaskViews, wait: waitTasks,
		cancel: cancelTask, resolveExternal: resolveExternalTask,
		steer: steerTask,
		...deps.services,
	};
	// ev-20261028-b3ba43：待接受提醒——本会话已结束且有回执、尚无 accept/reject 决策的任务，在后续任务工具返回里
	// 附一行可直接复制的 accept 调用（事故：模型写了「验收」却只发了 task_submit，2.5h 后才偶然发现）。
	// 非阻断；每任务至多提醒 PENDING_REMINDER_CAP 次（有意延后不被反复打扰）。
	const pendingReminders = new Map<string, number>();
	const pendingAcceptanceNote = (exclude: readonly string[] = []): string => {
		let pending: ReturnType<typeof listPendingAcceptance>;
		try { pending = listPendingAcceptance(); } catch { return ""; }
		const skip = new Set(exclude);
		const due = pending.filter((p) => !skip.has(p.taskId) && (pendingReminders.get(p.taskId) ?? 0) < PENDING_REMINDER_CAP);
		if (due.length === 0) return "";
		const shown = due.slice(0, 3);
		// 只给实际展示的项计数——未展示项保留配额，下次轮转展示（diting F1）。
		for (const p of shown) pendingReminders.set(p.taskId, (pendingReminders.get(p.taskId) ?? 0) + 1);
		const items = shown.map((p) => {
			// failed 回执内核不可 accept：直接给可成功的 reject 调用，免一次无效往返（diting F2）。
			if (p.settlement === "failed") {
				const call = { action: "reject", handle: p.taskId, receiptId: "latest", expectedRevision: p.revision, reason: "<拒绝理由>" };
				return `  • ${p.taskId.slice(0, 8)} ${p.agent}${p.name ? `(${p.name})` : ""} execution=${p.execution} settlement=failed（必需检查失败，须拒绝后重派）receiptId=${p.receiptId} → task_control(${JSON.stringify(call)})`;
			}
			// ev-20261108-m3（diting 审 m3）：ready 但自动基线探测级环境缺口降级（零测试事实）的回执
			// 在待接受行如实标注——accept 的是人工验收结论，不得被读作测试通过（判据单源）。
			let envGapTag = "";
			if (p.settlement === "ready") {
				try { envGapTag = baselineEnvGapOfView(peekTaskKernel()?.get(p.taskId)?.receipt) ? "；自动基线未执行（环境缺口降级）——未经自动测试验证，非测试通过" : ""; } catch { /* lint-exempt:提示附注读取失败按无附注处理，不影响待接受列表 */ envGapTag = ""; }
			}
			const waive = [...p.missing];
			if (p.execution === "error" && !waive.includes(ERROR_EXECUTION_COVERAGE_GAP_ID)) waive.push(ERROR_EXECUTION_COVERAGE_GAP_ID);
			const call = { action: "accept", handle: p.taskId, receiptId: "latest", expectedRevision: p.revision, reason: "<接受理由>", ...(waive.length ? { waivedCheckIds: waive } : {}) };
			return `  • ${p.taskId.slice(0, 8)} ${p.agent}${p.name ? `(${p.name})` : ""} execution=${p.execution} settlement=${p.settlement}${envGapTag} receiptId=${p.receiptId} → task_control(${JSON.stringify(call)})`;
		});
		const more = due.length > shown.length ? `\n  …另 ${due.length - shown.length} 个：task_query({ view: "summary" }) 查 acceptance=unreviewed` : "";
		return `\n[待接受] 本会话 ${due.length} 个已结束任务尚无接受/拒绝决策（契约存储中仍是 unreviewed）——确认验收即复制调用；不接受改 action:"reject"（去掉 waivedCheckIds）；有意延后可忽略（每任务至多提醒 ${PENDING_REMINDER_CAP} 次）：\n${items.join("\n")}${more}`;
	};
	const agentNames = deps.agents.map((a) => a.name);
	// v2 §7.2：枚举兼收八旧 stem 别名（归一到 canonical 后派发）；错误提示面保持 canonical 名册。
	const agentEnum = agentNames.length > 0 ? StringEnum(dispatchAcceptableAgentIds(agentNames)) : Type.String();

	// 公共收尾链（submit/resume 同语义；幂等 + stale 防护 + K7 候选回执发布）
	const trustedOf = (ctx: FacetCtx) => resolveProjectTrusted(ctx);

	const finalizeOf = (taskId: string, agentName: string, r: Readonly<RunResult> & { output: string }, cwd: string, trusted: boolean) =>
		finalizeTerminal({
			taskId, agent: agentName,
			result: { ...r },
			cwd,
			evidence: { gatherEv: deps.testOpts?.evidence, trusted, baselinePorcelain: (r as { gitBaseline?: string[] | null }).gitBaseline ?? null },
			expectedRevision: r.dispatchRevision,
		});

	// ── task_submit ──────────────────────────────────────────────────────────
	const taskSubmit: FacetToolDefinition<SubmitParams> = {
		name: "task_submit",
		label: "Amagi Task Submit",
		description: [
			"提交一个任务给指定角色：冻结任务契约（spec）→ 入队/启动子进程 → 回执三轴（执行/结算/接受）。",
			"必填 agent，task/taskFile 恰选一个；新任务书无论长短直接传 task，一次完成派发，harness 自动保存后启动，无需先 Write。taskFile 引用已有文件（相对调用者 cwd，UTF-8 原文冻结；同批并行写该文件的 Write/Edit 自动等待完成后再读）。inputPaths/outputPaths 路径数组简写（必读输入/必需文件产物）；具体用途/可选项/目录树用 inputs/outputs 对象。delivery=wait（缺省，阻塞到本轮终态返回终稿）或 handle（立即返回任务句柄，完成自动通知，两者共用生命周期）。",
			"返回 details 行（taskId/revision/execution/settlement/acceptance/receiptRef）——后续用 task_control 控制、task_query 查询；accept/reject 须引用返回的 receiptId 与 revision。",
			"contextMode 可选 isolated/selected/fork；普通任务推荐 selected、复杂攻坚咨询可选 fork，独立审核/全新探索选 isolated。无需先写上下文文件，历史原文随任务冻结。",
			"scope/profile 是请求面：实际权限由角色/授权交集决定，请求不放大权限；workspace.cwd 省略继承调用者目录。model 可选：本次派发临时模型覆盖（仅本轮，不改配置不扩权——限流/配额恢复场景）。",
		].join(" "),
		promptSnippet: `task_submit({ agent, task, contextMode: "selected", delivery: "handle" }) — 按任务选 isolated/selected/fork；正文直接提交并自动保存，一次派发；taskFile 仅引用已写好的文件`,
		promptGuidelines: DISPATCH_TASK_GUIDELINES,
		constrainedSampling: TASK_FACET_CONSTRAINED_SAMPLING,
		parameters: Type.Object({
			agent: agentEnum,
			task: Type.Optional(Type.String({ description: "新任务书完整正文（长短均可）；自动冻结保存进 spec 后启动，一次派发无需先 Write；与 taskFile 恰选一个" })),
			taskFile: Type.Optional(Type.String({ description: "已有 UTF-8 任务书文件（≤1MiB，相对调用者 cwd，与 task 互斥）；同批并行写此文件的 Write/Edit 自动等待完成后再读。读取原文冻结进 spec 并自动登记来源输入，后续改文件不改变已提交任务" })),
			contextMode: Type.Optional(StringEnum(["isolated", "selected", "fork"], { description: "由 Leader 按任务选择：isolated=不继承（兼容缺省）；selected=用户要求、相关观察与待核验判断的交接，原文按需回读（普通任务推荐）；fork=当前可见文本历史。关键约束写入本次 task。历史资料不继承 Leader 权限；同一次调用自动快照并冻结。" })),
			contextRefs: Type.Optional(Type.Array(Type.String(), { description: "selected 可选来源引用（至多16个文件路径、工具调用id或消息id）；直接引用已有原文，无需手写摘要或先 Write。缺省按任务与 inputs 自动匹配；引用不可用时该次提交被拒，改传可用引用或省略即可。" })),
			delivery: Type.Optional(StringEnum(["wait", "handle"], { description: "交付方式：wait=阻塞到本轮终态（缺省）；handle=立即返回句柄，完成自动通知" })),
			inputPaths: Type.Optional(Type.Array(Type.String(), { description: "必读输入路径简写；自动展开 purpose=任务参考输入、required=true，与 inputs 互斥。相对路径解析基准：existing=任务工作目录；worktree=调用者 cwd（与 taskFile 一致；主树未跟踪输入按绝对路径跨树读取，或在树内可见用 workspace.base=dirty-snapshot）" })),
			outputPaths: Type.Optional(Type.Array(Type.String(), { description: "必需文件产物路径简写；自动展开 kind=file、required=true，与 outputs 互斥。工作区外写面仍须 scope.write/reportFiles 声明" })),
			inputs: Type.Optional(Type.Array(InputReferenceSchema, { description: "输入引用完整对象（具体用途/可缺输入）；与 inputPaths 互斥；预处理兼容路径字符串混用。相对路径解析基准：existing=任务工作目录；worktree=调用者 cwd（与 taskFile 一致）" })),
			outputs: Type.Optional(Type.Array(OutputReferenceSchema, { description: "预期产物完整对象（目录树/可选产物）；与 outputPaths 互斥；预处理兼容路径字符串混用。仅声明产物，不授予写面；tool-enforced 的工作区外目标须另声明 scope.write/reportFiles" })),
			scope: Type.Optional(Type.Object({
				read: Type.Optional(Type.Array(Type.String(), { description: "请求读范围（声明性：仅记录任务预期输入面，不做执行期限制——读恒放行，仅 deny 禁入拒绝）" })),
				write: Type.Optional(Type.Array(Type.String(), { description: "请求写范围（声明性：仅记录预期写面，不做执行期限制——执行期硬保护仅 deny 禁入/契约存储/跨根；目录意图自动归一为子树）" })),
				deny: Type.Optional(Type.Array(Type.String(), { description: "显式禁入路径（读写双禁，恒优先硬执法：目录意图自动归一为子树）。仅用于密钥/凭据等安全红线——防写不要用 deny（未授予 write/reportFiles 即零写入）；必读输入路径放进 deny 会在提交时被拒" })),
				reportFiles: Type.Optional(Type.Array(Type.String(), { description: "仅报告可写路径" })),
				advisor: Type.Optional(Type.Literal("consult", { description: "请求 Advisor 咨询：受信配置、角色能力与后端同时授权后冻结模型及预算；不允许子 agent 派发任务" })),
				// scope.codemode 只在契约层保留历史兼容，不在新模型工具面展示申请字段。
				shell: Type.Optional(StringEnum(["deny", "guarded", "optional"], { description: "shell 通道请求：guarded=必需（交集为空整任务拒绝）；optional=非必需（交集为空自动降级 deny 并在回执告警，不拒单——惯性误请求零代价）；deny/缺省=不请求。内置五角色均可 guarded；通道上限 shell=deny 仅适用于自定义受限角色——对其带 guarded 必遭整单拒，请用 optional 或不请求" })),
				mcp: Type.Optional(Type.Array(Type.String(), { description: "请求的 MCP 工具名" })),
				lsp: Type.Optional(Type.Array(StringEnum(["diagnostics", "definition", "references", "hover", "rename"], { description: "LSP 能力" }), { description: "请求的 LSP 能力清单" })),
			}, { description: "权限请求面：read/write/reportFiles 均为声明性（记录意图面）；硬执法仅 deny 禁入/契约存储/跨根/shell 通道/mcp/lsp 名单，另 tool-enforced（无 bash）保留粗写围栏：工作区根外写入须 write/reportFiles 显式声明" })),
			workspace: Type.Optional(Type.Object({
				cwd: Type.Optional(Type.String({ description: "任务工作目录（省略继承调用者目录）" })),
				mode: Type.Optional(StringEnum(["existing", "worktree"], { description: "existing（缺省）/worktree" })),
				worktreeName: Type.Optional(Type.String({ description: "worktree 名（mode=worktree 时）" })),
				dependencyVisibility: Type.Optional(StringEnum(["portable", "main-tree", "unknown"], { description: "依赖可见性声明（worktree 依赖复用）：portable=依赖安装可移植，worktree 可复用主树安装 / main-tree=依赖仅主树可见，worktree 需自行安装 / unknown=不声明（缺省）" })),
				base: Type.Optional(StringEnum(["head", "dirty-snapshot"], { description: "worktree 检出基线：head（缺省）=仓库当前 HEAD，主树未提交/未跟踪不带入；dirty-snapshot=主树工作区脏快照 commit（未提交/未跟踪全量带入，临时 index 构建、主树零扰动，排除 .amagi-worktrees）——主树未跟踪相对输入在树内可见。仅对新建树生效：复用树/既有分支按树自身 HEAD 检出并披露差异，不静默换基" })),
			}, { description: "工作区请求（不自动选择隔离工作区）" })),
			profile: Type.Optional(Type.String({ description: "受信配置中的 profile 名（不是任意覆盖字典）" })),
			model: Type.Optional(Type.String({ description: "可选：本次派发临时模型覆盖（单 spec \"provider/model[:thinking]\"）——沿既有解析/归一/冻结链执行，不改 amagi.json、不改变权限；provider 限流/配额恢复场景使用（失败恢复指引会给出可复制的换模调用）。缺省按角色配置解析" })),
			dryRun: Type.Optional(Type.Boolean({ description: "预检模式：契约/角色/授权/服务可用性/输入存在性全量校验，不 spawn 不入队（effects=none），返回预检摘要" })),
		}),
		prepareArguments: prepareSubmitArguments,
		execute: async (_id, rawParams, signal, _onUpdate, ctx) => guardedExecute("task_submit", async () => {
			rawParams = prepareSubmitArguments(rawParams) as SubmitParams;
			const shape = rejectUnknownParams(rawParams as unknown as Record<string, unknown>, ["agent", "task", "taskFile", "delivery", "inputs", "outputs", "inputPaths", "outputPaths", "scope", "workspace", "profile", "model", "dryRun", "contextMode", "contextRefs"]);
			if (shape) return contractErrorReturn(shape);
			for (const [short, full] of [["inputPaths", "inputs"], ["outputPaths", "outputs"]] as const) {
				if (rawParams[short] === undefined) continue;
				if (rawParams[full] !== undefined) return fail(err("path-shorthand-conflict", `${short} 与 ${full} 互斥；混合路径和对象可统一放在 ${full}`, [short, full], "none", SUBMIT_MINIMAL_EXAMPLES));
				return fail(err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${short} 必须是路径字符串数组`, [short], "none", SUBMIT_MINIMAL_EXAMPLES));
			}
			const contextMode = validateDispatchContext(rawParams);
			if (!contextMode.ok) return contractErrorReturn(contextMode.error);
			const contextSnapshot = contextMode.value === "isolated" ? undefined : captureLeaderContext(ctx.sessionManager, _id);
			if (contextSnapshot && !contextSnapshot.ok) return contractErrorReturn(contextSnapshot.error);
			const source = validateTaskSource(rawParams);
			if (!source.ok) return contractErrorReturn(withRepair(source.error, SUBMIT_MINIMAL_EXAMPLES));
			let params = { ...rawParams, task: source.value.task,
				inputs: normalizeInputReferences(rawParams.inputs), outputs: normalizeOutputReferences(rawParams.outputs) };
			const delivery = params.delivery ?? "wait";
			if (delivery !== "wait" && delivery !== "handle") {
				return fail(err(CONTRACT_ERROR_CODES.INVALID_ENUM, `delivery 必须是 wait/handle 之一（收到 "${String(delivery)}"）`, ["delivery"], "none", SUBMIT_MINIMAL_EXAMPLES));
			}
			// SubmitInput 契约校验；contextMode 由 Leader 选择并沿同一内核提交链冻结。
			// ev-20260919：profile 序列化伪影容错——模型面把字面 null/undefined 转成字符串（"null"/"undefined"/空白）
			// 不再整单拒绝 unknown-profile，归一化为未提供（缺省 profile 解析链照常）。
			const profileRaw = typeof params.profile === "string" ? params.profile.trim() : undefined;
			const profileName = profileRaw && !["null", "undefined"].includes(profileRaw.toLowerCase()) ? profileRaw : undefined;
			const validated = validateSubmitInput({
				agent: params.agent,
				contextMode: contextMode.value,
				assignment: params.task,
				...(params.inputs !== undefined ? { inputs: params.inputs } : {}),
				...(params.outputs !== undefined ? { outputs: params.outputs } : {}),
				...(params.scope !== undefined ? { scope: params.scope } : {}),
				...(params.workspace !== undefined ? { workspace: params.workspace } : {}),
				...(profileName !== undefined ? { profile: profileName } : {}),
			});
			if (!validated.ok) return contractErrorReturn(withRepair(validated.error, SUBMIT_MINIMAL_EXAMPLES));
			// 业务校验（执行前整单拒绝，effects=none）：profile 受信名单 + 角色名册
			if (profileName !== undefined && !deps.caller.authority.profiles.includes(profileName)) {
				return fail(err("unknown-profile", `profile "${profileName}" 不在受信名单（可用：${deps.caller.authority.profiles.join(", ") || "（无）"}）——profile 是受信配置中的名字，不是任意覆盖字典`, ["profile"], "none",
					deps.caller.authority.profiles.slice(0, 2).map((p) => ({ agent: params.agent, task: "<任务书>", profile: p }))));
			}
			// v2 §7.2：集中归一（别名→canonical）+ 解析模式固定首部注入；未知名沿用既有 unknown-agent 错误。
			const _agentReq = resolveAgentRequest(params.agent);
			const _modeHeader = "modeHeader" in _agentReq ? _agentReq.modeHeader : undefined;
			const agent = findAgentByRequest(deps.agents, params.agent);
			if (!agent) {
				return fail(err("unknown-agent", `角色 "${params.agent}" 不在名册（可用：${agentNames.join(", ") || "（空）"}；兼容别名 wenqu/taibai/laojun/wukong/cangjie/diting-quick/hongjun/puti 归一到 canonical）`, ["agent"], "none",
					agentNames.slice(0, 2).map((n) => ({ agent: n, task: "<任务书>" }))));
			}
			// ev-20260920-beeac5：请求名 ≠ canonical 名（别名归一发生）时回执双名标注——显示层不失真，
// Leader 归因与跨会话检索不被误导（agent-aliases §7.2 步骤 5：requestedAgent 仅作回执兼容说明）。
const agentLabel = params.agent === agent.name ? agent.name : `${params.agent}→${agent.name}（别名归一）`;
// 解析模式 ≠ 角色默认时任务正文首部注入固定首部（幂等；如 hongjun→fuxi 附「任务态: attack」）。
			let taskCwd = params.workspace?.cwd !== undefined ? path.resolve(ctx.cwd, params.workspace.cwd) : ctx.cwd;
			// ev-20260922-1b1662：cwd 存在性 fail-fast——spawn({cwd}) 指向不存在目录时 Node 报文只含命令名
			// （「spawn <node绝对路径> ENOENT」），cwd 缺失与命令缺失不可区分，实战曾把任务目录被移动
			// 误诊为「fnm node 二进制丢失」。派发前拦截并给明确归因（resume 面 workspace-missing 同语义）。
			if (!fs.existsSync(taskCwd)) {
				return fail(err("workspace-missing",
					`任务工作目录不存在: ${taskCwd}——目录可能被移动/重命名；若仍派发，spawn 将以该目录为 cwd 报「spawn <node路径> ENOENT」（Node 报文只含命令名，cwd 缺失与命令缺失同形，极易误诊为 node 环境损坏）`,
					["workspace.cwd"], "none",
					[{ workspace: { cwd: "<核对后的存在路径>", mode: "existing" } }, { hint: "需要全新目录时：先创建目录再派发，或改用 worktree 模式（自动 git worktree add）" }]));
			}
			// ev-20261031-7110a8：可选临时模型覆盖——复用 legacy paramModel 归一/提示链（字符串化数组宽容
			// 恢复取首元素；归一/注册校验由 runTask/runBackgroundTask 同源拒绝，不建平行校验面）；仅影响
			// 本轮 --model 解析，不改 amagi.json、不改变权限，缺省派发行为不变。
			const _mp = normalizeFacetModelParam(rawParams.model);
			if (_mp.error) return fail(err(CONTRACT_ERROR_CODES.INVALID_FIELD, _mp.error, ["model"], "none", [{ agent: params.agent, task: "<任务书>", model: "provider/model[:thinking]" }]));
			const paramModel = _mp.model;
			const modelNotice = paramModel
				? [
						`[model] 本次临时覆盖 ${paramModel}——仅本轮生效，不改 amagi.json/角色配置，不改变权限`,
						modelOverrideNote(agent, { paramModel, effectiveSpec: paramModel, cwd: taskCwd }),
						..._mp.notes,
					].filter(Boolean).join("\n")
				: _mp.notes.length > 0 ? _mp.notes.join("\n") : undefined;
			// 读取来源在 worktree 创建/入队前完成；按调用者 cwd 定位，子任务 deny 同时核验词法与真实落点。
			if (source.value.taskFile !== undefined) {
				const advisor = advisorAuthorityOf(ctx.cwd, trustedOf(ctx));
				const sourceGrant = computeEffectiveGrant({
					role: { name: agent.name, tools: agent.tools, capabilities: agent.capabilities, ...(agent.capabilitiesError !== undefined ? { capabilitiesError: agent.capabilitiesError } : {}) },
					user: { ...unlimitedUserAuthority(deps.caller.authority.maxAssurance), advisor }, scope: params.scope,
					inputs: params.inputs ?? [], outputs: params.outputs ?? [], backend: JSON_BACKEND_CAPS, cwd: taskCwd,
				});
				if (!sourceGrant.ok) return contractErrorReturn(sourceGrant.error);
				// 同批并行的同文件 Write/Edit 先完成再读（工具侧自动串行，模型无需记调用时序）。
				const settled = await awaitPendingFileMutations(source.value.taskFile, ctx.cwd, { signal, sessionId: fileMutationSessionId(ctx, ctx.cwd) });
				if (!settled.ok) return fail(err("task-file-write-pending", settled.error!, ["taskFile"], "none"));
				const loaded = readTaskFile(source.value.taskFile, ctx.cwd, createFilePermissionEnforcer(sourceGrant.value, taskCwd).checkRead);
				if (!loaded.ok) return contractErrorReturn(withRepair(loaded.error, SUBMIT_MINIMAL_EXAMPLES));
				params = { ...params, task: loaded.value.task, inputs: [...(params.inputs ?? []), loaded.value.input] };
			}
			if (_modeHeader) params = { ...params, task: withModeHeader(_modeHeader, params.task) };
			// ev-20261031-1e0a8f：任务书验证命令=隐式 shell 需求声明——scope.shell 缺省且命中验证要求时
			// 自动按 optional 请求（识别面与 shellVerificationGapHint 单源）；显式 deny/guarded/optional 一律
			// 不动。下游 grant 求值/shellGapHint/optionalDowngrade/dryRun 授权行自动取到归一化值（一处归一化，
			// 三出口所见即所得）；optional 交集空降级 deny 是既有机制（零新拒单）。
			const autoShellRequest = inferImplicitShellRequest(params.task, params.scope?.shell);
			if (autoShellRequest) params = { ...params, scope: { ...params.scope, shell: autoShellRequest } };
			// ── ev-20261007-ef07e6：workspace.mode=worktree 派发口统一（fail-closed，绝不静默回落请求 cwd）──
			// 旧链：schema 接受 workspace{mode,worktreeName,dependencyVisibility} 但执行链只 resolve cwd，
			// 无人创建 worktree、无失败拒绝面——隔离意图静默失效。现统一在派发口：校验 → setupWorktree
			// （既有约定路径/lease/冲突检查）→ taskCwd 切到工作树（grant/spec/engineOpts/子进程/finalizer 全链一致）
			// → 依赖事实校验 → engineOpts 直传冻结；try/finally 闭合所有拒单和异常。
			let wtInfo: WorktreeSetup | null = null;
			let wtLease: string | undefined;
			let wtDepNote = "";
			let wtPlan: WorktreePlanProbe | undefined;
			let wtFacts: WorktreeDispatchFacts | undefined;
			let wtEffects: "none" | "unknown" = "none";
			let backgroundOwnsLease = false;
			// ev-20261021-fix（diting F2）：派发尝试标记——runTask/runBackgroundTask 调用前置 true。
			// 派发后（含 spawn ENOENT、wait error 终态、收尾异常）子进程已接触过工作树，
			// 「创建事务无用户产物」不再可证明 → 一律不自动删树（resume cwd / 用户产物保全优先）。
			let wtDispatched = false;
			// ev-20261017-348337：worktree 模式声明路径统一解析基准——调用者 cwd（submitCwd，与 taskFile
			// 一致）；dryRun 与正式提交同一预检链，校验全部在建树前完成，通过后才 setupWorktree。
			let wtBasis: { plan: WorktreePlanProbe; submitCwd: string; base: WorktreeBaseMode } | undefined;
			const retainedScene = (): string => wtInfo ? `\n[worktree 现场保留] ${wtInfo.path}；lease 已释放，未自动删树。` : "";
			// ev-20261017-348337 + ev-20261021-fix（diting F2）：提交期失败回滚仅限**尚未派发**且能证明
			// 创建事务无用户产物（新建树 + HEAD==创建基线 + 含 ignored 的丢弃面为空——证明在
			// rollbackWorktreeCreation）→ 删树删分支，effects 可诚实 none；已派发/复用树/脏树/探测失败
			// → 保守保留现场（effects=unknown）。setupWorktree 自身失败（含半成品建树）不经本回滚
			//（无法证明创建状态，仍按 effects=unknown 保留——partial-add 语义不变）。
			const tryRollbackFreshWorktree = (): string | null => {
				if (wtDispatched) return null; // F2：移除派发后/error 终态自动删树路径
				if (!wtInfo || wtInfo.reused || !wtLease || !wtInfo.root || !wtInfo.name) return null;
				releaseWorktreeLease(wtLease, "submit 失败（回滚检查）"); // 幂等；finally 再释放为无操作
				try {
					const rb = rollbackWorktreeCreation(wtInfo.root, wtInfo.name, { deleteBranch: !wtInfo.branchPreexisting, creationBaseCommit: wtInfo.baseCommit });
					return rb.ok ? rb.message : null;
				} catch { return null; /* lint-exempt:回滚探测失败不放大为异常，保留现场走 unknown */ }
			};
			const workspaceError = (e: Readonly<ContractError>, appendix?: string): FacetToolReturn => {
				const rolled = tryRollbackFreshWorktree();
				return contractErrorReturn(
					{ ...e, effects: rolled ? "none" : wtInfo || wtEffects === "unknown" ? "unknown" : e.effects },
					[appendix, rolled ?? (wtInfo ? `[worktree 现场保留] ${wtInfo.path}；本轮 lease 已释放，不自动删目录/分支，请核对副作用后重提。` : wtEffects === "unknown" ? "[worktree 创建尝试] 可能已留下目录/分支登记；未派发，不自动删除现场。" : "")].filter(Boolean).join("\n"),
				);
			};
			try {
			return await (async () => {
			const fail = (r: Result<never>, appendix?: string): FacetToolReturn => workspaceError((r as { error: ContractError }).error, appendix);
			if (params.workspace?.mode === "worktree") {
				const wtName = (params.workspace.worktreeName ?? "").trim();
				if (!wtName) {
					return fail(err("worktree-name-required", "workspace.mode=worktree 必须提供 worktreeName（非空；将创建 <仓库根>/.amagi-worktrees/<worktreeName>，分支 amagi/<worktreeName>，base=仓库当前 HEAD）", ["workspace.worktreeName"], "none", [
						{ agent: params.agent, task: "<任务书>", workspace: { mode: "worktree", worktreeName: "<工作树名>", dependencyVisibility: "portable" } },
						{ hint: "普通目录任务用 workspace.mode=existing（或缺省）；worktree 需 workspace.cwd 是 git 仓库" },
					]));
				}
				const depVis = params.workspace.dependencyVisibility ?? "unknown";
				const wtBase: WorktreeBaseMode = params.workspace.base === "dirty-snapshot" ? "dirty-snapshot" : "head";
				// ev-20261017-348337：正式提交与 dryRun 同一预检链——probeWorktreePlan 只读先行；输入存在性/
				// 授权/deny 等可在建树前完成的校验全部前移（任一失败=零建树零分支，effects=none，不遗留现场）。
				const probe = probeWorktreePlan(taskCwd, wtName);
				if (!probe.ok) {
					return fail(err("worktree-dispatch-failed", `${probe.message ?? "worktree 预检失败"}——${params.dryRun === true ? "dryRun 预检失败 = 正式提交同因拒绝" : "任务未派发"}（fail-closed，不回落请求 cwd）`, ["workspace"], "none"));
				}
				if (probe.activeLease) {
					return fail(params.dryRun === true
						? err("worktree-lease-conflict", `同名工作树正被任务 ${probe.activeLease.taskId || probe.activeLease.leaseId} 活跃占用（${probe.plannedPath}）——正式提交将拒绝（fail-closed）：等其终态、换 worktree 名，或由 Leader 重拆`, ["workspace.worktreeName"], "none")
						: err("worktree-dispatch-failed", `[worktree 占用冲突] ${probe.plannedPath} 正被任务 ${probe.activeLease.taskId || probe.activeLease.leaseId} 活跃使用中——任务未派发（fail-closed，不静默回落请求 cwd；等其终态、换 worktree 名，或由 Leader 重拆）`, ["workspace"], "none"));
				}
				if (params.dryRun === true) {
					// dryRun effects=none：只校验并报告将创建/复用的约定路径，不创建、不占有
					try {
						if (probe.reused) prepareWorktreeDependencies(probe.root!, probe.plannedPath!, depVis, undefined, true);
					} catch (e) { return fail(err("worktree-dependency-failed", `依赖事实校验拒绝：${String(e instanceof Error ? e.message : e)}；核对连接后重提，不自动拆链接`, ["workspace.dependencyVisibility"], "none")); }
				}
				// ev-20261017-348337 + ev-20261021-fix（diting F4）：声明路径统一解析基准=真实调用者 cwd
				//（ctx.cwd，与 taskFile 同基准——workspace.cwd 仅定位执行项目/建树根，不参与声明路径解析，
				// 否则「taskFile 按根目录读入、同目录 inputPaths 却被拼到 repo/sub/ 下拒单」的接缝回归）；
				// 授权/deny 按计划树 cwd 计算词法规则，输入/产物按该基准解析后换算子 Agent 侧形态再校验/冻结。
				wtBasis = { plan: probe, submitCwd: ctx.cwd, base: wtBase };
				wtPlan = probe;
				if (params.dryRun === true) taskCwd = probe.plannedPath!; // F9：展示/授权 cwd 按计划树（与正式提交建树后一致）
			}
			const trusted = trustedOf(ctx);
			// P4 §7-1 接缝接线（M3 生产激活）：scope 请求面 → 四方交集（role∩user∩task∩backend）→ 冻结 grant。
			// fail-closed：角色能力声明缺失/非法、请求超角色上限、输出未被覆盖均整单拒绝（P1 语义，不回退宽权限）。
			// B5A：codemode 四方门禁同面接入（受信配置角色开关 + 后端受控装配探测；未请求零影响）。
			// ev-20261017-348337：worktree 模式下 codemode 受信配置按调用者侧 cwd 解析（树内未跟踪 amagi.json
			// 不参与）；声明路径统一按调用者 cwd 解析后换算子 Agent 侧形态（childInputs=子 Agent 实读绝对路径；
			// childOutputs=工作树内落点），授权/deny 词法基准仍为子 Agent 实际 cwd（计划树）。
			const inputProbes: WorktreeInputProbe[] = wtBasis
				? (params.inputs ?? []).map((i) => probeWorktreeDeclaredInput(wtBasis!.plan, wtBasis!.submitCwd, i.path, { base: wtBasis!.base }))
				: [];
			// ev-20261021-fix（diting F4/F5）：声明路径基准=真实调用者 cwd；childInputs 在建树后按实际
			// 树内容复验修正（let——F5 创建后验证可改写 tree→caller）。
			let childInputs = wtBasis
				? (params.inputs ?? []).map((i, idx) => ({ ...i, path: inputProbes[idx]!.reachable === "tree" ? inputProbes[idx]!.treeAbs! : inputProbes[idx]!.callerAbs }))
				: params.inputs ?? [];
			const childOutputs = wtBasis
				? (params.outputs ?? []).map((o) => ({ ...o, path: convertWorktreeDeclaredOutput(wtBasis!.plan, wtBasis!.submitCwd, o.path).childPath }))
				: params.outputs ?? [];
			const advisor = advisorAuthorityOf(wtBasis ? wtBasis.submitCwd : taskCwd, trusted);
			const grant = computeEffectiveGrant({
				role: { name: agent.name, tools: agent.tools, capabilities: agent.capabilities, ...(agent.capabilitiesError !== undefined ? { capabilitiesError: agent.capabilitiesError } : {}) },
				user: { ...unlimitedUserAuthority(), advisor, maxAssurance: deps.caller.authority.maxAssurance },
				scope: params.scope as SubmitScope | undefined,
				inputs: childInputs,
				outputs: childOutputs,
				backend: JSON_BACKEND_CAPS,
				cwd: wtBasis ? wtBasis.plan.plannedPath! : taskCwd,
			});
			if (!grant.ok) return workspaceError(withRepair(grant.error, SUBMIT_MINIMAL_EXAMPLES));
			// diting full F02：降级候选的 worktree 双形态 deny 判定（调用者侧落点 + 树内对应落点，与既有
			// inputProbes deny 复验同口径）——grant 的 deny 词法按计划树展开，checkRead(主树绝对路径) 命不中
			// 树内规则；命中即不降级，与 checkRead 失败同口径走既有 context-ref-unavailable（不新增错误码/
			// 拒单面；显式 inputs 路径的该拒绝本就存在，降级路径不弱于它）。
			const wtDenyHit = (abs: string): boolean => {
				const probe = probeWorktreeDeclaredInput(wtBasis!.plan, wtBasis!.submitCwd, abs, { base: wtBasis!.base });
				return [probe.callerAbs, probe.treeAbs]
					.filter((a): a is string => a !== undefined)
					.some((a) => grant.value.deny.some((r) => matchPathRule(a, r)));
			};
			// diting full F03：降级去重基准（与下方去重块同一解析基准）；existing 模式按任务工作目录。
			const inputAbsOf = (p: string) => path.isAbsolute(p) ? p : path.resolve(wtBasis ? wtBasis.submitCwd : taskCwd, p);
			const inherited = prepareDispatchContext(rawParams, params.task, contextSnapshot?.ok ? contextSnapshot.value : undefined, {
				cwd: wtBasis ? wtBasis.plan.plannedPath! : taskCwd, inputPaths: childInputs.map(i => i.path),
				hasDeny: grant.value.deny.length > 0, checkRead: createFilePermissionEnforcer(grant.value, wtBasis ? wtBasis.plan.plannedPath! : taskCwd).checkRead,
				degradeRefsToInputs: true, // ev-20261031-da3f86：路径实存 ref 降级为必读输入（advisor 面不开启）
				...(wtBasis ? { degradeDenyHit: wtDenyHit } : {}),
				// diting full F03：去重命中时 notice 按实际保留条目的 required 披露（不改调用者显式 false）
				degradeExistingRequiredOf: (abs) => {
					const hit = (params.inputs ?? []).find((i) => inputAbsOf(i.path) === abs);
					return hit === undefined ? undefined : hit.required !== false;
				},
			});
			if (!inherited.ok) {
				if (inherited.error.code === "context-too-large" && rawParams.contextMode === "selected") {
					const { contextRefs, ...base } = rawParams;
					const examples = [{ ...base, contextMode: "isolated" }, ...(contextRefs?.length ? [{ ...base, contextMode: "selected", ...(contextRefs.length > 1 ? { contextRefs: contextRefs.slice(0, -1) } : {}) }] : [])];
					return workspaceError(withRepair({ ...inherited.error, message: `${inherited.error.message}；仅当任务书及输入自足时可显式 isolated；也可缩小 contextRefs（用户要求仍保留）` }, examples));
				}
				return workspaceError(inherited.error);
			}
			// ev-20261031-da3f86：contextRefs 降级条目 → params.inputs（必读、绝对路径、与既有 inputs 去重）。
			// deny 已由降级时的 checkRead + 双形态判定挡住（不降级维持既有拒绝）；existing 模式 required 存在性
			// 校验在下游用本 params.inputs 重算（绝对路径磁盘实存→通过）；worktree 模式 childInputs 追加同一条目
			// （跨树绝对路径读取，与 F5 复验改写同形态）。notice 已在 inherited.value.notice 披露降级事实。
			// diting full F02：降级条目同步生成 probes 纳入 inputProbes——deny 复验/可达性披露/required 复验/
			// 建树后 treeMiss 复验链与显式 inputs 同守（索引与 params.inputs 追加同序对齐）。
			const degradedInputs = inherited.value.degradedRefs ?? [];
			if (degradedInputs.length > 0) {
				const seenInputs = new Set((params.inputs ?? []).map((i) => inputAbsOf(i.path)));
				const freshDegraded = degradedInputs.filter((d) => !seenInputs.has(inputAbsOf(d.path)));
				if (freshDegraded.length > 0) {
					params = { ...params, inputs: [...(params.inputs ?? []), ...freshDegraded] };
					childInputs = [...childInputs, ...freshDegraded];
					if (wtBasis) inputProbes.push(...freshDegraded.map((d) => probeWorktreeDeclaredInput(wtBasis!.plan, wtBasis!.submitCwd, d.path, { base: wtBasis!.base })));
				}
			}
			// ev-20261017-348337：worktree 跨树输入的 deny 补充校验——computeEffectiveGrant 已按子 Agent 实读
			// 形态（树内绝对路径）校验；输入在主树实存但树内不存在时子 Agent 以调用者 cwd 绝对路径跨树
			// 读取，主树侧落点须同样不落 deny 禁入区（deny 读写双禁，跨树读取不能绕过）。
			if (wtBasis) {
				const denyHit = inputProbes.find((p) => [p.callerAbs, p.treeAbs]
					.filter((abs): abs is string => abs !== undefined)
					.some((abs) => grant.value.deny.some((r) => matchPathRule(abs, r))));
				if (denyHit) {
					return fail(err("input-in-deny-region",
						`输入 "${denyHit.declared}"（worktree 模式按调用者 cwd 解析为 ${denyHit.callerAbs}${denyHit.treeAbs ? `，工作树内对应 ${denyHit.treeAbs}` : ""}）落在 deny 禁入区（deny 读写双禁：read 同样被硬拒）——必读输入与禁入区自相矛盾，整任务拒绝`,
					["inputs"], "none",
					[{ hint: `若该输入确需读取：从 scope.deny 移除对应条目后重派（当前 deny=[${grant.value.deny.map((r) => `${r.kind}:${r.value}`).join("、")}]）——保护路径不被写入无需 deny，未授予 write/reportFiles 即零写入` }]));
				}
			}
			// ev-2026 deny 误伤根除（第二道拦截）：任务书正文引用的绝对路径落在 deny 禁入区 → 提交点
			// 整单拒绝。deny 读写双禁，正文必读路径与禁入区自相矛盾——子 Agent 运行中 read 必硬拒，
			// 高频阻断形态在此前移为一次可修复的拒单（fail-closed，零建档零 spawn）。
			const denyConflicts = findAssignmentDenyConflicts(params.task, grant.value.deny, wtBasis ? wtBasis.plan.plannedPath! : taskCwd);
			// B4·批B（D9，ev-20261012-af58eb §8 批B）：正文 deny 提及默认 disclose——「禁止访问某路径」
			// 类表述不再被误读成必读而整单拒绝；补 inputs 声明提示。护栏不变：结构化 inputs/outputs 落
			// deny 仍整任务拒单（computeEffectiveGrant 内硬拒，不经本规则），运行期 deny 不放松。
			// B4B 修复轮 R03：传实际角色视角（agent.name 经 canonicalAgentId 归一）——角色覆盖
			//（guards.roles.<role>）在解释面与判定消费同一视角（派发链经 AMAGI_AGENT env 同效）。
			if (denyConflicts.length > 0 && guardRuleOf("task.assignmentDenyMention", taskCwd, trusted, agent.name) === "block") {
				return fail(err(
					"assignment-path-in-deny-region",
					`任务书正文引用的路径落在 deny 禁入区（deny 读写双禁：子 Agent read 同样被硬拒——运行中必阻断）：${denyConflicts.join("、")}——整任务拒绝`,
					["scope.deny"],
					"none",
					[
						{ hint: `若这些是必读输入：从 scope.deny 移除对应条目后重派（当前 deny=[${grant.value.deny.map((r) => `${r.kind}:${r.value}`).join("、")}]）——保护路径不被写入无需 deny，未授予 write/reportFiles 即零写入` },
						{ hint: "若该路径确属禁入（密钥/凭据类）：改写任务书不逐字引用禁入路径（如改用相对表述或替代来源），deny 条目保留" },
					],
				));
			}
			const denyMentionHint = denyConflicts.length > 0
				? `[amagi guard:task.assignmentDenyMention｜已放行] 任务书正文提及 deny 禁入路径：${denyConflicts.join("、")}。事实：正文提及不等于必读请求（可能是「禁止访问」类表述），已按 disclose 放行提交；推测：若这些确为必读输入，子 Agent 运行中 read 仍会被运行期 deny 硬拒（deny 读写双禁不放松——届时将以 blocked 回流而非静默失败）。护栏：必读输入请显式声明进 inputs[].path（结构化 inputs 落 deny 仍在提交点整单拒绝——一次修复重派，不运行中报废）。配置：rule 可收紧回 block（来源见 /amagi config explain）。`
				: null;
			// ev-20260929-3c5db4（P0 路径漏层防线·提交点）+ ev-20261017-348337（基准统一/时序前移）：required
			// 输入存在性执法 + 漏层近邻提示 + 解析基准披露。worktree 模式：按调用者 cwd 统一解析后探测可达性
			//（新树基线/复用树磁盘/dirty-snapshot 主树实存），任一可达即通过，全部在建树前完成——失败零建树
			// 零分支（effects=none）。existing 模式：语义不变（任务工作目录基准），拒单文案附基准与绝对落点。
			const newTreeDryRun = wtPlan !== undefined && !wtPlan.reused;
			const inputBasisNotes: string[] = [];
			const crossTreeInputs: string[] = [];
			let driftScan: ReturnType<typeof submitPathDriftHints>;
			if (wtBasis) {
				const basis = wtBasis;
				// 近邻/等价/产物中间层提示按调用者 cwd 基准探测（Leader 修正视角）；missingRequired 只消费
				// 可达性判定为 missing 的条目（submitPathDriftHints 的调用者磁盘口径是其超集，交叠取用）。
				const advisoryScan = submitPathDriftHints(basis.submitCwd, params.inputs ?? [], params.outputs ?? []);
				driftScan = advisoryScan;
				const missing = inputProbes
					.map((p, idx) => ({ p, required: (params.inputs ?? [])[idx]!.required !== false }))
					.filter((x) => x.p.reachable === "missing" && x.required);
				if (missing.length > 0) {
					const hintOf = (declared: string) => advisoryScan.missingRequired.find((m) => m.path === declared);
					const failover = missing.map((x) => {
						const h = hintOf(x.p.declared);
						const parts: string[] = [];
						if (h?.equivalent) parts.push(`[amagi 路径快照·疑似隐形字符差异] ${x.p.declared} —— 同位置存在归一化等价路径 ${h.equivalent.equivalent}（首处差异：${h.equivalent.detail}），已核验存在；请以等价路径重提。`);
						if (h?.nearMiss) parts.push(`[amagi 路径快照·疑似漏层] ${x.p.declared} —— ${h.nearMiss}；若为漏层（少写一层）请修正后重提。`);
						return parts.join("\n");
					}).filter(Boolean).join("\n");
					const basisLines = missing.map((x) => `  · ${x.p.declared} → 调用者 cwd 基准绝对落点 ${x.p.callerAbs}${x.p.treeAbs ? `；工作树内对应 ${x.p.treeAbs}（${basis.plan.reused ? "复用树磁盘" : basis.base === "dirty-snapshot" ? "脏快照（主树实存）" : "新树基线检出"}均不含）` : "；路径在仓库根外，工作树无对应"}`);
					return fail(err(
						"required-input-missing",
						`inputs.required 声明的路径在解析基准与目标工作树均不存在（缺失即拒单——两处皆无，子 Agent 运行中必 ENOENT）：${missing.map((x) => x.p.declared).join("、")}\n解析基准: worktree 模式下相对路径按调用者 cwd（${basis.submitCwd}）解析为绝对路径后，再换算工作树内对应位置校验：\n${basisLines.join("\n")}`,
						["inputs"], "none",
						[
							{ hint: "输入在主树未跟踪/未提交且需要在树内可见：改用 workspace.base=dirty-snapshot（主树工作区脏快照检出）或以绝对路径声明（子 Agent 跨树读取主树实存文件）" },
							{ hint: "核对路径逐层完整性（漏层近邻/隐形字符差异见正文）；输入尚未产出：先等前置任务完成再派发；确属可缺输入改 required:false（附存在性说明）" },
						],
					), failover);
				}
				for (const p of inputProbes) {
					if (p.reachable === "tree") {
						if (p.treeBasis === "base") inputBasisNotes.push(`输入基线已验证: ${p.declared}（新树基线 ${basis.plan.baseCommit?.slice(0, 8)} 的检出：${p.treeAbs}；不承诺主树未提交内容）`);
						else if (p.treeBasis === "reused-disk") inputBasisNotes.push(`输入已验证: ${p.declared}（复用工作树实存：${p.treeAbs}）`);
						else inputBasisNotes.push(`输入已验证: ${p.declared}（dirty-snapshot 基线将带入主树 Git 可见实存：${p.treeAbs}；.gitignore 覆盖路径不入快照）`);
					} else if (p.reachable === "caller") {
						crossTreeInputs.push(p.declared);
						inputBasisNotes.push(p.ignoredInSnapshot
							? `输入已验证: ${p.declared}（主树实存但被 .gitignore 覆盖——不入 dirty-snapshot 快照，不强制入 Git；子 Agent 以绝对路径跨树读取：${p.callerAbs}）`
							: p.outsideRepo
								? `输入已验证: ${p.declared}（仓库根外调用者侧实存：${p.callerAbs}；无树内对应——子 Agent 以绝对路径跨树读取，deny/授权另行校验）`
								: `输入已验证: ${p.declared}（调用者 cwd 实存：${p.callerAbs}；工作树检出不含——子 Agent 以绝对路径跨树读取）`);
					}
				}
			} else {
				driftScan = submitPathDriftHints(taskCwd, params.inputs ?? [], params.outputs ?? []);
				if (driftScan.missingRequired.length > 0) {
					const nearMissLines = driftScan.missingRequired
						.filter((m) => m.nearMiss)
						.map((m) => `[amagi 路径快照·疑似漏层] ${m.path} —— ${m.nearMiss}；若为漏层（少写一层）请修正后重提。`);
					// ev-20261002-9aad70：隐形字符差异等价路径行——字节级不存在但同位置存在归一化等价
					// 实体（零宽字符/全角空格/Unicode 形态），已 existsSync 核验；给出可直接复制的真实路径。
					const equivalentLines = driftScan.missingRequired
						.filter((m) => m.equivalent)
						.map((m) => `[amagi 路径快照·疑似隐形字符差异] ${m.path} —— 同位置存在归一化等价路径 ${m.equivalent!.equivalent}（首处差异：${m.equivalent!.detail}；零宽字符/全角空格/Unicode 形态差异），已核验存在；请以等价路径重提。`);
					const failover = [...equivalentLines, ...nearMissLines].join("\n");
					return fail(err(
						"required-input-missing",
						`inputs.required 声明的路径冻结时不存在（缺失即拒单——此刻不存在，子 Agent 运行中必 ENOENT）：${driftScan.missingRequired.map((m) => m.path).join("、")}\n解析基准: 相对路径按任务工作目录（${taskCwd}）解析为绝对路径后校验存在性（首条绝对落点：${path.resolve(taskCwd, driftScan.missingRequired[0]!.path)}）`,
						["inputs"], "none",
						[
							{ hint: "核对路径逐层完整性（实战高发：深层中文路径漏写一层或含不可见字符差异——等价路径/近邻候选见正文，同名即疑似修正位置）" },
							{ hint: "输入尚未产出：先等前置任务完成再派发；确属可缺输入改 required:false（附存在性说明）" },
						],
					), failover);
				}
			}
			const pathDriftHint = driftScan.advisoryLines.length > 0 ? driftScan.advisoryLines.join("\n") : null;
			// ev-20261017-348337：跨树输入披露行（wait/handle 终稿三出口透出——子 Agent 读的是主树绝对路径，
			// 与树内基线检出版本不是同一份；需要树内可见时用 dirty-snapshot 基线）。
			const wtInputBasisNote = wtBasis && crossTreeInputs.length > 0
				? `[worktree 输入基准] inputs 相对路径按调用者 cwd（${wtBasis.submitCwd}）解析；以下输入在工作树检出内不存在，子 Agent 以绝对路径跨树读取主树实存文件：${crossTreeInputs.join("、")}——需要树内可见（同基线内容）时改用 workspace.base=dirty-snapshot`
				: null;
			const shellGapHint = shellVerificationGapHint(params.task, grant.value.shell, params.scope?.shell, autoShellRequest !== undefined); // 0f097a：请求面显式 deny=明确选择，不提示；1e0a8f：自动注入面用改写后文案
			// ev-20261031-1e0a8f：自动升级披露行（三出口同文案，与 optionalDowngrade/shellGapHint 同追加
			// 模式）——归一化不可静默，Leader 需知道 scope.shell 已被自动注入及其关闭出口。
			const autoShellNotice = autoShellRequest !== undefined
				? `[shell 自动请求] 任务书含验证执行要求（${matchAssignmentVerificationCommand(params.task) ?? "验证要求"}）且未显式声明 scope.shell——已自动按 optional 请求${grant.value.shell === "guarded" ? "，交集全过获 shell=guarded（任务书验证命令视为隐式 shell 需求声明）" : "，交集为空降级 shell=deny（见下方降级/提示行）"}；不希望子任务持有通道时显式 scope.shell="deny" 或任务书注明「${SHELL_VERIFICATION_WAIVERS[0]!.sample}」`
				: null;
			// ev-20261017-348337：产物写面提示按子 Agent 实际落点（worktree 模式=换算后的树内形态）核对。
			const outputWriteHint = declaredOutputWriteHint(wtBasis ? wtBasis.plan.plannedPath! : taskCwd, grant.value, childOutputs);
			// ev-20260930-c703e3：optional 降级告警（与 shellGapHint 同模式三出口透出：dryRun 摘要、
			// handle 即时返回、wait 终态返回）——降级事实不入 details.degraded（保留内核结算降级语义）。
			const optionalDowngrade = optionalShellDowngradeNotice(
				params.scope?.shell,
				{ name: agent.name, capabilities: agent.capabilities, ...(agent.capabilitiesError !== undefined ? { capabilitiesError: agent.capabilitiesError } : {}) },
				deps.caller.authority.maxAssurance,
				JSON_BACKEND_CAPS,
			);
			// ev-20260930-08a8e7：升级窗口中性提示（启动冻结版本 × 本次探测安装版本；已知且不相等才提示，
			// 同版本对一次；不拒单、不杀子进程、不执行更新——纯提示行，三出口同文案）
			const driftHint = versionDriftNotice();
			// ev-20261017-cd233f：dirty-snapshot 计划行（dryRun 预览——不创建快照；脏项计数按主树 porcelain 滤除 .amagi-worktrees）。
			const wtDirtyCount = wtBasis && !wtBasis.plan.reused && wtBasis.base === "dirty-snapshot"
				? snapshotMainBaseline(wtBasis.plan.root!).porcelain.split("\n").filter(Boolean).length : 0;
			// ev-20260919（P2-4）：dryRun 预检——不 spawn 不入队（effects=none），派发前可验证参数/授权/服务可用性，
			// 预检缺项（lsp/mcp 未检测到）即时返回修复提示，替代「失败→修参→重派」试错循环。
			if (params.dryRun === true) {
				const gaps = newTreeDryRun ? [] : findDispatchRequirementGaps(taskCwd, grant.value);
				// F1：显式覆盖完整复用正式派发的 resolve（含 thinking 宽容修正）→ normalize 链，
				// 不直接拿原始参数校验 registry，避免把 :HIGH 等可自动修正输入误报为正式必拒。
				// 缺省模型保持配置展示；dryRun 仍是 effects=none 预检报告，不新增拒单。
				const dryModelResolution = resolveModelWithSource(agent, { paramModel, cwd: taskCwd });
				const dryModelNorm = paramModel !== undefined ? normalizeModelSpec(dryModelResolution.spec, ctx.modelRegistry as ModelRegistryLike | undefined) : undefined;
				const dryModelInvalid = dryModelNorm !== undefined && !dryModelNorm.ok;
				const dryModelOk = dryModelNorm !== undefined && dryModelNorm.ok ? dryModelNorm : undefined;
				const dryModelLine = paramModel === undefined
					? `${dryModelResolution.spec ?? "宿主会话默认（未配置模型）"}（配置解析）`
					: dryModelInvalid
						? `⚠ ${paramModel}（本次显式覆盖）——正式派发将被拒绝：${dryModelNorm !== undefined && !dryModelNorm.ok ? dryModelNorm.error : ""}`
						: `${dryModelOk?.spec ?? dryModelResolution.spec}（本次显式覆盖——临时生效，不改配置${dryModelOk?.note ? `；${dryModelOk.note}` : ""}）`;
				// ev-20260929-3c5db4：required 缺失已在上方提交点整单拒绝（不再到达此处）；此处保留
				// 可选输入/产物漏层提示行（pathDriftHint）与既有预检面同文案透出。
				const g = grant.value;
				const text = [
					`[task_submit dryRun · ${agentLabel} · ${dryModelInvalid ? "预检未通过（模型校验失败——正式派发将拒绝）" : newTreeDryRun ? "可验证项预检通过（目标树非全量验证）" : "预检通过"}，未 spawn 未入队（effects=none）]`,
				`工作目录: ${taskCwd}`,
				inherited.value.notice,
				// ev-20261007-ef07e6 + ev-20261017-cd233f：worktree 预检行——只校验不创建，报告将创建/复用的
				// 约定路径、检出基线（head/dirty-snapshot）与依赖接入面。
				...(wtPlan && wtBasis ? [
					`工作区: mode=worktree（dryRun 只校验不创建）→ 将${wtPlan.reused ? `复用 ${wtPlan.plannedPath}（分支 ${wtPlan.branch}，base=树自身 HEAD ${wtPlan.baseCommit?.slice(0, 8)}${wtBasis.base === "dirty-snapshot" ? "；请求 base=dirty-snapshot 不生效（复用不换基）" : ""}）` : `创建 ${wtPlan.plannedPath}（分支 ${wtPlan.branch}，${wtBasis.base === "dirty-snapshot" ? `base=dirty-snapshot：将把主树工作区冻结为快照 commit（HEAD ${wtPlan.baseCommit?.slice(0, 8)} + ${wtDirtyCount} 项未提交/未跟踪，排除 .amagi-worktrees；dryRun 不创建快照）` : `base=head（检出 HEAD ${wtPlan.baseCommit?.slice(0, 8)}；主树未提交/未跟踪文件不带入新检出）`}）`}（只读时刻计划，未检验后续写入/竞态）`,
					`依赖可见性: ${params.workspace?.dependencyVisibility ?? "unknown"}${(params.workspace?.dependencyVisibility ?? "unknown") === "portable" ? "（主树 node_modules 将以符号链接接入）" : "（主树依赖不接入，执行者自装）"}`,
					`输入基准: inputs/outputs 相对路径按调用者 cwd（${wtBasis.submitCwd}）解析为绝对路径后校验；界内路径换算为工作树内形态（${wtPlan.reused ? "复用树磁盘" : wtBasis.base === "dirty-snapshot" ? "脏快照基线（主树 Git 可见实存）" : "新树基线检出"}）核对；仓库根外/被 .gitignore 覆盖的实存输入按调用者侧跨树读取（无树内对应）。`,
					...inputBasisNotes,
				] : []),
				...(newTreeDryRun ? [
					`校验边界: 授权/deny 按计划 cwd 计算词法规则；${wtBasis!.base === "dirty-snapshot" ? "dirty-snapshot 输入按主树 Git 可见实存校验（快照=git add -A 的 Git 可见内容：遵守 .gitignore、排除 .amagi-worktrees；被 ignore 覆盖的实存输入不入树，按调用者侧跨树读取放行；树内可达性在正式提交创建树后按实际内容复验）" : "目标树路径实存/漂移、依赖连接未验证；主树未提交/未跟踪文件不带入新检出（未跟踪必读输入按调用者 cwd 实存放行，子 Agent 以绝对路径跨树读取）"}。`,
				] : []),
				`授权: assurance=${g.assurance} shell=${g.shell} write=[${g.write.length ? `${g.write.length} 条规则` : "无"}] reportFiles=[${g.reportFiles.length ? `${g.reportFiles.length} 条` : "无"}] mcp=[${g.mcp.map((m) => m.tool).join(",") || "无"}] lsp=[${g.lsp.join(",") || "无"}]`,
				`模型: ${dryModelLine}`,
				// ev-20260923-93ede6：请求 vs 角色上限可见性——预检通过意味着请求通道（shell/mcp/lsp）
				// 均落在角色上限内；附上限速查行供 Leader 对照其它请求（不扩 dryRun 校验面，仅展示）。
				// ev-20260930-c703e3：optional 降级时「均在上限内」不再成立——改标注降级事实，细节见降级行。
				...(agent.capabilities ? [`角色上限: ${roleChannelCapsSummary(agent.name, agent.capabilities)}${optionalDowngrade ? "（shell 请求已降级 deny，见下方降级行）" : "（请求通道均在上限内）"}`] : []),
					...(gaps.length ? [`⚠ 服务缺项（正式派发将在 spawn 前拒发，先修复）:`, ...gaps.map((x) => `  · ${x.channel}: ${x.reason}`)] : [newTreeDryRun ? "服务可用性: 未验证（目标树尚未创建，正式提交在真实 cwd 重检 mcp/lsp）" : "服务可用性: mcp/lsp 预检无缺项"]),
					...(pathDriftHint ? [pathDriftHint] : []),
					newTreeDryRun ? "[验证预检] 目标工作树尚未创建，入口、预算与依赖未验证（unknown）；正式派发在目标树重检。" : baselineHint(taskCwd, trusted, true, ctx.sessionManager?.getSessionId()),
					...(wtInputBasisNote ? [wtInputBasisNote] : []),
					...(optionalDowngrade ? [optionalDowngrade] : []),
					...(autoShellNotice ? [autoShellNotice] : []),
					...(shellGapHint ? [shellGapHint] : []),
					...(outputWriteHint ? [outputWriteHint] : []),
					...(driftHint ? [driftHint] : []),
					...(denyMentionHint ? [denyMentionHint] : []),
					"预检不产生任务记录；确认后去掉 dryRun 正式提交。",
				].join("\n");
				return okReturn(text, aggregateDetailsBlock(surfaceVersion, "none", dryModelInvalid ? ["修正 model 后重试 dryRun（当前 model 正式派发将被拒绝）"] : gaps.length ? ["修复服务缺项后重试 dryRun，或去掉相关请求通道"] : ["去掉 dryRun 正式提交"]));
			}
			// ── ev-20261017-348337：预检全通过后才建树（正式提交）——此前任何拒单零建树零分支 ──
			// ev-20261021-fix（diting F4）：建树/项目定位仍按任务工作目录（workspace.cwd 合并后的
			// taskCwd——依赖链接/subdirCheckout/项目根提示的基准）；仅声明路径解析基准（wtBasis.submitCwd）
			// 用真实调用者 cwd（ctx.cwd）。
			if (wtBasis) {
				wtLease = genTaskId();
				const wt = setupWorktree(taskCwd, (params.workspace?.worktreeName ?? "").trim(), { leaseId: wtLease, base: wtBasis.base });
				wtEffects = wt.effects ?? "none";
				if (!wt.ok || !wt.path || !wt.root || !wt.name) {
					return fail(err("worktree-dispatch-failed", `${wt.message ?? "[worktree 创建失败]"}——任务未派发（fail-closed：不静默回落请求 cwd；按提示修复后重提）`, ["workspace"], "none"));
				}
				wtInfo = wt;
				taskCwd = wt.path; // 派发 cwd 切到独立工作树：grant/deny 校验/spec/engineOpts/子进程 spawn/finalizer 全链以该路径为基准
				// ev-20261021-fix（diting F5）：创建后按实际树复验 tree 基线声明——预探测声称 tree 的
				// 输入必须在创建出的工作树内实存（git add 遵守 ignore/嵌套仓 gitlink 等不入树事实在此暴露，
				// 不再凭建树前探测虚假承诺）。未实存：调用者侧仍实存 → 改写为跨树绝对路径并披露（deny 已
				// 双形态校验，读面声明性）；调用者侧也消失（竞态）→ 准确拒单（未派发，可尝试零写入回滚）。
				const treeMiss = inputProbes
					.map((p, idx) => ({ p, idx }))
					.filter((x) => x.p.reachable === "tree" && !fs.existsSync(x.p.treeAbs!));
				let wtReverifyNote = "";
				if (treeMiss.length > 0) {
					const gone = treeMiss.filter((x) => !fs.existsSync(x.p.callerAbs));
					if (gone.length > 0) {
						return fail(err("required-input-missing",
							`建树后复验发现必读输入在创建的工作树与调用者侧均不存在（创建与派发间窗口被移除/重命名）：${gone.map((x) => x.p.declared).join("、")}——不派发`,
							["inputs"], "none",
							[{ hint: "核对路径是否被并发进程移除；重新提交将重新探测建树" }]));
					}
					childInputs = childInputs.map((ci, idx) => {
						const miss = treeMiss.find((x) => x.idx === idx);
						return miss ? { ...ci, path: miss.p.callerAbs } : ci;
					});
					wtReverifyNote = `[worktree 输入复验] ${treeMiss.length} 项预探测声称树内可达但未出现在创建的工作树（快照 Git 可见性/嵌套仓等）——已改写为调用者侧跨树绝对路径：${treeMiss.map((x) => x.p.declared).join("、")}`;
				}
				const depVis = params.workspace?.dependencyVisibility ?? "unknown";
				try { wtDepNote = prepareWorktreeDependencies(wt.root, wt.path, depVis, wt.subdirCheckout?.cwdRel); }
				catch (e) { return fail(err("worktree-dependency-failed", `依赖事实校验拒绝：${String(e instanceof Error ? e.message : e)}；核对连接后重提，不自动拆链接`, ["workspace.dependencyVisibility"], "unknown")); }
				if (wtReverifyNote) wtDepNote = `${wtDepNote}\n${wtReverifyNote}`;
				if (wt.baseAdvisory) wtDepNote = `${wtDepNote}\n${wt.baseAdvisory}`;
				wtFacts = {
					repoRoot: wt.root, worktreePath: wt.path, worktreeName: wt.name, branch: wt.branch!, leaseId: wtLease,
					...(wt.baseCommit !== undefined ? { baseCommit: wt.baseCommit } : {}), dependencyVisibility: depVis,
					...(wt.baseMode !== undefined ? { base: wt.baseMode } : {}),
				};
			}
			// ev-20261007-ef07e6：派发摘要行（wait 返回/handle 即时返回）与终态收口（lease 生命周期按 worktree.ts
			// 既有语义：任务终态 releaseWorktreeOwnership 释放所有权但保留目录供 Leader 检查，移除仍走既有清理
			// 命令含脏树检查，不自动删树；attachWorktreeTask 补齐所有权→任务身份绑定，审计环幂等）。
			// ev-20261017-cd233f：base 来源标注（仅 dirty-snapshot 追加 · 脏快照，head 缺省不加噪）。
			const wtHeadLine = wtInfo
				? `\n[worktree] ${wtInfo.branch}${wtInfo.reused ? "（复用）" : ""} @ ${wtInfo.path}${wtInfo.baseCommit ? `（base ${wtInfo.baseCommit.slice(0, 8)}${wtInfo.baseMode === "dirty-snapshot" ? " · 脏快照" : ""}）` : ""}；${wtDepNote}`
				: "";
			const wtTerminalLine = (taskId: string, status: string, stale: boolean | undefined): string => {
				if (!wtInfo || !wtLease || !wtInfo.root || !wtInfo.name || !wtInfo.path) return "";
				attachWorktreeLease(wtLease, taskId);
				releaseWorktreeLease(wtLease, `task ${status}`, taskId);
				let patchRef = "";
				try {
						const artDir = registry.get(taskId)?.artifactRefs?.[0];
						if (!stale && artDir) {
								const patch = worktreePatch(wtInfo.path, wtInfo.baseCommit);
								if (patch) { fs.writeFileSync(path.join(artDir, "worktree.patch"), patch, "utf8"); patchRef = `\n完整 patch: ${path.join(artDir, "worktree.patch")}`; }
						}
				} catch { /* lint-exempt:patch 落盘尽力而为，不阻断终态回流 */ }
				let dirtyNote = "";
				try {
						const insp = inspectWorktreeRemoval(wtInfo.root, wtInfo.name);
						if (insp.probeError) dirtyNote = `\n[worktree 未提交] 状态未知（探测失败：${insp.probeError.slice(0, 120)}）——不自动删除，请人工核实。`;
						else if (insp.dirtyPaths.length > 0) dirtyNote = `\n[worktree 未提交] 树内未提交 ${insp.dirtyPaths.length} 个路径，未自动删除——处置（回流/合并/显式丢弃）前请勿删除工作树。`;
				} catch { /* lint-exempt:探测失败不阻断终态回流 */ }
				return `\n\n[worktree ${wtInfo.branch}${wtInfo.reused ? " · 复用" : ""}] ${wtInfo.path}${wtInfo.baseCommit ? `（base ${wtInfo.baseCommit.slice(0, 8)}${wtInfo.baseMode === "dirty-snapshot" ? " · 脏快照" : ""}）` : ""}${wtDepNote ? `\n${wtDepNote}` : ""}\n${worktreeSummary(wtInfo.path, { root: wtInfo.root, baseline: wtInfo.mainBaseline, base: wtInfo.baseCommit })}${patchRef}${dirtyNote}\n[lease] 所有权已释放（任务 ${status}），目录保留供 Leader 检查；回收走既有 worktree 清理语义（脏树 fail-closed，不自动删树）；集成责任在 Leader（审查 diff 后合并）。`;
			};
			// ev-20260920-61839b：outputs[] 声明契约闭环①信息面——归一化后机器注入任务书末尾（子 Agent
			// 只看任务书正文；fast 型弱模型不再凭猜测落位 agent-outputs/）。注入段刻意不用「交付物：」
			// 标记格式（标记行按空白切 token，含空格路径会截断出注定缺失）；执法走结构化 deliverablePaths。
			// ev-20261017-348337：worktree 模式冻结换算后的子 Agent 侧落点（相对树根/界外绝对）。
			const declaredOutputs = childOutputs.map((o) => ({
				path: o.path, kind: o.kind ?? "file", required: o.required ?? true,
				...(o.purpose !== undefined ? { purpose: o.purpose } : {}),
			} as { path: string; kind: "file" | "tree"; required: boolean; purpose?: string }));
			// ev-20261007-ef07e6：worktree 作业纪律注入子进程任务书（与 legacy task 工具同语义——不 commit、
			// 改动留工作区由 Leader 汇总 diff；整仓检出/项目根提示复用 task-tool 同一实现，不造第二份文案）。
			const _fullRepoNote = wtInfo ? fullRepoCheckoutNote(wtInfo) : undefined;
			const wtBlock = wtInfo ? [
				`[amagi worktree] 你在 git worktree 中作业（分支 ${wtInfo.branch}，路径 ${wtInfo.path}）。不要 git commit——改动留在工作区，由 Leader 汇总 diff 后统一合并。`,
				...(_fullRepoNote ? [_fullRepoNote] : []),
				...(wtInfo.projectRootHint ? [`[amagi 项目根提示] 工作树根目录没有项目标记，真实项目根: ${wtInfo.projectRootHint}——安装/build/git diff/写盘以该目录为路径基准。`] : []),
				wtDepNote,
			].join("\n") : "";
			// ev-20261017-348337：worktree 模式注入子 Agent 实读绝对路径（树内可达=树内路径；跨树=调用者
			// cwd 绝对路径）；existing 模式不变（声明形态按任务工作目录解析）。
			const taskWithInputs = appendInputsSection(freezeSelectedEvidence(inherited.value.assignment, inherited.value.archive), childInputs, taskCwd);
			const taskWithOutputs = appendDeclaredOutputsSection(wtBlock ? `${taskWithInputs}\n\n${wtBlock}` : taskWithInputs, declaredOutputs, { cwd: taskCwd });
			const requiredOutputPaths = declaredOutputs.filter((o) => o.required).map((o) => o.path);
			const verificationHint = baselineHint(taskCwd, trusted, false, ctx.sessionManager?.getSessionId());
			const engineOpts = {
				cwd: taskCwd, signal, permission: grant.value, contextMode: inherited.value.mode,
				...(paramModel !== undefined ? { model: paramModel } : {}),
				...(wtFacts ? { worktreeDispatch: wtFacts } : {}),
				...(deps.testOpts?.testCommand !== undefined ? { command: deps.testOpts.testCommand } : {}),
				...(ctx.modelRegistry !== undefined ? { modelRegistry: ctx.modelRegistry as never } : {}),
				journalGoal: params.task,
				trusted,
				// ev-20260920-61839b：③契约面（spec.outputs 冻结）与④执法面（B1 预检结构化通道，
				//  仅 required 项；background 路径无 B1，结算面产物完整性兑底）
				outputs: declaredOutputs,
				deliverablePaths: requiredOutputPaths,
			};

			if (delivery === "wait") {
				wtDispatched = true; // F2：即将派发（spawn）——此后任何失败不再自动回滚删树
				const res = await svc.runTask(agent, taskWithOutputs, engineOpts);
				if (wtLease) { attachWorktreeLease(wtLease, res.taskId); releaseWorktreeLease(wtLease, `task ${res.blocked ? "blocked" : res.status}`, res.taskId); }
				const body0 = res.status === "cancelled"
					? appendCancellationReason(res.output, res.errorMessage)
					: res.status === "error" && !res.output
						? `[失败根因] ${res.errorMessage || res.spawnError || `(退出码 ${res.exitCode})`}${res.stderr ? `\n[stderr]\n${res.stderr}` : ""}`
						: res.output;
				const fin = await finalizeOf(res.taskId, agent.name, { ...res, output: body0 }, taskCwd, trusted);
				// D2（ev-20260922-727096）：error 终态附恢复指引（单源 recoveryActionOf；stable 面渲染）——
				// transient/quota 列出实际 task_resume 句柄（完整 taskId）与副作用核对说明；无 session 时给
				// artifact 接力，不造必失败的 resume；cancelled/用户取消不出现可 resume 建议。
				const recoveryNote = res.isError ? stableRecoveryNoteOf({ ...res, cwd: taskCwd }, { modelRegistry: ctx.modelRegistry }) : undefined;
				const text = `${inherited.value.notice}\n${verificationHint}\n${wtHeadLine}${driftHint ? `${driftHint}\n` : ""}${pathDriftHint ? `${pathDriftHint}\n` : ""}${wtInputBasisNote ? `${wtInputBasisNote}\n` : ""}${optionalDowngrade ? `${optionalDowngrade}\n` : ""}${autoShellNotice ? `${autoShellNotice}\n` : ""}${shellGapHint ? `${shellGapHint}\n` : ""}${outputWriteHint ? `${outputWriteHint}\n` : ""}${denyMentionHint ? `${denyMentionHint}\n` : ""}${res.fuseWarning || ""}${res.modelNote ? `${res.modelNote}\n` : ""}${modelNotice ? `${modelNotice}\n` : ""}[task_submit ${res.taskId.slice(0, 8)} ${agentLabel} · ${statusLabelOf(res)}]\n\n${fin.body}${wtTerminalLine(res.taskId, res.blocked ? "blocked" : res.status, fin.stale)}${res.completionAnnotation || ""}${blockedReplyDirective(res.taskId, res.blocked, res.blockReason)}${kernelViewLine(res.taskId)}${renderUsageFooter(res.taskId)}${recoveryNote ? `\n${recoveryNote}` : ""}`;
				if (res.isError) {
					const hasRecord = registry.get(res.taskId) !== undefined;
					// D2：repairExamples 的 resume 句柄用完整 taskId（不用可能歧义的八位前缀）+ 标准副作用核对
					// 消息；仅会话仍在且无准入阻塞时才列 resume 样例（否则只有 fresh 重派）。
					const _rec = registry.get(res.taskId);
					const resumeExample = _rec?.sessionId && !resumeAdmissionCodeOf(_rec)
						? [{ resume: { handle: res.taskId, message: RECOVERY_RESUME_MESSAGE } }]
						: [];
					return fail(err(
						"dispatch-failed",
						`任务未成功终态（status=${res.status}）：${(res.errorMessage || res.spawnError || "失败根因见正文").slice(0, 300)}`,
						["task"], hasRecord ? "unknown" : "none",
						[{ retry: "修因后重新 task_submit（新 taskId）" }, ...resumeExample],
					), text);
				}
				return okReturn(`${text}${pendingAcceptanceNote([res.taskId])}`, detailsBlockOf(peekTaskKernel()?.get(res.taskId), surfaceVersion, res.taskId));
			}

			// delivery=handle：立即返回句柄；终态经完成通知（pi）+ registry/查询可观察
			// ev-20260919：通知标题附任务书首行摘要——迟到的历史终态通知（如早前失败派发）与当前任务不再混淆。
			const taskBrief = params.task.split("\n").map((l) => l.trim()).find(Boolean)?.slice(0, 48) || "（无任务书正文）";
			const onComplete = (r: Readonly<RunResult>): void => {
				notifiedTasks.delete(r.taskId); waitTimeouts.delete(r.taskId);
				if (wtLease) { attachWorktreeLease(wtLease, r.taskId); releaseWorktreeLease(wtLease, `task ${r.blocked ? "blocked" : r.status}`, r.taskId); }
				endCacheWarmingLease(r.taskId); // B8：完成通知收窗（幂等；后台运行期 idle 保温窗口到此收口）
				const body0 = r.status === "cancelled" ? appendCancellationReason(r.output, r.errorMessage) : r.output;
				void finalizeOf(r.taskId, agent.name, { ...r, output: body0 }, taskCwd, trusted).then((fin) => {
					// D2（ev-20260922-727096）：error 终态完成通知同源附恢复指引（与 wait 返回同一 renderer/文案，
					// 不维护第二份）；cancelled/用户取消不出现可 resume 建议。
					const recoveryNote = r.status === "error" ? stableRecoveryNoteOf({ ...r, cwd: taskCwd }, { modelRegistry: ctx.modelRegistry }) : undefined;
					// ev-20260930-08a8e7：完成通知时重新探测（派发→完成窗口内可能已升级；同版本对只提示一次）
					const completeDriftHint = versionDriftNotice();
					// ev-20261101-cbf452：wait 已消费终态且终稿已落盘可回源 → 通知只发摘要+可回源 artifact+内核视图，
					// 不再重复报告全文；artifact 缺位（落盘失败/不适用）时保留全文——不可回源不摘要，不丢关键报告。
					const summarize = waitSummarizable(r) && fin.artifact !== null && waitConsumedTerminal.delete(r.taskId);
					const msg = summarize
						? `[task_submit 完成 ${agentLabel}/${r.taskId.slice(0, 8)}] 状态: ${r.status}｜任务: 「${taskBrief}」（终态已由 task_control wait 交付，此处不重复全文）
终稿归档: ${fin.artifact!.resultPath}｜metadata: ${fin.artifact!.metadataPath}｜回源: task_query({ handle: ${JSON.stringify(r.taskId.slice(0, 8))}, view: "receipt" })${fin.finalizationContext ? `\n[收尾新增信息]\n${fin.finalizationContext}` : ""}${r.completionAnnotation || ""}${recoveryNote ? `\n${recoveryNote}` : ""}${wtTerminalLine(r.taskId, r.blocked ? "blocked" : r.status, fin.stale)}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${completeDriftHint ? `\n${completeDriftHint}` : ""}`
						: `[task_submit 完成 ${agentLabel}/${r.taskId.slice(0, 8)}] 状态: ${r.blocked ? "blocked" : r.status}｜任务: 「${taskBrief}」\n${fin.body}${wtTerminalLine(r.taskId, r.blocked ? "blocked" : r.status, fin.stale)}${r.completionAnnotation || ""}${recoveryNote ? `\n${recoveryNote}` : ""}${blockedReplyDirective(r.taskId, r.blocked, r.blockReason)}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${completeDriftHint ? `\n${completeDriftHint}` : ""}`;
					try { sendTaskCompletion(deps.pi, msg, r.taskId); } catch { /* lint-exempt:通知失败不回滚终态，仍可按句柄查询 */ }
				}, () => {
					// ev-20261101-7fffc6：收尾链异常通知也走 custom 机器通道（details.taskId 回源）——此前直发
					// sendUserMessage 落成无标记 role=user，被 selected 交接当不可裁剪用户要求累积。
					try { sendTaskCompletion(deps.pi, `[task_submit 完成 ${agentLabel}/${r.taskId.slice(0, 8)}] 终态 ${r.status}（收尾链异常——详情 task_query({ handle: "${r.taskId.slice(0, 8)}" })）`, r.taskId); } catch { /* 同上 */ }
				});
			};
			wtDispatched = true; // F2：即将派发（spawn）——此后任何失败不再自动回滚删树
			const start = await svc.runBackgroundTask(agent, taskWithOutputs, { ...engineOpts, onComplete: onComplete as never });
			if (isBackgroundStart(start)) {
				if (!registry.get(start.taskId)?.endedAt) notifiedTasks.add(start.taskId);
				if (!registry.get(start.taskId)?.endedAt) beginCacheWarmingLease(start.taskId, "background"); // B8：后台运行期开窗（queued→自动启动同窗）
				if (wtLease) attachWorktreeLease(wtLease, start.taskId);
				backgroundOwnsLease = true; // 唯一移交出口；onComplete 在收尾前释放
				const head = start.status === "queued"
					? `[task_submit ${start.taskId.slice(0, 8)} ${agentLabel} · queued handle] 槽位已满入 FIFO 队列——晋级后自动启动，完成自动通知（无需轮询）`
					: `[task_submit ${start.taskId.slice(0, 8)} ${agentLabel} · handle 已启动] 完成后自动通知（无需轮询；期间可并行推进无关任务）`;
				return okReturn(`${head}\n${inherited.value.notice}\n${verificationHint}${wtHeadLine}${modelNotice ? `\n${modelNotice}` : ""}${pathDriftHint ? `\n${pathDriftHint}` : ""}${wtInputBasisNote ? `\n${wtInputBasisNote}` : ""}${optionalDowngrade ? `\n${optionalDowngrade}` : ""}${autoShellNotice ? `\n${autoShellNotice}` : ""}${shellGapHint ? `\n${shellGapHint}` : ""}${outputWriteHint ? `\n${outputWriteHint}` : ""}${driftHint ? `\n${driftHint}` : ""}${denyMentionHint ? `\n${denyMentionHint}` : ""}\n句柄: ${start.taskId}（wait/cancel 用 task_control；三轴用 task_query）${pendingAcceptanceNote([start.taskId])}`, detailsBlockOf(peekTaskKernel()?.get(start.taskId), surfaceVersion, start.taskId));
			}
			const failed = start as RunResult;
			if (wtLease) releaseWorktreeLease(wtLease, `task start-failed(${failed.status})`, failed.taskId);
			return fail(err(
				"dispatch-failed",
				`后台启动失败（status=${failed.status}）：${(failed.errorMessage || failed.spawnError || "启动失败").slice(0, 300)}`,
				["task"], "none", SUBMIT_MINIMAL_EXAMPLES,
			), `[task_submit ${failed.taskId.slice(0, 8)} ${agentLabel}] ${failed.errorMessage || failed.spawnError || "启动失败"}`);
			})();
			} catch (e) {
				// ev-20261017-348337 + ev-20261021-fix（diting F2）：异常路径同样只对**尚未派发**的新建树尝试
				// 零写入回滚（HEAD=创建基线 + 含 ignored 丢弃面为空）——回滚成立时 effects=none，正文与
				// details 同源（重建契约错误，不双轨）；已派发/回滚失败保守保留现场（unknown）。
				const message = e instanceof Error ? e.message : String(e);
				const rolled = tryRollbackFreshWorktree();
				const thrown: ContractError = {
					code: "internal-tool-error",
					message: `[task_submit] 工具执行异常（已捕获，未上抛宿主）：${message.slice(0, 400)}`,
					fields: [],
					effects: rolled ? "none" : "unknown",
					repairExamples: [
						{ retry: "同参数重试一次（多为瞬时故障）" },
						{ retry: "仍失败则先 task_query 观察任务三轴，再决定重发或取消" },
					],
				};
				return contractErrorReturn(thrown, rolled ?? retainedScene());
			} finally {
				if (wtLease && !backgroundOwnsLease) releaseWorktreeLease(wtLease, "submit scope exited（拒单/终态/异常）");
			}
		}),
	};

	// ── task_resume ──────────────────────────────────────────────────────────
	const taskResume: FacetToolDefinition<ResumeParams> = {
		name: "task_resume",
		label: "Amagi Task Resume",
		description: [
			"续接一个已有会话：handle（taskId/sessionId 前缀或稳定 name）+ message（答复/追加指令）必填。",
			"delivery=wait（缺省）阻塞到本轮终态；handle 立即返回关联新任务句柄，完成自动通知，可继续控制与查询。",
			"创建关联新 taskId（父链可见），继承原任务的范围与 cwd；模型按当前配置解析，父轮模型作为 fallback；可选 model 参数做一次恢复性覆盖（仅模型，不改配置、不扩权——provider 限流/配额恢复场景用，失败恢复指引会给可复制的换模调用）——不接受任何权限覆盖字段（扩权请新派任务）。",
			"典型用于：blocked 任务补答后继续；error 终态外部中断后的续接（先核对已完成写入与外部副作用，不重放已成功操作——旧 error 回执保留不改写）；返回新任务 details 与继承回显。",
		].join(" "),
		promptSnippet: `task_resume({ handle, message, delivery: "wait"|"handle" }) — 续接 blocked/error 会话（默认 wait；handle 完成自动通知）`,
		constrainedSampling: TASK_FACET_CONSTRAINED_SAMPLING,
		parameters: Type.Object({
			handle: Type.String({ description: "目标任务句柄（taskId/sessionId 前缀、稳定 name 或 runId/name）" }),
			message: Type.String({ description: "续接消息：答复提问或补充指令（冻结进新任务 assignment）" }),
			delivery: Type.Optional(StringEnum(["wait", "handle"], { description: "wait=阻塞到本轮终态（缺省）；handle=立即返回新句柄，完成自动通知" })),
			model: Type.Optional(Type.String({ description: "可选：本轮续接临时模型覆盖（单 spec \"provider/model[:thinking]\"，仅模型不改权限/范围；provider 限流/配额恢复场景用。缺省按当前配置解析，父轮模型作 fallback" })),
		}),
		execute: async (_id, params, signal, _onUpdate, ctx) => guardedExecute("task_resume", async () => {
			params = normalizeToolArgumentArtifacts(params); // ev-20260919+ev-20260920：同 task_submit（null 键与 "null" 字符串伪影）
			const shape = rejectUnknownParams(params as unknown as Record<string, unknown>, ["handle", "message", "delivery", "model"]);
			if (shape) return contractErrorReturn(shape);
			// ev-20261031-7110a8：可选临时模型覆盖（单 spec；归一/注册校验由 runResumeTask 同源拒绝）。
			const _mp = normalizeFacetModelParam(params.model);
			if (_mp.error) return fail(err(CONTRACT_ERROR_CODES.INVALID_FIELD, _mp.error, ["model"], "none", [{ handle: params.handle || "<taskId 前 8 位>", message: params.message || "<答复或继续指令>", model: "provider/model[:thinking]" }]));
			const resumeModel = _mp.model;
			const resumeModelNotice = _mp.notes.length > 0 ? _mp.notes.join("\n") : undefined;
			if (params.delivery !== undefined && params.delivery !== "wait" && params.delivery !== "handle") return fail(err(CONTRACT_ERROR_CODES.INVALID_ENUM, "delivery 必须为 wait 或 handle", ["delivery"], "none"));
			if (!params.handle || !params.message) {
				return fail(err(CONTRACT_ERROR_CODES.INVALID_FIELD, "handle 与 message 均必填（handle=目标任务句柄；message=答复/追加指令）", [!params.handle ? "handle" : "message"], "none", [{ handle: "<taskId 前 8 位>", message: "<答复或继续指令>" }]));
			}
			let resolved: Awaited<ReturnType<typeof resolveSessionForResume>> | undefined;
			try {
				// ev-20261005-055864：契约候选经统一对账入口处置后回填（旧链把候选门拒绝吞成「磁盘回退亦未命中」）；
				// 歧义 RegistryError 仍整段透传（ambiguous-handle，语义不变）
				resolved = await resolveSessionForResume(params.handle);
			} catch (e) {
				return fail(err("ambiguous-handle", `句柄 "${params.handle}" 命中多条记录（歧义）：${e instanceof Error ? e.message : String(e)}`, ["handle"], "none", [{ handle: "<完整 taskId（歧义候选其一）>", message: params.message }]));
			}
			if (!resolved) {
				return fail(err("unknown-handle", `未找到会话 "${params.handle}"（registry 无记录；磁盘回退亦未命中）`, ["handle"], "none", [{ handle: "<task_submit/task_query 返回的 taskId>", message: params.message }]));
			}
			const rec = resolved.record;
			const agent = findAgentByRequest(deps.agents, rec.agent);
			if (!agent) {
				return fail(err("unknown-agent", `原角色 "${rec.agent}" 不在名册（名册单源 agents-loader；可用：${agentNames.join(", ") || "（空）"}；旧名经别名归一后仍找不到——请新派任务承接原 artifact）`, ["handle"], "none"));
			}
			const resumeCwd = rec.cwd ?? ctx.cwd;
			if (rec.cwd && !fs.existsSync(rec.cwd)) {
				return fail(err("workspace-missing", `原任务工作目录已不存在: ${rec.cwd}（会话与原目录绑定；请新派任务）`, ["handle"], "none", [{ agent: rec.agent, task: "<重写任务书后重新提交>" }]));
			}
			// F4：原树身份复核、新 lease、新 taskId；所有拒单/异常均释放，不能继承父已释放 lease。
			const parentContract = await loadResumeParentContract(rec.taskId);
			if (!parentContract.ok) return fail(err("workspace-spec-unavailable", `无法读取父冻结契约，不能降级 legacy 或跳过 worktree 所有权：${parentContract.error.code}: ${parentContract.error.message}；请新派任务承接原产物`, ["handle"], "none"));
			// F8：仅 store 明确无记录且内核无父任务才走历史链；workspace/授权/outputs 同源。
			const parentWs = parentContract.value?.workspace;
			let resumeWt: WorktreeDispatchFacts | undefined;
			let resumeLease: string | undefined;
			let backgroundOwnsLease = false;
			try {
			if (parentWs?.mode === "worktree") {
				if (!parentWs.repoRoot || !sameFacetPath(parentWs.cwd, resumeCwd)) return fail(err("worktree-resume-invalid", "冻结 workspace 缺原仓身份或 cwd 不一致；不回落主树，请新派任务", ["handle"], "none"));
				resumeLease = genTaskId();
				const prior = worktreeOwnership().find((o) => o.leaseId === parentWs.leaseId);
				const expectedBranch = parentWs.branch ?? prior?.branch;
				if (!expectedBranch) return fail(err("worktree-resume-invalid", "旧 worktree spec 缺冻结分支身份且 lease 已不可查；无法证明原树身份，请新派任务（不猜分支、不继承旧 lease）", ["handle"], "none"));
				const acquired = acquireWorktreeAtPath(resumeCwd, resumeLease, { repoRoot: parentWs.repoRoot, branch: expectedBranch });
				if (!acquired.ok) return fail(err("worktree-resume-invalid", acquired.message, ["handle"], "none"));
				const o = acquired.owner;
				try { prepareWorktreeDependencies(parentWs.repoRoot, o.path, parentWs.dependencyVisibility); }
				catch (e) { return fail(err("worktree-dependency-failed", `续接依赖事实不一致：${String(e instanceof Error ? e.message : e)}；未派发，核对连接后重提`, ["handle"], "unknown")); }
				resumeWt = { repoRoot: parentWs.repoRoot, worktreePath: o.path, worktreeName: o.name, branch: o.branch, leaseId: resumeLease, baseCommit: o.baseCommit, dependencyVisibility: parentWs.dependencyVisibility };
			}
			const trusted = trustedOf(ctx);
			const onComplete = (r: Readonly<RunResult>): void => {
				if (resumeWt) { attachWorktreeLease(resumeWt.leaseId, r.taskId); releaseWorktreeLease(resumeWt.leaseId, `resume ${r.status}`, r.taskId); }
				if (params.delivery !== "handle") return;
				notifiedTasks.delete(r.taskId); waitTimeouts.delete(r.taskId); endCacheWarmingLease(r.taskId);
				const body0 = r.status === "cancelled" ? appendCancellationReason(r.output, r.errorMessage) : r.output;
				void finalizeOf(r.taskId, agent.name, { ...r, output: body0 }, resumeCwd, trusted).then(fin => {
					const gap = (r.blocked || r.isError) ? resumePermissionGap(`${r.output}\n${r.errorMessage || ""}\n${r.spawnError || ""}`) : undefined;
					const recovery = r.status === "error" && !gap ? stableRecoveryNoteOf({ ...r, cwd: resumeCwd }, { modelRegistry: ctx.modelRegistry }) : undefined;
					const drift = versionDriftNotice();
					// ev-20261101-cbf452：同 task_submit——wait 已消费终态且 artifact 可回源时只发摘要；gap（工具/权限
					// 缺失指引）不受摘要影响照常保留，blocked 保留完整终稿。
					const summarize = waitSummarizable(r) && fin.artifact !== null && waitConsumedTerminal.delete(r.taskId);
					const msg = summarize
						? `[task_resume 完成 ${agent.name}/${r.taskId.slice(0, 8)}] 状态: ${r.status}｜父会话 ${rec.taskId}（终态已由 task_control wait 交付，此处不重复全文）
${r.modelNote ? `${r.modelNote}\n` : ""}终稿归档: ${fin.artifact!.resultPath}｜metadata: ${fin.artifact!.metadataPath}｜回源: task_query({ handle: ${JSON.stringify(r.taskId.slice(0, 8))}, view: "receipt" })${fin.finalizationContext ? `\n[收尾新增信息]\n${fin.finalizationContext}` : ""}${r.completionAnnotation || ""}${recovery ? `\n${recovery}` : ""}${gap ? resumePermissionAdvice(agent.name, gap) : ""}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${drift ? `\n${drift}` : ""}`
						: `[task_resume 完成 ${agent.name}/${r.taskId.slice(0, 8)}] 状态: ${r.blocked ? "blocked" : r.status}｜父会话 ${rec.taskId}\n${r.modelNote ? `${r.modelNote}\n` : ""}${fin.body}${r.completionAnnotation || ""}${recovery ? `\n${recovery}` : ""}${gap ? resumePermissionAdvice(agent.name, gap) : blockedReplyDirective(r.taskId, r.blocked, r.blockReason)}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${drift ? `\n${drift}` : ""}`;
					try { sendTaskCompletion(deps.pi, msg, r.taskId); } catch { /* 通知失败不回滚终态 */ }
				}, () => {
					// ev-20261101-7fffc6：同 task_submit——收尾链异常通知走 custom 机器通道（details.taskId）。
					try { sendTaskCompletion(deps.pi, `[task_resume 完成 ${agent.name}/${r.taskId.slice(0, 8)}] 终态 ${r.status}（收尾链异常——详情 task_query({ handle: "${r.taskId}" })）`, r.taskId); } catch { /* lint-exempt:通知失败不回滚终态，仍可按句柄查询 */ }
				});
			};
			const res = await svc.runResumeTask(agent, { session: params.handle, task: params.message, ...(resumeModel !== undefined ? { model: resumeModel } : {}), background: params.delivery === "handle" }, {
				cwd: resumeCwd, signal, resumeParentSpec: parentContract.value,
				onComplete: onComplete as never,
				...(resumeWt ? { worktreeDispatch: resumeWt } : {}),
				...(deps.testOpts?.testCommand !== undefined ? { command: deps.testOpts.testCommand } : {}),
				...(ctx.modelRegistry !== undefined ? { modelRegistry: ctx.modelRegistry as never } : {}),
				trusted,
			});
			if (isBackgroundStart(res)) {
				if (!registry.get(res.taskId)?.endedAt) notifiedTasks.add(res.taskId);
				if (resumeLease) attachWorktreeLease(resumeLease, res.taskId);
				backgroundOwnsLease = true;
				if (!registry.get(res.taskId)?.endedAt) beginCacheWarmingLease(res.taskId, "background"); // B8：resume 后台运行期开窗（收口：wait 终态/cancel/预算）
				return okReturn(`${res.modelNote ? `${res.modelNote}\n` : ""}${resumeModelNotice ? `${resumeModelNotice}\n` : ""}[task_resume ${res.taskId.slice(0, 8)} ${agent.name} · ${res.status} handle] 已入执行链（完成自动通知，无需轮询；父会话 ${rec.taskId}）\n句柄: ${res.taskId}（wait/cancel/steer 用 task_control；三轴用 task_query）${pendingAcceptanceNote([res.taskId, rec.taskId])}`, detailsBlockOf(peekTaskKernel()?.get(res.taskId), surfaceVersion, res.taskId));
			}
			if (resumeLease) { if (!res.rejected) attachWorktreeLease(resumeLease, res.taskId); releaseWorktreeLease(resumeLease, `resume ${res.status}`, res.taskId); }
			// 准入前拒绝（未 spawn/未建新记录）：直接透出根因，禁入收尾链（旧任务幂等缓存会顶掉根因）
			if ((res as { rejected?: boolean }).rejected) {
				// ev-20261021-a8de95：「运行中」拒绝而本会话并不持有其运行实体（跨重启/回填投影）——
				// registry 状态只是历史快照；给出 historical 说明与 reconcile 出口，替代无路可走的「运行中」。
				if (rec.status === "running" && !sessionOwnsRun(rec.taskId)) {
					const hist = await describeStoredControlTarget(rec.taskId, "task_resume");
					if (hist) return fail(err("historical-task", `续接被拒绝：记录状态为 running，但${hist}`.slice(0, 1200), ["handle"], "none", [{ action: "reconcile", handles: [rec.taskId], reason: "<可追溯理由>" }]), res.stderr || res.errorMessage || "运行中");
				}
				return fail(err("resume-rejected", (res.errorMessage || "续接被拒绝（未启动）").split("\n", 1)[0].slice(0, 400), ["handle"], "none", [{ handle: params.handle, message: "<按根因修正后续接>" }]), res.stderr || res.errorMessage || "续接被拒绝（未启动）");
			}
			const body0 = res.status === "cancelled"
				? appendCancellationReason(res.output, res.errorMessage)
				: res.status === "error" && !res.output
					? `[失败根因] ${res.errorMessage || res.spawnError || `(退出码 ${res.exitCode})`}`
					: res.output;
			const fin = await finalizeOf(res.taskId, agent.name, { ...res, output: body0 }, resumeCwd, trusted);
			const inherit = [
				`cwd=${resumeCwd}`,
				`本轮模型=${registry.get(res.taskId)?.model ?? "宿主默认（未声明）"}`,
				rec.allowedPaths?.length ? `白名单 ${rec.allowedPaths.length} 项（继承不扩权）` : "白名单=无",
			].join("；");
			const gap = (res.blocked || res.isError) ? resumePermissionGap(`${res.output}\n${res.errorMessage || ""}\n${res.spawnError || ""}`) : undefined;
			const text = `${res.fuseWarning || ""}${res.modelNote ? `${res.modelNote}\n` : ""}${resumeModelNotice ? `${resumeModelNotice}\n` : ""}[task_resume ${res.taskId.slice(0, 8)} ${agent.name} · ${statusLabelOf(res)}]（父会话 ${rec.taskId.slice(0, 8)}；继承：${inherit}）\n\n${fin.body}${res.completionAnnotation || ""}${gap ? resumePermissionAdvice(agent.name, gap) : blockedReplyDirective(res.taskId, res.blocked, res.blockReason)}${kernelViewLine(res.taskId)}${renderUsageFooter(res.taskId)}`;
			if (res.isError) {
				// D2（ev-20260922-727096）：续接轮自身失败同样附恢复指引（单源；完整 taskId 句柄）。
				const recoveryNote = gap ? undefined : stableRecoveryNoteOf({ ...res, cwd: rec.cwd }, { modelRegistry: ctx.modelRegistry });
				return fail(err("resume-failed", `续接未成功终态（status=${res.status}）：${(res.errorMessage || res.spawnError || "失败根因见正文").slice(0, 300)}`, ["handle"], "unknown", gap ? [resumePermissionExample(agent.name, gap)] : [{ handle: res.taskId, message: RECOVERY_RESUME_MESSAGE }]), `${text}${recoveryNote ? `\n${recoveryNote}` : ""}`);
			}
			return okReturn(`${text}${pendingAcceptanceNote([res.taskId, rec.taskId])}`, detailsBlockOf(peekTaskKernel()?.get(res.taskId), surfaceVersion, res.taskId));
			} finally {
				if (resumeLease && !backgroundOwnsLease) releaseWorktreeLease(resumeLease, "resume scope exited");
			}
		}),
	};

	// ── task_control ─────────────────────────────────────────────────────────
	const taskControl: FacetToolDefinition<ControlParams> = {
		name: "task_control",
		label: "Amagi Task Control",
		description: [
			"对已提交任务做控制：wait（handles+mode/timeoutMs，超时只观察不取消）/ cancel（handles+reason）/ resolve-external（handles+reason，产物已在外部采用的轻量收口）/ steer（单一 handle+message，对 queued/running 任务投递运行中调整——子 Agent 下一模型请求前注入且持续可见，任务书边界不变；blocked 改用 task_resume）/ accept·reject（单一 handle+reason；expectedRevision 为可选陈旧栅栏，省略按当前回执处理；receiptId 缺省或 \"latest\" 即引用当前回执，手抄差 1~2 字符自动纠正；accept 可携 waivedCheckIds——error 终态 accept 必含 \"error-execution-coverage\"（缺失即拒））/ reconcile（handles+reason，恢复对账：本会话不持有运行实体的历史契约任务——只读探测存活进程，宿主已退出则确认退出并按未完成关闭（不猜成功、不重放），仍存活/探测不可用/foreign-owner 拒绝并说明）。",
			"accept 标准流（示例）：task_control({ action: \"accept\", handle, reason, waivedCheckIds: [<回执 missing 的 id>] })——receiptId 省略即当前回执；revision/missing 取自完成通知的内核视图行或 task_query({ handle, view: \"receipt\" })；如需陈旧决策栅栏可加 expectedRevision: <revision>；stale-revision 拒绝→重取新 revision 再提交，勿盲重试。",
			"wait 遇到失败任务仍是正常查询结果；非法参数/非法组合/歧义句柄在任何动作前整单拒绝（effects=none）。",
			"控制成功≠任务目标完成；accept 后暂停组自动续跑（requires=accepted 边解锁）。",
		].join(" "),
		promptSnippet: `task_control({ action: "wait"|"cancel"|"resolve-external"|"steer"|"accept"|"reject"|"reconcile", ... }) — 控制、运行中调整、显式接受与恢复对账`,
		constrainedSampling: TASK_FACET_CONSTRAINED_SAMPLING,
		parameters: Type.Object({
			action: StringEnum([...CONTROL_ACTIONS], { description: "控制动作（七种；字段组合按动作封闭校验）" }),
			handles: Type.Optional(Type.Array(Type.String(), { description: "wait/cancel/resolve-external/reconcile 的任务句柄清单（非空；accept/reject/steer 不用）" })),
			handle: Type.Optional(Type.String({ description: "accept/reject/steer 的单一任务句柄" })),
			mode: Type.Optional(StringEnum(["any", "all"], { description: "wait 模式：any=首个终态即返（缺省）；all=全部终态" })),
			timeoutMs: Type.Optional(Type.Number({ description: "wait 上限 ms（缺省 120000；超时只观察不取消）" })),
			reason: Type.Optional(Type.String({ description: "cancel/resolve-external/reconcile/accept/reject 的可追溯理由（必填）" })),
			message: Type.Optional(Type.String({ description: "steer 的运行中调整指令（必填；任务书边界不变，子 Agent 按此修正方向继续）" })),
			receiptId: Type.Optional(Type.String({ description: "accept/reject 引用的回执：缺省或 \"latest\"=当前回执（推荐，免手抄）；显式 id 须为当前回执（差 1~2 字符的转录误差自动纠正）" })),
			expectedRevision: Type.Optional(Type.Number({ description: "accept/reject 可选失效栅栏：决策时的任务 revision（提供则不匹配即拒；省略按当前回执处理）" })),
			waivedCheckIds: Type.Optional(Type.Array(Type.String(), { description: "accept 显式豁免的检查 id（仅 accept；须 ⊆ 回执 missing∪checks；error 终态必须含 error-execution-coverage）" })),
		}),
		execute: async (_id, params, _signal, _onUpdate, _ctx) => guardedExecute("task_control", async () => {
			params = normalizeToolArgumentArtifacts(params); // ev-20260919+ev-20260920：null 键与 "null" 字符串伪影视为缺席——accept 等动作不再被 wait 专属参数伪影拒收
			const shape = rejectUnknownParams(params as unknown as Record<string, unknown>, ["action", "handles", "handle", "mode", "timeoutMs", "reason", "message", "receiptId", "expectedRevision", "waivedCheckIds"]);
			if (shape) return contractErrorReturn(shape);
			// 判别联合校验（§3.3 ControlCommand）：互斥字段组合在构造命令时整单拒绝
			const raw: Record<string, unknown> = { action: params.action };
			for (const key of ["handles", "handle", "mode", "timeoutMs", "reason", "message", "receiptId", "expectedRevision", "waivedCheckIds"] as const) {
				if (params[key] !== undefined) raw[key] = params[key];
			}
			// ev-20261028-965993：accept/reject 缺省 receiptId = 引用当前回执（同 "latest"）——失效栅栏由 expectedRevision
			// 与内核 unreviewed 前置承担；不再要求模型手抄 44 位 id。
			if ((params.action === "accept" || params.action === "reject") && raw.receiptId === undefined) raw.receiptId = "latest";
			// ev-20261108-a5504b：expectedRevision 与 receiptId 同口径宽容——缺省/不可解析（undefined、NaN、非数字串、负数/小数）
			// 视为「未提供栅栏」按当前回执 revision 处理并披露；显式合法值（含数字串）才做 stale-revision 校验。
			// 栅栏本职（防陈旧决策）仍由 receiptId 匹配 + 内核 unreviewed 前置承担。
			let fenceNote = "";
			let fenceOmitted = false;
			if (params.action === "accept" || params.action === "reject") {
				const rawRev: unknown = raw.expectedRevision;
				const coerced = typeof rawRev === "string" && /^\s*\d+\s*$/.test(rawRev) ? Number(rawRev) : rawRev;
				if (typeof coerced === "number" && Number.isInteger(coerced) && coerced >= 0) {
					raw.expectedRevision = coerced;
				} else {
					fenceOmitted = true;
					raw.expectedRevision = 0; // 占位通过形状校验；下方按 fenceOmitted 跳过比对
					fenceNote = rawRev === undefined
						? "未提供 expectedRevision，按当前回执 revision 处理（无陈旧决策栅栏；需要栅栏时传 task_query view=receipt 的 revision）"
						: `expectedRevision=${JSON.stringify(rawRev)} 不是非负整数，已忽略并按当前回执 revision 处理（正确来源：task_query({ handle, view: "receipt" }) 的 revision 字段）`;
				}
			}
			const vcmd = validateControlCommand(raw);
			if (!vcmd.ok) {
				// ev-20261021-fix（diting F1）：撤销无条件形状栅栏后 invalid-receipt-id 不再由命令校验发出；
			// 形状口径降级为 stale-receipt 不匹配诊断（下方同源），基础类型负例报错优先级不变。
				return contractErrorReturn(withRepair(vcmd.error, controlRepairExamples(params.action, {})));
			}
			const cmd = vcmd.value;

			if (cmd.action === "wait") {
				const resolved = await resolveControlHandles(cmd.handles, "wait");
				if (!resolved.ok) return contractErrorReturn(resolved.error);
				// B8（设计 §5.5）：wait 开窗/刷新窗（每次显式 wait 起点=新的单次等待窗口）。阻塞等待期间
				// 会话在 streaming 相位（决策器恒 delegate，宿主 P=1 自行裁决）；真实价值窗口是超时返回后
				// 未决任务仍在跑的 idle 期——故只对终态任务收窗，未决 lease 保留到完成通知/cancel/预算
				// （「并发任务全部结束才结束等待状态」）；svc.wait 异常时同样保留（预算兑底）。
				for (const id of resolved.value) beginCacheWarmingLease(id, "wait");
				const wr = await svc.wait([...resolved.value], cmd.mode ?? "any", cmd.timeoutMs ?? 120_000);
				{
					const settledIds = new Set(wr.settled.map((s) => s.taskId));
					for (const id of resolved.value) if (settledIds.has(id)) endCacheWarmingLease(id);
					// ev-20261101-cbf452：wait 已交付的终态记为已消费（含 blocked——wait 已给出状态行与结构化问题；
					// 通知摘要化另行按 waitSummarizable 剔除 blocked）——此后到达的完成通知不再重复全文。
					for (const s of wr.settled) if (s.status !== "unknown") noteWaitConsumed(s.taskId);
				}
				const settledLines = wr.settled.map((s) => {
					const rec = s.record;
					let text = `  ${s.taskId.slice(0, 8)} ${s.status}${s.status === "blocked" ? "（blocked 已退出，可 task_resume）" : ""}${kernelViewLine(s.taskId)}`;
					// Batch 3（§9.5 成本进入 footer）：wait 纯读渲染已聚合终值——重复 wait 数值逐字相同（幂等）
					const _uf = renderUsageFooter(s.taskId, { inline: true });
					if (_uf) text += `\n  ${_uf}`;
					if (s.status === "blocked") {
						text += rec?.blockReason === "needs-handoff"
							? `\n需接手 ${s.taskId}：NEEDS_HANDOFF（非提问）；task_resume({ handle: ${JSON.stringify(s.taskId)}, message: "先核对已有产物，再继续原任务未完成部分。" })`
							: `\n待答问题 ${s.taskId}:\n${blockedQuestionsTextForWait(rec)}`;
					}
					return text;
				});
				const pendingLines = wr.pendingDetails.map((p) => `  ${p.taskId.slice(0, 8)} 未决 · 已 ${Math.round(p.elapsedMs / 1000)}s · ${p.admission} · 最近活动: ${p.lastActivity || "（无）"}${p.lastActivityAgeMs !== undefined ? `（距今 ${Math.round(p.lastActivityAgeMs / 1000)}s）` : ""}`);
				// ev-20261012-381ddb：超时返回附建议等待时长（按最近活动间隔估算）与纯通知出口——
				// 30-60min 任务连续低信息量超时空转（每任务 2-4 轮、全会话 8-12 轮），把「等多久」
				// 与「可不等」就地给出；mode=any 取最短（最早可能终态）、all 取最长（全终态约束）。
				const suggestList = wr.pendingDetails.map((p) => p.suggestedNextWaitMs).filter((v): v is number => typeof v === "number");
				const suggestedWaitMs = (cmd.mode ?? "any") === "any" ? Math.min(...suggestList) : Math.max(...suggestList);
				const advice = wr.timedOut && suggestList.length > 0 && suggestedWaitMs > (cmd.timeoutMs ?? 120_000)
					? `[等待建议] 下次 wait timeoutMs ≥ ${Math.ceil(suggestedWaitMs / 1000)}s（按最近活动间隔估算）；handle 交付的任务完成会自动通知，无并行推进项时可先做其它工作、等通知再处理。`
					: undefined;
				const waitAdvice = advice && !shownWaitAdvice.has(advice) ? advice : undefined;
				if (waitAdvice) shownWaitAdvice.add(waitAdvice);
				let repeatedNotified = false;
				if (wr.timedOut && wr.settled.length === 0) for (const id of wr.pending) {
					const count = (waitTimeouts.get(id) ?? 0) + 1;
					if (waitTimeouts.size >= 256 && !waitTimeouts.has(id)) waitTimeouts.delete(waitTimeouts.keys().next().value!);
					waitTimeouts.set(id, count);
					if (count >= 2 && notifiedTasks.has(id)) repeatedNotified = true;
				}
				const text = [
					`[task_control wait · ${cmd.mode ?? "any"}${wr.timedOut ? " · 超时（只观察不取消）" : " · 完成"}]`,
					...(settledLines.length ? ["终态:", ...settledLines] : []),
					...(pendingLines.length ? [`未决 ${pendingLines.length}（超时只报告；可继续 wait 或 cancel）:`, ...pendingLines] : []),
					...(waitAdvice ? [waitAdvice] : []),
					...(repeatedNotified ? ["[等待提示] 本任务已登记完成自动通知；连续纯观察超时，可先推进其它工作，收到通知后处理。显式同步 wait 仍可用，超时不取消任务。"] : []),
				].join("\n");
				// 被 wait 的任务终态已在上方列出，提醒只带出其它被遗忘的待接受任务（diting 同类入口建议）。
				return okReturn(`${text}${pendingAcceptanceNote(resolved.value)}`, singleOrMultiDetails(surfaceVersion, resolved.value, wr.timedOut ? ["继续 wait 或 cancel"] : undefined));
			}

			if (cmd.action === "cancel" || cmd.action === "resolve-external") {
				const resolved = await resolveControlHandles(cmd.handles, cmd.action);
				if (!resolved.ok) return contractErrorReturn(resolved.error);
				const lines: string[] = [];
				let okCount = 0;
				for (const taskId of resolved.value) {
					const r = cmd.action === "cancel" ? svc.cancel(taskId, cmd.reason) : svc.resolveExternal(taskId, cmd.reason);
					if (r.ok) {
						okCount++;
						endCacheWarmingLease(taskId); // B8：取消/外部收口=等待窗口终结（幂等）
					}
					// ev-20261021-a8de95：失败且本会话不持有运行实体（回填投影/跨重启残留）→ 附 historical 说明与 reconcile 出口
					const hist = !r.ok && !sessionOwnsRun(taskId) ? await describeStoredControlTarget(taskId, cmd.action) : undefined;
					lines.push(`  ${taskId.slice(0, 8)} ${r.ok ? "✓" : "✗"} ${r.message}${hist ? `\n    ${hist}` : ""}`);
				}
				const text = `[task_control ${cmd.action} · ${resolved.value.length} 任务 · 成功 ${okCount}]\n${lines.join("\n")}`;
				if (okCount === 0) {
					return fail(err("control-all-failed", `${cmd.action} 全部失败（逐任务结果见正文——多为已终态拒绝）`, ["handles"], "none", [{ action: "wait", handles: [...cmd.handles], mode: "all", timeoutMs: 5000 }]), text);
				}
				return okReturn(text, singleOrMultiDetails(surfaceVersion, resolved.value));
			}

			// ev-20261021-a8de95：恢复对账——逐任务按启动锚点证明退出（只读），证明退出则关闭为未完成，live/unknown/foreign 拒绝
			if (cmd.action === "reconcile") {
				const lines: string[] = [];
				let okCount = 0;
				const ids: string[] = [];
				for (const h of cmd.handles) {
					const o = await reconcileStoredTask(h, cmd.reason, { ownerId: peekTaskKernel()?.ownerId ?? deps.caller.ownerId });
					if (o.ok) okCount++;
					ids.push(o.taskId);
					lines.push(`  ${o.taskId.slice(0, 8)} ${o.ok ? "✓" : "✗"} [${o.state}] ${o.message}`);
				}
				const text = `[task_control reconcile · ${cmd.handles.length} 任务 · 成功 ${okCount}]\n${lines.join("\n")}`;
				if (okCount === 0) {
					return fail(err("reconcile-rejected", `reconcile 全部未执行（逐任务状态见正文：live=仍有存活进程 / unknown=探测不可用 / foreign-owner=须主上 adopt / session-owned=本会话持有）`, ["handles"], "none", [{ action: "wait", handles: [...cmd.handles], mode: "all", timeoutMs: 5000 }]), text);
				}
				return okReturn(text, singleOrMultiDetails(surfaceVersion, ids));
			}

			// steer：单一 handle + message——对 queued/running 任务投递运行中调整（通道注入见 task-steer.ts）
			if (cmd.action === "steer") {
				const resolved = await resolveControlHandles([cmd.handle], "steer");
				if (!resolved.ok) return contractErrorReturn(resolved.error);
				const taskId = resolved.value[0]!;
				const r = svc.steer(taskId, cmd.message);
				// ev-20260930-0dd26f（R6）：文案只对 pendingActive 承诺「下个模型请求前注入」；
				// inactiveUnacked（被活跃字节预算淘汰且从未注入）明示不会自动注入——旧「未送达 N 条待下次
				// 请求注入」合计口径会虚假承诺淘汰项，已废除。
				const steerNote = r.ok
					? `\n  （通道 #${r.seq}；未注入合计 ${r.pending ?? 0}——其中活跃待注入 ${r.pendingActive ?? 0} 条将在下个模型请求前注入${(r.inactiveUnacked ?? 0) > 0 ? `；另有 ${r.inactiveUnacked} 条已被活跃字节预算淘汰、不会自动注入（如需传达请 task_resume 新一轮）` : "；无淘汰未注入项"}；任务书边界不变，不构成新契约）`
					: "";
				const text = `[task_control steer ${taskId.slice(0, 8)} · ${r.status}]\n  ${r.message}${steerNote}`;
				// ev-20260930-0dd26f（R6）：新 steer 写入后低频触发通道生命周期 GC（30 分钟节流、
				// 错误计入返回值不影响投递/结算；fire-and-forget）
				if (r.ok) void maybeSweepSteerChannels();
				if (!r.ok) {
					return fail(err("steer-rejected", r.message, ["handle"], "none", controlRepairExamples("steer", { handle: taskId })), text);
				}
				return okReturn(text, singleOrMultiDetails(surfaceVersion, [taskId]));
			}

			// accept / reject：单一 handle + 当前回执 + 失效栅栏；actor 取 CallerContext（N8：模型参数不能伪造身份）
			const resolved = await resolveControlHandles([cmd.handle], cmd.action, peekTaskKernel()?.ownerId ?? deps.caller.ownerId);
			if (!resolved.ok) return contractErrorReturn(resolved.error);
			const taskId = resolved.value[0];
			let view = peekTaskKernel()?.get(taskId);
			if (!view) {
				// v2.5.1（diting MJ-2）：重启后回执任务无内核视图——先经 store 回退静默补种子再判定
				// （恢复对账把 clean-complete 归为 no-action 不种子；decideTaskReceipt 同源回退）。
				const kernel0 = getTaskKernel({ ownerId: deps.caller.ownerId });
				if (kernel0 && typeof kernel0.seedFromStoreIfAbsent === "function" && await kernel0.seedFromStoreIfAbsent(taskId)) {
					view = kernel0.get(taskId);
				}
			}
			if (!view) {
				return fail(err("no-contract-view", `任务 ${taskId} 无内核契约视图（accept/reject 只对回执任务成立；legacy 任务详情用 task_query）`, ["handle"], "none"));
			}
			const repair = controlRepairExamples(cmd.action, { handle: taskId, receiptId: view.receipt?.receiptId, expectedRevision: view.revision });
			if (!view.receipt) {
				return fail(err("no-receipt", `无当前回执（settlement=${view.settlement}）——accept/reject 引用当前 receiptId；回执由终稿收尾链发布`, ["receiptId"], "none", repair));
			}
			// ev-20261028-965993：receiptId/waivedCheckIds 输入归一——latest/current 词元解析为当前回执；与当前值等长且
			// ≤NEAR_MISS_MAX 字符之差的转录畸变就地纠正并披露（旧回执为独立随机 uuid，不会落入该距离）。
			const normalized = normalizeDecisionRefs(cmd.receiptId, cmd.action === "accept" ? cmd.waivedCheckIds : undefined, view.receipt);
			if (fenceNote && view.receipt.receiptSeq !== undefined && view.receipt.receiptSeq > 1) fenceNote += `；注意当前回执 receiptSeq=${view.receipt.receiptSeq}（本任务回执已更新过，确认决策针对的是最新回执）`;
			const normNote = normalized.notes.length || fenceNote ? `\n[输入归一] ${[...normalized.notes, ...(fenceNote ? [fenceNote] : [])].join("；")}` : "";
			if (view.receipt.receiptId !== normalized.receiptId) {
				// D1：stale 先报——repair 基于当前回执给当前 id（不混上轮 id）；repairExamples 进结构化 details。
				// ev-20261014-4f7500：附机器可读差异定位（首差位+两侧片段+长度差）+ 勿手抄提示——
				// 44 位 hex 目视比对不可靠（事故中两侧完整渲染仍被误读为「字节相同」）。
				// ev-20261021-fix（diting F1）：形状降为不匹配诊断——非 uuid 形状提示疑似转录畸变；当前回执
				// 自身非 uuid（合法合成/历史回执）时不提示形状问题，精确相等通道不受形状影响。
				const shapeNote = !isValidReceiptIdShape(cmd.receiptId) && isValidReceiptIdShape(view.receipt.receiptId)
					? `；且收到 id 形状非当前生产形态 receipt-<uuid>（长度 ${cmd.receiptId.length}，疑似手抄/转录畸变——请原样复制 repairExamples 中的当前值）` : "";
				const staleMsg = `receiptId 不匹配（当前 ${view.receipt.receiptId}，收到 "${cmd.receiptId}"）——决策引用当前回执，防陈旧决策；${receiptIdMismatchHint(view.receipt.receiptId, cmd.receiptId)}${shapeNote}；请复制 repairExamples 中的 receiptId 原值，勿手抄`;
				const staleBase = fail(err("stale-receipt", staleMsg, ["receiptId"], "none", repair));
				return { ...staleBase, details: { ...(staleBase.details as Record<string, unknown>), repairExamples: repair } };
			}
			if (!fenceOmitted && view.revision !== cmd.expectedRevision) {
				const revBase = fail(err("stale-revision", `expectedRevision 失效（当前 revision=${view.revision}，收到 ${cmd.expectedRevision}）——栅栏拒绝陈旧决策`, ["expectedRevision"], "none", repair));
				return { ...revBase, details: { ...(revBase.details as Record<string, unknown>), repairExamples: repair } };
			}
			const dr = await svc.decide(taskId, cmd.action, normalized.receiptId, {
				actor: deps.caller.actor,
				reason: cmd.reason,
				...(cmd.action === "accept" && normalized.waivedCheckIds !== undefined ? { waivedCheckIds: normalized.waivedCheckIds } : {}),
			});
			if (!dr.ok) {
				// D1（ev-20260922-c896f8）：不截断内核错误（删 400 字上限）；receipt 已更新时先报 stale、
				// repair 基于当前回执给当前 id（重读视图，不混上轮 id）；内核 repairExamples（waivedCheckIds
				// 真数组）合并实际 handle/receiptId/expectedRevision 形成合法调用——全集超长也保留在结构化
				// repairExamples/details，正文完整列出。
				const now = peekTaskKernel()?.get(taskId);
				const curReceiptId = now?.receipt?.receiptId ?? view.receipt?.receiptId;
				const curRevision = now?.revision ?? view.revision;
				const callSkeleton = (extra?: object) => ({
					action: cmd.action, handle: taskId,
					receiptId: curReceiptId ?? "<当前回执 receiptId（task_query({ handle, view: \"receipt\" }) 获取）>",
					expectedRevision: curRevision ?? "<当前 revision>",
					reason: "<接受/拒绝理由>",
					...(extra ?? {}),
				});
				const kernelExamples = (dr.error?.repairExamples ?? []).map((ex) => callSkeleton(ex));
				const repair = [...kernelExamples, ...controlRepairExamples(cmd.action, { handle: taskId, receiptId: curReceiptId, expectedRevision: curRevision })];
				const decision = err("decide-rejected", `${dr.message}${normNote}`, dr.error?.fields?.length ? [...dr.error.fields] : ["receiptId"], "none", repair);
				const base = fail(decision);
				return { ...base, details: { ...(base.details as Record<string, unknown>), repairExamples: repair, ...(dr.error ? { kernelErrorCode: dr.error.code } : {}) } };
			}
			// K8b 接缝：accept 解锁 requires=accepted 边——暂停组自动续跑（不阻塞等待组终局；完成/再暂停另行通知）
			let groupNote = "";
			const runId = registry.get(taskId)?.runId;
			if (cmd.action === "accept" && runId !== undefined && getGroup(runId).paused) {
				const resumed = svc.resumeGroup(runId);
				if (resumed !== undefined) groupNote = `\n[组续跑] runId=${runId} 已恢复执行（requires=accepted 边解锁；组终局另行通知，无需轮询）`;
			}
			// ev-20261108-m3（diting 审 m3）：accept 的回执若为自动基线探测级环境缺口降级（ready 但零测试
			// 事实），返回文本如实附注——accept 记录的是人工验收结论，不得被读作测试通过；判据单源
			// baselineEnvGapOf（task_query 视图行/[待接受] 提示同源），只读不改三轴。
			let envGapNote = "";
			if (cmd.action === "accept") {
				const gap = baselineEnvGapOfView(view.receipt);
				if (gap) envGapNote = `\n[自动基线] 自动基线未执行（环境缺口：${gap.objectId || gap.checkId}）——测试事实缺失，非测试通过；本次 accept 为人工验收结论。`;
			}
			const after = peekTaskKernel()?.get(taskId);
			const text = `[task_control ${cmd.action} ${taskId.slice(0, 8)}] acceptance=${dr.acceptance} receiptSeq=${dr.receiptSeq ?? "?"}（${dr.message}）${normNote}${groupNote}${envGapNote}${kernelViewLine(taskId)}`;
			return okReturn(`${text}${pendingAcceptanceNote([taskId])}`, detailsBlockOf(after, surfaceVersion, taskId));
		}),
	};

	// ── task_query ───────────────────────────────────────────────────────────
	const taskQuery: FacetToolDefinition<{ handle?: string; view?: "summary" | "receipt" | "output"; cursor?: string; limit?: number }> = {
		name: "task_query",
		label: "Amagi Task Query",
		description: [
			"只读查询任务三轴（执行/结算/接受）——不触发结算、续接或恢复；「执行结束」≠「已接受」。",
			"handle 查单任务；省略列全部契约任务（新→旧分页）。view=summary（缺省，三轴标签）/receipt（展开回执、机器检查与产物引用）/output（只给产物引用不展开全文）。",
			"accept/reject 前先用 receipt 档取当前 receiptId 与 revision。",
		].join(" "),
		promptSnippet: `task_query({ handle?, view: "summary"|"receipt"|"output", cursor?, limit? }) — 三轴只读查询`,
		constrainedSampling: TASK_FACET_CONSTRAINED_SAMPLING,
		// O1（pi-0.99 机会批 §3.1）：唯一确证纯读分面——三档均经 queryTaskViews 只读解析（零磁盘回填/纯读磁盘回退），
		// 域内封闭无外部世界触达；不声明 destructive/idempotent（仅读写语义有意义，read-only 下省缺）。
		annotations: { readOnlyHint: true, openWorldHint: false },
		// O3b（pi-0.99 机会批 §4.7.2）：结构化输出 schema（四分支 Union：summary/receipt/output/error）——
		// 成功/错误路径均携 structuredContent；参数 schema/description/annotations/采样档不变。
		outputSchema: TaskQueryOutputSchema,
		parameters: Type.Object({
			handle: Type.Optional(Type.String({ description: "会话内任务句柄；历史契约可用完整 taskId 或至少 8 位唯一前缀（只读，不收编旧会话）" })),
			view: Type.Optional(StringEnum(["summary", "receipt", "output"], { description: "查询档位（缺省 summary）" })),
			cursor: Type.Optional(Type.String({ description: "分页游标（上页 nextCursor；不透明）" })),
			limit: Type.Optional(Type.Number({ description: "每页条数 1..500（缺省 20）" })),
		}),
		execute: async (_id, params, _signal, _onUpdate, _ctx) => guardedTaskQueryExecute(params, async () => {
			params = normalizeToolArgumentArtifacts(params); // ev-20260919+ev-20260920：同 task_submit（null 键与 "null" 字符串伪影）
			// O3b：错误路径双载体——正文经 contractErrorReturn 字节不变 + structuredContent 落 Failure 分支
			//（code/fields/effects 完整保留）。U5（diting F3 → D 片）：wire 与 details.error 两载体凭据脱敏
			//（redactContractError 同源产物——O3c §二-4 第三载体发现闭合）；正文 content 保持原文（字节不变
			// 红线优先于存量脱敏补齐——正文载体脱敏需另立契约变更，显式登记不在本片）；view 投影按 §4.4。
			const failWire = (e: Readonly<ContractError>): FacetToolReturn => {
				const sanitized = redactContractError(e);
				const base = contractErrorReturn(e); // 正文用原始 e——content 契约字节不变
				return {
					...base,
					details: { ...(base.details as Record<string, unknown>), error: sanitized.message },
					structuredContent: toFailureWire(sanitized, taskQueryWireViewOf(params)),
				};
			};
			const shape = rejectUnknownParams(params as unknown as Record<string, unknown>, ["handle", "view", "cursor", "limit"]);
			if (shape) return failWire(shape);
			const level = params.view ?? "summary";
			const vq = validateTaskQuery({ handle: params.handle, view: level, ...(params.cursor !== undefined ? { cursor: params.cursor } : {}), ...(params.limit !== undefined ? { limit: params.limit } : {}) });
			if (!vq.ok) return failWire(withRepair(vq.error, [{ handle: "<taskId 前 8 位>", view: "receipt" }, { view: "summary", limit: 20 }]));
			const r = await svc.queryViews(vq.value);
			if (!r.ok) return failWire(withRepair(r.error, [{ handle: "<task_submit 返回的 taskId>" }, { view: "summary" }]));
			const { page, legacy } = r.value;
			// O3b single-read（§4.7.2）：归档每任务恰好一次读取——正文渲染与 wire 映射共用同一已读结果
			//（O3a 模块零 I/O；接线处一次读取喂双载体，§4.5 同源同脱敏——wire 不另行读盘取未脱敏值）。
			// ev-20261108-m3：环境缺口标注派生同用此缓存（每任务仍恰好一次归档读取）。
			const archiveReads = new Map<string, { read: Readonly<Record<string, unknown>> | null }>();
			const archiveOf = (v: Readonly<{ taskId: string; receipt?: { ref?: { path: unknown } } }>): { checks?: unknown[]; outputs?: unknown[] } | null => {
				const refPath = typeof v.receipt?.ref?.path === "string" ? v.receipt.ref.path : undefined;
				if (!refPath) return null;
				const hit = archiveReads.get(v.taskId);
				if (hit) return hit.read as { checks?: unknown[]; outputs?: unknown[] } | null;
				const read = readReceiptArchive(refPath);
				archiveReads.set(v.taskId, { read });
				return read;
			};
			const lines: string[] = [`[task_query ${level}] 契约任务 ${page.items.length} 条`];
			// ev-20261012-4afdc8：页级单次基准提示——同页多条相对归档引用只补一次根路径（多任务页不刷屏）；
			// 无回执/无相对引用的页不出现（不增噪音），行内标注由 contractRefInlineNote 逐条自带。
			let contractBaseShown = false;
			for (const v of page.items) {
				const runtimeFacts = registry.get(v.taskId)?.runtimeObservation;
				lines.push(`  ${v.taskId.slice(0, 8)} ${v.spec.agent} · execution=${v.execution} settlement=${v.settlement} acceptance=${v.acceptance} · stateSeq=${v.stateSeq} revision=${v.revision} contextMode=${v.spec.contextMode}${v.degraded.length > 0 ? ` degraded=${v.degraded.length}` : ""}`);
				if (runtimeFacts && (level === "summary" || level === "receipt")) lines.push(`    ${formatRuntimeObservation(runtimeFacts)}`);
				// D2（ev-20260922-727096）：查询面同源展示恢复指引（与通知/返回同一 renderer，稳定面渲染）——
				// 事实取 registry 当前记录；无记录（跨重启未回填）不臆造。
				if (v.execution === "error") {
				const rec = registry.get(v.taskId);
				const note = rec ? renderRecoveryAdvice(recoveryActionOfRecord(rec, { modelRegistry: _ctx?.modelRegistry }), { surfaceVersion }) : undefined; // ev-20261031-7110a8：quota 候选探测透传
				if (note) for (const l of note.split("\n")) lines.push(`    ${l}`);
			}
				// ev-20260930-0dd26f（R6）：steer 通道状态投影（summary 档单任务与分页均读页内任务；
				// 零写入不触发 GC；receipt/output 档不强制读通道）。absent 静默——无通道事实不逐行噪音，
				// 显式追问语境（recovery show）才呈现 absent 文案；unreadable 如实警告不伪全送达。
				if (level === "summary") {
					const steerSnap = readSteerChannelSnapshot(v.taskId);
					if (steerSnap.availability !== "absent") lines.push(`    ${formatSteerChannelLine(steerSnap)}`);
				}
				// Batch 3（§9.5 成本进入 footer）：查询面纯读渲染（summary/output 两档；重复查询逐字相同）
				if (level === "summary" || level === "output") {
					const _uf = renderUsageFooter(v.taskId, { inline: true });
					if (_uf) lines.push(`    ${_uf}`);
				}
				if (level === "output") {
					for (const file of archivedTaskContextRefs(v.taskId)) lines.push(`    归档引用: ${file}（按需 read；此处不展开全文）`);
				}
				// ev-20261108-m3（diting 审 m3）：settlement=ready 但自动基线探测级环境缺口降级（零测试事实）的
				// 回执，在 summary/receipt 视图行下如实标注「未经自动测试验证」——settlement 判定不变（仍
				// ready，不补绿），只补展示；判据单源 baselineEnvGapOf（accept 附注/[待接受]/一次性提示同源）。
				if ((level === "summary" || level === "receipt") && v.settlement === "ready") {
					const gap = baselineEnvGapOf(archiveOf(v)?.checks);
					if (gap) lines.push(`    自动基线: 未执行（环境缺口：${gap.objectId || gap.checkId}）——测试事实缺失，未经自动测试验证（非测试通过）`);
				}
				if (level === "summary" || !v.receipt) {
					if (!v.receipt && level !== "summary") lines.push("    回执: 未发布（settlement=pending——执行结束但结算未落）");
					continue;
				}
				// D1（ev-20260922-c896f8）：归档可读时先取 checks id 集——旧 id:status 形态按当前 check
				// 精确 id 识别（splitLegacyCheckGapId 唯一识别，不猜 hash/截字符串）。
				const receiptRef = v.receipt.ref;
				const full = archiveOf(v);
				const checkIds = full && Array.isArray(full.checks)
					? full.checks.map((c) => ((c as { id?: unknown }).id ?? "")).filter((id): id is string => typeof id === "string")
					: [];
				const missingRendered = v.receipt.missing.map((g) => {
					const legacy = checkIds.length > 0 ? splitLegacyCheckGapId(g, checkIds) : null;
					return legacy
						? `${g}（旧版 id:status 形态——id=${legacy.checkId} status=${legacy.status}；decide 引用原字面 ${JSON.stringify(g)}，不剥离后缀）`
						: g;
				});
				lines.push(`    回执: receiptId=${v.receipt.receiptId} seq=${v.receipt.receiptSeq} settlement=${v.receipt.settlement} acceptance=${v.receipt.acceptance}${missingRendered.length > 0 ? ` missing=[${missingRendered.join(",")}]` : ""}`);
				if (receiptRef) {
					// ev-20261012-4afdc8：相对归档引用标注存储基准（解析面同源 contractStoreRoot）——
					// 已是绝对路径的引用不标注、不二次拼接。
					if (!path.isAbsolute(receiptRef.path) && !contractBaseShown) {
						lines.push(contractRefBaseHint());
						contractBaseShown = true;
					}
					lines.push(`    回执归档: ${receiptRef.path}（${receiptRef.bytes}B，sha256:${receiptRef.digest.slice(0, 16)}）${contractRefInlineNote(receiptRef.path)}`);
					// O3b：复用外层 single-read 结果（原第二次 readReceiptArchive 移除——同参同文件，正文字节不变）
					if (level === "receipt") {
						const checks = Array.isArray(full?.checks) ? full!.checks! : [];
						if (!full) lines.push("    检查: 回执文件不可读——归档引用如实展示，不臆造内容");
						else if (checks.length === 0) lines.push("    检查: （无机器检查——非编码/手动验收任务）");
						else for (const c of checks.slice(0, 8)) {
							const cc = c as { id?: unknown; status?: unknown; required?: unknown; exitCode?: unknown };
							// D1：id/status 分列展示（可照抄引用的纯 id 与状态分开，不拼接成 id:status）。
							lines.push(`    检查: id=${typeof cc.id === "string" ? cc.id : "?"} status=${typeof cc.status === "string" ? cc.status : "?"}${cc.required === true ? "（required）" : ""}${typeof cc.exitCode === "number" ? ` exit=${cc.exitCode}` : ""}`);
						}
					}
					const outputs = Array.isArray(full?.outputs) ? full!.outputs! : [];
					if (outputs.length === 0) lines.push("    回执产物: （无产物引用——非编码/无产物任务）");
					else for (const o of outputs.slice(0, 8)) {
						const oo = o as { path?: unknown; digest?: unknown; bytes?: unknown; sourcePath?: unknown };
						lines.push(`    回执产物: ${typeof oo.path === "string" ? oo.path : "?"}（${typeof oo.bytes === "number" ? `${oo.bytes}B` : "?"}，sha256:${typeof oo.digest === "string" ? oo.digest.slice(0, 16) : "?"}${typeof oo.sourcePath === "string" ? `，源=${oo.sourcePath}` : ""}）`);
					}
				}
			}
			// ev-20261019-06c169：空态不再建议「等启动对账」——对账不回填 list（列表真实恢复改经本会话磁盘
			// 契约合并；他Session/无盖章记录本就不该自动列入）；历史任务给可执行去向（完整 taskId / recovery）。
			if (page.items.length === 0 && vq.value.handle === undefined) lines.push("  （当前会话无可列出的契约任务；历史任务可按完整 taskId 查询或查看 recovery）");
			lines.push(`[页] snapshotSeq=${page.snapshotSeq}${page.nextCursor !== undefined ? ` · nextCursor=${page.nextCursor}` : ""}${page.truncated ? " · truncated" : ""}`);
			// ev-20261019-06c169：v1 文案只描述已确证无契约记录的条目（loadIfPresent 明确 null）；缺内核视图≠v1。
			if (legacy.length > 0) lines.push(`[遗留记录] ${legacy.length} 条已确证无契约记录的 v1 记录（无三轴）: ${legacy.slice(0, 5).map((l) => `${l.taskId.slice(0, 8)}(${l.agent}/${l.status})`).join(" ")}`);
			// O3b：成功路径双载体——正文 okReturn 字节不变 + structuredContent 三档映射（与正文同源：
			// 同一 page/legacy、同一归档已读结果、同一 registry 恢复说明——不重新取值，§4.5）。
			const wireSource: TaskQueryWireSource = {
				page,
				legacy,
				archiveOf: (taskId) => archiveReads.get(taskId),
				recoveryAdviceOf: (v) => {
					if (v.execution !== "error") return null;
					const rec = registry.get(v.taskId);
					// U5：recoveryAdvice 属 wire 自由文本载体（reason/waitHint/caveat 动态段可含凭据形态）——
					// wire 侧脱敏；正文侧同函数渲染保持原文（content 契约字节不变）。
					const advice = rec ? renderRecoveryAdvice(recoveryActionOfRecord(rec, { modelRegistry: _ctx?.modelRegistry }), { surfaceVersion }) : undefined; // ev-20261031-7110a8：quota 候选探测透传
					return advice ? redactCredentials(advice) : null;
				},
			};
			const wire: TaskQueryWireOutput = level === "receipt"
				? toReceiptWire(wireSource)
				: level === "output"
					? toOutputWire(wireSource)
					: toSummaryWire(wireSource);
			return { ...okReturn(lines.join("\n"), page.items.length === 1 && vq.value.handle !== undefined
				// ev-20261017-589e6d：单任务查询 details 取本页同一快照（与正文行同源，不再 revision=?）；
				// 句柄前缀解析后的完整 taskId 以视图为准（旧实现回显原始句柄文本）
				? detailsBlockOf(page.items[0], surfaceVersion)
				: aggregateDetailsBlock(surfaceVersion, "list")), structuredContent: wire };
		}),
	};

	return { taskSubmit, taskResume, taskControl, taskQuery, surfaceVersion };
}

/** 注册就绪的工具清单（I2 组合根 registerTool 消费；顺序即推荐展示序）。 */
export function createTaskFacetTools(deps: TaskFacetsDeps): FacetToolDefinition<never>[] {
	const facets = createTaskFacets(deps);
	return [facets.taskSubmit, facets.taskResume, facets.taskControl, facets.taskQuery] as unknown as FacetToolDefinition<never>[];
}
