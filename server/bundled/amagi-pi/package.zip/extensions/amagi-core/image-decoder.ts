/**
 * image-decoder.ts — C14/F6 终局（fuxi 设计 §4）：委托宿主解码，撤回完整格式符合性承诺。
 *
 * 责任边界（设计 §4.1/§4.2）：
 *   - 本模块是「小适配面 + 生命周期监督」，不是解码器：真实解码 100% 委托公共包根导出的
 *     `resizeImage`（@earendil-works/pi-coding-agent，Photon/WASM）。不解析容器结构、不验熵、
 *     不读 XML、不 deep-import 宿主内部模块、不直接依赖 Photon——因此不存在 amagi 自写格式
 *     裁判（F6 三轮教训：手写识别器在完整承诺下必然被同族反例推翻）。
 *   - probe 只返回 ImageDecodeObservation 联合：passed = 「指定宿主在指定范围内对这些字节完成
 *     主栅格读取」的限域事实（scope=host-primary-raster：不含全部动画帧/元数据/严格标准符合性/
 *     其它消费方兼容）；not-assessed = 未取得证明（null/throw/超时/取消/未支持/后端不可用）。
 *     不产出 formatValid=true；宽容接受不伪称规范合法。
 *   - MIME 只做有限封装一致性快筛（固定签名前缀：PNG 8B/JPEG SOI/GIF87a|89a/BMP BM）——
 *     不一致拒绝；一致只进入真实解码，不签正确性（设计 §4.3）。
 *
 * 生命周期（设计 §4.4，M1 实测口径）：
 *   - 一请求一受监督 worker（image-decode-worker.mjs）：worker 内只调公共宿主入口；父侧持有
 *     句柄、deadline 与取消状态；settle 后 terminate（worker 事件循环不自然排空——M1 实测）；
 *     finally 移除监听与计时器。禁止父线程 fallback 解码。
 *   - execArgv: [] —— worker 不继承宿主进程 exec 参数（M1 实测：eval/-e 形态会传崩 worker）。
 *   - 会话内最多一个在途 decode worker；占用时返回 backend-unavailable（不排队、不重试）。
 *   - 父侧单调时钟（performance.now）：probe 子预算取剩余预算与 10s 的较小值（调用面计算）。
 *     到点/取消后禁止消费迟到结果：消费门以单调 deadline 事实复核（now 等于/超过任一截止即弃权
 *     ——F6.B2，不依赖 timer 回调时序，与 F8/F10 同款口径）；落盘前调用面再次复核完整操作预算。
 *   - 宿主版本准入门（F6.B4）：探测版本必须在已测集 IMAGE_DECODE_VERIFIED_HOST_VERSIONS 内才启动
 *     worker；未测版本启动前拒绝（host-version-unverified，未知/未测宿主默认不可用）。
 *   - settle 后先 terminate 确认再 resolve（F6.B3）：fence 覆盖到实际退出——单在途约束以
 *     「terminate 已确认」为准入条件，取消/超时突发不堆叠未退出 worker；计数只记成功回收。
 *   - 宿主 no-resize 口径：maxWidth/maxHeight=MAX_SAFE_INTEGER、maxBytes=4·⌈20MiB/3⌉+1（外层
 *     编码文件 ≤20MiB 先行检查；+1 对齐宿主严格 < 判断）。要求 wasResized=false——实际发生
 *     resize 视作宿主适配契约变化（invalid-backend-result），不保存派生图。
 *   - 无 abort 的宿主调用不宣传硬内存隔离；20MiB 是编码文件字节上限，不是像素内存上限。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";
import { Worker } from "node:worker_threads";

import { detectHostPackageVersion } from "./host-capabilities.ts";

// ── 常量与类型（设计 §4.2/§4.3） ─────────────────────────────────────────────

/** 解码范围声明（证据消费方展示必附）。 */
export const IMAGE_DECODE_POLICY_VERSION = "host-primary-raster-v1";
/** 唯一后端标识（生产不建注册中心/投票器/降级链——设计 §4.2）。 */
export const IMAGE_DECODE_BACKEND = "pi-coding-agent.resizeImage";
/** probe 子预算上限（设计 §4.4：min(剩余预算, 10s) 由调用面计算后传入 deadline）。 */
export const IMAGE_DECODE_PROBE_BUDGET_MS = 10_000;
/** 单图编码文件字节上限（20 MiB——base64 还原后的原始文件字节；非像素内存上限）。 */
export const IMAGE_DECODE_LIMIT_BYTES = 20 * 1024 * 1024;
/** 已实测准入的宿主版本集（F6.B4 版本准入白名单：冻结平台 darwin/arm64 + 公共宿主 1.0.2/1.1.0/1.2.0/1.3.0 实测通过；
 *  1.1.0 取证：tests/c14-image-evidence.test.mjs AC4-AC7，2026-10-09（仅 darwin/arm64 本机平台）。
 *  1.2.0 取证：同套件 AC4-AC7，2026-10-14（仅 darwin/arm64 本机平台）。
 *  1.3.0 取证：同套件 AC4-AC7，2026-10-17（仅 darwin/arm64 本机平台；devDeps 升 1.3.0 后全套真实宿主解码矩阵通过）。
 *  未测版本默认不可用——新宿主版本须重新取得对应平台/MIME 证据后才可加入，不得仅凭非 null 即准入）。 */
export const IMAGE_DECODE_VERIFIED_HOST_VERSIONS: readonly string[] = ["1.0.2", "1.1.0", "1.2.0", "1.3.0"];

/** not-assessed 原因（closed union；mime-signature-mismatch 为 §4.2 失败码表 IMAGE_MIME_MISMATCH 的对应原因；
 *  host-version-unverified 为 F6.B4 未测宿主版本准入拒绝）。 */
export type ImageDecodeNotAssessedReason =
	| "unsupported-format"
	| "mime-signature-mismatch"
	| "backend-unavailable"
	| "host-version-unverified"
	| "no-decode-proof"
	| "timeout"
	| "cancelled"
	| "invalid-backend-result"
	| "legacy-no-proof";

/** 解码成功观测（限域：宿主主栅格 + 方向处理后显示尺寸——不是原容器存储尺寸，不声明格式规范正确）。 */
export interface ImageDecodePassed {
	status: "passed";
	backend: typeof IMAGE_DECODE_BACKEND;
	hostVersion: string;
	policyVersion: typeof IMAGE_DECODE_POLICY_VERSION;
	/** 探测输入字节 sha256（必须等于落盘回读 digest——字节绑定，设计 §4.1 不变量）。 */
	inputSha256: string;
	scope: "host-primary-raster";
	width: number;
	height: number;
	dimensionBasis: "host-oriented-raster";
}

export interface ImageDecodeNotAssessed {
	status: "not-assessed";
	reason: ImageDecodeNotAssessedReason;
}

export type ImageDecodeObservation = ImageDecodePassed | ImageDecodeNotAssessed;

/** 面向用户的有限失败码表（设计 §4.2；恒定文案，经 F17 同源净化——不含 base64/外部回显）。 */
export type ImageGenerationErrorCode =
	| "IMAGE_FORMAT_UNSUPPORTED"
	| "IMAGE_MIME_MISMATCH"
	| "IMAGE_DECODER_UNAVAILABLE"
	| "IMAGE_HOST_VERSION_UNVERIFIED"
	| "IMAGE_DECODE_UNPROVEN"
	| "IMAGE_DECODE_TIMEOUT"
	| "IMAGE_DECODE_CANCELLED"
	| "IMAGE_DECODER_RESULT_INVALID";

export function imageDecodeErrorCode(obs: ImageDecodeObservation): ImageGenerationErrorCode | undefined {
	if (obs.status === "passed") return undefined;
	switch (obs.reason) {
		case "unsupported-format":
			return "IMAGE_FORMAT_UNSUPPORTED";
		case "mime-signature-mismatch":
			return "IMAGE_MIME_MISMATCH";
		case "backend-unavailable":
			return "IMAGE_DECODER_UNAVAILABLE";
		case "host-version-unverified":
			return "IMAGE_HOST_VERSION_UNVERIFIED";
		case "no-decode-proof":
			return "IMAGE_DECODE_UNPROVEN";
		case "timeout":
			return "IMAGE_DECODE_TIMEOUT";
		case "cancelled":
			return "IMAGE_DECODE_CANCELLED";
		case "invalid-backend-result":
			return "IMAGE_DECODER_RESULT_INVALID";
		case "legacy-no-proof":
			return "IMAGE_DECODE_UNPROVEN";
	}
}

/** 失败码 → 固定说明（不含动态字节内容——天然可净化）。 */
const ERROR_CODE_TEXT: Readonly<Record<ImageGenerationErrorCode, string>> = {
	IMAGE_FORMAT_UNSUPPORTED: "图像格式不在解码准入集（png/jpeg/gif/bmp；svg/webp 及未知 MIME 明确不支持——不签发解码成功）",
	IMAGE_MIME_MISMATCH: "声明 MIME 与字节签名前缀不一致（有限封装一致性快筛——不签格式正确性）",
	IMAGE_DECODER_UNAVAILABLE: "宿主解码后端不可用（公共入口/版本/worker 不可解析或占用——未知版本默认不可用）",
	IMAGE_HOST_VERSION_UNVERIFIED: `宿主版本未验证（不在已测集 ${IMAGE_DECODE_VERIFIED_HOST_VERSIONS.join("/")} 内——未测宿主默认不可用；新宿主版本须重新取得平台/MIME 证据后才准入）`,
	IMAGE_DECODE_UNPROVEN: "宿主解码器未取得成功证明（null/异常/超限——不保存占位产物、不签发成功证据）",
	IMAGE_DECODE_TIMEOUT: "解码探测超时（迟到结果丢弃不写盘——父侧 terminate 回收 worker）",
	IMAGE_DECODE_CANCELLED: "解码探测已取消（预取消零启动；迟到结果不消费）",
	IMAGE_DECODER_RESULT_INVALID: "宿主解码结果不符合适配契约（wasResized≠false 或尺寸值域非法——不保存派生图）",
};

export function imageDecodeFailureText(obs: ImageDecodeNotAssessed): string {
	const code = imageDecodeErrorCode(obs);
	return `${code}：${ERROR_CODE_TEXT[code!]}（reason=${obs.reason}）`;
}

// ── 准入集与签名快筛（设计 §4.3：前缀一致≠格式通过） ──────────────────────────

/** 初始候选 MIME（M1 真机探针通过后准入：png/jpeg/gif/bmp 各有 ≥2 枚真实正例）。 */
export const IMAGE_ADMITTED_OUTPUT_MIME: readonly string[] = ["image/png", "image/jpeg", "image/gif", "image/bmp"];

const MIME_SIGNATURES: ReadonlyArray<{ mime: string; prefix: Buffer }> = [
	{ mime: "image/png", prefix: Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]) },
	{ mime: "image/jpeg", prefix: Buffer.from([0xff, 0xd8]) },
	{ mime: "image/gif", prefix: Buffer.from("GIF87a", "ascii") },
	{ mime: "image/gif", prefix: Buffer.from("GIF89a", "ascii") },
	{ mime: "image/bmp", prefix: Buffer.from("BM", "ascii") },
];

/** 签名前缀快筛：声明 MIME 在准入集且固定前缀一致 → true（只说明封装一致性，不签格式正确）。 */
export function imageSignatureConsistent(declaredMime: string, bytes: Uint8Array): boolean {
	if (!IMAGE_ADMITTED_OUTPUT_MIME.includes(declaredMime)) return false;
	return MIME_SIGNATURES.some((s) => s.mime === declaredMime && bytes.length >= s.prefix.length && Buffer.from(bytes.subarray(0, s.prefix.length)).equals(s.prefix));
}

// ── 宿主公共入口解析（父侧；与 host-capabilities 同源策略） ───────────────────

const HOST_PACKAGE = "@earendil-works/pi-coding-agent";

/** 解析公共包根入口 URL（import 条件）；失败回退 node_modules 布局向上查找；两路均失败返回 null。 */
export function resolveHostDecodeEntryUrl(): string | null {
	try {
		if (typeof import.meta.resolve === "function") {
			const url = import.meta.resolve(HOST_PACKAGE);
			if (typeof url === "string" && url.startsWith("file:")) return url;
		}
	} catch { /* lint-exempt:eval 上下文 resolve 失败→布局回退（不臆测解析路径） */
		// 落到布局回退
	}
	try {
		let dir = path.dirname(fileURLToPath(import.meta.url));
		for (let hops = 0; hops < 8; hops++) {
			const cand = path.join(dir, "node_modules", "@earendil-works", "pi-coding-agent", "dist", "index.js");
			if (fs.existsSync(cand)) return new URL(`file://${cand}`).href;
			const parent = path.dirname(dir);
			if (parent === dir) break;
			dir = parent;
		}
	} catch { /* lint-exempt:布局回退失败=不可解析→诚实 backend-unavailable */
		// 不可解析：诚实返回 null（backend-unavailable）
	}
	return null;
}

/** 监督 worker 文件定位（与本模块同目录；jiti 下 import.meta.url 指向源文件，仓库/安装布局均成立）。 */
function resolveWorkerPath(): string | null {
	const here = path.dirname(fileURLToPath(import.meta.url));
	const primary = path.join(here, "image-decode-worker.mjs");
	if (fs.existsSync(primary)) return primary;
	// 回退：进程 cwd 下的开发仓库布局（测试/脚本注入 cwd 时）
	const fallback = path.join(process.cwd(), "extensions", "amagi-core", "image-decode-worker.mjs");
	if (fs.existsSync(fallback)) return fallback;
	return null;
}

// ── HostImageDecoder（唯一生产解码器；可注入测试夹具替换） ────────────────────

export interface ImageDecodeProbeOptions {
	/** 单调时钟截止点（performance.now() 口径；probe 内部按 min(剩余, 10s) 执行）。 */
	deadlineAtMonotonic: number;
	/** 取消信号（预取消零启动；触发后迟到结果不消费）。 */
	signal?: AbortSignal;
}

/** 解码器接口（runImageGeneration 依赖注入面；测试夹具可实现同接口做机制注入）。 */
export interface ImageDecoderLike {
	probe(bytes: Uint8Array, declaredMime: string, opts: ImageDecodeProbeOptions): Promise<ImageDecodeObservation>;
}

/** 宿主 no-resize 探测口径（设计 §4.3；导出供测试/报告引用）。 */
export const HOST_NO_RESIZE_OPTIONS = {
	maxWidth: Number.MAX_SAFE_INTEGER,
	maxHeight: Number.MAX_SAFE_INTEGER,
	maxBytes: 4 * Math.ceil(IMAGE_DECODE_LIMIT_BYTES / 3) + 1,
} as const;

interface WorkerReply {
	ok: boolean;
	phase?: "import" | "decode";
	error?: string;
	result?: { originalWidth: number; originalHeight: number; wasResized: boolean } | null;
}

function isSafePositiveInt(v: unknown): v is number {
	return typeof v === "number" && Number.isSafeInteger(v) && v > 0;
}

/** 解码 worker 生命周期观测（真实计数；导出供测试/诊断验证「结束后 worker 归零」——AC8）。 */
let decodeWorkersSpawned = 0;
let decodeWorkersTerminated = 0;
export function hostDecodeWorkerStats(): Readonly<{ spawned: number; terminated: number }> {
	return { spawned: decodeWorkersSpawned, terminated: decodeWorkersTerminated };
}

/** 消费门（F6.B2，纯函数导出供单测与落盘前复核共用）：成功消息消费/落盘前以单调时钟事实复核——
 *  已取消弃权（cancelled）；now 等于/超过 probe 子预算截止或完整操作截止即弃权（timeout）。
 *  不依赖 timer 回调是否已执行（deadline 是事实，不是调度；与 F8/F10 同款口径）。 */
export function decodeResultAdmission(input: {
	now: number;
	/** probe 子预算绝对截止点（performance.now 口径）。 */
	probeDeadlineAt: number;
	/** 完整操作绝对截止点（180s 预算——不因解码重置）。 */
	operationDeadlineAt: number;
	aborted: boolean;
}): { consume: true } | { consume: false; reason: "timeout" | "cancelled" } {
	if (input.aborted) return { consume: false, reason: "cancelled" };
	if (input.now >= input.probeDeadlineAt || input.now >= input.operationDeadlineAt) {
		return { consume: false, reason: "timeout" };
	}
	return { consume: true };
}

/** 宿主 no-resize 结果消费检查（纯函数，导出供单测——设计 §4.3）：null=无证明；wasResized≠false /
 *  尺寸非正 safe integer / 像素乘积溢出 = invalid-backend-result（不保存派生图）；合法 → passed 观测。 */
export function consumeHostDecodeResult(
	r: { originalWidth: number; originalHeight: number; wasResized: boolean } | null | undefined,
	identity: { hostVersion: string; inputSha256: string },
): ImageDecodeObservation {
	if (r === null || r === undefined) return { status: "not-assessed", reason: "no-decode-proof" };
	if (r.wasResized !== false) return { status: "not-assessed", reason: "invalid-backend-result" };
	if (!isSafePositiveInt(r.originalWidth) || !isSafePositiveInt(r.originalHeight) || !Number.isSafeInteger(r.originalWidth * r.originalHeight)) {
		return { status: "not-assessed", reason: "invalid-backend-result" };
	}
	return {
		status: "passed",
		backend: IMAGE_DECODE_BACKEND,
		hostVersion: identity.hostVersion,
		policyVersion: IMAGE_DECODE_POLICY_VERSION,
		inputSha256: identity.inputSha256,
		scope: "host-primary-raster",
		width: r.originalWidth,
		height: r.originalHeight,
		dimensionBasis: "host-oriented-raster",
	};
}

export class HostImageDecoder implements ImageDecoderLike {
	private inFlight = false;

	constructor(
		private readonly deps: {
			/** 宿主版本探测注入（测试机制注入面——生产缺省用 detectHostPackageVersion；B4 版本准入回归用）。 */
			hostVersionProbe?: () => string | null;
			/** 单调时钟注入（测试机制注入面——生产缺省 performance.now；B2 消费门回归用）。 */
			clock?: { now(): number };
		} = {},
	) {}

	/** 解码探测：只返回观测联合；不产出格式正确性结论；任何失败路径零产物。 */
	async probe(bytes: Uint8Array, declaredMime: string, opts: ImageDecodeProbeOptions): Promise<ImageDecodeObservation> {
		if (opts.signal?.aborted) return { status: "not-assessed", reason: "cancelled" };
		if (this.inFlight) return { status: "not-assessed", reason: "backend-unavailable" };
		this.inFlight = true;
		try {
			return await this.probeLocked(bytes, declaredMime, opts);
		} finally {
			this.inFlight = false;
		}
	}

	private async probeLocked(bytes: Uint8Array, declaredMime: string, opts: ImageDecodeProbeOptions): Promise<ImageDecodeObservation> {
		// 外层统一资源检查（所有适配器输出同门——mock/custom 无旁路，设计 §4.4）。
		if (bytes.length === 0) return { status: "not-assessed", reason: "no-decode-proof" };
		if (bytes.length > IMAGE_DECODE_LIMIT_BYTES) return { status: "not-assessed", reason: "no-decode-proof" };
		if (!IMAGE_ADMITTED_OUTPUT_MIME.includes(declaredMime)) return { status: "not-assessed", reason: "unsupported-format" };
		if (!imageSignatureConsistent(declaredMime, bytes)) return { status: "not-assessed", reason: "mime-signature-mismatch" };
		const hostVersion = this.deps.hostVersionProbe !== undefined ? this.deps.hostVersionProbe() : detectHostPackageVersion();
		if (hostVersion === null) return { status: "not-assessed", reason: "backend-unavailable" };
		// F6.B4：版本准入门——未测宿主版本启动前拒绝（不得仅凭非 null 即准入；新版本须重新取得证据）。
		if (!IMAGE_DECODE_VERIFIED_HOST_VERSIONS.includes(hostVersion)) {
			return { status: "not-assessed", reason: "host-version-unverified" };
		}
		const hostEntryUrl = resolveHostDecodeEntryUrl();
		if (hostEntryUrl === null) return { status: "not-assessed", reason: "backend-unavailable" };
		const workerPath = resolveWorkerPath();
		if (workerPath === null) return { status: "not-assessed", reason: "backend-unavailable" };
		const inputSha256 = createHash("sha256").update(bytes).digest("hex");
		const nowMs = (): number => (this.deps.clock !== undefined ? this.deps.clock.now() : performance.now());
		// probe 子预算：剩余预算与 10s 的较小值（设计 §4.4；180s 完整操作预算不因解码重置）。
		const remaining = opts.deadlineAtMonotonic - nowMs();
		const budgetMs = Math.max(0, Math.min(remaining, IMAGE_DECODE_PROBE_BUDGET_MS));
		if (budgetMs <= 0) return { status: "not-assessed", reason: "timeout" };
		// F6.B2：probe 子预算绝对截止点（单调时钟）——timer 只作回收兑底，消费门以本事实为准。
		const probeDeadlineAt = nowMs() + budgetMs;

		return await new Promise<ImageDecodeObservation>((resolve) => {
			let worker: Worker;
			try {
				worker = new Worker(workerPath, { execArgv: [] }); // .mjs 扩展名即 ESM worker；execArgv 清空——不继承宿主 eval 参数（M1 实测）
				decodeWorkersSpawned++;
			} catch { /* lint-exempt:worker 启动失败=后端不可用（不降级主线程解码） */
				resolve({ status: "not-assessed", reason: "backend-unavailable" });
				return;
			}
			const bytesCopy = new Uint8Array(bytes); // 传 worker 拷贝（transfer 用）——调用方字节不被 detach
			let settled = false;
			const settle = (obs: ImageDecodeObservation): void => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				opts.signal?.removeEventListener("abort", onAbort);
				// F6.B3：fence 覆盖到实际退出——terminate 确认后才 resolve（外层 inFlight 随之释放，
				// 单在途约束以「terminate 已确认」为准入条件；计数只记成功回收，terminate 失败也 resolve
				// 不吞掉挂起，但计数不平衡可供诊断）。一请求一 worker：settle 即回收（M1：不自然退出）。
				void worker
					.terminate()
					.then(() => {
						decodeWorkersTerminated++;
					})
					.catch(() => undefined)
					.then(() => resolve(obs));
			};
			const timer = setTimeout(() => settle({ status: "not-assessed", reason: "timeout" }), budgetMs);
			const onAbort = (): void => settle({ status: "not-assessed", reason: "cancelled" });
			opts.signal?.addEventListener("abort", onAbort, { once: true });
			worker.once("message", (msg: WorkerReply) => {
				if (settled) return; // 迟到结果不消费
				// F6.B2 消费门：单调 deadline 事实复核（等于/超过即弃权；已取消弃权）——不依赖 timer 回调时序。
				const admission = decodeResultAdmission({
					now: nowMs(),
					probeDeadlineAt,
					operationDeadlineAt: opts.deadlineAtMonotonic,
					aborted: opts.signal?.aborted === true,
				});
				if (!admission.consume) {
					settle({ status: "not-assessed", reason: admission.reason });
				return;
				}
				if (msg?.ok === true) {
					settle(consumeHostDecodeResult(msg.result, { hostVersion, inputSha256 }));
					return;
				}
				if (msg?.ok === false && msg.phase === "import") {
					settle({ status: "not-assessed", reason: "backend-unavailable" });
					return;
				}
				settle({ status: "not-assessed", reason: "no-decode-proof" });
			});
			worker.once("error", () => settle({ status: "not-assessed", reason: "no-decode-proof" }));
			worker.once("exit", () => {
				if (!settled) settle({ status: "not-assessed", reason: "no-decode-proof" });
			});
			worker.postMessage(
				{ hostEntryUrl, bytes: bytesCopy, mimeType: declaredMime, options: HOST_NO_RESIZE_OPTIONS },
				[bytesCopy.buffer],
			);
		});
	}
}

/** 生产默认实例（会话内单在途约束由实例内 inFlight 保证）。 */
export const defaultHostImageDecoder = new HostImageDecoder();
