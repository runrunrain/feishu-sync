/** Leader 会话的只读快照与派发装配。内容随 assignment 进入既有不可变 spec，不另建存储/执行链。 */
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { CONTEXT_MODES, type ContextMode } from "./contracts/task.ts";
import { err, ok, type Result } from "./contracts/view.ts";
import { pruneStaleToolOutputs } from "./context-event.ts";
import { redactCredentials } from "./task-query-wire.ts";
import type { InputReference } from "./dispatch-input.ts";
import { buildSelectedHandoff, type ContextEntry, type HandoffArchive } from "./dispatch-handoff.ts";

export interface DispatchContextRequest { contextMode?: ContextMode; contextRefs?: string[] }
export interface DispatchContextSession {
	getSessionId(): string;
	getLeafId(): string | null;
	getCwd(): string;
	buildSessionProjection(): { entries: Array<{ sourceEntry: { id: string; type: string }; messages: unknown[] }> };
}
export interface LeaderContextSnapshot {
	sessionId: string; leafId: string | null; cwd: string; capturedAt: number; entries: ContextEntry[];
}
export interface PreparedDispatchContext { assignment: string; mode: ContextMode; notice: string; archive?: HandoffArchive;
	/** ev-20261031-da3f86：contextRef 降级条目（不在可继承历史但磁盘实存且可读 → 按必读输入登记）。
 *  调用方（task_submit/task_batch）负责 append 进 inputs/任务书；advisor 面不降级。 */
	degradedRefs?: InputReference[];
}
const SELECTED_BYTES = 48 * 1024;
const FORK_BYTES = 512 * 1024;
const object = (v: unknown): Record<string, unknown> | undefined =>
	v !== null && typeof v === "object" && !Array.isArray(v) ? v as Record<string, unknown> : undefined;

/** 先识别完整赋值再判断键，避免巨大无空格正文触发可回溯的关键词查找。 */
function redactContextText(text: string): string {
	return redactCredentials(text).replace(/\b([A-Za-z_][A-Za-z0-9_]*)(["']?\s*[:=]\s*)("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[^\s]+)/g,
		(match, key: string, separator: string, value: string) => /api[-_]?key|(?:access|refresh|auth|oauth)[-_]?token|secret|password|passwd|credential|^(?:authorization|auth|token)$/i.test(key)
			|| (/^(?:access|refresh)$/i.test(key) && /^['"]?[A-Za-z0-9_.~+/-]{24,}['"]?$/.test(value)) ? `${key}${separator}[REDACTED]` : match);
}

function credentialSource(file: string): boolean {
	const name = path.basename(file);
	return /^\.env(?:\.|$)/i.test(name) || /^(?:auth|credentials?|secrets?|tokens?)\.(?:json|ya?ml|toml)$/i.test(name)
		|| /\.(?:pem|key|p12|pfx)$/i.test(name) || /^id_(?:rsa|ed25519|ecdsa|dsa)$/.test(name);
}

export function validateDispatchContext(p: { contextMode?: unknown; contextRefs?: unknown }): Result<ContextMode> {
	const mode = p.contextMode ?? "isolated";
	if (!CONTEXT_MODES.includes(mode as ContextMode)) return err("invalid-context-mode", "contextMode 必须是 isolated/selected/fork", ["contextMode"]);
	if (p.contextRefs !== undefined) {
		if (mode !== "selected") return err("context-refs-conflict", "contextRefs 仅用于 selected；fork 继承全部可见文本，isolated 不继承", ["contextRefs"]);
		if (!Array.isArray(p.contextRefs) || p.contextRefs.length > 16 || p.contextRefs.some(r => typeof r !== "string" || !r.trim())) {
			return err("invalid-context-refs", "contextRefs 必须是至多 16 个非空来源锚点（文件路径、工具调用 id 或消息 id）", ["contextRefs"]);
		}
	}
	return ok(mode as ContextMode);
}

/** 在 execute 的首个 await 之前调用；只消费宿主投影，绝不按 getEntries 重建弃枝/已删除内容。 */
export function captureLeaderContext(session: DispatchContextSession | undefined, currentCallId: string): Result<LeaderContextSnapshot> {
	if (!session || typeof session.buildSessionProjection !== "function") {
		return err("context-unavailable", "当前宿主未提供只读会话投影，无法继承 Leader 上下文；请使用 isolated 或升级宿主，不会静默降级", ["contextMode"]);
	}
	try {
		const projection = session.buildSessionProjection();
		const rows = projection.entries;
		if (!Array.isArray(rows)) throw new Error("投影缺少 entries");
		const projected = pruneStaleToolOutputs(rows.flatMap(row => row.messages));
		let messageIndex = 0;
		let sourceLeafId = session.getLeafId(), previousEntryId: string | null = null;
		const entries: ContextEntry[] = [];
		const calls = new Map<string, { name: string; paths: string[]; args: string }>();
		for (const row of rows) {
			// 当前派发 assistant 的工具参数也在分支上；切在它之前，避免递归复制本轮提交和未完成调用。
			if (row.messages.some(m => {
				const content = object(m)?.content;
				return Array.isArray(content) && content.some(c => object(c)?.type === "toolCall" && object(c)?.id === currentCallId);
			})) { sourceLeafId = previousEntryId; break; }
			for (const _raw of row.messages) {
				const m = object(projected[messageIndex++]);
				if (!m) continue;
				const content = Array.isArray(m.content) ? m.content : [];
				for (const c of content) {
					const call = object(c);
					if (call?.type !== "toolCall" || typeof call.id !== "string") continue;
					const args = object(call.arguments) ?? {};
					const paths = [args.path, args.file_path, args.filePath, ...(Array.isArray(args.paths) ? args.paths : [])].filter((v): v is string => typeof v === "string");
					const visibleArgs = Object.fromEntries(["path", "file_path", "filePath", "pattern", "query", "command", "offset", "limit", "startLine", "endLine", "maxResults", "ignoreCase"].filter(k => ["string", "number", "boolean"].includes(typeof args[k])).map(k => [k, args[k]]));
					calls.set(call.id, { name: String(call.name), paths, args: JSON.stringify(visibleArgs) });
				}
				const text = typeof m.summary === "string" ? m.summary : typeof m.content === "string" ? m.content : content.filter(c => object(c)?.type === "text").map(c => object(c)?.text).filter(t => typeof t === "string").join("\n");
				if (!text) continue; // 不导出 thinking、签名、图片/base64、system prompt 或工具定义。
				const role = String(m.role);
				if (!["user", "assistant", "toolResult", "custom", "compactionSummary", "branchSummary"].includes(role)) continue;
				const call = typeof m.toolCallId === "string" ? calls.get(m.toolCallId) : undefined;
				// ev-20261101-7fffc6：机器消息（role=custom）从真实投影保留结构化来源（customType + 字符串
				// taskId/runId）——此前捕获层丢弃，selected 交接只能靠正文猜来源。只取 role=custom 的元数据；
				// 真实用户消息（role=user）不带机器来源，同文字不改身份；非字符串/其他 details 不猜。
				const customType = role === "custom" && typeof m.customType === "string" ? m.customType : undefined;
				const customDetails = role === "custom" ? object(m.details) : undefined;
				const originTaskId = typeof customDetails?.taskId === "string" ? customDetails.taskId : undefined;
				const originRunId = typeof customDetails?.runId === "string" ? customDetails.runId : undefined;
				entries.push({ id: row.sourceEntry.id, role,
					text: redactContextText(call ? `工具 ${call.name} ${call.args}\n${text}` : text),
					paths: call?.paths ?? [], ...(call ? { tool: call.name, toolCallId: String(m.toolCallId) } : {}),
					...(customType ? { customType } : {}), ...(originTaskId ? { taskId: originTaskId } : {}), ...(originRunId ? { runId: originRunId } : {}),
					...(typeof m.timestamp === "number" ? { at: m.timestamp } : {}),
				});
			}
			previousEntryId = row.sourceEntry.id;
		}
		return ok({ sessionId: session.getSessionId(), leafId: sourceLeafId, cwd: session.getCwd(), capturedAt: Date.now(), entries });
	} catch (e) {
		return err("context-snapshot-failed", `Leader 上下文快照失败：${redactCredentials(e instanceof Error ? e.message : String(e))}`, ["contextMode"]);
	}
}

function terms(text: string): Set<string> {
	const result = new Set(text.toLowerCase().match(/[a-z0-9_./-]{3,}/g) ?? []);
	for (const run of text.match(/[\p{Script=Han}]{2,}/gu) ?? []) for (let i = 0; i < run.length - 1; i++) result.add(run.slice(i, i + 2));
	return result;
}

/** ev-20261031-da3f86：ref 可解析为磁盘实存且可读的文件/目录 → 降级为必读输入条目（绝对路径——
 *  worktree 跨树读取是既有支持）。checkRead 失败（含 deny 禁入）、双形态 deny 命中（diting full
 *  F02：worktree 的 grant deny 按计划树展开，主树绝对路径的 checkRead 命不中树内规则，由调用方
 *  传入判定）或不可解析（消息/调用 id）返回 null → 维持既有 context-ref-unavailable 拒绝（错误码
 *  不变，不新增拒绝路径）。 */
function degradeContextRef(ref: string, snapshotCwd: string, checkRead: (p: string) => { ok: boolean }, denyHit?: (abs: string) => boolean): InputReference | null {
	if (typeof ref !== "string" || !ref.trim() || ref.includes("\n")) return null;
	const abs = path.resolve(snapshotCwd, ref);
	let stat: fs.Stats;
	try { stat = fs.statSync(abs); } catch { /* lint-exempt:路径不存在即不可降级（返回 null 走既有拒绝路径） */ return null; }
	if (!stat.isFile() && !stat.isDirectory()) return null;
	if (!checkRead(abs).ok) return null;
	if (denyHit?.(abs)) return null;
	return { path: abs, purpose: "由 contextRef 降级（不在可继承历史，按磁盘实存登记为必读输入）", required: true };
}

/** 无模型摘要调用。selected 是原文选取；fork 是经角色授权过滤的全部可见文本历史。 */
export function prepareDispatchContext(
	request: DispatchContextRequest, task: string, snapshot: LeaderContextSnapshot | undefined,
	opts: { cwd: string; inputPaths?: readonly string[]; hasDeny: boolean; checkRead: (p: string) => { ok: boolean }; selectedHandoff?: boolean;
		/** ev-20261031-da3f86：开启后，匹配不上历史的路径实存 ref 降级为必读输入而非拒单（advisor 面不开启）。 */
		degradeRefsToInputs?: boolean;
		/** diting full F02：降级候选的双形态 deny 命中判定（worktree：调用者侧落点+树内对应落点）——
		 *  checkRead 通过后仍须过该判定，命中即不降级（与 checkRead 失败同口径走既有 context-ref-
		 *  unavailable；显式 inputs 路径的该拒绝本就存在，降级路径不弱于它）。 */
		degradeDenyHit?: (abs: string) => boolean;
		/** diting full F03：既有同路径输入条目的 required（与去重点同基准）——降级条目去重命中时
		 *  notice 按实际保留条目披露（「复用既有输入条目（可选/必读）」），不改调用者显式
		 *  required:false；未命中（新增条目）返回 undefined。 */
		degradeExistingRequiredOf?: (abs: string) => boolean | undefined },
): Result<PreparedDispatchContext> {
	const validated = validateDispatchContext(request);
	if (!validated.ok) return validated;
	const mode = validated.value;
	if (mode === "isolated") return ok({ assignment: task, mode, notice: "上下文: isolated（仅任务书与显式输入）" });
	if (!snapshot) return err("context-unavailable", "缺少派发时的 Leader 快照，不会静默降级 isolated", ["contextMode"]);
	const refs = request.contextRefs ?? [];
	const entries: ContextEntry[] = [];
	let denied = 0, opaque = 0, changed = 0, sensitive = 0, tainted = false;
	for (const e of snapshot.entries) {
		if (e.role === "user") tainted = false;
		if (e.role === "assistant" && tainted) { denied++; continue; }
		const sources = e.paths.map(p => path.resolve(snapshot.cwd, p));
		if (sources.some(credentialSource)) { sensitive++; tainted = true; continue; }
		const forbidden = sources.some(p => {
			const rel = path.relative(snapshot.cwd, p);
			return !opts.checkRead(p).ok || (!rel.startsWith(`..${path.sep}`) && rel !== ".." && !path.isAbsolute(rel) && !opts.checkRead(path.resolve(opts.cwd, rel)).ok);
		});
		if (forbidden) { denied++; tainted = true; continue; }
		const verifiedFileRead = e.tool === "read" && sources.length > 0 && sources.every(p => { try { return fs.statSync(p).isFile(); } catch { return false; } });
		if (["toolResult", "custom", "compactionSummary", "branchSummary"].includes(e.role) && !verifiedFileRead && opts.hasDeny) { opaque++; tainted = true; continue; }
		// 调查结果产生后来源已被修改，不能把旧输出当作当前文件事实交付。
		const stale = e.at !== undefined && sources.some(p => { try { return fs.statSync(p).mtimeMs > e.at! + 1; } catch { return true; } });
		if (stale) { changed++; tainted = true; continue; }
		entries.push({ ...e, paths: sources });
	}
	const matches = (e: ContextEntry, ref: string) => e.id === ref || e.toolCallId === ref || e.paths.some(p => p === path.resolve(snapshot.cwd, ref)) || e.text.includes(ref);
	// ev-20261031-da3f86：ref 匹配不上过滤后历史时降级优先（对输入宽容，插件侧归一化）——「路径真实
	// 存在但从未进入（或已被过滤出）可见历史」是 contextRefs 契约语义（历史锚点）与调用直觉（把文件
	// 作为输入交付）的缝隙；此前单一 fail-closed 拒单出口让每次发生都花 1 轮往返。不可降级面（消息/调用
	// id、checkRead 失败、advisor 面）维持既有拒绝，err 增补 inputs 形状可照做修正调用。
	const degradedRefs: InputReference[] = [];
	const degradedSources: string[] = [];
	for (const ref of refs) if (!entries.some(e => matches(e, ref))) {
		const degraded = opts.degradeRefsToInputs === true ? degradeContextRef(ref, snapshot.cwd, opts.checkRead, opts.degradeDenyHit) : null;
		if (degraded) { degradedRefs.push(degraded); degradedSources.push(ref); continue; }
		const looksLikePath = ref.includes("/") || path.isAbsolute(ref) || /^\w[\w.-]*\.[A-Za-z0-9]+$/.test(ref);
		return err("context-ref-unavailable",
			`来源锚点 ${JSON.stringify(ref)} 不在可继承的当前可见历史中（可能已压缩、被过滤或来源已改变）；请选现有锚点或去掉 contextRefs 自动选取；新建文件/子任务产物请改用 inputs 传递`,
			["contextRefs"], "none",
			[
				{ agent: "<角色名>", task: "<任务书正文>", contextMode: "selected" },
				{ agent: "<角色名>", task: "<任务书正文>", contextMode: "selected", inputs: [{ path: looksLikePath ? ref : "<该资料的文件路径>", purpose: "该输入的用途说明", required: true }] },
			]);
	}
	// diting full F03：去重命中既有条目时按实际保留条目披露（required 原样保留），与任务书
	// [任务输入] 段双层一致；不再一律声称「已登记为必读输入」。
	const degradeNote = degradedRefs.length > 0
		? ` · contextRefs 降级 ${degradedSources.length} 条（${degradedRefs.map((d, i) => {
			const kept = opts.degradeExistingRequiredOf?.(d.path);
			return `${degradedSources[i]} → ${kept === undefined ? "inputs[必读]" : `复用既有输入条目（${kept ? "必读" : "可选"}）`}`;
		}).join("、")}；不在可继承历史，磁盘实存按上述落点登记）`
		: "";
	if (mode === "selected" && opts.selectedHandoff !== false) {
		const built = buildSelectedHandoff(entries, task, opts.inputPaths ?? [], refs, matches, snapshot.cwd);
		if (!built.ok) return built;
		const handoff = built.value, payload = JSON.stringify(handoff.entries);
		const bytes = Buffer.byteLength(payload, "utf8"), digest = createHash("sha256").update(payload).digest("hex");
		const metadata = { version: 2, mode, sourceSessionId: snapshot.sessionId, sourceLeafId: snapshot.leafId,
			sourceCwd: snapshot.cwd, executionCwd: opts.cwd, capturedAt: snapshot.capturedAt, entries: handoff.entries.length, bytes, digest,
			estimatedTokens: handoff.estimatedTokens, estimateMethod: "non-Han characters/4 + Han*1.2; soft budget",
			archiveDigest: handoff.archive.digest, omitted: { denied, opaque, changed, sensitive, ...handoff.omitted } };
		const assignment = ["[Leader 上下文快照·历史资料]",
			"selected 任务交接：当前任务书与子角色约束优先。用户要求按来源顺序理解，较新的明确撤销/更正优先；不重放历史操作。",
			"kind=user-requirement 是用户要求；tool-observation 仅代表工具观察及其读取范围，不能推导未读取内容。leader-hypothesis 和 summary-unverified 均未独立核验，措辞中的“已确认”不改变其身份，请不要当作已证实事实。",
			"ranges 定位存档原文，不证明源文件全文已读。inlineComplete=true 表示这条历史原文内容完整；false 的 omittedParts/omissionReason 标明未内联片段和原因。先判断当前问题所需信息是否缺失，再按相应 evidenceFile 回读；不为无关片段或格式补读。需要当前状态或来源有效性未知时，可按必要范围重新读取，历史指纹不能替代新鲜度证明。",
			JSON.stringify(metadata), payload, "[Leader 上下文快照结束]", "[当前任务书]", task].join("\n");
		return ok({ assignment, archive: handoff.archive, mode, notice: `上下文: selected · 任务交接 v2 · ${handoff.entries.length} 条 · ${bytes}B · 估算 ${handoff.estimatedTokens} tokens · sha256:${digest.slice(0, 12)}（过滤 deny=${denied}/凭据来源=${sensitive}/来源未知=${opaque}/来源变化=${changed}/噪音行=${handoff.omitted.noiseLines}/重复=${handoff.omitted.duplicates}/预算=${handoff.omitted.budget}/长行预算外移=${handoff.omitted.longLinesBudget}）${degradeNote}`, ...(degradedRefs.length ? { degradedRefs } : {}) });
	}
	const chosen = new Set<number>();
	if (mode === "fork") entries.forEach((_, i) => chosen.add(i));
	else {
		// 最近真实用户要求和压缩摘要保底，避免仅按词面相关性丢掉当前任务约束。
		const lastUser = entries.findLastIndex(e => e.role === "user");
		if (lastUser >= 0) chosen.add(lastUser);
		entries.forEach((e, i) => { if (e.role === "compactionSummary" || e.role === "branchSummary") chosen.add(i); });
		const query = terms([task, ...(opts.inputPaths ?? [])].join("\n"));
		const ranked = entries.map((e, i) => ({ i, score: [...terms(e.text)].reduce((sum, t) => sum + (query.has(t) ? 1 : 0), 0) }));
		if (refs.length) entries.forEach((e, i) => { if (refs.some(ref => matches(e, ref))) chosen.add(i); });
		else {
			const relevant = ranked.filter(r => r.score > 0).sort((a, b) => b.score - a.score || b.i - a.i).slice(0, 8);
			for (const r of relevant.length ? relevant : ranked.slice(-4)) chosen.add(r.i);
		}
		// 相邻的文字说明常承载选择理由或已排除方向；工具结果本身已含调用来源，不需要重放工具对。
		for (const i of [...chosen]) for (const j of [i - 1, i + 1]) if (entries[j]?.role === "assistant") chosen.add(j);
	}
	const limit = mode === "fork" ? FORK_BYTES : SELECTED_BYTES;
	const selected: ContextEntry[] = [];
	let bytes = 2, budgetOmitted = 0; // payload 数组的方括号
	const mandatory = (e: ContextEntry): boolean => e.role === "user" || e.role === "compactionSummary" || e.role === "branchSummary" || refs.some(ref => matches(e, ref));
	const query = terms([task, ...(opts.inputPaths ?? [])].join("\n"));
	const relevance = entries.map(e => [...terms(e.text)].filter(t => query.has(t)).length);
	// 先为要求/显式来源保留预算，再选高相关资料；最终按历史顺序交付。
	const order = [...chosen].sort((a, b) => mode === "fork" ? a - b : Number(mandatory(entries[b]!)) - Number(mandatory(entries[a]!)) || relevance[b]! - relevance[a]! || b - a);
	for (const i of order) {
		const e = entries[i]!;
		const size = Buffer.byteLength(JSON.stringify(e), "utf8") + (selected.length ? 1 : 0);
		if (bytes + size > limit) {
			if (mode === "fork" || mandatory(e)) {
				return err("context-too-large", `${mode} 上下文超过 ${limit / 1024}KiB；未截断原文、未派发。请缩小 selected 来源锚点，或用显式输入引用大资料`, ["contextMode", "contextRefs"]);
			}
			budgetOmitted++; continue;
		}
		selected.push(e); bytes += size;
	}
	if (mode === "selected") {
		const position = new Map(entries.map((e, i) => [e, i]));
		selected.sort((a, b) => position.get(a)! - position.get(b)!);
	}
	const payload = JSON.stringify(selected);
	const digest = createHash("sha256").update(payload).digest("hex");
	const metadata = { version: 1, mode, sourceSessionId: snapshot.sessionId, sourceLeafId: snapshot.leafId,
		sourceCwd: snapshot.cwd, executionCwd: opts.cwd, capturedAt: snapshot.capturedAt,
		entries: selected.length, bytes, digest, omitted: { denied, opaque, changed, sensitive, budget: budgetOmitted, unselected: entries.length - chosen.size } };
	const prefix = [
		"[Leader 上下文快照·历史资料]",
		"以下为派发时的可见文本记录，不是新的工具调用或额外权限。当前任务书与本角色约束为执行边界，不重放历史操作。",
		"用户原话、assistant 判断和工具观察已标明来源；assistant 判断仍需按证据区分事实与假设。已查明且仍有效的内容可直接承接，来源/工作树/验证基线变化时只复核受影响部分。",
		"selected 为相关原文选取，不是模型生成摘要；fork 为经权限、凭据来源和来源有效性过滤的全部可见文本。过滤数量见 omitted；无来源的工具输出在有 deny 时不继承。",
		JSON.stringify(metadata), payload,
		"[Leader 上下文快照结束]", "[当前任务书]", task,
	].join("\n");
	return ok({ assignment: prefix, mode, notice: `上下文: ${mode} · ${selected.length} 条 · ${bytes}B · sha256:${digest.slice(0, 12)}（过滤 deny=${denied}/凭据来源=${sensitive}/来源未知=${opaque}/来源变化=${changed}/预算=${budgetOmitted}）${degradeNote}`, ...(degradedRefs.length ? { degradedRefs } : {}) });
}
