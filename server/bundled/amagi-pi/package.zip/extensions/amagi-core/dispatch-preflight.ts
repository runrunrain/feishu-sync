/**
 * dispatch-preflight.ts — ev-20260916-2dbc7f/c5ee56：单一派发预检评估（S4 算法模块）。
 *
 * 背景（方案 §5.1）：旧 worktree 建议在 execute 内以迟到 steer 注入（"发生在执行后、却建议执行前
 * 换路线"）；且依赖可见性、相反建议各自加提示，噪音与矛盾并存。本模块把纯评估收敛为单一实现：
 * `evaluateDispatch(input) -> { recommendation: 'main'|'worktree'|'none', reasons, uncertainty, cwd, observedAt }`，
 * 供 S2 的 task dryRun（拟新增，不 spawn、不占 admission、不创建 worktree）与内部评估记录复用。
 * task-tool 内旧 `suggestWorktreeDispatch` 的删除与接线归 S2——本模块是其唯一替代实现的家；
 * `looksLikeLargeChange`/`looksLikeReadOnlyTask` 为自 task-tool 迁移的忠实副本（S2 删除原件后此处为唯一实现）。
 *
 * 判定优先级固定（方案 §5.1，语义不可变）：
 *  1. 显式 worktree / 已在 linked worktree / 只读任务 / exportPrompt / resume → none（仅记录事实，不给相反建议）；
 *  2. 依赖主树未提交前置产物（workspaceNeeds='main-tree'）或主树 dirty → main（理由逐项列出）；
 *  3. 状态或依赖可见性未知 → none（uncertainty 提示先核实，不武断选 worktree）；
 *  4. 主树干净 + portable + 大改 → worktree；其他 none。
 *
 * 边界约束：
 *  - **不能以发现 node_modules 就断言 worktree 不可用，也不能以目录干净就断言运行依赖可复制**——
 *    依赖可见性只来自调用方显式声明的 workspaceNeeds（自然语言识别可补充理由但不能推翻显式声明）；
 *    本模块不做任何文件系统依赖扫描。
 *  - 纯评估：输入仅为规范化任务上下文 + 只读 Git 事实（observeDispatchFacts 采集），不自行
 *    sendMessage、不 spawn 子进程（除只读 git 探测）、不获取 admission、不创建/删除任何 worktree。
 *  - 依赖门禁：不 import task-tool/index（引擎兄弟模块不得反向依赖编排面）。
 *
 * 回滚：AMAGI_WORKTREE_PREFLIGHT=legacy 暂回旧 steer 时序（开关解析见 worktreePreflightMode，供 S2
 * 接线消费）；建议开关复用 AMAGI_WORKTREE_SUGGEST=0（归 task-tool/S2）。非法 env 值回安全默认。
 */

import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { isInsideLinkedWorktree } from "./worktree.ts";
import { loadMcpServerConfigs, MCP_UNIFIED_CHANNEL_SERVER } from "./mcp-config.ts";
import { findLspRequirementGaps, type LspRequirementGap } from "./lsp-tool.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import { createFilePermissionEnforcer } from "./file-permission.ts";

// ── 任务书语义识别（自 task-tool.ts 迁移的忠实副本；S2 删除 task-tool 内原件后此处为唯一实现）──

/** 大改任务书特征（关键词族）；与 ≥600 字符阈值（超长任务书几乎必是跨文件大改）同判。 */
const LARGE_CHANGE_RE = /重构|重写|改写|迁移|大改|大范围|整体(?:改造|调整|重做)|批量(?:修改|调整|替换|重构)|多文件|全量(?:替换|重构)|跨模块|大规模/;

/** 大改任务书识别（纯函数）：关键词命中或文本 ≥600 字符。 */
export function looksLikeLargeChange(task: string): boolean {
	if (typeof task !== "string" || !task) return false;
	if (task.length >= 600) return true;
	return LARGE_CHANGE_RE.test(task);
}

const READ_ONLY_ABSOLUTE_RE = /只审不改|只看不改|纯只读|read-?only|无需(?:任何)?改动|不(?:得|要|需|应)?(?:修改|改动|写入|落盘|编辑)任何?(?:文件|代码|内容)/;
const REVIEW_VERB_RE = /审[查阅核]|复核|复审|评审|巡检|复盘|review|查阅|阅读|检索|梳理|调研|调查|答疑/i;
const IMPL_VERB_RE = /实现|落地|修复|编写|新增|删除|改写|重构|迁移|替换|修改|更新|开发|提交|创建|写入|补充|完善|优化|清理/;
const REVIEW_OBJECT_RE = /(?:审[查阅核]|复核|复审)[^。；\n]{0,30}(?:diff|改动|变更|重构|迁移|改写)/;
// 明确实现请求：审查动词之后经连接词（序列/并列）短距离内接实现动词——「审查重构 diff 并修复发现的
// 问题」是真实改动任务，不得判只读。缓冲限 12 字；否定语屏障（动词前 ≤3 字内有 不/未/无/勿/别/禁）。
const REVIEW_IMPL_REQUEST_RE = /(?:审[查阅核]|复核|复审)[^。；\n]*?(?:之?后|然后|再|随后|接着|并|以及|且|同时|随之)[^。；\n]{0,12}(?<![不未无勿别禁][^。；，\n]{0,3})(?:实现|落地|修复|重构|迁移|修改|改写|替换|编写|开发|新增|删除)/;

/** 只读审查/查询任务书识别（纯函数）：明确实现请求优先不判只读；只读声明 / 审查指令且无实现动词 /
 *  审查对象引用（书内「重构」是被审内容而非改动面）→ 只读。判定偶误不加仓（误判代价=少一条建议）。 */
export function looksLikeReadOnlyTask(task: string): boolean {
	if (typeof task !== "string" || !task) return false;
	if (REVIEW_IMPL_REQUEST_RE.test(task)) return false;
	if (READ_ONLY_ABSOLUTE_RE.test(task)) return true;
	if (REVIEW_VERB_RE.test(task) && !IMPL_VERB_RE.test(task)) return true;
	if (REVIEW_OBJECT_RE.test(task)) return true;
	return false;
}

// ── 单一派发评估（evaluateDispatch）──

/** 任务依赖可见性声明（方案 §5.1 拟新增最小声明，默认 unknown；仅用于建议，不覆盖显式 worktree）。 */
export type WorkspaceNeeds = "main-tree" | "portable" | "unknown";

export type DispatchRecommendation = "main" | "worktree" | "none";

export interface DispatchPreflightInput {
	/** 派发目标目录（结果原样回显；探测事实由调用方经 observeDispatchFacts 采集或自行提供）。 */
	cwd: string;
	/** 任务书正文（只读/大改语义识别；无任务书时不识别）。 */
	task?: string;
	/** 调用方已显式携带 worktree 参数（隔离意图已表达，不再给建议）。 */
	explicitWorktree?: boolean;
	/** resume 会话派发（沿用原会话工作目录）。 */
	resume?: boolean;
	/** exportPrompt 纯导出（不 spawn、产物不落主树）。truthy 判定同 task 参数语义。 */
	exportPrompt?: boolean | string;
	/** 角色章程只读（diting/baize 等「纯只读/只审不改」章程角色）。 */
	agentReadOnly?: boolean;
	/** 依赖可见性声明；缺省 unknown（不能以目录干净推断 portable）。 */
	workspaceNeeds?: WorkspaceNeeds;
	/** 主树（主检出）脏树状态；null/缺省 = 未知（探测失败或未提供）——未知不参与"干净"判定。 */
	mainTreeDirty?: boolean | null;
	/** 派发 cwd 是否位于 linked worktree 内（可由 observeDispatchFacts 采集）。 */
	insideLinkedWorktree?: boolean;
	/** 派发 cwd 是否 git 仓库（非 git 目录 worktree 语义不成立；可由 observeDispatchFacts 采集）。 */
	isGitRepo?: boolean;
	/** 大改特征显式覆盖（缺省时按任务书文本识别）。 */
	largeChange?: boolean;
}

export interface DispatchEvaluation {
	/** 单一建议——恒为 'main' | 'worktree' | 'none' 三者之一（同一次评估只输出一个结论）。 */
	recommendation: DispatchRecommendation;
	/** 逐项理由（决策可追溯；事实记录与建议理由都在此）。 */
	reasons: string[];
	/** 可见性缺口（未知项）——提示先核实，不武断选择。 */
	uncertainty: string[];
	/** 评估目标目录（原样回显输入 cwd）。 */
	cwd: string;
	/** 评估观测时刻（epoch ms）。 */
	observedAt: number;
}

/** 单一派发预检评估（纯函数，不做任何 Git/文件系统探测——事实全部来自输入；判定优先级见模块头）。
 *  同一组输入恒得同一 recommendation；每类命中理由逐项列出。 */
export function evaluateDispatch(input: DispatchPreflightInput): DispatchEvaluation {
	const task = typeof input.task === "string" ? input.task : "";
	const readOnly = input.agentReadOnly === true || looksLikeReadOnlyTask(task);
	const largeChange = input.largeChange ?? looksLikeLargeChange(task);
	const needs: WorkspaceNeeds = input.workspaceNeeds ?? "unknown";
	const dirty = input.mainTreeDirty === true ? true : input.mainTreeDirty === false ? false : null;
	const observedAt = Date.now();

	// 优先级 1：不建议面（none）——显式选择/不适用场景只记录事实，不给相反建议
	const noSuggest: string[] = [];
	if (input.explicitWorktree) noSuggest.push("显式 worktree 参数已表达隔离意图，无需建议");
	if (input.isGitRepo === false) noSuggest.push("派发目标非 git 目录——worktree 隔离语义不适用");
	if (input.insideLinkedWorktree) noSuggest.push("派发目标已在 linked worktree 内——树内未提交改动是本工作流合法半成品，不适用主树/隔离建议");
	if (input.resume) noSuggest.push("resume 沿用原会话工作目录，无新派发工作树选择");
	if (input.exportPrompt !== undefined && input.exportPrompt !== false) noSuggest.push("exportPrompt 为纯导出（不 spawn、产物不落主树），无隔离需求");
	if (readOnly) noSuggest.push("只读任务（角色章程只读或任务书只读/审查语义）——审核对象≠改动面，无隔离建议");
	if (noSuggest.length) {
		// 仅记录已知事实（不给"应改主树/应隔离"的相反建议）
		if (dirty === true) noSuggest.push("事实：主树存在未提交改动——worktree 是全新 checkout，不含这些改动");
		return { recommendation: "none", reasons: noSuggest, uncertainty: [], cwd: input.cwd, observedAt };
	}

	// 优先级 2：main——依赖主树未提交产物/不可复制运行环境，或主树 dirty（理由逐项列出）
	const mainReasons: string[] = [];
	if (needs === "main-tree") mainReasons.push("任务声明依赖主树未提交前置产物或不可复制的本地运行环境（workspaceNeeds=main-tree）——worktree 是全新 checkout，前置产物在新树不可见");
	if (dirty === true) mainReasons.push("主树存在未提交改动——任务书若依赖主树未提交产物，新树内不可见；主树作业更优");
	if (mainReasons.length) return { recommendation: "main", reasons: mainReasons, uncertainty: [], cwd: input.cwd, observedAt };

	// 优先级 3：可见性未知 → none（提示先核实；不默认当作干净/可复制，不武断选 worktree）
	const uncertainty: string[] = [];
	if (dirty === null) uncertainty.push("主树工作区状态未知（探测失败或未提供）——先核实（git status）再决策；不默认当作干净或脏");
	if (needs === "unknown") uncertainty.push("任务依赖可见性未知（workspaceNeeds 未声明 main-tree/portable）——先核实运行依赖能否在新树复制（node_modules/构建产物/本地环境）；目录干净不等于依赖可复制");
	if (uncertainty.length) {
		return { recommendation: "none", reasons: ["可见性不足，不武断选择 worktree——先补齐事实再评估"], uncertainty, cwd: input.cwd, observedAt };
	}

	// 优先级 4：主树干净 + portable 确认 → 大改 worktree；其他 none
	if (largeChange) {
		return {
			recommendation: "worktree",
			reasons: [
				"主树干净（无未提交改动）且任务依赖可复制（workspaceNeeds=portable）",
				"命中大改特征（重构/迁移/多文件/超长任务书）——独立工作树作业：半成品不污染主树，中断/取消后可对账合并",
			],
			uncertainty: [],
			cwd: input.cwd,
			observedAt,
		};
	}
	return { recommendation: "none", reasons: ["未命中大改特征（关键词族或 ≥600 字任务书）——无需隔离建议"], uncertainty, cwd: input.cwd, observedAt };
}

// ── 只读 Git 事实采集（observeDispatchFacts，供 S2 dryRun/内部评估接线）──

/** 从 start 向上有界查找 .git（目录或 worktree 链接文件均算；深度 ≤32，止于 fs 根）。 */
function isInsideGitRepoLocal(start: string): boolean {
	let dir = path.resolve(start);
	for (let i = 0; i < 32; i++) {
		if (fs.existsSync(path.join(dir, ".git"))) return true;
		const parent = path.dirname(dir);
		if (parent === dir) return false;
		dir = parent;
	}
	return false;
}

/** 有界脏树探测（只读；timeout 2s / maxBuffer 64KiB，与 probeGitDirtyState 同安全界）。失败 → null（未知）。 */
function probeDirty(cwd: string): boolean | null {
	try {
		const out = execFileSync("git", ["status", "--porcelain"], { cwd, encoding: "utf8", timeout: 2000, maxBuffer: 64 * 1024, stdio: ["ignore", "pipe", "ignore"] });
		return out.split("\n").some((l) => l.trim().length > 0);
	} catch {
		return null;
	}
}

/** 主检出根推导：--git-common-dir（共享 .git）所在目录；bare/非常规布局 → undefined（不猜测）。 */
function mainCheckoutRoot(cwd: string): string | undefined {
	try {
		const out = execFileSync("git", ["rev-parse", "--git-common-dir"], { cwd, encoding: "utf8", timeout: 2000, maxBuffer: 16 * 1024, stdio: ["ignore", "pipe", "ignore"] }).trim();
		if (!out) return undefined;
		const abs = path.resolve(cwd, out);
		if (!abs.endsWith(`${path.sep}.git`)) return undefined;
		const root = path.dirname(abs);
		return fs.existsSync(root) ? root : undefined;
	} catch {
		return undefined;
	}
}

export interface DispatchFacts {
	/** 派发目标目录（原样回显）。 */
	cwd: string;
	/** 是否 git 仓库（向上有界 .git 探测）。 */
	isGitRepo: boolean;
	/** 是否位于 linked worktree 内（复用 worktree.ts isInsideLinkedWorktree 同一归属判定）。 */
	insideLinkedWorktree: boolean;
	/** 主树（主检出）脏树状态；null = 探测失败/未知。从 linked worktree 派发时探测主检出本身，
	 *  不拿 linked 树工作区状态冒充主树状态；主检出推导失败 → null（诚实未知）。 */
	mainTreeDirty: boolean | null;
}

/** 采集 evaluateDispatch 所需的只读 Git 事实（有界、低频路径专用；不写任何状态）。
 *  S2 接线示例：`const f = observeDispatchFacts(cwd); const ev = evaluateDispatch({ cwd, task, mainTreeDirty: f.mainTreeDirty, insideLinkedWorktree: f.insideLinkedWorktree, isGitRepo: f.isGitRepo, ... });` */
export function observeDispatchFacts(cwd: string): DispatchFacts {
	const linked = isInsideLinkedWorktree(cwd);
	const isGitRepo = isInsideGitRepoLocal(cwd);
	let mainTreeDirty: boolean | null;
	if (linked) {
		// 主树状态必须落到主检出（git common dir 所属工作区）上——linked 树的脏态是树自身产出，不是主树事实
		const mainRoot = mainCheckoutRoot(cwd);
		mainTreeDirty = mainRoot ? probeDirty(mainRoot) : null;
	} else {
		mainTreeDirty = isGitRepo ? probeDirty(cwd) : null;
	}
	return { cwd, isGitRepo, insideLinkedWorktree: linked, mainTreeDirty };
}

// ── 回滚开关解析 ──

/** AMAGI_WORKTREE_PREFLIGHT 解析：preflight（默认）= dryRun 前置评估；legacy = 暂回旧 steer 时序
 *  （S2 接线时消费）。非法值回安全默认 preflight。 */
export function worktreePreflightMode(): "preflight" | "legacy" {
	return process.env.AMAGI_WORKTREE_PREFLIGHT === "legacy" ? "legacy" : "preflight";
}

// ── Declared outputs are not write grants (ev-20261012-919d09) ────────────────

/** Advisory only. Use the actual execution-point checker, including physical targets;
 * never infer or expand write authority from an output declaration. */
export function declaredOutputWriteHint(
	cwd: string,
	grant: Readonly<PermissionGrant>,
	outputs: ReadonlyArray<{ path: string }>,
): string | undefined {
	if (grant.assurance !== "tool-enforced" || outputs.length === 0) return undefined;
	const files = createFilePermissionEnforcer(grant, cwd);
	const blocked = [...new Set(outputs.map(o => path.resolve(cwd, o.path)))].filter(p => !files.checkWrite(p).ok);
	if (blocked.length === 0) return undefined;
	return `[产物写面提示] 当前冻结授权不能直接写入 ${blocked.slice(0, 4).join("、")}${blocked.length > 4 ? ` 等 ${blocked.length} 处` : ""}。outputs 仅声明产物，不授予写面；工作区外产物须在 scope.write/reportFiles 显式声明准确目标，或调整 workspace.cwd（deny/跨根/契约存储限制仍优先，声明不能绕过）。否则需 agent-outputs 中转及 Leader 代落盘；本提示不扩权、不拒单。`;
}

// ── v2 P4（方案 §5.2/§8.3-P4）：任务声明的必要服务派发前缺项检查 ────────────────

export interface DispatchRequirementGap {
	/** 缺项通道。 */
	channel: "mcp" | "lsp";
	/** 具体缺项说明（含任务要求与实际不可用原因，可直接进派发拒绝文案）。 */
	reason: string;
}

/** MCP server 级缺项：真实 server 名条目（非 P1 统一通道占位）要求的具体 server 未配置。
 *  与 mcp-client.findMcpRequirementGaps 同文案口径（`配置无 server "x"（已配置: …）`；发现缓存级
 *  缺项该函数另有覆盖——此处不依赖 mcp-client，避免 mcp-client→task-tool 反向边把引擎接入点成环）。
 *  通配条目（占位归一后的 "*"）不检查 server 级——路由面不等于工具授权，无具体名可查。 */
function mcpServerGaps(cwd: string, required: ReadonlyArray<{ server: string; tool: string }>): DispatchRequirementGap[] {
	const gaps: DispatchRequirementGap[] = [];
	const concrete = required.filter((r) => r && typeof r.server === "string" && typeof r.tool === "string"
		&& r.server.trim() !== "" && r.tool.trim() !== ""
		&& r.server !== "*" && r.server !== MCP_UNIFIED_CHANNEL_SERVER);
	if (concrete.length === 0) return gaps;
	const { servers } = loadMcpServerConfigs(cwd);
	const names = Object.keys(servers);
	const disabled = process.env.AMAGI_MCP_DISABLE === "1";
	for (const req of concrete) {
		if (!servers[req.server]) {
			gaps.push({
				channel: "mcp",
				reason: disabled
					? `任务要求 mcp:${req.server}/${req.tool}，但 MCP 通道已禁用（AMAGI_MCP_DISABLE=1）`
					: `任务要求 mcp:${req.server}/${req.tool}，但配置无 server "${req.server}"（已配置: ${names.join(", ") || "无"}）`,
			});
		}
	}
	return gaps;
}

/** P4 派发前缺项检查：任务冻结授权声明的 mcp/lsp 通道 vs 配置/检测可用性（§5.2「缺必要服务
 *  派发前给具体缺项，不静默空名单」）。纯检查（不 spawn 语言服务器、不碰 MCP transport）；
 *  任务未声明（空名单）→ 零缺项。引擎（task-run）在 spawn 前调用，命中即拒发并透出缺项文案。 */
export function findDispatchRequirementGaps(cwd: string, grant: Readonly<PermissionGrant>): DispatchRequirementGap[] {
	const gaps: DispatchRequirementGap[] = [];
	gaps.push(...mcpServerGaps(cwd, grant.mcp));
	for (const g of findLspRequirementGaps(cwd, grant.lsp) as LspRequirementGap[]) {
		gaps.push({ channel: "lsp", reason: g.reason });
	}
	return gaps;
}
