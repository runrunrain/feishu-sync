/**
 * bash-override.ts — Wave A2：同名覆盖内置 bash，新增 cwd 参数（对应 ev-20260815-0877b0）。
 *
 * 痛点（复盘 §3.1 ①④）：pi 原生 bash schema 仅 {command, timeout}；`cd X && cmd` 前缀在
 * 后台场景有 `&` 子 shell 陷阱（cd 被圈进子 shell，后续命令在原 cwd 执行报 MODULE_NOT_FOUND），
 * 子 Agent 任务文本被迫反复写绝对路径。
 *
 * 实现策略（pi extensions.md「Overriding Built-in Tools」官方模式）：
 *  - cwd 缺省 → 委托 createBashToolDefinition(baseCwd).execute，与原生逐字节一致
 *    （OutputAccumulator 截断策略、fullOutputPath 落盘、timeout 文本、exit code 格式全走原生路径）。
 *  - cwd 显式 → 先 existsSync+isDirectory 校验（不存在/不是目录直接报错，不 spawn），
 *    再委托以 resolvedCwd 构造的原生定义执行——绝不用 `cd X && ` 前缀改写命令（那正是
 *    & 子 shell 陷阱的来源；createLocalBashOperations.exec(command, cwd, …) 原生支持 cwd）。
 *  - 失败协同：cwd 显式且执行失败 → 保留原生首段错误，尾部附一行 `[cwd] <resolvedCwd>`
 *    （非零退出/timeout/abort/底层 throw 统一覆盖，B2 诊断波特征路由用）；cwd 缺省路径除 P2-6 note 外逐字节原生。
 *  - 任务边界 env 泄漏修复（fix-env-leak）：Leader 派发注入的 AMAGI_ALLOWED_PATHS/AMAGI_PROTECTED_PATHS
 *    会随 getShellEnv() 的 process.env 展开泄入测试进程，guard 哨兵测试的「无边界 env 放行」断言被误拦。
 *    经原生 BashToolOptions.spawnHook（spawn 前 command/cwd/env 调整钩）在命令命中测试运行特征时
 *    剔除且仅剔除这两个任务边界变量；非测试命令 context 原对象透传，行为与原生一致。
 *  - 长驻防线（复盘 P2-6，2026-08-16）：bashAdvisoryNote 三层软提示——①前置识别长驻模式（未带
 *    timeout 参数）劝限时/后台化；②前台耗时超阈值（默认 120s，AMAGI_BASH_LONGRUN_MS 可调，0=关闭）
 *    事后提示；③timeout/abort 掐断后给残留排查命令（lsof/ps/pkill）。成功路径追加在 content 文本尾部、
 *    失败路径追加在 e.message 尾部（[cwd] 行之后）；纯后处理，不改写命令、不阻断、不影响原生 shape 其余字段。
 *  - ABI 翻转感知（ev-20260903-191473，复盘 §1.1；ev-20261031-a25f7a 计次降频）：成功执行后
 *    recordEnvFlip 落/删 Electron ABI marker，测试类命令再经 abiReminderCompactNote 输出恢复指引
 *    （首次全文、同会话第 2 次起一行折叠；与 P2-6 长驻提示合并追加，先 ABI 后长驻、各占一行）；
 *    失败 catch 路径保持既有失败协同格式，不加 ABI 提醒。
 *  - 长驻警告分类与过渡指引（ev-386692/ev-99a6cd，2026-09-16 优化方案 S3）：默认 classified——一次性命令
 *    词表（vitest run/tsc/playwright test/build/lint/typecheck 等）豁免常驻警告，长耗时只给中性「显式设置
 *    预算」提示（不称常驻）；watch/dev/serve 常驻真警示首报后同会话去重。ev-99a6cd 已于 2026-09-17 落地
 *    run_bg 后台原语（run-bg.ts）：长驻指引改指 run_bg + 既有 task background / rpc_task。
 *    AMAGI_BASH_ADVISORY_POLICY=legacy 回旧行为（AMAGI_BASH_LONGRUN_MS 原语义保留）。
 *  - rg -r 粘连簇输出污染警示（ev-20260920-f736d8，前置通道）：rg 的 `-rn`/`-rln` 等粘连簇中 -r 是
 *    --replace，命令 exit 0 且输出被静默改写——尾部软提示在长输出下 100% 被忽略（实战复发 2/2 +
 *    修复当日 Leader 会话再复发 2/2）。根因是信号强度与危害不匹配：污染级警示与耗时/常驻建议级共用
 *    同一尾部追加通道。分级修复：rg 粘连簇升级为 criticalBashAdvisory（⚠️ 标题 + 修正命令），经
 *    prependAdvisoryNote 前置到输出首部（先于被污染内容被读到），不去重不阻断；bashAdvisoryNote 尾部
 *    通道不再承担 rg lint（建议级语义：耗时/常驻/中止残留）。
 *  - renderCall/renderResult 省略 → 继承内置渲染；结果 shape 由原生 execute 产出，天然匹配
 *    BashToolDetails（truncation?/fullOutputPath?）。提示与渲染元数据继承原生定义，只追加 amagi 能力说明。
 *  - 错误表达（pi 0.99.1 适配，N1b）：timeout/abort/底层 throw 仍以 throw 表达；非零退出改为
 *    resolve + isError:true（宿主 BashTool 0.99.1 语义）——失败协同（[cwd] 附注/审计 ok:false/失败
 *    路径注记）在 isError 结果分支处理，成功侧效果（fs 变更记录/写目标/ABI marker/成功注记）不进失败路径。
 *  - G-1（pi099 L 报告 §1）：定义面透传原生 bashOutputSchema（baseDef.outputSchema 引用）——宿主
 *    未从包根导出该符号（bash.js:40 模块私有 const），baseDef 定义上携带（bash.js:172）；codemode
 *    程序化面按声明解析（tool.js:147 / execute.js:174-175），缺声明则脚本调用退化纯文本。纯声明零行为变化。
 *  - 守卫（guards.ts beforeExecution 事件链）由 pi 事件系统按 toolName=bash 驱动，覆盖后照常生效。
 *  - 轻量观测（ev-20260926-bc6ba3 R5）：新增可选 debugTag 参数（1-64 位 ASCII [A-Za-z0-9._-]，非法
 *    执行前拒绝不 spawn）——委托原生 bash 前冻结 tag+会话 generation，完成/失败时从原生结果采集
 *    真实最终文本（在添加 amagi advisory/心跳文案**前**采集，不把提示当程序日志），已开启时尾部附
 *    ≤4KiB 的 [debug <tag>] 聚合摘要。只读采集+尾部追加，不改写原始行/命令/环境/cwd/退出码/
 *    details.fullOutputPath/truncation；timeout/abort/throw 采真实错误、保持原语义。会话默认标签与
 *    off/clear/show 经 /amagi debug 命令管理（amagi-commands.ts；collector 见 debug-observation.ts）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { AsyncLocalStorage } from "node:async_hooks";
import { Type } from "typebox";
import { createBashToolDefinition, type BashSpawnContext } from "@earendil-works/pi-coding-agent";
import { builtinFileCwd } from "./builtin-file-target.ts";
import { maybeSnapshotAnchor } from "./snapshot-guard.ts";
import { recordFsMutations } from "./fs-mutation-tracker.ts";
import { recordBashWriteTargets } from "./task-write-log.ts";
import { recordEnvFlip, abiReminderNote, abiFlipMarkerAt } from "./env-flip.ts";
import { toolProcessEnv } from "./tool-process-env.ts";
// ev-20261020-d56baa：项目 shell.pathPrepend ——bash spawn 同源 PATH 前置（与 run_bg/子 Agent/基线测试共用）
import { envWithPathPrepend, readProjectShellPathPrepend } from "./shell-env.ts";
export { nonInteractiveToolEnv } from "./tool-process-env.ts";
import { executableWords, shellSegments, shellPipelineChains, commandSubstitutions, tokenizeShellSpans, segmentShellSpans, type ShellTokenSpan } from "./shell-lexer.ts";
import { RepeatNoteTracker, withEscalatedNote, withCompactEscalatedNote } from "./guard-notes.ts";
import { spawnSync } from "node:child_process";
// ev-20260922-1eea28（B2）：授权丢弃的一次性放行凭证与结果记录（执行边界承接）——guard 预检
// 签发凭证（绑定 toolCallId/canonicalCommand/cwd），本层在执行前消费（预检后换命令/cwd 即失效）、
// 执行后把真实退出结果落盘到备份目录（outcome.jsonl 持久事实；guard-note 由 guards tool_result
// 发送，发送失败不抹掉此处落盘）。零授权时零开销直通。
import { takeDiscardExecutionTicket, recordDiscardExecutionOutcome, type DiscardExecutionTicket } from "./git-discard-backup.ts";
import { resolveBuiltinConstrainedSampling } from "./host-capabilities.ts";
import { isPosixStyleAbsolutePath, posixToWindowsVisible, probeBashRuntime, type BashRuntimeInfo } from "./runtime-env.ts";
// ev-20261002-de1845：GNU-only 旗标/地址执行前预警——复用 guards BSD 诊断单源的词法检测与平台归因
import { gnuOnlyBsdPatternHit, shellPlatformOf, wholeScanFindHit } from "./guards.ts";
import { guardRuleOf, guardProjectTrustedOf } from "./guard-policy.ts";
import { commitGuardDisclosureNote } from "./guards.ts";
import { isReadonlySearchCommand, looksLikeWatchCommand } from "./watch-probe.ts";
// ev-20260917-7b9298（P2）：bash 子孙进程环境标记 + 超时收尾级联回收（孤儿回收链）
import { orphanReaperEnabled, reapInvocationOrphans } from "./orphan-reaper.ts";
// ev-20260914-8f2669②：静默心跳周期/总窗从看门狗静默窗口推导（共用口径，env 读取点留在 watchdog.ts）
import { resolveSilenceMsEnv } from "./watchdog.ts";
// ev-20260926-bc6ba3（R5）：bash 真实输出轻量观测——采集决定冻结/事件记录/聚合摘要（纯内存 collector）
import { debugTagValid, freezeDebugCapture, recordDebugEvent, debugTagSummary, type DebugCapture } from "./debug-observation.ts";

// 仅追加 amagi 参数说明；原生系统提示从工具定义继承。
const CWD_GUIDELINE = "使用 bash 时可传 cwd 指定工作目录，避免 cd 前缀链（后台 & 场景 cd 会被子 shell 圈定）";
const DEBUG_TAG_GUIDELINE = "排查真实输出可给 bash 传 debugTag（1-64 位 ASCII 字符 [A-Za-z0-9._-]，非法即执行前拒绝）：命令完成时按标签采集真实最终输出/错误（stdout+stderr 合并流）并尾部附聚合摘要；会话级采集经 /amagi debug on <tag>/off/clear/show [tag] 管理——只采真实输出，不能读无输出程序的内部变量，不跨进程查子进程缓冲";

const schema = Type.Object({
	command: Type.String({ description: "Bash command to execute" }),
	timeout: Type.Optional(Type.Number({ description: "Timeout in seconds (optional, no default timeout)" })),
	cwd: Type.Optional(Type.String({ description: "Working directory for this command: absolute, or relative to the session cwd. Prefer this over `cd X && cmd` prefixes (which break in background `&` subshells). Must be an existing directory." })),
	debugTag: Type.Optional(Type.String({ description: "Optional debug tag (1-64 ASCII chars [A-Za-z0-9._-]): on completion, collect this command's real final output (combined stdout+stderr) or error into the session debug collector and append a [debug <tag>] summary. Invalid tags are rejected before execution. Session default tag managed via /amagi debug on|off|clear|show." })),
});

export interface BashCwdOverrideInput {
	command: string;
	timeout?: number;
	cwd?: string;
	debugTag?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// P2-6（2026-08-16 复盘）：长驻命令前台运行的收尾残留防线。
//
// 实战根因：子 Agent 前台跑 dev server 类长命令，任务收尾后进程不被带走，留下监听
// 端口/半死 worktree，人工 lsof+pkill 清理一次。防线是三层追加在原生结果尾部的软提示：
//  ① 前置识别：命令命中长驻模式且未带 timeout 参数 → 提示限时或后台化（事前劝阻）；
//  ② 事后提示：前台执行超阈值（默认 120s，env AMAGI_BASH_LONGRUN_MS 可调，0=关闭）→ 提示后台化/拆分；
//  ③ 中止/超时：前台命令被 timeout/abort 掐断 → 给出残留排查命令（lsof/ps grep/pkill）。
// 优先级 ③ > ① > ②（中止残留最紧急；命中①时②的建议已包含在①里，不重复堆行）。
// ─────────────────────────────────────────────────────────────────────────────

/** 长驻命令识别模式（复盘 P2-6 约定口径；python http.server 兼容 python3 与 SimpleHTTPServer 两种模块名）。 */
const LONGRUN_COMMAND_RE = new RegExp(
	[
		"vite",
		"next dev",
		"nodemon",
		"webpack[\\s\\S]*watch",
		"jest [\\s\\S]*watch",
		"vitest [\\s\\S]*watch",
		"http-server",
		"live-server",
		"python[0-9.]* -m (http\\.server|SimpleHTTPServer)",
		"flask run",
		"uvicorn",
		"rails s",
		"docker compose up",
		"npm (run|exec)[\\s\\S]*(dev|serve|start)",
		"pnpm (dev|serve)",
		"yarn (dev|serve)",
		"cargo watch",
		"terraform apply",
	].join("|"),
);

/**
 * ev-20260903-c1521b②：watch 型常驻识别（优先于通用长驻文案）——2026-09-04 起探测实现
 * 收敛到 watch-probe.ts（ev-20260904-0678c1 误报根治：词边界 + /dev/* 剥离 + 只读白名单短路），
 * 与 rpc-pool-tool 共用同一实现，口径不再单边漂移：tsx watch/pnpm dev/vite dev 等
 * watch/dev 型命令无完成态——rpc_task 池模式会挂起 result（实战试错 6-7 轮），
 * 需指到 launchctl/systemd 或 nohup+日志轮询，而非通用长驻文案里的 rpc_task 句柄路由。
 */

/** 前台长耗时阈值（ms）：env AMAGI_BASH_LONGRUN_MS 可调，<=0 关闭事后提示。 */
const LONGRUN_DEFAULT_MS = 120_000;
function longrunThresholdMs(): number {
	const raw = process.env.AMAGI_BASH_LONGRUN_MS;
	if (raw === undefined || raw.trim() === "") return LONGRUN_DEFAULT_MS;
	const v = Number(raw);
	return Number.isFinite(v) ? v : LONGRUN_DEFAULT_MS;
}

/** 中止残留排查用的 grep 关键片段：跳过 VAR=env 前缀取前 3 个 token，限长防超长串。 */
function commandGrepFragment(command: string): string {
	const tokens = command.trim().replace(/\s+/g, " ").split(" ").filter((t) => t && !/^[A-Za-z_][A-Za-z0-9_]*=/.test(t));
	const frag = tokens.slice(0, 3).join(" ");
	return (frag || command.trim()).slice(0, 48);
}

export interface BashAdvisoryOpts {
	timedOut?: boolean;
	aborted?: boolean;
	elapsedMs?: number;
	hasTimeoutParam?: boolean;
}

/**
 * ev-20260904-6a5d2e：rg `-r` 替换标志与搜索意图冲突 lint（纯函数，供测试直接断言）。
 * 实战同型复发 2/2：`rg -rln "x" path` 中 -r 是 --replace，整簇被解析为「替换文本=ln」，
 * 命令 exit 0、输出被静默改写，比报错更难发现；grep 习惯（-r 递归 + -n 行号）迁移到 rg 时高发。
 * 判定：rg 的参数 token 形如 `-r<字母+>`（粘连簇，如 -rln/-rn/-rl）；拆写 `-r ln`（显式替换）与
 * `--replace=<文本>` 长式不误伤；grep 自身的 -rln 语义合法，不 lint。
 * ev-20260920-f736d8：返回值从文案改为命中信息（供 criticalBashAdvisory 组装前置警示）。
 */
// 仅恢复无参短旗标簇（-rn/-rln 等）。-rfoo/-rVALUE 是合法的粘连替换文本，不得被自动改成选项。
// 有意使用 n/ln 等同形替换文本时写成 -r n 或 --replace=n，显式替换语义始终优先。
const RG_REPLACE_CLUSTER_RE = /^-r[nliwcsSHhUuvoqLP]+$/;
/** rg 带值选项（短式字母 / 长式全名）：其后紧邻 token 是选项值（如 `rg -e -rn` 的 -rn 是搜索模式），
 *  不得当粘连簇处理——自动改写会改变搜索内容。长式 `--x=v` 自带值不跳。 */
const RG_SHORT_VALUE_FLAGS = new Set(["A", "B", "C", "d", "E", "e", "f", "g", "j", "m", "M", "r", "t", "T"]);
const RG_LONG_VALUE_FLAGS = new Set([
	"--after-context", "--before-context", "--context", "--color", "--colors", "--context-separator", "--dfa-size-limit",
	"--encoding", "--engine", "--field-context-separator", "--field-match-separator", "--file", "--generate", "--glob",
	"--hostname-bin", "--hyperlink-format", "--iglob", "--ignore-file", "--max-columns", "--max-count", "--max-depth",
	"--max-filesize", "--path-separator", "--pre", "--pre-glob", "--regex-size-limit", "--regexp", "--replace", "--sort",
	"--sortr", "--threads", "--type", "--type-add", "--type-clear", "--type-not",
]);

/** rg 参数表（不含可执行名）中 `-r<字母+>` 粘连簇的下标：`--` 之后为字面量不判（diting F-09），
 *  带值选项的值不判；簇按「去掉 -r 后」语义继续消费后续值（与改写后真实解析一致）。 */
function rgReplaceClusterIndices(args: readonly string[]): number[] {
	const hits: number[] = [];
	for (let i = 0; i < args.length; i++) {
		const token = args[i]!;
		if (token === "--") break;
		// 明确请求替换时整段保留（不检查选项值及 -- 后字面量）。
		if ((token.startsWith("-r") && !RG_REPLACE_CLUSTER_RE.test(token)) || token === "--replace" || token.startsWith("--replace=")) return [];
		if (token.startsWith("--")) {
			if (!token.includes("=") && RG_LONG_VALUE_FLAGS.has(token)) i++;
			continue;
		}
		if (!/^-[A-Za-z]/.test(token)) continue;
		let letters = token.slice(1);
		if (RG_REPLACE_CLUSTER_RE.test(token)) { hits.push(i); letters = letters.slice(1); }
		// 短簇解析：首个带值字母吃掉簇内余下字符；若它是末字符则吃下一个 token。
		for (let k = 0; k < letters.length; k++) {
			if (!RG_SHORT_VALUE_FLAGS.has(letters[k]!)) continue;
			if (k === letters.length - 1) i++;
			break;
		}
	}
	return hits;
}

/** 只保留确认属于 argv 的 span；重定向操作符及目标不是 rg 参数。粘连到普通词的重定向等复杂
 *  形态无法用现有 tokenizer 无损拆分时放弃该段改写（不修改文件目标，不另造通用 shell parser）。 */
function rgArgvSpans(segment: ShellTokenSpan[], command: string): ShellTokenSpan[] | null {
	const argv: ShellTokenSpan[] = [];
	let target = false;
	for (const span of segment) {
		if (target) { target = false; continue; }
		const raw = command.slice(span.start, span.end).replace(/\\\r?\n/g, "");
		let quote: string | null = null;
		let redirect = -1;
		for (let i = 0; i < raw.length; i++) {
			const ch = raw[i]!;
			if (ch === "\\" && quote !== "'") { i++; continue; }
			if (quote) { if (ch === quote) quote = null; continue; }
			if (ch === "'" || ch === '"') { quote = ch; continue; }
			if (ch === "<" || ch === ">") { redirect = i; break; }
		}
		if (redirect < 0) { argv.push(span); continue; }
		const op = /^(?:&>>?|\d*(?:>>|<<-?|<>|>&|<&|>\||>|<))/.exec(raw);
		if (!op || !/^(?:\d+|&)?$/.test(raw.slice(0, redirect))) return null;
		const tail = raw.slice(op[0].length);
		// 多重粘连操作符/进程替换不确认；引号内含 < > 的目标同样保守回落。
		if (/[<>]/.test(tail) || tail.startsWith("(")) return null;
		target = tail.length === 0;
	}
	return target ? null : argv;
}

export function rgReplaceFlagHint(command: string): { cluster: string } | null {
	for (const segment of segmentShellSpans(tokenizeShellSpans(command))) {
		const argv = rgArgvSpans(segment, command);
		if (!argv) continue;
		const words = executableWords(argv.map((span) => span.text), true);
		const executable = words.length ? words[0].toLowerCase().replace(/^.*[\\/]/, "") : "";
		if (executable !== "rg") continue;
		// diting F-09：`--` 之后的 token 是模式/文件字面量非选项——`rg -- -rn file` 的 -rn 是搜索
		// 模式不是旗标，不得拦截（本函数供硬阻断与警示共用，修复两面同步生效）。
		const args = words.slice(1);
		const idx = rgReplaceClusterIndices(args);
		if (idx.length > 0) return { cluster: args[idx[0]!]! };
	}
	return null;
}

/**
 * rg -r 粘连簇自动改写（bash.rgReplace 默认 disclose 执法）：把每个 rg 段里的 `-r<字母+>` 改写为
 * `-<字母+>`（去掉 -r，保留其余标志；rg 默认递归，-r 在 rg 中是 --replace），按词法 span 原位替换，
 * 引号内模式与其它文本不动。显式 `-r <文本>` / `--replace` 不命中。含 heredoc（`<<`）的命令不改写
 * （正文行会被词法误切为命令段，改写会篡改写入内容）——返回 null，由调用方走前置警示兜底。
 */
export function rgReplaceClusterRewrite(command: string): { command: string; clusters: string[] } | null {
	if (command.includes("<<")) return null;
	let segments: ShellTokenSpan[][];
	try { segments = segmentShellSpans(tokenizeShellSpans(command)); } catch { /* lint-exempt:词法异常不改写（零故障放大） */ return null; }
	const replacements: Array<{ start: number; end: number; text: string; cluster: string }> = [];
	const flush = (segment: ShellTokenSpan[]): void => {
		if (segment.length === 0) return;
		const argv = rgArgvSpans(segment, command);
		if (!argv) return;
		const texts = argv.map((t) => t.text);
		const exe = executableWords(texts, true);
		if (!exe.length || exe[0]!.toLowerCase().replace(/^.*[\\/]/, "") !== "rg") return;
		const base = texts.length - exe.length + 1; // executableWords 返回后缀：args 在 segment 中的起点
		for (const i of rgReplaceClusterIndices(exe.slice(1))) {
			const span = argv[base + i]!;
			replacements.push({ start: span.start, end: span.end, text: `-${span.text.slice(2)}`, cluster: span.text });
		}
	};
	for (const segment of segments) flush(segment);
	if (replacements.length === 0) return null;
	let out = command;
	for (const r of [...replacements].sort((a, b) => b.start - a.start)) out = out.slice(0, r.start) + r.text + out.slice(r.end);
	return { command: out, clusters: replacements.map((r) => r.cluster) };
}

/** 自动改写结果首部说明（一行）：短命令给完整前后对照，长命令只给簇映射。 */
export function rgRewriteNote(original: string, rewrite: { command: string; clusters: string[] }): string {
	const oneLine = (text: string): string => text.replace(/\r/g, "\\r").replace(/\n/g, "\\n");
	const what = original.length <= 160
		? `\`${oneLine(original)}\` 改写为 \`${oneLine(rewrite.command)}\``
		: rewrite.clusters.map((c) => `\`${c}\` 改写为 \`-${c.slice(2)}\``).join("、");
	return `[amagi·rg 参数自动改写] 已将 ${what} 执行（rg 的 -r 是 --replace，粘连会静默替换输出；rg 默认递归）。`;
}

/**
 * ev-20260920-f736d8：rg -r 粘连簇 → 输出污染级警示（前置到结果首部；附修正命令；不阻断不去重）。
 * 分级依据：耗时/常驻是建议级（尾部即可）；本类是污染级——输出已被静默改写且 exit 0，
 * 尾部提示在长输出下被忽略（实战 100% 复发），必须先于内容被读到。
 * ev-20260926-19d1bb：接入会话计次升级（复用 guard-notes RepeatNoteTracker）——第 2 次起头部
 * 标注「本会话第 N 次出现」，第 3 次起追加升级段（固化建议：拆写参数/alias，打断 grep→rg
 * 迁移的肌肉记忆型复发；实战同型警示单会话 10 次全部逐次挽救但复发率未降）。
 */
export function criticalBashAdvisory(command: string): string | null {
	const hit = rgReplaceFlagHint(command);
	if (!hit) return null;
	const corrected = `-${hit.cluster.slice(2)}`;
	const fixedCmd = command.replace(hit.cluster, corrected);
	const base = [
		`⚠️ [amagi·输出污染警示] rg 参数误用：\`-r\` 是 --replace 替换标志——\`${hit.cluster}\` 被解析为「替换文本=${hit.cluster.slice(2)}」，下方输出已被静默改写（匹配处被替换成该文本），不可直接采信。`,
		`修正（搜索意图请重跑）：\`${fixedCmd}\`；确需替换请写 \`--replace=<文本>\`。本提示不阻断，原输出保留供比对。`,
	].join("\n");
	return withEscalatedNote(base, advisoryRepeat.note("rg-replace-cluster"),
		"同型失误已复发——请本轮就固化习惯：搜索场景显式拆写 `-n`（行号）/`-l`（文件名），或先 `alias rgn='rg -n'` 再用 rgn；今后见到 `-r` 一律先当 --replace 核对。");
}

/** ev-20261005-7b6d68：验证型命令+吞码管道的结果尾部提示。根因（reflect 复盘 §2.3）：管道
 *  退出码守卫前置提示每会话仅一次且在执行前——误读发生在读结果时，长会话后段同型误读 2-3 次
 *  （npm test|tail 使全量报 exit=0 实有 4 fail；tsc|head 产生假 TS_OK）。
 *  diting M1 修正：sink 判定改「**管道末段**」（shellPipelineChains 按 &&/||/;/换行断链后每链
 *  以 | 结尾的末段）而非命令末段——`npx tsc | head -5 && echo TS_OK`（条目点名的假 TS_OK 形态）
 *  此前漏报；验证型命令与 sink 须同链（`echo x | grep && npm test` 的 npm test 未被吞码，不误报）。
 *  diting m1：豁免与前置提示同口径（文本出现 pipefail/PIPESTATUS 即豁免——`set -euo pipefail`
 *  组合短格式已防护不提示；宁可漏报不误报）。
 *  ev-20261012-4b470d（降频接线，见 pipeExitTailNote；ev-20261031-a25f7a 阈值 3→2）：首次全文
 *  （贴误读发生点），同会话第 2 次起折叠为一行修正建议——与预执行守卫提示（guards pipe-exit-code）同频衰减，
 *  消除「预执行行声明已折叠但结果尾仍全文」的两路分叉残留。 */
const PIPE_EXIT_SINK_EXES = new Set(["tail", "head", "grep", "egrep", "fgrep", "wc", "cat", "more", "less", "cut", "tr", "tee"]);
// ev-20261012-61aee4（B6）：『验证型』判定按各管道段解析后的可执行词（首词+子命令）——原
// VERIFY_CMD_RE 对整链原始文本匹配，引号内搜索词/文件名（npm test、tsc、vitest、jest…）一并
// 命中（evolve-2.19.2 实战：`grep -n "…npm test" 任务书 | cut` 误报）。检索类命令（grep/rg/
// ag/cat/sed/awk/find/ls…）只看首词即非验证，参数文本不再参与判定；bash -c/xargs/env 包裹经
// lexer 既有展开（executableWords 剥裹 / -c payload 递归）后再判。集合等价迁移原正则：
// npm(run )?test* / npm run typecheck|build / npx tsc|vitest|jest|eslint|mocha|playwright /
// tsc / node --test / vitest / jest / eslint / depcruise。
const VERIFY_DIRECT_PROGRAMS = new Set(["tsc", "vitest", "jest", "eslint", "depcruise"]);
const VERIFY_NPX_PROGRAMS = new Set(["tsc", "vitest", "jest", "eslint", "mocha", "playwright"]);
const VERIFY_NPM_SCRIPTS = new Set(["typecheck", "build"]); // npm run test*（含 test:ci）由 test 前缀覆盖

/** 段内 sh/bash/zsh -c 的 payload（无 -c 或无 payload → undefined；-- 后取首词）。 */
function wrapperPayloadOf(seg: string[]): string | undefined {
	const exeWords = executableWords(seg, true);
	if (!exeWords.length) return undefined;
	const exe = exeWords[0]!.toLowerCase().replace(/^.*[\\/]/, "");
	if (exe !== "bash" && exe !== "sh" && exe !== "zsh") return undefined;
	const args = exeWords.slice(1);
	const cIndex = args.findIndex((w) => /^-[A-Za-z]*c[A-Za-z]*$/.test(w));
	let payloadIndex = cIndex + 1;
	if (args[payloadIndex] === "--") payloadIndex++;
	return cIndex >= 0 ? args[payloadIndex] : undefined;
}

/** 单管道段是否验证型命令：只看 executableWords 解析后的首词+子命令；hop 防 -c payload 病态嵌套。 */
function segmentIsVerificationCommand(seg: string[], hop: number): boolean {
	if (!seg.length || hop > 3) return false;
	const exeWords = executableWords(seg, true); // 剥 env/sudo/timeout/xargs 包裹（lexer 既有展开）
	if (!exeWords.length) return false;
	const exe = exeWords[0]!.toLowerCase().replace(/^.*[\\/]/, "");
	const args = exeWords.slice(1);
	if (exe === "bash" || exe === "sh" || exe === "zsh") {
		// bash -c "npm test | tail"：payload 是引号内单 token（引号内管道不切分）——payload 内任一
		// 管道段是验证命令即命中（与 shellWrapperPayloads 同口径的 -c 提取）。
		const payload = wrapperPayloadOf(seg);
		if (payload === undefined) return false;
		try {
			return shellPipelineChains(payload).some((chain) => chain.some((s) => segmentIsVerificationCommand(s, hop + 1)));
		} catch { /* lint-exempt:payload 词法异常不判定（零故障放大） */ return false; }
	}
	if (VERIFY_DIRECT_PROGRAMS.has(exe)) return true;
	if (exe === "node") return args[0] === "--test";
	if (exe === "npm") {
		const sub = args[0] === "run" ? args[1] : args[0];
		if (!sub) return false;
		return sub.startsWith("test") || VERIFY_NPM_SCRIPTS.has(sub);
	}
	if (exe === "npx" || exe === "dlx" || exe === "bunx") return VERIFY_NPX_PROGRAMS.has((args[0] ?? "").toLowerCase());
	return false;
}

/** 验证型命令＋吞码 sink 同链命中 → 返回 sink 可执行名（无则 null）；hop 防 -c payload 病态嵌套。 */
function pipelineVerifySinkName(command: string, hop: number): string | null {
	if (hop > 3) return null;
	let chains: string[][][];
	try { chains = shellPipelineChains(command); } catch { /* lint-exempt:词法异常不提示（零故障放大） */ return null; }
	for (const chain of chains) {
		if (chain.length < 2) {
			// bash -c "npm test 2>&1 | tail -25"：外层引号内管道不切分（整条只成一段）——payload 整链递归
			if (chain.length !== 1) continue;
			const payload = wrapperPayloadOf(chain[0]!);
			if (payload === undefined) continue;
			const hit = pipelineVerifySinkName(payload, hop + 1);
			if (hit) return hit;
			continue;
		}
		const lastSeg = chain[chain.length - 1]!;
		const words = executableWords(lastSeg, true);
		const sink = words.find((w) => PIPE_EXIT_SINK_EXES.has(w.toLowerCase().replace(/^.*[\\/]/, "")));
		if (!sink) continue;
		const verify = chain.slice(0, -1).some((seg) => segmentIsVerificationCommand(seg, hop)); // 验证命令与 sink 须同链（不误报前置管道消费形态）
		if (!verify) continue;
		return sink.toLowerCase().replace(/^.*[\\/]/, "");
	}
	return null;
}

export function pipeExitVerificationNote(command: string): string | null {
	if (/pipefail|PIPESTATUS/i.test(command)) return null; // m1：与前置提示同口径（文本出现即豁免，含 set -euo pipefail 组合短格式）
	const sinkName = pipelineVerifySinkName(command, 0);
	if (!sinkName) return null;
	return `[amagi 软提示·管道退出码·结果尾] 本管道退出码=末段 ${sinkName} 的退出码——左侧验证命令真实失败不会传播（本结果若显示成功，请勿直接采信；&&/|| 后续回显不反映左侧退出码）；左侧真实退出码：前置 set -o pipefail，或改 \${PIPESTATUS[0]}（bash 数组，紧随管道后取），或输出落盘后判 EXIT=$?。本提示首次全文；同会话第 2 次起折叠为一行修正建议。`;
}
/** ev-20261012-4b470d：结果尾管道提示接入会话计次降频（可纠正型；ev-20261031-a25f7a 阈值 3→2）
 *  ——首次全文（贴误读发生点：误读主要发生在「看起来成功」的结果），同会话第 2 次起升级接管
 *  （一行计数+修正建议，不再重复全文；首次全文见会话历史）。根因：预执行守卫提示（guards
 *  pipe-exit-code）已走 f9f167 降频，结果尾路径仍每次全文——同型提示「预执行行已折叠但结果尾
 *  仍全文」两路分叉，单会话 9 次全文重复（实战复盘 §2.2）。两分支（baseCwd/显式 cwd）共用同一计次键。 */
const PIPE_TAIL_ESCALATION = "管道退出码陷阱已多次命中——本轮命令开头加 `set -o pipefail` 再跑，或改判 `${PIPESTATUS[0]}`（bash 数组，紧随管道后取）；首次全文见会话历史。";
function pipeExitTailNote(command: string): string | null {
	const raw = pipeExitVerificationNote(command);
	if (!raw) return null;
	return withCompactEscalatedNote(raw, advisoryRepeat.note("pipe-exit-verify-tail"), PIPE_TAIL_ESCALATION);
}

/** ev-20261005-8036ce：rg -r 粘连簇硬阻断的 env 归一（AMAGI_RG_REPLACE_BLOCK=0/off → false，
 *  其余明确值 → true）。B4·批B（D10）起生产调用点改经 guard-policy 投影消费（默认 disclose）；
 *  本函数保留为 env 语义单源（guard-policy.test.mjs 镜像断言：投影归一 ≡ 本函数）。 */
export function rgReplaceBlockEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const raw = env.AMAGI_RG_REPLACE_BLOCK;
	return !(raw === "0" || raw?.toLowerCase() === "off");
}

/** ev-20261005-8036ce（friction/P3）：rg -r 粘连簇执行前拒绝文案（纯函数）。
 *  根因：警示三级升级（尾部软提示→前置污染级→计次升级）实测未能根治同型失误——
 *  3 次复发且第二次发生率 100%，输出已污染的事实无法撤销；「确认后才执行」在无交互面
 *  的等价形态 = 拒绝执行 + 给可直接复用的修正命令（模型重发修正版即继续）。误伤面：
 *  `-r<字母>` 粘连簇几乎必然是 grep -rn 迁移误用（确需替换写 `--replace=` 或拆写 -r 文本）。
 *  B4A（ev-20261012-af58eb 批A）：文案携 guard-rule 标签 bash.rgReplace（信号层）；
 *  env 逃生舱注明为操作者面（不给模型自助绕门指引），策略投影见 /amagi config explain。 */
export function rgReplaceHardBlockNote(command: string): string | null {
	const hit = rgReplaceFlagHint(command);
	if (!hit) return null;
	const corrected = `-${hit.cluster.slice(2)}`;
	const fixedCmd = command.replace(hit.cluster, corrected);
	return `[amagi 守卫·bash.rgReplace·rg 参数误用阻断] \`-r\` 是 --replace 替换标志——\`${hit.cluster}\` 被解析为「替换文本=${hit.cluster.slice(2)}」，输出会被静默改写且 exit 0，所以命令未执行。搜索意图请重跑：\`${fixedCmd}\`；确需替换请写 \`--replace=<文本>\` 或拆写 \`-r <文本>\`。（操作者逃生舱 AMAGI_RG_REPLACE_BLOCK=0 回退前置警示；策略投影与来源见 /amagi config explain）`;
}

// ── ev-20261002-de1845（friction/P3）：GNU-only 旗标/地址执行前预警 ──
// 实战：macOS 默认 BSD 工具链下 cat -A illegal option（环境清单未覆盖）×1、sed N,+p（AGENTS
// 环境段已明示仍踩——静态文本提示强度不足）×1。静态注记与失败后诊断均无法在「命令构造点」拦截
// 注意力：本预警在 bash 执行时点、绑定本条命令文本前置到结果首部（先于输出被读到）；命中检测
// 与事后改写诊断同源（guards gnuOnlyBsdPatternHit），平台归因同源（shellPlatformOf：bash 运行时
// uname，探测失败回退宿主 platform——与 DARWIN_BSD_NOTE 注记同语义）。仅 darwin 预警（Linux 无此
// 陷阱；若 PATH 已装 GNU 工具命令可能成功，预警文本如实说明「不可移植」而非断言必败）。回滚：
// AMAGI_BSD_PREWARN=0/false/off。
export function bsdPrewarnEnabled(env: string | undefined = process.env.AMAGI_BSD_PREWARN): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** 纯函数（供测试直接断言）：命令含 GNU-only 旗标/地址 且 bash 侧为 darwin → 前置预警行；否则 null。
 *  info 可注入；探测信息缺省时回退宿主 platform（与平台注记同回退语义）。 */
export function bsdPortabilityPreflightNote(
	command: string,
	opts: { hostPlatform?: string; bashRuntime?: () => BashRuntimeInfo | undefined } = {},
): string | null {
	if (!bsdPrewarnEnabled()) return null;
	const hit = gnuOnlyBsdPatternHit(command);
	if (!hit) return null;
	let info: BashRuntimeInfo | undefined;
	try { info = (opts.bashRuntime ?? (() => undefined))(); } catch { info = undefined; /* lint-exempt:探测异常降级为未知——回退宿主平台判定，预警层零故障放大 */ }
	const platform = shellPlatformOf(info) ?? opts.hostPlatform ?? process.platform;
	if (platform !== "darwin") return null;
	const base = hit.kind === "cat-A"
		? `[amagi 预警·GNU-only 旗标] 检测到 BSD cat 不支持的 \`-A\`（macOS 默认工具链）——cat -A 在 BSD cat 是 illegal option（GNU -A = -vET）。替代：\`cat -et\`（-e 行尾 $、-t tab ^I，均隐含 -v）或 \`od -c\`（逐字节）。若 PATH 已装 GNU coreutils 本命令可能成功，但形态跨环境不可移植。本提示不阻断。`
		: `[amagi 预警·GNU-only 地址] 检测到 sed 相对行号地址 \`N,+M\`（GNU 扩展——macOS BSD sed 支持视版本，不可移植）。替代：明确起止行号 \`sed -n 'N,(N+M)p'\` 或改用 read 工具（offset/limit）。本提示不阻断。`;
	return withCompactEscalatedNote(base, advisoryRepeat.note("bsd-gnu-only"),
		"同型 GNU-only 形态已复发——请本轮就改写为可移植形态（cat -et / 明确起止行号），不要再沿用待替换的 GNU-only 写法。");
}

/**
 * ev-386692/ev-99a6cd（S3）：一次性构建/测试/检查类命令词表——长耗时属正常，不因耗时收到
 * 常驻警告，只给中性「显式设置预算」提示。判定口径：每个 pipeline 段（剥 env/sudo/timeout 等
 * 包裹器后）逐段判；任一段不是一次性命令则整体不豁免（npm test 脚本内容未知，不宣称必为一次性）。
 * watch 旗标（--watch/-w）优先路由到 watch 型常驻提示（识别顺序：常驻标志 > 一次性识别 > 事后耗时）。
 */
const ONE_SHOT_PROGRAMS = new Set(["tsc", "eslint"]);
const ONE_SHOT_PROGRAM_ARG: Record<string, string> = { vitest: "run", playwright: "test" };
const ONE_SHOT_RUNNER_SCRIPTS = new Set(["build", "lint", "typecheck", "type-check", "check-types", "compile"]);
const ONE_SHOT_RUNNER_EXES = new Set(["npm", "pnpm", "yarn", "bun"]);

function isWatchFlagToken(token: string): boolean {
	return token === "-w" || token === "--watch" || token === "--watchall" || token.startsWith("--watch");
}

/** 段级递归判定（包管理器 exec/run 与 npx/dlx/bunx 包裹不超过 3 跳，防病态嵌套）。 */
function isOneShotSegment(words: string[], hop = 0): boolean {
	if (!words.length || hop > 3) return false;
	const exe = words[0].toLowerCase().replace(/^.*[\\/]/, "");
	const args = words.slice(1);
	if (args.some((a) => isWatchFlagToken(a.toLowerCase()))) return false;
	if (ONE_SHOT_PROGRAMS.has(exe)) return true;
	const sub = ONE_SHOT_PROGRAM_ARG[exe];
	if (sub && args.some((a) => a.toLowerCase() === sub)) return true;
	if (ONE_SHOT_RUNNER_EXES.has(exe)) {
		const lowered = args.map((a) => a.toLowerCase());
		const rest = lowered[0] === "run" || lowered[0] === "exec" ? lowered.slice(1) : lowered;
		if (rest.length && ONE_SHOT_RUNNER_SCRIPTS.has(rest[0])) return true;
		return isOneShotSegment(rest, hop + 1); // pnpm exec vitest run → 递归以 vitest run 判定
	}
	if (exe === "npx" || exe === "dlx" || exe === "bunx") return isOneShotSegment(args, hop + 1);
	return false;
}

/** 纯函数：命令是否为一次性构建/测试/检查命令（全部 pipeline 段均为一次性才豁免）。 */
export function isOneShotBuildCommand(command: string): boolean {
	const segments = shellSegments(command);
	if (!segments.length) return false;
	for (const segment of segments) {
		if (!isOneShotSegment(executableWords(segment, true))) return false;
	}
	return true;
}

/** ev-386692：常驻提示会话去重键（watch/longrun 两类，各首报一次；超时/取消/残留提示不去重）。
 *  模块级状态≈进程级会话（子代理每任务独立进程；Leader 主进程由 index.ts session_start/
 *  session_shutdown 接线复位——ev-20261031-a25f7a 前的「跨会话共享」缺口已闭合）。 */
const advisoryDedup = new Set<string>();
/** ev-20260926-19d1bb：可纠正型软提示会话计次（ruleId→次数；首次全文、第 2 次起折叠，见 guard-notes）。
 *  与 advisoryDedup 同生命周期，由 resetBashAdvisoryDedup 一并复位（session 生命周期 + 测试隔离）。 */
const advisoryRepeat = new RepeatNoteTracker();
// ev-20261031-a25f7a（P3，复盘 §2.6）：ABI 提醒「条件实例」身份——cwd → 当前 marker at。
// marker 消失（restore/过期/禁用）或被新 flip 覆盖（at 变化）→ 该 cwd 计数清零，重新首次全文。
const abiRepeatMarkerAt = new Map<string, string>();
/** ABI 提醒计次键：cwd 短哈希后缀区分目录（A 目录去重不吞 B 目录风险；键遵守 guard-notes
 *  短标识纪律，不含路径正文）。 */
function abiRepeatKey(execCwd: string): string {
	return `abi-flip-reminder:${createHash("sha256").update(execCwd).digest("hex").slice(0, 8)}`;
}
/** ABI 折叠行修正建议（保留风险关键词与可执行出口——折叠不丢风险信息）。 */
const ABI_TAIL_ESCALATION = "该目录仍在 Electron ABI flip 窗口内（marker 未失效）——若测试报 NODE_MODULE_VERSION 不匹配，先 `npm rebuild <原生模块>` 再跑测试；恢复命令成功或超时后本提示自动消失。";
/** ev-20261031-a25f7a：ABI 提醒（条件型）接会话计次降频——首次全文、第 2 次起一行折叠（与管道
 *  退出码等可纠正型族同款接线；此前该提示绕过计数器裸拼接，marker 存续期内每次测试型命令成功
 *  都全文重发）。条件失效语义：计数生命周期由 **marker 有效身份**（abiFlipMarkerAt）决定，与
 *  显示判定（测试命令正则）分离——普通命令（ls/pwd 等非测试）成功不清计数，真实会话夹杂读
 *  文件/杂项命令后计次仍持续；marker 消失（restore/过期/禁用）或被新 flip 覆盖（at 变化）→
 *  计数重置，后续重新首次全文。marker 生命周期仍只有 restore 命令与 TTL 两条路径（测试命令
 *  成功不清 marker——测试是否真的加载原生模块不可知，不虚称恢复）。 */
function abiReminderCompactNote(command: string, execCwd: string): string | null {
	const key = abiRepeatKey(execCwd);
	const markerAt = abiFlipMarkerAt(execCwd); // 条件实例身份：null=无/过期/禁用
	if (markerAt === null) {
		if (abiRepeatMarkerAt.has(execCwd)) {
			abiRepeatMarkerAt.delete(execCwd);
			advisoryRepeat.resetRule(key); // 条件已失效（restore/过期/禁用）：计数随实例消亡
		}
		return null;
	}
	if (abiRepeatMarkerAt.get(execCwd) !== String(markerAt)) {
		if (abiRepeatMarkerAt.has(execCwd)) advisoryRepeat.resetRule(key); // 新条件实例：重新首次全文
		abiRepeatMarkerAt.set(execCwd, String(markerAt));
	}
	const note = abiReminderNote(command, execCwd); // 显示判定：测试命令 + marker 有效（宽口径）
	if (!note) return null;
	return withCompactEscalatedNote(note, advisoryRepeat.note(key), ABI_TAIL_ESCALATION);
}
export function resetBashAdvisoryDedup(): void {
	advisoryDedup.clear();
	advisoryRepeat.reset();
	abiRepeatMarkerAt.clear();
	gitRootCache.clear();

}

// ── ev-20260926-98de68（friction/P1）：python heredoc 多段串联替换的原子性软提示 ──
// 实战：python3 heredoc 内多段 s.replace + assert old in s + 终末统一写盘——任一 assert 中途
// 崩溃则整段零写入，但崩溃输出与「前段已生效」不可区分；调用方按错误状态构造下一段 oldText
// 连环失配（8 次 AssertionError、约 5 次返工）。结构性根因是中间态信息断层：脚本原子性与
// 调用方的状态假设无同步机制。软提示（不阻断）：建议改为「先全量校验后统一写盘」结构。
// 检测面（宁可漏报不误报）：python3? heredoc（<<）且 ≥2 处 .replace( + assert + 写盘动作
//（open("w"/"a"、write_text、.write(）；python -c 单行与无写盘的只读脚本不命中。
// 回滚：AMAGI_PY_HEREDOC_HINT=0/false/off。
const PY_HEREDOC_RE = /(^|[;&|)\s])python3?(\s+-\S*)*\s*<<-?\s*['"]?[A-Za-z_][A-Za-z0-9_]*['"]?/;
// diting 审核 M3：open() 实参含嵌套括号（open(path.join(a,b),"w")）时 [^)] 不能跨括号——写盘
// 计数低报会把多段写盘误判「唯一写盘」合规而抑制提示；放宽到一层嵌套（两层以上形态罕见，宁漏勿噪）。
const PY_WRITE_RE = /open\((?:[^()]|\([^()]*\))*['"][wa]['"]|write_text\s*\(|\.write\s*\(/;

/** ev-20260929-ddf3c9（friction/P1）：合规结构识别——「全部 assert 前置于首个 .replace( 且唯一写盘」
 *  ＝已按建议整改（先全量校验后统一写盘），不再提示。实战：提示器 15 次触发约 10 次为合规结构
 *  噪音（assert 全部集中于唯一 write_text 之前、断言失败均零写入可证），持续提示产生注意力税。
 *  真风险保持提示：多段写盘（>1 处写盘动作）与 assert/replace 交错（校验后置）。
 *  纯函数，供测试直接断言。 */
export function pythonHeredocStructureCompliant(command: string): boolean {
	const writes = command.match(new RegExp(PY_WRITE_RE.source, "g")) ?? [];
	if (writes.length !== 1) return false; // 无写盘不进本提示面；多段写盘＝真风险
	const firstReplace = command.search(/\.replace\(/);
	if (firstReplace < 0) return false;
	const assertRe = /\bassert\b/g;
	let any = false;
	for (let m = assertRe.exec(command); m; m = assertRe.exec(command)) {
		any = true;
		if ((m.index ?? 0) >= firstReplace) return false; // 校验后置＝原风险形态
	}
	return any;
}

export function pythonHeredocReplaceHintEnabled(env: string | undefined = process.env.AMAGI_PY_HEREDOC_HINT): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

// ── ev-20261012-01ffd5（B6②）：assert 判定改在 heredoc 的 Python 可执行语句域 ──
// 病根：旧判定 /\bassert\b/ 对整条命令文本匹配——被替换 JavaScript 字符串内的 assert.equal(...)
// 被当 Python 断言（evolve-2.19.1 diting 57b9eb08 L56 实战：body 仅 read/多次 replace/write，
// 1 次噪音提示）。修复：只对 heredoc body 剥离字符串字面量（含三引号）与 # 注释后的语句域判
// assert——Python 语法不必全解析，剥离器以成对测试证明边界；未闭合引号 fail-closed 按原文判
// （保守保留提示）。heredoc 之后的其它语言程序（如 EOF 后的 node 验证）不进 body，天然分离。

/** Python 字符串/注释剥离器：返回可执行语句域文本（字符串以空格占位保词边界）；
 *  未闭合引号（含单行字符串遇换行）→ null（fail-closed：无法证明是字符串即当可执行）。 */
export function stripPythonStringsAndComments(body: string): string | null {
	let out = "";
	let i = 0;
	const n = body.length;
	while (i < n) {
		const ch = body[i];
		if (ch === "#") { while (i < n && body[i] !== "\n") i++; continue; } // 注释剥到行尾（换行留给主循环）
		if (ch === "'" || ch === '"') {
			const triple = body.slice(i, i + 3);
			if (triple === "'''" || triple === '"""') {
				const close = body.indexOf(triple, i + 3);
				if (close < 0) return null; // 三引号未闭合 → fail-closed
				out += " ";
				i = close + 3;
				continue;
			}
			let j = i + 1;
			let closed = false;
			while (j < n) {
				if (body[j] === "\\") { j += 2; continue; } // 转义（含 \' 与 \\）
				if (body[j] === ch) { closed = true; break; }
				if (body[j] === "\n") break; // 单行字符串不跨行（未闭合换行=语法错，保守 fail-closed）
				j++;
			}
			if (!closed) return null;
			out += " ";
			i = j + 1;
			continue;
		}
		out += ch;
		i++;
	}
	return out;
}

/** 提取 python heredoc 的 body 文本（引入行的定界词 → 闭合行；EOF 未闭合则余文全部为 body）。
 *  闭合口径与 splitHeredocs 同源：精确闭合（<<- 剥前导 tab 后整行==定界词）或容忍闭合（首词==定界词）。 */
export function pythonHeredocBodyText(command: string): string {
	const m = PY_HEREDOC_RE.exec(command);
	if (!m) return "";
	const intro = m[0];
	const idents = intro.match(/[A-Za-z_][A-Za-z0-9_]*/g) ?? [];
	const delim = idents[idents.length - 1] ?? "";
	const dash = /<<-/.test(intro);
	const rest = command.slice(m.index + intro.length).replace(/^\r?\n/, ""); // 引入行的行尾换行不属于 body
	const lines: string[] = [];
	for (const line of rest.split("\n")) {
		const strippedTab = dash ? line.replace(/^\t+/, "") : line;
		if (delim && (strippedTab === delim || strippedTab.split(/\s/)[0] === delim)) break; // 精确/容忍闭合
		lines.push(line);
	}
	return lines.join("\n");
}

/** heredoc 的 Python 语句域是否含 assert 语句（01ffd5 判定入口；剥离失败 fail-closed 按原 body）。 */
function pythonHeredocBodyHasAssert(command: string): boolean {
	const body = pythonHeredocBodyText(command);
	if (!body) return /\bassert\b/.test(command); // body 定位失败（异常形态）→ 保守按原文
	const stripped = stripPythonStringsAndComments(body);
	return /\bassert\b/.test(stripped ?? body);
}

/** 纯函数：python heredoc 多段 replace＋assert＋写盘形态 → 原子性风险软提示（无则 null）。 */
export function pythonHeredocReplaceHint(command: string): string | null {
	if (!pythonHeredocReplaceHintEnabled()) return null;
	if (!PY_HEREDOC_RE.test(command)) return null;
	if (((command.match(/\.replace\(/g) || []).length) < 2) return null;
	if (!pythonHeredocBodyHasAssert(command)) return null; // 01ffd5：只认 Python 语句域 assert（字符串/注释内不算）
	if (!PY_WRITE_RE.test(command)) return null;
	// ev-20260929-ddf3c9：合规结构（先全量校验后唯一写盘）不再打扰；且计次清零——Agent 已按
	// 建议整改，后续真风险形态从首报计（升级提示不因历史次数立即复现）。
	if (pythonHeredocStructureCompliant(command)) {
		advisoryRepeat.resetRule("py-heredoc-replace");
		return null;
	}
	const base = "[amagi 软提示·heredoc 原子性] 检测到 python heredoc 多段 replace＋assert 串联替换——任一 assert 中途失败将整段零写入，而输出与「前段已生效」不可区分，后续脚本按错误状态构造 oldText 会连环失配。建议：把全部存在性校验（assert old in s）集中到写盘之前、替换与写盘一步完成；或分段执行（读→替换→写→验证各一段）。本提示不阻断。";
	// ev-20261002-f9f167：可纠正型降频（ev-20261031-a25f7a 阈值 3→2）——第 2 次起升级接管（不再重复全文）
	return withCompactEscalatedNote(base, advisoryRepeat.note("py-heredoc-replace"),
		"串联替换提示已多次出现——建议本轮改为「先全量校验、后统一写盘」结构；按旧状态继续追加替换脚本容易再次连环失配。");
}

// ── ev-20260926-849b26（friction/P1）：git root 与 cwd 层级差的常驻信息注入 ──
// 实战（3 个真实事件）：git 仓库根在 cwd 上两级时——(1) `git diff --name-only | xargs prettier`
// 输出带前缀、消费者按 cwd 解析 → 13 文件全部 No files matching；(2) 子包目录跑根脚本
// ERR_PNPM_RECURSIVE_EXEC_FIRST_FAIL；(3) `git stash push -- <路径>` pathspec 带前缀不匹配。
// 结构性根因是信息断层：git porcelain/ls 输出以 git root 为基准，而管道消费者与 pathspec 按
// cwd 解析——层级信息存在于文件系统却从不在 bash 输出/提示通道内。修复分两层：
//  仅在 git 路径输出被消费或 stash pathspec 有层级风险时提示；无关命令不注入层级信息。
//  ev-20261027-5c2504：移除无条件首报，相关性前提对每次提示一致（计数升级收敛）。
// 探测开销：无关命令不探测；相关命令 spawnSync git rev-parse，按 cwd 缓存（含 null 缓存）。
// 回滚：AMAGI_GIT_ROOT_HINT=0/false/off。
const gitRootCache = new Map<string, string | null>();


export function gitRootHintEnabled(env: string | undefined = process.env.AMAGI_GIT_ROOT_HINT): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** git root 探测（带 per-cwd 缓存；git 不可用/非 git 目录 → null，同样缓存防重复探测）。 */
function gitRootOf(execCwd: string): string | null {
	const cached = gitRootCache.get(execCwd);
	if (cached !== undefined) return cached;
	let root: string | null = null;
	try {
		const res = spawnSync("git", ["-C", execCwd, "rev-parse", "--show-toplevel"], { encoding: "utf8", timeout: 5000 });
		if (res.status === 0 && typeof res.stdout === "string" && res.stdout.trim()) root = res.stdout.trim();
	} catch { /* lint-exempt:git 缺失/超时 → 非 git 目录语义，探测失败静默不提示 */ }
	gitRootCache.set(execCwd, root);
	return root;
}

/** 纯函数：git 路径输出被消费模式——porcelain/ls-files/--name-only 接管道、xargs 或命令替换；
 *  或 `git stash push -- <pathspec>`（pathspec 相对 cwd，未跟踪/跨层失配高发）。供测试直接断言。 */
export function gitPathConsumerPattern(command: string): boolean {
	const gitArgs = (segment: string[]): string[] => {
		const words = executableWords(segment, true);
		if (path.basename(words[0] ?? "") !== "git") return [];
		let i = 1;
		while (words[i]?.startsWith("-")) {
			i += ["-C", "-c", "--git-dir", "--work-tree", "--namespace", "--config-env"].includes(words[i]!) ? 2 : 1;
		}
		return words.slice(i);
	};
	const pathOutput = (segment: string[]): boolean => {
		const args = gitArgs(segment);
		return args[0] === "ls-files"
			|| (args[0] === "diff" && args.includes("--name-only"))
			|| (args[0] === "status" && args.some((arg) => /^--porcelain(?:=|$)/.test(arg)));
	};
	if (shellPipelineChains(command).some((chain) => chain.slice(0, -1).some(pathOutput))) return true;
	if (commandSubstitutions(command).some((sub) => shellSegments(sub).some(pathOutput))) return true;
	return shellSegments(command).some((segment) => {
		const args = gitArgs(segment);
		const separator = args.indexOf("--", 2);
		return args[0] === "stash" && args[1] === "push" && separator >= 0 && separator < args.length - 1;
	});
}

/** git root 与 cwd 层级差提示（仅路径消费模式；无层级差/非 git 目录/关闭 → null）。 */
export function gitRootDepthNote(command: string, execCwd: string): string | null {
	if (!gitRootHintEnabled() || !gitPathConsumerPattern(command)) return null;
	const root = gitRootOf(execCwd);
	if (!root) return null;
	const cwdNorm = path.resolve(execCwd);
	const rootNorm = path.resolve(root);
	if (cwdNorm === rootNorm) return null;
	const rel = path.relative(rootNorm, cwdNorm) || ".";
	const depth = rel.split(path.sep).filter(Boolean).length;

	const base = `[amagi 软提示·git 层级] 当前 cwd 在 git root 下 ${depth} 级（root=${root}，cwd=${cwdNorm}）——git diff --name-only / status --porcelain / ls-files 的输出路径以 git root 为基准（带目录前缀），而管道消费者（xargs 等）与 stash pathspec 按 cwd 解析，跨层消费会批量失配（例如全部报 No files matching the pattern）。建议：消费侧先剥前缀（如 | sed "s|^${rel}/||"）、用 git -C ${root} 统一基准，或把整条命令放到 root 执行。本提示不阻断。`;
	// ev-20261002-f9f167：可纠正型降频——实战单会话×4 次全量轰炸，第 2 次起升级接管（a25f7a 阈值 3→2）
	return withCompactEscalatedNote(base, advisoryRepeat.note("git-root-depth"),
		"git root/cwd 层级差已多次相关——本轮先统一基准再执行：`git -C <root> …` 或把消费命令放到 root 目录跑，不要继续拼接带前缀的相对路径。");
}

/** ev-386692：AMAGI_BASH_ADVISORY_POLICY 解析（非法值回安全默认 classified；legacy 恢复旧行为）。 */
export function resolveBashAdvisoryPolicy(env: NodeJS.ProcessEnv = process.env): "classified" | "legacy" {
	return env.AMAGI_BASH_ADVISORY_POLICY === "legacy" ? "legacy" : "classified";
}

/**
 * 纯函数：给定命令与执行上下文，返回一行 [amagi] 软提示（无则 null），供 execute 后处理与测试直接断言。
 * 优先级：中止/超时残留排查 > 【classified】watch/长驻识别（只读搜索短路、未带 timeout；首报后
 * 同会话去重）> 一次性/通用中性预算提示（不称常驻、不凭耗时判常驻）。
 * ev-20260920-f736d8：rg -r 粘连簇 lint 已迁出本通道（建议级→污染级分级）——改由 criticalBashAdvisory
 * 检出并前置到输出首部；本函数不再返回 rg lint（避免同一警示双通道重复）。
 */
export function bashAdvisoryNote(command: string, opts: BashAdvisoryOpts): string | null {
	if (opts.timedOut || opts.aborted) {
		return `[amagi] 前台长命令被中止——可能遗留子进程/端口占用；排查 \`lsof -i -P -sTCP:LISTEN\` / \`ps -ef | grep ${commandGrepFragment(command)}\` 后 pkill；重跑建议后台化。`;
	}
	if (resolveBashAdvisoryPolicy() === "legacy") return legacyBashAdvisoryNote(command, opts);
	// ev-20260904-0678c1：watch/长驻关键词提示对「全程只读搜索」命令短路——命令里的 node_modules
	// 路径、/dev/null 重定向、"watch"/"dev" 搜索词字面量都不是常驻意图（当日三连误报根因）。
	if (!opts.hasTimeoutParam && !isReadonlySearchCommand(command)) {
		if (looksLikeWatchCommand(command)) {
			// ev-20260903-c1521b②：watch 型常驻专属文案（无完成态，rpc_task 池模式会挂起 result）
			if (advisoryDedup.has("watch")) return null; // ev-386692：首报后同会话去重
			advisoryDedup.add("watch");
			return "[amagi] 疑似 watch 型常驻命令——watch/dev 型常驻（tsx watch/pnpm dev/vite dev）不适用 rpc_task 池模式（无完成态会挂起 result）；常驻服务走 launchctl（macOS，注意绝对路径与 PATH 环境）/ systemd（Linux）或 nohup 独立后台 + 日志轮询；无 task 工具的子代理可先向 Leader 报告，由 Leader 安排，避免前台空等";
		}
		if (!isOneShotBuildCommand(command) && LONGRUN_COMMAND_RE.test(command)) {
			// ev-99a6cd 已落地（2026-09-17）：run_bg 后台原语上线，长驻指引改指向它 + 既有 task background / rpc_task
			if (advisoryDedup.has("longrun")) return null; // ev-386692：首报后同会话去重
			advisoryDedup.add("longrun");
			return "[amagi] 疑似长驻命令前台运行——需要完成结果的长 CLI 从开始就后台化：run_bg({ action: \"start\", command: \"...\", timeoutMs }) 返回句柄后用 result 查询（含日志尾部）与 cancel 组级取消；需复用已有 RPC 代理会话时用 rpc_task start；需要完整子 Agent 任务时用 task({ background:true })。已在运行的 bash 无法转入后台，需中止后用 run_bg 重跑";
		}
	}
	// ev-386692：事后耗时提示——已设 timeout 预算的不唠叨；一次性命令不称常驻；未知命令不凭耗时判常驻
	const threshold = longrunThresholdMs();
	const elapsed = opts.elapsedMs ?? 0;
	if (threshold > 0 && elapsed > threshold && !opts.hasTimeoutParam) {
		const secs = Math.round(elapsed / 1000);
		if (isOneShotBuildCommand(command)) {
			return `[amagi] 本次命令前台耗时 ${secs}s（一次性命令，长耗时属正常）——为防无界等待，显式设置预算：bash 带 timeout 参数；长测试可在 task 派发时给 evidenceTimeouts`;
		}
		return `[amagi] 本次命令前台耗时 ${secs}s——耗时较长，未见常驻特征（不凭耗时判常驻）；显式设置预算（bash timeout 参数；长测试可用 task evidenceTimeouts）、拆分，或确需长等待的 CLI 从开始就放入 task({ background:true }) 后台运行`;
	}
	return null;
}

/**
 * ev-386692：legacy 策略（AMAGI_BASH_ADVISORY_POLICY=legacy）——恢复旧行为：无去重、无一次性豁免、
 * 旧文案（含 nohup 优先路由与「后台化」事后提示）。仅回退提示口径，不改变中止/超时与 rg lint 路径。
 */
function legacyBashAdvisoryNote(command: string, opts: BashAdvisoryOpts): string | null {
	if (!opts.hasTimeoutParam && !isReadonlySearchCommand(command)) {
		if (looksLikeWatchCommand(command)) {
			return "[amagi] 疑似 watch 型常驻命令——watch/dev 型常驻（tsx watch/pnpm dev/vite dev）不适用 rpc_task 池模式（无完成态会挂起 result）；常驻服务走 launchctl（macOS，注意绝对路径与 PATH 环境）/ systemd（Linux）或 nohup 独立后台 + 日志轮询";
		}
		if (LONGRUN_COMMAND_RE.test(command)) {
			return "[amagi] 疑似长驻命令前台运行——建议 timeout 参数限时、或改后台 `nohup <cmd> ><log> 2>&1 &` 后轮询日志；需要完成句柄/等待结果时优先 rpc_task start（返回 taskId 后 rpc_task result 等待），防盲轮询竞态与收尾残留端口/进程";
		}
	}
	const threshold = longrunThresholdMs();
	const elapsed = opts.elapsedMs ?? 0;
	if (threshold > 0 && elapsed > threshold) {
		return `[amagi] 本次命令前台耗时 ${Math.round(elapsed / 1000)}s——长命令建议后台化（见上）或拆分`;
	}
	return null;
}

/**
 * 成功结果尾部追加 note：原生 shape 为 { content: [{type:"text",text}], details }，只改首个
 * text 条目（浅拷贝不改原对象），details/truncation/fullOutputPath 等其余字段原样保留。shape 异常时原样返回。
 */
function appendAdvisoryNote(result: unknown, note: string | null): unknown {
	if (!note || !result || typeof result !== "object") return result;
	const r = result as { content?: unknown };
	if (!Array.isArray(r.content)) return result;
	const content = r.content.slice();
	const idx = content.findIndex((c) => !!c && typeof c === "object" && typeof (c as { text?: unknown }).text === "string");
	if (idx === -1) return result;
	const entry = content[idx] as { text: string };
	content[idx] = { ...(content[idx] as object), text: entry.text ? `${entry.text}\n${note}` : note };
	return { ...(r as object), content };
}

/** ev-20260920-f736d8：污染级警示前置到首个 text 条目首部（note + 空行 + 原文本）——与
 *  appendAdvisoryNote（尾部，建议级）同构；shape 异常原样返回，不改其它字段。 */
function prependAdvisoryNote(result: unknown, note: string | null): unknown {
	if (!note || !result || typeof result !== "object") return result;
	const r = result as { content?: unknown };
	if (!Array.isArray(r.content)) return result;
	const content = r.content.slice();
	const idx = content.findIndex((c) => !!c && typeof c === "object" && typeof (c as { text?: unknown }).text === "string");
	if (idx === -1) return result;
	const entry = content[idx] as { text: string };
	content[idx] = { ...(content[idx] as object), text: entry.text ? `${note}\n\n${entry.text}` : note };
	return { ...(r as object), content };
}

/** pi 0.99.1（N1b）：BashTool 非零退出不再 throw，改 resolve + isError:true——失败结果判定。 */
function isBashFailureResult(result: unknown): boolean {
	return !!result && typeof result === "object" && (result as { isError?: unknown }).isError === true;
}

/** pi 0.99.1（N1b）：失败结果的错误文本（content text 条目拼接；无 text 条目时空串）。 */
function bashResultErrorText(result: unknown): string {
	if (!result || typeof result !== "object") return "";
	const content = (result as { content?: unknown }).content;
	if (!Array.isArray(content)) return "";
	return content
		.filter((c) => !!c && typeof c === "object" && typeof (c as { text?: unknown }).text === "string")
		.map((c) => (c as { text: string }).text)
		.join("\n");
}

// ─────────────────────────────────────────────────────────────────────────
// ev-20260926-bc6ba3（R5）：真实输出采集——采集点必须位于 amagi advisory/心跳文案添加**之前**
//（心跳走 onUpdate partial 不入最终结果；advisory 注记在采集后才追加，不把提示当程序日志）。
// 只读采集 + 经 appendAdvisoryNote 尾部附摘要：不改写原始行/命令/环境/cwd/退出码/
// details.fullOutputPath/truncation；采集异常绝不影响执行路径。
// ─────────────────────────────────────────────────────────────────────────

/** R5：resolve 路径（成功/非零退出 isError）从原生结果采集真实文本并返回聚合摘要 note（null=不附）。 */
function collectBashDebugNote(capture: DebugCapture, toolCallId: string, rawResult: unknown): string | null {
	try {
		const details = (rawResult as { details?: { truncation?: unknown; fullOutputPath?: unknown } } | null)?.details;
		recordDebugEvent(capture, {
			toolCallId,
			kind: isBashFailureResult(rawResult) ? "bash-error" : "bash-output",
			text: bashResultErrorText(rawResult),
			nativeTruncated: !!details && typeof details === "object" && details.truncation !== undefined && details.truncation !== null,
			fullOutputPath: typeof details?.fullOutputPath === "string" ? details.fullOutputPath : undefined,
		});
		return debugTagSummary(capture);
	} catch { /* lint-exempt:采集失败绝不影响执行路径 */ return null; }
}

/** R5：throw 路径（timeout/abort/底层 throw）采集真实错误文本（保持原 throw 语义，不附摘要）。 */
function collectBashDebugThrow(capture: DebugCapture, toolCallId: string, e: unknown): void {
	try {
		recordDebugEvent(capture, {
			toolCallId,
			kind: "bash-error",
			text: e instanceof Error ? e.message : String(e),
		});
	} catch { /* lint-exempt:采集失败绝不影响执行路径 */ }
}

// ─────────────────────────────────────────────────────────────────────────────
// fix-env-leak：任务边界 env 泄漏清洗。
//
// 根因：task-run 派发子 Agent 时注入的 AMAGI_ALLOWED_PATHS / AMAGI_PROTECTED_PATHS（JSON 绝对
// 路径数组）驻留在子进程 process.env；bash 工具原生 exec 的 env 来自 getShellEnv()（展开
// process.env），子 Agent 跑 `npm test` / `node --test` 时边界 env 原样泄入测试进程——
// guards-resources / iter-aug-p1 / wave-c4-guard-quotes 等哨兵测试按「无边界 env 放行」写
// 断言，泄漏后临时目录写入被 assertAllowedPaths 误拦（复盘 §范围外发现②）。
// 修复口径：命令命中测试运行特征 → 从 spawn env 剔除且仅剔除这两个任务边界变量；
// 其它 AMAGI_*（如 AMAGI_STATS_PATH）与非测试命令 env 一律原样保留。无感知、只动 env 组装、不阻断。
// ─────────────────────────────────────────────────────────────────────────────

/** 测试运行命令特征：node --test / 包管理器 test 入口（含 npm run test:ci 等变体）/ vitest。 */
const TEST_RUN_COMMAND_RE = new RegExp(
	[
		"\\bnode\\s+--test\\b", // node --test（含 env 前缀 / 多参数形态）
		"\\b(?:npm|pnpm|yarn|bun)\\s+(?:run\\s+)?test[\\w:.-]*", // npm test / pnpm test / yarn run test:ci …
		"\\bvitest\\b", // vitest / npx vitest / pnpm exec vitest
	].join("|"),
);

/**
 * 纯函数：测试运行命令的任务边界 env 清洗（供 spawnHook 与测试直接断言）。
 * 命中测试特征且 env 实际携带边界变量 → 返回剔除 AMAGI_ALLOWED_PATHS / AMAGI_PROTECTED_PATHS
 * 后的浅拷贝；其余情况（非测试命令 / env 未携带）原对象引用返回，保证非测试路径零开销零改动。
 */
export function sanitizeTestEnv(command: string, env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
	if (!env || !TEST_RUN_COMMAND_RE.test(command)) return env;
	if (!("AMAGI_ALLOWED_PATHS" in env) && !("AMAGI_PROTECTED_PATHS" in env)) return env;
	const next = { ...env };
	delete next.AMAGI_ALLOWED_PATHS;
	delete next.AMAGI_PROTECTED_PATHS;
	return next;
}

// ev-20260917-7b9298：每次 bash 调用的唯一 invocation 标记（AsyncLocalStorage 跨 await 保持，经
// spawnHook 注入 env → 命令树全层继承——setsid/新进程组也不丢；超时收尾按 tag 精确回收遗孤）。
const bashInvocationScope = new AsyncLocalStorage<{ id: string; rootPid: number }>();

/** 原生 spawn 钩：工具非交互兜底 + 测试边界清洗 + invocation 标记。
 *  ev-20261020-d56baa：项目 shell.pathPrepend 前置注入（按 spawn cwd 读 <cwd>/amagi.json；幂等去重，
 *  不改 process.env）——用户级工具链（pip --user 的 cmake/ctest 等）不再每次手动 export。 */
function bashSpawnEnvSanitizeHook(context: BashSpawnContext): BashSpawnContext {
	const inv = bashInvocationScope.getStore();
	const sanitized = toolProcessEnv(envWithPathPrepend(sanitizeTestEnv(context.command, context.env), readProjectShellPathPrepend(context.cwd).dirs));
	if (!inv) return { ...context, env: sanitized };
	// 注入点：env 为原生每 spawn 新建对象（resolveSpawnContext {...getShellEnv()}）或 sanitize 拷贝，
	// 写入不污染 process.env；标记随命令树全层 env 继承，供 orphan-reaper 识别回收。
	const env = sanitized === context.env ? { ...sanitized } : sanitized;
	env.AMAGI_BASH_INVOCATION = inv.id;
	env.AMAGI_BASH_ROOT_PID = String(inv.rootPid);
	return { ...context, env };
}

/**
 * ev-20260909（P0，cwd 短路事故）：原生 bash execute 的 spawn cwd 取 `ctx?.cwd || 定义级 cwd`
 * （bash.js resolveSpawnContext 第二参）——而扩展工具执行时 pi 经 runner.createContext() 注入的
 * ctx.cwd 恒存在且恒为会话目录，直接透传 ctx 会把显式 cwd 参数永久短路（命令全部落在会话
 * 目录执行；a2-bash-cwd 测试的 makeCtx(dir) 让 ctx.cwd≡cwd 参数，短路分支从未被真实触发）。
 * 显式 cwd 分支必须以 Proxy 覆盖 ctx.cwd＝resolved：只拦 cwd 一键，其余 getter 惰性透传；
 * 不用 spread（runner.js 警告 spread 会急切读 getter 并冻结，assertActive 语义被破坏）。
 */
function withOverriddenCwd(ctx: unknown, resolvedCwd: string): unknown {
	if (ctx === undefined || ctx === null || typeof ctx !== "object") return ctx;
	return new Proxy(ctx as object, {
		get(target, prop, receiver) {
			if (prop === "cwd") return resolvedCwd;
			return Reflect.get(target, prop, receiver);
		},
	});
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20260914-8f2669②：长命令静默心跳。
//
// 实战：批量图片/文件生成类单命令（数十文件、无周期输出）执行期间子进程 watchdog 按静默超时
// 误判死 abort（4 次，含一次实现已 100% 落盘仅差报告）。根因：原生 bash 只在有输出时才发
// onUpdate partial（pi dist/core/tools/bash.js scheduleOutputUpdate 仅由 handleData 驱动），
// 静默命令全程零 update；watchdog 的 ACTIVITY_EVENTS 虽含 tool_execution_update 但收不到。
// 机制：execute 期间周期性调 onUpdate——pi agent-loop executePreparedToolCall 会把 partial 转发为
// tool_execution_update 事件（同进程子进程 watchdog 活性重置；json 模式 stdout 行同样刷新父进程
// 侧 lastActivity/execSilentMs 停滞计时，双端受益）。周期从 AMAGI_WATCHDOG_SILENCE_MS 推导
// （经 watchdog.resolveSilenceMsEnv 单一口径）：窗口关闭(0)心跳随之关闭；周期=窗口/6（钳 1s..5min）。
//
// ev-23f4a4（2026-09-16 优化方案 S3）bounded 租约：显式合法有限 bash timeout → 租约覆盖命令
// timeout + 执行器取消收口宽限，心跳持续到命令收口（不再被 2× 窗掐断）；无 timeout 维持 2× 窗
// 总预算，到期先发一次明确的「心跳预算耗尽」状态再停发（不悄悄停发、不无限续租）；完成/失败/取消
// 统一 finally 清 timer。原生有自然输出（1 个周期内）不打扰。AMAGI_BASH_HEARTBEAT_POLICY=legacy
// 恢复旧 2× 窗计划（到期悄悄停发、无耗尽通知）；现有 watchdog 禁用开关语义不变。
// ─────────────────────────────────────────────────────────────────────────────

export interface BashHeartbeatPlan {
	/** 心跳周期 ms；0 = 心跳关闭（看门狗静默窗口未启用）。 */
	periodMs: number;
	/** 心跳总窗口 ms（自命令开始）；超过后停发，看门狗恢复兜底。 */
	maxMs: number;
}

/** 纯函数：由看门狗静默窗口推导心跳计划（窗口 ≤0 = 关闭）。 */
export function bashHeartbeatPlan(silenceMs: number): BashHeartbeatPlan {
	if (!(silenceMs > 0)) return { periodMs: 0, maxMs: 0 };
	return { periodMs: Math.max(1_000, Math.min(silenceMs / 6, 300_000)), maxMs: silenceMs * 2 };
}

/** 纯函数：本拍是否应发心跳（自然输出周期内抑制；超总窗停发交还看门狗兜底）。 */
export function bashHeartbeatDue(o: { now: number; lastNaturalAt: number; startedAt: number; plan: BashHeartbeatPlan }): boolean {
	if (!(o.plan.periodMs > 0)) return false;
	if (o.now - o.lastNaturalAt < o.plan.periodMs) return false;
	if (o.plan.maxMs > 0 && o.now - o.startedAt > o.plan.maxMs) return false;
	return true;
}

/**
 * ev-23f4a4（S3）：bounded 心跳租约计划。
 * 显式合法有限 bash timeout（秒）→ 租约覆盖命令 timeout + 执行器取消收口宽限（原生 bash 超时即
 * 对进程组 SIGKILL 并包装错误，宽限只覆盖 kill→错误回流的时间，见 bash-executor/bash.js resolveTimeoutMs
 * 与 killProcessTree）；无 timeout → 维持 2× 静默窗总预算（到期不再惄惄停发，见 bashHeartbeatTick 的
 * exhaust 决策）。timeout=0/负/NaN 一律按无 timeout 处理（原生对非法值直接抛错，不存在「永久心跳」解释；
 * 也不得把 bash 秒参数直接当毫秒用——先 ×1000）。
 */
export interface BashHeartbeatLeasePlan {
	/** 心跳周期 ms；0 = 心跳关闭（看门狗静默窗口未启用）。与 BashHeartbeatPlan.periodMs 同推导。 */
	intervalMs: number;
	/** 自命令开始的总租约 ms；超过后停发心跳（legacy-window 原因下先发一次预算耗尽状态）。 */
	leaseMs: number;
	/** 租约来源：explicit-timeout=显式 bash timeout；legacy-window=2× 静默窗预算。 */
	reason: "explicit-timeout" | "legacy-window";
}

/** 执行器取消收口宽限（ms）：覆盖原生超时 SIGKILL→错误包装→本层后处理的时间。 */
export const HEARTBEAT_CANCEL_GRACE_MS = 2_000;

/** 纯函数：bounded 租约计划（窗口 ≤0 = 关闭；周期与 bashHeartbeatPlan 同口径：窗口/6 鉗 1s..5min）。 */
export function bashHeartbeatLeasePlan(silenceMs: number, timeoutSec?: number): BashHeartbeatLeasePlan {
	if (!(silenceMs > 0)) return { intervalMs: 0, leaseMs: 0, reason: "legacy-window" };
	const intervalMs = Math.max(1_000, Math.min(silenceMs / 6, 300_000));
	const finiteTimeout = typeof timeoutSec === "number" && Number.isFinite(timeoutSec) && timeoutSec > 0 ? timeoutSec : undefined;
	if (finiteTimeout !== undefined) {
		return { intervalMs, leaseMs: finiteTimeout * 1_000 + HEARTBEAT_CANCEL_GRACE_MS, reason: "explicit-timeout" };
	}
	return { intervalMs, leaseMs: silenceMs * 2, reason: "legacy-window" };
}

/** ev-23f4a4：AMAGI_BASH_HEARTBEAT_POLICY 解析（非法值回安全默认 bounded；legacy 恢复 2× 窗计划）。 */
export function resolveBashHeartbeatPolicy(env: NodeJS.ProcessEnv = process.env): "bounded" | "legacy" {
	return env.AMAGI_BASH_HEARTBEAT_POLICY === "legacy" ? "legacy" : "bounded";
}

/**
 * 纯函数（fake clock 可测）：本拍决策——beat=发心跳；exhaust=legacy-window 预算到期应发一次
 * 「心跳预算耗尽」状态（explicit-timeout 到期即命令自身 timeout 收口，无需耗尽通知）。
 * 与 bashHeartbeatDue 语义一致：自然输出周期内抑制；超租约停发。
 */
export function bashHeartbeatTick(o: {
	now: number;
	lastNaturalAt: number;
	startedAt: number;
	lease: BashHeartbeatLeasePlan;
	exhaustedSent: boolean;
}): { beat: boolean; exhaust: boolean } {
	if (!(o.lease.intervalMs > 0) || !(o.lease.leaseMs > 0)) return { beat: false, exhaust: false };
	if (o.now - o.startedAt > o.lease.leaseMs) {
		return { beat: false, exhaust: !o.exhaustedSent && o.lease.reason === "legacy-window" };
	}
	if (o.now - o.lastNaturalAt < o.lease.intervalMs) return { beat: false, exhaust: false };
	return { beat: true, exhaust: false };
}

/** 心跳 partial 文本（含短命令摘录，TUI/事件流可读）。 */
export function bashHeartbeatNote(command: string, elapsedMs: number): string {
	const frag = String(command || "").replace(/\s+/g, " ").trim().slice(0, 40);
	return `[amagi 心跳] bash 运行中 ${Math.round(elapsedMs / 1000)}s 无输出${frag ? `（${frag}…）` : ""}——活性信号，防看门狗静默误判；建议按长命令纪律拆批/加进度输出`;
}

/** ev-23f4a4：预算耗尽状态文本（一次、可见，不惄惄停发；命令未被证明完成）。 */
export function bashHeartbeatExhaustedNote(command: string, budgetMs: number): string {
	const frag = String(command || "").replace(/\s+/g, " ").trim().slice(0, 40);
	return `[amagi 心跳] bash 静默心跳预算耗尽（总预算 ${Math.round(budgetMs / 1000)}s，命令未被证明完成）——心跳停发，看门狗恢复静默兜底；长命令请显式设置 timeout 预算或按纪律拆批${frag ? `（${frag}…）` : ""}`;
}

/**
 * 包裹原生 execute：静默期周期性 onUpdate 心跳（onUpdate 缺省/心跳关闭时零开销直通）。
 * ev-23f4a4（S3）：bounded（默认）按租约计划执行——显式 timeout 内心跳持续到命令收口；无 timeout
 * 保持 2× 窗预算，到期先发一次明确的「预算耗尽」状态再停发；完成/失败/取消统一 finally 清 timer。
 * legacy（AMAGI_BASH_HEARTBEAT_POLICY=legacy）恢复旧 2× 窗计划（到期惄惄停发、无耗尽通知）。
 */
async function withBashHeartbeat<T>(
	command: string,
	startedAt: number,
	timeoutSec: number | undefined,
	onUpdate: ((partial: unknown) => void) | undefined,
	run: (patched: ((partial: unknown) => void) | undefined) => Promise<T>,
): Promise<T> {
	const silenceMs = resolveSilenceMsEnv();
	const policy = resolveBashHeartbeatPolicy();
	const legacyPlan = bashHeartbeatPlan(silenceMs);
	const lease: BashHeartbeatLeasePlan = policy === "legacy"
		? { intervalMs: legacyPlan.periodMs, leaseMs: legacyPlan.maxMs, reason: "legacy-window" }
		: bashHeartbeatLeasePlan(silenceMs, timeoutSec);
	if (!onUpdate || !(lease.intervalMs > 0)) return run(onUpdate);
	let lastNaturalAt = Date.now();
	let exhaustedSent = false;
	const patched = (partial: unknown): void => {
		lastNaturalAt = Date.now();
		onUpdate(partial);
	};
	const timer = setInterval(() => {
		const now = Date.now();
		const decision = bashHeartbeatTick({ now, lastNaturalAt, startedAt, lease, exhaustedSent });
		if (decision.exhaust && policy === "bounded") {
			// 无 timeout 路径 2× 窗预算到期：发一次明确「心跳预算耗尽」状态（不惄惄停发、不无限续租）
			exhaustedSent = true;
			try {
				onUpdate({ content: [{ type: "text", text: bashHeartbeatExhaustedNote(command, lease.leaseMs) }] });
			} catch { /* 心跳失败不阻断执行 */ }
			clearInterval(timer);
			return;
		}
		if (!decision.beat) return;
		try {
			onUpdate({ content: [{ type: "text", text: bashHeartbeatNote(command, now - startedAt) }] });
		} catch { /* 心跳失败不阻断执行 */ }
	}, lease.intervalMs);
	timer.unref?.();
	try {
		return await run(patched);
	} finally {
		clearInterval(timer);
	}
}

/** ev-20261004-e023ed②：子代理未传 timeout 的 bash 注入默认上限。B4·批C 起实现迁至 guards.ts
 * （与 D1/D2 disclose 前提的兑底检测同源）；此处 re-export 维持既有 import 路径（测试/外部消费者不变）。
 *  语义注释见 guards.ts 同名函数（根因：steer 送达挂在「下一个模型请求前」，未传 timeout 的长阻塞
 *  bash 使下一个请求不可达——默认上限把不可达窗口从无界收敛为有限，缺省 600s）。 */
export { resolveSubagentBashDefaultTimeout } from "./guards.ts";
import { resolveSubagentBashDefaultTimeout } from "./guards.ts";

/** ev-20261004-e023ed③：子代理全盘 find 执行前拒绝开关（AMAGI_SUBAGENT_FIND_BLOCK=0/off 关闭）。 */
export function subagentFindScanBlockEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const raw = env.AMAGI_SUBAGENT_FIND_BLOCK;
	return !(raw === "0" || raw?.toLowerCase() === "off");
}

/** ev-20261004-e023ed①：子代理全盘 find 执行前拒绝文案（纯函数）。
 *  B4A（ev-20261012-af58eb 批A）：文案携 guard-rule 标签 bash.wholeScan（信号层）；env 逃生舱
 *  注明为操作者面，策略投影与来源见 /amagi config explain。 */
export function subagentWholeScanBlockNote(command: string): string {
	return `[amagi 守卫·bash.wholeScan·全盘搜索阻断] 子代理执行了无超时兜底的全盘 find（${command.slice(0, 120)}）——全盘遍历在大目录树上可能长时间零产出，且长时间阻塞的 bash 会让 steer 调整无法送达，所以命令未执行（来由：ev-20261004-e023ed）。可改为：① 限定目录重试（find <项目/已知目录> -name …）；② 查找目标名已知时优先 mdfind/rg（限定目录）；③ 确需全盘：显式传 timeout 参数（秒级）后再试（有兜底即放行）。（Leader 侧为软提示；本阻断仅子代理生效；操作者逃生舱 AMAGI_SUBAGENT_FIND_BLOCK=0；策略投影与来源见 /amagi config explain）`;
}

/** B4·批C（D11，ev-20261012-af58eb §8 批C + Leader 裁定）：disclose 披露文案（纯函数）。
 *  前置实测④：未传 timeout 的子代理 bash 经 AMAGI_SUBAGENT_BASH_TIMEOUT 注入默认上限（缺省
 *  600s，可调，=0 关闭）真实收口——有界执行已生效，故默认 disclose（放行+披露）；受信配置/
 *  env 肯定值收紧回 block 时走 subagentWholeScanBlockNote 执行前拒绝。 */
export function wholeScanDisclosureNote(command: string, defaultTimeoutSec: number | undefined): string {
	const boundText = defaultTimeoutSec !== undefined ? `本次执行时限 ${defaultTimeoutSec}s（子代理默认超时，超时自动收口）` : "本次未传 timeout 且默认超时已关闭（AMAGI_SUBAGENT_BASH_TIMEOUT=0）——超时收口不可用，若搜索范围巨大可能长时间无产出";
	return `[amagi 守卫·bash.wholeScan｜已放行] 检测到全盘 find（${command.slice(0, 100)}）未传 timeout；${boundText}；建议限定目录（find <项目/已知目录> -name …）或改用 mdfind/rg；长任务可改 run_bg 后台。（策略投影与来源见 /amagi config explain）`;
}

/** ev-20260922-1eea28（B2）：执行前消费授权丢弃放行凭证；无凭证/异常零开销直通。
 *  diting F1（2026-09-24）：凭证与当前命令/cwd 不匹配（mismatch）时阻断执行而非静默放行——
 *  mismatch 语义为凭证已作废，继续执行即未授权丢弃；作废凭证不重发，重新授权后原命令重试。 */
type ActiveDiscardTicket = { ticket: DiscardExecutionTicket } | { mismatch: string } | null;
function consumeDiscardTicket(toolCallId: string, command: string, execCwd: string): ActiveDiscardTicket {
	let taken: ActiveDiscardTicket;
	try { taken = takeDiscardExecutionTicket(toolCallId, { command, cwd: execCwd }); } catch { return null; }
	if (taken && !("ticket" in taken)) {
		throw new Error(`[amagi 守卫·丢弃授权] 授权凭证与当前命令/工作目录不匹配（${taken.mismatch}）——凭证已作废，命令未执行；请重新取得授权后在相同命令与 cwd 下执行。`);
	}
	return taken;
}

/** ev-20260922-1eea28（B2）：执行后记录授权丢弃结果（ok=命令退出状态；失败附首段错误文本）。
 *  记录失败不掩盖原生执行结果（try/catch 静默；guard-note 发送与落盘双向独立）。 */
function finishDiscardTicket(active: ActiveDiscardTicket, outcome: { ok: boolean; errorMessage?: string }): void {
	if (!active || !("ticket" in active)) return; // mismatch：凭证已丢弃，不记录执行审计
	try { recordDiscardExecutionOutcome(active.ticket, { ok: outcome.ok, ...(outcome.errorMessage ? { errorMessage: outcome.errorMessage } : {}) }); } catch { /* 不掩盖执行结果 */ }
}

/** 创建覆盖内置 bash 的同名工具：schema 增加 cwd；省略 renderCall/renderResult 以继承内置渲染。 */
export function createBashCwdOverrideTool(baseCwd: string = process.cwd(), deps: { hostPlatform?: string; bashRuntime?: (baseCwd?: string) => BashRuntimeInfo } = {}) {
	// fix-env-leak：原生 spawn env 组装点唯一挂钩——resolveSpawnContext 先 {...getShellEnv()} 再过
	// spawnHook；环境防线仅修改每次工具 spawn 的副本，宿主交互环境保留。
	const baseDef = createBashToolDefinition(baseCwd, { spawnHook: bashSpawnEnvSanitizeHook });
	return {
		...baseDef,
		name: "bash" as const,
		label: "bash",
		description: `${baseDef.description} Optionally provide cwd to run the command in an existing directory instead of the session cwd, or debugTag (1-64 ASCII [A-Za-z0-9._-]) to collect the command's real final output into the session debug collector (/amagi debug).`,
		promptGuidelines: [...(baseDef.promptGuidelines ?? []), CWD_GUIDELINE, DEBUG_TAG_GUIDELINE],
		parameters: schema,
		// G-1（pi099 L 报告 §1）：透传原生 bashOutputSchema——宿主未从包根导出该符号（bash.js:40
		// 模块私有 const，index.d.ts 导出清单无），但 baseDef.outputSchema 即它（bash.js:172），直接
		// 引用透传：零复写失真、随宿主升级自动同步。纯声明（execute 行为/参数/描述/修饰/守卫/钳制零
		// 改动）：修复前 codemode 程序化面按声明解析（tool.js:147 outputSchema ?? TEXT_OUTPUT_SCHEMA；
		// execute.js:174-175 structuredContent 门槛），amagi 会话 bash 恒为 override 版 → 脚本调用退化
		// 纯文本，1MiB 结构化容量对该面不可达。
		outputSchema: baseDef.outputSchema,
		// pi 0.86.0 配合：对齐内置 bash 默认 strict:prefer（AMAGI_BUILTIN_CONSTRAINED=0 逃生舱），见 host-capabilities.resolveBuiltinConstrainedSampling
		constrainedSampling: resolveBuiltinConstrainedSampling(),
		async execute(
			toolCallId: string,
			args: BashCwdOverrideInput,
			signal: AbortSignal | undefined,
			onUpdate: ((partial: unknown) => void) | undefined,
			ctx: unknown,
		) {
			const { timeout, cwd, debugTag } = args;
			// requestedCommand：模型原始命令（丢弃授权凭证按它核对）；command：实际执行命令（rg 粘连簇可能被自动改写）。
			const requestedCommand = args.command;
			let command = requestedCommand;
			const sessionCwd = builtinFileCwd(baseCwd, ctx);
			let executionCwd = sessionCwd;
			// ev-20260926-bc6ba3（R5）：debugTag 参数校验——执行前拒绝（不 spawn），同 cwd 参数错误口径。
			if (debugTag !== undefined && !debugTagValid(debugTag)) {
				throw new Error(`[bash debugTag] debugTag 非法（收到 ${JSON.stringify(debugTag)}）：须为 1-64 位 ASCII 字符 [A-Za-z0-9._-]，不含控制符、路径或表达式——命令未执行；省略 debugTag 则不采集，修正后可直接重发`);
			}
			// R5：委托原生 bash 前冻结 tag+会话 generation——完成/失败时据此采集（迟到过期不回填）。
			const debugCapture = freezeDebugCapture(debugTag);
			// ev-20261004-e023ed③：子代理全盘 find 执行前拦截（Leader 侧保持软提示，见 guards fullScanFindRisk）。
			// 判定单源 wholeScanFindHit（与软提示同一检测）；仅拦「无超时兑底」形态——显式传 timeout 有
			// 兑底即放行（加上方子代理默认超时，最坏挂随有限窗口收口）。
			// B4·批C（D11，Leader 裁定）+ B4C-R01：判定经 guard-policy 投影（默认 disclose：放行执行+
			// 披露）；disclose 前提=最终有效 timeout 为正有限数（wholeScanFindHit 命中时无显式 timeout，
			// 故前提=子代理默认超时实际注入——AMAGI_SUBAGENT_BASH_TIMEOUT=0/off 关闭时保持 block）。
			// subagentFindScanBlockEnabled 保留为 env 语义单源（guard-policy.test.mjs 镜像断言：投影归一
			// ≡ 本函数）。block（受信配置收紧/AMAGI_SUBAGENT_FIND_BLOCK 肯定值/无兑底）仍执行前拒绝。
			const wholeScanHit = process.env.AMAGI_SUBAGENT === "1" && wholeScanFindHit(command, timeout);
			const wholeScanBounded = (typeof timeout === "number" && Number.isFinite(timeout) && timeout > 0) || resolveSubagentBashDefaultTimeout(process.env, timeout) !== undefined;
			const wholeScanRuleBlocks = wholeScanHit && (!wholeScanBounded || guardRuleOf("bash.wholeScan", sessionCwd, guardProjectTrustedOf(ctx)) === "block");
			if (wholeScanRuleBlocks) {
				throw new Error(subagentWholeScanBlockNote(command));
			}
			// 安全可识别的 rg 粘连簇自动改写（block/disclose 均先修正再执行）。策略仅用于无法安全
			// 改写的命中形态（例如 heredoc 混合脚本）：保留受信 block，默认前置披露。
			const rgRuleBlocks = guardRuleOf("bash.rgReplace", sessionCwd, guardProjectTrustedOf(ctx)) === "block";
			let rgRewriteNoteText: string | null = null;
			const rewrite = rgReplaceClusterRewrite(command);
			if (rewrite) {
				rgRewriteNoteText = rgRewriteNote(command, rewrite);
				command = rewrite.command;
				try { onUpdate?.({ content: [{ type: "text", text: rgRewriteNoteText }] }); } catch { /* lint-exempt:前置披露通道失败不阻断执行 */ }
			}
			if (rgRuleBlocks) {
				const rgBlock = rgReplaceHardBlockNote(command);
				if (rgBlock) throw new Error(rgBlock);
			}
			if (!rgRuleBlocks) {
				const rgPreWarning = criticalBashAdvisory(command);
				if (rgPreWarning) {
						// R01 终裁：partialResult 契约（与心跳同形）——裸字符串宿主无法消费，前置披露不生效。
						try { onUpdate?.({ content: [{ type: "text", text: rgPreWarning }] }); } catch { /* lint-exempt:前置披露通道失败不阻断执行 */ }
				}
			}
			// B4·批C（D11 disclose）：全盘 find 命中且投影 disclose 且有兑底 → 放行 + 前置披露（R01 同款
			// onUpdate 时序，先于执行器）；结果首部披露在 effectiveTimeout 计算后拼装（wholeScanDisclosure
			// Note）。无兑底（默认超时关闭）已在上整单 throw，不进入披露路径。
			const wholeScanDisclosure = wholeScanHit && !wholeScanRuleBlocks
				? wholeScanDisclosureNote(command, resolveSubagentBashDefaultTimeout(process.env, timeout))
				: null;
			// 首部前置披露通道（成功/失败/throw 全路径共用）：rg 改写说明在最顶。
			const wholeScanPreNote = [rgRewriteNoteText, wholeScanDisclosure].filter(Boolean).join("\n") || null;
			if (wholeScanDisclosure) {
				try { onUpdate?.({ content: [{ type: "text", text: wholeScanDisclosure }] }); } catch { /* lint-exempt:前置披露通道失败不阻断执行 */ }
			}
			// ev-20261004-e023ed②：子代理未传 timeout 的 bash 注入默认上限（steer 可达性兑底，见函数注释）。
			const subagentDefaultTimeout = resolveSubagentBashDefaultTimeout(process.env, timeout);
			// ev-20260930-timeout-cap（主上指令）：timeout 上限 1200s（20min）钳制——子 Agent 曾把
			// 70000（≈19.4h）当秒传入导致整轮阻塞；超限按上限执行并在结果首部附注（timeout 单位
			// 为秒；更久任务应走 run_bg 后台或 task 派发）。AMAGI_BASH_TIMEOUT_CAP 调上限，=0 关闭。
			const timeoutCap = (() => {
				const raw = process.env.AMAGI_BASH_TIMEOUT_CAP;
				if (raw === undefined || raw === "") return 1200; // 缺省 20min
				const v = Number(raw);
				if (!Number.isFinite(v) || v <= 0) return 0; // 显式 0/非法值 = 关闭钳制（原样透传）
				return v;
			})();
			const timeoutCapped = timeoutCap > 0 && typeof timeout === "number" && Number.isFinite(timeout) && timeout > timeoutCap;
			const effectiveTimeout = timeoutCapped ? timeoutCap : (timeout ?? subagentDefaultTimeout);
			const timeoutCapNote = timeoutCapped
				? `[amagi 守卫·超时钳制] timeout=${timeout}s 超上限 ${timeoutCap}s，已按上限执行——timeout 单位为秒；更久任务请用 run_bg 后台派发（AMAGI_BASH_TIMEOUT_CAP 可调，0=关闭）`
				: "";
			// P2-6：计时起点放在一切分支之前，elapsed 只度量真实执行耗时（cwd 校验耗时忽略不计）
			const startedAt = Date.now();
			// ev-7b9298：本次调用唯一标记（spawnHook 注入 env；超时/中止收尾按它精确回收遗孤）
			const invocation = { id: `bashinv-${randomUUID().slice(0, 8)}`, rootPid: process.pid };
			// ev-7b9298：超时/中止收尾——先按 invocation tag 组级回收脱离进程组的遗孤，再拼软提示行（不掩盖原始错误）
			// pi 0.99.1（N1b）：参数从 Error 改为 message 文本——同时服务 catch 路径（timeout/abort 仍 throw）
			// 与 isError 结果分支（非零退出 resolve，错误文本从 bashResultErrorText 提取）。
			const finalizeFailure = async (message: string): Promise<string> => {
				const note = failureNote(message);
				const lines: string[] = [];
				if (note) lines.push(note);
				// ev-20260926-98de68/849b26：heredoc 原子性与 git 层级提示在失败路径同样注入——
				// python assert 中途崩溃/管道批量失配正是这两类提示最需要的时机（见命令结构诊断）。
				const heredocNote = pythonHeredocReplaceHint(command);
				if (heredocNote) lines.push(heredocNote);
				// ev-20261004-e023ed②：子代理默认超时介入说明——长阻塞收口后模型请求恢复可达，
				// 附因与替代方案（拆批/显式 timeout/run_bg），避免子代理盲重试同型无界命令。
				if (subagentDefaultTimeout !== undefined && /timed out|aborted/i.test(message)) {
					lines.push(`[amagi 守卫·子代理默认超时] 未传 timeout 的 bash 已按默认上限 ${subagentDefaultTimeout}s 收口（AMAGI_SUBAGENT_BASH_TIMEOUT 可调，=0 关闭）——长任务请拆批、传显式 timeout 或改 run_bg 后台；若有运行中 steer 调整，现已随本错误回流送达。`);
				}
				const gitNote = gitRootDepthNote(command, executionCwd);
				if (gitNote) lines.push(gitNote);
				if (
					(/Command timed out after /.test(message) || signal?.aborted === true || /Command aborted/.test(message))
					&& orphanReaperEnabled()
				) {
					try {
						const res = await reapInvocationOrphans({ invocation: invocation.id, rootPid: invocation.rootPid });
						if (res.cleanedCount > 0) lines.push(`${res.summary}（本次命令脱离进程组的遗留后代已级联回收）`);
					} catch { /* 回收失败不掩盖原始错误 */ }
				}
				return lines.join("\n");
			};
			const postRunNote = () =>
				bashAdvisoryNote(command, { elapsedMs: Date.now() - startedAt, hasTimeoutParam: timeout !== undefined });
			// ev-20260903-191473（P1，复盘 §1.1）：成功结果的 note 拼装——先记录 ABI marker（restore 命令删
			// marker 必须先于提醒计算，本次恢复后即不再提示），再把 ABI 提醒与 P2-6 长驻提示合并
			// （先 ABI 后长驻、各占一行、null 跳过）；失败路径不调用（保持既有失败协同格式）。
			const successNote = (execCwd: string): string | null => {
				recordEnvFlip(command, execCwd);
				// ev-20260926-98de68（heredoc 原子性）+ ev-20260926-849b26（git root 层级差）：
				// 命令结构/环境类建议级提示并入尾部通道（null 跳过，各占一行）。
				// ev-20261031-a25f7a：ABI 提醒改经 abiReminderCompactNote（首次全文、第 2 次起一行折叠；
				// 按 cwd+marker 实例区分计数），其余保持原文拼装。
				const notes = [abiReminderCompactNote(command, execCwd), postRunNote(), pythonHeredocReplaceHint(command), gitRootDepthNote(command, execCwd)].filter((n): n is string => typeof n === "string" && n.length > 0);
				return notes.length > 0 ? notes.join("\n") : null;
			};
			// timeout/abort 的判定依据原生错误文本（Command timed out after N seconds / Command aborted）
			// + signal.aborted（ops.exec 在信号已中止时抛裸 "aborted" 也会被原生包装为 Command aborted）
			const failureNote = (message: string) =>
				bashAdvisoryNote(command, {
					timedOut: /Command timed out after /.test(message),
					aborted: signal?.aborted === true || /Command aborted/.test(message),
					elapsedMs: Date.now() - startedAt,
					hasTimeoutParam: timeout !== undefined,
				});
			if (cwd === undefined) {
				// ev-20260922-1eea28（B2）：授权丢弃一次性放行凭证消费（执行前；换命令/cwd 即失效）
				const discardTicket = consumeDiscardTicket(toolCallId, requestedCommand, sessionCwd);
				// ev-20260830-2c709d：批量写盘命令前置静默 git 快照锚点（stash create 悬空提交；失败安全零语义影响）
				await maybeSnapshotAnchor(command, sessionCwd);
				// 与原生行为一致：cwd 用 ctx.cwd || baseCwd，参数原样透传；P2-6 note 属纯后处理
				// （成功仅在 content 文本尾部追加一行、失败仅在 e.message 尾部追加一行），不影响原生行为语义
				try {
					// ev-20260914-8f2669②：静默心跳包裹（onUpdate → tool_execution_update 活性；见节首注释）
					// ev-23f4a4（S3）：透传显式 timeout 秒数 → bounded 租约覆盖命令收口
					// ev-7b9298：ALS 包裹 → spawnHook 注入 invocation 标记（见 bashSpawnEnvSanitizeHook）
					const result = await bashInvocationScope.run(invocation, () =>
						withBashHeartbeat(command, startedAt, effectiveTimeout, onUpdate, (patched) => baseDef.execute(toolCallId, { command, timeout: effectiveTimeout }, signal, patched as never, ctx as never)));
					// pi 0.99.1（N1b）：非零退出 resolve + isError:true——失败协同前移：不记 fs 变更/写目标/
					// ABI marker/成功注记，审计记 ok:false，失败路径注记（heredoc/git 层级/耗时预算）追加错误文本尾部。
					if (isBashFailureResult(result)) {
						const failText = bashResultErrorText(result);
						finishDiscardTicket(discardTicket, { ok: false, errorMessage: failText.slice(0, 400) });
						// R5：advisory 注记添加前采集真实错误文本（isError 语义/退出码不变），失败协同后附聚合摘要
						const debugNote = debugCapture ? collectBashDebugNote(debugCapture, toolCallId, result) : null;
						// B4B 修复轮 R01：失败路径同样保留 rg 污染风险说明（执行前已发过前置披露，此处为最终文本兜底）
						return prependAdvisoryNote(prependAdvisoryNote(appendAdvisoryNote(result, [await finalizeFailure(failText), criticalBashAdvisory(command), debugNote].filter(Boolean).join("\n") || null), timeoutCapNote), wholeScanPreNote);
					}
					// ev-20260901-91d4ae：mv/rm 成功后记录受影响路径（TTL 缓冲，供 edit ENOENT 竞态提示；内部静默不抛）
					recordFsMutations(command, sessionCwd);
					// ev-20260922-1eea28（B2）：授权丢弃执行结果落盘（真实退出事实；guard-note 由 guards tool_result 发送）
					finishDiscardTicket(discardTicket, { ok: true });
					// ev-20260903-64641c（P0）：成功执行后尽力登记明确写目标（重定向/tee/sed -i/cp·mv 目标侧/
					// mkdir·touch），供结算三档归因；未设 AMAGI_TASK_ID 时 no-op，解析不到静默跳过
					recordBashWriteTargets(command, sessionCwd);
					// ev-20260920-f736d8：污染级警示前置（首部）→ 建议级注记追加（尾部）——同首 text 条目，顺序无覆盖
				// R5：advisory 注记添加前采集真实输出（原始行/退出码/truncation/fullOutputPath 不改写），尾部附聚合摘要
				const debugNote = debugCapture ? collectBashDebugNote(debugCapture, toolCallId, result) : null;
				// ev-20261005-7b6d68：验证型命令+吞码管道的结果尾退出码提示（成功侧——误读主要发生在「看起来成功」的结果）；ev-20261012-4b470d：计次降频
				const pipeNote = pipeExitTailNote(command);
				// B4·批B（D5/D6 disclose）：commit 成功后基于真实提交集披露（大文件列大小/node_modules 列路径；rule=block 时事件链已拦，此处恒 null）。
				const commitNote = commitGuardDisclosureNote(command, sessionCwd, guardProjectTrustedOf(ctx));
				return prependAdvisoryNote(prependAdvisoryNote(appendAdvisoryNote(appendAdvisoryNote(appendAdvisoryNote(prependAdvisoryNote(prependAdvisoryNote(prependAdvisoryNote(result, criticalBashAdvisory(command)), commitNote), bsdPortabilityPreflightNote(command, { hostPlatform: deps.hostPlatform, bashRuntime: deps.bashRuntime })), successNote(sessionCwd)), pipeNote), debugNote), timeoutCapNote), wholeScanPreNote);
				} catch (e) {
					finishDiscardTicket(discardTicket, { ok: false, errorMessage: e instanceof Error ? e.message.slice(0, 400) : String(e).slice(0, 400) });
					// R5：throw 路径（timeout/abort/底层 throw）采真实错误——保持原 throw 语义，不附摘要
					if (debugCapture) collectBashDebugThrow(debugCapture, toolCallId, e);
					if (e instanceof Error) {
						const note = await finalizeFailure(e.message);
						const capPrefix = timeoutCapNote ? `${timeoutCapNote}\n` : "";
						// B4B 修复轮 R01：throw 路径（timeout/abort）同样保留 rg 污染风险说明（执行前已发过前置披露）
						const rgFailWarning = criticalBashAdvisory(command);
						if (note || rgFailWarning || wholeScanPreNote) throw new Error(`${capPrefix}${e.message}\n${[wholeScanPreNote, note, rgFailWarning].filter(Boolean).join("\n")}`);
						if (capPrefix) throw new Error(`${capPrefix}${e.message}`);
					}
					throw e;
				}
			}
			const trimmed = typeof cwd === "string" ? cwd.trim() : "";
			if (!trimmed) {
				throw new Error(`[bash cwd] cwd 不能为空串（收到 ${JSON.stringify(cwd)}）；省略 cwd 则使用 ${sessionCwd}`);
			}
			// ev-20260925-287e93（双宿主根治 §2.1）：cwd 按 bash 运行时宿主解析。win32 宿主 + bash 跑在
			// WSL 时，POSIX 绝对路径（/mnt/x/...、/home/...）在 Windows 侧 statSync 不到，此前整单拒绝
			// 「目录不存在」——实际目录在 bash 侧真实存在（实战：cwd:/mnt/x/WorkSpace/sub2api 被拒）。
			// 此处先把 POSIX 路径映射为 Windows 侧可达形式再校验/执行：/mnt/<盘>/P → <盘>:\P
			//（drvfs 同一文件系统，确定性映射、零探测）；其余 WSL 内部路径 → \\wsl.localhost\<distro><P>
			//（9P UNC，需 distro 已知；探测失败不映射，按原语义报错并附修正建议）。映射后 resolved 即
			// spawn cwd——bash.exe 经 UNC/盘符 cwd 落入对应 WSL 路径；[cwd] 行附 bash 侧路径供核对。
			let mappedBashSide: string | null = null;
			let resolved: string;
			if ((deps.hostPlatform ?? process.platform) === "win32" && isPosixStyleAbsolutePath(trimmed)) {
				let target = posixToWindowsVisible(trimmed, { probed: false, wsl: false });
				if (target === null) {
					try {
						const info = deps.bashRuntime ? deps.bashRuntime(sessionCwd) : probeBashRuntime(sessionCwd);
						target = posixToWindowsVisible(trimmed, info);
					} catch { /* lint-exempt:探测失败不映射——回退 win32 原生解析，报错文案附双宿主建议 */ }
				}
				if (target !== null) {
					mappedBashSide = trimmed;
					resolved = target;
				} else {
					resolved = path.isAbsolute(trimmed) ? trimmed : path.resolve(sessionCwd, trimmed);
				}
			} else {
				resolved = path.isAbsolute(trimmed) ? trimmed : path.resolve(sessionCwd, trimmed);
			}
			let st: fs.Stats;
			try { st = fs.statSync(resolved); } catch {
				const dualHostHint = mappedBashSide !== null
					? `（双宿主：已映射为 bash 运行时侧 ${mappedBashSide} 的 Windows 形态 ${resolved}，仍不可达——WSL 发行版未运行或 UNC 不可用；可先在 bash 侧确认目录存在）`
					: ((deps.hostPlatform ?? process.platform) === "win32" && isPosixStyleAbsolutePath(trimmed))
						? `（双宿主：bash 运行时探测失败，无法校验 WSL 侧路径；可改用 /mnt/<盘>/... 形态或省略 cwd）`
						: "";
				throw new Error(`[bash cwd] "${trimmed}"（解析为 ${resolved}）不存在${dualHostHint}；请提供存在的目录或省略 cwd`);
			}
			if (!st.isDirectory()) {
				throw new Error(`[bash cwd] "${trimmed}"（解析为 ${resolved}）不是目录${mappedBashSide !== null ? `（bash 侧 ${mappedBashSide} 的 Windows 映射）` : ""}`);
			}
			// ev-20260922-1eea28（B2）：授权丢弃一次性放行凭证消费（执行前；resolved 为实际执行 cwd）
			executionCwd = resolved;
			const discardTicket = consumeDiscardTicket(toolCallId, requestedCommand, resolved);
			try {
				// ev-20260830-2c709d：批量写盘命令前置静默 git 快照锚点（resolved 校验通过后；失败安全零语义影响）
				await maybeSnapshotAnchor(command, resolved);
				// 以 resolvedCwd 构造原生定义执行：截断/落盘/超时/退出码文本构造全部复用原生实现；
				// spawnHook 与 baseDef 同一份（fix-env-leak：测试命令剔除任务边界 env）。
				// ev-20260909：透传 ctx 前覆盖 cwd＝resolved，否则会话 ctx.cwd 会短路本参数（见 withOverriddenCwd）。
				// ev-20260914-8f2669②：静默心跳包裹（onUpdate → tool_execution_update 活性）
				// ev-23f4a4（S3）：透传显式 timeout 秒数 → bounded 租约覆盖命令收口
				// ev-7b9298：ALS 包裹 → spawnHook 注入 invocation 标记（见 bashSpawnEnvSanitizeHook）
				const result = await bashInvocationScope.run(invocation, () =>
					withBashHeartbeat(command, startedAt, effectiveTimeout, onUpdate, (patched) => createBashToolDefinition(resolved, { spawnHook: bashSpawnEnvSanitizeHook }).execute(toolCallId, { command, timeout: effectiveTimeout }, signal, patched as never, withOverriddenCwd(ctx, resolved) as never)));
				// pi 0.99.1（N1b）：非零退出 resolve + isError:true——失败协同前移：[cwd] 行（含双宿主双侧核对）
				// + 失败注记追加错误文本尾部；成功侧效果（fs 变更/写目标/ABI marker/成功注记）不进失败路径。
				if (isBashFailureResult(result)) {
					const failText = bashResultErrorText(result);
					finishDiscardTicket(discardTicket, { ok: false, errorMessage: failText.slice(0, 400) });
					// R5：advisory 注记添加前采集真实错误文本，失败协同（[cwd] 行+注记）后附聚合摘要
					const debugNote = debugCapture ? collectBashDebugNote(debugCapture, toolCallId, result) : null;
					const note = await finalizeFailure(failText);
					// ev-20260925-287e93：双宿主映射时 [cwd] 行附 bash 侧路径（POSIX 形态即调用方书写形态），供双侧核对。
					const cwdLine = mappedBashSide !== null ? `[cwd] ${resolved}（bash 侧 ${mappedBashSide}）` : `[cwd] ${resolved}`;
					// B4B 修复轮 R01：失败路径同样保留 rg 污染风险说明（同无 cwd 分支）
					return prependAdvisoryNote(prependAdvisoryNote(appendAdvisoryNote(result, [cwdLine, note, criticalBashAdvisory(command), debugNote].filter(Boolean).join("\n") || null), timeoutCapNote), wholeScanPreNote);
				}
				// ev-20260901-91d4ae：cwd 显式路径同样记录（相对操作数以 resolved 为基准解析）
				recordFsMutations(command, resolved);
				// ev-20260922-1eea28（B2）：授权丢弃执行结果落盘（真实退出事实）
				finishDiscardTicket(discardTicket, { ok: true });
				// ev-20260903-64641c（P0）：cwd 显式路径同样登记写目标（相对操作数以 resolved 为基准解析）
				recordBashWriteTargets(command, resolved);
				// ev-20260920-f736d8：同上——污染级前置（首部）→ 建议级追加（尾部）
				// R5：advisory 注记添加前采集真实输出（同无 cwd 分支），尾部附聚合摘要
				const debugNote = debugCapture ? collectBashDebugNote(debugCapture, toolCallId, result) : null;
				// ev-20261005-7b6d68：显式 cwd 分支同样附结果尾管道提示（与 baseCwd 分支同语义；ev-20261012-4b470d：计次降频共用同一键）
				const pipeNote2 = pipeExitTailNote(command);
				// B4·批B（D5/D6 disclose）：同无 cwd 分支——真实提交集披露（resolved 为实际执行 cwd）。
				const commitNote2 = commitGuardDisclosureNote(command, resolved, guardProjectTrustedOf(ctx));
				return prependAdvisoryNote(prependAdvisoryNote(appendAdvisoryNote(appendAdvisoryNote(appendAdvisoryNote(prependAdvisoryNote(prependAdvisoryNote(prependAdvisoryNote(result, criticalBashAdvisory(command)), commitNote2), bsdPortabilityPreflightNote(command, { hostPlatform: deps.hostPlatform, bashRuntime: deps.bashRuntime })), successNote(resolved)), pipeNote2), debugNote), timeoutCapNote), wholeScanPreNote);
			} catch (e) {
				// 失败协同（轻量）：cwd 显式 → 保留原生首段错误，尾部附 [cwd] 行，供 B2 诊断波引用「本次 cwd=X」。
				// timeout（Command timed out after N seconds）、abort（Command aborted）及 exec 底层 throw 走此
				// 路径；非零退出在 0.99.1 下 resolve + isError，已在上文 isError 分支处理（pi 0.99.1/N1b）。
				// 非 Error 抛出物无法附消息，原样透传。P2-6：[cwd] 行之后再追加一行残留排查 note（若有）；
				// [cwd] 协同格式保持不变。ev-20260922-1eea28（B2）：授权丢弃失败结果同样落盘（先记再抛，不掩盖原生错误）。
				finishDiscardTicket(discardTicket, { ok: false, errorMessage: e instanceof Error ? e.message.slice(0, 400) : String(e).slice(0, 400) });
				// R5：throw 路径（timeout/abort/底层 throw）采真实错误——保持原 throw 语义，不附摘要
				if (debugCapture) collectBashDebugThrow(debugCapture, toolCallId, e);
				if (e instanceof Error) {
					const note = await finalizeFailure(e.message);
					// ev-20260925-287e93：双宿主映射时 [cwd] 行附 bash 侧路径（POSIX 形态即调用方书写形态），供双侧核对。
					const cwdLine = mappedBashSide !== null ? `[cwd] ${resolved}（bash 侧 ${mappedBashSide}）` : `[cwd] ${resolved}`;
					const capPrefix = timeoutCapNote ? `${timeoutCapNote}\n` : "";
					// B4B 修复轮 R01：throw 路径（timeout/abort）同样保留 rg 污染风险说明（同无 cwd 分支）
					const rgFailWarning2 = criticalBashAdvisory(command);
					throw new Error(`${capPrefix}${e.message}\n${cwdLine}${[wholeScanPreNote, note, rgFailWarning2].filter(Boolean).map((x) => `\n${x}`).join("")}`);
				}
				throw e;
			}
		},
	};
}
