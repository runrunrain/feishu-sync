/**
 * jsonl-framing.ts — B3（自建面处置设计 §B3）：协议无关的共享 LF 行帧模块。
 *
 * 统一两个消费面的流式行帧（替代各自手写实现）：
 *   - mcp-client.ts StdioMcpServer（NDJSON JSON-RPC stdio 子进程 stdout）
 *   - task-query.ts readSessionSummary（session 记录 JSONL 流式读取，B7）
 *
 * 修正的两个实际缺陷（设计 §B3 允许改变项）：
 *   1. chunk 解码：旧实现每 chunk 独立 `d.toString()`——多字节 UTF-8 字符跨 chunk 边界时
 *      两侧各产生 U+FFFD 替换字符（中文 3 字节/增补字符 4 字节载荷即损坏）。本模块用
 *      node:string_decoder 增量解码，不完整字符跨 chunk 保留到补齐。
 *   2. 残留缓冲生命周期：旧 MCP 实现的半帧缓冲是实例字段，child 退出/重启不清理——旧 child
 *      的半帧会拼进新 child 的首行（代际串帧）。本模块每实例独立缓冲，由消费者按 child 代际
 *      创建/dispose（见 mcp-client.ts 的逐 child 附件接线）。
 *
 * 分帧语义（与宿主内部 jsonl 行帧一致的设计决定，设计 §B3 差异表）：
 *   - 只按 LF 分帧；每条完整帧只剥离一个帧尾 CR（CRLF 兼容）。裸 CR 不是分隔符，
 *     U+2028/U+2029 不是分隔符（它们保留在记录内容中）。
 *   - EOF（finish）：未换行尾段按策略送一次（'emit'）或丢弃（'discard'）；尾帧与完整帧
 *     同样只剥离一个尾 CR，剥离后为空则不发。
 *   - 空行照常送消费者（由消费者决定忽略）。
 *
 * 非职责：不装 stream 监听器、不做 JSON.parse、不吞 onLine 异常、不管理 timeout/进程/
 * pending/IO 错误、不设行大小额度（协议治理留在消费者）。
 */
import { StringDecoder } from "node:string_decoder";

/** LF 行帧器实例（createLfFramer 返回；生命周期＝一次输入流会话）。 */
export interface LfFramer {
	/** 喂入原始字节块。增量解码后按 LF 输出完整记录（每条剥离一个帧尾 CR）；不完整多字节
	 *  字符保留在内部缓冲。终结后调用抛状态错误（防静默复用）。 */
	push(chunk: Buffer): void;
	/** 终结并 flush 解码器残余：tail='emit' 时非空未换行尾段送一次，'discard' 丢弃。
	 *  幂等——重复调用不重复出帧；先置终结态再回调，onLine 抛错不会导致重发。 */
	finish(tail: "emit" | "discard"): void;
	/** 丢弃内部残余并终结（不发尾帧）。幂等。 */
	dispose(): void;
}

/**
 * 创建 LF 行帧器。
 * @param onLine 每条完整记录的回调（同步；异常向上传播，本模块不吞）。
 */
export function createLfFramer(onLine: (line: string) => void): LfFramer {
	let decoder = new StringDecoder("utf8");
	let buffer = "";
	let terminal = false;

	return {
		push(chunk: Buffer): void {
			if (terminal) throw new Error("LfFramer 已终结（finish/dispose 后不可再输入）");
			buffer += decoder.write(chunk);
			for (;;) {
				const idx = buffer.indexOf("\n");
				if (idx === -1) break;
				const raw = buffer.slice(0, idx);
				buffer = buffer.slice(idx + 1);
				onLine(raw.endsWith("\r") ? raw.slice(0, -1) : raw);
			}
		},
		finish(tail: "emit" | "discard"): void {
			if (terminal) return;
			// 先置终结态并取空缓冲，再回调——回调抛错也不会重发尾帧（设计 §B3 生命周期）
			terminal = true;
			const rest = buffer + decoder.end();
			buffer = "";
			if (tail !== "emit") return;
			const line = rest.endsWith("\r") ? rest.slice(0, -1) : rest;
			if (line.length > 0) onLine(line);
		},
		dispose(): void {
			terminal = true;
			buffer = "";
			decoder = new StringDecoder("utf8");
		},
	};
}
