/**
 * resource-reader.ts — amagi_resource 工具（§3.2）。
 * P2-Major6 修复 TOCTOU：realpath 后用 fd 读取（O_NOFOLLOW）。
 * 显式读取返回完整资源；自动供给片段的预算由 context-event 单独管理。
 * v2-I2（方案 §4.3）：新增显式参数 enableFacet="batch"——仅 resource="tools"（工具面说明档）
 * 且参数明确给出时申请启用 task_batch 分面（经注入的 onEnableFacet 钩子走 tool-surface 治理：
 * 只追加/子进程拒绝/幂等）；普通资源读取不改工具面（纯读零副作用）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
import { normalizeToolArgumentArtifacts } from "./contracts/view.ts";
import { discoverAgents } from "./agents-loader.ts";
import { AGENT_ALIASES } from "./agent-aliases.ts";
import { roleChannelCapsSummary } from "./task-permission.ts";
import { harnessGuide, HARNESS_GUIDE_TOPICS } from "./harness-help.ts";
import { noteResourceRead } from "./context-event.ts";

// 注意：不要传 Darwin O_NOFOLLOW_ANY(0x20000000)——libuv 的 flag 转换拒绝未知位，openSync 直接 EINVAL（实测 macOS + pi Node 运行时必现）。

function isWithin(parent: string, child: string): boolean {
	const rel = path.relative(parent, child);
	return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
}

export function createResourceReaderTool(
	packageRoot: string,
	testHooks?: {
		afterResolve?: (candidate: string) => void;
		/** 分面启用通道（v2-I2 §4.3：组合根注入 tool-surface.enableFacet；子进程/未接线时明确拒绝）。 */
		onEnableFacet?: (facet: string) => { ok: boolean; code?: string; message: string; added?: readonly string[] };
	},
) {
	const resourcesRoot = fs.realpathSync(path.join(packageRoot, "resources"));
	const rulesRoot = fs.realpathSync(path.join(packageRoot, "rules"));

	let byId: Record<string, string> = {};
	const indexPath = path.join(resourcesRoot, "core", "index.json");
	try {
		const index = JSON.parse(fs.readFileSync(indexPath, "utf8"));
		if (Array.isArray(index.modules)) byId = Object.fromEntries(index.modules.map((m: any) => [m.id, path.join(resourcesRoot, "core", m.path)]));
	} catch {}

	const guideIds = ["guide", ...HARNESS_GUIDE_TOPICS.map((topic) => `guide-${topic}`)];
	const idList = [...Object.keys(byId), ...guideIds].join(", ");
	/** 工具面说明档 ID（§4.3「仅 resource=tools 且参数明确给出时申请启用」——含 I2 分面说明档 tools-facets）。 */
	const FACET_DOC_IDS = new Set(["tools", "tools-facets"]);

	// ev-20260923-93ede6（角色通道能力面速查）：agents canonical 资源尾部追加「角色通道上限」机器投影段。
	// 单源：agents/*.md frontmatter capabilities（discoverAgents 解析，非第二份手写配置）；旧八别名经
	// agent-aliases 归一后上限同目标 canonical 角色。可见性补丁——不改授权语义（请求不放大权限）；投影
	// 失败/零角色时退化为零追加（附录是增益不是前置条件，不反噬资源读取本体）。
	let cachedCapsAppendix: string | undefined;
	const capsAppendix = (): string => {
		if (cachedCapsAppendix !== undefined) return cachedCapsAppendix;
		try {
			const { agents } = discoverAgents(path.join(packageRoot, "agents"));
			if (agents.length === 0) return (cachedCapsAppendix = "");
			const lines: string[] = [];
			for (const a of [...agents].sort((x, y) => x.name.localeCompare(y.name))) {
				if (a.capabilitiesError !== undefined) {
					lines.push(`- ${a.name} 角色通道上限：capabilities 声明非法（fail-closed——该角色任务将被授权计算拒绝）`);
				} else if (a.capabilities === undefined) {
					lines.push(`- ${a.name} 角色通道上限：未声明（fail-closed——该角色任务将被授权计算拒绝）`);
				} else {
					lines.push(`- ${roleChannelCapsSummary(a.name, a.capabilities)}`);
				}
			}
			const aliasParts = Object.entries(AGENT_ALIASES).map(([alias, target]) => `${alias}→${target.agent}`);
			cachedCapsAppendix = [
				"",
				"## 角色通道上限（机器投影：agents/*.md capabilities 单源生成，勿手改）",
				"",
				...lines,
				"",
				`别名归一（通道上限同目标 canonical 角色的上列速查行）：${aliasParts.join("；")}。`,
				"",
				"说明：shell/mcp/lsp 是四方交集（请求∩角色上限∩用户授权∩后端可兑现）中的角色上限面——请求超出即整任务拒绝（required-channel-empty / request-exceeds-role-ceiling）。派发前可用 task_submit dryRun 预检；同格式速查行也出现在拒单文案与 dryRun 摘要中。",
			].join("\n");
		} catch { /* lint-exempt:附录投影失败不反噬资源读取本体 */ cachedCapsAppendix = ""; }
		return cachedCapsAppendix;
	};

	return {
		name: "amagi_resource",
		label: "Amagi Resource",
		description: `读取 amagi canonical 规则/模板资源。支持 canonical ID（${idList}）或 resources/rules 下的相对路径。enableFacet="batch"（仅 resource="tools" 时有效）显式启用 task_batch 高级分面。`,
		promptSnippet: `amagi_resource({ resource: "persona" })`,
		parameters: Type.Object({
			resource: Type.String({ description: `canonical ID 或相对路径` }),
			enableFacet: Type.Optional(StringEnum(["batch"], { description: "显式启用高级分面（仅 resource=tools 时有效；普通资源读取不改工具面）" })),
		}),
		async execute(_id: string, params: { resource: string; enableFacet?: "batch" }, _signal?: unknown, _onUpdate?: unknown, ctx?: { sessionManager?: { getSessionId?: () => string } }) {
			// ev-20261101-cbf452：成功读取 canonical 资源后登记会话级已读——context 供给不再对
			// 本会话已读全文的资源重复注入片段（guide/canonical 命中才登记；相对路径不在供给名单内）。
			const sessionId = ctx?.sessionManager?.getSessionId?.();
			const readSessionId = typeof sessionId === "string" && sessionId ? sessionId : "default";
			params = normalizeToolArgumentArtifacts(params); // ev-20260919+ev-20260920：null 键与 "null" 字符串伪影视为缺席（宿主路径另经注册接线）
			const resource = params.resource?.trim();
			if (!resource) return { content: [{ type: "text" as const, text: `参数不能为空。可用 ID: ${idList}` }], isError: true };
			// v2-I2：enableFacet 门控——仅工具面说明档可携带；普通资源携带即拒（不改工具面）。
			if (params.enableFacet !== undefined && !FACET_DOC_IDS.has(resource)) {
				return { content: [{ type: "text" as const, text: `enableFacet 仅在 resource="tools"（工具面说明档）时有效——普通资源读取不改工具面；当前 resource="${resource}"。去掉 enableFacet 参数即为纯读。` }], isError: true };
			}
			if (guideIds.includes(resource)) {
				const guide = harnessGuide(resource === "guide" ? "overview" : resource.slice(6));
				if (guide.ok) noteResourceRead(resource, readSessionId);
				return { content: [{ type: "text" as const, text: guide.text }], isError: !guide.ok };
			}

			const named = byId[resource];
			const candidate = named || path.resolve(packageRoot, resource);
			if (!fs.existsSync(candidate)) return { content: [{ type: "text" as const, text: `资源未找到: "${resource}"。\n可用 ID: ${idList}` }], isError: true };

			// P2-Major6: fd-bound read（防 TOCTOU：realpath → open → fstat → read 同一 fd）
			let realCandidate: string;
			try { realCandidate = fs.realpathSync(candidate); } catch { return { content: [{ type: "text" as const, text: `路径解析失败: "${resource}"` }], isError: true }; }

			const allowed = isWithin(resourcesRoot, realCandidate) || isWithin(rulesRoot, realCandidate);
			if (!allowed) return { content: [{ type: "text" as const, text: `资源越界: "${resource}" 不在 resources/ 或 rules/ 内。` }], isError: true };
			testHooks?.afterResolve?.(realCandidate);

			// O_NOFOLLOW 拒绝最终组件 symlink；路径中间组件由下方 post-open realpath+inode 复核保证。
			let fd: number;
			try {
				fd = fs.openSync(realCandidate, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
			} catch {
				return { content: [{ type: "text" as const, text: `无法安全读取: "${resource}"` }], isError: true };
			}
			try {
				const fdStat = fs.fstatSync(fd);
				if (!fdStat.isFile()) return { content: [{ type: "text" as const, text: `不是文件: "${resource}"` }], isError: true };
				// Linux 从 /proc/self/fd 获取 fd 的真实目标；其他平台 realpath 复核 + dev/ino 比对，防读取期路径替换。
				let verifiedReal: string, pathStat: fs.Stats;
				try {
					verifiedReal = process.platform === "linux" ? fs.realpathSync(`/proc/self/fd/${fd}`) : fs.realpathSync(realCandidate);
					pathStat = fs.statSync(verifiedReal);
				}
				catch { return { content: [{ type: "text" as const, text: `读取期间路径发生变化: "${resource}"` }], isError: true }; }
				if (!(isWithin(resourcesRoot, verifiedReal) || isWithin(rulesRoot, verifiedReal)) || pathStat.dev !== fdStat.dev || pathStat.ino !== fdStat.ino) {
					return { content: [{ type: "text" as const, text: `读取期间路径越界或发生替换: "${resource}"` }], isError: true };
				}
				const buf = fs.readFileSync(fd);
				// fd 读取成功且为 canonical id 命中（非任意相对路径）——登记已读（供给去重）。
				if (named) noteResourceRead(resource, readSessionId);
				let content = buf.toString("utf8");
				// ev-20260923-93ede6：agents canonical 资源尾部追加通道上限投影（纯可见性增益；投影不可用时零追加）。
				if (resource === "agents") content += capsAppendix();
				// v2-I2（§4.3）：读取成功后申请启用分面（面操作零 spawn 零任务状态写；拒绝路径明确回绝）。
				if (params.enableFacet !== undefined) {
					if (process.env.AMAGI_SUBAGENT === "1") {
						return { content: [{ type: "text" as const, text: `[分面启用被拒] 子进程（AMAGI_SUBAGENT）不能启用派发分面——派发分面只对 Leader 会话开放（防递归派发）；资源纯读不受影响（去掉 enableFacet 参数重读即可）。\n\n${content}` }], isError: true };
				}
					const hook = testHooks?.onEnableFacet;
					if (!hook) {
						return { content: [{ type: "text" as const, text: `[分面启用被拒] 本进程未接分面启用通道（组合根未接线 tool-surface）——enableFacet 仅在 Leader 会话可用。\n\n${content}` }], isError: true };
					}
					const facet = params.enableFacet;
					const r = hook(facet);
					if (!r.ok) {
						return { content: [{ type: "text" as const, text: `[分面启用被拒 code=${r.code ?? "unknown"}] ${r.message}\n\n${content}` }], isError: true };
					}
					return { content: [{ type: "text" as const, text: `${content}\n\n[分面已启用] ${facet}: ${r.message}` }] };
				}
				return { content: [{ type: "text" as const, text: content }] };
			} finally {
				fs.closeSync(fd);
			}
		},
	};
}
