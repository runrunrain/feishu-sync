/**
 * task-write-log.ts — ev-20260903-64641c（P0）：任务写入登记（「子 Agent 写入」vs「外部进程写入」的归因数据源）。
 *
 * 实战事故：同会话主上侧另一进程与子 Agent 共享同一工作树并行写入，结算时 evidence.ts 的
 * fresh 差集（结算 git status vs 派发基线快照）把外部进程写入归因为子 Agent 改动，Leader
 * 误判越界令回滚，外部进程合法半成品被毁。本模块补上第三档归因数据：子进程侧的
 * write/edit/bash 覆盖层在**成功写盘后**登记被写绝对路径，结算侧 evidence.ts 用
 * readTaskWrites(taskId) 逐路径比对——命中 = 确认本任务写入；未命中 = 「外部写入嫌疑」
 * （弱断言警示，不阻断、不作为回滚依据）。
 *
 * 归因口径（轻护栏强感知）：
 *   - 登记 = 确认写入；未登记 ≠ 一定外部（bash 复杂写法覆盖不了）——消费侧文案必须弱断言；
 *   - 仅子 Agent 进程登记（检测 AMAGI_TASK_ID；Leader 主进程未设 → no-op 零开销）；
 *   - 登记数据绝不影响执行路径（任何异常静默；登记失败不影响工具回执）；
 *   - 有界：单任务登记 ≤512 行，超界截断保留最新；结算收尾链消费完后 clearTaskWrites 清理。
 *   - 可回收（ev-20260910-0f59ce）：error/blocked 保留登记由 GC 两档保守回收——链闭合定向
 *     回收（同会话链尾成功终态清前驱，reapTaskWrites）+ TTL/上限 LRU 低频清扫（sweepTaskWrites）；
 *     仅 Leader 侧执行，活跃链保护集由调用方注入。
 *
 * 独立共享模块的原因（同 fs-mutation-tracker 纪律）：bash/write/edit 覆盖层（登记方）与
 * evidence.ts（消费方）互不 import——把两套覆盖语义焊死会引入循环边；本模块只依赖
 * data-dir 与 shell-lexer 纯函数，零 pi 依赖、无循环边。
 *
 * ev-20261019-a7519f（任务启动状态快照 sidecar）：本目录额外存放 <safeTaskId>.start-state.json
 * ——派发时（runPiTask spawn 前，与 gitBaseline 同点）由 Leader 侧写入的「派发前已改动路径」
 * 内容状态基准（path→mtime+size+小文件 sha1，有界 ≤TASK_START_STATE_ENTRY_CAP 条）。产物摘要
 * 以它为基准计算任务期间净变化（新增/修改/删除），对 bash 写入同样生效（不依赖写日志登记）。
 * 存储语义：首写优先（resume/修复轮保留最早基准——净变化从首个 spawn 起算覆盖整链）；
 * done/truncated 终态随写入登记一并清理，error/blocked 保留（resume 归因），GC 同口径回收。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { amagiDataDir } from "./data-dir.ts";
import { shellSegments, executableWords } from "./shell-lexer.ts";

/** 单任务登记行数上限（有界：超界截断保留最新，防长任务 jsonl 无限增长）。 */
export const TASK_WRITE_LOG_MAX_LINES = 512;

export interface TaskWriteRecord {
	/** 被写目标绝对路径（登记方负责解析；未 stat、未展开通配）。 */
	file: string;
	/** 触发工具名（write | edit | bash）。 */
	tool: string;
	/** 登记时刻 epoch ms。 */
	at: number;
}

/** taskId → 安全文件名片段（同 result-fold.ts 兑底落盘的白名单化口径）。 */
function safeTaskId(taskId: string): string {
	return String(taskId).replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 64) || "unknown";
}

/** 登记文件路径：<amagiData>/task-writes/<safeTaskId>.jsonl（子进程与 Leader 默认同数据目录）。 */
function taskWriteFile(taskId: string): string {
	return path.join(amagiDataDir(), "task-writes", `${safeTaskId(taskId)}.jsonl`);
}

/**
 * 登记一条本任务写入（供结算三档归因）。仅子 Agent 进程生效：检测 process.env.AMAGI_TASK_ID
 * （task-run spawn 注入；Leader 主进程未设 → no-op 零开销）。追加一行 JSON {file, tool, at}；
 * 超 512 行截断保留最新；任何失败静默（归因数据绝不影响写入路径）。
 */
export function recordTaskWrite(absPath: string, tool: string): void {
	const taskId = process.env.AMAGI_TASK_ID;
	if (!taskId) return; // Leader/主进程（未派发上下文）：零开销 no-op
	try {
		const file = taskWriteFile(taskId);
		fs.mkdirSync(path.dirname(file), { recursive: true });
		let lines: string[] = [];
		try { lines = fs.readFileSync(file, "utf8").split("\n").filter(Boolean); } catch { /* 首次登记（文件不存在） */ }
		lines.push(JSON.stringify({ file: String(absPath), tool: String(tool).slice(0, 32), at: Date.now() }));
		const overflow = lines.length - TASK_WRITE_LOG_MAX_LINES;
		if (overflow > 0) lines = lines.slice(overflow); // 截断保留最新（有界）
		fs.writeFileSync(file, lines.join("\n") + "\n", "utf8");
	} catch { /* 登记失败静默（弱断言归因数据，宁缺不影响主流程） */ }
}

/** 读取任务写入登记（文件不存在/不可读 → 空数组；单行损坏跳过——弱断言数据口径）。 */
export function readTaskWrites(taskId: string): TaskWriteRecord[] {
	if (!taskId) return [];
	try {
		const raw = fs.readFileSync(taskWriteFile(taskId), "utf8");
		const out: TaskWriteRecord[] = [];
		for (const line of raw.split("\n")) {
			if (!line.trim()) continue;
			try {
				const v = JSON.parse(line) as { file?: unknown; tool?: unknown; at?: unknown };
				if (typeof v.file === "string" && typeof v.tool === "string" && typeof v.at === "number") out.push({ file: v.file, tool: v.tool, at: v.at });
			} catch { /* 单行损坏跳过 */ }
		}
		return out;
	} catch {
		return [];
	}
}

/** 清理任务写入登记文件（结算收尾链消费完后调用；不存在时静默幂等）。 */
export function clearTaskWrites(taskId: string): void {
	if (!taskId) return;
	try { fs.rmSync(taskWriteFile(taskId), { force: true }); } catch { /* 静默 */ }
}

// ── 任务启动状态快照 sidecar（ev-20261019-a7519f）────────────────────────────
// 背景（evolution ev-20261019-a7519f）：existing 共享树派发前常有大量未提交改动，产物摘要的
// 唯一基线是 git status porcelain 行集——行级差集对「派发前已改动路径被任务再次修改」不敏感
// （状态行不变即不可见），diff --stat 恒为 vs HEAD 绝对口径（数字含派发前改动），写日志缺失时
// 还回退全树统计。本 sidecar 为产物摘要补上内容级基准：派发时对基线脏路径逐个记录
// mtime+size（小文件附 sha1 内容指纹），结算侧据此计算任务期间净变化。类型定义放本模块
// （存储方），采集/计算在 evidence.ts（消费方）——避免反向依赖成环。

/** 快照路径条数上限（与 TASK_WRITE_LOG_MAX_LINES 同量级；超界截断置 truncated，诚实标注）。 */
export const TASK_START_STATE_ENTRY_CAP = 512;

/** 链首轮 porcelain 起点的保存上限（UTF-8 字节，evolve 2.21.11 复审 F-R4-3）。porcelain 只是路径行，
 *  与内容快照（逐文件 stat/sha1，≤TASK_START_STATE_ENTRY_CAP 条）成本不同量级，不共用条数上限——
 *  旧口径超 512 条即不保存，大预脏树回退次轮基线，重现「无净变化」与未跟踪段矛盾。超此字节上限
 *  （约数万路径）才回退，并由摘要截断横幅披露。 */
export const TASK_START_PORCELAIN_MAX_BYTES = 4 * 1024 * 1024;

/** porcelain 行集的序列化字节量（与 sidecar JSON 落盘同口径的近似：每行 UTF-8 字节 + 分隔）。 */
export function porcelainBytes(lines: readonly string[]): number {
	let n = 0;
	for (const l of lines) n += Buffer.byteLength(l, "utf8") + 4;
	return n;
}

/** 单条启动状态：派发时点的文件内容状态。 */
export interface TaskStartStateEntry {
	/** 派发时物理绝对路径（physicalPathDeep 口径归一）。 */
	file: string;
	/** 派发时 mtimeMs；-1 = 派发时不存在（porcelain "D" 侧 / rename 旧侧）。 */
	mtimeMs: number;
	/** 派发时字节数；-1 = 不存在。 */
	size: number;
	/** 内容指纹（sha1 hex）：采集时 ≤64KB 且未触总额预算的小文件；缺省回退 mtime+size 判定。 */
	sha1?: string;
}

/** 任务启动状态快照（sidecar 载荷；采集逻辑见 evidence.ts takeWorkspaceStateSnapshot）。 */
export interface TaskStartStateSnapshot {
	v: 1;
	/** 采集 cwd（信息性；结算侧不据此解析路径）。 */
	cwd: string;
	/** 派发时仓库根物理路径——结算侧 repoRoot 不一致（跨树/搬仓）→ 弃用快照，不跨树比较。 */
	repoRoot: string;
	collectedAt: number;
	cap: number;
	/** 基线脏路径超 cap 截断（超界路径净变化不可判，消费侧如实标注）。 */
	truncated: boolean;
	entries: TaskStartStateEntry[];
	/** ev-20261111-fix（diting F06）：链首轮 porcelain 行集（整链时间基准）。首写优先与 entries
	 *  同点——后续轮 RunResult.gitBaseline 含前轮新增产物，若摘要仍按次轮 porcelain 算 fresh，
	 *  首轮新建文件会被从净变化中排除（「无净变化」假阴性，与未跟踪段自相矛盾）。提供时
	 *  collectArtifactDiffSummary 以它替代次轮 baseline 做整链差集/净变化/基线计数；缺省（旧
	 *  sidecar / 超界不入）回退次轮口径。 */
	baselinePorcelain?: string[];
}

/** sidecar 文件路径：<amagiData>/task-writes/<safeTaskId>.start-state.json（与写入登记同目录同生命周期）。 */
function taskStartStateFile(taskId: string): string {
	return path.join(amagiDataDir(), "task-writes", `${safeTaskId(taskId)}.start-state.json`);
}

/**
 * 写入启动状态快照（Leader 侧派发点调用；显式 taskId，不经 AMAGI_TASK_ID 门——写入登记是
 * 子进程侧登记，快照是父进程侧采集，守卫方向不同）。**首写优先**：已存在即跳过——resume/
 * 修复轮是新 runPiTask 调用，但净变化须从任务链首个 spawn 起算，后到快照不覆盖。失败静默
 * （缺快照时摘要回退既有行级差集口径，绝不影响派发路径）。
 */
export function recordTaskStartState(taskId: string, snap: TaskStartStateSnapshot): void {
	if (!taskId) return;
	try {
		const file = taskStartStateFile(taskId);
		if (fs.existsSync(file)) return; // 首写优先：保留任务链最早基准
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.writeFileSync(file, JSON.stringify(snap), "utf8");
	} catch { /* lint-exempt:sidecar 落盘失败静默——摘要回退既有差集口径，不阻派发 */ }
}

/** 读取启动状态快照（不存在/损坏/形状不符 → null：明确不可用，消费侧回退，不猜测）。 */
export function readTaskStartState(taskId: string): TaskStartStateSnapshot | null {
	if (!taskId) return null;
	try {
		const raw = JSON.parse(fs.readFileSync(taskStartStateFile(taskId), "utf8")) as Record<string, unknown>;
		if (raw.v !== 1 || typeof raw.cwd !== "string" || typeof raw.repoRoot !== "string") return null;
		if (typeof raw.collectedAt !== "number" || typeof raw.cap !== "number" || typeof raw.truncated !== "boolean") return null;
		if (!Array.isArray(raw.entries)) return null;
		const entries: TaskStartStateEntry[] = [];
		for (const e of raw.entries) {
			if (typeof e !== "object" || e === null) return null;
			const o = e as Record<string, unknown>;
			if (typeof o.file !== "string" || typeof o.mtimeMs !== "number" || typeof o.size !== "number") return null;
			if (o.sha1 !== undefined && typeof o.sha1 !== "string") return null;
			entries.push({ file: o.file, mtimeMs: o.mtimeMs, size: o.size, ...(o.sha1 === undefined ? {} : { sha1: o.sha1 }) });
		}
		// ev-20261111-fix（diting F06）：可选链首 porcelain（形状不符丢弃字段回退旧口径，不拒收整份快照）
		const baselinePorcelain = Array.isArray(raw.baselinePorcelain) && raw.baselinePorcelain.every((l) => typeof l === "string")
			? (raw.baselinePorcelain as string[])
			: undefined;
		return { v: 1, cwd: raw.cwd, repoRoot: raw.repoRoot, collectedAt: raw.collectedAt, cap: raw.cap, truncated: raw.truncated, entries, ...(baselinePorcelain !== undefined ? { baselinePorcelain } : {}) };
	} catch {
		/* lint-exempt:sidecar 不存在/损坏 → null（明确不可用，不猜测） */
		return null;
	}
}

/** 清理启动状态快照（done/truncated 终态与 clearTaskWrites 同点调用；幂等）。 */
export function clearTaskStartState(taskId: string): void {
	if (!taskId) return;
	try { fs.rmSync(taskStartStateFile(taskId), { force: true }); } catch { /* lint-exempt:清理幂等，残留仅占临时空间 */ }
}

/**
 * 测试隔离：清空当前 AMAGI_DATA_DIR 下的 task-writes 目录与 GC 审计日志，复位清扫节流。
 * 仅在 AMAGI_DATA_DIR 显式注入（测试契约）时生效——绝不触碰用户默认数据目录。
 */
export function resetTaskWriteLogForTest(): void {
	lastSweepAt = 0;
	if (!process.env.AMAGI_DATA_DIR) return;
	try { fs.rmSync(path.join(amagiDataDir(), "task-writes"), { recursive: true, force: true }); } catch { /* 静默 */ }
	try { fs.rmSync(path.join(amagiDataDir(), "task-writes-gc.log"), { force: true }); } catch { /* 静默 */ }
}

// ── 登记回收 GC（ev-20260910-0f59ce，P3）────────────────────────────────────
// 背景：ev-20260910-8fbe4e 起 error 终态保留登记（resume 归因 / 迟终态回推重建现场报告），
// finalizer 成功终态只清新 taskId、blocked 永不清理——跨 taskId resume 的旧 error 文件
// 在 <amagiData>/task-writes/ 慢累积无回收方。本段补两档保守回收（组合使用）：
//   ① 链闭合定向回收（reapTaskWrites）：会话链（registry sessionId）尾节点成功终态时，
//      由调用方确认「前驱已收口、不再可 resume」后一次清掉（活跃链由调用方排除，本模块不越权猜测）；
//   ② 低频清扫（sweepTaskWrites）：TTL（mtime 超阈且不在保护集）+ 文件数上限 LRU 兜底
//      （超限才清，正常零动作）——防多会话/长驻进程残留无界。
// 纪律：宁可慢回收不可误删活跃链登记。仅 Leader 侧清扫：AMAGI_TASK_ID 置位的子进程直接跳过
// （子进程 registry 为空、保护集不可信，且失败任务登记可能仍被上级消费）；未隔离 node:test
// 进程同样跳过（见 gcBlockedInUnisolatedTest，防测试删真实数据）。保护集由调用方从
// task-registry 注入（本模块保持零 pi 依赖）。回收动作写有界审计日志（task-writes-gc.log，
// ≤256 行自截断），可事后追问「谁在何时删了哪份登记、原始 mtime/字节数」。

/** 清扫节流基线（同进程两次清扫最小间隔；resetTaskWriteLogForTest 复位）。 */
let lastSweepAt = 0;

/** TTL 默认 24h：error/blocked 登记保留「跨轮 resume 归因 + 迟终态回推」窗口，超窗且不在保护集才回收。 */
export const TASK_WRITES_TTL_DEFAULT_MS = 24 * 60 * 60 * 1000;
/** 登记文件数上限（LRU 兜底）：单文件 ≤512 行有界，上限保证目录总占用有界（正常远低于此，不动作）。 */
export const TASK_WRITES_MAX_FILES_DEFAULT = 200;
/** 低频节流：同进程两次清扫的最小间隔（30min）——登记增速慢，无需高频扫描。 */
export const TASK_WRITES_SWEEP_INTERVAL_MS = 30 * 60 * 1000;
/** 上限兜底的最小年龄：文件满一个清扫周期才有资格被 LRU 回收——给迟终态回推/证据消费留窗口。 */
const TASK_WRITES_CAP_MIN_AGE_MS = TASK_WRITES_SWEEP_INTERVAL_MS;
/** 审计日志保留行数（回收动作可追溯，日志自身有界，不成为新的泄漏源）。 */
const TASK_WRITES_GC_LOG_MAX_LINES = 256;

// ── GC 环境开关（env-knobs 已登记；同步改 docs/env-knobs.md）──
/** 总开关：`AMAGI_TASK_WRITES_GC=0/false/off` 关闭登记回收（链闭合定向 + TTL/上限清扫；不影响收尾链对本次任务自身的清理）。 */
export function taskWritesGcEnabled(): boolean {
	const v = process.env.AMAGI_TASK_WRITES_GC?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}
/** TTL 阈值（默认 24h）：未设/空/非有限数字回落默认，`<=0` 关闭 TTL 回收。 */
export function taskWritesTtlEnvMs(): number {
	const s = process.env.AMAGI_TASK_WRITES_TTL_MS;
	if (s === undefined || s.trim() === "") return TASK_WRITES_TTL_DEFAULT_MS;
	const raw = Number(s);
	return Number.isFinite(raw) ? raw : TASK_WRITES_TTL_DEFAULT_MS;
}
/** 文件数上限（默认 200）：未设/空/非有限数字回落默认，`<=0` 关闭上限回收。 */
export function taskWritesMaxFilesEnv(): number {
	const s = process.env.AMAGI_TASK_WRITES_MAX_FILES;
	if (s === undefined || s.trim() === "") return TASK_WRITES_MAX_FILES_DEFAULT;
	const raw = Number(s);
	return Number.isFinite(raw) ? raw : TASK_WRITES_MAX_FILES_DEFAULT;
}

/** 回收原因：chain=会话链闭合定向回收；ttl=陈旧登记；cap=文件数上限 LRU 兜底。 */
export type TaskWritesReapReason = "chain" | "ttl" | "cap";

export interface TaskWritesReapEvent {
	/** 登记文件键（safeTaskId 白名单化片段，即文件名去掉 .jsonl——审计可追溯到被删文件）。 */
	taskId: string;
	reason: TaskWritesReapReason;
	/** 被删文件绝对路径。 */
	file: string;
	/** 回收前文件 mtime / 字节数（stat 失败为 null）。 */
	mtimeMs: number | null;
	bytes: number | null;
	/** 回收动作时刻 epoch ms。 */
	at: number;
}

export interface TaskWritesSweepResult {
	/** true = 本次真实执行了扫描。 */
	scanned: boolean;
	/** true = 被非 Leader 身份或未隔离 node:test 进程跳过（两者都不应动真实登记）。 */
	disabled: boolean;
	/** true = 距上次扫描不足节流间隔（force 可绕过）。 */
	throttled: boolean;
	/** 扫描时登记文件总数（清扫前）。 */
	total: number;
	reaped: TaskWritesReapEvent[];
}

export interface TaskWritesSweepOpts {
	/** 保护集（活跃链 taskId，调用方从 registry 注入）：命中的登记文件绝不回收。 */
	protect?: Iterable<string>;
	/** 注入当前时刻（测试用；缺省 Date.now()）。 */
	now?: number;
	/** true = 绕过节流（测试/显式运维触发）。 */
	force?: boolean;
	/** TTL 覆盖（缺省 TASK_WRITES_TTL_DEFAULT_MS；<=0 关闭 TTL 回收）。 */
	ttlMs?: number;
	/** 文件数上限覆盖（缺省 TASK_WRITES_MAX_FILES_DEFAULT；<=0 关闭上限回收）。 */
	maxFiles?: number;
}

/**
 * 未隔离的 node:test 进程绝不动生产登记：node:test 子进程（NODE_TEST_CONTEXT）且未显式注入
 * AMAGI_DATA_DIR 时跳过（同 journal.ts 回归守卫的动机）。背景：无 isolate-env 的测试
 * （registry.test.mjs 等）会在真实 HOME 下驱动终态迁移，若无此守卫，自动清扫会删掉用户真实
 * task-writes 中的陈旧登记。显式注入 AMAGI_DATA_DIR 即视为已隔离（该变量本就是测试/运维注入契约）。
 */
function gcBlockedInUnisolatedTest(): boolean {
	return Boolean(process.env.NODE_TEST_CONTEXT && !process.env.AMAGI_DATA_DIR);
}

interface TaskWriteFileEntry { file: string; taskId: string; mtimeMs: number; bytes: number; }

/** sidecar 后缀（start-state 快照；GC 与写入登记同口径回收，见模块头 ev-20261019-a7519f 段）。 */
const START_STATE_SUFFIX = ".start-state.json";

/** 登记目录内的可回收文件清单（.jsonl 写入登记 + .start-state.json 快照；并发删除/不可读跳过）。 */
function listTaskWriteFiles(): TaskWriteFileEntry[] {
	let names: string[];
	try { names = fs.readdirSync(path.join(amagiDataDir(), "task-writes")); } catch { return []; }
	const out: TaskWriteFileEntry[] = [];
	for (const name of names) {
		const isWrites = name.endsWith(".jsonl");
		const isStart = name.endsWith(START_STATE_SUFFIX);
		if (!isWrites && !isStart) continue;
		const file = path.join(amagiDataDir(), "task-writes", name);
		try {
			const st = fs.statSync(file);
			if (!st.isFile()) continue;
			out.push({ file, taskId: name.slice(0, isWrites ? -6 : -START_STATE_SUFFIX.length), mtimeMs: st.mtimeMs, bytes: st.size });
		} catch { /* 并发删除/不可读：跳过 */ }
	}
	return out;
}

/** 删除单个登记文件（force 语义：不存在不报错）；成功返回审计事件，失败返回 null（下次清扫重试）。 */
function reapEntry(file: string, taskKey: string, reason: TaskWritesReapReason, mtimeMs: number | null, bytes: number | null, at: number): TaskWritesReapEvent | null {
	try {
		fs.rmSync(file, { force: true });
		return { taskId: taskKey, reason, file, mtimeMs, bytes, at };
	} catch {
		return null; // 回收失败静默：文件仍在，下次清扫重试
	}
}

/** 审计日志落盘（追加 + 自截断保留最新；失败静默——审计不得反噬回收本身）。 */
function appendTaskWritesGcLog(events: TaskWritesReapEvent[]): void {
	if (events.length === 0) return;
	const logFile = path.join(amagiDataDir(), "task-writes-gc.log");
	try {
		let lines: string[] = [];
		try { lines = fs.readFileSync(logFile, "utf8").split("\n").filter(Boolean); } catch { /* 首次写入 */ }
		for (const e of events) {
			lines.push(JSON.stringify({
				at: new Date(e.at).toISOString(), taskId: e.taskId, reason: e.reason,
				mtime: e.mtimeMs === null ? null : new Date(e.mtimeMs).toISOString(), bytes: e.bytes,
			}));
		}
		const overflow = lines.length - TASK_WRITES_GC_LOG_MAX_LINES;
		if (overflow > 0) lines = lines.slice(overflow);
		fs.writeFileSync(logFile, lines.join("\n") + "\n", "utf8");
	} catch { /* 审计失败静默 */ }
}

/**
 * 定向回收（链闭合路径）：删除给定 taskId 的登记文件并写审计日志。调用方负责只传已收口前驱
 * （活跃链保护由调用方与 sweep 的 protect 集承担）；AMAGI_TASK_ID 置位的子进程与未隔离
 * node:test 进程跳过（不自清现场/不删生产数据）。不存在/删除失败的文件零动作零事件（幂等）。
 */
export function reapTaskWrites(taskIds: Iterable<string>, reason: TaskWritesReapReason): TaskWritesReapEvent[] {
	const out: TaskWritesReapEvent[] = [];
	if (!taskWritesGcEnabled()) return out; // 总开关关闭：定向回收 no-op
	if (process.env.AMAGI_TASK_ID) return out; // 仅 Leader 侧回收
	if (gcBlockedInUnisolatedTest()) return out;
	const seen = new Set<string>();
	for (const taskId of taskIds) {
		if (!taskId) continue;
		const key = safeTaskId(taskId);
		if (seen.has(key)) continue;
		seen.add(key);
		// ev-20261019-a7519f：同 taskId 的 start-state 快照一并回收（同生命周期；不存在零动作）
		for (const file of [taskWriteFile(taskId), taskStartStateFile(taskId)]) {
			let mtimeMs: number | null = null, bytes: number | null = null;
			try { const st = fs.statSync(file); mtimeMs = st.mtimeMs; bytes = st.size; } catch { continue; } // 不存在：无动作
			const ev = reapEntry(file, key, reason, mtimeMs, bytes, Date.now());
			if (ev) out.push(ev);
		}
	}
	appendTaskWritesGcLog(out);
	return out;
}

/**
 * 低频清扫（TTL + 上限 LRU 兜底）。仅 Leader 侧（AMAGI_TASK_ID 置位直接 disabled）；
 * 未隔离 node:test 进程 disabled；节流窗口内 throttled 零动作。protect 集内文件永不回收。
 * 上限兜底只回收「满一个清扫周期且不在 protect」的最旧文件——正常远低于上限，零动作。
 */
export function sweepTaskWrites(opts: TaskWritesSweepOpts = {}): TaskWritesSweepResult {
	const now = opts.now ?? Date.now();
	const result: TaskWritesSweepResult = { scanned: false, disabled: false, throttled: false, total: 0, reaped: [] };
	if (!taskWritesGcEnabled()) { result.disabled = true; return result; }
	if (process.env.AMAGI_TASK_ID) { result.disabled = true; return result; }
	if (gcBlockedInUnisolatedTest()) { result.disabled = true; return result; }
	if (!opts.force && now - lastSweepAt < TASK_WRITES_SWEEP_INTERVAL_MS) { result.throttled = true; return result; }
	lastSweepAt = now;
	const protect = new Set<string>();
	for (const id of opts.protect ?? []) if (id) protect.add(safeTaskId(id));
	const files = listTaskWriteFiles();
	result.total = files.length;
	result.scanned = true;
	const events: TaskWritesReapEvent[] = [];
	const ttlMs = opts.ttlMs ?? taskWritesTtlEnvMs();
	const survivors: TaskWriteFileEntry[] = [];
	for (const f of files) {
		if (protect.has(f.taskId) || !Number.isFinite(ttlMs) || ttlMs <= 0 || now - f.mtimeMs < ttlMs) { survivors.push(f); continue; }
		const ev = reapEntry(f.file, f.taskId, "ttl", f.mtimeMs, f.bytes, now);
		if (ev) events.push(ev); else survivors.push(f); // 删除失败视同仍在（下次重试）
	}
	const rawMax = opts.maxFiles ?? taskWritesMaxFilesEnv();
	const maxFiles = Number.isFinite(rawMax) ? Math.floor(rawMax) : TASK_WRITES_MAX_FILES_DEFAULT;
	if (maxFiles > 0 && survivors.length > maxFiles) {
		let need = survivors.length - maxFiles;
		const candidates = survivors
			.filter((f) => !protect.has(f.taskId) && now - f.mtimeMs >= TASK_WRITES_CAP_MIN_AGE_MS)
			.sort((a, b) => a.mtimeMs - b.mtimeMs); // 最老优先（LRU）
		for (const f of candidates) {
			if (need <= 0) break;
			const ev = reapEntry(f.file, f.taskId, "cap", f.mtimeMs, f.bytes, now);
			if (ev) { events.push(ev); need--; }
		}
	}
	appendTaskWritesGcLog(events);
	result.reaped = events;
	return result;
}

// ── bash 写命令尽力解析（ev-20260903-64641c；口径同 fs-mutation-tracker：不追求完备）──
// 覆盖：重定向 > >> 目标、tee 目标、sed -i 目标、cp/mv 的目标侧、mkdir/touch 操作数。
// 未覆盖的写法（heredoc 直写、管道 sed 无 -i、$() 展开目标等）静默跳过——未登记 ≠ 一定
// 外部，消费侧文案必须弱断言。仅在命令**成功执行后**调用（失败命令的写未必生效）。

/** 快速预筛：不含写命令特征词/重定向符号时跳过词法解析（精确词边界）。 */
const BASH_WRITE_PRE_FILTER = /\b(?:tee|sed|cp|mv|mkdir|touch)\b|>>?/;

/** 各可执行名的「取值选项」集合（这些选项的下一个 token 是选项值，不是操作数/目标）。 */
const BASH_WRITE_OPT_VALUES: Record<string, Set<string>> = {
	tee: new Set(),
	sed: new Set(["-e", "--expression", "-f", "--file", "--sandbox"]),
	cp: new Set(["-t", "--target-directory", "-S", "--suffix", "--backup", "-Z", "--context"]),
	mv: new Set(["-t", "--target-directory", "-S", "--suffix", "--backup", "-Z", "--context"]),
	mkdir: new Set(["-m", "--mode", "-Z", "--context"]),
	touch: new Set(["-d", "--date", "-r", "--reference", "-t"]),
};

/** 操作数不可精确解析（空/stdin 标记/选项/变量/通配/命令替换）→ 跳过登记（同 fs-mutation-tracker 口径）。 */
function opaqueOperand(op: string): boolean {
	return !op || op === "-" || op.startsWith("$") || op.includes("*") || op.includes("?") || op.includes("$(");
}

/** `~` / `~/x` 展开为 homedir（其余原样；尽力口径）。 */
function expandTilde(op: string): string {
	if (op === "~") return os.homedir();
	if (op.startsWith("~/")) return path.join(os.homedir(), op.slice(2));
	return op;
}

/** 相对操作数按该次 bash 的执行 cwd 解析、绝对路径归一。 */
function resolveOperand(op: string, baseCwd: string): string {
	const expanded = expandTilde(op);
	return path.isAbsolute(expanded) ? path.normalize(expanded) : path.resolve(baseCwd, expanded);
}

/**
 * 解析命令文本中的明确写目标并逐个登记（只登记，不执行、不 stat）。
 * 供 bash-override 在命令**成功执行后**调用；未设 AMAGI_TASK_ID 时整体 no-op。
 * 任何解析异常静默返回（尽力口径，绝不影响执行路径）。
 */
export function recordBashWriteTargets(command: string, baseCwd: string): void {
	try {
		if (!process.env.AMAGI_TASK_ID) return;
		if (typeof command !== "string" || !BASH_WRITE_PRE_FILTER.test(command)) return;
		for (const segment of shellSegments(command)) {
			// ① 重定向目标：`>f` / `>>f` / `2>f` / `> f` / `&>f` 等（引号内 payload 不以 > 开头，天然不误触）
			for (let i = 0; i < segment.length; i++) {
				const m = segment[i].match(/^(?:\d*|&)>{1,2}(.*)$/);
				if (!m) continue;
				let target = m[1];
				if (target === "") {
					const next = segment[i + 1];
					if (!next || opaqueOperand(next)) continue;
					target = next;
				}
				if (target.startsWith("&") || target === "/dev/null") continue; // fd 聚合（2>&1）与黑洞跳过
				recordTaskWrite(resolveOperand(target, baseCwd), "bash");
			}
			// ② 可执行名维度的目标解析（剥 env/sudo/timeout 等包裹后取段首可执行名）
			const words = executableWords(segment, true);
			const exe = path.basename(words[0] ?? "").toLowerCase();
			const optValues = BASH_WRITE_OPT_VALUES[exe];
			if (!optValues) continue;
			const operands: string[] = [];
			let hasInPlace = false;
			let targetDir: string | null = null; // cp/mv -t DIR 形态的目标目录
			for (let i = 1; i < words.length; i++) {
				const w = words[i];
				if (w === "--") { operands.push(...words.slice(i + 1)); break; }
				if (w.startsWith("-") && w !== "-") {
					const eq = w.indexOf("=");
					const option = eq >= 0 ? w.slice(0, eq) : w;
					if (optValues.has(option)) {
						if (eq >= 0) {
							if (option === "-t" || option === "--target-directory") targetDir = w.slice(eq + 1);
						} else {
							const val = words[i + 1];
							if (option === "-t" || option === "--target-directory") targetDir = typeof val === "string" ? val : null;
							i++; // 取值选项：跳过其值 token
						}
					}
					if (exe === "sed" && /^-{1,2}i/.test(w)) hasInPlace = true; // -i / -i.bak / --in-place[=bak]
					continue;
				}
				operands.push(w);
			}
			if (exe === "sed" && !hasInPlace) continue; // 无 -i 的 sed 不写盘
			if (exe === "cp" || exe === "mv") {
				if (targetDir && !opaqueOperand(targetDir)) recordTaskWrite(resolveOperand(targetDir, baseCwd), "bash"); // -t DIR：登记目标目录（目录内逐文件不可精确枚举）
				else if (operands.length >= 2) {
					const last = operands[operands.length - 1];
					if (!opaqueOperand(last)) recordTaskWrite(resolveOperand(last, baseCwd), "bash"); // 仅目标侧（末操作数）
				}
				continue;
			}
			if (exe === "sed") operands.shift(); // 首个操作数是 sed 脚本（如 's/a/b/'），非写目标
			for (const op of operands) {
				if (opaqueOperand(op)) continue;
				recordTaskWrite(resolveOperand(op, baseCwd), "bash");
			}
		}
	} catch { /* 尽力解析，异常静默 */ }
}
