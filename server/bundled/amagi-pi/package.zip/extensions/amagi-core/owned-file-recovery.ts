/** Session-local evidence for recovering files this session changed from a clean Git state.
 * No permissions are granted by path declarations. Changed/unknown/shared bytes use the existing UI path.
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";

function canonical(file: string): string { try { return fs.realpathSync(file); } catch { /* lint-exempt:不存在的目标由 digest 返回未知归属。 */ return path.resolve(file); } }
function digest(file: string): string | undefined {
	try {
		const st = fs.lstatSync(file);
		if (!st.isFile() || st.size > 20 * 1024 * 1024) return undefined;
		return createHash("sha256").update(fs.readFileSync(file)).update(String(st.mode & 0o777)).digest("hex");
	} catch { /* lint-exempt:不可读文件不自动归属，沿用原确认流程。 */ return undefined; }
}
function git(cwd: string, args: string[]): string | undefined {
	try { return execFileSync("git", args, { cwd, encoding: "utf8", timeout: 3000, stdio: ["ignore", "pipe", "ignore"] }); }
	catch { /* lint-exempt:Git 观察失败不自动归属，沿用原确认流程。 */ return undefined; }
}
export class OwnedFileRecovery {
	private written = new Map<string, string>();
	private pending = new Map<string, string[]>();
	reset(): void { this.written.clear(); this.pending.clear(); }
	before(callId: string, cwd: string, targets: readonly string[]): void {
		if (!callId) return;
		const candidates: string[] = [];
		for (const target of targets) {
			const absolute = path.resolve(cwd, target), current = digest(absolute);
			if (!current) continue;
			const file = canonical(absolute);
			const prior = this.written.get(file);
			if (prior !== undefined ? prior === current : git(cwd, ["status", "--porcelain", "--untracked-files=all", "--", file]) === "" && !!git(cwd, ["ls-files", "--error-unmatch", "--", file])) candidates.push(file);
			else this.written.delete(file);
		}
		if (this.pending.size >= 128) this.pending.delete(this.pending.keys().next().value!);
		this.pending.set(callId, candidates);
	}
	after(callId: string, success: boolean): void {
		const candidates = this.pending.get(callId) ?? [];
		this.pending.delete(callId);
		for (const file of candidates) {
			const current = success ? digest(file) : undefined;
			if (current) this.written.set(file, current); else this.written.delete(file);
		}
		while (this.written.size > 2048) this.written.delete(this.written.keys().next().value!);
	}
	owns(repo: string, paths: readonly string[]): boolean {
		if (!paths.length) return false;
		if (git(repo, ["diff", "--cached", "--name-only", "--", ...paths]) !== "") return false;
		return paths.every(rel => { const absolute = path.resolve(repo, rel); const saved = this.written.get(canonical(absolute)); return saved !== undefined && saved === digest(absolute); });
	}
}
