/** Parent-owned startup observations; phases are evidence, never inferred root causes. */
import * as fs from "node:fs";
import { createHash } from "node:crypto";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
export type StartupPhase = "launch-prepared" | "process-created" | "extension-loading" | "resources-ready" | "model-wait" | "model-output";
const phases: readonly StartupPhase[] = ["launch-prepared", "process-created", "extension-loading", "resources-ready", "model-wait", "model-output"];
const sha = (v: string) => createHash("sha256").update(v).digest("hex");
export interface StartupObservation {
	version: 1; runKey: string; readyBudgetMs: number; budgetSource: "task" | "environment/default";
	launch: { command: string; argv: string[]; argvDigest: string; cwd: string; pathDigest: string; env: Record<string, string> };
	phase: StartupPhase; events: Array<{ phase: StartupPhase; at: number }>; probeAvailable: boolean;
}
export function createStartupObservation(runKey: string, command: string, argv: readonly string[], cwd: string, env: Record<string, string>, readyBudgetMs: number, taskBudget: boolean): StartupObservation {
	// 保留实际入口、模式与工具参数；任务/提示词/未知参数只存字节数和摘要，不冻结秘密正文。
	const safeFlags = new Set(["--mode", "--model", "--tools", "--session", "--session-dir", "--thinking", "--extension", "-e"]);
	const argvSafe = argv.map((arg, i) => /^--[a-z-]+$/.test(arg) || ["-p", "-e", "-n"].includes(arg) ? arg
		: (i === 0 && /(?:cli|index)\.[cm]?js$/.test(arg)) || safeFlags.has(argv[i - 1] ?? "") ? arg
		: `<redacted ${Buffer.byteLength(arg)}B sha256:${sha(arg)}>`);
	const safeEnv: Record<string, string> = {};
	for (const key of ["PI_OFFLINE", "AMAGI_SUBAGENT"]) if (env[key] !== undefined) safeEnv[key] = /^(?:0|1|true|false|on|off)$/.test(env[key]!) ? env[key]! : "non-boolean";
	return { version: 1, runKey, readyBudgetMs, budgetSource: taskBudget ? "task" : "environment/default",
		launch: { command, argv: argvSafe, argvDigest: sha(JSON.stringify(argv)), cwd, pathDigest: sha(env.PATH ?? ""), env: safeEnv },
		phase: "launch-prepared", events: [{ phase: "launch-prepared", at: Date.now() }], probeAvailable: false };
}
export function observeStartup(s: StartupObservation, phase: StartupPhase, at = Date.now()): void {
	if (!phases.includes(phase) || !Number.isFinite(at) || s.events.some(e => e.phase === phase)) return;
	s.events.push({ phase, at });
	if (phases.indexOf(phase) > phases.indexOf(s.phase)) s.phase = phase;
}
export function readStartupProbe(file: string | undefined, s: StartupObservation): void {
	if (!file) return;
	try {
		const stat = fs.lstatSync(file); if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 32_768) return;
		for (const line of fs.readFileSync(file, "utf8").split("\n")) {
			let v: any; try { v = JSON.parse(line); } catch { continue; }
			if (v?.runKey !== s.runKey || !["extension-loading", "resources-ready", "model-wait"].includes(v.phase) || !Number.isFinite(v.at) || v.at < s.events[0]!.at || v.at > Date.now() + 1000) continue;
			s.probeAvailable = true; observeStartup(s, v.phase, v.at);
		}
	} catch { /* lint-exempt:旧宿主/探针不可读保持未知，不新增派发拒绝。 */ }
}
export function startupExpired(s: StartupObservation, everOutput: boolean, now = Date.now()): boolean {
	// 旧宿主有输出即沿用原有运行看门狗；资源就绪后的静默属于模型等待，不再误杀为启动超时。
	return !everOutput && phases.indexOf(s.phase) < phases.indexOf("resources-ready") && s.readyBudgetMs > 0 && now - s.events[0]!.at >= s.readyBudgetMs;
}
export function startupSummary(s: StartupObservation): string {
	return `启动阶段=${s.phase}；readyBudgetMs=${s.readyBudgetMs}（${s.budgetSource}）；入口=${s.launch.command}；PI_OFFLINE=${s.launch.env.PI_OFFLINE ?? "unset"}；runKey=${s.runKey}`;
}
export function emitStartupPhase(phase: "extension-loading" | "resources-ready" | "model-wait"): void {
	if (process.env.AMAGI_SUBAGENT !== "1" || !process.env["AMAGI_STARTUP_FILE"] || !process.env.AMAGI_RUN_KEY) return;
	try {
		const file = process.env["AMAGI_STARTUP_FILE"], stat = fs.lstatSync(file);
		if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 32_000) return;
		fs.appendFileSync(file, JSON.stringify({ runKey: process.env.AMAGI_RUN_KEY, phase, at: Date.now() }) + "\n");
	} catch { /* lint-exempt:探针只供观察，不影响子进程正常启动。 */ }
}
emitStartupPhase("extension-loading");
export function registerStartupProbe(pi: ExtensionAPI): void {
	pi.on("session_start", () => { emitStartupPhase("resources-ready"); });
	pi.on("before_agent_start", () => { emitStartupPhase("model-wait"); });
}
