/**
 * verification-dependencies.ts — C2-a（ev-20260921-89cc12 / ev-20260922-7d1b10 联合，方案 §2.8）：
 * 冻结依赖对象（dependencyMode=copy-local）的捕获与复核——隔离高成本文件遍历。
 *
 * 背景（R/C 原事故）：共享树测试通过、收集器 unavailable——V1 验证对象明确排除 node_modules，
 * 快照上跑 npm 类命令只会把环境缺失误报成检查失败，于是依赖型检查恒 unavailable。本模块把
 * 「检查运行所需的本地依赖」建立为可校验的冻结副本：
 *   1. 捕获范围：授权工作区内全部 node_modules 根（包含未声明子包与 Git 忽略的依赖目录），
 *      由有界目录清单枚举统一驱动；检查计划已选中的 bin 根必须存在。目录/源码根别名不能
 *      摊平复制（会改变相对链接或运行时解析位置），如实 unavailable，不伪造等价快照。
 *      ev-20261019-9321ad：别名检查只作用于参与验证对象的路径（participatingPaths，见
 *      collectDependencyRoots）——清单外（git ignore 等）别名不再阻断捕获/自动基线。
 *   2. pnpm `.pnpm` 虚拟 store 与内部符号链接保持在新对象内（相对链接文本原样保留——整个
 *      workspace 镜像后相对解析不变）；指向 workspace 源码的链接重定位到快照源码（镜像内同形
 *      解析）；绝对链接重写为对象内路径。跨授权根 symlink、断链、缺文件、解析不完备如实
 *      失败——不跟随复制用户家目录 / pnpm 全局 store。
 *   3. 内容经私有复制保全（fs.copyFileSync：darwin/APFS 经 libuv 优先 clonefile CoW，失败回退
 *      全量复制——两形态均为私有副本），不用可写 hardlink、不建指向源树的 symlink。复制前后
 *      校验文件字节、可执行位、链接文本；源侧二次核对（捕获中途漂移 → 失败）。
 *   4. dependency-manifest.json（canonical JSON，键排序、无时间戳）+ digest 纳入验证对象
 *      environmentDigest；检查结束后 verifyDependencyManifest 复核——变化（含缓存写入等新
 *      文件）→ object-changed。锁文件只是 unavailable 判定的输入之一，不作为「依赖一定未
 *      捕获」的代用判断（调用方 evidence.ts/unavailableReason 消费）。
 *   5. 首版有界上限：1 GiB / 100,000 条 / 120 秒（DependencyCaptureLimits，超限保留原因不
 *      降格通过）；每 1,000 条或 5 秒经 onProgress 报告进度。成本在真实 pnpm fixture 实测
 *      （agent-outputs/luban/C2-evidence-chain-report.md），不宣称已调优。
 *
 * 边界：本模块不执行检查（evidence.ts）、不产出 VerificationObject（verification-object.ts）、
 * 不安装依赖（copy-local 只复制已有本地内容，无安装/网络/凭据读取）。失败语义 fail-closed：
 * 任何不完备返回 ok=false + 真实原因，调用方据此 unavailable——绝不静默缺失换绿。
 *
 * ev-20261017-ece384 续（Go 模块依赖可执行路径）：Go 依赖不落 node_modules——依赖在对象外的
 * 本机全局模块缓存（GOMODCACHE）。本模块提供「只读离线复用」路径（copy-local 的只读变体：
 * 不安装、不联网、不捕获副本）：
 *   1. GO_OFFLINE_ENV——快照上执行 go 命令的确定性 env 面（readonly 解析 + 禁网络 + 禁工具链
 *      下载）；env 变量优先于 GOENV 文件（go 环境变量决议规则），注入即权威。
 *   2. preflightGoModuleCache——离线预检（go list -m all）：模块图能否由本机缓存完备解析。
 *      完备 → 调用方（evidence.ts ②）解除 DEPS_REQUIRING_TOOLS 门控并执行；环境缺失特征
 *      （GOPROXY=off 查找被禁/missing go.sum entry/GOTOOLCHAIN 不满足）→ 保持 unavailable；
 *      无环境特征的失败（如 go.mod 语法错误）放行执行，由检查输出呈现真实失败（failed 语义
 *      不缺位，不把仓库缺陷误报成环境缺失）。
 *   3. goEnvironmentFailureLabel——执行期输出分类器（环境缺失 ≠ 检查失败）：evidence.ts ⑤
 *      执行后据此把 missing go.sum entry / module lookup disabled 类输出归 unavailable。
 */

import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { discoverUserToolBinDirs } from "./shell-env.ts";
import type { Ref } from "./contracts/view.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 公共类型：条目 / 清单 / 上限 / 结果
// ─────────────────────────────────────────────────────────────────────────────

/** 依赖清单条目（路径相对捕获根，POSIX 分隔——清单随对象整体迁移）。 */
export interface DependencyEntry {
	/** 相对捕获根的路径（node_modules/… 前缀保留原始布局）。 */
	path: string;
	type: "file" | "symlink";
	/** sha256：file=字节；symlink=写入对象内的最终链接文本（绝对重写型与源文本不同）。 */
	digest: string;
	bytes: number;
	/** file：可执行位（lstat mode & 0o111）。 */
	executable?: boolean;
	/** symlink：源侧链接文本（复制后源侧复核口径）。 */
	sourceLinkText?: string;
	/** symlink：捕获时直连目标不在场（pnpm 可选 peer 未安装的悬空链接——如实记录不静默；
	 *  目标路径仍在授权根内，副本保持同样悬空——源与对象同真同假，不猜成功）。 */
	dangling?: boolean;
	/** symlink：分类——internal=依赖树内部链接（.pnpm/store 布局）；workspace-source=指向
	 *  workspace 源码（镜像内同形解析）；absolute-rewritten=绝对链接重写为对象内路径。 */
	linkKind?: "internal" | "workspace-source" | "absolute-rewritten";
}

/** 冻结依赖清单（canonical JSON 落盘 dependency-manifest.json；无时间戳——同内容两次捕获同 digest）。 */
export interface DependencyManifest {
	version: 1;
	mode: "copy-local";
	/** 授权根（源工作区；捕获/分类边界——越界链接不跟随）。 */
	authorizedRoot: string;
	/** 捕获的 node_modules 树（相对根，如 ["node_modules","pkgs/alpha/node_modules"]）。 */
	roots: readonly string[];
	entries: readonly DependencyEntry[];
}

/** 捕获上限（首版策略建议，方案 §2.8；超限 fail-closed 不降格）。 */
export interface DependencyCaptureLimits {
	/** 依赖内容总字节上限（默认 1 GiB）。 */
	maxBytes: number;
	/** 条目数上限（file+symlink 合计；默认 100,000）。 */
	maxEntries: number;
	/** 捕获总时长上限 ms（默认 120,000）。 */
	deadlineMs: number;
}

export const DEFAULT_DEPENDENCY_LIMITS: DependencyCaptureLimits = {
	maxBytes: 1024 * 1024 * 1024,
	maxEntries: 100_000,
	deadlineMs: 120_000,
};

/** 进度报告（每 1,000 条或 5 秒；方案 §2.8）。 */
export interface DependencyCaptureProgress {
	phase: "scan" | "copy" | "verify";
	entries: number;
	bytes: number;
	lastPath: string;
}

export interface DependencyCaptureStats {
	roots: number;
	files: number;
	symlinks: number;
	bytes: number;
	/** 捕获耗时（不进清单/digest——无时间戳不变量）。 */
	durationMs: number;
}

/** 捕获失败码（ok=false 携带；调用方 → 检查 unavailable，不降格通过）。 */
export type DependencyCaptureFailureCode =
	| "no-capture-root"   // 工作区内无任何 node_modules（依赖未安装——「依赖缺失」口径）
	| "missing-plan-root" // 执行计划已选中的依赖根缺失，不能以其它根捕获成功代替
	| "invalid-plan-root" // 计划路径不在对象内或不是 node_modules 根
	| "root-alias"       // 根别名会改变相对链接/Node 解析语义，不能摊平复制
	| "limit-exceeded"    // 字节/条目/时长超限（保留原因，不降格）
	| "cross-root-link"   // symlink 指向授权根之外（不跟随复制用户家目录/store）
	| "broken-link"       // 断链 / 目标缺失（「缺文件」口径）
	| "copy-failed"       // 读取/复制/落盘失败
	| "source-drift";     // 复制后源侧复核不一致（捕获中途被写）

export type DependencyCaptureResult =
	| {
			ok: true;
			manifest: DependencyManifest;
			/** canonical JSON 落盘引用（dependency-manifest.json，内容寻址）。 */
			manifestRef: Ref;
			/** 清单 digest（canonical JSON sha256；纳入 environmentDigest 的稳定摘要）。 */
			digest: string;
			stats: DependencyCaptureStats;
	  }
	| {
			ok: false;
			code: DependencyCaptureFailureCode;
			reason: string;
			partialEntries: number;
			partialBytes: number;
	  };

/** 复核结果（检查结束后对冻结副本复核；任一非空 → object-changed，调用方消费）。 */
export interface DependencyVerifyResult {
	/** 内容/执行位/链接文本与清单不一致。 */
	changed: string[];
	/** 清单条目在副本中缺失。 */
	missing: string[];
	/** 依赖树内出现清单外新路径（如 runner 缓存写入 node_modules/.vite——不全局忽略换绿，如实上报）。 */
	unexpected: string[];
	/** ev-20261021-ba6114：命中 runner 输出边界且内容通过形态校验的检查期写出/就地改写（不计漂移，逐项透出）。 */
	runnerOutputs: Array<{ path: string; label: string }>;
}

// ─────────────────────────────────────────────────────────────────────────────
// runner 输出边界（ev-20261021-ba6114）
// ─────────────────────────────────────────────────────────────────────────────
// 根因：Vitest（实测 4.1.10）不读取 VITEST_CACHE_DIR——结果缓存固定写入 Vite cacheDir 下
// `node_modules/.vite/vitest/<label-hash>/results.json`（cli-api ResultsCache.setConfig：
// resolve(config.dir,"results.json")；cacheDir 只来自项目配置），env 重定向对它无效。旧口径把
// 这个文件当作被验证输入冻结进依赖清单，检查一跑就 changed → object-changed，exit 0/1 都失效。
// 边界：检查**写出**的该文件是 runner 输出（逐测试文件 duration/failed 记录）。捕获侧**不排除**——
// 检查开始前已存在的文件可能被检查读取（diting D-01：路径+内容形态证明不了「不会被读」），一律照常
// 冻结为输入，检查在真实输入上运行。只在检查后复核时放行：同路径普通文件（新写出，或冻结条目被
// 就地改写、执行位不变）且新内容通过严格形态校验（{version:string, results:[[string,{duration:
// number,failed:boolean}]]}）才归 runnerOutputs。不是目录级忽略：同目录其它文件、链接、形态不符内容、
// 删除、源码区与依赖区其它条目的任何改动都保持 object-changed。
const RUNNER_OUTPUT_RULES: ReadonlyArray<{ re: RegExp; label: string; validate: (body: string) => boolean }> = [
	{
		re: /(?:^|\/)node_modules\/\.vite\/vitest\/(?:[0-9a-f]{40}\/)?results\.json$/,
		label: "vitest 结果缓存（results.json）",
		validate: isVitestResultsCacheBody,
	},
];

/** Vitest results.json 内容形态校验（纯函数；与 ResultsCache.writeToCache 写出结构同构）。 */
export function isVitestResultsCacheBody(body: string): boolean {
	let v: unknown;
	try { v = JSON.parse(body); } catch { return false; /* lint-exempt:非法 JSON→形态不符，保持 unexpected */ }
	if (!v || typeof v !== "object" || Array.isArray(v)) return false;
	const rec = v as Record<string, unknown>;
	if (Object.keys(rec).some((k) => k !== "version" && k !== "results")) return false;
	if (typeof rec.version !== "string" || !Array.isArray(rec.results)) return false;
	return rec.results.every((item) => {
		if (!Array.isArray(item) || item.length !== 2 || typeof item[0] !== "string") return false;
		const meta = item[1];
		if (!meta || typeof meta !== "object" || Array.isArray(meta)) return false;
		const m = meta as Record<string, unknown>;
		return Object.keys(m).every((k) => k === "duration" || k === "failed")
			&& typeof m.duration === "number" && typeof m.failed === "boolean";
	});
}

/** 路径是否落在 runner 输出边界（仅路径形态；纯函数，供展示/测试）。返回形态标签或 null。 */
export function runnerOutputLabelOf(rel: string): string | null {
	const norm = rel.split(path.sep).join("/");
	for (const rule of RUNNER_OUTPUT_RULES) if (rule.re.test(norm)) return rule.label;
	return null;
}

/** 检查后写出分类：路径形态命中 + 普通文件 + 内容形态校验通过 → 标签；否则 null（保持 unexpected）。 */
export function classifyRunnerOutput(rel: string, abs: string): string | null {
	const norm = rel.split(path.sep).join("/");
	for (const rule of RUNNER_OUTPUT_RULES) {
		if (!rule.re.test(norm)) continue;
		try {
			const st = fs.lstatSync(abs);
			if (!st.isFile() || st.size > 16 * 1024 * 1024) return null;
			return rule.validate(fs.readFileSync(abs, "utf8")) ? rule.label : null;
		} catch { return null; /* lint-exempt:不可读→不归输出，保持 unexpected */ }
	}
	return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 内部工具
// ─────────────────────────────────────────────────────────────────────────────

/** 规范化 JSON（键排序稳定序列化；与 verification-object.ts canonicalJson 同口径）。 */
function canonicalJson(v: unknown): string {
	const walk = (x: unknown): unknown => {
		if (Array.isArray(x)) return x.map(walk);
		if (x && typeof x === "object") {
			const rec: Record<string, unknown> = {};
			for (const k of Object.keys(x as Record<string, unknown>).sort()) rec[k] = walk((x as Record<string, unknown>)[k]);
			return rec;
		}
		return x;
	};
	return JSON.stringify(walk(v));
}

function sha256File(p: string): string {
	return createHash("sha256").update(fs.readFileSync(p)).digest("hex");
}

function isAncestorOrSelf(anc: string, p: string): boolean {
	return anc === p || p.startsWith(anc + path.sep);
}

/** 归一直连目标路径：从最深存在祖先 realpath 后拼回剩余后缀（macOS /var → /private/var
 *  等挂载别名；悬空目标同样可判定包含关系，不误报跨根）。全链不可达时原样返回。 */
function canonicalizeExistingPrefix(p: string): string {
	let dir = path.dirname(p);
	const tail: string[] = [];
	for (;;) {
		if (fs.existsSync(dir)) {
			try { return path.join(fs.realpathSync(dir), ...tail); } catch { return p; }
		}
		tail.unshift(path.basename(dir));
		const parent = path.dirname(dir);
		if (parent === dir) return p;
		dir = parent;
	}
}

/** 依赖目录清单必须覆盖整个授权根，包含 Git 忽略且没有 package.json/源码的依赖目录。
 *  只枚举目录名，不进入 node_modules 或 .git；不跟随目录/源码别名，防解析位置变化假绿。
 *  inventory 与内容捕获共用条目/时长上限，不能超限后静默取部分根。
 *  ev-20261019-9321ad：别名检查只作用于真正参与验证对象的路径——participatingPaths（对象清单
 *  entries 的相对路径集合，git tracked/untracked 口径、天然尊重 ignore）在场的别名随源码快照
 *  解引用会改变运行时解析位置（保持 root-alias fail-closed）；清单外路径（如被 ignore 的
 *  `.worktrees -> .` 工作树别名）不进对象、不进依赖捕获，跳过——与测试无关的别名不再阻断
 *  依赖捕获/自动基线。集合缺席（captureLocalDependencies 直调）→ 维持全量严格口径（保守）。 */
function collectDependencyRoots(root: string, limits: DependencyCaptureLimits, startedAt: number, participatingPaths?: ReadonlySet<string>): string[] {
	const roots: string[] = [];
	let visited = 0;
	const walk = (dir: string): void => {
		if (++visited > limits.maxEntries || Date.now() - startedAt > limits.deadlineMs) throw new ScanFailure("limit-exceeded", "依赖目录清单枚举超限，不能只捕获部分依赖根");
		let entries: fs.Dirent[];
		try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
		catch { /* journal:dependency-inventory-unreadable */ throw new ScanFailure("copy-failed", `依赖目录清单不可读：${path.relative(root, dir) || "."}`); }
		for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
			if (entry.name === ".git") continue;
			const abs = path.join(dir, entry.name), rel = path.relative(root, abs).split(path.sep).join("/");
			if (entry.name === "node_modules") {
				try { if (!fs.statSync(abs).isDirectory()) throw new Error("not-directory"); }
				catch { /* journal:dependency-root-unavailable */ throw new ScanFailure("broken-link", `依赖根不可用：${rel}`); }
				roots.push(rel); continue;
			}
			if (entry.isSymbolicLink()) {
				// 源码快照会把文件链接解引用；目录链接也不能以浅复制证明 Node 解析等价。清单内
				// （参与对象）别名不能摊平；清单外别名不参与任何被验证内容，跳过（见函数头注释）。
				if (participatingPaths === undefined || participatingPaths.has(rel)) {
					throw new ScanFailure("root-alias", `源码/目录包含符号链接别名：${rel}——不能证明快照保持运行时解析位置，请准备实体副本或显式共享树验证`);
				}
			}
			if (entry.isDirectory()) walk(abs);
		}
	};
	walk(root);
	return roots;
}

function addExecutionPlanRoots(root: string, roots: string[], plan?: { execCwd: string; binDirsRel: readonly string[] }): void {
	if (!plan) return;
	const validRel = (rel: string): boolean => typeof rel === "string" && rel !== "" && !path.isAbsolute(rel) && !rel.split(/[\\/]/).includes("..");
	if (!validRel(plan.execCwd) || !Array.isArray(plan.binDirsRel) || plan.binDirsRel.some(rel => !validRel(rel))) {
		throw new ScanFailure("invalid-plan-root", "检查计划 cwd/bin 路径必须在对象内（相对路径、不含 ..）");
	}
	for (const binRel of plan.binDirsRel) {
		const parts = binRel.split(/[\\/]/), at = parts.indexOf("node_modules");
		if (at < 0) continue;
		const rel = parts.slice(0, at + 1).join("/");
		try { if (!fs.statSync(path.join(root, rel)).isDirectory()) throw new Error("not a directory"); }
		catch { throw new ScanFailure("missing-plan-root", `检查计划依赖根缺失：${rel}（bin=${binRel}）；在原工作区恢复该依赖后重新捕获，不能用其它根或活依赖替代`); }
		if (!roots.includes(rel)) roots.push(rel);
	}
}

/** Read-only inventory using the capture scanner and its bounds. Aliases outside the
 * unknown future object are ignored; other scan errors leave the projection unknown. */
export function inspectLocalDependencyRoots(sourceRoot: string, plan?: { execCwd: string; binDirsRel: readonly string[] }): { state: "present" | "missing" | "missing-plan-root" | "unknown" } {
	try {
		const root = fs.realpathSync(sourceRoot);
		const roots = collectDependencyRoots(root, DEFAULT_DEPENDENCY_LIMITS, Date.now(), new Set());
		addExecutionPlanRoots(root, roots, plan);
		return { state: roots.length ? "present" : "missing" };
	} catch (e) { return { state: e instanceof ScanFailure && e.code === "missing-plan-root" ? "missing-plan-root" : "unknown" }; }
}

/** 中间扫描记录（源侧事实 + 拟写入对象的链接目标）。 */
interface ScannedEntry {
	rel: string;
	kind: "file" | "symlink";
	srcAbs: string;
	dstAbs: string;
	/** file：字节 digest。symlink：写入对象的链接文本。 */
	finalText?: string;
	finalDigest: string;
	bytes: number;
	executable?: boolean;
	/** symlink：源侧链接文本（复核口径）。 */
	sourceLinkText?: string;
	linkKind?: DependencyEntry["linkKind"];
	/** symlink：捕获时直连目标不在场（悬空链接如实入清单）。 */
	dangling?: boolean;
}

/** 扫描阶段失败（内部携带 code 上抛到主流程 fail-closed；字段显式声明——node strip-types
 *  不支持 constructor 参数属性语法）。 */
class ScanFailure extends Error {
	code: DependencyCaptureFailureCode;
	constructor(code: DependencyCaptureFailureCode, message: string) {
		super(message);
		this.code = code;
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 捕获主流程（scan → afterManifest 钩子 → copy+逐条核对 → 源侧复核 → 清单落盘）
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 捕获本地依赖到冻结副本（copy-local 主入口）。
 * - sourceRoot：授权工作区根（越界链接不跟随）；captureRoot：验证对象捕获根（源码镜像已就位）。
 * - opts.afterManifest：测试/上层钩子——清单建立后、复制前调用（依赖漂移夹具点）。
 * - 失败语义 fail-closed：ok=false 携带 code/reason 与部分计数，调用方 → 检查 unavailable。
 */
export function captureLocalDependencies(
	sourceRoot: string,
	captureRoot: string,
	opts: {
		limits?: Partial<DependencyCaptureLimits>;
		onProgress?: (p: DependencyCaptureProgress) => void;
		afterManifest?: () => void;
		/** 与检查 cwd/bin 解析同源；包含未声明 workspace 的选中子包。 */
		executionPlan?: { execCwd: string; binDirsRel: readonly string[] };
		/** ev-20261019-9321ad：参与验证对象的路径集合（对象清单 entries 相对路径）——依赖根扫描
		 *  的别名检查只作用于这些真正参与的路径；清单外（git ignore 等）别名跳过。缺席 → 全量严格。 */
		participatingPaths?: ReadonlySet<string>;
	} = {},
): DependencyCaptureResult {
	const startedAt = Date.now();
	const limits: DependencyCaptureLimits = { ...DEFAULT_DEPENDENCY_LIMITS, ...opts.limits };
	const root = (() => { try { return fs.realpathSync(sourceRoot); } catch { return path.resolve(sourceRoot); } })();
	const dst = path.resolve(captureRoot);
	// 计数器先于 fail 闭包声明（no-capture-root 早退也要携带部分计数）
	const scanned: ScannedEntry[] = [];
	let totalBytes = 0;
	const fail = (code: DependencyCaptureFailureCode, reason: string): DependencyCaptureResult =>
		({ ok: false, code, reason, partialEntries: scanned.length, partialBytes: totalBytes });

	let rootsRel: string[];
	try { rootsRel = collectDependencyRoots(root, limits, startedAt, opts.participatingPaths); }
	catch (e) {
		if (e instanceof ScanFailure) return fail(e.code, e.message);
		return fail("copy-failed", `依赖目录清单异常：${String(e)}`);
	}
	// ev-20261008-1e5724：依赖闭包由真实执行计划补齐，不再另猜一份子包清单。
	// bin 所属根是必要输入；cwd 至对象根的已有依赖参与运行时 require/hoisting。
	try { addExecutionPlanRoots(root, rootsRel, opts.executionPlan); }
	catch (e) {
		if (e instanceof ScanFailure) return fail(e.code, e.message);
		return fail("copy-failed", `依赖目录清单异常：${String(e)}`);
	}
	if (rootsRel.length === 0) {
		return fail("no-capture-root", "工作区内不存在任何 node_modules 依赖目录（依赖未安装；copy-local 只复制已有本地依赖，不执行安装）");
	}
	// 根自身也可能是链接（portable 工作树、子包路径链接），不能跳过条目级边界校验。
	for (const rel of rootsRel) {
		try {
			const logical = path.join(root, rel), real = fs.realpathSync(logical);
			if (!isAncestorOrSelf(root, real)) {
				return fail("cross-root-link", `跨授权根依赖目录 ${rel}——不跟随复制外部依赖，请在工作区准备本地副本后重新捕获`);
			}
			if (real !== logical) return fail("root-alias", `依赖根包含符号链接别名：${rel}——摊平复制会改变相对链接与运行时解析，不能宣称捕获完整；请准备实体依赖副本后重新捕获`);
		} catch { /* journal:dependency-root-broken-link */ return fail("broken-link", `依赖根不可解析：${rel}`); }
	}

	// ── scan：分类 + 摘要（排序遍历保证清单确定性——同内容两次捕获同 digest）──
	let lastProgressAt = startedAt;
	const maybeProgress = (phase: DependencyCaptureProgress["phase"], lastPath: string): void => {
		if (!opts.onProgress) return;
		if (scanned.length % 1000 === 0 || Date.now() - lastProgressAt >= 5_000) {
			lastProgressAt = Date.now();
			opts.onProgress({ phase, entries: scanned.length, bytes: totalBytes, lastPath });
		}
	};

	const scanTree = (rootRel: string): void => {
		const rootSrc = path.join(root, rootRel);
		const walk = (relDir: string): void => {
			const srcDir = relDir ? path.join(rootSrc, relDir) : rootSrc;
			let ents: fs.Dirent[];
			try { ents = fs.readdirSync(srcDir, { withFileTypes: true }); } catch (e) {
				throw new ScanFailure("copy-failed", `依赖目录不可读 ${relDir || rootRel}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
			}
			for (const ent of ents.sort((a, b) => a.name.localeCompare(b.name))) {
				const rel = relDir ? `${relDir}/${ent.name}` : ent.name;
				const srcAbs = path.join(rootSrc, rel);
				let st: fs.Stats;
				try { st = fs.lstatSync(srcAbs); } catch (e) {
					throw new ScanFailure("broken-link", `依赖条目缺失 ${rootRel}/${rel}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
				}
				if (st.isDirectory()) { walk(rel); continue; }
				if (st.isSymbolicLink()) {
					let text: string;
					try { text = fs.readlinkSync(srcAbs); } catch (e) {
						throw new ScanFailure("copy-failed", `链接文本不可读 ${rootRel}/${rel}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
					}
					// 分类：直连目标（非 realpath 链尾——链中其余环节作为独立条目各自入清单）必须落在
					// 授权根内；越界（用户家目录/pnpm 全局 store）→ 不跟随复制，如实 unavailable。
					// 目标在根内但不在场（pnpm 可选 peer 未安装的悬空链接）：保留原文本入副本并标
					// dangling——源与对象同真同假，测试若真需要它会在两边同样失败（不猜成功也不误判缺捕获）。
					const directTarget = path.isAbsolute(text) ? canonicalizeExistingPrefix(path.resolve(text)) : path.resolve(path.dirname(srcAbs), text);
					if (!isAncestorOrSelf(root, directTarget)) {
						throw new ScanFailure("cross-root-link", `跨授权根链接 ${rootRel}/${rel} -> ${text}（解析至 ${directTarget}）——不跟随复制用户家目录/store，如实 unavailable`);
					}
					let finalText = text;
					let linkKind: DependencyEntry["linkKind"];
					let dangling = false;
					try { fs.lstatSync(directTarget); } catch { dangling = true; }
					if (path.isAbsolute(text)) {
						// 绝对链接（指向授权根内）：重写为对象内路径——不得保留指向源树的可写链接
						finalText = path.join(dst, path.relative(root, directTarget));
						linkKind = "absolute-rewritten";
					} else {
						// 相对链接：整树镜像后相对解析不变（.pnpm 内部链接 / workspace 源码链接同形成立）
						linkKind = isAncestorOrSelf(rootSrc, directTarget) ? "internal" : "workspace-source";
					}
					scanned.push({
						rel: `${rootRel}/${rel}`, kind: "symlink", srcAbs, dstAbs: path.join(dst, rootRel, rel),
						finalText, finalDigest: createHash("sha256").update(finalText, "utf8").digest("hex"),
						bytes: Buffer.byteLength(finalText, "utf8"), dangling,
						sourceLinkText: text, linkKind,
					});
					totalBytes += Buffer.byteLength(finalText, "utf8");
				} else if (st.isFile()) {
					let digest: string;
					try { digest = sha256File(srcAbs); } catch (e) {
						throw new ScanFailure("copy-failed", `依赖文件不可读 ${rootRel}/${rel}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
					}
					scanned.push({
						rel: `${rootRel}/${rel}`, kind: "file", srcAbs, dstAbs: path.join(dst, rootRel, rel),
						finalDigest: digest, bytes: st.size, executable: (st.mode & 0o111) !== 0,
					});
					totalBytes += st.size;
				} else {
					throw new ScanFailure("copy-failed", `非普通文件/链接的依赖条目 ${rootRel}/${rel}（fifo/socket 等）——不可冻结`);
				}
				if (scanned.length > limits.maxEntries) throw new ScanFailure("limit-exceeded", `依赖条目数超限（>${limits.maxEntries}）`);
				if (totalBytes > limits.maxBytes) throw new ScanFailure("limit-exceeded", `依赖字节数超限（>${limits.maxBytes}B）`);
				if (Date.now() - startedAt > limits.deadlineMs) throw new ScanFailure("limit-exceeded", `依赖捕获超时（>${limits.deadlineMs}ms）`);
				maybeProgress("scan", rel);
			}
		};
		walk("");
	};

	for (const rel of rootsRel) {
		try { scanTree(rel); } catch (e) {
			if (e instanceof ScanFailure) return fail(e.code, `${e.message}（捕获根：${rel}）`);
			return fail("copy-failed", `依赖捕获扫描异常: ${String((e as Error)?.message ?? e).slice(0, 160)}`);
		}
	}

	// 测试/上层钩子：清单建立后、复制前（依赖漂移夹具点——复制后源侧复核会检出）
	opts.afterManifest?.();

	// ── copy：私有复制（clonefile 可用则 CoW）+ 逐条核对（字节/执行位/链接文本）──
	for (let i = 0; i < scanned.length; i++) {
		const e = scanned[i];
		try {
			fs.mkdirSync(path.dirname(e.dstAbs), { recursive: true });
			if (e.kind === "file") {
				// fs.copyFileSync：darwin/APFS 经 libuv 优先 clonefile（同卷 CoW 私有副本），回退全量
				// 复制；两种形态都不是可写 hardlink / 指向源树的 symlink（方案 §2.8 禁形）。
				fs.copyFileSync(e.srcAbs, e.dstAbs);
				fs.chmodSync(e.dstAbs, fs.lstatSync(e.srcAbs).mode & 0o7777);
				if (sha256File(e.dstAbs) !== e.finalDigest) {
					// 副本字节与清单不一致：先区分「源在清单后被动过」（漂移）与「复制自身失败」
					const srcNow = sha256File(e.srcAbs);
					if (srcNow !== e.finalDigest) throw new ScanFailure("source-drift", `捕获期间依赖内容被写（源侧复核不一致）: ${e.rel}`);
					throw new Error("副本字节与清单不一致");
				}
				const dstMode = fs.lstatSync(e.dstAbs).mode & 0o111;
				if ((e.executable ?? false) !== (dstMode !== 0)) throw new Error("副本执行位不一致");
			} else {
				fs.symlinkSync(e.finalText ?? "", e.dstAbs);
				const text = fs.readlinkSync(e.dstAbs);
				if (text !== e.finalText) throw new Error("副本链接文本不一致");
				if (createHash("sha256").update(text, "utf8").digest("hex") !== e.finalDigest) throw new Error("副本链接 digest 不一致");
			}
		} catch (err) {
			if (err instanceof ScanFailure) return fail(err.code, err.message);
			return fail("copy-failed", `依赖复制失败 ${e.rel}: ${String((err as Error)?.message ?? err).slice(0, 120)}`);
		}
		if (i % 1000 === 0) maybeProgress("copy", e.rel);
	}

	// ── verify：源侧二次复核（捕获中途漂移 → fail-closed）──
	for (const e of scanned) {
		try {
			if (e.kind === "file") {
				if (sha256File(e.srcAbs) !== e.finalDigest) {
					return fail("source-drift", `捕获期间依赖内容被写（源侧复核不一致）: ${e.rel}`);
				}
			} else {
				if (fs.readlinkSync(e.srcAbs) !== e.sourceLinkText) {
					return fail("source-drift", `捕获期间依赖链接被改（源侧复核不一致）: ${e.rel}`);
				}
			}
		} catch (err) {
			return fail("copy-failed", `源侧复核失败 ${e.rel}: ${String((err as Error)?.message ?? err).slice(0, 120)}`);
		}
		if (Date.now() - startedAt > limits.deadlineMs) {
			return fail("limit-exceeded", `依赖捕获超时（>${limits.deadlineMs}ms，复核阶段）`);
		}
	}
	maybeProgress("verify", scanned.length > 0 ? scanned[scanned.length - 1].rel : "");

	// ── manifest：canonical JSON 落盘 + digest（无时间戳——同内容同 digest）──
	const entries: DependencyEntry[] = scanned.map((e) => ({
		path: e.rel,
		type: e.kind,
		digest: e.finalDigest,
		bytes: e.bytes,
		...(e.executable !== undefined ? { executable: e.executable } : {}),
		...(e.sourceLinkText !== undefined ? { sourceLinkText: e.sourceLinkText } : {}),
		...(e.linkKind !== undefined ? { linkKind: e.linkKind } : {}),
		...(e.dangling ? { dangling: true } : {}),
	}));
	const manifest: DependencyManifest = { version: 1, mode: "copy-local", authorizedRoot: root, roots: rootsRel, entries };
	const body = canonicalJson(manifest);
	const manifestAbs = path.join(dst, "dependency-manifest.json");
	try {
		fs.writeFileSync(manifestAbs, body, "utf8");
	} catch (e) {
		return fail("copy-failed", `dependency-manifest.json 落盘失败: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
	}
	const manifestRef: Ref = {
		path: manifestAbs,
		digest: createHash("sha256").update(body, "utf8").digest("hex"),
		bytes: Buffer.byteLength(body, "utf8"),
	};
	const stats: DependencyCaptureStats = {
		roots: rootsRel.length,
		files: entries.filter((x) => x.type === "file").length,
		symlinks: entries.filter((x) => x.type === "symlink").length,
		bytes: totalBytes,
		durationMs: Date.now() - startedAt,
	};
	return { ok: true, manifest, manifestRef, digest: manifestRef.digest, stats };
}

// ─────────────────────────────────────────────────────────────────────────────
// 复核（检查结束后：副本 vs 清单——变化/缺失/清单外新路径 → object-changed）
// ─────────────────────────────────────────────────────────────────────────────

/** 检查结束后复核冻结依赖副本：条目逐一核对（字节/执行位/链接文本）+ 依赖树内新路径检测
 *  （runner 缓存写入 node_modules/.vite 等——不全局忽略换绿，如实上报 unexpected）。 */
export function verifyDependencyManifest(captureRoot: string, manifest: DependencyManifest): DependencyVerifyResult {
	const dst = path.resolve(captureRoot);
	const byPath = new Map<string, DependencyEntry>();
	for (const e of manifest.entries) byPath.set(e.path, e);
	const changed: string[] = [];
	const missing: string[] = [];
	const runnerOutputs: Array<{ path: string; label: string }> = [];
	for (const e of manifest.entries) {
		const abs = path.join(dst, e.path);
		try {
			const st = fs.lstatSync(abs);
			if (e.type === "file") {
				if (!st.isFile()) { changed.push(e.path); continue; }
				if (sha256File(abs) !== e.digest) {
					// ev-20261021-ba6114（D-01）：冻结的结果缓存被 runner 就地改写——检查已在冻结原内容上
					// 运行，改写只是输出；执行位不变 + 新内容形态合规才放行，否则照常 changed。
					const label = (e.executable ?? false) === ((st.mode & 0o111) !== 0) ? classifyRunnerOutput(e.path, abs) : null;
					if (label !== null) runnerOutputs.push({ path: e.path, label });
					else changed.push(e.path);
					continue;
				}
				if ((e.executable ?? false) !== ((st.mode & 0o111) !== 0)) { changed.push(e.path); continue; }
			} else {
				if (!st.isSymbolicLink()) { changed.push(e.path); continue; }
				const text = fs.readlinkSync(abs);
				if (createHash("sha256").update(text, "utf8").digest("hex") !== e.digest) { changed.push(e.path); continue; }
			}
		} catch {
			missing.push(e.path);
		}
	}
	// 清单外新路径：遍历捕获的依赖树，出现 manifest 未登记的 file/symlink → unexpected
	const unexpected: string[] = [];
	for (const rootRel of manifest.roots) {
		const walk = (relDir: string): void => {
			const absDir = relDir ? path.join(dst, rootRel, relDir) : path.join(dst, rootRel);
			let ents: fs.Dirent[];
			try { ents = fs.readdirSync(absDir, { withFileTypes: true }); } catch { return; }
			for (const ent of ents) {
				const rel = `${rootRel}/${relDir ? `${relDir}/` : ""}${ent.name}`;
				if (ent.isDirectory()) { walk(relDir ? `${relDir}/${ent.name}` : ent.name); continue; }
				if (byPath.has(rel)) continue;
				const label = ent.isFile() ? classifyRunnerOutput(rel, path.join(dst, rel)) : null;
				if (label !== null) runnerOutputs.push({ path: rel, label });
				else unexpected.push(rel);
			}
		};
		walk("");
	}
	return { changed, missing, unexpected, runnerOutputs };
}

// ─────────────────────────────────────────────────────────────────────────────
// Go 模块依赖可执行路径（ev-20261017-ece384 续）：只读离线复用本机 GOMODCACHE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 快照上执行 go 命令的确定性离线 env 面（ev-20261017-ece384 续；ev-20261021-fix diting F6/F8 收严）。
 * - GOFLAGS=-mod=readonly：整体覆盖（不与用户 GOFLAGS 合并）——-mod=mod 会改写对象内
 *   go.mod/go.sum（对象漂移换绿）；readonly 下需要更新锁文件时显式失败（missing go.sum entry /
 *   updates to go.sum needed → 环境缺失分类，见 goToolchainSetupFailureLabel）。**注意：-mod=readonly
 *   只约束锁文件，不是模块缓存只读开关**——go test 仍可能向 GOMODCACHE 解压写源码（F6 实证），
 *   因此执行面另将 GOMODCACHE 钉到任务私有缓存（evidence.ts ⑤，见 prepareGoPrivateModuleCache）。
 * - GOPROXY=off（预检/无外部模块时）：模块获取全禁；有外部模块时执行面改钉本地 file:// 镜像
 *  （任务私有缓存目录，仅本地文件、零网络——离线语义不变，允许 go 从本地 zip 副本解压）。
 * - GOSUMDB=off：checksum database 不联网（缓存命中即用；防 go env 文件里的自定义 sumdb 触发网络）。
 * - GOTOOLCHAIN=local：工具链不下载（go.mod 声明更高 go 版本时显式失败，不联网升级工具链）。
 * - GOENV=off（ev-20261021-fix）：禁读用户 go env 配置文件——封 GOPRIVATE/GONOPROXY/GOPROXY 等
 *   经 GOENV 文件的绕行面（显式注入的 env 变量优先级仍最高，二者叠加后上述四项均由本面钉死）。
 * 范围边界：以上变量只约束 go 工具链自身的模块获取/校验/工具链下载行为；被测代码自身若直接
 * 触网（net/http 等）不受此 env 面限制——这不是全流程网络隔离保证，仅是 go 依赖获取路径的离线化。
 * 注意：GOMODCACHE/GOPATH 不在此固定——由 resolveHostGoModCache/resolveGoModCacheViaGoEnv
 * 解析后随调用方显式注入；执行面钉任务私有缓存，宿主缓存零写入（见 prepareGoPrivateModuleCache）。
 */
export const GO_OFFLINE_ENV: Readonly<Record<string, string>> = Object.freeze({
	GOFLAGS: "-mod=readonly",
	GOPROXY: "off",
	GOSUMDB: "off",
	GOTOOLCHAIN: "local",
	GOENV: "off",
});

/**
 * 本机 GOMODCACHE 解析（纯函数；宿主 env 口径）：GOMODCACHE 显式值 > GOPATH 首项/pkg/mod
 * （go 的默认派生规则）> null（未配置——子进程按 HOME 派生 $HOME/go/pkg/mod，与 go 缺省一致）。
 * 为什么在宿主侧解析：evidence.ts 的 spawn env 是凭据白名单（不含 GOPATH/GOMODCACHE），
 * 用户自定义 GOPATH 不透传会导致预检与执行各自派生出不同缓存；解析一次并显式注入，两侧钉死
 * 同一缓存路径。
 */
export function resolveHostGoModCache(env: Record<string, string | undefined> = process.env): string | null {
	const direct = env.GOMODCACHE?.trim();
	if (direct) return direct;
	const gopath = env.GOPATH?.trim();
	if (gopath) {
		const first = gopath.split(path.delimiter).map((s) => s.trim()).filter(Boolean)[0];
		if (first) return path.join(first, "pkg", "mod");
	}
	return null;
}

/** 环境缺失输出特征（离线执行面下；环境缺失 ≠ 检查失败——evidence.ts ⑤ 消费归 unavailable）。
 *  ev-20261021-fix（diting F7）：删除 dial tcp/proxyconnect/network unreachable 兜底模式——被测
 *  程序自身的网络输出（如 HTTP 客户端回归测试报连接错误）不可统归 unavailable（真实 --- FAIL 被
 *  改判的事故）；环境缺失只认 go 工具链自身的明确 setup 诊断（下列四类均为 go 专属字符串）。 */
export const GO_ENVIRONMENT_FAILURE_PATTERNS: ReadonlyArray<{ re: RegExp; label: string }> = [
	{ re: /missing go\.sum entry/i, label: "go.sum 缺条目（模块/锁文件不在本机缓存）" },
	{ re: /module lookup disabled by GOPROXY=off/i, label: "模块查找被 GOPROXY=off 禁止（GOMODCACHE 缓存缺失）" },
	{ re: /updates to go\.sum needed/i, label: "go.sum 需要更新（-mod=readonly 拒绝改写对象锁文件）" },
	{ re: /GOTOOLCHAIN=local/i, label: "go.mod 声明的 go 版本高于本机工具链（GOTOOLCHAIN=local 不下载）" },
];

/** 离线执行面下 go 输出的环境缺失分类：命中返回特征标签，否则 null（真实检查失败/正常输出）。 */
export function goEnvironmentFailureLabel(output: string): string | null {
	for (const p of GO_ENVIRONMENT_FAILURE_PATTERNS) if (p.re.test(output)) return p.label;
	return null;
}

/** 真实 go 测试失败标记（go test 框架产物）：--- FAIL: 断言行，或无 [setup failed]/[build failed]
 *  后缀的 FAIL 包行。存在任一 → 输出含真实测试失败事实，不得改判 unavailable（F7：混合包失败与
 *  依赖缺失保留失败事实——[setup failed]/[build failed] 后缀是工具链 setup 失败，不算断言失败）。 */
export function hasRealGoTestFailure(output: string): boolean {
	if (/^--- FAIL: /m.test(output)) return true;
	for (const line of output.matchAll(/^FAIL[^\n]*$/gm)) {
		if (!/\[(?:setup|build) failed\]/.test(line[0])) return true;
	}
	return false;
}

/** ev-20261021-fix（diting F7）：执行期失败 → unavailable 的改判分类器——真实测试失败优先 failed，
 *  仅在无真实失败标记时才认 go 工具链环境诊断。evidence.ts ⑤ 与预检共同消费。 */
export function goToolchainSetupFailureLabel(output: string): string | null {
	if (hasRealGoTestFailure(output)) return null;
	return goEnvironmentFailureLabel(output);
}

/** 预检 runner 形状（与 evidence.ts RunCmd 结构兼容——本模块不 import evidence 防循环依赖）。 */
export type GoPreflightRunner = (
	cmd: string[],
	cwd: string,
	timeoutMs: number,
	ctx?: { envExtra?: Record<string, string> },
) => Promise<{ ok: boolean; stdout: string; stderr: string; code: number | null; timedOut: boolean }>;

/** Go 模块缓存离线预检结果（runStructuredCheck ② 消费：ok → 解除门控；!ok → unavailable）。 */
export interface GoModulePreflight {
	ok: boolean;
	/** ok=false 时的环境缺口原因（→ unavailable 文案；环境缺失 ≠ 检查失败）。 */
	reason: string | null;
	/** 预检事实摘要（命令/退出码/输出尾部——notes 与检查日志审计用）。 */
	detail: string;
	/** 预检退出码（null = spawn 失败/无法执行）。 */
	exitCode: number | null;
	/** ev-20261021-fix（diting F6）：exit 0 时解析出的模块图清单（首行=主模块已剔除；本地目录
	 *  replace 目标记 localDir 不进缓存拷贝）——供 prepareGoPrivateModuleCache 拷贝私有缓存。 */
	modules?: readonly GoListModule[];
}

/** go list -m all 输出行解析结果。localDir 有值表示 replace 到本地目录（无缓存工件）。 */
export interface GoListModule {
	path: string;
	version: string;
	/** replace 到本地目录时的目标路径（本地目录 replace 无缓存工件）。 */
	localDir?: string;
}

/** go list -m all 输出解析（纯函数）：首行主模块剔除；`mod ver` 直入；`mod ver => /dir` 或
 *  `=> ./dir` 记 localDir；`mod v1 => other v2` 取替换后 (other,v2)。无法解析的行跳过（保守：
 *  拷贝面是超集判定，漏行会导致私有缓存缺件 → 执行期不可用，不会虚绿）。 */
export function parseGoListModules(stdout: string): GoListModule[] {
	const out: GoListModule[] = [];
	const lines = stdout.split("\n").map((l) => l.trim()).filter(Boolean);
	for (let i = 1; i < lines.length; i++) { // 首行=主模块
		const t = lines[i]!.split(/\s+/);
		if (t.length < 2) continue;
		if (t[2] === "=>" && t.length >= 4) {
			const rep = t[3]!;
			if (path.isAbsolute(rep) || rep.startsWith("./") || rep.startsWith("../") || rep === "." || rep === "..") {
				out.push({ path: t[0]!, version: t[1]!, localDir: rep });
			} else if (t.length >= 5) out.push({ path: rep, version: t[4]! });
			else out.push({ path: t[0]!, version: t[1]!, localDir: rep });
		} else {
			out.push({ path: t[0]!, version: t[1]! });
		}
	}
	return out;
}

/** 预检预算（go list -m all 离线纯解析，实测 <1s；只防挂死，不是执行预算）。 */
export const GO_PREFLIGHT_TIMEOUT_MS = 30_000;

/**
 * Go 模块缓存离线预检：在快照对象 cwd 上以 GO_OFFLINE_ENV 跑 `go list -m all`——
 * 模块图能否由本机 GOMODCACHE 完备解析（不写缓存、不联网：readonly + GOPROXY=off）。
 * 口径说明（对照 `go mod download` 方案）：GOPROXY=off 下 go mod download 仍可能对「zip 在
 * 缓存、源未解压」的条目做解压写入（违反只读）；go list -m all 只读解析 .mod 即可判定模块图。
 * **ev-20261021-fix（diting F6）：go list -m 成功不再被当作「源码完备/只读可执行」的证明**——
 * 它只读 .mod 文件；源码解压缺口与缓存写入隔离由 prepareGoPrivateModuleCache 的任务私有缓存
 * 承接（拷贝模块图 download 工件到私有目录，执行面 GOMODCACHE=私有 + GOPROXY=file:// 本地镜像，
 * 宿主缓存零写入）。语义不对称（保守方向）：模块图完备 ≠ 全部源码在缓存；图内非构建必需模块
 * 缺失也会判不完备（宁可 unavailable 不猜成功）。真实 go.mod/go.sum 缺陷（无环境特征）放行执行，
 * 由检查输出呈现真实 failed。
 */
export async function preflightGoModuleCache(
	runner: GoPreflightRunner,
	cwd: string,
	opts: { timeoutMs?: number; envExtra?: Record<string, string>; executable?: string } = {},
): Promise<GoModulePreflight> {
	const timeoutMs = opts.timeoutMs ?? GO_PREFLIGHT_TIMEOUT_MS;
	const envExtra: Record<string, string> = { ...GO_OFFLINE_ENV, ...(opts.envExtra ?? {}) };
	const r = await runner([opts.executable ?? "go", "list", "-m", "all"], cwd, timeoutMs, { envExtra });
	const tail = `${r.stdout}\n${r.stderr}`.split("\n").map((l) => l.trim()).filter(Boolean).slice(-2).join(" ｜ ").slice(0, 240);
	if (r.timedOut) {
		return {
			ok: false,
			reason: `Go 模块缓存预检超时（go list -m all 离线，${timeoutMs}ms）——缓存完备性不可判定，不猜成功`,
			detail: `go list -m all（GOFLAGS=-mod=readonly GOPROXY=off）超时无退出码`,
			exitCode: r.code,
		};
	}
	if (r.code === null) {
		return {
			ok: false,
			reason: `go 不可执行（PATH 缺席或 spawn 失败：${(r.stderr || "无输出").trim().slice(0, 120)}）——环境缺失，非检查失败`,
			detail: `go list -m all spawn 失败（无退出码）`,
			exitCode: null,
		};
	}
	if (r.code === 0) {
		return {
			ok: true,
			reason: null,
			detail: `go list -m all（离线）exit 0——模块图可由本机 GOMODCACHE 完备解析${tail ? `（${tail}）` : ""}`,
			exitCode: 0,
			modules: parseGoListModules(r.stdout),
		};
	}
	const label = goToolchainSetupFailureLabel(`${r.stdout}\n${r.stderr}`);
	if (label === null) {
		// 非环境特征（go.mod 语法/需求错误等仓库缺陷）——放行执行，检查输出呈现真实失败（failed）。
		return {
			ok: true,
			reason: null,
			detail: `go list -m all（离线）exit ${r.code} 但无环境缺失特征（${tail || "无输出"}）——放行执行，由检查输出呈现真实错误`,
			exitCode: r.code,
		};
	}
	return {
		ok: false,
		reason: `Go 模块缓存不完备（离线预检失败：${label}）——检查不可在快照上联网安装依赖`,
		detail: `go list -m all（离线）exit ${r.code}：${tail || "无输出"}`,
		exitCode: r.code,
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20261021-fix（diting F6/F8）：任务私有 Go 模块缓存（copy-local 方向的 Go 变体）
// ─────────────────────────────────────────────────────────────────────────────

/** 模块路径 → 模块缓存目录转义（go 规则：大写字母 X → !x；如 github.com/Alice/m →
 *  github.com/!alice/m——缓存目录与 cache/download 布局同用该转义）。 */
/** Shared identity for Go checks, including explicit POSIX/Windows executable paths.
 *  ev-20261019-9321ad：这是「名字字面」层——resolveCommandEntry 的 realpath 识别以其为回退
 *  口径（不可定位 token 保守判定 go，不弱于旧口径）；主判定面迁移到统一命令入口解析（见下节）。 */
export function isGoExecutable(executable: string | undefined): boolean {
	return executable !== undefined && /(?:^|[\\/])go(?:\.exe)?$/.test(executable);
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20261019-9321ad：统一命令入口解析（透明包装器剥离 + realpath 工具识别）
// ─────────────────────────────────────────────────────────────────────────────
// 根因背景：go 语义判定面（依赖门控/GOMODCACHE 解析与离线预检/离线 env 注入/失败分类/
// 禁复用）此前各看 argv[0] 字面（isGoExecutable 正则）——`env <go> test` 与异名 Go 符号链接
// 只需改变 argv[0] 字面即可让全部 go 判定面失明（旧绿灯可复用、不注入离线面、不走预检）。
// 本节提供单一解析入口，evidence.ts 复用判定与依赖捕获共用同一结果（不再各持一份字面判断）。

/** 透明包装器集合（封闭名单，basename 口径、.exe 归一）：这些命令只注入环境/时限/优先级，
 *  不改变被包裹工具的语义，逐层剥离后识别真正的工具。查询形态（command -v/-V/-p）不是
 *  包装执行，按不可识别处理（fail-closed）。名单外包装器（stdbuf/taskset 等）同样不可识别
 *  ——不猜语义（宁可拒绝复用，不虚称依赖已判定）。 */
const TRANSPARENT_WRAPPERS = new Set(["env", "timeout", "nice", "nohup", "command"]);

/** ev-20261111-fix（diting F02）：系统权威包装器目录（realpath 后的规范路径；macOS /bin →
 *  /usr/bin 由 realpath 归一）。包装器透明性只能由可证明身份建立——realpath 落在这些目录
 *  且非项目/用户可写路径才算系统包装器；其余同名脚本（本地撞名、项目 binDirs/pathPrepend
 *  内的自定义 env）按未知入口 fail-closed 拒复用，不剥高。/usr/local/bin 等用户可安装
 *  目录故意不在集合内（保守方向：误拒复用无害，误允许旧绿灯复用才是缺陷）。 */
const SYSTEM_WRAPPER_DIRS: ReadonlySet<string> = new Set(
	process.platform === "win32"
		? ["C:\\Windows\\System32", "C:\\Windows\\SysWOW64"]
		: ["/usr/bin", "/bin", "/usr/sbin", "/sbin"],
);

/** 包装器身份可证明：realpath 位于系统权威目录（符号链接全部解析后的规范路径）。 */
function isProvableSystemWrapper(realPath: string): boolean {
	return SYSTEM_WRAPPER_DIRS.has(path.dirname(realPath));
}

/** 包装器对子进程环境/工具定位的改写会使本进程侧解析失真 → recognized=false（复用面
 *  fail-closed，不借失真解析宣称依赖已判定）：env -i 清空环境；PATH 赋值改写子进程定位；
 *  go 离线钉死变量（GO_OFFLINE_ENV 面，见上）被赋值会覆盖注入权威（子 env 赋值优先于继承值）。 */
const RESOLUTION_BREAKING_ENV_KEYS = new Set(["PATH", "GOFLAGS", "GOPROXY", "GOSUMDB", "GOTOOLCHAIN", "GOENV", "GOMODCACHE"]);

/** env 的 NAME=VALUE 赋值形态（NAME 非空、首字符非数字——POSIX 变量名口径）。 */
function isEnvAssignment(tok: string): boolean {
	const eq = tok.indexOf("=");
	return eq > 0 && !/^[0-9]/.test(tok);
}

/** 取值型旗标（下一 token 是该旗标的值）；未列旗标均为布尔形态（或不支持 → fail）。 */
const WRAPPER_VALUE_FLAGS: Readonly<Record<string, ReadonlySet<string>>> = {
	env: new Set(["-u", "--unset"]),
	timeout: new Set(["-s", "--signal", "-k", "--kill-after"]),
	nice: new Set(["-n", "--adjustment"]),
};

/** 统一命令入口解析结果（ev-20261019-9321ad）。复用判定与依赖捕获（go 门控/预检/离线注入/
 *  失败分类）共用同一份——不再各看 argv[0] 字面。 */
export interface CommandEntryResolution {
	/** 剥离全部透明包装器后，真正工具 token 在 argv 中的索引。 */
	toolIndex: number;
	/** 工具 token 原文（argv[toolIndex]——预检/执行仍用该入口字面，不切换到 realpath 路径）。 */
	toolToken: string;
	/** 归一工具名（路径 token 取 basename；.exe 归一）——DEPS_REQUIRING_TOOLS 名字匹配口径。 */
	toolName: string;
	/** realpath 后的工具绝对路径（符号链接全部解析；裸名经 binDirs+PATH 定位）。不可定位 → null。 */
	realPath: string | null;
	/** realPath 的 basename（不可定位 → null）。 */
	basename: string | null;
	/** 逐层剥离的透明包装器名（外→内；无包装器 = []）。 */
	wrappers: readonly string[];
	/** 工具身份是否可证明。false=不可识别（包装器参数不可解析/查询形态/改写 PATH·清空 env·
	 *  钉死变量赋值/工具不可定位）——依赖语义不可证明，复用面必须 fail-closed（不得允许跨
	 *  对象外依赖的旧结果复用）。 */
	recognized: boolean;
	/** go 工具链判定：realpath basename=go|go.exe（异名符号链接归一到真实名）；不可定位时按
	 *  名字保守回退（isGoExecutable 字面口径——解析不弱于旧口径，只增强）。 */
	isGo: boolean;
	/** 工具 token 在解析域（pathPrepend/binDirs/宿主 PATH/自动发现目录）全链未命中可执行文件
	 *  （ev-20261101-bcee0f）——环境缺口（执行必 ENOENT），与包装器不可证明/参数不可解析（可能
	 *  实际可跑，只是无法证明语义）区分：unlocatable=true 供调用方将检查如实归类 unavailable。 */
	unlocatable: boolean;
	/** recognized=false 时的原因（审计披露；recognized=true → null）。 */
	problem: string | null;
}

/** 工具 token 定位（与 spawn 语义同源：路径 token 相对 cwd 解析；裸名经 pathPrepend → binDirs
 *  → PATH 搜索——ev-20261111-fix diting F01：pathPrepend 声明目录遮蔽宿主 PATH 时入口判定与
 *  实际 spawn 同一次序；ev-20261101-bcee0f：自动发现的用户级工具目录追加在宿主 PATH 之后
 *  ——PATH 已可解析者优先，优先级零变化，只在解析不到时兜底命中）→ realpath（符号链接全部解析）。
 *  候选不可达继续搜索；全链未命中 → 不可定位。 */
function locateToolToken(token: string, cwd: string, binDirs: readonly string[], prependDirs: readonly string[] = []): { ok: true; realPath: string; basename: string } | { ok: false } {
	const candidates = token.includes("/") || token.includes("\\")
		? [path.resolve(cwd, token)]
		: [...prependDirs.filter(Boolean), ...binDirs.filter(Boolean), ...(process.env.PATH ?? "").split(path.delimiter), ...discoverUserToolBinDirs()].map((d) => path.resolve(cwd, d, token));
	for (const cand of candidates) {
		try {
			const real = fs.realpathSync(cand);
			if (!fs.statSync(real).isFile()) continue;
			// evolve 2.21.11 复审残留：与 execvp/spawn 同口径——无执行位的同名文件被 spawn 跳过，
			// 入口解析也必须跳过（否则判定停在 A、实际执行 B，复用门控失效）。
			fs.accessSync(real, fs.constants.X_OK);
			return { ok: true, realPath: real, basename: path.basename(real) };
		} catch { /* lint-exempt:该候选不可达——继续搜索（与 spawn PATH 语义一致） */ continue; }
	}
	return { ok: false };
}

/** 包装器参数解析：返回工具 token 位置（next）。不认识的旗标/查询形态/破坏性环境改写/
 *  包装后无命令 → fail（recognized=false，不猜语义）。 */
function stripWrapperArgs(wrapper: string, argv: readonly string[], start: number): { next: number } | { fail: string } {
	let i = start;
	if (wrapper === "env") {
		for (;;) {
			const tok = argv[i];
			if (tok === undefined) return { fail: "env 后无命令 token" };
			if (tok === "-i" || tok === "--ignore-environment") return { fail: `env ${tok} 清空子进程环境——本进程侧 PATH/工具定位失真` };
			if (tok === "-u" || tok === "--unset") { i += 2; continue; }
			if (tok === "--" || tok === "-") { i += 1; return { next: i }; }
			if (tok.startsWith("-")) return { fail: `env 旗标 ${tok} 不在透明包装器认知内——不猜语义` };
			if (isEnvAssignment(tok)) {
				const name = tok.slice(0, tok.indexOf("="));
				if (RESOLUTION_BREAKING_ENV_KEYS.has(name)) return { fail: `env 赋值 ${name}=… 改写子进程定位/离线钉死变量——解析失真` };
				i += 1;
				continue;
			}
			return { next: i };
		}
	}
	if (wrapper === "timeout") {
		let expect: "duration" | "command" = "duration";
		for (;;) {
			const tok = argv[i];
			if (tok === undefined) return { fail: "timeout 后无命令 token" };
			if (tok.startsWith("--")) {
				if (tok === "--foreground" || tok === "--preserve-status") { i += 1; continue; }
				if (tok.startsWith("--signal=") || tok.startsWith("--kill-after=")) { i += 1; continue; }
				return { fail: `timeout 旗标 ${tok} 不在透明包装器认知内——不猜语义` };
			}
			if (tok.startsWith("-") && tok !== "-" && tok.length > 1) {
				if (WRAPPER_VALUE_FLAGS.timeout!.has(tok)) { i += 2; continue; }
				return { fail: `timeout 旗标 ${tok} 不在透明包装器认知内——不猜语义` };
			}
			if (expect === "duration") { expect = "command"; i += 1; continue; }
			return { next: i };
		}
	}
	if (wrapper === "nice") {
		for (;;) {
			const tok = argv[i];
			if (tok === undefined) return { fail: "nice 后无命令 token" };
			if (tok.startsWith("--")) {
				if (tok.startsWith("--adjustment=")) { i += 1; continue; }
				return { fail: `nice 旗标 ${tok} 不在透明包装器认知内——不猜语义` };
			}
			if (tok === "-n" || tok === "--adjustment") { i += 2; continue; }
			if (tok.startsWith("-") && tok.length > 1) return { fail: `nice 旗标 ${tok} 不在透明包装器认知内——不猜语义` };
			return { next: i };
		}
	}
	if (wrapper === "nohup") {
		if (argv[i] === undefined) return { fail: "nohup 后无命令 token" };
		return { next: i };
	}
	// command：仅 `command cmd` 透明；-v/-V/-p 是查询/PATH 改写形态
	const tok = argv[i];
	if (tok === undefined) return { fail: "command 后无命令 token" };
	if (tok.startsWith("-")) return { fail: `command ${tok} 是查询/旗标形态，不是透明包装执行` };
	return { next: i };
}

/** ev-20261019-9321ad：入口解析审计注记（无披露面 → null）：剥离了透明包装器、realpath 归一出
 *  与 token 不同的真实工具名（异名符号链接）、或入口不可识别/不可定位（fail-closed 披露）。
 *  evidence.ts 入 notes（纯函数，便于直测）。 */
export function commandEntryNoteOf(entry: CommandEntryResolution): string | null {
	const parts: string[] = [];
	if (entry.wrappers.length > 0) parts.push(`剥离透明包装器 ${entry.wrappers.join(" ▸ ")} → ${entry.toolToken}`);
	if (entry.realPath !== null && entry.basename !== null && entry.basename.replace(/\.exe$/i, "") !== entry.toolName) {
		parts.push(`${entry.toolToken} → 真实工具 ${entry.basename.replace(/\.exe$/i, "")}（realpath ${entry.realPath}）`);
	}
	if (!entry.recognized) {
		parts.push(entry.unlocatable
			? `入口不可定位（${entry.problem ?? "未知"}）——执行必 ENOENT，检查将如实归类 unavailable（环境缺口非测试失败）`
			: entry.isGo
				? `入口不可定位（${entry.problem ?? "未知"}）——go 判定按名字保守回退，复用面 fail-closed`
				: `入口不可识别（${entry.problem ?? "未知"}）——无法证明工具身份，复用面 fail-closed`);
	}
	if (parts.length === 0) return null;
	return `命令入口解析（ev-20261019-9321ad）：${parts.join("；")}——依赖门控/预检/离线注入/复用判定共用同一解析`;
}

/** 统一命令入口解析（ev-20261019-9321ad）：逐层剥离透明包装器 → 对最终工具 token 做 realpath
 *  定位与 basename 识别（异名符号链接归一到真实工具）。
 *  ev-20261111-fix（diting F01/F02）两个收口：
 *  - PATH 次序同源：opts.pathPrepend（受信根配置 shell.pathPrepend）优先于 binDirs/宿主
 *    PATH——项目前缀目录遮蔽宿主工具时（如前缀目录 node → 真实 go），入口判定看到的就是
 *    实际执行的那个二进制，不能再被字面名骗过；
 *  - 包装器透明性只能由可证明身份建立：realpath 落在系统权威目录（/usr/bin、/bin 等，见
 *    SYSTEM_WRAPPER_DIRS）才剥离；本地撞名/不可定位的同名脚本按未知入口 fail-closed
 *    （recognized=false，复用面拒绝），不再按 basename 推断透明性（diting F02 实证：撞名
 *    env 包装器被误剥后旧绿灯照常复用）。
 *  最终工具不可定位：名字保守回退判定 go（不弱于旧口径），但 recognized=false（身份未经
 *  realpath 确认——复用面 fail-closed）。包装器改写 PATH/清空 env/钉死变量赋值/查询形态/
 *  参数不可解析：recognized=false。 */
export function resolveCommandEntry(argv: readonly string[], opts: { cwd: string; binDirs?: readonly string[]; pathPrepend?: readonly string[] }): CommandEntryResolution {
	const binDirs = opts.binDirs ?? [];
	const prependDirs = opts.pathPrepend ?? [];
	const wrappers: string[] = [];
	const normOf = (name: string): string => name.replace(/\.exe$/i, "");
	let i = 0;
	for (;;) {
		const token = argv[i];
		if (token === undefined || token === "") {
			return { toolIndex: i, toolToken: token ?? "", toolName: "", realPath: null, basename: null, wrappers, recognized: false, isGo: false, unlocatable: false,
				problem: `${wrappers.length > 0 ? `包装器 ${wrappers[wrappers.length - 1]} 后` : "argv"}无命令 token` };
		}
		const located = locateToolToken(token, opts.cwd, binDirs, prependDirs);
		const norm = normOf(located.ok ? located.basename : path.basename(token));
		const toolName = (token.includes("/") || token.includes("\\")) ? (normOf(path.basename(token)) || token) : normOf(token) || token;
		if (TRANSPARENT_WRAPPERS.has(norm)) {
			// 名单内名字：须可证明为系统权威包装器才剥离（realpath 在系统目录）。
			// 已定位但不在系统目录（本地撞名/项目目录脚本）或全链不可定位（无文件可证）：
			// 透明性无法证明 → fail-closed，不再按封闭名单名字回退剥离（F02）。
			if (!located.ok || !isProvableSystemWrapper(located.realPath)) {
				return { toolIndex: i, toolToken: token, toolName, realPath: located.ok ? located.realPath : null, basename: located.ok ? located.basename : null,
					wrappers, recognized: false, isGo: isGoExecutable(token), unlocatable: false,
					problem: located.ok
						? `同名包装器 ${norm} 不在系统权威位置（realpath ${located.realPath}）——无法证明透明性，按未知入口处理`
						: `包装器 ${norm} 不可定位（无法证明为系统权威包装器）——按未知入口处理` };
			}
			const stripped = stripWrapperArgs(norm, argv, i + 1);
			if ("fail" in stripped) {
				return { toolIndex: i, toolToken: token, toolName, realPath: located.realPath, basename: located.basename,
					wrappers, recognized: false, isGo: false, unlocatable: false, problem: `透明包装器 ${norm} 参数不可解析：${stripped.fail}` };
			}
			wrappers.push(norm);
			i = stripped.next;
			continue;
		}
		if (located.ok) {
			return { toolIndex: i, toolToken: token, toolName, realPath: located.realPath, basename: located.basename,
				wrappers, recognized: true, isGo: isGoExecutable(located.basename), unlocatable: false, problem: null };
		}
		// 不可定位的非包装器 token：名字保守回退判定 go（不弱于旧口径），身份未确认 → 复用面 fail-closed
		return { toolIndex: i, toolToken: token, toolName, realPath: null, basename: null,
			wrappers, recognized: false, isGo: isGoExecutable(token), unlocatable: true,
			problem: `工具不可定位（${token}：pathPrepend/binDirs/系统 PATH/常见用户级目录均未命中可执行文件）——环境缺口非测试失败；可在 amagi.json shell.pathPrepend 声明工具目录` };
	}
}

export function escapeModulePathForCache(p: string): string {
	return p.replace(/[A-Z]/g, (c) => "!" + c.toLowerCase());
}

export interface GoPrivateCachePrep {
	ok: boolean;
	/** ok=true：私有缓存根（其 cache/download 子树为 GOPROXY=file:// 本地镜像；执行面 GOMODCACHE 钉到该根）。 */
	privateCache?: string;
	/** ok=true：拷贝的模块工件组数（每模块 .mod/.info/.zip/.ziphash 现存件）。 */
	modulesCopied?: number;
	/** ok=true：拷贝总字节（不含文件系统开销）。 */
	bytes?: number;
	/** replace 到本地目录的目标清单（无缓存工件；执行期直接读原路径——依赖未冻结，如实披露+禁复用）。 */
	localReplaceTargets?: readonly string[];
	/** ok=false：不可建立私有缓存的原因（→ 检查 unavailable，不降格）。 */
	reason?: string;
}

/**
 * 任务私有 Go 模块缓存准备（F6）：把预检模块图的 download 工件（.mod/.info/.zip/.ziphash）从宿主
 * GOMODCACHE 只读拷贝到私有目录——执行面 GOMODCACHE=私有根 + GOPROXY=file://私有镜像：go 按需
 * 从本地 zip 副本解压源码（写入只落在私有缓存），宿主缓存零写入（不自动下载、不联网；file:// 仅
 * 本地文件）。模块既无 zip 也无已解压源码 → 不可建立（如实 unavailable，不猜成功）。拷贝有界
 * （DEFAULT_DEPENDENCY_LIMITS：字节/条目/时长，超限如实失败不降格）。
 * 注意：本地目录 replace 不入缓存（执行期直读原路径）——依赖未冻结，调用方须披露且禁复用（F8）。
 */
export function prepareGoPrivateModuleCache(
	hostCache: string,
	modules: readonly GoListModule[],
	opts?: { limits?: Partial<DependencyCaptureLimits>; tmpDir?: string },
): GoPrivateCachePrep {
	const startedAt = Date.now();
	const limits: DependencyCaptureLimits = { ...DEFAULT_DEPENDENCY_LIMITS, ...opts?.limits };
	let privateCache: string;
	try { privateCache = fs.mkdtempSync(path.join(opts?.tmpDir ?? os.tmpdir(), "amagi-gomod-")); }
	catch (e) { return { ok: false, reason: `私有缓存目录创建失败: ${String((e as Error)?.message ?? e).slice(0, 120)}` }; }
	const fail = (reason: string): GoPrivateCachePrep => {
		try { fs.rmSync(privateCache, { recursive: true, force: true }); } catch { /* lint-exempt:失败路径清理尽力而为，系统 tmp 回收兑底 */ }
		return { ok: false, reason };
	};
	const localReplaceTargets: string[] = [];
	let modulesCopied = 0;
	let bytes = 0;
	let entries = 0;
	for (const m of modules) {
		if (m.localDir !== undefined) { localReplaceTargets.push(m.localDir); continue; }
		if (Date.now() - startedAt > limits.deadlineMs) return fail(`私有缓存拷贝超时（>${limits.deadlineMs}ms，拷到 ${modulesCopied} 模块）——有界失败，不降格`);
		const modulePath = escapeModulePathForCache(m.path);
		const dlSrc = path.join(hostCache, "cache", "download", modulePath, "@v");
		const dlDst = path.join(privateCache, "cache", "download", modulePath, "@v");
		const ver = escapeModulePathForCache(m.version);
		let copiedAny = false;
		let hasZip = false;
		const srcDir = path.join(hostCache, escapeModulePathForCache(m.path) + "@" + ver);
		let srcDirExists = false;
		try { srcDirExists = fs.statSync(srcDir).isDirectory(); } catch { srcDirExists = false; /* lint-exempt:stat 失败按无源码目录处理（保守 unavailable 方向） */ }
		for (const suffix of [".mod", ".info", ".zip", ".ziphash"]) {
			const src = path.join(dlSrc, ver + suffix);
			let st: fs.Stats;
			try { st = fs.statSync(src); } catch { continue; /* lint-exempt:工件现存件才拷（缺席跳过） */ }
			const dst = path.join(dlDst, ver + suffix);
			try {
				fs.mkdirSync(dlDst, { recursive: true });
				fs.copyFileSync(src, dst);
				copiedAny = true;
				if (suffix === ".zip") hasZip = true;
				bytes += st.size;
				if (++entries > limits.maxEntries) return fail(`私有缓存条目数超限（>${limits.maxEntries}）——有界失败，不降格`);
			} catch (e) {
				return fail(`私有缓存拷贝失败 ${m.path}@${ver}${suffix}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
			}
		}
		// 源码既无 zip 也未解压（仅 .mod 只能解析模块图，不能构建）→ 不可建立：如实 unavailable，
		// 不放行到执行期报真实 failed（环境捕获不完备 ≠ 检查失败；diting F8 复审口径）。
		if (!hasZip && !srcDirExists) {
			return fail(`模块 ${m.path}@${ver} 在宿主缓存既无 zip 也无已解压源码（仅 .mod 只能解析模块图，不能构建）——私有缓存不可建立（检查不可在快照上联网安装依赖）`);
		}
		// 已解压源码在场而 download 工件缺失（如手工解压形态）：直接拷贝源码目录（等效离线就绪）。
		if (srcDirExists && !copiedAny) {
			const dstDir = path.join(privateCache, escapeModulePathForCache(m.path) + "@" + ver);
			try {
				const copyTree = (src: string, dst: string): void => {
					fs.mkdirSync(dst, { recursive: true });
					for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
						const s = path.join(src, ent.name), d = path.join(dst, ent.name);
						if (ent.isDirectory()) copyTree(s, d);
						else if (ent.isSymbolicLink()) fs.symlinkSync(fs.readlinkSync(s), d);
						else { fs.copyFileSync(s, d); bytes += fs.statSync(s).size; if (++entries > limits.maxEntries) throw new Error("条目数超限"); }
						if (Date.now() - startedAt > limits.deadlineMs) throw new Error("超时");
					}
				};
				copyTree(srcDir, dstDir);
			} catch (e) {
				return fail(`私有缓存源码目录拷贝失败 ${m.path}@${ver}: ${String((e as Error)?.message ?? e).slice(0, 120)}`);
			}
		}
		if (copiedAny || srcDirExists) modulesCopied++;
		if (bytes > limits.maxBytes) return fail(`私有缓存字节数超限（>${limits.maxBytes}B）——有界失败，不降格`);
	}
	return { ok: true, privateCache, modulesCopied, bytes, localReplaceTargets };
}

/** 宿主 GOMODCACHE 解析兜底：env 显式值缺席时经 `go env GOMODCACHE`（继承环境，含 GOENV 文件
 *  决议）取子进程实际会用的缓存根——保证预检/拷贝/执行解析同一缓存。失败 → null（调用方保守
 *  unavailable，不猜路径）。ev-20261021-fix（diting F6）。 */
export async function resolveGoModCacheViaGoEnv(runner: GoPreflightRunner, cwd: string, executable = "go"): Promise<string | null> {
	try {
		const r = await runner([executable, "env", "GOMODCACHE"], cwd, 10_000, {});
		if (r.code !== 0 || r.timedOut) return null;
		const v = r.stdout.trim().split("\n")[0]?.trim();
		return v && path.isAbsolute(v) ? v : null;
	} catch { return null; /* lint-exempt:go env 解析失败回退 null，调用方保守 unavailable */ }
}

/** 宿主模块缓存递归元数据观测（条目名+mtimeMs，不跟随符号链接）。
 *  超限或读取失败标不可比较。相等只代表未检测到元数据变化，不证明字节相同或期间从未写入。 */
export interface GoCacheSurface {
	entries: Map<string, number>;
	truncated: boolean;
	error?: string;
}

export function snapshotGoCacheSurface(hostCache: string, maxEntries = 50_000): GoCacheSurface {
	const entries = new Map<string, number>();
	const walk = (dir: string, prefix: string): boolean => {
		let ents: fs.Dirent[];
		ents = fs.readdirSync(dir, { withFileTypes: true }); // unreadable surface is not comparable
		for (const e of ents) {
			const rel = prefix ? `${prefix}/${e.name}` : e.name;
			entries.set(rel, fs.lstatSync(path.join(dir, e.name)).mtimeMs);
			if (entries.size > maxEntries) return false;
			if (e.isDirectory()) { // recurse all real directories; never follow symlinks
				if (!walk(path.join(dir, e.name), rel)) return false;
			}
		}
		return true;
	};
	try {
		const truncated = !walk(hostCache, "");
		return { entries, truncated };
	} catch (e) {
		return { entries, truncated: true, error: String((e as Error)?.message ?? e).slice(0, 120) };
	}
}

/** 两次缓存面快照差异（新增/移除/mtime 变化路径清单；空=未检测到写入）。 */
export function diffGoCacheSurface(before: GoCacheSurface, after: GoCacheSurface): { added: string[]; removed: string[]; changed: string[]; comparable: boolean } {
	if (before.error || after.error || before.truncated || after.truncated) return { added: [], removed: [], changed: [], comparable: false };
	const added: string[] = [], removed: string[] = [], changed: string[] = [];
	for (const [k, v] of after.entries) {
		const b = before.entries.get(k);
		if (b === undefined) added.push(k);
		else if (b !== v) changed.push(k);
	}
	for (const k of before.entries.keys()) if (!after.entries.has(k)) removed.push(k);
	return { added, removed, changed, comparable: true };
}
