/**
 * wsl-windows-home.ts — WSL 内定位 Windows 侧用户主目录（只读发现）。
 *
 * 根因：WSL 里 os.homedir() 是 Linux 家目录（/home/<user>），而跨工具共享的 `~/.agents/.mcp.json`
 * 等配置通常放在 Windows 用户目录（C:\Users\<name>\.agents）——WSL 模式启动 pi 时按 Linux 家目录
 * 找不到，Windows 侧配置的 MCP 整体不加载。
 *
 * 发现顺序（仅 WSL；非 WSL 恒返回 undefined）：
 *   ① 显式覆盖 AMAGI_WIN_USERPROFILE / AMAGI_WINDOWS_HOME（Windows 形态 C:\Users\x 或挂载形态均可；
 *      AMAGI_WINDOWS_HOME=0/off 关闭本发现）；
 *   ② 经 WSLENV 透传的 USERPROFILE（Windows 形态）；
 *   ③ 扫描 <mnt>/<盘>/Users/<name>：含 `.agents` 目录的候选里，与 Linux 用户名同名（大小写不敏感）者优先；
 *      无同名时仅当候选唯一才采用（多用户歧义不猜，避免读到别人的配置/凭据）。
 * 只读目录探测；挂载根经 /etc/wsl.conf [automount] root（wslMntRoot）；结果缓存 60s。
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { wslMntRoot } from "./win-exec-mnt.ts";
import { isWindowsAbsolutePath, windowsToLinuxPath } from "./win-exec-paths.ts";

export interface WindowsHomeDeps {
	env?: NodeJS.ProcessEnv;
	platform?: NodeJS.Platform;
	readProcVersion?: () => string;
	mntRoot?: string;
	linuxUser?: string;
	readdir?: (p: string) => string[];
	isDir?: (p: string) => boolean;
}

export interface WindowsHomeResult {
	home?: string;
	/** 发现来源/未发现原因（诊断用）。 */
	note: string;
}

const SKIP_USERS = new Set(["public", "default", "default user", "all users", "defaultuser0", "desktop.ini"]);
const CACHE_MS = 60_000;
let cached: { at: number; key: string; value: WindowsHomeResult } | undefined;

export function resetWindowsHomeCache(): void { cached = undefined; }

function fsReaddir(p: string): string[] { try { return fs.readdirSync(p); } catch { return []; /* lint-exempt:探测失败=无候选 */ } }
function fsIsDir(p: string): boolean { try { return fs.statSync(p).isDirectory(); } catch { return false; /* lint-exempt:探测失败=不存在 */ } }

/** WSL 信号（与 win-exec.detectWslEnvironment 同口径；独立实现避免 mcp-config → win-exec 依赖环）。 */
function isWsl(deps: WindowsHomeDeps, env: NodeJS.ProcessEnv): boolean {
	if ((deps.platform ?? process.platform) === "win32") return false;
	if (env.WSL_DISTRO_NAME || env.WSL_INTEROP) return true;
	try { return /microsoft/i.test(deps.readProcVersion ? deps.readProcVersion() : fs.readFileSync("/proc/version", "utf8")); } catch { return false; /* lint-exempt:/proc 不可读 → 非 WSL */ }
}

export function discoverWindowsHome(deps: WindowsHomeDeps = {}): WindowsHomeResult {
	const env = deps.env ?? process.env;
	const off = (env.AMAGI_WINDOWS_HOME ?? "").trim().toLowerCase();
	if (off === "0" || off === "off" || off === "false") return { note: "AMAGI_WINDOWS_HOME 已关闭 Windows 家目录发现" };
	if (!isWsl(deps, env)) return { note: "非 WSL 环境" };
	const mnt = deps.mntRoot ?? wslMntRoot();
	const isDir = deps.isDir ?? fsIsDir;
	// explicit=显式覆盖项：Windows 形态换算，也接受任意 Linux 绝对目录（自定义挂载点）；USERPROFILE 仅认 Windows 形态。
	const toLinux = (v: string | undefined, explicit: boolean): string | undefined => {
		const s = (v ?? "").trim();
		if (!s) return undefined;
		if (isWindowsAbsolutePath(s)) return windowsToLinuxPath(s, { mntRoot: mnt }) ?? undefined;
		return explicit && path.posix.isAbsolute(s) && !s.split("/").includes("..") ? s.replace(/\/+$/, "") : undefined;
	};
	for (const [key, name, explicit] of [["AMAGI_WIN_USERPROFILE", "AMAGI_WIN_USERPROFILE", true], ["AMAGI_WINDOWS_HOME", "AMAGI_WINDOWS_HOME", true], ["USERPROFILE", "USERPROFILE(WSLENV)", false]] as const) {
		const p = toLinux(env[key], explicit);
		if (p && isDir(p)) return { home: p, note: `${name}=${p}` };
	}
	const readdir = deps.readdir ?? fsReaddir;
	const linuxUser = (deps.linuxUser ?? (() => { try { return os.userInfo().username; } catch { return env.USER ?? ""; /* lint-exempt:userInfo 失败回退 USER */ } })()).toLowerCase();
	const candidates: { name: string; dir: string }[] = [];
	for (const drive of readdir(mnt).filter((d) => /^[A-Za-z]$/.test(d)).sort()) {
		const usersDir = path.posix.join(mnt, drive, "Users");
		for (const name of readdir(usersDir)) {
			if (SKIP_USERS.has(name.toLowerCase())) continue;
			const dir = path.posix.join(usersDir, name);
			if (isDir(path.posix.join(dir, ".agents"))) candidates.push({ name, dir });
		}
	}
	const same = candidates.filter((c) => c.name.toLowerCase() === linuxUser);
	if (same.length > 0) return { home: same[0]!.dir, note: `扫描 ${mnt}/<盘>/Users，与 Linux 用户名同名：${same[0]!.dir}` };
	if (candidates.length === 1) return { home: candidates[0]!.dir, note: `扫描 ${mnt}/<盘>/Users，唯一含 .agents 的用户目录：${candidates[0]!.dir}` };
	if (candidates.length > 1) return { note: `发现多个含 .agents 的 Windows 用户目录（${candidates.map((c) => c.dir).join("、")}）且无同名项，不猜测；设置 AMAGI_WIN_USERPROFILE 指定` };
	return { note: `未在 ${mnt}/<盘>/Users 下找到含 .agents 的用户目录` };
}

/** 带缓存的 Windows 家目录（生产入口；deps 注入时不缓存，供测试）。 */
export function windowsHomeDir(deps?: WindowsHomeDeps): string | undefined {
	if (deps) return discoverWindowsHome(deps).home;
	const env = process.env;
	const key = `${env["AMAGI_WIN_USERPROFILE"] ?? ""}|${env.AMAGI_WINDOWS_HOME ?? ""}|${env.USERPROFILE ?? ""}`;
	const now = Date.now();
	if (cached && cached.key === key && now - cached.at < CACHE_MS) return cached.value.home;
	const value = discoverWindowsHome();
	cached = { at: now, key, value };
	return value.home;
}

// ── WSL 内 stdio MCP 命令适配 ────────────────────────────────────────────────
// Windows 侧写的 .mcp.json（项目根/.agents/Windows 家目录）常含 `D:\\tools\\x.exe`、`cmd /c npx …` 形态；
// WSL 里 node spawn 无法执行 Windows 盘符路径，也常没有 interop PATH——server 表面「没加载」实为起不来。
// 仅 WSL 生效：盘符路径换算为 <automount>/<盘>/…（.exe 经 WSL interop 直接可执行）；`cmd /c <prog> …` 去壳为 `<prog> …`。

let wslCache: boolean | undefined;
export function isWslHost(): boolean {
	if (wslCache === undefined) wslCache = isWsl({}, process.env);
	return wslCache;
}
export function resetWslHostCache(): void { wslCache = undefined; }

export interface StdioAdaptResult { command: string; args: string[]; env: Record<string, string>; changed: boolean; /** 目标是 Windows 程序（经 interop 启动）：args/env 保持 Windows 形态，env 键须经 WSLENV 透传。 */ windowsTarget: boolean; wslenvKeys: string[] }

/** 纯函数：把一个 stdio server 的 command/args/env 中的 Windows 盘符路径换算为 WSL 挂载路径。 */
export function adaptStdioForWsl(input: { command: string; args: string[]; env: Record<string, string> }, mntRoot: string): StdioAdaptResult {
	let changed = false;
	const conv = (v: string): string => {
		const whole = isWindowsAbsolutePath(v) ? windowsToLinuxPath(v, { mntRoot }) : null;
		if (whole) { changed = true; return whole; }
		const m = /^([^=]*=)([A-Za-z]:[\\/].*)$/.exec(v);
		if (m) { const p = windowsToLinuxPath(m[2]!, { mntRoot }); if (p) { changed = true; return `${m[1]}${p}`; } }
		return v;
	};
	let command = input.command;
	let args = [...input.args];
	// cmd /c <prog> … → <prog> …（Windows 壳在 WSL 无意义；prog 为 npx/node 等 Linux 可用程序）
	if (/^(?:.*[\\/])?cmd(?:\.exe)?$/i.test(command) && /^\/c$/i.test(args[0] ?? "") && args[1]) {
		command = args[1]!; args = args.slice(2); changed = true;
	}
	command = conv(command);
	// Windows 程序（.exe/.bat/.cmd，经 WSL interop 启动）自己读盘符路径：只换算程序路径，args/env 值保持 Windows 形态
	//（换成 /mnt/... 它读不到）；且 WSL 进程的环境变量默认不跨进程边界，须经 WSLENV 透传（否则如 ELECTRON_RUN_AS_NODE 丢失，
	// Electron 程序当 GUI 启动而非 Node，stdio 立即关闭 → 「MCP connection closed」）。
	const mntPrefix = `${mntRoot.replace(/\/+$/, "")}/`;
	const windowsTarget = /\.(?:exe|bat|cmd)$/i.test(command) && (command.startsWith(mntPrefix) || isWindowsAbsolutePath(input.command));
	if (windowsTarget) return { command, args, env: input.env, changed, windowsTarget, wslenvKeys: Object.keys(input.env) };
	args = args.map(conv);
	const env = Object.fromEntries(Object.entries(input.env).map(([k, v]) => [k, conv(v)]));
	return { command, args, env, changed, windowsTarget: false, wslenvKeys: [] };
}

/** 命令是否可在 PATH 中解析（仅 WSL 诊断用；含执行位检查）。 */
export function commandOnPath(command: string, env: NodeJS.ProcessEnv = process.env): boolean {
	for (const dir of (env.PATH ?? "").split(":").filter(Boolean)) {
		try { fs.accessSync(path.posix.join(dir, command), fs.constants.X_OK); return true; } catch { /* lint-exempt:该目录无此命令 */ }
	}
	return false;
}
