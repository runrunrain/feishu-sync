/**
 * process-audit.ts — 子进程后代/孙进程审计与残留自动回收（ev-20260909-1face0/P2）。
 *
 * 现状事实：子 Agent 冒烟泄漏孙进程（如 tsx watch 占端口）无框架收尾，实战残留 authority
 * 进程两代存活，后续验证 EADDRINUSE。
 *
 * 机制：
 *   - 运行期间动态追踪：记录子进程 rootPid，周期性（或重要工具执行后）通过 `ps axo pid,ppid,lstart,command`
 *     单次快照构建 PPID 树，累计「曾见过」的本子进程后代 PID 集。即使孤儿孙进程在子进程退出后
 *     PPID 变为 1，已在「曾见过」集合中定格，不会走丢。
 *   - 终态收尾审计：子进程退出时，对累计集合 + 终态快照再查存活；若存活则依次执行
 *     SIGTERM → 2s 宽限 → SIGKILL 回收，并在完成报告/结果附注中披露：
 *     `[进程清理] 回收 N 个残留进程: <摘要>`；无残留零噪音。
 *   - 平台与安全底线：仅 darwin/linux 生效；每次信号前重查 pid/lstart/command；ps 不可用、身份缺失或改变则跳过并记录
 *     （best-effort；PID 信号存在查询到发信号之间的非原子窗口，不宣称原子进程句柄保证）。仅杀确认血缘内的存活后代，pid <= 1 硬拒绝。
 *   - ev-20261008-30e744（R4）：根身份未知（出生探针不可用/未捕获）但活树仍可见（根 pid 存活）时，
 *     终态快照不首次认领根、也不产生任何信号授权——安全跳过必须留可观察证据：落审计 unknown/skip
 *     决策 + 非空摘要，不得静默返回空结果。已确认回收的正常路径（根已绑定且退出、零残留）保持零噪音不变。
 *   - ev-20261008-30e744（B7 终态锚点）：回收摘要每项携带可核对锚点——taskId/rootPid、首次
 *     确认血缘链（PPID 链+命令串+出生标识+首次观测时刻）与终态身份核对结论；尾注给审计日志
 *     可追溯路径（未配置路径时显式披露，不静默）。命令串过进程展示脱敏策略（F01，完整遮蔽
 *     KEY/TOKEN/SECRET 类赋值）；审计落盘投影（rootIdentity/observations/decisions 的全部
 *     命令字符串）统一同策略脱敏——审计 JSON 零明文（F02，不保留原始证据面）；内存身份比较
 *     仍用原始 command，授权语义不受脱敏影响；不展示 env/ps 全量。
 *   - 开关：AMAGI_PROC_AUDIT=0/false 关闭（默认开），docs/env-knobs.md 记录。
 */

import { execFile, execFileSync } from "node:child_process";
import { promisify } from "node:util";
import * as fs from "node:fs";
import * as path from "node:path";
import { redactProcessDisplayText } from "./task-query-wire.ts";

const execFileAsync = promisify(execFile);

export interface ProcessInfo {
	pid: number;
	ppid: number;
	command: string;
	/** ps lstart birth timestamp, absent in old/unsupported snapshots (never signal those). */
	startToken?: string;
	/** OS incarnation token; second-resolution lstart alone never authorizes signals. */
	identityToken?: string;
}

export interface ProcessAuditResult {
	cleanedCount: number;
	summary: string;
	pids: number[];
}

/** ev-20261008-30e744（B7）：单个回收项的可核对锚点——taskId/rootPid、首次确认血缘快照
 *  （PPID 链/命令串/出生标识/首次观测时刻）与终态身份核对结论；摘要展示与审计落盘共用形状。 */
export interface ReapedAnchor {
	pid: number;
	taskId: string | undefined;
	rootPid: number;
	firstLineagePids: number[];
	firstLineageCommands: string[];
	birth: string;
	firstObservedAt: string;
	finalIdentityCheck: string;
	command: string;
}

/** F02（B7 修复轮）：审计落盘投影——ProcessInfo 的命令串统一过进程展示脱敏策略；
 *  内存身份比较（sameIdentity/lineage 核验）仍用原始 command，不受投影影响。 */
function auditSafeInfo(p: ProcessInfo): ProcessInfo {
	return { ...p, command: redactProcessDisplayText(p.command) };
}

export interface ProcessAuditDeps {
	platform?: NodeJS.Platform;
	env?: NodeJS.ProcessEnv;
	runPs?: () => Promise<string>;
	kill?: (pid: number, signal: NodeJS.Signals) => void;
	isAlive?: (pid: number) => boolean;
	sleep?: (ms: number) => Promise<void>;
	log?: (msg: string) => void;
	taskId?: string;
	cwd?: string;
	parentPid?: number;
	auditPath?: string;
	/** Trusted token captured at spawn, never learned from a delayed running snapshot. */
	rootBirthToken?: string;
	rootBirthPromise?: Promise<string | undefined>;
}

const SAMPLE_THROTTLE_MS = 1000;
const TERM_GRACE_MS = 2000;

/** 总开关：AMAGI_PROC_AUDIT=0/false 关闭整套审计与清理（默认开启）。 */
export function isProcessAuditEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const v = env.AMAGI_PROC_AUDIT;
	return !(v === "0" || /^(false|off|no)$/i.test(v || ""));
}

/** 解析 `ps axo pid,ppid,command` 输出（纯函数）。 */
export function parsePsOutput(raw: string): ProcessInfo[] {
	if (!raw || typeof raw !== "string") return [];
	const lines = raw.split("\n");
	const result: ProcessInfo[] = [];
	for (const line of lines) {
		const trimmed = line.trim();
		if (!trimmed) continue;
		const match = trimmed.match(/^(\d+)\s+(\d+)\s+(.*)$/);
		if (!match) continue; // 跳过标题行（PID PPID COMMAND）或不合规行
		const pid = parseInt(match[1], 10);
		const ppid = parseInt(match[2], 10);
		const rest = match[3].trim();
		const birth = rest.match(/^([A-Za-z]{3}\s+[A-Za-z]{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}\s+\d{4})\s+(.*)$/);
		const tail = birth ? birth[2] : rest;
		const identity = tail.match(/^\[amagi-birth:([^\]\s]+)\]\s+(.*)$/);
		const command = identity ? identity[2] : tail;
		const identityToken = identity?.[1];
		const startToken = birth?.[1].replace(/\s+/g, " ");
		if (Number.isInteger(pid) && Number.isInteger(ppid)) {
			result.push({ pid, ppid, command, ...(startToken ? { startToken } : {}), ...(identityToken ? { identityToken } : {}) });
		}
	}
	return result;
}

/**
 * 构建以后代树根集（rootPids）为祖先的所有后代 PID 集合（广度优先遍历，纯函数）。
 * 不包含 rootPids 集合本身。防御循环依赖。
 */
export function findDescendants(
	rootPids: number | ReadonlySet<number> | ReadonlyArray<number>,
	processes: ProcessInfo[],
): Set<number> {
	const roots = new Set<number>(
		typeof rootPids === "number" ? [rootPids] : Array.from(rootPids),
	);
	const parentToChildren = new Map<number, number[]>();
	for (const p of processes) {
		const list = parentToChildren.get(p.ppid);
		if (list) {
			list.push(p.pid);
		} else {
			parentToChildren.set(p.ppid, [p.pid]);
		}
	}

	const descendants = new Set<number>();
	const queue: number[] = [];
	for (const root of roots) {
		const children = parentToChildren.get(root);
		if (children) queue.push(...children);
	}

	while (queue.length > 0) {
		const curr = queue.shift()!;
		if (!roots.has(curr) && !descendants.has(curr)) {
			descendants.add(curr);
			const nextChildren = parentToChildren.get(curr);
			if (nextChildren) queue.push(...nextChildren);
		}
	}

	return descendants;
}

export interface KernelProcessIdentity { pid: number; ppid: number; pgid: number; identityToken: string; }
// Darwin ABI matches SDK sys/proc_info.h proc_bsdinfo (PROC_PIDTBSDINFO=3).
// Python's standard-library ctypes is optional: if unavailable, identity stays unknown and signals are skipped.
const DARWIN_BIRTH_PROBE = `import ctypes,json,sys
class B(ctypes.Structure):
 _fields_=[("head",ctypes.c_uint32*12),("comm",ctypes.c_char*16),("name",ctypes.c_char*32),("tail",ctypes.c_uint32*6),("sec",ctypes.c_uint64),("usec",ctypes.c_uint64)]
lib=ctypes.CDLL("/usr/lib/libproc.dylib")
lib.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
lib.proc_pidinfo.restype=ctypes.c_int
out=[]
for pid in json.loads(sys.argv[1]):
 b=B()
 if lib.proc_pidinfo(pid,3,0,ctypes.byref(b),ctypes.sizeof(b))==ctypes.sizeof(b) and b.head[3]==pid and b.sec:
  out.append({"pid":pid,"ppid":int(b.head[4]),"pgid":int(b.tail[1]),"identityToken":"darwin:%s:%s"%(b.sec,b.usec)})
print(json.dumps(out))`;

/** Precise kernel birth facts; an unavailable platform/probe grants no cleanup authority. */
function collectKernelProcessIdentities(pids: readonly number[]): Map<number, KernelProcessIdentity> {
	const out = new Map<number, KernelProcessIdentity>();
	const selected = [...new Set(pids.filter(p => Number.isInteger(p) && p > 1))].slice(0, 16_384);
	try {
		if (process.platform === "darwin") {
			const raw = execFileSync("/usr/bin/python3", ["-c", DARWIN_BIRTH_PROBE, JSON.stringify(selected)], { timeout: 1500, maxBuffer: 4 * 1024 * 1024, encoding: "utf8" });
			for (const p of JSON.parse(raw) as KernelProcessIdentity[]) if (selected.includes(p.pid) && typeof p.identityToken === "string" && /^darwin:\d+:\d+$/.test(p.identityToken)) out.set(p.pid, p);
		} else if (process.platform === "linux") {
			const boot = fs.readFileSync("/proc/sys/kernel/random/boot_id", "utf8").trim();
			for (const pid of selected) {
				try {
					const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf8"), fields = stat.slice(stat.lastIndexOf(")") + 2).split(/\s+/);
					if (/^\d+$/.test(fields[19] ?? "")) out.set(pid, { pid, ppid: Number(fields[1]), pgid: Number(fields[2]), identityToken: `linux:${boot}:${fields[19]}` });
				} catch { /* lint-exempt:进程退出或身份不可读时不授予信号权 */ }
			}
		}
	} catch { /* lint-exempt:unavailable native source: never substitute rounded ps timestamps */ }
	return out;
}

/** Two complete collections reject cross-generation ancestry assembled during enumeration.
 * Numeric PID signaling still has an unavoidable lookup-to-signal race; this is conservative best effort,
 * not an atomic pidfd/process-handle guarantee. Missing or changed facts never authorize a signal. */
export function readKernelProcessIdentities(pids: readonly number[]): Map<number, KernelProcessIdentity> {
	const first = collectKernelProcessIdentities(pids), second = collectKernelProcessIdentities(pids);
	return new Map([...first].filter(([pid, p]) => { const q = second.get(pid); return q && p.identityToken === q.identityToken && p.ppid === q.ppid && p.pgid === q.pgid; }));
}

/** Runtime sampling must never block the JSONL event loop while a model is producing frames. */
export async function readKernelProcessIdentitiesAsync(pids: readonly number[]): Promise<Map<number, KernelProcessIdentity>> {
	if (process.platform !== "darwin") return readKernelProcessIdentities(pids);
	const selected = [...new Set(pids.filter(p => Number.isInteger(p) && p > 1))].slice(0, 16_384);
	const collect = async (): Promise<Map<number, KernelProcessIdentity>> => {
		try {
			const { stdout } = await execFileAsync("/usr/bin/python3", ["-c", DARWIN_BIRTH_PROBE, JSON.stringify(selected)], { timeout: 1500, maxBuffer: 4 * 1024 * 1024 });
			return new Map((JSON.parse(String(stdout)) as KernelProcessIdentity[]).filter(p => selected.includes(p.pid) && /^darwin:\d+:\d+$/.test(p.identityToken)).map(p => [p.pid, p]));
		} catch { /* journal:native-process-identity-unavailable */ return new Map(); }
	};
	const first = await collect(), second = await collect();
	return new Map([...first].filter(([pid, p]) => { const q = second.get(pid); return q && p.identityToken === q.identityToken && p.ppid === q.ppid && p.pgid === q.pgid; }));
}

async function defaultRunPs(): Promise<string> {
	const { stdout } = await execFileAsync("ps", ["axo", "pid,ppid,lstart,command"], {
		timeout: 3000,
		maxBuffer: 8 * 1024 * 1024,
		env: { ...process.env, LC_ALL: "C" },
		killSignal: "SIGKILL",
	});
	const raw = String(stdout ?? "");
	const processes = parsePsOutput(raw), identities = await readKernelProcessIdentitiesAsync(processes.map(p => p.pid));
	return processes.map(p => {
		const identity = identities.get(p.pid);
		const token = identity && identity.ppid === p.ppid ? identity.identityToken : undefined;
		return `${p.pid} ${p.ppid} ${p.startToken ?? ""} ${token ? `[amagi-birth:${token}] ` : ""}${p.command}`;
	}).join("\n");
}

function defaultIsAlive(pid: number): boolean {
	if (!Number.isInteger(pid) || pid <= 1) return false;
	try {
		process.kill(pid, 0);
		return true;
	} catch (err: any) {
		return err?.code === "EPERM";
	}
}

function defaultKill(pid: number, signal: NodeJS.Signals): void {
	if (!Number.isInteger(pid) || pid <= 1) return;
	process.kill(pid, signal);
}

function defaultSleep(ms: number): Promise<void> {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * 进程审计器：绑定单个子任务进程，在生命周期内累计后代并在终态回收残留。
 */
export class ProcessAuditor {
	readonly rootPid: number;
	private deps: ProcessAuditDeps;
	private seenDescendants = new Set<number>();
	private observed = new Map<number, { process: ProcessInfo; lineage: ProcessInfo[]; observedAt: number }>();
	private rootIdentity?: ProcessInfo;
	private rootBirthToken?: string;
	rootBirthPromise?: Promise<string | undefined>;
	private samplePromise?: Promise<void>;
	private sampling = false;
	private lastSampleMs = 0;

	constructor(rootPid: number, deps: ProcessAuditDeps = {}) {
		this.rootPid = rootPid;
		this.deps = deps;
		this.rootBirthToken = deps.rootBirthToken;
	}

	getRootBirthToken(): string | undefined { return this.rootBirthToken; }
	getSeenBirthTokens(): Map<number, string> { return new Map([...this.observed].filter(([, o]) => o.process.identityToken).map(([pid, o]) => [pid, o.process.identityToken!])); }

	/** 获取目前为止曾见过的所有后代 PID 快照 */
	getSeenDescendants(): Set<number> {
		return new Set(this.seenDescendants);
	}

	/** 记录一次 ps 输出文本快照，更新后代集合与命令映射（纯逻辑处理） */
	recordSnapshot(rawPsOutput: string, allowRootCapture = true): Set<number> {
		const procs = parsePsOutput(rawPsOutput), byPid = new Map(procs.map(p => [p.pid, p]));
		const root = byPid.get(this.rootPid);
		if (!this.rootIdentity && this.rootBirthToken && root?.identityToken === this.rootBirthToken && allowRootCapture && root && (this.deps.parentPid === undefined || root.ppid === this.deps.parentPid)) this.rootIdentity = { ...root };
		const roots = new Set<number>();
		if (root && this.rootIdentity && this.sameIdentity(this.rootIdentity, root)) roots.add(this.rootPid);
		// A historical PID is an ancestor only while it still names the same observed incarnation.
		for (const [pid, old] of this.observed) if (byPid.has(pid) && this.sameIdentity(old.process, byPid.get(pid)!)) roots.add(pid);
		const descendants = findDescendants(roots, procs);
		for (const pid of descendants) {
			if (this.observed.has(pid) || pid <= 1 || pid === this.rootPid) continue;
			const proc = byPid.get(pid)!;
			const lineage: ProcessInfo[] = [proc];
			let parent = proc.ppid; const visited = new Set<number>([pid]);
			while (!visited.has(parent)) {
				visited.add(parent);
				const historical = this.observed.get(parent);
				if (historical && roots.has(parent)) { lineage.push(...[...historical.lineage].reverse()); break; }
				const ancestor = byPid.get(parent); if (!ancestor) break;
				lineage.push(ancestor); if (parent === this.rootPid) break; parent = ancestor.ppid;
			}
			if (!lineage.some(p => p.pid === this.rootPid)) continue;
			this.seenDescendants.add(pid);
			this.observed.set(pid, { process: { ...proc }, lineage: lineage.reverse().map(p => ({ ...p })), observedAt: Date.now() });
		}
		return new Set(this.seenDescendants);
	}

	private sameIdentity(a: ProcessInfo, b: ProcessInfo): boolean {
		return !!a.identityToken && !!b.identityToken && a.pid === b.pid && a.identityToken === b.identityToken && a.command === b.command;
	}

	/** 周期性采样（异步，失败静默） */
	async sample(force: boolean = false): Promise<void> {
		const platform = this.deps.platform ?? process.platform;
		if (platform !== "darwin" && platform !== "linux") return;
		if (!isProcessAuditEnabled(this.deps.env ?? process.env)) return;
		const now = Date.now();
		if (!force && now - this.lastSampleMs < SAMPLE_THROTTLE_MS) return;
		if (this.sampling) return;
		this.sampling = true;
		this.lastSampleMs = now;
		this.samplePromise = (async () => {
			try {
				if (!this.rootBirthToken && this.deps.rootBirthPromise) this.rootBirthToken = await this.deps.rootBirthPromise;
				this.recordSnapshot(await (this.deps.runPs ?? defaultRunPs)());
			}
			catch { /* lint-exempt:sampling failure cannot authorize cleanup */ }
			finally { this.sampling = false; }
		})();
		await this.samplePromise;
	}

	/**
	 * 终态审计与回收：
	 * 1. 抓取终态 ps 快照补录；
	 * 2. 对累计 seenDescendants 过滤出存活者；
	 * 3. 对存活者发送 SIGTERM → 2s 宽限 → SIGKILL；
	 * 4. 返回披露摘要。
	 */
	async auditAndClean(): Promise<ProcessAuditResult> {
		const empty = { cleanedCount: 0, summary: "", pids: [] };
		const platform = this.deps.platform ?? process.platform;
		if ((platform !== "darwin" && platform !== "linux") || !isProcessAuditEnabled(this.deps.env ?? process.env)) return empty;
		await this.samplePromise;
		const alive = this.deps.isAlive ?? defaultIsAlive, kill = this.deps.kill ?? defaultKill;
		if (!this.seenDescendants.size) {
			if (!this.rootIdentity) {
				// 根未绑定身份且已退出：没有合法祖先可授权终态发现，保持零噪音（happy path 不退役）。
				if (!alive(this.rootPid)) return empty;
				// ev-20261008-30e744（R4）：根身份从未绑定但根 pid 仍存活（可见活树，无法排除 PID 复用）。
				// 终态快照不能首次认领根，缺精确 token 也不授权任何信号——安全跳过必须留可观察证据。
				const decisions = [{ pid: this.rootPid, signal: "SIGTERM", decision: "skip: root identity unknown; live tree visible; no signal authorized" }];
				const auditRef = this.deps.auditPath
					? this.persistAudit(decisions, [], [], "pid+kernel birth token+command; root identity never bound (probe unavailable or none captured); no authority to signal")
					: "；归属证据：未配置审计日志路径（本次未落盘）";
				const summary = `[进程清理] 根进程 pid ${this.rootPid} 身份未知（出生身份探针不可用，无法排除 PID 复用），可见活树不获回收授权——安全跳过，未发送任何信号${auditRef}`;
				this.deps.log?.(summary);
				return { cleanedCount: 0, summary, pids: [] };
			}
			// 根已绑定且已退出、无已见后代：零噪音返回。
			if (!alive(this.rootPid)) return empty;
			// 根已绑定且仍活：保留原路径终态发现能力——recordSnapshot(...,false) 不认领根，
			// 但能在已绑定根之下补录晚生后代；逐信号核验照常。
		}
		try { this.recordSnapshot(await (this.deps.runPs ?? defaultRunPs)(), false); } catch { /* lint-exempt:fresh per-signal checks still required below */ }
		const sleep = this.deps.sleep ?? defaultSleep;
		const decisions: Array<{ pid: number; signal: string; decision: string; current?: ProcessInfo }> = [];
		const signalled: number[] = [];
		const sendVerified = async (pid: number, signal: NodeJS.Signals): Promise<boolean> => {
			const old = this.observed.get(pid);
			if (!old || pid <= 1 || pid === this.rootPid || !alive(pid)) return false;
			let current: ProcessInfo | undefined;
			try { current = parsePsOutput(await (this.deps.runPs ?? defaultRunPs)()).find(p => p.pid === pid); }
			catch { /* journal:process-cleanup-ps-unavailable */ decisions.push({ pid, signal, decision: "skip: ps unavailable" }); return false; }
			if (!current || !old.lineage.every(p => !!p.identityToken) || !this.sameIdentity(old.process, current)) {
				decisions.push({ pid, signal, decision: "skip: identity unconfirmed or changed", current }); return false;
			}
			try { kill(pid, signal); decisions.push({ pid, signal, decision: "sent after identity check", current }); return true; }
			catch { /* journal:process-cleanup-signal-failed */ decisions.push({ pid, signal, decision: "signal failed", current }); return false; }
		};
		for (const pid of this.seenDescendants) if (await sendVerified(pid, "SIGTERM")) signalled.push(pid);
		if (signalled.length) {
			await sleep(TERM_GRACE_MS);
			for (const pid of signalled) await sendVerified(pid, "SIGKILL");
			await sleep(50);
		}
		const cleaned = signalled.filter(pid => !alive(pid));
		const skipped = decisions.filter(d => d.decision.startsWith("skip:"));
		const signalFailures = decisions.filter(d => d.decision === "signal failed");
		if (!decisions.length) return empty;
		// ev-20261008-30e744（B7）：每个回收项携带可核对锚点（taskId/rootPid/首次血缘链/
		// 出生标识/终态核对结论）；审计日志给可追溯路径，未配置路径时显式披露（不静默无路径）。
		const reapedAnchors = cleaned.map(pid => this.reapedAnchorOf(pid));
		const auditRef = this.deps.auditPath
			? this.persistAudit(decisions, cleaned, reapedAnchors, "pid+kernel birth token+command; precise lineage tokens required; rechecked before each signal")
			: "；归属证据：未配置审计日志路径（本次回收未落盘）";
		const descriptions = reapedAnchors.map(a => `pid ${a.pid}（首次血缘 ${a.firstLineagePids.join("→")}, 出生 ${a.birth}, 终态核对 ${a.finalIdentityCheck}, 命令 ${a.command}）`);
		const summary = `[进程清理] 回收 ${cleaned.length} 个残留进程（task=${this.deps.taskId ?? "未标记"}, rootPid=${this.rootPid}）: ${descriptions.join("; ")}${signalled.length > cleaned.length ? `；已发信号但退出未确认 ${signalled.length - cleaned.length} 个` : ""}${skipped.length ? `；身份未确认，跳过 ${new Set(skipped.map(s => s.pid)).size} 个` : ""}${signalFailures.length ? `；信号发送失败 ${signalFailures.length} 次` : ""}${auditRef}`;
		this.deps.log?.(summary);
		return { cleanedCount: cleaned.length, summary, pids: cleaned };
	}

	/** 30e744（B7）：单回收项锚点记录。命令串过进程展示脱敏策略（F01：完整遮蔽 KEY/TOKEN/
	 *  SECRET 类赋值——与用户可见摘要、审计落盘投影同面；F02 后审计 JSON 零明文，不保留原样
	 *  命令证据面）。 */
	private reapedAnchorOf(pid: number): ReapedAnchor {
		const o = this.observed.get(pid);
		const lineage = o?.lineage ?? [];
		return {
			pid,
			taskId: this.deps.taskId,
			rootPid: this.rootPid,
			firstLineagePids: lineage.map(p => p.pid),
			firstLineageCommands: lineage.map(p => redactProcessDisplayText(p.command)),
			birth: o?.process.identityToken ?? o?.process.startToken ?? "未知",
			firstObservedAt: o ? new Date(o.observedAt).toISOString() : "",
			// sendVerified 准入 = observed 身份完整且与发信号时快照一致（token+命令逐项相等）。
			finalIdentityCheck: o?.process.identityToken ? "出生token一致" : "未知",
			command: redactProcessDisplayText(o?.process.command ?? ""),
		};
	}

	/** 审计落盘（归属证据）：decisions/确认退出集/回收项锚点/身份方法口径；失败时返回失败注记，信号安全绝不依赖日志成功。 */
	private persistAudit(decisions: Array<{ pid: number; signal: string; decision: string; current?: ProcessInfo }>, confirmedExitedPids: number[], reapedAnchors: ReapedAnchor[], identityMethod: string): string {
		if (!this.deps.auditPath) return "";
		try {
			fs.mkdirSync(path.dirname(this.deps.auditPath), { recursive: true, mode: 0o700 });
			// F02：落盘投影统一脱敏——rootIdentity/observations/decisions.current 的全部命令字符串
			// 过进程展示脱敏策略（审计 JSON 零明文）；身份/token 字段非自由文本，原样保留。
			fs.writeFileSync(this.deps.auditPath, JSON.stringify({ version: 1, taskId: this.deps.taskId, cwd: this.deps.cwd, rootPid: this.rootPid, rootIdentity: this.rootIdentity ? auditSafeInfo(this.rootIdentity) : undefined, recordedAt: Date.now(), identityMethod, reapedAnchors, observations: [...this.observed.values()].map((o) => ({ process: auditSafeInfo(o.process), lineage: o.lineage.map(auditSafeInfo), observedAt: o.observedAt })), decisions: decisions.map((d) => (d.current ? { ...d, current: auditSafeInfo(d.current) } : d)), confirmedExitedPids }, null, 2) + "\n", { mode: 0o600 });
			return `；归属证据：${this.deps.auditPath}`;
		} catch { /* journal:process-cleanup-audit-write-failed */ return "；归属证据写入失败"; }
	}
}
