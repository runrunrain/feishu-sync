/**
 * input-router.ts — P4-2：确定性路由（§8.4）。
 *
 * 用户输入 `#<角色> <任务>` → 直接派发该角色子 Agent（绕过 Leader LLM 路由决策，零延迟零歧义）；
 * `#review [<关注点>]` → 派发 diting 审当前 git diff。
 * 未知 `#xxx` 或无 `#` 前缀 → 放行（continue），绝不吞输入。
 *
 * 机制证据（dist types.d.ts:617-637, 876）：
 *   InputEvent { text, source, ... }；InputEventResult = {action:"continue"} | {action:"transform",text} | {action:"handled"}。
 *   "handled" 取消原 input 进 agent loop → 确定性路由在此返回，派发逻辑异步执行后以 sendUserMessage 回流。
 *
 * 角色白名单 = agents/*.md 文件名（task 查找键，见 agents-loader.ts:123 name=fileBase）。
 * 派发复用 task-tool.ts 的 runTask（经 RouterDeps 注入，避免循环依赖）；回流经 pi.sendUserMessage。
 * K5b（方案 §8.1-K5b）：#agent 硬路由派发同样落必要清单——注入的 runTask 自 K5a 起统一经
 * submitTaskKernel（归一化 → 冻结真实 TaskSpec → 内核 register，saveSpec+current 落盘成功才准入/spawn），
 * 硬路由与 sync/background/resume 共享同一提交面与父链/取消栅栏语义；本模块零独立提交路径。
 * 日志佐证（"不经 LLM"）：派发时 tuiLog 记录路由决策（TUI 下经 notify 呈现——A1b：裸 console 写入
 * 会破坏 pi 1.0.2 fullscreen 差分渲染器；非 TUI 回落 console 语义）。
 */

import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { AgentConfig } from "./agents-loader.ts";
import { AGENT_ALIASES, findAgentByRequest, resolveAgentRequest, withModeHeader } from "./agent-aliases.ts";
import { appendEvidence } from "./evidence.ts";
import { finalizeTerminal } from "./finalizer.ts";
import { tuiLog } from "./tui-console.ts";
import { sendTaskCompletion, sendMachineNotice, MACHINE_NOTICE_TYPE } from "./evidence-context.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 类型
// ─────────────────────────────────────────────────────────────────────────────

/** runTask 返回的最小结构（解耦 RunResult 全字段）。 */
export interface DispatchResult {
	status: string;
	output: string;
	errorMessage?: string;
	blocked?: boolean;
	/** 统一收尾 stale 基线；runTask 在 registry.create 后捕获。 */
	dispatchRevision?: number;
	/** 8月迭代 F3：spawn 前 git 快照（RunResult.gitBaseline 透出，finalizer 归因基线）。 */
	gitBaseline?: string[] | null;
	/** v2 批次B：统一收尾链所需的任务 id（RunResult 携带；旧注入源缺省时降级为 evidence-only）。 */
	taskId?: string;
	/** v1.5.188 P1-3②：E1/E3 完成契约标注后缀（runTask finalize 透出）。 */
	completionAnnotation?: string;
	/** v1.5.188 P1-4⑤：派发前熔断警告（runTask 透出）。 */
	fuseWarning?: string;
}

export interface RouterDeps {
	agents: AgentConfig[];
	/** 注入 task-tool 的 sync runTask（避免循环 import）。 */
	runTask: (agent: AgentConfig, task: string, opts: { cwd: string; signal?: AbortSignal }) => Promise<DispatchResult>;
	/** 派发开始时同步回调（测试观测用）。 */
	onDispatch?: (agentName: string, task: string, kind: RouteKind) => void;
	/** 证据采集注入（默认真实 gatherEvidence；测试注入避免跑真实命令）。 */
	gatherEvidence?: (cwd: string) => Promise<string>;
	/** v1.5.178: #board/#panel 路由——打开看板（可选直达任务会话面板）。 */
	openBoard?: (ctx: unknown, opts?: { taskId?: string }) => Promise<void> | void;
	/** v1.5.178: 在途任务列表（running+queued，startedAt 升序），供 #panel 序号映射。 */
	listRunning?: () => ReadonlyArray<{ taskId: string; agent: string; startedAt: number }>;
}

export type RouteKind = "agent" | "review" | "qreview" | "board" | "panel";

export interface RouteMatch {
	kind: RouteKind;
	/** agent 路由：归一后的 canonical 角色名；review 路由：固定 "diting"。board/panel 路由为空串。 */
	agent: string;
	task: string;
	/** panel 路由：在途任务序号（1 起，startedAt 升序，与常驻面板编号一致）。 */
	index?: number;
	/** v2（§7.1-C/§7.2）：#qreview / #diting-quick 解析出的审核档（diting 专属）。 */
	reviewMode?: "quick" | "full";
	/** v2（§7.2）：#hongjun/#puti 别名解析出的任务态（fuxi 专属）。 */
	fuxiState?: "design" | "attack" | "reflect";
	/** ev-20260920-beeac5：#别名 直派时的原始请求 token（小写化）——归一后与 agent 不同名时回执双名标注用。
	 *  canonical 直请求不设（与 agent 同名，零标注噪声）；大小写变体（#Luban）小写化后同名亦不设。 */
	requested?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// 路由匹配（纯函数）
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 解析输入是否为确定性路由指令。
 * @param text 用户原始输入
 * @param names 角色文件名白名单（小写）
 * @returns 命中返回 RouteMatch；未知 `#xxx` / 无 `#` / 无任务 → null（放行）
 *
 * 规则：
 *   `#review [<关注>]` —— 必命中（裸 `#review` 也确定性派发 diting 审 diff；默认 full 档；关注点可选）
 *   `#qreview [<关注>]` —— 必命中（v2 §7.1-C：派发 diting + reviewMode=quick；不再回落已删除的
 *     diting-quick 角色——quick/full 是同一角色的覆盖档位，不按档位拆角色）
 *   `#<role> <task>` —— role ∈ 白名单 ∪ 别名表（v2 §7.2：wenqu→baize、hongjun→fuxi+attack 等
 *     八旧 stem 归一到 canonical）→ agent 路由（task 必须非空，避免吞普通 hashtag）
 *   role 大小写不敏感（normalize 小写）
 */
export function matchRoute(text: string, names: ReadonlySet<string>): RouteMatch | null {
	const s = text.trim();
	if (!s.startsWith("#")) return null;
	// #<role>[ <task>]：role 字母开头可含 word/hyphen；任务组可选（仅 #review/#qreview 允许无任务）
	const m = /^#([A-Za-z][\w-]*)(?:\s+(\S[\s\S]*))?$/.exec(s);
	if (!m) return null;
	const role = m[1].toLowerCase();
	const task = (m[2] || "").trim();
	// v1.5.178: #board 开看板；#panel <n> 直达第 n 个在途任务会话面板（常驻面板编号对应）
	if (role === "board") return { kind: "board", agent: "", task: "" };
	if (role === "panel") {
		const n = Number(task);
		if (!Number.isInteger(n) || n < 1) return { kind: "panel", agent: "", task, index: -1 }; // 非法序号 → 诚实报错（handled）
		return { kind: "panel", agent: "", task, index: n };
	}
	// M1: #review 必命中（裸 #review → buildReviewTask("")，diting 默认 full）；其他 role 无任务 → 放行
	if (role === "review") return { kind: "review", agent: "diting", task };
	// v1.5.191→v2 §7.1-C: #qreview 必命中——diting + quick（审核档注入任务正文首部，非仅显示标签）
	if (role === "qreview") return { kind: "qreview", agent: "diting", task, reviewMode: "quick" };
	if (!task) return null;
	// v2 §7.2 步骤 4：#<别名> = 用户显式选择对应态（hongjun→fuxi+attack、puti→fuxi+reflect 等）
	const alias = AGENT_ALIASES[role];
	if (alias) {
		return { kind: "agent", agent: alias.agent, task, requested: role, ...(alias.reviewMode !== undefined ? { reviewMode: alias.reviewMode } : {}), ...(alias.fuxiState !== undefined ? { fuxiState: alias.fuxiState } : {}) };
	}
	if (names.has(role)) return { kind: "agent", agent: role, task };
	return null; // 未知 #xxx → 放行不吞
}

/** 构造 #review 的 diting 任务文本。 */
export function buildReviewTask(userNote: string): string {
	const focus = userNote.trim();
	return [
		"审核当前工作区未提交的改动。",
		"执行 `git --no-pager diff HEAD`（必要时 `git status`）查看改动范围，按 agents/diting.md 交付契约分级（Critical / Major / Minor），逐条给出【问题定位】与【修复建议】，末行给 VERDICT（PASS | PASS_WITH_MINOR | FIX）。",
		"若无改动则明确说明。",
		focus ? `用户特别关注：${focus}` : "",
	]
		.filter(Boolean)
		.join("\n");
}

/** 构造 #qreview 的 diting 快审任务文本（v2 §7.1-C：同一 diting 角色 + quick 档；输出契约与
 *  agents/diting.md 一致——severity 词汇 Critical/Major/Minor 与 VERDICT 三档不因 quick 降档；
 *  quick 与 full 是覆盖范围之别，不是证据标准或严重度之别）。首部固定注入「审核档: quick」。 */
export function buildQuickReviewTask(userNote: string): string {
	const focus = userNote.trim();
	return [
		"审核档: quick",
		"快速审核当前工作区未提交的改动（quick 档：聚焦指定 diff 的高危路径与验证有效性，不扩大成全仓审计）。",
		"执行 `git --no-pager diff HEAD`（必要时 `git status`）查看改动范围。",
		"输出契约（严格遵守，与 diting 角色契约一致）：",
		"FINDINGS:",
		"1. [Critical|Major|Minor] 文件:行号 — 触发条件与可失败行为（一句话证据） → 最小修复方向",
		"（无发现写：FINDINGS: none）",
		"VERDICT: PASS（无问题）| PASS_WITH_MINOR（仅 Minor）| FIX（有 Critical/Major）—— 一行理由",
		"若改动涉凭证/密钥/auth/token/权限，必查：明文泄露、落盘权限位、合并方向（新值被旧值回滚）、日志/输出泄露。",
		"若无改动则明确说明。",
		focus ? `用户特别关注：${focus}` : "",
	]
		.filter(Boolean)
		.join("\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// 派发 + 回流
// ─────────────────────────────────────────────────────────────────────────────

async function dispatchAndReport(
	pi: ExtensionAPI,
	agent: AgentConfig,
	requested: string,
	task: string,
	cwd: string,
	kind: RouteKind,
	deps: RouterDeps,
	trusted: boolean,
): Promise<void> {
	deps.onDispatch?.(agent.name, task, kind);
	// ev-20260920-beeac5：硬路由同样做双名标注——#别名 直派时 UI 回流不再只显 canonical 名（归因失真）。
	const agentLabel = requested === agent.name ? agent.name : `${requested}→${agent.name}（别名归一）`;
	// 日志佐证：确定性派发，不经 Leader LLM 路由（K5b：清单落盘由注入的 runTask → submitTaskKernel 统一承担）
	const routeLabel = kind === "review" ? "review" : kind === "qreview" ? "qreview" : requested;
	tuiLog(`[amagi-router] #${routeLabel} → 直接派发 ${agentLabel}（不经 LLM 路由）`);
	let res: DispatchResult;
	try {
		res = await deps.runTask(agent, task, { cwd });
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		// ev-20261101-7fffc6：派发异常通知也走机器通道（无 taskId 可回源时不伪造）。
		try { sendMachineNotice(pi, MACHINE_NOTICE_TYPE, `[路由派发 ${agentLabel}] 异常：${msg}`); } catch {}
		return;
	}
	const status = res.blocked ? "blocked" : res.status;
	let body = res.output || res.errorMessage || "(无输出)";
	// v2 批次B：硬路由同样走统一收尾链（幂等 + stale 防护 + artifact 落盘——硬路由旁路此前不落 artifact，观测对等补齐）；
	// 旧注入源不带 taskId 时降级为 evidence-only（兼容）。
	if (res.taskId) {
		const fin = await finalizeTerminal({ taskId: res.taskId, agent: agent.name, result: { ...res, output: res.output, errorMessage: res.errorMessage, status, blocked: !!res.blocked }, cwd, evidence: { gatherEv: deps.gatherEvidence, trusted, baselinePorcelain: res.gitBaseline }, expectedRevision: res.dispatchRevision });
		body = fin.body || body;
	} else {
		// M2: 硬路由完成路径也附证据（与 task sync/resume 共享 appendEvidence；代码产物候选 + 完成态
		// + trust gate；v2 §7.1-B：基线判定走 producesProjectCode + fresh 路径分类，baselinePorcelain 透传派发前快照）
		body = await appendEvidence(body, agent.name, status, cwd, { gatherEv: deps.gatherEvidence, trusted, ...(res.gitBaseline ? { baselinePorcelain: res.gitBaseline } : {}) });
	}
	// v1.5.188 P1-3②/P1-4⑤：硬路由旁路天然覆盖——标注/熔断已由 runTask finalize 计算，此处仅拼接
	body += res.completionAnnotation || "";
	try {
		// ev-20261101-7fffc6：硬路由回流通 custom 机器通道（amagi:task-completion + details.taskId 回源）；
		// 旧注入源无 taskId 时退通用机器通知，仍不落无标记 role=user。
		const notice = `${res.fuseWarning || ""}[路由派发 ${agentLabel} · ${status}]\n\n${body}`;
		if (res.taskId) sendTaskCompletion(pi, notice, res.taskId);
		else sendMachineNotice(pi, MACHINE_NOTICE_TYPE, notice);
	} catch {}
}

// ─────────────────────────────────────────────────────────────────────────────
// 注册
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 注册确定性路由 input handler。
 * 仅 interactive/rpc/extension 三类 source 均生效（input 事件不区分 source 即拦截）。
 */
export function registerInputRouter(pi: ExtensionAPI, deps: RouterDeps): void {
	const nameSet = new Set(deps.agents.map((a) => a.name));

	pi.on("input", async (event: { text: string }, ctx: { cwd: string; isProjectTrusted?: () => boolean }) => {
		const m = matchRoute(event.text, nameSet);
		if (!m) return { action: "continue" as const };

		// v1.5.178: #board/#panel 看板路由（TUI 交互入口；不涉派发）
		if (m.kind === "board" || m.kind === "panel") {
			if (!deps.openBoard) { try { pi.sendUserMessage("[路由] 看板不可用（非 TUI 或未注册）"); } catch {} return { action: "handled" as const }; }
			if (m.kind === "board") {
				tuiLog("[amagi-router] #board → 打开看板（不经 LLM 路由）");
				void deps.openBoard(ctx);
				return { action: "handled" as const };
			}
			// panel：序号 → 在途任务（running+queued，startedAt 升序，与常驻面板编号一致）
			const running = (deps.listRunning?.() ?? []);
			const n = m.index ?? -1;
			if (n < 1 || n > running.length) {
				try { pi.sendUserMessage(`[路由] #panel ${m.task} 无效：当前在途任务 ${running.length} 个（有效序号 1-${running.length || 0}；见常驻面板编号）`); } catch {}
				return { action: "handled" as const };
			}
			const target = running[n - 1];
			tuiLog(`[amagi-router] #panel ${n} → 直达 ${target.agent}#${target.taskId.slice(0, 8)} 会话面板（不经 LLM 路由）`);
			void deps.openBoard(ctx, { taskId: target.taskId });
			return { action: "handled" as const };
		}

		const agent = findAgentByRequest(deps.agents, m.agent);
		// 防御：review/qreview 路由但 agents 未含 diting（配置裁剪）→ 放行交 Leader 处理
		if (!agent) {
			tuiLog(`[amagi-router] #${m.agent} 命中但角色未注册，放行`);
			return { action: "continue" as const };
		}

		// v2 §7.2 步骤 6：解析模式 ≠ 角色默认时任务正文首部注入固定首部（幂等；#qreview 首部由
		// buildQuickReviewTask 携带，此处覆盖 #hongjun/#puti/#diting-quick 等别名默认模式）
		const _resolved = resolveAgentRequest(m.agent, { ...(m.reviewMode !== undefined ? { reviewMode: m.reviewMode } : {}), ...(m.fuxiState !== undefined ? { fuxiState: m.fuxiState } : {}) });
		const modeHeader = "modeHeader" in _resolved ? _resolved.modeHeader : undefined;
		const task = m.kind === "review" ? buildReviewTask(m.task) : m.kind === "qreview" ? buildQuickReviewTask(m.task) : withModeHeader(modeHeader, m.task);
		// 异步派发（不阻塞 input 处理）；不传 signal（派发独立于当前 turn，避免 turn 结束 abort 子任务）
		// trust 从 ctx.isProjectTrusted() 贯穿至 evidence（dist types.d.ts:225-226）
		void dispatchAndReport(pi, agent, m.requested ?? m.agent, task, ctx.cwd, m.kind, deps, ctx.isProjectTrusted?.() ?? false);
		return { action: "handled" as const };
	});
}
