/**
 * win-exec-encoding.ts — Windows 程序输出解码纯函数（统一为 UTF-8 文本）。
 *
 * 痛点：Windows 原生程序输出编码混乱——cmd.exe/UBT 常按控制台代码页（简中环境 cp936/GBK）
 * 输出，PowerShell 部分场景吐 UTF-16，git/rg 多为 UTF-8；直接按 UTF-8 解码 GBK 字节会出现
 * 乱码或 U+FFFD。本模块按确定性探测链解码：
 *
 *   ① BOM：FF FE → UTF-16LE；FE FF → UTF-16BE；EF BB BF → UTF-8（剥 BOM）
 *   ② 高零字节比例（无 BOM）：样本 ≥4 字节且某一奇偶步长的零字节占比 > 60% → UTF-16（按零字节
 *      所在步长定端序；ASCII 文本在另一侧全零是 UTF-16 的天然指纹）
 *   ③ 严格 UTF-8（fatal 解码成功即收）
 *   ④ 回退控制台代码页（默认 gbk/cp936，可经 windows.exec.fallbackEncoding 配置；
 *      TextDecoder 不支持该标签时退 latin1 并在 note 标注——保字节不丢、如实降级）
 *
 * 后处理：\r\n → \n（Windows 程序普遍带 \r）；ANSI 转义序列保留不动（进度条/彩色输出）。
 * 纯函数、零 I/O，注入 fallback 标签即可单测（GBK 字节样本、UTF-16 样本、混合形态）。
 */

export type WinExecEncodingKind = "utf16le" | "utf16be" | "utf8" | "fallback" | "latin1";

export interface DecodedWindowsOutput {
	text: string;
	encoding: WinExecEncodingKind;
	/** 探测到的实际标签（fallback 时为生效的回退标签，latin1 时为 "latin1"）。 */
	label: string;
	/** 降级/异常说明（latin1 回退、非法序列替换等；无则省略）。 */
	note?: string;
}

/** 无 BOM UTF-16 判定的最小样本量（字节）。 */
const UTF16_MIN_BYTES = 4;
/** 某一奇偶步长的零字节占比阈值（ASCII-heavy 文本的另一侧近乎全零）。 */
const UTF16_ZERO_RATIO = 0.6;

function zeroRatioAtStride(buf: Uint8Array, stride: 0 | 1): number {
	if (buf.length < UTF16_MIN_BYTES) return 0;
	let zeros = 0;
	let total = 0;
	for (let i = stride; i < buf.length; i += 2) {
		total++;
		if (buf[i] === 0) zeros++;
	}
	return total === 0 ? 0 : zeros / total;
}

/** TextDecoder 构造（标签不支持时抛——调用方归因 latin1 降级）；缺省缓存常用解码器。 */
function decoderOf(label: string, fatal: boolean): TextDecoder {
	return new TextDecoder(label, { fatal, ignoreBOM: false });
}

/**
 * 解码 Windows 程序输出字节。fallbackEncoding 缺省 "gbk"（cp936；简中控制台代码页）。
 * 空输入 → 空文本（encoding "utf8"——无样本无从探测，按最常见形态记）。
 */
export function decodeWindowsOutput(input: Uint8Array, opts: { fallbackEncoding?: string } = {}): DecodedWindowsOutput {
	const buf = input instanceof Uint8Array ? input : Uint8Array.from(input ?? []);
	if (buf.length === 0) return { text: "", encoding: "utf8", label: "utf-8" };

	// ① BOM
	if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
		return finish("utf16le", "utf-16le", new TextDecoder("utf-16le").decode(buf.subarray(2)));
	}
	if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) {
		return finish("utf16be", "utf-16be", new TextDecoder("utf-16be").decode(buf.subarray(2)));
	}
	if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
		return finish("utf8", "utf-8", new TextDecoder("utf-8").decode(buf.subarray(3)));
	}

	// ② 高零字节比例（UTF-16 指纹）
	const evenZeros = zeroRatioAtStride(buf, 0);
	const oddZeros = zeroRatioAtStride(buf, 1);
	if (evenZeros > UTF16_ZERO_RATIO && oddZeros < 0.1) {
		return finish("utf16be", "utf-16be(零字节探测)", new TextDecoder("utf-16be").decode(buf));
	}
	if (oddZeros > UTF16_ZERO_RATIO && evenZeros < 0.1) {
		return finish("utf16le", "utf-16le(零字节探测)", new TextDecoder("utf-16le").decode(buf));
	}

	// ③ 严格 UTF-8
	try {
		return finish("utf8", "utf-8", decoderOf("utf-8", true).decode(buf));
	} catch { /* lint-exempt:严格 UTF-8 失败 → 进入代码页回退链 */ /* 非 UTF-8 → 进入回退链 */ }

	// ④ 控制台代码页回退（默认 gbk；标签不支持 → latin1 保字节）
	const fallbackLabel = (opts.fallbackEncoding || "gbk").trim() || "gbk";
	try {
		return finish("fallback", fallbackLabel, decoderOf(fallbackLabel, false).decode(buf));
	} catch { /* lint-exempt:回退标签不支持 → latin1 降级 */
		const text = new TextDecoder("latin1").decode(buf);
		return {
			...finish("latin1", "latin1", text),
			note: `回退编码 ${JSON.stringify(fallbackLabel)} 本环境 TextDecoder 不支持，已按 latin1 保字节解码（中文将显示为乱码；可在 amagi.json windows.exec.fallbackEncoding 配置环境支持的标签，如 gbk/big5/shift_jis）`,
		};
	}
}

function finish(encoding: WinExecEncodingKind, label: string, raw: string): DecodedWindowsOutput {
	// \r\n → \n；ANSI 转义序列（ESC[…）保留不动
	return { text: raw.replace(/\r\n/g, "\n"), encoding, label };
}

/** 探测结果的人读短名（结果文本里标注编码口径用）。 */
export function describeEncoding(d: DecodedWindowsOutput): string {
	const zh: Record<WinExecEncodingKind, string> = {
		utf16le: "UTF-16LE",
		utf16be: "UTF-16BE",
		utf8: "UTF-8",
		fallback: `回退(${d.label})`,
		latin1: "latin1",
	};
	return zh[d.encoding];
}
