/**
 * fs-mutation-tracker.ts — ev-20260901-91d4ae（battle-sim 复盘 §2.3）：同轮 bash(mv/rm)×edit 竞态的事后型提示缓冲。
 *
 * 实战事故：同一消息块并行 `mv … workflow.md`（bash）与 edit 同一路径——edit 先执行时目标尚不存在，
 * ENOENT 失败，下轮重试才成功。edit-override 的执行 ctx 为 unknown，拿不到同块工具调用清单，无法做
 * 真正的事前预检；改走事后型两段机制：bash-override 在 mv/rm 命令**成功执行后**把受影响路径记入本
 * 模块级 TTL 环形缓冲，edit-override 在目标 ENOENT 失败时查询缓冲，命中则错误尾部追加
 * 「可能同轮并行竞态」软提示（提示不阻断、不改写，交由使用者 read/ls 自证后重试）。
 *
 * 放独立共享模块的原因：bash-override（记录方）与 edit-override（消费方）互不 import——两个同名
 * 覆盖层互相耦合会把两套覆盖语义焊死；本模块只依赖 shell-lexer 纯函数，零 pi 依赖、无循环边。
 *
 * 解析口径（尽力而为，不追求完备）：shellSegments+executableWords 剥 env/sudo/timeout 等包裹后，
 * 段首可执行名为 mv/rm 时取全部非选项操作数（mv 的源与目的、rm 的参数；`--` 之后全取）；
 * 相对路径按该次 bash 的执行 cwd 解析、绝对路径原样归一、`~` 展开为 homedir；含通配符/命令替换的
 * 操作数跳过（未展开的字面量不可能命中真实路径）。任何解析异常静默返回——提示性数据绝不影响执行路径。
 */

import * as os from "node:os";
import * as path from "node:path";
import { shellSegments, executableWords } from "./shell-lexer.ts";

/** 缓冲 TTL（ms）：mv/rm 影响窗口，默认 60s（ev-20260901-91d4ae 约定口径）。 */
export const FS_MUTATION_TTL_MS = 60_000;
/** 环形缓冲容量上限（长会话 mv/rm 洪水时按最旧淘汰，防无界增长）。 */
const FS_MUTATION_MAX = 128;

/** 快速预筛：命令文本不含 mv/rm 词时跳过词法解析（精确词边界；mvx/rmdir 不命中）。 */
const MUTATION_PRE_FILTER = /\b(?:mv|rm)\b/;

export interface FsMutationRecord {
	/** 尽力解析的绝对路径（按记录时该次 bash 的 cwd 解析；未 stat、未展开通配）。 */
	file: string;
	/** 触发命令的可执行名（mv | rm）。 */
	kind: "mv" | "rm";
	/** 记录时刻 epoch ms。 */
	at: number;
}

const records: FsMutationRecord[] = [];

/** 惰性清理：淘汰队首已过期记录（records 按插入时间有序；elapsed ≥ ttl 即过期，与长耗时阈值「超过才提示」同向）。 */
function prune(now: number, ttlMs: number): void {
	while (records.length > 0 && now - records[0].at >= ttlMs) records.shift();
}

/** 追加一条并按容量淘汰最旧。 */
function push(file: string, kind: "mv" | "rm", at: number): void {
	records.push({ file, kind, at });
	if (records.length > FS_MUTATION_MAX) records.splice(0, records.length - FS_MUTATION_MAX);
}

/** `~` / `~/x` 展开为 homedir（其余原样；尽力口径）。 */
function expandTilde(op: string): string {
	if (op === "~") return os.homedir();
	if (op.startsWith("~/")) return path.join(os.homedir(), op.slice(2));
	return op;
}

/**
 * 解析命令文本中的 mv/rm 受影响路径并记入 TTL 缓冲（只记录，不执行、不 stat）。
 * 供 bash-override 在命令**成功执行后**调用（失败命令的 mv/rm 未必生效，不记录）。
 * now 可注入供测试。任何异常静默返回。
 */
export function recordFsMutations(command: string, baseCwd: string, now: number = Date.now()): void {
	try {
		if (typeof command !== "string" || !MUTATION_PRE_FILTER.test(command)) return;
		for (const segment of shellSegments(command)) {
			const words = executableWords(segment, true);
			const exe = path.basename(words[0] ?? "").toLowerCase();
			if (exe !== "mv" && exe !== "rm") continue;
			const operands: string[] = [];
			for (let i = 1; i < words.length; i++) {
				const w = words[i];
				if (w === "--") { operands.push(...words.slice(i + 1)); break; }
				if (w.startsWith("-")) continue; // 选项跳过（含 -f/-r/-t DIR 的值——尽力口径不逐一区分取值）
				operands.push(w);
			}
			for (const op of operands) {
				if (!op || op.startsWith("$") || op.includes("*") || op.includes("?") || op.includes("$(")) continue;
				const expanded = expandTilde(op);
				push(path.isAbsolute(expanded) ? path.normalize(expanded) : path.resolve(baseCwd, expanded), exe, now);
			}
		}
		prune(now, FS_MUTATION_TTL_MS);
	} catch { /* 提示性数据，解析失败静默 */ }
}

/**
 * 查询目标路径近 TTL 内是否被 mv/rm 影响（命中返回记录，否则 null）。
 * 精确匹配记录时解析的绝对路径；now/ttlMs 可注入供测试。
 */
export function findRecentFsMutation(file: string, now: number = Date.now(), ttlMs: number = FS_MUTATION_TTL_MS): FsMutationRecord | null {
	try {
		prune(now, ttlMs);
		const target = path.isAbsolute(file) ? path.normalize(file) : path.resolve(file);
		for (let i = records.length - 1; i >= 0; i--) if (records[i].file === target) return records[i];
		return null;
	} catch { return null; }
}

/**
 * 生成同轮竞态软提示行（未命中或已过期返回 null），供 edit-override 的 ENOENT 失败路径追加。
 * 文案为 ev-20260901-91d4ae 约定口径；now 可注入供测试。
 */
export function fsMutationRaceHint(targetAbs: string, now: number = Date.now()): string | null {
	const hit = findRecentFsMutation(targetAbs, now);
	if (!hit) return null;
	const sec = Math.max(1, Math.round((now - hit.at) / 1000));
	return `[amagi] 目标文件近 ${sec}s 内被 bash mv/rm 影响，可能同轮并行竞态；用 read/ls 确认实际路径后重试`;
}

/** 清空缓冲（测试隔离用）。 */
export function clearFsMutations(): void {
	records.length = 0;
}
