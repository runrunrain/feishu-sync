/**
 * codemode-ledger.ts — B5B（ev-20261012-7517d8 设计 §5.3/§9 批B）：codemode 受控预算持久账本。
 *
 * 受控存储（设计 §5.3 推荐口径）：<amagiDataDir>/codemode-ledger/<accountId>.jsonl 记录
 * append-only 预留/完成事件；账户 ID 经受控编码生成（sha256 派生 24-hex，格式校验后才可入路径
 * ——不接受任意路径输入）；目录 0700、文件 0600，与项目 workspace、v2-store 任务权威记录分离。
 *
 * 单写者租约（§5.3「单账户单写者，预留落盘成功才执行」）：
 *  - <accountId>.lease 持 {writerId, pid, expiresAt}；O_EXCL 首取，持有者 pid 已死（ESRCH）
 *    才可接管（过期只作诊断——活持有者即使过期也不被抢，防两活写者交替写坏账本）；
 *  - 第二写者争用 → conflict（可重试拒绝：本轮 deny，后续调用再试——老进程死亡后自动接管）；
 *  - 每次 append 前复核租约仍是本写者，append 后原子刷新 expiresAt（tmp+rename）。
 *
 * 崩溃一致性（保守重建：宁可多扣不少扣——§5.3「未完成预留一律按已消费重建」）：
 *  - reserve 落盘成功才执行（调用方语义）；end 不返还额度（reserve 恒计入，取消/失败/迟到结果同）；
 *  - 重放：Σ reserve = 已用（不返还）；Σ end.nestedCalls + 128×未完结 reserve = 会话 nested 保守值；
 *    执行资格消费集 = 全部 reserve 的 toolCallId（与批A 进程内 consumedExecutes 同强度——曾进入
 *    预留的 ID 永久消费，重试须新 ID 重新计费）；
 *  - 尾行撕裂（append 中途崩溃）：丢弃末尾不完整行——reserve 撕裂=append 未返回、脚本未执行
 *    （丢弃准确）；end 撕裂=按未完结保守重建（nested 高估，额度口径不变）。非末行损坏/未知事件
 *    形状 = 损坏 → STATE_UNAVAILABLE 关闭（不猜、不跳行继续）。
 *
 * 账户锚点（§5.3 恢复语义；跨进程稳定）：
 *  - accountId = sha256("amagi-codemode-account/v1|" + sha256(grantJson) + "|" + anchor)[0..24）；
 *  - anchor 解析序（子端）：env AMAGI_CODEMODE_ACCOUNT（RPC/父端显式交付）→ argv
 *    --session/--session-id/--fork 值（reload/resume/fork 续接同锚）→ 本会话自身 sessionId
 *    （全新会话）→ 均无 → 拒绝；
 *  - fork 续系逃逸收口：fork 子会话（新 sessionId）经 argv 锚沿用原账户，同时在新会话账户文件
 *    写 alias 事件（from=本会话账户 → to=原账户）；后续 resume 该 fork 会话时按自身锚打开即
 *    命中 alias 并跟随到原账户（≤8 跳，成环拒绝）。alias 只能把新账户并入已消费更深的旧账户
 *    （方向恒保守，不可能扩额度）。
 *
 * 回滚纪律（批B §9）：账本文件与事件只增不删不归零；clean 退出仅释放租约文件（非账本本体）。
 */
import { createHash, randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { Worker } from "node:worker_threads";
import { amagiDataDir } from "./data-dir.ts";
import { CODEMODE_MAX_NESTED_CALLS_PER_SCRIPT } from "./codemode-policy.ts";

/** 账户 ID 受控格式（24 位小写 hex——格式校验是入路径前的唯一门槛，防路径注入）。 */
export const CODEMODE_ACCOUNT_ID_PATTERN = /^[0-9a-f]{24}$/;

/** 账户锚点命名空间前缀（会话锚；与未来其它锚种类隔离，防同值异义碰撞）。 */
export const CODEMODE_ANCHOR_SESSION_PREFIX = "session|";

/** 装配版本（进入 RPC 指纹：装配语义变更时递增，跨版本 worker 不复用——设计 §5.3「池指纹含…装配版本」）。 */
export const CODEMODE_LEDGER_ASSEMBLY_VERSION = "b5b-1";

/** 租约 TTL（> 单脚本硬顶 600s + 余量；活 pid 永不被抢，过期仅诊断）。 */
const LEASE_TTL_MS = 660_000;
/** alias 跟随上限（成环/超深链拒绝——保守关闭）。 */
const ALIAS_MAX_HOPS = 8;

// ── 账户派生与锚点扫描（父端 rpc-pool 指纹 / 子端 adapter / 测试共用同一纯函数） ──

/** 账户 ID 派生（grant 原文 JSON + 锚点；父端用注入原文、子端用 env 原文——同串同 ID，无序列化歧义）。 */
export function codemodeAccountIdOfRawGrant(rawGrantJson: string, anchor: string): string {
	return createHash("sha256").update(`amagi-codemode-account/v1|${createHash("sha256").update(rawGrantJson, "utf16le").digest("hex")}|${anchor}`).digest("hex").slice(0, 24);
}

/** argv 会话续接扫描（--session/--session-id/--fork 值选项；`--` 后正文不扫；支持 = 拼写）。
 *  返回锚点（含 session| 前缀）或 null（全新会话——由调用方回退本会话自身锚）。 */
export function scanCodemodeSessionAnchorArgv(argv: readonly string[]): string | null {
	for (let i = 0; i < argv.length; i++) {
		const arg = argv[i];
		if (arg === "--") return null;
		if (arg === "--session" || arg === "--session-id" || arg === "--fork") {
			const v = argv[i + 1];
			if (typeof v === "string" && v !== "" && !v.startsWith("-")) return CODEMODE_ANCHOR_SESSION_PREFIX + v;
			return null;
		}
		if (arg.startsWith("--session=") || arg.startsWith("--session-id=") || arg.startsWith("--fork=")) {
			const v = arg.slice(arg.indexOf("=") + 1);
			if (v !== "") return CODEMODE_ANCHOR_SESSION_PREFIX + v;
			return null;
		}
	}
	return null;
}

// ── 事件与快照 ────────────────────────────────────────────────────────────────

export interface CodemodeLedgerReserveEvent { v: 1; t: "reserve"; at: number; toolCallId: string; scriptHash: string; tokens: number; ms: number }
export interface CodemodeLedgerStartEvent { v: 1; t: "start"; at: number; toolCallId: string }
export interface CodemodeLedgerEndEvent { v: 1; t: "end"; at: number; toolCallId: string; ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean }
export interface CodemodeLedgerAliasEvent { v: 1; t: "alias"; at: number; from: string; to: string }
export interface CodemodeLedgerCloseEvent { v: 1; t: "close"; at: number; reason: string }
export type CodemodeLedgerEvent = CodemodeLedgerReserveEvent | CodemodeLedgerStartEvent | CodemodeLedgerEndEvent | CodemodeLedgerAliasEvent | CodemodeLedgerCloseEvent;

/** 重放快照（父端诊断/子端播种共用；全部为保守口径——宁可多扣不少扣）。 */
export interface CodemodeLedgerSnapshot {
	readonly accountId: string;
	readonly reservedScripts: number;
	readonly reservedTokens: number;
	readonly reservedMs: number;
	/** Σ end.nestedCalls + 128×未完结（保守高估）。 */
	readonly sessionNestedCalls: number;
	/** 执行资格消费集（全部 reserve 的 toolCallId——与批A consumedExecutes 同强度持久化）。 */
	readonly consumedToolCallIds: readonly string[];
	/** reserve 后无 end 的数量（崩溃/中断保守计满 nested）。 */
	readonly incompleteReservations: number;
	/** 末条 alias 指向（无 alias 缺省）。 */
	readonly aliasedTo?: string;
	/** 账本事件行数（诊断）。 */
	readonly events: number;
}

export interface CodemodeLedgerHandle {
	readonly accountId: string;
	/** reserve 追加（含租约复核 + fsync；false=写失败，调用方须拒绝执行并关闭）。 */
	appendReserve(input: { toolCallId: string; scriptHash: string; tokens: number; ms: number }): boolean;
	appendStart(toolCallId: string): boolean;
	appendEnd(toolCallId: string, outcome: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean }): boolean;
	/** fork 系别名（from=本账户 → to=原账户；只并入更深消费，方向恒保守）。 */
	appendAlias(to: string): boolean;
	appendClose(reason: string): boolean;
	/** clean 退出释放租约（仅删本写者租约文件；账本本体不删）。 */
	release(): void;
}

export type CodemodeLedgerOpen =
	| { ok: true; ledger: CodemodeLedgerHandle; snapshot: CodemodeLedgerSnapshot; /** alias 跟随后最终账户的快照链（起点为请求账户）。 */ chain: readonly string[] }
	| { ok: false; kind: "conflict" | "corrupt" | "io" | "invalid-account"; reason: string };

// ── 目录与文件布局 ─────────────────────────────────────────────────────────────

/** 测试注入根目录覆盖（生产恒 amagiDataDir()/codemode-ledger）。 */
let ledgerRootOverride: string | undefined;
export function _setCodemodeLedgerRootForTest(p: string | null): void { ledgerRootOverride = p === null ? undefined : p; }

/** 测试 seam（与 _setCodemodeLedgerRootForTest 同风格）：暴露真实互斥锁供单测在真实持有态下
 *  验证写点 fence 原语（lockOwnershipIntact）——不改变锁算法本身。 */
export function _withLedgerMutationLockForTest(accountId: string, fn: (token: { sockPath: string; bindIno: number }) => void): boolean {
	return withLedgerMutationLock(accountId, fn);
}

export function codemodeLedgerRoot(): string {
	const root = ledgerRootOverride ?? path.join(amagiDataDir(), "codemode-ledger");
	try {
		fs.mkdirSync(root, { recursive: true, mode: 0o700 });
		try { fs.chmodSync(root, 0o700); } catch { /* lint-exempt:umask 已限或平台不支持——尽力而为 */ }
	} catch { /* lint-exempt:目录不可建在 open 时按 io 失败上报，不在此抛 */ }
	return root;
}

function accountFilePath(accountId: string): string {
	if (!CODEMODE_ACCOUNT_ID_PATTERN.test(accountId)) throw new Error(`[codemode-ledger] 非法账户 ID（受控格式 24-hex）：${JSON.stringify(accountId.slice(0, 40))}`);
	return path.join(codemodeLedgerRoot(), `${accountId}.jsonl`);
}

function leaseFilePath(accountId: string): string {
	if (!CODEMODE_ACCOUNT_ID_PATTERN.test(accountId)) throw new Error(`[codemode-ledger] 非法账户 ID（受控格式 24-hex）：${JSON.stringify(accountId.slice(0, 40))}`);
	return path.join(codemodeLedgerRoot(), `${accountId}.lease`);
}

function isPidAlive(pid: number): boolean {
	try { process.kill(pid, 0); return true; } catch (e) { return (e as NodeJS.ErrnoException)?.code === "EPERM"; }
}

// ── F02（审核终裁）：封闭事件 schema ──────────────────────────────────────────

/** 字段全集封闭 + 有限 safe integer/范围 + 工具/哈希/账户目标形状校验。任何非法字段（负数/
 *  缺字段/NaN/越界/多余键/alias 指向不自洽）= 损坏账目，corrupt 拒绝而非播种——损坏恢复必须
 *  保守（负数入账反向扩额度；NaN 比较不能拒绝超额）。返回 null=合法。 */
const LEDGER_HASH64 = /^[0-9a-f]{64}$/;
const LEDGER_ID_MAX = 256;
const RESERVE_TOKENS_MAX = 10_000;   // = 契约 maxOutputTokensPerScript 硬顶（admission 已拒更大值）
const RESERVE_MS_MAX = 600_000;      // = 契约 maxTimeoutMsPerScript 硬顶
const END_DURATION_MAX = 2_147_483_647;
const END_NESTED_MAX = 131_072;

function isLedgerInt(v: unknown, min: number, max: number): boolean {
	return typeof v === "number" && Number.isSafeInteger(v) && v >= min && v <= max;
}

export function validateLedgerEventShape(ev: unknown, accountId: string): string | null {
	if (ev === null || typeof ev !== "object") return "事件非对象";
	const e = ev as Record<string, unknown>;
	if (e.v !== 1) return "v 必须为 1";
	if (!isLedgerInt(e.at, 0, Number.MAX_SAFE_INTEGER)) return "at 须为非负 safe integer";
	const idOk = (v: unknown): boolean => typeof v === "string" && v.length > 0 && v.length <= LEDGER_ID_MAX;
	switch (e.t) {
		case "reserve": {
			if (Object.keys(e).length !== 7) return "reserve 字段集封闭（v/t/at/toolCallId/scriptHash/tokens/ms）";
			if (!idOk(e.toolCallId)) return "reserve.toolCallId 须为非空有界字符串";
			if (typeof e.scriptHash !== "string" || !LEDGER_HASH64.test(e.scriptHash)) return "reserve.scriptHash 须为 64-hex";
			if (!isLedgerInt(e.tokens, 0, RESERVE_TOKENS_MAX)) return `reserve.tokens 须为 ≥0 且 ≤${RESERVE_TOKENS_MAX} 的整数（负数/NaN/越界=损坏；0=合法零输出预算，与 policy maxOutputTokensPerScript≥0 同口径）`;
			if (!isLedgerInt(e.ms, 1, RESERVE_MS_MAX)) return `reserve.ms 须为 ≥1 且 ≤${RESERVE_MS_MAX} 的整数`;
			return null;
		}
		case "start": {
			if (Object.keys(e).length !== 4) return "start 字段集封闭（v/t/at/toolCallId）";
			if (!idOk(e.toolCallId)) return "start.toolCallId 须为非空有界字符串";
			return null;
		}
		case "end": {
			if (Object.keys(e).length !== 8) return "end 字段集封闭（v/t/at/toolCallId/ok/durationMs/nestedCalls/callsComplete）";
			if (!idOk(e.toolCallId)) return "end.toolCallId 须为非空有界字符串";
			if (typeof e.ok !== "boolean") return "end.ok 须为 boolean";
			if (!isLedgerInt(e.durationMs, 0, END_DURATION_MAX)) return "end.durationMs 须为有界非负整数";
			if (!isLedgerInt(e.nestedCalls, 0, END_NESTED_MAX)) return "end.nestedCalls 须为有界非负整数";
			if (typeof e.callsComplete !== "boolean") return "end.callsComplete 须为 boolean";
			return null;
		}
		case "alias": {
			if (Object.keys(e).length !== 5) return "alias 字段集封闭（v/t/at/from/to）";
			if (e.from !== accountId) return "alias.from 须等于本账户文件账户（不自洽=损坏）";
			if (typeof e.to !== "string" || !CODEMODE_ACCOUNT_ID_PATTERN.test(e.to)) return "alias.to 须为受控 24-hex 账户";
			if (e.to === accountId) return "alias.to 不得自指（成环）";
			return null;
		}
		case "close": {
			if (Object.keys(e).length !== 4) return "close 字段集封闭（v/t/at/reason）";
			if (typeof e.reason !== "string" || e.reason.length > 200) return "close.reason 须为 ≤200 字符字符串";
			return null;
		}
		default:
			return `未知事件类型 ${JSON.stringify(String(e.t))}`;
	}
}

// ── 重放 ──────────────────────────────────────────────────────────────────────

interface ReplayOutcome { events: CodemodeLedgerEvent[]; snapshot: CodemodeLedgerSnapshot }
type ReplayResult = { ok: true; out: ReplayOutcome } | { ok: false; kind: "corrupt" | "io"; reason: string };

/** 账本重放（读侧共用：open/readCodemodeLedgerSnapshot）。末行撕裂丢弃（见模块头崩溃一致性）；
 *  非末行解析失败/未知形状 = 损坏。 */
function replayLedgerFile(accountId: string): ReplayResult {
	const file = accountFilePath(accountId);
	let raw: string;
	try {
		raw = fs.readFileSync(file, "utf8");
	} catch (e) {
		const code = (e as NodeJS.ErrnoException).code;
		if (code === "ENOENT") return { ok: true, out: { events: [], snapshot: emptySnapshot(accountId) } };
		return { ok: false, kind: "io", reason: `账本读取失败（${code ?? String(e)}）：${file}` };
	}
	// F01（审核终裁）：撕裂判定只认「无尾换行 + 解析失败」的末行（append 中途崩溃的半行——
	// reserve 撕裂=append 未返回、脚本未执行，丢弃准确；end 撕裂=按未完结保守重建）。
	// 带尾换行的解析失败/形状非法行 = 完整落盘的损坏记录，按中段损坏关闭，不默认为未提交。
	const endsWithNewline = raw.endsWith("\n");
	const lines = raw.split("\n");
	if (lines.length > 0 && lines[lines.length - 1] === "") lines.pop();
	const events: CodemodeLedgerEvent[] = [];
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i]!;
		let parsed: unknown;
		try { parsed = JSON.parse(line); } catch { /* lint-exempt:半行解析失败走下方撕裂/损坏分流（非吞错） */
			if (i === lines.length - 1 && !endsWithNewline) break; // 真正未完成的末行（写者路径另行封存）
			return { ok: false, kind: "corrupt", reason: `账本第 ${i + 1} 行损坏（完整落盘的坏记录不按未提交放过）：${file}` };
		}
		const shapeProblem = validateLedgerEventShape(parsed, accountId);
		if (shapeProblem !== null) {
			return { ok: false, kind: "corrupt", reason: `账本第 ${i + 1} 行事件非法（${shapeProblem}）：${file}` };
		}
		events.push(parsed as CodemodeLedgerEvent);
	}
	return { ok: true, out: { events, snapshot: snapshotOfEvents(accountId, events) } };
}

/** F01（审核终裁）：写者开账时封存/隔离撕裂尾部并建立可靠追加边界——只对「无尾换行」的文件：
 *  ① 尾行可完整解析=仅丢失终结符：补换行（保留事件，追加不粘行）；
 *  ② 尾行撕裂（解析失败）：原文封存进 <accountId>.torn（0600 追加，留取证），主文件截断到最后
 *  一个完好行边界——新追加从干净行首开始，append 成功 ⇔ 重放可见（修复「追加成功但重放丢失」）。
 *  只在持约写者路径调用；只读面（readCodemodeLedgerSnapshot）不落盘。返回诊断。 */
function sealTornTailForWriter(file: string, accountId: string): string {
	let raw: string;
	try { raw = fs.readFileSync(file, "utf8"); } catch { return "no-file"; }
	if (raw === "" || raw.endsWith("\n")) return "clean";
	const boundary = raw.lastIndexOf("\n") + 1; // 0（全文件单半行）或最后完好行之后
	const tail = raw.slice(boundary);
	let parsed: unknown;
	try { parsed = JSON.parse(tail); } catch { parsed = undefined; /* lint-exempt:尾行解析失败走撕裂/损坏分流 */ }
	// R01（终裁）：解析在前——JSON 完整而 schema 非法 = 完整落盘的损坏记录（corrupt 关账），
	// 不走封存截断（截断会破坏历史消费证据并绕过 F02 关账）；解析失败才进真撕裂分流。
	if (parsed !== undefined) {
		if (validateLedgerEventShape(parsed, accountId) !== null) return "corrupt-tail";
		try { fs.appendFileSync(file, "\n", "utf8"); return "newline-completed"; } catch { /* lint-exempt:补行失败按封存失败上报路径 */ return "seal-failed(newline)"; }
	}
	try {
		const tornFile = path.join(codemodeLedgerRoot(), `${accountId}.torn`);
		fs.appendFileSync(tornFile, `${JSON.stringify({ sealedAt: Date.now(), boundary, tailBytes: Buffer.byteLength(tail, "utf8"), tail })}\n`, "utf8");
		try { fs.chmodSync(tornFile, 0o600); } catch { /* lint-exempt:平台差异尽力而为 */ }
	} catch { /* lint-exempt:封存失败不阻断截断（主账本边界优先） */ }
	try {
		fs.writeFileSync(file, raw.slice(0, boundary), "utf8");
		return "torn-quarantined";
	} catch { return "seal-failed(truncate)"; /* lint-exempt:截断失败按封存失败上报（调用方关账） */ }
}

function emptySnapshot(accountId: string): CodemodeLedgerSnapshot {
	return { accountId, reservedScripts: 0, reservedTokens: 0, reservedMs: 0, sessionNestedCalls: 0, consumedToolCallIds: [], incompleteReservations: 0, events: 0 };
}

function snapshotOfEvents(accountId: string, events: readonly CodemodeLedgerEvent[]): CodemodeLedgerSnapshot {
	let reservedScripts = 0, reservedTokens = 0, reservedMs = 0, ends = 0;
	const consumed: string[] = [];
	const incomplete = new Set<string>();
	let aliasedTo: string | undefined;
	for (const ev of events) {
		if (ev.t === "reserve") {
			reservedScripts += 1; reservedTokens += ev.tokens; reservedMs += ev.ms;
			consumed.push(ev.toolCallId); incomplete.add(ev.toolCallId);
		} else if (ev.t === "end") {
			incomplete.delete(ev.toolCallId); ends += ev.nestedCalls;
		} else if (ev.t === "alias") {
			aliasedTo = ev.to;
		}
	}
	const sessionNestedCalls = ends + incomplete.size * CODEMODE_MAX_NESTED_CALLS_PER_SCRIPT;
	return { accountId, reservedScripts, reservedTokens, reservedMs, sessionNestedCalls, consumedToolCallIds: consumed, incompleteReservations: incomplete.size, ...(aliasedTo !== undefined ? { aliasedTo } : {}), events: events.length };
}

/** 只读快照（无租约；诊断/测试/未来 journal 结算引用用——不作为执法路径）。 */
export function readCodemodeLedgerSnapshot(accountId: string): { ok: true; snapshot: CodemodeLedgerSnapshot; chain: readonly string[] } | { ok: false; kind: "corrupt" | "io" | "invalid-account" | "alias-loop"; reason: string } {
	const chain: string[] = [];
	let cursor = accountId;
	for (let hop = 0; ; hop++) {
		if (!CODEMODE_ACCOUNT_ID_PATTERN.test(cursor)) return { ok: false, kind: "invalid-account", reason: `非法账户 ID：${JSON.stringify(cursor.slice(0, 40))}` };
		if (chain.includes(cursor)) return { ok: false, kind: "alias-loop", reason: `alias 链成环（${chain.join("→")}→${cursor}）——保守拒绝` };
		chain.push(cursor);
		const r = replayLedgerFile(cursor);
		if (!r.ok) return r;
		if (r.out.snapshot.aliasedTo === undefined || hop >= ALIAS_MAX_HOPS) {
			if (r.out.snapshot.aliasedTo !== undefined && hop >= ALIAS_MAX_HOPS) {
				return { ok: false, kind: "alias-loop", reason: `alias 链超 ${ALIAS_MAX_HOPS} 跳——保守拒绝` };
			}
			return { ok: true, snapshot: r.out.snapshot, chain };
		}
		cursor = r.out.snapshot.aliasedTo;
	}
}

// ── 租约与写者 ────────────────────────────────────────────────────────────────

// ── B5C 修复轮一 F06：账户历史工件只读探针（纯读，零执行语义变更） ────────────────

/** 账户侧历史工件在场性（只读事实，供意识层区分「恢复账户」与「首次新建账户」）。
 *  - lease：本账户租约文件在场（曾被打开；持有者存活或死亡未释放）；
 *  - torn：撕裂封存工件在场（曾有写入历史）；
 *  - aliasReferenced：其它账户账本存在指向本账户的 alias 事件（别名入度——fork 只指向
 *    曾真实存在的原账户，入度>0 ⇒ 本账户必有历史）。
 *  任一在场 ⇒ 恢复账户：账本本体缺失/空时不得按满额度展示（宁 off 不夸大）。
 *  扫描为全目录 *.jsonl 逐文件整读+子串检查，未设文件数/字节上限——依赖批B 账本「append-only
 *  小文件、单账户 ≤ 数十事件」的既有设计假设，非已验证的性能保证（目录规模异常增大时本探针
 *  开销随之增大；证据面只少不多——不可读文件按无入度处理）。 */
export function codemodeAccountArtifacts(accountId: string): { lease: boolean; torn: boolean; aliasReferenced: boolean } {
	if (!CODEMODE_ACCOUNT_ID_PATTERN.test(accountId)) return { lease: false, torn: false, aliasReferenced: false };
	const root = codemodeLedgerRoot();
	const probeFile = (suffix: string): boolean => {
		try { return fs.statSync(path.join(root, `${accountId}${suffix}`)).isFile(); } catch { /* lint-exempt:工件缺席即事实面（非吞错——探针语义就是布尔） */ return false; }
	};
	let aliasReferenced = false;
	try {
		const needle = `"to":"${accountId}"`;
		for (const entry of fs.readdirSync(root)) {
			if (aliasReferenced) break;
			if (!entry.endsWith(".jsonl") || entry === `${accountId}.jsonl`) continue;
			try {
				if (fs.readFileSync(path.join(root, entry), "utf8").includes(needle)) aliasReferenced = true;
			} catch { /* lint-exempt:单文件不可读不影响其余扫描（保守面只少不多） */ }
		}
	} catch { /* lint-exempt:目录不可读按零入度（保守面只少不多） */ }
	return { lease: probeFile(".lease"), torn: probeFile(".torn"), aliasReferenced };
}


interface LeaseRecord { v: 1; accountId: string; writerId: string; pid: number; acquiredAt: number; expiresAt: number }

function writeLeaseAtomic(file: string, lease: LeaseRecord): void {
	const tmp = `${file}.tmp-${process.pid}-${randomUUID().slice(0, 8)}`;
	fs.writeFileSync(tmp, JSON.stringify(lease) + "\n", "utf8");
	fs.chmodSync(tmp, 0o600);
	fs.renameSync(tmp, file);
}

/** F04（审核终裁+复修）：排他租约获取——O_EXCL（"wx"）原子新建为唯一首取通道。接管（持有者
 *  pid 已死/同进程再开）竞争安全：rename 目标名绑定「判死租约的 writerId」，rename 后复核移走
 *  的正是该租约；若 read-判死与 rename 之间被他人重建活租约（误移），经 link no-replace 恢复或
 *  让位新租约后重判——两进程同时 claim/同时接管均恰一胜者，败者读到活持有者 → conflict。 */
function claimLeaseExclusive(leaseFile: string, lease: LeaseRecord): { ok: true } | { ok: false; kind: "conflict" | "corrupt" | "io"; reason: string } {
	for (let attempt = 0; attempt < 6; attempt++) {
		// 原子满内容创建：tmp 写全量后 link（no-replace）——租约文件出现即完整，不存在
		// 「已创建未写入」空窗（败者读到空文件会误判 corrupt；wx 先建后写有此窗）。
		const tmp = `${leaseFile}.new-${lease.writerId}`;
		try {
			fs.writeFileSync(tmp, JSON.stringify(lease) + "\n", "utf8");
			try { fs.chmodSync(tmp, 0o600); } catch { /* lint-exempt:平台差异尽力而为 */ }
			try {
				fs.linkSync(tmp, leaseFile);
				return { ok: true };
			} catch (e) {
				const code = (e as NodeJS.ErrnoException).code;
				if (code !== "EEXIST") return { ok: false, kind: "io", reason: `租约排他新建失败（${code ?? String(e)}）` };
			}
		} finally {
			try { fs.rmSync(tmp, { force: true }); } catch { /* lint-exempt:候选清理尽力而为 */ }
		}
		const existing = readLease(leaseFile);
		if (existing.kind === "missing") continue; // 并发抢建后又被释放——回到 wx 重试
		if (existing.kind === "corrupt") return { ok: false, kind: "corrupt", reason: `[codemode-ledger] 租约文件损坏——不猜不覆盖，codemode 保守关闭（修复：删除 ${leaseFile} 后重试）` };
		const sameProcess = existing.lease.pid === process.pid;
		if (!sameProcess && isPidAlive(existing.lease.pid)) {
			return { ok: false, kind: "conflict", reason: `[codemode-ledger] 账户 ${lease.accountId} 已有活写者（pid=${existing.lease.pid}，writer=${existing.lease.writerId.slice(0, 16)}…）——第二写者争用，本轮拒绝（写者退出后自动接管重试）` };
		}
		// 接管：rename 目标名绑定判死租约的 writerId（同判死的两个竞争者共用同名——仅一者 rename 成功）。
		const moved = `${leaseFile}.stale-${existing.lease.writerId}`;
		try {
			fs.renameSync(leaseFile, moved);
		} catch (e) {
			const code = (e as NodeJS.ErrnoException).code;
			if (code === "ENOENT") continue; // 他人先移走——回到 wx/重判
			return { ok: false, kind: "io", reason: `接管移除旧租约失败（${code ?? String(e)}）` };
		}
		// R04（终轮）：租约身份变更与 append 同一把锁（单一 fence 链）——锁内复核移走者身份
		// 并完成落位；误移活租约经 no-replace 恢复/让位后重判。
		const box: { verdict: "claimed" | "retry" } = { verdict: "retry" };
		const locked = withLedgerMutationLock(lease.accountId, () => {
			const movedRead = readLease(moved);
			if (movedRead.kind === "ok" && movedRead.lease.writerId === existing.lease.writerId) {
				try { fs.rmSync(moved, { force: true }); } catch { /* lint-exempt:副本清理尽力而为（名字唯一不再被引用） */ }
				// 路径此刻为空：锁内 link 本人租约（link 原子，恰一胜者）。
				const t2 = `${leaseFile}.new-${lease.writerId}`;
				try {
					fs.writeFileSync(t2, JSON.stringify(lease) + "\n", "utf8");
					try { fs.chmodSync(t2, 0o600); } catch { /* lint-exempt:平台差异尽力而为 */ }
					try { fs.linkSync(t2, leaseFile); box.verdict = "claimed"; return; } catch (e) { /* lint-exempt:EEXIST=首取者胜——重判 */ }
				} finally {
					try { fs.rmSync(t2, { force: true }); } catch { /* lint-exempt:候选清理尽力而为 */ }
				}
				return;
			}
			// 误移了活租约（判死后被他人接管重建）：no-replace 恢复；路径已被新租约占据则让位（删除副本）。
			try { fs.linkSync(moved, leaseFile); } catch { /* lint-exempt:EEXIST=新租约已立——让位 */ }
			try { fs.rmSync(moved, { force: true }); } catch { /* lint-exempt:同上 */ }
		});
		if (!locked) return { ok: false, kind: "io", reason: "账户互斥锁不可得（租约身份变更拒绝无锁落位）——保守拒绝" };
		if (box.verdict === "claimed") return { ok: true };
		continue; // 重新判定（活租约在场 → conflict；仍死 → 再接管）
	}
	return { ok: false, kind: "io", reason: "租约争用重试耗尽（6 次未取得排他）" };
}

/** R04（终轮·Leader 设计裁定）：每账户变更互斥锁改 unix domain socket bind 内核独占——
 *  ① 获取=bind（EADDRINUSE=有人在持，内核裁决无窗）；② 持有探测=connect（可连=活，拒绝=死/无主）；
 *  ③ 陈旧接管=unlink 后 bind——bind 决定胜负（两进程同时 unlink+bind 恰一 bind 成功，内核）；
 *    被误 unlink 的活持有者 socket 仍绑定旧 inode，其写前存在性复核（lockOwnershipIntact fence）
 *    发现路径丢失→自己停写 fail-closed（无双写）；④ release=close+unlink 自己的（路径 inode
 *    仍指向本人时才删）；⑤ claimLeaseExclusive（租约身份变更）与 append 同走这把锁——单一 fence 链。
 *  Node bind/connect 为异步原语：由常驻 worker 线程承载（内核独占属于进程级，worker 与主线程
 *  同进程），主线程经 SharedArrayBuffer+Atomics 握手同步等待——同步 API 保持。 */
const LEDGER_LOCK_WAIT_MS = 3000;

interface LedgerLockToken {
	sockPath: string;
	bindIno: number;
}

const LEDGER_LOCK_WORKER_SRC = `
// 双格式安全（ESM/CJS 宿主 eval worker 均可用——require 仅 CJS 可用，统一走动态 import）。
Promise.all([import("node:worker_threads"), import("node:net"), import("node:fs")]).then(([wt, net, fs]) => {
const parentPort = wt.parentPort;
const held = new Map();
const orphaned = []; // 路径已被他人占据的本人旧句柄：不 close（防按名误删他人锁）
let lastBindErr = null;
function bind(p) { return new Promise((res) => {
	const server = net.createServer((s) => { s.destroy(); });
	server.once("error", (e) => { lastBindErr = e && e.code; try { server.close(); } catch (e2) {} res(null); });
	server.listen(p, () => { let ino = -1; try { ino = fs.statSync(p).ino; } catch (e) {}
		if (ino < 0) { try { server.close(); } catch (e) {} res(null); return; }
		res({ server, ino }); });
}); }
function probe(p) { return new Promise((res) => {
	let done = false; const fin = (v) => { if (done) return; done = true; try { s.destroy(); } catch (e) {} res(v); };
	const s = net.connect(p);
	s.once("connect", () => fin(true)); s.once("error", () => fin(false));
	setTimeout(() => fin(true), 500); // 探测超时保守按活（不误接管）
}); }
parentPort.on("message", async (m) => {
	const view32 = new Int32Array(m.sab); const view64 = new Float64Array(m.sab);
	const finish = (status, ino) => { Atomics.store(view32, 0, status); view64[1] = ino; Atomics.notify(view32, 0); };
	try {
		if (m.op === "acquire") {
			const deadline = Date.now() + (m.waitMs || 3000);
			for (;;) {
				const t = await bind(m.sockPath);
				if (t) { held.set(m.accountId, t); finish(1, t.ino); return; }
				const alive = await probe(m.sockPath);
				if (alive) { if (Date.now() > deadline) { finish(2, 0); return; } await new Promise((r) => setTimeout(r, 3)); continue; }
				if (lastBindErr && lastBindErr !== "EADDRINUSE") { finish(5, 0); return; } // bind 系统性失败（路径/权限）——非占用，不空转
				// 死/无主：陈旧接管=unlink 后 bind（bind 定胜负，内核裁决恰一胜者）。
				try { fs.rmSync(m.sockPath, { force: true }); } catch (e) {}
				const t2 = await bind(m.sockPath);
				if (t2) { held.set(m.accountId, t2); finish(1, t2.ino); return; }
				if (Date.now() > deadline) { finish(2, 0); return; }
				await new Promise((r) => setTimeout(r, 3));
			}
		} else if (m.op === "release") {
			const t = held.get(m.accountId);
			if (t && t.ino === m.ino) {
				held.delete(m.accountId);
				// ev-20261022-1c2b21：libuv 关闭 pipe 时按路径名 unlink(pipe_fname)（同步）。旧序「先 rm 再 close」
				// 在两步之间留窗：对端恰好 bind 上同路径，随后的 close 按名删掉对端的活锁（对端 fence
				// 复核 ENOENT → 账本保守关闭）。路径仍是本人时只 close——unlink 发生在本人仍占有路径期间
				//（他人 bind 必 EADDRINUSE，无窗）；路径已不是本人时不 close（close 会删他人的锁），
				// 句柄留存至进程退出（仅占一个 fd，路径不再指向它）。
				let cur = -1; try { cur = fs.statSync(m.sockPath).ino; } catch (e) {}
				if (cur === t.ino) { try { t.server.close(); } catch (e) {} }
				else { orphaned.push(t.server); }
			}
			finish(3, 0);
		}
	} catch (e) { finish(4, 0); }
});
});`;

let ledgerLockWorker: Worker | null = null;
function ledgerLockWorkerInstance(): Worker {
	if (ledgerLockWorker) return ledgerLockWorker;
	ledgerLockWorker = new Worker(LEDGER_LOCK_WORKER_SRC, { eval: true, name: "amagi-codemode-ledger-lock" });
	ledgerLockWorker.unref();
	return ledgerLockWorker;
}

function callLedgerLockWorker(op: "acquire" | "release", accountId: string, sockPath: string, ino = 0, waitMs = LEDGER_LOCK_WAIT_MS): { status: number; ino: number } {
	const sab = new SharedArrayBuffer(16);
	const view32 = new Int32Array(sab);
	const view64 = new Float64Array(sab);
	try {
		ledgerLockWorkerInstance().postMessage({ op, accountId, sockPath, ino, waitMs, sab });
	} catch { /* lint-exempt:worker 不可用=锁不可得，fail-closed */ return { status: 4, ino: 0 }; }
	// 判定以共享状态字为准、不以 Atomics.wait 返回码为准：worker 先于本线程进入等待就已应答时
	// 返回 "not-equal"（应答已到，不是失败）——误判为失败会让已取得的锁无人释放，后续获取空转至超时。
	Atomics.wait(view32, 0, 0, waitMs + 2000);
	if (Atomics.load(view32, 0) === 0) return { status: 4, ino: 0 };
	return { status: Atomics.load(view32, 0), ino: view64[1] ?? 0 };
}

function lockSockPath(accountId: string): string {
	// unix domain socket 受 sun_path 长度限制（macOS 104 字节）——隔离测试根（/var/folders 长前缀）
	// +24-hex 账户名会越限（bind 报路径错误而非占用）。以 sha256(root|account) 前 16 hex 定长
	// 短名挂 os.tmpdir()：隔离性（同根同账户同路径）、跨进程一致性与确定性不变。
	const h = createHash("sha256").update(`${codemodeLedgerRoot()}|${accountId}`).digest("hex").slice(0, 16);
	return path.join(os.tmpdir(), `amagi-cl-${h}.sock`);
}

/** 写前存在性复核（fence）：锁路径 inode 仍指向本人 bind——被误 unlink/替换 → false，停写 fail-closed。 */
function lockOwnershipIntact(token: LedgerLockToken): boolean {
	try { return fs.statSync(token.sockPath).ino === token.bindIno; } catch { /* lint-exempt:stat 失败=路径丢失 */ return false; }
}

/** R04：每账户互斥锁——获取（bind 内核裁决）→ 进入即 fence 复核 → fn(token) → 释放。
 *  不可得/复核失败 → false（调用方按 fail-closed 拒绝）。fn 内写前必须以 token 再复核一次
 *  （R05 接线：appendLine 写点 lockOwnershipIntact fence——被误 unlink 的活持有者在写点自检停写）。 */
function withLedgerMutationLock(accountId: string, fn: (token: LedgerLockToken) => void): boolean {
	const sockPath = lockSockPath(accountId);
	const acq = callLedgerLockWorker("acquire", accountId, sockPath);
	if (acq.status !== 1) return false;
	const token: LedgerLockToken = { sockPath, bindIno: acq.ino };
	try {
		if (!lockOwnershipIntact(token)) return false;
		fn(token);
		return true;
	} finally {
		callLedgerLockWorker("release", accountId, sockPath, token.bindIno, 1500);
	}
}

/** R03：租约续期 no-replace——tmp+link，不覆盖他人租约；路径被移走时重建本人租约。 */
function refreshLeaseNoReplace(file: string, lease: LeaseRecord): void {
	const tmp = `${file}.new-${lease.writerId}`;
	try {
		fs.writeFileSync(tmp, JSON.stringify(lease) + "\n", "utf8");
		try { fs.chmodSync(tmp, 0o600); } catch { /* lint-exempt:平台差异尽力而为 */ }
		try { fs.linkSync(tmp, file); } catch { /* lint-exempt:EEXIST=他人已立——让位（下次 append 复核失败） */ }
	} finally {
		try { fs.rmSync(tmp, { force: true }); } catch { /* lint-exempt:候选清理尽力而为 */ }
	}
}

/** R03：租约释放身份安全——rename 目标名绑定本人 writerId，复核内容后删除；误移他人
 *  活租约时 no-replace 恢复或让位。 */
function releaseLeaseFileSafely(leaseFile: string, lease: LeaseRecord): void {
	const moved = `${leaseFile}.release-${lease.writerId}`;
	try { fs.renameSync(leaseFile, moved); } catch { return; /* lint-exempt:已不在场 */ }
	let mine = true;
	try { mine = (JSON.parse(fs.readFileSync(moved, "utf8")) as LeaseRecord)?.writerId === lease.writerId; } catch { mine = true; /* lint-exempt:名字绑定为本人所移，内容异常仍按本人清理 */ }
	if (mine) { try { fs.rmSync(moved, { force: true }); } catch { /* lint-exempt:清理失败留待 pid 死亡接管 */ } return; }
	try { fs.linkSync(moved, leaseFile); } catch { /* lint-exempt:他人已立新租约——让位 */ }
	try { fs.rmSync(moved, { force: true }); } catch { /* lint-exempt:清理尽力而为 */ }
}

function readLease(file: string): { kind: "missing" } | { kind: "ok"; lease: LeaseRecord } | { kind: "corrupt" } {
	let raw: string;
	try { raw = fs.readFileSync(file, "utf8"); } catch (e) {
		if ((e as NodeJS.ErrnoException).code === "ENOENT") return { kind: "missing" };
		return { kind: "corrupt" };
	}
	try {
		const parsed = JSON.parse(raw) as LeaseRecord;
		if (parsed?.v !== 1 || typeof parsed.writerId !== "string" || !Number.isSafeInteger(parsed.pid)) return { kind: "corrupt" };
		return { kind: "ok", lease: parsed };
	} catch { /* lint-exempt:租约损坏按 corrupt 上报（保守关闭，非吞错） */ return { kind: "corrupt" }; }
}

/** 打开（或接管）账户账本：租约获取 + 重放 + alias 跟随。写者身份 = 进程内随机（同进程二次
 *  open = 最后打开者接管租约、前写者随后 append 失能——单写者不变量同样成立）。 */
export function openCodemodeLedger(accountId: string): CodemodeLedgerOpen {
	if (!CODEMODE_ACCOUNT_ID_PATTERN.test(accountId)) {
		return { ok: false, kind: "invalid-account", reason: `[codemode-ledger] 非法账户 ID（受控格式 24-hex，不接受路径输入）：${JSON.stringify(accountId.slice(0, 40))}` };
	}
	const chain: string[] = [];
	let cursor = accountId;
	for (let hop = 0; ; hop++) {
		if (chain.includes(cursor)) return { ok: false, kind: "corrupt", reason: `[codemode-ledger] alias 链成环（${chain.join("→")}→${cursor}）——保守关闭` };
		if (hop > ALIAS_MAX_HOPS) return { ok: false, kind: "corrupt", reason: `[codemode-ledger] alias 链超 ${ALIAS_MAX_HOPS} 跳——保守关闭` };
		chain.push(cursor);
		const leaseFile = leaseFilePath(cursor);
		const writerId = `${process.pid}-${randomUUID()}`;
		const now = Date.now();
		const lease: LeaseRecord = { v: 1, accountId: cursor, writerId, pid: process.pid, acquiredAt: now, expiresAt: now + LEASE_TTL_MS };
		const claimed = claimLeaseExclusive(leaseFile, lease);
		if (!claimed.ok) {
			if (claimed.kind === "conflict") return { ok: false, kind: "conflict", reason: claimed.reason };
			return { ok: false, kind: claimed.kind === "corrupt" ? "corrupt" : "io", reason: claimed.reason };
		}
		// F01（审核终裁）：持约写者在重放前封存撕裂尾部/补行建立可靠追加边界（只读面不落盘）。
		let seal = "lock-unavailable";
		withLedgerMutationLock(cursor, () => { seal = sealTornTailForWriter(accountFilePath(cursor), cursor); });
		if (seal === "corrupt-tail") {
			releaseLeaseFileSafely(leaseFile, lease);
			return { ok: false, kind: "corrupt", reason: `[codemode-ledger] 账本尾部为完整 JSON 但事件 schema 非法——按完整损坏记录保守关账（不封存截断、不破坏历史消费证据）：${accountFilePath(cursor)}` };
		}
		if (seal.startsWith("seal-failed") || seal === "lock-unavailable") {
			releaseLeaseFileSafely(leaseFile, lease);
			return { ok: false, kind: "io", reason: `[codemode-ledger] 撕裂尾部封存失败（${seal}）——无法建立可靠追加边界，codemode 保守关闭` };
		}
		const replay = replayLedgerFile(cursor);
		if (!replay.ok) {
			releaseLeaseFileSafely(leaseFile, lease);
			if (replay.kind === "io") return { ok: false, kind: "io", reason: replay.reason };
			return { ok: false, kind: "corrupt", reason: replay.reason };
		}
		if (replay.out.snapshot.aliasedTo === undefined) {
			const handle = makeHandle(cursor, leaseFile, lease);
			return { ok: true, ledger: handle, snapshot: replay.out.snapshot, chain };
		}
		// alias 跟随：释放本跳租约（身份安全），继续打开目标账户。
		releaseLeaseFileSafely(leaseFile, lease);
		cursor = replay.out.snapshot.aliasedTo;
	}
}

function makeHandle(accountId: string, leaseFile: string, lease: LeaseRecord): CodemodeLedgerHandle {
	const file = accountFilePath(accountId);
	let released = false;
	let failed = false;
	const appendLine = (event: CodemodeLedgerEvent): boolean => {
		if (released || failed) return false;
		try {
			const fd = fs.openSync(file, "a", 0o600);
			try {
				let leaseMismatch = false;
				// R03（终裁）：复核紧贴写入——fd 之后、每账户互斥锁（socket bind 内核独占）之内，
				// 复核与写入同处互斥锁内（时点检查，固有 check-then-act 窗口仅容租约持有者单条在途写）：
				// 租约被移走/接管 ⇒ 本次追加拒绝（fail-closed），不产生无主写入；锁不可得同样拒绝（保守）。
				const locked = withLedgerMutationLock(accountId, (token) => {
					const current = readLease(leaseFile);
					if (current.kind !== "ok" || current.lease.writerId !== lease.writerId) { leaseMismatch = true; return; }
					// R05（终轮裁定）：写点 fence 接线——锁 inode 被夺/路径丢失 ⇒ 停写 fail-closed
					//（被误 unlink 的活持有者在此自检停写，不产生失锁后写入）。
					if (!lockOwnershipIntact(token)) { leaseMismatch = true; return; }
					fs.writeFileSync(fd, JSON.stringify(event) + "\n", "utf8");
					fs.fsyncSync(fd);
				});
				if (!locked || leaseMismatch) { failed = true; return false; }
			} finally { fs.closeSync(fd); }
			try { fs.chmodSync(file, 0o600); } catch { /* lint-exempt:平台差异尽力而为 */ }
			// R03：租约续期改 no-replace（tmp+link）——不覆盖他人已立租约；被移走时下次 append 复核失败。
			refreshLeaseNoReplace(leaseFile, { ...lease, expiresAt: Date.now() + LEASE_TTL_MS });
			return true;
		} catch { /* lint-exempt:追加失败置 failed 并返回 false——调用方拒绝执行（fail-closed 语义面） */ failed = true; return false; }
	};
	return {
		accountId,
		appendReserve: (input) => appendLine({ v: 1, t: "reserve", at: Date.now(), toolCallId: input.toolCallId, scriptHash: input.scriptHash, tokens: input.tokens, ms: input.ms }),
		appendStart: (toolCallId) => appendLine({ v: 1, t: "start", at: Date.now(), toolCallId }),
		appendEnd: (toolCallId, outcome) => appendLine({ v: 1, t: "end", at: Date.now(), toolCallId, ok: outcome.ok, durationMs: outcome.durationMs, nestedCalls: outcome.nestedCalls, callsComplete: outcome.callsComplete }),
		appendAlias: (to) => appendLine({ v: 1, t: "alias", at: Date.now(), from: accountId, to }),
		appendClose: (reason) => appendLine({ v: 1, t: "close", at: Date.now(), reason: String(reason).slice(0, 200) }),
		release(): void {
			if (released) return;
			released = true;
			withLedgerMutationLock(accountId, () => { releaseLeaseFileSafely(leaseFile, lease); });
		},
	};
}

/** 测试辅助：枚举账本根下账户文件（隔离目录内诊断断言用）。 */
export function _codemodeLedgerAccountsForTest(): string[] {
	try { return fs.readdirSync(codemodeLedgerRoot()).filter((f) => f.endsWith(".jsonl")).map((f) => f.replace(/\.jsonl$/, "")).sort(); } catch { /* lint-exempt:测试辅助读取失败按空面（诊断用途） */ return []; }
}
