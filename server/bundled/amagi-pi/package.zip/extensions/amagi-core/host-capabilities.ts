/**
 * host-capabilities.ts — amagi-pi v2 H1（方案 §6.1 宿主证据口径表 / §6.2.9 / §8.4-H1）：宿主能力快照。
 *
 * 职责（单一）：记录本扩展实际消费或明确关心的有限宿主能力集合，提供
 *  - 版本判定（受测版本表：能力 × 引入版本 × 事实依据注记，来源 CHANGELOG/dist/docs）；
 *  - 运行时探测（仅对象形状能力：typeof 探测 setActiveTools/registerTool 等）；
 *  - 组合快照 resolveHostCapabilities(pi)：探测结果 + 版本判定合成，供新能力准入
 *    （§6.2.10「不支持必要能力时拒绝新模式」）与诊断报告使用。
 *    新增 1.1.0 字段/CLI 条目仅作诊断；不以此快照证明当前事件或历史上下文有字段。
 *
 * 判定口径（§6.2.9；A2/S4 扩容后同口径延伸到 1.1.0 世代）：
 *  - 对象形状能力（setActiveTools/getActiveTools/registerTool、registerToolRenderer、
 *    ctx.modelRegistry.generateImages）→ 运行时 typeof 探测为权威，版本表仅作交叉注记；
 *    modelRegistry 在事件处理器 ctx 上而非 ExtensionAPI，探测面经 RuntimeProbeSurface
 *    的可选 modelRegistry 投影传入（消费方在 handler 内组装 { ...pi, modelRegistry: ctx.modelRegistry }）。
 *  - 选项/事件形状能力（ToolDefinition.constrainedSampling 字段、session_compact_failed 事件、
 *    ToolCallEventResult.terminate 批次提示、sendUserMessage.expandPromptTemplates、
 *    SessionManager.inMemory 外部 entries、ProviderHeaders string|null、agent_settled.aborted、
 *    tool_execution_end.durationMs、ToolRenderContext.durationMs/outputPad、--tools +/- 语法）
 *    → 无法安全 typeof 探测，按受测版本表说明宿主支持。pi.on 不抛错仅证明监听可注册，
 *    不证明事件字段存在；1.1.0 字段消费按实际载荷校验，缺字段走旧行为/省略展示。
 *    即使表为 false/版本未知也不能忽略合法字段；表为 true 不保证旧历史含新字段。
 *  - 配置键形状能力（models.json 的 samplingParamsByThinkingLevel、MCP 项目浅覆写 .pi/mcp.json、
 *    MCP auth.provider 令牌认证）→ 同为配置面，无法 typeof 探测，按受测版本表判定；
 *    配置键生效范围另有宿主约束（如采样键仅三类 OpenAI 兼容 API），记于各 evidence 注记。
 *  - 版本未知（包解析失败）→ 仅探测型能力可 true；版本判定型一律 false（保守降级，不误报）。
 *
 * 版本来源：createRequire 解析 @earendil-works/pi-coding-agent/package.json——生产安装（peer "*"
 * 由宿主提供）时即宿主自身版本；开发仓内为 devDeps 版本。解析失败返回 null，不猜测。
 *
 * 纯读无副作用：零 spawn、零任务状态写、零 ~/.pi 触碰。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";

/** 原生 MCP 的对象能力门。只探测公开注册/发现/注销接口，不以版本号或 owner 证明授权。
 * getter/枚举异常也视为不可用；不会连接、调用工具或修改宿主。
 */
export function nativeMcpRegistrationAvailable(host: unknown): boolean {
	if (!host || typeof host !== "object") return false;
	try {
		const pi = host as Partial<Pick<ExtensionAPI, "registerMcpServer" | "unregisterMcpServer" | "getMcpServers" | "getAllTools">>;
		return typeof pi.registerMcpServer === "function" && typeof pi.unregisterMcpServer === "function"
			&& typeof pi.getAllTools === "function" && typeof pi.getMcpServers === "function"
			&& Array.isArray(pi.getMcpServers());
	} catch { return false; }
}

/** 能力名（稳定标识，测试与准入逻辑引用）。 */
export type HostCapabilityName =
	| "setActiveTools" // 动态工具激活 API（get/setActiveTools）
	| "strictToolsAllowlist" // --tools 显式声明名单（1.0.4+ native MCP 保留例外，仍须 per-call 守卫）
	| "dynamicToolRegistration" // registerTool 运行期注册（session_start 后即时生效）
	| "toolPrepareArguments" // ToolDefinition.prepareArguments（schema 校验前参数准备垫片）
	| "constrainedSampling" // ToolDefinition.constrainedSampling（json_schema strict prefer/require）
	| "toolResultTerminate" // 工具结果 terminate:true（终结性工具结果）
	| "blockedToolCallTerminate" // ToolCallEventResult.terminate（blocked 批次整批 terminating 提示）
	| "sessionCompactFailed" // session_compact_failed 事件（reason/errorMessage/aborted/willRetry/fromExtension）
	| "sessionManagerInMemoryEntries" // SessionManager.inMemory(cwd, options, entries?) 外部 entries 恢复
	| "providerHeadersNullable" // ProviderHeaders 值 string|null（null = 删除同名默认头）
	| "expandPromptTemplates" // sendUserMessage 选项 expandPromptTemplates（显式命令/模板展开）
	| "reloadSwitchLifecycle" // reload/switch 重建扩展运行时、旧 ctx 失效（session_shutdown）
	| "agentBeforeSettleBoundary" // agent_before_settle 可动作边界（entries+continue:true 恰一次续请求）
	// ── A2（M1，2026-10-04）：pi 0.99.2–1.0.2 世代扩容，B4/B5/B6/C14 切片准入门 ──
	| "registerToolRenderer" // pi.registerToolRenderer（任意工具含未注册/MCP 工具的渲染 resolver 链）
	| "samplingParamsByThinkingLevel" // models.json 按思维档采样覆写（仅三类 OpenAI 兼容 API 生效）
	| "mcpProjectOverrides" // MCP 项目级浅覆写 .pi/mcp.json（仅 enabled/exposure/toolExposure）
	| "mcpAuthProvider" // MCP auth.provider（HTTP server 复用 /login provider 令牌认证）
	| "modelRegistryGenerateImages" // ctx.modelRegistry.generateImages（生图模型调用，会话计费）
	// ── B10（M2，2026-10-04）：L0 结构化分节准入门 ──
	| "structuredSystemPromptSections" // before_agent_start systemPromptOptions.sections 结构化分节（transcript 差分 + 中置系统消息更新）
	// ── S4（2026-10-09）：pi 1.1.0 字段/CLI 能力说明，仅诊断、不作载荷存在性门 ──
	| "agentSettledAborted" // agent_settled.aborted（宿主中止事实）
	| "toolsArgumentModifiers" // --tools +name/-name（宿主支持；amagi 派发不采纳）
	| "toolExecutionEndDurationMs" // tool_execution_end.durationMs（monotonic execute timing）
	| "toolRenderContextDurationMs" // ToolRenderContext.durationMs（最终结果记录耗时）
	| "toolRenderContextOutputPad" // ToolRenderContext.outputPad（委托宿主默认外壳）
	// ── B5A（ev-20261012-7517d8 批A，2026-10）：codemode 受控装配准入门 ──
	| "codemodeControlledFactory" // 公开 createCodemodeExtension 工厂（models:false 组合；同名替换内置实例）
	| "lengthContinuation"; // 流式 toolcall_delta、message_end 替换及 nested executeTool

/** 能力判定方式。 */
export type CapabilityProbeKind = "runtime-probe" | "version-table";

export interface CapabilityFact {
	/** 引入版本（受测版本表口径；基线前引入的以最早可考 CHANGELOG 条目为准）。 */
	readonly since: string;
	/** 判定方式。 */
	readonly kind: CapabilityProbeKind;
	/** 事实依据注记（来源文件 + 版本；CHANGELOG 行文关键词可在受测包内复核）。 */
	readonly evidence: string;
	/** 扩展消费状态注记（本仓库谁在用/预留）。 */
	readonly consumption: string;
}

/**
 * 受测版本表（宿主 0.85.1 CHANGELOG.md + dist/docs，2026-09-08 本机核对；ev-20260920 在 0.86.0 下逐条复核仍准确）。
 * 0.86.0 新增能力尚未入表（未消费不登记）：cache_warming_decision 事件、包入口导出的扩展事件/结果类型、
 * pi.on() 退订句柄、ctx.modelRegistry.stream()/streamSimple()——待 v2.7.x 择机批次消费时随受测证据入表。
 * since 均为 CHANGELOG 可复核条目；evidence 关键词直接引自该条目或 dist 类型声明。
 *
 * 0.87.1 批次 C（2026-09-30 L6 收口）受测说明：本表在 0.87.1 下经 tests/pi-087-rpc-smoke.mjs
 * （真实二进制 RPC 交互）与 tests/pi-087-constrained-wire.test.mjs（仓库解析 pi-ai 0.87.1
 * 公开导出的 payload 层全矩阵）复测，既有能力判定不变；本批实际消费的 0.87.1 新增面
 * （SessionManager.buildSessionProjection）登记在 webui/server.ts 的 context 视图装配层
 * （含旧宿主降级链），不入本表（本表只记 amagi-core 主扩展直接消费的能力快照）。
 * 实测差异记录（不作为能力登记）：rpc 模式下 bindExtensions 的 session_start emit
 * 时序与 TUI 不同步——依赖 session_start 绑定的能力（webui server）不可在 rpc/print
 * 无交互宿主下验证，见 CHANGELOG 2.8.6 已知边界。
 *
 * A2 扩容批次（2026-10-04，M1）：新增五项 0.99.2/1.0.0/1.0.1/1.0.2 能力，证据锚点取自实装
 * 1.0.2 包（devDeps 锁定）CHANGELOG.md/docs/dist .d.ts 逐条核对；B4/B5/B6/C14 的准入门。
 * fullscreen TUI 默认（1.0.0，tuiMode）经裁定不入本表：本扩展无任何 tuiMode/fullscreen
 * 消费分支（grep 零命中），且设计 §10.1 注记其验证口径是「双模式真实终端、不能只检查设置
 * 字段」——版本表条目恰是要避免的设置字段级宣称；真实终端证据由 A1b 切片交付。
 *
 * S4 扩容（2026-10-09）：五项 1.1.0 version-table 取自该版 CHANGELOG/dist 声明，
 * 锚点用发布引文 + 相对文件/符号（行号为该版位置）。版本表只说明能力，不证明字段当前有值；
 * 开发仓包版本不等于派生子进程版本，消费方不得以这些布尔值作新字段存在性门。
 */
export const CAPABILITY_FACTS: Readonly<Record<HostCapabilityName, CapabilityFact>> = {
	lengthContinuation: {
		since: "1.3.0", kind: "version-table",
		evidence: "pi 1.3.0 和 1.4.0 真实进程流式 length 复现：tests/length-continuation-repro.test.mjs；完整续传验证见 tests/length-continuation.test.mjs",
		consumption: "length-continuation.ts：保存增量并通过宿主原工具链续传；旧版与未知版本不注册",
	},
	setActiveTools: {
		since: "0.34.0",
		kind: "runtime-probe",
		evidence: "CHANGELOG 0.34.0「pi.getActiveTools()/pi.setActiveTools()」/ 0.39.0「setActiveTools() in ExtensionAPI for dynamic tool management」；dist/core/extensions/types.d.ts ExtensionAPI.getActiveTools/setActiveTools",
		consumption: "tool-surface.ts 动态工具面治理（弱宿主缺函数走懒注册降级）",
	},
	strictToolsAllowlist: {
		since: "0.68.0",
		kind: "version-table",
		evidence: "CHANGELOG 0.68.0「--tools now allowlists built-in, extension, and custom tools by name」；CHANGELOG 1.0.4 Fixed「--tools now keeps MCP tools unless an entry starts with mcp__」（CHANGELOG.md:72）；dist/core/sdk.d.ts:34–49 CreateAgentSessionOptions.tools：显式纯名单作用于声明面，无 mcp__ 条目仍保留 native MCP 的 codemode/tool search 可达性；docs/cli.md §Tools / §MCP tools",
		consumption: "task-run.ts / rpc-pool.ts 子任务显式 --tools 声明面名单；1.0.4+ native MCP 例外不能证明 nested 调用禁用，仍须 per-call 权限守卫；不展开宿主 defaultTools",
	},
	dynamicToolRegistration: {
		since: "0.35.0",
		kind: "runtime-probe",
		evidence: "CHANGELOG 0.35.0「pi.registerTool() - Register tools the LLM can call」/ 0.55.4「Tools registered in session_start and later handlers now refresh immediately … without /reload」；docs/extensions.md + examples/extensions/dynamic-tools.ts",
		consumption: "index.ts 16 处 pi.registerTool（四稳定工具 + legacy 面）",
	},
	toolPrepareArguments: {
		since: "0.64.0",
		kind: "version-table",
		evidence: "CHANGELOG 0.64.0「Added ToolDefinition.prepareArguments hook to prepare raw tool call arguments before schema validation」；dist/core/extensions/types.d.ts ToolDefinition.prepareArguments",
		consumption: "edit-override.ts / write-override.ts 透传原生 baseDef.prepareArguments；tool-surface.ts 分面工具依赖",
	},
	constrainedSampling: {
		since: "0.83.0",
		kind: "version-table",
		evidence: "CHANGELOG 0.83.0「Added inherited Tool.constrainedSampling with strict JSON Schema (prefer/require)」；dist/core/extensions/types.d.ts ToolDefinition.constrainedSampling?: false | ConstrainedSamplingConfig；pi-ai dist/types.d.ts ConstrainedSamplingConfig = {type:\"json_schema\",strict:\"prefer\"|\"require\"}|{type:\"grammar\",…}；W3-⑤ 真机实测（2026-09-18，host 0.84.4，pi-ai makeStrictJsonSchema 同形请求）：amagi-glm/glm-5.3 与 amagi-公司中转站/gemini-3.8-flash 均 HTTP 200 接受 strict 子集 schema 并返回合规 tool_call（可选字段补 null，遵循 anyOf-null 转换）；amagi-Deepseek-go 因端点要求 x-opencode-session 头未测出 strict 结论（control 亦失败，非 strict 不支持）",
		consumption: "v2 新分面预留（§6.1：先 prefer，保留运行校验，不引入 grammar）；实测两家接受、一家环境阻塞，报告 docs/verification/2026-09-18-constrained-sampling.md",
	},
	toolResultTerminate: {
		since: "0.69.0",
		kind: "version-table",
		evidence: "CHANGELOG 0.69.0「Terminating tool results via terminate: true, allowing custom tools to end on a final tool call」；examples/extensions/structured-output.ts",
		consumption: "tool-result-adapter.ts 终结性结果注记（受测版本表交叉核对）",
	},
	blockedToolCallTerminate: {
		since: "0.84.3",
		kind: "version-table",
		evidence: "CHANGELOG 0.84.3「Added terminate support to blocked extension tool_call events so all-terminating batches can skip the automatic follow-up model call」；dist/core/extensions/types.d.ts ToolCallEventResult.terminate（整批 finalized 结果均 terminating 才提前终止，不杀已开始的兄弟工具——docs/extensions.md）",
		consumption: "v2 权限拒绝路径预留（P 系列；混合批次不误判）",
	},
	sessionCompactFailed: {
		since: "0.84.3",
		kind: "version-table",
		evidence: "CHANGELOG 0.84.3「Added session_compact_failed extension events … expose their reason, retry state, source, and error message」；dist/core/extensions/types.d.ts SessionCompactFailedEvent{reason,errorMessage?,aborted,willRetry,fromExtension}",
		consumption: "continuation.ts 已接入（0.83 时代经类型强转订阅；typed 化属 H2）",
	},
	sessionManagerInMemoryEntries: {
		since: "0.85.0",
		kind: "version-table",
		evidence: "CHANGELOG 0.85.0「Added SessionManager.inMemory() support for restoring externally managed session entries」；dist/core/session-manager.d.ts static inMemory(cwd?, options?, entries?: FileEntry[])",
		consumption: "v2 隔离恢复夹具预留（H3；外部 entries 含分支/压缩语义，不替代 TaskStore）",
	},
	providerHeadersNullable: {
		since: "0.84.3",
		kind: "version-table",
		evidence: "CHANGELOG 0.84.3「ModelRegistry.getApiKeyAndHeaders() now returns ProviderHeaders with string | null values and preserves null header-deletion markers」；pi-ai dist/types.d.ts ProviderHeaders = Record<string, string|null>",
		consumption: "compaction-model.ts 旧宿主认证回退原样转发 headers（含 null 删除标记）；新宿主委托 ModelRegistry.streamSimple 原生运行时",
	},
	expandPromptTemplates: {
		since: "0.84.3",
		kind: "version-table",
		evidence: "CHANGELOG 0.84.3「Added expandPromptTemplates to extension pi.sendUserMessage() options for explicitly dispatching commands」；dist/core/extensions/types.d.ts sendUserMessage options.expandPromptTemplates",
		consumption: "webui/server.ts 命令派发已用（仅用户显式「/」开头文本，§6.2.8）",
	},
	reloadSwitchLifecycle: {
		since: "0.83.0", // 0.83.0 基线已验证在位（引入早于本表考据起点）
		kind: "version-table",
		evidence: "dist/core/extensions/types.d.ts SessionShutdownEvent「Fired before an extension runtime is torn down due to quit, reload, or session replacement」；docs/extensions.md：reload/switch 重建扩展运行时、旧 ctx 失效；本扩展 13 处 pi.on(\"session_shutdown\") 依赖该语义",
		consumption: "index.ts/continuation.ts 等生命周期收尾（owner 不跨 reload 复生）",
	},
	// ── B9 跟进（M1，2026-10-04）：agent_before_settle 版本门入表（continuation.ts 切口径）──
	agentBeforeSettleBoundary: {
		since: "0.87.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 0.87.0 Added「actionable turn_end and agent_before_settle extension boundaries. Return { entries: [...event.entries, draft], continue: true } to persist structural entries in order and ensure one next provider request without changing steering or follow-up scheduling」（同版 Breaking：AgentBeforeSettleEvent 入 ExtensionEvent 联合）；docs/extensions.md §extension events「agent_before_settle is the final actionable boundary: it can append entries and request one continuation」；dist/core/extensions/types.d.ts AgentBeforeSettleEvent extends BoundaryState、AgentBeforeSettleEventResult = BoundaryResult",
		consumption: "continuation.ts B9 边界裁决版本门（boundaryAdjudicationEnabled 经 capabilityEnabledByVersion 判定，宿主 <0.87.0 维持 legacy 行为）",
	},
	// ── A2（M1，2026-10-04）：pi 0.99.2–1.0.2 世代扩容（B4/B5/B6/C14 准入门）──
	registerToolRenderer: {
		since: "1.0.1",
		kind: "runtime-probe",
		evidence:
			"CHANGELOG 1.0.1 Added「pi.registerToolRenderer(), which chooses how calls to a tool are drawn, including tools that are not registered」(#10285)；docs/extensions.md §Tool rendering（resolver 链按扩展加载序、next() 回退余链）；dist/core/extensions/types.d.ts ExtensionAPI.registerToolRenderer(resolver: ToolRendererResolver)、ToolRendererResolver=(toolName,next)=>ToolRenderers|undefined",
		consumption: "B4 工具卡统一语义投影准入门（对未注册/MCP 工具挂 resolver，缺失回原 renderer 不接线）",
	},
	samplingParamsByThinkingLevel: {
		since: "1.0.2",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.0.2 Added「samplingParamsByThinkingLevel in models.json for per-thinking-level sampling parameter overrides on OpenAI-compatible APIs」(#9776)；docs/models.md §Configure sampling by thinking level：仅 openai-completions/openai-responses/azure-openai-responses 三类 API 生效、其余 API 忽略（设计 §2.3-3 校正，不能按 provider 名断言）；Pi 思维档键 off/minimal/low/medium/high/xhigh/max，合并序 = 模型 samplingParams → 档位覆写 → 请求级覆写",
		consumption: "B5 采样分层准入门（三 API payload 合并/clamp；模型显式要求却不支持则拒绝配置）",
	},
	mcpProjectOverrides: {
		since: "1.0.1",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.0.1 Added「project overrides for user-level MCP servers: a .pi/mcp.json entry without command or url sets only enabled, exposure, and toolExposure of the user-level server」(#10277)；docs/mcp.md §Configure servers：浅覆写条目（无 command/url/type）仅覆写 enabled/exposure/toolExposure，env/headers/auth 保留用户级；带 command/url/type 则整体替换；项目配置须先过 project trust",
		consumption: "B6 MCP 混合基座准入门（浅覆写与完整替换区分；不以版本号当权限证明）",
	},
	mcpAuthProvider: {
		since: "0.99.2",
		kind: "version-table",
		evidence:
			"CHANGELOG 0.99.2 Added「\"auth\": { \"provider\": \"<provider>\" } for HTTP MCP servers to send a provider's current /login token as the bearer token instead of using MCP OAuth. The token is read on every request … Only allowed in the global mcp.json and from extensions, and requires https except on loopback hosts」；dist/core/mcp-servers.d.ts McpHttpServerConfig.auth?: { provider: string }（注释：Send the token of a pi provider (/login <provider>) instead of using OAuth）",
		consumption: "B6b native 认证路线准入门（逐请求重读令牌、仅全局 mcp.json/扩展注册、HTTPS 除回环；未真机验证不启用）",
	},
	modelRegistryGenerateImages: {
		since: "1.0.0",
		kind: "runtime-probe",
		evidence:
			"CHANGELOG 1.0.0 Added「models.generateImages() to codemode scripts … Extensions can call ctx.modelRegistry.generateImages()」（用量计入会话成本）；dist/core/model-registry.d.ts generateImages(model: ImageModel<ImageApi>, context: ImagesContext, options?: ModelsImagesOptions): Promise<AssistantImages>；docs/codemode.md §Generate images / docs/models.md §Use image models",
		consumption: "C14 宿主生图证据通道准入门（可用模型/结果/费用/安全落盘；缺失不注册生图模式）",
	},
	// ── B10（M2，2026-10-04）：L0 结构化分节准入门（0.86.0 sections 差分语义定型）──
	structuredSystemPromptSections: {
		since: "0.86.0",
		kind: "version-table",
		evidence:
			"事件面自 0.68.0（CHANGELOG 0.68.0 Added「before_agent_start now exposes systemPromptOptions (BuildSystemPromptOptions)」#3473）；本能力按消费语义判定 0.86.0 定型——CHANGELOG 0.86.0 Added「transcript-backed mid-conversation system prompt and tool changes so instruction and tool updates survive resume and branch navigation while preserving cached prefixes on supported models」#9548；docs/extensions.md §Events and concurrency「before_agent_start exposes both the current prompt and its structured systemPromptOptions … Prefer changing prompt sections … so Pi can append a transcript delta」；dist/core/system-prompt.d.ts NormalizedBuildSystemPromptOptions.sections: Record<string,string>、buildSystemPromptSections（节名约束 ^[a-z][a-z0-9_-]*$ 且非 preamble，自定义节在 cwd 节后按插入序以 <name> 包裹）、diffSystemPromptSections（未变零 transcript 条目，变化发 SystemMessage.sections 补丁）",
		consumption: "B10 L0 结构化分节准入门（leader-prompt.ts 写 amagi_l0_* sections；不可用/版本未知回退 forced 字符串注入，行为等价）",
	},
	// ── S4（2026-10-09）：pi 1.1.0 字段/CLI 能力说明（非运行时字段探测）──
	agentSettledAborted: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.1.0 Added「aborted to agent_settled session, extension, and JSON events」(#10607)（CHANGELOG.md:21）；dist/core/extensions/types.d.ts:776–781 AgentSettledEvent.aborted:boolean；dist/core/agent-session.d.ts:47–56 AgentSessionEvent",
		consumption: "task-run.ts / rpc-pool.ts 按实际 aborted===true 消费中止事实；字段缺席维持旧行为，不依赖版本门",
	},
	toolsArgumentModifiers: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.1.0 Added「+name and -name entries to --tools」（CHANGELOG.md:15）；dist/core/settings-manager.d.ts:153–165 getToolListError/applyToolModifiers（纯 +/- 名单按默认集增删，与纯名字混用报错）；docs/cli.md §Tools",
		consumption: "仅诊断宿主支持；amagi 派发明确不采纳 +/- 语法，要求完整显式名单，权限交集不展开宿主 defaultTools",
	},
	toolExecutionEndDurationMs: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.1.0 Added「durationMs to the tool render context and to tool_execution_end extension events」(#10549)（CHANGELOG.md:16）；dist/core/extensions/types.d.ts:847–858 ToolExecutionEndEvent.durationMs?:number（monotonic execute timing；未执行可缺席）",
		consumption: "task-run.ts 活动摘要按实际合法非负有限数消费；不代替进程身份审计、验证命令时长或旧 toolMs，不依赖版本门",
	},
	toolRenderContextDurationMs: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.1.0 Added「durationMs to the tool render context」(#10549)（CHANGELOG.md:16）；dist/core/extensions/types.d.ts:372–376 ToolRenderContext.durationMs:number|undefined（运行中/未执行/旧历史可为 undefined）",
		consumption: "tool-renderers.ts 最终卡片按实际合法耗时展示；历史缺失不补算，不依赖版本门",
	},
	toolRenderContextOutputPad: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"CHANGELOG 1.1.0 Added「outputPad to the tool render context」(#10557)（CHANGELOG.md:17；Changed:27）；dist/core/extensions/types.d.ts:377–378 ToolRenderContext.outputPad:number（renderShell:self 须自行应用）",
		consumption: "tool-renderers.ts 委托宿主 default shell 应用 outputPad；amagi 无 self-shell 分支，不再包一层 padding",
	},
	// ── B5A（2026-10，7517d8 批A）：codemode 受控装配准入门 ──
	codemodeControlledFactory: {
		since: "1.1.0",
		kind: "version-table",
		evidence:
			"dist/index.d.ts:29 公开导出 createCodemodeExtension（CodemodeExtensionOptions.models 默认 true——1.1.0 实装核验；dist/extensions/codemode/index.d.ts:9-17）；宿主 7517d8 探测报告 Q4/C11#1：CLI/settings 无 models 关闭键，仅 SDK/组合层工厂可关；同名工具注册经 resource-loader omitReplacedExtensions 整体卸载 replaceable builtin（dist/core/resource-loader.js:62-100）；1.0.2 是否已有该 options 未核验（探测报告覆盖边界），故 since 按 1.1.0 已验证组合登记；异步动态导入探测在 codemode-adapter（本表只记版本门，不作导入探测）",
		consumption: "codemode-adapter.ts 受控装配（B5A 批A）：controlledCodemodeBackendAvailable（工厂动态导入+版本≥1.1.0 双门）供 task-facets BackendCaps.codemode；sandbox 物理隔离证据见 tests/pi-110-b5a-codemode-controlled.test.mjs（models typeof undefined / write 不可达）",
	},
};

/** 运行时探测面（ExtensionAPI 类型投影 + 事件 ctx 的 modelRegistry 可选投影；不引入 any）。 */
type RuntimeProbeSurface = Pick<
	ExtensionAPI,
	"registerTool" | "getActiveTools" | "setActiveTools" | "registerToolRenderer"
> &
	Partial<Pick<ExtensionContext, "modelRegistry">>;

/** 纯语义化版本三元组比较（x.y.z；容错忽略后缀）；非数字段按 0 处理。返回 <0/0/>0。 */
export function compareVersions(a: string, b: string): number {
	const parse = (v: string): number[] =>
		v
			.trim()
			.replace(/^[^0-9]*/, "")
			.split(/[.+-]/)
			.slice(0, 3)
			.map((seg) => {
				const n = Number.parseInt(seg, 10);
				return Number.isFinite(n) ? n : 0;
			});
	const pa = parse(a);
	const pb = parse(b);
	for (let i = 0; i < 3; i++) {
		const d = (pa[i] ?? 0) - (pb[i] ?? 0);
		if (d !== 0) return d;
	}
	return 0;
}

/** Identify the executing pi CLI rather than this extension's dev dependency. */
export function detectRunningHostVersion(argv: readonly string[] = process.argv): string | null {
	try {
		if (!argv[1]) return null;
		const entry = fs.realpathSync(argv[1]);
		let dir = path.dirname(entry);
		for (let i = 0; i < 8; i++) {
			const pkgFile = path.join(dir, "package.json");
			if (fs.existsSync(pkgFile)) {
				const pkg = JSON.parse(fs.readFileSync(pkgFile, "utf8")) as { name?: unknown; version?: unknown; bin?: unknown };
				if (pkg.name !== "@earendil-works/pi-coding-agent") return null;
				const bin = typeof pkg.bin === "string" ? pkg.bin : (pkg.bin as { pi?: unknown } | undefined)?.pi;
				if (typeof bin !== "string" || fs.realpathSync(path.resolve(dir, bin)) !== entry) return null;
				return typeof pkg.version === "string" ? pkg.version : null;
			}
			const parent = path.dirname(dir); if (parent === dir) break; dir = parent;
		}
	} catch { /* journal: SDK/unrecognised launcher remains unknown, never infer from devDependencies. */ }
	return null;
}

/**
 * 解析当前运行所依赖的 @earendil-works/pi-coding-agent 包版本；失败返回 null（不猜测）。
 * 注：包 exports 未暴露 ./package.json 子路径，且仅定义 import 条件——jiti/CJS require 解析
 * 会报「No "exports" main defined」。故优先 import.meta.resolve（import 条件，jiti 下可用），
 * 从入口路径向上定位包根读 package.json；解析失败回退到从本模块位置向上找标准
 * node_modules 布局；两路均失败返回 null。
 */
export function detectHostPackageVersion(): string | null {
	const readRoot = (startDir: string): string | null => {
		let dir = startDir;
		for (let hops = 0; hops < 8; hops++) {
			const pkgPath = path.join(dir, "package.json");
			if (fs.existsSync(pkgPath)) {
				const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8")) as { name?: unknown; version?: unknown };
				if (pkg.name === "@earendil-works/pi-coding-agent") {
					return typeof pkg.version === "string" && pkg.version.length > 0 ? pkg.version : null;
				}
			}
			const parent = path.dirname(dir);
			if (parent === dir) break;
			dir = parent;
		}
		return null;
	};
	try {
		if (typeof import.meta.resolve === "function") {
			const entryUrl = import.meta.resolve("@earendil-works/pi-coding-agent");
			const v = readRoot(path.dirname(fileURLToPath(entryUrl)));
			if (v !== null) return v;
		}
	} catch {
		// 落到回退路径
	}
	try {
		let dir = path.dirname(fileURLToPath(import.meta.url));
		for (let hops = 0; hops < 8; hops++) {
			const cand = path.join(dir, "node_modules", "@earendil-works", "pi-coding-agent");
			if (fs.existsSync(path.join(cand, "package.json"))) {
				return readRoot(cand);
			}
			const parent = path.dirname(dir);
			if (parent === dir) break;
			dir = parent;
		}
	} catch {
		// 不可解析：诚实返回 null
	}
	return null;
}

/** 能力名是否在受测版本表内。 */
export function isKnownCapability(name: string): name is HostCapabilityName {
	return Object.prototype.hasOwnProperty.call(CAPABILITY_FACTS, name);
}

/** 按名取能力事实；未知能力名拒绝（抛错，不静默返回近似项）。 */
export function capabilityByName(name: string): CapabilityFact {
	if (!isKnownCapability(name)) {
		throw new Error(`[host-capabilities] 未知能力名: ${name}（受测能力集合见 CAPABILITY_FACTS）`);
	}
	return CAPABILITY_FACTS[name];
}

/**
 * 版本表判定：version >= since → true；只说明版本支持，不能证明当前载荷含字段。
 * 1.1.0 新字段是否消费由载荷值决定，不以本函数作存在性门。
 * version 为 null/空（版本未知）→ 一律 false（保守降级：版本判定型能力不凭空宣称）。
 * 未知能力名 → false（isKnownCapability 先行拒绝语义的保守投影）。
 */
export function capabilityEnabledByVersion(name: string, version: string | null | undefined): boolean {
	if (!isKnownCapability(name) || version === null || version === undefined || version === "") return false;
	return compareVersions(version, CAPABILITY_FACTS[name].since) >= 0;
}

/** 宿主能力快照（探测 + 版本判定合成结果）。 */
export interface HostCapabilities {
	/** 解析到的 pi-coding-agent 包版本（null = 解析失败，仅探测型能力可信）。 */
	readonly hostVersion: string | null;
	/** 各能力探测/版本支持说明（按 CAPABILITY_FACTS 键序；version-table 不证明当前载荷有字段）。 */
	readonly capabilities: Readonly<Record<HostCapabilityName, boolean>>;
	/** 每项能力的判定来源（probe=运行时探测命中 / version=版本表判定 / none=版本未知且未探测）。 */
	readonly basis: Readonly<Record<HostCapabilityName, "probe" | "version" | "none">>;
}

/**
 * 解析宿主能力快照。
 * @param pi 宿主 ExtensionAPI（运行时探测对象形状能力；传 null 跳过探测）
 * @param options.versionOverride 覆盖版本来源（测试注入 0.83.0 等旧版本串验证降级）
 */
export function resolveHostCapabilities(
	pi: RuntimeProbeSurface | null,
	options?: { versionOverride?: string | null },
): HostCapabilities {
	const hostVersion = options?.versionOverride !== undefined ? options.versionOverride : detectHostPackageVersion();
	const probe: Partial<Record<HostCapabilityName, boolean>> = {};
	if (pi !== null) {
		probe.setActiveTools =
			typeof pi.getActiveTools === "function" && typeof pi.setActiveTools === "function";
		probe.dynamicToolRegistration = typeof pi.registerTool === "function";
		probe.registerToolRenderer = typeof pi.registerToolRenderer === "function";
		// modelRegistry 在事件处理器 ctx 上而非 ExtensionAPI；消费方组装后传入，缺省视为不可探测。
		probe.modelRegistryGenerateImages =
			pi.modelRegistry !== undefined && typeof pi.modelRegistry.generateImages === "function";
	}
	const capabilities = {} as Record<HostCapabilityName, boolean>;
	const basis = {} as Record<HostCapabilityName, "probe" | "version" | "none">;
	for (const name of Object.keys(CAPABILITY_FACTS) as HostCapabilityName[]) {
		const fact = CAPABILITY_FACTS[name];
		if (fact.kind === "runtime-probe") {
			capabilities[name] = probe[name] === true;
			basis[name] = probe[name] === true ? "probe" : "none";
		} else {
			capabilities[name] = capabilityEnabledByVersion(name, hostVersion);
			basis[name] = capabilities[name] ? "version" : "none";
		}
	}
	return { hostVersion, capabilities, basis };
}

/** 快照的单行诊断摘要（日志/看板用；不展开 evidence 全文）。 */
export function summarizeHostCapabilities(caps: HostCapabilities): string {
	const on = (Object.keys(caps.capabilities) as HostCapabilityName[]).filter((n) => caps.capabilities[n]);
	const off = (Object.keys(caps.capabilities) as HostCapabilityName[]).filter((n) => !caps.capabilities[n]);
	return `[host-capabilities] host=${caps.hostVersion ?? "unknown"} on=[${on.join(",")}] off=[${off.join(",")}]`;
}

// ── pi 0.86.0 配合（ev-20260920）：同名替换内置工具的约束采样对齐 ────────────────
// 背景：pi 0.86.0 起内置 read/bash/edit/write 默认 constrainedSampling={json_schema, strict:"prefer"}
// （dist/core/tools/*.js 实证）；但本扩展的 bash/edit/write 同名替换工具是自持字面量（仅委托
// baseDef.execute），不会自动继承该默认——不显式对齐则与宿主内置行为分叉。
// 安全性：strict 变换把可选属性转 required+nullable（anyOf:[x,null]，pi-ai makeJsonSchemaNodeStrict），
// 模型可选位携带的 null 在校验层被 normalizeOptionalNulls 剥除（pi-ai dist/utils/validation.js 实证，
// validateToolArguments 首步），不会进入 execute——与四分面工具 H3 决策（prefer + deepStripNulls）同向。
// 逃生舱：AMAGI_BUILTIN_CONSTRAINED=0|false|off → false（某模型/供应商 strict 劣化时止血，不重启可
// 经 env 预设进程级关闭）；缺省对齐宿主默认 prefer。env-knobs.md 已登记。
/**
 * 同名替换内置工具（bash/edit/write override）的 constrainedSampling 取值。
 * 缺省对齐 pi 0.86.0 内置默认（json_schema strict prefer）；AMAGI_BUILTIN_CONSTRAINED 关闭集值返回 false。
 * 返回值直接作为 ToolDefinition.constrainedSampling；与 CAPABILITY_FACTS.constrainedSampling 受测口径一致。
 */
export function resolveBuiltinConstrainedSampling(): false | { type: "json_schema"; strict: "prefer" } {
	const flag = (process.env.AMAGI_BUILTIN_CONSTRAINED ?? "").trim().toLowerCase();
	if (flag === "0" || flag === "false" || flag === "off") return false;
	return { type: "json_schema", strict: "prefer" };
}

// ── W3-④（2026-09-18）：平台支持矩阵（win32 无真机 → 按代码门如实标注；纯数据，不参与能力判定） ────
// 背景：v2.2 W3-④ 要求「win32 无真机则 host-capabilities 标 not-supported 并公布支持矩阵」。
// 口径：平台门（源码显式 platform !== win32 分支）→ not-supported；代码层跨平台但无 win32 真机证据
// → untested（不冒充 supported）；darwin/linux 为当前真机（macOS 实测 + 既有套件）supported。
// 硬约定：本矩阵只读，不接入 resolveHostCapabilities/capabilityEnabledByVersion——能力判定逻辑零变化。
export type PlatformSupportStatus = "supported" | "not-supported" | "untested";

export interface PlatformFeatureSupport {
	/** 平台敏感能力名（amagi 自有能力，非宿主 API）。 */
	readonly feature: string;
	readonly darwin: PlatformSupportStatus;
	readonly linux: PlatformSupportStatus;
	readonly win32: PlatformSupportStatus;
	/** 依据（源码门/行为差异/实测来源）。 */
	readonly evidence: string;
	/** win32 下的实际降级行为（如与 darwin/linux 不同）。 */
	readonly win32Fallback?: string;
}

export const PLATFORM_SUPPORT_MATRIX: readonly PlatformFeatureSupport[] = [
	{
		feature: "posix-process-group-termination",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "task-run.ts taskProcessGroupEnabled() 仅 darwin/linux 返回真；自有进程组（detached，pgid=pid）→ kill(-pgid) SIGTERM → 3s → 身份复核 → SIGKILL；W3-② 真机验证（2026-09-18，darwin）",
		win32Fallback: "child 级 SIGTERM→SIGKILL（仅直接子进程，无组信号；孙进程不随组回收）",
	},
	{
		feature: "orphan-diagnostics-and-reap",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "orphan-reaper.ts defaultSnapshotEnvs 仅 darwin（ps axeww）/linux（/proc）；reapInvocationOrphans/diagnoseOrphans/reapDiagnosedOrphans 平台门返回空/显式说明；W3-⑥ 真机验证（2026-09-18，darwin，真实 ps 快照）",
		win32Fallback: "诊断输出「仅 darwin/linux 支持（当前平台跳过）」，不列不杀",
	},
	{
		feature: "descendant-process-audit",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "process-audit.ts ProcessAuditor.sample/auditAndClean 平台门（darwin/linux），win32 不审计不回收（best-effort 静默）",
		win32Fallback: "无审计（终态残留孙进程不披露不回收）",
	},
	{
		feature: "run-bg-group-cancel",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "run-bg.ts killGroup 以 process.kill(-pgid) 组级 SIGTERM→2s→SIGKILL；win32 无负 pid 组信号语义；W3-⑥ 真机验证（2026-09-18，darwin）",
		win32Fallback: "组信号失败回退单 pid（直接子进程）；detached 孙进程可能残留，且 win32 无 orphan-reaper 兜底",
	},
	{
		feature: "evidence-runner-group-kill",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "evidence.ts runCmd：POSIX detached+killPgrp(-pid)；win32 spawn 经 cmd.exe(shell:true)（npm 垫片）可行但 killPgrp 组信号失败回退单 pid",
		win32Fallback: "测试命令派生的 npm/make 子进程超时后不随组回收（仅杀 shell 进程）",
	},
	{
		feature: "browser-reaper",
		darwin: "supported",
		linux: "supported",
		win32: "not-supported",
		evidence: "browser-reaper.ts 平台门仅 darwin/linux（收尾扫描/回收浏览器残留）",
		win32Fallback: "不扫描不回收（无噪音）",
	},
	{
		feature: "task-dispatch-and-json-backend",
		darwin: "supported",
		linux: "supported",
		win32: "untested",
		evidence: "task-run/task-service/json-execution-adapter 无 platform 分支（spawn/stdio 跨平台）；但 win32 无真机运行记录（W3-④ 明确不臆测）",
		win32Fallback: "无真机证据；进程组终止/孤儿回收/审计能力降级见上四条",
	},
	{
		feature: "guards-and-write-override",
		darwin: "supported",
		linux: "supported",
		win32: "untested",
		evidence: "guards.ts powershell 语义（win32 或显式 powershell 工具）、git-discard-guard.ts /mnt/* WSL 路径归一、write-override win32 必注册——代码层有 win32 适配；tests/guards-powershell.test.mjs 有覆盖但非 win32 真机",
		win32Fallback: "无真机证据（按代码推定可用，不作同等承诺）",
	},
];
