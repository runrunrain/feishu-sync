/**
 * edit-diagnostics.ts — P1-D（插件进化8.19）：edit/write 成功写盘后的 LSP 推送式诊断注入。
 *
 * 设计依据（opencode push 式「diagnostics as feedback」+ 本仓 traces：12 次 lsp 调用全部来自
 * 重构角色——拉取甜区仅重构）：把「改完必须自己跑 lsp 查诊断」变成「写盘即反馈」。拉取工具
 * lsp-tool.ts 保留不动，本模块只做结果追加。
 *
 * 边界纪律（任务契约逐条落码）：
 *  - 决策先于 spawn：isEnabled（env）→ 检测缓存（detectLspServers 纯配置层：rootMarkers ∩ cwd
 *    直接条目 + 二进制可解析，不 spawn、不持进程）→ 扩展名路由，三层全过才允许触达 LspClientPool。
 *    无 LSP 项目在第二层即短路（检测为一次配置读取+目录扫描，此后实例内缓存命中），零 spawn 零等待。
 *  - 有界：仅命中已启用服务器的文件（files 多文件模式按序探测 ≤maxFiles 个、首个产出 error 即止）、
 *    仅 error 级（severity===1，缺省视 1，与 lsp-tool formatDiagnostics 口径一致）、≤maxEntries 条、
 *    单文件整体竞速 ≤timeoutMs（外层 race 兜住 initialize 慢启动，内层 waitForDiagnostics 同限；
 *    竞速超时后底层尝试自行按内层超时收口，客户端留在池内供后续编辑复用）。
 *  - 静默降级：任何失败（读文件/spawn 失败/熔断冷却/超时/传输错误/结果形态不符）原样返回原 result，
 *    绝不 throw、绝不阻断写入路径与结果返回；写盘发生在注入之前，注入只追加尾部文本段。
 *  - 复用 lsp-client 基础设施：同一 LspClientPool/LspClient 类 + 模块级启动熔断（跨池共享，spawn
 *    失败 60s 冷却内后续 attach 快速失败静默）；不新建并行 LSP 实现。
 *  - AMAGI_EDIT_DIAGNOSTICS=0|false 关闭（默认开）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { LspClientPool, type LspDiagnostic } from "./lsp-client.ts";
import { filterEnvironmentNoise } from "./lsp-diagnostics.ts";
import { detectLspServers, routeFileToServers, type LspConfigHooks } from "./lsp-config.ts";
import type { DetectedLspServer } from "./lsp-types.ts";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { resolveBuiltinFileTarget } from "./builtin-file-target.ts";

/** 结果事件只追加诊断，执行/权限/取消仍归原生工具管线。getter 在事件时选择当前 cwd。
 * Windows 路径重定向仍用执行点的实际路径注入；未宣称通用输入可还原其 UNC 目标。
 */
export function registerEditDiagnosticsObserver(
	pi: Pick<ExtensionAPI, "on">,
	diagnosticsFor: (cwd: string) => Pick<EditDiagnostics, "attach"> | undefined,
): void {
	pi.on("tool_result", async (event, ctx) => {
		if (event.isError || (event.toolName !== "edit" && event.toolName !== "write")) return;
		// 显式旧接线已有诊断时不再叠加；不会按 toolCallId 去重而漏掉真实重跑。
		if (event.content.some((item) => item.type === "text" && item.text.includes(EDIT_DIAG_SECTION_TAG))) return;
		try {
			const raw = event.input;
			const files = Array.isArray(raw.files) ? raw.files : [raw.path ?? raw.file_path];
			const targets = [...new Set(files.filter((v): v is string => typeof v === "string" && v !== "")
				.map((file) => resolveBuiltinFileTarget(file, ctx.cwd)))];
			if (!targets.length) return;
			const enriched = await diagnosticsFor(ctx.cwd)?.attach({ content: event.content }, targets) as { content?: typeof event.content } | undefined;
			if (enriched?.content && enriched.content !== event.content) {
				// content-only 覆写会令宿主丢弃 structuredContent，故显式透传原生结构载体。
				return { content: enriched.content, ...(event.structuredContent !== undefined ? { structuredContent: event.structuredContent } : {}) };
			}
		} catch { /* lint-exempt:观察失败不改变写入和原生结果 */ }
		return;
	});
}

/** 单文件诊断整体竞速上限（含 spawn/initialize/发布等待）；缺省 3s。 */
export const EDIT_DIAG_TIMEOUT_MS = 3_000;
/** 注入条目上限（仅 error 级）。 */
export const EDIT_DIAG_MAX_ENTRIES = 8;
/** files 多文件模式按序探测的文件数上限（首个产出 error 的文件即止）。 */
export const EDIT_DIAG_MAX_FILES = 2;
/** 单条消息截断长度（字符，空白折叠为单空格）。 */
export const EDIT_DIAG_MESSAGE_MAX_CHARS = 200;

/** 注入段标题（edit/write 结果尾部）。 */
export const EDIT_DIAG_SECTION_TAG = "[LSP 诊断]";

export interface EditDiagnosticsDeps {
	/** 工作目录（相对文件解析与检测基准）。 */
	cwd?: string;
	/** 冻结任务的 LSP 名单；未注入=沿用非任务默认，空名单禁止诊断启动。 */
	lsp?: readonly string[];
	/** 复用文件通道的 deny/跨根检查，诊断不能旁路读取被禁入的目标。 */
	canRead?: (absolutePath: string) => boolean;
	/** 环境变量（缺省 process.env；AMAGI_EDIT_DIAGNOSTICS=0|false 关闭）。 */
	env?: Record<string, string | undefined>;
	/** 注入共享池（index.ts 把 lsp 拉取工具与本注入器接同一池；缺省懒建）。 */
	pool?: LspClientPool;
	/** 注入检测（测试）；缺省 detectLspServers（纯配置层，不 spawn）。 */
	detect?: (cwd: string) => DetectedLspServer[];
	/** 透传给默认检测的配置钩子（测试隔离 amagi.json 路径/PATH）。 */
	detectHooks?: LspConfigHooks;
	/** 单文件整体竞速上限 ms；缺省 3000。 */
	timeoutMs?: number;
	/** 注入条目上限；缺省 8。 */
	maxEntries?: number;
	/** files 模式探测文件上限；缺省 2。 */
	maxFiles?: number;
	/** 单条消息截断长度；缺省 200。 */
	messageMaxChars?: number;
}

export interface EditDiagnostics {
	/** 开关判定（只读 env，不检测、不 spawn）。 */
	isEnabled(): boolean;
	/** 成功写盘后附加 `[LSP 诊断]` 段；任何失败静默返回原 result（绝不 throw、绝不改写既有内容）。 */
	attach(result: unknown, files: string[]): Promise<unknown>;
	/** 共享池访问（懒建、不 spawn——构造仅一个 unref 定时器；供 lsp 拉取工具接线同一池）。 */
	sharedPool(): LspClientPool;
	/** 关池（幂等；session_shutdown/agent_settled 清理）。 */
	close(): Promise<void>;
}

function positiveInt(value: number | undefined, fallback: number): number {
	return Number.isFinite(value) && Number(value) > 0 ? Math.floor(Number(value)) : fallback;
}

/** 整体竞速：ms 内未决出 → null（底层 promise 继续按自身超时收口，不泄漏未处理拒绝）。 */
function raceTimeout<T>(promise: Promise<T>, ms: number): Promise<T | null> {
	return new Promise((resolve) => {
		const timer = setTimeout(() => resolve(null), ms);
		timer.unref();
		promise.then(
			(value) => { clearTimeout(timer); resolve(value); },
			() => { clearTimeout(timer); resolve(null); },
		);
	});
}

/** `  L{line}:{character} ERROR {message}`（行/列 1 基；消息折叠空白并截断）。 */
function formatEntry(diag: LspDiagnostic, messageMaxChars: number): string {
	const line = (diag.range?.start?.line ?? 0) + 1;
	const character = (diag.range?.start?.character ?? 0) + 1;
	const message = String(diag.message ?? "").replace(/\s+/g, " ").trim().slice(0, messageMaxChars);
	const source = typeof diag.source === "string" && diag.source ? ` (${diag.source})` : "";
	return `  L${line}:${character} ERROR ${message}${source}`;
}

/**
 * 创建诊断注入器。attach 的三层门（env → 检测缓存 → 扩展名路由）全部在触达池之前完成；
 * 无 LSP 项目的 attach 开销 = 一次 env 读取 + 数组长度判断（检测已缓存）。
 */
export function createEditDiagnostics(deps: EditDiagnosticsDeps = {}): EditDiagnostics {
	const cwd = deps.cwd ?? process.cwd();
	const env = deps.env ?? (process.env as Record<string, string | undefined>);
	const timeoutMs = positiveInt(deps.timeoutMs, EDIT_DIAG_TIMEOUT_MS);
	const maxEntries = positiveInt(deps.maxEntries, EDIT_DIAG_MAX_ENTRIES);
	const maxFiles = positiveInt(deps.maxFiles, EDIT_DIAG_MAX_FILES);
	const messageMaxChars = positiveInt(deps.messageMaxChars, EDIT_DIAG_MESSAGE_MAX_CHARS);

	const isEnabled = (): boolean => {
		const value = env.AMAGI_EDIT_DIAGNOSTICS;
		return value !== "0" && value !== "false" && (deps.lsp === undefined || deps.lsp.includes("diagnostics"));
	};

	let detectedCache: DetectedLspServer[] | null = null;
	const detected = (): DetectedLspServer[] => {
		if (!detectedCache) {
			detectedCache = deps.detect ? deps.detect(cwd) : detectLspServers(cwd, undefined, deps.detectHooks);
		}
		return detectedCache;
	};

	let pool = deps.pool;
	const sharedPool = (): LspClientPool => {
		if (!pool) pool = new LspClientPool({ cwd });
		return pool;
	};

	/** 单文件 error 级诊断（读文件→池取客户端→文档同步→等发布→过滤）；内部异常一律空数组。 */
	const errorsForFile = async (abs: string, def: DetectedLspServer): Promise<LspDiagnostic[]> => {
		let text: string;
		try { text = fs.readFileSync(abs, "utf8"); } catch { return []; }
		// 池 spawn 用 def.command，故用已解析 commandPath 覆盖（与 lsp-tool spawnDef 同口径）
		const spawnDef: DetectedLspServer = { ...def, command: def.commandPath || def.command };
		const client = await sharedPool().getOrCreate(spawnDef);
		client.ensureOpenFile(abs, text);
		const diags = await client.waitForDiagnostics(abs, timeoutMs);
		// ev-20261007：环境噪音降噪（clangd 无编译数据库的 include 误报）——推送面静默
		//（同 ev-20260920-508e67 原则：噪声代价高于漏报；拉取面 lsp({action:"diagnostics"})
		// 同批诊断已过滤并披露原因，可显式查）。
		const { kept } = filterEnvironmentNoise(def.name, abs, diags);
		return kept.filter((d) => (d.severity ?? 1) === 1);
	};

	const attach = async (result: unknown, files: string[]): Promise<unknown> => {
		try {
			if (!isEnabled() || !Array.isArray(files) || files.length === 0) return result;
			const servers = detected();
			if (servers.length === 0) return result;
			let probed = 0;
			for (const raw of files) {
				if (typeof raw !== "string" || raw === "") continue;
				const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
				if (deps.canRead && !deps.canRead(abs)) continue;
				const routed = routeFileToServers(abs, servers);
				if (routed.length === 0) continue; // 扩展名未命中任何已启用服务器：零开销跳过
				// ev-20260920-508e67：JS 族文件仅当项目显式 checkJs 才推送——tsconfig 不含 JS 时
				// tsserver 按 inferred project 解析，node 内置模块全部误报（本仓 tests/*.mjs 实测
				// 51 条 error 纯噪声），推送面零信息量；拉取面（lsp tool 显式查询）不受影响。
				if (JS_FILE_RE.test(abs) && !jsCheckEnabled(abs)) continue;
				if (probed >= maxFiles) break;
				probed++;
				const errors = await raceTimeout(errorsForFile(abs, routed[0] as DetectedLspServer), timeoutMs);
				if (errors === null || errors.length === 0) continue; // 超时/失败/无 error：静默
				const rel = path.relative(cwd, abs) || abs;
				const shown = errors.slice(0, maxEntries);
				const more = errors.length > shown.length ? `，仅列前 ${shown.length} 条` : "";
				const header = `\n\n${EDIT_DIAG_SECTION_TAG} ${rel}：${errors.length} 条 error（编辑后即时检查，仅 error 级${more}；lsp({action:"diagnostics"}) 可查全量）`;
				return appendSection(result, `${header}\n${shown.map((d) => formatEntry(d, messageMaxChars)).join("\n")}`);
			}
			return result;
		} catch {
			return result; // 诊断注入绝不反噬工具主路径
		}
	};

	const close = async (): Promise<void> => {
		try { await pool?.closeAll(); } catch { /* 幂等清理 */ }
	};

	return { isEnabled, attach, sharedPool, close };
}

/** ev-20260920-508e67：JS 族扩展（推送式诊断的项目检查面判定入口）。 */
const JS_FILE_RE = /\.(?:[cm]?jsx?)$/i;

/** ev-20260920-508e67：JS 族文件的项目检查面——最近 tsconfig 显式开 checkJs 才推送诊断。
 *  无 tsconfig（或不可解析）保守判 false：宁漏推不误报（推送面噪声代价高于漏报——拉取面可随时显式查）。 */
function jsCheckEnabled(abs: string): boolean {
	let cur = path.dirname(abs);
	for (let i = 0; i < 4; i++) {
		const cfgPath = path.join(cur, "tsconfig.json");
		let raw: string;
		try { raw = fs.readFileSync(cfgPath, "utf8"); } catch {
			const parent = path.dirname(cur);
			if (parent === cur) return false;
			cur = parent;
			continue;
		}
		try {
			const parsed = JSON.parse(stripTsconfigComments(raw)) as { compilerOptions?: { checkJs?: unknown } };
			return parsed?.compilerOptions?.checkJs === true;
		} catch {
			return /"checkJs"\s*:\s*true/.test(raw); // 带注释/尾逗号解析失败的宽松回退
		}
	}
	return false;
}

/** 剥离 tsconfig 常见注释形态（// 与块注释；粗粒度够用——只解析 compilerOptions.checkJs）。 */
function stripTsconfigComments(raw: string): string {
	return raw.replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
}

/** 结果尾部追加文本段：浅克隆并仅替换 content[0].text，其余字段（details 等）原样保留；形态不符原样返回。 */
function appendSection(result: unknown, section: string): unknown {
	if (!result || typeof result !== "object") return result;
	const r = result as { content?: unknown };
	if (!Array.isArray(r.content) || r.content.length === 0) return result;
	const first = r.content[0] as { type?: unknown; text?: unknown };
	if (!first || typeof first !== "object" || typeof first.text !== "string") return result;
	const content = [...r.content];
	content[0] = { ...first, text: first.text + section };
	return { ...r, content };
}
