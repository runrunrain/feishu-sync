/**
 * rpc-extension-ui.ts — B7（十月迭代 §5.4）：RPC extension UI 子协议分发与 pending 表。
 *
 * 设计边界（设计方案 §5.4「活跃 RPC 对话框」）：
 * - 子进程 stdout extension_ui_request → 本模块验证 union → pending 表（DialogEnvelope）→
 *   受鉴权 WebUI → 校验 answer → 原 worker stdin 写一条 LF JSON（写入由 rpc-pool 执行，
 *   本模块不持有 worker 引用——超时/取消只 resolve(undefined)，由 pool 翻译成 cancelled）。
 * - 关联键 = workerKey + workerGeneration + sessionId + requestId（并发 worker 可有相同
 *   requestId；worker 重启后 key 必然不同——旧页面/迟到回答按 key 拒绝）。
 * - select 只接受列出的选项，confirm 只接受布尔/取消；input/editor 为有界文本。
 *   单回答 16 KiB、每 worker 最多 8 个 pending，超限立即取消相应对话并报可见错误。
 * - 超时语义：宿主 request.timeout 存在时尊重其截止；无 timeout 的远程对话本地有效期
 *   120 秒（DEFAULT_REMOTE_DIALOG_DEADLINE_MS）。超时 resolve(undefined)（pool 发送
 *   cancelled），不回默认同意。agent 侧超时自动兜底由宿主文档定义——客户端不追踪超时。
 * - 多客户端「首个有效回答占有」：state pending→sent 后，重复 submit 拒绝（stale/busy）。
 * - notify/setStatus/setWidget/setTitle/set_editor_text 为单向投影，不建 pending、不给 ack。
 *   widget 仅接 string[]；未知方法降级告警，不执行任意客户端代码。
 *
 * 纯逻辑零 IO：不 import rpc-pool（pool 单向依赖本模块，无环）；可独立单测。
 */

// ── 常量（设计 §5.4 冻结值） ────────────────────────────────────────────────

/** dialog 四方法（会发 extension_ui_response）。 */
export type RpcDialogMethod = "select" | "confirm" | "input" | "editor";
export const RPC_DIALOG_METHODS: ReadonlySet<string> = new Set(["select", "confirm", "input", "editor"]);

/** fire-and-forget 五方法（单向投影，无应答）。 */
export type RpcProjectionMethod = "notify" | "setStatus" | "setWidget" | "setTitle" | "set_editor_text";
export const RPC_PROJECTION_METHODS: ReadonlySet<string> = new Set([
	"notify", "setStatus", "setWidget", "setTitle", "set_editor_text",
]);

/** 每 worker pending 上限（超限立即取消新对话并报错——不排更长的队）。 */
export const MAX_PENDING_DIALOGS_PER_WORKER = 8;
/** 单回答字节上限（input/editor 文本；select 选项天然受 options 集合约束）。 */
export const MAX_DIALOG_ANSWER_BYTES = 16 * 1024;
/** 宿主无 timeout 时远程对话的本地有效期（设计 §5.4：最多 120 秒）。 */
export const DEFAULT_REMOTE_DIALOG_DEADLINE_MS = 120_000;
/** deadline 硬上限（与 rpc-pool boundedInt 上限一致：30 分钟）。 */
export const MAX_DIALOG_DEADLINE_MS = 30 * 60_000;
/** deadline 下限（防 0/负值立即过期）。 */
export const MIN_DIALOG_DEADLINE_MS = 10;

// ── 类型 ────────────────────────────────────────────────────────────────────

/** 类型化应答（WebUI/rpc_task answer → broker.submit）。与 rpc_task answer 的
 *  value/confirmed/cancelled 三语义一一对应（W2-R1 类型化答复契约），不引入第二套语义。 */
export type RpcDialogAnswer =
	| { kind: "value"; value: string }
	| { kind: "confirmed"; confirmed: boolean }
	| { kind: "cancelled" };

/** broker 应答等待面的 resolve 形态（与 rpc-pool RpcLeaderAnswer 的对象子集结构兼容：
 *  {value}/{confirmed}/{cancelled}；undefined=超时/取消——pool 翻译为 cancelled:true）。 */
export type RpcDialogResolvedAnswer = { value: string } | { confirmed: boolean } | { cancelled: true } | undefined;

/** 对话关联键（WebUI 应答必须携带完整四元组；worker 重启后任一分量变化即视为不同对话）。 */
export interface RpcDialogKey {
	workerKey: string;
	workerGeneration: number;
	sessionId: string;
	requestId: string;
}

/** 内部桥接协议（设计方案 §5.4 提议形态）：payload 字段为宿主 request union 的白名单投影。
 *  发回宿主时只发送 U 定义的 type/id/value|confirmed|cancelled——envelope 额外字段绝不
 *  塞入 pi 命令（由 rpc-pool.uiResponse 负责翻译）。 */
export interface RpcDialogEnvelope {
	version: 1;
	workerKey: string;
	workerGeneration: number;
	sessionId: string;
	requestId: string;
	method: RpcDialogMethod;
	taskId?: string;
	/** epoch ms：本地截止时刻（宿主 timeout ?? 120s 本地默认）。 */
	deadlineAt: number;
	state: "pending" | "sent" | "expired" | "cancelled";
	createdAt: number;
	/** 宿主 request 白名单字段（按方法携带）。 */
	title?: string;
	message?: string;
	placeholder?: string;
	options?: string[];
	/** 宿主原始 timeout（ms；缺席 = 无宿主截止，本地默认生效）。 */
	hostTimeoutMs?: number;
}

/** fire-and-forget 投影事件（notify/setStatus/setWidget/setTitle/set_editor_text）。 */
export interface RpcDialogProjectionEvent {
	kind: "projection";
	workerKey: string;
	workerGeneration: number;
	sessionId: string;
	taskId?: string;
	method: RpcProjectionMethod;
	/** 白名单字段的浅拷贝（widget 仅 string[]）。 */
	payload: Record<string, unknown>;
	at: number;
}

/** broker 变更事件（pending 表生命周期 + 投影 + 未知方法告警）。 */
export type RpcDialogBrokerEvent =
	| { kind: "registered"; envelope: RpcDialogEnvelope }
	| { kind: "answered"; envelope: RpcDialogEnvelope; answer: RpcDialogAnswer }
	| { kind: "expired"; envelope: RpcDialogEnvelope }
	| { kind: "cancelled"; envelope: RpcDialogEnvelope; reason: string }
	| { kind: "rejected"; envelope: RpcDialogEnvelope; reason: string }
	| RpcDialogProjectionEvent
	| { kind: "unknown-method"; workerKey: string; method: string; at: number };

export interface RpcDialogSubmitResult {
	ok: boolean;
	code: "delivered" | "not-found" | "stale" | "invalid-answer";
	message?: string;
}

export interface RpcDialogAskInput {
	workerKey: string;
	workerGeneration: number;
	sessionId: string;
	requestId: string;
	method: RpcDialogMethod;
	taskId?: string;
	title?: string;
	message?: string;
	placeholder?: string;
	options?: string[];
	/** 宿主 timeout（正数毫秒）；缺席 = 无宿主截止（本地 120s 默认生效）。 */
	timeoutMs?: number;
	/** pool 侧取消信号（worker close / cancelTask / shutdown）。 */
	signal?: AbortSignal;
}

export interface RpcDialogAskOk {
	ok: true;
	envelope: RpcDialogEnvelope;
	/** 应答 Promise：submit 成功 resolve(answer)；超时/取消 resolve(undefined)。
	 *  pool 将 undefined 翻译为 cancelled:true 发送 worker stdin。 */
	answer: Promise<RpcDialogResolvedAnswer>;
}

export interface RpcDialogAskReject {
	ok: false;
	code: "invalid-request" | "worker-limit";
	message: string;
}

// ── 校验（纯函数） ──────────────────────────────────────────────────────────

/** 宿主 request union 白名单校验（dialog 四方法的字段形状）。
 *  非 dialog 方法返回 undefined（调用方分流到投影/未知方法路径）。 */
export function parseDialogRequest(request: { id?: unknown; method?: unknown; title?: unknown; message?: unknown; placeholder?: unknown; options?: unknown; timeout?: unknown }): RpcDialogAskInput | { error: string } | undefined {
	const method = typeof request.method === "string" ? request.method : "";
	if (!RPC_DIALOG_METHODS.has(method)) return undefined; // 非 dialog：调用方分流
	if (typeof request.id !== "string" || request.id === "") return { error: "id must be a non-empty string" };
	const title = typeof request.title === "string" ? request.title : undefined;
	if (title === undefined) return { error: "title must be a string" };
	const input: RpcDialogAskInput = {
		workerKey: "", workerGeneration: 0, sessionId: "",
		requestId: request.id,
		method: method as RpcDialogMethod,
		title,
	};
	if (request.message !== undefined) {
		if (typeof request.message !== "string") return { error: "message must be a string" };
		input.message = request.message;
	}
	if (request.placeholder !== undefined) {
		if (typeof request.placeholder !== "string") return { error: "placeholder must be a string" };
		input.placeholder = request.placeholder;
	}
	if (request.options !== undefined) {
		if (!Array.isArray(request.options) || !request.options.every((o) => typeof o === "string")) {
			return { error: "options must be a string[]" };
		}
		if (method === "select" && request.options.length === 0) return { error: "select requires non-empty options" };
		input.options = request.options as string[];
	}
	if (method === "select" && input.options === undefined) return { error: "select requires options" };
	if (request.timeout !== undefined) {
		if (typeof request.timeout !== "number" || !Number.isFinite(request.timeout) || request.timeout <= 0) {
			return { error: "timeout must be a positive finite number" };
		}
		input.timeoutMs = request.timeout;
	}
	return input;
}

/** 按方法校验应答（select∈options、confirm 布尔、input/editor 有界文本；cancelled 通用）。 */
export function validateDialogAnswer(method: RpcDialogMethod, options: ReadonlyArray<string> | undefined, answer: RpcDialogAnswer): { ok: true } | { ok: false; message: string } {
	if (answer.kind === "cancelled") return { ok: true };
	if (answer.kind === "confirmed") {
		if (method !== "confirm") return { ok: false, message: `confirmed 只适用于 confirm 对话（当前 ${method}）` };
		return { ok: true };
	}
	// value
	if (method === "confirm") return { ok: false, message: "confirm 对话不接受 value 应答（用 confirmed 布尔或 cancelled）" };
	if (method === "select") {
		if (!options || !options.includes(answer.value)) {
			return { ok: false, message: `select 应答必须是列出选项之一（收到 ${JSON.stringify(answer.value.slice(0, 40))}）` };
		}
		return { ok: true };
	}
	if (Buffer.byteLength(answer.value, "utf8") > MAX_DIALOG_ANSWER_BYTES) {
		return { ok: false, message: `input/editor 应答超过 ${MAX_DIALOG_ANSWER_BYTES} 字节上限` };
	}
	return { ok: true };
}

/** deadline 推导：宿主 timeout ?? 120s 本地默认，夹在 [10ms, 30min]。 */
export function dialogDeadlineOf(timeoutMs: number | undefined, now: number): number {
	const base = typeof timeoutMs === "number" && Number.isFinite(timeoutMs) && timeoutMs > 0
		? timeoutMs
		: DEFAULT_REMOTE_DIALOG_DEADLINE_MS;
	const clamped = Math.max(MIN_DIALOG_DEADLINE_MS, Math.min(MAX_DIALOG_DEADLINE_MS, Math.floor(base)));
	return now + clamped;
}

function keyOf(key: RpcDialogKey): string {
	return `${key.workerKey}\n${key.workerGeneration}\n${key.sessionId}\n${key.requestId}`;
}

interface DialogEntry {
	envelope: RpcDialogEnvelope;
	options?: string[];
	resolveAnswer: (answer: RpcDialogResolvedAnswer) => void;
	timer: ReturnType<typeof setTimeout>;
	signal?: AbortSignal;
	onAbort?: () => void;
}

// ── Broker ──────────────────────────────────────────────────────────────────

/**
 * RPC 对话框 pending 表：ask（pool 调用）建表并挂本地 deadline；submit（WebUI/rpc_task
 * answer）校验+首个占有；cancelByWorker/cancelDangerous/shutdown 收口；project 承载
 * fire-and-forget 单向投影。监听者（WebUI adapter 经 index 装配订阅）拿全部生命周期事件。
 */
export class RpcDialogBroker {
	#pending = new Map<string, DialogEntry>();
	#perWorker = new Map<string, number>();
	#listeners = new Set<(event: RpcDialogBrokerEvent) => void>();
	#closed = false;

	get size(): number { return this.#pending.size; }
	get closed(): boolean { return this.#closed; }

	/** 当前 pending 快照（wire 投影：浅拷贝 envelope）。 */
	list(): RpcDialogEnvelope[] {
		return [...this.#pending.values()].map((entry) => ({ ...entry.envelope }));
	}

	subscribe(listener: (event: RpcDialogBrokerEvent) => void): () => void {
		this.#listeners.add(listener);
		return () => this.#listeners.delete(listener);
	}

	#emit(event: RpcDialogBrokerEvent): void {
		for (const listener of this.#listeners) {
			try { listener(event); } catch { /* lint-exempt:单监听者故障不影响 broker（与 events.EventStream 同语义） */ }
		}
	}

	/** pool 调用：dialog 请求进入 pending 表（关联键由 pool 补全）。返回应答等待面。 */
	ask(input: RpcDialogAskInput): RpcDialogAskOk | RpcDialogAskReject {
		if (this.#closed) return { ok: false, code: "invalid-request", message: "broker 已关闭" };
		const parsed = parseDialogRequest({
			id: input.requestId, method: input.method, title: input.title, message: input.message,
			placeholder: input.placeholder, options: input.options, timeout: input.timeoutMs,
		});
		if (!parsed || "error" in parsed) {
			return { ok: false, code: "invalid-request", message: parsed && "error" in parsed ? parsed.error : "非 dialog 方法" };
		}
		const count = this.#perWorker.get(input.workerKey) ?? 0;
		if (count >= MAX_PENDING_DIALOGS_PER_WORKER) {
			return { ok: false, code: "worker-limit", message: `worker ${input.workerKey.slice(0, 8)} pending 对话已达上限 ${MAX_PENDING_DIALOGS_PER_WORKER}，立即取消本对话` };
		}
		const now = Date.now();
		const deadlineAt = dialogDeadlineOf(input.timeoutMs, now);
		const envelope: RpcDialogEnvelope = {
			version: 1,
			workerKey: input.workerKey,
			workerGeneration: input.workerGeneration,
			sessionId: input.sessionId,
			requestId: input.requestId,
			method: input.method,
			...(input.taskId !== undefined ? { taskId: input.taskId } : {}),
			deadlineAt,
			state: "pending",
			createdAt: now,
			...(input.title !== undefined ? { title: input.title } : {}),
			...(input.message !== undefined ? { message: input.message } : {}),
			...(input.placeholder !== undefined ? { placeholder: input.placeholder } : {}),
			...(input.options !== undefined ? { options: [...input.options] } : {}),
			...(input.timeoutMs !== undefined ? { hostTimeoutMs: input.timeoutMs } : {}),
		};
		const key = keyOf(envelope);
		if (this.#pending.has(key)) {
			return { ok: false, code: "invalid-request", message: `重复对话键（worker/session/request 未收口即重发）：${input.requestId}` };
		}
		let resolveAnswer!: (answer: RpcDialogResolvedAnswer) => void;
		const answer = new Promise<RpcDialogResolvedAnswer>((resolve) => { resolveAnswer = resolve; });
		const entry: DialogEntry = {
			envelope, options: input.options, resolveAnswer,
			timer: setTimeout(() => this.#expire(key), Math.max(0, deadlineAt - Date.now())),
			signal: input.signal,
		};
		entry.timer.unref?.();
		if (input.signal) {
			entry.onAbort = () => this.#cancel(key, "aborted");
			if (input.signal.aborted) entry.onAbort();
			else input.signal.addEventListener("abort", entry.onAbort, { once: true });
		}
		this.#pending.set(key, entry);
		this.#perWorker.set(input.workerKey, count + 1);
		this.#emit({ kind: "registered", envelope: { ...envelope } });
		return { ok: true, envelope, answer };
	}

	/** WebUI / rpc_task answer：完整关联键应答（首个有效回答占有；迟到/重复拒绝）。 */
	submit(key: RpcDialogKey, answer: RpcDialogAnswer): RpcDialogSubmitResult {
		const id = keyOf(key);
		const entry = this.#pending.get(id);
		if (!entry) return { ok: false, code: "not-found", message: "对话不存在（未发起/已收口/键不匹配——worker 重启后旧键立即失效）" };
		const validated = validateDialogAnswer(entry.envelope.method, entry.options, answer);
		if (!validated.ok) return { ok: false, code: "invalid-answer", message: validated.message };
		this.#finish(id, entry, "sent");
		entry.resolveAnswer(answer.kind === "cancelled" ? { cancelled: true } : answer.kind === "confirmed" ? { confirmed: answer.confirmed } : { value: answer.value });
		this.#emit({ kind: "answered", envelope: { ...entry.envelope }, answer });
		return { ok: true, code: "delivered" };
	}

	/** rpc_task answer 兼容路径：仅 requestId 匹配（唯一命中才送达；多义拒绝要求完整键）。 */
	submitByRequestId(requestId: string, answer: RpcDialogAnswer): RpcDialogSubmitResult {
		const hits = [...this.#pending.values()].filter((entry) => entry.envelope.requestId === requestId);
		if (hits.length === 0) return { ok: false, code: "not-found", message: `requestId 未命中任何 pending 对话：${requestId}` };
		if (hits.length > 1) return { ok: false, code: "stale", message: `requestId ${requestId} 命中 ${hits.length} 个并发对话（多 worker 同 ID）——用完整关联键应答` };
		return this.submit(hits[0].envelope, answer);
	}

	/** worker 退出/更换：该 worker 全部 pending 失效（resolve undefined → pool 不再写 stdin）。 */
	cancelByWorker(workerKey: string, reason = "worker-exit"): number {
		let n = 0;
		for (const [id, entry] of [...this.#pending.entries()]) {
			if (entry.envelope.workerKey !== workerKey) continue;
			this.#cancel(id, reason);
			n++;
		}
		return n;
	}

	/** 危险确认收口（设计 §5.4：断开最后一个有应答权限客户端时立即取消危险确认）。
	 *  宿主请求没有可信的危险等级字段——confirm/select 默认按危险确认处理，不能按标题
	 *  关键词推断可自动同意。input/editor 留到本地 deadline。 */
	cancelDangerous(reason: string): number {
		let n = 0;
		for (const [id, entry] of [...this.#pending.entries()]) {
			if (entry.envelope.method !== "confirm" && entry.envelope.method !== "select") continue;
			this.#cancel(id, reason);
			n++;
		}
		return n;
	}

	/** fire-and-forget 投影：notify/setStatus/setWidget/setTitle/set_editor_text。
	 *  widget 仅接 string[]（非法形状丢弃并告警）；未知方法降级告警，不执行。 */
	project(worker: { key: string; generation: number; sessionId: string; taskId?: string }, request: { method?: unknown; [k: string]: unknown }): void {
		const method = typeof request.method === "string" ? request.method : "";
		if (!RPC_PROJECTION_METHODS.has(method)) {
			this.#emit({ kind: "unknown-method", workerKey: worker.key, method, at: Date.now() });
			return;
		}
		const payload: Record<string, unknown> = {};
		// 字符串字段白名单（宿主 rpc union 定义：notify.message/notifyType、setStatus.statusKey/statusText、
		// setWidget.widgetKey/widgetLines/widgetPlacement、setTitle.title、set_editor_text.text）。
		for (const field of ["message", "notifyType", "statusKey", "statusText", "widgetKey", "widgetPlacement", "title", "text"]) {
			const value = request[field];
			if (typeof value === "string") payload[field] = value;
		}
		// 清除语义（union 定义：statusText/widgetLines 省略 = 清除）→ 显式 null 投影（JSON 不丢信号）；
		// widgetLines 仅接 string[]（非法形状丢弃并告警，不执行任意客户端代码）。
		if (method === "setStatus" && request.statusText === undefined && request.statusKey !== undefined) payload.statusText = null;
		const lines = request.widgetLines;
		if (method === "setWidget") {
			if (lines === undefined) {
				if (request.widgetKey !== undefined) payload.widgetLines = null;
			} else if (Array.isArray(lines) && lines.every((v) => typeof v === "string")) {
				payload.widgetLines = [...lines as string[]];
			} else {
				// 非法形状：丢弃整个投影并告警（widgetKey 失去内容配合无意义，不发半空事件）。
				this.#emit({ kind: "unknown-method", workerKey: worker.key, method: `setWidget(invalid widgetLines)`, at: Date.now() });
				return;
			}
		}
		const event: RpcDialogProjectionEvent = {
			kind: "projection",
			workerKey: worker.key,
			workerGeneration: worker.generation,
			sessionId: worker.sessionId,
			...(worker.taskId !== undefined ? { taskId: worker.taskId } : {}),
			method: method as RpcProjectionMethod,
			payload,
			at: Date.now(),
		};
		this.#emit(event);
	}

	/** 关闭：全部 pending 取消 + 清理（resolve undefined——pool 端翻译为不再发送）。 */
	shutdown(reason = "broker-shutdown"): void {
		if (this.#closed) return;
		this.#closed = true;
		for (const [id, entry] of [...this.#pending.entries()]) this.#cancel(id, reason);
		this.#pending.clear();
		this.#perWorker.clear();
	}

	#expire(key: string): void {
		const entry = this.#pending.get(key);
		if (!entry) return;
		this.#finish(key, entry, "expired");
		entry.resolveAnswer(undefined);
		this.#emit({ kind: "expired", envelope: { ...entry.envelope } });
	}

	#cancel(key: string, reason: string): void {
		const entry = this.#pending.get(key);
		if (!entry) return;
		this.#finish(key, entry, "cancelled");
		entry.resolveAnswer(undefined);
		this.#emit({ kind: "cancelled", envelope: { ...entry.envelope }, reason });
	}

	#finish(key: string, entry: DialogEntry, state: RpcDialogEnvelope["state"]): void {
		clearTimeout(entry.timer);
		if (entry.signal && entry.onAbort) entry.signal.removeEventListener("abort", entry.onAbort);
		this.#pending.delete(key);
		const count = (this.#perWorker.get(entry.envelope.workerKey) ?? 1) - 1;
		if (count <= 0) this.#perWorker.delete(entry.envelope.workerKey);
		else this.#perWorker.set(entry.envelope.workerKey, count);
		entry.envelope.state = state;
	}
}
