/**
 * lsp-config.ts — amagi.json `lsp` 段读取/合并 + 按项目语言的动态服务器检测（A1）。
 *
 * 检测模型对齐 oh-my-pi（docs/lsp-config.md）：rootMarkers 与 cwd 直接条目交集（不向上递归、
 * 单层通配）∩ 二进制可解析（项目本地 bin 优先于 PATH）。不同点：配置并入 amagi.json 既有
 * 全局+项目合并体系（项目键优先，servers 逐 key 浅合并），不引入独立 lsp.json。
 *
 * 纯配置层：不 spawn、不持有进程；测试可注入配置路径/环境/二进制解析器。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { LspRuntimeConfig, LspServerDefinition, LspServerOverride, DetectedLspServer } from "./lsp-types.ts";
import { DEFAULT_LSP_CONFIG } from "./lsp-types.ts";

/** defaults.json 为构建期静态资源，jiti 下 import assert 不可靠，运行时读取 + 容错。 */
function loadDefaults(): Record<string, LspServerDefinition> {
	try {
		const raw = JSON.parse(fs.readFileSync(new URL("./lsp-defaults.json", import.meta.url), "utf8"));
		const out: Record<string, LspServerDefinition> = {};
		for (const [key, entry] of Object.entries(raw as Record<string, Record<string, unknown>>)) {
			if (!entry || typeof entry !== "object" || typeof entry.command !== "string") continue;
			out[key] = { ...(entry as Partial<LspServerDefinition>), name: key, command: entry.command };
		}
		return out;
	} catch {
		return {};
	}
}

export interface LspConfigHooks {
	/** 覆盖全局 amagi.json 路径（缺省 <PI_CODING_AGENT_DIR||~/.pi/agent>/amagi.json）。 */
	globalConfigFile?: string;
	/** 覆盖项目 amagi.json 路径（缺省 <cwd>/amagi.json）。 */
	projectConfigFile?: string;
	/** 覆盖环境变量（PATH / PI_CODING_AGENT_DIR）；缺省 process.env。 */
	env?: Record<string, string | undefined>;
	/** 覆盖二进制解析（测试注入点）；返回绝对路径或 null。 */
	resolveBinary?: (command: string, cwd: string, pathDirs: string[]) => string | null;
}

function readFileJson(file: string): Record<string, unknown> {
	try {
		const raw = JSON.parse(fs.readFileSync(file, "utf8"));
		return raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
	} catch {
		return {}; // 缺失/损坏一律静默回退（与 ui-config 同策略）
	}
}

function agentDir(env: Record<string, string | undefined>): string {
	return env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

/** amagi.json `lsp` 段（全局 + 项目合并，项目键优先；servers 逐 key 浅合并）。 */
export function resolveLspRuntimeConfig(cwd: string, hooks: LspConfigHooks = {}): LspRuntimeConfig {
	const env = hooks.env ?? process.env as Record<string, string | undefined>;
	const globalFile = hooks.globalConfigFile ?? path.join(agentDir(env), "amagi.json");
	const projectFile = hooks.projectConfigFile ?? path.join(cwd, "amagi.json");
	const merged: LspRuntimeConfig = { ...DEFAULT_LSP_CONFIG, servers: {} };

	for (const file of [globalFile, projectFile]) {
		const lsp = readFileJson(file).lsp;
		if (!lsp || typeof lsp !== "object") continue;
		const l = lsp as Record<string, unknown>;
		if (typeof l.enabled === "boolean") merged.enabled = l.enabled;
		if (typeof l.autoDetect === "boolean") merged.autoDetect = l.autoDetect;
		if (typeof l.readOnly === "boolean") merged.readOnly = l.readOnly;
		if (typeof l.idleTimeoutMs === "number" && Number.isFinite(l.idleTimeoutMs) && l.idleTimeoutMs > 0) merged.idleTimeoutMs = l.idleTimeoutMs;
		if (l.servers && typeof l.servers === "object") {
			for (const [name, ov] of Object.entries(l.servers as Record<string, unknown>)) {
				if (!ov || typeof ov !== "object") continue;
				merged.servers[name] = { ...(merged.servers[name] ?? {}), ...(ov as LspServerOverride) };
			}
		}
	}
	return merged;
}

/** cwd 本地 bin 目录（优先级序）：npm venv go ruby 等项目级安装位。 */
export function localBinDirs(cwd: string): string[] {
	return [
		path.join(cwd, "node_modules", ".bin"),
		path.join(cwd, ".venv", "bin"),
		path.join(cwd, "venv", "bin"),
		path.join(cwd, "bin"),
	];
}

/** ev-20260919（LSP 开箱即用）：扩展自带 bin 目录——amagi-pi 依赖声明的 LSP server（typescript-language-server
 *  等）随扩展安装，目标项目无需自装。lsp-config.ts 位于 extensions/amagi-core/ → 扩展根 = ../../。 */
export function extensionOwnBinDirs(): string[] {
	try {
		// fileURLToPath 标准转换（new URL(".").pathname 带尾斜杠，path.dirname 会再剥一层——实测踩坑）。
		const here = path.dirname(fileURLToPath(import.meta.url)); // .../extensions/amagi-core
		return [path.resolve(here, "..", "..", "node_modules", ".bin")];
	} catch {
		return [];
	}
}

function defaultResolveBinary(command: string, cwd: string, pathDirs: string[]): string | null {
	// 含路径分隔符：直接可执行判定，不做搜索（绝对路径或 ./ 相对）
	if (command.includes("/")) {
		const abs = path.isAbsolute(command) ? command : path.resolve(cwd, command);
		return isExecutableFile(abs) ? abs : null;
	}
	for (const dir of [...localBinDirs(cwd), ...pathDirs, ...extensionOwnBinDirs()]) {
		const candidate = path.join(dir, command);
		if (isExecutableFile(candidate)) return candidate;
	}
	return null;
}

function isExecutableFile(file: string): boolean {
	try {
		fs.accessSync(file, fs.constants.X_OK);
		return fs.statSync(file).isFile();
	} catch {
		return false;
	}
}

function wildcardMatch(pattern: string, name: string): boolean {
	// 单层 * 通配（oh-my-pi 语义：不跨 /，直接条目名匹配）
	const re = new RegExp("^" + pattern.split("*").map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$");
	return re.test(name);
}

/** rootMarkers 与 cwd 直接条目交集（含 * 通配；不递归子目录）。 */
/** rootMarkers 探测（ev-20260919 升级为三级探测）：
 *  ① cwd 根目录直接条目（原语义，不变）；
 *  ② 一级子目录一层（嵌套工作区：battle-sim 根无标记而 battle-simulator/ 有 package.json ——
 *     与嵌套项目根提示同深度，不递归深入）；
 *  ③ 向上逐级至 .git 边界（含 .git 所在层，层深上限 8 防逃逸）——monorepo 派发 cwd=子包时
 *     标记在项目根的常规布局。
 *  任一层命中即启用；解决「标记不在 cwd 根」场景 LSP 零检测（「LSP 服务不可用」误报源）。 */
export function rootMarkerHit(cwd: string, markers: string[] | undefined): boolean {
	if (!markers || markers.length === 0) return false;
	const hit = (dir: string): boolean => {
		let entries: string[];
		try {
			entries = fs.readdirSync(dir);
		} catch {
			return false;
		}
		return markers.some((m) => entries.some((e) => (m.includes("*") ? wildcardMatch(m, e) : e === m)));
	};
	const base = path.resolve(cwd);
	if (hit(base)) return true;
	try {
		for (const ent of fs.readdirSync(base, { withFileTypes: true })) {
			if (ent.isDirectory() && hit(path.join(base, ent.name))) return true;
		}
	} catch { /* 目录不可读：向下探测无果，继续向上 */ }
	let cur = base;
	for (let i = 0; i < 8; i++) {
		if (hit(cur)) return true;
		if (fs.existsSync(path.join(cur, ".git"))) break; // 仓库边界层已探测即停（不跨仓向上）
		const parent = path.dirname(cur);
		if (parent === cur) break; // 文件系统根
		cur = parent;
	}
	return false;
}

/**
 * 动态检测启用服务器：enabled && autoDetect 时，默认目录 + 显式覆盖合成条目中，
 * rootMarkers 命中且二进制可解析者启用；disabled 剔除。
 */
export function detectLspServers(cwd: string, config?: LspRuntimeConfig, hooks: LspConfigHooks = {}): DetectedLspServer[] {
	const cfg = config ?? resolveLspRuntimeConfig(cwd, hooks);
	if (!cfg.enabled) return [];
	// v1.5.220 审核修复（Minor-2）+快审 Minor-3：autoDetect 只门控内置候选集；
	// 合成基始终用全量内置目录——显式覆盖内置服务器（如只改 args）在 autoDetect=false 下仍完整可检测。
	const defaultsAll = loadDefaults();
	const defaults = cfg.autoDetect ? defaultsAll : {};
	const resolveBinary = hooks.resolveBinary ?? defaultResolveBinary;
	const env = hooks.env ?? process.env as Record<string, string | undefined>;
	const pathDirs = (env.PATH ?? "").split(path.delimiter).filter(Boolean);

	const effective: Record<string, { def: LspServerDefinition; fromOverrideOnly: boolean }> = {};
	for (const [name, def] of Object.entries(defaults)) effective[name] = { def, fromOverrideOnly: false };
	for (const [name, ov] of Object.entries(cfg.servers)) {
		effective[name] = {
			def: { ...(defaultsAll[name] ?? { name, command: "" }), ...ov, name },
			fromOverrideOnly: !defaults[name],
		};
	}

	const detected: DetectedLspServer[] = [];
	for (const { def } of Object.values(effective)) {
		if (def.disabled) continue;
		if (!def.command) continue;
		if (!def.rootMarkers || def.rootMarkers.length === 0) continue; // 显式条目也要求 rootMarkers（无标记无检测）
		if (!rootMarkerHit(cwd, def.rootMarkers)) continue;
		const commandPath = resolveBinary(def.command, cwd, pathDirs);
		if (!commandPath) continue;
		detected.push({ ...def, commandPath });
	}
	detected.sort((a, b) => a.name.localeCompare(b.name));
	return detected;
}

/** 按扩展名把文件路由到服务器列表（点前缀统一、大小写不敏感）。 */
export function routeFileToServers(file: string, servers: LspServerDefinition[]): LspServerDefinition[] {
	const ext = path.extname(file).toLowerCase();
	if (!ext) return [];
	return servers.filter((s) =>
		(s.fileTypes ?? []).some((ftRaw) => {
			const ft = ftRaw.toLowerCase();
			return ft === ext || ft === ext.slice(1) || `.${ft}` === ext;
		}),
	);
}

/** 暴露给测试/诊断：内置目录副本。 */
export function builtinServerNames(): string[] {
	return Object.keys(loadDefaults()).sort();
}

/** 2026-08-16 复盘 P3-7：内置服务器完整定义（doctor 指引用——status 需要知道「语言命中但二进制未装」的候选）。 */
export function builtinServerDefs(): Record<string, LspServerDefinition> {
	return { ...loadDefaults() };
}

/** 二进制可解析性检查（与 detectLspServers 同语义：本地 bin ∪ PATH；供 lsp-tool doctor 指引）。 */
export function binaryResolvable(command: string, cwd: string): boolean {
	const pathDirs = (process.env.PATH ?? "").split(path.delimiter).filter(Boolean);
	return defaultResolveBinary(command, cwd, pathDirs) !== null;
}
