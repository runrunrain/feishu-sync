/**
 * win-exec-mnt.ts — WSL automount 根发现（m5）。
 *
 * 根因：WSL 的 Windows 盘符挂载根可经 /etc/wsl.conf [automount] root 自定义（默认 /mnt）——
 * 全部硬编码 /mnt 的路径校验在自定义根的机器上整体失效（放行判定、cwd 校验、/mnt 探测）。
 * 本模块单一来源读取实际根：优先 /etc/wsl.conf [automount] root，解析失败回退 /mnt；结果缓存
 * （doctor 展示实际值）；reader 可注入测试。
 */

import * as fs from "node:fs";

export const DEFAULT_WSL_MNT_ROOT = "/mnt";

let cachedRoot: { at: number; value: string } | undefined;
const CACHE_MS = 60_000;

/** 解析 [automount] root（纯函数：ini 段内 root= 行；值剥引号与尾斜杠；空/非法 → 缺省 /mnt）。 */
export function parseAutomountRoot(confText: string): string {
	const lines = String(confText ?? "").split(/\r?\n/);
	let inAutomount = false;
	for (const line of lines) {
		const trimmed = line.trim();
		if (trimmed.startsWith("#") || trimmed === "") continue;
		const section = /^\[(.+)\]$/.exec(trimmed);
		if (section) { inAutomount = section[1]!.trim().toLowerCase() === "automount"; continue; }
		if (!inAutomount) continue;
		const kv = /^root\s*=\s*(.*)$/.exec(trimmed);
		if (!kv) continue;
		let v = kv[1]!.trim().replace(/^["']|["']$/g, "").replace(/\/+$/, "");
		if (v === "") return DEFAULT_WSL_MNT_ROOT;
		// 相对根/裸盘符无意义（Windows 挂载点必须是绝对目录）；保持原样仅要求以 / 开头
		if (!v.startsWith("/")) return DEFAULT_WSL_MNT_ROOT;
		return v;
	}
	return DEFAULT_WSL_MNT_ROOT;
}

/** 读取实际 automount 根（缓存 60s；readFile 可注入测试；任何失败回退 /mnt）。 */
export function wslMntRoot(readFile: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc), now = Date.now()): string {
	if (cachedRoot && now - cachedRoot.at < CACHE_MS) return cachedRoot.value;
	let value = DEFAULT_WSL_MNT_ROOT;
	try { value = parseAutomountRoot(readFile("/etc/wsl.conf", "utf8")); } catch { /* lint-exempt:wsl.conf 读取失败 → 回退缺省 /mnt */ value = DEFAULT_WSL_MNT_ROOT; }
	cachedRoot = { at: now, value };
	return value;
}

export function resetWslMntRootCache(): void { cachedRoot = undefined; }
