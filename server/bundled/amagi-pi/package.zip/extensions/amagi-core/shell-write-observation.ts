/**
 * shell-write-observation.ts — bash 写盘形态分类/目标提取纯函数集（amagi-pi v2 K1 下沉）。
 *
 * 来源：task-jsonl.ts L40-200（P3-B 拆分自 task-tool.ts 后的 bash 写盘形态分类家族）。
 * 纯搬家纪律（同 guards.ts→shell-lexer.ts 的 P3-A 先例）：函数体零改动；
 * 唯一签名适配 = isWriteToolCall 由模块私有改为导出（task-jsonl.ts 的 processLine
 * 仍消费它，经 import 回引）。task-jsonl.ts re-export 全部既有导出名，外部调用方
 * （task-tool.ts / guards.ts / 既有测试）import 路径零变化。
 * 纯度：零 import、零 pi 依赖（depcruise 规则 v2-shell-write-observation-pure 断言）。
 * 它只提供观察，不能证明任意命令只读（§3.1）。
 */

/** A1-R（diting Major-3）/ A1-R2（diting 增审 Major-2）bash 写盘形态分类：引号感知的词法扫描，
 *  只认高置信写文件形态。旧实现复用 guards.isReadOnlyCommand（宽松哨兵正则）作写盘信任证据，
 *  两类可复现失真：grep "writeFile" 的引号内容被误计；Path(...).write_text 等未收录形态被漏计；
 *  heredoc/here-string 输入被当写盘。本分类独立实现（不复用哨兵正则），规则可审计：
 *   ① 重定向到真实文件（> / >> / >&file / &> / &>>；排除 >&n 描述符复合与 /dev/null）——引号外才算。
 *      A1-R2：>>& 仅当目标为纯数字 fd 或 - 才视为描述符操作（>&2 / 2>&1 / >&- 非文件写）；
 *      其余目标（>& output.log）按 bash 实际行为计写盘（旧实现一概排除 >&，漏计真写文件）；
 *   ② heredoc 家族（<< / <<- / <<<）仅表示 stdin 输入，不构成文件写证据——
 *      python <<'PY' 只读诊断 / grep foo <<< "$text" 不计（真写盘仍需独立输出重定向或③）；
 *   ③ 词级高置信写工具（引号内容剔除、按管道/控制符分段后取段首可执行词）：tee / dd of= /
 *      sed -i（含 -pi/-i.bak/--in-place）/ perl -i。
 *  引号内/转义后的任何内容（含 writeFile、write_text 字样）一律不参与判定——只读 grep 不误计。
 *  未命中高置信形态的命令（如 python -c "…write_text…"）返回 false：**不计为写盘**。
 *  这是保守方向——漏计只会多保留 NEEDS_HANDOFF 放行窗口（宁放行不误杀），绝不作为完成正证据。 */
export function bashCommandWritesFile(command: string): boolean {
	return scanBashWrites(command).writes;
}

/** Wave C2（8月迭代）：bash 高置信写盘目标粗提取（重定向 / >&file / &> 目标 + tee 首个非选项参数
 *  + dd of= 值）。提取不到则不记，宁缺勿错：变量/命令替换/通配/旗标形态一律不返回
 *  （$OUT、$(date).txt、*.log 运行时才可解析，记了必是错账）。导出供测试。 */
export function bashWriteTargets(command: string): string[] {
	return scanBashWrites(command).targets;
}

/** Wave C2：目标 token 合法性过滤（变量/替换/通配/旗标/超长 → undefined）。 */
function plausibleWriteTarget(t: string | undefined): string | undefined {
	if (!t) return undefined;
	if (t.length > 512) return undefined;
	if (/[$*?`]/.test(t)) return undefined;
	if (t.startsWith("-")) return undefined;
	return t;
}

/** Wave C2：从 j 处窥探重定向目标 token（引号包裹取内容；裸 token 到空白/控制符止；不消费）。 */
function peekBashTargetToken(cmd: string, j: number): string | undefined {
	const n = cmd.length;
	if (j < 0 || j >= n) return undefined;
	const q = cmd[j] === "'" || cmd[j] === '"' ? cmd[j] : null;
	if (q) {
		const end = cmd.indexOf(q, j + 1);
		if (end === -1) return undefined;
		return cmd.slice(j + 1, end) || undefined;
	}
	let k = j;
	while (k < n && !/[ \t;|&\n<>()]/.test(cmd[k])) k++;
	return k === j ? undefined : cmd.slice(j, k);
}

function scanBashWrites(command: string): { writes: boolean; targets: string[] } {
	let hasRedir = false;
	const targets: string[] = [];
	const segments: string[][] = [];
	let segment: string[] = [];
	let word = "", hasWord = false;
	const n = command.length;
	const pushWord = () => {
		if (!hasWord) return;
		segment.push(word);
		word = "";
		hasWord = false;
	};
	const pushSegment = () => { pushWord(); if (segment.length) { segments.push(segment); segment = []; } };
	let i = 0, quote: "'" | '"' | null = null;
	while (i < n) {
		const ch = command[i];
		if (quote) { // 引号内：既不产词也不参与操作符判定（词法级防 grep "writeFile" 误计）
			if (ch === "\\" && quote === '"') { i += 2; continue; } // 双引号内 \" 原义保留，内容一律跳过
			if (ch === quote) quote = null;
			i++;
			continue;
		}
		if (ch === "\\") { i += 2; continue; } // 转义符连同下一字符剔除
		if (ch === "'" || ch === '"') { quote = ch; pushWord(); i++; continue; }
		// heredoc/here-string（<< / <<- / <<<）：stdin 输入形态，不构成文件写证据（A1-R2）——仅跳过操作符。
		if (ch === "<" && command[i + 1] === "<") { pushWord(); i += 2; if (command[i] === "-") i++; if (command[i] === "<") i++; continue; }
		if (ch === ">") {
			const next = command[i + 1];
			let j: number;
			if (next === "&") {
				// >&：目标为纯数字 fd 或 -（>&2 / 2>&1 / >&-）→ 描述符操作非文件写；
			// 其余目标（>& output.log / >&log）→ bash 实际写该文件，计写盘（A1-R2 修复：不再一概排除）。
				j = i + 2;
				if (command[j] === ">") j++; // >>&file 少见形态一并覆盖
				const fd = /^(\d+|-)(?![\w.-])/.exec(command.slice(j));
				if (fd) { i = j + fd[1].length; continue; }
			} else {
				j = i + (next === ">" ? 2 : 1);
			}
			while (j < n && /[ \t]/.test(command[j])) j++;
			if (!command.startsWith("/dev/null", j)) {
				hasRedir = true;
				// Wave C2：同位提取重定向目标（> / >> / >&file / >>&file）
				const t = plausibleWriteTarget(peekBashTargetToken(command, j));
				if (t) targets.push(t);
			}
			i = j;
			continue;
		}
		if (ch === "&" && command[i + 1] === ">") { // &> / &>> 整体重定向
			let j = i + 2 + (command[i + 2] === ">" ? 1 : 0);
			while (j < n && /[ \t]/.test(command[j])) j++;
			if (!command.startsWith("/dev/null", j)) {
				hasRedir = true;
				// Wave C2：同位提取目标
				const t = plausibleWriteTarget(peekBashTargetToken(command, j));
				if (t) targets.push(t);
			}
			i = j;
			continue;
		}
		if (/[ \t;|&\n<>()]/.test(ch)) { if (/[;|&\n]/.test(ch)) pushSegment(); else pushWord(); i++; continue; }
		word += ch; hasWord = true; i++;
	}
	pushSegment();
	let writesTool = false;
	for (const seg of segments) {
		const head = seg[0] || "";
		const exe = head.slice(head.lastIndexOf("/") + 1).toLowerCase();
		const args = seg.slice(1);
		if (exe === "tee") {
			writesTool = true;
			// Wave C2：tee 首个非选项位置参数即写盘目标（引号包裹参数不进词表，自然不记）
			const arg = args.find((w) => w !== "" && !w.startsWith("-"));
			const t = plausibleWriteTarget(arg);
			if (t) targets.push(t);
		} else if (exe === "dd") {
			const of = args.find((w) => /^of=/.test(w));
			if (of) {
				writesTool = true;
				const t = plausibleWriteTarget(of.slice(3));
				if (t) targets.push(t);
			}
		} else if ((exe === "sed" || exe === "perl") && args.some((w) => /^-[^-]*i/.test(w) || w.startsWith("--in-place"))) {
			writesTool = true; // 目标为行尾位置参数，无法与其它操作数可靠区分——不提取（宁缺勿错）
		}
	}
	return { writes: hasRedir || writesTool, targets };
}

/** Wave C2：write/edit 工具调用的写盘目标（file_path/path 入参；缺省/非字符串 → 空数组）。导出供测试。 */
export function writeEditTargets(args: unknown): string[] {
	if (!args || typeof args !== "object") return [];
	const a = args as { file_path?: unknown; path?: unknown };
	for (const key of ["file_path", "path"] as const) {
		const v = a[key];
		if (typeof v === "string" && v.trim()) return [v.trim()];
	}
	return [];
}

/** A1-R（diting Major-3）写盘类判定（意图登记用）：write/edit 直算；bash 走高置信形态分类。
 *  只决定「该 toolCall 是否为写盘类」，是否计入证据由成功 tool_result 核销（settleWriteCredit）。
 *  K1 下沉适配：由 task-jsonl.ts 模块私有改为导出（processLine 留在 task-jsonl.ts，经 import 回引）。 */
export function isWriteToolCall(name: string, args: unknown): boolean {
	if (name === "write" || name === "edit") return true;
	if (name === "bash") {
		const command = (args as { command?: unknown } | null | undefined)?.command;
		return typeof command === "string" && command.length > 0 && bashCommandWritesFile(command);
	}
	return false;
}
