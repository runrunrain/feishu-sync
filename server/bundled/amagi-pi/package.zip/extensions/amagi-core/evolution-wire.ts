/**
 * evolution-wire.ts — P5（寄生增强方案 §9 P5 行 + §4.2，pi-0.99.1 批 W3）：amagi_evolution 结构化输出 wire。
 *
 * 本模块是**纯 schema/投影模块**（纪律沿 task-query-wire §4.1 / handbook-wire）：mapper 零 I/O、
 * 零副作用、不读用户现场——不执行 log 写盘、不触发 resolve 迁移、不二次 list（§9 P5 行「不二次
 * 触发 list 迁移」：listItems 的版本自愈副作用只由接线层原有单次调用发生，wire 只投影该次返回）。
 * 自由文本 import 复用 task-query-wire 的 redactCredentials；条目路径槽 import 复用 evolution-log
 * 的 itemFilePath（纯路径推导单源，防第二套拼路径）。
 *
 * wire 身份：kind="amagi.evolution"、wireVersion=1、schemaVersion=2（B9/ev-20261012-04b7b9 升版：
 * 六分支新增 evidence/evidenceState/warnings 等字段；v1 字段保留原义不改名）、action、ok、isError。
 * 成功分支带 data（对象封闭、无值字段 null）；失败分支带 error:{code,message}（code ∈
 * invalid-input/not-found/permission/operation/internal；message 过 redactCredentials 同源脱敏）。
 * URN：urn:amagi:evolution:<分支>:2。v2 冻结字段集合；增删字段或改语义先升 schemaVersion。
 * 历史 v1（schemaVersion=1）wire 不再由本模块产出；呈现层显式兼容 v1/v2。
 *
 * 分支投影（源闭合锚点=evolution-log EvolutionItem / 各操作真实回执）：
 *  - log：id/path + evidence（本次留存/遗漏逐项）+ warnings——logItem 真实落盘回执（写成功后才返回）。
 *  - list：items（id/title/category/severity/status/fixVersion/path，无值 null）+ returned + warnings
 *    （仅承载自愈失败——items 字段集不变，不读全库证据正文）。
 *  - resolve：id/path/fixVersion + evidence + warnings。
 *  - show：list 条目字段 + phenomenon/expected/source/note + evidence/evidenceState/warnings；
 *    evidenceState=legacy（无清单）/recorded（有清单）/invalid（清单损坏）；note 为真实首次备注或 null。
 *  - export：id/path/bytes（md 实写字节数）+ evidence/evidenceState/evidenceBytes/evidenceComplete/warnings；
 *    evidenceComplete=null（legacy 或显式空清单——不声称完整）/true（全部 retained 且校验通过）/false（有遗漏）。
 *  - error：code/message 两字段封闭 envelope。
 * evidence 投影：wire 不扩散绝对 origin 根（cwd/gitRoot 置 null；absolute/redacted 的 path 置 null），
 * sessionRef 同样不进 wire（§4.2）。
 */
import { Type } from "typebox";
import { redactCredentials } from "./task-query-wire.ts";
import { itemFilePath, type EvolutionItem, type EvolutionStatus } from "./evolution-log.ts";
import type { EvidenceResult, EvidenceState } from "./evolution-evidence.ts";

// ── wire 身份常量（固定字面量；接线层与测试共用） ──────────────────────────────

export const EVOLUTION_WIRE_KIND = "amagi.evolution";
export const EVOLUTION_WIRE_VERSION = 1;
export const EVOLUTION_SCHEMA_VERSION = 2;

/** 六分支 schema 标识（§4.2 URN 格式 urn:amagi:<家族>:<分支>:2——B9 升版）。 */
export const EVOLUTION_WIRE_URNS = {
	log: "urn:amagi:evolution:log:2",
	list: "urn:amagi:evolution:list:2",
	resolve: "urn:amagi:evolution:resolve:2",
	show: "urn:amagi:evolution:show:2",
	export: "urn:amagi:evolution:export:2",
	error: "urn:amagi:evolution:error:2",
} as const;

/** 家族错误码（§4.2「各家族/error」行：五值封闭；语义见模块头与接线层映射）。 */
export const EVOLUTION_ERROR_CODES = ["invalid-input", "not-found", "permission", "operation", "internal"] as const;
export type EvolutionErrorCode = (typeof EVOLUTION_ERROR_CODES)[number];

export type EvolutionAction = "log" | "list" | "resolve" | "show" | "export";

// ── 共享子 schema（additionalProperties:false + 全键 required；分支根才挂 $id） ──

const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });
const NullableString = Type.Union([Type.String(), Type.Null()]);

const WireCommonProperties = {
	kind: Type.Literal(EVOLUTION_WIRE_KIND),
	wireVersion: Type.Literal(EVOLUTION_WIRE_VERSION),
	schemaVersion: Type.Literal(EVOLUTION_SCHEMA_VERSION),
};

const ErrorCodeSchema = Type.Union(EVOLUTION_ERROR_CODES.map((c) => Type.Literal(c)));

const EvidenceLinesSchema = Type.Object({
	start: Type.Integer({ minimum: 1, maximum: Number.MAX_SAFE_INTEGER }),
	end: Type.Integer({ minimum: 1, maximum: Number.MAX_SAFE_INTEGER }),
}, { additionalProperties: false, description: "行锚（1-based 闭区间，指向规范化+脱敏后副本）" });

/** origin 投影：wire 不扩散绝对根（cwd/gitRoot 恒 null；absolute/redacted 的 path 恒 null）。 */
const EvidenceOriginWireSchema = Type.Object({
	base: Type.Union([Type.Literal("cwd"), Type.Literal("git-root"), Type.Literal("absolute"), Type.Literal("redacted")]),
	path: NullableString,
	cwd: NullableString,
	gitRoot: NullableString,
}, { additionalProperties: false, description: "溯源基准（仅相对来源携带 path；绝对根不进 wire）" });

/** 证据记录投影：retained 携 path/digest/bytes/redacted[lines][derivedFromDigest]；omitted 携 reason。
 *  health 与采集 state 分离（retained=verified/missing/drifted/denied/unreadable；omitted 恒 null）。 */
const EvidenceRecordWireSchema = Type.Object({
	key: Type.String(),
	phase: Type.Union([Type.Literal("log"), Type.Literal("resolve")]),
	state: Type.Union([Type.Literal("retained"), Type.Literal("omitted")]),
	origin: Type.Optional(EvidenceOriginWireSchema),
	summary: Type.Optional(Type.String()),
	path: Type.Optional(Type.String()),
	digest: Type.Optional(Type.String()),
	bytes: Type.Optional(NonNegativeSafeInt),
	redacted: Type.Optional(Type.Boolean()),
	lines: Type.Optional(EvidenceLinesSchema),
	derivedFromDigest: Type.Optional(Type.String()),
	reason: Type.Optional(Type.String()),
	health: Type.Union([Type.Literal("verified"), Type.Literal("missing"), Type.Literal("drifted"), Type.Literal("denied"), Type.Literal("unreadable"), Type.Null()]),
}, { additionalProperties: false, description: "证据留存记录（retained=实际留存并校验过的字节；omitted=未留存+封闭原因）" });

const EvidenceArraySchema = Type.Array(EvidenceRecordWireSchema, { description: "证据清单（本次操作逐项；无请求/无记录为空数组）" });
const WarningsArraySchema = Type.Array(Type.String(), { description: "警告（行锚失效/自愈失败/健康缺口等；有界不静默）" });
const EvidenceStateSchema = Type.Union([Type.Literal("legacy"), Type.Literal("recorded"), Type.Literal("invalid")], { description: "legacy=无清单（历史或未请求）；recorded=有清单；invalid=清单损坏" });

// ── 分支 schema（v2：v1 字段原义保留，新增 evidence/evidenceState/warnings） ───

/** log 档：logItem 真实落盘回执（写成功后才返回成功）+ 证据逐项披露。 */
export const EvolutionLogWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("log"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		path: Type.String(),
		evidence: EvidenceArraySchema,
		warnings: WarningsArraySchema,
	}, { additionalProperties: false, description: "沉淀回执（id/path=真实落盘文件；evidence=本次留存/遗漏逐项——单项失败不阻断沉淀）" }),
}, { $id: EVOLUTION_WIRE_URNS.log, additionalProperties: false, description: "amagi_evolution log 档 wire（§4.2 + B9 v2）" });

/** list 档：items 白名单投影 + returned + warnings（仅承载自愈失败；不读全库证据正文）。 */
export const EvolutionListWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("list"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		items: Type.Array(Type.Object({
			id: Type.String(),
			title: NullableString,
			category: NullableString,
			severity: NullableString,
			status: NullableString,
			fixVersion: NullableString,
			path: Type.String(),
		}, { additionalProperties: false, description: "条目白名单投影（无值字段 null；title 过脱敏；path=itemFilePath 单源推导）" })),
		returned: NonNegativeSafeInt,
		warnings: WarningsArraySchema,
	}, { additionalProperties: false, description: "列表投影（status 过滤语义与正文 renderItemsText 同一次 listItems 结果）" }),
}, { $id: EVOLUTION_WIRE_URNS.list, additionalProperties: false, description: "amagi_evolution list 档 wire（§4.2 + B9 v2）" });

/** resolve 档：迁移回执 id/path/fixVersion + evidence/warnings——fixVersion=迁移后条目真实生效值。 */
export const EvolutionResolveWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("resolve"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		path: Type.String(),
		fixVersion: NullableString,
		evidence: EvidenceArraySchema,
		warnings: WarningsArraySchema,
	}, { additionalProperties: false, description: "解决回执（迁移完成后才返回成功；幂等 resolve 同样真实路径；证据清单随条目身份不变）" }),
}, { $id: EVOLUTION_WIRE_URNS.resolve, additionalProperties: false, description: "amagi_evolution resolve 档 wire（§4.2 + B9 v2）" });

/** show 档：list 条目字段 + phenomenon/expected/source/note + evidence/evidenceState/warnings。 */
export const EvolutionShowWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("show"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		title: NullableString,
		category: NullableString,
		severity: NullableString,
		status: NullableString,
		fixVersion: NullableString,
		path: Type.String(),
		phenomenon: NullableString,
		expected: NullableString,
		source: NullableString,
		note: NullableString,
		evidence: EvidenceArraySchema,
		evidenceState: EvidenceStateSchema,
		warnings: WarningsArraySchema,
	}, { additionalProperties: false, description: "单条全文投影（note=真实首次备注或 null；evidenceState=legacy/recorded/invalid；sessionRef 不进 wire）" }),
}, { $id: EVOLUTION_WIRE_URNS.show, additionalProperties: false, description: "amagi_evolution show 档 wire（§4.2 + B9 v2）" });

/** export 档：真实写盘回执 id/path/bytes + 证据包字段——bytes 仍只计 md 实写字节数。 */
export const EvolutionExportWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("export"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		path: Type.String(),
		bytes: NonNegativeSafeInt,
		evidence: EvidenceArraySchema,
		evidenceState: EvidenceStateSchema,
		evidenceBytes: NonNegativeSafeInt,
		evidenceComplete: Type.Union([Type.Boolean(), Type.Null()]),
		warnings: WarningsArraySchema,
	}, { additionalProperties: false, description: "导出回执（path=真实输出文件；bytes=UTF-8 实写字节数；evidenceBytes=证据副本合计；evidenceComplete=null 不声称完整" }),
}, { $id: EVOLUTION_WIRE_URNS.export, additionalProperties: false, description: "amagi_evolution export 档 wire（§4.2 + B9 v2）" });

/** error 档：{code,message} 两字段封闭 envelope；action 只取合法五档字面或 null。 */
export const EvolutionErrorWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Union([Type.Literal("log"), Type.Literal("list"), Type.Literal("resolve"), Type.Literal("show"), Type.Literal("export"), Type.Null()]),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	error: Type.Object({
		code: ErrorCodeSchema,
		message: Type.String(),
	}, { additionalProperties: false }),
}, { $id: EVOLUTION_WIRE_URNS.error, additionalProperties: false, description: "amagi_evolution 工具内失败 wire（§4.2 error 分支；message 已同源脱敏）" });

/** 六封闭分支 Union（含 error 分支——注册面统一校验器；消费者判据 kind/wireVersion/action/ok/schemaVersion）。 */
export const EvolutionOutputSchema = Type.Union(
	[EvolutionLogWireSchema, EvolutionListWireSchema, EvolutionResolveWireSchema, EvolutionShowWireSchema, EvolutionExportWireSchema, EvolutionErrorWireSchema],
	{ description: "amagi_evolution 结构化输出 wire v2（六封闭分支：log/list/resolve/show/export/error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；一致性由专项测试 Value.Check+键集对照双断言） ──

export interface EvolutionWireCommon {
	kind: typeof EVOLUTION_WIRE_KIND;
	wireVersion: typeof EVOLUTION_WIRE_VERSION;
	schemaVersion: typeof EVOLUTION_SCHEMA_VERSION;
}

export interface EvolutionEvidenceOriginWire {
	base: "cwd" | "git-root" | "absolute" | "redacted";
	path: string | null;
	cwd: string | null;
	gitRoot: string | null;
}

export interface EvolutionEvidenceRecordWire {
	key: string;
	phase: "log" | "resolve";
	state: "retained" | "omitted";
	origin?: EvolutionEvidenceOriginWire;
	summary?: string;
	path?: string;
	digest?: string;
	bytes?: number;
	redacted?: boolean;
	lines?: { start: number; end: number };
	derivedFromDigest?: string;
	reason?: string;
	health: "verified" | "missing" | "drifted" | "denied" | "unreadable" | null;
}

export interface EvolutionListItemWire {
	id: string;
	title: string | null;
	category: string | null;
	severity: string | null;
	status: string | null;
	fixVersion: string | null;
	path: string;
}
export interface EvolutionLogWire extends EvolutionWireCommon {
	action: "log"; ok: true; isError: false;
	data: { id: string; path: string; evidence: EvolutionEvidenceRecordWire[]; warnings: string[] };
}
export interface EvolutionListWire extends EvolutionWireCommon {
	action: "list"; ok: true; isError: false;
	data: { items: EvolutionListItemWire[]; returned: number; warnings: string[] };
}
export interface EvolutionResolveWire extends EvolutionWireCommon {
	action: "resolve"; ok: true; isError: false;
	data: { id: string; path: string; fixVersion: string | null; evidence: EvolutionEvidenceRecordWire[]; warnings: string[] };
}
export interface EvolutionShowWire extends EvolutionWireCommon {
	action: "show"; ok: true; isError: false;
	data: {
		id: string; title: string | null; category: string | null; severity: string | null; status: string | null;
		fixVersion: string | null; path: string; phenomenon: string | null; expected: string | null;
		source: string | null; note: string | null; evidence: EvolutionEvidenceRecordWire[];
		evidenceState: EvidenceState; warnings: string[];
	};
}
export interface EvolutionExportWire extends EvolutionWireCommon {
	action: "export"; ok: true; isError: false;
	data: { id: string; path: string; bytes: number; evidence: EvolutionEvidenceRecordWire[]; evidenceState: EvidenceState; evidenceBytes: number; evidenceComplete: boolean | null; warnings: string[] };
}
export interface EvolutionErrorWire extends EvolutionWireCommon {
	action: EvolutionAction | null; ok: false; isError: true;
	error: { code: EvolutionErrorCode; message: string };
}
export type EvolutionWireOutput =
	| EvolutionLogWire | EvolutionListWire | EvolutionResolveWire
	| EvolutionShowWire | EvolutionExportWire | EvolutionErrorWire;

// ── 投影源（调用方同一次执行提供的源对象——本模块零 I/O、不二次读取、不执行副作用） ──

/** 条目投影源：EvolutionItem + note 开放槽（B9 起底层持久化 note；旧条目无值 → null）。
 *  sessionRef 在源类型上保留但**不投影**（§4.2「sessionRef 不默认扩散」）。 */
export type EvolutionItemSource = EvolutionItem & { note?: string };

/** list 投影源：同一次 listItems 调用的返回 + 该次调用所用 root + 自愈警告（可选）。 */
export interface EvolutionListSource {
	root: string;
	items: readonly EvolutionItemSource[];
	warnings?: readonly string[];
}

/** show 投影源：命中的单条目 + 所用 root + 证据校验结果（可选——缺席投影空清单/legacy）。 */
export interface EvolutionShowSource {
	root: string;
	item: EvolutionItemSource;
	evidence?: readonly EvidenceResult[];
	evidenceState?: EvidenceState;
	warnings?: readonly string[];
}

/** resolve 投影源：resolveItem 成功回执（fixVersion 为底层 DTO 增量）。 */
export interface EvolutionResolveSource {
	id: string;
	path: string;
	fixVersion?: string;
	evidence?: readonly EvidenceResult[];
	warnings?: readonly string[];
}

/** export 投影源扩展：证据包字段（B9）。 */
export interface EvolutionExportSource {
	id: string;
	path: string;
	bytes: number;
	evidence?: readonly EvidenceResult[];
	evidenceState?: EvidenceState;
	evidenceBytes?: number;
	evidenceComplete?: boolean | null;
	warnings?: readonly string[];
}

// ── 字段归一小件（无值/类型不合 → null；自由文本槽过 redactCredentials 同源脱敏） ─────

const strOrNull = (v: unknown): string | null => (typeof v === "string" ? v : null);
/** 自由文本槽（标题/现象/期望/来源/备注/摘要）：非字符串 → null；字符串过凭据形态脱敏（§4.2 show 行）。 */
const redactText = (v: unknown): string | null => (typeof v === "string" ? redactCredentials(v) : null);

/** 证据记录投影：origin 去绝对根（cwd/gitRoot→null；absolute/redacted 的 path→null）；摘要过脱敏。 */
function toEvidenceRecordWire(r: Readonly<EvidenceResult>): EvolutionEvidenceRecordWire {
	const rec = r.record;
	const w: EvolutionEvidenceRecordWire = { key: rec.key, phase: rec.phase, state: rec.state, health: r.health };
	if (rec.origin) {
		w.origin = {
			base: rec.origin.base,
			path: rec.origin.base === "cwd" || rec.origin.base === "git-root" ? rec.origin.path : null,
			cwd: null,
			gitRoot: null,
		};
	}
	if (rec.summary !== undefined) w.summary = redactCredentials(rec.summary);
	if (rec.state === "retained") {
		w.path = rec.path;
		w.digest = rec.digest;
		w.bytes = rec.bytes;
		w.redacted = rec.redacted;
		if (rec.lines !== undefined) w.lines = rec.lines;
		if (rec.derivedFromDigest !== undefined) w.derivedFromDigest = rec.derivedFromDigest;
	} else {
		w.reason = rec.reason;
	}
	return w;
}

const evidenceWire = (rs: readonly EvidenceResult[] | undefined): EvolutionEvidenceRecordWire[] =>
	(rs ?? []).map((r) => toEvidenceRecordWire(r));
const warningsWire = (ws: readonly string[] | undefined): string[] => (ws ?? []).map(redactCredentials);

// ── 各档映射 ─────────────────────────────────────────────────────────────────

/** log 档：落盘回执直投影 + 本次证据逐项（omitted 即『未留存：原因』的结构化载体）。 */
export function toLogWire(id: string, path: string, evidence?: readonly EvidenceResult[], warnings?: readonly string[]): EvolutionLogWire {
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: "log",
		ok: true,
		isError: false,
		data: { id, path, evidence: evidenceWire(evidence), warnings: warningsWire(warnings) },
	};
}

/** list 档：同一次 listItems 返回的单次投影（title 过脱敏；path 由 itemFilePath 单源推导）。 */
export function toListWire(src: Readonly<EvolutionListSource>): EvolutionListWire {
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: "list",
		ok: true,
		isError: false,
		data: {
			items: src.items.map((it) => ({
				id: it.id,
				title: redactText(it.title),
				category: strOrNull(it.category),
				severity: strOrNull(it.severity),
				status: strOrNull(it.status),
				fixVersion: strOrNull(it.fixVersion),
				path: itemFilePath(src.root, it.status as EvolutionStatus, it.id),
			})),
			returned: src.items.length,
			warnings: warningsWire(src.warnings),
		},
	};
}

/** resolve 档：迁移回执（fixVersion 无值 null——幂等 resolve 携条目原值或 null，不臆造）。 */
export function toResolveWire(src: Readonly<EvolutionResolveSource>): EvolutionResolveWire {
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: "resolve",
		ok: true,
		isError: false,
		data: { id: src.id, path: src.path, fixVersion: strOrNull(src.fixVersion), evidence: evidenceWire(src.evidence), warnings: warningsWire(src.warnings) },
	};
}

/** show 档：单条全文投影（自由文本过脱敏；note=真实首次备注或 null；sessionRef 不进 wire）。 */
export function toShowWire(src: Readonly<EvolutionShowSource>): EvolutionShowWire {
	const it = src.item;
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: "show",
		ok: true,
		isError: false,
		data: {
			id: it.id,
			title: redactText(it.title),
			category: strOrNull(it.category),
			severity: strOrNull(it.severity),
			status: strOrNull(it.status),
			fixVersion: strOrNull(it.fixVersion),
			path: itemFilePath(src.root, it.status as EvolutionStatus, it.id),
			phenomenon: redactText(it.phenomenon),
			expected: redactText(it.expected),
			source: redactText(it.source),
			note: redactText(it.note),
			evidence: evidenceWire(src.evidence),
			evidenceState: src.evidenceState ?? "legacy",
			warnings: warningsWire(src.warnings),
		},
	};
}

/** export 档：写盘回执（bytes=md 实写字节数；evidenceBytes=证据副本合计；只证明写入返回）。 */
export function toExportWire(id: string, path: string, bytes: number, ext?: Readonly<Omit<EvolutionExportSource, "id" | "path" | "bytes">>): EvolutionExportWire {
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: "export",
		ok: true,
		isError: false,
		data: {
			id, path, bytes,
			evidence: evidenceWire(ext?.evidence),
			evidenceState: ext?.evidenceState ?? "legacy",
			evidenceBytes: ext?.evidenceBytes ?? 0,
			evidenceComplete: ext?.evidenceComplete ?? null,
			warnings: warningsWire(ext?.warnings),
		},
	};
}

/** error 档：action 只认合法五档字面（非法/缺席 → null，不 echo 任意原参数）；message 同源脱敏。
 *  code 由调用方按错误语义给定（invalid-input/not-found/permission/operation/internal）。 */
export function toEvolutionErrorWire(action: unknown, code: EvolutionErrorCode, message: string): EvolutionErrorWire {
	const known: EvolutionAction | null =
		action === "log" || action === "list" || action === "resolve" || action === "show" || action === "export" ? action : null;
	return {
		kind: EVOLUTION_WIRE_KIND,
		wireVersion: EVOLUTION_WIRE_VERSION,
		schemaVersion: EVOLUTION_SCHEMA_VERSION,
		action: known,
		ok: false,
		isError: true,
		error: { code, message: redactCredentials(message) },
	};
}
