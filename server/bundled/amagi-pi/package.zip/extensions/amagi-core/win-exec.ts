/**
 * win-exec.ts — win_exec 工具：WSL 会话内受管执行 Windows 原生程序（白名单、可审计）。
 *
 * v2（diting 审核 M1-M9/m1-m8 修复轮）：安全边界全面加固——路径归一/realpath 复核（M1）、
 * shells 不对模型开放（M2）、配置信任门（M3）、.bat 元字符拒绝（M4）、PID 快照差集回收
 * （M5/M6）、Job Object 失败即退（M7）、破坏性 git 操作守卫（M8，经 win-exec-guard.ts 适配
 * guards.ts 既有门）、close 收口 + 输出上限/二进制检测（M9）、锁 token/starttime/relay 双校验
 * （m1）、中止前置检查（m2）、后台载荷内嵌脚本（m3）、长度预检（m4）、automount 根（m5）。
 *
 * 本机（macOS）无法真跑 WSL/Windows——所有外部访问经 WinExecToolDeps 注入；Windows 真机
 * 验证入口 /amagi win-doctor（win-exec-doctor.ts）。
 */

import { spawn as nodeSpawn, type ChildProcess } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { Type } from "typebox";
import { toolProcessEnv } from "./tool-process-env.ts";
import { runBgExecute } from "./run-bg.ts";
import { guardProjectTrustedOf } from "./guard-policy.ts";
import { readWinExecConfig, readGlobalWinExecConfig, mergeWinExecConfig, emptyWinExecConfig, applyWinExecConfigTrust, WIN_EXEC_LONGRUN_TIMEOUT_S, type WinExecConfig } from "./win-exec-config.ts";
import { acquireExclusiveLock, winExecRoot, type ExclusiveLockHandle, type LockDeps } from "./win-exec-lock.ts";
import { cachedWindowsRoots, discoverWindowsRoots, resolveProgram, resetWinExecDiscovery, type DiscoverDeps, type ResolvedProgram, type WindowsRoots } from "./win-exec-discover.ts";
import { buildArgumentsLine, buildLauncherScript, encodeLauncherPayload, WINEXEC_PAYLOAD_MAX_B64, WIN_COMMAND_LINE_MAX, windowsQuoteArg } from "./win-exec-launcher.ts";
import { decodeWindowsOutput, describeEncoding, type DecodedWindowsOutput } from "./win-exec-encoding.ts";
import { translateArgList, validateWindowsCwd, isUnderMnt } from "./win-exec-paths.ts";
import { wslMntRoot } from "./win-exec-mnt.ts";
import { StreamAccumulator, listWindowsTasks, snapshotOf, killNewSinceSnapshot, snapshotKillNote, runProcessUntilClose, defaultExecFileAsync, taskKillPid, type ExecFileAsyncFn, type PidSnapshot } from "./win-exec-run.ts";
import { takeDiscardExecutionTicket, recordDiscardExecutionOutcome } from "./git-discard-backup.ts";

// ── WSL 检测（可注入） ───────────────────────────────────────────────────────

export interface WslDetectResult {
	wsl: boolean;
	signals: string[];
}

export function detectWslEnvironment(deps: { env?: NodeJS.ProcessEnv; platform?: NodeJS.Platform; readProcVersion?: () => string } = {}): WslDetectResult {
	const env = deps.env ?? process.env;
	const platform = deps.platform ?? process.platform;
	const signals: string[] = [];
	if (platform === "win32") return { wsl: false, signals: ["win32 原生宿主（非 WSL）"] };
	if (env.WSL_DISTRO_NAME) signals.push(`WSL_DISTRO_NAME=${env.WSL_DISTRO_NAME}`);
	if (env.WSL_INTEROP) signals.push(`WSL_INTEROP=${env.WSL_INTEROP}`);
	let procVersion = "";
	try {
		procVersion = deps.readProcVersion ? deps.readProcVersion() : fs.readFileSync("/proc/version", "utf8");
	} catch { procVersion = ""; /* lint-exempt:/proc 不可读 → env 信号兜底 */ }
	if (/microsoft/i.test(procVersion)) signals.push("/proc/version 含 microsoft");
	return { wsl: signals.length > 0, signals };
}

// ── 注入面 ───────────────────────────────────────────────────────────────────

export interface WinExecToolDeps {
	platform?: NodeJS.Platform;
	env?: NodeJS.ProcessEnv;
	sessionCwd?: string;
	readProcVersion?: () => string;
	/** amagi.json 读取器（缺省真实 fs；测试注入）。 */
	configReader?: (cwd: string) => WinExecConfig;
	/** 全局 amagi.json 读取器（缺省真实 fs；注入 configReader 而未注入本项时全局层为空，避免测试读到真实 HOME）。 */
	globalConfigReader?: () => WinExecConfig;
	/** 项目信任判定（缺省经 guardProjectTrustedOf(ctx)——execute 时传入 ctx）。 */
	projectTrusted?: boolean;
	existsSync?: (p: string) => boolean;
	isDirectory?: (p: string) => boolean;
	writeFile?: (p: string, content: string) => void;
	unlink?: (p: string) => void;
	spawn?: typeof nodeSpawn;
	execAsync?: ExecFileAsyncFn;
	now?: () => number;
	roots?: WindowsRoots;
	discoverDeps?: DiscoverDeps;
	lockDeps?: LockDeps;
	killGraceMs?: number;
	reapMarkerTtlMs?: number;
	runBgStart?: (command: string, cwd: string, timeoutMs: number, label: string, onDone?: () => void) => Promise<string>;
	/** automount 根（缺省 wslMntRoot()）。 */
	mntRoot?: string;
}

/** M4：.bat/.cmd 参数元字符（cmd.exe 解释面）——命中即拒绝。 */
export const BAT_METACHAR_RE = /[&|<>^%!"()\r\n]/;

/** m3：env 键收紧为 Windows 常规标识符（无空格/括号——扩展键位留给配置映射而非 env 通道）。 */
const WIN_EXEC_ENV_NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

const FORBIDDEN_ENV_KEYS = new Set([
	"PATH", "PATHEXT", "SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "COMSPEC", "OS", "USERNAME", "USERPROFILE",
	"USERDOMAIN", "ALLUSERSPROFILE", "PUBLIC", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMW6432",
	"PROGRAMDATA", "TEMP", "TMP", "HOMEDRIVE", "HOMEPATH", "LOCALAPPDATA", "APPDATA", "PSMODULEPATH", "WSLENV",
]);

// ── 会话清理注册表（m3：pi 退出时尽力释放锁与临时脚本） ────────────────────────

const activeScripts = new Set<string>();
const activeLocks = new Set<{ handle: ExclusiveLockHandle; unlink: (p: string) => void }>();

export function winExecSessionCleanup(): void {
	for (const entry of activeLocks) {
		try { entry.handle.release(); } catch { /* lint-exempt:退出清理尽力而为 */ }
	}
	activeLocks.clear();
	for (const p of activeScripts) {
		try { fs.unlinkSync(p); } catch { /* lint-exempt:清理失败 → 临时残留无害 */ }
	}
	activeScripts.clear();
}

// ── env 白名单（m3 收紧） ────────────────────────────────────────────────────

export function validateEnvPass(env: Record<string, string> | undefined, envAllow: readonly string[]): { ok: true; env: Record<string, string> } | { ok: false; reason: string } {
	if (env === undefined || env === null) return { ok: true, env: {} };
	if (typeof env !== "object" || Array.isArray(env)) return { ok: false, reason: "env 必须是字符串到字符串的对象" };
	const allow = new Set(envAllow);
	const out: Record<string, string> = {};
	for (const [k, v] of Object.entries(env)) {
		const key = String(k);
		if (typeof v !== "string") return { ok: false, reason: `env["${key}"] 的值必须是字符串（收到 ${typeof v}）` };
		if (FORBIDDEN_ENV_KEYS.has(key.toUpperCase())) return { ok: false, reason: `env 键 "${key}" 属于系统保留键（PATH/SystemRoot/WSLENV 等），不允许覆盖` };
		if (!WIN_EXEC_ENV_NAME_RE.test(key)) return { ok: false, reason: `env 键 "${key}" 不是合法的环境变量名形态（^[A-Za-z_][A-Za-z0-9_]*$）` };
		if (!allow.has(key)) {
			return { ok: false, reason: `env 键 "${key}" 不在白名单内。当前允许键：${allow.size > 0 ? [...allow].join("、") : "（空——未配置 windows.exec.envAllow）"}；请在受信 amagi.json windows.exec.envAllow 中声明后使用` };
		}
		out[key] = v;
	}
	return { ok: true, env: out };
}

/** WSLENV 追加（保留既有值；无 flag——原样字符串透传）。 */
export function appendWslenv(current: string | undefined, keys: readonly string[]): string {
	const existing = (current ?? "").split(":").filter(Boolean);
	const merged = [...existing, ...keys.filter((k) => !existing.includes(k))];
	return merged.join(":");
}

/**
 * M2：git 执行类参数门（参数级防线；白名单约束程序名而非行为）。
 * 只检查「全局选项区」（子命令之前）与已知执行类选项，避免误伤 `git log -c` 等子命令自身合法标志：
 *  - 全局：`-c k=v`/`-ck=v`、`--config-env`、`--exec-path`（含值形态）；`-C/--git-dir/--work-tree/--namespace` 的值被正确跳过
 *  - 子命令级：`--upload-pack`/`--receive-pack`/`--exec`（fetch/pull/push/clone/ls-remote 的程序执行选项）
 *  - `config` 子命令：除只读形态（--get 系/--list/-l/--show-origin）外拒绝（可写 alias 与 core.sshCommand）
 */
export function gitDashCHit(args: readonly string[]): boolean {
	const valueTaking = new Set(["-C", "--git-dir", "--work-tree", "--namespace", "--super-prefix", "--attr-source"]);
	let i = 0;
	for (; i < args.length; i++) {
		const a = args[i];
		if (a === "-c" || /^-c.+/.test(a)) return true;
		if (a === "--config-env" || a.startsWith("--config-env=") || a === "--exec-path" || a.startsWith("--exec-path=")) return true;
		if (valueTaking.has(a)) { i++; continue; }
		if (a.startsWith("-")) continue;
		break; // 子命令
	}
	const sub = args[i];
	const rest = args.slice(i + 1);
	const execOpt = /^--(upload-pack|receive-pack|exec)(=|$)/;
	if (rest.some((a) => execOpt.test(a))) return true;
	if (sub === "config") {
		const readOnly = rest.some((a) => /^(--get(-all|-regexp|-urlmatch)?|--list|-l|--show-origin|--show-scope|--name-only)$/.test(a));
		if (!readOnly) return true;
	}
	return false;
}

/** M8：win_exec 破坏性 git 命令的规范命令串（与 win-exec-guard.ts 同源——票据绑定口径）。 */
export function canonicalGitCommand(programBase: string, args: readonly string[]): string {
	return [programBase, ...args].join(" ");
}

function shQuote(s: string): string {
	return `'${String(s).replace(/'/g, `'\\''`)}'`;
}

function sleep(ms: number): Promise<void> { return new Promise((r) => setTimeout(r, ms)); }

/** reap 标记（M5：PID 集合形态；使用后即删，TTL 仅兜底）。 */
interface ReapMarker { at: number; pids: number[]; images: string[] }

function reapMarkerPath(group: string): string {
	return path.join(winExecRoot(), "reap", `${group}.json`);
}

function readReapMarker(group: string): ReapMarker | null {
	try {
		const parsed = JSON.parse(fs.readFileSync(reapMarkerPath(group), "utf8")) as Partial<ReapMarker>;
		if (typeof parsed.at === "number" && Array.isArray(parsed.pids) && parsed.pids.every((p) => typeof p === "number")) {
			return { at: parsed.at, pids: parsed.pids, images: Array.isArray(parsed.images) ? parsed.images : [] };
		}
	} catch { return null; /* lint-exempt:无标记/损坏 → 非本工具遗留 */ }
	return null;
}

function writeReapMarker(group: string, rows: { image: string; pid: number }[], deps: Pick<WinExecToolDeps, "writeFile"> = {}): void {
	try {
		const dir = path.join(winExecRoot(), "reap");
		fs.mkdirSync(dir, { recursive: true });
		(deps.writeFile ?? ((p, c) => fs.writeFileSync(p, c, "utf8")))(reapMarkerPath(group), JSON.stringify({ at: Date.now(), pids: rows.map((r) => r.pid), images: rows.map((r) => r.image.toLowerCase()) }));
	} catch { /* lint-exempt:标记写失败只影响下次清扫归因 */ }
}

function deleteReapMarker(group: string, deps: Pick<WinExecToolDeps, "unlink"> = {}): void {
	try { (deps.unlink ?? ((p) => fs.unlinkSync(p)))(reapMarkerPath(group)); } catch { /* lint-exempt:已删/不存在 */ }
}

// ── 起前清扫（M5：killImages PID 语义 + PID 集合 isOurs + marker 即用即删） ─────

interface SweepOutcome {
	ok: boolean;
	reason?: string;
	killed: { image: string; pid: number }[];
	failed: { image: string; pid: number }[];
}

/** M2：内部通道解析 deps（shells/内部专用程序放行——bat/ps1 中转与 tasklist/taskkill）。 */
function internalDeps(deps: WinExecToolDeps): DiscoverDeps {
	return { ...(deps.discoverDeps ?? {}), existsSync: deps.existsSync, env: deps.env, realpath: deps.discoverDeps?.realpath, purpose: "internal" };
}

async function preSweep(
	deps: WinExecToolDeps, cfg: WinExecConfig, roots: WindowsRoots,
	group: { name: string; killImages: string[] } | undefined, exclusiveName: string, force: boolean, notes: string[],
): Promise<SweepOutcome> {
	const out: SweepOutcome = { ok: true, killed: [], failed: [] };
	if (!group || group.killImages.length === 0) return out;
	const execAsync = deps.execAsync ?? defaultExecFileAsync;
	const tasklistRes = resolveProgram("tasklist", cfg, roots, internalDeps(deps));
	if (!tasklistRes.ok) return { ...out, ok: false, reason: `互斥组 "${exclusiveName}" 声明了 killImages 但 tasklist.exe 无法解析——清扫无法核验（拒绝执行防误杀）；${tasklistRes.reason}` };
	const rows = await listWindowsTasks(execAsync, tasklistRes.program.linuxPath);
	if (rows === null) return { ...out, ok: false, reason: `tasklist 查询失败——无法核验组 "${exclusiveName}" 的 killImages 存活状态，拒绝执行（可重试；确认无残留后可临时传 force_sweep=true）` };
	const want = new Set(group.killImages.map((s) => s.trim().toLowerCase()).filter(Boolean));
	const alive = rows.filter((r) => want.has(r.image.toLowerCase()));
	if (alive.length === 0) {
		deleteReapMarker(exclusiveName, deps); // 干净状态：残留标记一并清理
		return out;
	}
	const marker = readReapMarker(exclusiveName);
	const ttl = deps.reapMarkerTtlMs ?? 10 * 60 * 1000;
	const isOurs = marker !== null && (Date.now() - marker.at) <= ttl && alive.every((r) => marker.pids.includes(r.pid));
	if (!force && !isOurs) {
		return {
			...out,
			ok: false,
			reason: [
				`互斥组 "${exclusiveName}" 声明的进程仍在运行：${alive.map((r) => `${r.image} (pid ${r.pid})`).join("、")}。`,
				"默认拒绝执行——这些进程可能是主上或别的工具启动的（本工具只按 PID 归因清理自己上次回收的遗留）；确认可杀请重试并传 force_sweep=true（高危参数：将对上述 PID 逐个 taskkill /T /F）。",
			].join("\n"),
		};
	}
	const taskkillRes = resolveProgram("taskkill", cfg, roots, internalDeps(deps));
	if (!taskkillRes.ok) return { ...out, ok: false, reason: `需要 taskkill 但无法解析——${taskkillRes.reason}` };
	for (const r of alive) {
		const ok = await taskKillPid(execAsync, taskkillRes.program.linuxPath, r.pid);
		(ok ? out.killed : out.failed).push({ image: r.image, pid: r.pid });
	}
	// M5：标记先写（崩溃兜底）再删（正常路径即用即删）
	writeReapMarker(exclusiveName, alive, deps);
	deleteReapMarker(exclusiveName, deps);
	notes.push(`起前清扫（${isOurs ? "判定为本工具上次回收的遗留（PID 归因）" : "force_sweep 高危确认"}）：已 taskkill ${out.killed.map((k) => `${k.image} pid ${k.pid}`).join("、") || "（无）"}${out.failed.length ? `；失败：${out.failed.map((k) => `${k.image} pid ${k.pid}`).join("、")}` : ""}`);
	if (out.failed.length > 0) return { ...out, ok: false, reason: `taskkill 失败（${out.failed.map((k) => `${k.image} pid ${k.pid}`).join("、")}）——进程仍在运行，拒绝执行；请手工核验` };
	return out;
}

// ── 超时/中止杀树（M5/M6：relay 两段信号 + PID 快照差集回收） ──────────────────

async function killTreeSequence(
	child: ChildProcess, pre: PidSnapshot, filterImages: readonly string[], mode: "supervised" | "direct",
	deps: WinExecToolDeps, cfg: WinExecConfig, roots: WindowsRoots, notes: string[], groupName?: string,
): Promise<void> {
	try { child.kill("SIGTERM"); } catch { /* lint-exempt:已死 ESRCH */ }
	await sleep(deps.killGraceMs ?? 2_000);
	try { child.kill("SIGKILL"); } catch { /* lint-exempt:已死 ESRCH */ }
	await sleep(300); // relay 收口 + Job 句柄关闭传播窗口
	const execAsync = deps.execAsync ?? defaultExecFileAsync;
	const tasklistRes = resolveProgram("tasklist", cfg, roots, internalDeps(deps));
	const taskkillRes = resolveProgram("taskkill", cfg, roots, internalDeps(deps));
	const report = await killNewSinceSnapshot({
		execAsync,
		tasklistExe: tasklistRes.ok ? tasklistRes.program.linuxPath : null,
		taskkillExe: taskkillRes.ok ? taskkillRes.program.linuxPath : null,
		pre,
		filterImages,
	});
	notes.push(snapshotKillNote(report, mode));
	if (groupName && report.killed.length > 0) writeReapMarker(groupName, report.killed, deps);
}

// ── 工具参数 ─────────────────────────────────────────────────────────────────

const WIN_EXEC_PARAMS = Type.Object({
	program: Type.String({ description: "白名单程序名（cmake/ctest/git/rg，或 windows.exec.programs 显式映射名），或位于 windows.exec.allowRoots 之下的挂载路径/xxx.exe|bat|cmd|ps1 显式路径。powershell/cmd/taskkill/tasklist 不对模型开放（allowShells 见文档）。不接受 shell 字符串" }),
	args: Type.Optional(Type.Array(Type.String(), { description: "逐元素传参（不经 shell）；挂载根/<盘>/ 开头的参数（含 --opt=、-DX= 形态）自动翻译为 X:\\…。git 的 -c 配置参数默认拒绝（windows.exec.gitAllowDashC 受信放开）；.bat/.cmd 参数含 cmd 元字符（& | < > ^ % ! \" ( ) 换行）拒绝" })),
	cwd: Type.Optional(Type.String({ description: "Linux 侧工作目录，必须在 <automount 根>/<盘符>/ 下（Windows 进程无法以 ext4 路径作 cwd）；缺省取会话 cwd（同样校验）" })),
	env: Type.Optional(Type.Record(Type.String(), Type.String(), { description: "附加环境变量（仅 windows.exec.envAllow 白名单键；系统保留键恒拒；键名 ^[A-Za-z_][A-Za-z0-9_]*$）" })),
	timeout_s: Type.Optional(Type.Number({ description: "超时秒数预算；缺省按程序类别（常规 120s / longRunning 1800s），上限 windows.exec.maxTimeoutS（缺省 3600）。到期回收：relay 终止（supervised 连带 Job Object 整树）+ PID 快照差集 taskkill（只杀本次新增 PID，不动起前已存在的同名进程；快照不可用时如实报告未能确认）" })),
	background: Type.Optional(Type.Boolean({ description: "true 时后台执行（复用 run_bg 原语返回句柄；载荷内嵌临时脚本，不经 shell 命令串传递）" })),
	exclusive: Type.Optional(Type.String({ description: "互斥组名（如 \"ue\"）：同组同时只允许一个 win_exec 在跑（锁 pid/starttime/relay 三重校验，陈旧自愈）；组配置 killImages 时启用起前清扫（存活默认拒绝列 PID）" })),
	translate_paths: Type.Optional(Type.Boolean({ description: "是否翻译挂载路径参数为 X:\\…（缺省 true）" })),
	supervised: Type.Optional(Type.Boolean({ description: "是否经 Job Object 启动脚本托管（longRunning/exclusive 默认开启；Job 建链失败即 exit 91 绝不启动目标）" })),
	force_sweep: Type.Optional(Type.Boolean({ description: "高危参数：起前清扫遇到存活的组 killImages PID 时逐个 taskkill /T /F（仅对这些起前 PID 生效；结果逐一列出被杀 PID 与镜像）" })),
});

export interface WinExecInput {
	program: string;
	args?: string[];
	cwd?: string;
	env?: Record<string, string>;
	timeout_s?: number;
	background?: boolean;
	exclusive?: string;
	translate_paths?: boolean;
	supervised?: boolean;
	force_sweep?: boolean;
}

// ── 执行主体 ─────────────────────────────────────────────────────────────────

export interface WinExecExecuteOpts {
	signal?: AbortSignal;
	/** pi 工具执行 ctx（M3 信任判定：guardProjectTrustedOf(ctx)）。 */
	ctx?: unknown;
	/** 工具调用 id（M8 票据消费绑定）。 */
	toolCallId?: string;
	/** 测试注入：跳过 M8 票据/兜底门（guard 层不在链路时）。 */
	skipDiscardTicket?: boolean;
}

function releaseLockEntry(lock: ExclusiveLockHandle): void {
	lock.release();
	for (const entry of [...activeLocks]) {
		if (entry.handle === lock) activeLocks.delete(entry);
	}
}

/** win_exec 单次执行主体（导出供测试直调；失败 throw 中文理由）。 */
export async function winExecExecute(
	params: WinExecInput, cfg: WinExecConfig, deps: WinExecToolDeps = {}, opts: WinExecExecuteOpts = {},
): Promise<string> {
	// m2：调用已在中止状态——立即终止（不 spawn、不落任何锁/脚本）
	if (opts.signal?.aborted) throw new Error("[win_exec] 调用已处于中止状态（signal aborted）——未执行任何操作");
	const sessionCwd = deps.sessionCwd ?? process.cwd();
	const mntRoot = deps.mntRoot ?? wslMntRoot();
	const roots = deps.roots ?? cachedWindowsRoots({ ...(deps.discoverDeps ?? {}), existsSync: deps.existsSync, env: deps.env }, mntRoot);
	const notes: string[] = [];

	// M3：项目信任门（deps.projectTrusted 显式注入优先——测试/组合根）
	const trusted = deps.projectTrusted ?? guardProjectTrustedOf(opts.ctx);
	const globalCfg = deps.globalConfigReader ? deps.globalConfigReader() : (deps.configReader ? emptyWinExecConfig() : readGlobalWinExecConfig(deps.env ?? process.env));
	const effectiveCfg = mergeWinExecConfig(globalCfg, applyWinExecConfigTrust(cfg, trusted));

	// 1. 程序解析（M1 归一/realpath 复核 + M2 模型面边界）
	const resolved = resolveProgram(params.program, effectiveCfg, roots, { ...(deps.discoverDeps ?? {}), existsSync: deps.existsSync, env: deps.env, purpose: "model" });
	if (!resolved.ok) throw new Error(`[win_exec] program 拒绝：${resolved.reason}`);
	const prog: ResolvedProgram = resolved.program;
	const progBase = path.posix.basename(prog.linuxPath);
	const progBaseName = progBase.toLowerCase().replace(/\.(exe|bat|cmd|ps1)$/, "");

	// 2. 互斥组语义
	const exclusiveName = params.exclusive ?? prog.exclusive;
	const group = exclusiveName !== undefined ? effectiveCfg.groups.get(exclusiveName) : undefined;
	if (exclusiveName !== undefined && !group) notes.push(`互斥组 "${exclusiveName}" 未在 windows.exec.groups 配置——锁互斥仍生效，killImages 清扫/核验为空`);

	// 3. cwd 校验
	const cwdCheck = validateWindowsCwd(params.cwd ?? sessionCwd, { mntRoot });
	if (!cwdCheck.ok) throw new Error(`[win_exec] cwd 拒绝：${cwdCheck.reason}`);

	// 4. 参数翻译
	const argsRaw = Array.isArray(params.args) ? params.args.map(String) : [];
	const translate = params.translate_paths !== false;
	const tr = translate ? translateArgList(argsRaw, { mntRoot }) : { values: argsRaw, translatedCount: 0, keptLinuxPaths: argsRaw.filter((a) => a.startsWith("/") && !isUnderMnt(a, { mntRoot })) };
	if (tr.translatedCount > 0) notes.push(`已翻译 ${tr.translatedCount} 个挂载路径参数为 Windows 形态`);
	if (tr.keptLinuxPaths.length > 0) notes.push(`以下参数是挂载根之外的 Linux 路径，已按原文传递（Windows 程序大概率读不到 ext4 路径，请确认预期）：${tr.keptLinuxPaths.join("、")}`);

	// 5. M2：git -c 执行类参数门（白名单约束程序名而非行为——参数级防线）
	if (progBaseName === "git" && gitDashCHit(tr.values) && !effectiveCfg.gitAllowDashC) {
		throw new Error(`[win_exec] args 拒绝：git 的 -c 全局配置参数可注入执行行为（如 core.sshCommand 执行任意命令、alias. 改写子命令），默认拒绝。确需使用时由主上在受信配置声明 windows.exec.gitAllowDashC=true；--exec-path / -c alias. 等同类程序内执行面见文档「已知限制」。`);
	}

	// 6. M8：破坏性 git 操作门（复用 git-discard-guard 同一判定 + 授权票据机制）
	let discardTicket: ReturnType<typeof takeDiscardExecutionTicket> = null;
	const isGitProgram = progBaseName === "git";
	const canonical = isGitProgram ? canonicalGitCommand("git", argsRaw) : null;
	if (isGitProgram && canonical !== null && !opts.skipDiscardTicket) {
		const taken = opts.toolCallId !== undefined ? takeDiscardExecutionTicket(opts.toolCallId, { command: canonical, cwd: cwdCheck.linux }) : null;
		if (taken !== null && !("ticket" in taken)) {
			throw new Error(`[win_exec] 丢弃授权凭证与当前命令/工作目录不匹配（${taken.mismatch}）——凭证已作废，命令未执行；请重新取得授权后在相同命令与 cwd 下执行。`);
		}
		if (taken !== null && "ticket" in taken) discardTicket = taken;
		if (discardTicket === null) {
			// 直接 API 面兜底：复用 decideDiscardGate 同一判定（工具链路的确认/授权在 guards tool_call 层完成）
			const { decideDiscardGate, decideStashChainGate } = await import("./git-discard-guard.ts");
			const chain = decideStashChainGate(canonical, cwdCheck.linux);
			if (chain) throw new Error(`[win_exec] ${chain.reason}`);
			const gate = decideDiscardGate(canonical, cwdCheck.linux);
			if (gate && gate.action === "warn") notes.push(`[丢弃改动风险·软提示] ${gate.reason}`);
			else if (gate && gate.action === "block") throw new Error(`[win_exec] ${gate.reason}`);
			else if (gate && gate.action === "confirm") throw new Error(`[win_exec] 检测到将丢弃未提交改动的 Git 操作（${gate.inspection.kindLabel}）——win_exec 通道要求经授权票据执行（Leader 经 /amagi discard-approve 预授权后在相同命令与 cwd 下调用）；无票据不执行。${gate.message.slice(0, 160)}`);
		}
	}

	// 7. env 白名单
	const envCheck = validateEnvPass(params.env, effectiveCfg.envAllow);
	if (!envCheck.ok) throw new Error(`[win_exec] env 拒绝：${envCheck.reason}`);

	// 8. 超时预算
	const longRunning = prog.longRunning === true || (group?.longRunning ?? false);
	const defaultTimeoutS = prog.timeoutS ?? group?.timeoutS ?? (longRunning ? WIN_EXEC_LONGRUN_TIMEOUT_S : effectiveCfg.defaultTimeoutS);
	let timeoutS = params.timeout_s ?? defaultTimeoutS;
	if (typeof timeoutS !== "number" || !(timeoutS > 0)) throw new Error(`[win_exec] timeout_s 须为正数秒（收到 ${JSON.stringify(params.timeout_s)}）`);
	if (timeoutS > effectiveCfg.maxTimeoutS) {
		notes.push(`timeout_s=${timeoutS}s 超上限，已按 windows.exec.maxTimeoutS=${effectiveCfg.maxTimeoutS}s 执行`);
		timeoutS = effectiveCfg.maxTimeoutS;
	}

	// 9. supervised 决策
	const supervised = params.supervised ?? prog.supervised ?? (longRunning || exclusiveName !== undefined);

	// 10. M4：.bat/.cmd 元字符拒绝（cmd.exe 解释面）
	if (prog.launcher === "cmd-c" || (!supervised && /\.(bat|cmd)$/i.test(prog.linuxPath))) {
		const bad = tr.values.find((a) => BAT_METACHAR_RE.test(a));
		if (bad !== undefined) {
			throw new Error(`[win_exec] args 拒绝：.bat/.cmd 经 cmd.exe 执行，参数含命令元字符（& | < > ^ % ! \" ( ) 或换行）会被 cmd 解释——收到 ${JSON.stringify(bad.slice(0, 80))}。请改用 .ps1 脚本（经 powershell -File 中转，参数无 shell 解释面）或调整参数写法去除元字符。`);
		}
	}

	// 11. m4：载荷/命令行长度预检
	const argsLine = buildArgumentsLine(tr.values);
	const payloadB64 = encodeLauncherPayload({ program: prog.windowsPath, argsLine, cwd: cwdCheck.windows, env: envCheck.env });
	if (supervised && payloadB64.length > WINEXEC_PAYLOAD_MAX_B64) {
		throw new Error(`[win_exec] args 拒绝：base64 载荷 ${payloadB64.length} 字符超上限 ${WINEXEC_PAYLOAD_MAX_B64}。请缩减参数，或改用 @response 文件（cmake @file / CMake 预设 / UBT 参数文件）后以文件路径作为唯一参数。`);
	}
	if (tr.values.some((a) => a.length > WIN_COMMAND_LINE_MAX) || `${prog.windowsPath} ${argsLine}`.length > WIN_COMMAND_LINE_MAX) {
		throw new Error(`[win_exec] args 拒绝：单参数或命令行总长超 Windows ${WIN_COMMAND_LINE_MAX} 字符上限。请缩减参数或改用 @response 文件（cmake @file / CMake 预设 / UBT 参数文件）传递长列表。`);
	}

	// 12. 互斥锁 + 起前清扫
	let lock: ExclusiveLockHandle | undefined;
	if (exclusiveName !== undefined) {
		const acq = acquireExclusiveLock(exclusiveName, deps.lockDeps);
		if (!acq.ok) throw new Error(`[win_exec] ${acq.reason}`);
		lock = acq.handle;
		activeLocks.add({ handle: acq.handle, unlink: deps.unlink ?? ((p) => fs.unlinkSync(p)) });
		if (acq.handle.recoveredFromStale) notes.push(`互斥组 "${exclusiveName}" 命中陈旧锁，已自愈接管（${acq.handle.lockPath}）`);
		const sweep = await preSweep(deps, effectiveCfg, roots, group, exclusiveName, params.force_sweep === true, notes);
		if (!sweep.ok) {
			releaseLockEntry(acq.handle);
			throw new Error(`[win_exec] ${sweep.reason}`);
		}
	}

	// 13. M5/M6：起前 PID 快照（killImages ∪ 程序 basename；不可用则记录并如实降级）
	const execAsync = deps.execAsync ?? defaultExecFileAsync;
	const filterImages = [...(group?.killImages ?? []), ...(progBase ? [progBase] : [])];
	let pre: PidSnapshot;
	const tasklistRes = resolveProgram("tasklist", effectiveCfg, roots, internalDeps(deps));
	if (tasklistRes.ok) {
		const rows = await listWindowsTasks(execAsync, tasklistRes.program.linuxPath);
		pre = snapshotOf(rows, filterImages);
	} else {
		pre = { ok: false, reason: "tasklist.exe 不可解析", byImage: new Map(), pids: new Set() };
	}
	if (!pre.ok) notes.push(`PID 快照不可用（${pre.reason}）——超时回收将只终止 relay，${supervised ? "Job Object 语义仍生效但" : ""}Windows 侧新增进程无法差集核验（如实报告未能确认回收）`);

	// 14. relay 与目标命令行组装（锁已持有：此段任何拒绝都必须先释放锁，防止同组此后一直冲突）
	const failRelease = (msg: string): Error => { if (lock !== undefined) releaseLockEntry(lock); return new Error(msg); };
	const spawnFn = deps.spawn ?? nodeSpawn;
	const baseEnv = toolProcessEnv(deps.env ?? process.env);
	let argv0 = prog.linuxPath;
	let argv = tr.values;
	let spawnEnv: NodeJS.ProcessEnv = { ...baseEnv };
	if (!supervised && envCheck.env && Object.keys(envCheck.env).length > 0) {
		for (const [k, v] of Object.entries(envCheck.env)) spawnEnv[k] = v;
		spawnEnv.WSLENV = appendWslenv(spawnEnv.WSLENV, Object.keys(envCheck.env));
	}

	let scriptLinuxPath: string | undefined;
	if (supervised) {
		const powershellRes = resolveProgram("powershell", effectiveCfg, roots, internalDeps(deps));
		if (!powershellRes.ok) throw failRelease(`[win_exec] supervised 模式需要 powershell.exe：${powershellRes.reason}`);
		const scriptDir = pickScriptDir(deps, roots, cwdCheck.linux);
		if (scriptDir === null) throw failRelease("[win_exec] supervised 模式找不到 Windows 可见的脚本落盘目录（LOCALAPPDATA/Temp、USERPROFILE、cwd 目录均不可用）；可显式配置 AMAGI_WIN_* 环境变量");
		const id = `amagi-winexec-${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 8)}`;
		scriptLinuxPath = path.posix.join(scriptDir, `${id}.ps1`);
		const scriptWinPath = linuxToWindowsPathOf(scriptLinuxPath, mntRoot);
		try {
			(deps.writeFile ?? ((p, c) => fs.writeFileSync(p, c, "utf8")))(scriptLinuxPath, buildLauncherScript(payloadB64));
		} catch (e) {
			throw failRelease(`[win_exec] launcher 脚本写入失败（${scriptLinuxPath}）：${e instanceof Error ? e.message : String(e)}`);
		}
		activeScripts.add(scriptLinuxPath);
		argv0 = powershellRes.program.linuxPath;
		argv = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", scriptWinPath];
	} else if (prog.launcher === "cmd-c") {
		const cmdRes = resolveProgram("cmd", effectiveCfg, roots, internalDeps(deps));
		if (!cmdRes.ok) throw failRelease(`[win_exec] .bat/.cmd 需要 cmd.exe 中转：${cmdRes.reason}`);
		argv0 = cmdRes.program.linuxPath;
		argv = ["/d", "/s", "/c", prog.windowsPath, ...tr.values];
	} else if (prog.launcher === "powershell-file") {
		const psRes = resolveProgram("powershell", effectiveCfg, roots, internalDeps(deps));
		if (!psRes.ok) throw failRelease(`[win_exec] .ps1 需要 powershell.exe 中转：${psRes.reason}`);
		argv0 = psRes.program.linuxPath;
		argv = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", prog.windowsPath, ...tr.values];
	}

	const unlinkScript = (): void => {
		if (scriptLinuxPath === undefined) return;
		activeScripts.delete(scriptLinuxPath);
		try { (deps.unlink ?? ((p) => fs.unlinkSync(p)))(scriptLinuxPath); } catch { /* lint-exempt:清理失败 → 临时残留无害 */ }
	};

	// 15a. 后台模式（m3：载荷内嵌脚本——env/载荷不拼进 shell 命令串；完成回调释放锁与脚本）
	if (params.background === true) {
		const command = [argv0, ...argv].map(shQuote).join(" ");
		const onDone = (): void => {
			if (lock !== undefined) releaseLockEntry(lock);
			unlinkScript();
		};
		const runBgStart = deps.runBgStart ?? defaultRunBgStart;
		let startText: string;
		try {
			startText = await runBgStart(command, cwdCheck.linux, timeoutS * 1000, `win_exec ${progBase}`, onDone);
		} catch (e) {
			onDone();
			throw new Error(`[win_exec] 后台启动失败：${e instanceof Error ? e.message : String(e)}`);
		}
		const lines = [
			`[win_exec background] ${progBase} 已交 run_bg 托管（${supervised ? "supervised/Job Object（载荷内嵌脚本）" : "direct"} 模式${exclusiveName ? ` · 互斥组 ${exclusiveName}` : ""} · 预算 ${timeoutS}s）`,
			startText,
		];
		if (notes.length > 0) lines.push(...notes.map((n) => `[注] ${n}`));
		return lines.join("\n");
	}

	// 15b. 前台执行（M9 close 收口；M5/M6 差集回收）
	const startedAt = Date.now();
	const outAcc = new StreamAccumulator({ id: `winexec-${startedAt.toString(36)}` });
	const errAcc = new StreamAccumulator({ id: `winexec-${startedAt.toString(36)}-err` });
	let child: ChildProcess;
	try {
		child = spawnFn(argv0, argv, { cwd: cwdCheck.linux, env: spawnEnv, stdio: ["ignore", "pipe", "pipe"] });
	} catch (e) {
		if (lock !== undefined) releaseLockEntry(lock);
		unlinkScript();
		throw new Error(`[win_exec] spawn 失败（${argv0}）：${e instanceof Error ? e.message : String(e)}（interop 不可用？/amagi win-doctor 核对）`);
	}
	if (typeof child.pid !== "number") {
		if (lock !== undefined) releaseLockEntry(lock);
		unlinkScript();
		throw new Error(`[win_exec] spawn 失败（未获得 pid）：${argv0}`);
	}
	lock?.bindRelay(child.pid); // m1：relay 登记（pi 退出但 relay 活着不判陈旧）
	child.stdout?.on("data", (c: Buffer) => outAcc.push(c));
	child.stderr?.on("data", (c: Buffer) => errAcc.push(c));

	const exitInfo = await runProcessUntilClose(child, {
		timeoutMs: timeoutS * 1000,
		signal: opts.signal,
		onTimeout: () => killTreeSequence(child, pre, filterImages, supervised ? "supervised" : "direct", deps, effectiveCfg, roots, notes, exclusiveName),
		onAbort: () => killTreeSequence(child, pre, filterImages, supervised ? "supervised" : "direct", deps, effectiveCfg, roots, notes, exclusiveName),
	});
	if (lock !== undefined) releaseLockEntry(lock);
	unlinkScript();
	if (discardTicket !== null && "ticket" in discardTicket) {
		try { recordDiscardExecutionOutcome(discardTicket.ticket, { ok: exitInfo.code === 0, ...(exitInfo.code !== 0 ? { errorMessage: `exit=${exitInfo.code}` } : {}) }); } catch { /* lint-exempt:记录失败不掩盖执行结果 */ }
	}

	const elapsedMs = Date.now() - startedAt;
	const decodeFn = (b: Buffer): { text: string; label: string; note?: string } => {
		const d: DecodedWindowsOutput = decodeWindowsOutput(b, { fallbackEncoding: effectiveCfg.fallbackEncoding });
		return { text: d.text, label: describeEncoding(d), ...(d.note ? { note: d.note } : {}) };
	};
	const outFin = outAcc.finalize(decodeFn);
	const errFin = errAcc.finalize(decodeFn);
	const section = (title: string, fin: typeof outFin): string => {
		if (fin.bytes === 0) return `${title}：（空）`;
		return `${title}（${fin.encodingLabel}，${(fin.bytes / 1024).toFixed(1)}KB${fin.truncated ? "，已截断" : ""}${fin.fullOutputPath ? `；全量：${fin.fullOutputPath}` : ""}${fin.droppedBytes > 0 ? `；超 64MB 上限丢弃 ${fin.droppedBytes} 字节` : ""}）：\n${fin.text}`;
	};
	const head = exitInfo.timedOut
		? `[win_exec] 超时（预算 ${timeoutS}s）——relay 已按 SIGTERM→宽限→SIGKILL 终止${supervised ? "，Job Object 关闭连带回收 Windows 进程树" : ""}；PID 快照差集回收结果见注记 · exit=${exitInfo.code ?? "null"} · ${Math.round(elapsedMs / 100) / 10}s · ${supervised ? "supervised" : "direct"} 模式${exclusiveName ? `（组 ${exclusiveName}）` : ""}`
		: `[win_exec] 完成：exit=${exitInfo.error ? "spawn-error" : exitInfo.code} · ${Math.round(elapsedMs / 100) / 10}s · ${supervised ? "supervised" : "direct"} 模式${exclusiveName ? `（组 ${exclusiveName}）` : ""} · ${prog.source}`;
	const lines = [head, `命令行：${prog.windowsPath}${argsLine !== "" ? ` ${argsLine}` : ""}`];
	if (exitInfo.error) lines.push(`spawn 错误：${exitInfo.error.message}`);
	lines.push(section("── stdout", outFin));
	lines.push(section("── stderr", errFin));
	const encNotes = [outFin.encodingNote, errFin.encodingNote].filter((n): n is string => typeof n === "string");
	if (encNotes.length > 0) notes.push(...new Set(encNotes));
	if (notes.length > 0) lines.push(...notes.map((n) => `[注] ${n}`));
	return lines.join("\n");
}

function linuxToWindowsPathOf(p: string, mntRoot: string): string {
	const { linuxToWindowsPath } = winExecPathsMod;
	return linuxToWindowsPath(p, { mntRoot })!;
}
import * as winExecPathsMod from "./win-exec-paths.ts";

/** launcher 脚本落盘目录：LOCALAPPDATA/Temp → USERPROFILE → cwd 目录 → 挂载盘根（首个存在目录；m6 修正 //mnt 拼接）。 */
function pickScriptDir(deps: WinExecToolDeps, roots: WindowsRoots, cwdLinux: string): string | null {
	const exists = deps.existsSync ?? ((p) => { try { fs.statSync(p); return true; } catch { return false; /* lint-exempt:不存在即跳过候选 */ } });
	const isDir = deps.isDirectory ?? ((p) => { try { return fs.statSync(p).isDirectory(); } catch { return false; /* lint-exempt:候选不可达即跳过 */ } });
	const mntRoot = roots.mntRoot.replace(/\/+$/, "");
	const driveRoot = cwdLinux.startsWith(`${mntRoot}/`) && /^\/[A-Za-z]$/.test(cwdLinux.slice(mntRoot.length, mntRoot.length + 2)) ? cwdLinux.slice(0, mntRoot.length + 2) : undefined;
	const candidates = [
		roots.localAppData ? path.posix.join(roots.localAppData, "Temp") : undefined,
		roots.userProfile,
		path.posix.dirname(cwdLinux),
		driveRoot,
	].filter((v): v is string => typeof v === "string");
	for (const c of candidates) {
		if (exists(c) && isDir(c)) return c;
	}
	return null;
}

async function defaultRunBgStart(command: string, cwd: string, timeoutMs: number, label: string, onDone?: () => void): Promise<string> {
	return runBgExecute({ action: "start", command, cwd, timeoutMs, label }, onDone ? { notify: () => onDone() } : {});
}

// ── 工具定义（仅 WSL 注册；非 WSL 返回 undefined） ────────────────────────────

export function createWinExecTool(deps: WinExecToolDeps = {}) {
	const det = detectWslEnvironment({ env: deps.env, platform: deps.platform, readProcVersion: deps.readProcVersion });
	if (!det.wsl) return undefined;
	const sessionCwd = deps.sessionCwd ?? process.cwd();
	const registrationCfg = (deps.configReader ?? ((cwd: string) => readWinExecConfig(cwd)))(sessionCwd);
	const registrationGlobal = deps.globalConfigReader ? deps.globalConfigReader() : (deps.configReader ? emptyWinExecConfig() : readGlobalWinExecConfig(deps.env ?? process.env));
	if (!registrationCfg.enabled || !registrationGlobal.enabled) return undefined;
	return {
		name: "win_exec" as const,
		label: "win_exec",
		description: [
			"在 WSL 会话中受管执行 Windows 原生程序（白名单、可审计；仅 WSL 环境注册）：",
			"cmake/ctest/git/rg 走 NTFS 原生（比挂载根 drvfs 上的 bash 明显快）、UBT Build.bat 与 UE 工具链经 windows.exec.allowRoots 放行（仅受信配置）。",
			"参数逐元素传递不经 shell；挂载路径参数自动翻译；.bat/.cmd 参数含 cmd 元字符拒绝；git -c 配置注入默认拒绝；输出统一解码（GBK/UTF-16/UTF-8）+ 上限/二进制检测。",
			"longRunning/exclusive 程序默认经 Job Object 托管（建链失败即 exit 91）；超时/中止回收=relay 终止 + PID 快照差集 taskkill（只杀本次新增 PID，不动起前同名进程；快照不可用如实报告）。",
			"何时用本工具而非 bash+powershell.exe 全路径：需要 Windows 原生程序、正确编码、超时杀树、UE 编译/编辑器进程管理时；普通 Linux 命令仍用 bash。诊断：/amagi win-doctor。",
		].join(""),
		parameters: WIN_EXEC_PARAMS,
		async execute(toolCallId: string, args: WinExecInput, signal?: AbortSignal, _onUpdate?: unknown, ctx?: unknown) {
			try {
				// M3/M8：每次调用现读配置（信任门按 ctx 判定）——与 shell-env 现读口径一致
				const cfg = (deps.configReader ?? ((cwd: string) => readWinExecConfig(cwd)))(sessionCwd);
				const text = await winExecExecute(args, cfg, deps, { signal, ctx, toolCallId });
				return { content: [{ type: "text" as const, text }] };
			} catch (e) {
				const message = e instanceof Error ? e.message : String(e);
				return { content: [{ type: "text" as const, text: message }], isError: true as const };
			}
		},
	};
}
