/**
 * run-bg.ts — 通用后台命令原语（ev-20260916-99a6cd / P1）。
 *
 * 痛点：无 task 工具的会话（Leader 自身 / AMAGI_SUBAGENT 子进程）跑长 CLI（识图、批处理、
 * 长测试）只有前台 bash 一条路——300s 超时被中止后，实战被迫手工 nohup+while poll 编排
 * ≈25 轮纯等待。本工具把「启动 → 句柄 → 查询/等待 → 结果（日志 tail）」产品化为一个工具，
 * 句柄模型对齐 rpc_task result。
 *
 * 职责边界（与既有原语，注释即文档）：
 *   - run_bg：任意 shell 命令后台化，无模型参与。spawn 为独立进程组（detached 组长），
 *     stdout/stderr 重定向日志文件落盘，立即返回句柄；支持 status/result（可选等待 +
 *     日志 tail）、cancel（组级 SIGTERM→SIGKILL）、timeoutMs 预算（到期组级回收标 timed-out）、
 *     list（跨会话：句柄落盘 index.ndjson，后续会话/Leader 可恢复查看）。
 *   - ev-20260924-12197e：Windows node 预检探针——win32 宿主且命令可执行段首 token 为 node 系时，
 *     start 前同步 node -e 探针（execFile，5s 超时）；失败整单拒绝并建议 WSL/前台（与
 *     ev-20260922-e44fe9 stash 串联门挂同一前置链）；非 node 系命令、非 win32 平台、以及
 *     bash 实际跑在 WSL 的 stdin 传输壳（ev-20260925-287e93，探针与实际执行环境无关）零行为变化。
 *   - ev-20260925-287e93（P1）：spawn 按 getShellConfig().commandTransport 分流——stdin 传输壳
 *     （legacy WSL bash.exe，args=["-s"]）命令经 stdin 管道投递（写后立即 end，与 pi 前台 bash
 *     工具同源语义），argv 传输壳维持 [...args, command] + stdin ignore。此前统一 argv 追加使
 *     `bash -s <cmd>` 的 <cmd> 沦为位置参数永不执行，且 stdin ignore 在 WSL 侧被无控制台分离
 *     进程替换为新 pty → bash 永挂（实战 2/2 挂死、句柄日志 0 字节，与命令内容无关）。
 *   - rpc_task：跑 prompt 任务（复用 pi 会话进程池，有模型参与）；需要"让一个 Agent 干活"
 *     用 rpc_task，需要"让一条命令跑完"用 run_bg。
 *   - task({background:true})：派发完整子 Agent 任务（编排、验收、证据链）；run_bg 只管命令本身。
 *   - watch/dev 型常驻（tsx watch/pnpm dev/vite dev）不适用：无完成态，句柄永远不会 done，
 *     常驻服务走 launchctl/systemd 或手工 nohup（与 rpc_task 同语义限制，watch-probe 共口径）。
 *
 * 通知：完成/超时经构造注入的 notify 回调（index.ts 接 pi.sendMessage steer 通道）尽力而为；
 * 子代理 print 模式进程退出时通知发不出，但句柄与状态已落盘 ndjson，主进程/后续会话
 * run_bg({action:"list"}) 可恢复查看。
 *
 * 开关：AMAGI_RUN_BG_ROOT 覆盖落盘根（缺省 <agentDir>/amagi/data/run-bg，测试注入用）。
 */

import { execFile, spawn, spawnSync, type ChildProcess } from "node:child_process";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { toolProcessEnv } from "./tool-process-env.ts";
// ev-20261020-d56baa：项目 shell.pathPrepend ——run_bg spawn 同源 PATH 前置（与 bash/子 Agent/基线测试共用）
import { envWithPathPrepend, readProjectShellPathPrepend } from "./shell-env.ts";
import { StringEnum } from "@earendil-works/pi-ai";
import { getShellConfig } from "@earendil-works/pi-coding-agent";
import { amagiDataDir } from "./data-dir.ts";
// ev-20260922-e44fe9（B0/P0）：stash 串联门——run_bg 直接 spawn 任意 shell 命令，不经 bash 工具的
// tool_call 钩子链；直接 API 入口在此复用同一门（guards.registerGuards 的 run_bg start 分支为
// 工具链路另一层）。只补串联保护，不重构后台工具权限。
import { decideStashChainGate } from "./git-discard-guard.ts";
// ev-20260924-12197e：Windows node 预检探针——判定用 shell 语义段（与 stash 串联门同源
// analyzeExecutableShell），首 token 提取复用 executableWords 的 wrapper 剥离。
import { analyzeExecutableShell, executableWords } from "./shell-lexer.ts";
// P4（寄生增强方案 §4.2）：结构化输出 wire——纯 schema/投影模块（零 I/O、零 spawn/kill）；
// 本模块经 runBgAction 单次执行内部对象投影接线（错误码语义见 run-bg-wire.ts toRunBgErrorWire）。
import {
	RunBgOutputSchema, toStartWire, toStatusWire, toResultWire, toCancelWire, toListWire, toRunBgErrorWire,
	type RunBgWireOutput, type RunBgRecordSource, type RunBgErrorCode,
} from "./run-bg-wire.ts";

export interface RunBgStartParams {
	action: "start";
	command: string;
	cwd?: string;
	/** 超时预算 ms；缺省不限时（后台长任务语义）；到期组级 SIGKILL 并标记 timed-out。 */
	timeoutMs?: number;
	/** 人读标签（list 输出摘引用）。 */
	label?: string;
}
export interface RunBgHandleParams {
	action: "status" | "result" | "cancel";
	/** run_bg 句柄（start 返回的 bg-xxxx）。 */
	handle: string;
	/** result 专用：至多等待 ms 再返回当前状态（缺省 0=立即返回）。 */
	waitMs?: number;
}
export type RunBgParams = RunBgStartParams | RunBgHandleParams | { action: "list" };

interface RunBgRecord {
	id: string;
	pid: number;
	command: string;
	cwd: string;
	logPath: string;
	label?: string;
	startedAt: number;
	timeoutMs?: number;
	ownerPid: number;
}

interface RunBgState {
	rec: RunBgRecord;
	exitCode?: number | null;
	finishedAt?: number;
	timedOut?: boolean;
	cancelled?: boolean;
}

const POLL_INTERVAL_MS = 200;
/** result 默认 tail 字节（防大日志撑爆上下文；完整日志走 logPath）。 */
const TAIL_BYTES = 4096;
const SIGKILL_GRACE_MS = 2_000;

/** 落盘根：AMAGI_RUN_BG_ROOT（测试注入）→ amagi data 目录下 run-bg/。 */
export function runBgRoot(): string {
	return process.env.AMAGI_RUN_BG_ROOT || path.join(amagiDataDir(), "run-bg");
}

function indexPath(root: string): string {
	return path.join(root, "index.ndjson");
}

function appendEvent(root: string, event: Record<string, unknown>): void {
	try {
		fs.mkdirSync(root, { recursive: true });
		fs.appendFileSync(indexPath(root), `${JSON.stringify(event)}\n`, "utf8");
	} catch { /* 落盘失败不阻断句柄管理（内存态仍可用） */ }
}

/** 会话内句柄表（id → 运行态）。进程退出后句柄即失效——跨会话经 list 读 ndjson 重建。 */
const liveHandles = new Map<string, RunBgState>();
/** 活跃 run_bg 进程 pid 集（orphan 诊断 clean 排除用：run_bg 管的进程不是孤儿）。 */
export function activeRunBgPids(): Set<number> {
	const pids = new Set<number>();
	for (const s of liveHandles.values()) {
		if (s.finishedAt === undefined && Number.isInteger(s.rec.pid) && s.rec.pid > 1) pids.add(s.rec.pid);
	}
	return pids;
}

function isAlive(pid: number): boolean {
	if (!Number.isInteger(pid) || pid <= 1) return false;
	try {
		process.kill(pid, 0);
		return true;
	} catch (e: any) {
		return e?.code === "EPERM";
	}
}

/** 组级终止（SIGTERM → 宽限 → SIGKILL；组空 ESRCH 静默回退单 pid，与 killProcessTree 同型）。 */
async function killGroup(pgid: number): Promise<void> {
	const killBoth = (sig: NodeJS.Signals): void => {
		try { process.kill(-pgid, sig); } catch { try { process.kill(pgid, sig); } catch { /* ESRCH：已死 */ } }
	};
	killBoth("SIGTERM");
	await new Promise((r) => setTimeout(r, SIGKILL_GRACE_MS));
	killBoth("SIGKILL");
}

function stateOf(s: RunBgState, now = Date.now()): { state: string; exitCode?: number | null; elapsedMs: number } {
	if (s.cancelled) return { state: "cancelled", elapsedMs: (s.finishedAt ?? now) - s.rec.startedAt };
	if (s.timedOut) return { state: "timed-out", exitCode: s.exitCode, elapsedMs: (s.finishedAt ?? now) - s.rec.startedAt };
	if (s.finishedAt !== undefined) {
		const ok = s.exitCode === 0;
		return { state: ok ? "done" : "failed", exitCode: s.exitCode, elapsedMs: s.finishedAt - s.rec.startedAt };
	}
	if (s.rec.ownerPid !== process.pid || isAlive(s.rec.pid)) {
		return { state: "running", elapsedMs: now - s.rec.startedAt };
	}
	// 同进程登记但无 exit 事件且已死：按未知退出收口（进程被外部 kill 等）
	return { state: "failed", exitCode: s.exitCode ?? null, elapsedMs: now - s.rec.startedAt };
}

/** 读日志尾部（缺省 4KB；文件不存在 → null）。P4：同次读取附带 truncated（st.size>bytes）——
 *  正文与 wire 同源，不二次读盘。 */
function tailLog(logPath: string, bytes = TAIL_BYTES): { text: string; truncated: boolean } | null {
	try {
		const st = fs.statSync(logPath);
		const fh = fs.openSync(logPath, "r");
		try {
			const start = Math.max(0, st.size - bytes);
			const buf = Buffer.alloc(st.size - start);
			fs.readSync(fh, buf, 0, buf.length, start);
			return { text: buf.toString("utf8"), truncated: start > 0 };
		} finally {
			fs.closeSync(fh);
		}
	} catch {
		return null;
	}
}

export interface RunBgToolDeps {
	/** 完成/超时通知回调（尽力而为；缺省不发）。 */
	notify?: (text: string) => void;
	/** 测试注入：宿主平台（ev-20260924-12197e Windows node 预检门控；缺省 process.platform）。 */
	platform?: NodeJS.Platform;
	/** 测试注入：Windows node 探针 runner（缺省真实 execFile node；注入路径不走进程内缓存）。 */
	winNodeProbe?: () => Promise<WinNodeProbeResult>;
	/** ev-20260925-287e93 测试注入：shell 配置（缺省 getShellConfig()）——stdin 传输壳
	 * （legacy WSL bash）的 spawn 分流与探针门控行为可测。 */
	getShellConfig?: () => { shell: string; args: string[]; commandTransport?: "argv" | "stdin" };
}

function shortCmd(command: string): string {
	const original = String(command || ""), compact = original.replace(/\s+/g, " ").trim();
	const chars = Array.from(compact);
	return chars.length <= 48 ? compact : `${chars.slice(0, 48).join("")}…（原命令 ${Array.from(original).length} 字符；完整命令用 run_bg result 查看）`;
}

// ── ev-20260924-12197e：Windows node 预检探针（纯判定 + 探针 runner） ──────────
// 实证（2026-09-24）：win32 宿主 run_bg detached（无控制台进程组）下 node 系命令 6/6 失败或挂起
// （npx exit 3221225786=0xC0000142 DLL 初始化失败 / npm run test 240-300s 超时零输出 /
// 最小探针 node -e 也挂起），同命令 WSL 侧全部正常。本节把定论前置为 start 前同步探针，
// 免去使用者多轮探针排查（当次损耗 5-6 轮 + 15 分钟）。

/** node 系可执行 basename 名单（node 运行时与包管理/启动入口；.exe/.cmd/.bat/.ps1 变体兼容）。 */
const WIN_NODE_FAMILY = new Set(["node", "npx", "npm", "pnpm", "yarn", "nodemon", "tsx"]);
const WIN_NODE_EXTS = new Set([".exe", ".cmd", ".bat", ".ps1"]);

/** 判定单个可执行词是否 node 系：basename（Windows/POSIX 分隔兼容）剥允许扩展名后小写匹配。 */
export function isNodeFamilyExecutable(word: string): boolean {
	const base = String(word || "").split(/[\\/]/).pop()!.toLowerCase();
	const dot = base.lastIndexOf(".");
	const stem = dot > 0 && WIN_NODE_EXTS.has(base.slice(dot)) ? base.slice(0, dot) : base;
	return WIN_NODE_FAMILY.has(stem);
}

/** 命令是否需要 Windows node 探针：shell 语义段（与 stash 串联门同源 analyzeExecutableShell，
 *  executableWords 剥 wrapper 后）任一可执行段首 token 命中 node 系——串联命令
 *  （`cd webui && npx vite build`）中的 node 段同样受害，只看第一段会漏拦。 */
export function commandNeedsWinNodeProbe(command: string): boolean {
	try {
		for (const segment of analyzeExecutableShell(command).segments) {
			const words = executableWords(segment.map((t) => t.text), true);
			if (words[0] && isNodeFamilyExecutable(words[0])) return true;
		}
	} catch { /* lint-exempt:lexer 有界安全网——解析异常按不需探针处理（不误伤非 node 命令，ev-20260924-12197e） */ }
	return false;
}

export interface WinNodeProbeResult {
	ok: boolean;
	/** missing（node 不在 PATH）/ timeout（挂起）/ exit（非零退出，0xC0000142 类）/ spawn-error。 */
	kind: "ok" | "missing" | "timeout" | "exit" | "spawn-error";
	/** 人读细节（拒绝文案直引；missing/timeout 分别落「node 缺失」「node 挂起」词面）。 */
	detail?: string;
	exitCode?: number;
}

export const WIN_NODE_PROBE_MS = 5_000;

/** 真实探针：execFile `node -e "process.exit(0)"`（timeout 5s）。任何失败不抛出，归类返回。 */
export function runWinNodeProbe(): Promise<WinNodeProbeResult> {
	return new Promise((resolve) => {
		execFile("node", ["-e", "process.exit(0)"], { timeout: WIN_NODE_PROBE_MS, windowsHide: true }, (err) => {
			if (!err) return resolve({ ok: true, kind: "ok" });
			const e = err as NodeJS.ErrnoException & { killed?: boolean; signal?: string };
			if (e.code === "ENOENT") return resolve({ ok: false, kind: "missing", detail: "node 缺失（PATH 中找不到 node 可执行，ENOENT）" });
			if (e.killed || e.signal) return resolve({ ok: false, kind: "timeout", detail: `node 挂起（${WIN_NODE_PROBE_MS}ms 探针超时未退出）` });
			if (typeof e.code === "number") {
				const hex = e.code === 0xC0000142 ? "（0xC0000142 DLL 初始化失败）" : "";
				return resolve({ ok: false, kind: "exit", exitCode: e.code, detail: `node 异常退出 exit=${e.code}${hex}` });
			}
			return resolve({ ok: false, kind: "spawn-error", detail: `探针 spawn 异常：${String(e.message || e).slice(0, 200)}` });
		});
	});
}

const WIN_NODE_PROBE_CACHE_MS = 60_000;
let winNodeProbeCache: { at: number; result: WinNodeProbeResult } | undefined;

/** 默认探针路径的 60s 进程内缓存（成本 ~几十 ms，不缓存也可；失败也缓存——修复路径是换环境
 *  而非原地自愈）；注入 runner（测试）不走此缓存，避免跨用例污染。 */
async function cachedWinNodeProbe(): Promise<WinNodeProbeResult> {
	if (winNodeProbeCache && Date.now() - winNodeProbeCache.at < WIN_NODE_PROBE_CACHE_MS) return winNodeProbeCache.result;
	const result = await runWinNodeProbe();
	winNodeProbeCache = { at: Date.now(), result };
	return result;
}

/** 探针失败拒绝文案（isError 语义与既有 start 失败一致：throw 后由工具层转错误回执）。 */
export function winNodeProbeRefusalText(probe: WinNodeProbeResult): string {
	const reason = probe.ok ? "探针返回 ok（不应构造拒绝文案）" : (probe.detail || probe.kind);
	return [
		`[run_bg] Windows node 预检失败，已拒绝后台启动（探针 node -e "process.exit(0)"：${reason}）。`,
		"本机实证：Windows 无控制台进程组（detached）下 node 系命令不可用——npx 0xC0000142 DLL 初始化失败 / npm 长挂起零输出（ev-20260924-12197e）。",
		"建议：改在 WSL 侧执行（bash 工具，同命令实证正常）或前台跑；本环境不要用 run_bg 后台化 node 系命令。",
	].join("\n");
}

/** 工具内失败（携 wire 错误码）：runBgExecute/直调路径照常 throw（消息字节不变——旧契约）；
 *  createRunBgTool 捕获转带内错误返回（复刻宿主对抛错的归一形状 + structuredContent Failure，P4）。 */
export class RunBgToolError extends Error {
	readonly code: RunBgErrorCode;
	constructor(message: string, code: RunBgErrorCode) {
		super(message);
		this.name = "RunBgToolError";
		this.code = code;
	}
}

/** 单次执行产物（P4 wire 源）：正文 + 同次执行的 wire 投影（runBgExecute 只取 text——旧签名不变；
 *  createRunBgTool 双载体消费两者）。 */
export interface RunBgActionOutcome {
	text: string;
	wire: RunBgWireOutput;
}

/** RunBgRecord + RunBgState + stateOf 产物 → run-bg-wire 投影源（单次读取直投影，U13）。 */
function recordSourceOf(rec: RunBgRecord, st: RunBgState, stt: ReturnType<typeof stateOf>): RunBgRecordSource {
	return {
		handle: rec.id,
		state: stt.state,
		pid: rec.pid,
		ownerPid: rec.ownerPid,
		exitCode: st.exitCode ?? null,
		timedOut: st.timedOut === true,
		cancelled: st.cancelled === true,
		command: rec.command,
		label: rec.label ?? null,
		logPath: rec.logPath,
		startedAt: rec.startedAt,
		timeoutMs: rec.timeoutMs ?? null,
		finishedAt: st.finishedAt ?? null,
		elapsedMs: stt.elapsedMs,
	};
}

/** 工具实现主体（纯逻辑可直测：不依赖 pi ExtensionAPI 形态）。旧签名/旧契约不变——返回正文
 *  字符串、失败 throw（直调层与既有测试消费者）；P4 wire 消费走 runBgAction。 */
export async function runBgExecute(params: RunBgParams, deps: RunBgToolDeps = {}): Promise<string> {
	return (await runBgAction(params, deps)).text;
}

/** 单次执行主体（P4）：正文 + wire 双产物——同一次执行的内部对象（RunBgRecord/RunBgState/
 *  stateOf/tailLog）单次读取投影为 wire，不重复 spawn/cancel/tail（§4.1「加 wire 不能让写动作
 *  重复执行以取得结构」）。 */
async function runBgAction(params: RunBgParams, deps: RunBgToolDeps = {}): Promise<RunBgActionOutcome> {
	const root = runBgRoot();
	if (params.action === "start") {
		const command = String(params.command || "").trim();
		if (!command) throw new RunBgToolError("run_bg start 需要 command（shell 命令串）", "invalid-input");
		if (/^(?:nohup\s+)?\S*(?:watch|dev|serve)\b/.test(command) === false && params.timeoutMs !== undefined) {
			if (!(Number.isFinite(params.timeoutMs) && params.timeoutMs > 0)) {
				throw new RunBgToolError(`run_bg timeoutMs 须为正数毫秒（收到 ${JSON.stringify(params.timeoutMs)}）；不限时请省略`, "invalid-input");
			}
		}
		const baseCwd = process.cwd();
		const cwdRaw = params.cwd?.trim();
		let cwd = baseCwd;
		if (cwdRaw) {
			const resolved = path.isAbsolute(cwdRaw) ? cwdRaw : path.resolve(baseCwd, cwdRaw);
			let st: fs.Stats;
			try { st = fs.statSync(resolved); } catch {
				throw new RunBgToolError(`[run_bg] cwd "${cwdRaw}"（解析为 ${resolved}）不存在；请提供存在的目录或省略 cwd`, "invalid-input");
			}
			if (!st.isDirectory()) throw new RunBgToolError(`[run_bg] cwd "${cwdRaw}"（解析为 ${resolved}）不是目录`, "invalid-input");
			cwd = resolved;
		}
		// ev-20260922-e44fe9（B0/P0）：stash 串联门——cwd 确认后、创建日志/启动进程前；命中整单拒绝
		// （未产生任何后台进程/日志/句柄记录），不被 AMAGI_GIT_DISCARD_POLICY 豁免。
		const stashChain = decideStashChainGate(command, cwd);
		if (stashChain) throw new RunBgToolError(stashChain.reason, "permission");
		// ev-20260924-12197e：Windows node 预检——同 stash 串联门的前置链（其后、日志/句柄/spawn 前），
		// 失败整单拒绝：零后台进程、零日志文件、零句柄记录（isError 语义与既有 start 失败一致）。
		// ev-20260925-287e93：探针只测 Windows 宿主 node（分离进程无控制台 → 0xC0000142）——双宿主
		// （win32 宿主 + bash 实际跑在 WSL 的 stdin 传输壳）下命令与 node 都在 WSL 内执行，Windows 侧
		// 探针结果与实际执行环境无关且会误拒合法命令：仅 Windows 原生 shell（commandTransport !==
		// "stdin"）时门控。shellConfig 在此先行解析（spawn 复用同一份）。
		const shellConfig = deps.getShellConfig ? deps.getShellConfig() : getShellConfig();
		if (
			(deps.platform ?? process.platform) === "win32" &&
			shellConfig.commandTransport !== "stdin" &&
			commandNeedsWinNodeProbe(command)
		) {
			const probe = deps.winNodeProbe ? await deps.winNodeProbe() : await cachedWinNodeProbe();
			if (!probe.ok) throw new RunBgToolError(winNodeProbeRefusalText(probe), "permission");
		}
		const id = `bg-${crypto.randomBytes(4).toString("hex")}`;
		fs.mkdirSync(root, { recursive: true });
		const logPath = path.join(root, `${id}.log`);
		const fd = fs.openSync(logPath, "a");
		let proc: ChildProcess;
		try {
			// ev-20260925-287e93（P1）：按 commandTransport 分流（对齐 pi core/tools/bash.js 前台语义）。
			// stdin 传输壳（legacy WSL bash.exe）：命令必须经 stdin 管道投递——argv 追加只会让
			// `bash -s <cmd>` 的 <cmd> 沦为 $1 永不执行；且 stdin="ignore" 在 WSL 侧被无控制台分离
			// 进程替换为新 pty → bash 在 TTY 上等输入直到永远。分离进程持有管道读端：写入+end 后
			// 读完脚本即执行，EOF 收口。argv 传输壳（bash -c 等）：命令作末位 argv、stdin 关闭（原样）。
			const stdinTransport = shellConfig.commandTransport === "stdin";
			// ev-20261020-d56baa：按 cwd 读项目 shell.pathPrepend 前置 PATH（幂等去重；spawn 副本注入，
			// 不改 process.env）——run_bg exit 127（用户级工具链不在 PATH）不再需要每次手动 export。
			proc = spawn(shellConfig.shell, stdinTransport ? shellConfig.args : [...shellConfig.args, command], {
				cwd,
				detached: true, // 独立进程组：本 pi 进程退出/被杀不连坐，cancel/timeout 按 -pgid 组级回收
				env: envWithPathPrepend(toolProcessEnv(process.env), readProjectShellPathPrepend(cwd).dirs),
				stdio: [stdinTransport ? "pipe" : "ignore", fd, fd],
			});
			if (stdinTransport) {
				proc.stdin?.on("error", () => { /* 子进程先退出（EPIPE）：exit 事件收口，不重复报错 */ });
				proc.stdin?.end(command);
			}
		} finally {
			// fd 所有权已移交子进程（spawn 完成）；父进程侧描述符可关（子进程持有自己的副本）
			fs.closeSync(fd);
		}
		if (typeof proc.pid !== "number") {
			throw new RunBgToolError(`[run_bg] spawn 失败（未获得 pid）：${shortCmd(command)}`, "operation");
		}
		proc.unref();
		const rec: RunBgRecord = {
			id, pid: proc.pid, command, cwd, logPath,
			...(params.label ? { label: String(params.label).slice(0, 60) } : {}),
			startedAt: Date.now(),
			...(params.timeoutMs !== undefined ? { timeoutMs: params.timeoutMs } : {}),
			ownerPid: process.pid,
		};
		const st: RunBgState = { rec };
		liveHandles.set(id, st);
		appendEvent(root, { t: "start", ...rec });
		const finish = (patch: { exitCode?: number | null; timedOut?: boolean; cancelled?: boolean }): void => {
			if (st.finishedAt !== undefined) return;
			st.finishedAt = Date.now();
			if (patch.exitCode !== undefined) st.exitCode = patch.exitCode;
			if (patch.timedOut) st.timedOut = true;
			if (patch.cancelled) st.cancelled = true;
			appendEvent(root, { t: "exit", id, at: st.finishedAt, exitCode: st.exitCode ?? null, ...(st.timedOut ? { timedOut: true } : {}), ...(st.cancelled ? { cancelled: true } : {}) });
			liveHandles.delete(id);
			try {
				deps.notify?.(`[run_bg 完成] ${id}（${shortCmd(command)}）→ ${stateOf(st).state}${st.exitCode !== undefined ? ` exit=${st.exitCode}` : ""}；日志 ${logPath}；run_bg({ action: "result", handle: "${id}" }) 查看结果`);
			} catch { /* 通知失败静默 */ }
		};
		proc.once("exit", (code) => finish({ exitCode: code }));
		proc.once("error", () => finish({ exitCode: null }));
		if (rec.timeoutMs !== undefined) {
			const timer = setTimeout(() => {
				if (st.finishedAt !== undefined) return;
				st.timedOut = true;
				void killGroup(rec.pid).then(() => {
					// exit 事件兜底：组死透仍无事件（极端：信号丢失/事件循环压力）时手动收口，防句柄永挂
					setTimeout(() => {
					if (st.finishedAt === undefined) finish({ exitCode: st.exitCode ?? null, timedOut: true });
					}, 1_000).unref?.();
				});
			}, rec.timeoutMs);
			timer.unref?.();
		}
		const text = [
			`[run_bg start ${id}] 已后台启动（独立进程组，pid=${rec.pid}）。`,
			`命令：${shortCmd(command)}`,
			`日志：${logPath}（tail -f 可看进度；result 自带尾部 ${TAIL_BYTES / 1024}KB 摘要）`,
			`查询：run_bg({ action: "result", handle: "${id}", waitMs: 5000 })（等待+结果）；run_bg({ action: "status", handle: "${id}" }) 只看状态`,
			`取消：run_bg({ action: "cancel", handle: "${id}" })（组级回收）`,
			rec.timeoutMs !== undefined ? `预算：${rec.timeoutMs}ms 超时自动组级回收（结果标 timed-out）` : "预算：未限时（长任务语义；建议对不可控命令给 timeoutMs）",
			"注意：watch/dev 型常驻不适用 run_bg（无完成态）；常驻服务走 launchctl/systemd 或 nohup。",
		].join("\n");
		return { text, wire: toStartWire(recordSourceOf(rec, st, stateOf(st))) };
	}

	if (params.action === "list") {
		// 本进程内存态 + ndjson 落盘态合并（跨会话恢复视图；同 id 内存优先）
		const merged = new Map<string, RunBgState>();
		try {
			const lines = fs.readFileSync(indexPath(root), "utf8").split("\n").filter(Boolean);
			for (const line of lines) {
				let ev: any;
				try { ev = JSON.parse(line); } catch { continue; }
				if (!ev || typeof ev.id !== "string") continue;
				if (ev.t === "start") {
					merged.set(ev.id, { rec: ev as unknown as RunBgRecord });
				} else if (ev.t === "exit" && merged.has(ev.id)) {
					const s = merged.get(ev.id)!;
					s.finishedAt = Number(ev.at) || undefined;
					s.exitCode = ev.exitCode;
					if (ev.timedOut) s.timedOut = true;
					if (ev.cancelled) s.cancelled = true;
				}
			}
		} catch { /* 无落盘记录 → 只看内存 */ }
		for (const [id, s] of liveHandles) merged.set(id, s);
		const rows = [...merged.values()]
			.sort((a, b) => b.rec.startedAt - a.rec.startedAt)
			.slice(-30);
		if (!rows.length) {
			return { text: "[run_bg list] 无记录（本会话未启动，落盘 index.ndjson 亦为空）。", wire: toListWire([], 0, false) };
		}
		const projected = rows.map((s) => ({ s, stt: stateOf(s) })); // stateOf 单次计算：正文行与 wire 同源
		const lines = projected.map(({ s, stt }) => {
			const age = Math.round((Date.now() - s.rec.startedAt) / 1000);
			return `- ${s.rec.id} ${stt.state}${stt.exitCode !== undefined ? ` exit=${stt.exitCode}` : ""} ${age}s前启动 pid=${s.rec.pid}${s.rec.ownerPid !== process.pid ? `（owner pid ${s.rec.ownerPid}${isAlive(s.rec.ownerPid) ? " 存活" : " 已退出"}）` : ""}：${s.rec.label ? `[${s.rec.label}] ` : ""}${shortCmd(s.rec.command)}`;
		});
		return {
			text: `[run_bg list] ${rows.length} 条（最近 30；跨会话含落盘记录）：\n${lines.join("\n")}\n结果查看：run_bg({ action: "result", handle: "..." })`,
			wire: toListWire(projected.map(({ s, stt }) => recordSourceOf(s.rec, s, stt)), rows.length, merged.size > rows.length),
		};
	}

	// status / result / cancel：均需 handle
	const handle = String((params as RunBgHandleParams).handle || "").trim();
	if (!handle) throw new RunBgToolError(`run_bg ${params.action} 需要 handle（start 返回的 bg-xxxx）`, "invalid-input");
	let st = liveHandles.get(handle);
	if (!st) {
		// 跨会话/他进程启动的句柄：从 ndjson 恢复只读视图。cancel 经命令指纹校验后可跨进程组级回收
		// （ev-20261005-487de8：会话重启后注册表残留/元数据 pid 与实际运行 pid 失配，旧语义拒绝跨进程
		// cancel，只能 ps+kill 手工回收；指纹校验保留防 pid 复用误杀语义）；跨会话清理另走 orphans 诊断。
		st = rebuildFromIndex(root, handle);
		if (!st) throw new RunBgToolError(`[run_bg] 句柄 ${handle} 不存在（本会话与落盘 index 均无记录）；run_bg({ action: "list" }) 查看全部句柄`, "not-found");
		if (params.action === "cancel") {
			if (st.finishedAt !== undefined) {
				const stt0 = stateOf(st);
				return { text: `[run_bg cancel ${handle}] 已结束（${stt0.state}），无需取消。`, wire: toCancelWire(recordSourceOf(st.rec, st, stt0)) };
			}
			if (!crossProcessCancelEnabled()) {
				throw new RunBgToolError(`[run_bg] 句柄 ${handle} 由 pid ${st.rec.ownerPid}（${isAlive(st.rec.ownerPid) ? "仍存活" : "已退出"}）启动，跨进程 cancel 已被 AMAGI_RUN_BG_XPROC_CANCEL=0 关闭（旧语义）；残留走 /amagi orphans 诊断`, "permission");
			}
			const verdict = crossProcessCancelVerdict(st.rec);
			if (!verdict.ok) {
				throw new RunBgToolError(`[run_bg] 跨进程 cancel ${handle} 被拒：${verdict.reason}（原记录：pid=${st.rec.pid}，owner pid=${st.rec.ownerPid}）`, "permission");
			}
			appendEvent(root, { t: "cancel", id: handle, at: Date.now() });
			void killGroup(st.rec.pid);
			st.cancelled = true; // diting F-07：本地视图同步（后续同句柄 status/result 不再报 running）
			const stt0 = stateOf(st);
			return { text: `[run_bg cancel ${handle}] 跨进程回收：pid ${st.rec.pid} 命令指纹匹配（${shortCmd(st.rec.command)}），已发 SIGTERM（${SIGKILL_GRACE_MS / 1000}s 宽限后 SIGKILL）；状态稍后经 status 确认。`, wire: toCancelWire(recordSourceOf(st.rec, st, stt0)) };
		}
	}

	if (params.action === "cancel") {
		if (st.finishedAt !== undefined) {
			const stt = stateOf(st);
			return { text: `[run_bg cancel ${handle}] 已结束（${stt.state}），无需取消。`, wire: toCancelWire(recordSourceOf(st.rec, st, stt)) };
		}
		st.cancelled = true;
		appendEvent(root, { t: "cancel", id: handle, at: Date.now() });
		void killGroup(st.rec.pid);
		const stt = stateOf(st);
		return { text: `[run_bg cancel ${handle}] 已对进程组 ${st.rec.pid} 发 SIGTERM（${SIGKILL_GRACE_MS / 1000}s 宽限后 SIGKILL）；状态稍后经 status 确认。`, wire: toCancelWire(recordSourceOf(st.rec, st, stt)) };
	}

	const waitMs = params.action === "result" ? Math.max(0, Number(params.waitMs) || 0) : 0;
	if (waitMs > 0) {
		const deadline = Date.now() + waitMs;
		while (st.finishedAt === undefined && Date.now() < deadline) {
			await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
		}
	}
	const stt = stateOf(st);
	const tail = params.action === "result" ? tailLog(st.rec.logPath) : null;
	const head = `[run_bg ${params.action} ${handle}] ${stt.state}${stt.exitCode !== undefined ? ` exit=${stt.exitCode}` : ""}（${Math.round(stt.elapsedMs / 1000)}s · pid=${st.rec.pid}）`;
	const cmdLine = params.action === "result" ? `完整命令：${st.rec.command}` : `命令：${shortCmd(st.rec.command)}`;
	if (tail === null) {
		return {
			text: `${head}\n${cmdLine}\n日志：${st.rec.logPath}（暂不可读/尚无输出）`,
			wire: params.action === "result"
				? toResultWire(recordSourceOf(st.rec, st, stt), null, false)
				: toStatusWire(recordSourceOf(st.rec, st, stt)),
		};
	}
	return {
		text: `${head}\n${cmdLine}\n日志尾部（${TAIL_BYTES / 1024}KB，完整：${st.rec.logPath}）：\n${tail.text}`,
		wire: toResultWire(recordSourceOf(st.rec, st, stt), tail.text, tail.truncated),
	};
}

/** ev-20261005-487de8：跨进程 cancel 开关（缺省开；AMAGI_RUN_BG_XPROC_CANCEL=0 关闭回旧行为）。 */
export function crossProcessCancelEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const raw = env.AMAGI_RUN_BG_XPROC_CANCEL;
	return !(raw === "0" || raw?.toLowerCase() === "off");
}

/** ev-20261005-487de8：pid 命令行读取（进程组 leader 的 ps -o command=）——不可读返回 null。 */
export function pidCommandFingerprint(pid: number): string | null {
	if (!Number.isInteger(pid) || pid <= 1) return null;
	try {
		const res = spawnSync("ps", ["-o", "command=", "-p", String(pid)], { encoding: "utf8", timeout: 5000 });
		if (res.error || res.status !== 0) return null;
		const line = (res.stdout || "").trim();
		return line || null;
	} catch { /* lint-exempt:ps 探测异常→指纹不可读（调用方拒绝发信号，fail-closed） */ return null; }
}

/** ev-20261005-487de8（diting F-06）：pid 进程启动时刻读取（ps -o lstart=）——不可读/不可解析返回 null。 */
export function pidStartEpochMs(pid: number): number | null {
	if (!Number.isInteger(pid) || pid <= 1) return null;
	try {
		const res = spawnSync("ps", ["-o", "lstart=", "-p", String(pid)], { encoding: "utf8", timeout: 5000 });
		if (res.error || res.status !== 0) return null;
		const t = Date.parse((res.stdout || "").trim());
		return Number.isFinite(t) ? t : null;
	} catch { /* lint-exempt:ps 探测异常→不可读（fail-closed 拒绝发信号） */ return null; }
}

/** ev-20261005-487de8：命令指纹归一——剥引号（sh -c 展开后 argv 无引号，原始命令串有）+
 *  空白归一，使比对对引号差异免疫。 */
export function normalizeCommandFingerprint(s: string): string {
	return s.replace(/["'`]/g, " ").replace(/\s+/g, " ").trim();
}

/** ev-20261005-487de8（diting F-06）：跨进程 cancel 资格判定——三重校验全部通过才允许组级回收：
 *  ①pid 存活；②命令行归一化后以 `sh -c <原始命令>` 形态**精确收尾**（子串包含可被相似命令欺骗——
 *  实测 `…; <原命令>` 前缀注入仍 includes 命中；shell argv 形态 [sh,-c,command] 使 endsWith 精确）；
 *  ③进程启动时刻在句柄 startedAt 容差窗口内（±10s——pid 复用后新进程启动时刻必然晚于原句柄
 *  记录时刻，命令巧合相似也无法通过时间窗口）。任一失败如实拒绝（已退出/复用嫌疑/不可读）。 */
export function crossProcessCancelVerdict(rec: Readonly<RunBgRecord>): { ok: true } | { ok: false; reason: string } {
	if (!isAlive(rec.pid)) return { ok: false, reason: `pid ${rec.pid} 已退出（无需回收；残留遗孤走 /amagi orphans 诊断）` };
	const cmdLine = pidCommandFingerprint(rec.pid);
	const wanted = normalizeCommandFingerprint(rec.command);
	if (cmdLine === null) return { ok: false, reason: `pid ${rec.pid} 命令行不可读（无法排除 pid 复用，拒绝发信号；人工核对：ps -o command= -p ${rec.pid}）` };
	const normalized = normalizeCommandFingerprint(cmdLine);
	if (!(normalized === wanted || normalized.endsWith(`-c ${wanted}`))) {
		return { ok: false, reason: `pid ${rec.pid} 命令指纹不匹配（疑似 pid 复用/相似命令欺骗，拒绝误杀；实际：${cmdLine.slice(0, 120)}）` };
	}
	const started = pidStartEpochMs(rec.pid);
	if (started === null) return { ok: false, reason: `pid ${rec.pid} 启动时刻不可读（无法排除 pid 复用，拒绝发信号；人工核对：ps -o lstart= -p ${rec.pid}）` };
	if (Math.abs(started - rec.startedAt) > 10_000) {
		return { ok: false, reason: `pid ${rec.pid} 启动时刻 ${new Date(started).toISOString()} 超出句柄记录时刻容差（pid 复用嫌疑，拒绝误杀）` };
	}
	return { ok: true };
}

/** 从落盘 index 恢复单句柄只读视图（无 → undefined）。 */
function rebuildFromIndex(root: string, handle: string): RunBgState | undefined {
	try {
		const lines = fs.readFileSync(indexPath(root), "utf8").split("\n").filter(Boolean);
		let rec: RunBgRecord | undefined;
		let exitEv: any;
		let cancelAt: number | undefined;
		for (const line of lines) {
			let ev: any;
			try { ev = JSON.parse(line); } catch { continue; }
			if (!ev || ev.id !== handle) continue;
			if (ev.t === "start") rec = ev as unknown as RunBgRecord;
			if (ev.t === "exit") exitEv = ev;
			if (ev.t === "cancel") cancelAt = Number(ev.at) || undefined;
			if (ev.t === "cancel" && rec) rec = { ...rec };
		}
		if (!rec) return undefined;
		const s: RunBgState = { rec };
		// diting F-07：cancel 事件语义消费——跨进程视图重建后取消态如实呈现：pid 已死 → 终态 cancelled；
		// pid 仍活（组信号宽限中）→ cancelled 中间态（旧实现只做 rec 浅拷贝，cancel 后 status 永远 running）。
		if (cancelAt !== undefined) {
			s.cancelled = true;
			if (!isAlive(rec.pid)) { s.finishedAt = cancelAt; }
		}
		if (exitEv) {
			s.finishedAt = Number(exitEv.at) || undefined;
			s.exitCode = exitEv.exitCode;
			if (exitEv.timedOut) s.timedOut = true;
			if (exitEv.cancelled) s.cancelled = true;
		}
		return s;
	} catch {
		return undefined;
	}
}

/** 测试辅助：清空会话内句柄表与探针缓存（不杀进程）。 */
export function resetRunBgForTest(): void {
	liveHandles.clear();
	winNodeProbeCache = undefined;
}

/** 创建 run_bg 工具定义（pi ExtensionAPI 注册形态）。 */
export function createRunBgTool(deps: RunBgToolDeps = {}) {
	return {
		name: "run_bg" as const,
		label: "run_bg",
		description: [
			"通用后台命令原语：把一次性长 CLI/脚本后台化（独立进程组+日志落盘），返回句柄后立即继续，",
			"稍后 result 查询（可选等待+日志尾部）、cancel 组级取消、timeoutMs 超时预算。",
			"职责边界：跑 shell 命令无模型参与（跑 prompt 任务用 rpc_task；完整子 Agent 任务用 task background）；",
			"watch/dev 常驻不适用（无完成态）。",
		].join(""),
		promptSnippet: `run_bg({ action: "start", command: "..." }) → run_bg({ action: "result", handle: "bg-...", waitMs })`,
		parameters: Type.Object({
			action: StringEnum(["start", "status", "result", "cancel", "list"]),
			command: Type.Optional(Type.String({ description: "start：shell 命令串" })),
			handle: Type.Optional(Type.String({ description: "status/result/cancel：start 返回的句柄 bg-xxxx" })),
			cwd: Type.Optional(Type.String({ description: "start：工作目录（存在的目录；缺省当前 cwd）" })),
			timeoutMs: Type.Optional(Type.Number({ description: "start：超时预算毫秒（缺省不限时）；到期组级回收标 timed-out" })),
			waitMs: Type.Optional(Type.Number({ description: "result：至多等待毫秒后返回（缺省立即）" })),
			label: Type.Optional(Type.String({ description: "start：人读标签（list 摘引）" })),
		}),
		/** P4（寄生增强方案 §4.2）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema：TSchema）。
		 *  声明后 execute 成功/失败均携 structuredContent（六封闭分支 Union）；消费者判据
		 *  kind/wireVersion/action/ok/schemaVersion。正文 content 契约字节不变。 */
		outputSchema: RunBgOutputSchema,
		async execute(_toolCallId: string, params: RunBgParams) {
			try {
				const { text, wire } = await runBgAction(params, deps);
				return { content: [{ type: "text" as const, text }], structuredContent: wire };
			} catch (e) {
				// 工具内失败双载体（§4.4 codemode 行：Failure resolve 与宿主拒绝 reject 成对）：
				// 正文复刻宿主对抛错的归一形状（pi 0.99.1 executePreparedToolCall catch →
				// createErrorToolResult：content=message、details={}、isError——实证于 agent-loop），
				// 只加 structuredContent（error 分支）；旧消费者面（content/details/isError）零变化。
				const code = e instanceof RunBgToolError ? e.code : "internal";
				const message = e instanceof Error ? e.message : String(e);
				return {
					content: [{ type: "text" as const, text: message }],
					details: {},
					isError: true,
					structuredContent: toRunBgErrorWire(params?.action, code, message),
				};
			}
		},
	};
}
