/**
 * terminal-push.ts — ev-20260905-24558f（P0）：settled 后终态回推（迟终态通知）。
 *
 * 实战事故：fuxi/503b960c——sync 派发返回体已报 error（SSE 超时+降档拒单），子进程实际继续
 * 运行 85 分钟才 settled(error) 零产出；settled 终态只存在于 journal，无任何通知推送，
 * Leader 阻塞 105 分钟。本模块订阅 task-registry 变更，任务转入终态且满足「迟终态」条件时，
 * 经注入的 pi sendMessage 句柄（customType=amagi:task-terminal，deliverAs=steer）回推一行摘要，
 * 让「返回体之外到达的终态」不再黑洞。
 *
 * 迟终态判定（双臂，任一命中即推）：
 *   ① execute 已返回——task-tool 派发侧在 sync 返回点 markExecuteReturned 登记 taskId→returnedAt，
 *     终态事件晚于该时刻到达 = 返回体通道已收口，终态只能靠回推送达；
 *   ② elapsed 超过 AMAGI_TERMINAL_PUSH_MS（缺省 240s，0=关闭回推）——sync SSE 通道可能已断，
 *     长任务的终态即使仍走返回体也值得补一条（幂等去重兜底防双通知噪音）。
 * 正常快速 sync 任务终态先于 execute 返回到达（两臂均不中）→ 不推——返回体本身就是通知。
 *
 * 通道分工（防双通道噪音）：编排节点（rec.runId 存在，onNodeDone 已逐节点通知）与后台任务
 * （mode=background，onComplete 已通知）不在回推范围；回推只覆盖「唯一通知通道是 execute
 * 返回体」的单任务 sync/resume 派发。error 与 done 同权都推；同 taskId 幂等只推一次。
 *
 * 模块纪律（同 fs-mutation-tracker / residue）：零 pi 依赖——pi 句柄注入式传入（wireTerminalPush）；
 * task-registry 不得反向依赖本模块（观察者模式，本模块订阅 registry.onChange，经节流差分检测
 * 终态迁移；registry emit 无 payload，扫描侧有界节流 ≤4 次/秒，不动 registry 任何代码）。
 */

import { registry } from "./task-registry.ts";
import { collectResidue, residueNote } from "./residue.ts";
import { formatRunDuration, buildInterruptionReport, isProviderInterruption } from "./task-run.ts";
// ev-20260910-8fbe4e（C）：迟终态回推重建现场报告的写入登记源（error 终态不清登记，仍可读）
import { readTaskWrites } from "./task-write-log.ts";

/** 缺省迟终态阈值（4 分钟：超过普通 sync SSE 通道存活期即视为通道可能已断）。 */
export const DEFAULT_TERMINAL_PUSH_MS = 240_000;

/** 回推 sink 类型（与 pi.sendMessage 的本模块消费面同构；注入式，测试传 mock）。 */
export type TerminalPushSink = (msg: { customType: string; content: string; display: boolean }, opts?: { deliverAs?: "steer" | "followUp" | "nextTurn" }) => void;

/** 会触发回推的状态集合（任务书口径：done/error/cancelled/blocked；blocked 进程已退但会话可 resume，同为可行动终态）。 */
const PUSHABLE_STATUSES = new Set(["done", "error", "cancelled", "blocked"]);
/** 差分基线/幂等登记的容量护栏（超限按插入序淘汰最旧一半——被淘汰键重现≈0，不构成漏推风险）。 */
const MAX_RETAINED = 1024;
/** emit 节流窗口（registry 高频 appendActivity 热路径上最多 1 次扫描/窗口）。 */
const THROTTLE_MS = 250;

/**
 * 回推阈值（env AMAGI_TERMINAL_PUSH_MS 可调；0=关闭回推）。非法/缺省回落 240s。
 * env 注入式参数（默认 process.env）供测试直接驱动。
 */
export function terminalPushThresholdMs(env: { AMAGI_TERMINAL_PUSH_MS?: string } = process.env): number {
	const raw = env.AMAGI_TERMINAL_PUSH_MS;
	if (raw === undefined || raw === "") return DEFAULT_TERMINAL_PUSH_MS;
	const v = Number(raw);
	if (!Number.isFinite(v) || v < 0) return DEFAULT_TERMINAL_PUSH_MS;
	return v;
}

// ── 模块级状态（测试可整体复位） ──────────────────────────────────────────────
const returnedAtMap = new Map<string, number>();   // taskId → execute 返回时刻（迟终态判据①）
const pushedSet = new Set<string>();               // 幂等：同 taskId 只推一次
const lastSeenStatus = new Map<string, string>();  // 终态检测差分基线（首见不推——重启恢复/磁盘回填的终态记录无迁移可观测）
let sinkRef: TerminalPushSink | undefined;
let unsubscribed: (() => void) | undefined;
let scheduleImpl: (fn: () => void, ms: number) => unknown = (fn, ms) => { const t = setTimeout(fn, ms); t.unref?.(); return t; };
let lastScanAt = 0;
let pendingTimer: { cancel?: () => void } | undefined;

/**
 * 派发侧登记「execute 已返回」时刻（task-tool sync/resume 返回点调用）。
 * 终态事件晚于该时刻到达 → 返回体通道已收口，迟终态判据①命中。
 */
export function markExecuteReturned(taskId: string, at: number = Date.now()): void {
	if (!taskId) return;
	returnedAtMap.set(taskId, at);
	if (returnedAtMap.size > MAX_RETAINED) {
		let evict = returnedAtMap.size - Math.ceil(MAX_RETAINED / 2);
		for (const k of returnedAtMap.keys()) { if (evict-- <= 0) break; returnedAtMap.delete(k); }
	}
}

/**
 * 回推文案（纯函数）：`[终态回推] <agent>/<taskId前8> 已 <status>（运行 <时长>）：<输出或根因摘录 200 字>`。
 * 摘录取根因（errorMessage）优先、输出（result）兜底，空白归一后截 200 字。
 */
export function terminalPushContent(
	rec: Readonly<{ taskId: string; agent: string; status: string; startedAt?: number; endedAt?: number; result?: string; errorMessage?: string }>,
	now: number = Date.now(),
): string {
	const start = rec.startedAt ?? rec.endedAt ?? now;
	const durSec = Math.max(0, Math.round(((rec.endedAt || now) - start) / 1000));
	const excerpt = String(rec.errorMessage || rec.result || "(无输出)").replace(/\s+/g, " ").trim().slice(0, 200);
	return `[终态回推] ${rec.agent}/${rec.taskId.slice(0, 8)} 已 ${rec.status}（运行 ${formatRunDuration(durSec)}）：${excerpt}`;
}

/**
 * 差分扫描：检测自上次扫描以来新转入终态的记录，满足迟终态条件的经 sink 回推。
 * 导出供测试直接驱动（生产经 registry.onChange 节流触发）；幂等（pushedSet）。
 */
export function scanRegistryForTerminalPush(now: number = Date.now()): void {
	const thresholdMs = terminalPushThresholdMs();
	for (const rec of registry.list()) {
		const prev = lastSeenStatus.get(rec.taskId);
		lastSeenStatus.set(rec.taskId, rec.status);
		if (prev === undefined || prev === rec.status) continue;         // 首见（重启恢复/回填）或无迁移：不推
		if (!PUSHABLE_STATUSES.has(rec.status) || pushedSet.has(rec.taskId)) continue;
		if (rec.runId || rec.mode === "background") continue;            // 编排/后台已有自带通知通道（onNodeDone/onComplete）
		if (thresholdMs <= 0 || !sinkRef) continue;                      // 0=关闭回推；无 sink（未接线）静默
		const returnedAt = returnedAtMap.get(rec.taskId);
		const elapsedMs = Math.max(0, now - (rec.startedAt || now));
		if (returnedAt === undefined && elapsedMs <= thresholdMs) continue; // 正常快速 sync：返回体即通知，不推
		// diting 增审 Major-1（ev20260905 阶段审核）：终态迁移时刻（endedAt）早于等于 execute 返回
		// 时刻 → 终态已随返回体送达；节流尾扫可能晚于 markExecuteReturned 才首次观察到迁移，判据①
		// 只看 returnedAt 存在会把它误判成迟终态（快速失败 sync 返回体+回推双通知噪音）。
		if (returnedAt !== undefined && typeof rec.endedAt === "number" && rec.endedAt <= returnedAt) continue;
		pushedSet.add(rec.taskId);
		try {
			let content = terminalPushContent(rec, now);
			// ev-20260905-f51a49：失败终态附残留摘要（此刻收尾链尚未清理写入登记，确认档可用）。
			if (rec.status === "error" || rec.status === "cancelled") {
				const note = residueNote(collectResidue(rec.taskId, { cwd: rec.cwd, startedAt: rec.startedAt }));
				if (note) content += `\n${note}`;
			}
			// ev-20260910-8fbe4e（C）：连接类中断现场报告（迟终态回推重建）——RunResult 已不可得
			//（execute 早已返回），按写入登记（error 终态不清登记，仍可读）+ registry 活动窗口尾时刻重建；
			// gitBaseline 不可得 → 报告省略差集归因段（不猜测）。判定口径与 finalize 侧 providerError 一致
			//（isProviderInterruption：stopReason=error/aborted 或裸 provider 文本根因）。
			if (rec.status === "error" && isProviderInterruption(rec.status, rec.stopReason, rec.errorMessage)) {
				try {
					const acts = rec.activityWindow ?? [];
					const lastEvTs = acts.length && typeof acts[acts.length - 1].ts === "number" ? acts[acts.length - 1].ts : undefined;
					content += `\n${buildInterruptionReport({
						taskId: rec.taskId, cwd: rec.cwd, writes: readTaskWrites(rec.taskId),
						lastAssistantEndTs: lastEvTs, endedAt: rec.endedAt, sessionId: rec.sessionId,
					})}`;
				} catch { /* 观测面绝不反噬主流程 */ }
			}
			sinkRef({ customType: "amagi:task-terminal", content, display: false }, { deliverAs: "steer" });
		} catch { /* 回推失败静默（观测面绝不反噬主流程） */ }
	}
	pruneState();
}

/** 容量护栏：三个状态表超限按插入序淘汰最旧一半。 */
function pruneState(): void {
	const cap = (m: Map<string, unknown> | Set<string>) => {
		if (m.size <= MAX_RETAINED) return;
		let evict = m.size - Math.ceil(MAX_RETAINED / 2);
		for (const k of m.keys()) { if (evict-- <= 0) break; m.delete(k); }
	};
	// diting 增审 Minor-4：lastSeenStatus 淘汰时保活仍在运行的任务差分基线——超长会话（>MAX_RETAINED
	// 个任务 id）下早期派发的长任务终态若基线被淘汰，首见不推规则会漏推其迟终态；运行中记录
	//（queued/running/answering/blocked）淘汰时重插尾端刷新插入序，仅淘汰已收口任务的陈旧基线。
	if (lastSeenStatus.size > MAX_RETAINED) {
		const LIVE = new Set(["queued", "running", "answering", "blocked"]);
		let evict = lastSeenStatus.size - Math.ceil(MAX_RETAINED / 2);
		for (const k of [...lastSeenStatus.keys()]) {
			if (evict-- <= 0) break;
			lastSeenStatus.delete(k);
			const rec = registry.get(k);
			if (rec && LIVE.has(rec.status)) lastSeenStatus.set(k, rec.status); // 保活：仍在跑
		}
	} else cap(lastSeenStatus);
	cap(pushedSet); cap(returnedAtMap);
}

/** registry.onChange 节流入口：窗口内首事件立即扫描，后续事件合并到窗口尾补扫一次。 */
function onRegistryEmit(): void {
	const now = Date.now();
	if (now - lastScanAt >= THROTTLE_MS) {
		lastScanAt = now;
		scanRegistryForTerminalPush();
		return;
	}
	if (!pendingTimer) {
		const wait = Math.max(0, THROTTLE_MS - (now - lastScanAt));
		pendingTimer = scheduleImpl(() => { pendingTimer = undefined; lastScanAt = Date.now(); scanRegistryForTerminalPush(); }, wait) as { cancel?: () => void };
	}
}

/**
 * 接线（createTaskTool 处调用，幂等）：登记 sink 句柄 + 订阅 registry 变更。
 * pi 可选注入（测试传 { sendMessage: mock }）；deps.schedule 可注入调度器供测试。
 */
export function wireTerminalPush(
	pi?: { sendMessage?: TerminalPushSink },
	deps?: { schedule?: (fn: () => void, ms: number) => unknown },
): void {
	if (pi?.sendMessage) sinkRef = pi.sendMessage.bind(pi);
	if (deps?.schedule) scheduleImpl = deps.schedule;
	if (unsubscribed) return;
	try {
		const off = registry.onChange(onRegistryEmit);
		unsubscribed = () => { try { off(); } catch { /* 静默 */ } };
	} catch { /* 订阅失败静默（回推不可用，不影响主流程） */ }
}

/** 测试隔离：清空全部模块级状态并退订（生产不调用）。 */
export function resetTerminalPushForTest(): void {
	returnedAtMap.clear();
	pushedSet.clear();
	lastSeenStatus.clear();
	try { unsubscribed?.(); } catch { /* 静默 */ }
	unsubscribed = undefined;
	sinkRef = undefined;
	lastScanAt = 0;
	if (pendingTimer?.cancel) { try { pendingTimer.cancel(); } catch { /* 静默 */ } }
	pendingTimer = undefined;
}
