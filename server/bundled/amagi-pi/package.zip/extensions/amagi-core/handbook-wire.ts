/**
 * handbook-wire.ts — P4（寄生增强方案 §4.2，pi-0.99.1 批 W2）：amagi_handbook 结构化输出 wire v1。
 *
 * 本模块是**纯 schema/投影模块**（纪律沿 task-query-wire §4.1）：零 I/O（无 fs/进程/store 写）、
 * 零宿主私有依赖（仅 typebox + task-query-wire 的纯字符串脱敏函数 import 复用——§4.3「先允许
 * 直接引用已有导出」，不复制实现、不改匹配阈值）；不读用户现场。调用点在 handbook-tool.ts
 * 接线层（同一次 load/filter 的源对象单次读取投影——U13：字段不从正文文本猜，mapper 不执行副作用）。
 *
 * wire 身份（§4.2 新家族共同字段）：kind="amagi.handbook"、wireVersion=1、schemaVersion=1、
 * action、ok、isError。成功分支带 data（对象封闭、无值字段 null）；失败分支带
 * error:{code,message}（code ∈ invalid-input/not-found/permission/operation/internal；
 * message 过 redactCredentials 同源脱敏——import 复用，不复制）。action 非法映射 null。
 * URN：urn:amagi:handbook:<分支>:1。v1 冻结字段集合；增删字段或改语义先升 schemaVersion。
 *
 * 分支投影（源闭合锚点见各 mapper 注释与 P4 报告源形状闭合表）：
 *  - query：items（id/title/section/status/insight/example/usageCount，无值 null）+ matched/
 *    returned/excluded/truncated——同一次 loadHandbook+过滤的 pool 单次投影，不再次读取。
 *  - show：renderShow 使用的全部条目字段（含 lifecycle.promotionRule/demotionRule、
 *    lastReviewed sidecar 合并态）——缺失显式 null；不把 Markdown 正文反解析为结构。
 *  - stats：total/bytes/bySection（section→status 双层 {key,count}，顺序=现行 Map 插入序）/
 *    staleIds（现行陈旧判据单源计算，全部 id——正文展示截 10，wire 携全量）。
 *  - lifecycle：id/from/to/changed——保存完成后才返回成功；已是目标态 changed=false（幂等成功）；
 *    写失败走 error 分支（operation），不虚报迁移。
 *  - error：code/message 两字段封闭 envelope（§4.3：无 ContractError 的普通工具不强转任务契约错误）。
 */
import { Type } from "typebox";
import { redactCredentials } from "./task-query-wire.ts";

/** 自由文本槽统一脱敏投影（diting v2.11.0 全量审核 F-1：跨家族纪律一致——wire 自由文本必已脱敏）。
 * schema 结构不变仅值变换（wire v1 值变换口径）。 */
function redactedStrOrNull(v: unknown): string | null {
	return typeof v === "string" && v !== "" ? redactCredentials(v) : strOrNull(v);
}

// ── wire 身份常量（固定字面量；接线层与测试共用） ──────────────────────────────

export const HANDBOOK_WIRE_KIND = "amagi.handbook";
export const HANDBOOK_WIRE_VERSION = 1;
export const HANDBOOK_SCHEMA_VERSION = 1;

/** 五分支 schema 标识（§4.2 URN 格式 urn:amagi:<家族>:<分支>:1）。 */
export const HANDBOOK_WIRE_URNS = {
	query: "urn:amagi:handbook:query:1",
	show: "urn:amagi:handbook:show:1",
	stats: "urn:amagi:handbook:stats:1",
	lifecycle: "urn:amagi:handbook:lifecycle:1",
	error: "urn:amagi:handbook:error:1",
} as const;

/** 家族错误码（§4.2「各家族/error」行：五值封闭；语义见模块头）。 */
export const HANDBOOK_ERROR_CODES = ["invalid-input", "not-found", "permission", "operation", "internal"] as const;
export type HandbookErrorCode = (typeof HANDBOOK_ERROR_CODES)[number];

export type HandbookAction = "query" | "show" | "stats" | "lifecycle";

// ── 共享子 schema（additionalProperties:false + 全键 required；分支根才挂 $id） ──

const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });
const NullableString = Type.Union([Type.String(), Type.Null()]);

const WireCommonProperties = {
	kind: Type.Literal(HANDBOOK_WIRE_KIND),
	wireVersion: Type.Literal(HANDBOOK_WIRE_VERSION),
	schemaVersion: Type.Literal(HANDBOOK_SCHEMA_VERSION),
};

const ErrorCodeSchema = Type.Union(HANDBOOK_ERROR_CODES.map((c) => Type.Literal(c)));

// ── 分支 schema（§4.2 规格块逐字段） ──────────────────────────────────────────

/** query 档：items 白名单投影 + 计数字段（matched=过滤后 pre-limit；returned=实际返回；truncated=matched>returned）。 */
export const HandbookQueryWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("query"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		items: Type.Array(Type.Object({
			id: Type.String(),
			title: NullableString,
			section: Type.String(),
			status: NullableString,
			insight: NullableString,
			example: NullableString,
			usageCount: Type.Union([NonNegativeSafeInt, Type.Null()]),
		}, { additionalProperties: false, description: "条目白名单投影（无值字段 null；不携带 addedDate/source/lifecycle——show 档取全文）" })),
		matched: NonNegativeSafeInt,
		returned: NonNegativeSafeInt,
		excluded: NonNegativeSafeInt,
		truncated: Type.Boolean(),
	}, { additionalProperties: false }),
}, { $id: HANDBOOK_WIRE_URNS.query, additionalProperties: false, description: "amagi_handbook query 档 wire（§4.2）" });

/** show 档：renderShow 消费的全部条目字段（含 sidecar 合并态 lastReviewed 与 lifecycle 规则）；缺失显式 null。 */
export const HandbookShowWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("show"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		title: NullableString,
		section: Type.String(),
		sectionName: NullableString,
		status: NullableString,
		insight: NullableString,
		example: NullableString,
		source: NullableString,
		usageCount: Type.Union([NonNegativeSafeInt, Type.Null()]),
		addedDate: NullableString,
		lastReviewed: NullableString,
		promotionRule: NullableString,
		demotionRule: NullableString,
	}, { additionalProperties: false, description: "单条目全文投影（源=loadHandbook 合并后的 MergedEntry；不反解析 Markdown 正文）" }),
}, { $id: HANDBOOK_WIRE_URNS.show, additionalProperties: false, description: "amagi_handbook show 档 wire（§4.2）" });

/** stats 档：total/bytes + section→status 双层 {key,count}（顺序=现行 Map 插入序）+ 陈旧候选全量 id。 */
export const HandbookStatsWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("stats"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		total: NonNegativeSafeInt,
		bytes: NonNegativeSafeInt,
		bySection: Type.Array(Type.Object({
			key: Type.String(),
			count: NonNegativeSafeInt,
			statuses: Type.Array(Type.Object({
				key: Type.String(),
				count: NonNegativeSafeInt,
			}, { additionalProperties: false }), { description: "section 内 status 分布（键=status 字面，缺省态按现行判据记 candidate）" }),
		}, { additionalProperties: false }), { description: "section×status 分布（现行 renderStats 同一 Map 的单源投影）" }),
		staleIds: Type.Array(Type.String(), { description: "陈旧候选全量 id（现行陈旧判据单源；正文展示截 10，wire 携全量）" }),
	}, { additionalProperties: false }),
}, { $id: HANDBOOK_WIRE_URNS.stats, additionalProperties: false, description: "amagi_handbook stats 档 wire（§4.2）" });

/** lifecycle 档：id/from/to/changed——保存完成后才成功；幂等（已是目标态）changed=false。
 *  from/to 为 string 投影（合法值 candidate/active/dormant/deprecated 由 LIFECYCLE_STATES 单源定义；
 *  本模块不另造枚举，sidecar 历史异常值原字面透传——消费者展示原字面并停止自动操作）。 */
export const HandbookLifecycleWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("lifecycle"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		id: Type.String(),
		from: Type.String(),
		to: Type.String(),
		changed: Type.Boolean(),
	}, { additionalProperties: false, description: "迁移回执（changed=false=幂等未写 sidecar；true=sidecar 已持久）" }),
}, { $id: HANDBOOK_WIRE_URNS.lifecycle, additionalProperties: false, description: "amagi_handbook lifecycle 档 wire（§4.2）" });

/** error 档：{code,message} 两字段封闭 envelope；action 只取合法四档字面或 null（不 echo 任意原参数）。 */
export const HandbookErrorWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Union([Type.Literal("query"), Type.Literal("show"), Type.Literal("stats"), Type.Literal("lifecycle"), Type.Null()]),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	error: Type.Object({
		code: ErrorCodeSchema,
		message: Type.String(),
	}, { additionalProperties: false }),
}, { $id: HANDBOOK_WIRE_URNS.error, additionalProperties: false, description: "amagi_handbook 工具内失败 wire（§4.2 error 分支；message 已同源脱敏）" });

/** 五封闭分支 Union（含 error 分支——注册面统一校验器；消费者判据 kind/wireVersion/action/ok/schemaVersion）。 */
export const HandbookOutputSchema = Type.Union(
	[HandbookQueryWireSchema, HandbookShowWireSchema, HandbookStatsWireSchema, HandbookLifecycleWireSchema, HandbookErrorWireSchema],
	{ description: "amagi_handbook 结构化输出 wire v1（五封闭分支：query/show/stats/lifecycle/error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；一致性由专项测试 Value.Check+键集对照双断言） ──

export interface HandbookWireCommon {
	kind: typeof HANDBOOK_WIRE_KIND;
	wireVersion: typeof HANDBOOK_WIRE_VERSION;
	schemaVersion: typeof HANDBOOK_SCHEMA_VERSION;
}

export interface HandbookQueryItemWire {
	id: string;
	title: string | null;
	section: string;
	status: string | null;
	insight: string | null;
	example: string | null;
	usageCount: number | null;
}
export interface HandbookQueryWire extends HandbookWireCommon {
	action: "query"; ok: true; isError: false;
	data: { items: HandbookQueryItemWire[]; matched: number; returned: number; excluded: number; truncated: boolean };
}
export interface HandbookShowWire extends HandbookWireCommon {
	action: "show"; ok: true; isError: false;
	data: {
		id: string; title: string | null; section: string; sectionName: string | null; status: string | null;
		insight: string | null; example: string | null; source: string | null; usageCount: number | null;
		addedDate: string | null; lastReviewed: string | null; promotionRule: string | null; demotionRule: string | null;
	};
}
export interface HandbookStatsWire extends HandbookWireCommon {
	action: "stats"; ok: true; isError: false;
	data: {
		total: number; bytes: number;
		bySection: Array<{ key: string; count: number; statuses: Array<{ key: string; count: number }> }>;
		staleIds: string[];
	};
}
export interface HandbookLifecycleWire extends HandbookWireCommon {
	action: "lifecycle"; ok: true; isError: false;
	data: { id: string; from: string; to: string; changed: boolean };
}
export interface HandbookErrorWire extends HandbookWireCommon {
	action: HandbookAction | null; ok: false; isError: true;
	error: { code: HandbookErrorCode; message: string };
}
export type HandbookWireOutput = HandbookQueryWire | HandbookShowWire | HandbookStatsWire | HandbookLifecycleWire | HandbookErrorWire;

// ── 投影源（调用方同一次执行提供的源对象——本模块零 I/O、不二次读取） ────────────

/** 条目投影源：结构兼容 loadHandbook 的 MergedEntry（字段闭合锚点=handbook-tool.ts HandbookEntry+合并字段；
 *  本模块不 import handbook-tool.ts——防循环依赖，接口按源形状在此声明）。 */
export interface HandbookEntrySource {
	id: string;
	title?: string;
	insight?: string;
	example?: string;
	source?: string;
	usageCount?: number;
	addedDate?: string;
	status?: string;
	lastReviewed?: string;
	section: string;
	sectionName?: string;
	lifecycle?: { promotionRule?: string; demotionRule?: string } | null;
}

/** query 投影源：过滤+排序后 pre-limit pool 与实际返回切片（同一次执行产物）。 */
export interface HandbookQuerySource {
	/** 过滤+排序后的完整命中池（matched=长度）。 */
	matchedPool: readonly HandbookEntrySource[];
	/** 实际返回切片（正文与 wire 同源——单次切片双消费）。 */
	returned: readonly HandbookEntrySource[];
	excluded: number;
}

/** stats 投影源：现行判据单源计算产物（computeStatsData——renderStats 与 wire 共用，不二次计算）。 */
export interface HandbookStatsSource {
	total: number;
	bytes: number;
	bySection: Array<{ key: string; count: number; statuses: Array<{ key: string; count: number }> }>;
	staleIds: string[];
}

// ── 字段归一小件（无值/类型不合 → null；数值须非负安全整数） ────────────────────

const strOrNull = (v: unknown): string | null => (typeof v === "string" ? v : null);
const countOrNull = (v: unknown): number | null =>
	typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= Number.MAX_SAFE_INTEGER ? v : null;

// ── 各档映射 ─────────────────────────────────────────────────────────────────

/** query 档：matchedPool/returned 同源切片投影（不重复过滤、不再次读取）。 */
export function toQueryWire(src: Readonly<HandbookQuerySource>): HandbookQueryWire {
	return {
		kind: HANDBOOK_WIRE_KIND,
		wireVersion: HANDBOOK_WIRE_VERSION,
		schemaVersion: HANDBOOK_SCHEMA_VERSION,
		action: "query",
		ok: true,
		isError: false,
		data: {
			items: src.returned.map((e) => ({
				id: e.id,
				title: redactedStrOrNull(e.title),
				section: e.section,
				status: strOrNull(e.status),
				insight: redactedStrOrNull(e.insight),
				example: redactedStrOrNull(e.example),
				usageCount: countOrNull(e.usageCount),
			})),
			matched: src.matchedPool.length,
			returned: src.returned.length,
			excluded: Math.max(0, Math.trunc(src.excluded) || 0),
			truncated: src.matchedPool.length > src.returned.length,
		},
	};
}

/** show 档：单条目全文字段投影（renderShow 消费集；缺失显式 null）。 */
export function toShowWire(e: Readonly<HandbookEntrySource>): HandbookShowWire {
	return {
		kind: HANDBOOK_WIRE_KIND,
		wireVersion: HANDBOOK_WIRE_VERSION,
		schemaVersion: HANDBOOK_SCHEMA_VERSION,
		action: "show",
		ok: true,
		isError: false,
		data: {
			id: e.id,
			title: redactedStrOrNull(e.title),
			section: e.section,
			sectionName: strOrNull(e.sectionName),
			status: strOrNull(e.status),
			insight: redactedStrOrNull(e.insight),
			example: redactedStrOrNull(e.example),
			source: strOrNull(e.source),
			usageCount: countOrNull(e.usageCount),
			addedDate: strOrNull(e.addedDate),
			lastReviewed: strOrNull(e.lastReviewed),
			promotionRule: strOrNull(e.lifecycle?.promotionRule),
			demotionRule: strOrNull(e.lifecycle?.demotionRule),
		},
	};
}

/** stats 档：computeStatsData 单源产物直投影（1:1——不在 mapper 里另算一套分布/陈旧规则）。 */
export function toStatsWire(src: Readonly<HandbookStatsSource>): HandbookStatsWire {
	return {
		kind: HANDBOOK_WIRE_KIND,
		wireVersion: HANDBOOK_WIRE_VERSION,
		schemaVersion: HANDBOOK_SCHEMA_VERSION,
		action: "stats",
		ok: true,
		isError: false,
		data: {
			total: src.total,
			bytes: src.bytes,
			bySection: src.bySection.map((s) => ({ key: s.key, count: s.count, statuses: s.statuses.map((t) => ({ key: t.key, count: t.count })) })),
			staleIds: [...src.staleIds],
		},
	};
}

/** lifecycle 档：迁移回执（changed 由调用方按 sidecar 写结果给定——保存完成后才 true）。 */
export function toLifecycleWire(id: string, from: string, to: string, changed: boolean): HandbookLifecycleWire {
	return {
		kind: HANDBOOK_WIRE_KIND,
		wireVersion: HANDBOOK_WIRE_VERSION,
		schemaVersion: HANDBOOK_SCHEMA_VERSION,
		action: "lifecycle",
		ok: true,
		isError: false,
		data: { id, from, to, changed },
	};
}

/** error 档：action 只认合法四档字面（非法/缺席 → null，不 echo 任意原参数）；message 同源脱敏。
 *  code 由调用方按错误语义给定（invalid-input/not-found/permission/operation/internal）。 */
export function toHandbookErrorWire(action: unknown, code: HandbookErrorCode, message: string): HandbookErrorWire {
	const known: HandbookAction | null =
		action === "query" || action === "show" || action === "stats" || action === "lifecycle" ? action : null;
	return {
		kind: HANDBOOK_WIRE_KIND,
		wireVersion: HANDBOOK_WIRE_VERSION,
		schemaVersion: HANDBOOK_SCHEMA_VERSION,
		action: known,
		ok: false,
		isError: true,
		error: { code, message: redactCredentials(message) },
	};
}
