/** 统一压缩选模及子进程交付；只读 amagi.json，不写原生会话或扩大工具授权。 */
import * as fs from "node:fs";
import * as path from "node:path";
import * as piAi from "@earendil-works/pi-ai";
import { getGlobalConfigPath, SUPPORTED_THINKING_LEVELS } from "./model-resolver.ts";

const CONFIG_CWD_ENV = "AMAGI_COMPACTION_CONFIG_CWD";
const AUTH_ENV = "AMAGI_COMPACTION_AUTH_ENV";
let leaderConfigCwd: string | undefined;
let extensionProvider: ((provider: string) => unknown) | undefined;
let nativeAi = piAi as unknown as {
	findEnvKeys?: (provider: string) => string[] | undefined;
	streamSimple?: NonNullable<Parameters<typeof import("@earendil-works/pi-coding-agent").compact>[7]>;
};
let nativeAiLoad: Promise<void> | undefined;

/** pi 1.1 把旧全局 API 移到公开 /compat；旧宿主从根导出。惰性读取，避免抬高最低版本。 */
export async function loadCompactionNativeAi(): Promise<typeof nativeAi> {
	if (!nativeAiLoad) nativeAiLoad = (async () => {
		if (nativeAi.findEnvKeys && nativeAi.streamSimple) return;
		try { const entry = "@earendil-works/pi-ai/compat"; nativeAi = await import(entry); } catch { /* 旧宿主根导出已保留。 */ }
	})();
	await nativeAiLoad;
	return nativeAi;
}

export interface CompactionConfig {
	model: string | null;
	source?: string;
	provider?: string;
	id?: string;
	thinkingLevel?: piAi.ThinkingLevel;
}

export function bindCompactionConfig(cwd: string, providerConfig?: (provider: string) => unknown): void {
	leaderConfigCwd = cwd;
	extensionProvider = providerConfig;
}

/** 子端沿用派发者配置目录；工作树或 task.cwd 不能意外切换统一压缩策略。 */
export function compactionConfigCwd(cwd: string): string {
	return process.env[CONFIG_CWD_ENV] || cwd;
}

export function resolveCompactionConfig(cwd: string): CompactionConfig {
	for (const file of [...new Set([path.join(cwd, "amagi.json"), getGlobalConfigPath()])]) {
		let raw: unknown;
		try { raw = JSON.parse(fs.readFileSync(file, "utf8")); }
		catch (error) {
			if ((error as NodeJS.ErrnoException).code === "ENOENT") continue;
			throw new Error(`压缩配置不可读或 JSON 无效：${file}`);
		}
		if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error(`压缩配置应为对象：${file}`);
		if (!("compaction" in raw)) continue;
		const config = (raw as { compaction?: unknown }).compaction;
		if (!config || typeof config !== "object" || Array.isArray(config) || Object.keys(config).some(k => k !== "model")) {
			throw new Error(`compaction 字段无效（只允许 model）：${file}`);
		}
		if (!("model" in config)) continue;
		const model = (config as { model: unknown }).model;
		if (model === null) return { model: null, source: file };
		if (typeof model !== "string" || !model || model.trim() !== model || /\s/.test(model)) throw new Error(`compaction.model 应为 provider/model[:thinking] 或 null：${file}`);
		const slash = model.indexOf("/");
		if (slash <= 0 || slash === model.length - 1) throw new Error(`compaction.model 缺少 provider/model：${file}`);
		const provider = model.slice(0, slash), remainder = model.slice(slash + 1), colon = remainder.lastIndexOf(":");
		const suffix = colon < 0 ? undefined : remainder.slice(colon + 1);
		const thinking = suffix !== undefined && SUPPORTED_THINKING_LEVELS.includes(suffix) ? suffix : undefined;
		// Ollama 等原生模型 ID 可含冒号；只有合法 thinking 后缀具有选档语义。
		const id = thinking ? remainder.slice(0, colon) : remainder;
		if (!id) throw new Error(`compaction.model 缺少模型 ID：${file}`);
		return { model, source: file, provider, id, ...(thinking ? { thinkingLevel: thinking as piAi.ThinkingLevel } : {}) };
	}
	return { model: null };
}

/** 仅提取原生配置的环境引用，不执行凭据命令、不解析/打印密钥值。 */
function referencedEnv(value: unknown): string[] {
	if (typeof value !== "string" || value.startsWith("!")) return [];
	const names: string[] = [];
	for (const match of value.matchAll(/\$\$|\$!|\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g)) {
		const name = match[1] || match[2];
		if (name) names.push(name);
	}
	return names;
}

export function providerEnvKeys(provider: string, id: string): string[] {
	const keys = new Set<string>(nativeAi.findEnvKeys?.(provider) ?? []);
	let native: any;
	try { native = JSON.parse(fs.readFileSync(path.join(path.dirname(getGlobalConfigPath()), "models.json"), "utf8"))?.providers?.[provider]; } catch { /* 宿主负责报告 models.json 错误。 */ }
	for (const config of [native, extensionProvider?.(provider)]) {
		if (!config || typeof config !== "object") continue;
		const c = config as { apiKey?: unknown; headers?: Record<string, unknown>; models?: Array<{ id?: string; headers?: Record<string, unknown> }> };
		for (const value of [c.apiKey, ...Object.values(c.headers ?? {}), ...Object.values(c.models?.find(m => m.id === id)?.headers ?? {})]) {
			for (const name of referencedEnv(value)) keys.add(name);
		}
	}
	return [...keys];
}

/** 父端专用交付：不把压缩供应商密钥放入子端普通环境，配置错误留到压缩时明确阻止。 */
export function appendCompactionEnv(env: Record<string, string>, cwd: string): void {
	const origin = compactionConfigCwd(leaderConfigCwd || cwd);
	env[CONFIG_CWD_ENV] = origin;
	delete env[AUTH_ENV];
	try {
		const config = resolveCompactionConfig(origin);
		if (!config.provider || !config.id) return;
		const auth = Object.fromEntries(providerEnvKeys(config.provider, config.id).flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]));
		if (Object.keys(auth).length) env[AUTH_ENV] = Buffer.from(JSON.stringify({ provider: config.provider, values: auth })).toString("base64");
	} catch { /* 工作任务仍可启动；session_before_compact 负责 fail-closed。 */ }
}

/** 子端扩展装配即取出并删除；密钥仅供原生模型运行时的 request.env 使用。 */
export function takeCompactionAuthEnv(): { provider?: string; values: Record<string, string> } {
	const encoded = process.env[AUTH_ENV];
	delete process.env[AUTH_ENV];
	if (!encoded) return { values: {} };
	try {
		const raw: unknown = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
		if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { values: {} };
		const bundle = raw as { provider?: unknown; values?: unknown };
		if (typeof bundle.provider !== "string" || !bundle.values || typeof bundle.values !== "object" || Array.isArray(bundle.values)) return { values: {} };
		return { provider: bundle.provider, values: Object.fromEntries(Object.entries(bundle.values).filter(([key, value]) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(key) && typeof value === "string")) as Record<string, string> };
	} catch { return { values: {} }; }
}

export function stripCompactionEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
	const next = { ...env };
	delete next[AUTH_ENV];
	delete next[CONFIG_CWD_ENV];
	return next;
}
