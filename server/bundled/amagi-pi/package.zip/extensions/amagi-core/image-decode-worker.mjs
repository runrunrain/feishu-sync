// image-decode-worker.mjs — C14/F6 终局（fuxi 设计 §4.4）：宿主解码监督 worker。
// 本文件是生命周期适配，不是第二个解码器：只导入公共宿主包根（@earendil-works/pi-coding-agent，
// 经父侧解析的公共入口 URL 注入——不 deep-import dist/utils/*、不直接 import Photon）。
// 宿主 resizeImage 返回的 base64 data 只在本 worker 内短暂存在：回传父侧仅观测字段
// （originalWidth/originalHeight/wasResized），不回传派生图字节、不落盘、不入日志（设计 §4.3）。
// 回收语义（M1 实测）：parentPort 监听使 worker 事件循环不自然排空——父侧必须在 settle 后
// terminate（一请求一受监督 worker）。本文件零持久化、零 Agent 派发、零用户文件访问。
// 注：本文件为 Node 原生加载的纯 ESM（不经 jiti/tsc），刻意保持零仓库依赖；父侧以
// { type: "module", execArgv: [] } 启动（execArgv 清空——不继承宿主进程 eval 类参数，M1 实测）。
import { parentPort } from "node:worker_threads";

parentPort.on("message", async (data) => {
	// F6.B5：import 与 decode 阶段异常分开标签——公共根模块加载失败（含顶层抛错）是 phase=import
	//（父侧映射 backend-unavailable：入口不可用语义）；只有 resizeImage 执行中的异常才是 phase=decode。
	// 不伪造通过、不追加 fallback；两阶段均零持久化。
	let host;
	try {
		host = await import(data.hostEntryUrl);
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		parentPort.postMessage({ ok: false, phase: "import", error: msg });
		return;
	}
	if (typeof host.resizeImage !== "function") {
		parentPort.postMessage({ ok: false, phase: "import", error: "resizeImage not exported at public root" });
		return;
	}
	try {
		const result = await host.resizeImage(new Uint8Array(data.bytes), data.mimeType, data.options);
		const observation =
			result === null
				? null
				: {
						originalWidth: result.originalWidth,
						originalHeight: result.originalHeight,
						wasResized: result.wasResized,
					};
		parentPort.postMessage({ ok: true, result: observation });
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		parentPort.postMessage({ ok: false, phase: "decode", error: msg });
	}
});
