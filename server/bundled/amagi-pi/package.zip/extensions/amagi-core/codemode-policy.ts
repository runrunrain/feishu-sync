/**
 * codemode-policy.ts — C11 codemode 证据收集快通道：会话级准入策略与审计（M4 试验基座）。
 *
 * 设计 §6.1 裁定（十月迭代 M4，默认关闭）：
 *  - **原生 codemode 本迭代不对受限子 Agent 开放**——1.0.2 未提供关闭 models.* 或按 grant
 *    拦截该桥的 API，也无外层强制 timeout/并发配额的完整配置面；子 Agent 分支恒 deny。
 *  - Leader 侧仅在**获授权的隔离试点会话**显式开启：只读工具集白名单 + 预算上限 + 审计记录。
 *  - 默认 deny；判定理由可追溯（同 B6a 拒绝码风格：结构化 code + 人读 reason）。
 *
 * 执法位置声明（设计红线：脚本前缀/关键字扫描/提示词禁令不能替代硬限制）：
 *  - 本模块不扫描脚本文本做安全执法——工具面白名单约束的是【会话工具面】本身
 *    （defaultTools/--tools 严格名单），物理执法依赖宿主：不在名单的工具在 codemode 沙箱内
 *    经 throwing proxy 不可达（A3 四层次核对：声明/可调用/发现/触达）。试点装配方负责把
 *    会话工具面收窄为白名单子集，本模块在启用时校验该声明并留审计。
 *  - 预算上限约束脚本 `// @options` 声明值（宿主明确定义的脚本选项协议，非关键字扫描）；
 *    试点脚本必须首行显式声明预算内选项——未声明时宿主默认（output 10000 tokens / 无超时）
 *    超出试点预算，按拒绝处理（fail-closed）。
 *  - 预算/审计是试点治理面，不是安全边界；安全边界=会话工具面严格名单+子 Agent 恒 deny。
 *
 * 会话身份来源：subagent=AMAGI_SUBAGENT==="1"（task-run 派生注入，防递归同源）；显式开启
 * =AMAGI_CODEMODE_TRIAL==="1"（隔离试点会话装配方注入；非法值/未设一律 deny）；会话工具面
 * =AMAGI_CODEMODE_TRIAL_TOOLS（逗号分隔，装配方声明）。三者均由 spawn env 交付，reload/项目
 * 覆写不继承生产配置（试点会话必须独立 env，见设计 §6.1「隔离 Leader 会话」）。
 */

/** 只读工具白名单基集（宿主内置只读面：read/grep/find/ls——settings.md §Tools）。试点会话
 *  工具面必须是本集的子集（外加发现场工具）。 */
export const CODEMODE_READ_ONLY_TOOL_WHITELIST: ReadonlySet<string> = new Set(["read", "grep", "find", "ls"]);

/** 发现场工具（宿主 builtin 扩展注册：codemode/tool_search，off by default，显式点名激活）。
 *  试点会话允许在场（codemode 本身即被测工具；tool_search/searchTools 发现链只读）。 */
export const CODEMODE_DISCOVERY_TOOLS: ReadonlySet<string> = new Set(["codemode", "tool_search"]);

/** 写类/副作用类工具（bash/powershell/edit/write 宿主内置写面 + run_bg amagi 扩展后台原语）。
 *  会话工具面出现任一即拒绝启用（写面必须物理缺席，不能靠运行时拦截兜底）。 */
export const CODEMODE_WRITE_CAPABLE_TOOLS: ReadonlySet<string> = new Set(["bash", "powershell", "edit", "write", "run_bg"]);

/** 试点预算（比宿主上限严——设计 §6.1「试验使用更小输入，不把宿主上限当业务预算」：
 *  宿主 output 默认 10000/上限 16777216 字符、timeout 无默认；试点收紧到 2000 tokens/60s/20 脚本）。 */
export interface CodemodeTrialBudget {
	/** 单会话脚本执行次数上限（试点对照设计 §6.1 ≥20 任务口径的会话级护栏）。 */
	readonly maxScriptsPerSession: number;
	/** 单脚本 @options max_output_tokens 声明上限。 */
	readonly maxOutputTokensPerScript: number;
	/** 单脚本 @options timeout_ms 声明上限。 */
	readonly maxTimeoutMsPerScript: number;
}

/** 试点预算默认（env 覆盖不得超出安全钳制上限）。 */
export const DEFAULT_CODEMODE_TRIAL_BUDGET: CodemodeTrialBudget = {
	maxScriptsPerSession: 20,
	maxOutputTokensPerScript: 2000,
	maxTimeoutMsPerScript: 60_000,
};

/** env 覆盖的绝对安全上限（试点治理面钳制：覆盖值超出按上限截断，不开无限预算）。 */
const BUDGET_HARD_CEILINGS = { maxScriptsPerSession: 200, maxOutputTokensPerScript: 10_000, maxTimeoutMsPerScript: 600_000 };

/** 判定理由码（结构化可追溯；ALLOW 之外的码即拒绝原因）。B5A 追加受控模式码（7517d8 设计 §5.4）。 */
export type CodemodeDecisionCode =
	| "ALLOW"
	| "SUBAGENT_ALWAYS_DENIED"
	| "TRIAL_NOT_ENABLED"
	| "SESSION_TOOLS_UNDECLARED"
	| "WRITE_TOOL_IN_SESSION"
	| "TOOL_OUTSIDE_WHITELIST"
	| "SCRIPT_BUDGET_EXHAUSTED"
	| "SCRIPT_OPTIONS_UNDECLARED"
	| "SCRIPT_OPTIONS_INVALID"
	| "SCRIPT_OUTPUT_TOKENS_OVER_CAP"
	| "SCRIPT_TIMEOUT_OVER_CAP"
	// ── B5A 受控模式（7517d8 设计 §5.4 新控制码）──
	| "GRANT_MISSING"
	| "ROLE_NOT_GRANTED"
	| "BACKEND_UNVERIFIED"
	| "BRIDGE_NOT_DISABLED"
	| "TOOL_OUTSIDE_READ_SET"
	| "TOOLS_CHANGED"
	| "OPTIONS_INVALID"
	| "BUDGET_EXHAUSTED"
	| "STATE_UNAVAILABLE";

export interface CodemodeAdmissionDecision {
	allowed: boolean;
	code: CodemodeDecisionCode;
	/** 人读理由（B6a 拒绝码风格：`[amagi codemode-policy]` 前缀 + 具体依据与指引）。 */
	reason: string;
}

/** 会话身份（判定输入；三项均由装配方从 spawn env 交付）。 */
export interface CodemodeSessionIdentity {
	/** 子 Agent 分支（AMAGI_SUBAGENT==="1"）——设计 §6.1 裁定恒 deny。 */
	readonly subagent: boolean;
	/** Leader 试点显式开启（AMAGI_CODEMODE_TRIAL==="1"）。 */
	readonly trialEnabled: boolean;
	/** 会话工具面声明（AMAGI_CODEMODE_TRIAL_TOOLS 逗号分隔解析；空=未声明 fail-closed）。 */
	readonly sessionTools: readonly string[];
}

/** 脚本 `// @options` 声明（宿主脚本选项协议的解析产物）。 */
export interface CodemodeScriptOptions {
	/** 首行是否声明了 @options。 */
	readonly present: boolean;
	readonly maxOutputTokens?: number;
	readonly timeoutMs?: number;
	/** 声明存在但不可解析（非法 JSON/非对象/值非法）——fail-closed。 */
	readonly invalidReason?: string;
}

const OPTIONS_PREFIX = "// @options:";

/** 宿主 @options timeout_ms 上限（@earendil-works/pi-codemode dist/source.js MAX_TIMEOUT_MS，F12 对齐口径）。 */
const HOST_TIMEOUT_MS_MAX = 2147483647;

/** 解析脚本首行 `// @options: {...}`（宿主协议：脚本以选项行开头；前导空白行后的首个非空行
 *  不算——宿主口径是 start with，从严按首字符区段匹配，避免把正文中的注释误当选项）。 */
export function parseCodemodeScriptOptions(code: string): CodemodeScriptOptions {
	const src = typeof code === "string" ? code : "";
	const firstLine = src.split(/\r?\n/, 1)[0] ?? "";
	if (!firstLine.trimStart().startsWith(OPTIONS_PREFIX)) return { present: false };
	const raw = firstLine.trimStart().slice(OPTIONS_PREFIX.length).trim();
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch (e) {
		return { present: true, invalidReason: `@options JSON 解析失败：${e instanceof Error ? e.message : String(e)}` };
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
		return { present: true, invalidReason: `@options 须为 JSON 对象，实得 ${Array.isArray(parsed) ? "array" : typeof parsed}` };
	}
	const obj = parsed as Record<string, unknown>;
	// F12：值域与宿主解析器对齐（@earendil-works/pi-codemode parseOptions）：max_output_tokens 须为
	// JSON number 且 Number.isSafeInteger 且 ≥0；timeout_ms 同型且 ≥1 且 ≤2147483647——字符串数字/
	// 浮点/越界宿主一律拒（CodemodeSourceError），本策略同口径 fail-closed（不 Number 强转）。
	const readHostInt = (key: string, min: number, max: number): { value?: number; reason?: string } => {
		const v = obj[key];
		if (v === undefined) return {};
		if (typeof v !== "number" || !Number.isSafeInteger(v) || v < min || v > max) {
			const range = min === 0 && max === Number.MAX_SAFE_INTEGER ? "非负 safe integer" : `≥${min} 且 ≤${max} 的整数`;
			return { reason: `@options 字段 ${key} 须为${range}（宿主 parseCodemodeSource 同值域；字符串数字/浮点/越界拒绝）` };
		}
		return { value: v };
	};
	const tokens = readHostInt("max_output_tokens", 0, Number.MAX_SAFE_INTEGER);
	if (tokens.reason !== undefined) return { present: true, invalidReason: tokens.reason };
	const timeout = readHostInt("timeout_ms", 1, HOST_TIMEOUT_MS_MAX);
	if (timeout.reason !== undefined) return { present: true, invalidReason: timeout.reason };
	const maxOutputTokens = tokens.value;
	const timeoutMs = timeout.value;
	const invalidKeys = Object.keys(obj).filter((k) => k !== "max_output_tokens" && k !== "timeout_ms");
	if (invalidKeys.length > 0) {
		return { present: true, invalidReason: `@options 含试点未知键（${invalidKeys.join(", ")}）——仅认 max_output_tokens/timeout_ms` };
	}
	return { present: true, ...(maxOutputTokens !== undefined ? { maxOutputTokens } : {}), ...(timeoutMs !== undefined ? { timeoutMs } : {}) };
}

/** AMAGI_CODEMODE_TRIAL 解析：仅字面 "1" 显式开启；未设/其它值（含非法）一律 deny。 */
export function codemodeTrialEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return env.AMAGI_CODEMODE_TRIAL === "1";
}

/** 预算解析：默认值 + env 覆盖（AMAGI_CODEMODE_TRIAL_MAX_SCRIPTS/MAX_OUTPUT_TOKENS/TIMEOUT_MS，
 *  钳制在 BUDGET_HARD_CEILINGS 内——覆盖不能开无限预算）。 */
export function codemodeTrialBudget(env: NodeJS.ProcessEnv = process.env): CodemodeTrialBudget {
	const readBounded = (v: string | undefined, fallback: number, ceiling: number): number => {
		const n = Number(v);
		if (!Number.isFinite(n) || n < 1) return fallback;
		return Math.min(Math.floor(n), ceiling);
	};
	return {
		maxScriptsPerSession: readBounded(env.AMAGI_CODEMODE_TRIAL_MAX_SCRIPTS, DEFAULT_CODEMODE_TRIAL_BUDGET.maxScriptsPerSession, BUDGET_HARD_CEILINGS.maxScriptsPerSession),
		maxOutputTokensPerScript: readBounded(env.AMAGI_CODEMODE_TRIAL_MAX_OUTPUT_TOKENS, DEFAULT_CODEMODE_TRIAL_BUDGET.maxOutputTokensPerScript, BUDGET_HARD_CEILINGS.maxOutputTokensPerScript),
		maxTimeoutMsPerScript: readBounded(env.AMAGI_CODEMODE_TRIAL_TIMEOUT_MS, DEFAULT_CODEMODE_TRIAL_BUDGET.maxTimeoutMsPerScript, BUDGET_HARD_CEILINGS.maxTimeoutMsPerScript),
	};
}

/** AMAGI_CODEMODE_TRIAL_TOOLS 解析（逗号分隔、trim、去空）。 */
export function codemodeTrialSessionTools(env: NodeJS.ProcessEnv = process.env): string[] {
	const raw = env.AMAGI_CODEMODE_TRIAL_TOOLS;
	if (typeof raw !== "string" || raw.trim() === "") return [];
	return raw.split(",").map((t) => t.trim()).filter(Boolean);
}

/** 会话身份装配（env 三源合一；接线与探针共用同一解析面）。 */
export function codemodeSessionIdentityFromEnv(env: NodeJS.ProcessEnv = process.env): CodemodeSessionIdentity {
	return {
		subagent: env.AMAGI_SUBAGENT === "1",
		trialEnabled: codemodeTrialEnabled(env),
		sessionTools: codemodeTrialSessionTools(env),
	};
}

/** 审计条目（每次判定一条——allow 与 deny 都记；结构化 code 优先，脚本摘要辅助定位）。 */
export interface CodemodeAuditEntry {
	readonly ts: string;
	readonly allowed: boolean;
	readonly code: CodemodeDecisionCode;
	/** 脚本头摘要（前 160 字符、单行化——足够定位，不复制全文进审计）。 */
	readonly scriptHead: string;
	readonly maxOutputTokens?: number;
	readonly timeoutMs?: number;
}

const AUDIT_MAX_ENTRIES = 256;

/** 会话试点状态（脚本计数 + 审计日志；模块级单例由 sessionCodemodeTrialState 持有）。 */
export interface CodemodeTrialState {
	readonly budget: CodemodeTrialBudget;
	/** 已放行的脚本执行次数（预算轴——仅 allow 递增）。 */
	scriptsExecuted: number;
	/** 判定审计（有界 FIFO，溢出丢最旧；完整证据以会话日志为准，此处是治理面速查）。 */
	readonly audit: CodemodeAuditEntry[];
}

export function newCodemodeTrialState(budget: CodemodeTrialBudget = DEFAULT_CODEMODE_TRIAL_BUDGET): CodemodeTrialState {
	return { budget, scriptsExecuted: 0, audit: [] };
}

function scriptHeadOf(code: string): string {
	return (typeof code === "string" ? code : "").slice(0, 160).replace(/\s+/g, " ").trim();
}

function deny(code: CodemodeDecisionCode, reason: string): CodemodeAdmissionDecision {
	return { allowed: false, code, reason: `[amagi codemode-policy] ${reason}` };
}

function allow(): CodemodeAdmissionDecision {
	return { allowed: true, code: "ALLOW", reason: "[amagi codemode-policy] 试点准入通过（子 Agent 禁入+工具面白名单+脚本预算三查全过；判定已记入会话审计）。" };
}

function recordAudit(state: CodemodeTrialState, decision: CodemodeAdmissionDecision, script: { code: string }, options?: CodemodeScriptOptions): void {
	state.audit.push({
		ts: new Date().toISOString(),
		allowed: decision.allowed,
		code: decision.code,
		scriptHead: scriptHeadOf(script.code),
		...(options?.maxOutputTokens !== undefined ? { maxOutputTokens: options.maxOutputTokens } : {}),
		...(options?.timeoutMs !== undefined ? { timeoutMs: options.timeoutMs } : {}),
	});
	if (state.audit.length > AUDIT_MAX_ENTRIES) state.audit.splice(0, state.audit.length - AUDIT_MAX_ENTRIES);
}

/**
 * 会话级 codemode 准入判定（纯函数 + 状态记录；fail-closed）。
 *
 * 判定序（先身份后会话后脚本；每一步拒绝即返回，全部通过才 allow）：
 *  1. subagent → 恒 deny（设计 §6.1 裁定：models.* 桥无公开拦截/限制 API——该判定与脚本内容
 *     无关，子 Agent 会话不存在「显式开启」逃生门）；
 *  2. 未显式开启 → deny（默认面：生产 Leader 会话同样不开）；
 *  3. 会话工具面校验：未声明 → 拒；含写类工具 → 拒；含白名单外工具 → 拒（封闭集）；
 *  4. 会话预算：已放行脚本数达上限 → 拒；
 *  5. 脚本选项：未声明 @options → 拒（宿主默认超试点预算，须显式声明）；声明不可解析 → 拒；
 *     max_output_tokens/timeout_ms 超上限 → 拒；
 *  6. 全过 → allow（scriptsExecuted+1；allow 与 deny 均记审计）。
 */
export function decideCodemodeAdmission(
	identity: CodemodeSessionIdentity,
	script: { code: string },
	state: CodemodeTrialState,
): CodemodeAdmissionDecision {
	// 1. 子 Agent 恒 deny（设计裁定；先于一切开关——显式开启 env 在子 Agent 分支无救）
	if (identity.subagent) {
		const d = deny("SUBAGENT_ALWAYS_DENIED",
			"codemode 不对受限子 Agent 开放（设计 §6.1 裁定：1.0.2 无 models.* 桥拦截/限制 API，也不能用脚本扫描/提示词禁令替代硬限制）——本会话为子 Agent 分支，恒拒绝；程序化只读取证须由 Leader 在隔离试点会话执行。");
		recordAudit(state, d, script);
		return d;
	}
	// 2. 默认 deny：Leader 会话也须显式开启（试点装配方注入 AMAGI_CODEMODE_TRIAL=1）
	if (!identity.trialEnabled) {
		const d = deny("TRIAL_NOT_ENABLED",
			"codemode 试点未开启（默认 deny）——仅获授权的隔离 Leader 试点会话可显式开启（装配 env AMAGI_CODEMODE_TRIAL=1 + 只读工具面 + 预算声明）；生产会话一律拒绝。");
		recordAudit(state, d, script);
		return d;
	}
	// 3. 会话工具面白名单校验（封闭集：写类缺席 + 白名单内 + 允许发现场；未声明 fail-closed）
	const tools = identity.sessionTools;
	if (tools.length === 0) {
		const d = deny("SESSION_TOOLS_UNDECLARED",
			"试点会话工具面未声明（AMAGI_CODEMODE_TRIAL_TOOLS 缺失或为空）——fail-closed：装配方必须声明会话实际工具面供白名单校验，不能默认放行。");
		recordAudit(state, d, script);
		return d;
	}
	const writeHits = tools.filter((t) => CODEMODE_WRITE_CAPABLE_TOOLS.has(t));
	if (writeHits.length > 0) {
		const d = deny("WRITE_TOOL_IN_SESSION",
			`试点会话工具面含写类/副作用工具（${writeHits.join(", ")}）——写面必须物理缺席（defaultTools/--tools 严格名单不含写类），不能依赖运行时拦截兜底；收窄工具面后重新开启。`);
		recordAudit(state, d, script);
		return d;
	}
	const outside = tools.filter((t) => !CODEMODE_READ_ONLY_TOOL_WHITELIST.has(t) && !CODEMODE_DISCOVERY_TOOLS.has(t));
	if (outside.length > 0) {
		const d = deny("TOOL_OUTSIDE_WHITELIST",
			`试点会话工具面含白名单外工具（${outside.join(", ")}）——白名单为封闭集（只读 read/grep/find/ls + 发现场 codemode/tool_search）；扩展工具面须先单独论证准入，不在本试点范围。`);
		recordAudit(state, d, script);
		return d;
	}
	// 4. 会话预算（治理面：先于脚本级检查——预算耗尽时脚本内容不影响结论）
	if (state.scriptsExecuted >= state.budget.maxScriptsPerSession) {
		const d = deny("SCRIPT_BUDGET_EXHAUSTED",
			`试点脚本预算已耗尽（本会话已放行 ${state.scriptsExecuted}/${state.budget.maxScriptsPerSession} 次）——对照试验的会话样本量已到治理上限；如需扩量须重新授权并新建隔离试点会话。`);
		recordAudit(state, d, script);
		return d;
	}
	// 5. 脚本选项（试点脚本必须首行显式声明预算内选项；未声明=宿主默认超预算）
	const options = parseCodemodeScriptOptions(script.code);
	if (!options.present) {
		const d = deny("SCRIPT_OPTIONS_UNDECLARED",
			"脚本未声明 // @options 预算行——宿主默认（max_output_tokens=10000、无 timeout）超出试点预算（默认 2000 tokens/60s）；试点脚本必须在首行显式声明预算内选项。");
		recordAudit(state, d, script, options);
		return d;
	}
	if (options.invalidReason) {
		const d = deny("SCRIPT_OPTIONS_INVALID", `脚本 @options 声明不可解析——${options.invalidReason}；fail-closed 拒绝，修正声明后重试。`);
		recordAudit(state, d, script, options);
		return d;
	}
	if (options.maxOutputTokens === undefined || options.maxOutputTokens > state.budget.maxOutputTokensPerScript) {
		const d = deny("SCRIPT_OUTPUT_TOKENS_OVER_CAP",
			`脚本 max_output_tokens 声明超出试点上限（声明 ${options.maxOutputTokens ?? "未声明"}，上限 ${state.budget.maxOutputTokensPerScript}）——收窄输出声明后重试。`);
		recordAudit(state, d, script, options);
		return d;
	}
	if (options.timeoutMs === undefined || options.timeoutMs > state.budget.maxTimeoutMsPerScript) {
		const d = deny("SCRIPT_TIMEOUT_OVER_CAP",
			`脚本 timeout_ms 声明超出试点上限（声明 ${options.timeoutMs ?? "未声明"}，上限 ${state.budget.maxTimeoutMsPerScript} ms）——试点要求显式限时且不超上限（宿主默认无超时，不接受）。`);
		recordAudit(state, d, script, options);
		return d;
	}
	// 6. 全过：放行并登记（计数+审计）
	const d = allow();
	state.scriptsExecuted += 1;
	recordAudit(state, d, script, options);
	return d;
}

// ── 模块级会话单例（对齐 admission.ts 模式：Leader 会话装配一次，判定期内复用） ──

let sessionState: CodemodeTrialState | undefined;

/** 会话试点状态（按 env 惰性初始化；接线方在 session_start 重置——试点配置随会话生，不跨会话）。 */
export function sessionCodemodeTrialState(env: NodeJS.ProcessEnv = process.env): CodemodeTrialState {
	if (sessionState === undefined) sessionState = newCodemodeTrialState(codemodeTrialBudget(env));
	return sessionState;
}

/** 会话重置（接线方挂 session_start/session_shutdown；测试隔离同用）。 */
export function resetCodemodeTrialSession(): void {
	sessionState = undefined;
}

/** 审计导出（治理面速查；结构化 code 优先，脚本摘要辅助定位——完整证据以会话日志为准）。 */
export function codemodeAuditLogOf(state: CodemodeTrialState): readonly CodemodeAuditEntry[] {
	return [...state.audit];
}

/** 测试隔离：清空模块级会话状态。 */
export function resetCodemodePolicyForTest(): void {
	sessionState = undefined;
}

// ═════════════════════════════════════════════════════════════════════════════
// B5A（ev-20261012-7517d8 设计 §5.1/§5.2/§5.4）：受控模式（grant 驱动）运行时执法状态机。
//
// 与上方 TRIAL 试点路径的关系：TRIAL（AMAGI_CODEMODE_TRIAL=1 隔离 Leader 试点）语义零变化；
// 受控模式是「会话可写、脚本只读」的新通道——准入事实源是冻结 PermissionGrant.codemode 子对象
// （父端四方交集产物，经 AMAGI_PERMISSION_GRANT env 交付），不是 env 自声明。批A 预算全部以
// 进程内状态强制（设计 §5.3：首个接线批仅全新一次性 JSON 试点，无持久账本——批B 迁移）。
// ═════════════════════════════════════════════════════════════════════════════

import { createHash } from "node:crypto";
import type { CodemodeGrantBudget, ReadOnlyCodemodeGrant } from "./contracts/permission.ts";

/** §5.1 首轮实现常量（amagi 新增限额，非宿主既有保证；不增加可调键）。 */
export const CODEMODE_MAX_NESTED_CALLS_PER_SCRIPT = 128;
export const CODEMODE_MAX_NESTED_CALLS_PER_SESSION = 1024;
export const CODEMODE_MAX_NESTED_IN_FLIGHT = 4;
/** 外层脚本并发 1（同一时刻至多一个在执行脚本；第二个并发调用按 STATE_UNAVAILABLE 拒）。 */
export const CODEMODE_MAX_CONCURRENT_OUTER = 1;

/** 脚本摘要（sha256 hex + 字节数——审计只存摘要与长度，不存原文片段，设计 §5.1/§5.4）。
 *  B5A 修复轮 F11：hash 输入改为 UTF-16 码元编码（utf16le 原样保留 lone surrogate，不做 U+FFFD
 *  替换）——摘要对 JS 字符串单射，任意改参（含非良构 Unicode）必致摘要不一致；codeBytes 同口径。 */
export function codemodeScriptDigest(code: string): { scriptHash: string; codeBytes: number } {
	const src = typeof code === "string" ? code : "";
	return { scriptHash: createHash("sha256").update(src, "utf16le").digest("hex"), codeBytes: Buffer.byteLength(src, "utf16le") };
}

/** 受控审计条目（每次 deny/reserve/start/end 一条；脚本正文/参数/结果/密钥不进审计——设计 §5.4）。 */
export interface CodemodeControlledAuditEntry {
	readonly ts: string;
	readonly phase: "deny" | "reserve" | "start" | "end";
	readonly code: CodemodeDecisionCode;
	readonly toolCallId?: string;
	readonly scriptHash?: string;
	readonly codeBytes?: number;
	readonly declaredTokens?: number;
	readonly declaredMs?: number;
	/** reserve 后余额（scripts/tokens/ms）。 */
	readonly reservedAfter?: { scripts: number; tokens: number; ms: number };
	/** end 专属：真实结束状态/耗时/nested 数与完整性标志。B5B（§5.4）：argumentsComplete/
	 *  resultsCaptured 恒 false——nested 记录不含参数/结果正文，「有记录」不冒充可重放全文。 */
	readonly outcome?: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean; argumentsComplete: false; resultsCaptured: false };
	/** 任务身份元数据（B5A 修复轮：§5.4 start/identity 落实——reserve/start/end 随行；不含敏感载荷）。 */
	readonly identity?: { taskId?: string; agent?: string; runId?: string };
}

/** 单次脚本预留（原子预留产物；绑定 toolCallId 与脚本摘要——execute 入口复核防后续改参）。 */
export interface CodemodeReservation {
	readonly reservationId: string;
	readonly toolCallId: string;
	readonly scriptHash: string;
	readonly declaredTokens: number;
	readonly declaredMs: number;
	/** nested 计数与本脚本在选上限（128/脚本；排队计入；错误也计数）。 */
	nestedCalls: number;
	/** 在选 nested 信号量占用数（≤4；排队不占）。 */
	nestedInFlight: number;
}

/** B5B：持久账本通道（codemode-ledger 句柄的结构投影——策略只依赖追加语义，不依赖文件细节）。 */
export interface CodemodeLedgerChannel {
	readonly accountId: string;
	appendReserve(input: { toolCallId: string; scriptHash: string; tokens: number; ms: number }): boolean;
	appendStart(toolCallId: string): boolean;
	appendEnd(toolCallId: string, outcome: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean }): boolean;
}

/** 受控模式执法状态（批A 进程内预算；B5B 起 ledger 在场时预留先落盘成功才放行——跨进程强制，
 *  快照播种后同口径执法。无 ledger = 批A 纯内存语义，保持既有测试/隔离用例零变化）。 */
export interface CodemodeControlledState {
	readonly grant: ReadOnlyCodemodeGrant;
	readonly budget: CodemodeGrantBudget;
	/** 已预留（声明预算之和，不冒充实际计费）：不返还（失败/超时/取消均不退——防重试重复消费）。 */
	reservedScripts: number;
	reservedTokens: number;
	reservedMs: number;
	/** 会话累计 nested 调用数（含排队与失败；上限 1024）。 */
	sessionNestedCalls: number;
	/** 活动脚本预留（toolCallId → reservation；外层并发 ≤1）。 */
	readonly active: Map<string, CodemodeReservation>;
	/** 审计（有界 FIFO，溢出丢最旧；转发源与完整证据以会话 appendEntry 记录为准——修复轮 F06：
	 *  adapter 转发改为自身增量队列 + onAudit 观察者，不再对本数组保存绝对下标，溢出不静默停写）。 */
	readonly audit: CodemodeControlledAuditEntry[];
	/** 任务身份（审计随行；构造时冻结）。 */
	readonly identity?: { taskId?: string; agent?: string; runId?: string };
	/** 审计观察者（策略记录时同步回调——adapter 消费入自身转发队列；单一事实源仍在策略）。 */
	readonly onAudit?: (entry: CodemodeControlledAuditEntry) => void;
	/** B5B：持久账本通道（adapter 在账本打开成功后挂接；在场时 reserve/start/end 先落盘成功
	 *  才放行/登记——「预留落盘成功才执行」）。可变字段：播种时注入。 */
	ledger?: CodemodeLedgerChannel;
}

const CONTROLLED_AUDIT_MAX_ENTRIES = 256;

/** 受控状态构造（grant 须已过契约校验——adapter 接线前验证）。 */
export function newCodemodeControlledState(
	grant: ReadOnlyCodemodeGrant,
	opts?: { identity?: { taskId?: string; agent?: string; runId?: string }; onAudit?: (entry: CodemodeControlledAuditEntry) => void; ledger?: CodemodeLedgerChannel },
): CodemodeControlledState {
	return {
		grant,
		budget: grant.budget,
		reservedScripts: 0,
		reservedTokens: 0,
		reservedMs: 0,
		sessionNestedCalls: 0,
		active: new Map(),
		audit: [],
		...(opts?.identity !== undefined ? { identity: opts.identity } : {}),
		...(opts?.onAudit !== undefined ? { onAudit: opts.onAudit } : {}),
		...(opts?.ledger !== undefined ? { ledger: opts.ledger } : {}),
	};
}

/** B5B：账本快照播种（跨进程续跑：reserved 三轴 + 保守 nested + 执行资格消费集进入本进程状态）。
 *  消费集返回给 adapter 并入 consumedExecutes（持久化语义与批A 进程内集合等强）。 */
export function applyCodemodeLedgerSnapshot(
	state: CodemodeControlledState,
	snapshot: { reservedScripts: number; reservedTokens: number; reservedMs: number; sessionNestedCalls: number; consumedToolCallIds: readonly string[] },
): readonly string[] {
	state.reservedScripts = snapshot.reservedScripts;
	state.reservedTokens = snapshot.reservedTokens;
	state.reservedMs = snapshot.reservedMs;
	state.sessionNestedCalls = snapshot.sessionNestedCalls;
	return snapshot.consumedToolCallIds;
}

function recordControlledAudit(state: CodemodeControlledState, entry: CodemodeControlledAuditEntry): void {
	const stamped: CodemodeControlledAuditEntry = entry.phase === "deny" ? entry : { ...entry, ...(state.identity !== undefined ? { identity: state.identity } : {}) };
	state.audit.push(stamped);
	if (state.audit.length > CONTROLLED_AUDIT_MAX_ENTRIES) state.audit.splice(0, state.audit.length - CONTROLLED_AUDIT_MAX_ENTRIES);
	try { state.onAudit?.(stamped); } catch { /* lint-exempt:观察者异常不影响策略执法（adapter 侧自关） */ }
}

/**
 * 受控模式单次脚本准入（§5.2 原子预留：先校验后预留，任一拒绝零扣款）：
 *  usedScripts+1≤capScripts && reservedTokens+declared≤capTotalTokens && reservedMs+declared≤capTotalMs。
 * 校验序：grant 子对象在场且只读（GRANT_MISSING/BRIDGE_NOT_DISABLED）→ 预算内 @options 声明
 * （复用既有 options 校验码）→ 外层并发 ≤1（STATE_UNAVAILABLE）→ 原子预留。
 */
export function admitControlledCodemodeScript(
	state: CodemodeControlledState,
	script: { code: string },
	options?: { toolCallId?: string },
): { allowed: true; reservation: CodemodeReservation } | { allowed: false; code: CodemodeDecisionCode; reason: string } {
	const digest = codemodeScriptDigest(script.code);
	const denyAudit = (code: CodemodeDecisionCode) => {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code, ...digest });
	};
	const grant = state.grant;
	if (grant.mode !== "read-only") {
		denyAudit("GRANT_MISSING");
		return { allowed: false, code: "GRANT_MISSING", reason: "[amagi codemode] 冻结授予非只读模式（mode!=read-only）——受控装配拒绝执行" };
	}
	if (grant.models !== false) {
		denyAudit("BRIDGE_NOT_DISABLED");
		return { allowed: false, code: "BRIDGE_NOT_DISABLED", reason: "[amagi codemode] 冻结授予 models 桥未关闭——受控装配拒绝执行（本批不存在 models:true 逃生舱）" };
	}
	// @options 协议校验（宿主协议口径，非关键字扫描）：缺声明/非法/超单次上限均拒。
	const parsed = parseCodemodeScriptOptions(script.code);
	if (!parsed.present) {
		denyAudit("SCRIPT_OPTIONS_UNDECLARED");
		return { allowed: false, code: "SCRIPT_OPTIONS_UNDECLARED", reason: "[amagi codemode] 脚本未声明 // @options 预算行——受控模式要求首行显式声明（max_output_tokens + timeout_ms），不接受宿主缺省" };
	}
	if (parsed.invalidReason) {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code: "OPTIONS_INVALID", ...digest });
		return { allowed: false, code: "OPTIONS_INVALID", reason: `[amagi codemode] 脚本 @options 声明不可解析——${parsed.invalidReason}` };
	}
	if (parsed.maxOutputTokens === undefined || parsed.maxOutputTokens > state.budget.maxOutputTokensPerScript) {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code: "SCRIPT_OUTPUT_TOKENS_OVER_CAP", ...digest, declaredTokens: parsed.maxOutputTokens });
		return { allowed: false, code: "SCRIPT_OUTPUT_TOKENS_OVER_CAP", reason: `[amagi codemode] max_output_tokens 声明 ${parsed.maxOutputTokens ?? "未声明"} 超出单次上限 ${state.budget.maxOutputTokensPerScript}` };
	}
	if (parsed.timeoutMs === undefined || parsed.timeoutMs > state.budget.maxTimeoutMsPerScript) {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code: "SCRIPT_TIMEOUT_OVER_CAP", ...digest, declaredMs: parsed.timeoutMs });
		return { allowed: false, code: "SCRIPT_TIMEOUT_OVER_CAP", reason: `[amagi codemode] timeout_ms 声明 ${parsed.timeoutMs ?? "未声明"} 超出单次上限 ${state.budget.maxTimeoutMsPerScript} ms（不接受无超时）` };
	}
	// 外层并发 ≤1。
	if (state.active.size >= CODEMODE_MAX_CONCURRENT_OUTER) {
		denyAudit("STATE_UNAVAILABLE");
		return { allowed: false, code: "STATE_UNAVAILABLE", reason: `[amagi codemode] 外层脚本并发上限 ${CODEMODE_MAX_CONCURRENT_OUTER}——已有脚本在执行，本次拒绝（排队重试不增加额度）` };
	}
	// 原子预留（声明预算之和；不返还）。
	const nextScripts = state.reservedScripts + 1;
	const nextTokens = state.reservedTokens + parsed.maxOutputTokens;
	const nextMs = state.reservedMs + parsed.timeoutMs;
	if (nextScripts > state.budget.maxScriptsPerSession || nextTokens > state.budget.maxTotalOutputTokens || nextMs > state.budget.maxTotalTimeoutMs) {
		denyAudit("BUDGET_EXHAUSTED");
		return {
			allowed: false,
			code: "BUDGET_EXHAUSTED",
			reason: `[amagi codemode] 会话聚合预算已尽（脚本 ${state.reservedScripts}/${state.budget.maxScriptsPerSession}，声明 tokens ${state.reservedTokens}+${parsed.maxOutputTokens}>${state.budget.maxTotalOutputTokens} 或 ms ${state.reservedMs}+${parsed.timeoutMs}>${state.budget.maxTotalTimeoutMs}）——预留不返还，新试点须显式新任务授权`,
		};
	}
	const toolCallId = options?.toolCallId ?? `anon-${digest.scriptHash.slice(0, 12)}`;
	// B5B：预留落盘成功才执行（§5.3）。写失败 ⇒ 本次拒绝（STATE_UNAVAILABLE）、零扣款零预留——
	// 不能在账本缺记的状态下放行执行（跨进程强制面出现记账洞）。
	if (state.ledger !== undefined && !state.ledger.appendReserve({ toolCallId, scriptHash: digest.scriptHash, tokens: parsed.maxOutputTokens, ms: parsed.timeoutMs })) {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code: "STATE_UNAVAILABLE", toolCallId, ...digest, declaredTokens: parsed.maxOutputTokens, declaredMs: parsed.timeoutMs });
		return { allowed: false, code: "STATE_UNAVAILABLE", reason: "[amagi codemode] 持久账本 reserve 写入失败（§5.3 预留落盘成功才执行）——本次拒绝并关闭后续 codemode（fail-closed）" };
	}
	state.reservedScripts = nextScripts;
	state.reservedTokens = nextTokens;
	state.reservedMs = nextMs;
	const reservation: CodemodeReservation = {
		reservationId: `${toolCallId}#${nextScripts}`,
		toolCallId,
		scriptHash: digest.scriptHash,
		declaredTokens: parsed.maxOutputTokens,
		declaredMs: parsed.timeoutMs,
		nestedCalls: 0,
		nestedInFlight: 0,
	};
	state.active.set(toolCallId, reservation);
	recordControlledAudit(state, {
		ts: new Date().toISOString(), phase: "reserve", code: "ALLOW", toolCallId,
		...digest, declaredTokens: parsed.maxOutputTokens, declaredMs: parsed.timeoutMs,
		reservedAfter: { scripts: nextScripts, tokens: nextTokens, ms: nextMs },
	});
	return { allowed: true, reservation };
}

/** execute 入口复核（设计 §3.2-4：防后续 tool_call 改参导致预算校验与执行脚本不一致；不重复扣款）。 */
export function verifyReservedScript(
	state: CodemodeControlledState,
	toolCallId: string,
	script: { code: string },
): { ok: true; reservation: CodemodeReservation } | { ok: false; reason: string } {
	const reservation = state.active.get(toolCallId);
	if (reservation === undefined) {
		return { ok: false, reason: "[amagi codemode] 无活动预留（STATE_UNAVAILABLE）——先经准入预留再执行" };
	}
	const digest = codemodeScriptDigest(script.code);
	if (digest.scriptHash !== reservation.scriptHash) {
		return { ok: false, reason: "[amagi codemode] 执行脚本与预留脚本摘要不一致（TOOLS_CHANGED 口径：输入改变即本次拒绝，重新提交后再计）" };
	}
	return { ok: true, reservation };
}

/** 执行开始登记（B5A 修复轮：§5.4 start 段落实——adapter 在转发真实执行前调用；含身份元数据）。
 *  B5B：返回 false = 账本 start 追加失败——调用方须拒绝本次执行（已预留额度不退还，§5.4 同口径）。 */
export function recordControlledStart(state: CodemodeControlledState, toolCallId: string): boolean {
	const reservation = state.active.get(toolCallId);
	if (state.ledger !== undefined && !state.ledger.appendStart(toolCallId)) {
		recordControlledAudit(state, { ts: new Date().toISOString(), phase: "deny", code: "STATE_UNAVAILABLE", toolCallId, ...(reservation !== undefined ? { scriptHash: reservation.scriptHash } : {}) });
		return false;
	}
	recordControlledAudit(state, {
		ts: new Date().toISOString(), phase: "start", code: "ALLOW", toolCallId,
		...(reservation !== undefined ? { scriptHash: reservation.scriptHash } : {}),
	});
	return true;
}

/** 适配器层拒绝登记（B5A 修复轮：装配身份认证失败等 §5.4 deny 段随会话记录；零正文，只存摘要）。 */
export function recordControlledDenyEntry(state: CodemodeControlledState, input: { code: CodemodeDecisionCode; toolCallId?: string; script?: string }): void {
	recordControlledAudit(state, {
		ts: new Date().toISOString(), phase: "deny", code: input.code,
		...(input.toolCallId !== undefined ? { toolCallId: input.toolCallId } : {}),
		...(input.script !== undefined ? codemodeScriptDigest(input.script) : {}),
	});
}

/** nested 调用准入（§5.2：并发闸在委托真实执行前；排队计入；错误也计数；会话级 1024 封顶）。 */
export function admitControlledNestedCall(
	state: CodemodeControlledState,
	reservation: CodemodeReservation,
): { ok: true } | { ok: false; code: CodemodeDecisionCode; reason: string } {
	if (reservation.nestedCalls + 1 > CODEMODE_MAX_NESTED_CALLS_PER_SCRIPT) {
		return { ok: false, code: "BUDGET_EXHAUSTED", reason: `[amagi codemode] 单脚本 nested 调用上限 ${CODEMODE_MAX_NESTED_CALLS_PER_SCRIPT}（含排队与失败）——本次拒绝` };
	}
	if (state.sessionNestedCalls + 1 > CODEMODE_MAX_NESTED_CALLS_PER_SESSION) {
		return { ok: false, code: "BUDGET_EXHAUSTED", reason: `[amagi codemode] 会话 nested 调用上限 ${CODEMODE_MAX_NESTED_CALLS_PER_SESSION}——本次拒绝` };
	}
	reservation.nestedCalls += 1;
	state.sessionNestedCalls += 1;
	return { ok: true };
}

/** 脚本结束登记（释放活动槽位；不归还已预留预算；记录真实状态/nested 数/完整性）。
 *  B5B：账本 end 追加失败 ⇒ 返回 false（宿主真实结果保留、调用方标审计缺口并暂停后续 codemode
 *  ——§5.4 结束审计失败语义同口径；该脚本按未完结保守重建，额度口径不变）。 */
export function settleControlledCodemodeScript(
	state: CodemodeControlledState,
	toolCallId: string,
	outcome: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean },
): boolean {
	const reservation = state.active.get(toolCallId);
	state.active.delete(toolCallId);
	// F05（审核终裁）：结算 outcome 保守规范化单源——nestedCalls 取传入值与预留累计的 max
	//（导出结算接口传 0 时不得低于真实累计），ledger 与审计共用同一规范化结果（双写口径一致）。
	const normalized: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean } = {
		ok: outcome.ok,
		durationMs: outcome.durationMs,
		nestedCalls: Math.max(outcome.nestedCalls, reservation?.nestedCalls ?? 0),
		callsComplete: outcome.callsComplete,
	};
	const ledgerEndOk = state.ledger === undefined ? true : state.ledger.appendEnd(toolCallId, normalized);
	recordControlledAudit(state, {
		ts: new Date().toISOString(), phase: "end", code: normalized.ok ? "ALLOW" : "SCRIPT_BUDGET_EXHAUSTED",
		toolCallId, ...(reservation !== undefined ? { scriptHash: reservation.scriptHash } : {}),
		outcome: { ...normalized, argumentsComplete: false, resultsCaptured: false },
	});
	return ledgerEndOk;
}

/** 受控审计导出（有界快照；完整证据以会话 appendEntry（amagi-codemode-audit）记录为准）。 */
export function controlledAuditLogOf(state: CodemodeControlledState): readonly CodemodeControlledAuditEntry[] {
	return [...state.audit];
}

// ═════════════════════════════════════════════════════════════════════════
// B5C（ev-20261012-7517d8 设计 §7 意识层）：实际生效工具面状态行——Leader 投影。
//
// 只描述真实开关状态，不代替批A/B 机制（受控装配/持久账本仍为准入事实源）；off 措辞不暗示
// 可调用。子进程（AMAGI_SUBAGENT=1）不走本函数（子端投影在 codemode-adapter，grant/账户/账本
// 驱动）；trial 试点会话是唯一可能为 read-only 的 Leader 形态，且 models 桥未受控——如实标注，
// 不冒充受控装配面。
// ═════════════════════════════════════════════════════════════════════════

/** Leader 会话 codemode 状态行（实际生效工具面投影；env 恒定 → 会话内字节稳定）。 */
export function codemodeLeaderFaceLine(env: NodeJS.ProcessEnv = process.env): string {
	if (env.AMAGI_CODEMODE_DISABLE === "1") {
		return "[amagi codemode 状态] codemode: off｜AMAGI_CODEMODE_DISABLE=1 紧急关闭——本会话不可用（不暗示可调用；不花轮次尝试解锁）";
	}
	const identity = codemodeSessionIdentityFromEnv(env);
	if (identity.subagent) {
		// 防御：本函数只服务 Leader 投影；子进程误用路径如实 off（子 Agent 恒 deny）。
		return "[amagi codemode 状态] codemode: off｜子 Agent 分支恒 deny——不可用，直接用既有只读工具";
	}
	if (!identity.trialEnabled) {
		return "[amagi codemode 状态] codemode: off｜本会话未启用（默认 deny）——不暗示可调用、不花轮次尝试解锁；子任务受控准入由 amagi.json codemode 节与任务 scope 决定，与本行无关";
	}
	// C11 隔离试点：唯一可能为 read-only 的 Leader 形态——按策略面如实投影（含 fail-closed 拒因）。
	if (identity.sessionTools.length === 0) {
		return "[amagi codemode 状态] codemode: off｜试点开启但会话工具面未声明（fail-closed）——不可用";
	}
	const writeHits = identity.sessionTools.filter((t) => CODEMODE_WRITE_CAPABLE_TOOLS.has(t));
	if (writeHits.length > 0) {
		return `[amagi codemode 状态] codemode: off｜试点会话工具面含写类工具（${writeHits.join(", ")}）——策略拒启，不可用`;
	}
	const outside = identity.sessionTools.filter((t) => !CODEMODE_READ_ONLY_TOOL_WHITELIST.has(t) && !CODEMODE_DISCOVERY_TOOLS.has(t));
	if (outside.length > 0) {
		return `[amagi codemode 状态] codemode: off｜试点会话工具面含白名单外工具（${outside.join(", ")}）——策略拒启，不可用`;
	}
	const budget = codemodeTrialBudget(env);
	return `[amagi codemode 状态] codemode: read-only 试点（C11 隔离会话）｜tools=${identity.sessionTools.join(",")}｜单次≤${budget.maxOutputTokensPerScript}tok/${budget.maxTimeoutMsPerScript}ms·会话≤${budget.maxScriptsPerSession} 脚本｜models 桥未受控（不得在脚本内使用）`;
}
