/**
 * status-ui.ts — TUI 状态栏/widget 渲染 SubAgent 编排实况（P4-1）。
 *
 * dist API 证据（node_modules/@earendil-works/pi-coding-agent/dist/core/extensions/types.d.ts）：
 * - L78-79  `ExtensionUIContext.setStatus(key: string, text: string | undefined): void`
 *           "Set status text in the footer/status bar. Pass undefined to clear."
 * - L95-99  `ExtensionUIContext.setWidget(key, content: string[] | undefined, options?: ExtensionWidgetOptions)`
 *           "Set a widget to display above or below the editor. Accepts string array ..."
 * - L41-46  `WidgetPlacement = "aboveEditor" | "belowEditor"`；ExtensionWidgetOptions.placement 默认 "aboveEditor"
 * - L205-211 `ExtensionMode = "tui" | "rpc" | "json" | "print"`；ExtensionContext.mode：
 *           "Use "tui" to guard terminal-only UI such as custom components."
 * - 刷新机制：TaskRegistry 无事件发射器（task-registry.ts 为纯内存 Map），
 *   dist 未提供 registry 订阅；setStatus/setWidget 可随时调用 → 采用定时轮询（默认 2s，unref），
 *   并暴露 refresh() 供事件驱动场景额外触发。
 * - 最近结算自交付：无在途时状态面不清空——settledTtlMs（默认 15s）内终态
 *   （done/error/cancelled/answered）以紧凑计数驻留，blocked 无 TTL 常驻独立计数；
 *   全部纯派生自 TaskRecord.endedAt/blockedAt，无第二状态源、无新增计时器
 *   （轮询/事件刷新在 TTL 到期后自动清空）。状态栏与 widget 一样按终端列宽 trimDisplay。
 *
 * 接线说明（index.ts 统一接线时需要的最小改动，本任务不改 index.ts）：
 *   1) 顶部 import：
 *        import { createStatusUI } from "./status-ui.ts";
 *   2) amagiCore() 内声明模块级持有：
 *        let statusUI: ReturnType<typeof createStatusUI> | undefined;
 *   3) session_start handler 末尾（registry restore 之后）追加：
 *        statusUI?.stop();
 *        statusUI = createStatusUI({ taskRegistry: registry, ctx });
 *        statusUI.start();
 *   4) session_shutdown handler 内追加：
 *        statusUI?.stop(); statusUI = undefined;
 *   5)（可选，降低刷新延迟）注册事件驱动刷新：
 *        pi.on("tool_execution_end", () => statusUI?.refresh());
 *        pi.on("agent_end", () => statusUI?.refresh());
 *      轮询已兜底，事件仅加速感知；不加也正确。
 */

import type { TaskRecord, TaskStatus } from "./task-registry.ts";

/** 注入的最小 registry 读面（结构子集，mock 友好）。 */
export interface StatusUIRegistry {
	list(): Readonly<TaskRecord>[];
	/** v1.5.185 事件响应订阅（可选）：registry 变更立即 refresh，轮询 interval 降为兜底心跳。 */
	onChange?(fn: () => void): () => void;
}

/** 注入的最小 ctx 面（ExtensionContext 结构子集；真实 ctx 直接兼容）。 */
export interface StatusUICtx {
	mode: string;
	ui: {
		setStatus(key: string, text: string | undefined): void;
		setWidget(key: string, content: string[] | undefined, options?: { placement?: "aboveEditor" | "belowEditor" }): void;
	};
}

export interface StatusUIDeps {
	taskRegistry: StatusUIRegistry;
	ctx: StatusUICtx;
	/** 轮询间隔 ms，默认 2000；测试可注入小值。 */
	intervalMs?: number;
	/** 同时展示的 running 任务上限，默认 5（超出折叠为计数行）。 */
	maxTasks?: number;
	/** 单行最大字符数（code point 计），默认 96。 */
	maxWidth?: number;
	/** pi 0.83 单 widget 最多显示 10 行；默认 10，超出前由本模块主动折叠并保留导航提示。 */
	maxLines?: number;
	/** 最近结算可见窗口 ms（默认 15000）：纯派生自 TaskRecord.endedAt，到期随下次刷新自动消失。 */
	settledTtlMs?: number;
	/** 终端列数读取器；生产缺省 process.stdout.columns，测试可注入。 */
	getColumns?: () => number | undefined;
}

export interface StatusUI {
	/** 启动：TUI 模式下立即渲染一次并开始轮询；非 TUI 模式 no-op。 */
	start(): void;
	/** 停止：清轮询并清空状态栏与 widget。 */
	stop(): void;
	/** 立即重渲染一次（事件驱动刷新入口）。永不抛错。 */
	refresh(): void;
	/** 8月迭代 pi-0.84 配合 P2⑥：ui_prompt_start/end 等待用户输入态——true 时状态栏
	 *  前置「⏸等输入」短标记（title 有界 ≤24 格），false 清除；不改变既有状态优先级逻辑。 */
	setUiPromptWaiting(active: boolean, title?: string): void;
	/** 纯函数：渲染 widget 行（无在途/最近结算/blocked 时返回 []；严格 ≤ maxLines）。now 可注入便于测试。 */
	renderLines(now?: number): string[];
	/** 纯函数：渲染状态栏文本（无可展示状态返回 undefined；按当前终端列宽截断）。 */
	renderStatusText(now?: number): string | undefined;
}

const STATUS_KEY = "amagi:tasks";
const WIDGET_KEY = "amagi:tasks";
const DEFAULT_INTERVAL_MS = 2000;
const DEFAULT_MAX_TASKS = 5;
const DEFAULT_MAX_WIDTH = 96;
const DEFAULT_MAX_LINES = 10;

/** editor widget 可用宽度：预留两列避免终端自动换行；非 TTY 时保持配置上限。 */
export function resolveWidgetWidth(configured: number, columns: number | undefined): number {
	if (typeof columns !== "number" || !Number.isFinite(columns) || columns <= 0) return configured;
	return Math.max(8, Math.min(configured, Math.floor(columns) - 2));
}

/** 常驻面板与 #panel 路由共享的唯一编号顺序。queued 也是可钻取的在途任务。 */
export function selectPanelTasks(tasks: Readonly<TaskRecord>[]): Readonly<TaskRecord>[] {
	return tasks
		.filter((r) => r.status === "running" || r.status === "queued")
		.sort((a, b) => a.startedAt - b.startedAt);
}

/** 最近结算默认可见窗口：15s。刚结束的编排结果在状态面短暂驻留（终态自交付），到期自动消失。 */
export const DEFAULT_SETTLED_TTL_MS = 15_000;

/**
 * 终态结算符号表（与 task-registry TERMINAL 一致的小静态表）：✓done ✗error ⊘cancelled ↩answered。
 * Object 键序即固定展示顺序（字符串键保持插入序）。
 */
const SETTLED_SYMBOL: Partial<Record<TaskStatus, string>> = {
	done: "✓",
	error: "✗",
	cancelled: "⊘",
	answered: "↩",
	truncated: "⚠",
	// ev-20260908-f189e7：外部处置终态（非放弃——产物已在外部采用，与 cancelled ⊘ 区分）
	"resolved-external": "✅",
};

/**
 * 最近结算（纯选择，无第二状态源/无计时器）：终态且 endedAt 距 now 不超过 ttlMs。
 * 无 endedAt 的终态记录无法派生结算时刻 → 不计入；按 endedAt 新→旧排序（顺序固定）。
 */
export function selectRecentSettled(tasks: Readonly<TaskRecord>[], now: number, ttlMs: number = DEFAULT_SETTLED_TTL_MS): Readonly<TaskRecord>[] {
	return tasks
		.filter((r) => SETTLED_SYMBOL[r.status] !== undefined && Number.isFinite(r.endedAt) && now - r.endedAt! <= ttlMs)
		.sort((a, b) => b.endedAt! - a.endedAt!);
}

/** 常驻 blocked（无 TTL，等待用户答复）：按 blockedAt 新→旧（缺省回退 endedAt/startedAt）。 */
export function selectBlockedTasks(tasks: Readonly<TaskRecord>[]): Readonly<TaskRecord>[] {
	const at = (r: Readonly<TaskRecord>): number => r.blockedAt ?? r.endedAt ?? r.startedAt;
	return tasks.filter((r) => r.status === "blocked").sort((a, b) => at(b) - at(a));
}

/** 最近结算紧凑计数段：固定 done✓/error✗/cancelled⊘/answered↩ 顺序，仅非零项，如 "✓2 ✗1"。 */
function settledCountsText(recent: Readonly<TaskRecord>[]): string {
	return Object.entries(SETTLED_SYMBOL).flatMap(([status, sym]) => {
		const n = recent.reduce((acc, r) => acc + (r.status === status ? 1 : 0), 0);
		return n > 0 ? [`${sym}${n}`] : [];
	}).join(" ");
}

/** blocked 行动项摘要（diting 增审 Major-3 中性展示）：handoff=待接手（resume，非提问）；
 *  questions=blockedQuestions 首条 > result 压空白截断 > 占位（与 workflow-board blockedQuestionOf 同规）。 */
function blockedQuestion(rec: Readonly<TaskRecord>): string {
	if (rec.blockReason === "needs-handoff") return "待接手（resume）：settle 产出窗口收口（零写盘），非提问";
	if (rec.blockedQuestions && rec.blockedQuestions.length > 0) return rec.blockedQuestions[0];
	if (rec.result) return trimDisplay(rec.result.replace(/\s+/g, " ").trim(), 120);
	return "（无问题摘要）";
}

/** 时长格式化：<60s→"42s"；<60m→"3m12s"；否则"1h05m"。 */
export function formatDuration(ms: number): string {
	const s = Math.max(0, Math.floor(ms / 1000));
	if (s < 60) return `${s}s`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m${String(s % 60).padStart(2, "0")}s`;
	const h = Math.floor(m / 60);
	return `${h}h${String(m % 60).padStart(2, "0")}m`;
}

/**
 * 终端显示单元截断（v1.5.182 重写）：maxChars 按**终端格**计（CJK 全角=2 格），ANSI 转义序列
 * 不占格、不被切断，截断后若含转义序列自动补 reset 防颜色泄漏；超长追加 "…"。
 * 背景：旧版按 code point 截断，CJK 文本实际宽度可达预算 2 倍 → 终端折行 → overlay 看板帧叠帧
 * 花屏 / widget 行错位（实战 2026-07-30 看板完全不可用截图）。
 */
const ANSI_SGR_RE = /\x1b\[[0-9;]*m/;

/** 单码点显示格数（常见宽字符区间：CJK/谚文/全角/Emoji/大字面）。 */
function cpCells(cp: number): number {
	if (cp < 0x1100) return 1;
	return (cp <= 0x115f || (cp >= 0x2e80 && cp <= 0x9fff) || (cp >= 0xa960 && cp <= 0xa97f)
		|| (cp >= 0xac00 && cp <= 0xd7a3) || (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe30 && cp <= 0xfe6f)
		|| (cp >= 0xff00 && cp <= 0xff60) || (cp >= 0xffe0 && cp <= 0xffe6)
		|| (cp >= 0x1f300 && cp <= 0x1faff) || (cp >= 0x20000 && cp <= 0x3fffd)) ? 2 : 1;
}

/** 字符串终端显示格数（ANSI 序列不计）。 */
export function cellWidth(value: string): number {
	let w = 0;
	for (const seg of String(value).split(new RegExp(`${ANSI_SGR_RE.source}`, "g"))) {
		for (const ch of seg) w += cpCells(ch.codePointAt(0)!);
	}
	return w;
}

export function trimDisplay(value: string, maxChars: number): string {
	if (cellWidth(value) <= maxChars) return value;
	const budget = Math.max(0, maxChars - 1); // 预留 "…" 一格
	let w = 0, out = "", i = 0;
	const s = String(value);
	while (i < s.length) {
		const m = s.slice(i).match(new RegExp(`^${ANSI_SGR_RE.source}`));
		if (m) { out += m[0]; i += m[0].length; continue; } // 转义序列原样透传不占格
		const cp = s.codePointAt(i)!;
		const ch = String.fromCodePoint(cp);
		const cw = cpCells(cp);
		if (w + cw > budget) break;
		out += ch; w += cw; i += ch.length;
	}
	if (ANSI_SGR_RE.test(out)) out += "\x1b[0m";
	return out + "…";
}

/** 模型 + 思考强度展示："provider/name:tier" → "name·思考tier"；"provider/name" → "name"；空 → ""。 */
export function modelWithThinking(model?: string): string {
	if (!model) return "";
	const short = model.includes("/") ? model.split("/").pop()! : model;
	const m = /^(.+?):(max|high|medium|low|minimal)$/.exec(short);
	return m ? `${m[1]}·思考${m[2]}` : short;
}

/** 任务摘要：goal > name > taskId 前缀。 */
function taskSummary(rec: Readonly<TaskRecord>): string {
	return rec.goal || rec.name || rec.taskId.slice(0, 12);
}

/** 最近动作：activityWindow 末条 "type: summary"；无则占位。 */
function latestActivity(rec: Readonly<TaskRecord>): string {
	const win = rec.activityWindow;
	if (!win || win.length === 0) return "等待首个动作…";
	const last = win[win.length - 1];
	return last.summary && last.summary !== last.type ? `${last.type}: ${last.summary}` : last.type;
}

export function createStatusUI(deps: StatusUIDeps): StatusUI {
	const intervalMs = deps.intervalMs ?? DEFAULT_INTERVAL_MS;
	const maxTasks = deps.maxTasks ?? DEFAULT_MAX_TASKS;
	const maxWidth = deps.maxWidth ?? DEFAULT_MAX_WIDTH;
	const maxLines = Math.max(3, deps.maxLines ?? DEFAULT_MAX_LINES);
	const settledTtlMs = deps.settledTtlMs ?? DEFAULT_SETTLED_TTL_MS;
	let timer: ReturnType<typeof setInterval> | undefined;

	function renderLines(now: number = Date.now()): string[] {
		const tasks = deps.taskRegistry.list();
		const running = selectPanelTasks(tasks);
		const width = resolveWidgetWidth(maxWidth, deps.getColumns ? deps.getColumns() : process.stdout.columns);
		if (running.length === 0) return renderIdleLines(tasks, now, width);
		const recent = selectRecentSettled(tasks, now, settledTtlMs);
		const blocked = selectBlockedTasks(tasks);
		let shownCount = Math.min(maxTasks, running.length);
		while (shownCount > 0) {
			const hiddenCount = running.length - shownCount;
			const requiredLines = 1 + shownCount * 2 + (hiddenCount > 0 ? 1 : 0);
			if (requiredLines <= maxLines) break;
			shownCount--;
		}
		const shown = running.slice(0, shownCount);
		const hidden = running.length - shown.length;
		// 有在途时结算/blocked 仅追加紧凑计数（不占行预算，明细去看板）。
		const settledSeg = recent.length > 0 ? ` · 结算 ${settledCountsText(recent)}` : "";
		const blockedSeg = blocked.length > 0 ? ` · ⏸${blocked.length} blocked` : "";
		const lines: string[] = [trimDisplay(`amagi 编排实况 · ${running.length} 个子 Agent 在途${settledSeg}${blockedSeg}`, width)];
		for (const [idx, rec] of shown.entries()) {
			const dur = formatDuration(now - rec.startedAt);
			const head = rec.mode === "background" ? `${rec.agent} [bg]` : rec.agent;
			const modelSeg = rec.model ? `${modelWithThinking(rec.model)} · ` : "";
			lines.push(trimDisplay(`${idx + 1}. ${head} · ${trimDisplay(taskSummary(rec), 28)} · ${modelSeg}${dur}`, width));
			lines.push(trimDisplay(rec.status === "queued" ? "  └ 排队中（等待执行槽位）" : `  └ ${latestActivity(rec)}`, width));
		}
		if (hidden > 0) lines.push(trimDisplay(`  …另有 ${hidden} 个在途任务（打开看板查看）`, width));
		return lines;
	}

	/** 无在途时的驻留面板：最近结算紧凑计数（TTL 内）+ blocked 常驻明细（可行动项），严格 ≤ maxLines。 */
	function renderIdleLines(tasks: Readonly<TaskRecord>[], now: number, width: number): string[] {
		const recent = selectRecentSettled(tasks, now, settledTtlMs);
		const blocked = selectBlockedTasks(tasks);
		if (recent.length === 0 && blocked.length === 0) return [];
		const settledSeg = recent.length > 0 ? ` · 结算 ${settledCountsText(recent)}` : "";
		// diting 增审 Major-3：questions（⏸ 待答复）与 handoff（↻ 待接手）分列中性展示
		const questions = blocked.filter((r) => r.blockReason !== "needs-handoff");
		const handoff = blocked.filter((r) => r.blockReason === "needs-handoff");
		const segs: string[] = [];
		if (questions.length > 0) segs.push(`⏸${questions.length} blocked 待答复`);
		if (handoff.length > 0) segs.push(`↻${handoff.length} 待接手(resume)`);
		const blockedSeg = segs.length > 0 ? ` · ${segs.join(" · ")}` : "";
		const lines: string[] = [trimDisplay(`amagi 编排实况 · 无在途${settledSeg}${blockedSeg}`, width)];
		// blocked 逐条列出（等待答复/接手需用户行动）；行预算 = maxLines - header，折叠时再多让一行。
		let shownCount = Math.min(blocked.length, Math.max(0, maxLines - 1));
		if (blocked.length > shownCount) shownCount = Math.max(0, maxLines - 2);
		for (const rec of blocked.slice(0, shownCount)) {
			const wait = formatDuration(now - (rec.blockedAt ?? rec.endedAt ?? rec.startedAt));
			const sym = rec.blockReason === "needs-handoff" ? "↻" : "⏸";
			lines.push(trimDisplay(`  ${sym} ${rec.agent} · ${trimDisplay(blockedQuestion(rec), 40)} · 等待 ${wait}`, width));
		}
		const hidden = blocked.length - shownCount;
		if (hidden > 0) lines.push(trimDisplay(`  …另有 ${hidden} 个 blocked（打开看板查看）`, width));
		return lines;
	}

	// 8月迭代 pi-0.84 配合 P2⑥：ui_prompt 等待态（ctx.ui.select/confirm/input/editor/custom
	// 阻塞等待用户；嵌套提示 pi 已合并为外层 span）。仅前置短标记，不参与也不改变
	// 既有状态优先级逻辑；setUiPromptWaiting 顺带 refresh（事件驱动即时感知，轮询自然携带兜底）。
	let uiPromptWaiting = false;
	let uiPromptTitle = "";

	function setUiPromptWaiting(active: boolean, title?: string): void {
		uiPromptWaiting = active;
		// diting 修复轮 Minor-7：title 来自扩展 UI 事件，可能携带 CR/LF/制表符——不清洗会
		// 撕裂单行状态栏；控制字符归一为空格后再入库（渲染层 trimDisplay 仍做宽度裁剪）。
		uiPromptTitle = typeof title === "string" ? title.replace(/[\x00-\x1f\x7f]+/g, " ").trim() : "";
		try { refresh(); } catch { /* 事件路径绝不抛错：等待标记失败不影响编排主流程 */ }
	}

	/** 等待标记段：「⏸等输入」+ 空格 + 有界 title（≤24 终端格）；未等待返回 ""。 */
	function uiPromptSegment(): string {
		if (!uiPromptWaiting) return "";
		return `⏸等输入${uiPromptTitle ? ` ${trimDisplay(uiPromptTitle, 24)}` : ""}`;
	}

	function renderStatusText(now: number = Date.now()): string | undefined {
		const tasks = deps.taskRegistry.list();
		const running = selectPanelTasks(tasks);
		const recent = selectRecentSettled(tasks, now, settledTtlMs);
		const blocked = selectBlockedTasks(tasks);
		// 状态栏同样受当前终端列宽约束（窄终端不溢出折行）；非 TTY 保持配置上限。
		const width = resolveWidgetWidth(maxWidth, deps.getColumns ? deps.getColumns() : process.stdout.columns);
		const waiting = uiPromptSegment();
		// 8月迭代 pi-0.84 配合 P2⑥：无任何任务态时等待标记独立可见（等待用户毫无指示比空栏更糟），
		// 其余情况仅作为首段前缀叠加，既有优先级逻辑不动。
		if (running.length === 0 && recent.length === 0 && blocked.length === 0) {
			return waiting ? trimDisplay(waiting, width) : undefined;
		}
		const segments: string[] = [];
		if (waiting) segments.push(waiting);
		if (running.length > 0) {
			const longest = running[0];
			const queued = running.filter((r) => r.status === "queued").length;
			segments.push(`amagi ● ${running.length} active${queued > 0 ? ` · ${queued} queued` : ""} · ${longest.agent} ${formatDuration(now - longest.startedAt)}`);
		} else {
			segments.push("amagi ○ 无在途");
		}
		if (recent.length > 0) segments.push(`结算 ${settledCountsText(recent)}`);
		// diting 增审 Major-3：questions（⏸ 待答复）与 handoff（↻ 待接手）分列中性计数
		{
			const questions = blocked.filter((r) => r.blockReason !== "needs-handoff");
			const handoff = blocked.filter((r) => r.blockReason === "needs-handoff");
			if (questions.length > 0) segments.push(`⏸${questions.length} blocked 待答复`);
			if (handoff.length > 0) segments.push(`↻${handoff.length} 待接手`);
		}
		return trimDisplay(segments.join(" · "), width);
	}

	// P4 终审 M5-a：refresh/stop 与 start 同级守卫——仅 active 且 TUI 时允许写 UI。
	// 否则 index 的 tool_execution_end/agent_end 事件加速路径在 rpc/json 模式会经真实
	// UI context 发出 extension_ui_request（reviewer probe：json 模式 refresh 后 UI 调用 0→2）。
	let active = false;
	let unsubChange: (() => void) | undefined;
	const uiWritable = (): boolean => active && deps.ctx.mode === "tui";

	function refresh(): void {
		if (!uiWritable()) return;
		try {
			const lines = renderLines();
			deps.ctx.ui.setWidget(WIDGET_KEY, lines.length > 0 ? lines : undefined, { placement: "aboveEditor" });
			deps.ctx.ui.setStatus(STATUS_KEY, renderStatusText());
		} catch {
			// 轮询路径绝不抛错：UI 渲染失败不影响编排主流程。
		}
	}

	function start(): void {
		if (timer) return;
		// dist types.d.ts L211: mode "tui" 守卫 terminal-only UI；rpc/json/print 模式不渲染。
		if (deps.ctx.mode !== "tui") return;
		active = true;
		refresh();
		// v1.5.185 事件响应：registry 变更立即刷新（主通道）；interval 仅为兜底心跳。
		unsubChange = deps.taskRegistry.onChange?.(() => { try { refresh(); } catch {} });
		timer = setInterval(refresh, intervalMs);
		timer.unref?.(); // 不阻止进程退出
	}

	function stop(): void {
		unsubChange?.(); unsubChange = undefined;
		if (timer) { clearInterval(timer); timer = undefined; }
		if (!uiWritable()) { active = false; return; }
		try {
			deps.ctx.ui.setWidget(WIDGET_KEY, undefined);
			deps.ctx.ui.setStatus(STATUS_KEY, undefined);
		} catch {}
		active = false;
	}

	return { start, stop, refresh, setUiPromptWaiting, renderLines, renderStatusText };
}
