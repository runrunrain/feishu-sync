/**
 * win-exec-discover.ts — Windows 根目录发现与白名单程序解析。
 *
 * v2（diting 审核 M1/M2/m5）：
 *  - 挂载根经 mntRoot 参数（win-exec-mnt.wslMntRoot()，/etc/wsl.conf [automount] root 生效）。
 *  - M1：所有候选/配置路径先 normalizeMntPath（拒绝 `..`、UNC、`\\?\`、尾随点/空格、8.3 短名）；
 *    容器判定 isPathUnderRootSafe（大小写不敏感 + 双侧 realpath 复核，junction 外指拒绝）。
 *  - M2：powershell/cmd/taskkill/tasklist 不再对模型开放——taskkill/tasklist 仅内部通道
 *    （清扫/核验），powershell/cmd 仅受信配置 allowShells=true 时可用；内部解析经 purpose:"internal"。
 *
 * 事实来源优先级：① AMAGI_WIN_* 环境变量（/mnt 形态）→ ② 回退探测 <mntRoot>/<盘>/Windows/
 * System32/cmd.exe → ③ windows.exec.programs 显式映射（覆盖内置表）。不依赖 WSL PATH 中的
 * Windows 目录（CodeBox 刻意不开 interop PATH）；发现结果缓存（doctor 可看）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import {
	isUnderMnt, isWindowsAbsolutePath, linuxToWindowsPath, windowsToLinuxPath,
	hasAllowedExecutableExt, normalizeMntPath, isPathUnderRootSafe, type MntPathOptions,
} from "./win-exec-paths.ts";
import type { WinExecConfig } from "./win-exec-config.ts";

export interface WindowsRoots {
	systemRoot?: string;
	programFiles?: string;
	localAppData?: string;
	userProfile?: string;
	/** 实际使用的挂载根（doctor 展示）。 */
	mntRoot: string;
	probedDrives: string[];
}

export interface DiscoverDeps {
	env?: NodeJS.ProcessEnv;
	existsSync?: (p: string) => boolean;
	listMnt?: () => string[];
	/** where.exe 兜底（rg 定位）。 */
	whereLookup?: (name: string) => string | null;
	/** M1：realpath 复核（缺省真实 fs；注入测试模拟 junction/符号链接外指）。 */
	realpath?: (p: string) => string | null;
	/** M2：解析目的——model=模型调用面（默认，shells 族受限）；internal=内部通道（bat/ps1 中转、tasklist/taskkill）。 */
	purpose?: "model" | "internal";
}

export const WIN_ENV_KEYS = {
	systemRoot: "AMAGI_WIN_SYSTEMROOT",
	programFiles: "AMAGI_WIN_PROGRAMFILES",
	localAppData: "AMAGI_WIN_LOCALAPPDATA",
	userProfile: "AMAGI_WIN_USERPROFILE",
} as const;

/** M2：不对模型开放的内置程序（内部通道专用；powershell/cmd 经 allowShells 受信放开）。 */
const SHELL_FAMILY = new Set(["powershell", "cmd"]);
const INTERNAL_ONLY = new Set(["taskkill", "tasklist"]);

function toMnt(v: string | undefined, mntRoot: string): string | undefined {
	if (typeof v !== "string" || v.trim() === "") return undefined;
	const n = normalizeMntPath(v.trim(), { mntRoot });
	if (!n.ok) return undefined;
	return n.value;
}

function fsIsFile(p: string): boolean {
	try { return fs.statSync(p).isFile(); } catch { return false; /* lint-exempt:探测失败=不存在 */ }
}

/** 发现 Windows 根目录（纯函数 + 注入；调用方缓存）。 */
export function discoverWindowsRoots(deps: DiscoverDeps = {}, mntRoot = "/mnt"): WindowsRoots {
	const env = deps.env ?? process.env;
	const exists = deps.existsSync ?? fsIsFile;
	const roots: WindowsRoots = { mntRoot, probedDrives: [] };
	const sys = toMnt(env[WIN_ENV_KEYS.systemRoot], mntRoot);
	if (sys) {
		roots.systemRoot = sys;
	} else {
		let drives: string[] = [];
		try { drives = deps.listMnt ? deps.listMnt() : fs.readdirSync(mntRoot).filter((d) => /^[A-Za-z]$/.test(d)); } catch { drives = []; /* lint-exempt:/mnt 枚举失败 → 空表 */ }
		for (const d of drives) {
			const candidate = path.posix.join(mntRoot, d, "Windows");
			if (exists(path.posix.join(candidate, "System32", "cmd.exe"))) {
				roots.systemRoot = candidate;
				roots.probedDrives.push(d);
				break;
			}
		}
	}
	const pf = toMnt(env[WIN_ENV_KEYS.programFiles], mntRoot);
	if (pf) roots.programFiles = pf;
	const la = toMnt(env[WIN_ENV_KEYS.localAppData], mntRoot);
	if (la) roots.localAppData = la;
	const up = toMnt(env[WIN_ENV_KEYS.userProfile], mntRoot);
	if (up) roots.userProfile = up;
	return roots;
}

export interface BuiltinProgramSpec {
	name: string;
	candidates: (roots: WindowsRoots) => string[];
}

export const BUILTIN_PROGRAMS: BuiltinProgramSpec[] = [
	{ name: "powershell", candidates: (r) => (r.systemRoot ? [path.posix.join(r.systemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")] : []) },
	{ name: "cmd", candidates: (r) => (r.systemRoot ? [path.posix.join(r.systemRoot, "System32", "cmd.exe")] : []) },
	{ name: "taskkill", candidates: (r) => (r.systemRoot ? [path.posix.join(r.systemRoot, "System32", "taskkill.exe")] : []) },
	{ name: "tasklist", candidates: (r) => (r.systemRoot ? [path.posix.join(r.systemRoot, "System32", "tasklist.exe")] : []) },
	{ name: "cmake", candidates: (r) => (r.programFiles ? [path.posix.join(r.programFiles, "CMake", "bin", "cmake.exe")] : []) },
	{ name: "ctest", candidates: (r) => (r.programFiles ? [path.posix.join(r.programFiles, "CMake", "bin", "ctest.exe")] : []) },
	{
		name: "git",
		candidates: (r) => (r.programFiles
			? [path.posix.join(r.programFiles, "Git", "cmd", "git.exe"), path.posix.join(r.programFiles, "Git", "bin", "git.exe")]
			: []),
	},
	{
		name: "rg",
		candidates: (r) => [
			...(r.localAppData ? [path.posix.join(r.localAppData, "Microsoft", "WinGet", "Links", "rg.exe")] : []),
			...(r.programFiles ? [path.posix.join(r.programFiles, "ripgrep", "rg.exe")] : []),
		],
	},
];

export const BUILTIN_PROGRAM_NAMES = BUILTIN_PROGRAMS.map((p) => p.name);

export interface ResolvedProgram {
	windowsPath: string;
	linuxPath: string;
	launcher: "direct" | "cmd-c" | "powershell-file";
	source: string;
	longRunning?: boolean;
	exclusive?: string;
	supervised?: boolean;
	timeoutS?: number;
}

export type ResolveProgramResult =
	| { ok: true; program: ResolvedProgram }
	| { ok: false; reason: string };

export interface ProgramResolveConfig {
	programs?: Map<string, { path: string; longRunning?: boolean; exclusive?: string; supervised?: boolean; timeoutS?: number }>;
	allowRoots?: string[];
	/** M2：受信配置声明的 allowShells（powershell/cmd 模型面放开）。 */
	allowShells?: boolean;
}

/**
 * 程序解析（M1 归一/复核 + M2 边界）。内置白名单名 → 根目录候选；配置显式映射优先（值同样
 * 归一化校验）；显式路径仅在 allowRoots 容器内放行（扩展名限 .exe/.bat/.cmd/.ps1）。
 * purpose="model"（默认）时 shells 族按 M2 边界拒绝；"internal" 供内部通道（.bat 中转/
 * supervised relay/tasklist/taskkill）使用。
 */
export function resolveProgram(
	program: string,
	config: ProgramResolveConfig,
	roots: WindowsRoots,
	deps: DiscoverDeps = {},
): ResolveProgramResult {
	const raw = String(program ?? "").trim();
	if (!raw) return { ok: false, reason: "program 不能为空" };
	const exists = deps.existsSync ?? fsIsFile;
	const realpath = deps.realpath ?? ((p: string) => { try { return fs.realpathSync(p); } catch { /* lint-exempt:不可解析→null，由词法门兜底 */ return null; } });
	const mntRoot = roots.mntRoot;
	const purpose = deps.purpose ?? "model";
	const mk = (linuxPath: string, source: string, extra: Partial<ResolvedProgram> = {}): ResolveProgramResult => {
		const ext = path.posix.extname(linuxPath).toLowerCase();
		const launcher: ResolvedProgram["launcher"] = ext === ".bat" || ext === ".cmd" ? "cmd-c" : ext === ".ps1" ? "powershell-file" : "direct";
		const win = linuxToWindowsPath(linuxPath, { mntRoot });
		if (win === null) return { ok: false, reason: `程序路径 ${linuxPath} 无法转换为 Windows 形态` };
		return { ok: true, program: { windowsPath: win, linuxPath, launcher, source, ...extra } };
	};

	// M2：模型面 shells/内部专用边界（显式映射优先于内置名——受信配置放开 shells 的通道是
	// allowShells 布尔而非 programs 映射 shells 名，映射也放行但仅受信配置可读出该映射）
	const lowerName = raw.toLowerCase();
	if (purpose === "model" && !raw.includes("/") && !raw.includes("\\")) {
		if (INTERNAL_ONLY.has(lowerName)) {
			return { ok: false, reason: `program "${raw}" 是内部通道专用程序（起前清扫/超时核验由 win_exec 自动执行）——不对模型开放；需要查询进程请用 program=tasklist 的等价能力（当前无），需要结束进程请在 windows.exec.groups 配置 killImages 后经 force_sweep 语义处理` };
		}
		if (SHELL_FAMILY.has(lowerName) && config.allowShells !== true) {
			return {
				ok: false,
				reason: [
					`program "${raw}" 默认不对模型开放（shell 家族可执行任意命令，等同放开 bash 面）。`,
					"需要跑 .ps1/.bat/.cmd 时：位于 windows.exec.allowRoots 之内的脚本文件可直接以路径作为 program 调用（经受管的 cmd /d /s /c 或 powershell -File 中转）；确需交互式 shell 时由主上在受信配置（全局 amagi.json 或受信项目）显式声明 windows.exec.allowShells=true。",
				].join("\n"),
			};
		}
	}

	// ③ 配置显式映射优先（值经 M1 归一化校验）
	const configured = config.programs?.get(raw);
	if (configured) {
		const n = normalizeMntPath(configured.path, { mntRoot });
		if (!n.ok) return { ok: false, reason: `windows.exec.programs["${raw}"] 的路径非法（${n.reason}）` };
		if (!exists(n.value)) {
			return { ok: false, reason: `windows.exec.programs["${raw}"] 的路径 ${n.value} 不存在（已拒绝执行）；请核对该文件在 Windows 侧真实存在` };
		}
		return mk(n.value, `windows.exec.programs["${raw}"]`, {
			longRunning: configured.longRunning,
			exclusive: configured.exclusive,
			supervised: configured.supervised,
			timeoutS: configured.timeoutS,
		});
	}

	// 显式路径：M1 归一 + allowRoots 容器（isPathUnderRootSafe）+ 扩展名
	if (raw.includes("/") || raw.includes("\\")) {
		const n = normalizeMntPath(raw, { mntRoot });
		if (!n.ok) return { ok: false, reason: `program "${raw}" 非法（${n.reason}）` };
		if (!hasAllowedExecutableExt(n.value)) {
			return { ok: false, reason: `program "${raw}" 扩展名不在允许清单（.exe/.bat/.cmd/.ps1）内；如需放行其它类型请在 amagi.json windows.exec.programs 显式映射` };
		}
		const allowRoots = (config.allowRoots ?? [])
			.map((root) => normalizeMntPath(root, { mntRoot }))
			.filter((r): r is { ok: true; value: string } => r.ok);
		let hit: { value: string } | undefined;
		for (const root of allowRoots) {
			const verdict = isPathUnderRootSafe(n.value, root.value, realpath);
			if (verdict.ok) { hit = root; break; }
			if (verdict.reason?.includes("逃出")) return { ok: false, reason: `program "${raw}" ${verdict.reason}` };
		}
		if (!hit) {
			const rawRoots = config.allowRoots ?? [];
			return {
				ok: false,
				reason: [
					`program "${n.value}" 不在放行根（windows.exec.allowRoots）之内，已拒绝执行。`,
					rawRoots.length > 0 ? `当前 allowRoots：${rawRoots.join("、")}` : "当前 allowRoots 为空（未配置任何放行根）。",
					"放行方法：在受信 amagi.json 的 windows.exec.allowRoots 中加入该程序所在目录（如 UE 引擎目录），或用 windows.exec.programs 按名字显式映射。",
				].join("\n"),
			};
		}
		if (!exists(n.value)) {
			return { ok: false, reason: `program "${n.value}" 在 allowRoots ${hit.value} 内但文件不存在；请核对路径` };
		}
		return mk(n.value, `allowRoots(${hit.value})`);
	}

	// 内置白名单名（不含路径分隔符）
	if (!/^[A-Za-z0-9._-]+$/.test(raw)) {
		return { ok: false, reason: `program "${raw}" 含非法字符（白名单名只允许字母/数字/._-；显式路径须位于 allowRoots 之内）` };
	}
	const spec = BUILTIN_PROGRAMS.find((p) => p.name === lowerName);
	if (!spec) {
		return {
			ok: false,
			reason: [
				`program "${raw}" 不在白名单内，已拒绝执行。`,
				`内置白名单：${BUILTIN_PROGRAM_NAMES.filter((n) => !INTERNAL_ONLY.has(n) && !(SHELL_FAMILY.has(n) && config.allowShells !== true)).join("、")}${config.allowShells === true ? "、powershell、cmd" : ""}。`,
				"需要其它 Windows 程序时：在受信 amagi.json windows.exec.programs 按名字显式映射（name → /mnt/<盘>/…/xxx.exe），或把所在目录加入 windows.exec.allowRoots 后以完整路径调用。",
				"白名单约束的是程序名而非行为：git 的 --exec-path/-c alias.、cmake 的 -E 子命令等可在程序内执行其它命令的参数，由参数级规则（如 git -c 默认拒绝）与受信配置共同约束。",
			].join("\n"),
		};
	}
	for (const candidate of spec.candidates(roots)) {
		if (exists(candidate)) return mk(candidate, `内置表(${spec.name})`);
	}
	if (deps.whereLookup && spec.name === "rg") {
		const found = deps.whereLookup("rg.exe");
		if (found) {
			const n = normalizeMntPath(found, { mntRoot });
			if (n.ok && isUnderMnt(n.value, { mntRoot }) && exists(n.value)) return mk(n.value, "where.exe 兜底");
		}
	}
	const missing: string[] = [];
	if (!roots.systemRoot) missing.push("AMAGI_WIN_SYSTEMROOT");
	if (!roots.programFiles && ["cmake", "ctest", "git"].includes(spec.name)) missing.push("AMAGI_WIN_PROGRAMFILES");
	return {
		ok: false,
		reason: [
			`内置程序 ${spec.name} 未能定位可执行文件，已拒绝执行。`,
			missing.length > 0 ? `缺失的 Windows 根环境变量：${missing.join("、")}（amagi-codebox 会经 WSLENV 注入；手动会话可 export，或依赖挂载根回退探测）。` : "Windows 根已发现但候选路径均不存在。",
			"修复：在受信 amagi.json windows.exec.programs 显式映射该程序的完整路径（挂载根/<盘>/…/xxx.exe），或核对 Windows 侧安装。",
		].join("\n"),
	};
}

// ── 进程内缓存（发现结果缓存、doctor 可看；测试 reset） ────────────────────────

let cachedRoots: { at: number; value: WindowsRoots } | undefined;
const ROOTS_CACHE_MS = 60_000;

export function cachedWindowsRoots(deps: DiscoverDeps = {}, mntRoot = "/mnt", now = Date.now()): WindowsRoots {
	if (cachedRoots && now - cachedRoots.at < ROOTS_CACHE_MS && cachedRoots.value.mntRoot === mntRoot) return cachedRoots.value;
	const value = discoverWindowsRoots(deps, mntRoot);
	cachedRoots = { at: now, value };
	return value;
}

export function resetWinExecDiscovery(): void {
	cachedRoots = undefined;
}

export { isWindowsAbsolutePath, windowsToLinuxPath };
