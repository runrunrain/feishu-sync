import { parseCodemodeScriptOptions } from "./codemode-policy.ts";
import type { CodemodeGrantBudget } from "./contracts/permission.ts";

export const CODEMODE_USAGE = "模型自行决定是否使用及如何组合当前已有工具。适合批量调用、筛选/聚合、循环或依赖调用；单次简单工具调用直接执行。嵌套调用沿用原工具权限，保留来源、错误与截断。无需申请 codemode 角色或 scope。";
export const CODEMODE_EXAMPLE = 'const paths = ["README.md", "package.json"];\nconst rows = await Promise.allSettled(paths.map(path => tools.read({path})));\ntext(rows.map((r,i) => r.status === "fulfilled" ? {path:paths[i],value:r.value} : {path:paths[i],error:String(r.reason)}));' +
	'\n\n// 或单独使用下面的依赖读取片段（与上段分别使用）：中间引用不必先返回模型。\nconst manifest = JSON.parse(await tools.read({path:"manifest.json"}));\nconst value = await tools.read({path:manifest.next});\ntext({source:manifest.next,value});';

/** 补齐运行默认值；显式值保留，由宿主校验和执行。 */
export function withCodemodeDefaults(code: string, budget: Pick<CodemodeGrantBudget, "maxOutputTokensPerScript" | "maxTimeoutMsPerScript">): string {
	const options = parseCodemodeScriptOptions(code);
	if (options.invalidReason) return code;
	const defaults = { max_output_tokens: budget.maxOutputTokensPerScript, timeout_ms: budget.maxTimeoutMsPerScript };
	if (!options.present) return `// @options: ${JSON.stringify(defaults)}\n${code}`;
	const lines = code.split(/\r?\n/);
	const supplied = JSON.parse(lines[0]!.trimStart().slice("// @options:".length));
	lines[0] = `// @options: ${JSON.stringify({ ...defaults, ...supplied })}`;
	return lines.join("\n");
}

export function codemodePreferenceLine(preference: "auto" | "prefer"): string {
	return preference === "prefer" ? "[amagi codemode 选择] 适用的批量调用、筛选/聚合或依赖调用优先考虑 codemode；单次简单读取直接 read。" : "[amagi codemode 选择] 按任务选择；独立简单读取可直接并行，跨调用筛选/聚合或依赖处理适合 codemode。";
}
