/**
 * handbook-tool.ts — amagi_handbook 工具：战术手册查询接口 + dormant 生命周期执行（v1.5.193）。
 *
 * 背景（上下文腐烂分析 2026-07-31）：handbook.json 消费方式是全量读取——条目增长到
 * 200+ 时读取即腐化；lifecyclePolicy 定义了 active/candidate/dormant/deprecated 四态与
 * 晋升/降级规则，但无执行机制（usageTracking.lastCleanup=null，usageCount=0 条目曾占 47%）。
 *
 * 动作：
 *   query     — 关键词/section/status 过滤取片段（默认排除 dormant/deprecated），替代全量读取
 *   show      — 单条全文（id 或前缀）
 *   stats     — section×status 分布 + 陈旧候选（usageCount=0 且 addedDate 超阈值）+ 字节量（腐烂可观测）
 *   lifecycle — 状态迁移（写 sidecar 覆盖层）
 *
 * 持久化设计（与 fuse-state.json 同款）：状态迁移写 <amagiData>/handbook-lifecycle.json
 * sidecar 覆盖层——包内 handbook.json 保持只读（pi update / git pull 不丢迁移记录），
 * 读取时合并（sidecar 状态覆盖包内状态，附 lastReviewed/history/lastCleanup）。
 */

import { StringEnum } from "@earendil-works/pi-ai";
import { Type } from "typebox";
import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataFile } from "./data-dir.ts";
// P4（寄生增强方案 §4.2）：结构化输出 wire——纯 schema/投影模块（零 I/O），接线层在此。
import { HandbookOutputSchema, toQueryWire, toShowWire, toStatsWire, toLifecycleWire, toHandbookErrorWire } from "./handbook-wire.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 类型
// ─────────────────────────────────────────────────────────────────────────────

export interface HandbookEntry {
	id: string;
	title: string;
	insight: string;
	example?: string;
	source?: string;
	usageCount?: number;
	addedDate?: string;
	status?: string;
	defaultLoad?: boolean;
	lifecycle?: { promotionRule?: string; demotionRule?: string };
	validationGate?: string[];
	/** sidecar 合并后附加 */
	lastReviewed?: string;
}

interface HandbookFile {
	version?: string;
	lastUpdated?: string;
	sections?: Record<string, { id?: string; name?: string; entries?: HandbookEntry[] }>;
	usageTracking?: { lastCleanup?: string | null };
}

interface LifecycleOverride {
	status: string;
	lastReviewed: string;
	note?: string;
	history: Array<{ at: string; from: string; to: string; note?: string }>;
}

interface LifecycleSidecar {
	version: 1;
	lastCleanup?: string;
	overrides: Record<string, LifecycleOverride>;
}

const LIFECYCLE_STATES = ["candidate", "active", "dormant", "deprecated"] as const;
type LifecycleState = (typeof LIFECYCLE_STATES)[number];

// ─────────────────────────────────────────────────────────────────────────────
// 读取与合并
// ─────────────────────────────────────────────────────────────────────────────

function handbookPath(packageRoot: string): string {
	return path.join(packageRoot, "resources", "tactical-book", "handbook.json");
}

function sidecarPath(): string {
	return process.env.AMAGI_HANDBOOK_LIFECYCLE_PATH || amagiDataFile("handbook-lifecycle.json");
}

export function loadSidecar(file?: string): LifecycleSidecar {
	try {
		const s = JSON.parse(fs.readFileSync(file || sidecarPath(), "utf8"));
		if (s && s.version === 1 && s.overrides) return s as LifecycleSidecar;
	} catch { /* 缺失/损坏 → 空覆盖层 */ }
	return { version: 1, overrides: {} };
}

function saveSidecar(s: LifecycleSidecar, file?: string): void {
	const f = file || sidecarPath();
	fs.mkdirSync(path.dirname(f), { recursive: true });
	const tmp = f + ".tmp";
	fs.writeFileSync(tmp, JSON.stringify(s), { encoding: "utf8", mode: 0o600 });
	fs.renameSync(tmp, f);
}

export interface MergedEntry extends HandbookEntry {
	section: string;
	sectionName?: string;
}

/** 读包内手册 + 应用 sidecar 覆盖（状态/lastReviewed/history）。纯函数（注入文件路径可测）。 */
export function loadHandbook(packageRoot: string, sidecarFile?: string): { entries: MergedEntry[]; bytes: number; sidecar: LifecycleSidecar; lastUpdated?: string } {
	const hp = handbookPath(packageRoot);
	let parsed: HandbookFile = {};
	let bytes = 0;
	try {
		const raw = fs.readFileSync(hp, "utf8");
		bytes = Buffer.byteLength(raw, "utf8");
		parsed = JSON.parse(raw);
	} catch { /* 包内手册缺失 → 空 */ }
	const sidecar = loadSidecar(sidecarFile);
	const entries: MergedEntry[] = [];
	for (const [sectionId, section] of Object.entries(parsed.sections || {})) {
		for (const e of section.entries || []) {
			const merged: MergedEntry = { ...e, section: sectionId, sectionName: section.name };
			const ov = sidecar.overrides[e.id];
			if (ov) { merged.status = ov.status; merged.lastReviewed = ov.lastReviewed; }
			entries.push(merged);
		}
	}
	return { entries, bytes, sidecar, lastUpdated: parsed.lastUpdated };
}

// ─────────────────────────────────────────────────────────────────────────────
// 各动作实现
// ─────────────────────────────────────────────────────────────────────────────

function truncate(s: string, n: number): string {
	const t = (s || "").replace(/\s+/g, " ").trim();
	return t.length > n ? t.slice(0, n - 1) + "…" : t;
}

function staleDays(): number {
	const v = Number(process.env.AMAGI_HANDBOOK_STALE_DAYS);
	return Number.isFinite(v) && v > 0 ? v : 60;
}

/** stats 单源计算产物（P4：renderStats 正文与 handbook-wire wire 共用同一份——不二次计算另一套规则）。
 *  bySection 顺序=现行 Map 插入序（section 首遇序 → status 首遇序）；stale=现行陈旧判据
 *  （usageCount=0 且 candidate 且 addedDate 可解析早于阈值，addedDate 升序稳定排序）。
 *  staleRows 为正文展示源（截 10 由 renderStats 做）；staleIds 携全量（wire 消费）。 */
export interface StatsStaleRow { id: string; addedDate: string; section: string }
export interface StatsData {
	total: number;
	bytes: number;
	bySection: Array<{ key: string; count: number; statuses: Array<{ key: string; count: number }> }>;
	staleIds: string[];
	staleRows: StatsStaleRow[];
	staleThresholdDays: number;
	lastUpdated: string | null;
	lastCleanup: string | null;
	sidecarOverrideCount: number;
}

/** stats 计算（单源）：输入 loadHandbook 一次读取产物，输出封闭统计对象。 */
export function computeStatsData(data: { entries: MergedEntry[]; bytes: number; sidecar: LifecycleSidecar; lastUpdated?: string }): StatsData {
	const { entries, bytes, sidecar } = data;
	const bySection = new Map<string, Map<string, number>>();
	for (const e of entries) {
		let m = bySection.get(e.section);
		if (!m) { m = new Map(); bySection.set(e.section, m); }
		const st = e.status || "candidate";
		m.set(st, (m.get(st) || 0) + 1);
	}
	const bySectionOut = [...bySection.entries()].map(([sid, m]) => ({
		key: sid,
		count: [...m.values()].reduce((a, b) => a + b, 0),
		statuses: [...m.entries()].map(([st, n]) => ({ key: st, count: n })),
	}));
	// 陈旧候选：usageCount=0 且 addedDate 超阈值（腐烂评审队列）——现行判据原样
	const cutoff = Date.now() - staleDays() * 86400_000;
	const stale = entries.filter((e) =>
		(e.usageCount ?? 0) === 0 && (e.status || "candidate") === "candidate" &&
		e.addedDate && !Number.isNaN(Date.parse(e.addedDate)) && Date.parse(e.addedDate) < cutoff,
	).sort((a, b) => String(a.addedDate).localeCompare(String(b.addedDate)));
	return {
		total: entries.length,
		bytes,
		bySection: bySectionOut,
		staleIds: stale.map((e) => e.id),
		staleRows: stale.map((e) => ({ id: e.id, addedDate: String(e.addedDate), section: e.section })),
		staleThresholdDays: staleDays(),
		lastUpdated: data.lastUpdated ?? null,
		lastCleanup: sidecar.lastCleanup ?? null,
		sidecarOverrideCount: Object.keys(sidecar.overrides).length,
	};
}

function renderQuery(entries: MergedEntry[], opts: { keyword?: string; total: number; bytes: number; excluded: number }): string {
	const head = `[tactical-book] 命中 ${entries.length} 条（全量 ${opts.total} 条目 / ${(opts.bytes / 1024).toFixed(1)}KB${opts.excluded > 0 ? `；已排除 dormant/deprecated ${opts.excluded} 条` : ""}）`;
	if (entries.length === 0) return head + (opts.keyword ? `\n关键词 "${opts.keyword}" 无命中——可换词或加 includeDormant:true 查历史。` : "\n（无条目）");
	const lines = entries.map((e, i) =>
		`${i + 1}. [${e.id}] ${e.title}（${e.section}/${e.status || "candidate"}/用${e.usageCount ?? 0}次）\n   insight: ${truncate(e.insight, 140)}`,
	);
	return `${head}\n${lines.join("\n")}\n（全文：amagi_handbook({ action:"show", id:"<id>" })；未命中可试 includeDormant:true）`;
}

function renderShow(e: MergedEntry): string {
	return [
		`# [${e.id}] ${e.title}`,
		`section: ${e.section}${e.sectionName ? `（${e.sectionName}）` : ""} | status: ${e.status || "candidate"} | usageCount: ${e.usageCount ?? 0} | addedDate: ${e.addedDate || "?"}${e.lastReviewed ? ` | lastReviewed: ${e.lastReviewed}` : ""}`,
		"",
		"## insight", e.insight || "(空)",
		...(e.example ? ["", "## example", e.example] : []),
		...(e.source ? ["", `source: ${e.source}`] : []),
		...(e.lifecycle ? ["", `promotionRule: ${e.lifecycle.promotionRule || "-"}`, `demotionRule: ${e.lifecycle.demotionRule || "-"}`] : []),
	].join("\n");
}

/** stats 正文渲染（输入 computeStatsData 单源产物；输出字节与 v1.5.193 起的既有契约一致）。 */
function renderStats(stats: StatsData): string {
	const sectionTxt = stats.bySection
		.map((s) => `${s.key}: ${s.statuses.map((t) => `${t.key}${t.count}`).join("/")}`)
		.join("；");
	const staleCount = stats.staleIds.length;
	const lines = [
		`[tactical-book stats] ${stats.total} 条目 / ${(stats.bytes / 1024).toFixed(1)}KB（包内只读） + ${stats.sidecarOverrideCount} 条 sidecar 覆盖`,
		`lastUpdated: ${stats.lastUpdated || "?"} | lastCleanup: ${stats.lastCleanup || "从未"}`,
		`section×status: ${sectionTxt || "(空)"}`,
		`陈旧候选（usageCount=0 且 candidate 超 ${stats.staleThresholdDays}d）：${staleCount} 条${staleCount > 0 ? "——建议主上评审降级 dormant：" : ""}`,
		...stats.staleRows.slice(0, 10).map((e) => `  ${e.id}（${e.addedDate}, ${e.section}）`),
		...(staleCount > 10 ? [`  …其余 ${staleCount - 10} 条`] : []),
	];
	return lines.join("\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// 工具工厂
// ─────────────────────────────────────────────────────────────────────────────

export function createHandbookTool(deps?: { packageRoot?: string }) {
	const root = deps?.packageRoot || "";
	/** 单 action 执行主体（P4 拆出）：返回旧契约形状（content[/isError]）+ structuredContent 新键。
	 *  正文渲染函数与文案零改动——字节契约不变（O3b 模式：展开加键）。 */
	const executeAction = (
		params: {
			action: "query" | "show" | "stats" | "lifecycle";
			keyword?: string; section?: string; status?: string; includeDormant?: boolean; limit?: number;
			id?: string; to?: LifecycleState; note?: string;
		},
	) => {
		const data = loadHandbook(root);
		if (params.action === "stats") {
			const stats = computeStatsData(data);
			return { content: [{ type: "text" as const, text: renderStats(stats) }], structuredContent: toStatsWire(stats) };
		}
		if (params.action === "query") {
			const kw = (params.keyword || "").trim().toLowerCase();
			let pool = data.entries;
			const excluded = params.includeDormant ? 0 : pool.filter((e) => e.status === "dormant" || e.status === "deprecated").length;
			if (!params.includeDormant) pool = pool.filter((e) => e.status !== "dormant" && e.status !== "deprecated");
			if (params.section) pool = pool.filter((e) => e.section === params.section);
			if (params.status) pool = pool.filter((e) => (e.status || "candidate") === params.status);
			if (kw) {
				pool = pool.filter((e) =>
					`${e.id}\n${e.title}\n${e.insight}\n${e.example || ""}`.toLowerCase().includes(kw),
				);
			}
			// 高价值优先：usageCount 降序，同级 active 优先
			pool = pool.sort((a, b) => (b.usageCount ?? 0) - (a.usageCount ?? 0) || String(b.status).localeCompare(String(a.status)));
			const limit = params.limit && params.limit > 0 ? Math.floor(params.limit) : 5;
			const returned = pool.slice(0, limit); // 单次切片：正文与 wire 同源
			return {
				content: [{ type: "text" as const, text: renderQuery(returned, { keyword: params.keyword, total: data.entries.length, bytes: data.bytes, excluded }) }],
				structuredContent: toQueryWire({ matchedPool: pool, returned, excluded }),
			};
		}
		// show / lifecycle 需要唯一定位
		if (!params.id) {
			const text = `${params.action} 需要 id（或前缀）`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toHandbookErrorWire(params.action, "invalid-input", text) };
		}
		const hits = data.entries.filter((e) => e.id === params.id || e.id.startsWith(params.id!));
		if (hits.length !== 1) {
			const text = hits.length === 0 ? `未找到: ${params.id}` : `前缀歧义: ${params.id} 匹配 ${hits.length} 条`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toHandbookErrorWire(params.action, hits.length === 0 ? "not-found" : "invalid-input", text) };
		}
		if (params.action === "show") {
			return { content: [{ type: "text" as const, text: renderShow(hits[0]) }], structuredContent: toShowWire(hits[0]) };
		}
		// lifecycle
		if (!params.to) {
			const text = "lifecycle 需要 to（candidate/active/dormant/deprecated）";
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toHandbookErrorWire("lifecycle", "invalid-input", text) };
		}
		// 非法目标状态拒绝（P4：宿主参数面已枚举拦截——此为直接调用/防御层，迁移前拦截不写 sidecar）
		if (!(LIFECYCLE_STATES as readonly string[]).includes(params.to)) {
			const text = `lifecycle to 需为 candidate/active/dormant/deprecated（收到 ${JSON.stringify(params.to)}）`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toHandbookErrorWire("lifecycle", "invalid-input", text) };
		}
		const entry = hits[0];
		const from = entry.status || "candidate";
		if (from === params.to) return { content: [{ type: "text" as const, text: `[handbook lifecycle] ${entry.id} 已是 ${params.to}，无需迁移` }], structuredContent: toLifecycleWire(entry.id, from, params.to, false) };
		const sidecar = loadSidecar();
		const prev = sidecar.overrides[entry.id];
		const now = new Date().toISOString().slice(0, 10);
		const history = [...(prev?.history || []), { at: new Date().toISOString(), from, to: params.to, ...(params.note ? { note: params.note } : {}) }];
		sidecar.overrides[entry.id] = { status: params.to, lastReviewed: now, ...(params.note ? { note: params.note } : {}), history };
		if (params.to === "dormant" || params.to === "deprecated") sidecar.lastCleanup = now;
		try {
			saveSidecar(sidecar);
		} catch (e) {
			const text = `sidecar 写失败: ${(e as Error).message}`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toHandbookErrorWire("lifecycle", "operation", text) };
		}
		return { content: [{ type: "text" as const, text: `[handbook lifecycle] ${entry.id}: ${from} → ${params.to}（sidecar 持久，包内手册只读；pi update 不丢）` }], structuredContent: toLifecycleWire(entry.id, from, params.to, true) };
	};
	return {
		name: "amagi_handbook",
		label: "Amagi Tactical Handbook",
		description:
			"战术手册查询接口与生命周期治理：query（关键词/section/status 过滤取片段，替代全量读取）、" +
			"show（单条全文）、stats（分布+陈旧候选+字节量，腐烂可观测）、lifecycle（状态迁移，写 sidecar 覆盖层，pi update 不丢）。",
		promptSnippet:
			`amagi_handbook({ action:"query", keyword, limit }) — 手册片段查询（默认排除 dormant/deprecated）；` +
			`amagi_handbook({ action:"stats" }) — 分布/陈旧候选/字节量；` +
			`amagi_handbook({ action:"lifecycle", id, to, note }) — 状态迁移（sidecar 持久）`,
		parameters: Type.Object({
			action: StringEnum(["query", "show", "stats", "lifecycle"], { description: "query=片段查询 / show=单条全文 / stats=分布统计 / lifecycle=状态迁移" }),
			keyword: Type.Optional(Type.String({ description: "query: 关键词（匹配 id/title/insight/example，大小写不敏感）" })),
			section: Type.Optional(Type.String({ description: "query: section 过滤（如 error-patterns）" })),
			status: Type.Optional(Type.String({ description: "query: status 过滤（candidate/active/dormant/deprecated）" })),
			includeDormant: Type.Optional(Type.Boolean({ description: "query: 含 dormant/deprecated 历史条目（缺省 false）" })),
			limit: Type.Optional(Type.Number({ description: "query: 最大返回条数（缺省 5）" })),
			id: Type.Optional(Type.String({ description: "show/lifecycle: 条目 id 或前缀" })),
			to: Type.Optional(StringEnum(["candidate", "active", "dormant", "deprecated"], { description: "lifecycle: 目标状态" })),
			note: Type.Optional(Type.String({ description: "lifecycle: 迁移备注（证据/理由）" })),
		}),
		/** P4（寄生增强方案 §4.2）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema：TSchema）。
		 *  声明后 execute 成功/失败均携 structuredContent（五封闭分支 Union；消费者判据
		 *  kind/wireVersion/action/ok/schemaVersion）。正文 content 契约字节不变。 */
		outputSchema: HandbookOutputSchema,
		async execute(
			_id: string,
			params: {
				action: "query" | "show" | "stats" | "lifecycle";
				keyword?: string; section?: string; status?: string; includeDormant?: boolean; limit?: number;
				id?: string; to?: LifecycleState; note?: string;
			},
		) {
			// P4 双载体：正常分支正文/错误文案零改动（executeAction 内逐分支同文案）；
			// 意外异常兑底 internal error wire——正文复刻宿主对抛错的归一形状
			//（pi 0.99.1 executePreparedToolCall catch → createErrorToolResult：content=message、
			// details={}、isError），只加 structuredContent 新键（旧消费者面零变化）。
			try {
				return executeAction(params);
			} catch (e) {
				const message = e instanceof Error ? e.message : String(e);
				return {
					content: [{ type: "text" as const, text: message }],
					details: {},
					isError: true,
					structuredContent: toHandbookErrorWire(params?.action, "internal", message),
				};
			}
		},
	};
}
