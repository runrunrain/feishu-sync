/**
 * settled-write-face.ts — ev-20261117-f8a88b：子任务结算写面快照（内存缓存，会话级）。
 *
 * 实战事故（evolution 证据 ev-20261117-f8a88b）：Leader 提交已验收子任务的产物时，9 个已被
 * 子任务写面登记（own 11/写面命中 11、回执可定位）的路径仍被 staged-origin 提示整批标
 * 「来源未确认」。根因是时序：finalizer 在 done 终态结算链末尾 clearTaskWrites 清理登记文件
 * （登记生命周期纪律，防累积），而 guards.ts 的 taskRegisteredRelativePaths 在**之后**的
 * commit 阶段才消费 readTaskWrites——文件已删，读到空集，豁免从未生效。
 *
 * 修法（不动 task-run/finalizer 的清理纪律）：结算链在清理登记**之前**必然经过
 * evidence.ts collectArtifactDiffSummary（产物摘要消费登记的汇聚点）——在这里把登记的绝对
 * 路径集转存进本模块的会话级快照；guards 消费侧在 readTaskWrites 为空（登记已被结算清理）时
 * 回退读取快照。快照与 StagedOriginState 同为会话内存态：重启后丢失，staged-origin 回到保守
 * 警示口径（与 warnedPaths 会话内语义一致）。
 *
 * 证据口径纪律（与 task-write-log 相同）：
 *   - 快照只转存「子进程成功写盘登记 + registry 工具事件轨迹」的真实路径，不把 mtime、
 *     git add、allowedPaths 声明当创作证据；
 *   - 消费侧仍按 registry 记录的执行终态过滤（cancelled/error 不作来源，e91768-r2 口径），
 *     验收态从内核投影读取，不凭快照断言；
 *   - 有界：≤64 任务、每任务 ≤512 路径（与登记行上限同量级），FIFO 淘汰；
 *   - 本模块零 pi/fs 依赖（纯内存 Map），登记方（evidence.ts）与消费方（guards.ts）互不
 *     import——避免重模块间新增依赖边（同 task-write-log 的独立共享模块纪律）。
 */

/** 快照任务数上限（FIFO；会话内派发的子任务远小于此，超界淘汰最旧）。 */
export const SETTLED_WRITE_FACE_MAX_TASKS = 64;
/** 单任务快照路径上限（与 TASK_WRITE_LOG_MAX_LINES 同量级；超出截断保留最新）。 */
export const SETTLED_WRITE_FACE_MAX_FILES = 512;

export interface SettledWriteFace {
	/** 结算时仓库根（物理归一，physicalPathDeep 口径——消费侧用它判定路径归属）。 */
	repoRoot: string;
	/** 登记绝对路径集（归一后，无序）。 */
	files: Set<string>;
	/** 首次记录时刻 epoch ms（信息性）。 */
	at: number;
}

const settledFaces = new Map<string, SettledWriteFace>();

/**
 * 记录/合并一个任务的结算写面快照（幂等；resume 多轮结算路径集累积）。
 * 空路径集 no-op（不占缓存槽）。任何异常由调用方语境静默——快照是弱归因辅助数据。
 */
export function recordSettledWriteFace(taskId: string, repoRoot: string, files: readonly string[]): void {
	if (!taskId || !repoRoot || files.length === 0) return;
	try {
		const existing = settledFaces.get(taskId);
		if (existing) {
			for (const f of files) {
				if (!f) continue;
				existing.files.add(f);
				if (existing.files.size > SETTLED_WRITE_FACE_MAX_FILES) existing.files.delete(existing.files.values().next().value as string);
			}
			return;
		}
		if (settledFaces.size >= SETTLED_WRITE_FACE_MAX_TASKS) {
			const oldest = settledFaces.keys().next().value;
			if (oldest !== undefined) settledFaces.delete(oldest);
		}
		const bounded = new Set<string>();
		for (const f of files) {
			if (!f) continue;
			bounded.add(f);
			if (bounded.size > SETTLED_WRITE_FACE_MAX_FILES) bounded.delete(bounded.values().next().value as string);
		}
		settledFaces.set(taskId, { repoRoot, files: bounded, at: Date.now() });
	} catch { /* lint-exempt:快照失败静默——回退 readTaskWrites 旧口径（保守警示） */ }
}

/** 读取任务的结算写面快照路径（无快照 → 空数组；不暴露内部可变结构）。 */
export function readSettledWriteFaceFiles(taskId: string): string[] {
	if (!taskId) return [];
	try { return [...(settledFaces.get(taskId)?.files ?? [])]; } catch { /* lint-exempt:弱归因快照读取失败回退空集，继续保守提示未知来源 */ return []; }
}

/** 测试隔离：清空全部快照（仅测试进程调用；不影响任何持久数据）。 */
export function resetSettledWriteFaceForTest(): void {
	settledFaces.clear();
}
