/**
 * git-discard-guard.ts — ev-20260916-18f0d5 / 07e44a（bash 入口）：Git 丢弃改动确认门与脏 worktree 强删前置检查。
 *
 * 背景（已沉淀改进项消化，方案 §3.2/§3.3）：
 *  - `git checkout -- <paths>` / `git restore` / `git reset --hard` 此前只有静默快照锚点
 *    （snapshot-guard）或完全无覆盖（reset --hard）——多源共享工作区里一次误丢弃直接毁掉
 *    未提交现场。本模块补「执行前确认门」：识别会丢弃未提交改动的 Git 操作，列出准确影响
 *    范围；默认要求真实确认渠道（TUI ui.confirm，默认否、超时/取消均拒绝）；无确认渠道的
 *    子代理/RPC/headless 会话一律阻断并报告 Leader，绝不伪造授权。
 *  - `git worktree remove --force` 会连脏工作树一起强删——cleanupWorktree（worktree.ts，S4）
 *    的非 force 拒绝保护不了用户直接走 Git CLI。本模块在 bash 实际执行前做同一脏树检查。
 *
 * 接口契约（方案 §3.2 拟定，语义为准）：
 *  - `inspectDiscard(command, cwd)`：识别丢弃操作并采集 { kind, repoRoot, pathspecs,
 *    dirtyPaths, sides, numstat, unknownReason?, fingerprint, splitBefore? }；非丢弃命令返回 null。
 *  - `decideDiscardGate(command, cwd)`：策略机 → allow / warn / block / confirm（confirm 分支
 *    由接线方走真实确认渠道，确认后重查 fingerprint，状态变化则取消本次执行）。
 *  - `decideWorktreeRemoveGate(command, cwd)`：git worktree remove（含 --force/-f/-C）前置脏树检查。
 *
 * 识别范围（方案 §3.2「识别范围必须正确」）：
 *  - checkout：路径还原（-- 分隔 / tree-ish+路径 / . 形态），单纯切分支不算；-f/--force 的
 *    丢改动形态按破坏性风险识别，不能靠去掉 `--` 绕过；
 *  - restore：默认工作区、--staged 暂存区、--staged --worktree 组合分别报告；--source 纳入
 *    变更范围（与来源树比较，不只比默认来源）；
 *  - reset：仅 --hard 进入本门，不扩展为 reset 全族硬禁；
 *  - 路径集合走 Git pathspec 语义（由 git diff 实际解析，天然支持引用与带空格文件名），
 *    NUL 分隔读取；展示前 20 条 + 总数；
 *  - 状态查询失败、alias/cwd/路径范围不能确定 → unknownReason → 确认模式下保守拒绝，不猜「干净」。
 *
 * 回滚开关（操作者部署配置；阻断文案不得教模型临时设 env 绕过）：
 *  - AMAGI_GIT_DISCARD_POLICY=confirm|warn|legacy，默认 confirm；非法值回安全默认 confirm。
 *    warn 列出风险但不确认；legacy 恢复旧行为（仅静默快照，无确认门）。
 *  - AMAGI_WORKTREE_DIRTY_REMOVE=protect|legacy，默认 protect；legacy 仅恢复 force 的旧行为。
 *
 * 本模块还承载从 guards.ts 迁入的 Git 调用解析共享层（cd/-C/--git-dir/--work-tree 跟踪、
 * 同命令变量赋值展开、alias 解析、只读判定）——guards.ts 的提交守卫与本模块共用，避免
 * 循环依赖（guards → git-discard-guard 单向）。零 pi 依赖、无注册副作用。
 */

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { shellSegmentsMeta, executableWords, substitutionPayloads, analyzeExecutableShell, UNCLOSED_BACKTICK, UNSAFE_DOUBLE_QUOTED_BACKTICK, type ShellTokenMeta } from "./shell-lexer.ts";

// ══════════════════ 共享层：Git 调用解析（自 guards.ts 迁入，语义逐字保持） ══════════════════

export interface GitInvocation {
	cwd: string;
	globalOptions: string[];
	subcommand: string;
	args: string[];
	/** ev-20260916：该 invocation 首词所在段索引（复合命令的丢弃前置段检测用）。 */
	segmentIndex: number;
	/** 命令内 cd / -C / --git-dir / --work-tree 目标解析不到真实目录（变量未展开或目录不存在）
	 *  时置位——cwd 不可信，破坏性判定保守拒绝而不是拿错位探针猜「干净」。 */
	cwdUncertain?: boolean;
	/** 触发 cwdUncertain 的原始目标文本。 */
	uncertainTarget?: string;
}

const KNOWN_GIT_COMMANDS = new Set([
	"add", "am", "apply", "bisect", "branch", "checkout", "cherry-pick", "clean", "clone", "config", "diff", "fetch", "grep", "init", "log", "merge", "mv", "pull", "push", "rebase", "remote", "reset", "restore", "rev-parse", "rm", "show", "stash", "status", "switch", "tag", "worktree",
	"commit",
]);

export function gitOutput(invocation: GitInvocation, args: string[], timeoutMs = 10_000): string | null {
	try {
		return execFileSync("git", [...invocation.globalOptions, ...args], { cwd: invocation.cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: timeoutMs }).trim();
	} catch { return null; }
}

/** NUL 分隔输出读取（-z）：pathspec/porcelain 逐条解析，天然支持带空格文件名。 */
function nulEntries(raw: string | null): string[] | null {
	if (raw === null) return null;
	return raw.split("\0").map((s) => s.replace(/\r?\n$/, "")).filter(Boolean);
}

/** ev-20260922-1eea28（B2）：原始 NUL 输出执行（不 trim 整体输出）——porcelain -z 首记录以
 *  状态前缀（可能含前导空格）开头，`gitOutput` 的整体 `.trim()` 会剥掉它；影响集合采集
 *  （障碍路径/rename 两侧/index 条目）必须用原始字节流逐 NUL 解析，不 `.trim()` 文件名。 */
export function gitOutputRaw(invocation: GitInvocation, args: string[], timeoutMs = 10_000): string | null {
	try {
		return execFileSync("git", [...invocation.globalOptions, ...args], { cwd: invocation.cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: timeoutMs });
	} catch { return null; }
}

/** bash/powershell 工具调用的有效执行 cwd：input.cwd 优先（WSL 形态归一化），缺省回会话 cwd。
 *  ev-20260916 起 guards/git-discard-guard 共用；B2（ev-20260922-1eea28）起 bash-override
 *  执行边界（一次性放行凭证绑定 cwd）同款解析，保证守卫预检与实际执行同一 cwd 口径。 */
export function effectiveBashCwd(input: Record<string, unknown> | undefined, sessionCwd: string): string {
	const raw = typeof input?.cwd === "string" ? input.cwd.trim() : "";
	if (!raw) return sessionCwd;
	const normalized = normalizeGuardPath(raw);
	return path.isAbsolute(normalized) ? path.normalize(normalized) : path.resolve(sessionCwd, normalized);
}

/** ev-20260823-c3881f：WSL 路径归一化（语义自 guards.ts 迁入，guards re-export 维持外部导入路径）。 */
export function normalizeGuardPath(raw: string): string {
	if (process.platform === "win32") {
		const m = /^\/mnt\/([a-z])(?:\/(.*))?$/i.exec(raw.trim());
		if (m) {
			const drive = m[1]!.toUpperCase();
			const rest = m[2] ? m[2].replaceAll("/", "\\") : "";
			return `${drive}:\\${rest}`;
		}
	}
	return raw;
}

const SHELL_ASSIGNMENT_RE = /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/;

const UNSAFE_UNQUOTED_EXPANSION_RE = /[\s*?[]/;

function expandShellTarget(raw: string, vars: Map<string, string>, unquotedVar = false): { value: string; unresolved: boolean } {
	let value = raw;
	for (let pass = 0; pass < 5; pass++) {
		const next = value.replace(/\$(?:\{([A-Za-z_][A-Za-z0-9_]*)\}|([A-Za-z_][A-Za-z0-9_]*))/g, (all: string, braced?: string, bare?: string) => {
			const name = braced || bare || "";
			const assigned = vars.get(name);
			if (assigned !== undefined) return assigned;
			const fromEnv = process.env[name];
			return fromEnv ? fromEnv : all;
		});
		if (next === value) break;
		value = next;
	}
	if (value === "~" || value.startsWith("~/")) value = `${os.homedir()}${value.slice(1)}`;
	if (unquotedVar && (value.trim() === "" || UNSAFE_UNQUOTED_EXPANSION_RE.test(value))) return { value, unresolved: true };
	return { value, unresolved: value.includes("`") || /\$\(|\$\{?[A-Za-z_]/.test(value) };
}

function resolveGuardTarget(target: string, base: string, vars: Map<string, string>, unquotedVar = false): { dir: string; uncertain: boolean } {
	const expanded = expandShellTarget(target, vars, unquotedVar);
	const dir = path.resolve(base, normalizeGuardPath(expanded.value));
	if (expanded.unresolved) return { dir, uncertain: true };
	try {
		if (fs.statSync(dir).isDirectory()) return { dir, uncertain: false };
	} catch { /* 目录不存在 / 不可访问：cd 必然失败 */ }
	return { dir, uncertain: true };
}

function cdTarget(words: readonly ShellTokenMeta[]): { target: ShellTokenMeta | null; unknown: boolean } {
	for (let i = 1; i < words.length; i++) {
		const token = words[i]!;
		if (token.text === "--" || /^-[LPe@]+$/.test(token.text)) continue;
		return { target: token, unknown: token.text.startsWith("-") };
	}
	return { target: null, unknown: false };
}

export function parseGitInvocations(command: string, cwd: string): GitInvocation[] {
	const result: GitInvocation[] = [];
	let currentCwd = path.resolve(cwd);
	let cwdUncertain = false, cwdUncertainTarget: string | undefined;
	const vars = new Map<string, string>();
	let segmentIndex = -1;
	for (const segment of shellSegmentsMeta(command)) {
		segmentIndex++;
		const normalized = segment.map((token) => ({ ...token }));
		if (normalized.length) {
			normalized[0]!.text = normalized[0]!.text.replace(/^\(+/, "");
			normalized[normalized.length - 1]!.text = normalized[normalized.length - 1]!.text.replace(/\)+$/, "");
		}
		const rawTexts = normalized.map((token) => token.text);
		const leadCount = compoundLeadCount(rawTexts); // B4C 复审 RR-02：then/do/else/case 模式词后的命令段照常识别
		const texts = leadCount > 0 ? rawTexts.slice(leadCount) : rawTexts;
		const assignWords = ["export", "declare", "typeset", "readonly"].includes(texts[0] ?? "") ? texts.slice(1) : texts;
		for (const token of assignWords) {
			const assignment = SHELL_ASSIGNMENT_RE.exec(token);
			if (!assignment) break;
			vars.set(assignment[1]!, assignment[2]!);
		}
		const words = executableWords(texts, true);
		const wordsMeta = normalized.slice(leadCount + texts.length - words.length);
		if (path.basename(words[0] || "") === "cd") {
			const target = cdTarget(wordsMeta);
			if (target.unknown) { cwdUncertain = true; cwdUncertainTarget = target.target?.text; continue; }
			if (target.target === null) { currentCwd = os.homedir(); cwdUncertain = false; cwdUncertainTarget = undefined; continue; }
			const resolved = resolveGuardTarget(target.target.text, currentCwd, vars, target.target.unquotedVar);
			currentCwd = resolved.dir;
			cwdUncertain = resolved.uncertain;
			cwdUncertainTarget = resolved.uncertain ? target.target.text : undefined;
			continue;
		}
		if (path.basename(words[0] || "") !== "git") continue;
		let gitCwd = currentCwd;
		let uncertain = cwdUncertain, uncertainTarget = cwdUncertainTarget;
		const globalOptions: string[] = [];
		let i = 1;
		while (i < words.length && words[i].startsWith("-")) {
			const option = words[i];
			if (option === "-C" && words[i + 1]) {
				const resolved = resolveGuardTarget(wordsMeta[i + 1]!.text, gitCwd, vars, wordsMeta[i + 1]!.unquotedVar);
				gitCwd = resolved.dir;
				if (resolved.uncertain) { uncertain = true; uncertainTarget = words[i + 1]; }
				globalOptions.push("-C", gitCwd); i += 2; continue;
			}
			if (option.startsWith("--git-dir=")) {
				const resolved = resolveGuardTarget(option.slice(10), gitCwd, vars, wordsMeta[i]!.unquotedVar);
				if (resolved.uncertain) { uncertain = true; uncertainTarget = option.slice(10); }
				globalOptions.push(`--git-dir=${resolved.dir}`); i++; continue;
			}
			if (option === "--git-dir" && words[i + 1]) {
				const resolved = resolveGuardTarget(wordsMeta[i + 1]!.text, gitCwd, vars, wordsMeta[i + 1]!.unquotedVar);
				if (resolved.uncertain) { uncertain = true; uncertainTarget = words[i + 1]; }
				globalOptions.push("--git-dir", resolved.dir); i += 2; continue;
			}
			if (option.startsWith("--work-tree=")) {
				const resolved = resolveGuardTarget(option.slice(12), gitCwd, vars, wordsMeta[i]!.unquotedVar);
				if (resolved.uncertain) { uncertain = true; uncertainTarget = option.slice(12); }
				globalOptions.push(`--work-tree=${resolved.dir}`); i++; continue;
			}
			if (option === "--work-tree" && words[i + 1]) {
				const resolved = resolveGuardTarget(wordsMeta[i + 1]!.text, gitCwd, vars, wordsMeta[i + 1]!.unquotedVar);
				if (resolved.uncertain) { uncertain = true; uncertainTarget = words[i + 1]; }
				globalOptions.push("--work-tree", resolved.dir); i += 2; continue;
			}
			if ((option === "-c" || option === "--config-env" || option === "--namespace") && words[i + 1]) { globalOptions.push(option, words[i + 1]); i += 2; continue; }
			globalOptions.push(option); i++;
		}
		if (words[i]) result.push({ cwd: currentCwd, globalOptions, subcommand: words[i], args: words.slice(i + 1), segmentIndex, ...(uncertain ? { cwdUncertain: true, uncertainTarget } : {}) });
	}
	return result;
}

export function resolveGitCommand(invocation: GitInvocation): { subcommand: string; args: string[]; uncertain?: boolean; uncertainShellAlias?: boolean } {
	let subcommand = invocation.subcommand;
	let args = [...invocation.args];
	for (let depth = 0; depth < 5; depth++) {
		if (KNOWN_GIT_COMMANDS.has(subcommand)) return { subcommand, args };
		const alias = gitOutput(invocation, ["config", "--get", `alias.${subcommand}`]);
		if (!alias) return { subcommand, args };
		if (alias.startsWith("!")) {
			// shell 别名内的自由文本不再递归展开——只提取首个疑似 git 子命令。
			// diting 审核 Minor-3：提取不出（空）或提取出的不是已知 git 子命令（如 "bash"/"\"$@\""）——
			// 均标 uncertainShellAlias（! 形态丢弃语义不可探），inspectDiscard 无条件保守进门，
			// 不再依赖命令文本字样（防 `!bash -c 'git reset --hard'` 类函数/包装形态绕过确认门）。
			const aliasWords = alias.slice(1).split(/\s+/).filter(Boolean);
			const gitIndex = aliasWords.findIndex((token) => path.basename(token) === "git");
			const resolved = gitIndex >= 0 ? aliasWords[gitIndex + 1] : aliasWords[0];
			if (!resolved || !KNOWN_GIT_COMMANDS.has(resolved)) return { subcommand, args, uncertain: true, uncertainShellAlias: true };
			return { subcommand: resolved, args: [...aliasWords.slice(gitIndex >= 0 ? gitIndex + 2 : 1), ...args] };
		}
		const aliasWords = alias.split(/\s+/).filter(Boolean);
		if (!aliasWords.length) return { subcommand, args, uncertain: true };
		subcommand = aliasWords[0];
		args = [...aliasWords.slice(1), ...args];
	}
	return { subcommand, args, uncertain: true };
}

// v1.5.179（自 guards.ts 迁入）：bash 只读判别——无变异指示符（重定向/写入 API/移动删除/git 写
// 操作等）时视为只读；不确定时保守视为变异（用于丢弃前置段的拆分检测）。
const SENTINEL_MUTATING = /(>>?\s*[^&]|\btee\b|\brm\b|\bmv\b|\bcp\b|\bmkdir\b|\btouch\b|\bchmod\b|\bchown\b|\btruncate\b|\bdd\b|sed\s+-i|open\([^)]*["'][wax]["']|json\.dump|writeFile|appendFile|\.write\(|git\s+(add|commit|push|reset|checkout|apply|merge|rebase)|\bpi\s+(update|install|remove))/;

export function isReadOnlyCommand(command: string): boolean {
	const scrubbed = command
		.replace(/\d*>&\d*/g, " ")
		.replace(/>>?\s*\/dev\/null\b/g, " ");
	return !SENTINEL_MUTATING.test(scrubbed);
}

// ══════════════════ 18f0d5：丢弃改动确认门 ══════════════════

export type DiscardPolicy = "confirm" | "warn" | "legacy";

/** AMAGI_GIT_DISCARD_POLICY 解析：confirm（默认）| warn | legacy；非法值回安全默认 confirm。 */
export function parseDiscardPolicy(env: string | undefined = process.env.AMAGI_GIT_DISCARD_POLICY): DiscardPolicy {
	const v = env?.trim().toLowerCase();
	if (v === "warn" || v === "legacy") return v;
	return "confirm";
}

export type DiscardKind = "checkout-paths" | "checkout-force" | "restore" | "reset-hard";

export interface DiscardInspection {
	/** 丢弃操作形态。 */
	kind: DiscardKind;
	/** 形态说明（restore 的 worktree/--staged 组合、checkout 的 tree 来源等）。 */
	kindLabel: string;
	/** 丢弃操作执行 cwd（命令内 cd/-C 解析后）。 */
	cwd: string;
	/** 仓库根（rev-parse --show-toplevel；null = 不可定位）。 */
	repoRoot: string | null;
	/** git pathspec（checkout/restore；reset-hard / checkout-force 为空数组 = 全仓）。 */
	pathspecs: string[];
	/** 将被丢弃改动的路径（相对仓库根，已排序；空 = 无待丢弃改动）。 */
	dirtyPaths: string[];
	/** ev-20260922-1eea28（B2）：pathspec 范围内的未跟踪/忽略障碍路径（不在暂存区；恢复来源为
	 *  tree 时会被直接覆写——此前 stash create 快照与 diff 探针都保不到它们）。已排序。 */
	obstaclePaths: string[];
	/** dirty 集合的 index/worktree 侧构成（能可靠区分时）。 */
	sides: { index: number; worktree: number };
	/** numstat 可靠统计时的约增删行数。 */
	numstat?: { added: number; deleted: number };
	/** 存在 = 影响范围不可信（状态查询失败 / alias / cwd / 路径范围不能确定）→ 确认模式保守拒绝。 */
	unknownReason?: string;
	/** 一次有效指纹：规范 cwd + 命令 + 目标路径 + HEAD/index/worktree 状态摘要；确认后重查不一致则取消。 */
	fingerprint: string;
	/** 丢弃段之前/之后存在会改变 Git 状态的段（复合命令，要求拆开执行）；值为该段文本。 */
	splitBefore?: string;
	/** 展示文本（前 20 条 + 总数）。 */
	dirtyListText: string;
}

/** 丢弃命令快速预筛：命令提及 git 即进入段解析（alias 可能把任意词映射到 checkout/restore/reset，
 *  词级预筛会旁路；已知子命令零子进程开销，未知子命令的 alias 探测与提交守卫同成本面）。 */
const DISCARD_PRE_FILTER = /\bgit\b/;

/** checkout/restore/reset 之外、会先改变 Git 状态的子命令（丢弃前置段检测）。 */
const GIT_STATE_MUTATORS = new Set(["add", "commit", "stash", "rm", "mv", "clean", "merge", "rebase", "cherry-pick", "revert", "checkout", "restore", "reset", "switch", "am", "apply", "bisect", "worktree", "tag", "notes", "update-index", "read-tree", "sparse-checkout"]);

interface DiscardForm {
	kind: DiscardKind;
	kindLabel: string;
	pathspecs: string[];
	tree?: string;
	unknown?: string;
}

/** checkout 参数 → 丢弃形态（路径还原 / force 丢改动 / 切分支·建分支不拦 / 不可判定）。 */
function parseCheckoutForm(invocation: GitInvocation, args: string[]): DiscardForm | null {
	const valueOptions = new Set(["-b", "-B", "--orphan", "--conflict", "--pathspec-from-file"]);
	let force = false;
	let createsBranch = false;
	const nonOptions: string[] = [];
	const specs: string[] = [];
	let afterDash = false;
	for (let i = 0; i < args.length; i++) {
		const arg = args[i];
		if (afterDash) { specs.push(arg); continue; }
		if (arg === "--") { afterDash = true; continue; }
		if (arg.startsWith("--")) {
			if (arg === "--force") { force = true; continue; }
			if (arg.startsWith("--pathspec-from-file=")) return { kind: "checkout-paths", kindLabel: "checkout 路径还原（pathspec 来自文件，范围须确认）", pathspecs: [], unknown: "pathspec 来自文件，路径范围不能在执行前确定" };
			if (arg.startsWith("--orphan=")) { createsBranch = true; continue; }
			if (valueOptions.has(arg)) { if (arg === "-b" || arg === "-B" || arg === "--orphan") createsBranch = true; i++; }
			continue;
		}
		if (arg.startsWith("-") && arg.length > 1) {
			const flags = arg.slice(1);
			if (/[fF]/.test(flags)) force = true;
			if (/[bB]/.test(flags)) createsBranch = true;
			continue;
		}
		nonOptions.push(arg);
	}
	if (createsBranch) return null; // checkout -b/-B/--orphan：创建分支并携带改动，非丢弃形态
	if (specs.length) {
		// 显式 `--` 分隔：-- 之后全部是 pathspec；-- 之前至多一个 tree-ish
		if (nonOptions.length > 1) return { kind: "checkout-paths", kindLabel: "checkout 路径还原", pathspecs: specs, unknown: "`--` 之前存在多个参数，tree-ish 与路径无法区分" };
		const tree = nonOptions.length === 1 ? nonOptions[0] : undefined;
		return {
			kind: "checkout-paths",
			kindLabel: tree ? `checkout 路径还原（来源 ${tree}）` : "checkout 路径还原（来源 index）",
			pathspecs: specs,
			...(tree ? { tree } : {}),
		};
	}
	if (force) return { kind: "checkout-force", kindLabel: `checkout --force（${nonOptions.join(" ") || "HEAD"}，丢弃未提交改动）`, pathspecs: [] };
	if (nonOptions.length === 0) return null; // 无目标（git 报用法错），不拦
	if (nonOptions.length === 1) {
		const only = nonOptions[0];
		const resolvesAsTree = gitOutput(invocation, ["rev-parse", "--verify", "-q", only]) !== null;
		if (resolvesAsTree) return null; // 单 tree-ish 且无 --：切分支/检出到提交，不是路径还原
		return { kind: "checkout-paths", kindLabel: "checkout 路径还原（来源 index）", pathspecs: [only] };
	}
	// 多参数无 --：首个若为 tree-ish 则其余是 pathspec，否则全部按 pathspec（与 git 行为一致）
	const first = nonOptions[0];
	const firstIsTree = gitOutput(invocation, ["rev-parse", "--verify", "-q", first]) !== null;
	if (firstIsTree) return { kind: "checkout-paths", kindLabel: `checkout 路径还原（来源 ${first}）`, pathspecs: nonOptions.slice(1), tree: first };
	return { kind: "checkout-paths", kindLabel: "checkout 路径还原（来源 index）", pathspecs: nonOptions };
}

/** restore 参数 → 丢弃形态（--staged / --worktree / --source 组合分别报告）。 */
function parseRestoreForm(args: string[]): DiscardForm | null {
	const valueOptions = new Set(["-s", "--source", "--conflict", "--pathspec-from-file"]);
	let staged = false, worktreeFlag = false, source: string | undefined;
	const specs: string[] = [];
	let afterDash = false;
	let pathspecFile = false;
	for (let i = 0; i < args.length; i++) {
		const arg = args[i];
		if (afterDash) { specs.push(arg); continue; }
		if (arg === "--") { afterDash = true; continue; }
		if (arg.startsWith("--")) {
			if (arg === "--staged") staged = true;
			else if (arg === "--worktree") worktreeFlag = true;
			else if (arg.startsWith("--source=")) source = arg.slice("--source=".length);
			else if (arg.startsWith("--pathspec-from-file=")) pathspecFile = true;
			else if (valueOptions.has(arg)) { if (arg === "--source") source = args[i + 1]; i++; }
			continue;
		}
		if (arg.startsWith("-") && arg.length > 1) {
			if (/^-[A-Za-z]*S/.test(arg)) staged = true;
			if (/^-[A-Za-z]*W/.test(arg)) worktreeFlag = true;
			if (arg === "-s") { source = args[i + 1]; i++; }
			continue;
		}
		specs.push(arg);
	}
	if (pathspecFile) return { kind: "restore", kindLabel: "restore（pathspec 来自文件，范围须确认）", pathspecs: [], unknown: "pathspec 来自文件，路径范围不能在执行前确定" };
	if (!specs.length) return null; // restore 必须带 pathspec，缺省由 git 报错
	const worktree = worktreeFlag || !staged;
	const labels: string[] = [];
	if (staged) labels.push(`--staged（index ← ${source ?? "HEAD"}）`);
	if (worktree) labels.push(`工作区 ← ${source ?? "index"}`);
	return {
		kind: "restore",
		kindLabel: `restore：${labels.join(" + ")}`,
		pathspecs: specs,
		...(source ? { tree: source } : {}),
	};
}

/** reset 参数 → 丢弃形态（仅 --hard 进门；target 默认 HEAD）。 */
function parseResetForm(args: string[]): DiscardForm | null {
	let hard = false;
	let target: string | undefined;
	for (const arg of args) {
		if (arg === "--hard") { hard = true; continue; }
		if (arg === "--soft" || arg === "--mixed" || arg === "--merge" || arg === "--keep") continue;
		if (arg.startsWith("-")) continue;
		if (target === undefined) target = arg;
	}
	if (!hard) return null;
	return { kind: "reset-hard", kindLabel: `reset --hard（目标 ${target ?? "HEAD"}，丢弃全部未提交 tracked 改动）`, pathspecs: [], ...(target ? { tree: target } : {}) };
}

/** 段文本（供 splitBefore 描述与只读判定）。 */
function segmentTexts(meta: ShellTokenMeta[]): string[] {
	return meta.map((t) => t.text);
}

/** pathspec 可确定性：含未展开变量/命令替换 → 不能确定范围。 */
function pathspecUncertain(specs: string[]): string | undefined {
	for (const spec of specs) {
		if (/\$\{?[A-Za-z_]/.test(spec) || spec.includes("`")) return `pathspec「${spec}」含未展开变量，路径范围不能确定`;
	}
	return undefined;
}

/** ev-20260922-1eea28（B2）：pathspec 范围内的未跟踪/忽略障碍路径采集（不在 index 中的文件——
 *  `ls-files --others` 天然只列非 index 路径）。--exclude-standard 给 untracked（不含 ignored）；
 *  加 --ignored 给仅 ignored；两者相加 = pathspec 范围内全部非暂存文件。保守不判定「目标 tree
 *  是否含该路径」——多列影响面让确认/授权看到更全的对象（风险只朝保守方向）。探测失败返回
 *  null（调用方 unknownReason 把关，不当空集）。 */
function obstaclePathsFor(invocation: GitInvocation, specs: string[]): string[] | null {
	if (!specs.length) return [];
	const collected = new Set<string>();
	const untracked = gitOutputRaw(invocation, ["ls-files", "--others", "--exclude-standard", "-z", "--", ...specs]);
	const ignored = gitOutputRaw(invocation, ["ls-files", "--others", "--ignored", "--exclude-standard", "-z", "--", ...specs]);
	if (untracked === null || ignored === null) return null;
	for (const entry of nulEntries(untracked) ?? []) collected.add(entry);
	for (const entry of nulEntries(ignored) ?? []) collected.add(entry);
	return [...collected].sort();
}

function sha256(text: string): string {
	return createHash("sha256").update(text).digest("hex");
}

/** diff 探针：mode=""（worktree 侧）| "--cached"（index 侧）；返回 NUL 路径集或 null（探针失败）。 */
function diffPaths(invocation: GitInvocation, cached: boolean, tree: string | undefined, specs: string[]): { paths: string[] } | null {
	const args = ["diff"];
	if (cached) args.push("--cached");
	args.push("--name-only", "-z");
	if (tree) args.push(tree);
	if (specs.length) args.push("--", ...specs);
	const raw = gitOutput(invocation, args);
	const entries = nulEntries(raw);
	if (entries === null) return null;
	return { paths: entries };
}

/** numstat 汇总（二进制/不可解析行跳过；失败返回 null）。 */
function diffNumstat(invocation: GitInvocation, cached: boolean, tree: string | undefined, specs: string[]): { added: number; deleted: number } | null {
	const args = ["diff"];
	if (cached) args.push("--cached");
	args.push("--numstat");
	if (tree) args.push(tree);
	if (specs.length) args.push("--", ...specs);
	const raw = gitOutput(invocation, args);
	if (raw === null) return null;
	let added = 0, deleted = 0;
	for (const line of raw.split(/\r?\n/)) {
		const m = /^(\d+|-)\s+(\d+|-)\s+/.exec(line.trim());
		if (!m) continue;
		if (m[1] !== "-") added += Number(m[1]);
		if (m[2] !== "-") deleted += Number(m[2]);
	}
	return { added, deleted };
}

/** 丢弃形态 → 影响 legs（每 leg 标注侧别与比较基准；restore 依据 kindLabel 中的标志组合）。 */
function discardLegsFor(form: DiscardForm): Array<{ cached: boolean; tree?: string }> {
	switch (form.kind) {
		case "checkout-paths":
			return form.tree
				? [{ cached: false, tree: form.tree }, { cached: true, tree: form.tree }]
				: [{ cached: false, tree: undefined }];
		case "checkout-force":
			return [{ cached: false, tree: "HEAD" }];
		case "restore": {
			// --staged：index ← source（默认 HEAD）；工作区：worktree ← source（默认 index）
			const legs: Array<{ cached: boolean; tree?: string }> = [];
			if (form.kindLabel.includes("--staged")) legs.push({ cached: true, tree: form.tree ?? "HEAD" });
			if (form.kindLabel.includes("工作区")) legs.push({ cached: false, tree: form.tree });
			return legs;
		}
		case "reset-hard":
			return [{ cached: false, tree: form.tree ?? "HEAD" }];
	}
}

/**
 * inspectDiscard：识别命令中的第一个丢弃操作并采集影响范围。
 * 返回 null = 非丢弃命令；unknownReason 存在时 dirtyPaths 不可信（调用方保守拒绝）。
 */
export function inspectDiscard(command: string, cwd: string): DiscardInspection | null {
	if (!command || !DISCARD_PRE_FILTER.test(command)) return null;
	const invocations = parseGitInvocations(command, cwd);
	let target: { invocation: GitInvocation; form: DiscardForm } | null = null;
	let splitBefore: string | undefined;
	for (const invocation of invocations) {
		const resolved = resolveGitCommand(invocation);
		if (resolved.uncertain) {
			// diting 审核 Minor-3：! shell-alias 函数形态（展开不出子命令）丢弃语义不可探——无条件
			// 保守进门；其余 uncertain（空文本别名/展开深度）维持命令文本含丢弃字样才进（避免 `git st`
			// 等正常文本别名误拦）。
			const enterUnknown = !!resolved.uncertainShellAlias || /(?:checkout|restore|reset)/i.test(command);
			if (enterUnknown && !target) return buildUnknownInspection(command, cwd, invocation, resolved.uncertainShellAlias ? "Git shell 别名（! 形态）无法安全展开，丢弃语义不能确定" : "Git alias 无法安全展开，丢弃语义不能确定");
			continue;
		}
		let form: DiscardForm | null = null;
		if (resolved.subcommand === "checkout") form = parseCheckoutForm(invocation, resolved.args);
		else if (resolved.subcommand === "restore") form = parseRestoreForm(resolved.args);
		else if (resolved.subcommand === "reset") form = parseResetForm(resolved.args);
		if (!form) continue;
		if (!target) { target = { invocation, form }; continue; }
		// 同一命令内出现第二个丢弃操作：预检只对第一个做确认，第二个必然针对「新状态」——要求拆开。
		if (!splitBefore) splitBefore = `同一命令内存在多个丢弃操作（第 ${invocation.segmentIndex + 1} 段）`;
	}
	if (!target) return null;

	// 复合命令：丢弃段之前存在会改变 Git 状态的段 → 预检看到的是旧状态，要求拆开执行。
	const segments = shellSegmentsMeta(command);
	const earlier = splitBefore ?? detectStateChangingPrefix(segments, target.invocation.segmentIndex);
	if (earlier) splitBefore = earlier;

	const { invocation, form } = target;
	const sides = { index: 0, worktree: 0 };
	const dirty = new Set<string>();
	let probeFailed = false;
	const specUncertain = pathspecUncertain(form.pathspecs);
	const legs = discardLegsFor(form);
	let added = 0, deleted = 0, numstatOk = true;
	for (const leg of legs) {
		const legResult = diffPaths(invocation, leg.cached, leg.tree, form.pathspecs);
		if (!legResult) { probeFailed = true; break; }
		for (const p of legResult.paths) dirty.add(p);
		sides[leg.cached ? "index" : "worktree"] += legResult.paths.length;
		const stat = diffNumstat(invocation, leg.cached, leg.tree, form.pathspecs);
		if (stat) { added += stat.added; deleted += stat.deleted; } else numstatOk = false;
	}
	const repoRoot = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
	// ev-20260922-1eea28（B2）：未跟踪/忽略障碍路径（pathspec 范围内非 index 文件，恢复来源会覆写）。
	// 探测失败 → unknownReason（不当空集，防「障碍面不可见」的假干净）。
	const obstacleProbe = obstaclePathsFor(invocation, form.pathspecs);
	const unknownReason = invocation.cwdUncertain
		? `执行目录不能确定（cd/-C 目标${invocation.uncertainTarget ? `「${invocation.uncertainTarget}」` : ""}无法解析）`
		: repoRoot === null
			? "目标目录不是可用的 Git 仓库（或 git 探测失败）"
			: specUncertain
				? specUncertain
				: form.unknown
					? form.unknown
					: probeFailed
						? "Git 状态查询失败（超时/权限/引用损坏）"
						: obstacleProbe === null
							? "未跟踪/忽略障碍路径探测失败（ls-files --others 探针失败）——影响面不能确定"
							: undefined;

	const head = gitOutput(invocation, ["rev-parse", "HEAD"]) ?? "no-head";
	// 状态摘要：porcelain（tracked + untracked）——确认后任何工作区/暂存变化都会使 fingerprint 失效，
	// 预检授权不跨状态生效（保守方向：宁可重新确认）。探测失败时摘要为空串（unknownReason 已另行把关）。
	const stateDigest = gitOutput(invocation, ["status", "--porcelain", "-z", "--untracked-files=all"]) ?? "";
	const obstaclePaths = obstacleProbe ?? [];
	const dirtyPaths = [...dirty].sort();
	const fingerprint = sha256(JSON.stringify([path.resolve(invocation.cwd), command, form.kind, repoRoot, form.pathspecs, dirtyPaths, obstaclePaths, head, sha256(stateDigest)]));
	const list = dirtyPaths.slice(0, 20).join("、");
	const dirtyListText = dirtyPaths.length
		? `${list}${dirtyPaths.length > 20 ? ` 等 ${dirtyPaths.length} 项` : ""}`
		: "";
	return {
		kind: form.kind,
		kindLabel: form.kindLabel,
		cwd: invocation.cwd,
		repoRoot,
		pathspecs: form.pathspecs,
		dirtyPaths,
		obstaclePaths,
		sides,
		...(numstatOk && (added > 0 || deleted > 0) ? { numstat: { added, deleted } } : {}),
		...(unknownReason ? { unknownReason } : {}),
		fingerprint,
		...(splitBefore ? { splitBefore } : {}),
		dirtyListText,
	};
}

function buildUnknownInspection(command: string, cwd: string, invocation: GitInvocation, reason: string): DiscardInspection {
	const fingerprint = sha256(JSON.stringify([path.resolve(invocation.cwd), command, "unknown", reason]));
	return {
		kind: "reset-hard",
		kindLabel: "疑似丢弃操作（alias 展开不确定）",
		cwd: invocation.cwd,
		repoRoot: null,
		pathspecs: [],
		dirtyPaths: [],
		obstaclePaths: [],
		sides: { index: 0, worktree: 0 },
		unknownReason: reason,
		fingerprint,
		dirtyListText: "",
	};
}

/** B4C 复审 RR-02：复合语句引导词剥除——then/do/else/elif/in/{/!/time、case 分支模式词
 *  （`x)`/`*)`）或 `;;` 开头的段，其引导词后的内容按独立命令段判定。fail-safe：正常命令段首
 *  不会是这些词/形态，误剥仅造成更严（识别更多 git/cd 调用），不形成放行；不剥则复合语句体内
 *  的 git 调用逃逸检测（`if true; then git commit…; fi`）。既有无尾同段缺口随本修复一并补齐。 */
const COMPOUND_LEAD_WORDS = new Set(["if", "while", "until", "then", "do", "else", "elif", "in", "!", "time", "{", "(", ";;"]);
// B4C 复审 RR2-04：if/while/until 头一并剥除——条件位命令真实执行（`if git commit; then…`）
// 但旧集合漏检（既有缺口，双树同 ALLOW）；剥除后条件命令按独立命令段检查，误剥仅更严。
function compoundLeadCount(texts: readonly string[]): number {
	let n = 0;
	while (n < texts.length) {
		const first = texts[n]!;
		if (first === "case") { // `case WORD in PATTERN) cmds`：跳过条件词直到 in/esac（in 在集合中，下一轮剥除）
			n++;
			while (n < texts.length && texts[n] !== "in" && texts[n] !== "esac") n++;
			continue;
		}
		if (COMPOUND_LEAD_WORDS.has(first) || /^\S+\)$/.test(first)) { n++; continue; }
		break;
	}
	return n;
}

/** 丢弃段之前的状态改变段检测：git 变异子命令 / 非只读命令 → 要求拆开执行。 */
function detectStateChangingPrefix(segments: ShellTokenMeta[][], discardSegmentIndex: number): string | undefined {
	for (let i = 0; i < discardSegmentIndex && i < segments.length; i++) {
		const rawTexts = segmentTexts(segments[i]);
		if (!rawTexts.length) continue;
		const texts = rawTexts.slice(compoundLeadCount(rawTexts)); // B4C 复审 RR-02
		if (!texts.length) continue;
		const words = executableWords(texts, true);
		if (!words.length) continue; // 纯赋值段
		const exe = path.basename(words[0]).toLowerCase();
		if (exe === "cd") continue;
		if (exe === "git") {
			let j = 1;
			while (j < words.length && words[j].startsWith("-")) {
				if ((words[j] === "-C" || words[j] === "--git-dir" || words[j] === "--work-tree" || words[j] === "-c" || words[j] === "--config-env" || words[j] === "--namespace") && words[j + 1]) j += 2;
				else j++;
			}
			const sub = words[j];
			if (!sub) continue;
			if (sub === "stash" && ["list", "show"].includes(words[j + 1] ?? "")) continue; // stash list/show 只读
			if (sub === "worktree" && words[j + 1] === "list") continue; // worktree list 只读
			if (GIT_STATE_MUTATORS.has(sub)) return `前置段「${texts.join(" ")}」会先改变 Git 状态`;
			continue;
		}
		if (!isReadOnlyCommand(texts.join(" "))) return `前置段「${texts.join(" ")}」可能改变工作区/Git 状态`;
	}
	return undefined;
}

// ── 决策机 ──

export type DiscardGateDecision =
	| { action: "allow" }
	| { action: "warn"; reason: string }
	| { action: "block"; reason: string }
	| { action: "confirm"; inspection: DiscardInspection; title: string; message: string };

/** 风险清单文本（warn 与 confirm 共用；B2 起含未跟踪/忽略障碍面）。 */
export function discardRiskText(inspection: DiscardInspection): string {
	const parts = [
		`操作：${inspection.kindLabel}`,
		`将丢弃 ${inspection.dirtyPaths.length} 个路径的未提交改动（index 侧 ${inspection.sides.index} / worktree 侧 ${inspection.sides.worktree}${inspection.numstat ? `；约 +${inspection.numstat.added}/-${inspection.numstat.deleted} 行` : ""}）`,
		`路径：${inspection.dirtyListText}`,
	];
	if (inspection.obstaclePaths?.length) {
		const obstacleList = inspection.obstaclePaths.slice(0, 20).join("、");
		parts.push(`另将覆盖 ${inspection.obstaclePaths.length} 个未跟踪/忽略路径（不在暂存区，stash/diff 类快照保不到；恢复来源会直接覆写）：${obstacleList}${inspection.obstaclePaths.length > 20 ? ` 等 ${inspection.obstaclePaths.length} 项` : ""}`);
	}
	return parts.join("\n");
}

/** 确认对话内容（默认否；超时/取消均拒绝）。ev-20260918-2d67fa：补「等效恢复路径同样受审视」警示——
 *  实战：git checkout -- 被确认门拦截后，改用 python 从 git show HEAD 读内容写回（7+29 文件）完全放行，
 *  两条路径效果等价却只拦一条——安全机制被无声架空。文案如实声明边界：拦截针对 git 丢弃命令形态；
 *  「读 HEAD 内容写回」类等效操作不自动拦截（内容级检测成本过高且误伤正常写入），但要求同等自证已获确认，
 *  不得把确认门当作可绕过的形式。 */
export function buildDiscardConfirmMessage(inspection: DiscardInspection): { title: string; message: string } {
	const message = `${discardRiskText(inspection)}\n小范围恢复优先用 edit 工具做局部修复；执行前会自动建立 git 快照锚点（stash create），但它只覆盖已跟踪改动，不保证未跟踪/忽略文件或并发写入可恢复。\n⚠ 等效路径同样受审视：改用「从 git show HEAD 读内容写回文件」（python/cat 直写等）与本确认门效果等价——同样视为丢弃工作树改动，须先取得同等确认再执行，不得以此绕过确认门。\n确认执行本次丢弃？（默认否；超时/取消视为拒绝）`;
	return { title: "[amagi] Git 丢弃改动确认", message };
}

/**
 * 决策机（纯同步；confirm 分支由接线方接真实 UI 并负责确认后 fingerprint 重查）。
 * 返回 null = 命令不含丢弃操作（不干预）；policy=legacy 一律 allow。
 */
export function decideDiscardGate(command: string, cwd: string, policy: DiscardPolicy = parseDiscardPolicy()): DiscardGateDecision | null {
	if (policy === "legacy") return { action: "allow" };
	const inspection = inspectDiscard(command, cwd);
	if (!inspection) return null;
	if (inspection.splitBefore) {
		const reason = `${inspection.splitBefore}——预检针对旧状态的确认不能授权新状态，请拆开执行：先执行前置命令，再单独执行丢弃操作（${inspection.kindLabel}）。`;
		return policy === "confirm" ? { action: "block", reason } : { action: "warn", reason };
	}
	if (inspection.unknownReason) {
		const reason = `影响范围不能确定（${inspection.unknownReason}）——不做「干净」猜测，保守${policy === "confirm" ? "拒绝" : "警示"}：${inspection.kindLabel}。请改用可确定 cwd/pathspec 的写法（字面路径、同命令变量赋值），或人工确认后单独执行。`;
		return policy === "confirm" ? { action: "block", reason } : { action: "warn", reason };
	}
	if (!inspection.dirtyPaths.length && !inspection.obstaclePaths.length) return { action: "allow" }; // 目标无待丢弃改动且无障碍面：不弹确认，正常执行
	if (policy === "warn") return { action: "warn", reason: discardRiskText(inspection) };
	const { title, message } = buildDiscardConfirmMessage(inspection);
	return { action: "confirm", inspection, title, message };
}

// ═══ ev-20260917-589972（P2）：子 Agent stash 硬拦截 ═══
// 实战（battle-simulator F6d，任务 6c42dde6）：共享树多进程协作时子 Agent 为归因把主上未提交改动
// 「stash 短暂归因后原样恢复」——stash 后进程中断即主上工作丢失（本次侥幸恢复成功，风险已实际
// 发生）。checkout/restore/reset --hard 已由下方丢弃确认门覆盖（headless 无确认渠道 → block），
// stash 此前只有软提示——本门补齐：子 Agent（AMAGI_SUBAGENT）进程内 stash 风险子命令命中
// 未提交改动（工作区/暂存区脏）或既有 stash 条目（pop/apply/drop/clear 会改他人 stash）→ 阻断；
// 干净树 + 空 stash 栈的少量形态放行（无他人工作可丢）；探测失败保守阻断（状态未知不当干净）。
// 逃生舱沿用 AMAGI_GIT_DISCARD_POLICY（legacy 全放行、warn 不阻断）。stash 子命令解析随
// STASH_RISKY_SUBCOMMANDS/stashRiskOperation 一并自 guards.ts 迁入（guards re-export 维持外部导入路径）。

/** stash 子命令中会改动工作区/引用状态的集合（list/show 只读豁免）。 */
export const STASH_RISKY_SUBCOMMANDS = new Set(["push", "pop", "apply", "drop", "clear", "store", "save", "branch", "create"]);

/** 命令是否包含真实的 stash 风险操作（纯函数；ev-20260922-2d5a76 起经 analyzeExecutableShell
 *  统一视图——quoted heredoc body 只是数据不触发，bash -c/eval 包裹、$()/反引号替换与
 *  unquoted body 展开均可达真实执行节点）。 */
export function stashRiskOperation(command: string, cwd: string = process.cwd()): boolean {
	const view = analyzeExecutableShell(command);
	for (const text of [view.stripped, ...view.wrapperPayloads, ...view.substitutionPayloads, ...view.unquotedBodyPayloads]) {
		for (const invocation of parseGitInvocations(text, cwd)) {
			const resolved = resolveGitCommand(invocation);
			if (resolved.subcommand !== "stash") continue;
			const sub = resolved.args.find((arg) => !arg.startsWith("-"));
			if (!sub) return true; // git stash（无子命令 = 新增 stash，改引用与工作区）
			if (STASH_RISKY_SUBCOMMANDS.has(sub)) return true;
			// list/show 只读；其余未知子命令 git 自行报错，不提示
		}
	}
	return false;
}

/** 子 Agent stash 拦截门决策。返回 null = 非子 Agent/非 stash/策略放行/干净树空栈；
 *  返回 { action: "block", reason } = 命中未提交改动或既有 stash 条目，命令不得执行。
 *  ev-20260922-2d5a76：入口改消费 analyzeExecutableShell 统一视图（quoted heredoc body 是数据
 *  不再误触发；wrapper/替换/unquoted body 展开可达性保持）。 */
export function decideSubagentStashGate(command: string, cwd: string, opts?: { subagent?: boolean; policy?: DiscardPolicy }): { action: "block"; reason: string } | null {
	const subagent = opts?.subagent ?? process.env.AMAGI_SUBAGENT === "1";
	if (!subagent) return null;
	const policy = opts?.policy ?? parseDiscardPolicy();
	if (policy === "legacy" || policy === "warn") return null; // 逃生舱：warn 仅警示（软提示仍在），legacy 全放行
	const view = analyzeExecutableShell(command);
	for (const text of [view.stripped, ...view.wrapperPayloads, ...view.substitutionPayloads, ...view.unquotedBodyPayloads]) {
		for (const invocation of parseGitInvocations(text, cwd)) {
			const resolved = resolveGitCommand(invocation);
			if (resolved.subcommand !== "stash") continue;
			const sub = resolved.args.find((arg) => !arg.startsWith("-"));
			const bare = !sub; // git stash（无子命令 = push）
			if (!bare && !STASH_RISKY_SUBCOMMANDS.has(sub!)) continue; // list/show 只读放行
			if (invocation.cwdUncertain) {
				return { action: "block", reason: `[amagi 守卫·共享树纪律] 子 Agent git stash 操作的执行目录不能确定（cd/-C 目标${invocation.uncertainTarget ? `「${invocation.uncertainTarget}」` : ""}无法解析）——不猜测目标，命令未执行。请用字面路径写法后重试。` };
			}
			// 未提交改动探针（tracked；不含 untracked——默认 stash 不触碰未跟踪文件）
			// 非仓库豁免前置：rev-parse 失败（非仓库）→ git 自行报错、无可丢工作，放行不产生误拦噪音。
			if (gitOutput(invocation, ["rev-parse", "--show-toplevel"]) === null) continue;
			const dirtyRaw = gitOutput(invocation, ["status", "--porcelain", "--untracked-files=no"]);
			// 既有 stash 栈探针（pop/apply/drop/clear 会改他人 stash 条目）
			const stashListRaw = gitOutput(invocation, ["stash", "list"]);
			if (dirtyRaw === null || stashListRaw === null) {
				return { action: "block", reason: `[amagi 守卫·共享树纪律] 子 Agent git stash 操作前状态探测失败（非仓库/git 探测失败）——状态未知时按「可能有未提交改动」处理，命令未执行。归因分析只观察（git status/diff），不改变工作区状态；确需 stash 处置请报告 Leader 在具备确认渠道的会话执行。` };
			}
			const dirtyCount = dirtyRaw.split("\n").filter(Boolean).length;
			const stashCount = stashListRaw.split("\n").filter(Boolean).length;
			const touchesStashEntries = !bare && ["pop", "apply", "drop", "clear", "store", "branch", "create"].includes(sub!);
			if (dirtyCount > 0 || (touchesStashEntries && stashCount > 0)) {
				const parts: string[] = [];
				if (dirtyCount > 0) parts.push(`工作区/暂存区存在 ${dirtyCount} 个未提交改动路径（共享树多进程协作时可能是主上或并行 Agent 的工作——stash 后中断即丢失）`);
				if (touchesStashEntries && stashCount > 0) parts.push(`stash 栈已有 ${stashCount} 条既有条目（可能是他人暂存——${sub} 会改动/删除它们）`);
				return { action: "block", reason: `[amagi 守卫·共享树纪律] 子 Agent 会话检测到 git stash 操作将触碰未提交改动/既有 stash：${parts.join("；")}——命令未执行。归因分析只观察（git status/diff/log）不改变工作区状态；确需 stash 处置请报告 Leader 在具备确认渠道的会话执行（逃生舱 AMAGI_GIT_DISCARD_POLICY=warn 由操作者部署配置）。` };
			}
		}
	}
	return null;
}

// ═══ ev-20260922-e44fe9（B0/P0）：stash 串联门——同一工具调用内风险 stash 与其他可执行段整单拒绝 ═══
// 实战（evolution 研究 R/B，任务 p7）：`git stash push -m p7-check -- <paths>; git stash pop`——
// push 因 untracked 路径失败，pop 仍运行，弹出他人 stash 污染七个文件。裁决：风险 stash 不得
// 与另一可执行段放在同一工具调用（;/&&/||/换行/管道/后台串联一律拦，&& 不豁免：退出 0 不证明
// 新增 stash，共享栈两步间可能被改）。本门不以 AMAGI_SUBAGENT 分流、不被 AMAGI_GIT_DISCARD_POLICY
// =warn/legacy 豁免（安全兼容性变化，发布说明列出）；单步 stash 仍走既有子 Agent 门与主会话软提示，
// 不扩展成全部 stash 禁用。判定基于 analyzeExecutableShell 的真实可执行段（引用参数/注释/quoted
// heredoc body/printf 文本不算执行）；wrapper/alias 递归保留 compound 上下文；深度上限 4；解析不到
// alias 语义时复合 Git 调用保守要求拆分，不把普通命令当 stash。
//
// B4·批C（ev-20261012-af58eb §3#6 + Leader 裁定）：拆「组合形态」与「stash 对象危险」——
// 只读段（list/show）本就不触发；新增：显式 pathspec 的 push（`git stash push … -- <paths>`）
// 属精确对象且可恢复（中断后新条目在栈中可见、git stash show -p 可读、apply 可恢复），不因
// 串联拒绝。继续拒绝：drop/clear（销毁既有条目）、隐式栈顶 pop（无参或 stash@{0}——栈顶可能是
// 他人条目）、来源未知 push（无 pathspec——收走全部脏改动，可能含他人工作）、pop/apply（弹出/
// 应用他人条目污染工作区且不可自动恢复）、store/save/branch/create（改栈结构或工作区）。不新增
// stashChain=off，不做统一放行。

export interface StashChainGateDecision {
	action: "block";
	reason: string;
}

/** 串联扫描执行单元：exe=段主执行名；stashRisk=解析为风险 stash；parent=包裹/替换展开链父节点。 */
interface StashChainUnit {
	exe: string;
	text: string;
	stashRisk: boolean;
	uncertainAlias: boolean;
	parent: StashChainUnit | null;
}

const STASH_CHAIN_MAX_DEPTH = 4;

/** 「另一可执行段」判定：排除目标自身、其祖先链（包裹宿主：bash -c 'git stash push' 单步不算串联）
 *  与其后代（自身展开域内的替换执行：git stash push -m $(date) 的 date 不算另一段）。 */
function stashChainUnitOtherExists(units: StashChainUnit[], target: StashChainUnit): boolean {
	const excluded = new Set<StashChainUnit>();
	for (let u: StashChainUnit | null = target; u; u = u.parent) excluded.add(u);
	const collectDescendants = (unit: StashChainUnit): void => {
		excluded.add(unit);
		for (const other of units) if (other.parent === unit) collectDescendants(other);
	};
	collectDescendants(target);
	return units.some((unit) => !excluded.has(unit));
}

/** 递归扫描一个链上下文的可执行段：view.segments 顶层段 + 段自身展开域（wrapper/$()/反引号）
 *  + 未引用 heredoc body 展开节点。cd 段跟踪 cwd（alias 解析正确性）；纯赋值段不算执行段。 */
function scanStashChainUnits(text: string, baseCwd: string, depth: number, parent: StashChainUnit | null, units: StashChainUnit[]): void {
	if (depth > STASH_CHAIN_MAX_DEPTH) return;
	const view = analyzeExecutableShell(text);
	let currentCwd = path.resolve(baseCwd);
	let cwdUncertain = false;
	const vars = new Map<string, string>();
	for (const segment of view.segments) {
		if (!segment.length) continue;
		const rawText = view.stripped.slice(segment[0].start, segment[segment.length - 1].end);
		const metas: ShellTokenMeta[] = segment.map((token) => ({ text: token.text, unquotedVar: token.unquotedVar }));
		metas[0].text = metas[0].text.replace(/^\(+/, "");
		metas[metas.length - 1].text = metas[metas.length - 1].text.replace(/\)+$/, "");
		for (const meta of metas) {
			const assignment = SHELL_ASSIGNMENT_RE.exec(meta.text);
			if (!assignment) break;
			vars.set(assignment[1]!, assignment[2]!);
		}
		let ai = 0;
		while (ai < metas.length && SHELL_ASSIGNMENT_RE.test(metas[ai].text)) ai++;
		if (ai >= metas.length) continue; // 纯赋值段：不是执行段（含命令替换的赋值经 payload 递归检查真实执行节点）
		const rest = metas.slice(ai);
		const words = executableWords(rest.map((meta) => meta.text), true);
		if (!words.length) continue;
		const exe = path.basename(words[0]).toLowerCase();
		if (exe === "cd") {
			const target = cdTarget(rest);
			if (target.unknown) cwdUncertain = true;
			else if (target.target === null) { currentCwd = os.homedir(); cwdUncertain = false; }
			else {
				const resolved = resolveGuardTarget(target.target.text, currentCwd, vars, target.target.unquotedVar);
				currentCwd = resolved.dir;
				cwdUncertain = resolved.uncertain;
			}
			units.push({ exe: "cd", text: rawText, stashRisk: false, uncertainAlias: false, parent });
			continue;
		}
		const unit: StashChainUnit = { exe, text: rawText, stashRisk: false, uncertainAlias: false, parent };
		if (exe === "git") {
			for (const invocation of parseGitInvocations(rawText, currentCwd)) {
				const resolved = resolveGitCommand(invocation);
				if (resolved.subcommand === "stash") {
					const sub = resolved.args.find((arg) => !arg.startsWith("-"));
					// B4·批C：stashChainRiskClass 分类——scoped-push（显式 pathspec，精确对象且可恢复）
					// 不因串联拒绝；drop/clear/隐式 pop/无 pathspec push/pop/apply 继续拒。
					if (stashChainRiskClass(sub, resolved.args) === "risky") unit.stashRisk = true;
				}
				// 解析不到 alias 语义（! 形态/展开深度），或 cwd 不可信时未知子命令无法证明非 stash——
				// 仅在复合链中保守要求拆分（单段交由既有守卫处置）。
				if (resolved.uncertain || ((invocation.cwdUncertain || cwdUncertain) && !KNOWN_GIT_COMMANDS.has(resolved.subcommand))) unit.uncertainAlias = true;
			}
		}
		units.push(unit);
		const childPayloads: string[] = [];
		for (const payload of substitutionPayloads(rawText)) {
			if (payload === UNCLOSED_BACKTICK || payload === UNSAFE_DOUBLE_QUOTED_BACKTICK) continue; // 解析错误归危险命令守卫
			childPayloads.push(payload);
		}
		if (["sh", "bash", "zsh"].includes(exe)) {
			const cIndex = words.findIndex((word, index) => index > 0 && /^-[A-Za-z]*c[A-Za-z]*$/.test(word));
			let payloadIndex = cIndex + 1;
			if (words[payloadIndex] === "--") payloadIndex++;
			if (cIndex >= 0 && words[payloadIndex]) childPayloads.push(words[payloadIndex]);
		}
		if (exe === "eval" && words.length > 1) childPayloads.push(words.slice(1).join(" "));
		for (const payload of childPayloads) scanStashChainUnits(payload, currentCwd, depth + 1, unit, units);
	}
	// 未引用 heredoc body 的展开执行节点：与顶层同链处置（unquoted 危险替换按真实执行判）
	for (const payload of view.unquotedBodyPayloads) scanStashChainUnits(payload, currentCwd, depth + 1, null, units);
}

function shortUnitText(unit: StashChainUnit): string {
	const text = unit.text.replace(/\s+/g, " ").trim();
	return text.length > 80 ? `${text.slice(0, 80)}…` : text;
}

/** B4C-R03/RR-04/RR-05：pathspec token 的字面精确性证明——含变量/命令替换/引号/反斜杠/空白/
 *  通配/字符类/pathspec magic 前缀（:/^!）/`-` 开头选项形态，均属对象不确定，保守 risky。
 *  RR-04：token 按 `/` 分段，任一段为 `.` 或 `..` 即拒（`a/..`/`./.`/`dir/../.` 归一化到仓库
 *  根/父目录 ≡ 全量收走，真实语义实测）；RR-05：绝对路径（`/tmp/…`）一并保守拒（仓库外对象
 *  不可证明，真实多为 fatal/零效果——拒属 fail-safe 过度拦截，如实披露）。仅相对、无 `.`/`..`
 *  段、无通配、字面逐 token 可证的 pathspec 放行。 */
function literalPathspecToken(token: string): boolean {
	if (token === "") return false;
	if (/[$`(){};'\"\s\\]/.test(token)) return false; // 变量/命令替换/引号/空白/转义（展开后不可证明）
	if (/[*?\[\]]/.test(token)) return false; // shell 通配/字符类（展开面不可证明）
	if (token.startsWith(":") || token.startsWith("^") || token.startsWith("!")) return false; // git pathspec magic
	if (token.startsWith("-")) return false; // 选项不是路径
	if (token.startsWith("/")) return false; // 绝对路径（RR-05：仓库外/全盘形态不可证明，保守拒）
	if (token.split("/").some((seg) => seg === "." || seg === "..")) return false; // `.`/`..` 段：归一到根/父 = 扩大对象（RR-04）
	return true;
}

/** B4C 复审 RR-03：无 `--` 时只认的独立安全选项集（布尔标志，无值）。合并短簇/未知/带值形态
 *  均不进白名单（fail-safe：证明不了就拒）。 */
const SAFE_STASH_PUSH_FLAGS = new Set(["-u", "-k", "-a", "-q", "-S", "--include-untracked", "--all", "--keep-index", "--no-keep-index", "--staged", "--quiet"]);

/** stash 子命令串联危险分类（B4·批C 精化 + B4C-R03 + B4C 复审 RR-03/RR-04）：只读不触发；pathspec **非空且每个 token
 *  为字面精确路径**的 push = scoped（串联放行）；其余风险子命令/裸 stash/动态来源继续拒绝。
 *  B4C-R03：token 个数不是证明——`-- $P`（空展开）/`-- *`（通配）/`-- .`（全目录）/
 *  `--pathspec-from-file <file>`（对象来自文件内容，未经证明）均保持 risky；选项值
 *  （--pathspec-from-file/--message 后的参数）不得计入 pathspec。-p/--patch 交互形态保守归
 *  risky。解析并到边界形态一律 risky（不为凑数放行）。 */
export function stashChainRiskClass(sub: string | undefined, args: readonly string[]): "readonly" | "scoped-push" | "risky" {
	if (sub === undefined) return "risky"; // git stash（无子命令 = push 无 pathspec）
	if (sub === "list" || sub === "show") return "readonly";
	if (sub !== "push") return "risky"; // pop/apply/drop/clear/store/save/branch/create 与未知子命令
	const subIdx = args.findIndex((a) => !a.startsWith("-"));
	const body = args.slice(subIdx + 1); // 子命令之后的参数
	if (body.some((a) => a === "-p" || a === "--patch" || /^-[^-]*p/.test(a))) return "risky"; // 交互 patch 形态
	if (body.some((a) => a === "--pathspec-from-file" || a.startsWith("--pathspec-from-file=") || a === "--pathspec-file-nul")) return "risky"; // 对象来自文件内容，未经证明（B4C-R03）
	const dashIdx = body.indexOf("--");
	let specs: string[];
	if (dashIdx >= 0) {
		specs = body.slice(dashIdx + 1);
	} else {
		// 无 `--`：只认白名单独立选项（RR-03：合并短选项簇 -um/-qum/-m<val> 与未知选项一律 risky——
		// 簇的真实语义不可从形状证明，`-um w` = -u -m w：w 是 message 值，曾被误计为 pathspec 把
		// 无 pathspec 全量收走误判 scoped）；独立 -m/--message 消费值，--message= 内嵌值；剩余位参 =
		// message（若未显式 -m）+ pathspec。
		const positional: string[] = [];
		let hasMessageFlag = false;
		for (let i = 0; i < body.length; i++) {
			const a = body[i]!;
			if (a === "-m" || a === "--message") { hasMessageFlag = true; i++; continue; } // 独立形态消费值
			if (/^--message=/.test(a)) { hasMessageFlag = true; continue; }
			if (/^-/.test(a)) { if (!SAFE_STASH_PUSH_FLAGS.has(a)) return "risky"; continue; } // 白名单外（含合并簇/未知/带值短选项）risky
			positional.push(a);
		}
		const messageCount = hasMessageFlag ? 0 : 1;
		specs = positional.slice(messageCount);
	}
	// 非空 + 每个都是字面精确路径 → scoped；否则（含空/动态/扩大对象）risky。
	return specs.length > 0 && specs.every(literalPathspecToken) ? "scoped-push" : "risky";
}

/** stash 串联门决策（纯同步，无 git 探针）。返回 null = 无风险 stash 串联；返回 block = 整单拒绝
 *  （未执行任何前置段）。全通道适用，不受 AMAGI_SUBAGENT/AMAGI_GIT_DISCARD_POLICY 影响。
 *  B4·批C：scoped-push（显式 pathspec，精确对象且可恢复）不再因串联拒绝；drop/clear/隐式栈顶
 *  pop/无 pathspec push/pop/apply 等对象危险段继续拒绝。 */
export function decideStashChainGate(command: string, cwd: string): StashChainGateDecision | null {
	if (!command || !/\bgit\b/.test(command)) return null;
	const units: StashChainUnit[] = [];
	try {
		scanStashChainUnits(command, cwd, 0, null, units);
	} catch {
		return null; // 解析异常不额外拦（有界安全网：其余守卫链仍在）
	}
	for (const unit of units) {
		if (!stashChainUnitOtherExists(units, unit)) continue;
		if (unit.stashRisk) {
			return {
				action: "block",
				reason: `[amagi 守卫·stash 串联] 同一命令链中的对象危险 git stash（drop/clear 销毁既有条目；隐式栈顶 pop/apply 弹出或应用可能是他人的条目；无 pathspec 的 push 收走来源不明的全部脏改动；store/save/branch/create 改栈结构——段「${shortUnitText(unit)}」）与其他可执行段串联——串联 pop/apply 可能弹出他人 stash 条目且无自动恢复（共享 stash 栈在两步之间可能被其他进程修改；前置段退出 0 不证明新增 stash 归属本操作）；整条命令未执行。请拆开分步执行：其他段单独执行（cd 段改用工具 cwd 参数），stash 步骤单独执行并确认条目 OID 与归属（显式 pathspec 的 push 如 git stash push -m msg -- <paths> 为精确对象且可恢复，串联不拦）。本门覆盖主/子 Agent 与全部执行通道，不被 AMAGI_GIT_DISCARD_POLICY=warn/legacy 豁免（安全兼容性变化，见发布说明）；单步 stash 仍走既有确认/提示通道。`,
			};
		}
		if (unit.uncertainAlias) {
			return {
				action: "block",
				reason: `[amagi 守卫·stash 串联] 复合命令链中的 Git 调用（段「${shortUnitText(unit)}」）alias 语义无法解析——不能证明其不是 stash 风险操作，保守拦截：整条命令未执行。请拆开分步执行：先把别名展开为真实子命令，或将复合命令拆成单条命令分别执行。`,
			};
		}
	}
	return null;
}

// ══════════════════ 07e44a（bash 入口）：git worktree remove 前置脏树检查 ══════════════════
// 复用 S4 在 worktree.ts 导出的只读检查 inspectWorktreeRemoval（目标解析 + active owner 硬拒绝 +
// status --porcelain -z --untracked-files=all 脏态采集；探测失败不当干净）——cleanupWorktree 的
// API 入口与本 bash 入口同一实现，缺一不可（只改 API 防不住用户直接走 Git CLI）。
// 回滚：AMAGI_WORKTREE_DIRTY_REMOVE=protect|legacy（默认 protect；解析在 worktree.ts，非法值回 protect）。

import { inspectWorktreeRemoval, worktreeDirtyRemoveMode } from "./worktree.ts";

/** invocation 全局选项里最后一个 -C 的已解析绝对目录（无则 undefined）：git 的路径解析基准。 */
function lastGlobalMinusCDir(invocation: GitInvocation): string | undefined {
	let value: string | undefined;
	for (let i = 0; i + 1 < invocation.globalOptions.length; i++) {
		if (invocation.globalOptions[i] === "-C") value = invocation.globalOptions[i + 1];
	}
	return value;
}

/**
 * bash 前置门：命令含 `git worktree remove`（含 --force/-f、-C）时检查目标树脏状态。
 * 返回 null = 无该调用或放行（含 legacy 策略与不存在的目标——git 自行报错，无可丢弃内容）；
 * 返回 { action: "block", reason } = 脏树/活跃占用/状态未知，命令不得执行。
 *
 * 2.22.2 任务E（diting N1/N1′/N2/N2′ 三轮对抗审核后 Leader 裁定）：本门是硬拦截守卫，漏放 = 丢
 * 未提交内容——不做任何「shell 形态识别」的放宽（heredoc 剥离与字面 for 循环展开均曾致脏树真放行），
 * 恢复 HEAD 的 fail-closed 行为：直接消费 rawCommand，目标是 $var/反引号等未展开形态一律按
 * 「含未展开变量」拦截。executableDomainOf 的文档型 heredoc 剥离仅保留给提醒类消费方（env-flip），
 * 禁止用于本门（见 shell-lexer.ts executableDomainOf 头注释）。-C 基准目录修正（lastGlobalMinusCDir，
 * fix-A/D，diting 已核实）保留。
 */
export function decideWorktreeRemoveGate(rawCommand: string, cwd: string): { action: "block"; reason: string } | null {
	if (!rawCommand || !/\bworktree\b/.test(rawCommand) || !/\b(?:remove|rm)\b/.test(rawCommand)) return null;
	if (worktreeDirtyRemoveMode() === "legacy") return null;
	for (const invocation of parseGitInvocations(rawCommand, cwd)) {
		if (invocation.cwdUncertain) return { action: "block", reason: `git worktree remove 的执行目录不能确定（cd/-C 目标${invocation.uncertainTarget ? `「${invocation.uncertainTarget}」` : ""}无法解析）——不猜测目标，命令未执行。请用字面路径写法后重试。` };
		const resolved = resolveGitCommand(invocation);
		if (resolved.subcommand !== "worktree") continue;
		let sub: string | undefined, target: string | undefined;
		for (const arg of resolved.args) {
			if (arg.startsWith("-")) continue;
			if (!sub) { sub = arg; continue; }
			if (sub === "remove" || sub === "rm") { target = arg; break; }
		}
		if (sub !== "remove" && sub !== "rm") continue;
		if (!target) return null; // 缺目标：git 自行报错
		if (/\$\{?[A-Za-z_]/.test(target) || target.includes("`")) return { action: "block", reason: `worktree remove 目标「${target}」含未展开变量，目标不能确定——命令未执行。请用字面路径后重试（循环/变量形态请拆成逐条字面路径命令，或先确认各 worktree 干净）。` };
		// fix-A/D 修正（diting 已核实 -C 会移动 git 的路径解析基准）+ 2.22.2 任务E 补充：git worktree
		// remove 的目标解析实测同时受 -C 链与原始 cwd 影响（`git -C wt -C . worktree remove wt/dirty` 在
		// -C 基准解析不出目标时仍会删除 invocation.cwd 基准下的 wt/dirty——名字/回退匹配语义无法静态枚举），
		// 单一基准解析会漏。硬拦截守卫按候选基准并集检查：-C 目标与 invocation.cwd 各解析一次，任一命中
		// 真实存在的 worktree 即纳入脏树/占用/探测检查——只增加检查面，不构成任何放行。
		const minusCDir = lastGlobalMinusCDir(invocation);
		const baseCwds = minusCDir && minusCDir !== invocation.cwd ? [minusCDir, invocation.cwd] : [invocation.cwd];
		for (const baseCwd of baseCwds) {
			const targetAbs = path.isAbsolute(target) ? path.normalize(normalizeGuardPath(target)) : path.resolve(baseCwd, normalizeGuardPath(target));
			const repoRoot = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
			if (!repoRoot) return null; // 非仓库：git 自行报错
			const inspection = inspectWorktreeRemoval(repoRoot, targetAbs);
			if (!inspection.exists) continue; // 此基准下目标不存在：换下一候选（均不存在 → git 报错，无数据可丢）
			if (inspection.activeOwner) {
				return { action: "block", reason: `worktree ${inspection.path} 仍被任务 ${inspection.activeOwner.taskId || inspection.activeOwner.leaseId} 活跃占用——硬拒绝不可被开关豁免；先等任务终态或 cancel 后再删除。命令未执行。` };
			}
			if (inspection.probeError) {
				return { action: "block", reason: `worktree ${inspection.path} 的 Git 状态探测失败（${inspection.probeError}）——状态未知时按「可能有未提交改动」处理。命令未执行；请人工检查 ${inspection.path} 后再处理。` };
			}
			if (!inspection.dirtyPaths.length) continue; // 此基准下干净：换下一候选（全部干净才放行）
			const list = inspection.dirtyPaths.slice(0, 20).join("、");
			const more = inspection.dirtyPaths.length > 20 ? ` 等 ${inspection.dirtyPaths.length} 项` : "";
			const linkNote = inspection.symlinkPaths?.length ? `（另有 ${inspection.symlinkPaths.length} 个 symlink 不计入丢弃面：${inspection.symlinkPaths.slice(0, 5).join("、")}——删除链接不伤目标）` : "";
			return {
				action: "block",
				reason: `git worktree remove 将丢弃 ${inspection.path} 内 ${inspection.dirtyPaths.length} 个未提交/未跟踪路径：${list}${more}${linkNote}。--force 不构成丢弃授权；请先把改动显式回流（git -C ${JSON.stringify(inspection.path)} diff 查看）或保全，确认可丢弃后再删除。干净工作树仍可正常删除（分支保留）。`,
			};
		}
	}
	return null;
}
