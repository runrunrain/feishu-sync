/**
 * guard-policy.ts — B4A/B4B（ev-20261012-af58eb 设计 §8 批A+批B）：护栏策略解释与判定消费层。
 *
 * 单一职责（设计 §5.1/§5.2 + 批A「行为缺省不变」铁律；批B 起 D5—D10 判定接线）：
 *  - 规则 ID 封闭注册表：D1—D11 的 rule ID + command.remoteExecution（值域只有 block/disclose，
 *    没有 off）；每条规则携带「当前执法」描述与内建默认值——批B 起 D5—D10、批C 起 D1—D3/D11
 *    默认 disclose（局部判断类：检测照常、阻断转披露；D1/D2/D11 前提=有界执行实测生效、D3
 *    前提=未闭合替换零执行实测，见 B4C 前置探针），其余维持 block 现状（D4 平台未验证、
 *    remoteExecution 表外未批）。
 *  - 来源投影：内建默认 → 受信全局 amagi.json → 受信项目 amagi.json → role 覆盖 → 旧 env 兼容
 *    覆盖（逐层后者胜）；非法/未知配置只产生诊断（到字段路径，不回显配置值——秘密不进入提示），
 *    该规则回落既有执法，绝不因配置问题回落 allow（设计 §5.2）。
 *  - 旧 env 归一：AMAGI_RG_REPLACE_BLOCK / AMAGI_SUBAGENT_FIND_BLOCK（bash-override.ts 既有
 *    逃生舱）逐字节镜像运行时语义（=0/off → disclose；其余明确值 → block）——投影与运行时
 *    实际行为恒一致，冲突在 explain 显示来源，不静默拼两套决策。
 *  - 受信配置读取/冻结：项目层仅经统一 trust 结果消费（projectTrusted===true；unknown/未受信
 *    不消费项目层——与 codemode-config F04 同口径）；freezeGuardPolicy 提供进程级冻结快照
 *    （含稳定 digest）；explain 每次现读（诊断工具语义）。
 *  - 批B 判定消费入口（guardRuleOf/guardRegexReplaceBytesLimitOf/guardProjectTrustedOf）：
 *    guards.ts（D5/D6 提交内容）、bash-override.ts（D10）、edit-guard.ts/edit-override.ts
 *    （D7/D8）、task-facets.ts（D9 正文 deny 扫描）经 freezeGuardPolicy 消费同一投影——
 *    运行中编辑配置不改变既有会话（首次解析冻结）；受信配置可把任一规则收紧回 block。
 *    修复轮 R02：trust 经 trust-context 统一回退链（会话捕获值兜底工具 ctx 缺失）；
 *    修复轮 R03：role 视角缺省读派发链注入的 AMAGI_AGENT（角色覆盖解释与消费同视角）。
 *
 * 边界（批C 起）：D4 powershell.executionPolicy（平台未验证）与 command.remoteExecution 维持
 * block（表外/未批）；不新增 env 逃生舱；L-不可逆防线（凭据/AMAGI_PROTECTED_PATHS/跨根/契约
 * 存储、敏感文件提交拦截、.git/ 禁入、deny 运行期硬拒、hard 危险段扫描）不在 rule 命名空间内、
 * 不受任何投影影响。配置解释不是授权证明。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { canonicalAgentId, CANONICAL_AGENT_IDS } from "./agent-aliases.ts";
import { resolveProjectTrusted } from "./trust-context.ts";

/** 规则值域：只有 block/disclose（设计 §5.1「没有 off」）。 */
export type GuardRuleValue = "block" | "disclose";

/** 规则 ID 封闭集（D1—D11 + command.remoteExecution；设计 §4/§5.1）。 */
export type GuardRuleId =
	| "command.interactive" // D1：交互命令族（含 PS 交互旗标）
	| "command.wait" // D2：长 sleep/循环/stdin 等待
	| "command.opaque" // D3：解析深度/不可安全展开
	| "powershell.executionPolicy" // D4：set-executionpolicy
	| "commit.largeFile" // D5：>10MB 提交
	| "commit.generatedPaths" // D6：node_modules/ 提交（.git/ 属不可逆底线不在本规则内）
	| "edit.headingDeletion" // D7：markdown 标题吞噬
	| "edit.regexSpan" // D8：regex 替换字节阈值
	| "task.assignmentDenyMention" // D9：任务书正文 deny 词法扫描
	| "bash.rgReplace" // D10：rg -r 粘连簇
	| "bash.wholeScan" // D11：子代理全盘 find
	| "command.remoteExecution"; // 远程下载即执行（默认 block；设计 §4 表外单列）

export interface GuardRuleMeta {
	/** 设计决议项编号（command.remoteExecution 为表外单列）。 */
	readonly design: string;
	/** 内建默认值（批B 起 D5—D10=disclose；缺省 block=现状执法）。非法配置回落本值，不回落 allow。 */
	readonly default?: GuardRuleValue;
	/** 当前执法事实（explain 逐条展示；与判定消费者实际行为同源）。 */
	readonly enforcement: string;
	/** 既有 env 逃生舱（运行时仍直接读取该 env——投影逐字节镜像其语义）。 */
	readonly envExit?: string;
}

/** 规则注册表（封闭；顺序即 explain 展示顺序）。 */
export const GUARD_RULES: Readonly<Record<GuardRuleId, GuardRuleMeta>> = Object.freeze({
	"command.interactive": { design: "D1", default: "disclose", enforcement: "交互命令族（编辑器/分页器/TUI/REPL 裸启动/-i/ssh 无 BatchMode/crontab -e/PS 交互旗标）默认放行+披露（实际时限/非交互替代）；前提=有有限兑底（显式 timeout 或子代理默认超时），无界调用保持 block；powershell 工具通道（仅 Windows，平台未验证）保持 block。B4C 前置实测：vi 无 TTY 真实挂起但被有限 timeout 3s 收口、read -p/裸 python 无 stdin 立即 EOF" },
	"command.wait": { design: "D2", default: "disclose", enforcement: "长等待形态（sleep≥1000、while true/for(;;)、read -p/raw_input、python -c 内 input/while True）默认放行+披露（拆批/run_bg/有界退出条件建议）；前提=有有限兑底，无界调用保持 block。B4C 前置实测：sleep 15+timeout 2 真实 2.2s 收口、abort 692ms 可取消" },
	"command.opaque": { design: "D3", default: "disclose", enforcement: "无法安全展开（嵌套展开>4 层、不可安全展开的双引号反引号替换无已知危险）默认放行+披露；已识别不可逆段（remoteExecution/终止进程/递归删除根/eval 远程载荷）不因解析失败放行——不可安全展开 payload 原文照常扫描。未闭合替换（UNCLOSED_*）恒 block：真实 bash 报语法错误零成功执行，放行收益≈0，而该子翻转连续四轮被构造出 Critical 凭据底线绕过（B4C 修复轮四 Leader 裁定收回——含解析错误的命令按 fail-safe 保守阻止）" },
	"powershell.executionPolicy": { design: "D4", enforcement: "set-executionpolicy 硬阻断（可持久影响主机安全配置，scope 取决于参数）。B4·批C：本机无 PowerShell 平台，行为未实测，维持 block 不翻转（规则 ID 已接入披露文案；平台验证后另行裁定）" },
	"commit.largeFile": { design: "D5", default: "disclose", enforcement: ">10MB 文件提交默认放行+成功结果首部披露（列路径与字节数；凭据检查照常执行，不自动回退 index；受信配置可收紧回 block）" },
	"commit.generatedPaths": { design: "D6", default: "disclose", enforcement: "node_modules/ 提交默认放行+披露（列路径；.git/ 属不可逆底线恒拒，敏感内容不受本开关控制）" },
	"edit.headingDeletion": { design: "D7", default: "disclose", enforcement: "markdown 标题删除默认放行+结果披露（含行范围；diff 提供反向恢复路径；受信配置可收紧回 block）" },
	"edit.regexSpan": { design: "D8", default: "disclose", enforcement: "regex 总替换超阈值（guards.limits.regexReplaceBytes，缺省 102400）默认放行+披露（字节数/行范围；唯一非零匹配与权限校验契约不变）" },
	"task.assignmentDenyMention": { design: "D9", default: "disclose", enforcement: "任务书正文 deny 路径提及默认放行提交+提示（补 inputs 声明提示；结构化 inputs/outputs 落 deny 仍整任务拒单，运行期 deny 不放松）" },
	"bash.rgReplace": { design: "D10", default: "disclose", enforcement: "rg 无参旗标粘连簇自动改写（block/disclose 均先去掉 -r）后执行+首行说明；合法粘连替换文本 -rfoo、显式 -r <替换串>/--replace 不改；无法安全改写的命中形态由本规则 block/disclose 兜底", envExit: "AMAGI_RG_REPLACE_BLOCK=0/off → disclose；肯定值 → block" },
	"bash.wholeScan": { design: "D11", default: "disclose", enforcement: "子代理无超时兑底的全盘 find 默认放行+披露（实际时限/限定目录建议；Leader 侧为软提示）；前提=子代理默认超时实测生效（AMAGI_SUBAGENT_BASH_TIMEOUT 缺省 600s 注入真实收口）", envExit: "AMAGI_SUBAGENT_FIND_BLOCK=0/off → 关闭；肯定值 → block" },
	"command.remoteExecution": { design: "表外", enforcement: "远程下载即执行硬阻断（curl|sh、eval/$() 下载载荷、PS iex 远程内容）" },
});

export const GUARD_RULE_IDS: readonly GuardRuleId[] = Object.keys(GUARD_RULES) as GuardRuleId[];

/** 规则值来源（优先级从低到高：builtin-default → global-config → project-config → role-override → env-override）。 */
export type GuardRuleSourceKind = "builtin-default" | "global-config" | "project-config" | "role-override" | "env-override";

export interface GuardRuleResolution {
	readonly value: GuardRuleValue;
	readonly source: GuardRuleSourceKind;
	/** 来源说明（explain 展示；含 env 归一与覆盖链事实；不含任何配置正文）。 */
	readonly sourceLabel: string;
}

export interface GuardLimitResolution {
	readonly value: number;
	readonly source: "builtin-default" | "global-config" | "project-config";
	readonly sourceLabel: string;
}

export interface GuardPolicySnapshot {
	/** 全部规则的投影值与来源（封闭集全覆盖）。 */
	readonly rules: Readonly<Record<GuardRuleId, GuardRuleResolution>>;
	readonly limits: Readonly<{ regexReplaceBytes: GuardLimitResolution }>;
	/** 配置诊断（到字段路径；不回显配置值；含 env 覆盖冲突说明）。 */
	readonly diagnostics: readonly string[];
	/** 有效值稳定摘要（冻结/交付比对用；sha256 前 16 hex）。 */
	readonly digest: string;
	/** 解析时的 role 视角（null=基础投影）。 */
	readonly role: string | null;
}

/** 旧 env 归一读取点（字面访问——env-knobs 对账可 grep；语义逐字节镜像 bash-override.ts
 *  rgReplaceBlockEnabled/subagentFindScanBlockEnabled：=0/off → disclose，其余明确值 → block）。 */
function readEnvCompatRaw(id: GuardRuleId, env: NodeJS.ProcessEnv): string | undefined {
	if (id === "bash.rgReplace") return env.AMAGI_RG_REPLACE_BLOCK;
	if (id === "bash.wholeScan") return env.AMAGI_SUBAGENT_FIND_BLOCK;
	return undefined;
}

/** 归一映射的 env 展示名（诊断/来源标签用）。 */
function envNameOfCompatRule(id: GuardRuleId): string {
	return id === "bash.rgReplace" ? "AMAGI_RG_REPLACE_BLOCK" : id === "bash.wholeScan" ? "AMAGI_SUBAGENT_FIND_BLOCK" : String(id);
}

/** 判定消息的规则标签（信号层：消费方在 block/警示文案中引用，判定本身不变）。 */
export function guardRuleTag(ruleId: GuardRuleId): string {
	return `[AMAGI 守卫·${ruleId}]`;
}

// ── 受信配置读取（字段封闭；诊断不回显配置值——秘密不进入提示） ────────────────

type SectionRead = { kind: "absent" } | { kind: "invalid" } | { kind: "ok"; section: Record<string, unknown> };

function readGuardsSection(file: string, label: string, diagnostics: string[]): SectionRead {
	let raw: string;
	try {
		raw = fs.readFileSync(file, "utf8");
	} catch {
		return { kind: "absent" }; /* lint-exempt:文件不存在为正常（KB 级逐次现读，无缓存热点） */
	}
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch {
		// B4A-R02：固定错误分类，不回显原始解析错误（其 message 可携带文件正文片段/敏感原文）。
		diagnostics.push(`guards 配置读取失败（${label} ${file}）：JSON 解析失败（语法错误，不回显原文）——该层不消费`);
		return { kind: "invalid" };
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
		diagnostics.push(`guards 配置非法（${label} ${file}）：根必须是对象——该层不消费`);
		return { kind: "invalid" };
	}
	const section = (parsed as Record<string, unknown>).guards;
	if (section === undefined) return { kind: "absent" };
	if (section === null || typeof section !== "object" || Array.isArray(section)) {
		diagnostics.push(`guards 配置非法（${label} ${file}）：guards 节必须是对象（rules/roles/limits）——该层不消费`);
		return { kind: "invalid" };
	}
	return { kind: "ok", section: section as Record<string, unknown> };
}

const RULE_VALUE_SET = new Set<GuardRuleValue>(["block", "disclose"]);
const LEGAL_RULE_KEYS = GUARD_RULE_IDS.join(" / ");

/** B4A-R02 输出边界：诊断回显键名的有界清洗——凭据形态/高熵长串/超长/控制字符一律不回显
 *  （不能依赖末端 redactCredentials 兑底：其模式集有限，孤立 ghp_ 等形态不覆盖）。 */
function safeKeyEcho(key: string): string {
	if (
		key.length > 64
		|| /[\x00-\x1f\x7f]/.test(key)
		|| /(?:sk-[A-Za-z0-9_-]{8,}|ghp_[A-Za-z0-9]{8,}|github_pat_[A-Za-z0-9_]{8,}|AKIA[0-9A-Z]{8,}|xox[baprs]-[A-Za-z0-9-]{8,}|-----BEGIN|Bearer\s)/i.test(key)
		|| /^[A-Za-z0-9_\-=+/]{32,}$/.test(key)
	) return `非法键名（不回显）`;
	return `"${key}"`;
}

/** 单层 rules 对象校验：字段封闭 + 值域；非法项记诊断并忽略（不回显值）。 */
function parseRulesObject(raw: unknown, fieldPath: string, diagnostics: string[], out: Map<GuardRuleId, GuardRuleValue>): void {
	if (raw === undefined) return;
	if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
		diagnostics.push(`guards.${fieldPath} 非法：必须是对象（rule ID → block/disclose）——已忽略`);
		return;
	}
	for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
		const id = key as GuardRuleId;
		if (!(id in GUARD_RULES)) {
			diagnostics.push(`guards.${fieldPath}[${safeKeyEcho(key)}] 未知规则键（合法：${LEGAL_RULE_KEYS}）——已忽略，该键不产生任何效果`);
			continue;
		}
		if (!RULE_VALUE_SET.has(value as GuardRuleValue)) {
			diagnostics.push(`guards.${fieldPath}.${key} 值非法（只认 block/disclose）——已忽略，该规则维持既有执法`);
			continue;
		}
		out.set(id, value as GuardRuleValue);
	}
}

/** 单层 roles 校验：canonical 名册（旧 stem 归一）+ 内层 rules 同域；非法记诊断并忽略。 */
function parseRolesSection(raw: unknown, label: string, diagnostics: string[], out: Map<string, Map<GuardRuleId, GuardRuleValue>>): void {
	if (raw === undefined) return;
	if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
		diagnostics.push(`guards.roles 非法（${label}）：必须是对象（canonical 角色名 → { rules }）——已忽略`);
		return;
	}
	for (const [rawKey, rawValue] of Object.entries(raw as Record<string, unknown>)) {
		const subject = canonicalAgentId(rawKey);
		if (!(CANONICAL_AGENT_IDS as readonly string[]).includes(subject)) {
			diagnostics.push(`guards.roles[${safeKeyEcho(rawKey)}]（${label}）未知角色（合法：${CANONICAL_AGENT_IDS.join("/")}；旧 stem 名自动归一）——已忽略`);
			continue;
		}
		if (rawValue === null || typeof rawValue !== "object" || Array.isArray(rawValue)) {
			diagnostics.push(`guards.roles.${subject}（${label}）非法：必须是对象（{ rules }）——已忽略`);
			continue;
		}
		const inner = (rawValue as Record<string, unknown>).rules;
		const layer = new Map<GuardRuleId, GuardRuleValue>();
		parseRulesObject(inner, `roles.${subject}.rules（${label}）`, diagnostics, layer);
		if (layer.size > 0) out.set(subject, layer);
	}
}

export interface ResolveGuardPolicyOptions {
	/** 工作目录（项目 amagi.json 发现基准）。 */
	cwd: string;
	/** env 来源（缺省 process.env；测试注入）。 */
	env?: NodeJS.ProcessEnv;
	/** 角色视角（canonical/旧 stem 归一；null/缺省=基础投影不套用 role 覆盖）。 */
	role?: string | null;
	/** 路径注入（测试隔离）。 */
	paths?: { globalConfigPath?: string; projectConfigPath?: string };
	/** 统一 trust 结果（缺席=unknown：项目层不消费——与 codemode-config F04 同口径）。 */
	projectTrusted?: boolean;
}

/**
 * 解析护栏策略投影（纯读；每次现读——explain 语义）。判定不消费返回值（批A 解释层）；
 * 冻结交付用 freezeGuardPolicy。任何非法配置只降为「该规则维持既有执法」，不产生 allow。
 */
export function resolveGuardPolicy(opts: ResolveGuardPolicyOptions): GuardPolicySnapshot {
	const env = opts.env ?? process.env;
	const diagnostics: string[] = [];
	const globalFile = opts.paths?.globalConfigPath ?? path.join(env.PI_CODING_AGENT_DIR ?? path.join(String(env.HOME ?? ""), ".pi", "agent"), "amagi.json");
	const projectFile = opts.paths?.projectConfigPath ?? path.join(opts.cwd, "amagi.json");
	const globalRead = readGuardsSection(globalFile, "全局", diagnostics);
	const projectRead = readGuardsSection(projectFile, "项目", diagnostics);

	let projectSection: Record<string, unknown> | undefined;
	if (projectRead.kind === "ok") {
		if (opts.projectTrusted === true) {
			projectSection = projectRead.section;
		} else {
			diagnostics.push(`项目未受信（projectTrusted=${String(opts.projectTrusted ?? "unknown")}）：guards 项目层不消费（未知 trust 不接受项目放宽）——仅全局层与 env 归一生效`);
		}
	}
	const globalSection = globalRead.kind === "ok" ? globalRead.section : undefined;
	for (const section of [globalSection, projectSection]) {
		if (section === undefined) continue;
		for (const key of Object.keys(section)) {
			if (!["rules", "roles", "limits"].includes(key)) {
				diagnostics.push(`guards 节未知键 ${safeKeyEcho(key)}：字段封闭（rules/roles/limits）——已忽略`);
			}
		}
	}

	// 逐层收集（低→高：全局 → 项目 → role 全局 → role 项目）。
	const globalRules = new Map<GuardRuleId, GuardRuleValue>();
	const projectRules = new Map<GuardRuleId, GuardRuleValue>();
	const globalRoles = new Map<string, Map<GuardRuleId, GuardRuleValue>>();
	const projectRoles = new Map<string, Map<GuardRuleId, GuardRuleValue>>();
	if (globalSection !== undefined) {
		parseRulesObject(globalSection.rules, "rules（全局）", diagnostics, globalRules);
		parseRolesSection(globalSection.roles, "全局", diagnostics, globalRoles);
	}
	if (projectSection !== undefined) {
		parseRulesObject(projectSection.rules, "rules（项目）", diagnostics, projectRules);
		parseRolesSection(projectSection.roles, "项目", diagnostics, projectRoles);
	}

	const role = opts.role ? canonicalAgentId(opts.role) : null;
	const roleIsCanonical = role !== null && (CANONICAL_AGENT_IDS as readonly string[]).includes(role);

	// limits：内建默认 → 全局 → 项目（无 env/role 面）。
	let limits: GuardLimitResolution = { value: 102400, source: "builtin-default", sourceLabel: "内建缺省（B4·批B 起 edit.regexSpan 消费本值）" };
	for (const [section, label, kind] of [[globalSection, "全局", "global-config"], [projectSection, "项目", "project-config"]] as const) {
		if (section === undefined || section.limits === undefined) continue;
		if (section.limits === null || typeof section.limits !== "object" || Array.isArray(section.limits)) {
			diagnostics.push(`guards.limits 非法（${label}）：必须是对象（regexReplaceBytes）——已忽略`);
			continue;
		}
		for (const key of Object.keys(section.limits as Record<string, unknown>)) {
			if (key !== "regexReplaceBytes") diagnostics.push(`guards.limits 未知键 ${safeKeyEcho(key)}（${label}）：字段封闭——已忽略`);
		}
		const rawLimit = (section.limits as Record<string, unknown>).regexReplaceBytes;
		if (rawLimit === undefined) continue;
		if (typeof rawLimit !== "number" || !Number.isSafeInteger(rawLimit) || rawLimit < 1024 || rawLimit > 10485760) {
			diagnostics.push(`guards.limits.regexReplaceBytes（${label}）非法：须为 safe integer 且在 1024—10485760 内——已忽略，维持当前值`);
			continue;
		}
		limits = { value: rawLimit, source: kind, sourceLabel: `${label} amagi.json guards.limits` };
	}

	// 逐规则合成（env 归一最后覆盖；冲突记诊断说明）。批C 起内建 disclose 的规则集（D1—D3/D11）。
	const batchCRules = new Set<GuardRuleId>(["command.interactive", "command.wait", "command.opaque", "bash.wholeScan"]);
	const rules = {} as Record<GuardRuleId, GuardRuleResolution>;
	for (const id of GUARD_RULE_IDS) {
		// 批B：内建默认经注册表（D5—D10=disclose，其余=block）；非法配置只回落本值，不回落 allow。
		const builtin = GUARD_RULES[id].default ?? "block";
		// 批C：sourceLabel 按规则归属批次生成（D1—D3/D11=批C，D5—D10=批B）——与发布默认表同源。
		const discloseBatch = batchCRules.has(id) ? "B4·批C" : "B4·批B";
		let res: GuardRuleResolution = { value: builtin, source: "builtin-default", sourceLabel: builtin === "disclose" ? `内建缺省（${discloseBatch} 起默认 disclose；受信配置可收紧回 block）` : "内建缺省（现状执法）" };
		if (globalRules.has(id)) res = { value: globalRules.get(id)!, source: "global-config", sourceLabel: "全局 amagi.json guards.rules" };
		if (projectRules.has(id)) res = { value: projectRules.get(id)!, source: "project-config", sourceLabel: "项目 amagi.json guards.rules" };
		if (roleIsCanonical) {
			// B4A-R01：角色覆盖按 rule 逐字段合成（全局角色层→项目角色层），每条 rule 保留真实层来源；
			// 不得整张 Map 二选一（同角色跨层不同字段会丢失另一层 role 值）。
			const globalRoleLayer = globalRoles.get(role);
			if (globalRoleLayer?.has(id)) {
				res = { value: globalRoleLayer.get(id)!, source: "role-override", sourceLabel: `role 覆盖 guards.roles.${role}.rules（全局）` };
			}
			const projectRoleLayer = projectRoles.get(role);
			if (projectRoleLayer?.has(id)) {
				res = { value: projectRoleLayer.get(id)!, source: "role-override", sourceLabel: `role 覆盖 guards.roles.${role}.rules（项目）` };
			}
		}
		const raw = readEnvCompatRaw(id, env);
		if (raw !== undefined) {
			const envValue: GuardRuleValue = raw === "0" || raw.toLowerCase() === "off" ? "disclose" : "block";
			if (res.source !== "builtin-default" && res.value !== envValue) {
				diagnostics.push(`guards.rules.${id} 来源冲突：env ${envNameOfCompatRule(id)}（归一=${envValue}）覆盖了 ${res.sourceLabel} 的 ${res.value}——按旧 env 优先执行，冲突在此披露`);
			}
			// B4A-R02：sourceLabel 只展示 env 名+归一结果+封闭控制值；非标准值一律不回显原文。
			const valueDisplay = raw === "0" ? "=0" : raw.toLowerCase() === "off" ? "=off" : "=非标准值（不回显）";
			res = { value: envValue, source: "env-override", sourceLabel: `env ${envNameOfCompatRule(id)}${valueDisplay}（旧 env 归一${envValue === "disclose" ? "——现有逃生舱" : "，肯定值映射 block"}；运行时同源读取）` };
		}
		rules[id] = res;
	}

	const digestInput = JSON.stringify({ role, rules: Object.fromEntries(GUARD_RULE_IDS.map((id) => [id, rules[id].value])), limits: limits.value });
	const digest = createHash("sha256").update(digestInput).digest("hex").slice(0, 16);
	return { rules, limits: { regexReplaceBytes: limits }, diagnostics, digest, role: roleIsCanonical ? role : null };
}

// ── 冻结（派发/会话级快照；批A 仅基建，判定消费者属批B/C） ──────────────────────

// B4A-R03：按 freezeKey（cwd/role/projectTrusted/paths 四元组）持有各自快照，互不驱逐
//（A→B→A 不重新解析、值不漂移）；返回对象运行时深冻结（嵌套改写在严格模式抛 TypeError，
// 不污染缓存）。生命周期：进程级 Map——同参复用即同参快照；新参（新 cwd/角色/trust/paths）
// 重新解析；reset 清空全部（测试注入；生产无消费者，key 集合天然有界）。派发/JSON/RPC
// 冻结交付属批B/C（设计 §5.2：重启/新派发生效，运行中编辑配置不改变既有任务）。
const frozenCache = new Map<string, GuardPolicySnapshot>();

function freezeKeyOf(opts: ResolveGuardPolicyOptions): string {
	return JSON.stringify([opts.cwd, opts.role ?? null, opts.projectTrusted ?? null, opts.paths ?? null]);
}

/** 运行时深冻结：rules/每条 resolution/limits/diagnostics 全部不可变。 */
function deepFreezeSnapshot(snap: GuardPolicySnapshot): GuardPolicySnapshot {
	for (const id of GUARD_RULE_IDS) Object.freeze(snap.rules[id]);
	Object.freeze(snap.rules);
	Object.freeze(snap.limits.regexReplaceBytes);
	Object.freeze(snap.limits);
	Object.freeze(snap.diagnostics);
	return Object.freeze(snap);
}

/** 进程级冻结：同参返回同一不可变快照（Map 按 key 持有，不驱逐其它参数的活动快照）。 */
export function freezeGuardPolicy(opts: ResolveGuardPolicyOptions): GuardPolicySnapshot {
	const key = freezeKeyOf(opts);
	let snap = frozenCache.get(key);
	if (snap === undefined) {
		snap = deepFreezeSnapshot(resolveGuardPolicy(opts));
		frozenCache.set(key, snap);
	}
	return snap;
}

/** 测试注入：清除全部冻结快照（生产无消费者，无需调用）。 */
export function resetFrozenGuardPolicyForTests(): void {
	frozenCache.clear();
}

// ── B4·批B 判定消费入口（设计 §8 批B：D5—D10 rule 值驱动判定；与 explain 投影同源冻结）──

/** B4B 修复轮 R02：判定消费的统一 trust 解析——复用 trust-context 会话回退链
 *  （setTrustFallback：index.ts 于 session_start 捕获会话信任态注入；工具 execute ctx
 *  不携带 isProjectTrusted 时回退会话捕获值，不丢弃已确认的受信会话）。ctx 形态不确定
 *  （事件链/工具 execute 各异）——异常/缺失回 false（fail-closed，不猜）。
 *  返回 boolean（项目层消费口径：true=消费；false/未捕获=不消费）。 */
export function guardProjectTrustedOf(ctx: unknown): boolean {
	try {
		return resolveProjectTrusted(ctx as { isProjectTrusted?: () => boolean } | undefined);
	} catch { /* lint-exempt:ctx 形态异常回 fail-closed（不猜信任） */ }
	return false;
}

/** B4B 修复轮 R03：判定消费的角色视角缺省——子代理进程由派发链注入 AMAGI_AGENT（task-run
 *  buildMinimalEnv：env.AMAGI_AGENT=角色名；JSON/RPC 子进程同链），Leader 会话无角色=基础投影。
 *  角色只来自受信派发链注入的 env/显式参数，不从模型文本推导。 */
function guardRoleDefault(role: string | undefined): string | null {
	return role ?? process.env.AMAGI_AGENT ?? null;
}

/** 判定消费：rule 有效值。freezeGuardPolicy 进程级冻结（同 cwd/role/trust 首次解析后固定——
 *  运行中编辑配置不改变既有会话；与 /amagi config explain 投影同源，env 归一在投影内完成）。
 *  消费方：guards.ts（D5/D6 + 批C 起 D1/D2/D3 事件链分流）、bash-override.ts（D10 + 批C 起 D11）、
 *  edit-guard.ts/edit-override.ts（D7/D8）、task-facets.ts（D9）。L-不可逆防线不经本入口（无
 *  rule 命名空间）。
 *  B4B 修复轮 R03：role 缺省读派发链注入的 AMAGI_AGENT——角色覆盖（guards.roles.<role>）在
 *  解释面与判定消费同一角色视角（task-facets 等持角色名者显式传入；旧 stem 名经 canonicalAgentId 归一）。 */
export function guardRuleOf(id: GuardRuleId, cwd: string, projectTrusted?: boolean, role?: string): GuardRuleValue {
	return freezeGuardPolicy({ cwd, projectTrusted, role: guardRoleDefault(role) }).rules[id].value;
}

/** 判定消费：regexReplaceBytes 有效阈值（edit.regexSpan；同源冻结；safe integer 1024—10485760）。 */
export function guardRegexReplaceBytesLimitOf(cwd: string, projectTrusted?: boolean, role?: string): number {
	return freezeGuardPolicy({ cwd, projectTrusted, role: guardRoleDefault(role) }).limits.regexReplaceBytes.value;
}

/** explain 投影（不回显任何配置正文/凭据；逐条给「当前执法」对照——批A 判定与现状一致）。 */
export function summarizeGuardPolicy(snapshot: GuardPolicySnapshot, roleSnapshots: readonly GuardPolicySnapshot[] = []): string {
	const lines = ["guards 规则投影（解释+判定消费层）：B4·批B 起 D5—D10、批C 起 D1—D3/D11 判定已接线（检测照常，阻断按 rule 值转披露；L-不可逆防线不受任何 rule 影响）；D4 powershell.executionPolicy（平台未验证）与 command.remoteExecution 维持 block 现状（表外未批）；带 env 逃生舱的规则照常按 env 生效（运行时与投影同源）；配置解释不是授权证明。"];
	for (const id of GUARD_RULE_IDS) {
		const r = snapshot.rules[id];
		const meta = GUARD_RULES[id];
		lines.push(`  ${id}=${r.value} ←${r.sourceLabel} · ${meta.design} · 执法：${meta.enforcement}${meta.envExit ? ` · 逃生舱：${meta.envExit}` : ""}`);
	}
	lines.push(`  limits.regexReplaceBytes=${snapshot.limits.regexReplaceBytes.value} ←${snapshot.limits.regexReplaceBytes.sourceLabel}`);
	for (const roleView of roleSnapshots) {
		if (roleView.role === null) continue;
		const diffs = GUARD_RULE_IDS.filter((id) => roleView.rules[id].value !== snapshot.rules[id].value || roleView.rules[id].source !== snapshot.rules[id].source);
		if (diffs.length === 0) continue;
		lines.push(`  role 视角 ${roleView.role}（digest ${roleView.digest}）：${diffs.map((id) => `${id}=${roleView.rules[id].value} ←${roleView.rules[id].sourceLabel}`).join("；")}`);
	}
	if (snapshot.diagnostics.length > 0) lines.push(`  诊断：${snapshot.diagnostics.join("；")}`);
	return lines.join("\n");
}
