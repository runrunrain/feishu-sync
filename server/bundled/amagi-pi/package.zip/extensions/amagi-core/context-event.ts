/**
 * context-event.ts — T2-4 上下文自动供给与剪枝（§9.2 信息流转循环）。
 *
 * dist 证据：ContextEvent { type:"context"; messages: AgentMessage[] }（types.d.ts:489）；
 *   ContextEventResult { messages?: AgentMessage[] }（types.d.ts:764）—— 可整体改写 messages；
 *   pi.on("context", handler)（types.d.ts:855）—— 每 provider 请求前触发。
 *
 * 三支柱（§9.2）：
 *   a) 关键词匹配注入：用户输入关键词 → 相关 L1 资源片段（resources/core 按 ID 读取，优先级排序）
 *   b) 采集降噪：仅缩减已归档且有生产者范围证明的自动采集片段
 *   c) token 预算自适应：注入总量有上限（默认 8KB/可配），超预算按优先级截断
 *
 * v2.21.8 缓存稳定：注入粘性化（M1 修复）——注入只存在于请求投影，历史中的 user 消息仍是原文；
 * 每轮 context 事件以字节冻结的注入后缀重放到已注入消息上，不随占用率/预算/后续消息重算，
 * 提示缓存前缀不再因注入锚点转移被历史中段改写打断。
 *
 * 显式工具输出、指南、规则和任务正文完整保留；会话压缩由 pi 原生处理。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { archivedCollectionDetails, COLLECTION_DETAILS_KEY, TASK_COMPLETION_TYPE, pruneArchivedCollectionText } from "./evidence-context.ts";
const OWNED_TASK_TOOLS = new Set(["task", "task_submit", "task_resume", "task_control", "task_batch", "rpc_task"]);

// ─────────────────────────────────────────────────────────────────────────────
// 配置（动态读 env 便于测试）
// ─────────────────────────────────────────────────────────────────────────────

/** 关键词 → 资源 ID 映射（简明可测，按 priority 排序注入）。 */
interface KeywordRule {
	re: RegExp;
	resourceId: string;
	priority: number;
}
const KEYWORD_MAP: KeywordRule[] = [
	// ev-20261011-01baab：不再用裸词 task 触发 workflow——编排会话几乎每条消息（含所有 task_* 工具完成通知）
	// 都含该词，导致近乎常开的 2–4.5KB 注入且 selectSections 常选到离题小节（实测 replay："调用 task_submit
	// 提交任务书"命中的是跨边界链路/专家调用预算）。工具名触发由下方 tools-facets 规则精确覆盖；
	// workflow 自身名称是强意图信号，保留。
	{ re: /派发|分派|子\s*agent|subagent|编排|fanout|pipeline|tournament|workflow/i, resourceId: "workflow", priority: 1 },
	// v2.2 W2: 任务工具分面与误用形态（accept 缺 receiptId/expectedRevision、stale 回执、resume 句柄等）→ tools-facets
	// v2.8.8: steer/运行中调整语义（steer-rejected、注入送达语义）同引 tools-facets
	{ re: /task_submit|task_resume|task_control|task_query|task_batch|receiptId|expectedRevision|waivedCheckIds|stale-receipt|stale-revision|unknown-handle|ambiguous-handle|no-contract-view|no-receipt|steer|运行中调整/i, resourceId: "tools-facets", priority: 1 },
	// v2.2 W2: legacy task 工具旧语法与编排误用（task({...}) 旧语法、query_task、exportPrompt 等）→ tools-legacy
	{ re: /task\s*\(\s*\{|query_task|exportPrompt|workspaceNeeds|asyncGroup|sharedTree/i, resourceId: "tools-legacy", priority: 1 },
	// v1.5.190 凭证面（实战缺口：auth.json 合并改动全程无安全引导）——优先级与安全同级提前
	{ re: /auth\.json|credentials?|secrets?|api[\s_-]?key|access[\s_-]?token|refresh[\s_-]?token|私钥|凭证|凭据|密钥/i, resourceId: "credential-safety", priority: 2 },
	// 普通“检查/review”不是质量审核请求；明确审核意图仍可正常供给。
	{ re: /审核|代码审查|质量(?:标准|要求|门禁)|code\s+review|quality\s+(?:review|gate|standards?)|diting|major|minor/i, resourceId: "quality", priority: 2 },
	{ re: /角色|baize|luban|luoshen|diting|fuxi|路由|确认性|分档/i, resourceId: "agents", priority: 3 },
	{ re: /底线|安全|baseline|守卫|凭据/i, resourceId: "baseline", priority: 4 },
	{ re: /技能|skill|工具用法|tool/i, resourceId: "tools", priority: 5 },
];

// P3-D 冻结：以下 5 个重注入预算参数原为 env 调参开关，审计无任何非测试代码消费差异化值，冻结为常量。
// 如需恢复 env 读取请回看 git 历史（P3-D 前版本）。
/** P3-D 冻结自 AMAGI_CONTEXT_BUDGET（默认 8192）。 */
const MAX_INJECT_BYTES = 8192;
/** P3-D 冻结自 AMAGI_STALE_TOOL_TURNS（默认 5）。 */
const STALE_TOOL_TURNS = 5;
/** P3-D 冻结自 AMAGI_TOOL_OUTPUT_MAX（默认 4096）。 */
const TOOL_OUTPUT_MAX = 4096;

function getMaxInjectBytes(): number {
	return MAX_INJECT_BYTES;
}
function getStaleThreshold(): number {
	return STALE_TOOL_TURNS;
}
function getToolOutputMax(): number {
	return TOOL_OUTPUT_MAX;
}

// ─────────────────────────────────────────────────────────────────────────────
// a) 关键词匹配 → 资源 ID
// ─────────────────────────────────────────────────────────────────────────────

/** 匹配文本关键词 → 资源 ID 列表（按优先级排序，去重）。纯函数，可测。 */
export function matchResources(text: string): string[] {
	if (!text) return [];
	const hits: Array<{ id: string; priority: number }> = [];
	for (const { re, resourceId, priority } of KEYWORD_MAP) {
		if (re.test(text)) hits.push({ id: resourceId, priority });
	}
	return hits.sort((a, b) => a.priority - b.priority).map((h) => h.id);
}

/** 读资源文件片段（前 N 字节），沙箱在 resources/core 内（复用 index.json 索引）。 */
export function loadSnippet(resourceId: string, packageRoot: string, maxBytes = 2048): string {
	try {
		const indexPath = path.join(packageRoot, "resources", "core", "index.json");
		const index = JSON.parse(fs.readFileSync(indexPath, "utf8"));
		const mod = (index.modules || []).find((m: any) => m.id === resourceId);
		if (!mod) return "";
		const filePath = path.join(packageRoot, "resources", "core", mod.path);
		const realFile = fs.realpathSync(filePath);
		const realCore = fs.realpathSync(path.join(packageRoot, "resources", "core"));
		if (!realFile.startsWith(realCore)) return ""; // 沙箱防 traversal
		const full = fs.readFileSync(filePath, "utf8");
		const buf = Buffer.from(full);
		if (buf.length <= maxBytes) return full;
		let cut = Math.max(0, Math.floor(maxBytes));
		while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--;
		return buf.subarray(0, cut).toString("utf8");
	} catch {
		return "";
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// E5: 片段级索引（section 级而非文件级）+ top-K 截断 + 命中理由（迭代期望 F5）
// ─────────────────────────────────────────────────────────────────────────────

/** 每资源 top-K 小节数。P3-D 冻结自 AMAGI_SNIPPET_TOP_K（默认 2）。 */
const SNIPPET_TOP_K = 2;
/** 单片段字节预算（注入总量预算仍由 MAX_INJECT_BYTES 控制）。P3-D 冻结自 AMAGI_SNIPPET_BYTES（默认 2048）。 */
const SNIPPET_BYTES = 2048;

function getSnippetTopK(): number {
	return SNIPPET_TOP_K;
}
function getSnippetBytes(): number {
	return SNIPPET_BYTES;
}

/** 匹配文本关键词 → 资源 ID + 命中关键词（供注入附命中理由一行）。 */
export function matchResourcesWithReasons(text: string): Array<{ id: string; priority: number; keyword: string }> {
	if (!text) return [];
	const hits: Array<{ id: string; priority: number; keyword: string }> = [];
	for (const { re, resourceId, priority } of KEYWORD_MAP) {
		const m = re.exec(text);
		if (m) hits.push({ id: resourceId, priority, keyword: m[0] });
	}
	return hits.sort((a, b) => a.priority - b.priority);
}

export interface ResourceSection { title: string; body: string; }

/** markdown 按标题切节；首个标题前的内容归为 "(前言)" 节。纯函数，可测。 */
export function splitSections(content: string): ResourceSection[] {
	if (!content) return [];
	const sections: ResourceSection[] = [];
	let cur: ResourceSection | null = null;
	for (const line of content.split("\n")) {
		const hm = /^(#{1,4})\s+(.+?)\s*$/.exec(line);
		if (hm) {
			if (cur) sections.push(cur);
			cur = { title: hm[2].replace(/\s*#+$/, "").trim(), body: "" };
		} else if (cur) {
			cur.body += line + "\n";
		} else if (line.trim()) {
			cur = { title: "(前言)", body: line + "\n" };
		}
	}
	if (cur) sections.push(cur);
	return sections;
}

/** query 词元化：latin 词 + CJK 二元组（简明可测，不引外部分词）。 */
function tokenize(text: string): string[] {
	const tokens = new Set<string>();
	for (const t of text.toLowerCase().match(/[a-z0-9_+.\-]{2,}/g) || []) tokens.add(t);
	for (const seg of text.match(/[\u4e00-\u9fff]{2,}/g) || []) {
		for (let i = 0; i < seg.length - 1; i++) tokens.add(seg.slice(i, i + 2));
	}
	return [...tokens];
}

/** 小节相关度评分（标题命中 ×3 / 正文命中 ×1），返回 top-K；无相关小节 → 空。纯函数，可测。 */
export function selectSections(content: string, query: string, topK = 2): ResourceSection[] {
	const sections = splitSections(content);
	if (sections.length === 0) return [];
	if (!query.trim()) return sections.slice(0, Math.max(1, topK));
	const qTokens = tokenize(query);
	const scored = sections.map((s) => {
		const titleLow = s.title.toLowerCase();
		const bodyTokens = new Set(tokenize(s.body));
		let score = 0;
		for (const t of qTokens) {
			if (titleLow.includes(t)) score += 3;
			else if (bodyTokens.has(t)) score += 1;
		}
		return { s, score };
	}).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
	return scored.slice(0, Math.max(1, topK)).map((x) => x.s);
}

/**
 * E5: 片段级读取——section 级索引 + top-K 截断 + 单片段字节预算 + 命中理由。
 * 无相关小节时回退文件首部（保持召回）；资源不可读 → null。
 */
export function loadSnippetForQuery(
	resourceId: string,
	packageRoot: string,
	query: string,
	maxBytes = getSnippetBytes(),
): { snippet: string; reason: string } | null {
	const full = loadSnippet(resourceId, packageRoot, Number.MAX_SAFE_INTEGER);
	if (!full) return null;
	const topK = getSnippetTopK();
	const picked = selectSections(full, query, topK);
	const raw = picked.length > 0
		? picked.map((s) => (s.title === "(前言)" ? s.body.trim() : `## ${s.title}\n${s.body.trim()}`)).join("\n\n")
		: full;
	const buf = Buffer.from(raw, "utf8");
	let snippet = raw;
	if (buf.length > maxBytes) {
		let cut = maxBytes;
		while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--; // UTF-8 字符边界
		snippet = buf.slice(0, cut).toString("utf8") + " …[节选截断]";
	}
	const titles = (picked.length > 0 ? picked.map((s) => s.title) : ["文件首部"]).slice(0, Math.max(1, topK));
	return { snippet, reason: `§${titles.join(" / ")}` };
}

// ─────────────────────────────────────────────────────────────────────────────
// b) 仅对有归档来源证明的采集片段降噪
// ─────────────────────────────────────────────────────────────────────────────

/**
 * pi 一轮 = 一次 assistant 响应及它的全部工具结果（docs/json.md）。
 * 不把 user/custom/toolResult 消息条数当轮次，不缩减显式 read/MCP/query 输出。
 */
export function pruneStaleToolOutputs(
	messages: any[],
	opts?: { staleThreshold?: number; toolMax?: number },
): any[] {
	if (!Array.isArray(messages) || messages.length === 0) return messages;
	const threshold = opts?.staleThreshold ?? getStaleThreshold();
	const toolMax = opts?.toolMax ?? getToolOutputMax();
	if (!Number.isFinite(threshold) || threshold < 0 || !Number.isFinite(toolMax) || toolMax <= 0) return messages;
	const completedToolCalls = new Set<string>();
	let completedTurns = 0;
	let result = messages;
	for (let i = messages.length - 1; i >= 0; i--) {
		const m = messages[i];
		if (m?.role === "assistant") {
			const calls = Array.isArray(m.content) ? m.content.filter((p: any) => p?.type === "toolCall") : [];
			if (calls.every((p: any) => typeof p.id === "string" && completedToolCalls.has(p.id))) completedTurns++;
			for (const call of calls) completedToolCalls.delete(call.id);
			continue;
		}
		const completion = m?.role === "custom" && m.customType === TASK_COMPLETION_TYPE;
		if (!completion && m?.role !== "toolResult" && m?.role !== "tool_result") continue;
		if (!completion && typeof m.toolCallId === "string") completedToolCalls.add(m.toolCallId);
		if (completedTurns < threshold || (!completion && !OWNED_TASK_TOOLS.has(m.toolName))) continue;
		const taskId = m.details?.taskId;
		if (typeof taskId !== "string") continue; // 无任务来源元数据时保守保留，不能从正文猜句柄。
		const proof = m.details?.[COLLECTION_DETAILS_KEY] ?? null;
		if (completion && typeof m.content === "string") {
			const content = pruneArchivedCollectionText(m.content, toolMax, taskId, proof);
			if (content !== m.content) {
				if (result === messages) result = [...messages];
				result[i] = { ...m, content };
			}
			continue;
		}
		if (!Array.isArray(m.content)) continue;
		let changed = false;
		const content = m.content.map((part: any, index: number) => {
			if (part?.type !== "text" || typeof part.text !== "string") return part;
			const text = pruneArchivedCollectionText(part.text, toolMax, taskId, proof, index);
			if (text === part.text) return part;
			changed = true;
			return { ...part, text };
		});
		if (changed) {
			if (result === messages) result = [...messages];
			result[i] = { ...m, content };
		}
	}
	return result;
}

/**
 * 仅去重插件自己标识的相同快照；正文/其他插件/任务完成通知不按相似文本猜来源。
 * v2.21.8 缓存友好化：保留最早出现、丢弃后来的重复——被丢弃的必然出现在首见之后，首个删除点
 * 之前的全部历史消息逐项原样保留，提示缓存前缀不再被历史中段删除打断（旧「保留最新」把删除点
 * 提前到首见位置，中段前缀整体失效）；去重语义不变（模型只见一份）。
 */
export function dedupeAutomaticSnapshots(messages: any[]): any[] {
	const types = new Set(["amagi:recovery", "amagi:compact-continuation", "amagi-routing-memory"]);
	const seen = new Set<string>();
	let changed = false;
	const kept = [];
	for (let i = 0; i < messages.length; i++) {
		const m = messages[i];
		if (m?.role === "custom" && types.has(m.customType)) {
			let key: string | undefined;
			try { key = JSON.stringify([m.customType, m.content, m.details]); } catch { /* 不可序列化则保留 */ }
			if (key !== undefined) {
				if (seen.has(key)) { changed = true; continue; }
				seen.add(key);
			}
		}
		kept.push(m);
	}
	return changed ? kept : messages;
}

// ─────────────────────────────────────────────────────────────────────────────
// 粘性注入记忆（v2.21.8 M1 修复）
// ─────────────────────────────────────────────────────────────────────────────
// 注入只存在于请求投影，会话历史中的 user 消息始终是原文。修复前每轮对「最后一条 user 消息」
// 重算注入：新 user 消息（含任务完成通知等 user 角色消息）到来后注入锚点转移、旧消息恢复原文
// → 旧消息起全部前缀失效。Leader 实测（会话 JSONL usage）：同 5 分钟 TTL 内上一条 user 命中
// 关键词时下一轮缓存断裂 claude-opus 7/8、gpt-6-astra 10/11、claude-sonnet 14/22；未命中 0/3~0/3；
// 断裂时 cacheRead 恒停在 ≈51k（系统提示+工具），即历史中段前缀被改写。修复：注入后缀按稳定键
// 在模块内记忆，后续每次 context 事件以字节完全相同的内容重放到该消息上，不随占用率/预算/
// 后续消息变化重算；新 user 消息仍按现有规则独立判定注入。

/** 注入块起始标记（检测「已注入」，并从投影回灌中剥离还原原文）。 */
const INJECTION_MARKER = "\n\n--- 上下文自动供给";

/**
 * 粘性表 LRU 上限。取舍：被淘汰的只是极旧 user 消息的注入记录——该消息恢复原文，造成一次
 * 历史中段改写（一次性缓存断裂）。命中即刷新，活跃注入不会被淘汰；128 已覆盖单会话绝大多数
 * user 消息，越界的消息通常早已进入压缩窗口（压缩后旧消息消失，粘性记录无重放对象、自然失效，
 * 与淘汰语义一致）。
 */
const STICKY_TABLE_MAX = 128;

/** 稳定键 → 注入后缀（字节冻结）。Map 按插入序维护，命中重插实现 LRU。 */
const stickyInjections = new Map<string, string>();

/** 测试隔离：清空粘性注入记忆（生产无消费者）。 */
export function resetStickyInjectionsForTest(): void {
	stickyInjections.clear();
}

/** FNV-1a 双轮 64 位散列（hex 16 位）：会话规模（千级消息）下碰撞概率可忽略。 */
function stableHash(text: string): string {
	let h1 = 0x811c9dc5;
	let h2 = 0x9e3779b9;
	for (let i = 0; i < text.length; i++) {
		const c = text.charCodeAt(i);
		h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
		h2 = Math.imul(h2 ^ ((c + i) & 0xffff), 0x85ebca6b) >>> 0;
	}
	return h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0");
}

/** user 消息纯文本（string 原样；数组取 text part 拼接，非文本 part 不参与）。 */
function userTextOf(m: any): string {
	if (typeof m?.content === "string") return m.content;
	if (Array.isArray(m?.content)) {
		return m.content.map((p: { type?: string; text?: string }) => (p?.type === "text" && typeof p.text === "string" ? p.text : "")).join("");
	}
	return "";
}

/**
 * 粘性身份键：role + timestamp + 原文内容 hash。不能只靠对象引用（WeakSet）——宿主每轮重建
 * messages 数组（新对象引用），引用必然失配，这正是 M1 修复前的失效面。原文 = 剥离注入标记
 * 之前的内容（投影回灌时还原）。同文同刻的重复消息共享一键：内容相同则注入字节相同，无语义差。
 */
function stickyKeyOf(m: any): string | null {
	if (!m || m.role !== "user") return null;
	let text = userTextOf(m);
	const markerIdx = text.indexOf(INJECTION_MARKER);
	if (markerIdx >= 0) text = text.slice(0, markerIdx);
	const ts = typeof m.timestamp === "number" || typeof m.timestamp === "string" ? String(m.timestamp) : "";
	return `user|${ts}|${stableHash(text)}`;
}

/** 追加注入后缀到 user 消息（C2 fix：保留原 content 结构——数组含 image 等，只追加 text part）。 */
function appendInjectionToUser(m: any, injection: string): any {
	if (typeof m.content === "string") return { ...m, content: m.content + injection };
	if (Array.isArray(m.content)) return { ...m, content: [...m.content, { type: "text", text: injection }] };
	return { ...m, content: [{ type: "text", text: String(m.content ?? "") }, { type: "text", text: injection }] };
}

/** 记录粘性注入（LRU：重插刷新位置；超上限淘汰最旧键）。 */
function rememberStickyInjection(key: string, injection: string): void {
	stickyInjections.delete(key);
	stickyInjections.set(key, injection);
	while (stickyInjections.size > STICKY_TABLE_MAX) {
		const oldest = stickyInjections.keys().next().value;
		if (oldest === undefined) break;
		stickyInjections.delete(oldest);
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20261101-cbf452：已供给/已读资源去重（会话生命周期）+ 机器消息不触发新供给
// ─────────────────────────────────────────────────────────────────────────────
// 实测根因（M01 会话 8 次预检 + 4/4 次完成通知）：完成通知经 sendUserMessage 以无标记
// role=user 进入会话，本模块把通知正文当新用户请求做关键词匹配（workflow/task_submit/
// 检查/review 等词全在通知正文里），每条通知尾部注入 2-3k 无关片段；同一资源反复供给。
// 修复三面：a) 供给去重——当前投影中已存在某资源注入块（含粘性待重放）则不再供给，
// 注入块随会话压缩/淘汰从投影消失后自然复位（真实生命周期）；b) 已读去重——
// amagi_resource 成功读过的资源按会话分桶去重；c) 机器驱动轮——本轮请求由机器消息
//（custom，如 amagi:task-completion 完成通知）触发时不产生新供给，真实用户消息照常。

/** 注入块中资源 id 的提取口径（与 snippets 拼装格式同源：〔命中〕"kw" → id §…）。 */
const SUPPLIED_ID_RE = /→ ([a-z0-9-]+) §/g;
function suppliedIdsOfInjection(injection: string): Set<string> {
	const ids = new Set<string>();
	for (const m of injection.matchAll(SUPPLIED_ID_RE)) ids.add(m[1]!);
	return ids;
}

/** 当前投影已供给资源集合：回灌消息（正文含注入块）取块内 id；原文消息查粘性表
 *（键在投影中存在才会被重放——与 replayStickyInjections 同判定基准，压缩后自然复位）。 */
function suppliedResourceIds(messages: any[]): Set<string> {
	const supplied = new Set<string>();
	for (const m of messages) {
		if (m?.role !== "user") continue;
		const text = userTextOf(m);
		const markerIdx = text.indexOf(INJECTION_MARKER);
		if (markerIdx >= 0) { for (const id of suppliedIdsOfInjection(text.slice(markerIdx))) supplied.add(id); continue; }
		const key = stickyKeyOf(m);
		const injection = key !== null ? stickyInjections.get(key) : undefined;
		if (injection !== undefined) for (const id of suppliedIdsOfInjection(injection)) supplied.add(id);
	}
	return supplied;
}

/** 会话级已读登记桶（LRU 上限 8 会话×32 资源；sessionId 缺省 "default" 共享桶）。 */
const resourceReads = new Map<string, Set<string>>();
const RESOURCE_READ_SESSIONS_MAX = 8;
const RESOURCE_READ_PER_SESSION_MAX = 32;

/** amagi_resource 成功读取 canonical 资源后登记（resource-reader 组合接线）；
 * 同会话内不再对该资源重复供给片段。 */
export function noteResourceRead(resourceId: string, sessionId = "default"): void {
	if (!resourceId) return;
	let bucket = resourceReads.get(sessionId);
	if (bucket === undefined) {
		bucket = new Set();
		resourceReads.set(sessionId, bucket);
	}
	bucket.delete(resourceId);
	bucket.add(resourceId);
	while (bucket.size > RESOURCE_READ_PER_SESSION_MAX) bucket.delete(bucket.keys().next().value!);
	resourceReads.delete(sessionId);
	resourceReads.set(sessionId, bucket);
	while (resourceReads.size > RESOURCE_READ_SESSIONS_MAX) resourceReads.delete(resourceReads.keys().next().value!);
}

/** 测试隔离：清空已读登记（生产无消费者）。 */
export function resetResourceReadsForTest(): void {
	resourceReads.clear();
}

/** 机器驱动轮判定：最后一条 user 消息之后存在宿主/扩展机器消息（role=custom，如
 * amagi:task-completion 完成通知 triggerTurn）——本轮请求由机器消息触发，不产生新供给。
 * 只按消息角色识别，不按正文前缀猜测（真实用户引用通知正文不受影响）。 */
function machineDrivenTurn(messages: any[], lastUserIdx: number): boolean {
	for (let i = lastUserIdx + 1; i < messages.length; i++) if (messages[i]?.role === "custom") return true;
	return false;
}

/** 粘性重放：历史中所有已记忆的 user 消息按冻结字节重放注入（历史是原文，注入只存在于投影）。 */
function replayStickyInjections(messages: any[]): any[] {
	if (stickyInjections.size === 0) return messages;
	let result = messages;
	for (let i = 0; i < messages.length; i++) {
		const m = messages[i];
		if (m?.role !== "user") continue;
		if (userTextOf(m).includes(INJECTION_MARKER)) continue; // 已含注入（投影回灌）不重复追加
		const key = stickyKeyOf(m);
		if (!key) continue;
		const injection = stickyInjections.get(key);
		if (injection === undefined) continue;
		stickyInjections.delete(key); // LRU 刷新：活跃注入不被淘汰
		stickyInjections.set(key, injection);
		if (result === messages) result = [...messages];
		result[i] = appendInjectionToUser(m, injection);
	}
	return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// c) token 预算自适应注入
// ─────────────────────────────────────────────────────────────────────────────

/**
 * C9 fix: 注入资源片段，UTF-8 byte 口径 + 基于当前 messages 占用率的动态预算缩减。
 * v2.21.8：注入粘性化——已注入消息先经 replayStickyInjections 以字节冻结内容重放（M1 修复：
 * 新 user 消息到来后旧注入不再消失，前缀不失效）；新注入只对最后一条 user 消息判定，占用率
 * 按重放后的投影计算（已重放的注入是请求里的真实字节，且字节本身冻结，不影响稳定性）。
 */
export function injectResourceSnippets(messages: any[], snippets: string[]): any[] {
	if (!Array.isArray(messages)) return messages;
	// 粘性重放（M1 修复核心）：不随占用率/预算/后续消息变化重算。
	const replayed = replayStickyInjections(messages);
	if (!snippets.length) return replayed;
	// ev-20261013（设计 §7.3 方案 A）：loop 内缓存稳定（M2）——占用率只统计到最后一条 user 消息为止，
	// 排除其后工具输出增长尾部。同一 user 输入下（无论其后工具输出如何增长）动态预算与截断结果
	// 字节相同，注入位置之后的请求前缀不因尾部增长失效。
	let lastUserIdx = -1;
	for (let i = replayed.length - 1; i >= 0; i--) {
		if (replayed[i]?.role === "user") { lastUserIdx = i; break; }
	}
	// 已注入（本轮重放或投影回灌）的最后一条 user 消息不重复追加
	if (lastUserIdx >= 0 && userTextOf(replayed[lastUserIdx]).includes(INJECTION_MARKER)) return replayed;
	// C9: 估算前缀（≤ 最后一条 user 消息）UTF-8 bytes，随占用率动态缩减注入预算；无 user 消息时
	// 注入追加在末尾，全部消息均在注入锚点之前，按全量计（无尾部可排除）。
	const anchorIdx = lastUserIdx >= 0 ? lastUserIdx : replayed.length - 1;
	const ctxBytes = replayed.slice(0, anchorIdx + 1).reduce((sum, m) => {
		const c = typeof m?.content === "string" ? m.content : (Array.isArray(m?.content) ? m.content.map((p: { text?: string }) => p?.text || "").join("") : "");
		return sum + Buffer.byteLength(c, "utf8");
	}, 0);
	const maxContextBytes = 128 * 1024; // 128KB 估算上下文窗口
	const occupancy = Math.min(1, ctxBytes / maxContextBytes);
	const dynamicBudget = Math.floor(getMaxInjectBytes() * (1 - occupancy * 0.7)); // 高占用时缩减 70%
	let budget = dynamicBudget;
	const accepted: string[] = [];
	for (const s of snippets) {
		if (budget <= 0) break;
		// C9: UTF-8 byte 口径截断（不切断多字节字符）
		const buf = Buffer.from(s, "utf8");
		if (buf.length <= budget) {
			accepted.push(s);
			budget -= buf.length;
		} else {
			let cut = budget;
			while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--; // 回退到字符边界
			accepted.push(buf.slice(0, cut).toString("utf8"));
			budget = 0;
		}
	}
	if (!accepted.length) return replayed;
	const injection = `\n\n--- 上下文自动供给（关键词匹配 L1 资源片段，仅供参考）---\n${accepted.join("\n\n---\n\n")}`;
	// A2: 不用 role:"system"（pi convertToLlm 丢弃非 user/assistant/toolResult role，types.d.ts:122-145）；
	// 改为追加到最后 user message content（合法 role，LLM 可见）
	if (lastUserIdx < 0) {
		// 无 user 消息：追加合成 user 消息。合成消息不进粘性表——宿主不回写投影，下一轮它自然消失、
		// 无重放对象；进表反而可能与真实空 content 消息撞键造成误重放。
		return [...replayed, { role: "user", content: injection }];
	}
	const key = stickyKeyOf(replayed[lastUserIdx]);
	const result = [...replayed];
	result[lastUserIdx] = appendInjectionToUser(replayed[lastUserIdx], injection);
	if (key) rememberStickyInjection(key, injection);
	return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// 注册 context 事件 handler
// ─────────────────────────────────────────────────────────────────────────────

/** 注册 context handler：自动片段供给 + 已归档采集降噪，原生压缩生命周期保持不变。 */
export function registerContextHandler(pi: ExtensionAPI, packageRoot: string): void {
	pi.on("tool_result", (event) => {
		if (!OWNED_TASK_TOOLS.has(event.toolName)) return undefined;
		const details = event.details as Record<string, unknown> | undefined;
		if (typeof details?.taskId !== "string") return undefined;
		const proof = archivedCollectionDetails(event.content, details.taskId);
		if (proof) return { details: { ...details, [COLLECTION_DETAILS_KEY]: proof } };
		return undefined;
	});
	pi.on("context", (event: { messages: any[] }, _ctx: any): any => {
		const messages = event.messages;
		if (!Array.isArray(messages)) return undefined;

		// a) 关键词匹配注入（E5: 片段级索引 + top-K + 命中理由一行，便于判断采纳深度）。
		// ev-20261013（设计 §7.3 方案 A 对照开关 / §9.3）：AMAGI_CONTEXT_INJECT_OFF=1 只关闭关键词
		// 片段注入——pruneStaleToolOutputs / dedupeAutomaticSnapshots 等其余 context 处理完全不变
		//（对照实验与快速回滚用；不恢复 P3-D 冻结的调参开关）。
		const injectOff = process.env.AMAGI_CONTEXT_INJECT_OFF === "1";
		let next = dedupeAutomaticSnapshots(messages);
		if (!injectOff) {
			// v2.21.8 粘性注入：新注入只对最后一条 user 消息判定；已粘性记忆的消息跳过片段计算
			//（重放必达且字节冻结）。粘性重放对全部已注入消息生效（含 snippets 为空时——旧消息不因
			// 新消息未命中而掉注入，M1 修复核心）。
			// ev-20261101-cbf452：①机器驱动轮（最后 user 之后有 custom 机器消息，如完成通知 triggerTurn）
			// 不产生新供给；②已供给（投影中已有该资源注入块）与已读（本会话 amagi_resource 读过全文）
			// 的资源去重——真实用户消息的首次供给不受影响。
			let lastUserIdx = -1;
			for (let i = next.length - 1; i >= 0; i--) { if (next[i]?.role === "user") { lastUserIdx = i; break; } }
			const lastUser = lastUserIdx >= 0 ? next[lastUserIdx] : undefined;
			let snippets: string[] = [];
			if (lastUser && !userTextOf(lastUser).includes(INJECTION_MARKER) && !machineDrivenTurn(next, lastUserIdx)) {
				const lastUserKey = stickyKeyOf(lastUser);
				if (!(lastUserKey !== null && stickyInjections.has(lastUserKey))) {
					const userText = typeof lastUser.content === "string"
						? lastUser.content
						: JSON.stringify(lastUser.content || "");
					const sessionId = _ctx?.sessionManager?.getSessionId?.();
					const readBucket = resourceReads.get(typeof sessionId === "string" && sessionId ? sessionId : "default");
					const hits = matchResourcesWithReasons(userText)
						.filter((h) => {
							if (readBucket?.has(h.id)) return false; // 已读全文（本会话 amagi_resource），不重复供给
							return true;
						});
					if (hits.length > 0) {
						// 供给去重在命中后计算（无命中时不扫投影）；已供给集合与 replayStickyInjections
						// 同基准（压缩/淘汰后自然复位）。
						const supplied = suppliedResourceIds(next);
						const fresh = hits.filter((h) => !supplied.has(h.id));
						snippets = fresh.map((h) => {
							const r = loadSnippetForQuery(h.id, packageRoot, userText);
							return r ? `〔命中〕"${h.keyword}" → ${h.id} ${r.reason}\n\n${r.snippet}` : "";
						}).filter(Boolean);
					}
				}
			}
			next = injectResourceSnippets(next, snippets);
		}

		// b) 仅缩减有生产者范围证明的陈旧采集块
		next = pruneStaleToolOutputs(next);

		// 只有实际改动才返回（避免无谓 messages 替换）
		if (next === messages) return undefined;
		return { messages: next };
	});
}
