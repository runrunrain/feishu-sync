/**
 * evidence-options.ts — S5/23f4a4（方案 §5.3）+ S5/01ef8c（§5.4）：证据超时预算与呈现模式解析层。
 *
 * 独立无上层依赖（不 import task-tool/index 等；依赖门禁 no-reverse/no-cycles 安全）。
 * evidence.ts / finalizer.ts 消费；S2 在 task 派发侧做参数校验与一次性解析，把冻结值传入
 * runTask auto-verify 与最终 finalizer 两条证据链（后台/自动重试/resume 均携带）。
 *
 * 超时优先级链（§5.3；ev-20261011-ad4513 增项目层）：task evidenceTimeouts > env
 * AMAGI_EVIDENCE_{TEST,GIT,SUMMARY_GIT}_TIMEOUT_MS > 项目 <cwd>/amagi.json evidenceTimeouts
 * > 默认 120000 / 10000 / 5000 ms（与旧三常量一致——旧调用不传任何配置完全维持默认）。
 *   - 任务参数越界/非法 → validateEvidenceTimeouts 抛 EvidenceTimeoutsParamError（S2 报参数错误）；
 *   - 非法 env（非正整数/越界，0 不代表无限）→ 回退（项目层/默认）并在 envWarning 收集一次性提示；
 *   - 项目层非法（文件缺失/非法 JSON/字段越界）→ 忽略该字段回退 env/默认（与 concurrency 段同口径：
 *     非法值仅诊断不阻断派发；根因 ev-20261011-ad4513：本仓全量 140-180s > 固定 120s 预算，
 *     每任务 chk-auto-baseline-test 恒超时 → settlement=incomplete → Leader 逐任务 waive——
 *     允许项目声明预算把该结构性税归零）；
 *   - 回滚：AMAGI_EVIDENCE_TIMEOUT_CONFIG=0 强制忽略 task/env/项目新配置，用旧三常量（=默认值）。
 *
 * 呈现（§5.4）：AMAGI_EVIDENCE_VIEW=legacy|compact，默认 compact；非法值回 compact。
 * compact 的终态通知使用有界采集摘要，详情先保存 evidence.md；legacy 用旧呈现。
 * 底层 classifyFreshPaths 四档归因与 ±2min 窗口语义完全不变。
 */
import * as fs from "node:fs";
import * as path from "node:path";

// ─────────────────────────────────────────────────────────────────────────────
// 类型
// ─────────────────────────────────────────────────────────────────────────────

/** 任务级可选证据超时输入（task evidenceTimeouts；三字段均可选）。 */
export interface EvidenceTimeouts {
	/** 单次证据测试命令预算（ms；合法区间 1000–14400000，即 4h 上限）。 */
	testMs?: number;
	/** 证据链 git 探测/diff/status 预算（ms；合法区间 1000–120000）。 */
	gitMs?: number;
	/** 产物摘要块 git（execFileSync）预算（ms；合法区间 1000–120000）。 */
	summaryGitMs?: number;
}

/** 解析冻结后的证据超时（finalizer / gatherEvidenceReport 消费；每逻辑派发解析一次后传入）。 */
export interface ResolvedEvidenceTimeouts {
	testMs: number;
	gitMs: number;
	summaryGitMs: number;
	/** 非法 env 回默认的一次性提示（无非法项为 null；随证据文本提示一次，不重复）。 */
	envWarning: string | null;
	/** 生效来源（诊断用）：rollback=强制旧三常量；defaults=无任何配置；project/env/task=对应层覆盖。 */
	source: "defaults" | "project" | "env" | "task" | "rollback";
}

/** 证据归因呈现模式（§5.4）：compact=低噪音聚焦（默认）；legacy=旧呈现（回滚）。 */
export type EvidenceView = "legacy" | "compact";

// ─────────────────────────────────────────────────────────────────────────────
// 常量（默认值 = 旧三常量，行为零变化）
// ─────────────────────────────────────────────────────────────────────────────

export const DEFAULT_EVIDENCE_TEST_TIMEOUT_MS = 120_000;
export const DEFAULT_EVIDENCE_GIT_TIMEOUT_MS = 10_000;
export const DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS = 5_000;

/** testMs 合法区间：1000ms – 14400000ms（4h；测试 timeout 是单次证据命令预算，非逻辑任务预算）。 */
export const EVIDENCE_TEST_MS_MIN = 1_000;
export const EVIDENCE_TEST_MS_MAX = 14_400_000;
/** git 系（gitMs/summaryGitMs）合法区间：1000ms – 120000ms。 */
export const EVIDENCE_GIT_MS_MIN = 1_000;
export const EVIDENCE_GIT_MS_MAX = 120_000;

/** 任务参数错误（S2 在 schema 校验层捕获并报参数错误；finalizer 侧不吞掉真实参数问题）。 */
export class EvidenceTimeoutsParamError extends Error {
	constructor(message: string) {
		super(message);
		this.name = "EvidenceTimeoutsParamError";
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 解析
// ─────────────────────────────────────────────────────────────────────────────

/** 单个任务字段校验：有限整数且在 [min,max]；非法抛 EvidenceTimeoutsParamError。 */
function requireTaskField(name: keyof EvidenceTimeouts, v: number | undefined, min: number, max: number): number {
	if (v === undefined) return NaN; // 哨兵：调用方跳过该字段
	if (typeof v !== "number" || !Number.isFinite(v) || !Number.isInteger(v)) {
		throw new EvidenceTimeoutsParamError(`evidenceTimeouts.${name} 必须为整数毫秒值，实际: ${String(v)}`);
	}
	if (v < min || v > max) {
		throw new EvidenceTimeoutsParamError(`evidenceTimeouts.${name}=${v} 越界（合法区间 ${min}–${max} ms；0 不代表无限）`);
	}
	return v;
}

/**
 * 任务级 evidenceTimeouts 校验（S2 派发侧参数错误判定入口；与回滚开关无关——参数合法性
 * 始终校验，回滚只影响生效预算）。全字段合法/缺省返回原值（部分字段缺省合法）。
 */
export function validateEvidenceTimeouts(input: EvidenceTimeouts | undefined): EvidenceTimeouts {
	if (input === undefined || input === null) return {};
	if (typeof input !== "object" || Array.isArray(input)) {
		throw new EvidenceTimeoutsParamError(`evidenceTimeouts 必须为对象 { testMs?, gitMs?, summaryGitMs? }，实际: ${typeof input}`);
	}
	requireTaskField("testMs", input.testMs, EVIDENCE_TEST_MS_MIN, EVIDENCE_TEST_MS_MAX);
	requireTaskField("gitMs", input.gitMs, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	requireTaskField("summaryGitMs", input.summaryGitMs, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	return input;
}

/** 单个 env 值解析：正整数字符串且在区间内 → 数值；否则 undefined（非法，收集提示）。 */
function parseEnvMs(raw: string | undefined, min: number, max: number): number | undefined {
	if (raw === undefined || raw === "") return undefined;
	if (!/^\d+$/.test(raw.trim())) return undefined;
	const n = Number(raw.trim());
	if (!Number.isInteger(n) || n < min || n > max) return undefined;
	return n;
}

const ENV_TEST = "AMAGI_EVIDENCE_TEST_TIMEOUT_MS";
const ENV_GIT = "AMAGI_EVIDENCE_GIT_TIMEOUT_MS";
const ENV_SUMMARY_GIT = "AMAGI_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS";

/** 回滚开关：AMAGI_EVIDENCE_TIMEOUT_CONFIG=0 → 强制忽略 task/env/项目新配置，用旧三常量。 */
export function evidenceTimeoutConfigDisabled(env: Record<string, string | undefined> = process.env): boolean {
	return env.AMAGI_EVIDENCE_TIMEOUT_CONFIG === "0" || env.AMAGI_EVIDENCE_TIMEOUT_CONFIG === "false";
}

/** ev-20261011-ad4513：项目级证据超时声明读取（<cwd>/amagi.json 的 evidenceTimeouts 段）。
 *  容错口径：文件缺失/不可读/非法 JSON/段形状非法/字段越界 → 对应字段忽略（回退 env/默认），
 *  不抛不阻断派发（与 amagi.json concurrency 段同口径：非法值仅诊断不阻断）。readFileSync
 *  可注入供测试隔离。 */
export function readProjectEvidenceTimeouts(
	cwd: string | undefined,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): EvidenceTimeouts {
	if (typeof cwd !== "string" || !cwd) return {};
	let raw: string;
	try {
		raw = readFileSync(path.join(cwd, "amagi.json"), "utf8");
	} catch { return {}; }
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch { return {}; }
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return {};
	const section = (parsed as Record<string, unknown>).evidenceTimeouts;
	if (section === undefined) return {};
	if (section === null || typeof section !== "object" || Array.isArray(section)) return {};
	const rec = section as Record<string, unknown>;
	const intIn = (v: unknown, min: number, max: number): number | undefined =>
		typeof v === "number" && Number.isInteger(v) && v >= min && v <= max ? v : undefined;
	const out: EvidenceTimeouts = {};
	const t = intIn(rec.testMs, EVIDENCE_TEST_MS_MIN, EVIDENCE_TEST_MS_MAX);
	if (t !== undefined) out.testMs = t;
	const g = intIn(rec.gitMs, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	if (g !== undefined) out.gitMs = g;
	const s = intIn(rec.summaryGitMs, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	if (s !== undefined) out.summaryGitMs = s;
	return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20261020-c8ca99：项目级测试命令声明（<cwd>/amagi.json verification.testCommand）
// ─────────────────────────────────────────────────────────────────────────────

/** 项目声明测试命令（verification.testCommand；声明优先于一切探测——探测是猜测，声明是权威）。
 *  argv 数组不经 shell（逐元素 spawn，无注入面）；cwd 相对项目根（缺省项目根）。 */
export interface ProjectTestCommand {
	argv: string[];
	/** 执行目录（相对声明 amagi.json 所在目录；已归一 POSIX 分隔；缺省 "."）。 */
	cwdRel: string;
	/** ev-20261021-54b4e3：声明的执行期环境（资源预算等，如 NODE_OPTIONS=--max-old-space-size=1024、
	 *  runner 并发变量）。自动检查 env 白名单不继承宿主 NODE_OPTIONS——资源约束只能经此声明到达
	 *  实际执行；缺省 = 无（runner 默认并发/Node 默认堆）。 */
	env?: Record<string, string>;
}

/** ev-20261021-54b4e3：自动基线入口策略。probe（缺省）=无声明时走探测链；declared-only=只执行
 *  项目声明的入口，无声明即 unavailable（不探测、不退回全量 npm test）。 */
export type AutoBaselinePolicy = "probe" | "declared-only";

/** ev-20261021-54b4e3：项目验证策略读取结果。problem=声明存在但非法（自动基线据此 unavailable，
 *  不回退探测链——声明的意图是指定入口，非法声明退回探测会执行与项目约束冲突的命令）。 */
export interface ProjectVerificationPolicy {
	testCommand: ProjectTestCommand | null;
	autoBaseline: AutoBaselinePolicy;
	problem: string | null;
}

/** 声明 env 中禁止覆盖的键：PATH 走 shell.pathPrepend；隔离注入键（缓存重定向/Go 离线环境）由
 *  harness 管理，项目覆盖会破坏对象隔离；动态装载器注入不属于资源配置。 */
const DECLARED_ENV_RESERVED = /^(?:PATH|HOME|VITEST_CACHE_DIR|npm_config_cache|AMAGI_TEST_JITI_CACHE_DIR|GOFLAGS|GOPROXY|GOSUMDB|GOTOOLCHAIN|GOENV|GOMODCACHE|LD_PRELOAD|LD_LIBRARY_PATH|DYLD_.*)$/;

const ABSENT_POLICY: ProjectVerificationPolicy = { testCommand: null, autoBaseline: "probe", problem: null };

/**
 * ev-20261020-c8ca99 / ev-20261021-54b4e3：读取 <cwd>/amagi.json 的 verification 段。
 * 文件缺失/不可读/非法 JSON → 未声明（回退探测链，doctor 报文件问题）。verification 段存在但形状
 * 非法（argv 非非空字符串数组 / cwd 绝对或含 .. / env 非字符串映射或含保留键 / autoBaseline 非法）
 * → problem 非空：自动基线记 unavailable，不静默退回探测（54b4e3：退回的全量探测命令可能违背项目
 * 声明的 guarded 串行入口与资源约束）。readFileSync 可注入供测试隔离。
 */
export function readProjectVerificationPolicy(
	cwd: string | undefined,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): ProjectVerificationPolicy {
	if (typeof cwd !== "string" || !cwd) return ABSENT_POLICY;
	let raw: string;
	try {
		raw = readFileSync(path.join(cwd, "amagi.json"), "utf8");
	} catch { return ABSENT_POLICY; /* lint-exempt:文件缺失/不可读 → 未声明，回退探测链 */ }
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch { return ABSENT_POLICY; /* lint-exempt:非法 JSON → 未声明，回退探测链（doctor 报文件问题） */ }
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return ABSENT_POLICY;
	const verification = (parsed as Record<string, unknown>).verification;
	if (verification === undefined || verification === null) return ABSENT_POLICY;
	const bad = (problem: string): ProjectVerificationPolicy => ({ testCommand: null, autoBaseline: "probe", problem });
	if (typeof verification !== "object" || Array.isArray(verification)) return bad("verification 须为对象");
	const v = verification as Record<string, unknown>;
	let autoBaseline: AutoBaselinePolicy = "probe";
	if (v.autoBaseline !== undefined) {
		if (v.autoBaseline !== "probe" && v.autoBaseline !== "declared-only") return bad(`verification.autoBaseline=${JSON.stringify(v.autoBaseline)} 非法（probe | declared-only）`);
		autoBaseline = v.autoBaseline;
	}
	const tc = v.testCommand;
	if (tc === undefined || tc === null) return { testCommand: null, autoBaseline, problem: null };
	if (typeof tc !== "object" || Array.isArray(tc)) return bad("verification.testCommand 须为对象");
	const rec = tc as Record<string, unknown>;
	if (!Array.isArray(rec.argv) || rec.argv.length === 0 || rec.argv.some((a) => typeof a !== "string" || a === "")) return bad("verification.testCommand.argv 须为非空字符串组成的非空数组");
	let cwdRel = ".";
	if (rec.cwd !== undefined) {
		if (typeof rec.cwd !== "string" || rec.cwd.trim() === "") return bad("verification.testCommand.cwd 须为非空字符串");
		if (path.isAbsolute(rec.cwd) || rec.cwd.split(/[\\/]/).includes("..")) return bad(`verification.testCommand.cwd=${rec.cwd} 须为项目内相对路径（非绝对、不含 ..）`);
		cwdRel = rec.cwd.split(/[\\/]/).join("/");
	}
	let env: Record<string, string> | undefined;
	if (rec.env !== undefined) {
		if (rec.env === null || typeof rec.env !== "object" || Array.isArray(rec.env)) return bad("verification.testCommand.env 须为字符串映射对象");
		env = {};
		for (const [k, val] of Object.entries(rec.env as Record<string, unknown>)) {
			if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(k)) return bad(`verification.testCommand.env 键 ${JSON.stringify(k)} 非法（须为环境变量名）`);
			if (DECLARED_ENV_RESERVED.test(k)) return bad(`verification.testCommand.env.${k} 为保留键（PATH 用 shell.pathPrepend；缓存重定向/Go 离线/装载器变量由 harness 管理）`);
			if (typeof val !== "string") return bad(`verification.testCommand.env.${k} 须为字符串`);
			env[k] = val;
		}
		if (Object.keys(env).length === 0) env = undefined;
	}
	return { testCommand: { argv: [...rec.argv as string[]], cwdRel, ...(env ? { env } : {}) }, autoBaseline, problem: null };
}

/** 兼容读取面：合法声明 → ProjectTestCommand；未声明或非法 → null（非法细节见 readProjectVerificationPolicy）。 */
export function readProjectTestCommand(
	cwd: string | undefined,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): ProjectTestCommand | null {
	return readProjectVerificationPolicy(cwd, readFileSync).testCommand;
}

/**
 * 解析生效证据超时（每逻辑派发一次，解析后冻结传入消费链；旧调用不传 → env 链生效，
 * 无任何配置时与旧三常量完全一致）。非法 env 回退并一次性提示；非法 task 字段抛
 * EvidenceTimeoutsParamError（调用方先用 validateEvidenceTimeouts 校验可避免在收尾链抛错）；
 * 项目层（ev-20261011-ad4513）仅收合法字段，位置在 env 之下、默认之上（读盘容错见
 * readProjectEvidenceTimeouts）。
 */
export function resolveEvidenceTimeouts(
	task?: EvidenceTimeouts,
	env: Record<string, string | undefined> = process.env,
	project?: EvidenceTimeouts,
): ResolvedEvidenceTimeouts {
	// 回滚：部署级强制旧三常量（忽略 task/env/项目新配置；默认值即旧常量，行为零变化）
	if (evidenceTimeoutConfigDisabled(env)) {
		return {
			testMs: DEFAULT_EVIDENCE_TEST_TIMEOUT_MS,
			gitMs: DEFAULT_EVIDENCE_GIT_TIMEOUT_MS,
			summaryGitMs: DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS,
			envWarning: null,
			source: "rollback",
		};
	}

	let testMs = DEFAULT_EVIDENCE_TEST_TIMEOUT_MS;
	let gitMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS;
	let summaryGitMs = DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS;
	let source: ResolvedEvidenceTimeouts["source"] = "defaults";
	const bad: string[] = [];

	const envTest = parseEnvMs(env.AMAGI_EVIDENCE_TEST_TIMEOUT_MS, EVIDENCE_TEST_MS_MIN, EVIDENCE_TEST_MS_MAX);
	if (envTest !== undefined) { testMs = envTest; source = "env"; }
	else if (env.AMAGI_EVIDENCE_TEST_TIMEOUT_MS !== undefined && env.AMAGI_EVIDENCE_TEST_TIMEOUT_MS !== "") bad.push(`${ENV_TEST}=${env.AMAGI_EVIDENCE_TEST_TIMEOUT_MS}（合法区间 ${EVIDENCE_TEST_MS_MIN}–${EVIDENCE_TEST_MS_MAX} 整数毫秒）`);

	const envGit = parseEnvMs(env.AMAGI_EVIDENCE_GIT_TIMEOUT_MS, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	if (envGit !== undefined) { gitMs = envGit; source = "env"; }
	else if (env.AMAGI_EVIDENCE_GIT_TIMEOUT_MS !== undefined && env.AMAGI_EVIDENCE_GIT_TIMEOUT_MS !== "") bad.push(`${ENV_GIT}=${env.AMAGI_EVIDENCE_GIT_TIMEOUT_MS}（合法区间 ${EVIDENCE_GIT_MS_MIN}–${EVIDENCE_GIT_MS_MAX} 整数毫秒）`);

	const envSummary = parseEnvMs(env.AMAGI_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS, EVIDENCE_GIT_MS_MIN, EVIDENCE_GIT_MS_MAX);
	if (envSummary !== undefined) { summaryGitMs = envSummary; source = "env"; }
	else if (env.AMAGI_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS !== undefined && env.AMAGI_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS !== "") bad.push(`${ENV_SUMMARY_GIT}=${env.AMAGI_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS}（合法区间 ${EVIDENCE_GIT_MS_MIN}–${EVIDENCE_GIT_MS_MAX} 整数毫秒）`);

	// ev-20261011-ad4513：项目层（amagi.json evidenceTimeouts）在 env 之下、默认之上——
	// 仅补齐 env 未覆盖的字段（env 显式值优先；非法项目字段已在读取层过滤）。
	if (project !== undefined && project !== null) {
		if (envTest === undefined && project.testMs !== undefined) { testMs = project.testMs; if (source === "defaults") source = "project"; }
		if (envGit === undefined && project.gitMs !== undefined) { gitMs = project.gitMs; if (source === "defaults") source = "project"; }
		if (envSummary === undefined && project.summaryGitMs !== undefined) { summaryGitMs = project.summaryGitMs; if (source === "defaults") source = "project"; }
	}

	// task 层最高优先（显式人工 resume 可给新值；未给字段继承 env/默认）
	if (task !== undefined && task !== null) {
		validateEvidenceTimeouts(task); // 越界/非法直接抛（参数错误，不静默吞）
		let touched = false;
		if (task.testMs !== undefined) { testMs = task.testMs; touched = true; }
		if (task.gitMs !== undefined) { gitMs = task.gitMs; touched = true; }
		if (task.summaryGitMs !== undefined) { summaryGitMs = task.summaryGitMs; touched = true; }
		if (touched) source = "task";
	}

	return {
		testMs,
		gitMs,
		summaryGitMs,
		// 非法 env 一次性提示（对应字段回退——可能命中项目 amagi.json 层或默认；0 不代表无限）
		envWarning: bad.length > 0 ? `证据超时 env 配置非法，对应字段已回退（项目 amagi.json evidenceTimeouts 层或默认 test=${DEFAULT_EVIDENCE_TEST_TIMEOUT_MS}/git=${DEFAULT_EVIDENCE_GIT_TIMEOUT_MS}/summaryGit=${DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS} ms）: ${bad.join("；")}` : null,
		source,
	};
}

/**
 * 呈现模式（§5.4）：AMAGI_EVIDENCE_VIEW=legacy 回旧呈现；缺省/非法回 compact（安全默认）。
 * 只影响 renderer，不改 classifyFreshPaths 四档归因与 ±2min 窗口。
 */
export function resolveEvidenceView(env: Record<string, string | undefined> = process.env): EvidenceView {
	return env.AMAGI_EVIDENCE_VIEW === "legacy" ? "legacy" : "compact";
}

// ─────────────────────────────────────────────────────────────────────────────
// V2（方案 §8.5-V2 风险/回滚「关闭复用可重验」）：结构化检查证据复用开关
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 结构化检查复用开关（evidence.ts runStructuredCheck/checkReuseVerdict 消费）：
 * AMAGI_CHECK_REUSE=0|false 关闭后，即使对象/策略/实际 cwd+argv 完全一致也拒绝复用——
 * 每次重验重新执行（每次重验本就生成新对象/新 CheckResult，关闭复用只影响是否跳过执行）。
 * 非法/未设回开启（默认复用可用）。
 */
export function checkReuseEnabled(env: Record<string, string | undefined> = process.env): boolean {
	const v = env.AMAGI_CHECK_REUSE;
	return !(v === "0" || v === "false");
}
