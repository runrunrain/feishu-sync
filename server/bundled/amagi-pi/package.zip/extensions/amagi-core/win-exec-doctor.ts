/**
 * win-exec-doctor.ts — /amagi win-doctor 自检（用户在 Windows 真机上验证 win_exec 的唯一入口）。
 *
 * v2（diting 审核轮）：新增 配置信任状态（M3）、allowShells 状态（M2）、automount 实际根（m5）、
 * tasklist CSV 解析探测（M5）四项；Job Object 冒烟改用内嵌载荷脚本并断言 exit 91 建链失败
 * 分支存在于脚本文本（M7）。全部探测只读 + 一次 exit-0 冒烟（临时文件用后即删）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { execFile } from "node:child_process";
import { detectWslEnvironment } from "./win-exec.ts";
import { readWinExecConfig, readGlobalWinExecConfig, mergeWinExecConfig } from "./win-exec-config.ts";
import { cachedWindowsRoots, BUILTIN_PROGRAMS, resolveProgram, resetWinExecDiscovery, type WindowsRoots } from "./win-exec-discover.ts";
import { buildLauncherScript, encodeLauncherPayload } from "./win-exec-launcher.ts";
import { linuxToWindowsPath } from "./win-exec-paths.ts";
import { wslMntRoot, parseAutomountRoot, resetWslMntRootCache } from "./win-exec-mnt.ts";
import { parseTasklistCsv } from "./win-exec-run.ts";
import { winExecRoot } from "./win-exec-lock.ts";

export interface DoctorRow {
	status: "OK" | "WARN" | "FAIL";
	item: string;
	detail: string;
	fix?: string;
}

export interface WinDoctorDeps {
	cwd?: string;
	platform?: NodeJS.Platform;
	env?: NodeJS.ProcessEnv;
	/** M3：项目信任判定（缺省 false——如实显示不受信）。 */
	projectTrusted?: boolean;
	readProcVersion?: () => string;
	existsSync?: (p: string) => boolean;
	spawnSync?: typeof execFile;
	writeFile?: (p: string, content: string) => void;
	unlink?: (p: string) => void;
	readWslConf?: () => string;
}

function runRow(rows: DoctorRow[], status: DoctorRow["status"], item: string, detail: string, fix?: string): void {
	rows.push({ status, item, detail, ...(fix ? { fix } : {}) });
}

/** 执行 win-doctor 自检并渲染人读报告（每项 OK/WARN/FAIL + 修复建议）。 */
export function runWinDoctor(deps: WinDoctorDeps = {}): string {
	const rows: DoctorRow[] = [];
	const env = deps.env ?? process.env;
	const cwd = deps.cwd ?? process.cwd();
	const exists = deps.existsSync ?? ((p: string) => { try { return fs.existsSync(p); } catch { return false; /* lint-exempt:探测失败=不存在 */ } });
	const sync = deps.spawnSync;

	// 1. WSL 检测
	const det = detectWslEnvironment({ env, platform: deps.platform, readProcVersion: deps.readProcVersion });
	if (det.wsl) runRow(rows, "OK", "WSL 检测", `命中：${det.signals.join("；")}`);
	else runRow(rows, "FAIL", "WSL 检测", `未命中任何信号（${det.signals.join("；") || "无"}）`, "win_exec 仅在 WSL 内注册；非 WSL 会话本工具不应出现。若确在 WSL 里，检查 WSL_DISTRO_NAME/WSL_INTEROP 环境变量");

	// 2. interop binfmt
	const binfmtOk = ["/proc/sys/fs/binfmt_misc/WSLInterop", "/proc/sys/fs/binfmt_misc/WSLInterop-late"].some((p) => exists(p));
	if (binfmtOk) runRow(rows, "OK", "interop binfmt", "/proc/sys/fs/binfmt_misc/WSLInterop* 存在——Windows exe 可经 interop spawn");
	else runRow(rows, "WARN", "interop binfmt", "WSLInterop binfmt 注册项不存在", "检查 /etc/wsl.conf 是否禁用了 interop（interop=false 时 win_exec 无法执行 Windows 程序）；重启 WSL（wsl --shutdown）");

	// 3. AMAGI_WIN_* 环境变量
	const winEnvNames = ["AMAGI_WIN_SYSTEMROOT", "AMAGI_WIN_PROGRAMFILES", "AMAGI_WIN_LOCALAPPDATA", "AMAGI_WIN_USERPROFILE"];
	const present = winEnvNames.filter((k) => env[k]);
	runRow(rows, present.length === winEnvNames.length ? "OK" : "WARN", "AMAGI_WIN_* 环境变量", `${present.length}/${winEnvNames.length} 已注入${present.length ? `：${present.map((k) => `${k}=${env[k]}`).join("；")}` : ""}——缺失项依赖挂载根回退探测`, "amagi-codebox 1.3.126+ 会经 WSLENV 注入；手动会话可在 shell 配置 export（值为 <挂载根>/<盘>/… 形态）");

	// 4. m5：automount 实际根（诊断场景现读——重置缓存避免其它调用的 60s 快照遮蔽）
	resetWslMntRootCache();
	let confText = "";
	try { confText = deps.readWslConf ? deps.readWslConf() : fs.readFileSync("/etc/wsl.conf", "utf8"); } catch { confText = ""; /* lint-exempt:无 wsl.conf → 缺省 /mnt */ }
	const mntRoot = wslMntRoot(() => confText);
	if (mntRoot === "/mnt") runRow(rows, "OK", "automount 根", `实际挂载根 ${mntRoot}（缺省；/etc/wsl.conf 未见 [automount] root 自定义）`);
	else runRow(rows, "OK", "automount 根", `实际挂载根 ${mntRoot}（/etc/wsl.conf [automount] root 生效；解析形态：${parseAutomountRoot(confText)}）`);

	// 5. Windows 根发现（env 优先 + 回退探测；注入 env/existsSync 贯通）
	resetWinExecDiscovery();
	const roots: WindowsRoots = cachedWindowsRoots({ env, existsSync: exists }, mntRoot);
	if (roots.systemRoot) runRow(rows, "OK", "Windows 根发现", `systemRoot=${roots.systemRoot}${roots.programFiles ? ` · programFiles=${roots.programFiles}` : " · programFiles 未发现"}${roots.localAppData ? ` · localAppData=${roots.localAppData}` : ""}${roots.probedDrives.length ? `（回退探测命中 ${mntRoot}/${roots.probedDrives.join(",")}）` : ""}`);
	else runRow(rows, "FAIL", "Windows 根发现", "未能定位 Windows 根（env 与挂载根回退探测均未命中）", `export AMAGI_WIN_SYSTEMROOT=${mntRoot}/<盘>/Windows 后重试；确认 Windows 盘已挂载`);

	// 6. M3/M2：配置信任状态 + allowShells
	const trusted = deps.projectTrusted === true;
	const globalCfg = readGlobalWinExecConfig(env);
	const cfg = readWinExecConfig(cwd);
	const projectApplied = trusted ? cfg : { ...cfg, programs: new Map(), allowRoots: [], envAllow: [], groups: new Map(), allowShells: false, gitAllowDashC: false, problems: [...cfg.problems] };
	const applied = mergeWinExecConfig(globalCfg, projectApplied);
	if (trusted) runRow(rows, "OK", "配置信任状态", `项目受信（trust context）——windows.exec 全字段生效（programs=${cfg.programs.size} · allowRoots=${cfg.allowRoots.length} · groups=${cfg.groups.size}）`);
	else runRow(rows, "WARN", "配置信任状态", "项目 amagi.json 未受信——programs/allowRoots/groups/envAllow/allowShells/gitAllowDashC 已忽略（仅 enabled=false 生效）；安全敏感配置请放全局 amagi.json", "在具备确认渠道的会话建立项目信任，或把 windows.exec 安全字段迁移到 ~/.pi/agent/amagi.json");
	if (cfg.enabled === false) runRow(rows, "WARN", "windows.exec.enabled", "配置显式关闭（false）——win_exec 不注册", "需要时改为 true 或删除该键");
	runRow(rows, applied.allowShells ? "WARN" : "OK", "allowShells", applied.allowShells ? "已放开——powershell/cmd 可被模型调用（等同放开 shell 面，确认这是受信配置的本意）" : "关闭（默认）——powershell/cmd 不对模型开放；.ps1/.bat 经 allowRoots 放行不受影响");
	if (cfg.problems.length > 0) {
		runRow(rows, "WARN", "windows.exec 配置", `${cfg.problems.length} 条非法条目被跳过：${cfg.problems.slice(0, 5).join("；")}${cfg.problems.length > 5 ? "…" : ""}`, "按上述提示修正 amagi.json windows 段");
	}

	// 7. 内置程序解析表（M2：shells/内部专用如实标注）
	const missing: string[] = [];
	for (const spec of BUILTIN_PROGRAMS) {
		// 解析用 internal 视角（shells 存在性与内部中转可用性）；模型面开闭由 note 如实标注
		const res = resolveProgram(spec.name, { programs: applied.programs, allowRoots: applied.allowRoots, allowShells: applied.allowShells }, roots, { existsSync: exists, purpose: "internal" });
		if (res.ok) {
			const note = (spec.name === "powershell" || spec.name === "cmd")
				? (applied.allowShells ? "（模型面已放开：allowShells=true）" : "（模型面关闭：allowShells=false；内部中转可用）")
				: spec.name === "taskkill" || spec.name === "tasklist" ? "（内部通道专用，不对模型开放）" : "";
			runRow(rows, "OK", `程序 ${spec.name}`, `${res.program.windowsPath}（${res.program.source}）${note}`);
		} else {
			missing.push(spec.name);
			runRow(rows, "WARN", `程序 ${spec.name}`, res.reason.split("\n")[0] ?? "未解析", "在受信 windows.exec.programs 显式映射完整路径");
		}
	}

	// 8. cmd.exe /c ver 往返
	const cmdRes = resolveProgram("cmd", { programs: applied.programs, allowRoots: applied.allowRoots, allowShells: applied.allowShells }, roots, { existsSync: exists, purpose: "internal" });
	if (cmdRes.ok && sync) {
		try {
			const r = sync(cmdRes.program.linuxPath, ["/d", "/s", "/c", "ver"], { timeout: 15_000 }) as unknown as { status: number | null; stdout?: string };
			if (r.status === 0) runRow(rows, "OK", "cmd.exe 往返", String(r.stdout ?? "").replace(/\r\n/g, "\n").trim());
			else runRow(rows, "FAIL", "cmd.exe 往返", `exit=${r.status}`, "核对 interop（wsl --shutdown 后重开；/etc/wsl.conf interop 配置）");
		} catch (e) {
			runRow(rows, "FAIL", "cmd.exe 往返", `spawn 异常：${e instanceof Error ? e.message : String(e)}`, "interop binfmt 不可用（见上）或 cmd.exe 路径错误");
		}
	} else {
		runRow(rows, "FAIL", "cmd.exe 往返", "cmd.exe 未解析或探测通道不可用，跳过", "先修复 Windows 根发现/程序解析");
	}

	// 9. chcp 编码探测
	if (cmdRes.ok && sync) {
		try {
			const r = sync(cmdRes.program.linuxPath, ["/d", "/s", "/c", "chcp"], { timeout: 15_000 }) as unknown as { status: number | null; stdout?: string };
			const m = /(\d{3,})/.exec(String(r.stdout ?? ""));
			if (m) runRow(rows, "OK", "编码探测", `活动代码页 ${m[1]}（输出回退解码标签：${cfg.fallbackEncoding ?? "gbk"}）`, m[1] === "936" || m[1] === "65001" ? undefined : "非 936/65001 代码页：如输出乱码，配置 windows.exec.fallbackEncoding（如 big5/shift_jis）");
			else runRow(rows, "WARN", "编码探测", `chcp 输出无法解析：${String(r.stdout ?? "").trim()}`);
		} catch (e) {
			runRow(rows, "WARN", "编码探测", `chcp 探测异常：${e instanceof Error ? e.message : String(e)}`);
		}
	}

	// 10. M5：tasklist CSV 解析探测（真实往返 + 列位置解析健全性）
	const tasklistRes = resolveProgram("tasklist", { programs: applied.programs, allowRoots: applied.allowRoots }, roots, { existsSync: exists, purpose: "internal" });
	if (tasklistRes.ok && sync) {
		try {
			const r = sync(tasklistRes.program.linuxPath, ["/FO", "CSV", "/NH"], { timeout: 15_000 }) as unknown as { status: number | null; stdout?: string };
			const parsed = parseTasklistCsv(String(r.stdout ?? ""));
			if (r.status === 0 && parsed.length > 0) runRow(rows, "OK", "tasklist CSV 解析", `真实往返解析 ${parsed.length} 行（首行 ${parsed[0]!.image} pid ${parsed[0]!.pid}；按列位置解析，本地化免疫）`);
			else runRow(rows, "WARN", "tasklist CSV 解析", `解析 ${parsed.length} 行（exit=${r.status}）——PID 快照差集回收将降级为「只记录不杀并如实报告」`, "核对 tasklist 输出形态；win_exec 超时回收依赖该解析");
		} catch (e) {
			runRow(rows, "WARN", "tasklist CSV 解析", `探测异常：${e instanceof Error ? e.message : String(e)}——差集回收将如实降级`);
		}
	} else {
		runRow(rows, "WARN", "tasklist CSV 解析", "tasklist.exe 未解析——差集回收不可用（起前清扫的组将被拒绝）", "修复程序解析后重跑");
	}

	// 11. Job Object 启动脚本冒烟（M7：断言建链失败分支 + exit 0 往返）
	const psRes = resolveProgram("powershell", { programs: applied.programs, allowRoots: applied.allowRoots, allowShells: applied.allowShells }, roots, { existsSync: exists, purpose: "internal" });
	if (psRes.ok && det.wsl) {
		const scriptDir = roots.localAppData ? path.posix.join(roots.localAppData, "Temp") : (roots.userProfile ?? path.posix.join(mntRoot, "c"));
		const scriptLinux = path.posix.join(scriptDir, `amagi-win-doctor-${Date.now().toString(36)}.ps1`);
		let wrote = false;
		try {
			const payload = encodeLauncherPayload({ program: cmdRes.ok ? cmdRes.program.windowsPath : "C:\\Windows\\System32\\cmd.exe", argsLine: '/d /s /c exit 0', cwd: "", env: {} });
			const scriptText = buildLauncherScript(payload);
			if (!/exit 91/.test(scriptText)) throw new Error("脚本文本缺少 Job 建链失败 exit 91 分支（M7）");
			(deps.writeFile ?? ((p, c) => fs.writeFileSync(p, c, "utf8")))(scriptLinux, scriptText);
			wrote = true;
			const winPath = linuxToWindowsPath(scriptLinux, { mntRoot });
			if (winPath === null) throw new Error(`脚本路径无法翻译为 Windows 形态：${scriptLinux}`);
			if (sync) {
				const r = sync(psRes.program.linuxPath, ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", winPath], { timeout: 30_000 }) as unknown as { status: number | null; stdout?: string; stderr?: string };
				if (r.status === 0) runRow(rows, "OK", "Job Object 脚本冒烟", "powershell -File 内嵌载荷脚本 exit 0 往返成功（建链失败分支 exit 91 已在脚本文本断言）");
				else if (r.status === 91) runRow(rows, "FAIL", "Job Object 脚本冒烟", "exit 91：Job 建链失败（CreateJobObject/SetInformation/Assign 之一）", "检查 Windows 版本 Job Object 权限（容器/沙箱环境常见）；supervised 模式不可用，direct 模式不受影响");
				else runRow(rows, "FAIL", "Job Object 脚本冒烟", `exit=${r.status}：${String(r.stderr ?? r.stdout ?? "").slice(0, 300)}`, "检查 ExecutionPolicy/临时目录写权限");
			} else {
				runRow(rows, "WARN", "Job Object 脚本冒烟", "探测通道不可用——仅完成脚本文本静态断言（exit 91 分支在位）");
			}
		} catch (e) {
			runRow(rows, "FAIL", "Job Object 脚本冒烟", `异常：${e instanceof Error ? e.message : String(e)}`, "核对临时目录可写与 powershell 可用");
		} finally {
			if (wrote || exists(scriptLinux)) { try { (deps.unlink ?? ((p) => fs.unlinkSync(p)))(scriptLinux); } catch { /* lint-exempt:清理失败 → 临时残留无害 */ } }
		}
	} else {
		runRow(rows, "WARN", "Job Object 脚本冒烟", "powershell.exe 未解析或非 WSL——跳过", "修复程序解析后重跑 /amagi win-doctor");
	}

	// 渲染
	const order = { FAIL: 0, WARN: 1, OK: 2 } as const;
	rows.sort((a, b) => order[a.status] - order[b.status]);
	const counts = { OK: 0, WARN: 0, FAIL: 0 };
	for (const r of rows) counts[r.status]++;
	return [
		`[amagi win-doctor] win_exec 自检（cwd=${cwd} · 挂载根=${mntRoot} · 项目受信=${trusted ? "是" : "否"}）：OK ${counts.OK} · WARN ${counts.WARN} · FAIL ${counts.FAIL}`,
		...rows.map((r) => `[${r.status}] ${r.item}：${r.detail}${r.fix ? `\n       ↳ 修复建议：${r.fix}` : ""}`),
		`说明：FAIL 项会阻断对应能力（注册/interop/解析）；WARN 为降级可用。诊断数据目录：${winExecRoot()}。`,
	].join("\n");
}
