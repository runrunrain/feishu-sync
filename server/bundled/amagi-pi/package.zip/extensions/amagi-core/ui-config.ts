/**
 * ui-config.ts — amagi.json `ui` 段读取（面板与交互优化 M1-03；技术方案 §10）。
 *
 * 独立小读取器：model-resolver 的 UserConfig 校验白名单不含 ui 键（会被剥除），
 * 且 UI 侧只需三组键位 + 面板参数 + 横幅开关；与模型解析无耦合，不引入缓存竞态。
 * 合并序：项目 <cwd>/amagi.json 的 ui 键优先于全局 ~/.pi/agent/amagi.json（与模型配置同序）。
 * 解析容错：损坏/缺省一律回退默认；键值数组元素去重去空。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export interface UiKeysConfig {
	board: string[];
	tasks: string[];
	review: string[];
}

export interface UiConfig {
	keys: UiKeysConfig;
	panelMaxLines?: number;
	shortcutHint?: boolean;
}

export const DEFAULT_UI_KEYS: UiKeysConfig = {
	// 键位审计（pi 0.84.2 全量默认表 + pi-tui TUI_KEYBINDINGS）：alt+w/r/t 空闲；
	// alt+b 被 tui.editor.cursorWordLeft 占用，故 tasks 用 ⌥T（助记 T=Tasks）。
	board: ["alt+w", "ctrl+shift+w"],
	tasks: ["alt+t", "ctrl+shift+b"],
	review: ["alt+r", "ctrl+shift+r"],
};

export const DEFAULT_PANEL_MAX_LINES = 12;

function readUiSection(file: string): Partial<UiConfig> {
	try {
		const raw = JSON.parse(fs.readFileSync(file, "utf8"));
		const ui = raw && typeof raw === "object" ? (raw as Record<string, unknown>).ui : undefined;
		if (!ui || typeof ui !== "object") return {};
		const out: Partial<UiConfig> = {};
		const keys = (ui as Record<string, unknown>).keys;
		if (keys && typeof keys === "object") {
			const k = keys as Record<string, unknown>;
			const norm = (v: unknown, def: string[]): string[] => {
				if (typeof v === "string") return [v];
				if (Array.isArray(v)) {
					const arr = v.filter((x): x is string => typeof x === "string" && x.trim() !== "").map((x) => x.trim().toLowerCase());
					return arr.length > 0 ? [...new Set(arr)] : def;
				}
				return def;
			};
			out.keys = {
				board: norm(k.board, DEFAULT_UI_KEYS.board),
				tasks: norm(k.tasks, DEFAULT_UI_KEYS.tasks),
				review: norm(k.review, DEFAULT_UI_KEYS.review),
			};
		}
		const panel = (ui as Record<string, unknown>).panel;
		if (panel && typeof panel === "object") {
			const ml = (panel as Record<string, unknown>).maxLines;
			if (typeof ml === "number" && Number.isFinite(ml)) out.panelMaxLines = Math.max(6, Math.min(24, Math.floor(ml)));
		}
		const hint = (ui as Record<string, unknown>).shortcutHint;
		if (typeof hint === "boolean") out.shortcutHint = hint;
		return out;
	} catch {
		return {}; // 不存在/损坏 → 默认
	}
}

/** 读取合并后的 ui 配置（项目优先）。测试可注入路径。 */
export function readUiConfig(cwd?: string, inject?: { globalPath?: string; projectPath?: string }): UiConfig {
	const globalPath = inject?.globalPath ?? path.join(process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent"), "amagi.json");
	const projectPath = inject?.projectPath ?? (cwd ? path.join(cwd, "amagi.json") : null);
	const g = readUiSection(globalPath);
	const p = projectPath ? readUiSection(projectPath) : {};
	const keys: UiKeysConfig = {
		board: p.keys?.board ?? g.keys?.board ?? DEFAULT_UI_KEYS.board,
		tasks: p.keys?.tasks ?? g.keys?.tasks ?? DEFAULT_UI_KEYS.tasks,
		review: p.keys?.review ?? g.keys?.review ?? DEFAULT_UI_KEYS.review,
	};
	return {
		keys,
		panelMaxLines: p.panelMaxLines ?? g.panelMaxLines ?? DEFAULT_PANEL_MAX_LINES,
		shortcutHint: p.shortcutHint ?? g.shortcutHint ?? true,
	};
}
