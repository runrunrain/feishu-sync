/**
 * session-repair.ts — 400 tool 消息序自愈（2026-08-16 战斗模拟复盘 P0-1）。
 *
 * 实战根因（复盘终验段 2 次死派发）：provider 对会话历史回放报 400
 * 「Messages with role 'tool' must be a response to a preceding message with 'tool_calls'」——
 * session JSONL 中出现孤儿 toolResult（其 toolCallId 不在前序 assistant 消息的 toolCall 集合内）
 * 或悬挂 toolCall（assistant 发出后始终没有对应 toolResult，或被 user 消息隔断）。
 * resume 回放 poisoned 历史必然复现；fresh 派发也可在运行中段写入损坏行。
 *
 * 修复策略：读取 pi 的当前分支、压缩与 context_edit 投影；仅在实际投影有孤儿/悬挂时
 * 使用公开 forkFrom 创建独立恢复会话，保留完整树，再追加 context_edit 排除无效上下文。
 * 源文件始终只读，无错误零落盘；不支持的旧格式/宿主、非法父链或解析失败交回 fresh 恢复。
 *
 * 开关：AMAGI_SESSION_REPAIR=0 关闭（调用方判定）；重派轮数由调用方有界控制。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as piHost from "@earendil-works/pi-coding-agent";

/** provider 400 tool 消息序签名（OpenAI 系兼容端点的已知变体，保守匹配避免误吞其他 400）。 */
const TOOL_ORDER_400_RES: RegExp[] = [
	/must be a response to a preceding message with ['"]?tool_calls['"]?/i,
	/messages? with role ['"]?tool['"]? .*(follow|preceding|response)/i,
	/tool_calls?['"]? .* (must be followed|must be responded)/i,
	/(tool_use|tool_result) .*(blocks?|message).*(without|missing).*(matching|preceding)/i,
];

/** 上下文超限签名（复盘 P0-2：401 context 上限死派发的恢复指引触发器）。 */
const CONTEXT_LIMIT_RES: RegExp[] = [
	/context (length|window|size|limit)/i,
	/maximum.{0,20}(context|token|prompt) (length|size|limit)/i,
	/too many (input )?tokens/i,
	/input.{0,20}(is )?too long/i,
	/exceeds? the (maximum|model).{0,20}(context|token|input)/i,
	/reduce the (length|number) of (the )?(messages|tokens|prompt)/i,
	/token limit (exceeded|reached)/i,
];

export function isToolOrder400(text?: string | null): boolean {
	if (!text) return false;
	return TOOL_ORDER_400_RES.some((re) => re.test(text));
}

export function isContextLimitError(text?: string | null): boolean {
	if (!text) return false;
	return CONTEXT_LIMIT_RES.some((re) => re.test(text));
}

/** session-repair 总开关（AMAGI_SESSION_REPAIR=0 关闭；缺省开）。 */
export function sessionRepairEnabled(): boolean {
	return process.env.AMAGI_SESSION_REPAIR !== "0";
}

// ── session 文件定位 ──────────────────────────────────────────────────────────

function agentRoot(): string {
	return process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

export interface LocateOpts {
	/** 测试注入：sessions 根目录（缺省 <agentRoot>/sessions）。 */
	sessionsRoot?: string;
	/** 项目 cwd（优先扫对应项目目录，兜底全量——resume 跨 cwd 时会话可能在别的项目目录）。 */
	cwd?: string;
}

/**
 * 按 sessionId 定位 pi session JSONL（文件名 `<ts>_<sessionId>.jsonl`）。
 * 找不到返回 null（不抛错）。扫描有界：优先 cwd 对应项目目录，其次 sessions 根一级子目录。
 */
export function locateSessionJsonl(sessionId: string, opts?: LocateOpts): string | null {
	if (!sessionId || /[/\\\s]/.test(sessionId)) return null;
	const root = opts?.sessionsRoot || path.join(agentRoot(), "sessions");
	const projectDirs: string[] = [];
	if (opts?.cwd) projectDirs.push(path.join(root, "--" + opts.cwd.split(/[\\/]+/).filter(Boolean).join("-") + "--"));
	projectDirs.push(root);
	const suffix = `_${sessionId}.jsonl`;
	for (const dir of projectDirs) {
		let entries: string[];
		try { entries = fs.readdirSync(dir); } catch { continue; }
		for (const f of entries) {
			if (f.endsWith(suffix)) {
				const full = path.join(dir, f);
				try { if (fs.statSync(full).isFile()) return full; } catch { /* 竞态忽略 */ }
			}
		}
	}
	return null;
}

// ── 孤儿/悬挂消息清理 ─────────────────────────────────────────────────────────

export interface SessionRepairResult {
	ok: boolean;
	/** 源会话文件：只读，修复不会改写或删除它的历史。 */
	file?: string;
	/** 在当前分支投影中排除的孤儿 toolResult 数量（不是删除历史行）。 */
	droppedToolResults: number;
	/** 在当前分支投影中排除的悬挂 toolCall 数量。 */
	droppedToolCalls: number;
	/** 原生 fork + context_edit 生成的独立恢复会话。 */
	recoveryFile?: string;
	sessionId?: string;
	/** 旧回流字段兼容；新修复不生成备份，因为源会话始终保留。 */
	backup?: string;
	error?: string;
}

type RepairContent = import("@earendil-works/pi-coding-agent").ContextEditEntry["replacement"];
interface PendingAssistant {
	entryId: string;
	content: unknown[];
	calls: Set<string>;
}

/** 按原生当前分支/压缩/context_edit 投影生成修正；不直接操作原始历史。 */
function repairProjection(projection: import("@earendil-works/pi-coding-agent").SessionProjection) {
	const edits = new Map<string, RepairContent>();
	let pending: PendingAssistant | undefined;
	let droppedToolResults = 0;
	let droppedToolCalls = 0;
	const stripPending = () => {
		if (pending?.calls.size) {
			droppedToolCalls += pending.calls.size;
			const content = pending.content.filter((block) => {
				const b = block as { type?: string; id?: string };
				return !(b?.type === "toolCall" && typeof b.id === "string" && pending!.calls.has(b.id));
			});
			edits.set(pending.entryId, content.length ? { content: content as NonNullable<RepairContent>["content"] } : null);
		}
		pending = undefined;
	};
	for (const entry of projection.entries) {
		for (const message of entry.messages) {
			const m = message as { role: string; content?: unknown; toolCallId?: string };
			if (m.role === "assistant") {
				stripPending();
				if (entry.sourceEntry.type !== "message" || !Array.isArray(m.content)) continue;
				const calls = new Set<string>();
				for (const block of m.content) {
					const b = block as { type?: string; id?: string };
					if (b?.type === "toolCall" && typeof b.id === "string") calls.add(b.id);
				}
				if (calls.size) pending = { entryId: entry.sourceEntry.id, content: m.content, calls };
			} else if (m.role === "toolResult") {
				if (m.toolCallId && pending?.calls.has(m.toolCallId)) pending.calls.delete(m.toolCallId);
				else if (entry.sourceEntry.type === "message") {
					edits.set(entry.sourceEntry.id, null);
					droppedToolResults++;
				}
			} else {
				stripPending();
			}
		}
	}
	stripPending();
	return { edits, droppedToolResults, droppedToolCalls };
}

/**
 * 只读检查源会话；确有错误时以原生 forkFrom 保留完整树，在独立会话追加 context_edit。
 * 无错误零落盘；不可解析/不支持的宿主能力拒绝自动修复，交回 fresh 恢复。
 */
export function sanitizeSessionFile(file: string): SessionRepairResult {
	const empty: SessionRepairResult = { ok: false, file, droppedToolResults: 0, droppedToolCalls: 0 };
	let recoveryFile: string | undefined;
	try {
		const raw = fs.readFileSync(file, "utf8");
		// 原生 parser 对非法行宽容跳过；自动恢复不能把这种跳过当作完整会话验证。
		for (const line of raw.split("\n")) if (line.trim()) JSON.parse(line);
		const entries = piHost.parseSessionEntries(raw);
		const header = entries.find((entry) => entry.type === "session");
		if (!header) throw new Error("源会话缺少 session header");
		if (header.version !== 3) throw new Error("旧会话格式须先经宿主迁移副本，不自动改写源会话");
		const sourceEntries = entries.filter((entry): entry is import("@earendil-works/pi-coding-agent").SessionEntry => entry.type !== "session");
		const ids = new Set<string>();
		for (const entry of sourceEntries) {
			// pi 的追加树只能引用已经存在的父节点；同时拒绝重复、环与向前引用。
			if (typeof entry.id !== "string" || ids.has(entry.id) ||
				(entry.parentId !== null && !ids.has(entry.parentId))) {
				throw new Error("源会话分支引用非法，不执行工具消息修复");
			}
			ids.add(entry.id);
		}
		if (typeof piHost.buildSessionProjection !== "function" ||
			typeof piHost.SessionManager.forkFrom !== "function" ||
			typeof piHost.SessionManager.prototype.appendContextEdit !== "function") {
			throw new Error("宿主缺少原生投影/fork/context_edit 能力，不自动改写历史");
		}
		const projection = piHost.buildSessionProjection(sourceEntries);
		const plan = repairProjection(projection);
		if (!plan.edits.size) return { ...empty, ok: true };
		const cwd = typeof header.cwd === "string" && header.cwd ? header.cwd : process.cwd();
		// forkFrom 不打开/迁移源文件；原生新会话保留分支、压缩、标签和原有 context_edit。
		const recovery = piHost.SessionManager.forkFrom(file, cwd, path.dirname(file));
		recoveryFile = recovery.getSessionFile();
		if (!recoveryFile) throw new Error("宿主未创建恢复会话文件");
		// 源文件被外部写者改变时不能应用旧投影的修正。
		if (fs.readFileSync(file, "utf8") !== raw) throw new Error("检查期间源会话已变化，拒绝应用过期修正");
		for (const [targetId, content] of plan.edits) recovery.appendContextEdit(targetId, content);
		const remaining = repairProjection(recovery.buildSessionProjection());
		if (remaining.edits.size) throw new Error("恢复会话投影仍有孤儿/悬挂，拒绝续跑");
		return { ok: true, file, recoveryFile, sessionId: recovery.getSessionId(),
			droppedToolResults: plan.droppedToolResults, droppedToolCalls: plan.droppedToolCalls };
	} catch (e) {
		// 只移除本次创建但未完成的恢复副本，源会话从不写入。
		if (recoveryFile) try { fs.unlinkSync(recoveryFile); } catch { /* lint-exempt:清理本次副本尽力而为 */ }
		return { ...empty, error: e instanceof Error ? e.message : String(e) };
	}
}

/** 修复结果 → 面向回流的一行摘要。 */
export function repairSummary(r: SessionRepairResult): string {
	if (!r.ok) return `[400 消息序自愈失败] ${r.error || "未知原因"}——改用 fresh 派发恢复（resume 本 session 会复现 400）`;
	return `[400 消息序自愈] 当前分支投影排除孤儿 toolResult ${r.droppedToolResults} 条/悬挂 toolCall ${r.droppedToolCalls} 块；源会话保留${r.recoveryFile ? `，独立恢复会话 ${path.basename(r.recoveryFile)}` : ""}，自动续跑一轮`;
}

/**
 * 修复决策（2026-08-19 增补 transient 分支）：
 *  - 有清除项 → "redispatch"：当前分支投影需修正，在独立恢复会话续跑；
 *  - ok 且零清除 → "transient-retry"：当前分支投影未发现孤儿/悬挂，400 可能是 provider 端瞬时误拒
 *    （Kimi 过载窗口实测：同一会话 payload 原样回放返回 200），此时不重派=任务必死，
 *    原地有界重试一轮即可自愈；
 *  - !ok → "none"：修复失败，调用方降级为定向提示。
 */
export type RepairAction = "redispatch" | "transient-retry" | "none";
export function repairAction(r: SessionRepairResult): RepairAction {
	if (!r.ok) return "none";
	return r.droppedToolResults > 0 || r.droppedToolCalls > 0 ? "redispatch" : "transient-retry";
}

/** 瞬时误拒场景的续跑 nudge（会话校验干净，明示非历史损坏，避免子 Agent 误判要重做）。 */
export const TRANSIENT_400_NUDGE =
	"[amagi 400 消息序自愈] 上一轮被 provider 以「400 tool 消息序」拒绝，当前分支投影未发现孤儿 toolResult 或悬挂 toolCall，可能是 provider 端瞬时误拒。本次保留源会话并有界重试一轮；原任务不变，已完成的步骤无需重做，请继续执行。";

/** 瞬时误拒重试注记（回流可见，与 repairSummary 的「已清除 N 条」区分开）。 */
export function transientRepairSummary(): string {
	return "[400 消息序自愈] 当前分支投影未发现孤儿/悬挂，可能是 provider 端瞬时误拒，保留源会话并有界重试一轮";
}

/** 瞬时误拒重试前的短等待 ms（过载窗口通常持续数十秒~数分钟）；AMAGI_SESSION_REPAIR_TRANSIENT_DELAY_MS 可调，0 不等。 */
export function transientRetryDelayMs(): number {
	return Math.max(0, parseInt(process.env.AMAGI_SESSION_REPAIR_TRANSIENT_DELAY_MS ?? "15000", 10) || 0);
}

/**
 * 一步式修复入口：按 sessionId 定位并清理。找不到文件 → ok:false（调用方降级为提示）。
 */
export function repairSessionById(sessionId: string, opts?: LocateOpts): SessionRepairResult {
	const file = locateSessionJsonl(sessionId, opts);
	if (!file) return { ok: false, droppedToolResults: 0, droppedToolCalls: 0, error: `sessions 目录未定位到 ${sessionId}` };
	return sanitizeSessionFile(file);
}
