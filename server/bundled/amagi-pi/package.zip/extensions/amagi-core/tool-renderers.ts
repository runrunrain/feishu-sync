/**
 * tool-renderers.ts — B4（十月迭代设计 §5.1）：pi.registerToolRenderer 注册面（TUI 工具卡）。
 *
 * 职责：
 *  1. 能力门：registerToolRenderer 是 pi 1.0.1+ 能力（host-capabilities A2 已入表，
 *     kind=runtime-probe）——经 resolveHostCapabilities 探测；旧宿主（0.99.1 及更早，
 *     API 不存在）**优雅降级为零注册不报错**（registered=false，旧渲染路径不变）。
 *  2. resolver：amagi 自有工具（PRESENTATION_TOOL_NAMES）→ 本模块卡片渲染器；其它
 *     工具 `next()` 原样保留（§5.1；next() 返回余链+已注册工具的 renderers，不吞别人）。
 *  3. 实时 wire 投影缓存：宿主 ToolExecutionComponent 调 renderResult 时只传
 *     {content, details}——**不携带 structuredContent/isError**（dist 实证：
 *     modes/interactive/components/tool-execution.js updateDisplay 只取
 *     content/details 两键；isError 在 ToolRenderContext 上）。本模块经
 *     pi.on("tool_execution_end")（事件载荷含完整 result）捕获 wire 投影，以
 *     toolCallId 关联到 renderer；事件序实证（agent-session.js _handleAgentEvent：
 *     await _emitExtensionEvent → _emit）扩展先于 TUI 监听器收到事件——渲染时缓存已就位。
 *     缓存界（§5.1）：≤256 条 / ≤1 MiB（FIFO 淘汰）；session_start（任意 reason）与
 *     session_tree（分支切换）即清空——不跨会话/分支复用；淘汰或未命中回 details/text 档。
 *  4. 历史边界（与 tool-presentation 分层一致）：resume 历史（ToolResultMessage）无
 *     structuredContent——details 档（可证明字段）/text 档（原文+「历史无结构化数据」
 *     注记），不伪造结构、不查当前状态替换历史。
 *
 * 零新增运行时包依赖：组件按 pi-tui Component 契约**结构化实现**（render(width)→
 * string[]，同 workflow-board/session-viewer 手法）；宿主类型仅 type-only import。
 * 回滚：能力门关闭（或 Leader 撤掉 index.ts 接线）即整体回退宿主默认渲染，wire 与
 * 任务数据零迁移。
 */
import type {
	ToolRendererResolver,
	ToolRenderers,
	ToolRenderResultOptions,
} from "@earendil-works/pi-coding-agent";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { resolveHostCapabilities } from "./host-capabilities.ts";
import {
	projectToolPresentation,
	isAmagiPresentationTool,
	sanitizePresentationText,
	type ToolPresentation,
} from "./tool-presentation.ts";

// ── 宿主面（结构化最小表面；测试可注入弱宿主验证降级） ────────────────────────

/** pi.on 的可退订句柄（0.86+ 返回 unsubscribe；忽略返回值亦可）。 */
type OnFn = (event: string, handler: (event: unknown, ctx: unknown) => void | Promise<void>) => unknown;

export interface ToolRendererHostSurface {
	/** 1.0.1+ 渲染 resolver 注册面；旧宿主缺席（能力门判据）。 */
	registerToolRenderer?: (resolver: ToolRendererResolver) => void;
	on?: OnFn;
}

/** theme.fg 的结构化最小表面（缺省不着色——测试/无主题环境）。 */
export type ThemeLike = { fg?(color: string, text: string): string } | undefined;

function paint(theme: ThemeLike, color: string, text: string): string {
	try { return theme?.fg ? theme.fg(color, text) : text; } catch { /* lint-exempt:宿主主题缺色不反噬渲染 */ return text; }
}

/** 语义卡行渲染配色（success/error/unknown → 宿主主题色键；与 workflow-board 同键空间）。 */
function outcomeColor(outcome: ToolPresentation["outcome"]): string {
	if (outcome === "error") return "error";
	if (outcome === "success") return "success";
	return "muted";
}

// ── LinesComponent（pi-tui Component 契约结构化实现；零 pi-tui import） ────────

export interface LinesComponent {
	render(width: number): string[];
	invalidate(): void;
}

function linesComponent(lines: string[]): LinesComponent {
	return {
		render(_width: number): string[] { return lines.slice(); },
		invalidate(): void { /* 行集不可变——无需失效处理 */ },
	};
}

// ── 实时 wire 投影缓存（§5.5 界：256 条 / 1 MiB；切会话/切分支清空） ───────────

export const WIRE_PRESENTATION_CACHE_MAX_ENTRIES = 256;
export const WIRE_PRESENTATION_CACHE_MAX_BYTES = 1024 * 1024;

function presentationBytes(p: Readonly<ToolPresentation>): number {
	try { return JSON.stringify(p)?.length ?? 0; } catch { /* lint-exempt:投影为纯 JSON 值，序列化仅防御 */ return 0; }
}

/** 有界投影缓存（FIFO 淘汰；只存 wire 档——details/text 渲染时可从 result 重推导）。 */
export class WirePresentationCache {
	#map = new Map<string, ToolPresentation>();
	#bytes = 0;
	#maxEntries: number;
	#maxBytes: number;

	constructor(maxEntries = WIRE_PRESENTATION_CACHE_MAX_ENTRIES, maxBytes = WIRE_PRESENTATION_CACHE_MAX_BYTES) {
		this.#maxEntries = maxEntries;
		this.#maxBytes = maxBytes;
	}

	get size(): number { return this.#map.size; }
	get bytes(): number { return this.#bytes; }

	set(toolCallId: string, presentation: ToolPresentation): void {
		const prev = this.#map.get(toolCallId);
		if (prev) this.#bytes -= presentationBytes(prev);
		this.#map.delete(toolCallId);
		this.#map.set(toolCallId, presentation);
		this.#bytes += presentationBytes(presentation);
		while (this.#map.size > this.#maxEntries || this.#bytes > this.#maxBytes) {
			const oldest = this.#map.keys().next();
			if (oldest.done) break;
			const evicted = this.#map.get(oldest.value);
			this.#map.delete(oldest.value);
			if (evicted) this.#bytes -= presentationBytes(evicted);
		}
	}

	get(toolCallId: string): ToolPresentation | undefined {
		return this.#map.get(toolCallId);
	}

	clear(): void {
		this.#map.clear();
		this.#bytes = 0;
	}
}

/** renderer 上下文的最小结构面（宿主 ToolRenderContext 子集；isError 实证在 ctx 上）。 */
export interface RenderContextLike {
	toolCallId?: string;
	isError?: boolean;
	/** pi 1.1.0 原生 execute 耗时；旧宿主/历史/运行中可缺席，不补算。 */
	durationMs?: number;
}

/** 事件捕获处理器（registerAmagiToolRenderers 内部接线；导出供测试直接驱动）。 */
export function createPresentationEventCapture(cache: WirePresentationCache): {
	onToolExecutionEnd(event: unknown): void;
	onSessionBoundary(): void;
} {
	return {
		onToolExecutionEnd(event: unknown): void {
			const e = event as { toolName?: unknown; toolCallId?: unknown; result?: { structuredContent?: unknown; details?: unknown; content?: unknown } } | null;
			if (!e || typeof e.toolName !== "string" || typeof e.toolCallId !== "string") return;
			if (!isAmagiPresentationTool(e.toolName)) return;
			const content = Array.isArray(e.result?.content)
				? (e.result.content as ReadonlyArray<{ type?: string; text?: unknown }>) : undefined;
			const presentation = projectToolPresentation(e.toolName, {
				content,
				details: e.result?.details,
				structuredContent: e.result?.structuredContent,
				isError: (event as { isError?: unknown } | null)?.isError === true,
			});
			if (presentation && presentation.source === "wire") cache.set(e.toolCallId, presentation); // 只缓存 wire 档（其余档渲染时可重推导）
		},
		onSessionBoundary(): void {
			cache.clear(); // session_start（任意 reason）/ session_tree（分支切换）——不跨代复用
		},
	};
}

// ── 卡片行渲染（纯函数；theme 可缺省——测试断言无色文本） ──────────────────────

/** 展开态原文行上限（与宿主 fallback preview 同量级；防止超长结果刷屏）。 */
export const PRESENTATION_EXPANDED_LINES = 20;

/** 历史无结构化数据注记（§5.1 tier-3 冻结文案语义）。 */
export const NO_STRUCTURE_NOTE = "历史无结构化数据——以下为原文（未查询当前状态补数据）";

export function renderPresentationLines(
	presentation: Readonly<ToolPresentation>,
	options: { expanded?: boolean; isPartial?: boolean } = {},
	theme?: ThemeLike,
	originalText?: string,
): string[] {
	if (options.isPartial) return [paint(theme, "warning", "⋯ 执行中 …")];
	const lines: string[] = [];
	const mark = presentation.outcome === "error" ? "●" : presentation.outcome === "success" ? "●" : "○";
	lines.push(paint(theme, outcomeColor(presentation.outcome), `${mark} ${presentation.title}`));
	const scope = presentation.source === "wire" ? "" : presentation.source === "details" ? " · 局部结构" : "";
	if (presentation.facts.length > 0) {
		lines.push(paint(theme, "dim", `  ${presentation.facts.map((f) => `${f.label}=${f.value}`).join(" · ")}${scope}`));
	} else if (scope !== "") {
		lines.push(paint(theme, "dim", `  （无可证明结构字段${scope}）`));
	}
	if (presentation.axes) {
		lines.push(paint(theme, "accent", `  三轴: ${presentation.axes.execution}/${presentation.axes.settlement}/${presentation.axes.acceptance}`));
	}
	if (presentation.source === "text") {
		lines.push(paint(theme, "muted", `  ${NO_STRUCTURE_NOTE}`));
	}
	if (options.expanded) {
		const source = originalText !== undefined ? originalText : presentation.excerpt;
		const safe = sanitizePresentationText(source);
		const rows = safe.split("\n").slice(0, PRESENTATION_EXPANDED_LINES);
		for (const row of rows) lines.push(paint(theme, "dim", `  ${row}`));
		const total = safe.split("\n").length;
		if (total > PRESENTATION_EXPANDED_LINES) lines.push(paint(theme, "muted", `  …（共 ${total} 行，展开上限 ${PRESENTATION_EXPANDED_LINES}）`));
	} else if (presentation.excerpt !== "") {
		lines.push(paint(theme, "dim", `  ${presentation.excerpt}`));
	}
	return lines;
}

// ── renderCall 参数摘要（每工具关注键；不可信值安全化） ────────────────────────

const CALL_ARG_KEYS: Record<string, readonly string[]> = {
	task_query: ["view", "handle", "taskId", "agent"],
	mcp_call: ["server", "tool"],
	mcp_list_tools: [],
	amagi_handbook: ["action", "query", "id"],
	run_bg: ["action", "handle"],
	amagi_evolution: ["action", "query", "id"],
	lsp: ["action", "file"],
	task_submit: ["agent", "name", "taskId"],
	task_resume: ["taskId"],
	task_control: ["action", "taskId"],
	task: ["agent", "name"],
	query_task: ["handle", "level"],
};

function argSnippet(value: unknown, max = 60): string {
	const s = typeof value === "string" ? value : (() => { try { return JSON.stringify(value); } catch { /* lint-exempt:参数值序列化失败退 String */ return String(value); } })();
	return sanitizePresentationText(s).replace(/\s+/g, " ").trim().slice(0, max);
}

export function renderCallLine(toolName: string, args: unknown): string {
	const o = typeof args === "object" && args !== null && !Array.isArray(args) ? args as Record<string, unknown> : {};
	const keys = CALL_ARG_KEYS[toolName] ?? Object.keys(o).slice(0, 2);
	const parts: string[] = [];
	for (const k of keys) {
		if (o[k] === undefined || o[k] === null || o[k] === "") continue;
		const v = argSnippet(o[k]);
		if (v !== "") parts.push(v);
	}
	return parts.length > 0 ? `${toolName} ${parts.join(" ")}` : toolName;
}

// ── 注册入口（能力门 + 事件接线；Leader 在 index.ts 串行接线） ─────────────────

export interface RegisterToolRenderersResult {
	/** true=resolver 已注册；false=宿主无 registerToolRenderer（零注册零报错）。 */
	registered: boolean;
	/** 诊断注记（测试与 /amagi 诊断消费）。 */
	reason: string;
}

/**
 * 注册 amagi 工具卡渲染器（B4 唯一注册入口）。
 * - 能力门：resolveHostCapabilities 探测 registerToolRenderer（runtime-probe 权威）；
 *   缺席 → {registered:false}，不注册任何 resolver/handler（旧宿主零行为变化）。
 * - 接线：resolver（amagi 工具→语义卡；其余 next() 透传）+ tool_execution_end 捕获 +
 *   session_start/session_tree 缓存清空（旧宿主无 session_tree 事件——单独 try 接线）。
 */
export function registerAmagiToolRenderers(
	pi: ToolRendererHostSurface,
	options?: { cache?: WirePresentationCache },
): RegisterToolRenderersResult {
	const cache = options?.cache ?? new WirePresentationCache();
	// 能力门（A2 已入表；runtime-probe：typeof 探测为权威，版本表仅交叉注记）。
	// 弱宿主表面经 as 对齐 RuntimeProbeSurface——缺席键的 typeof 探测自然为 false，不误报。
	const caps = resolveHostCapabilities(pi as unknown as ExtensionAPI);
	if (!caps.capabilities.registerToolRenderer || typeof pi.registerToolRenderer !== "function") {
		return { registered: false, reason: `host=${caps.hostVersion ?? "unknown"} 无 registerToolRenderer（pi 1.0.1+ 能力）——零注册降级` };
	}
	const capture = createPresentationEventCapture(cache);
	const on = pi.on;
	if (typeof on === "function") {
		on("tool_execution_end", (event: unknown) => { capture.onToolExecutionEnd(event); });
		on("session_start", () => { capture.onSessionBoundary(); });
		try { on("session_tree", () => { capture.onSessionBoundary(); }); } catch { /* lint-exempt:旧宿主无 session_tree 事件名——分支清理面缺席不阻塞注册 */ }
	}
	const resolver: ToolRendererResolver = (toolName: string, next: () => ToolRenderers | undefined): ToolRenderers | undefined => {
		if (!isAmagiPresentationTool(toolName)) return next(); // 其它工具原样保留（不吞余链）
		return {
			renderCall: (args: unknown, theme: unknown) => linesComponent([renderCallLine(toolName, args)]),
			renderResult: (result: unknown, options: ToolRenderResultOptions, theme: unknown, context: unknown) => {
				const r = (result ?? {}) as { content?: unknown; details?: unknown };
				const ctx = (context ?? {}) as RenderContextLike;
				const cached = typeof ctx.toolCallId === "string" ? cache.get(ctx.toolCallId) : undefined;
				const presentation = cached ?? projectToolPresentation(toolName, {
					content: Array.isArray(r.content) ? (r.content as ReadonlyArray<{ type?: string; text?: unknown }>) : undefined,
					details: r.details,
					isError: ctx.isError === true,
				});
				if (!presentation) return linesComponent([]); // 未识别工具防御（resolver 已挡——不可达分支不抛）
				const originalText = presentation.source === "text" || options.expanded
					? textOfContent(r.content) : undefined;
				const lines = renderPresentationLines(presentation, options, theme as ThemeLike, originalText);
				// 只消费最终 context 的原生事实；不从事件缓存或当前状态补历史耗时。
				if (!options.isPartial && typeof ctx.durationMs === "number" && Number.isFinite(ctx.durationMs) && ctx.durationMs >= 0) {
					lines.push(paint(theme as ThemeLike, "dim", `  工具执行：${Math.round(ctx.durationMs)}ms`));
				}
				return linesComponent(lines);
			},
		};
	};
	pi.registerToolRenderer(resolver);
	return { registered: true, reason: `host=${caps.hostVersion ?? "unknown"} registerToolRenderer=on（amagi ${"tool-presentation"} 语义卡）` };
}

/** content 块 → 原文（展开态与 text 档渲染用；多行保留）。 */
function textOfContent(content: unknown): string | undefined {
	if (!Array.isArray(content)) return undefined;
	const parts: string[] = [];
	for (const b of content) {
		if (b && typeof b === "object" && (b as { type?: unknown }).type === "text" && typeof (b as { text?: unknown }).text === "string") {
			parts.push((b as { text: string }).text);
		}
	}
	return parts.length > 0 ? parts.join("\n") : undefined;
}
