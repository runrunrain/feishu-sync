/**
 * lsp-client.ts — LSP over stdio JSON-RPC 客户端与按项目隔离的客户端池。
 *
 * V1 只实现工具层所需的生命周期：Content-Length 帧、initialize、文档同步、
 * diagnostics 缓存、请求超时取消、启动熔断与空闲回收。无外部运行时依赖。
 */

import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import * as path from "node:path";
import { pathToFileURL } from "node:url";

const DEFAULT_REQUEST_TIMEOUT_MS = 15_000;
const DEFAULT_IDLE_TIMEOUT_MS = 300_000;
const DEFAULT_BREAKER_COOLDOWN_MS = 60_000;
const GRACEFUL_CLOSE_TIMEOUT_MS = 2_000;
const STDERR_TAIL_LINES = 20;
const MAX_FRAME_BYTES = 32 * 1024 * 1024;

/**
 * 与并行切片 lsp-types.ts 的 LspServerDefinition 同构。
 * B1 装配批可改为 type import；此处保持 A2 在 A1 尚未落盘时可独立加载、测试。
 */
export interface LspServerDefinition {
	name: string;
	command: string;
	args?: string[];
	fileTypes?: string[];
	rootMarkers?: string[];
	languageId?: string;
	/** ev-20260924-895eac：按扩展名的 languageId 映射（键=点前缀扩展名如 ".tsx"，值=languageId）。
	 *  typescript-language-server 等以 languageId 决定 ScriptKind（tsx 必须 typescriptreact，
	 *  否则每个 JSX 标签都是语法错误并级联数千条误报）。解析链 languageIds[ext] → languageId →
	 *  plaintext；只配 languageId 的用户定义行为不变（向后兼容）。 */
	languageIds?: Record<string, string>;
	initializationOptions?: Record<string, unknown>;
	disabled?: boolean;
}

export interface LspPosition {
	line: number;
	character: number;
}

export interface LspRange {
	start: LspPosition;
	end: LspPosition;
}

export interface LspDiagnostic {
	range: LspRange;
	message: string;
	severity?: number;
	code?: string | number;
	source?: string;
	[k: string]: unknown;
}

export interface LspClientOptions {
	/** 单请求超时；默认 15000ms。 */
	requestTimeoutMs?: number;
	/** requestTimeoutMs 的便捷别名，便于测试/调用方注入。 */
	timeoutMs?: number;
	/** 启动失败后的熔断冷却；默认 60000ms。 */
	circuitBreakerCooldownMs?: number;
}

export interface LspClientStatus {
	name: string;
	cwd: string;
	command: string;
	pid: number | undefined;
	alive: boolean;
	initialized: boolean;
	pendingRequests: number;
	openFiles: number;
	diagnosticFiles: number;
	lastUsedAt: number;
	stderrTail: string;
}

export interface LspClientPoolOptions extends LspClientOptions {
	cwd?: string;
	idleTimeoutMs?: number;
	/** 测试可注入；缺省取 min(30s, idleTimeoutMs / 2)。 */
	sweepIntervalMs?: number;
}

interface PendingRequest {
	method: string;
	resolve: (value: unknown) => void;
	reject: (error: Error) => void;
	timer: NodeJS.Timeout;
}

interface DiagnosticWaiter {
	resolve: (diagnostics: LspDiagnostic[]) => void;
	reject: (error: Error) => void;
	timer: NodeJS.Timeout;
}

interface ChildExit {
	code: number | null;
	signal: NodeJS.Signals | null;
}

interface BreakerEntry {
	failedAt: number;
	reason: string;
}

const circuitBreakers = new Map<string, BreakerEntry>();

function breakerKey(definition: LspServerDefinition, cwd: string): string {
	return `${definition.name}:${definition.command}:${cwd}`;
}

function errorMessage(error: unknown): string {
	return error instanceof Error ? error.message : String(error);
}

function delay(ms: number): Promise<void> {
	return new Promise((resolve) => {
		const timer = setTimeout(resolve, ms);
		timer.unref();
	});
}

function textFingerprint(text: string): string {
	let hash = 2166136261;
	for (let i = 0; i < text.length; i++) {
		hash ^= text.charCodeAt(i);
		hash = Math.imul(hash, 16777619);
	}
	return `${text.length}:${hash >>> 0}`;
}

function fileUri(absPath: string): string {
	return pathToFileURL(path.resolve(absPath)).href;
}

/**
 * ev-20260924-895eac（P2）：按文件路径解析 didOpen 应发的 languageId（纯函数，导出供测试）。
 * 解析链：languageIds[<点前缀小写扩展名>] → languageId → "plaintext"。
 * 背景：typescript-language-server 以 languageId 决定 ScriptKind——单一 "typescript" 登记下
 * .tsx 被当 TS（非 JSX）解析，每个 JSX 标签都是语法错误并级联数千条误报；tsc 按扩展名判定
 * ScriptKind，两边结论冲突。languageIds 映射让 didOpen 发出正确的 typescriptreact/javascriptreact。
 * 只配 languageId 的用户定义行为不变（映射缺失即回退，向后兼容）。
 */
export function languageIdFor(definition: LspServerDefinition, filePath: string): string {
	const ids = definition.languageIds;
	if (ids && typeof ids === "object") {
		const dot = filePath.lastIndexOf(".");
		const dirSep = Math.max(filePath.lastIndexOf("/"), filePath.lastIndexOf(path.sep));
		if (dot > dirSep) {
			const ext = filePath.slice(dot).toLowerCase();
			const mapped = ids[ext] ?? ids[ext.replace(/^\./, "")];
			if (typeof mapped === "string" && mapped) return mapped;
		}
	}
	return definition.languageId || "plaintext";
}

function rootFileUri(cwd: string): string {
	const withSeparator = cwd.endsWith(path.sep) ? cwd : `${cwd}${path.sep}`;
	return pathToFileURL(withSeparator).href;
}

function tailLines(current: string, addition: string): string {
	const lines = `${current}${addition}`.split(/\r?\n/);
	return lines.slice(-STDERR_TAIL_LINES).join("\n").slice(-8_192);
}

function normalizeTimeout(value: number | undefined, fallback: number): number {
	return Number.isFinite(value) && Number(value) > 0 ? Number(value) : fallback;
}

/** 测试或配置热切换时清空模块级启动熔断记录。 */
export function clearLspCircuitBreakers(): void {
	circuitBreakers.clear();
}

/** 单个语言服务器进程的 LSP stdio 客户端。请用 create() 完成握手。 */
export class LspClient {
	readonly definition: LspServerDefinition;
	readonly cwd: string;
	readonly requestTimeoutMs: number;
	initializeResult: Record<string, unknown> | null = null;
	lastUsedAt = Date.now();

	private readonly circuitBreakerCooldownMs: number;
	private child: ChildProcessWithoutNullStreams | null = null;
	private readBuffer = Buffer.alloc(0);
	private stderrBuffer = "";
	private nextId = 1;
	private readonly pending = new Map<number, PendingRequest>();
	private readonly openFiles = new Map<string, { fingerprint: string; version: number }>();
	private readonly diagnostics = new Map<string, LspDiagnostic[]>();
	private readonly diagnosticWaiters = new Map<string, Set<DiagnosticWaiter>>();
	private readonly notificationLog: string[] = [];
	private transportError: Error | null = null;
	private childExit: ChildExit | null = null;
	private resolveExit!: (value: ChildExit) => void;
	private readonly exitPromise: Promise<ChildExit>;
	private closePromise: Promise<void> | null = null;
	private initialized = false;

	private constructor(definition: LspServerDefinition, cwd: string, options: LspClientOptions) {
		this.definition = definition;
		this.cwd = path.resolve(cwd);
		this.requestTimeoutMs = normalizeTimeout(options.requestTimeoutMs ?? options.timeoutMs, DEFAULT_REQUEST_TIMEOUT_MS);
		this.circuitBreakerCooldownMs = normalizeTimeout(options.circuitBreakerCooldownMs, DEFAULT_BREAKER_COOLDOWN_MS);
		this.exitPromise = new Promise((resolve) => { this.resolveExit = resolve; });
	}

	/** spawn server 并完成 initialize/initialized 握手；失败会记录 60s 熔断。 */
	static async create(definition: LspServerDefinition, cwd: string, options: LspClientOptions = {}): Promise<LspClient> {
		if (!definition?.name?.trim()) throw new Error("LSP server definition 缺少 name");
		if (!definition?.command?.trim()) throw new Error(`LSP server "${definition.name}" 缺少 command`);
		if (definition.disabled) throw new Error(`LSP server "${definition.name}" 已禁用`);

		const normalizedCwd = path.resolve(cwd);
		const cooldownMs = normalizeTimeout(options.circuitBreakerCooldownMs, DEFAULT_BREAKER_COOLDOWN_MS);
		const key = breakerKey(definition, normalizedCwd);
		const previous = circuitBreakers.get(key);
		if (previous) {
			const elapsed = Date.now() - previous.failedAt;
			if (elapsed < cooldownMs) {
				throw new Error(`LSP server "${definition.name}" 熔断冷却中（${cooldownMs - elapsed}ms remaining）：${previous.reason}`);
			}
			circuitBreakers.delete(key);
		}

		const client = new LspClient(definition, normalizedCwd, options);
		try {
			await client.start();
			circuitBreakers.delete(key);
			return client;
		} catch (error) {
			const stderr = client.stderrTail;
			const reason = `${errorMessage(error)}${stderr ? `；stderr tail: ${stderr}` : ""}`;
			circuitBreakers.set(key, { failedAt: Date.now(), reason });
			await client.forceStop();
			throw new Error(`LSP server "${definition.name}" 启动或 initialize 失败（${definition.command}）：${reason}`);
		}
	}

	get pid(): number | undefined {
		return this.child?.pid;
	}

	get isAlive(): boolean {
		return !!this.child && !this.childExit && !this.transportError;
	}

	get stderrTail(): string {
		return this.stderrBuffer.trim();
	}

	get serverCapabilities(): Record<string, unknown> {
		const capabilities = this.initializeResult?.capabilities;
		return capabilities && typeof capabilities === "object" ? capabilities as Record<string, unknown> : {};
	}

	/** 服务端 window/logMessage 等非业务通知的有界调试记录。 */
	get serverNotifications(): readonly string[] {
		return this.notificationLog;
	}

	touch(): void {
		this.lastUsedAt = Date.now();
	}

	private async start(): Promise<void> {
		let child: ChildProcessWithoutNullStreams;
		try {
			child = spawn(this.definition.command, this.definition.args ?? [], {
				cwd: this.cwd,
				env: { ...process.env },
				stdio: ["pipe", "pipe", "pipe"],
				shell: false,
			});
		} catch (error) {
			throw new Error(`spawn 失败: ${errorMessage(error)}`);
		}
		this.child = child;
		child.stdout.on("data", (chunk: Buffer) => this.consume(chunk));
		child.stderr.on("data", (chunk: Buffer) => {
			this.stderrBuffer = tailLines(this.stderrBuffer, chunk.toString("utf8"));
		});
		child.stdin.on("error", (error) => this.onTransportError(new Error(`stdin error: ${error.message}`)));
		child.once("error", (error) => this.onTransportError(new Error(`spawn error: ${error.message}`)));
		child.once("close", (code, signal) => this.onChildClose(code, signal));

		const rootUri = rootFileUri(this.cwd);
		const result = await this.request("initialize", {
			processId: process.pid,
			clientInfo: { name: "amagi-pi", version: "1.0.0" },
			rootPath: this.cwd,
			rootUri,
			workspaceFolders: [{ uri: rootUri, name: path.basename(this.cwd) || this.cwd }],
			capabilities: {
				textDocument: {
					synchronization: { dynamicRegistration: false, didSave: false, willSave: false, willSaveWaitUntil: false },
					hover: { dynamicRegistration: false, contentFormat: ["markdown", "plaintext"] },
					definition: { dynamicRegistration: false, linkSupport: true },
					references: { dynamicRegistration: false },
					rename: { dynamicRegistration: false, prepareSupport: false },
					documentSymbol: { dynamicRegistration: false, hierarchicalDocumentSymbolSupport: true },
					implementation: { dynamicRegistration: false, linkSupport: true },
					publishDiagnostics: {
						relatedInformation: true,
						tagSupport: { valueSet: [1, 2] },
						versionSupport: true,
					},
				},
				workspace: {
					configuration: false,
					workspaceFolders: true,
					symbol: { dynamicRegistration: false },
					workspaceEdit: { documentChanges: true },
				},
			},
			initializationOptions: this.definition.initializationOptions ?? {},
			trace: "off",
		}) as Record<string, unknown>;
		this.initializeResult = result ?? {};
		this.initialized = true;
		this.notify("initialized", {});
	}

	private send(message: Record<string, unknown>): void {
		const child = this.child;
		if (!child || this.childExit) throw new Error(`LSP server "${this.definition.name}" 未运行`);
		if (this.transportError) throw this.transportError;
		if (!child.stdin.writable) throw new Error(`LSP server "${this.definition.name}" stdin 不可写`);
		const body = Buffer.from(JSON.stringify(message), "utf8");
		const header = Buffer.from(`Content-Length: ${body.length}\r\n\r\n`, "ascii");
		child.stdin.write(Buffer.concat([header, body]));
	}

	private consume(chunk: Buffer): void {
		this.readBuffer = this.readBuffer.length === 0 ? Buffer.from(chunk) : Buffer.concat([this.readBuffer, chunk]);
		for (;;) {
			const crlfEnd = this.readBuffer.indexOf("\r\n\r\n");
			const lfEnd = this.readBuffer.indexOf("\n\n");
			let headerEnd = -1;
			let separatorBytes = 0;
			if (crlfEnd >= 0 && (lfEnd < 0 || crlfEnd <= lfEnd)) {
				headerEnd = crlfEnd;
				separatorBytes = 4;
			} else if (lfEnd >= 0) {
				headerEnd = lfEnd;
				separatorBytes = 2;
			}
			if (headerEnd < 0) return;

			const header = this.readBuffer.subarray(0, headerEnd).toString("ascii");
			const lengthMatch = /^content-length\s*:\s*(\d+)\s*$/im.exec(header);
			if (!lengthMatch) {
				this.readBuffer = this.readBuffer.subarray(headerEnd + separatorBytes);
				continue;
			}
			const contentLength = Number(lengthMatch[1]);
			if (!Number.isSafeInteger(contentLength) || contentLength < 0 || contentLength > MAX_FRAME_BYTES) {
				this.onTransportError(new Error(`LSP 非法 Content-Length: ${lengthMatch[1]}`));
				return;
			}
			const bodyStart = headerEnd + separatorBytes;
			const bodyEnd = bodyStart + contentLength;
			if (this.readBuffer.length < bodyEnd) return;
			const body = this.readBuffer.subarray(bodyStart, bodyEnd).toString("utf8");
			this.readBuffer = this.readBuffer.subarray(bodyEnd);

			let message: unknown;
			try {
				message = JSON.parse(body);
			} catch (error) {
				this.recordNotification(`invalid-json: ${errorMessage(error)}`);
				continue;
			}
			this.handleMessage(message);
		}
	}

	private handleMessage(value: unknown): void {
		if (!value || typeof value !== "object") return;
		const message = value as Record<string, unknown>;
		if (typeof message.id === "number" && (Object.hasOwn(message, "result") || Object.hasOwn(message, "error"))) {
			const pending = this.pending.get(message.id);
			if (!pending) return;
			this.pending.delete(message.id);
			clearTimeout(pending.timer);
			if (message.error && typeof message.error === "object") {
				const rpcError = message.error as Record<string, unknown>;
				pending.reject(new Error(`LSP JSON-RPC error ${String(rpcError.code ?? "unknown")} (${pending.method}): ${String(rpcError.message ?? "unknown error")}`));
			} else {
				pending.resolve(message.result);
			}
			return;
		}

		if (message.method === "textDocument/publishDiagnostics") {
			const params = message.params && typeof message.params === "object" ? message.params as Record<string, unknown> : {};
			const uri = typeof params.uri === "string" ? params.uri : "";
			const diagnostics = Array.isArray(params.diagnostics) ? params.diagnostics as LspDiagnostic[] : [];
			if (uri) {
				this.diagnostics.set(uri, diagnostics);
				const waiters = this.diagnosticWaiters.get(uri);
				if (waiters) {
					this.diagnosticWaiters.delete(uri);
					for (const waiter of waiters) {
						clearTimeout(waiter.timer);
						waiter.resolve(diagnostics);
					}
				}
			}
			return;
		}

		if (typeof message.method === "string") {
			this.recordNotification(`${message.method}: ${JSON.stringify(message.params ?? {}).slice(0, 500)}`);
			// 未声明支持服务端反向请求；明确回 method not found，避免 server 永久等待。
			if ((typeof message.id === "number" || typeof message.id === "string") && this.isAlive) {
				try {
					this.send({ jsonrpc: "2.0", id: message.id, error: { code: -32601, message: `Method not supported: ${message.method}` } });
				} catch {}
			}
		}
	}

	private recordNotification(message: string): void {
		this.notificationLog.push(message);
		if (this.notificationLog.length > 50) this.notificationLog.splice(0, this.notificationLog.length - 50);
	}

	private onTransportError(error: Error): void {
		if (this.transportError || this.childExit) return;
		this.transportError = error;
		this.rejectPending(error);
		this.rejectDiagnosticWaiters(error);
		// v1.5.220 审核修复（Major-4）：transport 已坏但进程可能仍存活——主动强杀，防孤儿进程递出池管理
		void this.forceStop().catch(() => {});
	}

	private onChildClose(code: number | null, signal: NodeJS.Signals | null): void {
		if (this.childExit) return;
		this.childExit = { code, signal };
		const error = this.transportError ?? new Error(
			`LSP server "${this.definition.name}" exited (code=${code} signal=${signal})${this.stderrTail ? `；stderr tail: ${this.stderrTail}` : ""}`,
		);
		this.rejectPending(error);
		this.rejectDiagnosticWaiters(error);
		this.resolveExit(this.childExit);
	}

	private rejectPending(error: Error): void {
		for (const pending of this.pending.values()) {
			clearTimeout(pending.timer);
			pending.reject(error);
		}
		this.pending.clear();
	}

	private rejectDiagnosticWaiters(error: Error): void {
		for (const waiters of this.diagnosticWaiters.values()) {
			for (const waiter of waiters) {
				clearTimeout(waiter.timer);
				waiter.reject(error);
			}
		}
		this.diagnosticWaiters.clear();
	}

	/** 发送 JSON-RPC 请求；超时会先发 $/cancelRequest，再 reject。 */
	request(method: string, params?: unknown, timeoutMs = this.requestTimeoutMs): Promise<unknown> {
		this.touch();
		if (this.childExit) return Promise.reject(new Error(`LSP server "${this.definition.name}" 已退出`));
		if (this.transportError) return Promise.reject(this.transportError);
		const effectiveTimeoutMs = normalizeTimeout(timeoutMs, this.requestTimeoutMs);
		const id = this.nextId++;
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(id);
				try { this.send({ jsonrpc: "2.0", method: "$/cancelRequest", params: { id } }); } catch {}
				reject(new Error(`LSP request timeout (${effectiveTimeoutMs}ms): ${this.definition.name}/${method}${this.stderrTail ? `；stderr tail: ${this.stderrTail}` : ""}`));
			}, effectiveTimeoutMs);
			timer.unref();
			this.pending.set(id, { method, resolve, reject, timer });
			try {
				this.send({ jsonrpc: "2.0", id, method, ...(params === undefined ? {} : { params }) });
			} catch (error) {
				this.pending.delete(id);
				clearTimeout(timer);
				reject(error instanceof Error ? error : new Error(String(error)));
			}
		});
	}

	/** 发送 JSON-RPC notification。 */
	notify(method: string, params?: unknown): void {
		this.touch();
		this.send({ jsonrpc: "2.0", method, ...(params === undefined ? {} : { params }) });
	}

	/**
	 * 首次发送 didOpen；同一路径文本指纹变化时发送 full-sync didChange。
	 * 返回值用于调用方/测试区分是否实际发送了同步通知。
	 */
	ensureOpenFile(absPath: string, text: string): "opened" | "changed" | "unchanged" {
		if (!path.isAbsolute(absPath)) throw new Error(`ensureOpenFile 需要绝对路径: ${absPath}`);
		this.touch();
		const uri = fileUri(absPath);
		const fingerprint = textFingerprint(text);
		const previous = this.openFiles.get(uri);
		if (!previous) {
			this.notify("textDocument/didOpen", {
				textDocument: {
				uri,
				languageId: languageIdFor(this.definition, absPath),
				version: 1,
				text,
				},
			});
			this.openFiles.set(uri, { fingerprint, version: 1 });
			this.diagnostics.delete(uri); // v1.5.220 审核修复（Major-5）：文档同步即失效旧诊断，waitForDiagnostics 等新 publish
			return "opened";
		}
		if (previous.fingerprint === fingerprint) return "unchanged";
		const version = previous.version + 1;
		this.notify("textDocument/didChange", {
			textDocument: { uri, version },
			contentChanges: [{ text }],
		});
		this.openFiles.set(uri, { fingerprint, version });
		this.diagnostics.delete(uri); // 同上：didChange 后旧缓存必陈旧
		return "changed";
	}

	/** 指定文件最近一次 publishDiagnostics；尚未收到时返回空数组。 */
	diagnosticsFor(absPath: string): LspDiagnostic[] {
		this.touch();
		return this.diagnostics.get(fileUri(absPath)) ?? [];
	}

	/** 等待指定文件首次/下一次 publishDiagnostics，便于 diagnostics action 同步取结果。 */
	waitForDiagnostics(absPath: string, timeoutMs = this.requestTimeoutMs): Promise<LspDiagnostic[]> {
		this.touch();
		const uri = fileUri(absPath);
		const cached = this.diagnostics.get(uri);
		if (cached) return Promise.resolve(cached);
		const effectiveTimeoutMs = normalizeTimeout(timeoutMs, this.requestTimeoutMs);
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				const waiters = this.diagnosticWaiters.get(uri);
				if (waiters) {
					waiters.delete(waiter);
					if (waiters.size === 0) this.diagnosticWaiters.delete(uri);
				}
				reject(new Error(`LSP diagnostics timeout (${effectiveTimeoutMs}ms): ${absPath}`));
			}, effectiveTimeoutMs);
			timer.unref();
			const waiter: DiagnosticWaiter = { resolve, reject, timer };
			let waiters = this.diagnosticWaiters.get(uri);
			if (!waiters) {
				waiters = new Set();
				this.diagnosticWaiters.set(uri, waiters);
			}
			waiters.add(waiter);
		});
	}

	status(): LspClientStatus {
		return {
			name: this.definition.name,
			cwd: this.cwd,
			command: this.definition.command,
			pid: this.pid,
			alive: this.isAlive,
			initialized: this.initialized,
			pendingRequests: this.pending.size,
			openFiles: this.openFiles.size,
			diagnosticFiles: this.diagnostics.size,
			lastUsedAt: this.lastUsedAt,
			stderrTail: this.stderrTail,
		};
	}

	whenExit(): Promise<ChildExit> {
		return this.childExit ? Promise.resolve(this.childExit) : this.exitPromise;
	}

	/** shutdown → exit；2s 未退出则 SIGTERM，最后 SIGKILL。幂等。 */
	close(): Promise<void> {
		if (!this.closePromise) this.closePromise = this.performClose();
		return this.closePromise;
	}

	private async performClose(): Promise<void> {
		const child = this.child;
		if (!child || this.childExit) return;
		try { await this.request("shutdown", undefined, GRACEFUL_CLOSE_TIMEOUT_MS); } catch {}
		if (!this.childExit) {
			try { this.send({ jsonrpc: "2.0", method: "exit" }); } catch {}
		}
		if (await this.waitForExit(GRACEFUL_CLOSE_TIMEOUT_MS)) return;
		try { child.kill("SIGTERM"); } catch {}
		if (await this.waitForExit(1_000)) return;
		try { child.kill("SIGKILL"); } catch {}
		await this.waitForExit(1_000);
	}

	private async forceStop(): Promise<void> {
		const child = this.child;
		if (!child || this.childExit) return;
		try { child.kill("SIGTERM"); } catch {}
		if (await this.waitForExit(500)) return;
		try { child.kill("SIGKILL"); } catch {}
		await this.waitForExit(500);
	}

	private async waitForExit(timeoutMs: number): Promise<boolean> {
		if (this.childExit) return true;
		const result = await Promise.race([
			this.exitPromise.then(() => true),
			delay(timeoutMs).then(() => false),
		]);
		return result;
	}
}

/** 按 `${name}:${cwd}` 缓存并回收 LspClient。 */
export class LspClientPool {
	readonly cwd: string;
	readonly idleTimeoutMs: number;
	private readonly clientOptions: LspClientOptions;
	private readonly clients = new Map<string, LspClient>();
	private closePromise: Promise<void> | null = null;
	private readonly creating = new Map<string, Promise<LspClient>>();
	private readonly sweepTimer: NodeJS.Timeout;
	private closed = false;
	private sweeping = false;

	constructor(cwdOrOptions: string | LspClientPoolOptions = process.cwd(), options: LspClientPoolOptions = {}) {
		const combined = typeof cwdOrOptions === "string" ? options : cwdOrOptions;
		this.cwd = path.resolve(typeof cwdOrOptions === "string" ? cwdOrOptions : cwdOrOptions.cwd ?? process.cwd());
		this.idleTimeoutMs = normalizeTimeout(combined.idleTimeoutMs, DEFAULT_IDLE_TIMEOUT_MS);
		this.clientOptions = {
			requestTimeoutMs: combined.requestTimeoutMs,
			timeoutMs: combined.timeoutMs,
			circuitBreakerCooldownMs: combined.circuitBreakerCooldownMs,
		};
		const defaultSweepInterval = Math.max(50, Math.min(30_000, Math.floor(this.idleTimeoutMs / 2)));
		const sweepIntervalMs = normalizeTimeout(combined.sweepIntervalMs, defaultSweepInterval);
		this.sweepTimer = setInterval(() => { void this.sweepIdle(); }, sweepIntervalMs);
		this.sweepTimer.unref();
	}

	private key(definition: LspServerDefinition, cwd: string): string {
		return `${definition.name}:${path.resolve(cwd)}`;
	}

	/** 取缓存客户端；相同 key 的并发首次调用共享同一个 initialize Promise。 */
	async getOrCreate(definition: LspServerDefinition, cwd = this.cwd): Promise<LspClient> {
		if (this.closed) throw new Error("LspClientPool 已关闭");
		const normalizedCwd = path.resolve(cwd);
		const key = this.key(definition, normalizedCwd);
		const existing = this.clients.get(key);
		if (existing?.isAlive) {
			existing.touch();
			return existing;
		}
		if (existing) {
			// v1.5.220 审核修复（Major-4）+快审 Minor-2：失效实例替换前先收口其进程；await 期间池可能已 closeAll → 重检
			this.clients.delete(key);
			await existing.close().catch(() => {});
			if (this.closed) throw new Error("LspClientPool 已关闭");
		}
		const pending = this.creating.get(key);
		if (pending) return pending;

		const creating = (async () => {
			const client = await LspClient.create(definition, normalizedCwd, this.clientOptions);
			if (this.closed) {
				await client.close();
				throw new Error("LspClientPool 在 server 初始化期间已关闭");
			}
			this.clients.set(key, client);
			client.touch();
			return client;
		})();
		this.creating.set(key, creating);
		try {
			return await creating;
		} finally {
			this.creating.delete(key);
		}
	}

	/** 按扩展名选 server definitions，并懒创建对应客户端。 */
	async routeGet(file: string, definitions: LspServerDefinition[]): Promise<LspClient[]> {
		const extension = path.extname(file).toLowerCase();
		const basename = path.basename(file).toLowerCase();
		const matches = definitions.filter((definition) => {
			if (definition.disabled) return false;
			return (definition.fileTypes ?? []).some((fileType) => {
				const normalized = fileType.trim().toLowerCase();
				if (!normalized) return false;
				if (normalized === "*") return true;
				if (normalized.startsWith("*.")) return basename.endsWith(normalized.slice(1));
				return extension === (normalized.startsWith(".") ? normalized : `.${normalized}`);
			});
		});
		return Promise.all(matches.map((definition) => this.getOrCreate(definition)));
	}

	statusAll(): LspClientStatus[] {
		return [...this.clients.values()].map((client) => client.status()).sort((a, b) => a.name.localeCompare(b.name));
	}

	/** 立即执行一次空闲回收；定时 sweep 使用同一路径。 */
	async sweepIdle(now = Date.now()): Promise<void> {
		if (this.closed || this.sweeping) return;
		this.sweeping = true;
		try {
			const closing: Promise<void>[] = [];
			for (const [key, client] of this.clients) {
				if (!client.isAlive || now - client.lastUsedAt >= this.idleTimeoutMs) {
					this.clients.delete(key);
					closing.push(client.close());
				}
			}
			await Promise.allSettled(closing);
		} finally {
			this.sweeping = false;
		}
	}

	/** 关闭全部 server 并停止 sweep；幂等（复用同一关闭 Promise，审核 Minor-1），之后不可重新创建。 */
	closeAll(): Promise<void> {
		if (this.closePromise) return this.closePromise;
		this.closed = true;
		clearInterval(this.sweepTimer);
		const clients = [...this.clients.values()];
		this.clients.clear();
		this.closePromise = (async () => {
			await Promise.allSettled(clients.map((client) => client.close()));
			await Promise.allSettled([...this.creating.values()]);
		})();
		return this.closePromise;
	}
}
