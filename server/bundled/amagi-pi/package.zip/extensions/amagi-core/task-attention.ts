/** Running-task observations for wait. No cancellation, retries or permission decisions. */
import { createHash } from "node:crypto";
import { registry, type WaitAttentionSignal } from "./task-registry.ts";
import { redactCredentials } from "./task-query-wire.ts";

export function setWaitAttention(taskId: string, kind: WaitAttentionSignal["kind"], summary?: string): void {
	const rec = registry.get(taskId);
	if (!rec || rec.status !== "running") return;
	const signals = rec.waitSignals ?? [];
	if (summary === undefined && !signals.some(s => s.kind === kind)) return;
	if (summary !== undefined && (rec.waitReported ?? []).includes(kind)) return;
	registry.patch(taskId, { waitSignals: [...signals.filter(s => s.kind !== kind), ...(summary === undefined ? [] : [{ kind, summary: redactCredentials(summary).slice(0, 600) }])] });
}

function canonical(value: unknown): string {
	if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
	if (value && typeof value === "object") return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${canonical(v)}`).join(",")}}`;
	return JSON.stringify(value) ?? "null";
}

/** Counts completed failures, not assistant intent frames or repeated successful reads. */
export class RepeatedToolFailureObserver {
	private pending = new Map<string, { signature: string; label: string }>();
	private last?: string;
	private repeats = 0;
	private readonly report: (summary?: string) => void;
	constructor(report: (summary?: string) => void) { this.report = report; }
	observe(event: { type?: string; toolCallId?: string; toolName?: string; args?: Record<string, unknown>; isError?: boolean; result?: { content?: unknown } }): void {
		if (event.type === "tool_execution_start" && event.toolCallId && event.toolName) {
			if (this.pending.size >= 128) this.pending.delete(this.pending.keys().next().value!);
			const signature = createHash("sha256").update(canonical([event.toolName, event.args ?? {}])).digest("hex");
			const label = redactCredentials(`${event.toolName} ${String(event.args?.command ?? event.args?.path ?? "")}`).replace(/\s+/g, " ").slice(0, 180);
			this.pending.set(event.toolCallId, { signature, label });
		} else if (event.type === "tool_execution_end") {
			const call = this.pending.get(event.toolCallId ?? "");
			this.pending.delete(event.toolCallId ?? "");
			if (!call || event.isError !== true) { this.last = undefined; this.repeats = 0; this.report(); return; }
			this.repeats = call.signature === this.last ? this.repeats + 1 : 1;
			this.last = call.signature;
			if (this.repeats < 3) { this.report(); return; }
			if (this.repeats !== 3) return;
			const content = event.result?.content;
			const result = typeof content === "string" ? content : Array.isArray(content) ? content.filter(p => p?.type === "text").map(p => String(p.text ?? "")).join("\n") : "";
			const first = redactCredentials(result).split(/\r?\n/).find(line => line.trim())?.slice(0, 200);
			this.report(`${call.label}：同一签名连续失败 3 次${first ? `；最近错误：${first}` : ""}`);
		}
	}
}
