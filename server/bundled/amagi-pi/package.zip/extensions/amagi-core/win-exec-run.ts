/**
 * win-exec-run.ts — win_exec 执行运行时（diting 审核 M5/M6/M9/m6/m7 重构）。
 *
 *  - PID 快照差集回收（M5/M6）：起前对「killImages ∪ 目标程序 basename」做 PID 快照；超时/
 *    中止后只杀**快照之外新增**的 PID（taskkill /PID n /T /F），不再按镜像名一刀切——用户在
 *    别处手开的同名进程绝不动。快照/核验不可用时如实报告「未能确认回收」，禁止声称已终止。
 *  - tasklist 解析按列位置（/FO CSV /NH 无表头；本地化免疫）；解析失败降级为只记录不杀。
 *  - 输出累积（M9/m7）：内存只留头 8KB + 滚动尾 24KB；超限部分边流边写 fullOutputPath 文件
 *    （总上限 64MB，超限丢弃并标注）；UTF-8 截断按码点边界；疑似二进制（NUL/控制字符比例）
 *    改十六进制摘要；剥离 SGR 颜色以外的危险控制序列。
 *  - 进程收口（M9）：await close（stdio 落定）而非 exit；error 兜底。
 *  - tasklist/taskkill 经异步 execFile（m6，超时可控、注入测试）。
 */

import { execFile, type ChildProcess } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { winExecRoot } from "./win-exec-lock.ts";

// ── tasklist / taskkill（异步，注入面） ──────────────────────────────────────

export interface TaskRow {
	image: string;
	pid: number;
}

export type ExecFileAsyncFn = (cmd: string, args: string[], opts: { timeout: number }) => Promise<{ status: number | null; stdout: string; stderr: string }>;

export function defaultExecFileAsync(cmd: string, args: string[], opts: { timeout: number }): Promise<{ status: number | null; stdout: string; stderr: string }> {
	return new Promise((resolve) => {
		execFile(cmd, args, { timeout: opts.timeout, encoding: "utf8", windowsHide: true }, (err, stdout, stderr) => {
			const e = err as (NodeJS.ErrnoException & { code?: number | string }) | undefined;
			const status = e && typeof e.code === "number" ? e.code : (e ? null : 0);
			resolve({ status, stdout: String(stdout ?? ""), stderr: String(stderr ?? "") });
		});
	});
}

/** 解析 tasklist /FO CSV /NH 输出（按列位置取 image/pid；坏行跳过）。 */
export function parseTasklistCsv(stdout: string): TaskRow[] {
	const rows: TaskRow[] = [];
	for (const line of String(stdout ?? "").split(/\r?\n/)) {
		const trimmed = line.trim();
		if (!trimmed) continue;
		const cells = trimmed.split('","').map((c) => c.replace(/^"|"$/g, ""));
		const image = cells[0];
		const pid = Number(cells[1]);
		if (typeof image === "string" && image !== "" && !/^"?image/i.test(image) && Number.isInteger(pid) && pid > 0) rows.push({ image, pid });
	}
	return rows;
}

/** 查询全部进程；失败返回 null（调用方如实降级为「不可核验」）。 */
export async function listWindowsTasks(execAsync: ExecFileAsyncFn, tasklistExe: string): Promise<TaskRow[] | null> {
	try {
		const res = await execAsync(tasklistExe, ["/FO", "CSV", "/NH"], { timeout: 15_000 });
		if (res.status !== 0) return null;
		const rows = parseTasklistCsv(res.stdout);
		// 解析健全性：至少应解析出自身（tasklist）或任意一行；全空按本地化异常降级
		return rows.length > 0 ? rows : null;
	} catch { return null; /* lint-exempt:tasklist 失败 → null（只记录不杀，如实报告） */ }
}

/** taskkill /PID n /T /F；返回是否成功。 */
export async function taskKillPid(execAsync: ExecFileAsyncFn, taskkillExe: string, pid: number): Promise<boolean> {
	try {
		const res = await execAsync(taskkillExe, ["/PID", String(pid), "/T", "/F"], { timeout: 15_000 });
		return res.status === 0;
	} catch { return false; /* lint-exempt:taskkill 失败 → 如实上报该 pid 未杀掉 */ }
}

// ── PID 快照差集（M5/M6） ────────────────────────────────────────────────────

export interface PidSnapshot {
	ok: boolean;
	/** ok=false 时快照不可用（tasklist 不可达/解析失败）——只记录不杀并如实报告。 */
	reason?: string;
	/** 关注镜像名（小写）→ 起前 PID 集。 */
	byImage: Map<string, number[]>;
	/** 全部关注 PID 集（快照差集基线）。 */
	pids: Set<number>;
}

export function snapshotOf(rows: TaskRow[] | null, filterImages: readonly string[]): PidSnapshot {
	if (rows === null) return { ok: false, reason: "tasklist 快照不可用（查询或解析失败）", byImage: new Map(), pids: new Set() };
	const want = new Set(filterImages.map((s) => s.trim().toLowerCase()).filter(Boolean));
	const byImage = new Map<string, number[]>();
	const pids = new Set<number>();
	for (const r of rows) {
		if (!want.has(r.image.toLowerCase())) continue;
		const list = byImage.get(r.image.toLowerCase()) ?? [];
		list.push(r.pid);
		byImage.set(r.image.toLowerCase(), list);
		pids.add(r.pid);
	}
	return { ok: true, byImage, pids };
}

export interface SnapshotKillReport {
	killed: { image: string; pid: number }[];
	failed: { image: string; pid: number }[];
	/** 快照不可用 → 未能确认回收（绝不声称已终止）。 */
	unverified?: string;
	/** 起前已存在、按语义保留的同类 PID（明确不动）。 */
	preserved: { image: string; pid: number }[];
}

/**
 * 超时/中止后的差集回收：只杀「快照之外新增」且镜像在关注集内的 PID；起前已存在的同类
 * PID 一律保留（preserved）。taskkill 不可解析时如实返回 unverified。
 */
export async function killNewSinceSnapshot(args: {
	execAsync: ExecFileAsyncFn;
	tasklistExe: string | null;
	taskkillExe: string | null;
	pre: PidSnapshot;
	filterImages: readonly string[];
}): Promise<SnapshotKillReport> {
	const report: SnapshotKillReport = { killed: [], failed: [], preserved: [] };
	// N2：起前快照不可用 → 无差集基线，绝不杀（否则 post 成功时会把用户同名进程全杀）
	if (!args.pre.ok) {
		return { ...report, unverified: `起前 PID 快照不可用（${args.pre.reason ?? "tasklist 不可达/解析失败"}）——无差集基线，未杀任何进程；Windows 侧进程树未能确认回收（请手工核验）` };
	}
	if (args.tasklistExe === null || args.taskkillExe === null) {
		return { ...report, unverified: "tasklist/taskkill 不可解析——Windows 侧进程树未能确认回收（请手工核验）" };
	}
	const rows = await listWindowsTasks(args.execAsync, args.tasklistExe);
	if (rows === null) {
		return { ...report, unverified: "tasklist 查询失败——Windows 侧进程树未能确认回收（请手工核验）" };
	}
	const post = snapshotOf(rows, args.filterImages);
	for (const [image, pids] of post.byImage) {
		for (const pid of pids) {
			if (args.pre.pids.has(pid)) {
				report.preserved.push({ image, pid });
				continue;
			}
			const ok = await taskKillPid(args.execAsync, args.taskkillExe, pid);
			(ok ? report.killed : report.failed).push({ image, pid });
		}
	}
	return report;
}

/** 差集回收报告 → 人读注记（按实际结果生成，禁止虚报）。 */
export function snapshotKillNote(r: SnapshotKillReport, mode: "supervised" | "direct"): string {
	const lines: string[] = [];
	if (r.unverified) {
		lines.push(`${mode === "supervised" ? "relay 已终止（SIGTERM→宽限→SIGKILL），Job Object 关闭应连带回收整树；但快照核验不可用：${r.unverified}" : r.unverified}`);
	} else {
		if (r.killed.length > 0) lines.push(`快照差集回收：已 taskkill /PID /T /F 新增进程 ${r.killed.map((k) => `${k.image} pid ${k.pid}`).join("、")}`);
		if (r.preserved.length > 0) lines.push(`起前已存在的同类进程未动（用户/他处进程）：${r.preserved.map((k) => `${k.image} pid ${k.pid}`).join("、")}`);
		if (r.killed.length === 0 && r.preserved.length === 0) lines.push("快照核验：关注镜像无存活（本次进程树已收口）");
	}
	if (r.failed.length > 0) lines.push(`taskkill 失败（请手工核验）：${r.failed.map((k) => `${k.image} pid ${k.pid}`).join("、")}`);
	return lines.join("\n");
}

// ── 输出累积（M9/m7：头/滚动尾 + fullOutputPath 边流边写 + 码点边界 + 二进制检测） ──

const HEAD_BYTES = 8 * 1024;
const TAIL_BYTES = 24 * 1024;
export const OUTPUT_FILE_MAX_BYTES = 64 * 1024 * 1024;

export interface OutputAccumDeps {
	/** 落盘根（缺省 <winExecRoot>/out）。 */
	root?: string;
	id: string;
	/** 注入测试。 */
	mkdir?: (p: string) => void;
	appendFile?: (p: string, data: Buffer) => void;
}

export interface FinalizedOutput {
	text: string;
	truncated: boolean;
	fullOutputPath?: string;
	bytes: number;
	/** 疑似二进制 → 摘要形态。 */
	binary: boolean;
	/** 文件超 64MB 丢弃后续。 */
	droppedBytes: number;
	/** 生效解码标签（人读）。 */
	encodingLabel: string;
	/** 解码降级注记（latin1 等）。 */
	encodingNote?: string;
}

export type DecodeFn = (b: Buffer) => DecodedWindowsOutputLike;
export interface DecodedWindowsOutputLike { text: string; label: string; note?: string }

export function utf8DecodeFn(b: Buffer): DecodedWindowsOutputLike {
	return { text: b.toString("utf8").replace(/\r\n/g, "\n"), label: "utf-8" };
}

/** 码点边界回退：仅当末尾 UTF-8 序列不完整（lead 在切片内但续字节不足）时截到 lead 前；
 *  完整序列（如「中」以续字节 AD 收尾）保持不动——不能把完整多字节字符误当断尾削掉。 */
export function cutAtCodepointBoundary(buf: Buffer): Buffer {
	const end = buf.length;
	if (end === 0 || (buf[end - 1]! & 0x80) === 0) return buf; // ASCII/空——完整
	let i = end - 1;
	let steps = 0;
	while (i > 0 && (buf[i]! & 0xc0) === 0x80 && steps < 3) { i--; steps++; }
	const lead = buf[i]!;
	if ((lead & 0xc0) === 0x80) return buf.subarray(0, i); // 窗口内全续字节（lead 缺）→ 硬截
	const expected = (lead & 0xf8) === 0xf0 ? 4 : (lead & 0xf0) === 0xe0 ? 3 : (lead & 0xe0) === 0xc0 ? 2 : 1;
	return end - i >= expected ? buf : buf.subarray(0, i);
}

/** 疑似二进制判定：含 NUL 或控制字符（除 \n \t \r ESC）比例 > 15%。 */
export function isProbablyBinary(buf: Buffer): boolean {
	if (buf.length === 0) return false;
	let ctrl = 0;
	for (const b of buf) {
		if (b === 0) return true;
		if (b < 0x20 && b !== 0x0a && b !== 0x09 && b !== 0x0d && b !== 0x1b) ctrl++;
	}
	return ctrl / buf.length > 0.15;
}

/** 危险控制序列剥离：保留 SGR（ESC[…m）与 OSC 终结前的载荷改为剥除、保留 \n\t；其余 C0 删除。 */
export function sanitizeControlSequences(text: string): string {
	// 移除 ESC 后跟非 [ 的控制序列（含 OSC "ESC]"…BEL/ST 单行近似）与裸 C0（保留 \n\t）
	return text
		.replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)?/g, "") // OSC（窗口标题等）
		.replace(/\x1b[^\[\]]/g, "") // 非 CSI 的 ESC 序列（键盘协议等）
		.replace(/[\x00-\x08\x0b\x0c\x0e-\x1a\x1c-\x1f\x7f]/g, ""); // 裸 C0/DEL（保留 \t\n\r 与 ESC）
}

export class StreamAccumulator {
	private head: Buffer[] = [];
	private headLen = 0;
	private tail: Buffer[] = [];
	private tailLen = 0;
	private total = 0;
	private filePath: string | null = null;
	private fileBytes = 0;
	private dropped = 0;
	private readonly deps: OutputAccumDeps;

	constructor(deps: OutputAccumDeps) { this.deps = deps; }

	push(chunk: Buffer): void {
		if (chunk.length === 0) return;
		this.total += chunk.length;
		let rest = chunk;
		if (this.headLen < HEAD_BYTES) {
			const budget = HEAD_BYTES - this.headLen;
			const headPart = rest.subarray(0, budget);
			this.head.push(headPart);
			this.headLen += headPart.length;
			rest = rest.subarray(headPart.length);
			if (rest.length === 0) return;
		}
		// 溢出：滚动尾 + 边流边写全量文件（首次溢出时建文件并补写头部）
		this.tail.push(rest);
		this.tailLen += rest.length;
		while (this.tailLen > TAIL_BYTES && this.tail.length > 1) {
			this.tailLen -= this.tail[0]!.length;
			this.tail.shift();
		}
		if (this.filePath === null) {
			try {
				const root = this.deps.root ?? path.join(winExecRoot(), "out");
				(this.deps.mkdir ?? ((p2) => fs.mkdirSync(p2, { recursive: true })))(root);
				this.filePath = path.join(root, `${this.deps.id}.out`);
				(this.deps.appendFile ?? ((p2, d) => fs.appendFileSync(p2, d)))(this.filePath, Buffer.concat(this.head));
				this.fileBytes = this.headLen;
			} catch { this.filePath = null; /* lint-exempt:落盘失败只影响溯源路径 */ }
		}
		if (this.filePath !== null && this.fileBytes < OUTPUT_FILE_MAX_BYTES) {
			const budget2 = OUTPUT_FILE_MAX_BYTES - this.fileBytes;
			const write = rest.length <= budget2 ? rest : rest.subarray(0, budget2);
			if (write.length > 0) {
				try {
					(this.deps.appendFile ?? ((p2, d) => fs.appendFileSync(p2, d)))(this.filePath, write);
					this.fileBytes += write.length;
				} catch { /* lint-exempt:写失败继续内存累积 */ }
			}
			if (rest.length > budget2) this.dropped += rest.length - budget2;
		} else if (this.filePath !== null) {
			this.dropped += rest.length;
		}
	}

	finalize(decode: DecodeFn = utf8DecodeFn): FinalizedOutput {
		const headBuf = cutAtCodepointBoundary(Buffer.concat(this.head));
		const bytes = this.total;
		const truncated = this.total > HEAD_BYTES + TAIL_BYTES;
		if (isProbablyBinary(headBuf)) {
			const sample = headBuf.subarray(0, 256);
			const hex = sample.toString("hex").replace(/(..)/g, "$1 ").trim();
			return {
				text: `（疑似二进制输出，已转十六进制摘要（前 ${sample.length} 字节）：${hex}${bytes > sample.length ? ` …共 ${bytes} 字节` : ""}）`,
				truncated: false, bytes, binary: true, droppedBytes: this.dropped, encodingLabel: "binary",
				...(this.filePath ? { fullOutputPath: this.filePath } : {}),
			};
		}
		const headDecoded = decode(headBuf);
		if (!truncated) {
			return { text: sanitizeControlSequences(headDecoded.text), truncated: false, bytes, binary: false, droppedBytes: 0, encodingLabel: headDecoded.label, ...(headDecoded.note ? { encodingNote: headDecoded.note } : {}) };
		}
		const tailBuf = cutAtCodepointBoundary(Buffer.concat(this.tail));
		const tailDecoded = decode(tailBuf);
		const omitted = bytes - headBuf.length - tailBuf.length;
		const text = `${sanitizeControlSequences(headDecoded.text)}\n…（中间省略 ${omitted > 0 ? omitted : 0} 字节；全量输出${this.filePath ? `：${this.filePath}` : " 落盘失败，仅保留首尾"}）…\n${sanitizeControlSequences(tailDecoded.text)}`;
		return { text, truncated: true, bytes, binary: false, droppedBytes: this.dropped, encodingLabel: headDecoded.label, ...(headDecoded.note ? { encodingNote: headDecoded.note } : {}), ...(this.filePath ? { fullOutputPath: this.filePath } : {}) };
	}
}

// ── 进程运行（M9 close 收口） ────────────────────────────────────────────────

export interface RunProcessOutcome {
	code: number | null;
	signal: NodeJS.Signals | null;
	error?: Error;
	timedOut: boolean;
}

/**
 * 前台运行：close（而非 exit）收口——stdio 数据在 close 前全部送达（残余 data 兜底由
 * close 语义天然覆盖）；超时回调（onTimeout）触发差集杀树并置 timedOut。
 */
export async function runProcessUntilClose(
	child: ChildProcess,
	opts: { onTimeout?: () => Promise<void> | void; timeoutMs: number; signal?: AbortSignal; onAbort?: () => Promise<void> | void },
): Promise<RunProcessOutcome> {
	let timedOut = false;
	let killSeq: Promise<void> | undefined;
	const timer = setTimeout(() => {
		timedOut = true;
		killSeq = Promise.resolve(opts.onTimeout?.());
	}, opts.timeoutMs);
	timer.unref?.();
	const onAbort = (): void => {
		if (killSeq === undefined) killSeq = Promise.resolve(opts.onAbort?.());
	};
	opts.signal?.addEventListener("abort", onAbort, { once: true });
	try {
		const closed = await new Promise<{ code: number | null; signal: NodeJS.Signals | null; error?: Error }>((resolve) => {
			child.once("close", (code, signal) => resolve({ code, signal }));
			child.once("error", (err) => resolve({ code: null, signal: null, error: err }));
			// spawn 失败（无 pid）时 error 先到；close 不会再来——error 已覆盖
		});
		if (killSeq !== undefined) await killSeq;
		return { ...closed, timedOut };
	} finally {
		clearTimeout(timer);
		opts.signal?.removeEventListener("abort", onAbort);
	}
}
