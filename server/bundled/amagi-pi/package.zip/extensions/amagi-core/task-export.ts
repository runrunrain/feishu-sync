/**
 * task-export.ts — ev-20260905-7614b1（capability/P2）：任务书自包含提示词导出。
 *
 * 背景事故：fuxi/503b960c——provider 不稳定致派发 85 分钟零产出后，主上要求「把给 fuxi 的
 * 提示词发我，我复制给 codex」手动接管；当时无现成导出通道，Leader 只能现场手工把派发任务书
 * 转写为自包含提示词（补角色设定/工作目录/纪律/回链）。本模块把该转写固化为五段式提示词文件：
 *   ① 角色设定（AgentConfig.systemPrompt 原文——派发时子进程经 --append-system-prompt 注入的同一份）
 *   ② 任务（任务书原文）
 *   ③ 工作环境（任务 cwd 绝对路径 / git 仓库根 / 参照模型 spec）
 *   ④ 工程纪律（固定紧凑段落）
 *   ⑤ 完成回链（产物绝对路径 + 结论摘要粘回 Amagi 会话，Leader 按路径验收）
 *
 * 调用方：task 工具 exportPrompt 参数（只导出不派发——零 spawn/零准入槽/零 registry），
 * 落盘供主上复制到外部工具（如 Codex CLI）手动接管。
 *
 * 模块纪律（同 residue / terminal-push）：零 pi 依赖、node:fs/node:path/node:child_process——
 * 组装函数纯参数化（agent 配置对象、task 文本、cwd、model spec、gitRoot、时间戳全注入），
 * 不读全局状态；task-tool 只做参数校验+调用+结果回传。
 */

import { execSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import type { AgentConfig } from "./agents-loader.ts";

/** 导出输入（全注入；task-tool 负责上游校验，本模块不重复派发面校验）。 */
export interface TaskExportInput {
	/** 目标角色（systemPrompt 原文进入「角色设定」段）。 */
	agent: Pick<AgentConfig, "name" | "systemPrompt">;
	/** 任务书原文（进入「任务」段；摘要前 120 字进入「完成回链」段）。 */
	task: string;
	/** 任务工作目录（绝对路径；进入「工作环境」段，同时是缺省导出目录基准）。 */
	taskCwd: string;
	/** 当前解析模型 spec（仅参照，外部工具模型不限）。 */
	modelSpec?: string;
	/** git 仓库根（git rev-parse --show-toplevel 结果；失败/非 git 仓库传 undefined → 跳过该行）。 */
	gitRoot?: string;
	/** 显式文件路径（相对该基准解析；缺省走 <taskCwd>/.amagi-export/ 时间戳命名）。 */
	leaderCwd?: string;
	/** 显式文件路径（空串由调用方拒单；此处只接收非空值）。 */
	explicitPath?: string;
	/** 生成时间（缺省 new Date()；测试注入确定性时间戳）。 */
	now?: Date;
}

/** 导出结果：ok=true 携带落盘绝对路径与字节数；ok=false 携带可读根因。 */
export type TaskExportResult = { ok: true; path: string; bytes: number } | { ok: false; message: string };

/** ④ 工程纪律固定段（紧凑单段，与 Leader 手工转写口径一致）。 */
export const EXPORT_DISCIPLINE_TEXT = "不交付假数据/占位/TODO；修改前先读现状；修复根因并做与风险相称的真实验证；不碰任务范围外文件、不自行 commit；产出物写明绝对路径清单。";

/** 任务摘要截断长度（完成回链段；与任务书口径一致的软上限）。 */
const TASK_SUMMARY_MAX = 120;

/** 文件名时间戳：yyyyMMdd-HHmmss（本地时区，与终端肉眼可对齐）。 */
function stampForFile(now: Date): string {
	const p = (n: number, w = 2) => String(n).padStart(w, "0");
	return `${now.getFullYear()}${p(now.getMonth() + 1)}${p(now.getDate())}-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}`;
}

/** 正文时间戳：yyyy-MM-dd HH:mm:ss（本地时区）。 */
function stampForText(now: Date): string {
	const p = (n: number) => String(n).padStart(2, "0");
	return `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`;
}

/** agent 名落文件名净化（writePromptTmp 同款：非 [\w.-] 折叠为 _）。 */
function safeName(name: string): string {
	return name.replace(/[^\w.-]+/g, "_");
}

/** 任务摘要：折叠空白后取前 120 字（超出附省略号）。 */
export function taskSummaryClip(task: string, max = TASK_SUMMARY_MAX): string {
	const flat = task.replace(/\s+/g, " ").trim();
	return flat.length > max ? `${flat.slice(0, max)}…` : flat;
}

/** 缺省导出路径：<taskCwd>/.amagi-export/task-<agent>-<yyyyMMdd-HHmmss>.md（不保证不冲突，冲突由 exportTaskPrompt 加序号）。 */
function defaultExportPath(taskCwd: string, agentName: string, now: Date): string {
	return path.join(taskCwd, ".amagi-export", `task-${safeName(agentName)}-${stampForFile(now)}.md`);
}

/** git 仓库根探测：git rev-parse --show-toplevel（失败跳过——非 git 仓库/无 git 均返回 undefined）。 */
export function resolveGitRoot(cwd: string): string | undefined {
	try {
		const out = execSync("git rev-parse --show-toplevel", { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], timeout: 3000 });
		const root = out.trim();
		return root || undefined;
	} catch {
		return undefined;
	}
}

/** 五段式自包含提示词组装（纯函数，零 IO）。 */
export function buildTaskExportMarkdown(input: TaskExportInput): string {
	const now = input.now ?? new Date();
	const sections: string[] = [];
	sections.push("# 角色设定", "", input.agent.systemPrompt.trim() || "(该角色无 systemPrompt 正文)", "");
	sections.push("# 任务", "", input.task.trim(), "");
	sections.push("# 工作环境", "", `- 工作目录：${path.resolve(input.taskCwd)}`);
	if (input.gitRoot) sections.push(`- Leader 仓库根：${input.gitRoot}（git rev-parse --show-toplevel）`);
	sections.push(`- 参照模型：${input.modelSpec || "(未解析)"}（外部工具模型不限，仅供参照）`, "");
	sections.push("# 工程纪律", "", EXPORT_DISCIPLINE_TEXT, "");
	sections.push(
		"# 完成回链", "",
		"完成后把产物绝对路径清单与结论摘要粘回 Amagi 会话，Leader 按路径验收。",
		`本文件由 amagi-pi task exportPrompt 生成（${stampForText(now)}）；原派发参数 agent=${input.agent.name}，task 摘要：${taskSummaryClip(input.task)}`, "",
	);
	return sections.join("\n");
}

/**
 * 导出任务书到磁盘（唯一落盘入口）：
 *   - 缺省路径：<taskCwd>/.amagi-export/task-<agent>-<yyyyMMdd-HHmmss>.md（同秒冲突加 -2/-3 序号）；
 *   - 显式路径：相对 leaderCwd 解析（缺省 process.cwd()），父目录不存在则递归创建；
 *   - 写入 mode 0o600（writePromptTmp 风格：提示词含任务/路径上下文，不放大可读面）。
 * 失败返回可读根因（目录创建失败/写入失败分开归因），不 throw。
 */
export function exportTaskPrompt(input: TaskExportInput): TaskExportResult {
	const now = input.now ?? new Date();
	let target: string;
	if (input.explicitPath !== undefined) {
		target = path.resolve(input.leaderCwd ?? process.cwd(), input.explicitPath);
	} else {
		target = defaultExportPath(input.taskCwd, input.agent.name, now);
		for (let n = 2; fs.existsSync(target) && n < 100; n++) {
			target = defaultExportPath(input.taskCwd, input.agent.name, now).replace(/\.md$/, `-${n}.md`);
		}
	}
	const dir = path.dirname(target);
	try {
		fs.mkdirSync(dir, { recursive: true });
	} catch (e) {
		return { ok: false, message: `[导出失败] 创建目录失败 ${dir}: ${e instanceof Error ? e.message : String(e)}` };
	}
	const content = buildTaskExportMarkdown(input);
	try {
		fs.writeFileSync(target, content, { mode: 0o600 });
	} catch (e) {
		return { ok: false, message: `[导出失败] 写入 ${target} 失败: ${e instanceof Error ? e.message : String(e)}` };
	}
	return { ok: true, path: target, bytes: Buffer.byteLength(content, "utf8") };
}
