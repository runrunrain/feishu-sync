import type { ContextMode } from "./contracts/task.ts";
/**
 * task-service.ts — 任务控制面服务（v2 批次B）。
 *
 * 背景（v2 分析 §4）：此前任务一旦派发只有两条出路——自然终态或进程重启；
 * 无查询单任务/等待一组任务/主动取消的产品级入口。Codex 长板（TaskService get/wait/cancel）
 * 在本批次落地为薄服务层，统一供 task 工具参数（wait/cancel）、批次C GroupScheduler、
 * 批次D RPC adapter 复用——控制面只有一份语义。
 *
 * 契约：
 *  - getTask：registry 只读快照 + 准入层位置注解（queued/running）。
 *  - waitTasks：50ms 轮询 registry（内存读取开销可忽略），本轮结算态 =
 *    done/blocked/error/answered/cancelled。blocked 表示子进程本轮已经退出、会话仍可 resume，
 *    因此 wait 必须返回给 Leader 处理问题，不能把一个已退出的进程永久当作 running。
 *    answering 才是活跃态；超时不取消任何任务，只如实返回未决项及其耗时/最近活动/准入位置。
 *    等待期间登记 sync-wait（自定义工具虽有 start/end 边界事件，但长等待期未必持续 update；
 *    用领域计数防主进程活性看门狗误杀）。
 *  - cancelTask：幂等收口（K3：状态写经内核 cancel 命令——task-kernel 唯一写入口；槽位释放/SIGTERM 链保留原样，那是 K4/K6 的活）——
 *      queued（准入等待中）→ cancelQueued 出队 + 内核 cancel 置 cancelled（零副作用，未占槽未 spawn）；
 *      running → 内核 cancel（revision+1 stale 防护基线）后 child SIGTERM→2s SIGKILL；
 *        槽位由 runPiTask finalize/onFinalize 链恰好一次归还（本函数不直接 release，防双释放竞态：
 *        提前 release 会让 waiter 晋级而旧 child 尚未退出，瞬时超容量）；
 *      blocked/answering → 内核 cancel（无 child 可杀；answering 的 resume 新任务是
 *        独立 taskId，不级联——语义：取消的是"待答记录"，续跑任务有自己的生命周期）；
 *      终态（done/error/answered/cancelled）→ 拒绝（幂等语义：已收口，不重复写）。
 *  - resolveExternalTask（ev-20260908-f189e7）：blocked/排队任务的轻量「已外部处置」收口（K3：状态写经内核
 *      resolve-external 命令）——与 cancelled 区分（产物已在外部采用非放弃）；纯状态迁移零 spawn 零重跑；
 *      queued → cancelQueued 出队 + 置 resolved-external；blocked/answering → revision+1 后
 *      置 resolved-external（记 resolveNote 收口注记 + endedAt 时间）；running → 拒绝（运行中
 *      任务的外部替代是取消语义，不混淆两种终态）；终态 → 拒绝（幂等）。
 *  - 所有路径返回结构化结果，永不抛错。
 *
 * K5a（方案 §3.1/§3.5/§8.1-K5a）：统一 submit 归一化入口——task-tool 的 sync 与 background 提交
 * 共用 submitTaskKernel（归一化输入 → 冻结真实 TaskSpec → 内核 register，saveSpec+current 清单落盘
 * 成功才返回 ok），交付失败封闭（清单落盘失败 = 明确错误，不占槽、不 spawn）；grantStartTask 在
 * spawn 前持久化 launchIntent（§3.5 派发序列：冻结 spec → 写 spec 与 queued current → 共同准入 →
 * 持久化 launchIntent → 启动后端）。delivery（sync=wait / background=handle）不分状态机——同一
 * 生命周期，只影响 Leader 等待方式；kernelViewLine 供 sync 返回与后台完成通知读同一内核投影版本
 * （不走桥补写，K5a 验收 4）。
 */

import { randomUUID } from "node:crypto";
import { SUBMIT_BASELINE_POLICY } from "./baseline-policy.ts";
import * as os from "node:os";
import { getMachineId } from "./data-dir.ts";
import { registry, type TaskRecord, type TaskRelationMeta, type TaskStatus } from "./task-registry.ts";
import { cancelQueued, admissionStateOf } from "./admission.ts";
import { beginSyncWait, endSyncWait } from "./sync-wait.ts";
import { createTaskKernel, type KernelTaskView, type TaskKernelRuntime } from "./task-kernel.ts";
import { createTaskStore } from "./task-store.ts";
import { sealSpec, type OutputSpec, type ReceiptSummary, type TaskPage, type TaskReceipt, type TaskRun, type TaskSpec, type TaskView as ContractTaskView, type WorkspaceSpec } from "./contracts/task.ts";
import { availableWaiverIds } from "./contracts/evidence.ts";
import { validatePermissionGrant, type PathRule, type PermissionGrant } from "./contracts/permission.ts";
import { matchPathRule } from "./task-permission.ts";
import { claimWorktreeLease, releaseWorktreeLease, worktreeOwnership } from "./worktree.ts";
import { err, ok, validateTaskQuery, type ContractError, type Result, type TaskKey, type TaskQuery } from "./contracts/view.ts";
import type { ExecutionObservation, RunObservationTarget } from "./execution-port.ts";
// ev-20261014-4f7500：stale-receipt 差异定位（首差位+片段）单源复用 contracts/command.ts。
// ev-20261021-fix（diting F1）：非 uuid 形状的不匹配输入附形状可疑诊断（撤销无条件栅栏后的
// 诊断增强；合法合成/历史回执仍按精确相等决策，不受形状影响）。
import { isValidReceiptIdShape, receiptIdMismatchHint } from "./contracts/command.ts";

/** K3：进程级唯一任务内核（惰性创建；K8c 组合根已前移到 index.ts 启动实例化）。
 *  创建即 attachRegistry 安装迁移桥（@deprecated K4-K8 拆除）；deps.onSettle 由组合根注入
 *  （K8c：GC 适配器 = registry.settleGc），未注入时回退 attachRegistry 目标的 settleGc。 */
let taskKernel: TaskKernelRuntime | undefined;
export interface TaskKernelOwnerOptions {
	/** owner 逻辑身份（K8c 组合根注入；首个创建者生效；缺省 amagi-leader-local）。 */
	ownerId?: string;
	/** 终态回调（K8c 组合根注入 GC 清理适配器；缺省回退 attachRegistry 目标的 settleGc）。 */
	onSettle?: (taskId: string) => void;
}
export function getTaskKernel(opts?: TaskKernelOwnerOptions): TaskKernelRuntime {
	if (!taskKernel) {
		taskKernel = createTaskKernel({
			store: createTaskStore(),
			...(opts?.ownerId !== undefined ? { ownerId: opts.ownerId } : {}),
			...(opts?.onSettle !== undefined ? { onSettle: opts.onSettle } : {}),
		});
		taskKernel.attachRegistry();
	}
	return taskKernel;
}
/** 测试隔离：复位内核单例（生产不调用）。 */
export function resetTaskKernelForTest(): void {
	taskKernel = undefined;
}

// ── v2.1 会话盖章（恢复对账会话精确绑定） ──────────────────────────────────────

/** Leader 进程当前会话标识（sessionFile 路径优先，回退 sessionId；组合根 index.ts 在每次
 *  session_start 捕获注入）。派发冻结 spec 时写入 spec.leaderSession——恢复对账据此把在途
 *  记录绑定到原会话；未捕获（无会话面/防御缺省）= 不盖章，对账侧按 pull-only 处理。 */
let leaderSessionStamp: string | undefined;

/** 组合根注入当前会话标识（每 session_start 调用；undefined/空串 = 不盖章）。 */
export function setLeaderSessionStamp(v: string | undefined): void {
	leaderSessionStamp = typeof v === "string" && v ? v : undefined;
}

/** 当前会话盖章（供派发冻结面与测试读取；未捕获 → undefined）。 */
export function getLeaderSessionStamp(): string | undefined {
	return leaderSessionStamp;
}

// ── v2.1-A1 机器盖章（owner 身份稳定化：spec.machineId 冗余记录，不改契约版本语义） ──

/** 本机持久身份盖章（data-dir machine.json 随机 UUID；组合根 index.ts 启动时注入）。派发冻结 spec
 *  时写入 spec.machineId——恢复对账据此把 ownerId 不匹配但机器匹配的记录识别为本机历史；
 *  未注入（子进程/测试）= 不盖章，旧记录保持 foreign-owner 报告可 adopt 收口。 */
let leaderMachineStamp: string | undefined;

/** 组合根注入本机持久身份（每进程一次；undefined/空串 = 不盖章）。 */
export function setLeaderMachineStamp(v: string | undefined): void {
	leaderMachineStamp = typeof v === "string" && v ? v : undefined;
}

/** 当前机器盖章（供派发冻结面/恢复对账缺省与测试读取；未注入 → undefined）。 */
export function getLeaderMachineStamp(): string | undefined {
	return leaderMachineStamp;
}

// K8c（方案 §3.1/§8.1-K8c）：Leader 逻辑身份（可信来源——组合根注入，模型参数不能构造，N1 单写者栅栏）。
// ev-20261005-055864（diting F-03）：从 index.ts 组合根下移至此——resume 桥接的 reconcile 需与生产
// applyTaskRecovery 同源 owner（旧位置在 index 使引擎层拿不到，缺省 fallback "amagi-leader-local"
// 被生产 owner fence 拒绝）。优先 AMAGI_OWNER_ID；缺省 user@machineId 派生（v2.1-A1：machineId 是
// 数据目录内 machine.json 持久 UUID，跨重启/hostname 漂移稳定；他机记录归 foreign-owner 只报告）。
function ownerIdForMachine(machineId: string): string {
	let user = "local";
	try { user = os.userInfo().username || "local"; } catch { /* lint-exempt:兼容无 userinfo 环境 */ }
	return `amagi-leader-${user}@${machineId}`;
}

export function resolveLeaderOwnerId(): string {
	return process.env.AMAGI_OWNER_ID?.trim() || ownerIdForMachine(getMachineId());
}

/** 查询只消费已注入身份；不能为只读查找触发 getMachineId 的建档/数据迁移。 */
function knownLeaderOwnerId(): string | undefined {
	return peekTaskKernel()?.ownerId ?? (process.env.AMAGI_OWNER_ID?.trim()
		|| (leaderMachineStamp ? ownerIdForMachine(leaderMachineStamp) : undefined));
}

/** K5a：只读探测内核单例（未创建返回 undefined——读路径不得因读取两创建内核/安装桥，副作用限定在提交/控制面）。 */
export function peekTaskKernel(): TaskKernelRuntime | undefined {
	return taskKernel;
}

// ── ev-20261019-06c169：执行期默认 JSON 观察 sink 工厂 ──────────────────────

/** 执行期默认 JSON 观察 sink（runPiTask 唯一 spawn 引擎消费；类型与 task-run.RunObservationTarget 结构同构）。
 *  设计「JSON 观察修复」责任划分：对当前已注册契约任务自动接管物理观察——捕获创建时的内核引用、
 *  owner、dispatch revision 与本次运行身份（backendRunId），会话切换后不转读新全局内核（旧任务
 *  不补进新会话 registry）。仅限执行路径（runPiTask）调用；只读查询不得使用。未注册契约（纯 legacy
 *  测试环境/无内核）返回 undefined，不为观察自动建档。 */
export function createDefaultJsonObservation(taskId: string, backendRunId: string): RunObservationTarget | undefined {
	const kernel = peekTaskKernel();
	const view = kernel?.get(taskId);
	if (!kernel || !view) return undefined;
	const key: TaskKey = { ownerId: kernel.ownerId, taskId, revision: view.revision };
	return {
		key,
		backendRunId,
		emit: (observation: ExecutionObservation) => kernel.apply({
			type: "observe",
			key: observation.key,
			backendRunId: observation.backendRunId,
			observationSeq: observation.observationSeq,
			event: observation.event,
		}),
	};
}

// ── K8c：三轴查询应用入口（§3.3 TaskApplication.query；只读——不 spawn、不续接、不修复磁盘） ─────

/** 三轴查询结果：契约任务页（TaskPage DTO）+ 未进内核的 v1 遗留记录（无三轴，观察层另行标注）。 */
export interface QueryViewsResult {
	page: TaskPage;
	/** registry 投影中无内核视图的记录（v1 遗留/重启后未对账），仅标识与状态。 */
	legacy: Readonly<Array<{ taskId: string; agent: string; status: TaskStatus }>>;
}

function viewOrderKey(v: Readonly<ContractTaskView>): { at: number; id: string } {
	return { at: v.run.queuedAt, id: v.taskId };
}

/** 只读磁盘回退视图（重启后未重种子内核的契约任务）：store.load 纯读（不种子内核/不修复磁盘），
 *  从 spec/run/(receipt) 合成 TaskView——nextActions 留空（重启语境不驱动动作）。 */
function synthViewFromStore(loaded: { spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt }): ContractTaskView {
	const { spec, run, receipt } = loaded;
	const rs: ReceiptSummary | undefined = receipt
		? {
			receiptId: receipt.receiptId, receiptSeq: receipt.receiptSeq, settlement: receipt.settlement,
			acceptance: receipt.acceptance, specDigest: receipt.specDigest, missing: receipt.missing,
			// ev-20260924-a28713：磁盘回退视图同样单源填充可 waive 全集（accept 决策面信息不因回退投影丢失）
			waivable: availableWaiverIds(receipt),
			...(run.currentReceipt ? { ref: run.currentReceipt } : {}),
		}
		: undefined;
	return {
		viewVersion: 1,
		taskId: run.taskId,
		ownerId: run.ownerId,
		revision: run.revision,
		stateSeq: run.stateSeq,
		assurance: (typeof spec.permission === "object" && spec.permission !== null && Array.isArray((spec.permission as { tools?: unknown }).tools) && ((spec.permission as { tools?: unknown }).tools as unknown[]).length > 0)
			? ((spec.permission as { assurance?: unknown }).assurance === "tool-enforced" ? "tool-enforced" : "guarded")
			: "guarded",
		execution: run.execution,
		settlement: run.settlement,
		acceptance: run.acceptance,
		degraded: [],
		spec: {
			specId: spec.specId, specDigest: spec.specDigest, agent: spec.agent, assignment: spec.assignment,
			outputs: spec.outputs, contextMode: spec.contextMode,
			...(spec.parentTaskId !== undefined ? { parentTaskId: spec.parentTaskId } : {}),
		},
		run,
		...(rs !== undefined ? { receipt: rs } : {}),
		nextActions: [],
	};
}

type StoredTask = { spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt };

/** 查询/决策共享本机身份口径：保留原 owner，不自动采纳 foreign-owner。 */
function checkStoredTaskOwner(spec: Readonly<TaskSpec> | undefined, run: Readonly<TaskRun>, ownerId: string | undefined): Result<true> {
	if (run.ownerId === ownerId
		|| (spec?.machineId !== undefined && spec.machineId === getLeaderMachineStamp())
		|| (ownerId !== undefined && createTaskStore().hasOwnerAdoption(run.taskId, run.ownerId, ownerId))) return ok(true);
	return err("foreign-owner", `任务 ${run.taskId} 属于 foreign-owner（${run.ownerId}）——N1 单写者栅栏；本机历史须先 /amagi recovery adopt ${run.taskId}`, ["handle"], "none");
}

/** ev-20261008-276846：内存句柄缺席时按明确 taskId/≥8 位唯一前缀只读查契约。
 *  校验完整存储链与本机身份，不种子内核、不回填 registry、不扫描历史 name/session。 */
export async function resolveStoredTaskHandle(
	handle: string,
	ownerId = knownLeaderOwnerId(),
): Promise<Result<StoredTask | undefined>> {
	if (!/^[A-Za-z0-9_-]{1,64}$/.test(handle)) return ok(undefined);
	const store = createTaskStore();
	const exact = await store.loadIfPresent(handle);
	if (!exact.ok) return exact;
	let loaded = exact.value;
	if (!loaded) {
		const candidates = store.findTaskIdsByPrefix(handle);
		if (!candidates.ok) return candidates;
		if (candidates.value.length > 1) {
			return err("ambiguous-handle", `歧义 "${handle}" 匹配多个磁盘任务（复制完整 taskId）：\n${candidates.value.map((id) => `  • taskId=${id}`).join("\n")}`, ["handle"], "none");
		}
		if (candidates.value.length === 0) return ok(undefined);
		const candidate = await store.load(candidates.value[0]);
		if (!candidate.ok) return candidate;
		loaded = candidate.value;
	}
	const access = checkStoredTaskOwner(loaded.spec, loaded.run, ownerId);
	return access.ok ? ok(loaded) : access;
}

/** K8c：三轴只读查询（handle/view/cursor/limit）。handle 缺省 = 全量分页（新→旧）；
 *  内核单例经 peek 只读探测（未创建不因查询而创建——零副作用）；handle 模式对内核未持有的
 *  契约任务回退 store.load 纯读合成视图（重启后未对账种子也可查三轴；不修复磁盘）；
 *  分页 cursor 为不透明偏移编码。 */
export async function queryTaskViews(query: TaskQuery): Promise<Result<QueryViewsResult>> {
	const validated = validateTaskQuery(query);
	if (!validated.ok) return validated;
	const kernel = peekTaskKernel();
	if (query.handle !== undefined) {
		// 会话内别名优先；缺席时只读查明确磁盘身份，不收编旧会话展示记录。
		let resolved: { taskId: string } | undefined;
		try {
			resolved = registry.resolveSession(query.handle);
		} catch (e) {
			return err("query-ambiguous-handle", e instanceof Error ? e.message : String(e), ["handle"]);
		}
		if (!resolved) {
			const stored = await resolveStoredTaskHandle(query.handle);
			if (!stored.ok) return stored.error.code === "ambiguous-handle"
				? err("query-ambiguous-handle", stored.error.message, stored.error.fields)
				: stored;
			if (!stored.value) return err("query-task-not-found", `未找到任务: "${query.handle}"（会话与契约存储均无明确 taskId；历史任务可用完整 ID 或至少 8 位唯一前缀）`, ["handle"]);
			const sv = kernel?.get(stored.value.run.taskId) ?? synthViewFromStore(stored.value);
			return ok({ page: { items: [sv], truncated: false, snapshotSeq: sv.stateSeq }, legacy: [] });
		}
		const view = kernel?.get(resolved.taskId);
		const rec = registry.get(resolved.taskId);
		if (!view) {
			// 只读磁盘回退：重启后内核未重种子的契约任务（干净记录不经对账种子）——store.load 纯读合成视图
			try {
				const loaded = await createTaskStore().load(resolved.taskId);
				if (loaded.ok) {
					const access = checkStoredTaskOwner(loaded.value.spec, loaded.value.run, knownLeaderOwnerId());
					if (!access.ok) return access;
					const sv = synthViewFromStore(loaded.value);
					return { ok: true, value: { page: { items: [sv], truncated: false, snapshotSeq: sv.stateSeq }, legacy: [] } };
				}
			} catch { /* 回退失败走遗留错误路径 */ }
			return err("query-legacy-task", `任务 ${resolved.taskId} 无内核契约视图（v1 遗留记录，status=${rec?.status ?? "unknown"}）——三轴仅对契约任务成立，遗留详情用 query_task({ session }) 路径`, ["handle"]);
		}
		return { ok: true, value: { page: { items: [view], truncated: false, snapshotSeq: view.stateSeq }, legacy: [] } };
	}
	// 全量分页：契约任务（内核视图）新→旧 + 遗留记录清单
	// ev-20261019-06c169：有可信会话键时合并本会话 registry 候选与 spec.leaderSession 盖章的磁盘候选
	//（重启后 registry 快照缺席/裁剪时列表不再归零；只读回退不种子内核/不投影 registry/nextActions 空）；
	// 无会话键时仅保留内存候选（不扫描全库猜当前会话，历史调用方语义不变）。
	const records = registry.list();
	const sessionKey = getLeaderSessionStamp();
	const views: ContractTaskView[] = [];
	const legacy: Array<{ taskId: string; agent: string; status: TaskStatus }> = [];
	const merged = new Set<string>();
	if (sessionKey === undefined) {
		for (const rec of records) {
			merged.add(rec.taskId);
			const v = kernel?.get(rec.taskId);
			if (v) views.push(v);
			else legacy.push({ taskId: rec.taskId, agent: rec.agent, status: rec.status });
		}
	} else {
		const store = createTaskStore();
		const ownerId = kernel?.ownerId ?? knownLeaderOwnerId();
		const recoveryIncomplete = (e: { code: string; message: string; fields?: readonly string[] }): Result<QueryViewsResult> =>
			err("query-recovery-incomplete", `本会话历史契约枚举不完整（${e.code}）：${e.message}——不能伪装成空列表；单任务可按完整 taskId/handle 查询，全量清单看 /amagi recovery list`, ["list"], "none", [{ hint: "修复或隔离损坏的任务目录后重试列表查询" }]);
		// 1) registry 候选：内存权威视图优先；无视图候选经 loadIfPresent 区分真 v1（明确无契约记录）与磁盘契约（仅本会话盖章列入）
		for (const rec of records) {
			merged.add(rec.taskId);
			const v = kernel?.get(rec.taskId);
			if (v) { views.push(v); continue; }
			const stored = await store.loadIfPresent(rec.taskId);
			if (!stored.ok) return recoveryIncomplete(stored.error);
			if (stored.value === null) {
				legacy.push({ taskId: rec.taskId, agent: rec.agent, status: rec.status }); // 真 v1：已确证无契约记录（损坏/权限错误不会落到这里）
				continue;
			}
			const loaded = stored.value;
			if (loaded.spec.leaderSession !== sessionKey) continue; // 明确他会话/无盖章的持久记录不自动列入（显式 handle/recovery 仍可拉取）
			if (!checkStoredTaskOwner(loaded.spec, loaded.run, ownerId).ok) continue; // foreign-owner 不混入本会话列表
			views.push(synthViewFromStore(loaded));
		}
		// 2) 磁盘候选：本会话盖章契约枚举（taskId 去重合并；只读合成视图不种子内核）
		const disk = await store.listByLeaderSession(sessionKey);
		if (!disk.ok) return recoveryIncomplete(disk.error);
		for (const loaded of disk.value) {
			if (merged.has(loaded.run.taskId)) continue;
			if (!checkStoredTaskOwner(loaded.spec, loaded.run, ownerId).ok) continue;
			merged.add(loaded.run.taskId);
			views.push(synthViewFromStore(loaded));
		}
		// 会话切换保护：异步读取期间会话键已变 → 拒绝回流（不向新会话返回旧结果）
		if (getLeaderSessionStamp() !== sessionKey) {
			return err("query-session-changed", "查询期间会话已切换（session_start 重新注入会话键）——本次结果属旧会话不回流；请重发查询", ["sessionKey"], "none");
		}
	}
	views.sort((a, b) => viewOrderKey(b).at - viewOrderKey(a).at || (viewOrderKey(a).id < viewOrderKey(b).id ? -1 : viewOrderKey(a).id > viewOrderKey(b).id ? 1 : 0));
	legacy.sort((a, b) => (a.taskId < b.taskId ? -1 : a.taskId > b.taskId ? 1 : 0));
	// v2.5.1（MN-4）：cursor 为不透明偏移编码（非负整数字符串）——非数字不再静默回卷首页，显式拒绝
	if (query.cursor !== undefined && !/^\d+$/.test(query.cursor)) {
		return err("invalid-cursor", `cursor 非法（${JSON.stringify(query.cursor)}）：不透明偏移编码为非负整数字符串——上页 nextCursor 原样回传，勿自造`, ["cursor"]);
	}
	const offset = Math.max(0, Number.parseInt(query.cursor ?? "0", 10) || 0);
	const limit = query.limit ?? 20;
	const items = views.slice(offset, offset + limit);
	const truncated = offset + items.length < views.length;
	return {
		ok: true,
		value: {
			page: {
				items,
				...(truncated ? { nextCursor: String(offset + items.length) } : {}),
				truncated,
				snapshotSeq: views.reduce((m, v) => Math.max(m, v.stateSeq), 0),
			},
			legacy,
		},
	};
}

// ── K5a：统一 submit 归一化入口（sync/background 共用；§3.5 派发序列的入口段） ──────

/** 归一化提交输入：由 task-tool/task-background 从工具参数与解析结果构造（模型已归一、cwd 已解析）；
 *  模型不手填 digest/owner——spec 由本入口冻结（sealSpec），taskId 即 specId（K3 裁量：一 spec 一 run）。 */
export interface KernelSubmitInput {
	taskId: string;
	agent: string;
	/** 任务书正文（冻结进 spec.assignment；与展示用 goal 可不同——goal 缺省取 assignment）。 */
	assignment: string;
	contextMode?: ContextMode;
	goal?: string;
	cwd: string;
	/** 归一后生效模型 spec（未解析到时省略——spec.effective.model 回退 "unknown"，记录 model 不被覆写）。 */
	model?: string;
	/** delivery 不分状态机（§4.1：sync=wait / background=handle 共用同一生命周期）；mode 仅作 legacy 展示字段。 */
	mode: "sync" | "background";
	name?: string;
	/** 运行图关联（batch/orchestrate 节点）；groupId/nodeId 进 register 命令，dependsOn 等展示字段随富化写入。 */
	relation?: TaskRelationMeta;
	/** 任务白名单快照（记录展示字段；子进程 env 由引擎从 opts 注入，不读本字段）。 */
	allowedPaths?: string[];
	artifactRefs?: string[];
	upstreamArtifactRefs?: string[];
	fallbackModels?: readonly string[];
	workspaceMode?: "existing" | "worktree";
	/** 本次 dispatch 的真实工作区事实；经引擎 opts 直传，不按 cwd 查找共享槽。 */
	worktreeDispatch?: Readonly<WorktreeDispatchFacts>;
	/** 冷却占位展示字段（queued/cooldown；重派到期复用同 taskId 提交，见 ev-20260916-101d8a）。 */
	queueReason?: "cooldown" | "capacity";
	retryAt?: number;
	/** 冷却占位重派：taskId 已在内核注册（queued 占位）——幂等复用记录，不重复 register（其余重复提交一律拒绝）。 */
	reuseQueued?: boolean;
	/** ev-20260920-61839b：声明产物契约（task_submit outputs[]）——冻结进 spec.outputs（此前恒空数组，
	 *  声明只流入权限交集计算，执行者与结算面都看不到）。缺省空（legacy 调用方兼容）。 */
	outputs?: readonly OutputSpec[];
	/** P1（§5.1/§8.3-P1）：冻结用有效授权（四方交集产物；scope 请求面→computeEffectiveGrant 的接线属
	 *  P2/P4——task-facets 现未传 scope，本字段是 spec 冻结入口）。非法 grant 在提交处 fail-closed 拒绝
	 *  （不回退宽权限占位）；缺省时 legacy 调用方冻结 v1 如实占位（guarded，不冒称 tool-enforced）。 */
	permission?: Readonly<PermissionGrant>;
}

export type KernelSubmitResult =
	| { ok: true; taskId: string; view: Readonly<KernelTaskView>; record: Readonly<TaskRecord>; revision: number }
	| { ok: false; taskId: string; code: string; message: string };

// ── P4（方案 §5.1/§8.3-P4）：冻结授权读取与续接不扩权断言 ──────────────────────

/** 真实 P1 授权判定（computeEffectiveGrant 产物恒含 amagi_resource；legacy v1 占位 tools 为空——
 *  引擎据此区分「v2 执法面」与「legacy 零干预面」，绝不把占位当可执法授权）。 */
export function isEnforceablePermissionGrant(p: unknown): p is PermissionGrant {
	return typeof p === "object" && p !== null && Array.isArray((p as { tools?: unknown }).tools)
		&& (p as { tools: unknown[] }).tools.length > 0;
}

/** P4：读取任务冻结授权（v2-store spec.permission；真实 P1 grant 返回，legacy 占位/缺记录 → undefined。
 *  引擎（task-run spawn 交付）与续接断言共同消费——授权只从冻结 spec 读，不接受调用方内存面。 */
export async function getFrozenPermissionGrant(taskId: string): Promise<PermissionGrant | undefined> {
	if (typeof taskId !== "string" || !taskId.trim()) return undefined;
	try {
		const loaded = await createTaskStore().load(taskId);
		if (!loaded.ok) return undefined;
		return isEnforceablePermissionGrant(loaded.value.spec.permission) ? loaded.value.spec.permission : undefined;
	} catch {
		return undefined; // 存储不可读 = 无可执法面（不拒单：legacy 面继续，引擎零执法不变）
	}
}

// ev-20261007-ef07e6 F5：事实随本次 engineOpts → KernelSubmitInput 直传；没有共享路径槽或 TTL。
export interface WorktreeDispatchFacts {
	repoRoot: string;
	worktreePath: string;
	worktreeName: string;
	branch: string;
	leaseId: string;
	baseCommit?: string;
	/** ev-20261017-cd233f：实际生效的检出基线（dirty-snapshot=主树脏快照；head/缺省不落字段——审计/展示面）。 */
	base?: "head" | "dirty-snapshot";
	dependencyVisibility: "portable" | "main-tree" | "unknown";
}

/** 只读读取冻结 spec.workspace（磁盘 store 回退口径与 getFrozenPermissionGrant 同源；无记录/不可读 → undefined）。 */
export async function getFrozenWorkspaceSpec(taskId: string): Promise<WorkspaceSpec | undefined> {
	if (typeof taskId !== "string" || !taskId.trim()) return undefined;
	try {
		const loaded = await createTaskStore().load(taskId);
		if (!loaded.ok) return undefined;
		return loaded.value.spec.workspace;
	} catch { /* lint-exempt:存储不可读=无冻结 workspace（与 getFrozenPermissionGrant 同语义） */
		return undefined;
	}
}

/** F8：续接来源只读供给。store 明确无记录且内核也不持有才为历史；IO/校验错误
 *  不被内存掩盖。磁盘缺席但内核有完整冻结 spec 仍为现代（不能丢 worktree/授权/outputs）。 */
export async function loadResumeParentSpec(taskId: string): Promise<Result<Readonly<TaskSpec> | null>> {
	let loaded: Awaited<ReturnType<ReturnType<typeof createTaskStore>["loadIfPresent"]>>;
	try { loaded = await createTaskStore().loadIfPresent(taskId); }
	catch (e) { return err("store-io-error", `父契约读取异常：${String(e)}`, ["handle"], "none"); }
	if (!loaded.ok) return loaded;
	const memory = peekTaskKernel()?.frozenSpecOf(taskId);
	const spec = loaded.value?.spec ?? memory;
	if (!spec) return ok(null);
	if (!isEnforceablePermissionGrant(spec.permission)) {
		return err("resume-parent-contract-unavailable", "内核/磁盘持有父契约但冻结授权/outputs 无法恢复（bridge 占位不能降级 legacy）", ["permission", "outputs"], "none");
	}
	if (loaded.value && memory && memory.verification.id !== "bridge-legacy" && memory.specDigest !== spec.specDigest) {
		return err("resume-parent-conflict", "内存与磁盘父冻结契约不同源，不能猜测授权/outputs", ["specDigest"], "none");
	}
	return ok(spec);
}

/** P4：子授权 ⊆ 父授权逐通道断言（resume/续接不扩权；P1 四方交集对角色/用户面天然收窄，父链是第二道闸）。
 *  - shell/assurance：父 deny/tool-enforced ⇒ 子不得更宽；
 *  - read/write/reportFiles：ev-20260919 门禁减重后不再构成扩权轴（写面声明性化）；
 *  - deny：父禁入区不得被移除（子可新增 deny，不可丢弃——否则实质保护被绕）；
 *  - mcp/lsp/tools：子名单 ⊆ 父名单。违规逐条列出供拒绝文案透出。 */
export function permissionGrantSubsetOf(
	child: Readonly<PermissionGrant>,
	parent: Readonly<PermissionGrant>,
): { ok: true } | { ok: false; violations: string[] } {
	const violations: string[] = [];
	if (parent.shell === "deny" && child.shell !== "deny") violations.push(`shell：父授权 shell=deny，子授权 shell=${child.shell}（扩权）`);
	if (parent.assurance === "tool-enforced" && child.assurance !== "tool-enforced") violations.push(`assurance：父保证等级 tool-enforced，子授权 ${child.assurance}（扩权）`);
	// ev-20260919（门禁减重）：write/reportFiles 对比随写面声明性化退役（对称 read 恒 ["**"]）——
	// 写不再构成扩权轴；硬语义闸保留：shell/assurance（上）与 deny（下）。
	for (const pd of parent.deny) {
		// v2.5.1（MN-2）：deny 等价判定按规则对规则精确匹配（pattern-vs-value）——语义等价改写（如
		// glob `s/**` → directory `s/`）会被判「移除（扩权）」而拒单：保守方向（宁拒不放大），非缺陷。
		if (!child.deny.some((cd) => matchPathRule(pd.value, cd))) {
			violations.push(`deny：父授权禁入区 ${pd.kind}:${pd.value} 在子授权被移除（扩权）`);
		}
	}
	for (const cm of child.mcp) {
		if (!parent.mcp.some((pm) => pm.server === cm.server && pm.tool === cm.tool)) {
			violations.push(`mcp：子授权工具 ${cm.server}/${cm.tool} 超出父授权名单`);
		}
	}
	for (const cl of child.lsp) {
		if (!parent.lsp.includes(cl)) violations.push(`lsp：子授权能力 ${cl} 超出父授权名单`);
	}
	for (const ct of child.tools) {
		if (!parent.tools.includes(ct)) violations.push(`tools：子授权工具 ${ct} 超出父授权名单`);
	}
	return violations.length === 0 ? { ok: true } : { ok: false, violations };
}

/** K5a：冻结真实 TaskSpec（机器检查/回执属 K7）。P1 起：input.permission（四方交集冻结授权）
 *  优先；legacy 调用方未接 scope 请求面时如实冻结 v1 执行面承诺：guarded=通用 shell 受 guards 守护
 *  （v1 子进程工具面现状），路径清单/工具名单由 P2/P4 执法接线——不冒称 tool-enforced。 */
function freezeSubmitSpec(input: KernelSubmitInput): TaskSpec {
	const wtFacts = input.worktreeDispatch;
	return sealSpec({
		version: 1,
		specId: input.taskId,
		agent: input.agent,
		assignment: input.assignment,
		inputs: [],
		// ev-20260920-61839b：声明产物冻结（此前恒 []——契约面闭环；结算面 finalizer 据此做产物完整性）
		outputs: input.outputs ? input.outputs.map((o) => ({ path: o.path, kind: o.kind, required: o.required, ...(o.purpose !== undefined ? { purpose: o.purpose } : {}) })) : [],
		// 权限冻结：P1 四方交集产物优先（已在 submitTaskKernel 校验合法）；缺省 legacy 如实占位。
		permission: input.permission ?? {
			policyVersion: 1, assurance: "guarded", tools: [], read: [], write: [], deny: [], reportFiles: [],
			shell: "guarded", mcp: [], lsp: [],
		},
		// 仅本次提交显式携带的工作树事实进入冻结面（existing 后任务不会消费失败请求的事实）。
		workspace: wtFacts
			? {
				cwd: input.cwd,
				mode: "worktree",
				branch: wtFacts.branch,
				...(wtFacts.repoRoot !== undefined ? { repoRoot: wtFacts.repoRoot } : {}),
				...(wtFacts.leaseId !== undefined ? { leaseId: wtFacts.leaseId } : {}),
				dependencyVisibility: wtFacts.dependencyVisibility,
				...(wtFacts.baseCommit !== undefined ? { baseCommit: wtFacts.baseCommit } : {}),
				...(wtFacts.base !== undefined ? { base: wtFacts.base } : {}),
			}
			: { cwd: input.cwd, mode: input.workspaceMode ?? "existing", dependencyVisibility: "unknown" },
		// C2-a（ev-20260921-89cc12，方案 §2.8）：新验证策略标记 id/version 升 v2，新建任务选
		// dependencyMode=copy-local——冻结依赖对象（root + 声明 workspace 子包 node_modules 私有
		// 副本；无 node_modules 的非 JS 项目捕获为空、无额外成本；copy-local 只复制已有本地依赖，
		// 不获得安装/网络/凭据读取权限）。旧冻结 spec 缺字段按 none（历史 specDigest 绝不回改）。
		verification: {
			id: "amagi-submit-v2", version: 2, ...SUBMIT_BASELINE_POLICY,
			checks: [], acceptance: "manual",
			criteria: [
				"完成契约：终稿含 ACHIEVEMENT 清单与 <!--AMAGI:DONE--> 末行（v1 收尾链；K7 起回执面接管机器检查）",
				"接受由 Leader 显式验收（acceptance=manual；ready/accepted 语义 K7 接线）",
			],
		},
		effective: {
			profileId: "amagi-v1", profileDigest: "amagi-v1",
			model: input.model || "unknown",
			fallbackModels: input.fallbackModels ?? [],
			hostVersion: "amagi-pi-v2-k5a", surfaceVersion: 1,
		},
		contextMode: input.contextMode ?? "isolated",
		...(input.relation?.parentTaskId ? { parentTaskId: input.relation.parentTaskId } : {}),
		// v2.1 会话盖章：派发会话标识冻结进 spec（digest 覆盖该字段；未捕获 → 不盖章 = pull-only）
		...(leaderSessionStamp !== undefined ? { leaderSession: leaderSessionStamp } : {}),
		// v2.1-A1 机器盖章：本机持久身份冻结进 spec（digest 覆盖；未注入 → 不盖章 = 对账按 foreign-owner 可 adopt）
		...(leaderMachineStamp !== undefined ? { machineId: leaderMachineStamp } : {}),
	});
}

/** K5a 统一提交：归一化 → 冻结 spec → 内核 register（saveSpec+current 清单落盘成功才 ok）→ legacy 展示字段富化。
 *  失败封闭：清单落盘失败返回明确错误（不占槽、不 spawn——零副作用，调用方直接回流）。
 *  成功时任务为 queued/pending/unreviewed（内核与 registry 投影同步）；准入占位与 grant-start 由调用方
 *  在本调用成功后进行（清单先于准入，K5a 验收 1）。 */
export async function submitTaskKernel(input: KernelSubmitInput): Promise<KernelSubmitResult> {
	let kernel: TaskKernelRuntime;
	try {
		kernel = getTaskKernel();
	} catch (e) {
		return { ok: false, taskId: input.taskId, code: "kernel-unavailable", message: `[submit 拒绝] 任务内核初始化失败，未进准入队列、未启动子进程：${e instanceof Error ? e.message : String(e)}` };
	}
	// F5：直传事实仍须属于当前 dispatch 的 cwd 与活跃 lease；不接受失效/错树的交接。
	if (input.worktreeDispatch) {
		const w = input.worktreeDispatch;
		const owner = worktreeOwnership().find((o) => o.leaseId === w.leaseId && !o.releasedAt);
		if (w.worktreePath !== input.cwd || !owner || owner.path !== w.worktreePath || owner.branch !== w.branch
			|| owner.root !== w.repoRoot || owner.name !== w.worktreeName || owner.baseCommit !== w.baseCommit) {
			return { ok: false, taskId: input.taskId, code: "worktree-dispatch-mismatch", message: "[submit 拒绝] worktree 事实不属于本次 cwd/活跃 lease（未建档、未 spawn）" };
		}
	}
	// P1（§5.1）：冻结授权 fail-closed 校验——非法 grant 整任务拒绝，不回退宽权限占位（零副作用：未建档/未占槽/未 spawn）。
	if (input.permission !== undefined) {
		const pv = validatePermissionGrant(input.permission);
		if (!pv.ok) {
			return { ok: false, taskId: input.taskId, code: `permission-${pv.error.code}`, message: `[submit 拒绝] permission 授予非法（fail-closed，不回退宽权限）：${pv.error.message}（fields: ${pv.error.fields.join(", ")}）` };
		}
	}
	// lease→task 绑定必须在首个 await（包括父授权读取）之前同步完成；不存在检查/attach 异步窗口。
	const leaseId = input.worktreeDispatch?.leaseId;
	let newlyClaimed = false;
	if (leaseId !== undefined) {
		const claim = claimWorktreeLease(leaseId, input.taskId);
		if (!claim.ok) return { ok: false, taskId: input.taskId, code: claim.code, message: `[submit 拒绝] ${claim.code}: ${claim.message}（未建档、未 spawn）` };
		newlyClaimed = claim.newlyClaimed;
	}
	let submitted = false;
	try {
	// P4（§5.1/§8.3-P4）：resume/续接不扩权——父链携带真实授权时，新提交授权逐通道 ⊄ 父冻结授权 → 整任务拒绝
	//（P1 四方交集对角色/用户面天然收窄；父链是第二道闸——绕过交集计算手工构造的授权同样被拦截）。
	// 父为 legacy 占位（无真实授权）时不设限：legacy 面行为零变化。
	if (input.relation?.parentTaskId !== undefined && isEnforceablePermissionGrant(input.permission)) {
		const parentGrant = await getFrozenPermissionGrant(input.relation.parentTaskId);
		if (parentGrant !== undefined) {
			const subset = permissionGrantSubsetOf(input.permission, parentGrant);
			if (!subset.ok) {
				return {
					ok: false, taskId: input.taskId, code: "permission-exceeds-parent",
					message: `[submit 拒绝] 续接任务授权超出父任务冻结授权（resume 不扩权；违规通道：${subset.violations.join("；")}）——收窄 scope 后重新提交`,
				};
			}
		}
	}
	const existing = kernel.get(input.taskId);
	if (existing) {
		// 冷却占位重派（queued 占位幂等复用）；其余重复提交拒绝（一 spec 一 run；续接/重派创建新 taskId）
		if (input.reuseQueued && existing.execution === "queued") {
			// 幂等复用：不重复 register（同 taskId 重复 register 内核拒绝），仅重申展示字段
		} else {
			return { ok: false, taskId: input.taskId, code: "kernel-invalid-command-state", message: `[submit 拒绝] 同 taskId 重复提交：${input.taskId} 已在内核（execution=${existing.execution}；一 spec 一 run，续接/重派创建新 taskId；冷却占位重派须 reuseQueued 且记录保持 queued）` };
		}
	} else {
		if (registry.get(input.taskId)) {
			return { ok: false, taskId: input.taskId, code: "kernel-invalid-command-state", message: `[submit 拒绝] taskId 碰撞：${input.taskId}（registry 已有同名记录而内核未持有——疑似外部写入；taskId 须为内核生成的安全新 id）` };
		}
		const spec = freezeSubmitSpec(input);
		const r = await kernel.apply({
			type: "register", spec,
			...(input.relation?.runId !== undefined ? { groupId: input.relation.runId } : {}),
			...(input.relation?.nodeId !== undefined ? { nodeId: input.relation.nodeId } : {}),
		});
		if (!r.ok) {
			return { ok: false, taskId: input.taskId, code: r.error.code, message: `[submit 拒绝] 任务契约清单落盘失败（${r.error.code}），未进准入队列、未启动子进程：${r.error.message}` };
		}
	}
	// legacy 展示字段富化（mode/goal/name/边界快照/运行图关联/冷却展示）：mode/allowedPaths/dependsOn 等
	// 不在 registry PATCHABLE 白名单、无内核命令等价物——唯一写入面是桥受控字段投影（一次写入一次 CAS；
	// 终稿字段面归 K7/K8，K8c 组合根把展示字段并入内核投影后拆除本写点）。
	const enrich: Partial<TaskRecord> = {
		goal: input.goal ?? input.assignment,
		mode: input.mode,
		upstreamArtifactRefs: input.upstreamArtifactRefs ?? [],
		...(input.model !== undefined ? { model: input.model } : {}),
		...(input.name !== undefined ? { name: input.name } : {}),
		...(input.allowedPaths !== undefined ? { allowedPaths: input.allowedPaths } : {}),
		...(input.artifactRefs !== undefined ? { artifactRefs: input.artifactRefs } : {}),
		...(input.queueReason !== undefined ? { queueReason: input.queueReason } : {}),
		...(input.retryAt !== undefined ? { retryAt: input.retryAt } : {}),
		...(input.relation?.runId !== undefined ? { runId: input.relation.runId } : {}),
		...(input.relation?.nodeId !== undefined ? { nodeId: input.relation.nodeId } : {}),
		...(input.relation?.parentTaskId !== undefined ? { parentTaskId: input.relation.parentTaskId } : {}),
		...(input.relation?.dependsOn !== undefined ? { dependsOn: input.relation.dependsOn } : {}),
	};
	for (const k of Object.keys(enrich) as Array<keyof TaskRecord>) {
		if ((enrich as Record<string, unknown>)[k as string] === undefined) delete (enrich as Record<string, unknown>)[k as string];
	}
	try { kernel.bridge.patchRecord(input.taskId, enrich); } catch { /* 展示字段富化失败不阻断（内核/存储权威已成立） */ }
	const view = kernel.get(input.taskId);
	const record = registry.get(input.taskId);
	if (!view || !record) {
		return { ok: false, taskId: input.taskId, code: "kernel-invalid-command-state", message: `[submit 异常] 注册后内核/投影缺位（${input.taskId}）——零准入零启动，请重派新任务` };
	}
	submitted = true;
	return { ok: true, taskId: input.taskId, view, record, revision: record.revision ?? 0 };
	} finally {
		// 只归还本次新 claim；输家和重复同 taskId 提交绝不清掉原所有权。
		if (!submitted && newlyClaimed && leaseId !== undefined) releaseWorktreeLease(leaseId, "submit rejected/exception", input.taskId);
	}
}

export interface KernelGrantResult {
	ok: boolean;
	/** 失败根因（内核错误文案）；成功时省略。 */
	message?: string;
}

/** K5a：内核 grant-start 命令（queued→running；launchIntent 持久化先于 spawn，§3.5）。
 *  失败封闭：任务离开 queued（被取消/已启动）即拒——调用方释放槽位、不 spawn。 */
export async function grantStartTask(taskId: string): Promise<KernelGrantResult> {
	const kernel = getTaskKernel();
	const view = kernel.get(taskId);
	if (!view) return { ok: false, message: `内核无任务 ${taskId}（未 register）` };
	const r = await kernel.apply({
		type: "grant-start",
		key: { ownerId: view.ownerId, taskId, revision: view.revision },
		backend: "json",
		launchIntent: { nonce: `k5a-${randomUUID()}`, at: Date.now() },
	});
	if (!r.ok) return { ok: false, message: r.error.message };
	return { ok: true };
}

/** K5a 验收 4：sync 返回与后台完成通知读同一内核投影版本（viewVersion/stateSeq/revision/三轴；不走桥补写）。
 *  内核未持有该任务（未提交/纯 legacy）时返回空串，不创建内核单例（读路径零副作用）。 */
export function kernelViewLine(taskId: string): string {
	const kernel = peekTaskKernel();
	if (!kernel) return "";
	try {
		const view = kernel.get(taskId);
		if (!view) return "";
		const receipt = view.receipt ? ` receipt=${view.receipt.receiptId}(${view.receipt.settlement}/${view.receipt.acceptance})` : "";
		// ev-20260924-a28713（P1）：accept 决策所需信息在决策点前可见——incomplete/failed 回执的
		// missing 与可 waive id 全集直接列在投影行（此前只在拒绝响应里出现，Leader 只能先猜后试错）。
		// ready 回执零噪音不输出；集合单源 availableWaiverIds（ReceiptSummary.waivable 同源）。
		// diting F7 修复：failed 且无缺口时省略空 missing=[] 段（可waive 列表仍携带决策信息）。
		const missingPart = view.receipt && view.receipt.missing.length > 0 ? ` missing=[${view.receipt.missing.join(",")}]` : "";
		const waivableLine = view.receipt && view.receipt.settlement !== "ready"
			? `${missingPart} 可waive=[${view.receipt.waivable.join(",")}]（accept 的 waivedCheckIds 取自此集合，按接受决策裁剪）`
			: "";
		const degraded = view.degraded.length > 0 ? ` degraded=${view.degraded.length}` : "";
		// diting-M3-A4：承诺可见——guarded 壳承诺非对抗隔离（hash 仅一致性），tool-enforced 为逐次执法。
		return `\n[内核视图 v${view.viewVersion}] taskId=${taskId.slice(0, 8)} stateSeq=${view.stateSeq} revision=${view.revision} execution=${view.execution} settlement=${view.settlement} acceptance=${view.acceptance} 承诺=${view.assurance}${receipt}${waivableLine}${degraded}（sync 返回与后台完成通知同版内核投影，K5a）`;
	} catch {
		return "";
	}
}

/** ev-20261028-b3ba43：本会话「已结束、有回执、尚无接受/拒绝决策」的任务清单（内核 nextActions 含 decide）。
 *  只读：peek 内核，不创建单例、不种子、不回填；registry 为本会话投影，不扫描历史会话。 */
export interface PendingAcceptance {
	taskId: string;
	agent: string;
	name?: string;
	execution: string;
	revision: number;
	receiptId: string;
	settlement: string;
	missing: readonly string[];
	endedAt?: number;
}

export function listPendingAcceptance(): PendingAcceptance[] {
	const kernel = peekTaskKernel();
	if (!kernel) return [];
	const out: PendingAcceptance[] = [];
	for (const rec of registry.list()) {
		let view: ContractTaskView | undefined;
		try { view = kernel.get(rec.taskId); } catch { continue; }
		if (!view?.receipt || view.acceptance !== "unreviewed" || !view.nextActions.includes("decide")) continue;
		out.push({
			taskId: rec.taskId, agent: rec.agent, ...(rec.name ? { name: rec.name } : {}),
			execution: view.execution, revision: view.revision,
			receiptId: view.receipt.receiptId, settlement: view.receipt.settlement,
			missing: view.receipt.missing, ...(rec.endedAt !== undefined ? { endedAt: rec.endedAt } : {}),
		});
	}
	return out.sort((a, b) => (a.endedAt ?? 0) - (b.endedAt ?? 0));
}

/** 取消控制面的封闭态：blocked 仍允许显式取消待答会话。 */
const CLOSED_STATUS = new Set<TaskStatus>(["done", "error", "answered", "cancelled", "resolved-external"]);
/** wait 观察的是“本轮是否已结算”，blocked 子进程已退出，必须作为 needs-attention 返回。 */
const WAIT_SETTLED_STATUS = new Set<TaskStatus>(["done", "blocked", "error", "answered", "cancelled", "truncated", "resolved-external"]);
const WAIT_POLL_MS = 50;
const SIGKILL_GRACE_MS = 2000;

export interface TaskView {
	record?: Readonly<TaskRecord>;
	/** 准入层位置（registry 与准入瞬时可能不一致：晋级微任务间隙 registry 仍 queued——以准入为准注解）。 */
	admission?: "running" | "queued";
}

export function getTask(taskId: string): TaskView {
	return { record: registry.get(taskId), admission: admissionStateOf(taskId) };
}

export interface PendingTaskProgress {
	taskId: string;
	/** 从派发/registry 建档到本次 wait 返回的耗时。 */
	elapsedMs: number;
	/** activityWindow 尾部至多两条摘要；每条空白归一并截断 60 字。 */
	lastActivity: string;
	/** 准入层位置；晋级微任务间隙以 admissionStateOf 的实时结果为准。 */
	admission: "running" | "queued";
	/** ev-20261012-381ddb：最近一次活动距本次 wait 返回的时刻（ms）；无活动窗口时缺省。 */
	lastActivityAgeMs?: number;
	/** ev-20261012-381ddb：建议下次等待时长（ms）——最近两次活动间隔 ×1.5，钳 [60s, 900s]；
 *  少于两条活动记录（无真实节奏可估）时缺省，不编造。 */
	suggestedNextWaitMs?: number;
}

export interface WaitResult {
	/** 已达终态的任务（any=首个，all=全部；含未知 taskId 的 unknown 占位）。 */
	settled: Array<{ taskId: string; status: TaskStatus | "unknown"; record?: Readonly<TaskRecord> }>;
	/** 兼容既有消费点的未决 taskId 清单。 */
	pending: string[];
	/** 未决任务的结构化进度；工具层可渐进切换，不破坏 pending:string[] 旧契约。 */
	pendingDetails: PendingTaskProgress[];
	timedOut: boolean;
}

/** 与停滞告警一致的最近活动摘要语义，下沉到服务层供 wait 结构化结果复用。 */
export function lastActivityDigest(rec: Readonly<Pick<TaskRecord, "activityWindow">> | undefined): string {
	return (rec?.activityWindow ?? [])
		.slice(-2)
		.map((ev) => String(ev.summary || ev.type || "").replace(/\s+/g, " ").trim().slice(0, 60))
		.filter(Boolean)
		.join(" | ");
}

function pendingProgress(taskId: string, now: number): PendingTaskProgress {
	const rec = registry.get(taskId);
	const rawDispatchTime = (rec as (Readonly<TaskRecord> & { dispatchTime?: unknown }) | undefined)?.dispatchTime;
	// 当前 registry 的 startedAt 即 create/派发时刻；若后续持久化独立 dispatchTime，优先消费该字段。
	const dispatchTime = typeof rawDispatchTime === "number" && Number.isFinite(rawDispatchTime)
		? rawDispatchTime
		: rec?.startedAt;
	const admission = admissionStateOf(taskId)
		?? (rec?.status === "queued" || rec?.status === "running" ? rec.status : "running");
	// ev-20261012-381ddb：活动距今 + 建议等待时长（按最近活动间隔估算）——长任务连续低信息量
	// 超时空转的根治面：把「等多久」就地给出。少两条活动记录不估（不编造节奏）。
	const tsList = (rec?.activityWindow ?? [])
		.map((ev) => (typeof ev.ts === "number" && Number.isFinite(ev.ts) ? ev.ts : null))
		.filter((t): t is number => t !== null);
	const lastTs = tsList.length > 0 ? tsList[tsList.length - 1]! : undefined;
	const lastActivityAgeMs = lastTs !== undefined ? Math.max(0, now - lastTs) : undefined;
	const suggestedNextWaitMs = tsList.length >= 2
		? Math.min(900_000, Math.max(60_000, Math.round(((lastTs! - tsList[tsList.length - 2]!) * 3) / 2)))
		: undefined;
	return {
		taskId,
		elapsedMs: dispatchTime === undefined ? 0 : Math.max(0, now - dispatchTime),
		lastActivity: lastActivityDigest(rec),
		admission,
		...(lastActivityAgeMs !== undefined ? { lastActivityAgeMs } : {}),
		...(suggestedNextWaitMs !== undefined ? { suggestedNextWaitMs } : {}),
	};
}

/** 等待一组任务到达终态。mode=any 首个终态即返；all 全部终态才返。超时只报告，不取消。 */
export async function waitTasks(ids: string[], mode: "any" | "all", timeoutMs: number): Promise<WaitResult> {
	const deadline = Date.now() + Math.max(0, timeoutMs);
	const unique = [...new Set(ids)];
	const settled = new Map<string, { taskId: string; status: TaskStatus | "unknown"; record?: Readonly<TaskRecord> }>();
	beginSyncWait();
	try {
		for (;;) {
			for (const id of unique) {
				if (settled.has(id)) continue;
				const rec = registry.get(id);
				if (!rec) settled.set(id, { taskId: id, status: "unknown" });
				else if (WAIT_SETTLED_STATUS.has(rec.status)) settled.set(id, { taskId: id, status: rec.status, record: rec });
			}
			const done = mode === "any" ? settled.size >= 1 : settled.size >= unique.length;
			const now = Date.now();
			if (done || now >= deadline) {
				const pending = unique.filter((id) => !settled.has(id));
				return {
					settled: [...settled.values()],
					pending,
					pendingDetails: pending.map((id) => pendingProgress(id, now)),
					timedOut: !done,
				};
			}
			await new Promise((r) => setTimeout(r, WAIT_POLL_MS));
		}
	} finally {
		endSyncWait();
	}
}

export interface CancelResult {
	ok: boolean;
	taskId: string;
	/** 取消后的状态（取消成功="cancelled"；终态拒绝=原状态；不存在=unknown）。 */
	status: TaskStatus | "unknown";
	message: string;
}

/** v2 批次D：外部后端取消拦截器（RPC pool 等无本地 child 的后端在此接管终止）。
 *  cancelTask 在 registry 置 cancelled（revision+1 stale 防护）后调用；首个返回 true 的
 *  拦截器视为已接管外部终止（异步尽力送达，拦截器内部容错）。 */
const cancelInterceptors: Array<(taskId: string) => boolean> = [];
export function registerCancelInterceptor(fn: (taskId: string) => boolean): void { cancelInterceptors.push(fn); }
export function resetCancelInterceptorsForTest(): void { cancelInterceptors.length = 0; }
function notifyCancelInterceptors(taskId: string): boolean {
	for (const fn of cancelInterceptors) { try { if (fn(taskId)) return true; } catch {} }
	return false;
}

/** 主动取消任务（幂等；终态拒绝）。 */
export function cancelTask(taskId: string, reason?: string): CancelResult {
	const rec = registry.get(taskId);
	if (!rec) return { ok: false, taskId, status: "unknown", message: `任务不存在: ${taskId}` };
	const why = (reason || "").trim() || "用户/系统主动取消";
	if (CLOSED_STATUS.has(rec.status)) {
		return { ok: false, taskId, status: rec.status, message: `任务已终态（${rec.status}），不可取消` };
	}

	const adm = admissionStateOf(taskId);

	// ── queued：准入等待中（含"已晋级但 registry 尚未 patch"的微任务间隙——该情形由
	// waiter continuation 自查 cancelled 放弃 spawn 并归还槽位，此处同样只需置终态） ──
	if (rec.status === "queued") {
		if (adm === "queued") cancelQueued(taskId); // 出队并 resolve waiter（"cancelled"）
		// K3：内核 cancel 命令（先 revision+1 撒销采纳资格，再迁移状态；N3 取消栅栏）
		const kr = getTaskKernel().bridge.cancelLegacy(taskId, `[已取消] ${why}（排队期间，未启动）`);
		if (!kr.ok) return { ok: false, taskId, status: rec.status, message: `取消失败: ${kr.message.slice(0, 120)}` };
		return { ok: true, taskId, status: "cancelled", message: `已取消（排队中，未启动）` };
	}

	// ── running：先 revision+1（stale 防护：旧回流不得再写），再置 cancelled，最后杀 child ──
	if (rec.status === "running") {
		// child 必须取原始引用：registry.get() 返回 deepFreeze 普通对象拷贝（kill 等方法在原型上，
		// 拷贝后丢失——取消将静默打不到进程）；getRunningChildren 直取内存原表。
		const child = registry.getRunningChildren().find((c) => c.taskId === taskId)?.child as { kill?: (sig?: string) => void; __amagiTerminateOwnedRun?: (reason: string) => void } | undefined;
		try {
			// K3：内核 cancel 命令（先 revision+1 撒销采纳资格，再迁移状态）；SIGTERM 链保留原样（K4/K6 的活）
			const kr = getTaskKernel().bridge.cancelLegacy(taskId, `[已取消] ${why}（运行中被终止）`);
			if (!kr.ok) return { ok: false, taskId, status: rec.status, message: `取消失败: ${kr.message.slice(0, 120)}` };
		} catch (e) {
			return { ok: false, taskId, status: rec.status, message: `取消失败: ${String(e).slice(0, 120)}` };
		}
		// 5d0ef1（ev-20260916）：优先引擎建立的幂等组级终止入口（POSIX 进程组 SIGTERM→3s→身份复核后
		// SIGKILL；控制面与引擎同一入口，不再各起宽限 timer）；非组模式维持 child 级 SIGTERM→2s SIGKILL。
		const _groupTerm = typeof child?.__amagiTerminateOwnedRun === "function" ? child.__amagiTerminateOwnedRun : undefined;
		if (_groupTerm) {
			try { _groupTerm("cancel"); } catch { /* 组级终止失败退回 child 级 */ }
		}
		if (!_groupTerm && child?.kill) {
			try { child.kill("SIGTERM"); } catch {}
			setTimeout(() => { try { child?.kill?.("SIGKILL"); } catch {} }, SIGKILL_GRACE_MS).unref?.();
		}
		// v2 批次D：无本地 child 的后端（RPC pool 等）经拦截器尽力送达终止（异步容错）
		const intercepted = !child && notifyCancelInterceptors(taskId);
		// 槽位归还由 runPiTask finalize/onFinalize 链恰好一次完成（此处不 release——见模块头契约）。
		return { ok: true, taskId, status: "cancelled", message: _groupTerm ? "已取消（进程组 SIGTERM 已发，3s 后组级 SIGKILL 兜底）" : child?.kill ? "已取消（SIGTERM 已发，2s 后 SIGKILL 兜底）" : intercepted ? "已取消（外部后端已送达终止）" : "已取消（无存活子进程）" };
	}

	// ── blocked/answering：无 child，直接终态化（内核 cancel；revision+1 stale 防护） ──
	const kr2 = getTaskKernel().bridge.cancelLegacy(taskId, `[已取消] ${why}（${rec.status} 状态）`);
	if (!kr2.ok) return { ok: false, taskId, status: rec.status, message: `取消失败: ${kr2.message.slice(0, 120)}` };
	return { ok: true, taskId, status: "cancelled", message: `已取消（原状态 ${rec.status}）` };
}

// ── ev-20260908-f189e7：resolve(external) 轻量收口（blocked 条目「已外部处置」终态） ──
// 背景：derived-kb-sync 会话三节点 blocked 后 Leader 已选「代套用」在会话内完成交付，但 blocked
// 条目仍以「⏸ 等待答复」驻留看板，主上误判插件卡死；cancel 语义上是放弃、resume 会新起进程，
// 两者都不表达「产物已外部采用、会话无需再跑」。此收口纯状态迁移（不 spawn、不重跑、不杀进程），
// 与 cancelled 状态可区分；收口方式记入 resolveNote、时间记入 endedAt（registry patch 终态路径自动落）。
export interface ResolveExternalResult {
	ok: boolean;
	taskId: string;
	/** 收口后状态（成功="resolved-external"；拒绝=原状态；不存在=unknown）。 */
	status: TaskStatus | "unknown";
	message: string;
}

/** blocked/排队任务的外部处置收口（幂等；终态拒绝；running 拒绝——运行中替代是取消语义）。 */
export function resolveExternalTask(taskId: string, note?: string): ResolveExternalResult {
	const rec = registry.get(taskId);
	if (!rec) return { ok: false, taskId, status: "unknown", message: `任务不存在: ${taskId}` };
	if (CLOSED_STATUS.has(rec.status) || rec.status === "truncated") {
		return { ok: false, taskId, status: rec.status, message: `任务已终态（${rec.status}），无需外部处置收口` };
	}
	// 运行中任务拒绝：外部替代时终止进程属取消语义（SIGTERM），不与「已外部处置」终态混淆——
	// 提示先行 cancel 或等本轮 blocked 后再收口（半途回流无意义，产物已在外部定型）。
	if (rec.status === "running") {
		return { ok: false, taskId, status: rec.status, message: "运行中任务不支持 resolve(external)——请 task({ cancel }) 终止，或等本轮 blocked 后再收口（外部处置语义面向已暂停/排队等待的会话）" };
	}
	const resolveNote = `[已外部处置] ${(note || "").trim() || "产物已在外部采用，会话无需再跑"}`;
	// ── queued：准入等待中（未 spawn）→ 出队（waiter 收到 "cancelled" 放弃 spawn）+ 置终态（K3：内核 resolve-external 命令） ──
	if (rec.status === "queued") {
		if (admissionStateOf(taskId) === "queued") cancelQueued(taskId);
		const kr = getTaskKernel().bridge.resolveExternalLegacy(taskId, resolveNote);
		if (!kr.ok) return { ok: false, taskId, status: rec.status, message: `外部处置收口失败: ${kr.message.slice(0, 120)}` };
		return { ok: true, taskId, status: "resolved-external", message: `已外部处置（排队中，未启动）——${resolveNote}` };
	}
	// ── blocked/answering：无 child，纯状态迁移（K3：内核 resolve-external 命令；revision+1 stale 防护；answering 的 resume 新任务独立生命周期不级联，与 cancel 同语义） ──
	const kr2 = getTaskKernel().bridge.resolveExternalLegacy(taskId, resolveNote);
	if (!kr2.ok) return { ok: false, taskId, status: rec.status, message: `外部处置收口失败: ${kr2.message.slice(0, 120)}` };
	const waitedMs = rec.blockedAt ? Math.max(0, Date.now() - rec.blockedAt) : undefined;
	const waitedNote = waitedMs !== undefined ? `，曾等待 ${Math.round(waitedMs / 1000)}s` : "";
	return { ok: true, taskId, status: "resolved-external", message: `已外部处置（原状态 ${rec.status}${waitedNote}）——${resolveNote}；终态不再可 resume` };
}

// ── K7（方案 §8.1-K7/§3.4 N8）：decide 应用命令（accept/reject 控制面；供 I1 task_control 接线）──
// 内核已实现 K1 v1.2 decide 语义（ev-20260918-0784ed）：accept 面向 done/truncated/error 且非 failed；error 前置须显式
// waive error-execution-coverage（接受「产物已被外部核采用」事实，豁免留痕）；incomplete 须显式 waive
// （waivedCheckIds ⊆ receipt.missing∪checks）；reject 不设 waive 门槛、不限 execution（failed 回执走
// reject 表达不接受）。decide 生成新回执（receiptSeq+1，沿用证据不重跑），旧回执不可变保留。

export interface DecideReceiptResult {
	ok: boolean;
	taskId: string;
	/** 决策后的接受态（成功=accepted/rejected；失败=决策前原状态）。 */
	acceptance: "unreviewed" | "accepted" | "rejected";
	/** 决策后回执序号（成功=新回执 receiptSeq；失败时为当前值或省略）。 */
	receiptSeq?: number;
	message: string;
	/** D1（ev-20260922-c896f8）：decide 拒绝时的结构化错误（code/message/fields/effects/repairExamples
	 *  ——内核错误不截断透传，task_control 不丢内核例子）。 */
	error?: ContractError;
}

/** K7：对当前回执显式决策（accept/reject）。幂等拒绝（已决策不可重复 decide）；决策引用当前
 *  receiptId（防陈旧决策）；栅栏校验经内核 revision 失效栅栏（key 取当前视图 revision，取消后旧
 *  revision 决策被拒）。actor 由入口身份提供（N8：子进程 DONE 标记不能 decide），模型参数不能
 *  伪造用户身份——受信调用上下文接线属 I1/K8c。 */
export async function decideTaskReceipt(
	taskId: string,
	verdict: "accept" | "reject",
	receiptId: string,
	decision: { actor: "leader" | "user"; reason: string; waivedCheckIds?: readonly string[] },
): Promise<DecideReceiptResult> {
	const fail = (acceptance: DecideReceiptResult["acceptance"], message: string, receiptSeq?: number, error?: ContractError): DecideReceiptResult =>
		({ ok: false, taskId, acceptance, message, ...(receiptSeq !== undefined ? { receiptSeq } : {}), ...(error !== undefined ? { error } : {}) });
	let kernel: TaskKernelRuntime;
	try {
		kernel = getTaskKernel();
	} catch (e) {
		return fail("unreviewed", `[decide 拒绝] 任务内核初始化失败：${e instanceof Error ? e.message : String(e)}`);
	}
	let view = kernel.get(taskId);
	if (!view) {
		const stored = await resolveStoredTaskHandle(taskId, kernel.ownerId);
		if (!stored.ok) return fail("unreviewed", `[decide 拒绝] ${stored.error.message}`, undefined, stored.error);
		// v2.5.1（diting MJ-2 修复）：回执已发布而验收前 Leader 重启——恢复对账把 clean-complete 归为
		// no-action（零种子），decide 面经 store 回退静默补种子后重查（零命令执行、零 stateSeq 变更；
		// store.load 已校验一致链）。与 queryTaskViews 的磁盘回退同源口径。
		const seeded = await (typeof kernel.seedFromStoreIfAbsent === "function"
			? kernel.seedFromStoreIfAbsent(taskId)
			: Promise.resolve(false));
		if (seeded) view = kernel.get(taskId);
	}
	if (!view) return fail("unreviewed", `[decide 拒绝] 内核无任务 ${taskId}（未 register/非契约任务；store 回退亦无一致记录）`, undefined,
		(err("no-contract-view", `内核无任务 ${taskId}（未 register/非契约任务；store 回退亦无一致记录）`, ["taskId"], "none") as { error: ContractError }).error);
	const access = checkStoredTaskOwner(kernel.frozenSpecOf(taskId), view.run, kernel.ownerId);
	if (!access.ok) return fail(view.acceptance, `[decide 拒绝] ${access.error.message}`, view.receipt?.receiptSeq, access.error);
	if (!view.receipt) {
		return fail(view.acceptance, `[decide 拒绝] 无当前回执（settlement=${view.settlement}）——接受/拒绝引用当前 receiptId（N8）`, undefined,
			(err("no-receipt", `无当前回执（settlement=${view.settlement}）——接受/拒绝引用当前 receiptId（N8）`, ["receiptId"], "none") as { error: ContractError }).error);
	}
	if (view.receipt.receiptId !== receiptId) {
		// D1：stale 先报——消息与结构化错误都携带当前回执 receiptId（不混上轮 id）。
		// ev-20261014-4f7500：附机器可读差异定位 + 勿手抄提示（与 task_control 同源文案）。
		// ev-20261021-fix（F1）：形状降为不匹配诊断——非 uuid 形状提示疑似转录畸变（当前回执自身
		// 非 uuid 形状时不提示形状问题，避免把合法合成/历史回执误标为畸形）。
		const shapeNote = !isValidReceiptIdShape(receiptId) && isValidReceiptIdShape(view.receipt.receiptId)
			? `；且收到 id 形状非当前生产形态 receipt-<uuid>（长度 ${receiptId.length}，疑似手抄/转录畸变——请原样复制 repairExamples 中的当前值）` : "";
		const staleMsg = `receiptId 不匹配（当前 ${view.receipt.receiptId}，收到 "${receiptId}"）——决策引用当前回执，防陈旧决策；${receiptIdMismatchHint(view.receipt.receiptId, receiptId)}${shapeNote}；请复制 repairExamples 中的 receiptId 原值，勿手抄`;
		return fail(view.acceptance, `[decide 拒绝] ${staleMsg}；请用当前回执重发`, view.receipt.receiptSeq,
			(err("stale-receipt", staleMsg, ["receiptId"], "none", [{ action: "accept", handle: taskId, receiptId: view.receipt.receiptId, expectedRevision: view.revision, reason: "<接受/拒绝理由>" }]) as { error: ContractError }).error);
	}
	if (view.acceptance !== "unreviewed") {
		return fail(view.acceptance, `[decide 幂等拒绝] 已决策（acceptance=${view.acceptance}，receiptSeq=${view.receipt.receiptSeq}）——回执不可重复 decide`, view.receipt.receiptSeq,
			(err("already-decided", `已决策（acceptance=${view.acceptance}，receiptSeq=${view.receipt.receiptSeq}）——回执不可重复 decide`, ["decision"], "none") as { error: ContractError }).error);
	}
	const reason = (decision?.reason ?? "").trim();
	if (!reason) return fail(view.acceptance, "[decide 拒绝] reason 必须是非空字符串（决策须可追溯）", view.receipt.receiptSeq,
		(err("invalid-field", "reason 必须是非空字符串（决策须可追溯）", ["decision.reason"], "none") as { error: ContractError }).error);
	// 历史显式决策仍不污染当前会话看板；命令、CAS 与回执链经同一内核执行。
	const applyDecision = registry.get(taskId) ? kernel.apply.bind(kernel) : kernel.applyQuiet.bind(kernel);
	const applied = await applyDecision({
		type: "decide",
		key: { ownerId: kernel.ownerId, taskId, revision: view.revision },
		receiptId,
		verdict,
		decision: { actor: decision.actor, reason, waivedCheckIds: decision.waivedCheckIds ?? [] },
	});
	// D1：内核错误不截断（删 200 字上限）——message 全文 + 结构化 error（repairExamples 等）透传。
	if (!applied.ok) return fail(view.acceptance, `[decide 拒绝] ${applied.error.message}`, view.receipt.receiptSeq, applied.error);
	const after = kernel.get(taskId);
	const acceptance = after?.acceptance ?? (verdict === "reject" ? "rejected" : "accepted");
	const receiptSeq = after?.receipt?.receiptSeq;
	return { ok: true, taskId, acceptance, ...(receiptSeq !== undefined ? { receiptSeq } : {}), message: `已${verdict === "accept" ? "接受" : "拒绝"}（新回执 receiptSeq=${receiptSeq ?? "?"}，沿用证据不重跑；settlement 保持原值）` };
}
