/**
 * task-recovery.ts — amagi-pi v2 K8a：重启恢复对账统一入口（方案 §3.4-N9 / §3.5 恢复 / §8.1-K8a）。
 *
 * 职责：Leader 重启后扫描 v2-store 契约记录（<contractRoot>/<taskId>/{spec,current,receipts}），
 * 对每条记录做 owner/current/receipt 校验（复用 K2 FileTaskStore.load 回读校验——digest 复核、
 * 版本校验、currentReceipt 一致提交链），把现场分类为结构化对账清单（taskId/现场/证据缺口/建议动作），
 * 并对不确定执行应用内核 reconcile 命令（标 needs-reconciliation）。
 *
 * N9 纪律（§3.5「恢复先确认旧 owner 已退出或经人工确认交接…缺文件、坏 JSON、未知必要版本均进入
 * 待对账，不回退猜测到较旧成功记录」）：
 *   - 不自动启动（launchIntent / 孤立回执 / unknown 窗口零 spawn——本模块不 import child_process，
 *     依赖图 task-service/task-store/task-kernel/contracts 亦无 spawn）；
 *   - 不自动 continuation / 重放（K6 WAL 恢复器经 recoveryGate 问询本语义；见 reconcileRestartTask）；
 *   - 不猜成功：reconcile needs-reconciliation 只标记，execution/settlement 原样保留（K3 内核语义）；
 *   - 未知 owner 不采纳（单写者栅栏 N1——只报告 foreign-owner）；
 *   - 孤立回执（receipt 文件存在而 current 未引用）只报告不补成功：不自动 publish-receipt、不改
 *     current 指针（回执采纳是 finalizer/人工动作）；
 *   - 无 launchIntent 的 queued 可明确关闭为未执行（§3.5：reconcile close-unexecuted——确定性关闭，
 *     非猜测）；其余一切不确定 → needs-reconciliation + 建议动作 manual-takeover。
 *
 * 对账规则表（现场 → disposition / apply 动作）：
 *   clean-complete            终态(done/error/truncated)+exited+currentReceipt+settlement≠pending
 *                             （load 已验证一致链）→ no-action（确认 exited/回执链完整，不误报）
 *   closed-terminal           cancelled/resolved-external/answered（权威关闭，无回执预期）→ no-action
 *   launch-intent-unconfirmed running 或有 launchIntent 而 processState≠exited（含 queued-with-intent）
 *                             → needs-reconciliation + manual-takeover 建议
 *   process-state-unknown     processState=unknown → needs-reconciliation
 *   exited-no-receipt         done/error/truncated+exited+无 currentReceipt（settlement=pending，
 *                             §3.5「进程已退出无 current 回执」）→ needs-reconciliation
 *   orphan-receipt            目录有 receipt-*.json 而 current 未引用（saveReceipt 成功、current CAS
 *                             前崩溃等窗口；decide 链中旧回执由 currentReceipt 历史引用，不在此列）
 *                             → needs-reconciliation（不自动置 done、不自动发布）
 *   awaiting-handling         blocked/answering（重启后 N5/N6 lease 内存态已丢）→ needs-reconciliation
 *   queued-unexecuted         queued 且无 launchIntent → close-unexecuted（§3.5 明确关闭为未执行）
 *   store-unreadable          load 失败（corrupt/ref-mismatch/io/版本——fail-closed 不猜）
 *                             → manual-takeover（内核不种子、不写任何东西，只报告）
 *   no-current                目录存在但无 current.json（清单失败窗口：spec 落盘后 current 未建——
 *                             零 spawn 承诺的磁盘残证；v2.5.1 起目录不存在亦归此场景但证据文案拆分）
 *                             → manual-review（孤儿 spec，不猜）
 *   foreign-owner             run.ownerId ≠ 预期 owner 且非本机历史（v2.1-A1：spec.machineId 匹配
 *                             本机 → 本机历史，按 lease/退出事实正常分类，不自动改判 owner；
 *                             无 machineId 旧记录保持 foreign-owner 只报告，可经 adoptRecoveryRecord
 *                             /amagi recovery adopt 确认收口）→ 不采纳（只报告）
 *
 * 历史回填协同（K8a 规则 2）：session-backfill.ts 对有契约记录的任务只产候选、不再自动收编——
 * 采纳入口是本模块（applyTaskRecovery → 内核 reconcile 种子+标记+投影），旧磁盘恢复不旁路补成功。
 *
 * K6 协同（K8a 规则 3）：rpc-pool WAL 恢复器已按同一语义问询 contractRecoveryGate（rpc-pool-tool.ts，
 * 本片不改）：新契约在途任务 → reconcile needs-reconciliation + 不自动接管。reconcileRestartTask 是
 * 抽出的单任务统一入口（同语义 + 结构化清单），供 gate 消费或并列实现（对接补丁要点见 K8a 报告）。
 *
 * 零 spawn 承诺（ev-20261026-165da9 修订）：scan 只读（store.load + readdir）；apply 只经内核命令
 * （CAS 落盘），不启动任务后端、不触发 finalizer/continuation。新增的重启退出证明预检（无人值守
 * 启动恢复）会执行有界只读系统探测（boot_id/boottime/sysctl + ps 进程表，launch-anchor 统一退出
 * 证明）——均为诊断性探测，不派生任务进程、不重放副作用；其余 apply 路径维持零 spawn。
 * 查询面（formatRecoveryReport）供 K8c task-query /启动对账报告接线。
 */

import * as fs from "node:fs";
import { createHash } from "node:crypto";
import * as fsp from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { contractStoreRoot, sanitizeId } from "./artifact.ts";
import { createTaskStore, readTaskAdoption as readAdoptedSidecar, type TaskAdoption as AdoptedNote } from "./task-store.ts";
// ev-20261026-165da9：无人值守启动恢复与显式 task_control reconcile 共用 reconcileStoredTask 执行体
import { reconcileStoredTask, type ExitProver } from "./task-reconcile.ts";
import { getLeaderMachineStamp, getTaskKernel } from "./task-service.ts";
import { registry } from "./task-registry.ts";
import type { TaskStore } from "./contracts/command.ts";
import type { TaskKernelRuntime } from "./task-kernel.ts";
import type { PathRule } from "./contracts/permission.ts";
import { PATH_RULE_KINDS } from "./contracts/permission.ts";
import { matchPathRule } from "./task-permission.ts";
import { isNonEmptyString, isNonNegativeInt, isRecord } from "./contracts/view.ts";
import type { ExecutionState, SettlementState, TaskRun, TaskSpec } from "./contracts/task.ts";
// ev-20260930-0dd26f（R6）：steer 通道状态投影与生命周期 GC（组合根/应用层保护证据注入；
// task-steer-channel 零 registry/kernel/recovery 依赖，本模块是允许 import task-store 的三个模块之一）
import {
	formatSteerChannelLine,
	readSteerChannelSnapshot,
	sweepSteerChannels,
	type SteerChannelClassifier,
	type SteerChannelLifecycleClass,
	type SteerChannelSweepOpts,
	type SteerChannelSweepResult,
} from "./task-steer-channel.ts";

/** 预期 owner（与内核缺省一致；K8c 组合根注入真实 Leader 身份后由调用方传入）。 */
export const RECOVERY_DEFAULT_OWNER = "amagi-leader-local";

// ── ev-20260930-08a8e7：恢复现场投影（RecoveryCheckpoint）──────────────────
//
// 根因（信息断层）：宿主升级重启后 registry 内存清零、in-flight 子进程被杀，恢复报告此前只投影
// 运行态——启动意图/任务书/outputs 均已持久化，却缺「冻结交付清单 × 当前文件现场」关联，Leader
// 只能手动对照 outputs 清单逐个 ls。本投影由可信 spec 的 outputs 与 assignment 派生只读观测
// （存在/mtime/大小/类型），供 Leader 直接派续接片。
//
// 边界（冻结）：不进 TaskRun、不写回 current、不用于 reconcile 成功判定；文件观测与分类分开——
// 文件存在不改 execution/不移除 needs-reconciliation；动态 checkpoint 不混进 applyOne 证据缺口
// （防 mtime 变化造成额外内核写入）；不读文件正文、不递归 tree、不运行 ls；deny 命中返回 denied
// 不扩权；mtime/freshness 仅是观测事实，不作为「已完成」证据。

/** 单条声明产物的只读观测（stat 元数据；不读正文、不递归）。 */
export interface OutputObservation {
	/** 冻结声明原样（spec.outputs[].path，不重写）。 */
	path: string;
	/** 按冻结 spec.workspace.cwd 解析（不按重启后 cwd）。 */
	absolutePath: string;
	expectedKind: "file" | "tree";
	required: boolean;
	state: "present" | "missing" | "kind-mismatch" | "unreadable" | "denied";
	actualKind?: "file" | "directory" | "other";
	/** 仅常规文件（stat.size）；目录 st_size 不是产物总大小，不透出。 */
	bytes?: number;
	mtimeMs?: number;
	/** mtime 与 run.startedAt（无则 queuedAt 标近似）及观测时刻的三方比较；仅观测事实。 */
	freshness?: "before-run" | "within-run-window" | "unknown";
	/** 错误类别（如 EACCES/EIO——类别码，不暴露文件内容或敏感信息）。 */
	errorCode?: string;
}

/** 恢复现场投影：冻结交付清单 × 当前文件现场（scan 时只对会话绑定的可信不确定任务生成）。 */
export interface RecoveryCheckpoint {
	observedAt: number;
	/** 任务书摘要一行（首非空行、空白归一、≤160 Unicode 码点）。 */
	assignmentSummary: string;
	assignmentTruncated: boolean;
	workspaceCwd: string;
	/** 声明产物总数（= spec.outputs.length；0 = 无声明交付清单，不从任务文本猜路径）。 */
	declarationCount: number;
	outputs: readonly OutputObservation[];
}

/** scan 阶段生成 checkpoint 的可信不确定现场（launch-intent-unconfirmed 等；含 launchIntent/
 *  lease/待答内存态丢失的全部不确定窗口；queued-unexecuted/orphan-receipt 有各自确定性处置不混入）。 */
const CHECKPOINT_SCENES: ReadonlySet<string> = new Set([
	"launch-intent-unconfirmed",
	"process-state-unknown",
	"exited-no-receipt",
	"awaiting-handling",
]);

/** 任务书单行摘要：首非空行、空白归一、截断 ≤160 Unicode 码点（码点切分防代理对劈半）。 */
function summarizeAssignment(assignment: string): { summary: string; truncated: boolean } {
	const firstLine = String(assignment ?? "").split("\n").map((l) => l.replace(/\s+/g, " ").trim()).find(Boolean) ?? "（无任务书正文）";
	const cps = Array.from(firstLine);
	return cps.length > 160 ? { summary: cps.slice(0, 160).join(""), truncated: true } : { summary: firstLine, truncated: false };
}

/** 冻结权限 deny 规则提取（spec.permission.deny；形状防御——畸形条目丢弃不放大不误拦）。 */
function denyRulesOf(permission: unknown): PathRule[] {
	if (!isRecord(permission) || !Array.isArray(permission.deny)) return [];
	const out: PathRule[] = [];
	for (const r of permission.deny) {
		if (isRecord(r) && PATH_RULE_KINDS.includes(r.kind as PathRule["kind"]) && isNonEmptyString(r.value)) {
			out.push({ kind: r.kind as PathRule["kind"], value: r.value });
		}
	}
	return out;
}

/** 单条声明产物观测：冻结权限 read/deny 判定先行（deny 命中不 stat 不扩权）→ stat 真实落点。 */
async function observeOneOutput(
	o: { path: string; kind: "file" | "tree"; required: boolean },
	cwd: string,
	denyRules: readonly PathRule[],
	startRef: number | undefined,
	now: number,
): Promise<OutputObservation> {
	const absolutePath = path.isAbsolute(o.path) ? path.normalize(o.path) : path.resolve(cwd, o.path);
	if (denyRules.some((r) => matchPathRule(absolutePath, r))) {
		return { path: o.path, absolutePath, expectedKind: o.kind, required: o.required, state: "denied" };
	}
	try {
		// stat 跟随 symlink（真实落点语义；断链 symlink → ENOENT → missing）
		const st = await fsp.stat(absolutePath);
		const actualKind: "file" | "directory" | "other" = st.isFile() ? "file" : st.isDirectory() ? "directory" : "other";
		const state: OutputObservation["state"] = (o.kind === "file" ? actualKind === "file" : actualKind === "directory") ? "present" : "kind-mismatch";
		const mtimeMs = st.mtimeMs;
		const freshness: OutputObservation["freshness"] = startRef === undefined
			? "unknown"
			: mtimeMs < startRef
				? "before-run"
				: mtimeMs <= now ? "within-run-window" : "unknown"; // mtime 晚于观测时刻（时钟异常）不冒充窗口内
		return {
			path: o.path, absolutePath, expectedKind: o.kind, required: o.required, state,
			actualKind,
			...(st.isFile() ? { bytes: st.size } : {}),
			mtimeMs,
			freshness,
		};
	} catch (e) {
		const code = e instanceof Error && isNonEmptyString((e as NodeJS.ErrnoException).code) ? (e as NodeJS.ErrnoException).code! : "E-UNKNOWN";
		// ENOENT/ENOTDIR = missing；EACCES/EIO 等 = unreadable（类别如实，不猜内容）
		const state: OutputObservation["state"] = code === "ENOENT" || code === "ENOTDIR" ? "missing" : "unreadable";
		return { path: o.path, absolutePath, expectedKind: o.kind, required: o.required, state, errorCode: code };
	}
}

/** 小并发池（上限 limit；逐项保序收集）。 */
async function mapPool<T, R>(items: readonly T[], limit: number, fn: (item: T, index: number) => Promise<R>): Promise<R[]> {
	const results = new Array<R>(items.length);
	let next = 0;
	const worker = async (): Promise<void> => {
		for (;;) {
			const i = next++;
			if (i >= items.length) return;
			results[i] = await fn(items[i]!, i);
		}
	};
	await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, worker));
	return results;
}

/** 恢复现场投影核心（单一观测函数：scan 会话绑定面与 show 显式拉取面共用）。
 *  stat 异步、并发上限 4；输出规模不静默裁剪（裁剪只在展示层并明示省略数量）。 */
async function observeCheckpoint(spec: Readonly<TaskSpec>, run: Readonly<TaskRun>): Promise<RecoveryCheckpoint> {
	const now = Date.now();
	const startRef = run.startedAt ?? run.queuedAt; // startedAt 缺失（崩溃现场）以 queuedAt 标近似
	const denyRules = denyRulesOf(spec.permission);
	const outputs = await mapPool(spec.outputs, 4, (o) => observeOneOutput(o, spec.workspace.cwd, denyRules, startRef, now));
	const { summary, truncated } = summarizeAssignment(spec.assignment);
	return {
		observedAt: now,
		assignmentSummary: summary,
		assignmentTruncated: truncated,
		workspaceCwd: spec.workspace.cwd,
		declarationCount: spec.outputs.length,
		outputs,
	};
}

// ── 类型（对账结果可查询：结构化清单） ────────────────────────────────────────

export type RecoveryScene =
	| "clean-complete"
	| "closed-terminal"
	| "launch-intent-unconfirmed"
	| "process-state-unknown"
	| "exited-no-receipt"
	| "orphan-receipt"
	| "awaiting-handling"
	| "queued-unexecuted"
	| "store-unreadable"
	| "no-current"
	| "foreign-owner"
	| "auto-reconciled"
	| "reboot-closed";

export type RecoveryAction =
	| "no-action"
	| "needs-reconciliation"
	| "close-unexecuted"
	| "manual-takeover"
	| "manual-review"
	| "foreign-owner";

/** 单条契约记录的对账结果（现场 → 证据缺口 → 建议动作 → apply 结果）。 */
export interface RecoveryItem {
	taskId: string;
	/** 任务目录名（sanitizeId 口径；与 taskId 不同时说明目录被外部改动，load 会如实报错）。 */
	dir: string;
	scene: RecoveryScene;
	/** 建议动作（对账处置 disposition；manual-takeover/manual-review/foreign-owner 为人工面）。 */
	action: RecoveryAction;
	/** 证据缺口（人类可读；apply 时作为 reconcile facts 结构化携带）。 */
	evidenceGaps: readonly string[];
	/** 契约记录事实（load 成功时）。 */
	ownerId?: string;
	execution?: ExecutionState;
	processState?: TaskRun["processState"];
	settlement?: SettlementState;
	recovery?: TaskRun["recovery"];
	stateSeq?: number;
	revision?: number;
	hasCurrentReceipt?: boolean;
	/** v2.1 会话盖章：spec.leaderSession（load 成功时可见；undefined = 旧记录无盖章或合成 spec）。 */
	leaderSession?: string;
	/** v2.1-A1 机器盖章：spec.machineId（load 成功时可见；undefined = 旧记录无机器盖章）。 */
	machineId?: string;
	/** v2.1-A1 采纳注记（任务目录 adopted.json 存在且被当前 owner 采纳时透出）。 */
	adopted?: { originalOwnerId: string; adoptedByOwner: string; adoptedAt: number };
	/** v2.1 会话绑定（仅 sessionKey 提供时计算）：session = 本会话派发记录；pull-only =
	 *  无盖章/盖章他Session/foreign-owner/不可读——只入全量视图，不进横幅计数、不被启动对账应用。 */
	sessionBinding?: "session" | "pull-only";
	/** load 失败事实（store-unreadable / no-current 场景）。 */
	loadError?: { code: string; message: string };
	/** applyTaskRecovery 填充：应用结果（scan 模式缺省无此字段）。 */
	applied?: { ok: boolean; marked?: boolean; code?: string; message?: string };
	/** ev-20260930-08a8e7：恢复现场投影（可选；仅 scan 阶段对会话绑定的可信不确定任务生成）。
	 *  动态只读观测——不进 TaskRun/不写回 current/不参与 reconcile 成功判定；重复 scan 会重新
	 *  观测（observedAt/mtime 变化不触发额外内核写入）。 */
	checkpoint?: RecoveryCheckpoint;
	/** launchIntent 时戳（run.launchIntent.at；load 成功且存在时透出——自动收口条件B 时龄判定输入）。 */
	launchIntentAt?: number;
	/** v2.x 恢复对账自动收口事实（任务目录 auto-reconciled.json 存在，或本会话 apply 阶段刚收口）：
	 *  只关闭对账环（等价 adopt 的记账语义——sidecar 注记），不改执行/结算/接受三轴、不猜成功。 */
	autoReconciled?: { criterion: "terminal-bookkeeping" | "stale-dead-process"; reconciledAt: number; staleHours?: number };
}

export interface RecoveryReport {
	scannedAt: number;
	/** 契约存储根（扫描范围）。 */
	root: string;
	items: readonly RecoveryItem[];
	summary: {
		total: number;
		/** 需对账（needs-reconciliation + close-unexecuted + 人工面）。 */
		uncertain: number;
		/** v2.1 横幅触发计数：本会话绑定且可行动（action ∉ {no-action, foreign-owner} 且非 pull-only）
		 *  的项数——resume 横幅只看本数；无 sessionKey 时与 uncertain 同义（历史调用方兼容）。 */
		actionable: number;
		/** 干净记录（clean-complete / closed-terminal，零标记零写入）。 */
		clean: number;
		applied: number;
		failed: number;
		/** v2.x 恢复对账自动收口：本会话 apply 阶段新收口的 launch-intent 残痕数（scan 只读模式恒 0；
		 *  sidecar 已存在的记录归 auto-reconciled scene，不重复计数）。 */
		autoClosed: number;
		/** ev-20261026-165da9：本会话 apply 阶段按重启退出证明（统一退出证明 exited）自动关闭的在途
		 *  记录数（确认退出 + 按未完成关闭，接受轴不变；scan 只读模式恒 0，关闭后记录归 closed-terminal）。 */
		rebootClosed: number;
	};
}

export interface TaskRecoveryOptions {
	/** 契约存储（缺省 createTaskStore()——AMAGI_CONTRACT_ROOT 注入）。 */
	store?: TaskStore;
	/** 契约存储根（目录扫描用；缺省 store 根或 contractStoreRoot()）。 */
	root?: string;
	/** 预期 owner（缺省 amagi-leader-local）。 */
	ownerId?: string;
	/** 应用内核工厂（缺省 task-service.getTaskKernel——进程级共享态，与 resume/控制面同一内核）。 */
	kernel?: () => TaskKernelRuntime;
	/** v2.1 当前会话标识（sessionFile 路径优先，回退 sessionId；组合根 session_start 捕获）。
	 *  提供时：记录按 spec.leaderSession 盖章与本键比对——匹配 = 本会话绑定（可横幅可应用）；
	 *  无盖章/不匹配/foreign-owner/不可读 = pull-only（全量视图可见，不触发横幅、不被应用）。
	 *  缺省：不过滤（历史行为——reconcileRestartTask / RPC recoveryGate 语义保持不变）。 */
	sessionKey?: string;
	/** v2.1-A1 当前机器身份（data-dir machine.json 持久 UUID；组合根注入，测试可显式指定）。
	 *  ownerId 不匹配但 spec.machineId 匹配本键的记录识别为本机历史（按 lease/退出事实正常分类，
	 *  不再误报 foreign-owner）；缺省回退 task-service 机器盖章（未注入 → 不识别，保守 foreign-owner）。 */
	machineId?: string;
	/** v2.x 恢复对账自动收口开关（缺省 loadRecoveryAutoConfig()——amagi.json recovery 节 + env 逃生舱）。
	 *  enabled=false 时 launch-intent 残痕全走人工（不评估判据、零 sidecar 零日志）。 */
	autoReconcile?: { enabled: boolean; staleHours: number };
	/** ev-20261026-165da9：退出证明注入（测试 seam；缺省真实 proveTaskExited——含 boot 身份判定）。
	 *  仅重启证明关闭阶段消费；不影响其余对账路径。 */
	proveExit?: ExitProver;
}

// ── 扫描与分类 ───────────────────────────────────────────────────────────────

/** 契约存储根下的任务目录清单（只读；无根/不可读 → 空清单如实返回）。 */
function listTaskDirs(root: string): string[] {
	try {
		return fs
			.readdirSync(root, { withFileTypes: true })
			.filter((e) => e.isDirectory() && !e.isSymbolicLink())
			.map((e) => e.name)
			.sort();
	} catch {
		return [];
	}
}

/** 任务目录内未被 current 引用的孤立回执文件（receipt-*.json 且 run 无 currentReceipt）。 */
function orphanReceiptFiles(dir: string, run: TaskRun | undefined): string[] {
	try {
		const files = fs.readdirSync(dir).filter((f) => f.startsWith("receipt-") && f.endsWith(".json"));
		if (run?.currentReceipt) return []; // current 已引用回执：其余 receipt 文件属 decide 历史链（receiptSeq+1 沿用），非孤立
		return files;
	} catch {
		return [];
	}
}

// ── v2.1-A1 采纳注记 sidecar（用户显式确认“该记录属本机”后写入；不改写原契约记录内容） ──

const ADOPTED_FILE = "adopted.json";

/** 写采纳注记（tmp+rename 原子替换；幂等——已存在且同采纳者时不改写原注记）。 */
function writeAdoptedSidecar(dirAbs: string, taskId: string, note: AdoptedNote & { machineId?: string }): void {
	const abs = path.join(dirAbs, ADOPTED_FILE);
	const tmp = `${abs}.tmp-${process.pid}`;
	fs.writeFileSync(tmp, `${JSON.stringify({ formatVersion: 1, taskId, ...note }, null, 2)}\n`, "utf8");
	try {
		fs.renameSync(tmp, abs);
	} finally {
		try { fs.rmSync(tmp, { force: true }); } catch { /* best-effort */ }
	}
}

interface Classified {
	scene: RecoveryScene;
	action: RecoveryAction;
	gaps: readonly string[];
}

// ── v2.x 恢复对账自动收口（历史残痕不再逐会话侵扰上下文）────────────────────
//
// 主上需求：恢复对账残留 5 条历史残痕（早前中断/取消/外部收口任务的 launchIntent 未闭环，
// 均无实际未交付产物）不应每次会话唤起都轰炸上下文。Leader 裁定（安全优先，仅对
// launch-intent-unconfirmed 类）：
//   条件A（终态记账缺口）：execution ∈ {cancelled, resolved-external, done, error}——内核状态
//     已权威，launchIntent 缺口是纯记账 → 自动收口；
//   条件B（陈旧死进程）：execution=running 且无退出事实且 launchIntent 时龄 > 阈值（默认 24h）
//     且（无声明产物 或 声明产物全部在盘）→ 自动收口；
//   不自动：声明产物有 missing/unreadable/kind-mismatch/denied 的；非 launch-intent 类对账缺口；
//     时龄 ≤ 阈值的 running 记录（可能是真在途）；checkpoint 缺失（无 sessionKey/非会话绑定——
//     产物面未知不猜）。
// 语义：只关闭对账环（等价 adopt 的记账效果——任务目录 sidecar 注记 + root 追溯日志），绝不改动
// 执行/结算/接受三轴（不写 current.json、不猜成功、不自动启动任何进程）。幂等：sidecar 存在 →
// 后续扫描归 auto-reconciled（no-action）→ 不重复收口不重复日志；扫描无候选时零副作用。

const AUTO_RECONCILED_FILE = "auto-reconciled.json";
const AUTO_RECONCILE_LOG_FILE = "recovery-auto.ndjson";
export const RECOVERY_AUTO_STALE_HOURS_DEFAULT = 24;
export const RECOVERY_AUTO_STALE_HOURS_MIN = 1;

export type RecoveryAutoCriterion = "terminal-bookkeeping" | "stale-dead-process";

/** 条件A 终态集合（Leader 裁定：内核状态已权威，launchIntent 缺口是纯记账）。 */
const AUTO_RECONCILE_TERMINAL_EXECUTIONS: ReadonlySet<string> = new Set(["cancelled", "resolved-external", "done", "error"]);

/** ev-20261026-165da9：无人值守重启关闭的适用现场——统一退出证明可裁决的三个不确定现场
 *  （launch 意图未闭环 / 进程态不可确认 / 待处理内存态丢失）；其余现场照旧确定性处置或人工面。 */
const REBOOT_CLOSURE_SCENES: ReadonlySet<string> = new Set(["launch-intent-unconfirmed", "process-state-unknown", "awaiting-handling"]);

export interface RecoveryAutoConfig {
	enabled: boolean;
	staleHours: number;
	/** 非法配置的 bounded 提示（调用方一行告知，不刷屏）。 */
	warnings: readonly string[];
}

/** 读任务目录自动收口注记（形状防御：畸形/不属本任务的注记视为不存在，fail-closed 保守回人工）。 */
function readAutoReconciledSidecar(dirAbs: string, taskId: string): { criterion: RecoveryAutoCriterion; reconciledAt: number; staleHours?: number } | undefined {
	try {
		const v: unknown = JSON.parse(fs.readFileSync(path.join(dirAbs, AUTO_RECONCILED_FILE), "utf8"));
		if (!isRecord(v) || v.formatVersion !== 1 || v.taskId !== taskId) return undefined;
		if (typeof v.criterion !== "string" || v.criterion !== "terminal-bookkeeping" && v.criterion !== "stale-dead-process") return undefined;
		if (!isNonNegativeInt(v.reconciledAt)) return undefined;
		if (v.staleHours !== undefined && !(typeof v.staleHours === "number" && Number.isFinite(v.staleHours))) return undefined;
		return { criterion: v.criterion, reconciledAt: v.reconciledAt, ...(v.staleHours !== undefined ? { staleHours: v.staleHours } : {}) };
	} catch { /* lint-exempt:auto-reconciled sidecar 损坏按无注记处理（保守回人工对账） */
		return undefined;
	}
}

/** 写自动收口注记（tmp+rename 原子替换，同 adopted sidecar 模式；不触碰契约记录内容）。 */
function writeAutoReconciledSidecar(dirAbs: string, taskId: string, note: { criterion: RecoveryAutoCriterion; reconciledAt: number; staleHours?: number }): void {
	const abs = path.join(dirAbs, AUTO_RECONCILED_FILE);
	const tmp = `${abs}.tmp-${process.pid}`;
	fs.writeFileSync(tmp, `${JSON.stringify({ formatVersion: 1, taskId, ...note }, null, 2)}\n`, "utf8");
	try {
		fs.renameSync(tmp, abs);
	} finally {
		try { fs.rmSync(tmp, { force: true }); } catch { /* lint-exempt:tmp 清理 best-effort（原子替换失败路径） */ }
	}
}

/** 追加追溯日志（契约根 recovery-auto.ndjson：taskId+判据+时间+对账时三轴事实，一行一事件）。 */
function appendAutoReconcileLog(root: string, entry: Record<string, unknown>): void {
	fs.appendFileSync(path.join(root, AUTO_RECONCILE_LOG_FILE), `${JSON.stringify(entry)}\n`, "utf8");
}

function globalAmagiConfigPath(): string {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi.json");
}

function readRecoverySection(file: string): unknown | null {
	try {
		const json: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
		return json && typeof json === "object" && "recovery" in (json as Record<string, unknown>) ? (json as Record<string, unknown>).recovery : null;
	} catch { /* lint-exempt:配置不可读按缺省（env/默认链兜底） */
		return null;
	}
}

/** 读自动收口配置（优先级：env AMAGI_RECOVERY_AUTORECONCILE / AMAGI_RECOVERY_STALE_HOURS > amagi.json recovery 节
 *  （全局打底、项目覆盖）> 默认 enabled=true/staleHours=24）。非法值回退下一层有效值并产 bounded 提示；
 *  事件频率极低（resume 唤起一次），每次现读不缓存。 */
export function loadRecoveryAutoConfig(cwd?: string): RecoveryAutoConfig {
	const warnings: string[] = [];
	let envEnabled: boolean | undefined;
	const envEnable = process.env.AMAGI_RECOVERY_AUTORECONCILE;
	if (envEnable !== undefined && envEnable !== "") {
		const v = envEnable.trim().toLowerCase();
		if (v === "1" || v === "true" || v === "on") envEnabled = true;
		else if (v === "0" || v === "false" || v === "off") envEnabled = false;
		else warnings.push(`AMAGI_RECOVERY_AUTORECONCILE=${envEnable} 非法（合法：1/true/on 开、0/false/off 关）——忽略，回退 amagi.json/默认`);
	}
	let envStale: number | undefined;
	const envStaleRaw = process.env.AMAGI_RECOVERY_STALE_HOURS;
	if (envStaleRaw !== undefined && envStaleRaw !== "") {
		const n = Number(envStaleRaw);
		if (Number.isFinite(n) && n >= RECOVERY_AUTO_STALE_HOURS_MIN) envStale = n;
		else warnings.push(`AMAGI_RECOVERY_STALE_HOURS=${envStaleRaw} 非法（最小 ${RECOVERY_AUTO_STALE_HOURS_MIN}）——忽略，回退 amagi.json/默认 ${RECOVERY_AUTO_STALE_HOURS_DEFAULT}`);
	}
	// amagi.json recovery 节：全局打底、项目覆盖（后读覆盖先读，同 model-resolver 优先级链方向）
	let enabled: boolean | undefined;
	let staleHours: number | undefined;
	const files = [globalAmagiConfigPath()];
	if (cwd !== undefined) files.push(path.join(cwd, "amagi.json"));
	for (const f of files) {
		const section = readRecoverySection(f);
		if (!isRecord(section)) continue;
		if (typeof section.autoReconcile === "boolean") enabled = section.autoReconcile;
		if (typeof section.staleHours === "number" && Number.isFinite(section.staleHours)) {
			if (section.staleHours >= RECOVERY_AUTO_STALE_HOURS_MIN) staleHours = section.staleHours;
			else warnings.push(`${path.basename(path.dirname(f))}/amagi.json recovery.staleHours=${section.staleHours} 低于最小 ${RECOVERY_AUTO_STALE_HOURS_MIN}——忽略`);
		}
	}
	// env 有效值最后强制（非法 env 已被忽略并提示，不阻断 amagi.json 生效）
	if (envEnabled !== undefined) enabled = envEnabled;
	if (envStale !== undefined) staleHours = envStale;
	return { enabled: enabled ?? true, staleHours: staleHours ?? RECOVERY_AUTO_STALE_HOURS_DEFAULT, warnings };
}

function autoReconcileCriterionLabel(n: { criterion: RecoveryAutoCriterion; staleHours?: number }): string {
	return n.criterion === "terminal-bookkeeping"
		? "条件A 终态记账缺口"
		: `条件B 陈旧死进程（时龄超 ${n.staleHours ?? RECOVERY_AUTO_STALE_HOURS_DEFAULT}h 阈值）`;
}

/** 自动收口判据（纯计算；仅 launch-intent-unconfirmed）。条件A 看终态事实；条件B 需会话绑定扫描
 *  产出的 checkpoint（无 checkpoint → 产物面未知不猜，fail-closed 不自动）。 */
function evaluateAutoReconcile(
	item: Readonly<RecoveryItem>,
	cfg: { staleHours: number },
	now: number,
): RecoveryAutoCriterion | undefined {
	if (item.scene !== "launch-intent-unconfirmed") return undefined;
	if (item.execution !== undefined && AUTO_RECONCILE_TERMINAL_EXECUTIONS.has(item.execution)) return "terminal-bookkeeping";
	if (item.execution === "running" && item.processState !== "exited" && item.launchIntentAt !== undefined
		&& now - item.launchIntentAt > cfg.staleHours * 3600_000) {
		const cp = item.checkpoint;
		if (cp === undefined) return undefined;
		if (cp.declarationCount === 0) return "stale-dead-process";
		if (cp.outputs.length > 0 && cp.outputs.every((o) => o.state === "present")) return "stale-dead-process";
	}
	return undefined;
}


/** 现场分类（纯计算，N9：不确定一律 needs-reconciliation，干净记录不误报）。 */
function classify(run: TaskRun, orphanReceipts: readonly string[]): Classified {
	const gaps: string[] = [];
	// 已有前次对账标记：如实列入证据（不清除——K1 无 unmark 命令；事实链完整时 clean 仍可确认）
	if (run.recovery === "needs-reconciliation") gaps.push("recovery=needs-reconciliation（前次对账保守标记）");
	if (orphanReceipts.length > 0) {
		gaps.push(`孤立回执：${orphanReceipts.join(", ")} 存在而 current 未引用（receipt 落盘成功、current CAS 前中断）——不自动补成功/发布`);
		return { scene: "orphan-receipt", action: "needs-reconciliation", gaps };
	}
	if (run.processState === "unknown") {
		gaps.push("processState=unknown（进程态不可确认）");
		return { scene: "process-state-unknown", action: "needs-reconciliation", gaps };
	}
	const launchUnconfirmed = run.execution === "running" || (run.launchIntent !== undefined && run.processState !== "exited");
	if (launchUnconfirmed) {
		gaps.push(
			run.launchIntent
				? `launchIntent(${run.launchIntent.nonce}) 已持久化而无 exited 事实（processState=${run.processState}）——启动意图与执行结果均不确定`
				: `execution=running 而 launchIntent 缺失（异常记录）且 processState=${run.processState}`,
		);
		return { scene: "launch-intent-unconfirmed", action: "needs-reconciliation", gaps };
	}
	switch (run.execution) {
		case "queued":
			gaps.push("queued 且无 launchIntent——未执行（§3.5 可明确关闭为未执行）");
			return { scene: "queued-unexecuted", action: "close-unexecuted", gaps };
		case "blocked":
		case "answering":
			gaps.push(`execution=${run.execution}（N5/N6：重启后 lease/待答内存态已丢，需对账处置）`);
			return { scene: "awaiting-handling", action: "needs-reconciliation", gaps };
		case "done":
		case "error":
		case "truncated":
			// ev-20261019-06c169：显式核验终态的物理退出前提——无 launchIntent 的异常记录（种子推断/桥迁移
			// 产物、processState 停 not-started/alive）不能凭回执判干净；有 launchIntent 的已被前置分支拦截。
			if (run.processState !== "exited") {
				gaps.push(`execution=${run.execution} 而 processState=${run.processState}（终态无物理退出证据）——不能凭回执/终态判干净，待对账确认退出事实`);
				return { scene: "launch-intent-unconfirmed", action: "needs-reconciliation", gaps };
			}
			if (run.currentReceipt && run.settlement !== "pending") {
				return { scene: "clean-complete", action: "no-action", gaps }; // 确认 exited/回执链完整（load 已验证），不误报
			}
			gaps.push(
				run.currentReceipt
					? `currentReceipt 已引用但 settlement=${run.settlement}（一致链异常——load 校验应已拦截，此处保守待对账）`
					: `进程已退出（execution=${run.execution}, processState=${run.processState}）无 current 回执（settlement=pending）——§3.5 不确定窗口`,
			);
			return { scene: "exited-no-receipt", action: "needs-reconciliation", gaps };
		default:
			// cancelled / resolved-external / answered：权威关闭，无回执预期（回执可选，load 已验证一致）
			return { scene: "closed-terminal", action: "no-action", gaps };
	}
}

/** 单任务对账：load（K2 回读校验）→ 分类 → 结构化 item（不写任何东西）。
 *  v2.1-A1 本机历史识别：ownerId 不匹配但 spec.machineId 匹配当前机器、或存在当前 owner 的
 *  adopted 注记 → 按本机历史正常分类（仍按 lease/退出事实判断采纳，不自动改判 ownerId）；
 *  无 machineId 的旧记录保持 foreign-owner 报告不变。
 *  ev-20260930-08a8e7：checkpointWhen（可选）——load 成功且非 foreign-owner 时由调用方判定
 *  （现场可信不确定 × 会话绑定/显式拉取）是否附加恢复现场投影；foreign-owner/store-unreadable/
 *  no-current 路径不触发射谓词（不访问声明路径）。观测与分类分开：只读 stat，不改状态面。 */
async function inspectOne(
	store: TaskStore,
	root: string,
	dir: string,
	ownerId: string,
	machineId?: string,
	checkpointWhen?: (scene: RecoveryScene, spec: Readonly<TaskSpec>) => boolean,
): Promise<RecoveryItem> {
	const taskId = dir;
	const dirAbs = path.join(root, dir);
	const adopted = readAdoptedSidecar(dirAbs, taskId);
	const loaded = await store.load(taskId);
	if (!loaded.ok) {
		if (loaded.error.code === "store-not-found") {
			// v2.5.1（MN-4）：目录不存在与「目录存在但 current.json 缺失」拆开陈述——两者磁盘事实不同，
			// 前者是清单/外部删除不一致，后者才是清单失败窗口残证；处置同为 manual-review 不变。
			const dirExists = fs.existsSync(dirAbs);
			return {
				taskId, dir, scene: "no-current", action: "manual-review",
				evidenceGaps: [dirExists
					? "任务目录存在但无 current.json（清单失败窗口：spec 落盘后 current 未建——零 spawn 承诺的磁盘残证；不猜状态）"
					: "任务目录不存在（目录清单与磁盘不一致：外部删除/清单残留）——无契约记录可对账"],
				loadError: { code: loaded.error.code, message: loaded.error.message },
			};
		}
		return {
			taskId, dir, scene: "store-unreadable", action: "manual-takeover",
			evidenceGaps: [
				`契约记录不可读（${loaded.error.code}）：${loaded.error.message}`,
				"fail-closed（N9）：不种子内核、不写任何文件、不回退猜测较旧成功记录——人工接管修复后重扫",
			],
			loadError: { code: loaded.error.code, message: loaded.error.message },
		};
	}
	const { spec, run } = loaded.value;
	const orphan = orphanReceiptFiles(dirAbs, run);
	// v2.1-A1 本机历史判定（正交于 sessionBinding）：machineId 匹配本机，或当前 owner 已显式采纳
	const machineMatch = spec.machineId !== undefined && spec.machineId === machineId;
	const adoptedHonored = adopted !== undefined && adopted.originalOwnerId === run.ownerId && adopted.adoptedByOwner === ownerId;
	if (run.ownerId !== ownerId && !machineMatch && !adoptedHonored) {
		return {
			taskId, dir, scene: "foreign-owner", action: "foreign-owner",
			evidenceGaps: [
				`run.ownerId=${run.ownerId} ≠ 预期 ${ownerId}${
					spec.machineId !== undefined
					? ` 且 spec.machineId=${spec.machineId.slice(0, 8)}… ≠ 本机（他人机器记录，拒绝采纳）`
					: "（无 machineId——旧记录）"
				}（N1 单写者：不采纳他人 owner 的记录，只报告；本机历史确认收口：/amagi recovery adopt ${taskId}）`,
			],
			ownerId: run.ownerId, execution: run.execution, processState: run.processState,
			settlement: run.settlement, recovery: run.recovery, stateSeq: run.stateSeq, revision: run.revision,
			hasCurrentReceipt: run.currentReceipt !== undefined,
			leaderSession: spec.leaderSession,
			machineId: spec.machineId,
		};
	}
	const c = classify(run, orphan);
	// ev-20261019-06c169：answered 待对账现场的续接链诊断（只读展示，不改变分类/处置——历史 answered +
	// successorTaskId 只证明续接关系，不构成父退出的独立证据；精确 load 指定 successor 核对身份与回指，
	// 不反向全库搜索任意子任务充当证明，也不因子任务 done/accepted 豁免父退出核验）。
	const successorFacts: string[] = [];
	if (c.scene === "launch-intent-unconfirmed" && run.execution === "answered" && run.successorTaskId !== undefined) {
		const succ = run.successorTaskId;
		let loadedS: { spec: TaskSpec; run: TaskRun } | undefined;
		try {
			const r = await store.load(succ);
			loadedS = r.ok ? r.value : undefined;
		} catch { /* lint-exempt:successor 链诊断读取异常按缺失处理（保守展示，不放大不阻断对账） */ loadedS = undefined; }
		if (!loadedS) {
			successorFacts.push(`续接链诊断：successorTaskId=${succ.slice(0, 8)} 记录不可读/缺失——链关系未核实（不反向全库搜索子任务充当证明）`);
		} else {
			const backLink = loadedS.run.parentTaskId === run.taskId || loadedS.spec.parentTaskId === run.taskId;
			const sameOwner = loadedS.run.ownerId === run.ownerId;
			if (!backLink || !sameOwner) {
				successorFacts.push(`续接链诊断：successorTaskId=${succ.slice(0, 8)} 存在但链关系未核实（parentTaskId 回指本任务=${backLink ? "是" : "否"}，owner 一致=${sameOwner ? "是" : "否"}——relation 可显式覆盖 parentTaskId，不据此重写父状态）`);
			} else {
				successorFacts.push(`续接已确认：successor ${succ.slice(0, 8)}（execution=${loadedS.run.execution}/${loadedS.run.settlement}/${loadedS.run.acceptance}，parentTaskId 回指本任务）——但父退出未确认，不因子任务完成/已接受豁免父退出核验`);
			}
		}
	}
	// v2.x 自动收口注记：sidecar 存在且现场仍是 launchIntent 未闭环 → 归 auto-reconciled（no-action，
	// 不进横幅/不被应用/不重复收口）；其它现场（后续变为干净/孤立回执等）按事实分类，注记不影响。
	const autoNote = c.scene === "launch-intent-unconfirmed" ? readAutoReconciledSidecar(dirAbs, taskId) : undefined;
	const autoFacts = autoNote !== undefined
		? [`已自动收口（${autoReconcileCriterionLabel(autoNote)}，${new Date(autoNote.reconciledAt).toISOString()}）：launchIntent 记账缺口关闭，执行/结算/接受三轴未动（明细 /amagi recovery list）`]
		: [];
	const localHistoryFacts = run.ownerId !== ownerId
		? [
			machineMatch
				? `本机历史（machineId 匹配）：run.ownerId=${run.ownerId} ≠ 预期 ${ownerId}——按 lease/退出事实对账，不自动改判 owner（v2.1-A1）`
				: `已采纳注记（原 owner ${adopted?.originalOwnerId}，${new Date(adopted!.adoptedAt).toISOString()}）：按本机历史对账，原记录内容未改写（v2.1-A1）`,
		]
		: [];
	const item: RecoveryItem = {
		taskId, dir,
		scene: autoNote !== undefined ? "auto-reconciled" : c.scene,
		action: autoNote !== undefined ? "no-action" : c.action,
		evidenceGaps: [...localHistoryFacts, ...successorFacts, ...c.gaps, ...autoFacts],
		ownerId: run.ownerId, execution: run.execution, processState: run.processState,
		settlement: run.settlement, recovery: run.recovery, stateSeq: run.stateSeq, revision: run.revision,
		hasCurrentReceipt: run.currentReceipt !== undefined,
		leaderSession: spec.leaderSession,
		machineId: spec.machineId,
		launchIntentAt: run.launchIntent?.at,
		...(autoNote !== undefined ? { autoReconciled: autoNote } : {}),
		...(adoptedHonored ? { adopted } : {}),
	};
	// ev-20260930-08a8e7：恢复现场投影（只读观测；不进证据缺口/不改分类——文件存在不移除
	// needs-reconciliation，mtime 变化不触发额外内核写入）；auto-reconciled 不在 CHECKPOINT_SCENES
	//（已收口条目不再生成断点投影——显式拉取面 show 仍可观测）。
	if (checkpointWhen !== undefined && checkpointWhen(item.scene, spec)) {
		item.checkpoint = await observeCheckpoint(spec, run);
	}
	return item;
}

function storeRootOf(store: TaskStore): string {
	const maybe = store as { root?: unknown };
	if (maybe && typeof maybe.root === "string") return maybe.root;
	return contractStoreRoot();
}

// ── v2.1 会话绑定分类（主上裁定：恢复对账只在唤起原会话时发生） ──────────────

/** 横幅可行动项：非 no-action/foreign-owner 且未被会话绑定过滤为 pull-only。 */
function isActionableItem(i: Readonly<RecoveryItem>): boolean {
	if (i.action === "no-action" || i.action === "foreign-owner") return false;
	return i.sessionBinding !== "pull-only";
}

/** 可行动项语义签名——恢复对账通知去重用。
 *  根因：长会话接力（同进程 /resume 切新会话）每次唤起都全量注入清单（实战 ≥6 次、每次
 *  550+ 行，可行动项通常仅 1-2 条）——上下文噪音。签名只看可行动面的语义事实，
 *  不受扫描时刻或正常文件大小/mtime 扰动；事实变化须重新注入，数量相同不代表内容相同。 */
export function recoveryActionableSignature(report: Readonly<RecoveryReport>): string {
	return report.items
		.filter(isActionableItem)
		// diting F-11：签名纳入 scene/证据缺口数/应用结果——同 taskId:action 但现场或处置事实变化
		// （如 manual-takeover → needs-reconciliation 迁移、应用成功/失败翻转）不再被去重吞掉。
		.map((i) => {
			// 只签语义事实，不签扫描时刻/mtime/字节数；相同缺口数的内容变化、产物缺失变化仍须通知。
			const facts = [i.execution, i.processState, i.settlement, i.recovery, i.applied,
				[...new Set(i.evidenceGaps)].sort(), i.checkpoint && {
					assignment: i.checkpoint.assignmentSummary, declarationCount: i.checkpoint.declarationCount,
					outputs: i.checkpoint.outputs.map((o) => [o.absolutePath, o.expectedKind, o.required, o.state, o.actualKind, o.errorCode])
						.sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))),
				}];
			const digest = createHash("sha256").update(JSON.stringify(facts)).digest("hex").slice(0, 16);
			return `${i.taskId}:${i.action}:${i.scene}:${i.evidenceGaps?.length ?? 0}:${i.applied?.ok === true ? 1 : 0}:${digest}`;
		})
		.sort()
		.join("|");
}

/** 仅宿主当前可见的已送达通知可去重；旧宿主分支回退在压缩点保守停止，不猜摘要内容。 */
export function recoveryNoticeAlreadyDelivered(entries: readonly unknown[], sessionKey: string, signature: string): boolean {
	if (!signature) return false;
	for (let k = entries.length - 1; k >= 0; k--) {
		const entry = entries[k] as { type?: string; role?: string; customType?: string; details?: { sessionKey?: string; signature?: string } } | null;
		if (entry?.type === "compaction") break;
		if ((entry?.type !== "custom_message" && entry?.role !== "custom") || entry.customType !== "amagi:recovery") continue;
		if (entry.details?.sessionKey === sessionKey) return entry.details.signature === signature;
	}
	return false;
}

/** 会话绑定标注（仅 sessionKey 提供时）：leaderSession 盖章精确匹配 = session；
 *  其余（无盖章旧记录/他Session 盖章/foreign-owner/不可读）一律 pull-only——不进横幅、
 *  不被启动对账应用，仍出现在全量视图与 formatRecoveryReport 输出（标注本会话外/pull-only）。 */
function bindSession(items: RecoveryItem[], sessionKey: string | undefined): void {
	if (sessionKey === undefined) return;
	for (const i of items) {
		i.sessionBinding = i.scene !== "foreign-owner" && i.leaderSession === sessionKey ? "session" : "pull-only";
	}
}

async function scan(opts: TaskRecoveryOptions): Promise<RecoveryReport> {
	const store = opts.store ?? createTaskStore();
	const root = opts.root ?? storeRootOf(store);
	const ownerId = opts.ownerId ?? RECOVERY_DEFAULT_OWNER;
	const machineId = opts.machineId !== undefined ? opts.machineId : getLeaderMachineStamp();
	const dirs = listTaskDirs(root);
	const items: RecoveryItem[] = [];
	// ev-20260930-08a8e7：仅本会话绑定（leaderSession 盖章精确匹配）且可信不确定现场的任务生成
	// 恢复现场投影；无 sessionKey（单任务 gate/历史调用面）不观测——跨会话 pull-only 不展开。
	const checkpointWhen = opts.sessionKey !== undefined
		? (scene: RecoveryScene, spec: Readonly<TaskSpec>): boolean =>
			CHECKPOINT_SCENES.has(scene) && spec.leaderSession === opts.sessionKey
		: undefined;
	for (const dir of dirs) items.push(await inspectOne(store, root, dir, ownerId, machineId, checkpointWhen));
	bindSession(items, opts.sessionKey);
	return {
		scannedAt: Date.now(),
		root,
		items,
		summary: {
			total: items.length,
			uncertain: items.filter((i) => i.action !== "no-action").length,
			actionable: items.filter(isActionableItem).length,
			clean: items.filter((i) => i.action === "no-action").length,
			applied: 0,
			failed: 0,
			autoClosed: 0,
			rebootClosed: 0,
		},
	};
}

/** 重启对账扫描（只读）：契约记录全量清单——现场/证据缺口/建议动作。零 spawn、零写入。 */
export async function scanTaskRecovery(opts: TaskRecoveryOptions = {}): Promise<RecoveryReport> {
	return scan(opts);
}

// ── 应用（内核采纳）────────────────────────────────────────────────────────

// （v2.0.1 修复移除）内核投影兜底 ensureRegistryProjection：原实现对账采纳后把旧会话任务收编进
// 本会话 registry，导致新会话看板/status-ui 显示旧会话的编排子 Agent。跨会话残留的可见面改为
// 启动一次性 steer 通知 + query_task({recovery:true}) 报告 + handle 档三轴查询（内核/store 回退）；
// 内核仍持有对账种子（权威可查/可后续 decide-cancel），仅不再进本会话展示态。

/** 单任务统一对账入口（K6 recoveryGate 同语义 + 结构化清单；供 WAL 恢复器/启动对账消费）。 */
export async function reconcileRestartTask(
	taskId: string,
	opts: TaskRecoveryOptions & { facts?: readonly { code: string; detail: string }[] } = {},
): Promise<RecoveryItem & { decision: { auto: boolean; reason: string } }> {
	const store = opts.store ?? createTaskStore();
	const ownerId = opts.ownerId ?? RECOVERY_DEFAULT_OWNER;
	const machineId = opts.machineId !== undefined ? opts.machineId : getLeaderMachineStamp();
	const kernel = (opts.kernel ?? getTaskKernel)();
	const item = await inspectOne(store, storeRootOf(store), sanitizeId(taskId), ownerId, machineId);
	const extraFacts = opts.facts ?? [];
	if (item.action === "needs-reconciliation" || item.action === "close-unexecuted") {
		const applied = await applyOne(kernel, item, ownerId, extraFacts);
		item.applied = applied;
		return {
			...item,
			decision: {
				auto: false,
				reason: applied.ok
					? `K8a_N9_NEEDS_RECONCILIATION: ${item.scene} 已标记（不自动启动/不猜成功；证据缺口保留，重新派发走新 taskId）`
					: `K8a_N9_NEEDS_RECONCILIATION: 内核 reconcile 拒绝（${applied.code ?? "unknown"}: ${applied.message ?? ""}）——不自动接管，供人工对账`,
			},
		};
	}
	return {
		...item,
		decision: {
			auto: false,
			reason: item.action === "no-action"
				? `K8a: 契约记录干净（${item.scene}），无需对账动作`
				: `K8a_N9_NEEDS_RECONCILIATION: ${item.scene}（action=${item.action}）——只报告不自动处置，人工面接管`,
		},
	};
}

/** 应用单条处置：needs-reconciliation / close-unexecuted → 内核 reconcile 命令（种子+标记+投影）。
 *  v2.1-A1：key.ownerId 用当前对账 owner（内核单写者栅栏口径）——本机历史（machineId 匹配/已采纳）
 *  记录的原 ownerId 保留在 run（不自动改判），标记动作由当前 owner 作为唯一写者执行。 */
async function applyOne(
	kernel: TaskKernelRuntime,
	item: RecoveryItem,
	ownerId: string,
	extraFacts: readonly { code: string; detail: string }[] = [],
): Promise<{ ok: boolean; marked?: boolean; code?: string; message?: string }> {
	if (item.action !== "needs-reconciliation" && item.action !== "close-unexecuted") return { ok: true };
	const facts = [
		...item.evidenceGaps.map((detail, i) => ({ code: `k8a-${item.scene}-${i + 1}`, detail })),
		...extraFacts,
	];
	const key = { ownerId, taskId: item.taskId, revision: item.revision ?? 0 };
	const disposition = item.action === "close-unexecuted" ? "close-unexecuted" : "needs-reconciliation";
	const r = await (typeof kernel.applyQuiet === "function"
		? kernel.applyQuiet({ type: "reconcile", key, facts, disposition })
		: kernel.apply({ type: "reconcile", key, facts, disposition }));
	if (!r.ok) return { ok: false, code: r.error.code, message: r.error.message };
	return { ok: true, marked: item.action === "needs-reconciliation" };
}

/** 重启对账应用：扫描 + 对 needs-reconciliation/close-unexecuted 应用内核 reconcile 命令。
 *  干净记录零标记零写入；store-unreadable/no-current/foreign-owner 只报告（fail-closed）。
 *  零 spawn、不自动 continuation、幂等（重复应用保持标记不重复迁移）。
 *  跨会话显示契约（v2.0.1 修复）：对账采纳只进内核（权威可查/可后续 decide-cancel）与报告面，
 *  不投影进本会话 registry——看板/status-ui/答题队列是本进程会话态，新会话不得显示旧会话的
 *  编排子 Agent；跨会话残留的可见面 = 启动一次性 steer 通知 + query_task({recovery:true}) 报告
 *  + handle 档三轴查询（内核/store 回退）。
 *  v2.x 自动收口（Leader 裁定）：launch-intent-unconfirmed 残痕命中条件A（终态记账缺口）/条件B（陈旧
 *  死进程）判据时，只写任务目录 sidecar + 契约根追溯日志（等价 adopt 记账效果，不改三轴、不猜
 *  成功、不启动进程）并改判 auto-reconciled；不命中或开关关闭 → 走既有 applyOne 人工面。sidecar
 *  写失败回退保守标记（不放大失败）。幂等：sidecar 已存在的记录归 auto-reconciled（no-action），
 *  不重复收口不重复日志。 */
export async function applyTaskRecovery(opts: TaskRecoveryOptions = {}): Promise<RecoveryReport> {
	const report = await scan(opts);
	const kernel = (opts.kernel ?? getTaskKernel)();
	const cfg = opts.autoReconcile ?? loadRecoveryAutoConfig();
	const root = opts.root ?? storeRootOf(opts.store ?? createTaskStore());
	const now = Date.now();
	let applied = 0;
	let failed = 0;
	let autoClosed = 0;
	let rebootClosed = 0;
	for (const item of report.items) {
		if (item.action !== "needs-reconciliation" && item.action !== "close-unexecuted") continue;
		// v2.1 会话绑定：pull-only（他Session/无盖章）记录不被本会话对账应用——恢复对账只在
		// 唤起原会话时发生；无 sessionKey 时不过滤（reconcileRestartTask/RPC gate 及历史调用方不变）。
		if (item.sessionBinding === "pull-only") continue;
		// ev-20261026-165da9（无人值守启动恢复）：重启退出证明自动关闭——与显式 task_control reconcile
		// 共用 reconcileStoredTask 执行体（同一退出证明/同一内核契约/同一守卫面：本会话持有拒绝、
		// foreign-owner 拒绝、live 拒绝、unknown fail-closed）。仅接受跨 boot 重启证明（requireCrossBootProof：
		// 同 boot 进程表缺席不是重启证明，退回人工面）：确认物理退出（processState→exited）+ 按未完成
		// 关闭（cancelled/close-unexecuted）——接受轴不变、不猜成功、不自动重派/重放；开关关闭时全走
		// 人工（与 v2.x 自动收口同一逃生舱）。
		if (cfg.enabled && opts.sessionKey !== undefined && REBOOT_CLOSURE_SCENES.has(item.scene)) {
			const outcome = await reconcileStoredTask(item.taskId, `[启动恢复] 设备重启后统一退出证明对账（${item.scene}）——无人值守关闭`, {
				ownerId: opts.ownerId ?? RECOVERY_DEFAULT_OWNER,
				requireCrossBootProof: true,
				...(opts.proveExit !== undefined ? { prove: opts.proveExit } : {}),
			});
			if (outcome.ok && outcome.state === "closed") {
				item.scene = "reboot-closed";
				item.action = "no-action";
				// 关闭后刷新三轴事实（内核已是新事实源）——不能报告 running/alive 却宣称关闭成功
				const fresh = getTaskKernel(opts.ownerId !== undefined ? { ownerId: opts.ownerId } : undefined).get(item.taskId);
				if (fresh) {
					item.execution = fresh.run.execution;
					item.processState = fresh.run.processState;
					item.settlement = fresh.run.settlement;
					item.recovery = fresh.run.recovery;
					item.revision = fresh.revision;
				}
				item.applied = { ok: true, marked: false, code: "reboot-exit-proven", message: outcome.message };
				item.evidenceGaps = [...item.evidenceGaps, `已按重启退出证明关闭（${new Date(now).toISOString()}）：确认物理退出并按未完成关闭，接受轴不变——不猜成功、不自动重派（明细 /amagi recovery show ${item.taskId}）`];
				rebootClosed++;
				try {
					appendAutoReconcileLog(root, { formatVersion: 1, taskId: item.taskId, criterion: "reboot-exit-proven", reconciledAt: now, execution: item.execution, processState: item.processState, settlement: item.settlement });
				} catch { /* lint-exempt:追溯日志失败不回滚权威内核关闭（current.json 已是事实源） */ }
				continue;
			}
			// 证明不可用（unknown/live/同 boot 证据）或不可关闭 → 落入下方保守路径（v2.x 判据 / 人工面标记）。
		}
		// v2.x 自动收口分类器（仅 launch-intent-unconfirmed；开关关闭/无 sessionKey（非会话唤起场景，
		// v2.1「恢复对账只在唤起原会话时发生」）/判据不中 → 人工面照旧）
		if (cfg.enabled && opts.sessionKey !== undefined) {
			const criterion = evaluateAutoReconcile(item, cfg, now);
			if (criterion !== undefined) {
				const note = { criterion, reconciledAt: now, ...(criterion === "stale-dead-process" ? { staleHours: cfg.staleHours } : {}) };
				try {
					writeAutoReconciledSidecar(path.join(root, item.dir), item.taskId, note);
					appendAutoReconcileLog(root, {
						formatVersion: 1, taskId: item.taskId, criterion, reconciledAt: now,
						...(criterion === "stale-dead-process" ? { staleHours: cfg.staleHours } : {}),
						execution: item.execution, processState: item.processState, settlement: item.settlement,
					});
				} catch { /* lint-exempt:自动收口落盘失败回退人工对账（applyOne 保守面） */
					// sidecar/日志落盘失败：回退保守人工面（applyOne 标记 needs-reconciliation），不放大失败
					const r0 = await applyOne(kernel, item, opts.ownerId ?? RECOVERY_DEFAULT_OWNER, [
						{ code: "auto-reconcile-write-failed", detail: "自动收口注记/日志落盘失败——回退人工对账面（sidecar 未生效）" },
					]);
					item.applied = r0;
					if (r0.ok) applied++; else failed++;
					continue;
				}
				item.scene = "auto-reconciled";
				item.action = "no-action";
				item.autoReconciled = note;
				item.evidenceGaps = [...item.evidenceGaps, `已自动收口（${autoReconcileCriterionLabel(note)}，${new Date(now).toISOString()}）：launchIntent 记账缺口关闭，执行/结算/接受三轴未动（明细 /amagi recovery list）`];
				item.applied = { ok: true, marked: false, code: "auto-reconciled" };
				autoClosed++;
				continue;
			}
		}
		const r = await applyOne(kernel, item, opts.ownerId ?? RECOVERY_DEFAULT_OWNER);
		item.applied = r;
		if (r.ok) {
			applied++;
		} else {
			failed++;
		}
	}
	report.summary.applied = applied;
	report.summary.failed = failed;
	report.summary.autoClosed = autoClosed;
	report.summary.rebootClosed = rebootClosed;
	// 改判后重算对账计数（auto-reconciled 不再占待对账/可行动位）
	report.summary.uncertain = report.items.filter((i) => i.action !== "no-action").length;
	report.summary.actionable = report.items.filter(isActionableItem).length;
	report.summary.clean = report.items.filter((i) => i.action === "no-action").length;
	return report;
}

// ── v2.1-A1 adopt 收口流（存量假 foreign-owner 的用户显式确认通道）──────────────

export interface AdoptRecoveryResult {
	ok: boolean;
	taskId: string;
	message: string;
	/** 采纳注记事实（成功采纳/已采纳时透出）。 */
	adopted?: AdoptedNote;
}

/** v2.1-A1：确认收口 foreign-owner 历史记录（/amagi recovery adopt <taskId> 核心）。
 *  语义：用户显式确认“该记录属本机”后写任务目录 adopted.json 注记（原 ownerId/采纳时间/采纳者），
 *  不静默改写原契约记录内容；后续对账按本机历史处理（ownerId 不匹配但被当前 owner 采纳 → 正常分类）。
 *  拒绝面：他人机器记录（spec.machineId 存在且 ≠ 本机）；记录带 machineId 而本机身份未解析（不猜）；
 *  契约记录不可读；已被其他 owner 采纳。幂等：同 owner 重复 adopt 返回既有注记，不改写。 */
export async function adoptRecoveryRecord(taskId: string, opts: TaskRecoveryOptions = {}): Promise<AdoptRecoveryResult> {
	if (!isNonEmptyString(taskId)) return { ok: false, taskId: String(taskId ?? ""), message: "[adopt 拒绝] taskId 必须是非空字符串（用法：/amagi recovery adopt <taskId>）" };
	const store = opts.store ?? createTaskStore();
	const root = opts.root ?? storeRootOf(store);
	const ownerId = opts.ownerId ?? RECOVERY_DEFAULT_OWNER;
	const machineId = opts.machineId !== undefined ? opts.machineId : getLeaderMachineStamp();
	const dir = sanitizeId(taskId);
	const loaded = await store.load(taskId);
	if (!loaded.ok) {
		return { ok: false, taskId, message: `[adopt 拒绝] 契约记录不可读（${loaded.error.code}）：${loaded.error.message}——人工接管修复后重扫再确认收口` };
	}
	const { spec, run } = loaded.value;
	const dirAbs = path.join(root, dir);
	const existing = readAdoptedSidecar(dirAbs, taskId);
	if (existing !== undefined) {
		if (existing.originalOwnerId !== run.ownerId) {
			return { ok: false, taskId, message: `[adopt 拒绝] 采纳注记原 owner ${existing.originalOwnerId} 与记录 ${run.ownerId} 不一致——注记损坏，人工核对后再确认收口` };
		}
		if (existing.adoptedByOwner !== ownerId) {
			return { ok: false, taskId, message: `[adopt 拒绝] 该记录已被 ${existing.adoptedByOwner} 采纳（${new Date(existing.adoptedAt).toISOString()}，原 owner ${existing.originalOwnerId}）——不重复改判` };
		}
		return { ok: true, taskId, adopted: existing, message: `[adopt 幂等] 已采纳（原 owner ${existing.originalOwnerId}，${new Date(existing.adoptedAt).toISOString()}）——对账已按本机历史处理` };
	}
	if (run.ownerId === ownerId) {
		return { ok: true, taskId, message: `[adopt 无需] 记录本属当前 owner（${ownerId}），对账已按本机处理——无需采纳注记` };
	}
	if (spec.machineId !== undefined) {
		if (machineId === undefined) {
			return { ok: false, taskId, message: `[adopt 拒绝] 记录携带 machineId=${spec.machineId.slice(0, 8)}… 而本机身份未解析（machineId 未注入）——无法确认属本机，不猜；确认机器身份后重试` };
		}
		if (spec.machineId !== machineId) {
			return { ok: false, taskId, message: `[adopt 拒绝] 他人机器记录：spec.machineId=${spec.machineId.slice(0, 8)}… ≠ 本机 ${machineId.slice(0, 8)}…（仅本机历史可确认收口；N1 单写者）` };
		}
		return { ok: true, taskId, message: `[adopt 无需] machineId 匹配本机（${machineId.slice(0, 8)}…）——对账已按本机历史识别（v2.1-A1），无需采纳注记` };
	}
	// 旧记录（无 machineId，ownerId 不匹配）：用户显式确认 → sidecar 注记（不静默改写原记录内容）
	const note: AdoptedNote & { machineId?: string } = {
		originalOwnerId: run.ownerId,
		adoptedByOwner: ownerId,
		adoptedAt: Date.now(),
		...(machineId !== undefined ? { machineId } : {}),
	};
	try {
		writeAdoptedSidecar(dirAbs, taskId, note);
	} catch (e) {
		return { ok: false, taskId, message: `[adopt 拒绝] 采纳注记落盘失败（${e instanceof Error ? e.message : String(e)}）——未收口，可重试` };
	}
	return {
		ok: true,
		taskId,
		adopted: { originalOwnerId: note.originalOwnerId, adoptedByOwner: note.adoptedByOwner, adoptedAt: note.adoptedAt },
		message: `[adopt 已收口] 原 owner ${note.originalOwnerId} → 归并入本机对账流（${new Date(note.adoptedAt).toISOString()}）；原契约记录内容未改写，后续对账按本机历史处理`,
	};
}

// ── 查询面（K8c task-query / 启动对账报告接线）──────────────────────────────

/** pull-only 标注（v2.1 噪音分层）：无盖章/他Session/foreign-owner 的记录只入全量视图，
 *  不进横幅触发计数、不被启动对账应用——输出中明确标注，供人工拉取。 */
function pullOnlyNote(i: Readonly<RecoveryItem>): string {
	if (i.sessionBinding !== "pull-only") return "";
	if (i.scene === "foreign-owner") return "｜pull-only（他人记录，仅全量视图；本机历史确认收口：/amagi recovery adopt）";
	if (i.leaderSession === undefined) return "｜pull-only（无会话盖章——旧记录，仅全量视图）";
	return "｜pull-only（本会话外，仅全量视图）";
}

/** v2.1-A1 采纳注记标注（用户显式确认后的本机历史记录）。 */
function adoptedNote(i: Readonly<RecoveryItem>): string {
	return i.adopted ? `｜已采纳（原 owner ${i.adopted.originalOwnerId.slice(0, 24)}，${new Date(i.adopted.adoptedAt).toISOString()}）` : "";
}

/** 单条产物观测的明细行（present/kind-mismatch 带 bytes/mtime/freshness；错误态带 errorCode）。 */
function observedLine(o: Readonly<OutputObservation>): string {
	const parts: string[] = [];
	if (o.state === "kind-mismatch" && o.actualKind !== undefined) parts.push(`实际=${o.actualKind}`);
	if (o.bytes !== undefined) parts.push(`${o.bytes}B`);
	if (o.mtimeMs !== undefined) parts.push(`mtime=${new Date(o.mtimeMs).toISOString()}`);
	if (o.freshness !== undefined) parts.push(o.freshness);
	if (o.errorCode !== undefined) parts.push(o.errorCode);
	return `· ${o.state}${o.required ? "" : "（可选）"}｜${o.expectedKind}｜${o.absolutePath}${parts.length > 0 ? `｜${parts.join(" · ")}` : ""}`;
}

/** 断点块渲染（maxDetails 明细上限，超出明示省略数量与观测时刻——输出规模不静默裁剪）。 */
function checkpointLines(i: Readonly<RecoveryItem>, maxDetails: number): string[] {
	const cp = i.checkpoint;
	if (cp === undefined) return [];
	const lines = [
		`    [断点] 任务书：${cp.assignmentSummary}${cp.assignmentTruncated ? "（摘要截断）" : ""}`,
	];
	if (cp.declarationCount === 0) {
		lines.push("    [断点] 无声明交付清单（spec.outputs 为空——不从任务文本猜路径）");
		return lines;
	}
	const states = ["present", "missing", "kind-mismatch", "unreadable", "denied"] as const;
	const counts = states.map((s) => `${s} ${cp.outputs.filter((o) => o.state === s).length}`).join("·");
	lines.push(`    [断点] 声明产物 ${cp.declarationCount} 项｜${counts}｜观测 ${new Date(cp.observedAt).toISOString()}`);
	for (const o of cp.outputs.slice(0, maxDetails)) lines.push(`    [断点]   ${observedLine(o)}`);
	if (cp.outputs.length > maxDetails) {
		lines.push(`    [断点]   （其余 ${cp.outputs.length - maxDetails} 项省略——全量：/amagi recovery show ${i.taskId}）`);
	}
	return lines;
}

/** 对账清单的人类可读渲染（每任务一行：现场/状态/缺口/建议动作/应用结果 + 断点块≤6 条明细）。
 *  显式拉取面（/amagi recovery / query_task）保留全量信息；auto-reconciled 条目如实呈现判据与时间。 */
export function formatRecoveryReport(report: Readonly<RecoveryReport>): string {
	const lines: string[] = [];
	const autoClosedNow = report.summary.autoClosed ?? 0;
	const rebootClosedNow = report.summary.rebootClosed ?? 0;
	lines.push(`[K8a 恢复对账] root=${report.root} 扫描 ${report.summary.total} 条（干净 ${report.summary.clean}｜待对账 ${report.summary.uncertain}｜本会话可行动 ${report.summary.actionable}${autoClosedNow > 0 ? `｜本会话已自动收口 ${autoClosedNow}` : ""}${rebootClosedNow > 0 ? `｜本会话重启证明关闭 ${rebootClosedNow}` : ""}｜已应用 ${report.summary.applied}${report.summary.failed ? `｜应用失败 ${report.summary.failed}` : ""}）`);
	for (const i of report.items) {
		const facts = i.execution ? `${i.execution}/${i.processState ?? "-"}/${i.settlement ?? "-"}` : `${i.loadError?.code ?? "-"}`;
		lines.push(
			`- ${i.taskId}｜${i.scene}｜${facts}${i.recovery === "needs-reconciliation" ? "｜已标 needs-reconciliation" : ""}${i.autoReconciled ? `｜已自动收口（${autoReconcileCriterionLabel(i.autoReconciled)}，${new Date(i.autoReconciled.reconciledAt).toISOString()}）` : ""}${i.applied ? `｜apply=${i.applied.ok ? `ok${i.applied.code ? `:${i.applied.code}` : ""}` : `fail:${i.applied.code ?? "?"}`}` : ""}${pullOnlyNote(i)}${adoptedNote(i)}｜建议动作=${i.action}`,
		);
		for (const g of i.evidenceGaps) lines.push(`    · 缺口/事实：${g}`);
		lines.push(...checkpointLines(i, 6));
	}
	return lines.join("\n");
}

/** 启动通知预算渲染（v2.x 上下文纪律收敛）：仍需人工的条目只保留任务行（一行/条汇总），断点块/
 *  证据缺口/异常产物的逐条明细全部退到显式拉取面（/amagi recovery show / recovery）；自动收口的
 *  条目零列（仅 index 层注入一行汇总）。保留 1800 字预算与整行装填（长列表不裁一半），溢出附
 *  省略计数与逐项入口。 */
export function formatStartupRecoveryNotice(report: Readonly<RecoveryReport>, opts: { budget?: number } = {}): string {
	const budget = Math.max(200, opts.budget ?? 1800);
	const autoClosedNow = report.summary.autoClosed ?? 0;
	const rebootClosedNow = report.summary.rebootClosed ?? 0;
	const header = `[K8a 恢复对账] 扫描 ${report.summary.total} 条（干净 ${report.summary.clean}｜待对账 ${report.summary.uncertain}｜本会话可行动 ${report.summary.actionable}${autoClosedNow > 0 ? `｜本会话已自动收口 ${autoClosedNow}` : ""}${rebootClosedNow > 0 ? `｜本会话重启证明关闭 ${rebootClosedNow}` : ""}）`;
	const actionable = report.items.filter(isActionableItem);
	const ordered: string[] = [header];
	for (const i of actionable) {
		const facts = i.execution ? `${i.execution}/${i.processState ?? "-"}/${i.settlement ?? "-"}` : `${i.loadError?.code ?? "-"}`;
		// 一条一行汇总（taskId/现场/三轴事实/建议动作——Leader 派续接片的最小行动信息面）
		ordered.push(`- ${i.taskId}｜${i.scene}｜${facts}｜建议动作=${i.action}${pullOnlyNote(i)}`);
	}
	if (actionable.length > 0) {
		ordered.push("（逐任务断点明细：/amagi recovery show <taskId>；完整清单与证据缺口：/amagi recovery）");
	}
	const out: string[] = [];
	let used = 0;
	let droppedAt = -1;
	for (let k = 0; k < ordered.length; k++) {
		const cost = ordered[k]!.length + 1;
		if (used + cost > budget) { droppedAt = k; break; }
		out.push(ordered[k]!);
		used += cost;
	}
	if (droppedAt >= 0 || out.length < ordered.length) {
		const noteOf = () => {
			const note = `…（其余 ${ordered.length - out.length} 行省略——逐任务断点明细：/amagi recovery show <taskId>；完整清单：/amagi recovery）`;
			return header.length + note.length + 1 <= budget ? note : `…（其余 ${ordered.length - out.length} 行省略；全量：/amagi recovery show <taskId>）`;
		};
		// 入口本身也计入预算；替换一条短行仍可能超限，须逐行回退。
		while (out.length > 1 && used + noteOf().length + 1 > budget) used -= out.pop()!.length + 1;
		out.push(noteOf());
	}
	return out.join("\n");
}

// ── ev-20260930-08a8e7：/amagi recovery show 显式拉取面（单任务断点明细）────────

export interface RecoveryShowResult {
	ok: boolean;
	taskId: string;
	message: string;
	/** 观测产物（成功时透出结构化面供 webui/测试消费）。 */
	checkpoint?: RecoveryCheckpoint;
}

/** 单任务断点明细（/amagi recovery show <完整taskId> 核心）：精确查 store → 重新观测 →
 *  完整声明清单（不靠 registry 曾恢复成功；不载 scan 缓存）。显式拉取按原身份/安全规则只读展开
 *  （spec 冻结权限 deny 判定同 scan）；foreign-owner 拒绝不访问声明路径；不可读记录如实拒绝不猜。 */
export async function showRecoveryCheckpoint(taskId: string, opts: TaskRecoveryOptions = {}): Promise<RecoveryShowResult> {
	if (!isNonEmptyString(taskId)) return { ok: false, taskId: String(taskId ?? ""), message: "[show 拒绝] taskId 必须是非空字符串（用法：/amagi recovery show <完整taskId>）" };
	const store = opts.store ?? createTaskStore();
	const root = opts.root ?? storeRootOf(store);
	const ownerId = opts.ownerId ?? RECOVERY_DEFAULT_OWNER;
	const machineId = opts.machineId !== undefined ? opts.machineId : getLeaderMachineStamp();
	// 精确查 store + 重新观测（checkpointWhen 恒真：显式拉取不受会话绑定/现场过滤——观测本身零写入）
	const item = await inspectOne(store, root, sanitizeId(taskId), ownerId, machineId, () => true);
	// 会话绑定标注（仅 sessionKey 提供时；同源 bindSession 单条语义）：显式拉取不受绑定限制，
	// 但标注如实呈现（pull-only 记录可拉取、横幅/应用面照旧不动）。
	bindSession([item], opts.sessionKey);
	if (item.loadError !== undefined) {
		return { ok: false, taskId, message: `[show 拒绝] 契约记录不可读（${item.loadError.code}）：${item.loadError.message}——精确查 store 失败，不猜` };
	}
	if (item.scene === "foreign-owner") {
		return { ok: false, taskId, message: `[show 拒绝] foreign-owner 记录（run.ownerId=${item.ownerId} ≠ 预期 ${ownerId}）——不访问该记录的声明产物路径（N1 单写者；本机历史确认收口：/amagi recovery adopt ${taskId}）` };
	}
	if (item.checkpoint === undefined) {
		return { ok: false, taskId, message: `[show 异常] 断点观测未产出（${item.scene}）——请重试或人工核查任务存储目录` };
	}
	const facts = item.execution ? `${item.execution}/${item.processState ?? "-"}/${item.settlement ?? "-"}` : "-";
	const lines = [
		`[K8a 断点明细] ${taskId}｜${item.scene}｜${facts}｜建议动作=${item.action}${pullOnlyNote(item)}${adoptedNote(item)}`,
		`  工作目录（冻结）：${item.checkpoint.workspaceCwd}`,
	];
	for (const g of item.evidenceGaps) lines.push(`  · 缺口/事实：${g}`);
	// ev-20260930-0dd26f（R6）：steer 通道状态投影（recovery show 是 registry 丢失时的事后追问入口；
	// absent 也如实呈现——「未记录或已回收，无法据此证明全部注入」在显式追问语境下是有效答案；
	// 零写入不触发 GC）
	lines.push(`  ${formatSteerChannelLine(readSteerChannelSnapshot(taskId))}`);
	// 完整声明清单（不载 6 条上限；观测为本次拉取时点）
	const cp = { ...item.checkpoint, outputs: item.checkpoint.outputs };
	lines.push(`  任务书：${cp.assignmentSummary}${cp.assignmentTruncated ? "（摘要截断）" : ""}`);
	if (cp.declarationCount === 0) {
		lines.push("  声明产物：无声明交付清单（spec.outputs 为空——不从任务文本猜路径）");
	} else {
		lines.push(`  声明产物 ${cp.declarationCount} 项（观测 ${new Date(cp.observedAt).toISOString()}）：`);
		for (const o of cp.outputs) lines.push(`  ${observedLine(o)}`);
	}
	lines.push("  （观测为只读 stat 事实：mtime/freshness 不作为「已完成」证据；文件存在不改变待对账状态；续接派新 taskId，普通 running 仍不可 task_resume）");
	return { ok: true, taskId, message: lines.join("\n"), checkpoint: cp };
}

// ── ev-20260930-0dd26f（R6）：steer 通道生命周期分类 + GC 组合（应用层保护证据注入） ──────
//
// 职责分界：task-steer-channel.sweepSteerChannels 是零生命周期知识的低层清扫函数（八条规则④③⑦⑧
// 在彼）；本段从全局契约 store + 本进程 registry 构造分类器注入（八条规则②③⑥的保护证据）：
//   - 契约 store（跨会话权威）：execution 非终态（queued/running/blocked/answering——含待处理链）、
//     recovery=needs-reconciliation、processState alive/unknown/not-started 均 protected；
//     契约明确终态且 processState=exited 才 terminal-exited（取消但进程活着不算可删）。
//   - registry（本进程补充保护）：store 不可读但本进程观察到非终态 → active（不因契约不可读而
//     丢保护）；其余 load 失败一律 no-contract（无可信契约孤儿先保护并列需人工确认——
//     不从「老而 registry 没有」推断进程死）。
// 可删资格另需文件 ≥24h 未修改与 TTL/软阈值判定（低层）；steer 任务不能同 taskId 重开
// （resume 新 taskId 另建通道），旧 taskId 终态后回收不影响任何新通道。

/** 契约执行终态（ExecutionState 契约口径；分类可删依据的唯一权威来自 store 的 run 事实）。 */
const STEER_GC_TERMINAL_EXECUTIONS: ReadonlySet<string> = new Set(["done", "error", "truncated", "cancelled", "resolved-external", "answered"]);

/** registry 非终态（本进程补充保护面：queued/running/blocked/answering——含待处理链）。 */
const STEER_GC_REGISTRY_NON_TERMINAL: ReadonlySet<string> = new Set(["queued", "running", "blocked", "answering"]);

/**
 * 构造 steer 通道生命周期分类器（应用层，任务书 §2-②：组合根/应用层从全局契约 store 及本进程
 * 活跃记录构造分类注入低层清扫函数）。每次 sweep 建一次 store（30 分钟低频触发，代价可忽略）；
 * load 失败 fail-closed 保护，绝不猜终态。导出供测试与部署首轮 dry-run 校验直接消费。
 */
export function buildSteerChannelClassifier(store?: TaskStore): SteerChannelClassifier {
	const s = store ?? createTaskStore();
	return async (taskId: string): Promise<SteerChannelLifecycleClass> => {
		let loaded: Awaited<ReturnType<TaskStore["load"]>> | undefined;
		try { loaded = await s.load(taskId); } catch { /* lint-exempt:契约不可读按 no-contract 保护（fail-closed） */ }
		if (loaded?.ok) {
			const run = loaded.value.run;
			if (run.recovery === "needs-reconciliation") return { kind: "protected", reason: "needs-reconciliation" };
			if (!STEER_GC_TERMINAL_EXECUTIONS.has(run.execution)) return { kind: "protected", reason: "active" };
			if (run.processState !== "exited") return { kind: "protected", reason: run.processState === "unknown" ? "process-unknown" : "process-alive" };
			return { kind: "terminal-exited" };
		}
		const rec = registry.get(taskId);
		if (rec && STEER_GC_REGISTRY_NON_TERMINAL.has(rec.status)) return { kind: "protected", reason: "active" };
		return { kind: "protected", reason: "no-contract" };
	};
}

/**
 * 应用层触发入口（任务书 §2-①）：启动恢复完成后（index.ts）与新 steer 写入后（task-facets steer）
 * 低频触发（30 分钟节流、无后台定时器，节流器在 task-steer-channel）；分类器每次现构——读当前
 * 契约 store 与 registry 现场，不缓存陈旧生命周期。错误与失败如实计入返回值
 * （disabled/failed/deferred），绝不影响 steer 投递/结算——调用方 fire-and-forget（void）。
 */
export async function maybeSweepSteerChannels(opts: SteerChannelSweepOpts = {}): Promise<SteerChannelSweepResult> {
	return sweepSteerChannels(buildSteerChannelClassifier(), opts);
}
