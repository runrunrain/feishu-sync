/**
 * codemode-config.ts — B5A（ev-20261012-7517d8 设计 §6.1）：codemode 受控准入的受信配置面。
 *
 * 单一职责：解析 amagi.json `codemode` 节（全局 ~/.pi/agent/amagi.json → 项目 <cwd>/amagi.json
 * 逐字段覆盖），产出父端（task-facets computeEffectiveGrant 的 user 受信授权面）与
 * /amagi config explain 共用的准入建议。子端不自行现读本配置提高 grant（设计 §6.1）。
 *
 * 语义（设计 §6.1 全文依据；B5A 修复轮 F02/F03/F04 强化）：
 *  - mode/roles.<role>/rpc 只认 off/read-only；根 mode 是总启用门，roles 是主体名单，rpc 是额外交集；
 *   缺省均 off（不配置=零激活=现状字节级等价）。
 *  - 对象字段封闭；role 键以 canonical 名册（baize/luban/luoshen/diting/fuxi）加 leader 校验，
 *   旧 stem 经 agent-aliases 归一；同层归一碰撞异值拒绝（别名冲突报错，F03）；跨层覆盖允许。
 *  - rpc 批B 起接受 off/read-only（批A 只认 off；read-only = RPC 池准入额外交集开启——池侧
 *   还须 worker 启动面 grant 携带 codemode 子对象 + 后端装配成立，配置开启不等于自动授权）。
 *  - budget 按两层显式字段逐字段合并（项目字段优先）后统一物化缺省与校验（F02：项目层 budget
 *   缺失/缺字段不得重置全局显式预算）；聚合字段未显式设置时取「表中默认」与「有效单次上限×次数」
 *   的较小值；显式设大于乘积即配置错误。
 *  - absent 与 invalid 严格区分（F03）：文件不存在/无 codemode 节 = absent；JSON 损坏/节形状非法/
 *   未知键/字段值域非法 = invalid——任一层 invalid 即整体 off（fail-closed，不继承另一层 allow），
 *   只影响 codemode 不阻断普通任务。
 *  - 项目层仅经统一 trust 结果消费（F04）：未受信/unknown 不接受项目放宽（项目 allow 层不消费；
 *   全局层照常生效，即收紧语义保留为「回到全局」，不支持未受信项目收紧全局）。
 *  - AMAGI_CODEMODE_DISABLE=1 紧急关闭（优先于一切配置；=0 不能提升权限——设计 §6.2）。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { canonicalAgentId, CANONICAL_AGENT_IDS } from "./agent-aliases.ts";
import {
	codemodeBudgetFieldRangeProblem,
	codemodeGrantBudgetProblem,
	type CodemodeGrantBudget,
} from "./contracts/permission.ts";

/** 主体名单：canonical 五角色 + leader（一次性 Leader 试点；批A 实际可用主体按 Q-C2=baize/fuxi）。 */
export const CODEMODE_ADMISSION_SUBJECTS: readonly string[] = [...CANONICAL_AGENT_IDS, "leader"];

/** §5.1 预算默认表（硬顶见 contracts/permission.ts codemodeGrantBudgetProblem）。 */
export const DEFAULT_CODEMODE_BUDGET: Readonly<CodemodeGrantBudget> = Object.freeze({
	maxScriptsPerSession: 20,
	maxOutputTokensPerScript: 2000,
	maxTimeoutMsPerScript: 60_000,
	maxTotalOutputTokens: 20_000,
	maxTotalTimeoutMs: 600_000,
});

/** 解析产物：enabled=false（off/配置错误/紧急关闭）或 enabled=true（根门 read-only + 已开角色集 + 物化预算）。 */
export interface CodemodeAdmissionConfig {
	readonly enabled: boolean;
	/** enabled=true 时已显式开启 read-only 的主体名单（canonical 名；空=根门开但无主体）。 */
	readonly roles: ReadonlySet<string>;
	/** enabled=true 时的物化预算（全字段；grant 冻结消费同一对象）。 */
	readonly budget: CodemodeGrantBudget;
	/** rpc 开关（批B：配置 read-only 且根门开启时 true；off/缺省 false——池侧额外交集）。 */
	readonly rpc: boolean;
	/** 配置诊断（错误+来源行；explain/doctor 透出；不影响普通任务）。 */
	readonly diagnostics: readonly string[];
	/** 配置来源说明（哪层文件生效）。 */
	readonly source: "default" | "global" | "project";
}

/** 单层读取结果（F03）：absent=无文件/无节；invalid=损坏或形状非法（整体 off）；ok=节对象。 */
type CodemodeSectionRead = { kind: "absent" } | { kind: "invalid" } | { kind: "ok"; section: Record<string, unknown> };

/** 单层 amagi.json `codemode` 节的宽松读取（字段级校验在合并层做；损坏层=invalid 而非缺省）。 */
function readCodemodeSection(file: string, label: string, diagnostics: string[]): CodemodeSectionRead {
	let raw: string;
	try {
		raw = fs.readFileSync(file, "utf8");
	} catch {
		return { kind: "absent" }; /* lint-exempt:配置文件不存在为正常（缺省 off，非吞错） */
	}
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch (e) {
		diagnostics.push(`codemode 配置读取失败（${label} ${file}）：JSON 解析失败（${e instanceof Error ? e.message : String(e)}）——该层 invalid，整体按 off 处理`);
		return { kind: "invalid" };
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
		diagnostics.push(`codemode 配置非法（${label} ${file}）：根必须是对象——该层 invalid，整体按 off 处理`);
		return { kind: "invalid" };
	}
	const section = (parsed as Record<string, unknown>).codemode;
	if (section === undefined) return { kind: "absent" };
	if (section === null || typeof section !== "object" || Array.isArray(section)) {
		diagnostics.push(`codemode 配置非法（${label} ${file}）：codemode 节必须是对象（mode/roles/rpc/budget）——该层 invalid，整体按 off 处理`);
		return { kind: "invalid" };
	}
	return { kind: "ok", section: section as Record<string, unknown> };
}

function readModeValue(v: unknown): "off" | "read-only" | "invalid" {
	return v === "off" ? "off" : v === "read-only" ? "read-only" : "invalid";
}

/** 预算物化：两层显式字段逐字段合并后统一执行（F02）；显式字段校验值域；聚合字段缺省取
 *  min(默认表值, 单次×次数)。返回 null=非法（诊断已记）。fields 值已验证为 safe integer。 */
function materializeBudgetFromFields(fields: Record<string, number>, label: string, diagnostics: string[]): CodemodeGrantBudget | null {
	const out: Record<string, number> = {
		maxScriptsPerSession: DEFAULT_CODEMODE_BUDGET.maxScriptsPerSession,
		maxOutputTokensPerScript: DEFAULT_CODEMODE_BUDGET.maxOutputTokensPerScript,
		maxTimeoutMsPerScript: DEFAULT_CODEMODE_BUDGET.maxTimeoutMsPerScript,
	};
	for (const key of ["maxScriptsPerSession", "maxOutputTokensPerScript", "maxTimeoutMsPerScript"] as const) {
		if (fields[key] !== undefined) out[key] = fields[key];
	}
	// 聚合字段缺省取「表中默认」与「有效单次上限×次数」较小值（设计 §5.1：避免只调小次数却使继承默认不合法）。
	const defaultAggregate = {
		maxTotalOutputTokens: Math.min(DEFAULT_CODEMODE_BUDGET.maxTotalOutputTokens, out.maxScriptsPerSession! * out.maxOutputTokensPerScript!),
		maxTotalTimeoutMs: Math.min(DEFAULT_CODEMODE_BUDGET.maxTotalTimeoutMs, out.maxScriptsPerSession! * out.maxTimeoutMsPerScript!),
	};
	for (const key of ["maxTotalOutputTokens", "maxTotalTimeoutMs"] as const) {
		out[key] = fields[key] !== undefined ? fields[key] : defaultAggregate[key];
	}
	const problem = codemodeGrantBudgetProblem(out, `codemode.budget（${label}）`);
	if (problem !== null) {
		diagnostics.push(`${problem}——显式越界配置拒绝（不静默钳制），按 off 处理`);
		return null;
	}
	return Object.freeze({
		maxScriptsPerSession: out.maxScriptsPerSession!,
		maxOutputTokensPerScript: out.maxOutputTokensPerScript!,
		maxTimeoutMsPerScript: out.maxTimeoutMsPerScript!,
		maxTotalOutputTokens: out.maxTotalOutputTokens!,
		maxTotalTimeoutMs: out.maxTotalTimeoutMs!,
	}) as CodemodeGrantBudget;
}

const OFF_CONFIG = (diagnostics: readonly string[] = [], source: CodemodeAdmissionConfig["source"] = "default"): CodemodeAdmissionConfig => ({
	enabled: false,
	roles: new Set<string>(),
	budget: DEFAULT_CODEMODE_BUDGET,
	rpc: false,
	diagnostics,
	source,
});

/**
 * 解析 codemode 准入配置（纯读；每次提交/解释现读——KB 级文件，无缓存热点）。
 * env.AMAGI_CODEMODE_DISABLE==="1" 紧急关闭优先；任何一层非法即整体 off（fail-closed）。
 * B5A 修复轮 F04：trust.projectTrusted !== true 时项目层不消费（未知 trust 不接受项目放宽）。
 */
export function resolveCodemodeAdmissionConfig(
	cwd: string,
	env: NodeJS.ProcessEnv = process.env,
	paths?: { globalConfigPath?: string; projectConfigPath?: string },
	trust?: { projectTrusted?: boolean },
): CodemodeAdmissionConfig {
	if (env.AMAGI_CODEMODE_DISABLE === "1") {
		return OFF_CONFIG(["AMAGI_CODEMODE_DISABLE=1：紧急关闭生效（优先于一切 codemode 配置）"]);
	}
	const diagnostics: string[] = [];
	const globalFile = paths?.globalConfigPath ?? path.join(env.PI_CODING_AGENT_DIR ?? path.join(String(env.HOME ?? ""), ".pi", "agent"), "amagi.json");
	const projectFile = paths?.projectConfigPath ?? path.join(cwd, "amagi.json");
	const globalRead = readCodemodeSection(globalFile, "全局", diagnostics);
	const projectRead = readCodemodeSection(projectFile, "项目", diagnostics);
	// F03：任一层 invalid（含损坏 JSON/节形状非法）→ 整体 off，不继承另一层 allow。
	for (const r of [globalRead, projectRead]) {
		if (r.kind === "invalid") return OFF_CONFIG(diagnostics);
	}
	// F04：项目层仅在统一 trust 结果显式受信时消费；未受信/unknown 不接受项目放宽（§6.1）。
	let projectSection: Record<string, unknown> | undefined;
	if (projectRead.kind === "ok") {
		if (trust?.projectTrusted === true) {
			projectSection = projectRead.section;
		} else {
			diagnostics.push(`项目未受信（isProjectTrusted=${String(trust?.projectTrusted ?? "unknown")}）：codemode 项目层不消费（§6.1 未知 trust 不接受项目放宽）——仅全局层生效`);
		}
	}
	const globalSection = globalRead.kind === "ok" ? globalRead.section : undefined;
	if (globalSection === undefined && projectSection === undefined) return OFF_CONFIG(diagnostics);
	const source: CodemodeAdmissionConfig["source"] = projectSection !== undefined ? "project" : "global";

	// 字段封闭（F03：未知键=invalid 整体 off；两层分别校验）。
	for (const [section, label] of [[globalSection, "全局"], [projectSection, "项目"]] as const) {
		if (section === undefined) continue;
		for (const key of Object.keys(section)) {
			if (!["mode", "roles", "rpc", "budget"].includes(key)) {
				diagnostics.push(`codemode 节未知键 "${key}"（${label}）：字段封闭（mode/roles/rpc/budget）——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
		}
	}

	// 逐字段覆盖（项目优先）：mode / rpc。
	// B5A 修复轮二 R2-01：覆盖前分别验证每层明确提供的 mode/rpc——任一层非法即整体 off，
	// 不让合法上层值消除下层非法事实（逐层 fail-closed）。
	for (const [section, label] of [[globalSection, "全局"], [projectSection, "项目"]] as const) {
		if (section === undefined) continue;
		const layerModeRaw = section.mode;
		if (layerModeRaw !== undefined && readModeValue(layerModeRaw) === "invalid") {
			diagnostics.push(`codemode.mode 非法（${label}，实得 ${JSON.stringify(layerModeRaw)}）：只认 off/read-only——该层非法，整体按 off 处理`);
			return OFF_CONFIG(diagnostics, source);
		}
		const layerRpcRaw = section.rpc;
		if (layerRpcRaw !== undefined && readModeValue(layerRpcRaw) === "invalid") {
			diagnostics.push(`codemode.rpc 非法（${label}，实得 ${JSON.stringify(layerRpcRaw)}）：只认 off/read-only（批B 起 read-only=RPC 池准入交集开启）——该层非法，整体按 off 处理`);
			return OFF_CONFIG(diagnostics, source);
		}
	}
	const pickSection = <T>(read: (s: Record<string, unknown>) => T | undefined): T | undefined => {
		const fromProject = projectSection !== undefined ? read(projectSection) : undefined;
		if (fromProject !== undefined) return fromProject;
		return globalSection !== undefined ? read(globalSection) : undefined;
	};
	const rootModeRaw = pickSection((s) => s.mode);
	const rootMode = readModeValue(rootModeRaw);
	if (rootMode !== "read-only") return OFF_CONFIG(diagnostics, source);

	// roles：两层并集语义（项目键覆盖全局同键；canonical+leader 校验；同层别名归一碰撞异值拒绝——F03）。
	const roles = new Map<string, "off" | "read-only">();
	for (const [section, label] of [[globalSection, "全局"], [projectSection, "项目"]] as const) {
		if (section === undefined) continue;
		const rawRoles = section.roles;
		if (rawRoles === undefined) continue;
		if (rawRoles === null || typeof rawRoles !== "object" || Array.isArray(rawRoles)) {
			diagnostics.push(`codemode.roles 非法（${label}）：必须是对象（role → off/read-only）——整体按 off 处理`);
			return OFF_CONFIG(diagnostics, source);
		}
		const layer = new Map<string, "off" | "read-only">();
		for (const [rawKey, rawValue] of Object.entries(rawRoles as Record<string, unknown>)) {
			const key = rawKey.trim().toLowerCase();
			const subject = canonicalAgentId(key);
			if (!CODEMODE_ADMISSION_SUBJECTS.includes(subject)) {
				diagnostics.push(`codemode.roles 未知主体 "${rawKey}"（${label}；合法：${CODEMODE_ADMISSION_SUBJECTS.join("/")}；旧 stem 名须用 canonical 名）——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
			const value = readModeValue(rawValue);
			if (value === "invalid") {
				diagnostics.push(`codemode.roles.${rawKey} 非法（${label}，实得 ${JSON.stringify(rawValue)}）：只认 off/read-only——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
			if (layer.has(subject) && layer.get(subject) !== value) {
				diagnostics.push(`codemode.roles 同层主体冲突（${label}）：键 "${rawKey}" 与前键归一到 ${subject} 但值 ${JSON.stringify(value)}≠${JSON.stringify(layer.get(subject))}——别名冲突拒绝，整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
			layer.set(subject, value);
		}
		for (const [subject, value] of layer) roles.set(subject, value);
	}

	// 预算（F02 逐字段合并；R2-01 逐层 fail-closed）：每层显式字段先单层物化+值域校验
	//（任一层非法即整体 off，不被上层合法覆盖抹除）；再合并物化做跨层乘积终检。
	const BUDGET_KEYS = ["maxScriptsPerSession", "maxOutputTokensPerScript", "maxTimeoutMsPerScript", "maxTotalOutputTokens", "maxTotalTimeoutMs"] as const;
	const mergedFields: Record<string, number> = {};
	for (const [section, label] of [[globalSection, "全局"], [projectSection, "项目"]] as const) {
		if (section === undefined) continue;
		const rawBudget = section.budget;
		if (rawBudget === undefined) continue; // 该层未显式设预算——不重置另一层显式字段（F02）
		if (rawBudget === null || typeof rawBudget !== "object" || Array.isArray(rawBudget)) {
			diagnostics.push(`codemode.budget 非法（${label}）：必须是对象——整体按 off 处理`);
			return OFF_CONFIG(diagnostics, source);
		}
		for (const key of Object.keys(rawBudget as Record<string, unknown>)) {
			if (!(BUDGET_KEYS as readonly string[]).includes(key)) {
				diagnostics.push(`codemode.budget 未知键 "${key}"（${label}）：字段封闭——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
		}
		const layerFields: Record<string, number> = {};
		for (const key of BUDGET_KEYS) {
			const v = (rawBudget as Record<string, unknown>)[key];
			if (v === undefined) continue;
			if (typeof v !== "number" || !Number.isSafeInteger(v)) {
				diagnostics.push(`codemode.budget.${key} 必须是 safe integer（${label}，实得 ${JSON.stringify(v)}）——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
			layerFields[key] = v;
		}
		// R2-01+B5A 终裁 R3-01：单层只查**显式字段**值域（契约单源逐字段检查）——不做层内缺省物化
		// 与乘积判定（层内缺省乘积会误拒合法继承预算，如项目聚合 60000 依赖全局单次 10000）；
		// 乘积约束仅对合并物化结果检查（下方统一物化处）。任一层显式非法字段仍在此拒绝（R2-01 保持）。
		for (const [key, value] of Object.entries(layerFields)) {
			const problem = codemodeBudgetFieldRangeProblem(key, value, `codemode.budget（${label}）`);
			if (problem !== null) {
				diagnostics.push(`${problem}——整体按 off 处理`);
				return OFF_CONFIG(diagnostics, source);
			}
		}
		Object.assign(mergedFields, layerFields); // 项目字段逐字段覆盖全局（F02）
	}
	// 跨层合并后的乘积终检（R2-01：合并物化后检查跨字段约束）。
	const budget = materializeBudgetFromFields(mergedFields, projectSection !== undefined ? "项目（含全局继承合并）" : "全局", diagnostics);
	if (budget === null) return OFF_CONFIG(diagnostics, source);

	const enabledRoles = new Set<string>([...roles.entries()].filter(([, v]) => v === "read-only").map(([k]) => k));
	// rpc 逐字段覆盖（项目优先；两层均 off/缺省 → false）。
	const rpcValue = readModeValue(pickSection((s) => s.rpc));
	return {
		enabled: true,
		roles: enabledRoles,
		budget,
		rpc: rpcValue === "read-only",
		diagnostics,
		source,
	};
}

/** explain/doctor 单行投影（不回显任何凭据；诊断随行）。 */
export function summarizeCodemodeAdmissionConfig(config: CodemodeAdmissionConfig): string {
	if (!config.enabled) {
		const extra = config.diagnostics.length > 0 ? `；诊断：${config.diagnostics.join("；")}` : "";
		return `codemode：off（${config.source}）${extra}`;
	}
	const roleList = [...config.roles].join(",") || "（无主体开启）";
	return `codemode：read-only（${config.source}）· subjects=${roleList} · scriptTools=read（批A 冻结——deny 感知搜索属后续批） · rpc=${config.rpc ? "read-only（批B：池侧额外交集——任务仍须携带 codemode grant）" : "off"} · budget=scripts≤${config.budget.maxScriptsPerSession},tokens≤${config.budget.maxOutputTokensPerScript}/次,timeout≤${config.budget.maxTimeoutMsPerScript}ms/次,聚合 ${config.budget.maxTotalOutputTokens}tokens/${config.budget.maxTotalTimeoutMs}ms${config.diagnostics.length > 0 ? `；诊断：${config.diagnostics.join("；")}` : ""}`;
}
