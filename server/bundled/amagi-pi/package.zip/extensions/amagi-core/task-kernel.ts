/**
 * task-kernel.ts — amagi-pi v2 K3：任务内核（每个 owner 唯一的提交状态写入口，N1 单写者）。
 *
 * 依赖方向（§3.1 应用层）：task-kernel → { contracts/*（纯契约）, task-registry（迁移期投影）}；
 * 不得 import 具体执行后端/工具面（depcruise 规则 v2-kernel-no-backend）——后端只能报告观察。
 *
 * 核心纪律（方案 §3.3/§3.4/§3.5，K1 冻结契约 contracts/command.ts|task.ts）：
 *  - apply(KernelCommand) 是唯一状态写入口：每命令恰好一次 store.replaceCurrent CAS，stateSeq
 *    连续（= 旧值+1，首建 0）；命令先经 validateKernelCommand 先验后行，再做内核语义校验
 *    （迁移表 / 三轴 / revision 失效栅栏 / 回执一致性）。
 *  - 同步提交段（校验→内存权威态→投影→视图通知→入队 CAS）是线性化点：JS 单线程保证段间不可
 *    交织；磁盘 CAS 串行链按入队顺序执行。apply 路径 await 自身提交，失败且未被并发覆盖时
 *    回滚内存与投影（内存不半提交）；桥路径 fire-and-forget，失败标记 degraded[]（迁移期内存
 *    权威，K8a 对账收敛）。
 *  - revision 失效栅栏（N2/N3）：一切携带 TaskKey 的命令要求 key.revision === 当前 revision，
 *    否则拒绝——旧 revision 不发布回执/通知/解锁。唯一例外（§3.4）：取消后迟到的 exited 观察
 *    仍可确认物理退出（仅清理观察 processState/exitedAt，不改执行态、不改 cancelled）。
 *  - cancel 先 revision+1（撤销采纳资格）再迁移状态；§3.4 pending 例外：done/truncated 且
 *    settlement=pending 允许取消（撤销本轮结果采纳，不伪造进程被杀——processState/exitedAt 不动，
 *    settlement 保持 pending）；已发布结算回执（currentReceipt 存在 ⇒ settlement≠pending）的完成
 *    记录拒绝 cancel，错误引导 decide/reject 表达不接受。
 *  - 分层声明（任务书明示）：activity 事件只进内存 ring（视图可见），不推进 stateSeq、不触发
 *    存储提交——重启可丢，属 degraded 可接受；started/session/exited 是 TaskRun 持久字段变化，
 *    推进 stateSeq。TaskRun 持久提交（stateSeq）只在执行状态/结算/接受/回执指针变化时发生。
 *  - 观察序号（§3.3 observe）：observationSeq 单后端内递增；重复序号无副作用（幂等 no-op）；
 *    终结事件 exited 不可被低序号覆盖（seq 门 + exitedSeen 闩锁）。
 *  - publish-receipt：先栅栏校验（迟到回执落盘前被拒——N3「无回执落盘」），saveReceipt 不可变
 *    落盘成功后再 CAS 提交 currentReceipt 指针与 settlement/acceptance 一致组（§3.2「一起提交」）；
 *    回执只接受初始 unreviewed（acceptance 只能经 decide 改变）。decide：accept 生成新 receiptSeq
 *    沿用证据不重跑；incomplete 接受须显式 waive（K1 预留口子的 K3 实现口径：waivedCheckIds 非
 *    空且 id 已知）。v2.3（ev-20260918-0784ed）：accept 前置扩至 error（外部采用收口）——error 须
 *    显式 waive error-execution-coverage，无该豁免整单拒绝（effects=none）。【K1 契约缺口注记】decide 命令缺 accept/reject 判别字段——K3 实现为 accept
 *    面，reject 语义待集成负责人统一改版 K1（或经 TaskApplication.control，K7 接线）后接入。
 *  - reconcile（N9）：不确定执行标 recovery=needs-reconciliation，不猜成功（不置 done）；
 *    close-unexecuted 仅适用无 launchIntent 的 queued；confirm-exited 只确认物理退出事实。
 *  - 任务身份（K3 裁量）：K1 register 命令未携带独立 taskId（TaskSpec 契约亦无），本内核以
 *    spec.specId 为任务身份键（一 spec 一 run；N6 续接=新 taskId+新 specId；submit 面生成安全
 *    UUID 作 specId，K5a 接线）。ownerId 由组合根注入（缺省 amagi-leader-local，K8c 换真实身份）。
 *
 * 迁移桥（LegacyBridge，@deprecated K4-K8 逐片拆除）：现役生产代码大量调用 registry.patch——
 * 桥是本切片让「内核成为唯一写入口」落地的手段：registry legacy 写方法经桥转译为内核命令
 * （状态变化→命令映射；观测补录→内存投影；其余字段→受控白名单写入），绝不开放任意 patch
 * 直写内部表（registry 内部可变表仅经 kernelProjection 注入点由本模块写）。桥写入同样走内核
 * CAS（stateSeq 连续）；内核命令语义与 legacy 语义冲突时退回桥过渡（legacy 语义优先，标
 * degraded），保证既有测试与调用方零破坏。
 */

import { randomUUID } from "node:crypto";
import {
	DECIDE_ACCEPT_EXECUTIONS,
	ERROR_EXECUTION_COVERAGE_GAP_ID,
	validateKernelCommand,
	type KernelCommand,
	type ResumeLease,
	type TaskKernel,
	type TaskStore,
} from "./contracts/command.ts";
import {
	canCancelExecution,
	sealSpec,
	validateExecutionTransition,
	validateStateTriple,
	type ExecutionState,
	type TaskReceipt,
	type TaskRun,
	type TaskSpec,
	type TaskView,
} from "./contracts/task.ts";
import { CONTRACT_ERROR_CODES, err, ok, type ContractError, type Ref, type Result, type TaskKey } from "./contracts/view.ts";
// D1（ev-20260922-c896f8）：可 waive id 全集单源（当前回执 missing∪checks.id 去重稳定序；纯函数）。
import { availableWaiverIds } from "./contracts/evidence.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import {
	registry,
	RegistryError,
	type RegistryKernelBridge,
	type RegistryKernelProjection,
	type TaskRecord,
} from "./task-registry.ts";

// ── 错误码（内核命名空间；契约校验错误透传 CONTRACT_ERROR_CODES，存储错误透传 store-*/cas-*） ──

export const KERNEL_ERROR_CODES = {
	TASK_NOT_FOUND: "kernel-task-not-found",
	REVISION_FENCE: "kernel-revision-fence",
	INVALID_COMMAND_STATE: "kernel-invalid-command-state",
	STORE_FAILURE: "kernel-store-failure",
} as const;

// ── 公共类型 ─────────────────────────────────────────────────────────────────

export interface TaskKernelDeps {
	store: TaskStore;
	/** 时钟注入（测试/确定性用）；缺省 Date.now。 */
	clock?: () => number;
	/** owner 逻辑身份（组合根注入；缺省 amagi-leader-local）。 */
	ownerId?: string;
	/** 结算回调：终态迁移后触发（task-writes GC 等清理适配器经此注入；§3.1「GC 迁至结算后的可选清理适配器」，GC 失败不影响事实提交）。 */
	onSettle?: (taskId: string) => void;
}

/** K3 裁量：TaskView 附加 activity 内存 ring 摘要（§3.4 分层——活动不进持久状态，视图可见、重启可丢）。 */
export type KernelTaskView = TaskView & { activity?: readonly string[] };

export type KernelViewListener = (view: Readonly<KernelTaskView>) => void;

/** @deprecated K3 迁移桥 API 面（K4-K8 逐片拆除）——task-service/registry legacy 写点经此走内核命令。 */
export interface LegacyBridgeApi {
	/** @deprecated registry.create 经此：内核 register（+ 非 queued 记录 grant-start）。 */
	createRecord(rec: TaskRecord, opts: { startQueued: boolean }): Readonly<TaskRecord>;
	/** @deprecated registry.patch 经此：状态变化映射内核命令；字段走受控白名单写入（每次桥写入一次 CAS）。 */
	patchRecord(taskId: string, patch: Partial<TaskRecord>): Readonly<TaskRecord> | undefined;
	/** @deprecated registry.adoptExternal 经此：内核种子收编（bridge seed，K8a 收敛为对账命令）。 */
	adoptRecord(rec: TaskRecord): Readonly<TaskRecord>;
	/** @deprecated 观测补录经此（activity/round/writePath/artifactRef/cancelledResult——内存投影，不推进 stateSeq）。 */
	observeLegacy(
		taskId: string,
		kind: "activity" | "round" | "writePath" | "artifactRef" | "cancelledResult",
		payload: unknown,
		apply: (rec: TaskRecord) => void,
	): void;
	/** @deprecated registry.reopenForAutoContinue 经此（v1 自动续跑机制的桥专用受控迁移，K4/K5 拆除）。 */
	reopen(taskId: string): void;
	/** @deprecated registry.clear/restoreFromSnapshot 经此复位内核态（记录重建仍走 registry 自身，K8a 收敛）。 */
	reset(): void;
	/** @deprecated 内核是否持有该任务（registry.create 碰撞预检用）。 */
	has(taskId: string): boolean;
	/** task-service K3 接线：cancel 命令 + legacy 记录语义（errorMessage/revision/endedAt/child 清理）。 */
	cancelLegacy(taskId: string, errorMessage: string): { ok: boolean; message: string };
	/** task-service K3 接线：resolve-external 命令 + legacy 记录语义（resolveNote/revision/endedAt）。 */
	resolveExternalLegacy(taskId: string, resolveNote: string): { ok: boolean; message: string };
}

/** attachRegistry 目标（registry 单例的结构化超集；默认注入全局 registry）。 */
export interface RegistryAttachTarget {
	kernelProjection(): RegistryKernelProjection;
	installKernelBridge(bridge: RegistryKernelBridge): void;
	settleGc(taskId: string): void;
}

export interface TaskKernelRuntime extends TaskKernel {
	/** ev-20261005-055864（diting F-03）：内核 owner 只读暴露——reconcile fence 要求 key.ownerId
	 *  与内核同源，resume 桥接/生产对账统一从内核读。 */
	readonly ownerId: string;
	apply(command: KernelCommand): Promise<Result<TaskView>>;
	/** v2.0.1 跨会话显示契约：恢复对账静默执行——种子与 apply 同源，零 registry 投影/零 settle 钩子
	 *  （旧会话残留不进本会话看板/status-ui；内核仍持有供查询与后续 decide-cancel）。 */
	applyQuiet(command: KernelCommand, opts?: { syncExistingProjection?: boolean }): Promise<Result<TaskView>>;
	/** v2.5.1（diting MJ-2 修复）：decide/验收面的 store 回退种子——回执已发布而验收前重启的
	 *  clean-complete 记录不进恢复对账种子（no-action 零写入），accept/reject 在内核未知时经
	 *  store.load 静默补种子：零命令执行、零 stateSeq 变更、零 registry 投影（保守面同 applyQuiet）。 */
	seedFromStoreIfAbsent(taskId: string): Promise<boolean>;
	/** F8-R2：续接恢复真实契约，可替换 bridge 占位；等待占位提交退出后重读 store，冲突拒绝。 */
	restoreResumeParentFromStore(taskId: string): Promise<Result<Readonly<TaskSpec>>>;
	/** 冻结 spec 同步快照（含 workspace/空 outputs 的事实）；占位仍由消费者显式识别。 */
	frozenSpecOf(taskId: string): Readonly<TaskSpec> | undefined;
	get(taskId: string): Readonly<KernelTaskView> | undefined;
	/** 视图变更订阅（K8c 查询面用；接口最小化——只读快照通知，无命令面）。 */
	subscribe(fn: KernelViewListener): () => void;
	/** P4 §7 接缝（M3 生产激活）：同步读冻结 spec 授权（内存态——register 后 spec 不可变，与 store
	 *  回读等价；仅真实 P1 grant 返回，legacy 占位/未持有 → undefined。只读，不触发任何写入）。 */
	frozenPermissionOf(taskId: string): PermissionGrant | undefined;
	/** ev-20260920-61839b：同步读冻结 spec.outputs（resume 继承面；空声明/legacy 恒空 → undefined）。 */
	frozenOutputsOf(taskId: string): readonly import("./contracts/task.ts").OutputSpec[] | undefined;
	/** 安装迁移桥到 registry（@deprecated 桥面，K4-K8 拆除）；deps.onSettle 缺省时接 registry 终态 GC。 */
	attachRegistry(target?: RegistryAttachTarget): void;
	/** @deprecated 迁移桥 API（K4-K8 拆除）。 */
	readonly bridge: LegacyBridgeApi;
}

// ── 内部状态 ─────────────────────────────────────────────────────────────────

interface KernelTask {
	spec: TaskSpec;
	/** 内存权威态（同步提交段更新；磁盘 CAS 串行链跟随）。 */
	run: TaskRun;
	/** 当前回执（与 run.currentReceipt 一致提交）。 */
	receipt?: TaskReceipt;
	degraded: string[];
	/** activity 内存 ring（§3.4 分层：不持久化、不推进 stateSeq，重启可丢）。 */
	activity: string[];
	/** backendRunId → 已应用最高 observationSeq（重复/低序号幂等门）。 */
	obsSeq: Map<string, number>;
	/** backendRunId → 已观察到终结事件（started/session 不复活已退出的运行）。 */
	exitedSeen: Set<string>;
	/** resume session lease（N6：防并发续接；内存态，重启经 reconcile 收敛）。 */
	resumeLease?: ResumeLease;
	/** store CAS 串行链（按入队顺序；绝不 reject——失败经结果通道回收）。 */
	commitChain: Promise<void>;
}

interface ComputedPlan {
	/** noop = 幂等无副作用（重复观察序号/同 lease 重复 begin/重复 reconcile 标记）；mutate = 一次 stateSeq 提交；activity = 仅内存 ring。 */
	kind: "mutate" | "activity" | "noop";
	run?: TaskRun;
	receipt?: TaskReceipt;
	needReceiptSave?: TaskReceipt;
	needSpecSave?: TaskSpec;
	createdTask?: boolean;
	terminal?: boolean;
	obsSeq?: { backendRunId: string; seq: number };
	obsExit?: string;
	lease?: ResumeLease;
	clearLease?: boolean;
	/** activity ring 追加（activity 事件 / 迟到观察注记）。 */
	note?: string;
}

interface ExecOpts {
	/** apply 路径：await 自身提交，失败回滚（内存不半提交）；桥路径 fire-and-forget，失败进 degraded。 */
	awaitCommit: boolean;
	/** 内核原生任务投影到 registry 记录（桥路径由桥自身写记录）。"existing"=只更新本会话已有投影，
	 *  不新建（恢复对账：已回填收编的记录须同步，未收编的跨会话记录不进看板）。 */
	project: boolean | "existing";
	/** 终态回调时机：afterCommit=提交成功后（apply）；sync=同步段（桥专用收口）；none=桥调用方自行触发。 */
	settle: "afterCommit" | "sync" | "none";
}

const EXEC_APPLY: ExecOpts = { awaitCommit: true, project: true, settle: "afterCommit" };
const EXEC_BRIDGE: ExecOpts = { awaitCommit: false, project: false, settle: "none" };
/** v2.0.1 跨会话显示契约：恢复对账专用执行档——持久化与 apply 同权威（awaitCommit），
 *  但零 registry 投影、零 settle 钩子（旧会话残留不得进入本会话看板/状态栏/GC 链）。 */
const EXEC_RECOVERY_QUIET: ExecOpts = { awaitCommit: true, project: false, settle: "none" };
/** ev-20261021-a8de95（diting F-03）：工具面恢复对账档——与 quiet 同为零 settle 钩子（不重放终态副作用），
 *  但同步本会话已有的 registry 投影（回填收编记录不残留 running 快照）；不新建投影。 */
const EXEC_RECOVERY_SYNC: ExecOpts = { awaitCommit: true, project: "existing", settle: "none" };

const ACTIVITY_RING_MAX = 20;
const DEGRADED_MAX = 10;

/** DTO 深冻结（拷贝后冻结——冻结的是投影视图，内核内部态保持可变）。 */
function freezeDto<T>(v: T): Readonly<T> {
	if (v === null || typeof v !== "object") return v;
	if (Array.isArray(v)) return Object.freeze((v as unknown[]).map(freezeDto)) as unknown as Readonly<T>;
	const c: Record<string, unknown> = {};
	for (const k of Object.keys(v as Record<string, unknown>)) c[k] = freezeDto((v as Record<string, unknown>)[k]);
	return Object.freeze(c) as Readonly<T>;
}

/** 桥种子 spec：legacy 记录没有 v2 spec——合成最小合法冻结 spec（K5a 起由 submit 面冻结真实策略）。 */
function bridgeSpec(p: { taskId: string; agent: string; assignment: string; model?: string; cwd?: string; parentTaskId?: string }): TaskSpec {
	return sealSpec({
		version: 1,
		specId: p.taskId,
		agent: p.agent,
		assignment: p.assignment,
		inputs: [],
		outputs: [],
		permission: {
			policyVersion: 1,
			assurance: "tool-enforced",
			tools: [],
			read: [],
			write: [],
			deny: [],
			reportFiles: [],
			shell: "deny",
			mcp: [],
			lsp: [],
		},
		workspace: { cwd: p.cwd || process.cwd(), mode: "existing", dependencyVisibility: "unknown" },
		verification: {
			id: "bridge-legacy",
			version: 1,
			objectMode: "snapshot",
			allowSharedFallback: false,
			checks: [],
			acceptance: "manual",
			criteria: ["legacy 桥种子：验收沿用 v1 语义（K5a 起由 submit 面冻结真实策略）"],
		},
		effective: {
			profileId: "bridge-legacy",
			profileDigest: "bridge-legacy",
			model: p.model || "unknown",
			fallbackModels: [],
			hostVersion: "amagi-pi-v2-k3",
			surfaceVersion: 1,
		},
		contextMode: "isolated",
		...(p.parentTaskId ? { parentTaskId: p.parentTaskId } : {}),
	});
}

/** legacy 状态 → 种子 processState（收编/重种子时的保守推断；N9：不确定走 reconcile）。 */
function seedProcessState(status: string): TaskRun["processState"] {
	if (status === "running" || status === "answering") return "alive";
	if (status === "queued") return "not-started";
	return "exited"; // done/error/cancelled/truncated/answered/resolved-external/blocked：已退出（blocked 语义=进程已退出待处理）
}

function storeErrorOf(e: unknown): ContractError {
	const maybe = e as { error?: ContractError };
	if (maybe && typeof maybe.error === "object" && maybe.error !== null && typeof maybe.error.code === "string") {
		const er = maybe.error;
		return {
			code: er.code,
			message: er.message,
			fields: er.fields ?? [],
			effects: er.effects ?? "unknown",
			repairExamples: er.repairExamples ?? [],
		};
	}
	return {
		code: KERNEL_ERROR_CODES.STORE_FAILURE,
		message: `存储提交失败：${e instanceof Error ? e.message : String(e)}`,
		fields: [],
		effects: "unknown",
		repairExamples: [],
	};
}

/** 错误透传（Result<true>/Result<{from,to}> 的失败分支转目标 Result<T>）。 */
function failOf<T>(r: { ok: false; error: ContractError }): Result<T> {
	return { ok: false, error: r.error };
}

function terminalExecution(s: ExecutionState): boolean {
	return ["done", "error", "answered", "cancelled", "truncated", "resolved-external"].includes(s);
}

function nextActionsOf(run: TaskRun, hasReceipt: boolean): readonly string[] {
	const out: string[] = [];
	if (run.recovery === "needs-reconciliation") out.push("reconcile");
	switch (run.execution) {
		case "queued":
			out.push("grant-start", "cancel");
			break;
		case "running":
			out.push("observe", "cancel");
			break;
		case "blocked":
			out.push("begin-resume", "cancel", "resolve-external");
			break;
		case "answering":
			out.push("finish-resume", "cancel");
			break;
		case "done":
		case "truncated":
			if (!hasReceipt) {
				out.push("publish-receipt");
				if (canCancelExecution(run.execution, run.settlement)) out.push("cancel");
			} else if (run.acceptance === "unreviewed") {
				out.push("decide");
			}
			break;
		case "error":
			// v2.3（ev-20260918-0784ed）：error+回执+unreviewed 可 decide（accept 须 waive
			// error-execution-coverage / reject 表达不接受）——终态收口不再只能靠会话记录留痕。
			if (hasReceipt && run.acceptance === "unreviewed") out.push("decide");
			break;
		default:
			break; // answered/cancelled/resolved-external/error：无后续动作（后续执行新建 taskId）
	}
	return out;
}

// ── 内核实现 ─────────────────────────────────────────────────────────────────

class TaskKernelImpl implements TaskKernelRuntime {
	private readonly tasks = new Map<string, KernelTask>();
	private readonly listeners = new Set<KernelViewListener>();
	private proj: RegistryKernelProjection | null = null;
	private settleGcTarget: { settleGc(taskId: string): void } | null = null;
	private readonly clock: () => number;
	private readonly ownerIdInternal: string;
	/** ev-20261005-055864（diting F-03）：内核 owner 公开只读——reconcile 命令 fence 要求 key.ownerId
	 *  与内核同源（resume 桥接/生产对账统一从内核读，不再各自解析可能漂移的身份）。 */
	get ownerId(): string { return this.ownerIdInternal; }
	private readonly deps: TaskKernelDeps;
	readonly bridge: LegacyBridgeApi;

	// 注：不用 TS 参数属性（constructor(private readonly x)）——本模块经 task-service 被
	// 多个测试以 node 原生 strip-only 模式直载，该语法不受支持。
	constructor(deps: TaskKernelDeps) {
		this.deps = deps;
		this.clock = deps.clock ?? Date.now;
		this.ownerIdInternal = deps.ownerId ?? "amagi-leader-local";
		this.bridge = {
			has: (taskId) => this.tasks.has(taskId),
			createRecord: (rec, opts) => {
				this.bridgeRegister(rec, opts.startQueued);
				this.projectUpsertBridge(rec);
				return freezeDto(rec);
			},
			patchRecord: (taskId, patch) => this.bridgePatch(taskId, patch),
			adoptRecord: (rec) => {
				this.ensureAdopted(rec.taskId);
				this.projectUpsertBridge(rec);
				return freezeDto(rec);
			},
			observeLegacy: (taskId, kind, payload, apply) => {
				const kt = this.tasks.get(taskId);
				// activity 类同时进内核内存 ring（§3.4 分层——视图可见、不推进 stateSeq）
				if (kt && kind === "activity") {
					const ev = payload as { type?: string; summary?: string };
					this.pushActivity(kt, `${ev?.type ?? "activity"}: ${ev?.summary ?? ""}`.trim());
					this.notify(kt);
				}
				this.projMutate(taskId, apply);
			},
			reopen: (taskId) => {
				// v1 自动续跑：done/error→running（v2 表禁止 done 重开——legacy 例外，K4/K5 换新 taskId 后拆除）
				const r = this.bridgeTransitionSync(taskId, "running", { legacyException: true });
				if (!r.ok) throw new RegistryError(`仅 done 可自动续跑重开: ${taskId} ${r.error.message.slice(0, 120)}`);
				this.projMutate(taskId, (rec) => {
					rec.status = "running";
					rec.endedAt = undefined;
					rec.startedAt = Date.now();
				});
			},
			reset: () => {
				this.tasks.clear();
			},
			cancelLegacy: (taskId, errorMessage) => this.bridgeControl(taskId, "cancel", errorMessage, (rec, run) => {
				rec.errorMessage = errorMessage;
			}),
			resolveExternalLegacy: (taskId, resolveNote) => this.bridgeControl(taskId, "resolve-external", resolveNote, (rec) => {
				rec.resolveNote = resolveNote;
			}),
		};
	}

	// ── TaskKernel 端口 ──────────────────────────────────────────────────────

	async apply(command: KernelCommand): Promise<Result<TaskView>> {
		// 恢复路径前置能力（K8a 全量恢复的种子）：reconcile 对内核未知任务先尝试 store.load 种子
		const taskId = command.type === "register" ? command.spec.specId : command.key.taskId;
		if (!this.tasks.has(taskId) && command.type === "reconcile") {
			const loaded = await this.deps.store.load(taskId);
			if (loaded.ok && !this.tasks.has(taskId)) this.seedFromStore(loaded.value.spec, loaded.value.run, loaded.value.receipt);
		}
		return await this.execute(command, EXEC_APPLY);
	}

	/** v2.0.1：恢复对账静默执行——种子前置与 apply 同源，但零 registry 投影/零 settle 钩子。
	 *  跨会话残留经此进内核（权威可查/可后续 decide-cancel），不进本会话展示态。 */
	async applyQuiet(command: KernelCommand, opts?: { syncExistingProjection?: boolean }): Promise<Result<TaskView>> {
		const taskId = command.type === "register" ? command.spec.specId : command.key.taskId;
		if (!this.tasks.has(taskId) && command.type === "reconcile") {
			const loaded = await this.deps.store.load(taskId);
			if (loaded.ok && !this.tasks.has(taskId)) this.seedFromStore(loaded.value.spec, loaded.value.run, loaded.value.receipt);
		}
		return await this.execute(command, opts?.syncExistingProjection ? EXEC_RECOVERY_SYNC : EXEC_RECOVERY_QUIET);
	}

	/** v2.5.1（diting MJ-2）：store 回退种子（decide 面）——接口注释见 TaskKernelRuntime。 */
	async seedFromStoreIfAbsent(taskId: string): Promise<boolean> {
		if (this.tasks.has(taskId)) return true;
		const loaded = await this.deps.store.load(taskId);
		if (!loaded.ok) return false;
		if (!this.tasks.has(taskId)) this.seedFromStore(loaded.value.spec, loaded.value.run, loaded.value.receipt);
		return this.tasks.has(taskId);
	}

	async restoreResumeParentFromStore(taskId: string): Promise<Result<Readonly<TaskSpec>>> {
		const before = this.tasks.get(taskId);
		if (before) await before.commitChain;
		const chain = before?.commitChain;
		const loaded = await this.deps.store.load(taskId);
		if (!loaded.ok) return loaded;
		const current = this.tasks.get(taskId);
		if (current !== before || current?.commitChain !== chain || current?.resumeLease) {
			return err("resume-parent-conflict", "恢复父契约期间内核状态变化/lease 被占，未替换占位", ["taskId"]);
		}
		if (current && current.spec.verification.id !== "bridge-legacy") {
			return current.spec.specDigest === loaded.value.spec.specDigest
				? ok(freezeDto(current.spec))
				: err("resume-parent-conflict", "内存与磁盘父冻结契约不同源，不能猜测授权/outputs", ["specDigest"]);
		}
		const { spec, run, receipt } = loaded.value;
		if (current && (current.run.execution !== run.execution || current.run.revision !== run.revision || (run.sessionId !== undefined && current.run.sessionId !== run.sessionId))) {
			return err("resume-parent-conflict", `bridge 占位与磁盘父执行身份不一致（execution=${current.run.execution}/${run.execution}, revision=${current.run.revision}/${run.revision}, sessionId=${current.run.sessionId}/${run.sessionId}），不能重置续接状态`, ["execution", "revision", "sessionId"]);
		}
		// 旧 JSON 执行记录可只在 registry snapshot 保留 sessionId；缺字段不是相冲突身份。
		// 仅补缺失的会话元数据，授权/workspace/outputs 绝不取自占位或默认值。
		const restored = this.seedFromStore(spec, run.sessionId === undefined && current?.run.sessionId !== undefined
			? { ...run, sessionId: current.run.sessionId } : run, receipt);
		this.project(restored);
		return ok(freezeDto(spec));
	}

	frozenSpecOf(taskId: string): Readonly<TaskSpec> | undefined {
		const kt = this.tasks.get(taskId);
		return kt ? freezeDto(kt.spec) : undefined;
	}

	get(taskId: string): Readonly<KernelTaskView> | undefined {
		const kt = this.tasks.get(taskId);
		return kt ? this.viewOf(kt) : undefined;
	}

	subscribe(fn: KernelViewListener): () => void {
		this.listeners.add(fn);
		return () => { this.listeners.delete(fn); };
	}

	frozenPermissionOf(taskId: string): PermissionGrant | undefined {
		const kt = this.tasks.get(taskId);
		if (kt === undefined) return undefined;
		const p = kt.spec.permission;
		// 与 task-service.isEnforceablePermissionGrant 同判定（此处内联避免循环依赖）：真实 grant 携带非空 tools；
		// legacy v1 占位（guarded 无 tools）不返回——调用方据此区分执法/占位。
		if (typeof p === "object" && p !== null && Array.isArray((p as { tools?: unknown }).tools) && ((p as { tools?: unknown }).tools as unknown[]).length > 0) {
			return p as PermissionGrant;
		}
		return undefined;
	}

	frozenOutputsOf(taskId: string): readonly import("./contracts/task.ts").OutputSpec[] | undefined {
		const kt = this.tasks.get(taskId);
		if (kt === undefined) return undefined;
		// 与 frozenPermissionOf 同口径：legacy 空 outputs 不返回——调用方据此区分「无声明」与「未冻结」。
		// ev-20260920-61839b：resume 续接继承父任务声明产物契约（注入续接轮任务书 + 新 spec 冻结）。
		return kt.spec.outputs.length > 0 ? kt.spec.outputs : undefined;
	}

	attachRegistry(target?: RegistryAttachTarget): void {
		const t = target ?? (registry as RegistryAttachTarget);
		this.proj = t.kernelProjection();
		this.settleGcTarget = t;
		t.installKernelBridge(this.registryBridgeView());
	}

	// ── 视图 ─────────────────────────────────────────────────────────────────

	private viewOf(kt: KernelTask): Readonly<KernelTaskView> {
		const run = kt.run;
		const view: KernelTaskView = {
			viewVersion: 1,
			taskId: run.taskId,
			ownerId: run.ownerId,
			revision: run.revision,
			stateSeq: run.stateSeq,
			execution: run.execution,
			settlement: run.settlement,
			acceptance: run.acceptance,
			assurance: this.frozenPermissionOf(run.taskId)?.assurance ?? "guarded",
			degraded: Object.freeze([...kt.degraded]),
			spec: freezeDto({
				specId: kt.spec.specId,
				specDigest: kt.spec.specDigest,
				agent: kt.spec.agent,
				assignment: kt.spec.assignment,
				outputs: kt.spec.outputs,
				contextMode: kt.spec.contextMode,
				...(kt.spec.parentTaskId ? { parentTaskId: kt.spec.parentTaskId } : {}),
			}),
			run: freezeDto({ ...run }),
			...(kt.receipt
				? {
					receipt: freezeDto({
						receiptId: kt.receipt.receiptId,
						receiptSeq: kt.receipt.receiptSeq,
						settlement: kt.receipt.settlement,
						acceptance: kt.receipt.acceptance,
						specDigest: kt.receipt.specDigest,
						missing: kt.receipt.missing,
						// ev-20260924-a28713：可 waive 全集单源填充（availableWaiverIds），投影不再丢弃决策面信息
						waivable: availableWaiverIds(kt.receipt),
						ref: run.currentReceipt,
					}),
				}
				: {}),
			nextActions: Object.freeze([...nextActionsOf(run, kt.receipt !== undefined)]),
			activity: Object.freeze([...kt.activity]),
		};
		return Object.freeze(view);
	}

	private notify(kt: KernelTask): void {
		if (this.listeners.size === 0) return;
		const view = this.viewOf(kt);
		for (const fn of this.listeners) {
			try { fn(view); } catch { /* 订阅者异常不反噬提交 */ }
		}
	}

	private pushActivity(kt: KernelTask, note: string): void {
		kt.activity.push(note);
		if (kt.activity.length > ACTIVITY_RING_MAX) kt.activity.shift();
	}

	private degrade(taskId: string, note: string): void {
		const kt = this.tasks.get(taskId);
		if (!kt) return;
		kt.degraded.push(note);
		if (kt.degraded.length > DEGRADED_MAX) kt.degraded.shift();
	}

	private fireSettle(taskId: string): void {
		try {
			if (this.deps.onSettle) this.deps.onSettle(taskId);
			else this.settleGcTarget?.settleGc(taskId);
		} catch { /* 清理适配器失败不影响事实提交（§3.1） */ }
	}

	// ── 执行核心（apply 与桥共用） ───────────────────────────────────────────

	/** 命令执行：桥路径（awaitCommit=false）全同步返回 Result；apply 路径含回执保存/CAS 等待时返回 Promise。 */
	private execute(command: KernelCommand, opts: ExecOpts): Result<TaskView> | Promise<Result<TaskView>> {
		const validated = validateKernelCommand(command);
		if (!validated.ok) return validated;
		const cmd = validated.value;
		const taskId = cmd.type === "register" ? cmd.spec.specId : cmd.key.taskId;

		const kt = this.tasks.get(taskId);
		if (!kt && cmd.type !== "register") {
			return err(
				KERNEL_ERROR_CODES.TASK_NOT_FOUND,
				`内核无任务 ${taskId}（未 register；reconcile 亦未在存储中找到可用种子）`,
				["key.taskId"], "none",
				[{ hint: "先 register（taskId=spec.specId）；恢复流程经 store.load 后 reconcile" }],
			);
		}

		const planned = this.plan(cmd, kt ?? undefined);
		if (!planned.ok) return planned;
		const plan = planned.value;
		if (plan.kind === "noop") return ok(this.viewOf(this.tasks.get(taskId)!));

		// 回执类命令：先落不可变回执（栅栏校验已在 plan 完成——N3：迟到回执在落盘前被拒），
		// 成功取回 Ref 后才进入同步提交段（内存任何时刻不出现「有 settlement 无 currentReceipt」的中间态）。
		if (plan.needReceiptSave) {
			if (!opts.awaitCommit) {
				return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, "回执类命令（publish-receipt/decide）不支持桥路径——仅经 apply 提交", ["command.type"]);
			}
			return this.executeWithReceipt(taskId, plan, opts);
		}
		return this.commitPlanned(taskId, plan, opts, cmd.type);
	}

	/** 同步提交段 + CAS；apply 路径返回 Promise（失败回滚——内存不半提交），桥路径同步返回。 */
	private commitPlanned(taskId: string, plan: ComputedPlan, opts: ExecOpts, cmdType?: KernelCommand["type"]): Result<TaskView> | Promise<Result<TaskView>> {
		const target = this.tasks.get(taskId)!;
		const preRun = target.run;
		const preReceipt = target.receipt;
		const preRecordRaw = this.proj ? this.proj.raw(taskId) : undefined;
		const preRecordSnap = preRecordRaw ? ({ ...preRecordRaw } as TaskRecord) : undefined;

		// ── 同步提交段（线性化点） ──
		if (plan.run) target.run = plan.run;
		if (plan.receipt) target.receipt = plan.receipt;
		if (plan.obsSeq) target.obsSeq.set(plan.obsSeq.backendRunId, Math.max(plan.obsSeq.seq, target.obsSeq.get(plan.obsSeq.backendRunId) ?? -1));
		if (plan.obsExit) target.exitedSeen.add(plan.obsExit);
		if (plan.lease) target.resumeLease = plan.lease;
		if (plan.clearLease) target.resumeLease = undefined;
		if (plan.note) this.pushActivity(target, plan.note);
		if (plan.kind === "mutate" && (opts.project === true || (opts.project === "existing" && this.proj?.raw(taskId) !== undefined))) this.project(target);
		this.notify(target);
		if (plan.kind === "activity") {
			// §3.4 分层：活动摘要不触发存储提交、不推进 stateSeq（内存 ring 已更新并通知视图）
			return ok(this.viewOf(target));
		}
		if (opts.settle === "sync" && plan.terminal) this.fireSettle(taskId);

		// ── 存储串行 CAS（每命令恰好一次 replaceCurrent） ──
		const expectedSeq = plan.createdTask ? null : preRun.stateSeq;
		const commit = this.enqueueCommit(target, expectedSeq, target.run, plan.needSpecSave ? { spec: plan.needSpecSave } : {});

		if (!opts.awaitCommit) {
			// 桥路径 fire-and-forget：失败进 degraded（迁移期内存权威；K8a 对账收敛）。
			// diting-M1-Minor②加固：终态控制类（cancel/resolve-external）持久化失败时同步在 legacy 记录面
			// 附加显式注记（不假报无瑕成功——取消采纳资格的存档尚未落盘，重启对账前存在窗口）。
			void commit.then((r) => {
				if (!r.ok) {
					this.degrade(taskId, `store-commit:${r.error.code}`);
					if (cmdType === "cancel" || cmdType === "resolve-external") {
						this.projMutate(taskId, (rec) => {
							rec.errorMessage = `${rec.errorMessage ? rec.errorMessage + "；" : ""}[amagi 桥注记] 终态持久化失败（${r.error.code}）——内存态已收口，重启后需对账确认`;
						});
					}
				}
			});
			return ok(this.viewOf(target));
		}

		return (async () => {
			const committed = await commit;
			if (!committed.ok) {
				// 回滚：内存不半提交（仅当未被并发桥写覆盖时；覆盖场景保内存现状并标 degraded）
				if (target.run === plan.run) {
					target.run = preRun;
					target.receipt = preReceipt;
					if (plan.createdTask) this.tasks.delete(taskId);
					if (this.proj) this.proj.replace(taskId, plan.createdTask ? undefined : preRecordSnap);
					this.notify(target);
				} else {
					this.degrade(taskId, `store-commit-diverged:${committed.error.code}`);
				}
				return err(committed.error.code, committed.error.message, committed.error.fields, committed.error.effects, committed.error.repairExamples);
			}
			if (opts.settle === "afterCommit" && plan.terminal) this.fireSettle(taskId);
			return ok(this.viewOf(target));
		})();
	}

	/** 回执类命令（apply 路径）：saveReceipt → 同步提交段（含 Ref 指针）→ CAS → 失败回滚（孤儿回执留盘，§3.5 对账收敛）。 */
	private async executeWithReceipt(taskId: string, plan: ComputedPlan, opts: ExecOpts): Promise<Result<TaskView>> {
		const target = this.tasks.get(taskId)!;
		const saved = await this.enqueueReceiptSave(target, plan.needReceiptSave!);
		if (!saved.ok) return saved; // 落盘失败：零内存提交
		plan.run = { ...plan.run!, currentReceipt: saved.value };
		plan.receipt = plan.needReceiptSave;
		return this.commitPlanned(taskId, plan, opts);
	}

	// ── 命令语义规划（校验 → 新 run 计划；register 分支在此预置内存任务表——apply 失败路径有
	// 回滚、桥路径 degrade 收口（行为正确），其余分支纯计算无内存副作用） ──────────

	private plan(cmd: KernelCommand, kt: KernelTask | undefined): Result<ComputedPlan> {
		const now = this.clock();
		switch (cmd.type) {
			case "register": {
				if (kt) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `同 taskId 重复 register 拒绝：${cmd.spec.specId}（一 spec 一 run；续接/重派创建新 taskId）`, ["spec.specId"]);
				}
				const run: TaskRun = {
					version: 1,
					ownerId: this.ownerId,
					taskId: cmd.spec.specId,
					revision: 0,
					specId: cmd.spec.specId,
					stateSeq: 0,
					execution: "queued",
					settlement: "pending",
					acceptance: "unreviewed",
					backend: "json",
					...(cmd.groupId ? { groupId: cmd.groupId } : {}),
					...(cmd.nodeId ? { nodeId: cmd.nodeId } : {}),
					...(cmd.spec.parentTaskId ? { parentTaskId: cmd.spec.parentTaskId } : {}),
					recovery: "none",
					queuedAt: now,
					processState: "not-started",
				};
				const fresh: KernelTask = { spec: cmd.spec, run, degraded: [], activity: [], obsSeq: new Map(), exitedSeen: new Set(), commitChain: Promise.resolve() };
				this.tasks.set(run.taskId, fresh);
				return ok({ kind: "mutate", run, needSpecSave: cmd.spec, createdTask: true, terminal: false });
			}
			case "grant-start": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				if (kt!.run.execution !== "queued") {
					return err(CONTRACT_ERROR_CODES.INVALID_TRANSITION, `grant-start 仅允许 queued（当前 ${kt!.run.execution}；二次 grant 幂等拒绝）`, ["execution"]);
				}
				return ok({ kind: "mutate", run: this.bump(kt!, { execution: "running", backend: cmd.backend, launchIntent: cmd.launchIntent }), terminal: false });
			}
			case "observe": {
				return this.planObserve(kt!, cmd, now);
			}
			case "cancel": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const run = kt!.run;
				if (!canCancelExecution(run.execution, run.settlement)) {
					if ((run.execution === "done" || run.execution === "truncated") && run.currentReceipt) {
						return err(
							CONTRACT_ERROR_CODES.INVALID_TRANSITION,
							`${run.execution} 已发布结算回执（settlement=${run.settlement}）——cancel 拒绝，使用 decide(reject)/reject 表达不接受`,
							["execution", "settlement"], "none",
							[{ hint: "decide 引用当前 receiptId 拒绝该回执；接受失败结果须受信上下文例外授权（K7 control 面）" }],
						);
					}
					return err(CONTRACT_ERROR_CODES.INVALID_TRANSITION, `不可取消（execution=${run.execution}, settlement=${run.settlement}；§3.4 取消例外仅 done/truncated+pending——撤销本轮结果采纳）`, ["execution"]);
				}
				// N3：先 revision+1（撤销采纳资格），再迁移状态；不伪造进程被杀（processState/exitedAt 不动）
				return ok({ kind: "mutate", run: this.bump(kt!, { execution: "cancelled", revision: cmd.key.revision + 1 }), terminal: true });
			}
			case "resolve-external": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const t = validateExecutionTransition(kt!.run.execution, "resolved-external");
				if (!t.ok) return failOf(t);
				return ok({ kind: "mutate", run: this.bump(kt!, { execution: "resolved-external", revision: cmd.key.revision + 1 }), terminal: true });
			}
			case "begin-resume": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const lease = kt!.resumeLease;
				if (lease && (lease.holder !== cmd.lease.holder || lease.nonce !== cmd.lease.nonce)) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `resume session lease 被 ${lease.holder} 持有（N6：lease 防并发续接）`, ["lease"]);
				}
				if (lease) return ok({ kind: "noop" }); // 同 lease 重复 begin 幂等
				const t = validateExecutionTransition(kt!.run.execution, "answering");
				if (!t.ok) return failOf(t);
				return ok({ kind: "mutate", run: this.bump(kt!, { execution: "answering" }), lease: cmd.lease, terminal: false });
			}
			case "finish-resume": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const to = cmd.outcome;
				const t = validateExecutionTransition(kt!.run.execution, to);
				if (!t.ok) return failOf(t);
				return ok({
					kind: "mutate",
					run: this.bump(kt!, { execution: to, ...(cmd.successorTaskId ? { successorTaskId: cmd.successorTaskId } : {}) }),
					clearLease: true,
					terminal: to === "answered",
				});
			}
			case "publish-receipt": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const r = cmd.receipt;
				const run = kt!.run;
				if (r.acceptance !== "unreviewed" || r.decision !== undefined) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, "publish-receipt 只接受初始 unreviewed 回执（acceptance 只能经 decide 改变——N8 显式接受）", ["receipt.acceptance"]);
				}
				if (r.taskId !== run.taskId || r.ownerId !== this.ownerId) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `回执 TaskKey(${r.ownerId}/${r.taskId}) 与任务不匹配`, ["receipt.taskId", "receipt.ownerId"]);
				}
				if (r.specDigest !== kt!.spec.specDigest) {
					return err(CONTRACT_ERROR_CODES.DIGEST_MISMATCH, "回执 specDigest 与冻结 spec 不一致（交付版本链断裂）", ["receipt.specDigest"]);
				}
				if (r.revision !== cmd.key.revision) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `receipt.revision=${r.revision} 须与栅栏 revision=${cmd.key.revision} 一致提交`, ["receipt.revision"]);
				}
				if (r.executionObserved !== run.execution) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `receipt.executionObserved=${r.executionObserved} 与当前执行态 ${run.execution} 不一致（证据/状态分歧）`, ["receipt.executionObserved"]);
				}
				if (r.receiptSeq !== (kt!.receipt?.receiptSeq ?? 0) + 1) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `receiptSeq=${r.receiptSeq} 不连续（须为 ${(kt!.receipt?.receiptSeq ?? 0) + 1}；首发=1）`, ["receipt.receiptSeq"]);
				}
				const triple = validateStateTriple({ execution: run.execution, settlement: r.settlement, acceptance: "unreviewed", hasReceipt: true });
				if (!triple.ok) return failOf(triple);
				return ok({
					kind: "mutate",
					run: this.bump(kt!, { settlement: r.settlement, acceptance: "unreviewed" }),
					needReceiptSave: r,
					terminal: false,
				});
			}
			case "decide": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				const run = kt!.run;
				const cur = kt!.receipt;
				if (!cur || !run.currentReceipt) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, "无当前回执不可 decide（N8：接受/拒绝引用当前 receiptId；无回执只能 pending/incomplete 且 unreviewed）", ["receiptId"]);
				}
				if (cmd.receiptId !== cur.receiptId) {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `receiptId 不匹配（当前 ${cur.receiptId}）`, ["receiptId"]);
				}
				if (run.acceptance !== "unreviewed") {
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `已决策（acceptance=${run.acceptance}）——回执不可重复 decide`, ["decision"]);
				}
				// K1 v1.1（Leader 集成负责人裁定）：verdict 判别。reject 不设 waive 门槛、不限 execution
				// （failed 回执也走 reject 表达不接受）；accept 保持原门槛（非 failed、incomplete 须显式 waive）。
				// v2.3（ev-20260918-0784ed）：accept 前置从 done/truncated 扩至 +error（DECIDE_ACCEPT_EXECUTIONS）
				// ——error 终态产物被外部核验采用后的收口路径（resolve-external 只面向 blocked/queued，实战缺口）。
				// error 前置必须显式 waive error-execution-coverage：接受的是「产物已被外部核采用」的事实，
				// 豁免是显式留痕；无该豁免整单拒绝（effects=none）。done/truncated 门槛零变化。
				const isReject = cmd.verdict === "reject";
				if (!isReject) {
					if (!DECIDE_ACCEPT_EXECUTIONS.includes(run.execution)) {
						return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `accept 只面向 done/truncated/error（当前 ${run.execution}；error 须 waive ${ERROR_EXECUTION_COVERAGE_GAP_ID}）`, ["execution"]);
					}
					if (cur.settlement === "failed") {
						return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, "failed 回执不可 accept（失败处置走重派/新 taskId；拒绝该回执用 verdict=reject）", ["decision"]);
					}
					if (run.execution === "error" && !cmd.decision.waivedCheckIds.includes(ERROR_EXECUTION_COVERAGE_GAP_ID)) {
						// D1：全集单源 + 结构化 repairExamples（真数组，非伪 JSON 字符串；只建议裁剪不默认全 waive）。
						const errorAvailable = availableWaiverIds(cur);
						return err(
							KERNEL_ERROR_CODES.INVALID_COMMAND_STATE,
							`execution=error 的 accept 必须显式 waive ${ERROR_EXECUTION_COVERAGE_GAP_ID}（accept 记录的是「产物已被外部核验采用」这一事实，waive 用来留痕）；当前回执 missing=[${cur.missing.join(", ")}]；可 waive id 全集=[${errorAvailable.join(", ")}]`,
							["decision.waivedCheckIds"], "none",
							[{ waivedCheckIds: [...new Set([ERROR_EXECUTION_COVERAGE_GAP_ID, ...cur.missing])] }],
						);
					}
				}
				const waived = cmd.decision.waivedCheckIds;
				// D1（ev-20260922-c896f8）：known 取 availableWaiverIds（contracts 纯 helper；旧回执照实含
				// id:status 字面量——不猜测映射、不剥离后缀，decide 对旧回执仍使用实际存储 id）。
				const available = availableWaiverIds(cur);
				const known = new Set<string>(available);
				if (!isReject && cur.settlement === "incomplete" && waived.length === 0) {
					const fillIds = cur.missing.length > 0 ? cur.missing : available;
					return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `settlement=incomplete 的 accept 必须显式 waive（waivedCheckIds 非空）；当前回执 missing=[${cur.missing.join(", ")}]；可 waive id 全集=[${available.join(", ")}]（repairExamples 已预填全集，按接受决策裁剪，不默认全 waive）`, ["decision.waivedCheckIds"], "none", [{ waivedCheckIds: [...fillIds] }]);
				}
				for (const id of waived) {
					if (!known.has(id)) {
						return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, `waivedCheckIds 含未知 id：${id}（须引用 receipt.missing 或 checks[].id；当前回执可用 id：[${available.join(", ")}]${available.length === 0 ? "——清单为空（settlement=ready 且无未通过 checks）：无需 waive，去掉该字段直接 accept" : "；旧回执的 id:status 字面量照实引用，不剥离后缀"}）`, ["decision.waivedCheckIds"], "none",
							available.length > 0 ? [{ waivedCheckIds: [...available] }] : [{ hint: "去掉 waivedCheckIds 字段后直接 accept（回执无可用豁免项）" }]);
					}
				}
				// 新回执：receiptSeq+1，沿用证据不重跑（outputs/object/checks/settlement/missing 原样）；settlement 保持原值
				const nextAcceptance: "accepted" | "rejected" = isReject ? "rejected" : "accepted";
				const nextReceipt: TaskReceipt = {
					...cur,
					receiptId: `receipt-${randomUUID()}`,
					receiptSeq: cur.receiptSeq + 1,
					acceptance: nextAcceptance,
					decision: {
						actor: cmd.decision.actor,
						reason: cmd.decision.reason,
						at: now,
						waivedCheckIds: waived,
						previousReceiptId: cur.receiptId,
					},
					createdAt: now,
				};
				return ok({
					kind: "mutate",
					run: this.bump(kt!, { acceptance: nextAcceptance }),
					needReceiptSave: nextReceipt,
					terminal: false,
				});
			}
			case "reconcile": {
				const f = this.fence(kt!, cmd.key);
				if (!f.ok) return failOf(f);
				switch (cmd.disposition) {
					case "needs-reconciliation":
					case "manual-takeover": {
						if (kt!.run.recovery === "needs-reconciliation") return ok({ kind: "noop" });
						// N9：不确定执行标 needs-reconciliation，不猜成功（不置 done）；人工接管同样保留证据缺口
						return ok({ kind: "mutate", run: this.bump(kt!, { recovery: "needs-reconciliation" }), terminal: false });
					}
					case "close-unexecuted": {
						if (kt!.run.execution !== "queued" || kt!.run.launchIntent) {
							return err(KERNEL_ERROR_CODES.INVALID_COMMAND_STATE, "close-unexecuted 仅适用无 launchIntent 的 queued（§3.5：明确关闭为未执行；有启动意图的不确定执行走 needs-reconciliation）", ["execution", "launchIntent"]);
						}
						return ok({ kind: "mutate", run: this.bump(kt!, { execution: "cancelled" }), terminal: true });
					}
					case "confirm-exited": {
						// 只确认物理退出事实；execution 不变（不猜成功/失败——N9）
						return ok({ kind: "mutate", run: this.bump(kt!, { processState: "exited", exitedAt: kt!.run.exitedAt ?? now }), terminal: false });
					}
				}
			}
		}
	}

	private planObserve(kt: KernelTask, cmd: Extract<KernelCommand, { type: "observe" }>, _now: number): Result<ComputedPlan> {
		// 身份/栅栏：owner/taskId 恒校验（diting-M1-Minor①：非 stale 路径原漏查 ownerId——跨 owner 观察不得因 revision 恰好匹配而放行）；
		// revision 例外只放行迟到 exited（§3.4 清理观察）
		const stale = cmd.key.revision !== kt.run.revision;
		if (cmd.key.ownerId !== this.ownerId || cmd.key.taskId !== kt.run.taskId) {
			const f = this.fence(kt, cmd.key);
			if (!f.ok) return failOf(f);
		}
		if (stale && cmd.event.kind !== "exited") {
			return err(KERNEL_ERROR_CODES.REVISION_FENCE, `revision 失效栅栏：key.revision=${cmd.key.revision} ≠ 当前 ${kt.run.revision}（N3：旧 revision 不发布回执/通知/解锁；仅迟到 exited 允许清理观察）`, ["key.revision"], "none", [{ hint: "get(taskId) 重读当前 revision 后重试" }]);
		}
		// 观察序号门（单后端内递增）：重复/低序号无副作用（幂等）——终结事件 exited 由此受高序号保护
		const lastSeq = kt.obsSeq.get(cmd.backendRunId) ?? -1;
		if (cmd.observationSeq <= lastSeq) return ok({ kind: "noop" });
		const obsSeq = { backendRunId: cmd.backendRunId, seq: cmd.observationSeq };

		// ev-20261019-06c169 运行身份栅栏：前一 backendRunId 的迟到退出不得覆盖已开始的新运行
		//（同 taskId 自动续跑/修复轮各是独立物理运行；旧 close 迟到只留诊断注记，不改当前运行状态）。
		if (cmd.event.kind === "exited" && kt.run.backendRunId !== undefined && kt.run.backendRunId !== cmd.backendRunId && kt.run.processState === "alive") {
			return ok({
				kind: "activity",
				note: `迟到退出观察来自旧运行 ${cmd.backendRunId.slice(0, 16)}（当前 ${kt.run.backendRunId.slice(0, 16)} 在跑）——忽略，不覆盖当前运行`,
				obsSeq,
				});
		}

		if (stale) {
			// 取消后迟到退出观察：仅清理观察（processState/exitedAt），不改执行态、不改 cancelled
			const ev = cmd.event as { kind: "exited"; exitCode: number | null; at: number };
			return ok({
				kind: "mutate",
				run: this.bump(kt, { processState: "exited", exitedAt: ev.at, backendRunId: cmd.backendRunId }),
				terminal: false,
				obsSeq,
				obsExit: cmd.backendRunId,
				note: `迟到退出观察（旧 revision ${cmd.key.revision}→当前 ${kt.run.revision}）：exitCode=${ev.exitCode ?? "null"}（清理观察，${kt.run.execution} 不变）`,
			});
		}

		switch (cmd.event.kind) {
			case "activity": {
				// 分层（§3.4/N2）：活动摘要只进内存 ring（视图可见），不推进 stateSeq、不触发存储提交；重启可丢（degraded 可接受）
				return ok({ kind: "activity", note: cmd.event.note, obsSeq });
			}
			case "started": {
				if (kt.exitedSeen.has(cmd.backendRunId)) return ok({ kind: "noop" });
				// ev-20261019-06c169：新物理运行开始——清除上一物理运行的 exitedAt（任务级 startedAt 保留首轮口径）
				const run = this.bump(kt, { processState: "alive", backendRunId: cmd.backendRunId, ...(kt.run.startedAt === undefined ? { startedAt: cmd.event.at } : {}) });
				if (run.exitedAt !== undefined) delete run.exitedAt;
				return ok({ kind: "mutate", run, terminal: false, obsSeq });
			}
			case "session": {
				if (kt.exitedSeen.has(cmd.backendRunId)) return ok({ kind: "noop" });
				return ok({ kind: "mutate", run: this.bump(kt, { sessionId: cmd.event.sessionId, backendRunId: cmd.backendRunId }), terminal: false, obsSeq });
			}
			case "exited": {
				// ev-20261019-06c169：preserve＝纯物理退出观察——只更新 processState/exitedAt/backendRunId，
				// 不迁移 execution、不触发业务终结钩子（业务终态由桥/回执面提交；JSON 引擎统一携带 preserve）。
				if (cmd.event.executionPolicy === "preserve") {
					return ok({
						kind: "mutate",
						run: this.bump(kt, { processState: "exited", exitedAt: cmd.event.at, backendRunId: cmd.backendRunId }),
						terminal: false,
						obsSeq,
						obsExit: cmd.backendRunId,
					});
				}
				// 退出映射：running + exitCode 0 → done（settlement 仍 pending，回执由 publish-receipt 提交）；
				// 非零/null（信号死）→ error；非 running（queued/blocked/answering/终态）只记录退出事实，不改执行态
				const exec: ExecutionState = kt.run.execution === "running" ? (cmd.event.exitCode === 0 ? "done" : "error") : kt.run.execution;
				if (exec !== kt.run.execution) {
					const t = validateExecutionTransition(kt.run.execution, exec);
					if (!t.ok) return failOf(t);
				}
				return ok({
					kind: "mutate",
					run: this.bump(kt, { processState: "exited", exitedAt: cmd.event.at, execution: exec, backendRunId: cmd.backendRunId }),
					terminal: exec !== kt.run.execution,
					obsSeq,
					obsExit: cmd.backendRunId,
				});
			}
		}
	}

	private fence(kt: KernelTask, key: TaskKey): Result<true> {
		if (key.ownerId !== this.ownerId) {
			return err(KERNEL_ERROR_CODES.REVISION_FENCE, `ownerId 不匹配（key=${key.ownerId}，owner=${this.ownerId}）——单写者栅栏（N1）`, ["key.ownerId"]);
		}
		if (key.taskId !== kt.run.taskId) {
			return err(KERNEL_ERROR_CODES.REVISION_FENCE, `taskId 不匹配（key=${key.taskId}，任务=${kt.run.taskId}）`, ["key.taskId"]);
		}
		if (key.revision !== kt.run.revision) {
			return err(KERNEL_ERROR_CODES.REVISION_FENCE, `revision 失效栅栏：key.revision=${key.revision} ≠ 当前 ${kt.run.revision}（N2/N3：旧 revision 不发布回执/通知/解锁）`, ["key.revision"], "none", [{ hint: "get(taskId) 重读当前 revision 后重试" }]);
		}
		return ok(true);
	}

	private bump(kt: KernelTask, over: Partial<TaskRun>): TaskRun {
		return { ...kt.run, ...over, stateSeq: kt.run.stateSeq + 1 };
	}

	// ── 存储提交（串行链 + CAS） ─────────────────────────────────────────────

	private enqueueCommit(kt: KernelTask, expectedSeq: number | null, run: TaskRun, extra: { spec?: TaskSpec } = {}): Promise<Result<true>> {
		const exec = async (): Promise<Result<true>> => {
			try {
				if (extra.spec) {
					// K2 端口超集（K2-report「K3 集成注意①」）：saveSpec 需 taskId 定位任务目录；K1 契约签名未含——窄 cast 调用
					const store = this.deps.store as TaskStore & { saveSpec(spec: Readonly<TaskSpec>, taskId: string): Promise<Ref> };
					await store.saveSpec(extra.spec, run.taskId);
				}
				await this.deps.store.replaceCurrent(expectedSeq, run);
				return ok(true);
			} catch (e) {
				const er = storeErrorOf(e);
				return err(er.code, er.message, er.fields, er.effects, er.repairExamples);
			}
		};
		const result = kt.commitChain.then(exec, exec);
		kt.commitChain = result.then(() => undefined, () => undefined);
		return result;
	}

	/** 回执不可变落盘（串行链上先于对应 current CAS；失败零内存提交）。 */
	private enqueueReceiptSave(kt: KernelTask, receipt: TaskReceipt): Promise<Result<Ref>> {
		const exec = async (): Promise<Result<Ref>> => {
			try {
				return ok(await this.deps.store.saveReceipt(receipt));
			} catch (e) {
				const er = storeErrorOf(e);
				return err(er.code, er.message, er.fields, er.effects, er.repairExamples);
			}
		};
		const result = kt.commitChain.then(exec, exec);
		kt.commitChain = result.then(() => undefined, () => undefined);
		return result;
	}

	// ── registry 投影（内核原生任务；桥任务由桥写记录） ──────────────────────

	private project(kt: KernelTask): void {
		if (!this.proj) return;
		const run = kt.run;
		const existing = this.proj.raw(run.taskId);
		if (!existing) {
			this.proj.upsert({
				taskId: run.taskId,
				agent: kt.spec.agent,
				status: run.execution,
				model: kt.spec.effective.model,
				goal: kt.spec.assignment,
				cwd: kt.spec.workspace.cwd,
				startedAt: run.queuedAt,
				backend: run.backend,
				revision: run.revision,
				queuedAt: run.queuedAt,
				...(run.sessionId !== undefined ? { sessionId: run.sessionId } : {}),
				...(run.groupId !== undefined ? { runId: run.groupId } : {}),
				...(run.nodeId !== undefined ? { nodeId: run.nodeId } : {}),
				...(run.parentTaskId !== undefined ? { parentTaskId: run.parentTaskId } : {}),
			});
		} else {
			this.proj.mutate(run.taskId, (rec) => {
				rec.status = run.execution;
				rec.revision = run.revision;
				if (run.sessionId !== undefined) rec.sessionId = run.sessionId;
				if (terminalExecution(run.execution)) {
					if (!rec.endedAt) rec.endedAt = this.clock();
					rec.child = undefined;
				}
			});
		}
		this.proj.notify();
	}

	// ── 迁移桥（@deprecated K4-K8 拆除） ─────────────────────────────────────

	private registryBridgeView(): RegistryKernelBridge {
		return {
			hasTask: (taskId) => this.tasks.has(taskId),
			create: (rec, opts) => this.bridge.createRecord(rec, opts),
			patch: (taskId, patch) => this.bridge.patchRecord(taskId, patch),
			adoptExternal: (rec) => this.bridge.adoptRecord(rec),
			observeLegacy: (taskId, kind, payload, apply) => this.bridge.observeLegacy(taskId, kind, payload, apply),
			reopenForAutoContinue: (taskId) => this.bridge.reopen(taskId),
			reset: () => this.bridge.reset(),
		};
	}

	private projMutate(taskId: string, apply: (rec: TaskRecord) => void): void {
		if (!this.proj) return;
		this.proj.mutate(taskId, apply);
		this.proj.notify();
	}

	private projectUpsertBridge(rec: TaskRecord): void {
		if (!this.proj) return;
		this.proj.upsert(rec);
		this.proj.notify();
	}

	private keyOf(kt: KernelTask): TaskKey {
		return { ownerId: this.ownerId, taskId: kt.run.taskId, revision: kt.run.revision };
	}

	/** 桥种子：legacy 记录收编进内核（stateSeq=0 起步，CAS 首建 fire-and-forget；目录已存在时 degraded，K8a 对账收敛）。 */
	private ensureAdopted(taskId: string): KernelTask {
		const existing = this.tasks.get(taskId);
		const raw = this.proj ? this.proj.raw(taskId) : undefined;
		if (!raw) throw new RegistryError(`桥写入失败：registry 无记录 ${taskId}`);
		if (existing && existing.run.execution === raw.status) return existing;
		// 无内核态（桥安装前创建/快照恢复后首次写）或与记录状态脱同步：以记录现状重种子（迁移期以 registry 投影为对齐基准）
		const spec = bridgeSpec({
			taskId: raw.taskId,
			agent: raw.agent,
			assignment: raw.goal || `bridge:${raw.taskId}`,
			model: raw.model,
			cwd: raw.cwd,
			parentTaskId: raw.parentTaskId,
		});
		const run: TaskRun = {
			version: 1,
			ownerId: this.ownerId,
			taskId: raw.taskId,
			revision: raw.revision ?? 0,
			specId: raw.taskId,
			stateSeq: 0,
			execution: raw.status as ExecutionState,
			settlement: "pending",
			acceptance: "unreviewed",
			backend: raw.backend ?? "json",
			...(raw.sessionId !== undefined ? { sessionId: raw.sessionId } : {}),
			...(raw.runId !== undefined ? { groupId: raw.runId } : {}),
			...(raw.nodeId !== undefined ? { nodeId: raw.nodeId } : {}),
			...(raw.parentTaskId !== undefined ? { parentTaskId: raw.parentTaskId } : {}),
			recovery: "none",
			queuedAt: raw.queuedAt ?? raw.startedAt,
			...(raw.startedAt !== undefined ? { startedAt: raw.startedAt } : {}),
			processState: seedProcessState(raw.status),
		};
		const fresh: KernelTask = {
			spec,
			run,
			degraded: existing ? existing.degraded : [],
			activity: existing ? existing.activity : [],
			obsSeq: new Map(),
			exitedSeen: new Set(),
			commitChain: existing ? existing.commitChain : Promise.resolve(),
		};
		this.tasks.set(taskId, fresh);
		void this.enqueueCommit(fresh, null, run, { spec }).then((r) => {
			if (!r.ok) this.degrade(taskId, `seed-commit:${r.error.code}`);
		});
		return fresh;
	}

	/** 桥 create：内核 register（+ 非 queued 记录补 grant-start）。 */
	private bridgeRegister(rec: TaskRecord, startQueued: boolean): void {
		const spec = bridgeSpec({
			taskId: rec.taskId,
			agent: rec.agent,
			assignment: rec.goal || `bridge:${rec.taskId}`,
			model: rec.model,
			cwd: rec.cwd,
			parentTaskId: rec.parentTaskId,
		});
		void this.execute(
			{ type: "register", spec, ...(rec.runId !== undefined ? { groupId: rec.runId } : {}), ...(rec.nodeId !== undefined ? { nodeId: rec.nodeId } : {}) },
			EXEC_BRIDGE,
		);
		if (!startQueued) {
			const kt = this.tasks.get(rec.taskId);
			if (kt) {
				void this.execute(
					{ type: "grant-start", key: this.keyOf(kt), backend: rec.backend ?? "json", launchIntent: { nonce: `bridge-${randomUUID()}`, at: this.clock() } },
					EXEC_BRIDGE,
				);
			}
		}
	}

	/** 桥 patch：状态变化映射内核命令（映射不到的走桥过渡）；字段（含 revision 显式置值）走受控白名单写入；
	 *  每写一次内核 CAS；记录投影一次性应用（legacy 副作用保真：blockedAt 首次定格、终态 endedAt/child 清理）。 */
	private bridgePatch(taskId: string, patch: Partial<TaskRecord>): Readonly<TaskRecord> | undefined {
		if (!this.proj || !this.proj.raw(taskId)) return undefined;
		this.ensureAdopted(taskId);
		const status = patch.status;
		if (status !== undefined) {
			const kt = this.tasks.get(taskId)!;
			const cmd = this.mapLegacyStatusCommand(kt, status, patch);
			if (cmd) {
				const r = this.execute(cmd, EXEC_BRIDGE) as Result<TaskView>;
				if (!r.ok) {
					// 防御回退：内核命令语义拒绝时退回桥过渡（legacy 语义优先——桥义务是零破坏），标 degraded 供 K4-K8 拆除审计；
					// diting-M1-Minor③加固：强制迁移前复核三轴一致性（settlement/acceptance 保持不变的前提下，
					// 目标 execution 与现状的三元组必须合法——不合法则拒绝，不以 legacyException 之名绕过状态机）。
					const triple = validateStateTriple({ execution: status, settlement: kt.run.settlement, acceptance: kt.run.acceptance, hasReceipt: kt.receipt !== undefined });
					if (!triple.ok) {
						this.degrade(taskId, `bridge-fallback-triple:${triple.error.code}`);
						return undefined;
					}
					this.degrade(taskId, `bridge-fallback:${r.error.code}:${r.error.message.slice(0, 80)}`);
					this.bridgeTransitionSync(taskId, status, { legacyException: true });
				}
			} else {
				// legacy-only 迁移（running→blocked/truncated、queued→error、truncated→done 证据升级）：
				// 无对应内核命令——桥专用受控迁移（仍走内核 CAS；truncated→done 为 v1 例外，K7 改回执面后拆除）
				this.bridgeTransitionSync(taskId, status, { legacyException: status === "done" });
			}
		} else {
			// 字段-only 受控白名单写入（registry 侧 PATCHABLE 已校验；sessionId/revision 同步进 run）
			this.bridgeFieldWriteSync(taskId, patch);
		}
		// 记录投影（一次性；legacy 副作用保真）——revision 以内核为权威（cancel/resolve-external 命令恒 +1，v2 语义）
		this.projMutate(taskId, (rec) => {
			Object.assign(rec, patch);
			if (status === "blocked" && rec.blockedAt === undefined) rec.blockedAt = Date.now();
			if (status !== undefined && terminalExecution(status)) {
				if (!rec.endedAt) rec.endedAt = Date.now();
				rec.child = undefined;
			}
			const cur = this.tasks.get(taskId);
			if (cur) rec.revision = cur.run.revision;
		});
		if (status !== undefined && terminalExecution(status)) this.fireSettle(taskId);
		return this.freezeRecord(taskId);
	}

	private freezeRecord(taskId: string): Readonly<TaskRecord> | undefined {
		const raw = this.proj ? this.proj.raw(taskId) : undefined;
		return raw ? freezeDto(raw) : undefined;
	}

	/** legacy 状态迁移 → 内核命令映射（null = 桥过渡承接）。 */
	private mapLegacyStatusCommand(kt: KernelTask, to: string, patch: Partial<TaskRecord>): KernelCommand | null {
		const from = kt.run.execution;
		const key = this.keyOf(kt);
		const now = this.clock();
		if (to === "running" && from === "queued") {
			return { type: "grant-start", key, backend: kt.run.backend, launchIntent: { nonce: `bridge-${randomUUID()}`, at: now } };
		}
		if (to === "cancelled") {
			return { type: "cancel", key, reason: String(patch.errorMessage || patch.stopReason || "bridge: legacy cancel") };
		}
		if (to === "resolved-external") {
			return { type: "resolve-external", key, reason: String(patch.resolveNote || "bridge: legacy resolve-external") };
		}
		if (from === "blocked" && to === "answering") {
			return { type: "begin-resume", key, lease: { holder: "amagi-bridge", nonce: "bridge", at: now } };
		}
		if (from === "answering" && to === "answered") {
			return { type: "finish-resume", key, outcome: "answered", reason: "bridge: legacy answered" };
		}
		if (from === "answering" && to === "blocked") {
			return { type: "finish-resume", key, outcome: "blocked", reason: "bridge: resume 启动失败回 blocked" };
		}
		if (from === "running" && to === "done") {
			// ev-20261019-06c169：JSON 后端的物理退出事实由真实 spawn/close 观察回流（preserve），
			// 桥不再合成假 exit 0/1（未 spawn 的失败路径会伪造退出事实）；业务终态走受控迁移。
			if (kt.run.backend === "json") return null;
			return { type: "observe", key, backendRunId: "bridge", observationSeq: this.nextBridgeSeq(kt, "bridge"), event: { kind: "exited", exitCode: 0, at: now } };
		}
		if (from === "running" && to === "error") {
			if (kt.run.backend === "json") return null; // 同上：JSON 不合成假退出（RPC 缺省映射保持）
			return { type: "observe", key, backendRunId: "bridge", observationSeq: this.nextBridgeSeq(kt, "bridge"), event: { kind: "exited", exitCode: 1, at: now } };
		}
		return null;
	}

	private nextBridgeSeq(kt: KernelTask, backendRunId: string): number {
		return (kt.obsSeq.get(backendRunId) ?? -1) + 1;
	}

	/** @deprecated 桥专用受控迁移（非十命令面）：legacy-only 迁移经此；校验 v2 表（legacyException 按 v1 表放行）。 */
	private bridgeTransitionSync(taskId: string, to: ExecutionState, opts: { legacyException?: boolean }): Result<true> {
		const kt = this.tasks.get(taskId);
		if (!kt) return err(KERNEL_ERROR_CODES.TASK_NOT_FOUND, `桥迁移失败：内核无任务 ${taskId}`, ["taskId"]);
		if (!opts.legacyException) {
			const t = validateExecutionTransition(kt.run.execution, to);
			if (!t.ok) return err(t.error.code, t.error.message, t.error.fields, t.error.effects, t.error.repairExamples);
		}
		const next = this.bump(kt, { execution: to });
		kt.run = next;
		void this.enqueueCommit(kt, next.stateSeq - 1, next).then((r) => {
			if (!r.ok) this.degrade(taskId, `store-commit:${r.error.code}`);
		});
		return ok(true);
	}

	/** @deprecated 桥专用受控字段写入：PATCHABLE 字段进记录；sessionId/revision 同步 run；stateSeq+1 一次 CAS。
	 *  diting-M1-Minor④加固：revision 显式置值仅允许单调递增（对齐 v2b/registry 既有「外部推进」测试语义）——
	 *  降级写入（回拨栅栏）拒绝，防止以旧 revision 重新采纳已取消结果。 */
	private bridgeFieldWriteSync(taskId: string, patch: Partial<TaskRecord>): void {
		const kt = this.tasks.get(taskId);
		if (!kt) return;
		const over: Partial<TaskRun> = {};
		if (typeof patch.sessionId === "string") over.sessionId = patch.sessionId;
		if (typeof patch.revision === "number") {
			if (patch.revision < kt.run.revision) {
				this.degrade(taskId, `bridge-revision-downgrade-blocked:${patch.revision}<${kt.run.revision}`);
				patch = { ...patch, revision: undefined };
			} else {
				over.revision = patch.revision;
			}
		}
		const next = this.bump(kt, over);
		kt.run = next;
		void this.enqueueCommit(kt, next.stateSeq - 1, next).then((r) => {
			if (!r.ok) this.degrade(taskId, `store-commit:${r.error.code}`);
		});
	}

	/** task-service 控制面接线：cancel/resolve-external 命令 + legacy 记录语义保真。 */
	private bridgeControl(
		taskId: string,
		kind: "cancel" | "resolve-external",
		note: string,
		extraRecord: (rec: TaskRecord, run: TaskRun) => void,
	): { ok: boolean; message: string } {
		const kt = this.ensureAdopted(taskId);
		const cmd: KernelCommand = kind === "cancel"
			? { type: "cancel", key: this.keyOf(kt), reason: note }
			: { type: "resolve-external", key: this.keyOf(kt), reason: note };
		const r = this.execute(cmd, EXEC_BRIDGE) as Result<TaskView>;
		if (!r.ok) return { ok: false, message: r.error.message };
		const after = this.tasks.get(taskId)!;
		this.projMutate(taskId, (rec) => {
			rec.status = after.run.execution;
			rec.revision = after.run.revision;
			extraRecord(rec, after.run);
			if (!rec.endedAt) rec.endedAt = Date.now();
			rec.child = undefined;
		});
		this.fireSettle(taskId);
		return { ok: true, message: "" };
	}

	// ── 恢复种子（reconcile 前置；K8a 全量恢复复用） ─────────────────────────

	private seedFromStore(spec: TaskSpec, run: TaskRun, receipt?: TaskReceipt): KernelTask {
		const kt: KernelTask = {
			spec,
			run,
			...(receipt !== undefined ? { receipt } : {}),
			degraded: [],
			activity: [],
			obsSeq: new Map(),
			exitedSeen: new Set(),
			commitChain: Promise.resolve(),
		};
		this.tasks.set(run.taskId, kt);
		return kt;
	}
}

/** 创建任务内核：apply/get + 视图订阅；attachRegistry 安装迁移桥（@deprecated K4-K8 拆除）。 */
export function createTaskKernel(deps: TaskKernelDeps): TaskKernelRuntime {
	return new TaskKernelImpl(deps);
}
