/**
 * finalizer.ts — 统一终态收尾链（v2 批次B；K7 回执面改造，方案 §3.2/§3.4 N7/N8/§3.5）。
 *
 * 背景（v2 分析 §6）：此前终态收尾分散在五处以上手工装配（execute sync/resume sync/
 * 两个 background onComplete/降档路径 + orchestrate 分支 + input-router 硬路由），
 * 各自拼装 artifact 落盘 → 大输出折叠 → 证据采集，顺序与缺省不一（硬路由甚至不落 artifact），
 * 且没有任何幂等/stale 防护——晚期回流（取消后的 close、旧 revision 的迟到结果）会
 * 覆盖新状态写 artifact，产生"取消的任务又写出产物"的观测污染。
 *
 * 本模块是唯一收尾入口，链序固定：
 *   幂等去重（owner/task/revision 复合键，命中先核对 current）→ stale revision 检查
 *   → artifact 落盘 + artifactRefs 收编（任务终稿原样）
 *   → 证据采集（evidence 门控：编码角色+完成态+trust；结构化事实一次采集双用）
 *   → 产物摘要块 → 候选回执 publish（K7：evidence await 后先查后交，revision 栅栏）
 *
 * V3（方案 §7/§8.5-V3）：候选回执的证据采集升级为 V2 结构化检查（runStructuredCheck——
 * checks 绑真实验证对象 objectId + 策略 policyDigest）；settlement 判定改用 deriveSettlementFace
 * （required failed→failed；对象不可建立/检查 unavailable 等非确定绿→incomplete；不再用文本推导）。
 * 结构化检查来源：① evidence.checkSpecs 注入（受信冻结面，测试/上层接线）；② 生产自动探测
 * （编码角色完成态 + trusted + 未注入 gatherReport/evidenceText → detectTestCommand → auto-baseline
 * 单检查，在 V1 验证对象上真实执行）；③ gatherReport 注入链保持 K7 迁移口径（合成 objectId/policyDigest，
 * 从 report.test 结构化状态推导——展示文本永不被解析）。缺机器检查任务（非编码角色）走产物完整性
 * （inspectArtifactIntegrity 经 deriveSettlementFace）+ 人工验收条件（冻结 spec verification.criteria）
 * 两面——不伪造机器检查。展示链经 runCmd shim 复用结构化检查执行事实（同一检查不双跑）。
 *
 * 契约：
 *  - 同 (owner, taskId, revision) 恰好生效一次；重复调用返回缓存结果并标 duplicate（不重复写
 *    artifact/证据/回执）。缓存命中先核对 current——取消/新 revision 后旧缓存不得回放
 *    （K7 验收 1：stale-duplicate，零写副作用，正文回退为本次输入原文）。
 *  - expectedRevision 与 registry.revision 不一致 → stale：跳过全部写副作用（调用方仍可用
 *    返回的 body 做展示——展示不等于落盘）。
 *  - K7 候选回执：契约任务（内核持有）终稿（done/error/truncated）经内核 publish-receipt 提交；
 *    settlement 只由结构化事实推导（N7——checks 全 passed 且无 missing→ready；任一 required
 *    failed→failed；证据缺失/不可用/truncated→incomplete），acceptance 恒 unreviewed（N8：
 *    子进程 DONE 标记不能 decide）。evidence await 窗口内取消的任务不发布回执（提交前复核
 *    current revision；内核栅栏兜底竞态）。store 写回执失败 → 不伪 ready（degraded 如实标注）。
 *  - K7（方案 §3.4）：truncated 文本推导升级 done 的采纳规则已删除——截断默认 incomplete，
 *    不凭测试绿升级 execution；显式人工验收走 decide(reject 之外的 accept+waive)。
 *  - 永不抛错（收尾不阻断主流程；内部各步独立容错，与既有 persistArtifact/appendEvidence 语义一致）。
 */

import { createHash, randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { SUBMIT_BASELINE_POLICY } from "./baseline-policy.ts";
import { inspectLocalDependencyRoots, resolveCommandEntry } from "./verification-dependencies.ts";
import { resolveExecutionEnv } from "./shell-env.ts";
import { resolveObjectMode } from "./verification-object.ts";
import { registry } from "./task-registry.ts";
import { peekTaskKernel } from "./task-service.ts";
// B0-3（附录 B.2）：重复全套观测——子进程工具执行观测统计（observeChildSuiteRuns）与观测行落盘。
import { observeChildSuiteRuns, type ToolExecutionObservation } from "./task-jsonl.ts";
import { writeObservation } from "./trace.ts";
import { tuiWarn } from "./tui-console.ts";
import { writeArtifact, writeEvidenceClassification, writeAutomaticEvidence, contractStoreRoot, sanitizeId, type ArtifactPaths } from "./artifact.ts";
import { compactAutomaticText, renderEvidenceContext, rememberArchivedCollection } from "./evidence-context.ts";
import { resolveEvidenceTimeouts, resolveEvidenceView, readProjectEvidenceTimeouts } from "./evidence-options.ts";
import { collectArtifactDiffSummary, gatherEvidenceReport, shouldGatherEvidence, producesProjectCodeOf, runStructuredCheck, deriveSettlementFace, detectTestCommand, newCheckId, renderAdvisoryEvidenceNote, type ArtifactIntegrityItem, type CheckId, type CmdResult, type EvidenceClassificationSnapshot, type EvidenceReport, type RunCmd, type StructuredCheckOutcome, type StructuredCheckSpec, type StructuredTestRef } from "./evidence.ts";
import { asCheckSpecId } from "./contracts/evidence.ts";
import type { ResolvedEvidenceTimeouts } from "./evidence-options.ts";
// B8（设计 §5.5）：基线验证长跑的保温窗口标记（cache-warming 决策器消费；sync 路径在
// streaming 相位恒 delegate，后台 onComplete 路径的 idle 相位是真实价值窗口）。
import { beginCacheWarmingLease, endCacheWarmingLease } from "./cache-warming.ts";
// C15（设计 §6.5）：进程内 advisory 通道——机器检查结果的模型解释（默认关闭；纯展示注记，
// 不参与 settlement/acceptance；真实命令执行/冻结验证对象/结果归档仍走原机制，不取证此通道）。
import { buildCheckFactsSummary, loadInProcessAdvisoryConfig, runInProcessAdvisory, type AdvisoryModelCaller, type InProcessAdvisoryConfig } from "./in-process-advisory.ts";
import { clearTaskWrites, clearTaskStartState } from "./task-write-log.ts";
// b6f343（ev-20261019-b6f343）：终稿/声明产物轻量内容 lint → 回执 advisory checks（required:false，
// 不参与 settlement 判定；可 waive）——报告陈述此前是结算面盲区（夸大/危险回退表述无提示进入 ready 回执）。
import { lintReportBundle, reportLintFindingsToChecks, gitWriteForbiddenInAssignment } from "./report-lint.ts";
// B10（ev-20261008-eb1e27，主上裁定①+②）：写面感知基线选择与兄弟切片干扰豁免的判定输入构造。
import { baselineRunnerSupport, prepareBaselineScope, scopeGuardOf, selectBaselineSubset } from "./baseline-scope.ts";
import type { BaselineScopeGuard } from "./evidence.ts";
import type { CheckResult, CheckStatus } from "./contracts/evidence.ts";
import type { OutputRef, ReceiptSettlement, TaskReceipt } from "./contracts/task.ts";

export interface FinalizeTerminalOpts {
	taskId: string;
	agent: string;
	/** 终态结果载体（RunResult 或 onComplete 回调参数；字段取并集语义）。 */
	result: {
		runtimeObservation?: import("./runtime-fingerprint.ts").RuntimeObservation;
		output?: string; errorMessage?: string; status: string; blocked: boolean;
		/** diting Major-4：blocked 结构化原因，随 artifact metadata 持久化（磁盘回填不丢 handoff 语义）。 */
		blockReason?: "questions" | "needs-handoff";
		sessionId?: string; model?: string;
		/** ev-20260914：角色类型（fast/work/expert，runTask 侧赋值）——折叠 marker 豁免仅对
		 *  契约适用角色（编码类 work/expert）生效；fast 型不校验 marker 不应享受豁免。缺省按适用
		 *  处理（保守兼容旧调用方，如 rpc 池的 RpcRunResult 无此字段）。 */
		agentType?: string;
		/** Sync auto-verifier already ran the final baseline and diff; reuse instead of spawning them again. */
		evidenceText?: string;
		evidenceReport?: EvidenceReport;
		/** ev-20260924-0cf0e7：sync auto-verifier 交接的结构化检查事实（runBaselineVerification →
		 *  runStructuredCheck 产物，绑验证对象 objectId + copy-local 依赖冻结）。finalizer 直接收编为
		 *  唯一执行事实（不重跑）；有交接时 autoDetect 门关闭——检查确实跑过了，不再是文本遮挡。 */
		structuredChecks?: ReadonlyArray<StructuredCheckOutcome>;
		/** B0-3（附录 B.2）：本次逻辑运行的工具执行观测（各轮汇总；缺省=无法关联→观测行记 unknown）。 */
		_toolExecutions?: ReadonlyArray<ToolExecutionObservation>;
		/** B0-1（附录 B.1）：本次真实子运行标识（观测行与 trace 行关联键；缺省=unknown）。 */
		runKey?: string;
	};
	cwd: string;
	/** 证据采集门控（evidence.ts 契约：gatherEv 缺省走 DEFAULT_CODE_AGENTS 判定；trusted 门 git 采集）。
	 * ev-20260903-64641c：deps.taskId 透传三档归因（gatherReport/appendEvidence 归因行 + 产物摘要块）；
	 * 顶层 taskId 缺省即不透传（旧注入源兼容）。
	 * S5/23f4a4（方案 §5.3）：timeouts = S2 在派发侧解析冻结后的证据超时预算（task > env > 默认；
	 * 缺省时证据链内部走 env 链回旧三常量——旧调用零变化）。
	 * V3（§7/§8.5）：checkSpecs = 结构化检查规格供给（受信冻结面——模型不能注入任意结算 shell
	 * 命令；测试/上层注入真实规格，finalizer 对每项规格调 runStructuredCheck 在验证对象上执行）。
	 * 数组或 (cwd) 供给；缺省走自动探测（编码角色完成态 + trusted 且未注入 gatherReport/evidenceText
	 * → 项目测试命令）。 */
	evidence?: { gatherEv?: (cwd: string) => Promise<string>; gatherReport?: (cwd: string, deps?: { trusted?: boolean; structuredTest?: StructuredTestRef; baselinePorcelain?: string[] | null; taskId?: string; timeouts?: ResolvedEvidenceTimeouts; sharedTree?: boolean }) => Promise<EvidenceReport>; trusted?: boolean; baselinePorcelain?: string[] | null; timeouts?: ResolvedEvidenceTimeouts; checkSpecs?: readonly StructuredCheckSpec[] | ((cwd: string) => readonly StructuredCheckSpec[] | null); sharedTree?: boolean };
	/** stale 判定基线：派发时刻的 registry.revision。不提供则不检查（兼容旧调用方）。 */
	expectedRevision?: number;
	/** C15（设计 §6.5）：进程内 advisory 钩子（默认关闭；index.ts 接线注入 HostStreamAdapter）。
	 *  调用层由调用方注入（mock/host-stream）；配置缺省读盘（amagi.json inProcessAdvisory 节），
	 *  enabled=false 时零调用零构造开销。触发面：机器检查结果产出后（outcomes/structured），
	 *  回执已按机器事实发布——advisory 仅解释，永不改变 settlement/acceptance（三轴零影响）。 */
	advisory?: {
		caller: AdvisoryModelCaller;
		/** 配置注入（测试；缺省 loadInProcessAdvisoryConfig(cwd)）。 */
		config?: InProcessAdvisoryConfig;
		/** 外部取消信号。 */
		signal?: AbortSignal;
	};
}

/** K7：候选回执发布结果（FinalizeTerminalResult.receipt；非契约任务/守卫跳过=unpublished）。 */
export interface FinalizeReceiptOutcome {
	/** true = 已经内核 publish-receipt 提交（saveReceipt+current CAS 均成功）。 */
	published: boolean;
	/** 已发布回执的 receiptId（仅 published=true 时携带；B0-3 观测行关联用）。 */
	receiptId?: string;
	/** 候选回执推导的结算态（发布成功或 store 写失败时的候选值；跳过时省略）。 */
	settlement?: ReceiptSettlement;
	/** K7 验收 6：store 写回执失败——不伪 ready（内核已回滚为未发布态），此处 degraded 如实标注。 */
	degraded?: boolean;
	/** 未发布原因（no-kernel/not-contract-task/execution=…/already-published/内核错误码）。 */
	reason?: string;
}

export interface FinalizeTerminalResult {
	/** true = 本次调用真实执行了收尾链（非 duplicate、非 stale）。 */
	ok: boolean;
	/** true = revision 不匹配（晚期回流）；body 仍可用（展示语义），但无任何写副作用。 */
	stale: boolean;
	/** true = 同 (owner, taskId, revision) 重复调用；body/artifact 取自首次生效结果。 */
	duplicate: boolean;
	/** 折叠 + 证据后的展示正文（stale 时为未折叠原文，供调用方展示）。 */
	body: string;
	artifact: ArtifactPaths | null;
	/** 仅 harness 收尾阶段在原始终稿之后新增的内容；折叠子任务正文时仍必须交付这些新事实。 */
	finalizationContext?: string;
	/** B1（Wave B）：产物摘要块文本（done/error 采集；非 git 仓库/失败/不适用为 null）。
	 *  已拼入 body；独立字段供 group 节点通知（envelope display）复用，避免重复采集。 */
	artifactSummary?: string | null;
	/** 已归档的自动采集展示块（含详情路径），供 DAG 通知复用同一投影。 */
	automaticEvidence?: string | null;
	/** S5/01ef8c（方案 §5.4）：结构化完整分类结果（随任务证据已落盘 artifact 目录；
	 *  无基线/非 git/artifact 关闭 → null——full 明确不可用，不臆造）。 */
	classification?: EvidenceClassificationSnapshot | null;
	/** K7：候选回执发布结果（契约任务 done/error/truncated 终稿时经内核提交）。 */
	receipt?: FinalizeReceiptOutcome;
}

const MAX_FINALIZED_CACHE = 256;
const finalized = new Map<string, FinalizeTerminalResult>();
const inFlight = new Map<string, Promise<FinalizeTerminalResult>>();

/** K7：自动基线检查 id（evidence 链探测的项目测试命令；required——failed 即确定失败）。 */
const AUTO_CHECK_ID = "auto-baseline-test";
/** §3.4：truncated 默认 incomplete 的缺口注记 id（显式 accept 须 waive 此项）。 */
const TRUNCATION_GAP_ID = "truncation-coverage";
/** V3 §3.4：error 执行态结算缺口注记 id（执行错误终态不凭检查绿判 ready；显式 accept 须 waive）。 */
const ERROR_EXEC_GAP_ID = "error-execution-coverage";

/** 测试隔离用复位。 */
export function resetFinalizerForTest(): void {
	finalized.clear();
	inFlight.clear();
}

/** K7 验收 1：缓存键 = owner|task|revision（现仅 taskId 的问题：取消/新 revision 后旧缓存会被
 *  同 taskId 的迟到调用回放）。owner 取内核视图 ownerId（无内核=legacy 任务，不发布回执）。 */
function cacheKeyOf(taskId: string, owner: string, revision: number): string {
	return `${owner}|${taskId}|${revision}`;
}

function cacheFinalized(key: string, result: FinalizeTerminalResult): void {
	finalized.delete(key);
	finalized.set(key, result);
	if (finalized.size <= MAX_FINALIZED_CACHE) return;
	const oldest = finalized.keys().next().value;
	if (typeof oldest === "string") finalized.delete(oldest);
}

/** 当前权威态（内核优先；无内核/未持有回退 registry 只读投影）。 */
function currentOf(taskId: string): { revision: number; execution: string } | undefined {
	const view = peekTaskKernel()?.get(taskId);
	if (view) return { revision: view.revision, execution: view.execution };
	const rec = registry.get(taskId);
	if (rec) return { revision: rec.revision ?? 0, execution: rec.status };
	return undefined;
}

/** evidence 链测试状态 → 契约 CheckStatus（N7：passed 须有时间+exitCode=0 退出事实，由采集窗口补齐）。
 *  v2.3 C1：unavailable 新档——隔离快照创建失败且 strict 不回退时如实标注（回执 incomplete，不猜成功）。 */
function checkStatusOfEvidenceTest(status: EvidenceReport["test"]["status"]): CheckStatus {
	switch (status) {
		case "passed": return "passed";
		case "failed": return "failed";
		case "timed-out": return "timed-out";
		case "error": return "error";
		case "skipped": return "unavailable"; // trust gate 跳过：环境不可用，非未探测
		case "unavailable": return "unavailable"; // v2.3 C1：快照创建失败（strict 不回退）：环境不可建立
		default: return "not-run"; // missing：未探测到测试命令
	}
}

/** store 类失败（必要写失败→degraded/incomplete，不伪 ready）；内核栅栏/状态拒绝为良性跳过。 */
function isStoreFailureCode(code: string): boolean {
	return code === "kernel-store-failure" || code.startsWith("store-") || code === "cas-conflict";
}

/** artifact result.md → 契约 OutputRef（K7 验收 7：回执面携带产物引用；registry.artifactRefs 保留为兼容展示投影）。 */
function artifactOutputRef(ap: ArtifactPaths): OutputRef | null {
	try {
		const buf = fs.readFileSync(ap.resultPath);
		return {
			path: `${ap.relDir}/result.md`,
			digest: createHash("sha256").update(buf).digest("hex"),
			bytes: buf.byteLength,
			sourcePath: ap.resultPath,
			kind: "file",
		};
	} catch {
		return null;
	}
}

/** 证据采集窗口捕获的结构化测试事实（startedAt/endedAt 为真实采集窗口，N7 时间事实）。 */
interface StructuredCheckFact {
	test: EvidenceReport["test"];
	startedAt: number;
	endedAt: number;
	/** v2.3 C1：证据链 degraded 注记（如隔离快照回退共享树）→ 回执 degraded[]（不改变 settlement 判定）。 */
	degraded?: readonly string[];
}

// ── V3：结构化检查供给与展示链单一事实源（§7.2/§8.5-V3） ──────────────────────

/** V3：只读读回冻结 spec 的验证策略（K5a 冻结面落盘 spec-<specId>.json；TaskSpecSummary 投影未携带
 *  verification——协同点：投影补字段后可省此磁盘读）。读失败 → undefined（对象策略走 V2 缺省、
 *  人工验收条件缺席如实记缺口，不曰造）。C2-a：同步读回 dependencyMode（旧 spec 缺字段 = none）。
 *  validateVerificationPolicy 已在冻结时封闭枚举——此处再窄校验，非法值不注入（fail-closed）。 */
function frozenVerificationOf(taskId: string, specId: string):
	{ objectMode: "snapshot" | "shared-tree"; allowSharedFallback: boolean; dependencyMode?: "none" | "copy-local"; criteria: readonly string[] } | undefined {
	try {
		const specPath = path.join(contractStoreRoot(), sanitizeId(taskId), `spec-${sanitizeId(specId)}.json`);
		const v = (JSON.parse(fs.readFileSync(specPath, "utf8")) as { verification?: unknown }).verification;
		if (!v || typeof v !== "object") return undefined;
		const rec = v as { objectMode?: unknown; allowSharedFallback?: unknown; dependencyMode?: unknown; criteria?: unknown };
		if (rec.objectMode !== "snapshot" && rec.objectMode !== "shared-tree") return undefined;
		if (typeof rec.allowSharedFallback !== "boolean") return undefined;
		const dependencyMode = rec.dependencyMode === "copy-local" ? "copy-local" : rec.dependencyMode === "none" ? "none" : undefined;
		const criteria = Array.isArray(rec.criteria) ? rec.criteria.filter((c): c is string => typeof c === "string" && c.trim() !== "") : [];
		return { objectMode: rec.objectMode, allowSharedFallback: rec.allowSharedFallback, ...(dependencyMode ? { dependencyMode } : {}), criteria };
	} catch {
		return undefined;
	}
}

/** b6f343（ev-20261019-b6f343）：冻结 spec 的 workspace.mode 只读读回（existing=共享树——
 *  回退指令 lint 门控输入；TaskSpecSummary 投影不携带 workspace，与 frozenVerificationOf 同一
 *  磁盘口径）。读失败/非法 → undefined（门控退化为仅任务书文本判定，不阻断）。 */
function frozenWorkspaceModeOf(taskId: string, specId: string): "existing" | "worktree" | undefined {
	try {
		const specPath = path.join(contractStoreRoot(), sanitizeId(taskId), `spec-${sanitizeId(specId)}.json`);
		const w = (JSON.parse(fs.readFileSync(specPath, "utf8")) as { workspace?: { mode?: unknown } }).workspace;
		return w && (w.mode === "existing" || w.mode === "worktree") ? w.mode : undefined;
	} catch { /* lint-exempt:spec 不可读→模式未知，门控退化为任务书文本判定，advisory 不影响结算 */ return undefined; }
}

/** V3：解析本轮结构化检查规格。注入（checkSpecs）优先；生产自动探测仅限编码角色完成态 +
 *  trusted（不可信项目不自动执行其测试命令——与 gatherEvidenceReport trust gate 同语义）且
 *  未注入 gatherReport（K7 迁移面不升级）/无 evidenceText（sync auto-verifier 已跑过，不双跑）。
 *  探测不到命令 → null（回执侧走 K7 迁移口径或如实记缺口）。
 *  C1（ev-20260922-7d1b10）：规格唯一数据源改为 detected.plan——execCwd 用 cwdRel（相对，根为
 *  "." 不填，**不再把绝对 detected.execCwd 填入规格**——旧形状被 structuredSpecProblem 拒绝为
 *  error 的事故根因）；bin 链落入 binDirsRel（进 policyDigest）。探测级 unavailable（根声明
 *  test 但 bin 不可达/歧义）→ 不产出必败 spec，返回 null——展示链 gatherReport 给出准确
 *  unavailable（回执迁移口径 objectRef），不静默降格。 */
export function resolveCheckSpecs(
	cwd: string,
	ev: FinalizeTerminalOpts["evidence"],
	autoDetect: boolean,
	frozenPolicy?: { objectMode: "snapshot" | "shared-tree"; allowSharedFallback: boolean; dependencyMode?: "none" | "copy-local" },
	/** B10：任务 id（自动探测路径的写面感知选择与豁免守卫输入；注入面/无任务 → 行为不变）。 */
	taskId?: string,
	detectedInput?: ReturnType<typeof detectTestCommand>,
): { specs: readonly StructuredCheckSpec[] | null; guard: BaselineScopeGuard | null; bestEffort: boolean } {
	const withPolicy = (spec: StructuredCheckSpec): StructuredCheckSpec =>
		spec.policy || !frozenPolicy ? spec : { ...spec, policy: frozenPolicy };
	const injected = ev?.checkSpecs;
	if (injected !== undefined) {
		const specs = typeof injected === "function" ? injected(cwd) : injected;
		// steer #4：ev.checkSpecs 注入面是调用方显式规格——不设 bestEffort（required 语义恒尊重）。
		return { specs: specs && specs.length > 0 ? specs.map(withPolicy) : null, guard: null, bestEffort: false };
	}
	if (!autoDetect) return { specs: null, guard: null, bestEffort: false };
	const detected = detectedInput === undefined ? detectTestCommand(cwd) : detectedInput;
	const plan = detected?.plan;
	if (!plan) return { specs: null, guard: null, bestEffort: false };
	// B10（ev-20261008-eb1e27）①：写面感知子集选择——own 写面（冻结 spec 声明面 + 写面登记 +
	// 声明面内 fresh 变更）推导相关测试集；子集成立时以 node --test 直跑替换全量 argv（argv 进
	// policyDigest——子集是真实执行语义）；回退全量保守并携带 basis 披露（不做默认全仓冗余执行）。
	// ②：守卫供 runStructuredCheck 判兄弟切片干扰豁免（写面为空 → 无守卫不豁免）。
	let selection: { mode: "subset" | "full"; basis: string; argv?: string[]; responsibleTests?: string[] } | null = null;
	let guard: BaselineScopeGuard | null = null;
	if (taskId) {
		try {
			const view = peekTaskKernel()?.get(taskId);
			const prepared = prepareBaselineScope(cwd, taskId, {
				...(view ? { specId: view.spec.specId } : {}),
				...(ev?.baselinePorcelain !== undefined ? { baselinePorcelain: ev.baselinePorcelain } : {}),
			});
			// ev-20261021-54b4e3：项目声明入口是权威执行面——不以 node --test 直跑子集替换（子集会绕过
			// 声明的 guarded 串行入口与资源环境）。责任测试推导与执行 argv 分离（diting F-02）：仍按写面
			// 推导 own 责任测试集交给守卫——丢失它会让 own 源码导致、定位落在 sibling 测试文件的失败被
			// 误豁免为 sibling-interference；只替换执行面，豁免面语义与探测路径一致。
			const derived = selectBaselineSubset(cwd, plan, prepared);
			selection = plan.source === "amagi.json"
				? {
					mode: "full",
					basis: "项目声明入口（amagi.json verification.testCommand）为权威执行面——不构造 node --test 子集（子集会绕过声明的 guarded 入口与资源环境）",
					...(derived.responsibleTests ? { responsibleTests: [...derived.responsibleTests] } : {}),
				}
				: derived;
			guard = scopeGuardOf(prepared, selection);
		} catch { /* lint-exempt:B10-探测失败不阻断基线检查——回退全量原行为，豁免面自然缺席 */ }
	}
	// steer #4（ev-20261101-bcee0f 终版）：自动 spec **恒 required=true**——不在预检改写规格语义；
	// 尽力基线降级改由 runStructuredCheck 内部通道 bestEffortMissingExecutable 承担（仅执行时
	// 精确入口工具不可定位的 unavailable 分支把该条结果降 required=false，其余一律保留）。
	// bestEffort 仅自动探测入口（非 amagi.json 声明）设置；显式声明/注入面恒 false。
	const finalArgv = selection?.mode === "subset" && selection.argv ? [...selection.argv] : [...plan.argv];
	const bestEffort = detected.source !== "amagi.json";
	return { specs: [withPolicy({
		// D1：AUTO_CHECK_ID 仅为检查规格名（CheckSpecId 配置面）；回执引用面用 newCheckId 分配的完整记录 id。
		id: asCheckSpecId(AUTO_CHECK_ID),
		required: true,
		argv: finalArgv,
		...(selection ? { selection: { basis: selection.basis } } : {}),
		...(plan.cwdRel !== "." ? { execCwd: plan.cwdRel } : {}),
		...(plan.binDirsRel.length > 0 ? { binDirsRel: [...plan.binDirsRel] } : {}),
		...(detected.env ? { env: { ...detected.env } } : {}),
		entry: { source: plan.source, label: detected.label },
		// ev-20261011-ad4513（diting F-01）：无冻结超时值时项目层（<cwd>/amagi.json evidenceTimeouts）
		// 参与预算（task > env > project > 默认）——结构化检查是唯一执行事实入口，规格缺
		// timeoutMs 会让 runStructuredCheck 落回硬 120s，项目声明到不了实际执行。
		...(ev?.timeouts !== undefined
			? { timeoutMs: ev.timeouts.testMs }
			: { timeoutMs: resolveEvidenceTimeouts(undefined, process.env, readProjectEvidenceTimeouts(cwd)).testMs }),
	})], guard, bestEffort };
}

/** Read-only projection of the same baseline specification used by final settlement.
 * This is not a check result: capture, dependency availability and the final
 * write-surface subset can only be determined after the task runs. */
export function describeBaselinePreflight(cwd: string, trusted: boolean): string {
	if (!trusted) return "[验证预检] 项目未受信：自动基线不会执行项目测试；先确认项目可信性。任务状态与检查仍以回执为准。";
	const detected = detectTestCommand(cwd);
	const { specs } = resolveCheckSpecs(cwd, undefined, true, SUBMIT_BASELINE_POLICY, undefined, detected);
	const mode = resolveObjectMode(SUBMIT_BASELINE_POLICY);
	const policyLine = `验证策略: objectMode=${SUBMIT_BASELINE_POLICY.objectMode}，dependencyMode=${SUBMIT_BASELINE_POLICY.dependencyMode}，allowSharedFallback=${SUBMIT_BASELINE_POLICY.allowSharedFallback}；当前有效对象模式=${mode.ok ? mode.mode : "不可用"}。`;
	const planned = specs?.[0];
	// ev-20261101-cbf452：区分根目录与计划执行目录的 Node 清单；缺根清单不代表无依赖。
	// 非 Node 工具链/锁文件依赖仍待实际核验，不能用 executable 已定位冒充依赖完备。
	const nodeManifest = [cwd, path.resolve(cwd, planned?.execCwd ?? ".")]
		.some(dir => fs.existsSync(path.join(dir, "package.json")));
	const roots = mode.ok && mode.mode === "snapshot" ? inspectLocalDependencyRoots(cwd, planned ? { execCwd: planned.execCwd ?? ".", binDirsRel: planned.binDirsRel ?? [] } : undefined).state : "unknown";
	const dependencyLine = roots === "missing"
		? nodeManifest
			? "依赖根: 已知缺口：工作区未发现 node_modules 捕获根；copy-local 不安装依赖。若锁文件与依赖型入口触发终态门控，将以 no-capture-root unavailable（Go 离线缓存另判）；无依赖入口不必然不可执行。请在已有授权内准备本地依赖，或核对项目验证策略；不自动安装。"
			: "依赖根: 根目录及执行目录未发现 Node 清单；其他工具链缓存、锁文件与构建依赖完整性尚未核验（unknown），仍以实际检查为准；入口定位不代表依赖完整。"
		: roots === "missing-plan-root" ? "依赖根: 已知缺口：检查计划所需 node_modules 根缺失（missing-plan-root）；在已有授权内恢复该本地依赖，其他根不能替代，不自动安装。"
		: roots === "present" ? "依赖根: 已发现本地捕获根；捕获完整性和期间漂移仍为 unknown。" : "依赖根: 不适用或读取失败，状态 unknown。";
	const project = readProjectEvidenceTimeouts(cwd);
	const budget = resolveEvidenceTimeouts(undefined, undefined, project.testMs === undefined ? undefined : { testMs: project.testMs });
	const budgetLine = `测试预算: ${budget.testMs}ms（来源=${budget.source}${budget.envWarning ? `；${budget.envWarning}` : ""}）；预算是否足够须实际执行才能确定。`;
	const boundary = "捕获、依赖冻结、runner 运行时与任务完成后的写面子集：未验证（unknown）；是否执行还取决于任务结果与实际代码产物。预检不产生检查事实，不改变 required/missing。";
	if (!specs?.length || !detected?.plan) {
		const budgetExample = JSON.stringify({ evidenceTimeouts: { testMs: budget.testMs } });
		return `[验证预检] 入口不可用：${detected?.unavailableReason ?? "未探测到测试入口"}。\n${policyLine}\n${dependencyLine}\n${budgetLine}\n项目预算配置片段（当前值，不保证足够）：${budgetExample}；请在项目 amagi.json 的 verification.testCommand.argv 声明项目实际测试入口，或修复上述 runner 缺口；未知入口不猜命令，先核对运行环境，不自动扩权。\n${boundary}`;
	}
	const spec = specs[0]!;
	// ev-20261101-bcee0f：预检用与执行同一解析器（resolveCommandEntry：locateToolToken 候选含
	// 自动发现的用户级工具目录）真实核验入口可定位性——不再假称「已解析」；不可定位时预告终态
	//（unavailable 环境缺口）并给出可复制的 shell.pathPrepend 声明片段。预检无 spawn、无副作用。
	const probeEnv = resolveExecutionEnv({ configRoot: cwd, execDir: spec.execCwd ? path.resolve(cwd, spec.execCwd) : cwd, binDirs: spec.binDirsRel?.map((rel) => path.resolve(cwd, rel)) ?? [] });
	const probe = resolveCommandEntry(spec.argv, { cwd: probeEnv.execDir, binDirs: probeEnv.binDirs, pathPrepend: probeEnv.prependDirs });
	const entryVerifyLine = probe.realPath !== null
		? `入口核验：✓ ${probe.toolToken} 已定位（${probe.realPath}${probeEnv.discoveredDirs.some((d) => probe.realPath!.startsWith(`${path.resolve(d)}${path.sep}`)) ? "；经用户级工具目录自动发现" : ""}）——预检与执行共用同一解析器。`
		: probe.unlocatable
			? `入口核验：✗ ${probe.toolToken} 不可定位（shell.pathPrepend/系统 PATH/常见用户级目录${probeEnv.discoveredDirs.length > 0 ? `（已探测：${probeEnv.discoveredDirs.join(":")}` : ""}均未命中可执行文件）——检查将以 unavailable（环境缺口，非测试失败）如实记录${detected.source === "amagi.json" ? "（声明入口保持 required，accept 需 waive 留痕）" : "（自动探测基线仅此工具缺口时不阻断结算、无需豁免；对象/依赖等其他缺口仍保留）"}；可在项目 amagi.json 声明（可复制片段：${JSON.stringify({ shell: { pathPrepend: ["<工具所在目录>"] } })}）或安装工具（自动发现覆盖 ~/.local/bin、~/Library/Python/*/bin、Homebrew、CMake.app 等常见用户级目录）。`
			: `入口核验：⚠ ${probe.toolToken} 身份不可证明（${probe.problem ?? "未知"}）——将真实执行并如实记录，复用面 fail-closed。`;
	const runner = detected.plan.source === "amagi.json"
		? "项目声明入口保持完整执行，不以子集替换"
		: baselineRunnerSupport(cwd, detected.plan).directNodeTest
			? "node --test 直跑形态支持按写面尝试子集（最终仍可能保守全量）"
			: nodeManifest
				? "非 node --test 直跑/无 scripts.test，不安全构造子集，保守全量"
				: "非 Node 测试形态（无 node --test/scripts.test 子集推导面），保守全量";
	const example = JSON.stringify({ evidenceTimeouts: { testMs: budget.testMs } });
	const entryNote = detected.source === "amagi.json"
		? "入口已在项目声明；保留已有 argv、cwd 和 env。"
		: detected.plan.binDirsRel.length > 0
			? `入口由项目探测，当前 binDirs=[${detected.plan.binDirsRel.join(", ")}]；声明入口会改变 bin 路径与写面子集策略，须先核对 PATH/依赖，不自动生成可能失效的声明。`
			: `如需固定已探测入口（声明后执行完整入口，不再构造写面子集），核实后可合并：${JSON.stringify({ verification: { testCommand: { argv: spec.argv, ...(spec.execCwd ? { cwd: spec.execCwd } : {}) } } })}；运行环境与预算仍需核实。`;
	const envLine = spec.env && Object.keys(spec.env).length ? "资源环境: 项目已声明 verification.testCommand.env（不展示值）；其余宿主资源环境不继承。" : "资源环境: 未声明；宿主 NODE_OPTIONS 等资源环境不继承，使用 runner/Node 默认。";
	// ev-20261101-bcee0f（steer）：首行措辞与核验结果一致——不可定位时不再假称「已解析入口」。
	const headLine = probe.unlocatable
		? `[验证预检] 入口计划已探测但工具不可定位：${spec.argv.join(" ")}；cwd=${spec.execCwd ?? "."}；来源=${detected.source}；runner解析=${detected.plan.resolution}。`
		: `[验证预检] 已解析入口（非通过）：${spec.argv.join(" ")}；cwd=${spec.execCwd ?? "."}；来源=${detected.source}；runner解析=${detected.plan.resolution}。`;
	return `${headLine}\n${entryVerifyLine}\n${policyLine}\n${dependencyLine}\n${envLine}\n写面 runner: ${runner}。\n${budgetLine}\n项目预算配置片段（当前值，核实后合并到 amagi.json；不自动写入）：${example}。${entryNote}\n${boundary}`;
}

/** ev-20260924-0cf0e7（P1）：自动基线验证唯一执行入口（验证执行权收归）。
 *  背景（22 份真实回执佐证）：此前 sync auto-verifier 走 gatherEvidenceReport 旧快照路径——它没有
 *  copy-local 依赖冻结，快照里找不到 node_modules/.bin/vitest 即被判 unavailable；其结果又以
 *  evidenceText 文本形式关掉 finalizer 的结构化检查路径，回执恒 not-run/no-object:no-structured-fact，
 *  accept 恒 waive。收归后：runStructuredCheck（含依赖冻结，冻结策略取 spec verification）是唯一
 *  执行事实；gatherEvidenceReport 只消费 structuredTestRefOf 的 checkId/logRef 引用渲染文本报告——
 *  同一检查不双跑，文本与结构化事实同源。修复轮每轮重新调用本函数：修复后对象已变，不序用旧对象。 */
export async function runBaselineVerification(
	cwd: string,
	taskId: string,
	opts: { timeouts?: ResolvedEvidenceTimeouts; trusted?: boolean } = {},
): Promise<{ report: EvidenceReport; outcomes: StructuredCheckOutcome[] }> {
	beginCacheWarmingLease(`verify:${taskId}`, "verify"); // B8：验证长跑开窗（幂等刷新）
	try {
		const trusted = opts.trusted ?? true;
		const outcomes: StructuredCheckOutcome[] = [];
		if (trusted) {
			const frozenPolicy = (() => {
				try {
					const v = peekTaskKernel()?.get(taskId);
					return v ? frozenVerificationOf(taskId, v.spec.specId) : undefined;
				} catch { return undefined; }
			})();
			const { specs, guard, bestEffort } = resolveCheckSpecs(cwd, { timeouts: opts.timeouts }, true, frozenPolicy, taskId);
			if (specs) {
				for (const spec of specs) {
					// steer #4：仅自动探测入口设置尽力基线内部通道（声明/注入面恒 false，见 resolveCheckSpecs）。
					try { outcomes.push(await runStructuredCheck(cwd, spec, { ...(guard ? { scopeGuard: guard } : {}), ...(bestEffort ? { bestEffortMissingExecutable: true } : {}) })); } catch { /* lint-exempt:fail-closed——单项检查异常不阻断验证，缺事实如实进回执 */ }
				}
			}
		}
		const structuredTest = structuredTestRefOf(outcomes, cwd);
		const report = await gatherEvidenceReport(cwd, { trusted, ...(structuredTest ? { structuredTest } : {}) }, { taskId, timeouts: opts.timeouts });
		return { report, outcomes };
	} finally {
		endCacheWarmingLease(`verify:${taskId}`); // B8：验证窗口收口（幂等）
	}
}

/** V3：结构化检查事实 → 展示链 CmdResult（单一事实源：展示文本复用检查执行输出，同一检查不双跑）。
 *  无时间窗（未执行/无采集窗口）→ null。退出事实：exitCode 存在则原样；timed-out 且无退出码
 *  （SIGTERM 后 code=null）时如实重构 code=null+timedOut=true——不伪造退出码，保留 timeout
 *  与断言失败/exit 非零的区分（formatTestLine 按此渲染预算与阶段文案）。stdout/stderr 取自
 *  检查日志归档（captureRoot 保留供复核 §7.1.5）；日志不可读时降级为空输出——退出码/状态事实仍在。 */
function cmdResultOfOutcome(o: StructuredCheckOutcome): CmdResult | null {
	const c = o.check;
	if (c.startedAt === undefined || c.endedAt === undefined) return null;
	const timedOut = c.status === "timed-out";
	if (c.exitCode === undefined && !timedOut) return null;
	let stdout = "", stderr = "";
	if (c.log) {
		try {
			const raw = JSON.parse(fs.readFileSync(c.log.path, "utf8")) as { stdout?: unknown; stderr?: unknown };
			if (typeof raw.stdout === "string") stdout = raw.stdout;
			if (typeof raw.stderr === "string") stderr = raw.stderr;
		} catch { /* 日志不可读：展示降级为空输出 */ }
	}
	return { ok: c.status === "passed", stdout, stderr, code: c.exitCode ?? null, timedOut, durationMs: c.endedAt - c.startedAt };
}

/** C2-b（ev-20260921-89cc12，方案 §2.8）：结构化检查 → 展示链证据引用（唯一执行事实的单源
 *  转发——不是第二种 CheckResult）。{checkId, logRef} 只指向 harness 已保存记录：日志文件
 *  在场才携带 logRef；退出事实由 cmdResultOfOutcome 从检查日志渲染（日志不可读时降级空输出，
 *  退出码/状态事实仍在）。多检查时优先与探测到的测试命令 argv 一致的那条，否则取首条。 */
function structuredTestRefOf(outcomes: readonly StructuredCheckOutcome[], cwd: string): StructuredTestRef | undefined {
	if (outcomes.length === 0) return undefined;
	const detected = detectTestCommand(cwd);
	const pick = outcomes.find((o) =>
			detected?.cmd && o.check.argv.length === detected.cmd.length && o.check.argv.every((a, i) => a === detected.cmd[i])
			&& o.check.exitCode !== undefined)
		?? outcomes.find((o) => o.check.exitCode !== undefined)
		?? outcomes[0];
	const c = pick.check;
	const logRef = c.log && fs.existsSync(c.log.path) ? c.log : undefined;
	return {
		checkId: c.id,
		...(logRef ? { logRef } : {}),
		label: detected?.label ?? "检查",
		source: detected?.source ?? "structured",
		argv: [...c.argv],
		status: c.status,
		result: cmdResultOfOutcome(pick),
		...(pick.notes.length > 0 && c.status !== "passed" ? { problem: pick.notes.join("；").slice(0, 400) } : {}),
		...(detected?.plan?.coverage === "selected-package" ? { coverage: `仅 ${detected.plan.selectedPackage ?? detected.subdir} 子包；根与其余子包未跑。` } : {}),
		// B10（ev-20261008-eb1e27）：写面感知选择依据与豁免事实随引用透传（展示链披露，单一事实源）。
		...(pick.selection ? { selection: pick.selection.basis } : {}),
		...(c.exemption ? { exemption: c.exemption } : {}),
	};
}

/**
 * K7：候选回执发布（§3.5 结算数据流末段：固定候选产物 → 生成候选回执 → 内核复核 key/对象/策略
 * → 保存回执 → 提交 current 指针）。evidence await 之后调用——先查后交（重读内核 current），
 * await 窗口内取消/推进 revision 的任务不发布回执（内核 revision 栅栏兜底竞态）。
 */
/** ev-20260930-c6c316 §④：advisory 证据事实（结算面只读投影——checks 与 face.artifacts 原样
 *  转发，供 C15 in-process advisory 消费；不写新字段进 TaskReceipt/TaskSpec，不进 settlement/acceptance）。 */
interface ReceiptAdvisoryFacts {
	checks: readonly CheckResult[];
	artifacts: readonly ArtifactIntegrityItem[];
}
async function publishCandidateReceipt(args: {
	taskId: string;
	cwd: string;
	ap: ArtifactPaths | null;
	/** K7 迁移口径事实（gatherReport 注入链）：report.test 结构化状态 → 合成 objectId/policyDigest。 */
	structured: StructuredCheckFact | null;
	/** V3：本轮真实结构化检查产物（runStructuredCheck——checks 绑真实验证对象/策略）。 */
	outcomes: readonly StructuredCheckOutcome[];
	/** 编码角色完成态（evidence 门控命中）——机器检查应跑；未产出结构化事实 = 证据缺失。 */
	evidenceApplicable: boolean;
	/** b6f343：终稿原文（lint 扫描面；报告陈述内容首次进入结算检查层——advisory，不阻断）。 */
	reportText: string;
}): Promise<FinalizeReceiptOutcome & { advisoryFacts?: ReceiptAdvisoryFacts }> {
	const kernel = peekTaskKernel();
	if (!kernel) return { published: false, reason: "no-kernel" };
	// 先查后交：不持有 await 前的旧读取结果直接写（§3.5）。
	const view = kernel.get(args.taskId);
	if (!view) return { published: false, reason: "not-contract-task" };
	if (view.execution !== "done" && view.execution !== "error" && view.execution !== "truncated") {
		// blocked（待 resume 续接）不结算；cancelled/resolved-external（含 await 窗口内取消——
		// revision 已 +1，此处按 current 执行态拦下）不发布回执。
		return { published: false, reason: `execution=${view.execution}` };
	}
	if (view.receipt || view.settlement !== "pending") {
		return { published: false, reason: view.receipt ? "already-published" : `settlement=${view.settlement}` };
	}
	// 守卫后无当前回执（首发 receiptSeq=1；防御性保留表达式防未来守卫放宽）
	const priorSeq: number = (view.receipt as { receiptSeq?: number } | undefined)?.receiptSeq ?? 0;

	// checks 由结构化事实推导（N7：回执校验器不解析展示文本推导结论）；acceptance 恒 unreviewed（N8）。
	// V3：优先真实结构化检查产物（绑验证对象 objectId/策略 policyDigest，§7.2 七字段齐全）；
	// 无 V3 产物时回退 K7 迁移口径（合成 objectId/policyDigest，从 report.test 结构化状态推导）；
	// 应跑而全无结构化事实 → 如实记缺口 → incomplete。
	const checks: CheckResult[] = [];
	const missing: string[] = [];
	if (args.evidenceApplicable) {
		if (args.outcomes.length > 0) {
			for (const o of args.outcomes) checks.push(o.check);
		} else if (args.structured) {
			const status = checkStatusOfEvidenceTest(args.structured.test.status);
			// D1（ev-20260922-c896f8）：迁移口径检查也分配完整记录 id（newCheckId）——AUTO_CHECK_ID
			// 仅为规格名；机器检查缺口引用该完整 id，不再 push 规格名或 `id:status` 拼接。
			const checkId = newCheckId(AUTO_CHECK_ID);
			checks.push({
				id: checkId,
				required: true,
				// C1（ev-20260922-7d1b10）：unavailable 时 objectRef 携带 no-object:<reason> 真实短码
				// （如 snapshot-bin-missing:<bin>）——与 D1 单一 id 口径协同；其余保持迁移口径合成 id。
				objectId: args.structured.test.objectRef ?? `evidence-baseline@${view.spec.specDigest.slice(0, 16)}`,
				// K7 迁移期口径：检查配置锚定冻结 spec 整体 digest（受信验证计划冻结检查面后由 V3 结构化检查替代）
				policyDigest: view.spec.specDigest,
				status,
				argv: args.structured.test.command ? [...args.structured.test.command] : [],
				cwd: args.cwd,
				startedAt: args.structured.startedAt,
				endedAt: args.structured.endedAt,
				// evidence 链 passed ⟺ 退出码 0（evidence.ts：r.ok ⟺ code===0 且未超时）
				...(status === "passed" ? { exitCode: 0 as const } : {}),
			});
			if (status !== "passed" && status !== "failed") missing.push(checkId);
		} else {
			// 应跑而未产出结构化事实（gatherEv 注入只回文本 / 采集异常 / 探测不到测试命令——
			// ev-20260924-0cf0e7 后 sync auto-verifier 必交接 outcomes，此分支只留给确实没人跑过检查的情形）：
			// 不解析文本推导结论（N7）；D1：先生成真实 not-run CheckResult（分配一次完整 id、标明
			// no-object:<reason>；不伪造执行时间/退出码）加入 checks，再引用该 id 记缺口 → incomplete。
			const checkId = newCheckId(AUTO_CHECK_ID);
			checks.push({
				id: checkId,
				required: true,
				objectId: "no-object:no-structured-fact",
				policyDigest: view.spec.specDigest,
				status: "not-run",
				argv: [],
				cwd: args.cwd,
			});
			missing.push(checkId);
		}
	}
	// b6f343（ev-20261019-b6f343）：终稿/声明产物轻量 lint → advisory checks（required:false——
	// deriveSettlementFace 只对 required 检查判 failed/missing，advisory 永不阻断 settlement；
	// id 携带 规则@来源:行号，回执渲染可见定位，Leader 可经 decide.waivedCheckIds 显式 waive。
	// 门控：共享树（workspace.mode=existing）或任务书显式禁 Git 写才扫回退指令；矛盾提示恒扫。
	// lint 异常 → advisory 缺席（不伪造通过，也不阻断收尾）。
	try {
		const workspaceMode = frozenWorkspaceModeOf(view.taskId, view.spec.specId);
		const lint = lintReportBundle({
			cwd: args.cwd,
			reportText: args.reportText,
			reportLabel: "final-report",
			declaredOutputs: view.spec.outputs.map((o) => o.path),
			rollbackLint: workspaceMode === "existing" || gitWriteForbiddenInAssignment(view.spec.assignment),
		});
		checks.push(...reportLintFindingsToChecks(lint, args.cwd));
	} catch { /* lint-exempt:advisory 缺席——lint 异常不阻断结算，也不伪造通过 */ }
	// V3：settlement 判定改用 V2 deriveSettlementFace（准确投影：required failed→failed；对象不可建立
	// /检查 unavailable 等非确定绿→缺口→incomplete；全 passed 无缺口→ready）。执行轴缺口按 §3.4 注记：
	// truncated 默认 incomplete（显式人工验收须 waive 截断未覆盖项；required failed 时不另注截断缺口）；
	// error 执行态不凭检查绿判 ready。缺机器检查任务（非编码角色/无 checks）走产物完整性 + 人工验收
	// 条件两面（§7 头段）：归档 artifact 产物逐项核查 + 冻结 spec verification.criteria 供人裁决。
	const requiredFailed = checks.some((c) => c.required && c.status === "failed");
	if (view.execution === "truncated" && !requiredFailed) missing.push(TRUNCATION_GAP_ID);
	if (view.execution === "error") missing.push(ERROR_EXEC_GAP_ID);
	const frozen = frozenVerificationOf(view.taskId, view.spec.specId);
	// ev-20260920-61839b：声明契约结算闭环——冻结 spec.outputs（required 项）并入产物完整性检查面。
	// 此前 declaredOutputs 只喂 resultPath（result-fold），outputs[] 声明从未进结算面：落位错位
	// 照样 ready，验收只能事后人工核。合并后：缺必需要求产物 → incomplete + artifact-integrity 缺口
	// （「执行结束，待结算」，accept 前可见）；可选声明不参与执法。保持「无任何声明 → 不传 declaredOutputs」
	// 语义（空数组与 undefined 在 deriveSettlementFace 语义不同——不能把未声明伪装成「声明为空」）。
	const declaredOutputPaths = view.spec.outputs.filter((o) => o.required).map((o) => o.path);
	const declaredOutputs = [...(args.ap ? [args.ap.resultPath] : []), ...declaredOutputPaths];
	const face = deriveSettlementFace({
		checks,
		missing,
		...(declaredOutputs.length > 0 ? { declaredOutputs, cwd: args.cwd } : {}),
		...(frozen ? { manualAcceptance: frozen.criteria } : {}),
	});
	const settlement: ReceiptSettlement = face.settlement;
	const receiptMissing = [...face.missing];

	const outRef = args.ap ? artifactOutputRef(args.ap) : null;
	const receipt: TaskReceipt = {
		version: 1,
		ownerId: view.ownerId,
		taskId: view.taskId,
		revision: view.revision,
		receiptId: `receipt-${randomUUID()}`,
		receiptSeq: priorSeq + 1,
		specDigest: view.spec.specDigest,
		outputs: outRef ? [outRef] : [],
		checks,
		settlement,
		missing: receiptMissing,
		acceptance: "unreviewed",
		executionObserved: view.execution,
		createdAt: Date.now(),
	};
	const applied = await kernel.apply({
		type: "publish-receipt",
		key: { ownerId: view.ownerId, taskId: view.taskId, revision: view.revision },
		receipt,
	});
	// §④：只读事实随发布结果带回（无论发布成败——候选面事实已真实采集）
	const advisoryFacts: ReceiptAdvisoryFacts = { checks, artifacts: face.artifacts };
	if (applied.ok) return { published: true, settlement, receiptId: receipt.receiptId, advisoryFacts };
	if (isStoreFailureCode(applied.error.code)) {
		// K7 验收 6：必要写失败——内核已回滚（无回执、settlement 回 pending，不伪 ready）；
		// 此处 degraded 如实标注（TaskView 级 degraded 标记需 task-kernel 扩展，只读上游——列协同点）。
		return { published: false, settlement, degraded: true, reason: applied.error.code, advisoryFacts };
	}
	// 内核栅栏/状态拒绝（await 窗口内取消→revision 栅栏、并发重复发布→receiptSeq 等）：迟到回执不发布（N3）。
	return { published: false, reason: applied.error.code, advisoryFacts };
}

async function performFinalize(opts: FinalizeTerminalOpts, cacheKey: string): Promise<FinalizeTerminalResult> {
	const { taskId, agent, result: r, cwd } = opts;
	const rec = registry.get(taskId);
	const stale = opts.expectedRevision !== undefined && (rec?.revision ?? 0) !== opts.expectedRevision;
	const raw = r.output || r.errorMessage || "";
	if (stale) {
		return { ok: false, stale: true, duplicate: false, body: raw, artifact: null, artifactSummary: null };
	}

	let ap: ArtifactPaths | null = null;
	try {
		ap = writeArtifact({
			runtimeObservation: r.runtimeObservation ?? rec?.runtimeObservation,
			taskId, agent, model: r.model, status: r.status, blocked: r.blocked, blockReason: r.blockReason,
			output: raw, sessionId: r.sessionId,
			startedAt: rec?.startedAt, endedAt: rec?.endedAt, rounds: rec?.rounds?.length, cwd,
			// P1-C（8.19）：上游 artifact 引用采自 registry create 时定格的派发契约快照
			// （任务文本 refs ∪ resume 直接父交接入口）；未被终态 output refs 合并污染，无 refs → 空数组。
			upstreamArtifactReferences: rec?.upstreamArtifactRefs ?? [],
		});
		// K7 验收 7：registry.artifactRefs 保留为兼容展示投影（group envelope/continuation 等消费面
		// 未切 TaskView 前 K8b/K8c 收口）；结构化产物引用已由候选回执 outputs[] 携带（新权威）。
		if (ap) registry.appendArtifactRef(taskId, ap.relDir);
	} catch {}

	// ── 证据步（K7 统一：truncated 与 done/error 共用同一采集口；结构化事实供回执推导）──
	let body = raw;
	let structured: StructuredCheckFact | null = null;
	let automaticReport: EvidenceReport | null = null;
	let automaticText = "";
	const ev = opts.evidence;
	const gatherReport = ev?.gatherReport
		?? ((c: string, d?: { trusted?: boolean; runCmd?: RunCmd; structuredTest?: StructuredTestRef; baselinePorcelain?: string[] | null; taskId?: string; timeouts?: ResolvedEvidenceTimeouts; sharedTree?: boolean }) =>
			gatherEvidenceReport(c, { trusted: d?.trusted, ...(d?.runCmd ? { runCmd: d.runCmd } : {}), ...(d?.structuredTest ? { structuredTest: d.structuredTest } : {}) }, { baselinePorcelain: d?.baselinePorcelain, taskId: d?.taskId, timeouts: d?.timeouts, sharedTree: d?.sharedTree }));
	// V3：结构化检查先行（回执面权威——checks 绑真实验证对象/策略，§7.2）。自动探测 gate：编码角色
	// 完成态 + trusted（不可信项目不自动执行其测试命令）+ 未注入 gatherReport（K7 迁移面不升级）。
	// ev-20260924-0cf0e7：门控从「无 evidenceText」改为「无交接 outcomes」——sync auto-verifier
	// 经 runBaselineVerification 产出结构化事实随 RunResult 交接，finalizer 直接收编（唯一执行事实，
	// 不重跑）；evidenceText 有无只管展示。无交接（测试注入 opts.verification 只回文本 / 采集异常 /
	// 探测不到命令）时 autoDetect 照旧生效。逐项 fail-closed：单项执行异常不阻断收尾，回执侧按缺失
	// 记缺口。对象策略取冻结 spec verification（受信配置优先；env 快照开关仍由 V1 判定面处理）。
	const outcomes: StructuredCheckOutcome[] = [];
	// v2 §7.1-B：代码基线判定输入——fresh 变更路径分类（当前 git status 减派发前快照；fuxi 按 D1
	// 裁决恒 false；无基线/非 git 保守 true，不能因任务声称文档跳过代码验收）。计算一次供全部门消费。
	const producesProjectCode = producesProjectCodeOf(agent, cwd, ev?.baselinePorcelain);
	try {
		const handedOver = Array.isArray(r.structuredChecks) ? r.structuredChecks : [];
		const autoDetect = !r.blocked && shouldGatherEvidence(agent, r.status, producesProjectCode) && (ev?.trusted ?? false) === true
			&& ev?.gatherReport === undefined && handedOver.length === 0;
		const frozenPolicy = (() => {
			try {
				const v = peekTaskKernel()?.get(taskId);
				return v ? frozenVerificationOf(taskId, v.spec.specId) : undefined;
			} catch { return undefined; }
		})();
		const { specs, guard, bestEffort } = resolveCheckSpecs(cwd, ev, autoDetect, frozenPolicy, taskId);
		if (specs) {
			for (const spec of specs) {
				// steer #4：仅自动探测入口设置尽力基线内部通道（声明/注入面恒 false，见 resolveCheckSpecs）。
				try { outcomes.push(await runStructuredCheck(cwd, spec, { ...(guard ? { scopeGuard: guard } : {}), ...(bestEffort ? { bestEffortMissingExecutable: true } : {}) })); } catch { /* lint-exempt:fail-closed——检查异常不阻断收尾 */ }
			}
		}
		// ev-20260924-0cf0e7：sync auto-verifier 交接的结构化检查事实（绑验证对象/依赖冻结）直接收编——
		// 同一基线不重跑（唯一执行事实；文本侧 evidenceText 仅展示）。顺序在注入 specs 之后：
		// 生产链二者不同时存在（交接时 autoDetect 关、注入面仅测试接线），共存时两者都是真实事实。
		outcomes.push(...handedOver);
	} catch { /* 探测异常不阻断收尾（回执侧记缺口） */ }
	// C2-b（ev-20260921-89cc12，方案 §2.8）：展示链单一事实源——有结构化检查时测试部分消费其
	// 执行事实（{checkId, logRef} 证据引用，同一检查不双跑；不同 cwd/策略/依赖 digest 不串用——
	// 旧 argv shim 已删）；git diff/归因等其余命令照常真实采集（独立口径）。
	const structuredTest = outcomes.length > 0 ? structuredTestRefOf(outcomes, cwd) : undefined;
	const gatherArgs = { trusted: ev?.trusted ?? false, baselinePorcelain: ev?.baselinePorcelain, taskId, timeouts: ev?.timeouts, sharedTree: ev?.sharedTree, ...(structuredTest ? { structuredTest } : {}) } as const;
	if (r.status === "truncated" && !r.blocked && shouldGatherEvidence(agent, r.status, producesProjectCode)) {
		// K7（方案 §3.4）：截断证据只作展示——「测试绿+文本检测到 diff → 升级 done」的文本推导
		// 采纳规则已删除（结算判定只认结构化事实）；truncated 默认 incomplete，终稿可 resume 续接。
		const t0 = Date.now();
		try {
			const report = await gatherReport(cwd, gatherArgs);
			automaticReport = report;
			automaticText = report.text;
			structured = { test: report.test, startedAt: t0, endedAt: Date.now(), degraded: report.degraded ?? [] };
		} catch { /* 证据失败不影响：保持 truncated，回执侧记缺口 */ }
	} else if (r.evidenceText && !r.blocked) {
		// sync auto-verifier 的文本报告复用展示（runBaselineVerification 渲染，与交接 outcomes 同源；
		// ev-20260924-0cf0e7 后不再作为“已跑过”的门控信号——结构化事实走 structuredChecks 交接）。
		automaticReport = r.evidenceReport ?? null;
		automaticText = r.evidenceText;
	} else if (shouldGatherEvidence(agent, r.status, producesProjectCode)) {
		if (ev?.gatherEv) {
			try {
				const text = await ev.gatherEv(cwd);
				if (text) automaticText = text;
			} catch { /* 注入采集失败不影响主回流 */ }
		} else {
			const t0 = Date.now();
			try {
				const report = await gatherReport(cwd, gatherArgs);
				automaticReport = report;
				automaticText = report.text;
				structured = { test: report.test, startedAt: t0, endedAt: Date.now(), degraded: report.degraded ?? [] };
			} catch { /* 证据失败不影响主回流；回执侧记缺口 */ }
		}
	}

	// B1（Wave B）产物摘要块：完成通知（done/error）尾部追加——派发 gitBaseline 与结束时 git status
	// 差集（有界）+ git diff --stat 尾部；非 git 仓库/采集失败静默省略（execFileSync + 限时）。
	// S5/01ef8c：同一采集产出结构化完整分类快照，随任务证据落盘 artifact 目录（classification.json），
	// query evidenceDetail=full 从它展开（结束后工作树改动不改变旧详情）；S5/23f4a4：summaryGitMs 预算透传。
	let artifactSummary: string | null = null;
	let artifactContext: string | null = null;
	let classification: EvidenceClassificationSnapshot | null = null;
	if ((r.status === "done" || r.status === "error" || r.status === "truncated") && !r.blocked) {
		try {
			const collected = collectArtifactDiffSummary(cwd, opts.evidence?.baselinePorcelain, taskId, { summaryGitMs: opts.evidence?.timeouts?.summaryGitMs, sharedTree: opts.evidence?.sharedTree });
			artifactSummary = collected.text;
			artifactContext = collected.contextText ?? null;
			classification = collected.classification;
		} catch { artifactSummary = null; classification = null; }
		if (classification && ap) writeEvidenceClassification(ap.dir, classification);
		// ev-20260903-64641c（P0）：证据链（appendEvidence/gatherReport 归因行 + 产物摘要块三档归因）
		// 全部消费完写入登记后清理登记文件。放收尾链末尾而非 appendEvidence 尾部——产物摘要块在
		// 其后还要读登记，提前清理会把命中误降级为外部嫌疑；blocked 不清理（resume 续跑继续累积，
		// 跨轮归因不失真）。清理失败静默（残留登记文件仅占临时空间，不影响正确性）。
		// ev-20260910-8fbe4e（C）：error 终态不清写入登记——保留供 resume 后归因与迟终态回推重建
		// 现场报告读取（task-run finalize 已先于本收尾链生成报告快照，登记是后续仍可追问的真相源）；
		// 注：跨 taskId 的 resume 终态不会回收旧 error 登记文件（新任务只清新 taskId 登记；单文件 ≤512 行有界，
		// 慢累积无正确性影响，TTL/GC 能力项沉淀于 evolution 待排期）。
		if (r.status !== "error") {
			try { clearTaskWrites(taskId); } catch { /* 静默 */ }
			// ev-20261019-a7519f：启动状态快照同点清理（done/truncated 清、error/blocked 留供 resume 归因；
			// 与写入登记同生命周期，GC 同口径回收）。
			try { clearTaskStartState(taskId); } catch { /* lint-exempt:清理幂等，残留由 GC 兜底 */ }
		}
	}
	// 上下文与归档分流：只处理 harness 附加的采集块，绝不扫描/改写子 Agent 原始终稿。
	// 先保存详情，失败/关闭时回退原文，避免留下无法追溯的截断摘要。
	const checkLines = outcomes.length > 1 ? outcomes.map((o) => `• 检查 ${o.check.id} → ${o.check.status}${o.notes.length ? `：${o.notes.join("；")}` : ""}${o.check.log ? `；日志 ${o.check.log.path}` : ""}`) : [];
	const fullAutomatic = [automaticText, artifactSummary, ...checkLines].filter(Boolean).join("\n\n");
	const archiveAutomatic = [automaticReport?.archiveText ?? automaticText, artifactSummary, ...checkLines].filter(Boolean).join("\n\n");
	const evidencePath = writeAutomaticEvidence(ap, archiveAutomatic);
	const useCompactCollection = !!evidencePath && resolveEvidenceView() === "compact";
	let automaticEvidence = fullAutomatic;
	if (useCompactCollection) {
		const gitContext = artifactContext ? compactAutomaticText(artifactContext, 1536, 8) : null;
		const checkNotes: string[] = [];
		if (outcomes.length > 1) {
			const counts = new Map<string, number>();
			for (const o of outcomes) counts.set(o.check.status, (counts.get(o.check.status) ?? 0) + 1);
			checkNotes.push(`• 全部检查 ${outcomes.length} 项：${[...counts].map(([s, n]) => `${s} ${n}`).join("，")}`);
			checkNotes.push(...outcomes.filter((o) => o.check.status !== "passed").slice(0, 2).map((o) => `  ${o.check.id} → ${o.check.status}`));
		}
		automaticEvidence = automaticReport?.context
			? renderEvidenceContext({ ...automaticReport.context, notes: [...checkNotes, ...automaticReport.context.notes] }, gitContext)
			: [compactAutomaticText(automaticText, 2000, 12), compactAutomaticText(checkNotes.join("\n"), 768, 4), gitContext ?? compactAutomaticText(artifactSummary ?? "", 1536, 8)].filter(Boolean).join("\n\n");
		const detailLine = `[采集详情] ${evidencePath}（按需 read；检查日志仍由回执引用）`;
		automaticEvidence = `${automaticEvidence}\n${detailLine}`;
		artifactSummary = gitContext ? `${gitContext}\n${detailLine}` : null;
	}
	const collectionStart = body.length + 2;
	if (automaticEvidence) body = `${body}\n\n${automaticEvidence}`;
	const collectionEnd = body.length;

	// ── K7 候选回执（evidence await 之后；提交前复核 revision 栅栏——先查后交）──
	const evidenceApplicable = !r.blocked && shouldGatherEvidence(agent, r.status, producesProjectCode);
	let receiptOutcome: FinalizeReceiptOutcome;
	let advisoryFacts: ReceiptAdvisoryFacts | undefined;
	try {
		const published = await publishCandidateReceipt({ taskId, cwd, ap, structured, outcomes, evidenceApplicable, reportText: raw });
		// §④：advisory 事实留本地消费，不随 FinalizeReceiptOutcome 外泄（契约面零污染）
		const { advisoryFacts: facts, ...outcome } = published;
		receiptOutcome = outcome;
		advisoryFacts = facts;
	} catch (e) {
		// 回执发布异常不反噬收尾链（内核态为准；此处如实标 degraded）
		receiptOutcome = { published: false, degraded: true, reason: `publish-error:${e instanceof Error ? e.message : String(e)}`.slice(0, 120) };
	}
	if (receiptOutcome.degraded) {
		body = `${body}\n\n[回执] 候选回执（${receiptOutcome.settlement ?? "incomplete"}）落盘失败（${receiptOutcome.reason}）——settlement 不伪 ready，任务视图保持未发布态（degraded），待对账修复后重发。`;
	}

	// ── B0-3（§9.2 / 附录 B.2）：重复全套观测行——结算后另行追加到 observations.ndjson ──
	// 不重排结算、不回写旧行；子运行 trace 可能早于父侧回归落盘，由 /amagi stats 按 taskId/runKey
	// 关联。harnessBaselineRan/verificationObjectId 只取真实结构化检查回执（无结构化事实=false，
	// 无法关联记 unknown，区别于 0）；观测写失败只报 bounded 诊断，不影响 settlement；
	// 未探测到测试命令的任务不写观测行（未调用到观察点不算「没有重复」）。
	try {
		const detected = detectTestCommand(cwd);
		if (detected) {
			const executions = Array.isArray(r._toolExecutions) ? r._toolExecutions : undefined;
			const obs = executions ? observeChildSuiteRuns([{ _toolExecutions: executions }], detected, cwd) : undefined;
			const executedChecks = outcomes.filter((o) => o.check.startedAt !== undefined);
			const written = writeObservation({
				formatVersion: 1,
				kind: "child-full-suite",
				taskId,
				runKey: typeof r.runKey === "string" && r.runKey ? r.runKey : "unknown",
				agent,
				...(receiptOutcome.receiptId !== undefined ? { receiptId: receiptOutcome.receiptId } : {}),
				command: detected.cmd.join(" ").slice(0, 200),
				cwd,
				childFullSuiteRuns: obs ? obs.fullSuiteRuns : "unknown",
				childCwdMismatchRuns: obs ? obs.cwdMismatchRuns : "unknown",
				childSuiteCandidate: obs ? obs.candidate : "unknown",
				harnessBaselineRan: executedChecks.length > 0,
				verificationObjectId: executedChecks[0]?.check.objectId ?? "unknown",
				at: Date.now(),
			});
			if (!written) tuiWarn(`[amagi-core/finalizer] 重复全套观测行写入失败（observations.ndjson 不可写）——任务 ${taskId.slice(0, 8)} 结算不受影响`);
		}
	} catch { /* lint-exempt:观测面绝不反噬结算链 */ }

	// ── C15（设计 §6.5）：进程内 advisory 解释（默认关闭；机器检查结果产出后可选触发）──
	// 纯展示注记（evidence.renderAdvisoryEvidenceNote 明示「非机器验证结论」）；unavailable 静默
	// 省略（主验证已照常按机器结果结算——回执在前；journal advisory 行已记录真实 stopReason/detail）。
	// 进幂等缓存 body，重复调用回放一致。有机器检查事实才触发（outcomes 或 K7 迁移口径 structured）。
	if (opts.advisory?.caller && !r.blocked && (r.status === "done" || r.status === "error" || r.status === "truncated")
		&& (outcomes.length > 0 || structured !== null)) {
		try {
			const advCfg = opts.advisory.config ?? loadInProcessAdvisoryConfig(cwd);
			if (advCfg.enabled) {
				const checkFacts = outcomes.length > 0
					? outcomes.map((o) => ({ id: o.check.id, status: o.check.status, required: o.check.required, ...(o.check.exitCode !== undefined ? { exitCode: o.check.exitCode } : {}) }))
					: [{ id: AUTO_CHECK_ID, status: checkStatusOfEvidenceTest(structured!.test.status), required: true, ...(structured!.test.status === "passed" ? { exitCode: 0 } : {}) }];
				const factsSummary = buildCheckFactsSummary({
					parentTaskId: taskId, agent, execution: r.status,
					settlement: receiptOutcome.settlement,
					checks: checkFacts,
					...(advisoryFacts ? { missing: advisoryFacts.checks.filter((c) => c.status !== "passed" && c.status !== "failed").map((c) => c.id) } : {}),
				});
				const advisoryOutcome = await runInProcessAdvisory(
					{ parentTaskId: taskId, factsSummary },
					{ caller: opts.advisory.caller, config: advCfg, ...(opts.advisory.signal ? { signal: opts.advisory.signal } : {}) },
				);
				if (advisoryOutcome.status === "ok" && advisoryOutcome.text) {
					body = `${body}\n\n${renderAdvisoryEvidenceNote({
						callerId: opts.advisory.caller.id, modelRef: advisoryOutcome.modelRef,
						promptVersion: advisoryOutcome.promptVersion, text: advisoryOutcome.text, usageStatus: advisoryOutcome.usageStatus,
					})}`;
				}
			}
		} catch { /* lint-exempt:advisory 失败静默省略（不阻断收尾链；journal 行已记录事实） */ }
	}

	// 每次生产替换当前登记；legacy/无归档也清除旧范围，历史仅消费已落盘的来源证明。
	rememberArchivedCollection(body, collectionStart, collectionEnd, useCompactCollection ? evidencePath ?? "" : "", taskId);
	const finalizationContext = [body.slice(raw.length).trim(), evidencePath && !useCompactCollection ? `[采集详情] ${evidencePath}` : ""].filter(Boolean).join("\n");
	const out: FinalizeTerminalResult = { ok: true, stale: false, duplicate: false, body, artifact: ap, finalizationContext, artifactSummary, automaticEvidence: automaticEvidence || null, classification, receipt: receiptOutcome };
	cacheFinalized(cacheKey, out);
	return out;
}

/**
 * 统一终态收尾。相同 (owner, taskId, revision) 的并发调用共享同一个 in-flight Promise，避免 await
 * evidence 窗口内重复写 artifact/回执；完成缓存为有界 LRU，防长驻 TUI 随任务数无限保留结果正文。
 */
export async function finalizeTerminal(opts: FinalizeTerminalOpts): Promise<FinalizeTerminalResult> {
	const view = peekTaskKernel()?.get(opts.taskId);
	const owner = view?.ownerId ?? "legacy";
	const keyRevision = opts.expectedRevision ?? view?.revision ?? registry.get(opts.taskId)?.revision ?? 0;
	const key = cacheKeyOf(opts.taskId, owner, keyRevision);

	const cached = finalized.get(key);
	if (cached) {
		// K7 验收 1：缓存命中先核对 current——取消/新 revision 后旧缓存不得回放
		// （stale-duplicate：零写副作用，正文回退本次输入原文供展示）。
		const cur = currentOf(opts.taskId);
		const raw = opts.result.output || opts.result.errorMessage || "";
		if (!cur || cur.revision !== keyRevision || cur.execution === "cancelled") {
			return { ok: false, stale: true, duplicate: true, body: raw, artifact: null, artifactSummary: null };
		}
		cacheFinalized(key, cached);
		return { ...cached, ok: false, duplicate: true };
	}
	const pending = inFlight.get(key);
	if (pending) {
		const result = await pending;
		return { ...result, ok: false, duplicate: true };
	}
	beginCacheWarmingLease(`verify:${opts.taskId}`, "verify"); // B8：收尾验证窗口开窗（performFinalize 的检查/证据 await 期）
	const operation = performFinalize(opts, key);
	inFlight.set(key, operation);
	try {
		return await operation;
	} finally {
		inFlight.delete(key);
		endCacheWarmingLease(`verify:${opts.taskId}`); // B8：收尾链 await 窗口收口（幂等；并发 duplicate 共享同一 operation）
	}
}
