/**
 * snapshot-guard.ts — 批量写盘快照守卫（对应 ev-20260830-2c709d）。
 *
 * 背景：多源（多个子 Agent / 多会话）共享同一工作区时常驻大量未提交改动；bash 工具执行
 * 高危批量写盘命令（go fmt / gofmt -w / git checkout -- / git restore / sed -i / cargo fmt /
 * rustfmt / black / prettier --write / eslint --fix / clang-format -i，含 xargs 携带上述工具）
 * 会把未提交内容原地覆盖，事后无任何恢复线索（战术手册 EP-BATCH-WRITE-SNAPSHOT-WHITELIST-20260830）。
 *
 * 修复口径（结构性）：bash 执行前对高危命令静默建立 git 快照锚点——`git stash create`
 * 生成悬空提交（dangling commit）：不改工作区、不动 untracked、不写 stash ref、不进
 * reflog，由 gc 自然回收（不是 `git stash push`，后者会清空工作区）。sha 以一行 JSONL 落
 * <数据目录>/snapshot-guard.jsonl（事故恢复线索，给人看）。
 *
 * 事故恢复：
 *   git stash apply <SHA>            —— 全量恢复锚点快照
 *   git checkout <SHA> -- <path>     —— 单文件恢复
 *
 * 约束（硬性）：
 *  - 零模型负担：完全静默——不向 bash 结果追加任何提示、不新增 prompt 内容、不要求模型配合。
 *  - 失败安全：任何异常（非 git 目录 / git 缺失 / 权限 / detached HEAD 等）静默吞掉，
 *    绝不阻断原命令执行、不改变原命令任何行为语义。
 *  - 关闭开关：AMAGI_BASH_SNAPSHOT_GUARD=0（或 false）。
 *  - 双运行时：守卫在 pi 宿主进程内执行（Windows 宿主即 Windows git），cwd 为宿主侧
 *    路径格式，与 bash 工具的 WSL 运行时无耦合（两侧 .git 同库，锚点互通）。
 */

import { execFile } from "node:child_process";
import * as fs from "node:fs";
import { amagiDataFile } from "./data-dir.ts";

/** 高危批量写盘命令特征（词边界精确匹配工具名；xargs 携带上述工具时工具名以词元出现在命令中，天然命中）。 */
export const BULK_WRITE_COMMAND_RE = new RegExp(
	[
		"\\bgo\\s+fmt\\b", // go fmt（Golang 官方批量格式化，写盘）
		"\\bgofmt\\b(?=[^\\n|;&]*\\s-w(?:\\s|$))", // gofmt -w（-l/-d 只读检查不命中；前瞻限定同一管道段）
		"\\bgit\\s+checkout\\s+(?:-{1,2}[\\w-]+\\s+)*(?:--(?:\\s|$)|\\.(?=\\s|$))", // 还原类：-- file / . / -- . / -f .；切分支不命中
		"\\bgit\\s+restore\\b", // git restore（还原工作区/暂存区）
		"\\bgit\\s+reset\\b(?=\\s+(?:-{1,2}[\\w-]+\\s+)*--hard(?:\\s|$))", // ev-20260916-18f0d5：git reset --hard（丢弃 tracked 工作区/index 改动；仅 --hard，soft/mixed 不动工作区）
		"\\bsed\\b(?=[^\\n|;&]*\\s(?:-i|--in-place)(?![\\w-]))", // sed -i（含 GNU -i.bak 附缀与 --in-place；-n/-E 只读不命中）
		"\\bcargo\\s+fmt\\b", // cargo fmt（默认写盘）
		"\\brustfmt\\b(?=\\s|$)", // rustfmt（默认写盘；限定独立词元防 black.md 类文件名误伤）
		"\\bblack\\b(?=\\s|$)", // black（Python 格式化，默认写盘；同上限定独立词元）
		"\\bprettier\\b(?=[^\\n|;&]*\\s(?:--write|-w)(?:\\s|$))", // prettier --write/-w（--check 只读不命中）
		"\\beslint\\b(?=[^\\n|;&]*\\s--fix(?!\\w|-))", // eslint --fix（--fix-dry-run 不命中）
		"\\bclang-format\\b(?=[^\\n|;&]*\\s-i(?:\\s|$))", // clang-format -i（原地写盘）
	].join("|"),
);

/** 纯函数：命令是否命中批量写盘特征（供 bash 前置守卫与测试直接断言）。 */
export function shouldSnapshotGuard(command: string): boolean {
	return BULK_WRITE_COMMAND_RE.test(command);
}

/** 节流键：跳过 VAR=env 前缀取前 3 个 token、限长 48——重试/循环脚本的同命令判定用。 */
function snapshotFrag(command: string): string {
	const tokens = command.trim().replace(/\s+/g, " ").split(" ").filter((t) => t && !/^[A-Za-z_][A-Za-z0-9_]*=/.test(t));
	const frag = tokens.slice(0, 3).join(" ");
	return (frag || command.trim()).slice(0, 48);
}

/** 同 cwd 同命令片段的重复快照窗口（ms）：防重试/循环脚本反复 spawn git。 */
const SNAPSHOT_THROTTLE_MS = 5000;

/** 模块级节流状态：cwd → 最近一次快照（命令片段 + sha + 时刻）。 */
const lastAnchorByCwd = new Map<string, { commandFrag: string; sha: string; at: number }>();

/** 清空节流状态（测试隔离用；生产路径无需调用）。 */
export function resetSnapshotGuardForTest(): void {
	lastAnchorByCwd.clear();
}

/** `git -C <cwd> stash create`：5s 超时；git 命令直接按名 spawn，解析失败（ENOENT）由调用侧吞掉。 */
function gitStashCreate(cwd: string): Promise<string> {
	return new Promise((resolve, reject) => {
		execFile("git", ["-C", cwd, "stash", "create"], { timeout: 5000, windowsHide: true }, (err, stdout) => {
			if (err) reject(err);
			else resolve(String(stdout));
		});
	});
}

/** 追加一行 JSONL 记录（写失败静默——快照悬空提交已在对象库中，记录只是恢复线索）。 */
function appendSnapshotRecord(record: { ts: string; cwd: string; command: string; sha: string }): void {
	try {
		fs.appendFileSync(amagiDataFile("snapshot-guard.jsonl"), `${JSON.stringify(record)}\n`, "utf8");
	} catch {
		// 容错：目录解析失败/写盘失败只损失线索，不影响快照本身与原命令
	}
}

/**
 * bash 前置快照守卫集成入口：高危批量写盘命令执行前静默建立 git 悬空提交锚点。
 * 任何异常静默吞掉（失败安全原则：守卫绝不能改变原命令的执行语义）；不返回任何内容。
 */
export async function maybeSnapshotAnchor(command: string, cwd: string): Promise<void> {
	try {
		const disable = process.env.AMAGI_BASH_SNAPSHOT_GUARD;
		if (disable === "0" || disable === "false") return;
		if (!shouldSnapshotGuard(command)) return; // 快路径：一次正则测试
		const frag = snapshotFrag(command);
		const prev = lastAnchorByCwd.get(cwd);
		if (prev && prev.commandFrag === frag && Date.now() - prev.at < SNAPSHOT_THROTTLE_MS) return;
		const stdout = await gitStashCreate(cwd);
		const sha = stdout.trim();
		lastAnchorByCwd.set(cwd, { commandFrag: frag, sha, at: Date.now() });
		if (!/^[0-9a-f]{40}$/.test(sha)) return; // stdout 为空 = 无未提交改动，静默返回
		appendSnapshotRecord({ ts: new Date().toISOString(), cwd, command: command.slice(0, 200), sha });
	} catch {
		// 失败安全：非 git 目录（exit 128）/ git 缺失（ENOENT）/ 权限 / 超时等任何异常，
		// 静默跳过——守卫对原命令零语义影响（ev-20260830-2c709d 硬性约束）。
	}
}
