/**
 * codex-computer-use.ts — codex_computer_use：经官方 Codex App Server 自有实例委托原生
 * Computer Use（非浏览器应用控制）的实验工具，子 Agent 需显式授权。
 *
 * 事实基线（2026-10-07 有界协议 spike，证据 D/app-server-evidence/probe/probe-run2-*）：
 * - 官方 `codex app-server --listen stdio://` 公开 JSON-RPC 实例可由外部客户端合法使用：
 *   initialize/initialized → thread/start（ephemeral+read-only+on-request）→ turn/start（一次）
 *   → 事件流（item/*、thread/tokenUsage/updated、turn/completed）→ turn/interrupt。
 * - 源 CU 许可以 `mcpServer/elicitation/request`（mode:"form"，serverName:"node_repl"，携带
 *   callId/x-codex-turn-metadata/riskLevel/tool_name/persist 选项）真实路由到客户端；decline 后
 *   工具调用被拒（"Computer Use was not approved to use …"），无 GUI 副作用，turn 正常完成。
 * - 实际 selected model 从 thread/start response 取（实测 gpt-6.1-sol），不读用户 config 找 model。
 *
 * 边界（任务书/正式方案 v1.3 §6.5/§7 + 原生阶段 full review NI-01～NI-12 修复批）：
 * - 新官方 Codex 实例的模型委托（额外 Codex 模型/usage/时延单列；price/cost 未由 source 提供
 *   → 恒标 unknown，不编造费率），不是复用运行中 Desktop、不是直接工具桥。
 * - 模型输入仅 app（bundle ID）/objective/expectedOutcome；不接受 command/code/env/threadId/
 *   _meta/approval 等覆盖；固定官方已安装 binary 与独立 argv；工作目录为本次自有空目录。
 * - elicitation 只支持已实证的空 object form（mode=form + properties:{} + required 空）；仅
 *   node_repl + _meta.tool_params.app 严格等于工具输入 + owned thread/current turn（nullable
 *   turn 按协议接受，但失效边界后不接受）；按当前策略人工转交或预授权自动接受，逐次披露；
 *   应答 _meta:null 不 persist。其它 mode/字段/URL/userVerification 一律 unsupported decline。
 * - 其它 exec/file/dynamic/auth 审批安全拒绝（decline 或协议 method-not-found），不自动授权源 shell。
 * - 生命周期（NI-03）：deadline/abort/turn 结束/serverRequest resolved/server exit/解析失败统一
 *   invalidate pending 源请求；accept 发送前按当前状态+截止重验；UI 对话框带 signal+timeout
 *   （SDK ExtensionUIDialogOptions 实际字段）；收尾 allSettled 有独立上界，不无限等。
 * - 取消（NI-02）：预取消零副作用（不 mkdtemp/spawn/turn）；每次有状态提交前检查取消；单一
 *   deadline 覆盖启动/模型/UI/媒体/收尾；source 不确定时不再发新 model turn；interrupt 快速独立。
 * - 效果判定（NI-01）：native 尝试/效果/源 turn 完成三轴分离；代码 regex、任意结果文本、
 *   toolSurface、tag 都不是效果证据；顶层 item.error 真实保留；caught "Error:" 文本按错误处理；
 *   deny 不覆写已有效果；只有 ≥2 个无错误无拒绝的 node_repl 调用（动作+再观察的结构性代理）
 *   才给 effects=observed；不能证明零动作即 unknown；effects=none 仅限从未派发。
 * - 关联校验（NI-05）：item/turn 通知须带 owned threadId（turn/completed 须匹配 owned turn.id）；
 *   同 thread 的 stale turn 不结算不污染；malformed/handler error 令证据不可信 → unknown +
 *   best-effort interrupt；终结后迟到事件不恢复结算/批准资格。
 * - 资源界限（NI-06）：编码图 20MiB 上限在 base64 分配前按字符串长度预检；pending 图数量/累计
 *   上限；stdout 帧长上限；媒体探测共用剩余预算，超支不消费；失败不重试 GUI。
 * - 健壮性（NI-04）：child/stdio/日志流 error 立即处理；UI reject 安全 decline；全部路径
 *   owned-only finally 收尾；延迟 kill 前检查自有 Child 生存（防 PID 组重用误杀）；承载进程不崩。
 * - 重入（NI-07）：executionMode=sequential + 模块级门 + 同临时目录内跨进程锁；曾接受且停止
 *   未确认（unconfirmed/证据不可信）时，新窗口须经真实用户确认；残锁不自动回收。
 * - 图片 bytes 不文本化：PNG 落盘 + 现有 decoder 探测 + imageReadCapability 三态指引导出；
 *   仅标准 inline data（不读 file:// URL 任意宿主文件）。
 */

import { spawn, type ChildProcess } from "node:child_process";
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { Type, type Static } from "typebox";
import { imageReadCapability } from "./guards.ts";
import { defaultHostImageDecoder, IMAGE_ADMITTED_OUTPUT_MIME, IMAGE_DECODE_LIMIT_BYTES, imageSignatureConsistent, type ImageDecoderLike, type ImageDecodeObservation } from "./image-decoder.ts";

export const CODEX_COMPUTER_USE_TOOL_NAME = "codex_computer_use";

/** 官方已安装 CLI（ChatGPT.app 随包 0.160.1；spike 实测口径）。 */
export const CODEX_COMPUTER_USE_BIN = "/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex";

/** 启用开关（装配层显式启用；禁用时 execute 拒绝调用，不只藏声明）。 */
export function codexComputerUseEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return env.AMAGI_CODEX_COMPUTER_USE === "1";
}

// ── 跨进程互斥门：同一 tmpdir 内用 O_EXCL 单在途锁协调 Leader 与子 Agent。
//    持锁进程死亡不证明 detached 源已停止；已有锁一律不自动回收，需人工确认源停止后恢复。
//    此门不约束目标应用边界，也不能协调使用不同临时目录的进程。──

/** 跨进程门目录（生产同机共享；测试用 deps.tmpRoot 隔离避免 npm test 并发互撞）。 */
function cuGateDir(tmpRoot?: string): string {
	return path.join(tmpRoot ?? os.tmpdir(), "amagi-codex-computer-use-gate");
}

export interface CuCrossProcessStopGate { app: string; threadId: string | null; turnId: string | null; reason: string; pid: number; at: number }

/** stopgate 读取三态：none=无门；gate=有效门；corrupt=文件存在但无法解析（保守 fail-closed：
 *  不得当作无门放行——调用方须按未知门处理：有 UI 时人工确认清理，无 UI 拒绝）。 */
export type CuStopGateRead = { status: "none" } | { status: "gate"; gate: CuCrossProcessStopGate } | { status: "corrupt"; raw: string };

interface LockHolder { pid: number | null; at: number | null; token: string | null }

function readLockHolder(lockPath: string): { holder: LockHolder | null; raw: string | null; mtimeMs: number | null } {
	try {
		const raw = fs.readFileSync(lockPath, "utf8").trim();
		try {
			const parsed = JSON.parse(raw) as { pid?: unknown; at?: unknown; token?: unknown };
			return { holder: { pid: typeof parsed.pid === "number" ? parsed.pid : null, at: typeof parsed.at === "number" ? parsed.at : null, token: typeof parsed.token === "string" ? parsed.token : null }, raw, mtimeMs: null };
		} catch { /* lint-exempt: 损坏锁按未知占用保守拒绝 */ return { holder: null, raw, mtimeMs: null }; }
	} catch { /* lint-exempt: 不可读锁按未知占用保守拒绝 */ return { holder: null, raw: null, mtimeMs: null }; }
}

/** 获取同临时目录内的跨进程单在途锁。已有锁不自动回收，避免遗孤及恢复竞态。 */
export function acquireCodexCuCrossProcessLock(deps: { tmpRoot?: string } = {}): { ok: true; release: () => void } | { ok: false; reason: string } {
	const dir = cuGateDir(deps.tmpRoot);
	const lockPath = path.join(dir, "lock");
	const myToken = createHash("sha256").update(`${process.pid}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 16);
	try {
		fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
		const fd = fs.openSync(lockPath, "wx", 0o600);
		try { fs.writeSync(fd, JSON.stringify({ pid: process.pid, at: Date.now(), token: myToken }) + "\n"); }
		finally { fs.closeSync(fd); }
	} catch (e) {
		if ((e as NodeJS.ErrnoException).code === "EEXIST") {
			const { holder } = readLockHolder(lockPath);
			return { ok: false, reason: `另一进程或未恢复的锁（${holder?.pid ? `pid ${holder.pid}` : "状态未知"}）持有 codex_computer_use 在途窗口；不自动回收，须人工确认源已停止后恢复` };
		}
		return { ok: false, reason: `跨进程锁不可用（${(e as NodeJS.ErrnoException).code ?? "unknown"}）；保守拒绝并检查锁目录` };
	}
	return { ok: true, release: () => {
		const { holder } = readLockHolder(lockPath);
		if (holder?.token !== myToken) return;
		try { fs.unlinkSync(lockPath); } catch { /* lint-exempt: 保留残锁，后续调用保守拒绝 */ }
	} };
}

export function writeCodexCuCrossProcessStopGate(state: CuCrossProcessStopGate, deps: { tmpRoot?: string } = {}): boolean {
	try {
		const dir = cuGateDir(deps.tmpRoot);
		fs.mkdirSync(dir, { recursive: true });
		fs.writeFileSync(path.join(dir, "stopgate.json"), JSON.stringify({ ...state, pid: process.pid, at: Date.now() }) + "\n");
		return true;
	} catch { /* lint-exempt: 写入失败时返回 false 并保留锁 */
		// 写入失败（tmpdir 满/权限等）：返回 false——调用方（execute）按 fail-closed 保持锁不释放，
		// 不得吞错当作已落盘（steer #10：门未写而锁已释 = 另一进程可直接开新窗口）。
		return false;
	}
}

export function readCodexCuCrossProcessStopGate(deps: { tmpRoot?: string } = {}): CuCrossProcessStopGate | null {
	const r = readCodexCuStopGateState(deps);
	return r.status === "gate" ? r.gate : null;
}

/** 三态读取（steer #4：损坏不得 fail-open 当无门）：none=无门；gate=有效门；corrupt=存在但
 *  无法解析（调用方须按未知门保守处理，不得当作无门放行）。 */
export function readCodexCuStopGateState(deps: { tmpRoot?: string } = {}): CuStopGateRead {
	const gatePath = path.join(cuGateDir(deps.tmpRoot), "stopgate.json");
	let raw: string;
	try { raw = fs.readFileSync(gatePath, "utf8"); }
	catch (e) {
		if ((e as NodeJS.ErrnoException).code === "ENOENT") return { status: "none" };
		return { status: "corrupt", raw: `读取失败: ${(e as NodeJS.ErrnoException).code ?? "unknown"}` };
	}
	const trimmed = raw.trim();
	if (!trimmed) return { status: "corrupt", raw: "(empty)" };
	try {
		const parsed = JSON.parse(trimmed) as Partial<CuCrossProcessStopGate>;
		if (typeof parsed.app !== "string" || typeof parsed.reason !== "string") return { status: "corrupt", raw: trimmed.slice(0, 200) };
		return { status: "gate", gate: { app: parsed.app, threadId: typeof parsed.threadId === "string" ? parsed.threadId : null, turnId: typeof parsed.turnId === "string" ? parsed.turnId : null, reason: parsed.reason, pid: typeof parsed.pid === "number" ? parsed.pid : 0, at: typeof parsed.at === "number" ? parsed.at : 0 } };
	} catch { /* lint-exempt: 无法解析按损坏拒绝 */ return { status: "corrupt", raw: trimmed.slice(0, 200) }; }
}

export function clearCodexCuCrossProcessStopGate(deps: { tmpRoot?: string } = {}): boolean {
	try { fs.unlinkSync(path.join(cuGateDir(deps.tmpRoot), "stopgate.json")); return true; }
	catch (e) { return (e as NodeJS.ErrnoException).code === "ENOENT"; }
}

// ── 协议形状（ts-rs public schema 0.160.1 的运行时子集）───────────────────────

/** McpServerElicitationRequestParams：turnId 可空（协议允许；按单一 owned source 关联）。 */
export interface SourceElicitationParams {
	threadId: string;
	turnId: string | null;
	serverName: string;
	mode: "form" | "openai/userVerification" | "openai/form" | "openaiForm" | "url" | (string & {});
	message?: string;
	title?: string;
	description?: string;
	challenge?: string;
	url?: string;
	elicitationId?: string;
	requestedSchema?: unknown;
	_meta?: unknown;
}

/** ServerRequest 判别（ServerRequest.ts 0.160.1 的 11 个方法 + 未知兜底）。 */
export type SourceServerRequest =
	| { kind: "elicitation"; id: number | string; params: SourceElicitationParams }
	| { kind: "exec-approval"; id: number | string }
	| { kind: "file-approval"; id: number | string }
	| { kind: "legacy-approval"; id: number | string; method: string }
	| { kind: "unsupported"; id: number | string; method: string };

/** 真实 elicitation 解析（对 Spike 捕获形状防御式收窄；解析失败交上层按 unsupported 拒绝）。 */
export function parseElicitationParams(raw: unknown): { ok: true; params: SourceElicitationParams } | { ok: false; reason: string } {
	if (typeof raw !== "object" || raw === null) return { ok: false, reason: "params-not-object" };
	const p = raw as Record<string, unknown>;
	if (typeof p.threadId !== "string" || p.threadId === "") return { ok: false, reason: "threadId-missing" };
	if (!("turnId" in p)) return { ok: false, reason: "turnId-missing" };
	if (p.turnId !== null && typeof p.turnId !== "string") return { ok: false, reason: "turnId-invalid" };
	if (typeof p.serverName !== "string" || p.serverName === "") return { ok: false, reason: "serverName-missing" };
	if (typeof p.mode !== "string" || p.mode === "") return { ok: false, reason: "mode-missing" };
	return { ok: true, params: p as unknown as SourceElicitationParams };
}

/** server→client 请求判别。 */
export function parseSourceServerRequest(msg: unknown): { kind: "request"; req: SourceServerRequest } | { kind: "other" } {
	const m = msg as { id?: unknown; method?: unknown; params?: unknown } | null;
	if (!m || typeof m !== "object" || m.id === undefined || typeof m.method !== "string") return { kind: "other" };
	const id = m.id as number | string;
	switch (m.method) {
		case "mcpServer/elicitation/request": {
			const parsed = parseElicitationParams(m.params);
			if (!parsed.ok) return { kind: "request", req: { kind: "unsupported", id, method: `${m.method}:${parsed.reason}` } };
			return { kind: "request", req: { kind: "elicitation", id, params: parsed.params } };
		}
		case "item/commandExecution/requestApproval":
			return { kind: "request", req: { kind: "exec-approval", id } };
		case "item/fileChange/requestApproval":
			return { kind: "request", req: { kind: "file-approval", id } };
		case "applyPatchApproval":
		case "execCommandApproval":
			return { kind: "request", req: { kind: "legacy-approval", id, method: m.method } };
		default:
			return { kind: "request", req: { kind: "unsupported", id, method: m.method } };
	}
}

/** elicitation 人工转交计划（NI 修复批收窄）：只支持已实证的空 object form。 */
export type ElicitationRelayPlan =
	| { kind: "confirm-empty"; message: string }
	| { kind: "unsupported"; reason: string; message: string };

/** 标准 shape：mode=form + 非空 message + {type:"object", properties:{}, required 空/缺省}。 */
export function planElicitationRelay(params: SourceElicitationParams): ElicitationRelayPlan {
	const message = typeof params.message === "string" ? params.message : "";
	const schema = params.requestedSchema as { type?: unknown; properties?: unknown; required?: unknown } | null;
	if (params.mode !== "form" || !message || !schema || typeof schema !== "object" || Array.isArray(schema)
		|| schema.type !== "object" || !schema.properties || typeof schema.properties !== "object"
		|| Array.isArray(schema.properties) || Object.keys(schema.properties).length !== 0
		|| (schema.required !== undefined && (!Array.isArray(schema.required) || schema.required.length !== 0))) {
		return { kind: "unsupported", reason: "unverified-form-schema", message };
	}
	return { kind: "confirm-empty", message };
}

// ── 运行结果类型（NI-01 三轴分离 + NI-12 cost unknown）───────────────────────

export interface CodexCuUsage { totalTokens: number; inputTokens: number; cachedInputTokens: number; cacheWriteInputTokens: number; outputTokens: number; reasoningOutputTokens: number; modelContextWindow: number | null }

export interface CodexCuRunResult {
	route: "codex-app-server-delegation";
	/** 总判定：仅 ≥2 干净 node_repl 调用（动作+再观察结构性代理）+ 干净完成 turn 才 completed。 */
	outcome: "completed" | "blocked" | "failed" | "unknown";
	/** none 仅限从未派发 turn；不能证明零动作即 unknown；deny 不覆写已有 observed。 */
	effects: "none" | "observed" | "unknown";
	/** 输入停止未经协议证明：turn 完成为 unsupported，否则 unconfirmed；永非 confirmed。 */
	stopConfirmation: "confirmed" | "unconfirmed" | "unsupported";
	/** 源 turn 完成轴（与 outcome 分离，NI-01）：turn 干净完成也可报告，同时 outcome 仍缺证。 */
	sourceTurn: { completed: boolean; status: string | null; id: string | null };
	/** native 尝试轴：owned node_repl 调用数 / 其中无错误无拒绝的干净调用数。 */
	nativeAttempts: number;
	cleanNativeCalls: number;
	threadId: string | null;
	turnId: string | null;
	model: string | null;
	usage: CodexCuUsage | null;
	/** price/cost 未由 source 提供 → 恒 unknown（NI-12），额外 Codex 模型额度适用。 */
	cost: { status: "unknown"; note: string };
	elicitationRelay: { received: number; humanDecided: number; declined: number; unsupported: number; foreign: number; lateIgnored: number; accepted: number; autoAccepted: number; notes: string[] };
	deniedLiteral: string | null;
	images: Array<{ file: string; sha256: string; bytes: number; signatureOk: boolean; decode: ImageDecodeObservation | { status: "not-assessed"; reason: string } }>;
	badImages: string[];
	evidenceDir: string;
	evidenceTrusted: boolean;
	serverPid: number | null;
	events: {
		notificationMethods: string[];
		mcpToolCalls: Array<{ server: string; tool: string; status: string; durationMs: number | null; resultText: string | null; imageCount: number; errorText: string | null; topError: string | null }>;
		agentMessages: string[];
		turnFinal: { id: string; status: string; error: unknown; durationMs: number | null } | null;
		tokenUsage: CodexCuUsage | null;
		serverRequests: Array<{ method: string; handled: string; foreign: boolean }>;
		foreignEvents: number;
		/** NI-05：同 item.id 重复完成去重计数 / 终结后迟到事件计数（不恢复已终结状态）。 */
		duplicateItems: number;
		lateEvents: number;
		/** NI-06：准入关闭（整批预算越界）后丢弃的消息计数。 */
		droppedAfterClose: number;
		/** 本次源 App Server 的退出观察，不证明共享服务或输入控制已退出。 */
		serverExitObserved: boolean;
		serverStreamsClosed: boolean;
		serverExitCode: number | null;
	};
	turnCount: number;
	/** NI-01：提交/确认分离——turn/start 已写出但 ack 缺失时为 true（此时不得报 none）。 */
	turnSubmitted: boolean;
	interruptSent: boolean;
	latencyMs: number;
	warnings: string[];
}

export interface CodexCuRunDeps {
	/** 测试注入面：替换源进程命令（生产缺省固定官方 binary + 独立 argv）。 */
	serverCommand?: { command: string; args: string[] };
	/** 批准策略（默认 resolveApprovalPolicy：主上裁定默认全批准；可收窄/转人工）。 */
	approvalPolicy?: CodexCuApprovalPolicy;
	clientVersion?: string;
	deadlineMs?: number;
	uiTimeoutMs?: number;
	decoder?: ImageDecoderLike;
	/** mkdtemp 根（缺省 os.tmpdir()）；测试隔离用。 */
	tmpRoot?: string;
}

const CU_DENY_RE = /Computer Use was not approved to use/i;
const CAUGHT_ERROR_RE = /^Error:/i;
/** 实证官方 CU REPL 服务名：用户配置 node_repl（probe run2）与 unified 插件 cua_repl
 *  （真实 E2E 01a119b1 实测装配）。其它 server 名一律 foreign 拒绝。 */
const OFFICIAL_CU_SERVERS = new Set(["node_repl", "cua_repl"]);
/** 主上裁定（2026-10-08 聊天指令）：源 CU 批准默认全批准（无人值守）；
 * AMAGI_CODEX_COMPUTER_USE_AUTO_ACCEPT 收窄为白名单（设置后仅列出的 app 自动批准）；
 * AMAGI_CODEX_COMPUTER_USE_APPROVAL=manual/human 恢复全人工转交。
 * 仅作用于已通过线程/轮次/目标/官方服务名/形状校验的 CU 批准请求；外来/未知/失效一律仍拒。 */
export interface CodexCuApprovalPolicy { manual: boolean; autoAll: boolean; apps: ReadonlySet<string> }
export function resolveApprovalPolicy(env: NodeJS.ProcessEnv = process.env): CodexCuApprovalPolicy {
	const manual = /^(manual|human)$/i.test(env.AMAGI_CODEX_COMPUTER_USE_APPROVAL ?? "");
	const raw = env.AMAGI_CODEX_COMPUTER_USE_AUTO_ACCEPT;
	const apps = new Set<string>(raw ? raw.split(",").map((s) => s.trim()).filter((s) => s.length > 0) : []);
	return { manual, autoAll: !manual && apps.size === 0, apps };
}
/** AX 状态观察证据：源原生无障碍树 diff 且含具体值（结构化应用状态，非普通文本回述）。 */
const AX_DIFF_STATE_RE = /diff from the previous accessibility tree/i;
/** NI-06 资源界限：帧上限需覆盖编码图上限（20MiB → base64 ≈26.7MiB + JSON 信封）才能让
 * “分配前拒绝”成为超限图的主判定路径；更大无换行流直接丢帧 poison。另设整批累计预算：
 * 事件总数/帧字节总数/pending 请求数共用上限，越界 → 链失信 + 停止准入 + 尽力 interrupt
 * （保留有限摘要，不再囤消息）。事件明细/pending 图数量/累计图字节另设上限（编码上限复用
 * decoder 20MiB）。 */
const MAX_STDOUT_FRAME_BYTES = 33 * 1024 * 1024;
const MAX_TOTAL_EVIDENCE_EVENTS = 2_100;
const MAX_TOTAL_FRAME_BYTES = 64 * 1024 * 1024;
const MAX_PENDING_SERVER_REQUESTS = 200;
const MAX_RECORDED_EVENTS = 2_000;
const MAX_PENDING_IMAGES = 8;
const MAX_CUMULATIVE_IMAGE_BYTES = 2 * IMAGE_DECODE_LIMIT_BYTES;

interface RelayUi {
	confirm(t: string, m: string, o?: { signal?: AbortSignal; timeout?: number }): Promise<boolean>;
	select(t: string, o: string[], op?: { signal?: AbortSignal; timeout?: number }): Promise<string | undefined>;
	input(t: string, p?: string, o?: { signal?: AbortSignal; timeout?: number }): Promise<string | undefined>;
	notify?(m: string, t?: "info" | "warning" | "error"): void;
}

/** 图片取证提取（仅标准 inline data，不读 file:// URL）；NI-06：分配前按 base64 长度预检上限。 */
function extractImageBytes(item: unknown): { bytes: Uint8Array; mimeType: string } | { error: string } {
	const it = item as { type?: unknown; data?: unknown; mimeType?: unknown } | null;
	if (!it || typeof it !== "object" || it.type !== "image") return { error: "not-image" };
	const mime = typeof it.mimeType === "string" ? it.mimeType : "image/png";
	if (typeof it.data !== "string" || it.data.length === 0) return { error: "no-bytes" };
	const decodedEstimate = Math.floor(it.data.length * 3 / 4);
	if (decodedEstimate > IMAGE_DECODE_LIMIT_BYTES) return { error: `oversize:${decodedEstimate}` };
	try { return { bytes: new Uint8Array(Buffer.from(it.data, "base64")), mimeType: mime }; }
	catch { /* lint-exempt: malformed source image is returned as explicit error */ return { error: "base64-invalid" }; }
}

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

function summarizeElicitationMeta(p: SourceElicitationParams): string {
	const meta = (p._meta ?? {}) as { tool_name?: unknown; riskLevel?: unknown; connector_name?: unknown; persist?: unknown };
	const parts: string[] = [];
	if (typeof meta.tool_name === "string") parts.push(`tool=${meta.tool_name}`);
	if (typeof meta.riskLevel === "string") parts.push(`risk=${meta.riskLevel}`);
	if (typeof meta.connector_name === "string") parts.push(`connector=${meta.connector_name}`);
	if (Array.isArray(meta.persist)) parts.push(`persist options=${meta.persist.map(String).join("/")}`);
	parts.push(`server=${p.serverName}`);
	return parts.join(" ");
}

/** 源提示词：目标 app/objective/expectedOutcome 之外的规则文本固定（不接受模型覆盖）。 */
export function buildSourcePrompt(app: string, objective: string, expectedOutcome: string): string {
	return [
		"You are Codex with Computer Use on this Mac. Complete the task below using ONLY the declared target application.",
		`Target application (bundle identifier): ${app}`,
		`Objective: ${objective}`,
		`Expected outcome: ${expectedOutcome}`,
		"Rules: Use the official Computer Use approach (node_repl + @oai/sky or the unified app APIs): observe the target app, act, then re-observe. Do not use any other application, do not read or modify user data outside the target app, and do not use the shell for GUI automation. Approval prompts are shown to the human operator by the client — never attempt to bypass or self-approve them. Quote tool errors verbatim. Finish with a short report of what changed inside the target app and what you observed.",
	].join("\n\n");
}

// ── NI-07 模块级局部门：单在途 + 停止确认（进程内、本工具范围；非机器级独占） ──

const gateState = { inflight: false };

/** 仅测试复位用（生产不调用）。 */
export function resetCodexCuGatesForTest(): void { gateState.inflight = false; }

/**
 * 主执行体（NI-02/03/04/05/06 全链路）：
 * 预取消零副作用 → 单一 deadline → 每次有状态提交前检查取消 → 事件循环（owned 关联校验）→
 * bounded 媒体取证 → 三轴判定 → owned-only finally 收尾（生存检查后组回收）。
 */
export async function runCodexComputerUse(input: {
	app: string;
	objective: string;
	expectedOutcome: string;
	ui: RelayUi | undefined;
	hasUI: boolean;
	signal?: AbortSignal;
	ownsModel?: unknown;
	deps?: CodexCuRunDeps;
}): Promise<CodexCuRunResult> {
	const deps = input.deps ?? {};
	const deadlineMs = deps.deadlineMs ?? 120_000;
	const uiTimeoutMs = deps.uiTimeoutMs ?? 120_000;
	const decoder = deps.decoder ?? defaultHostImageDecoder;
	const startedAt = Date.now();
	const deadlineAt = startedAt + deadlineMs; // NI-02：单一截止覆盖启动/模型/UI/媒体/收尾
	const remaining = (): number => deadlineAt - Date.now();

	const result: CodexCuRunResult = {
		route: "codex-app-server-delegation",
		outcome: "unknown", effects: "unknown", stopConfirmation: "unconfirmed",
		sourceTurn: { completed: false, status: null, id: null },
		nativeAttempts: 0, cleanNativeCalls: 0,
		threadId: null, turnId: null, model: null, usage: null,
		cost: { status: "unknown", note: "price/cost not provided by source; additional Codex model quota applies; no rates fabricated" },
		elicitationRelay: { received: 0, humanDecided: 0, declined: 0, unsupported: 0, foreign: 0, lateIgnored: 0, accepted: 0, autoAccepted: 0, notes: [] },
		deniedLiteral: null, images: [], badImages: [],
		evidenceDir: "", evidenceTrusted: true, serverPid: null,
		events: {
			notificationMethods: [], mcpToolCalls: [], agentMessages: [], turnFinal: null, tokenUsage: null,
			serverRequests: [], foreignEvents: 0, duplicateItems: 0, lateEvents: 0, droppedAfterClose: 0, serverExitObserved: false, serverStreamsClosed: false, serverExitCode: null,
		},
		turnCount: 0, turnSubmitted: false, interruptSent: false, latencyMs: 0, warnings: [],
	};

	// NI-02：预取消 → 零副作用（不 mkdtemp、不 spawn、不 turn），effects=none（从未派发）。
	if (input.signal?.aborted) {
		result.outcome = "unknown";
		result.effects = "none"; // 仅从未派发可 none（NI-01/NI-02）
		result.stopConfirmation = "unconfirmed";
		result.warnings.push("pre-aborted before any side effect (no evidence dir, no spawn, no turn)");
		result.latencyMs = Date.now() - startedAt;
		return result;
	}

	const evidenceDir = fs.mkdtempSync(path.join(deps.tmpRoot ?? os.tmpdir(), "codex-cu-"));
	result.evidenceDir = evidenceDir;
	const eventsFile = path.join(evidenceDir, "events.jsonl");
	const evtStream = fs.createWriteStream(eventsFile, { flags: "a" });
	evtStream.on("error", (e) => { result.warnings.push(`events log stream error: ${e.message}`); }); // NI-04：流 error 立即处理
	let logClosed = false;
	const appendLog = (evt: unknown): void => { if (logClosed) return; try { evtStream.write(JSON.stringify(evt) + "\n"); } catch { /* lint-exempt:日志失败不改变主流程，warning 已在流层记录 */ } }; // 只保存本次 owned 事件

	const pendingImages: Array<{ bytes: Uint8Array; mimeType: string }> = []; // 每运行态（不跨 run 泄漏）
	let cumulativeImageBytes = 0;

	const cmd = deps.serverCommand ?? { command: CODEX_COMPUTER_USE_BIN, args: ["app-server", "--listen", "stdio://"] };
	const approvalPolicy = deps.approvalPolicy ?? resolveApprovalPolicy();
	const server: ChildProcess = spawn(cmd.command, cmd.args, {
		cwd: evidenceDir, stdio: ["pipe", "pipe", "pipe"], detached: true, // 自有进程组（收尾只回收本组）
	});
	result.serverPid = server.pid ?? null;
	// NI-04：child/stdio error 立即挂 listener（missing binary 等不得崩溃承载进程）；
	// error/exit 时立即 reject 全部 pending 调用，mainline 不必等步进超时。
	const rejectPending = (why: string): void => {
		for (const [id, p] of [...pendingCalls.entries()]) { pendingCalls.delete(id); p.reject(new Error(why)); }
	};
	server.on("error", (e) => { result.warnings.push(`source process error: ${e.message}`); rejectPending("source-process-error"); wakeMain("server-error"); });
	server.stdin?.on("error", (e) => { result.warnings.push(`source stdin error: ${e.message}`); });
	server.stdout?.on("error", (e) => { result.warnings.push(`source stdout error: ${e.message}`); wakeMain("stdout-error");
	});
	const stderrChunks: Buffer[] = [];
	let stderrLen = 0;
	server.stderr?.on("error", (e) => { result.warnings.push(`source stderr error: ${e.message}`); });
	server.stderr?.on("data", (d: Buffer) => { stderrLen += d.length; if (stderrLen <= 64 * 1024) stderrChunks.push(d); });

	let nextClientId = 1;
	const pendingCalls = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void }>();
	const answeredServerIds = new Set<string>(); // 每个源请求 id 恰好应答一次（防碰撞/重复）
	const resolvedServerIds = new Set<string>(); // NI-03：serverRequest/resolved → pending 请求失效
	let buffer = "";
	let turnDone!: () => void;
	const turnDonePromise = new Promise<void>((res) => { turnDone = res; });
	let wakeMainFn: (() => void) | undefined;
	const mainWait = new Promise<void>((res) => { wakeMainFn = res; });
	function wakeMain(_why: string): void { wakeMainFn?.(); }
	let cancelled = false;
	/** NI-04（复审二）：退出态寿命利据——'exit' 事件（含信号退出，此时 exitCode 可为 null 且
	 * killed 不置位）重于 exitCode 推断；延迟组信号前必须复核未退出。 */
	let serverExited = false;
	const cancelWaiters: Array<() => void> = [];
	const onAbort = () => {
		cancelled = true;
		// NI-03（复审二）：abort 永久关闭 lifecycle——不但撤现存 relay，也阻止 abort 后新到的
		// elicitation 进入人工转交（不可恢复失效，不因“当时无 pending”而放过）。
		invalidateLifecycle("external-abort");
		for (const w of cancelWaiters.splice(0)) w();
		wakeMain("abort");
	};
	input.signal?.addEventListener("abort", onAbort, { once: true });

	/** NI-03：统一失效面——deadline/abort/owned turn 结束/resolved/server exit/解析失败。 */
	let lifecycleActive = true;
	const pendingRelays = new Map<string, { id: number | string; invalidate: (reason: string) => void }>();
	function invalidatePendingRelays(reason: string): void {
		for (const [, r] of [...pendingRelays.entries()]) r.invalidate(reason);
		pendingRelays.clear();
	}
	function invalidateLifecycle(reason: string): void {
		if (!lifecycleActive) return;
		lifecycleActive = false;
		invalidatePendingRelays(reason);
	}

	const send = (obj: unknown): void => {
		try { if (server.stdin?.writable) server.stdin.write(JSON.stringify(obj) + "\n"); } catch { /* lint-exempt:写入失败由 error listener 记录 */ }
	};
	/** NI-02：有状态提交前检查取消/预算；超时上限 = min(步进上限, 剩余预算)。 */
	const request = (method: string, params: unknown, stepTimeoutMs: number): Promise<unknown> => {
		if (cancelled || remaining() <= 0) return Promise.reject(new Error(`cancelled-or-deadline-before:${method}`));
		const id = nextClientId++;
		send({ jsonrpc: "2.0", id, method, params });
		return new Promise((resolve, reject) => {
			const t = setTimeout(() => { pendingCalls.delete(id); reject(new Error(`timeout:${method}`)); }, Math.max(1, Math.min(stepTimeoutMs, remaining())));
			pendingCalls.set(id, { resolve: (v) => { clearTimeout(t); resolve(v); }, reject: (e) => { clearTimeout(t); reject(e); } });
		});
	};
	/** raw 请求：不做取消/预算预检（取消类动作如 turn/interrupt 在截止后仍必须能发出）。 */
	const rawRequest = (method: string, params: unknown, timeoutMs: number): Promise<unknown> => {
		const id = nextClientId++;
		send({ jsonrpc: "2.0", id, method, params });
		return new Promise((resolve, reject) => {
			const t = setTimeout(() => { pendingCalls.delete(id); reject(new Error(`timeout:${method}`)); }, timeoutMs);
			pendingCalls.set(id, { resolve: (v) => { clearTimeout(t); resolve(v); }, reject: (e) => { clearTimeout(t); reject(e); } });
		});
	};
	const declineElicitation = (id: number | string): void => { send({ jsonrpc: "2.0", id, result: { action: "decline", content: null, _meta: null } }); };

	/** NI-05：malformed/handler error → 证据不可信 + best-effort interrupt（不重放）。
	 * NI-03（复审二）：poison 同时永久关闭 lifecycle——证据失信后 pending/新到请求均不得 accept。 */
	async function poisonEvidence(reason: string): Promise<void> {
		if (result.evidenceTrusted) result.evidenceTrusted = false;
		if (!result.warnings.includes(reason)) result.warnings.push(reason);
		invalidateLifecycle(`poison:${reason}`);
		await maybeInterrupt(`poison:${reason}`);
	}
	let interruptInFlight = false;
	async function maybeInterrupt(reason: string): Promise<void> {
		const tid = result.threadId;
		const vid = result.turnId;
		if (result.interruptSent || interruptInFlight) return;
		if (typeof tid !== "string" || typeof vid !== "string") return;
		if (result.events.turnFinal) return;
		interruptInFlight = true;
		result.interruptSent = true;
		appendLog({ dir: "send", method: "turn/interrupt", reason });
		try { await rawRequest("turn/interrupt", { threadId: tid, turnId: vid }, 5_000); }
		catch (e) { result.warnings.push(`turn/interrupt failed: ${e instanceof Error ? e.message : String(e)}`); }
	}

	/** 源请求 → 安全应答（elicitation 例外：经人工转交 + accept 前重验）。 */
	const handleServerRequest = async (req: SourceServerRequest): Promise<void> => {
		const key = typeof req.id === "number" ? `n:${req.id}` : `s:${String(req.id)}`;
		if (answeredServerIds.has(key)) return;
		answeredServerIds.add(key);
		if (req.kind === "elicitation") {
			const p = req.params;
			result.elicitationRelay.received++;
			const foreignThread = result.threadId === null || p.threadId !== result.threadId;
			const foreignTurn = result.turnId === null || (p.turnId !== null && p.turnId !== result.turnId);
			// 目标一致性：官方 CU REPL（node_repl/cua_repl）+ _meta.tool_params.app 必须严格等于工具输入 app
			//（缺 app 也拒绝）；非本次 app/线程/轮次保守拒绝，绝不因展示元数据而放宽。
			const metaApp = (p._meta as { tool_params?: { app?: unknown } } | undefined)?.tool_params?.app;
			const foreignTarget = !OFFICIAL_CU_SERVERS.has(p.serverName) || metaApp !== input.app;
			if (foreignThread || foreignTurn || foreignTarget) {
				result.elicitationRelay.foreign++;
				declineElicitation(req.id);
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: `decline:foreign-${foreignThread ? "thread" : foreignTurn ? "turn" : "target"}`, foreign: true });
				return;
			}
			const plan = planElicitationRelay(p);
			if (plan.kind === "unsupported") {
				result.elicitationRelay.unsupported++;
				result.elicitationRelay.notes.push(`unsupported elicitation (${plan.reason}) → declined`);
				declineElicitation(req.id);
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: `decline:unsupported:${plan.reason}`, foreign: false });
				return;
			}
			// NI-03（复审二）：abort/poison/断线等不可恢复失效后，新到请求不得进入任何批准路径
			if (!lifecycleActive || cancelled || !result.evidenceTrusted) {
				result.elicitationRelay.declined++;
				const why = cancelled ? "external-abort" : !result.evidenceTrusted ? "evidence-untrusted" : "lifecycle-invalidated";
				declineElicitation(req.id);
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: `decline:${why}`, foreign: false });
				return;
			}
			// 主上裁定默认全批准（无人值守）：仅对已过全部校验的 CU 批准请求自动 accept，逐次披露；
			// exec/file 等非 CU 审批不在此路径，仍一律拒绝。
			if (!approvalPolicy.manual && (approvalPolicy.autoAll || approvalPolicy.apps.has(input.app))) {
				result.elicitationRelay.accepted++;
				result.elicitationRelay.autoAccepted++;
				const why = approvalPolicy.autoAll ? "default-approve-all (owner directive)" : `pre-authorized app ${input.app}`;
				result.elicitationRelay.notes.push(`${why} → auto accept #${result.elicitationRelay.autoAccepted}`);
				send({ jsonrpc: "2.0", id: req.id, result: { action: "accept", content: {}, _meta: null } });
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: "accept:auto", foreign: false });
				return;
			}
			if (!input.hasUI || !input.ui) {
				result.elicitationRelay.declined++;
				result.elicitationRelay.notes.push("no UI channel → declined (never auto-approve)");
				declineElicitation(req.id);
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: "decline:no-ui", foreign: false });
				return;
			}
			// NI-03（复审二）：abort/poison/断线等不可恢复失效后的残留防护（主路径已前置拒绝）
			if (!lifecycleActive || cancelled || !result.evidenceTrusted) {
				declineElicitation(req.id);
				return;
			}
			// NI-03：pending 关联 + 统一失效（deadline/abort/turn 结束/resolved/断线）
			let relayInvalidated: string | null = null;
			const relayCancel = new Promise<"cancelled">((res) => {
				pendingRelays.set(key, { id: req.id, invalidate: (reason) => { relayInvalidated = reason; res("cancelled"); } });
			});
			// UI 对话框带 signal + timeout（SDK ExtensionUIDialogOptions 实际字段）；预算封顶
			const uiDialog = new AbortController();
			cancelWaiters.push(() => uiDialog.abort());
			const uiTimeout = Math.max(1, Math.min(uiTimeoutMs, Math.max(1, remaining())));
			const deadlineTimer = setTimeout(() => { relayInvalidated = "deadline"; uiDialog.abort(); }, Math.max(1, remaining()));
			// NI-04：UI reject → 安全 decline，绝不冒泡承载进程
			const uiPromise = (async (): Promise<{ action: "accept"; content: unknown } | { action: "decline"; content: null } | { action: "error" }> => {
				try {
					const ok = await input.ui!.confirm("Codex 源 Computer Use 许可", `${plan.message}\n${summarizeElicitationMeta(p)}`, { signal: uiDialog.signal, timeout: uiTimeout });
					return ok === true ? { action: "accept", content: {} } : { action: "decline", content: null };
				} catch (e) {
					result.warnings.push(`ui channel error → safety decline: ${e instanceof Error ? e.message : String(e)}`);
					return { action: "error" };
				}
			})();
			const outcome = await Promise.race([uiPromise, relayCancel]);
			clearTimeout(deadlineTimer);
			pendingRelays.delete(key);
			// NI-03：accept 紧前重验——失效/截止/turn 已终结/取消/证据失信/源已退出一律不批准，
			// 迟到人工结果只记账。
			const recheck = relayInvalidated
				?? (!lifecycleActive ? "lifecycle-invalidated"
					: cancelled ? "external-abort"
					: !result.evidenceTrusted ? "evidence-untrusted"
					: serverExited ? "server-exit"
					: remaining() <= 0 ? "deadline-exhausted"
					: result.events.turnFinal ? "turn-ended"
					: resolvedServerIds.has(key) ? "request-resolved"
					: null);
			if (outcome === "cancelled" || recheck !== null) {
				result.elicitationRelay.declined++;
				declineElicitation(req.id);
				const why = outcome === "cancelled" ? (relayInvalidated ?? "cancelled") : recheck;
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: `decline:${why}`, foreign: false });
				void uiPromise.then((late) => { if (late.action === "accept") result.elicitationRelay.lateIgnored++; });
				return;
			}
			if (outcome.action === "accept") {
				result.elicitationRelay.humanDecided++;
				result.elicitationRelay.accepted++;
				send({ jsonrpc: "2.0", id: req.id, result: { action: "accept", content: outcome.content, _meta: null } });
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: "accept:human", foreign: false });
			} else {
				result.elicitationRelay.humanDecided++;
				if (outcome.action !== "error") result.elicitationRelay.declined++;
				else result.elicitationRelay.notes.push("ui channel error treated as decline (never auto-approve)");
				declineElicitation(req.id);
				result.events.serverRequests.push({ method: "mcpServer/elicitation/request", handled: outcome.action === "error" ? "decline:ui-error" : "decline:human", foreign: false });
			}
			return;
		}
		if (req.kind === "exec-approval" || req.kind === "file-approval") {
			send({ jsonrpc: "2.0", id: req.id, result: { decision: "decline" } });
			result.events.serverRequests.push({ method: req.kind, handled: "decline", foreign: false });
			return;
		}
		// legacy/未知（auth、permissions、dynamic tool、attestation、userVerification 等）：协议
		// method-not-found，不自动授权源 shell/凭据。
		const method = req.method;
		send({ jsonrpc: "2.0", id: req.id, error: { code: -32601, message: `amagi codex_computer_use: unsupported source request (${method}) — denied` } });
		result.events.serverRequests.push({ method, handled: "error:unsupported", foreign: false });
	};

	const inFlight: Array<Promise<void>> = [];
	/** NI-05（复审二）：同一 owned (thread,turn,item.id) 完成去重表。 */
	const seenItemIds = new Set<string>();
	/** NI-06（复审二）：整批累计预算——帧字节总数/事件总数共用上限，越界关间准入（链失信 +
	 * 尽力 interrupt），之后消息只计数不排队不囤积。 */
	let admissionOpen = true;
	let totalFrameBytes = 0;
	let totalEvidenceEvents = 0;
	const closeAdmission = (reason: string): void => {
		if (!admissionOpen) return;
		admissionOpen = false;
		void poisonEvidence(reason);
	};

	const handleMessage = async (msg: unknown): Promise<void> => {
		const parsed = parseSourceServerRequest(msg);
		if (parsed.kind === "request") {
			// NI-06（复审二）：pending 源请求数上限——越界不再排队，链失信 + 安全应答
			if (result.events.serverRequests.length >= MAX_PENDING_SERVER_REQUESTS) {
				closeAdmission(`pending server requests exceed ${MAX_PENDING_SERVER_REQUESTS}`);
				if (parsed.req.kind === "elicitation") declineElicitation(parsed.req.id);
				else send({ jsonrpc: "2.0", id: parsed.req.id, error: { code: -32601, message: "amagi codex_computer_use: request budget exceeded — denied" } });
				return;
			}
			appendLog({ dir: "recv", serverRequest: { method: (msg as { method: string }).method, id: parsed.req.id } });
			// NI-04：promise 立即挂 catch（晚到 allSettled 不再暴露 unhandled rejection）
			inFlight.push(handleServerRequest(parsed.req).catch((e) => { void poisonEvidence(`handler error: ${e instanceof Error ? e.message : String(e)}`); }));
			return;
		}
		const m = msg as { id?: unknown; method?: unknown; params?: unknown; result?: unknown; error?: unknown };
		if (m.id !== undefined && m.method === undefined && typeof m.id === "number") {
			const p = pendingCalls.get(m.id);
			if (p) {
				pendingCalls.delete(m.id);
				if (m.error !== undefined) p.reject(new Error(`source-error:${JSON.stringify(m.error)}`));
				else p.resolve(m.result);
			}
			return;
		}
		if (typeof m.method === "string" && m.id === undefined) {
			await handleNotification(m.method, (m.params ?? {}) as Record<string, unknown>);
		}
	};

	// 消息串行队列：防 chunk 合并竞态（thread/turn 响应与首个 server request 同 chunk 到达时，
	// 同步处理会先于 await 续体赋值 threadId/turnId → foreign 判定失效）。链式串行保证每个消息的
	// 处理在先前响应的续体（含 threadId/turnId 赋值）之后执行。
	let queueTail: Promise<void> = Promise.resolve();
	const enqueueMessage = (msg: unknown): void => {
		queueTail = queueTail.then(() => handleMessage(msg)).catch((e) => { void poisonEvidence(`handler error: ${e instanceof Error ? e.message : String(e)}`); });
	};

	const handleNotification = async (method: string, params: Record<string, unknown>): Promise<void> => {
		// NI-05：owned 关联校验——item/turn/tokenUsage 通知必须带 owned threadId（缺 threadId 的
		// 不完整通知不计入证据，只计数）；外来 thread 只计数不落原始字节。
		const threadId = params.threadId;
		const needsThread = method.startsWith("item/") || method.startsWith("turn/") || method === "thread/tokenUsage/updated";
		if (needsThread && (typeof threadId !== "string" || threadId !== result.threadId)) {
			result.events.foreignEvents++;
			return;
		}
		// NI-05（复审二）：终结后迟到事件只计数，不恢复已终结状态/证据链
		if (result.events.turnFinal && method.startsWith("item/")) {
			result.events.lateEvents++;
			return;
		}
		if (result.events.notificationMethods.length < MAX_RECORDED_EVENTS) {
			appendLog({ dir: "recv", notification: { method } });
			result.events.notificationMethods.push(method);
		}
		switch (method) {
			case "item/completed": {
				// NI-05（复审二）：item 通知必带非空 turnId 且匹配 owned turn（缺失/null 拒收，不入证据）
				const itemTurnId = params.turnId;
				if (typeof itemTurnId !== "string" || itemTurnId !== result.turnId) {
					result.events.foreignEvents++;
					return;
				}
				const item = params.item as { type?: unknown; id?: unknown; server?: unknown; tool?: unknown; status?: unknown; durationMs?: unknown; error?: unknown; result?: { content?: unknown[]; error?: unknown } | null; text?: unknown; arguments?: unknown } | undefined;
				if (!item || typeof item !== "object") return;
				// NI-05（复审二）：同一 owned (thread,turn,item.id) 的重复完成去重（不冒充第二次调用）
				const dedupKey = `${threadId}|${itemTurnId}|${typeof item.id === "string" ? item.id : typeof item.id === "number" ? String(item.id) : "(no-id)"}`;
				if (seenItemIds.has(dedupKey)) {
					result.events.duplicateItems++;
					return;
				}
				seenItemIds.add(dedupKey);
				if (item.type === "mcpToolCall") {
					const topError = item.error !== null && item.error !== undefined ? JSON.stringify(item.error).slice(0, 500) : null; // NI-01：顶层 error 真实保留
					const contents = Array.isArray(item.result?.content) ? item.result!.content : [];
					const texts = contents.filter((c) => (c as { type?: unknown }).type === "text").map((c) => String((c as { text?: unknown }).text ?? ""));
					const joined = texts.join("\n");
					if (CU_DENY_RE.test(joined) && result.deniedLiteral === null) result.deniedLiteral = joined.slice(0, 500);
					const imageCount = contents.filter((c) => (c as { type?: unknown }).type === "image").length;
					result.events.mcpToolCalls.push({
						server: String(item.server ?? ""), tool: String(item.tool ?? ""), status: String(item.status ?? ""),
						durationMs: typeof item.durationMs === "number" ? item.durationMs : null,
						resultText: joined.slice(0, 2_000) || null, imageCount,
						errorText: item.result?.error ? JSON.stringify(item.result.error).slice(0, 500) : null,
						topError,
					});
					appendLog({ dir: "recv", item: { type: "mcpToolCall", id: item.id, server: item.server, tool: item.tool, status: item.status, resultText: joined.slice(0, 1_000), imageCount, topError } }); // 原始 bytes 不进日志
					for (const c of contents) {
						const r = extractImageBytes(c);
						if ("error" in r) { if (r.error !== "not-image") result.badImages.push(r.error); continue; }
						// NI-06：pending 数量/累计字节上限（分配已在上一步完成，此处入队前再限累计）
						if (pendingImages.length >= MAX_PENDING_IMAGES) { result.badImages.push("too-many-images"); continue; }
						if (cumulativeImageBytes + r.bytes.length > MAX_CUMULATIVE_IMAGE_BYTES) { result.badImages.push("cumulative-image-budget-exceeded"); continue; }
						cumulativeImageBytes += r.bytes.length;
						pendingImages.push({ bytes: r.bytes, mimeType: r.mimeType });
					}
				} else if (item.type === "agentMessage" && typeof item.text === "string") {
					result.events.agentMessages.push(item.text.slice(0, 4_000));
				}
				return;
			}
			case "thread/tokenUsage/updated": {
				const u = params.tokenUsage as { total?: Record<string, unknown>; modelContextWindow?: unknown } | undefined;
				if (u && typeof u === "object" && u.total) {
					const t = u.total;
					const usage: CodexCuUsage = {
						totalTokens: num(t.totalTokens), inputTokens: num(t.inputTokens), cachedInputTokens: num(t.cachedInputTokens),
						cacheWriteInputTokens: num(t.cacheWriteInputTokens), outputTokens: num(t.outputTokens), reasoningOutputTokens: num(t.reasoningOutputTokens),
						modelContextWindow: typeof u.modelContextWindow === "number" ? u.modelContextWindow : null,
					};
					result.usage = usage;
					result.events.tokenUsage = usage;
				}
				return;
			}
			case "serverRequest/resolved": {
				// NI-03：源侧已解决（或终结）该请求 → pending 批准资格失效
				const rid = params.requestId;
				if (rid !== undefined) resolvedServerIds.add(typeof rid === "number" ? `n:${rid}` : `s:${String(rid)}`);
				const entry = [...pendingRelays.entries()].find(([k]) => k === (typeof rid === "number" ? `n:${rid}` : `s:${String(rid)}`));
				entry?.[1].invalidate("request-resolved");
				return;
			}
			case "turn/completed": {
				const turn = params.turn as { id?: unknown; status?: unknown; error?: unknown; durationMs?: unknown } | undefined;
				if (!turn || typeof turn !== "object") return;
				// NI-05：turn.id 必须匹配 owned turn；外来 turn 只计数，不结算不唤醒
				if (result.turnId !== null && turn.id !== result.turnId) {
					result.events.foreignEvents++;
					return;
				}
				result.events.turnFinal = {
					id: String(turn.id ?? ""), status: String(turn.status ?? ""),
					error: turn.error ?? null, durationMs: typeof turn.durationMs === "number" ? turn.durationMs : null,
				};
				invalidateLifecycle("turn-ended");
				turnDone();
				return;
			}
			case "error": {
				result.warnings.push(`source error notification: ${JSON.stringify(params).slice(0, 300)}`);
				return;
			}
			default:
				return;
		}
	};

	server.stdout?.on("data", (chunk: Buffer) => {
		buffer += chunk.toString("utf8");
		let idx: number;
		while ((idx = buffer.indexOf("\n")) >= 0) {
			const line = buffer.slice(0, idx).trim();
			buffer = buffer.slice(idx + 1);
			if (!line) continue;
			// NI-06（复审二）：准入已关（整批预算越界）→ 只计数，不再解析/排队/囤消息
			if (!admissionOpen) { result.events.droppedAfterClose++; continue; }
			// NI-06：帧长上限——超限行不可信，丢弃并 poison（unknown + interrupt），不无界累积
			if (line.length > MAX_STDOUT_FRAME_BYTES) {
				void poisonEvidence(`stdout frame exceeds ${MAX_STDOUT_FRAME_BYTES}B and was dropped`);
				continue;
			}
			// NI-06（复审二）：帧字节/事件总数累计预算
			totalFrameBytes += line.length;
			totalEvidenceEvents++;
			if (totalFrameBytes > MAX_TOTAL_FRAME_BYTES) { closeAdmission(`total stdout frames exceed ${MAX_TOTAL_FRAME_BYTES}B`); continue; }
			if (totalEvidenceEvents > MAX_TOTAL_EVIDENCE_EVENTS) { closeAdmission(`total evidence events exceed ${MAX_TOTAL_EVIDENCE_EVENTS}`); continue; }
			let msg: unknown;
			try { msg = JSON.parse(line); } catch {
				// NI-05：malformed → 证据不可信 + unknown + best-effort interrupt
				void poisonEvidence("unparseable source stdout line");
				continue;
			}
			enqueueMessage(msg);
		}
		// NI-06：无换行的残留缓冲上限（防长无换行 stdout 无界增长）
		if (buffer.length > MAX_STDOUT_FRAME_BYTES) {
			void poisonEvidence(`stdout buffer exceeds ${MAX_STDOUT_FRAME_BYTES}B without newline and was dropped`);
			buffer = "";
		}
	});
	let resolveServerExit!: () => void;
	const serverExitSignal = new Promise<void>((resolve) => { resolveServerExit = resolve; });
	let serverStreamsClosed = false;
	const serverCloseSignal = new Promise<void>((resolve) => server.once("close", () => { serverStreamsClosed = true; resolve(); }));
	server.once("exit", (code) => {
		serverExited = true;
		resolveServerExit();
		invalidateLifecycle("server-exit");
		rejectPending("server-exit");
		wakeMain("server-exit");
		void code;
	});

	// ── owned-only 外层收尾（NI-04 复审二：主线/媒体/判定任一异常都必经；媒体写盘失败
	//    不再跳过自有回收） ──────────────────────────────────────────────
	let cleanupPromise: Promise<void> | undefined;
	const ownedCleanup = (): Promise<void> => cleanupPromise ??= (async () => {
		try {
			try { server.stdin?.end(); } catch { /* lint-exempt: owned transport may already be closed */ }
			if (!serverExited && server.pid) await Promise.race([serverExitSignal, sleep(200)]);
			// 只处理未退出的本次子进程组，避免信号命中已退出进程复用的 PID。
			const stillOurs = (): boolean => !serverExited && server.exitCode === null && !server.killed && typeof server.pid === "number";
			if (stillOurs()) {
				try { process.kill(-server.pid!, "SIGTERM"); } catch { /* lint-exempt: owned process group may already be gone */ }
				await Promise.race([serverExitSignal, sleep(800)]);
			}
			if (stillOurs()) {
				try { process.kill(-server.pid!, "SIGKILL"); } catch { /* lint-exempt: owned process group may already be gone */ }
				await Promise.race([serverExitSignal, sleep(1_000)]);
			}
			// exit 早于 stdio 关闭：有界等待剩余输出，避免关日志后还有数据写入。
			if (!serverStreamsClosed) await Promise.race([serverCloseSignal, sleep(200)]);
			if (!serverStreamsClosed && server.pid) {
				result.evidenceTrusted = false;
				result.warnings.push("源 stdio 未确认关闭，事件证据链不完整");
			}
			result.events.serverExitObserved = serverExited;
			result.events.serverStreamsClosed = serverStreamsClosed;
			if (server.pid && !serverExited) result.warnings.push("本次 App Server 未能在清理时限内确认退出；不能据此判断控制权是否释放");
			result.events.serverExitCode = server.exitCode;
			appendLog({ dir: "fin", serverExitObserved: serverExited, serverExitCode: server.exitCode, foreignEvents: result.events.foreignEvents });
			logClosed = true;
			evtStream.end();
			fs.writeFileSync(path.join(result.evidenceDir, "stderr.txt"), Buffer.concat(stderrChunks));
		} catch (e) {
			result.warnings.push(`cleanup: ${e instanceof Error ? e.message : String(e)}`);
		} finally {
			input.signal?.removeEventListener("abort", onAbort);
		}
	})();

	try {
	// ── 协议主线（每步恰好一次；有错不循环；NI-02 每步提交前检查取消/预算） ──────
	try {
		await request("initialize", {
			clientInfo: { name: "amagi-pi", title: "amagi-pi codex_computer_use", version: deps.clientVersion ?? "1.0.0" },
			capabilities: { experimentalApi: false, requestAttestation: false },
		}, 15_000);
		send({ jsonrpc: "2.0", method: "initialized" });
		appendLog({ dir: "send", method: "initialized" });

		const thread = await request("thread/start", {
			cwd: evidenceDir,
			ephemeral: true,
			approvalPolicy: "on-request",
			sandbox: "read-only",
			// 不传 baseInstructions/developerInstructions/model：保留源默认 instructions/safety。
		}, 20_000) as { thread?: { id?: unknown }; model?: unknown };
		result.threadId = typeof thread.thread?.id === "string" ? thread.thread.id : null;
		result.model = typeof thread.model === "string" ? thread.model : null; // 实际 selected model（不读 config）
		appendLog({ dir: "send", method: "thread/start", threadId: result.threadId, model: result.model });
		if (!result.threadId) throw new Error("thread/start: no thread id");

		// NI-02：source 不确定（取消/预算耗尽）时不得再发 model turn。
		// NI-01（复审二）：提交/确认分离——send 同步发生后立即置 turnSubmitted（ack 缺失不得报 none）。
		const turnStartPromise = request("turn/start", {
			threadId: result.threadId,
			input: [{ type: "text", text: buildSourcePrompt(input.app, input.objective, input.expectedOutcome), text_elements: [] }],
		}, 20_000);
		result.turnSubmitted = true;
		const turnStart = await turnStartPromise as { turn?: { id?: unknown } };
		result.turnCount = 1;
		result.turnId = typeof turnStart.turn?.id === "string" ? turnStart.turn.id : null;
		appendLog({ dir: "send", method: "turn/start", turnId: result.turnId });

		await Promise.race([
			turnDonePromise,
			mainWait,
			new Promise<void>((res) => {
				const t = setInterval(() => { if (Date.now() >= deadlineAt || cancelled) { clearInterval(t); res(); } }, 100);
				t.unref?.();
			}),
		]);

		if (!result.events.turnFinal && result.turnCount > 0) {
			// 取消只走官方 turn/interrupt（一次）+ 有界等待；绝不重放/换后端补做。
			// NI-03：interrupt 快速独立发送，不排在 inFlight/UI 之后。
			await maybeInterrupt(cancelled ? "external-abort" : "deadline");
			await Promise.race([turnDonePromise, sleep(1_500)]);
		}
		// NI-03：收尾 allSettled 有独立上界（UI 永不 settle 也不无限等）
		await Promise.race([Promise.allSettled(inFlight), sleep(1_500)]);
	} catch (e) {
		result.warnings.push(`protocol: ${e instanceof Error ? e.message : String(e)}`);
	}

	// 协议完成/中止后优先关闭自有源进程，再进行可能较慢的媒体处理。
	await ownedCleanup();
	// ── 图片取证（NI-06：整批共用剩余预算；超支跳过探测不消费） ─────────────────
	const queue = pendingImages.splice(0, pendingImages.length);
	let imgIdx = 0;
	for (const img of queue) {
		const file = path.join(result.evidenceDir, `screenshot-${imgIdx}.png`);
		try {
			if (remaining() <= 0) {
				result.badImages.push(`screenshot-${imgIdx}.png:budget-exhausted-before-decode`);
				// 预算耗尽仍落盘字节作为有限事实（不 decode、不重试）
				fs.writeFileSync(file, img.bytes);
				imgIdx++;
				continue;
			}
			const sha256 = createHash("sha256").update(img.bytes).digest("hex");
			const signatureOk = (IMAGE_ADMITTED_OUTPUT_MIME as readonly string[]).includes(img.mimeType) && imageSignatureConsistent(img.mimeType, img.bytes);
			fs.writeFileSync(file, img.bytes);
			let decode: CodexCuRunResult["images"][number]["decode"];
			if (!signatureOk) {
				decode = { status: "not-assessed", reason: "signature-mismatch" };
				result.badImages.push(`screenshot-${imgIdx}.png:signature-mismatch`);
			} else {
				try { decode = await decoder.probe(img.bytes, img.mimeType, { deadlineAtMonotonic: performance.now() + Math.min(10_000, Math.max(1, remaining())), signal: input.signal }); }
				catch (e) { decode = { status: "not-assessed", reason: `decoder-error:${e instanceof Error ? e.message : String(e)}` }; }
			}
			result.images.push({ file, sha256, bytes: img.bytes.length, signatureOk, decode });
		} catch (e) {
			// NI-04（复审二）：媒体写盘/解码真实 fs 错误（EISDIR/ENOSPC 等）——记入 badImages 与
			// warnings，不向上抛、不跳过外层 owned 收尾。
			const w = `screenshot-${imgIdx}.png:write-failed:${e instanceof Error ? e.message : String(e)}`;
			result.badImages.push(w);
			result.warnings.push(`media write failure recorded (owned cleanup still enforced): ${w}`);
		}
		imgIdx++;
	}

	// ── 三轴判定（NI-01 复审二：普通 JS 调用计数不升级为 native 效果——effects=observed 需
	//    ≥2 干净 node_repl 调用且 ≥1 张签名合法且解码 passed 的真实观察产物图；提交已发但 ack
	//    缺失不得报 none；deny 不覆写；none 仅限从未提交） ─────────────────────
	const turnFinal = result.events.turnFinal;
	const denySeen = result.deniedLiteral !== null || CU_DENY_RE.test(result.events.agentMessages.join("\n"));
	const errorSeen = result.events.mcpToolCalls.some((c) => c.topError !== null || c.errorText !== null || (c.resultText !== null && CAUGHT_ERROR_RE.test(c.resultText.trim())));
	result.nativeAttempts = result.events.mcpToolCalls.filter((c) => OFFICIAL_CU_SERVERS.has(c.server)).length;
	result.cleanNativeCalls = result.events.mcpToolCalls.filter((c) =>
		c.server !== undefined && OFFICIAL_CU_SERVERS.has(c.server) && c.status === "completed" && c.topError === null && c.errorText === null
		&& (c.resultText === null || !CU_DENY_RE.test(c.resultText)) && (c.resultText === null || !CAUGHT_ERROR_RE.test(c.resultText.trim())),
	).length;
	const observationImages = result.images.filter((i) => i.signatureOk && i.decode.status === "passed").length;
	const axStateObservations = result.events.mcpToolCalls.filter((c) => c.server !== undefined && OFFICIAL_CU_SERVERS.has(c.server) && c.status === "completed"
		&& c.resultText !== null && AX_DIFF_STATE_RE.test(c.resultText) && /Value:/.test(c.resultText)).length;
	const observationEvidence = observationImages + axStateObservations;
	result.sourceTurn.completed = turnFinal !== null && turnFinal.status === "completed";
	result.sourceTurn.status = turnFinal?.status ?? null;
	result.sourceTurn.id = turnFinal?.id ?? null;
	if (!result.turnSubmitted) {
		// 从未提交（预取消已在入口返回；此处为提交前失败）→ 唯一可 none 的分支
		result.outcome = "unknown"; result.effects = "none"; result.stopConfirmation = "unconfirmed";
	} else if (result.turnCount === 0) {
		// NI-01（复审二）：turn/start 已写出但 ack 缺失——不得冒充未派发报 none
		result.outcome = "unknown"; result.effects = "unknown"; result.stopConfirmation = "unconfirmed";
		result.warnings.push("turn/start submitted but ack missing — dispatch uncertainty (no replay)");
	} else if (denySeen) {
		result.outcome = "blocked";
		result.effects = nativeEffectsProven(result, observationEvidence) ? "observed" : "unknown"; // deny 不覆写此前效果
		result.stopConfirmation = result.sourceTurn.completed ? "unsupported" : "unconfirmed";
	} else if (errorSeen) {
		result.outcome = "failed"; result.effects = "unknown";
		result.stopConfirmation = result.sourceTurn.completed ? "unsupported" : "unconfirmed";
	} else if (!result.sourceTurn.completed || !result.evidenceTrusted) {
		result.outcome = "unknown"; result.effects = "unknown"; result.stopConfirmation = "unconfirmed";
		if (result.sourceTurn.completed && !result.evidenceTrusted) result.warnings.push("evidence chain untrusted (malformed/handler error/budget) → unknown");
	} else if (nativeEffectsProven(result, observationEvidence)) {
		result.outcome = "completed"; result.effects = "observed"; result.stopConfirmation = "unsupported";
	} else {
		result.outcome = "unknown"; result.effects = "unknown"; result.stopConfirmation = "unsupported";
		result.warnings.push(`insufficient native evidence: ${result.cleanNativeCalls} clean CU call(s) + ${observationImages} decodable image(s)/${axStateObservations} ax-state diff(s); effects=observed 需 ≥2 干净调用且 ≥1 张可解码观察图或含值 AX 状态 diff（动作轴仍无像素级证明，见 verifyGap）`);
	}
	result.latencyMs = Date.now() - startedAt;
	} finally {
		// NI-04（复审二）：主线/媒体/判定的任何异常（含媒体写盘 EISDIR/ENOSPC 等）都必经此收尾
		await ownedCleanup();
	}
	return result;
}

/** NI-01（复审二）：效果证明门槛——普通 JS 调用计数不升级；需证据链可信 + ≥2 干净调用 +
 *  ≥1 张可解码观察产物图（真实观察像素交付）。动作轴仍无独立像素证明（verifyGap 单列）。 */
function nativeEffectsProven(result: CodexCuRunResult, observationEvidence: number): boolean {
	return result.evidenceTrusted && result.cleanNativeCalls >= 2 && observationEvidence >= 1;
}

function num(v: unknown): number { return typeof v === "number" && Number.isFinite(v) ? v : 0; }

/** Leader-only：仅人工确认旧控制已停止后解除停止门，不开启新的源窗口。 */
export function createCodexComputerUseResetTool(deps: { enabled?: boolean; tmpRoot?: string } = {}) {
	const enabled = deps.enabled ?? codexComputerUseEnabled();
	return {
		name: "codex_computer_use_reset_stopgate",
		label: "Computer Use 停止确认",
		description: "仅 Leader 使用。旧 Computer Use 窗口提交后无法证明控制已释放时，先由用户手动退出并确认标识和光标已消失，再调用本工具弹出真实用户确认；仅解除停止门，不启动控制。无 UI、用户拒绝、源仍在途或残锁均拒绝。",
		parameters: Type.Object({}, { additionalProperties: false }),
		annotations: { readOnlyHint: false },
		executionMode: "sequential" as const,
		execute: async (_id: string, _params: unknown, signal: AbortSignal | undefined, _onUpdate: undefined, ctx: { hasUI?: boolean; ui?: RelayUi }) => {
			const reject = (message: string, error: string) => ({ content: [{ type: "text" as const, text: message }], structuredContent: { error }, isError: true });
			if (!enabled) return reject("Computer Use 未启用。", "disabled");
			if (signal?.aborted) return reject("停止确认已取消。", "cancelled");
			if (ctx.hasUI !== true || !ctx.ui) return reject("解除停止门需要真实用户 pi UI 确认；无 UI 时拒绝。", "no-ui");
			if (gateState.inflight) return reject("仍有源窗口在途或残锁待处理；拒绝解除。", "in-flight-gate");
			gateState.inflight = true;
			const lock = acquireCodexCuCrossProcessLock({ tmpRoot: deps.tmpRoot });
			if (!lock.ok) { gateState.inflight = false; return reject(`跨进程锁未释放：${lock.reason}`, "cross-process-in-flight-gate"); }
			try {
				const state = readCodexCuStopGateState({ tmpRoot: deps.tmpRoot });
				if (state.status === "none") return { content: [{ type: "text" as const, text: "当前没有待确认的停止门；未启动源窗口。" }], structuredContent: { released: false, noGate: true }, isError: false };
				const confirmed = await ctx.ui.confirm("Computer Use：确认控制已退出", "请先停止旧的 Computer Use 操作，确认受控标识及专用光标已消失。确认旧控制已停止并解除停止门？不确定请拒绝。此操作不会启动新窗口。", { signal, timeout: 120_000 });
				if (signal?.aborted) return reject("停止确认已取消。", "cancelled");
				if (confirmed !== true) return reject("用户未确认旧控制已停止，保持停止门。", "stop-confirmation-gate");
				if (!clearCodexCuCrossProcessStopGate({ tmpRoot: deps.tmpRoot })) return reject("停止门清理失败，保持关闭。", "stop-confirmation-gate-clear-failed");
				return { content: [{ type: "text" as const, text: "用户已确认旧控制停止，停止门解除；未启动新的源窗口。" }], structuredContent: { released: true }, isError: false };
			} finally { gateState.inflight = false; lock.release(); }
		},
	};
}

// ── 工具面（Leader：实验开关启用即注册；子 Agent：冻结任务声明 + 开关注册，
//    见 index.ts SUBAGENT 分支——注册/开关/授权缺一不可，不向只读角色静默放大）──────────

const CodexComputerUseParamsSchema = Type.Object({
	app: Type.String({ description: "目标应用 bundle identifier（如 com.amagi.tests.codex-native-fixture）。仅作目标声明与审计，不是强应用隔离。" }),
	objective: Type.String({ description: "交给源 Codex 的任务目标（一段短指令）。" }),
	expectedOutcome: Type.String({ description: "期望的可观察结果（用于事后核对；turn completed 不等于达成）。" }),
}, { additionalProperties: false });

export type CodexComputerUseParams = Static<typeof CodexComputerUseParamsSchema>;

const CodexComputerUseOutputSchema = Type.Object({
	route: Type.String(),
	outcome: Type.String(),
	effects: Type.String(),
	stopConfirmation: Type.String(),
	sourceTurn: Type.Unknown(),
	nativeAttempts: Type.Number(),
	cleanNativeCalls: Type.Number(),
	threadId: Type.Union([Type.String(), Type.Null()]),
	turnId: Type.Union([Type.String(), Type.Null()]),
	model: Type.Union([Type.String(), Type.Null()]),
	turnStatus: Type.Union([Type.String(), Type.Null()]),
	usage: Type.Unknown(),
	cost: Type.Unknown(),
	elicitation: Type.Unknown(),
	deniedLiteral: Type.Union([Type.String(), Type.Null()]),
	badImages: Type.Array(Type.String()),
	images: Type.Array(Type.Object({ file: Type.String(), sha256: Type.String(), bytes: Type.Number(), signatureOk: Type.Boolean(), decode: Type.Unknown() })),
	evidenceDir: Type.String(),
	evidenceTrusted: Type.Boolean(),
	turnSubmitted: Type.Boolean(),
	duplicateItems: Type.Number(),
	lateEvents: Type.Number(),
	droppedAfterClose: Type.Number(),
	foreignEvents: Type.Number(),
	serverPid: Type.Union([Type.Number(), Type.Null()]),
	serverExitObserved: Type.Boolean(),
	serverStreamsClosed: Type.Boolean(),
	serverExitCode: Type.Union([Type.Number(), Type.Null()]),
	turnCount: Type.Number(),
	interruptSent: Type.Boolean(),
	latencyMs: Type.Number(),
	warnings: Type.Array(Type.String()),
	verifyGap: Type.String(),
	imageReadCapability: Type.String(),
});

export function createCodexComputerUseTool(deps: CodexCuRunDeps & { enabled?: boolean; subagentApps?: readonly string[] } = {}): {
	name: string;
	label: string;
	description: string;
	parameters: typeof CodexComputerUseParamsSchema;
	outputSchema: typeof CodexComputerUseOutputSchema;
	annotations: { readOnlyHint: boolean };
	executionMode: "sequential";
	execute: (toolCallId: string, params: CodexComputerUseParams, signal: AbortSignal | undefined, onUpdate: undefined, ctx: {
		hasUI?: boolean;
		ui?: RelayUi;
		model?: unknown;
	}) => Promise<{ content: Array<{ type: "text"; text: string }>; structuredContent: unknown; isError: boolean; details?: unknown }>;
} {
	const enabled = deps.enabled ?? codexComputerUseEnabled();
	return {
		name: CODEX_COMPUTER_USE_TOOL_NAME,
		label: "Codex Computer Use（官方 App Server 委托）",
		description: "非浏览器原生桌面应用控制委托（官方 Codex App Server 自有实例；源 Codex 模型委托：额外模型/额度/时延单列，cost 恒 unknown）。适用：CLI/API 无法观察或操作的非浏览器桌面应用；浏览器自动化用 agent-browser（skill/MCP），不要用本工具；非必要不调用（优先 CLI/API）。仅接受 app（bundle ID，目标声明）/objective/expectedOutcome。批准策略：默认全批准（通过全部校验的 CU 批准自动 accept，输出逐次披露 default-approve-all auto=N）；AMAGI_CODEX_COMPUTER_USE_APPROVAL=manual 恢复人工转交（子 Agent 无 UI 时全部 decline→任务 blocked）；_AUTO_ACCEPT 可收窄为 bundle 白名单。目标 app 非硬隔离（不受文件 scope 约束）；source turn completed ≠ 目标达成，结果需独立核验（读截图/AX diff）；同一临时目录内跨进程单在途门；正常完成且源收尾结束后可连续调用；异常停止时用户确认后由 Leader 使用 codex_computer_use_reset_stopgate 单独解除；实验性受控入口。",
		parameters: CodexComputerUseParamsSchema,
		outputSchema: CodexComputerUseOutputSchema,
		annotations: { readOnlyHint: false },
		executionMode: "sequential", // NI-07：同批工具调用串行（另有模块级单在途门）
		execute: async (_toolCallId, params, signal, _onUpdate, ctx) => {
			const allowedKeys = ["app", "objective", "expectedOutcome"];
			const illegal = Object.keys(params ?? {}).filter((k) => !allowedKeys.includes(k));
			if (illegal.length > 0) {
				return { content: [{ type: "text" as const, text: `codex_computer_use 不接受覆盖参数：${illegal.join(", ")}（仅 ${allowedKeys.join("/")}；command/code/env/threadId/_meta/approval 一律拒绝）` }], structuredContent: { error: "illegal-params", keys: illegal }, isError: true };
			}
			if (!params?.app || !params.objective || !params.expectedOutcome) {
				return { content: [{ type: "text" as const, text: "codex_computer_use 需要 app + objective + expectedOutcome" }], structuredContent: { error: "missing-params" }, isError: true };
			}
			if (!enabled) {
				return { content: [{ type: "text" as const, text: "codex_computer_use 当前禁用（AMAGI_CODEX_COMPUTER_USE!=1）。停用即拒绝调用。" }], structuredContent: { error: "disabled" }, isError: true };
			}
			// NI-07（复审二）：门在任何 await（含停止确认 UI）之前原子占用——两个并发释放者只有一个
			// 能进入；所有拒绝/异常路径在外层 finally 释放；stopGate 在持门期间清除（同一代窗口）。
			if (gateState.inflight) {
				return { content: [{ type: "text" as const, text: "codex_computer_use 已有一个在途源窗口（单在途门）。本实例同一时间只允许一个源模型窗口。" }], structuredContent: { error: "in-flight-gate" }, isError: true };
			}
			gateState.inflight = true;
			// 跨进程单在途门（NI-07 补齐）：Leader 与 JSON 子 Agent 是独立进程，模块级 gate 仅进程内。
			// O_EXCL 文件锁互斥（同机 tmpdir）；失败拒绝（不排队）——并发窗口必须显式失败而非静默重叠。
			const crossLock = acquireCodexCuCrossProcessLock({ tmpRoot: deps.tmpRoot });
			if (!crossLock.ok) {
				gateState.inflight = false;
				return { content: [{ type: "text" as const, text: `codex_computer_use 跨进程单在途门拒绝：${crossLock.reason}。本机同一时间只允许一个 codex_computer_use 源窗口（Leader/子 Agent 共享此门）。` }], structuredContent: { error: "cross-process-in-flight-gate", reason: crossLock.reason }, isError: true };
			}
			let r: CodexCuRunResult;
			// steer #10：stopgate 必须在仍持锁时写入（防 unlock-before-gate 窗口——锁释放后另一
			// 进程可启动，若门尚未落盘则其读不到门直接开窗）；写入失败或 run 异常而来源状态未知
			// 时锁保持不释放（fail-closed，需人工确认源已停止后清理门目录），不假称已落盘。
			let keepCrossLock = false;
			try {
				// 持跨进程锁读取共享停止门。其他进程完成恢复后，本进程直接看到最新状态。
				const crossState = readCodexCuStopGateState({ tmpRoot: deps.tmpRoot });
				if (crossState.status === "corrupt") {
					if (ctx.hasUI !== true || !ctx.ui) {
						return { content: [{ type: "text" as const, text: `跨进程停止确认门状态文件损坏（无法判定旧源窗口输入是否已停止；${crossState.raw}）——保守拒绝：需真实用户在 Leader UI 确认旧源已停止并清理 stopgate 状态后重试；子 Agent 无 UI 通道，请向 Leader 报告。` }], structuredContent: { error: "stop-confirmation-gate-corrupt" }, isError: true };
					}
					const release = await ctx.ui.confirm(
						"codex_computer_use：停止确认门状态损坏",
						"跨进程停止确认门状态文件无法解析（无法判定旧源窗口输入是否已停止）。仅在确认旧源已停止输入后授权清理并继续；不确定请拒绝并人工检查。",
						{ signal, timeout: 120_000 },
					);
					if (signal?.aborted || release !== true) {
						return { content: [{ type: "text" as const, text: "用户未确认旧源输入已停止；保持关闭（状态文件未清理）。" }], structuredContent: { error: "stop-confirmation-gate-corrupt", released: false }, isError: true };
					}
					if (!clearCodexCuCrossProcessStopGate({ tmpRoot: deps.tmpRoot })) {
						return { content: [{ type: "text" as const, text: "停止确认门清理失败；保守拒绝新窗口。" }], structuredContent: { error: "stop-confirmation-gate-clear-failed" }, isError: true };
					}
				} else if (crossState.status === "gate") {
					const crossGate = crossState.gate;
					if (ctx.hasUI !== true || !ctx.ui) {
						return { content: [{ type: "text" as const, text: `跨进程停止确认门：进程 pid ${crossGate.pid} 的源窗口（app=${crossGate.app}, turn=${crossGate.turnId ?? "unknown"}）以输入停止未确认结束（${crossGate.reason}）。新窗口需真实用户在 Leader UI 确认后释放；子 Agent 无 UI 通道，拒绝开放（向 Leader 报告由其确认）。` }], structuredContent: { error: "stop-confirmation-gate", crossProcess: crossGate }, isError: true };
					}
					const release = await ctx.ui.confirm(
						"codex_computer_use：跨进程旧源窗口输入停止确认",
						`进程 pid ${crossGate.pid} 已提交的源窗口（app=${crossGate.app}, turn=${crossGate.turnId ?? "unknown"}）以「${crossGate.reason}」结束，输入停止未经协议证明。请先确认受控标识与专用光标已消失、旧源已停止，再授权新的受控窗口。`,
						{ signal, timeout: 120_000 },
					);
					if (signal?.aborted || release !== true) {
						return { content: [{ type: "text" as const, text: "用户未确认旧源输入已停止或未授权新窗口，停止门保持关闭。" }], structuredContent: { error: "stop-confirmation-gate", crossProcess: crossGate, released: false }, isError: true };
					}
					if (!clearCodexCuCrossProcessStopGate({ tmpRoot: deps.tmpRoot })) {
						return { content: [{ type: "text" as const, text: "停止确认门清理失败；保守拒绝新窗口。" }], structuredContent: { error: "stop-confirmation-gate-clear-failed" }, isError: true };
					}
				}
				try {
					r = await runCodexComputerUse({
						app: params.app, objective: params.objective, expectedOutcome: params.expectedOutcome,
						ui: ctx.ui, hasUI: ctx.hasUI === true, signal, ownsModel: ctx.model, deps,
					});
				} catch (runErr) {
					// run 异常而来源状态未知：锁保持占用（fail-closed），异常上抛由宿主记工具错误。
					keepCrossLock = true;
					throw runErr;
				}
				// 异常轮次挂停止门；正常收尾不要求额外人工确认。
				// 保留真实停止状态，不将流程收尾解释为系统控制释放证据。
				// 写入在持锁期间原子完成；写失败则锁不释放并披露人工恢复路径。
				const completedAndClosed = r.sourceTurn.completed && r.evidenceTrusted
					&& r.events.serverExitObserved && r.events.serverStreamsClosed;
				// 正常轮次及自有源收尾完成即可继续；这不声称已验证系统光标释放。
				if (r.turnSubmitted && !completedAndClosed && (r.stopConfirmation !== "confirmed" || !r.evidenceTrusted)) {
					const reason = !r.evidenceTrusted ? "证据链不可信" : `输入释放未确认 (${r.stopConfirmation})`;
					r.warnings.push("无法证明 Computer Use 控制标识与光标已退出；如仍显示，请用户手动按物理 Esc，并在确认退出后再授权下一窗口");
					const wrote = writeCodexCuCrossProcessStopGate({ app: params.app, threadId: r.threadId, turnId: r.turnId, reason, pid: process.pid, at: Date.now() }, { tmpRoot: deps.tmpRoot });
					if (!wrote) {
						keepCrossLock = true;
						r.warnings.push("跨进程停止确认门写入失败（tmpdir 满或权限问题）——锁保持占用（fail-closed）：需真实用户确认旧源输入已停止后人工清理门目录（<tmpdir>/amagi-codex-computer-use-gate/）并重启会话；不自动重试、不假称已落盘");
					}
				}
				if (r.serverPid !== null && (!r.events.serverExitObserved || !r.events.serverStreamsClosed)) {
					keepCrossLock = true;
					r.warnings.push("本次源进程退出或 stdio 关闭未确认，跨进程锁继续保留；须先核实自有源及可能的子进程已停止，再由用户人工恢复残锁");
				}
			} finally {
				if (!keepCrossLock) gateState.inflight = false;
				if (!keepCrossLock) crossLock.release();
			}
			const cap = imageReadCapability(ctx.model);
			const el = r.elicitationRelay;
			const lines = [
				`[codex_computer_use] route=${r.route} model=${r.model ?? "unknown"} turn=${r.sourceTurn.status ?? "none"} outcome=${r.outcome} effects=${r.effects} stopConfirmation=${r.stopConfirmation}${r.evidenceTrusted ? "" : " evidenceTrusted=false"}`,
				`target: ${params.app}`,
				`native: attempts=${r.nativeAttempts} cleanCalls=${r.cleanNativeCalls} obsImages=${r.images.filter((i) => i.signatureOk && i.decode.status === "passed").length} axState=${r.events.mcpToolCalls.filter((c) => c.server !== undefined && OFFICIAL_CU_SERVERS.has(c.server) && c.status === "completed" && c.resultText !== null && AX_DIFF_STATE_RE.test(c.resultText) && /Value:/.test(c.resultText)).length}（effects=observed 需 ≥2 干净调用且 ≥1 可解码观察图或含值 AX diff；普通 JS 调用计数不升级为效果；动作轴无像素级证明）`,
				`elicitation: received=${el.received} humanDecided=${el.humanDecided} accepted=${el.accepted}${el.autoAccepted > 0 ? ` (pre-authorized auto=${el.autoAccepted})` : ""} declined=${el.declined} unsupported=${el.unsupported} foreign=${el.foreign}${el.notes.length ? ` | ${el.notes.join("; ")}` : ""}`,
				`source refs: thread=${r.threadId ?? "missing"} turn=${r.turnId ?? "missing"} turns=${r.turnCount} interrupt=${r.interruptSent} serverExitObserved=${r.events.serverExitObserved} serverStreamsClosed=${r.events.serverStreamsClosed}`,
				r.usage ? `usage: input ${r.usage.inputTokens} (cached ${r.usage.cachedInputTokens}) / output ${r.usage.outputTokens} / reasoning ${r.usage.reasoningOutputTokens}` : "usage: unknown",
				`cost: unknown（source 未提供 price/cost；额外 Codex 模型额度适用，不编造费率）`,
				r.images.length ? `images: ${r.images.map((i) => `${i.file} (${i.bytes}B decode=${i.decode.status})`).join(", ")}` : "images: none",
				r.badImages.length ? `bad images: ${r.badImages.join(", ")}` : "",
				`evidence: ${r.evidenceDir || "(none — 未派发)"}`,
				`latency: ${r.latencyMs}ms${r.warnings.length ? ` | warnings: ${r.warnings.join("; ")}` : ""}`,
				`verifyGap: 源 turn ${r.sourceTurn.completed ? "completed" : r.sourceTurn.status ?? "未完成"} ≠ 目标达成；effects=${r.effects} 为源事件口径（未独立像素核验）；输入停止未经协议证明（${r.stopConfirmation}）。外层任务仍按三轴验收。`,
				`imageReadCapability=${cap}${r.images.length ? `（图片 bytes 未注入文本；用 read 读取 ${r.images[0].file}）` : ""}`,
			].filter((l) => l !== "");
			const structured = {
				route: r.route, outcome: r.outcome, effects: r.effects, stopConfirmation: r.stopConfirmation,
				sourceTurn: r.sourceTurn, nativeAttempts: r.nativeAttempts, cleanNativeCalls: r.cleanNativeCalls,
				threadId: r.threadId, turnId: r.turnId, model: r.model, turnStatus: r.sourceTurn.status,
				usage: r.usage, cost: r.cost, elicitation: el, deniedLiteral: r.deniedLiteral, badImages: r.badImages,
				images: r.images.map((i) => ({ file: i.file, sha256: i.sha256, bytes: i.bytes, signatureOk: i.signatureOk, decode: i.decode })),
				evidenceDir: r.evidenceDir, evidenceTrusted: r.evidenceTrusted, turnSubmitted: r.turnSubmitted,
				duplicateItems: r.events.duplicateItems, lateEvents: r.events.lateEvents, droppedAfterClose: r.events.droppedAfterClose,
				foreignEvents: r.events.foreignEvents,
				serverPid: r.serverPid, serverExitObserved: r.events.serverExitObserved, serverStreamsClosed: r.events.serverStreamsClosed, serverExitCode: r.events.serverExitCode,
				turnCount: r.turnCount, interruptSent: r.interruptSent, latencyMs: r.latencyMs,
				warnings: r.warnings,
				verifyGap: "source-turn ≠ goal accepted; effects 未独立核验; 输入停止 unconfirmed/unsupported; cost unknown",
				imageReadCapability: cap,
			};
			const isError = r.outcome !== "completed";
			return { content: [{ type: "text" as const, text: lines.join("\n") }], structuredContent: structured, isError, details: { evidenceDir: r.evidenceDir } };
		},
	};
}
