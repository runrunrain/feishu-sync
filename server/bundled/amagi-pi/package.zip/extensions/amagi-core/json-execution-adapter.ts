/**
 * json-execution-adapter.ts — amagi-pi v2 K4：JSON 后端执行适配器（方案 §3.1/§3.3/§8.1-K4）。
 *
 * 实现 K1 execution-port.ts 的 ExecutionPort：
 *  - capabilities() = { backend: "json", resume: true, adjust: false }（派生 pi 子进程后端；会话可 resume；
 *    不支持运行中 adjust——unsupported 语义由调用方按能力声明判定）。
 *  - start(spec, key, emit)：复用 runPiTask 唯一 spawn 引擎（不建第二套执行链、不并行双写）；进程句柄只留
 *    本适配器私有 Map（§3.2：不进公开 View/持久化对象；registry.child 仅引擎侧迁移期兼容投影）。
 *    观察流：启动 emit started → 会话建立 emit session → 活动摘要 emit activity（限流沿用引擎
 *    ACTIVITY_NOISE 白名单）→ 退出 emit exited（exitCode + 终稿引用 activity 前置事件）；
 *    observationSeq 单后端内严格递增，重复 close/迟到 exit 只报告一次有效退出（task-run 侧 relay
 *    门锁 + 本适配器槽状态幂等——内核低序号保护（§3.3 observe）之外的两道适配器侧闸）。
 *  - stop(handle, reason)：requested=停止请求已送达（进程组 SIGTERM→宽限 SIGKILL 链，退出事实经 exited
 *    观察确认，§3.3「请求取消不等于已确认退出」）；confirmed=已观察到退出（携带 exitCode）；
 *    unknown=句柄不属于本适配器。pending 槽（spawn 前）登记停止请求，spawn 即终止。
 *
 * 依赖方向：json-execution-adapter → { task-run（唯一 spawn 入口）, execution-port/contracts（纯契约类型）}；
 * 本模块不 import task-registry（状态写权在内核——N1 后端只报告观察；registry 记录由内核投影/桥维护）。
 * 槽位归还（N4）不在本端口职责内：由准入层在 finalize/onFinalize 链恰好一次释放，取消请求不提前释放存活进程槽位。
 */
import { randomUUID } from "node:crypto";
import type { AgentConfig } from "./agents-loader.ts";
import type { ExecutionCapabilities, ExecutionHandle, ExecutionPort, ObservationSink, StopObservation } from "./execution-port.ts";
import type { TaskSpec } from "./contracts/task.ts";
import type { TaskKey } from "./contracts/view.ts";
import { runPiTask, type BackgroundStart, type PiTaskOpts } from "./task-run.ts";

/** 适配器工厂依赖（测试/K5a 注入面；缺省合成最小合法 AgentConfig + pi 本体调用）。 */
export interface JsonExecutionAdapterDeps {
	/** spawn 命令覆写（fake runner / 受控调用面）；缺省走引擎 getPiInvocation（pi 本体）。 */
	command?: { command: string; args: string[] };
	/** spec.agent → 完整角色卡解析；缺省合成最小合法卡（type=expert——完成契约标注适用面）。 */
	resolveAgent?: (agentName: string) => AgentConfig | undefined;
	/** 透传 runPiTask opts（signal/timeoutMs/边界路径/onFinalize 等；观察面字段由适配器自持，不可覆写）。 */
	runOpts?: Partial<Omit<PiTaskOpts, "cwd" | "model" | "background" | "observation" | "command">>;
}

/** 运行槽（适配器私有；state 推进由观察回流与句柄回投驱动，幂等）。
 *  ev-20261019-06c169：closed＝运行未 spawn 即结束（启动失败/预启动取消）——与 exited（真实物理退出
 *  观察）区分：stop 的事实来自真实进程状态，未启动失败不声称物理退出、不伪造 exitCode。 */
interface RunSlot {
	state: "pending" | "alive" | "exited" | "closed";
	child?: { kill?: (sig?: string) => void; __amagiTerminateOwnedRun?: (reason: string) => void };
	exitCode?: number | null;
	/** pending 期到达的停止请求（spawn 即终止）。 */
	pendingStop?: string;
}

/** 句柄槽有界保留（已退出槽保留 exitCode 供 stop confirmed 语义；FIFO 淘汰最旧）。 */
const MAX_SLOTS = 128;

function minimalAgent(name: string): AgentConfig {
	return { name, frontmatterName: name, description: "", type: "expert", tools: [], systemPrompt: "", filePath: "" };
}

/** 终止链：优先引擎挂载的幂等组级入口（POSIX 进程组 SIGTERM→3s→身份复核后 SIGKILL）；非组模式 child 级同款宽限。 */
function terminateSlot(slot: RunSlot, reason: string): void {
	const child = slot.child;
	if (!child) return;
	const groupTerm = child.__amagiTerminateOwnedRun;
	if (typeof groupTerm === "function") {
		try { groupTerm(reason); return; } catch { /* 组级失败退回 child 级 */ }
	}
	if (typeof child.kill === "function") {
		try { child.kill("SIGTERM"); } catch { /* ESRCH 静默 */ }
		const t = setTimeout(() => { try { child.kill?.("SIGKILL"); } catch { /* ESRCH 静默 */ } }, 3000);
		t.unref?.();
	}
}

export function createJsonExecutionAdapter(deps: JsonExecutionAdapterDeps = {}): ExecutionPort {
	// backendRunId → 运行槽（私有句柄映射，§3.2）
	const slots = new Map<string, RunSlot>();
	const slotOrder: string[] = [];
	const track = (backendRunId: string): RunSlot => {
		const slot: RunSlot = { state: "pending" };
		slots.set(backendRunId, slot);
		slotOrder.push(backendRunId);
		while (slotOrder.length > MAX_SLOTS) slots.delete(slotOrder.shift()!);
		return slot;
	};

	return {
		capabilities(): Readonly<ExecutionCapabilities> {
			return { backend: "json", resume: true, adjust: false };
		},

		async start(spec: Readonly<TaskSpec>, key: TaskKey, emit: ObservationSink): Promise<ExecutionHandle> {
			const taskId = spec.specId; // K3 裁量：taskId = spec.specId（一 spec 一 run）
			const backendRunId = `json-${randomUUID()}`;
			const slot = track(backendRunId);
			// 观察回流包装：exited 事件幂等推进槽状态（stop confirmed 语义的数据源；重复回流无副作用），再交调用方 sink。
			const wrappedEmit: ObservationSink = async (observation) => {
				if (observation.backendRunId === backendRunId && observation.event.kind === "exited") {
					slot.state = "exited";
					slot.exitCode = observation.event.exitCode;
					slot.child = undefined;
				}
				return emit(observation);
			};
			const agent = deps.resolveAgent?.(spec.agent) ?? minimalAgent(spec.agent);
			const sessionName = `amagi/${spec.agent}/${taskId.slice(0, 8)}`;
			const model = spec.effective.model && spec.effective.model !== "unknown" ? spec.effective.model : undefined;
			const args = ["--mode", "json", "-p", "--name", sessionName];
			if (model) args.push("--model", model);
			args.push(spec.assignment);
			const opts: PiTaskOpts = {
				cwd: spec.workspace.cwd,
				model,
				background: true,
				...(deps.command ? { command: deps.command } : {}),
				...(deps.runOpts ?? {}),
				observation: {
					key,
					backendRunId,
					emit: wrappedEmit,
					onProcess: (child) => {
						if (child) {
							slot.child = child;
							slot.state = "alive";
							if (slot.pendingStop !== undefined) terminateSlot(slot, slot.pendingStop); // pending 期停止请求：spawn 即终止
						} else {
							slot.child = undefined;
						}
					},
				},
			};
			const res = await runPiTask(agent, args, opts, taskId, sessionName);
			// runPiTask 同步早退（未 spawn：启动失败/启动前取消）——运行已结束但无物理退出观察
			//（ev-20261019-06c169：引擎不再为未 spawn 的尝试合成 started/exited；slot 收口为 closed，不伪造 exitCode）。
			const started = typeof (res as BackgroundStart).agent === "string" && ((res as BackgroundStart).status === "running" || (res as BackgroundStart).status === "queued");
			if (!started) {
				slot.state = "closed";
				slot.child = undefined;
			}
			return { key, backendRunId };
		},

		async stop(handle: ExecutionHandle, reason: string): Promise<StopObservation> {
			const slot = slots.get(handle.backendRunId);
			if (!slot) return { status: "unknown", at: Date.now(), detail: "句柄不属于本适配器（未知运行）" };
			if (slot.state === "exited") {
				const exitCode = slot.exitCode;
				return {
					status: "confirmed",
					at: Date.now(),
					...(exitCode === null || exitCode === undefined ? {} : { exitCode }),
					detail: "已观察到退出（exited 观察回流；exitCode 随观察携带）",
				};
			}
			if (slot.state === "closed") {
				// ev-20261019-06c169：未 spawn 即结束——运行已终、无残留进程；无物理退出事实，不携带 exitCode。
				return { status: "confirmed", at: Date.now(), detail: "运行未启动即结束（启动失败/预启动取消）——无残留进程可停；未观察到物理退出，不伪造 exitCode" };
			}
			if (slot.state === "pending") {
				slot.pendingStop = reason;
				return { status: "requested", at: Date.now(), detail: "进程未启动：停止请求已登记，spawn 即终止（退出事实经 exited 观察确认）" };
			}
			terminateSlot(slot, reason);
			return { status: "requested", at: Date.now(), detail: "停止请求已送达（进程组 SIGTERM→宽限 SIGKILL 链）；退出事实经 exited 观察确认，不在此冒充确认" };
		},
	};
}
