/**
 * tool-presentation.ts — B4（十月迭代设计 §5.1）：工具卡统一语义投影（纯函数层）。
 *
 * 职责（单一）：把七家族 wire（task-query/mcp-call/mcp-list/handbook/run-bg/evolution/lsp）
 * 的 structuredContent、既有 details 块、或纯文本结果投影为统一呈现语义模型
 * ToolPresentation——TUI 工具卡（tool-renderers.ts）与 WebUI（webui/agent-session.ts、
 * webui/server.ts）消费**同一模型、同一三轴口径**（设计裁定「共享语义投影，TUI 与
 * WebUI 各自渲染」——三端一致指同一语义字段、同一错误与三轴口径，不要求像素相同）。
 *
 * 纪律（§5.1）：
 *  - 零 I/O、零 TUI、零宿主运行时依赖（仅 import 七家族 wire 纯模块的身份常量 +
 *    panel-model 的 axisLabelOf——三轴标签语义单源，不实现第二套业务语义）；
 *    **不定义第二份 wire schema**——判据只是 kind/wireVersion/schemaVersion 字面核对，
 *    字段消费按各 wire 模块已冻结的 TypeScript 接口形状防御读取。
 *  - 证据强度分层（历史边界，测试先行）：
 *      source="wire"   实时 wire 帧（structuredContent 经身份核对）→ completeness="complete"；
 *      source="details" 无 wire 但 details 已有可证明字段（任务族 ToolDetailsBlock /
 *                      ContractError details / mcp_call 调用面 details）→ "partial"，
 *                      只投影可证明字段，未给三轴就不拼出 accepted；
 *      source="text"   纯文本历史 → "unknown"，只做安全摘要 + 原文，不伪造结构。
 *    会话历史（pi ToolResultMessage）只持久化 content/details——**structuredContent 不入
 *    历史**（pi-agent-core dist/types.d.ts ToolResultMessage 无该键，agent-loop.js 只落
 *    content/details/usage/isError），故 resume 历史天然只有 details/text 两档。
 *  - 错误判定：outcome 只从 isError / wire 自带 ok/isError 分支字段推导，**禁止以字段
 *    存在推定成功**（§5.1 验收「业务错不变绿」）。
 *  - 不可信值处理：外部 toolName、错误消息、长路径、正文文本按不可信值——展示前剥
 *    ANSI 转义与控制序列（sanitizePresentationText）；fact 值压单行并按 code point 截断。
 *    凭据不在本层二次脱敏：wire 载体在生成侧已过 redactCredentials（各 wire 模块单源），
 *    本层不重复实现匹配规则（避免第二套阈值）。
 *  - 未识别工具名 → undefined（调用方交回 next()/default）；识别工具名但 structuredContent
 *    版本未知 → 不升 wire 档，按 details/text 降级（不伪造、不保留过期结构）。
 *
 * 历史替换禁令（§5.1）：本层无状态、零 I/O——不查询当前任务状态替换历史状态、不重执行
 * MCP 补数据；首版不新增持久化 wire 副本，不改变 content/details 契约。
 */
import { axisLabelOf } from "./panel-model.ts";
import {
	TASK_QUERY_WIRE_KIND, TASK_QUERY_WIRE_VERSION, TASK_QUERY_SCHEMA_VERSION,
} from "./task-query-wire.ts";
import {
	MCP_WIRE_CALL_KIND, MCP_WIRE_LIST_KIND, MCP_WIRE_VERSION, MCP_SCHEMA_VERSION,
	MCP_CALL_WIRE_VERSION, MCP_CALL_SCHEMA_VERSION,
} from "./mcp-wire.ts";
import {
	HANDBOOK_WIRE_KIND, HANDBOOK_WIRE_VERSION, HANDBOOK_SCHEMA_VERSION,
} from "./handbook-wire.ts";
import {
	RUN_BG_WIRE_KIND, RUN_BG_WIRE_VERSION, RUN_BG_SCHEMA_VERSION,
} from "./run-bg-wire.ts";
import {
	EVOLUTION_WIRE_KIND, EVOLUTION_WIRE_VERSION, EVOLUTION_SCHEMA_VERSION,
} from "./evolution-wire.ts";
import {
	LSP_WIRE_KIND, LSP_WIRE_VERSION, LSP_SCHEMA_VERSION,
} from "./lsp-wire.ts";

// ── 语义模型（设计 §5.1 冻结形状；内部接口，不是宿主 API） ─────────────────────

export type PresentationSource = "wire" | "details" | "text";
export type PresentationCompleteness = "complete" | "partial" | "unknown";
export type PresentationOutcome = "success" | "error" | "running" | "unknown";

export interface ToolPresentationFact {
	label: string;
	value: string;
}

export interface ToolPresentationAxes {
	execution: string;
	settlement: string;
	acceptance: string;
}

export interface ToolPresentation {
	version: 1;
	toolName: string;
	source: PresentationSource;
	completeness: PresentationCompleteness;
	title: string;
	outcome: PresentationOutcome;
	facts: ToolPresentationFact[];
	axes?: ToolPresentationAxes;
	excerpt: string;
}

/** 投影输入：宿主 AgentToolResult 的只读子集——实时（含 structuredContent）与历史
 *  ToolResultMessage（content/details/isError）同形兼容。 */
export interface PresentationResultShape {
	content?: ReadonlyArray<{ type?: string; text?: unknown }>;
	details?: unknown;
	structuredContent?: unknown;
	isError?: boolean;
}

// ── 覆盖工具清单（resolver 选择面；wire 七家族 + details 档任务族含 legacy） ────

/**
 * amagi 自有工具名单（§5.1「resolver 对 amagi 自有工具明确选择新 renderer；其它工具
 * next() 原样保留」）。wire 档七家族；task_submit/task_resume/task_control 与 legacy
 * task/query_task 无 wire 但 details 携可证明三轴字段——按 details 档投影。
 */
export const PRESENTATION_TOOL_NAMES: readonly string[] = [
	// wire 七家族
	"task_query",
	"mcp_call",
	"mcp_list_tools",
	"amagi_handbook",
	"run_bg",
	"amagi_evolution",
	"lsp",
	// details 档（ToolDetailsBlock / ContractError details）
	"task_submit",
	"task_resume",
	"task_control",
	"task",
	"query_task",
];

export function isAmagiPresentationTool(toolName: string): boolean {
	return PRESENTATION_TOOL_NAMES.includes(toolName);
}

// ── 展示安全小件（不可信值 → 安全文本） ──────────────────────────────────────

/** ANSI 转义序列（CSI/OSC 简形）与其余控制字符（保留 \t；\n 由单行化处理）。 */
const ANSI_OR_CONTROL = /(?:\u001b\[[0-9;?]*[ -/]*[@-~]|\u001b\][^\u0007\u001b]*(?:\u0007|\u001b\\)?)|[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g;

/** 展示安全化：剥 ANSI 转义与控制序列（§5.1「展示时移除不可信 ANSI/控制序列」）。 */
export function sanitizePresentationText(text: string): string {
	return text.replace(ANSI_OR_CONTROL, "");
}

/** code point 截断（UTF-16 不切半代理对；与 webui/task-panel capChars 同规则）。 */
function capChars(value: string, maxChars: number): string {
	if (value.length <= maxChars) return value;
	let count = 0, i = 0;
	while (i < value.length && count < maxChars) {
		i += value.codePointAt(i)! > 0xffff ? 2 : 1;
		count++;
	}
	return value.slice(0, i);
}

/** fact 值单行化 + 安全化 + 截断（label/value 均为展示文本）。 */
function factValueOf(value: unknown, maxChars = 120): string {
	if (typeof value === "string") return capChars(sanitizePresentationText(value).replace(/\s+/g, " ").trim(), maxChars);
	if (typeof value === "number" && Number.isFinite(value)) return String(value);
	if (typeof value === "boolean") return String(value);
	if (value === null || value === undefined) return "";
	return capChars(sanitizePresentationText(String(value)).replace(/\s+/g, " ").trim(), maxChars);
}

function fact(label: string, value: unknown, maxChars?: number): ToolPresentationFact | null {
	const v = factValueOf(value, maxChars);
	return v === "" ? null : { label, value: v };
}

function factsOf(...maybe: Array<ToolPresentationFact | null>): ToolPresentationFact[] {
	return maybe.filter((f): f is ToolPresentationFact => f !== null);
}

/** 摘要上限（code point）：卡片单行摘要边界；展开原文由渲染层自理（本层只供摘要）。 */
export const PRESENTATION_EXCERPT_CAP = 200;

/** content 文本块拼接 → 安全摘要（多行压单行、剥控制序列、截断）。 */
function excerptOf(result: Readonly<PresentationResultShape>): string {
	const blocks = Array.isArray(result.content) ? result.content : [];
	const parts: string[] = [];
	for (const b of blocks) {
		if (b && typeof b === "object" && b.type === "text" && typeof b.text === "string") parts.push(b.text);
	}
	const joined = parts.join("\n").replace(/\s+/g, " ").trim();
	return capChars(sanitizePresentationText(joined), PRESENTATION_EXCERPT_CAP);
}

// ── wire 身份核对（判据 = kind + wireVersion + schemaVersion；不含 surfaceVersion——
//    mcp 家族按其模块裁定不携带该字段） ─────────────────────────────────────────

interface WireIdentity { kind: string; wireVersion: number; schemaVersion: number }

function wireIdentityOf(v: unknown): WireIdentity | null {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return null;
	const w = v as Record<string, unknown>;
	if (typeof w.kind !== "string") return null;
	if (typeof w.wireVersion !== "number" || typeof w.schemaVersion !== "number") return null;
	return { kind: w.kind, wireVersion: w.wireVersion, schemaVersion: w.schemaVersion };
}

/** wire 自带错误分支判定：ok===false 或 isError===true（两字段在全部家族成对出现；
 *  只认显式字段，不以 data 存在推定成功）。 */
function wireIsError(w: Record<string, unknown>): boolean {
	return w.ok === false || w.isError === true;
}

// ── 各家族 wire facts（字段按各 wire 模块冻结接口防御读取——本层不做完整 schema 校验，
//    身份核对已过才进来；异常字段读出 null/缺席即略，不臆造） ───────────────────

function num(v: unknown): string | null {
	return typeof v === "number" && Number.isFinite(v) ? String(v) : null;
}

function axesOfItem(item: unknown): ToolPresentationAxes | null {
	if (typeof item !== "object" || item === null) return null;
	const o = item as Record<string, unknown>;
	if (typeof o.execution !== "string" || typeof o.settlement !== "string" || typeof o.acceptance !== "string") return null;
	return { execution: o.execution, settlement: o.settlement, acceptance: o.acceptance };
}

/** 三轴 fact 值：axisLabelOf 优先（panel-model 单源口径），未知状态回退原字面拼接
 *  （axisLabelOf 对未知 execution 返回 undefined——不折叠为 done/accepted）。 */
function axisFactValue(axes: ToolPresentationAxes): string {
	const label = axisLabelOf(axes);
	return label ?? `${axes.execution}/${axes.settlement}/${axes.acceptance}`;
}

function projectTaskQueryWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const isError = wireIsError(w) || result.isError === true;
	const view = typeof w.view === "string" ? w.view : null;
	const title = view ? `${toolName} · ${view} 档` : toolName;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title,
			outcome: "error",
			facts: factsOf(
				fact("错误码", e.code),
				fact("错误", e.message, 160),
				fact("副作用", e.effects),
				view ? fact("档位", view) : null,
			),
			excerpt: excerptOf(result),
		};
	}
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	const page = (typeof data.page === "object" && data.page !== null ? data.page : {}) as Record<string, unknown>;
	const items = Array.isArray(page.items) ? page.items : [];
	const legacy = (typeof data.legacy === "object" && data.legacy !== null ? data.legacy : {}) as Record<string, unknown>;
	const first = items.length === 1 ? axesOfItem(items[0]) : null; // 单任务查询才升三轴（多任务页不拿首条代表全页）
	const facts = factsOf(
		first ? fact("三轴", axisFactValue(first)) : null,
		fact("任务数", items.length > 0 ? String(items.length) : null),
		fact("遗留记录", num(legacy.total)),
		fact("snapshotSeq", num(page.snapshotSeq)),
	);
	// receipt 档单任务：receiptId 全字面（§5.1「receipt 对应完整 receiptId 的数据不被短形展示替代」）
	if (view === "receipt" || view === "output") {
		if (items.length === 1 && typeof items[0] === "object" && items[0] !== null) {
			const r = (items[0] as Record<string, unknown>).receipt;
			if (typeof r === "object" && r !== null && typeof (r as Record<string, unknown>).receiptId === "string") {
				facts.push({ label: "receiptId", value: (r as Record<string, unknown>).receiptId as string });
			}
		}
	}
	return {
		version: 1, toolName, source: "wire", completeness: "complete", title,
		outcome: "success",
		facts,
		...(first ? { axes: first } : {}),
		excerpt: excerptOf(result),
	};
}

function projectMcpWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const isError = wireIsError(w) || result.isError === true;
	const server = typeof w.server === "string" ? w.server : null;
	const tool = typeof w.tool === "string" ? w.tool : null;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete",
			title: toolName + (server || tool ? ` · ${[server, tool].filter(Boolean).join("/")}` : ""),
			outcome: "error",
			facts: factsOf(
				fact("错误码", e.code),
				fact("错误", e.message, 160),
				fact("副作用", e.effects),
				e.remoteResult != null ? fact("远端业务错", "远端已应答错误载荷") : null,
			),
			excerpt: excerptOf(result),
		};
	}
	if (w.kind === MCP_WIRE_LIST_KIND) {
		const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
		const servers = Array.isArray(data.servers) ? data.servers : [];
		const toolTotal = servers.reduce((n, s) =>
			n + (typeof s === "object" && s !== null && Array.isArray((s as Record<string, unknown>).tools)
				? ((s as Record<string, unknown>).tools as unknown[]).length : 0), 0);
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title: toolName,
			outcome: "success",
			facts: factsOf(
				fact("server 数", String(servers.length)),
				fact("可见工具数", toolTotal > 0 || servers.length === 0 ? String(toolTotal) : null),
				servers.length > 0 ? fact("server", servers.slice(0, 3).map((s) =>
					typeof s === "object" && s !== null && typeof (s as Record<string, unknown>).name === "string"
						? (s as Record<string, unknown>).name : "?").join(", ")) : null,
			),
			excerpt: excerptOf(result),
		};
	}
	// mcp_call 成功
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	return {
		version: 1, toolName, source: "wire", completeness: "complete",
		title: toolName + (server || tool ? ` · ${[server, tool].filter(Boolean).join("/")}` : ""),
		outcome: "success",
		facts: factsOf(
			fact("载荷", data.payloadState),
			data.payloadBytes != null ? fact("载荷字节", num(data.payloadBytes)) : null,
			data.textTruncated === true ? fact("文本截断", "已截断（原文见结果）") : null,
			data.schemaSource === "remote-output" ? fact("输出声明", "远端 outputSchema 在场") : null,
		),
		excerpt: excerptOf(result),
	};
}

function projectHandbookWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const action = typeof w.action === "string" ? w.action : null;
	const isError = wireIsError(w) || result.isError === true;
	const title = action ? `${toolName} · ${action}` : toolName;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title,
			outcome: "error",
			facts: factsOf(fact("错误码", e.code), fact("错误", e.message, 160)),
			excerpt: excerptOf(result),
		};
	}
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	let facts: ToolPresentationFact[];
	switch (action) {
		case "query":
			facts = factsOf(
				fact("命中", num(data.matched)),
				fact("返回", num(data.returned)),
				data.truncated === true ? fact("截断", "matched>returned") : null,
			);
			break;
		case "show":
			facts = factsOf(fact("条目", data.id), fact("状态", data.status), fact("分区", data.section));
			break;
		case "stats":
			facts = factsOf(fact("总条目", num(data.total)), fact("字节数", num(data.bytes)));
			break;
		case "lifecycle":
			facts = factsOf(
				fact("条目", data.id),
				fact("迁移", data.from != null && data.to != null ? `${String(data.from)} → ${String(data.to)}` : null),
				data.changed === true ? fact("落盘", "sidecar 已持久") : null,
			);
			break;
		default:
			facts = [];
	}
	return { version: 1, toolName, source: "wire", completeness: "complete", title, outcome: "success", facts, excerpt: excerptOf(result) };
}

function projectRunBgWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const action = typeof w.action === "string" ? w.action : null;
	const isError = wireIsError(w) || result.isError === true;
	const title = action ? `${toolName} · ${action}` : toolName;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title,
			outcome: "error",
			facts: factsOf(fact("错误码", e.code), fact("错误", e.message, 160)),
			excerpt: excerptOf(result),
		};
	}
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	if (action === "list") {
		const records = Array.isArray(data.records) ? data.records : [];
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title, outcome: "success",
			facts: factsOf(fact("记录数", num(data.returned) ?? String(records.length)), data.truncated === true ? fact("截断", "超 30 条") : null),
			excerpt: excerptOf(result),
		};
	}
	// start/status/result/cancel：句柄状态投影（state=failed 是业务事实——ok=true 不变绿歧义：
	// outcome=success 表示工具调用成功；进程失败由 state fact 呈现，§4.2 run-bg 裁定）
	return {
		version: 1, toolName, source: "wire", completeness: "complete", title, outcome: "success",
		facts: factsOf(
			fact("句柄", data.handle),
			fact("状态", data.state),
			data.exitCode != null ? fact("退出码", num(data.exitCode)) : null,
			data.elapsedMs != null ? fact("elapsedMs", num(data.elapsedMs)) : null,
			data.text === null && action === "result" ? fact("日志", "不可读（text=null）") : null,
		),
		excerpt: excerptOf(result),
	};
}

function projectEvolutionWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const action = typeof w.action === "string" ? w.action : null;
	const isError = wireIsError(w) || result.isError === true;
	const title = action ? `${toolName} · ${action}` : toolName;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title,
			outcome: "error",
			facts: factsOf(fact("错误码", e.code), fact("错误", e.message, 160)),
			excerpt: excerptOf(result),
		};
	}
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	// B9（ev-20261012-04b7b9）：证据 facts（留存/未留存计数；show 另携 evidenceState；export 携证据字节）
	const evidenceFact = (): ToolPresentationFact | null => {
		const ev = data.evidence;
		if (!Array.isArray(ev) || ev.length === 0) return null;
		const retained = ev.filter((r) => typeof r === "object" && r !== null && (r as Record<string, unknown>).state === "retained").length;
		const omitted = ev.length - retained;
		return fact("证据", omitted > 0 ? `${retained} 留存 / ${omitted} 未留存` : `${retained} 留存`);
	};
	let facts: ToolPresentationFact[];
	switch (action) {
		case "log":
			facts = factsOf(fact("id", data.id), fact("路径", data.path), evidenceFact());
			break;
		case "list":
			facts = factsOf(fact("返回", num(data.returned)));
			break;
		case "resolve":
			facts = factsOf(fact("id", data.id), fact("fixVersion", data.fixVersion), evidenceFact());
			break;
		case "show":
			facts = factsOf(fact("id", data.id), fact("标题", data.title, 80), fact("状态", data.status), evidenceFact(), typeof data.evidenceState === "string" ? fact("证据态", data.evidenceState) : null);
			break;
		case "export":
			facts = factsOf(fact("id", data.id), fact("路径", data.path), data.bytes != null ? fact("字节", num(data.bytes)) : null, evidenceFact(), typeof data.evidenceBytes === "number" && data.evidenceBytes > 0 ? fact("证据字节", num(data.evidenceBytes)) : null);
			break;
		default:
			facts = [];
	}
	return { version: 1, toolName, source: "wire", completeness: "complete", title, outcome: "success", facts, excerpt: excerptOf(result) };
}

function projectLspWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const action = typeof w.action === "string" ? w.action : null;
	const isError = wireIsError(w) || result.isError === true;
	const title = action ? `${toolName} · ${action}` : toolName;
	if (isError) {
		const e = (typeof w.error === "object" && w.error !== null ? w.error : {}) as Record<string, unknown>;
		return {
			version: 1, toolName, source: "wire", completeness: "complete", title,
			outcome: "error",
			facts: factsOf(fact("错误码", e.code), fact("错误", e.message, 160)),
			excerpt: excerptOf(result),
		};
	}
	const data = (typeof w.data === "object" && w.data !== null ? w.data : {}) as Record<string, unknown>;
	let facts: ToolPresentationFact[];
	switch (action) {
		case "status": {
			const servers = Array.isArray(data.servers) ? data.servers : [];
			const instances = Array.isArray(data.instances) ? data.instances : [];
			facts = factsOf(
				fact("检测", servers.length > 0 ? servers.slice(0, 3).map((s) =>
					typeof s === "object" && s !== null && typeof (s as Record<string, unknown>).name === "string"
						? (s as Record<string, unknown>).name : "?").join(",") : "无"),
				fact("实例", instances.length > 0 ? String(instances.length) : null),
			);
			break;
		}
		case "diagnostics": {
			const diags = Array.isArray(data.diagnostics) ? data.diagnostics : [];
			facts = factsOf(fact("文件", data.file), fact("诊断数", String(diags.length)));
			break;
		}
		case "definition":
		case "type_definition":
		case "implementation":
		case "references": {
			const locations = Array.isArray(data.locations) ? data.locations : [];
			facts = factsOf(fact("文件", data.file), fact("定位数", String(locations.length)));
			break;
		}
		case "hover":
			facts = factsOf(fact("文件", data.file), fact("内容", data.state));
			break;
		case "symbols":
			facts = factsOf(fact("文件", data.file), fact("符号树", data.state));
			break;
		case "rename":
			facts = factsOf(
				fact("文件", data.file),
				fact("模式", data.mode),
				data.editCount != null ? fact("编辑数", num(data.editCount)) : null,
			);
			break;
		default:
			facts = [];
	}
	return { version: 1, toolName, source: "wire", completeness: "complete", title, outcome: "success", facts, excerpt: excerptOf(result) };
}

// ── wire 档分派（身份核对过才进；未知版本在此前已拒） ─────────────────────────

function projectWire(w: Record<string, unknown>, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	switch (w.kind) {
		case TASK_QUERY_WIRE_KIND: return projectTaskQueryWire(w, toolName, result);
		case MCP_WIRE_CALL_KIND:
		case MCP_WIRE_LIST_KIND: return projectMcpWire(w, toolName, result);
		case HANDBOOK_WIRE_KIND: return projectHandbookWire(w, toolName, result);
		case RUN_BG_WIRE_KIND: return projectRunBgWire(w, toolName, result);
		case EVOLUTION_WIRE_KIND: return projectEvolutionWire(w, toolName, result);
		case LSP_WIRE_KIND: return projectLspWire(w, toolName, result);
		default: return textPresentation(toolName, result); // 身份核对已挡未知名——防御回退文本档
	}
}

// ── details 档（可证明字段白名单投影；未给三轴就不拼 accepted） ────────────────

/** 任务族 ToolDetailsBlock（tool-result-adapter detailsBlockOf 冻结形状）防御识别：
 *  surfaceVersion 数字 + taskId/revision 三轴可空字段在场。 */
function isToolDetailsBlock(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return false;
	const o = v as Record<string, unknown>;
	if (typeof o.surfaceVersion !== "number") return false;
	for (const k of ["taskId", "revision", "execution", "settlement", "acceptance", "receiptRef"]) {
		if (o[k] !== undefined && o[k] !== null && typeof o[k] !== "string" && typeof o[k] !== "number") return false;
	}
	return true;
}

/** ContractError details（contractErrorReturn 冻结形状 {code,fields,effects,error}）识别。 */
function isContractErrorDetails(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return false;
	const o = v as Record<string, unknown>;
	return typeof o.code === "string" && typeof o.error === "string" && typeof o.effects === "string" && Array.isArray(o.fields);
}

/** mcp_call 调用面 details（mcp-client/mcp-override 冻结形状）识别。 */
function isMcpCallDetails(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return false;
	const o = v as Record<string, unknown>;
	return typeof o.mcpServer === "string" && typeof o.remoteTool === "string";
}

function projectDetails(details: unknown, toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	const base = { version: 1 as const, toolName, source: "details" as const, completeness: "partial" as const };
	const isError = result.isError === true;
	if (isContractErrorDetails(details)) {
		return {
			...base,
			title: toolName,
			outcome: isError ? "error" : "unknown", // 契约错误 details 形状在场即错误返回；isError 缺席（历史不可证）→ unknown，不推定
			facts: factsOf(
				fact("错误码", details.code),
				fact("错误", details.error, 160),
				fact("副作用", details.effects),
			),
			excerpt: excerptOf(result),
		};
	}
	if (isToolDetailsBlock(details)) {
		const axes = typeof details.execution === "string" && typeof details.settlement === "string" && typeof details.acceptance === "string"
			? { execution: details.execution, settlement: details.settlement, acceptance: details.acceptance }
			: null; // 三轴任一缺席（null）→ 不拼轴（「未给三轴就不拼出 accepted」）
		return {
			...base,
			title: toolName,
			outcome: isError ? "error" : "success", // 任务工具正常返回（details 在场=已收口返回；错误由 isError 显式标注）
			facts: factsOf(
				axes ? fact("三轴", axisFactValue(axes)) : null,
				fact("taskId", details.taskId),
				fact("revision", details.revision),
				details.receiptRef ? fact("receiptRef", details.receiptRef) : null,
				details.assurance ? fact("承诺", details.assurance) : null,
			),
			...(axes ? { axes } : {}),
			excerpt: excerptOf(result),
		};
	}
	if (isMcpCallDetails(details)) {
		return {
			...base,
			title: toolName,
			outcome: isError ? "error" : "success",
			facts: factsOf(
				fact("server", details.mcpServer),
				fact("tool", details.remoteTool),
				details.permissionDenied === true ? fact("权限", "调用被拒（预 transport）") : null,
			),
			excerpt: excerptOf(result),
		};
	}
	// details 在场但形状不可证明 → 文本档（不伪造结构）
	return textPresentation(toolName, result);
}

// ── 文本档（纯文本历史：安全摘要 + 原文；completeness=unknown） ────────────────

function textPresentation(toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation {
	return {
		version: 1,
		toolName,
		source: "text",
		completeness: "unknown",
		title: toolName,
		outcome: result.isError === true ? "error" : "unknown", // 纯文本不推定成功（isError 是宿主/历史显式字段，可证错误）
		facts: [],
		excerpt: excerptOf(result),
	};
}

// ── 入口投影（分层判定序：wire → details → text；未识别工具 → undefined） ─────

/**
 * 工具结果 → 呈现语义模型。
 * 返回 undefined 仅当 toolName 不在 amagi 覆盖名单（调用方交回 next()/default）。
 * structuredContent 身份（kind+wireVersion+schemaVersion）与当前受测家族不符时不升
 * wire 档（版本未知不伪造结构），按 details/text 降级。
 */
export function projectToolPresentation(toolName: string, result: Readonly<PresentationResultShape>): ToolPresentation | undefined {
	if (!isAmagiPresentationTool(toolName)) return undefined;
	const sc = result.structuredContent;
	const identity = sc === undefined || sc === null ? null : wireIdentityOf(sc);
	const known = identity !== null
		&& (identity.kind === TASK_QUERY_WIRE_KIND ? identity.wireVersion === TASK_QUERY_WIRE_VERSION && identity.schemaVersion === TASK_QUERY_SCHEMA_VERSION
			: identity.kind === MCP_WIRE_CALL_KIND ? (identity.wireVersion === MCP_CALL_WIRE_VERSION && identity.schemaVersion === MCP_CALL_SCHEMA_VERSION)
				|| (identity.wireVersion === 1 && identity.schemaVersion === 1) // 历史 call v1 仍可呈现。
			: identity.kind === MCP_WIRE_LIST_KIND ? identity.wireVersion === MCP_WIRE_VERSION && identity.schemaVersion === MCP_SCHEMA_VERSION
			: identity.kind === HANDBOOK_WIRE_KIND ? identity.wireVersion === HANDBOOK_WIRE_VERSION && identity.schemaVersion === HANDBOOK_SCHEMA_VERSION
			: identity.kind === RUN_BG_WIRE_KIND ? identity.wireVersion === RUN_BG_WIRE_VERSION && identity.schemaVersion === RUN_BG_SCHEMA_VERSION
			: identity.kind === EVOLUTION_WIRE_KIND
			? identity.wireVersion === EVOLUTION_WIRE_VERSION && (identity.schemaVersion === EVOLUTION_SCHEMA_VERSION
				|| (identity.wireVersion === 1 && identity.schemaVersion === 1)) // B9：历史 v1 仍可呈现（只读降级）
			: identity.kind === LSP_WIRE_KIND ? identity.wireVersion === LSP_WIRE_VERSION && identity.schemaVersion === LSP_SCHEMA_VERSION
			: false);
	if (known && identity !== null) return projectWire(sc as Record<string, unknown>, toolName, result);
	if (result.details !== undefined && result.details !== null) return projectDetails(result.details, toolName, result);
	return textPresentation(toolName, result);
}

/** 三轴标签（panel-model axisLabelOf 单源透出——WebUI/TUI 消费同一口径）。 */
export function presentationAxisLabel(axes: Readonly<ToolPresentationAxes>): string | undefined {
	return axisLabelOf(axes);
}
