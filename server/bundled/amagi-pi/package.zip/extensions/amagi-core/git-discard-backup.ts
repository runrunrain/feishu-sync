/**
 * git-discard-backup.ts — ev-20260922-1eea28（B2/P1）：unattended 丢弃保全放行。
 *
 * 根因（evolution 研究 R/B，ev-20260922-1eea28）：守卫拦截 `git checkout HEAD -- <paths>` 后，
 * 无确认渠道的会话改用 python 从 git show 直写文件——「拦截→绕道直写更危险」的反向激励。
 * 裁决：**「无人值守」本身不是授权**。本模块提供受授权约束的 backup-and-execute 通道：
 * 消除反向激励的方式是给安全通道，而非无条件放行。
 *
 * 授权接口（宿主内部，不开放给模型造字段）：
 *  - `DiscardApproval = { approvalId, repoIdentity, canonicalCommand, targetPaths, sides,
 *    contentFingerprint, expiresAt, maxUses:1, actor:"user" }`。
 *  - 签发源两种：① TUI 会话命令面 /amagi discard-approve（列出完整清单、显式 --yes 确认后生成；
 *    ev-1eea28 E1 接通）；② 任务派发预授权
 *    （Leader 在派发 env 注入 AMAGI_DISCARD_APPROVAL_REF 不透明引用）。审批记录保存于宿主
 *    受保护目录（amagi 数据根 `.amagi-discard-backup/approvals/`，仓库外、0600）——工作区
 *    JSON 不能自证；子进程只拿引用，消费时重新验真（命令/内容指纹/归属/有效期）。
 *  - 有效期默认 10 分钟、单次消费（claims/ 下 O_EXCL 原子 claim）；过期/命令或内容变化/
 *    归属不明均拒绝。**任务角色不能自己设 env 或 backup 参数来批准丢弃**——引用必须对应
 *    宿主已签发的记录，记录内容由签发渠道写入。
 *
 * 保全与执行协议（本模块职责）：
 *  1. 调用方（guards）先跑全部硬门（含 B0 stash 串联门）；本模块只支持一条目标确定的
 *     路径级 checkout/restore（pathspec 非空）；reset --hard / checkout --force / clean /
 *     stash / worktree 删除 / 未知 alias / 子模块 / 不确定路径仍走人工处置——不伪称覆盖
 *     所有破坏性操作。
 *  2. 影响集合（collectDiscardImpact）：tracked 当前工作树字节、index blob/mode/stage、
 *     删除事实（tombstone）、rename 两侧（porcelain R 记录）、会被目标树覆盖的
 *     untracked/ignored 障碍路径。内容指纹为字节级（同 status 下内容变化必失效）。
 *     全部状态查询用原始 NUL 输出（不 trim 文件名）。
 *  3. 首版单次上限：256 MiB / 10,000 条 / 60 秒备份预算；超限报准确规模并拒绝（不截断后放行）。
 *  4. 备份落盘：数据根 `.amagi-discard-backup/backups/<repoKey>/<backupId>/`（仓库外、
 *     宿主受保护路径；目录 0700、文件 0600）+ manifest（内容寻址、逐条 size/mode/mtime、
 *     二进制探测）。staging 完成落盘与校验后 fsync 文件/manifest/目录，同文件系统 rename
 *     发布 ready，fsync 父目录。放行前 verifyDiscardBackup 全量复核（可恢复字节）。
 *     备份失败 → 不放行、原命令不执行。
 *  5. 拒绝存在已知活跃 lease 的任务并行写窗口（worktree 租约；有冲突保守拒绝）。
 *  6. 执行：guards 预检通过后签发一次性放行凭证（绑定 toolCallId/canonicalCommand/cwd，
 *     预检后换命令即失效）；实际执行由 bash-override 承接并记录结果（guard-note 含真实
 *     backupId；发送失败不抹掉落盘事实）。执行后记录实际退出码与影响摘要。
 *  7. 恢复（restoreFromDiscardBackup）是独立、再次授权的操作，不是失败后自动回滚；
 *     备份不随版本回滚删除；审批引用不随重启复活成可重复消费（claim 落盘持久）。
 *
 * 原子性边界：保证「备份完整可读后才发起命令」与「预检失败零执行」；不宣称文件系统与
 * Git 命令跨进程事务原子。框架租约挡住本框架已知写者，无法锁住编辑器等外部写者。
 *
 * 零 pi 依赖（guards/bash-override 接线；测试直调）。guards → 本模块 → git-discard-guard/
 * worktree/data-dir 单向依赖，无循环（depcruise 门禁）。
 */

import { execFileSync, spawnSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataDir } from "./data-dir.ts";
import type { DiscardInspection } from "./git-discard-guard.ts";
import { activeWorktreeLeasesFor } from "./worktree.ts";

// ══════════════════ 常量与基础工具 ══════════════════

/** 首版单次备份上限（设计边界，非实测容量）：超限报准确规模并拒绝，不截断后放行。 */
export const DISCARD_BACKUP_LIMITS = {
	/** 备份内容总字节上限（工作树字节 + index blob 备份字节）。 */
	maxBytes: 256 * 1024 * 1024,
	/** 影响条目数上限。 */
	maxEntries: 10_000,
	/** 采集+备份总预算（ms）。 */
	budgetMs: 60_000,
} as const;

/** 授权默认有效期（10 分钟）。 */
export const DISCARD_APPROVAL_TTL_MS = 10 * 60 * 1000;

/** 一次性放行凭证有效期（与授权同步过期口径）。 */
export const DISCARD_TICKET_TTL_MS = DISCARD_APPROVAL_TTL_MS;

/** 任务派发预授权的不透明引用 env 名（由 Leader 派发时显式注入；子进程不得自行设置伪造授权）。 */
export const DISCARD_APPROVAL_REF_ENV = "AMAGI_DISCARD_APPROVAL_REF";

function sha256(data: string | Buffer): string {
	return createHash("sha256").update(data).digest("hex");
}

/** 命令规范形（连续空白折叠为单空格、去首尾空白）——授权与执行凭证的命令绑定口径。 */
export function canonicalCommandOf(command: string): string {
	return String(command || "").replace(/\s+/g, " ").trim();
}

/** 仓库身份（realpath 优先的 canonical 根路径）。 */
export function repoIdentityOf(repoRoot: string): string {
	try { return fs.realpathSync(repoRoot); } catch { return path.resolve(repoRoot); }
}

/** 备份根目录（宿主受保护：数据根下 `.amagi-discard-backup/`，仓库外）。 */
export function discardBackupRoot(): string {
	return path.join(amagiDataDir(), ".amagi-discard-backup");
}

function approvalsDir(): string {
	return path.join(discardBackupRoot(), "approvals");
}

function claimsDir(): string {
	return path.join(approvalsDir(), "claims");
}

function repoKeyOf(repoRoot: string): string {
	return sha256(repoIdentityOf(repoRoot)).slice(0, 16);
}

function backupBaseDir(repoRoot: string): string {
	return path.join(discardBackupRoot(), "backups", repoKeyOf(repoRoot));
}

/** 原始 NUL 输出执行（不 trim 整体输出）：porcelain/ls-files -z 解析基准。 */
function runGitRaw(cwd: string, args: readonly string[], timeoutMs = 10_000): string | null {
	try {
		return execFileSync("git", args as string[], { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: timeoutMs });
	} catch { return null; }
}

function runGitText(cwd: string, args: readonly string[], timeoutMs = 10_000): string | null {
	const raw = runGitRaw(cwd, args, timeoutMs);
	return raw === null ? null : raw.trim();
}

/** 二进制探测：头 16KB 含 NUL 字节即 binary（manifest 标注用，不改变保全内容）。 */
function probeBinary(chunks: Buffer[]): "text" | "binary" {
	const head = Buffer.concat(chunks.length ? chunks : []).subarray(0, 16 * 1024);
	return head.includes(0) ? "binary" : "text";
}

/** 同步版字节读取（备份落盘用：读取完整字节；受 256MiB 上限保护）。 */
function readWorktreeBytes(absPath: string): { ok: true; data: Buffer } | { ok: false; reason: string } {
	try {
		return { ok: true, data: fs.readFileSync(absPath) };
	} catch (e) {
		return { ok: false, reason: `读取 ${absPath} 失败：${(e as Error).message}` };
	}
}

// 补充：fs.readFileSync 需要显式 Buffer 返回（NodeNext 下 readFileSync(path) 已是 Buffer）


// ══════════════════ 授权接口：DiscardApproval ══════════════════

/** 宿主内部的丢弃授权（签发由真实用户渠道完成；模型不可自造字段——消费时逐项验真）。 */
export interface DiscardApproval {
	approvalId: string;
	/** 授权针对的仓库（canonical repoRoot）。 */
	repoIdentity: string;
	/** 授权针对的命令规范形（canonicalCommandOf）。 */
	canonicalCommand: string;
	/** 授权覆盖的目标路径（相对 repoRoot、POSIX 分隔、已排序；= 签发时的影响路径全集）。 */
	targetPaths: string[];
	/** index/worktree 侧计数（签发时快照）。 */
	sides: { index: number; worktree: number };
	/** 字节级内容指纹（collectDiscardImpact 产物；同 status 下内容变化必失效）。 */
	contentFingerprint: string;
	/** 过期时间（epoch ms）。 */
	expiresAt: number;
	maxUses: 1;
	actor: "user";
	createdAt: number;
	/** 签发渠道（slash-command / ui-confirm / task-dispatch）；仅供审计展示，不参与验真分支。 */
	issuedVia: "slash-command" | "ui-confirm" | "task-dispatch";
}

/** 影响集合条目（备份 manifest 的原子单位）。 */
export interface DiscardImpactEntry {
	/** 相对 repoRoot 的 POSIX 路径。 */
	path: string;
	kind: "worktree" | "index" | "untracked" | "ignored";
	/** 工作树侧：内容 SHA-256（symlink 为链接文本 hash）。 */
	sha256?: string;
	/** 工作树侧字节数。 */
	bytes?: number;
	/** 工作树侧 mode（lstat）。 */
	mode?: number;
	/** mtime（ms，展示与人工核对用）。 */
	mtimeMs?: number;
	isSymlink?: boolean;
	symlinkTarget?: string;
	/** index 侧：blob oid / mode / stage（ls-files -s）。 */
	blobOid?: string;
	indexMode?: string;
	stage?: number;
	/** index blob 内容指纹（sha256 + 字节数；备份与复核的 .idx 文件校验基准）。 */
	blobSha256?: string;
	blobBytes?: number;
	/** 二进制探测（头 16KB 含 NUL）。 */
	binary?: "text" | "binary";
	/** 删除事实：index 有该路径但工作树无文件（恢复时须删回）。 */
	worktreeTombstone?: boolean;
	/** index 无该路径（执行后 index 可能被 checkout <tree> 写入；恢复时须移除）。 */
	indexAbsent?: boolean;
	/** mtime 采集（mtimeMs 的字符串备份形态，防 JSON 数值精度争议）。 */
	mtimeIso?: string;
}

/** 影响集合（collectDiscardImpact 产物；内容指纹 = 字节级）。 */
export interface DiscardImpact {
	entries: DiscardImpactEntry[];
	/** 字节级内容指纹（entries 排序后 JSON 的 sha256）。 */
	fingerprint: string;
	/** 影响路径全集（sorted，= dirty + obstacle + rename 两侧）。 */
	paths: string[];
	headOid: string;
	totalBytes: number;
}

/**
 * 采集丢弃影响集合（全只读：git 探针 + 文件读；不动 index/不执行 stash/reset）。
 * - porcelain -z -uall --ignored=matching：tracked dirty（含删除事实、rename 两侧——R 记录
 *   自带 orig path）、untracked、ignored 障碍；
 * - ls-files -s -z：index blob/mode/stage（gitlink 160000 = 子模块 → 拒绝，走人工处置）；
 * - 工作树逐路径 lstat：symlink 存链接文本不跟随出根，FIFO/socket 拒绝；
 * - index blob 内容经 cat-file 备份（missing blob → 拒绝：不备份不可恢复的字节）。
 * opts.deadline：采集+备份共享预算（超时拒绝）。
 */
export function collectDiscardImpact(cwd: string, repoRoot: string, specs: readonly string[], opts: { deadline?: number } = {}): { ok: true; impact: DiscardImpact } | { ok: false; reason: string } {
	const startedAt = Date.now();
	const checkBudget = (): string | null => {
		if (opts.deadline !== undefined && Date.now() > opts.deadline) {
			return `备份预算超限（${DISCARD_BACKUP_LIMITS.budgetMs / 1000}s）：采集在 ${Math.round((Date.now() - startedAt + DISCARD_BACKUP_LIMITS.budgetMs) / 1000)}s 内未完成，已处理条目见拒绝前统计——拒绝放行（不截断后放行）`;
		}
		return null;
	};
	if (!specs.length) return { ok: false, reason: "路径级 checkout/restore 才能进入备份通道（pathspec 为空 = 全仓形态，走人工处置）" };

	// ① porcelain：tracked dirty + untracked + ignored（原始 NUL 输出，不 trim 文件名）
	const porcelain = runGitRaw(cwd, ["status", "--porcelain", "-z", "--untracked-files=all", "--ignored=matching", "--", ...specs]);
	if (porcelain === null) return { ok: false, reason: "影响集合采集失败（git status --porcelain -z 探针失败）" };
	const trackedPaths = new Set<string>();
	const obstaclePaths = new Set<string>();
	const renameOrigPaths = new Set<string>();
	const records = porcelain.split("\0");
	for (let i = 0; i < records.length; i++) {
		const rec = records[i]!;
		if (!rec || rec.length < 4 || rec[2] !== " ") continue;
		const xy = rec.slice(0, 2);
		const p = rec.slice(3);
		if (!p) continue;
		if (xy.includes("!")) { obstaclePaths.add(p); continue; }
		if (xy.includes("?")) { obstaclePaths.add(p); continue; }
		trackedPaths.add(p);
		if (xy.includes("R") || xy.includes("C")) {
			const orig = records[i + 1];
			if (orig) { renameOrigPaths.add(orig); i++; }
		}
	}
	for (const orig of renameOrigPaths) trackedPaths.add(orig);

	// ② ls-files -s：index 条目（pathspec 范围内）
	const lsFiles = runGitRaw(cwd, ["ls-files", "-s", "-z", "--", ...specs]);
	if (lsFiles === null) return { ok: false, reason: "影响集合采集失败（git ls-files -s -z 探针失败）" };
	const indexEntries = new Map<string, { mode: string; oid: string; stage: number }>();
	for (const rec of lsFiles.split("\0")) {
		if (!rec) continue;
		const tabIndex = rec.indexOf("\t");
		if (tabIndex < 0) continue;
		const meta = rec.slice(0, tabIndex).split(" ");
		const p = rec.slice(tabIndex + 1);
		if (meta.length < 3 || !p) continue;
		if (meta[0] === "160000") return { ok: false, reason: `路径 ${p} 是子模块（gitlink）——子模块不进入本备份通道，走人工处置` };
		indexEntries.set(p, { mode: meta[0]!, oid: meta[1]!, stage: Number(meta[2] ?? 0) });
	}

	// ③ 影响路径全集与条目组装
	const allPaths = new Set<string>([...trackedPaths, ...obstaclePaths, ...indexEntries.keys()]);
	// FIFO/socket 探测（git 视野外；null = 扫描不完整，保守拒绝：不伪称无非常规文件）
	const irregular = scanIrregularEntries(repoRoot, specs);
	if (irregular === null) return { ok: false, reason: "pathspec 范围内非常规文件（FIFO/socket）探测不完整（目录过深/条目过多）——影响面不能确定，拒绝" };
	if (irregular.length) return { ok: false, reason: `pathspec 范围内存在非常规文件（FIFO/socket/设备：${irregular.slice(0, 5).join("、")}${irregular.length > 5 ? ` 等 ${irregular.length} 项` : ""}）——不进入备份通道，走人工处置` };
	if (allPaths.size > DISCARD_BACKUP_LIMITS.maxEntries) {
		return { ok: false, reason: `影响条目 ${allPaths.size} 条超过首版上限 ${DISCARD_BACKUP_LIMITS.maxEntries} 条——拒绝放行（不截断后放行）；请缩小 pathspec 或人工处置` };
	}
	const entries: DiscardImpactEntry[] = [];
	let totalBytes = 0;
	for (const p of [...allPaths].sort()) {
		const budget = checkBudget();
		if (budget) return { ok: false, reason: budget };
		const rel = p.split("/").join("/");
		const abs = path.join(repoRoot, rel);
		// 越界防线：影响路径必须落在 repoRoot 内（git 输出理论天然满足；纵深防御）
		const relCheck = path.relative(repoRoot, abs);
		if (!relCheck || (relCheck === ".." || relCheck.startsWith(`..${path.sep}`)) || path.isAbsolute(relCheck)) {
			return { ok: false, reason: `影响路径 ${p} 解析出仓库根之外（${abs}）——目标越界，拒绝` };
		}
		const indexEntry = indexEntries.get(p);
		const isObstacle = obstaclePaths.has(p);
		// 工作树侧（tracked 修改与 untracked/ignored 障碍都要保字节）
		let worktree: { sha256: string; bytes: number; mode: number; isSymlink: boolean; symlinkTarget?: string; mtimeMs: number; binary: "text" | "binary" } | undefined;
		let tombstone = false;
		try {
			const st = fs.lstatSync(abs);
			if (st.isSymbolicLink()) {
				const target = fs.readlinkSync(abs);
				worktree = { sha256: sha256(target), bytes: Buffer.byteLength(target), mode: st.mode, isSymlink: true, symlinkTarget: target, mtimeMs: st.mtimeMs, binary: "text" };
			} else if (st.isFile()) {
				const data = fs.readFileSync(abs);
				worktree = { sha256: sha256(data), bytes: data.length, mode: st.mode, isSymlink: false, mtimeMs: st.mtimeMs, binary: probeBinary([data]) };
			} else {
				return { ok: false, reason: `${p} 不是常规文件也不是符号链接（FIFO/socket/设备不进入备份通道）` };
			}
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "ENOENT") tombstone = true;
			else return { ok: false, reason: `读取工作树 ${p} 失败：${(e as Error).message}` };
		}
		if (worktree) totalBytes += worktree.bytes;
		const entry: DiscardImpactEntry = {
			path: rel,
			kind: isObstacle ? (ignoredRecorded(p, porcelain) ? "ignored" : "untracked") : "worktree",
			...(worktree ? {
				sha256: worktree.sha256, bytes: worktree.bytes, mode: worktree.mode, mtimeMs: worktree.mtimeMs,
				...(worktree.isSymlink ? { isSymlink: true, symlinkTarget: worktree.symlinkTarget } : {}),
				binary: worktree.binary,
			} : {}),
			...(tombstone ? { worktreeTombstone: true } : {}),
			...(indexEntry ? { blobOid: indexEntry.oid, indexMode: indexEntry.mode, stage: indexEntry.stage } : {}),
			...(indexEntry ? {} : { indexAbsent: true }),
			mtimeIso: worktree ? new Date(worktree.mtimeMs).toISOString() : undefined,
		};
		if (entry.mtimeIso === undefined) delete entry.mtimeIso;
		// index blob 内容验证（missing blob → 拒绝；同时采集 .idx 备份的校验基准）
		if (indexEntry) {
			const blob = runGitRawBuffer(cwd, indexEntry.oid);
			if (blob === null) return { ok: false, reason: `index blob ${indexEntry.oid}（${p}）在对象库中缺失——无法保全，拒绝放行（missing blob）` };
			entry.blobSha256 = sha256(blob);
			entry.blobBytes = blob.length;
			totalBytes += blob.length;
		}
		entries.push(entry);
	}
	if (totalBytes > DISCARD_BACKUP_LIMITS.maxBytes) {
		return { ok: false, reason: `备份内容 ${(totalBytes / 1024 / 1024).toFixed(1)} MiB 超过首版上限 256 MiB——拒绝放行（不截断后放行）；请缩小 pathspec 或人工处置` };
	}
	const headOid = runGitText(cwd, ["rev-parse", "HEAD"]) ?? "no-head";
	const fingerprint = sha256(JSON.stringify(entries));
	return { ok: true, impact: { entries, fingerprint, paths: [...allPaths].sort(), headOid, totalBytes } };
}

/** porcelain 原文中该路径是否以 !!（ignored）记录（kind 标注用）。 */
function ignoredRecorded(p: string, porcelain: string): boolean {
	for (const rec of porcelain.split("\0")) {
		if (rec.length >= 4 && rec[2] === " " && rec.slice(3) === p && rec.slice(0, 2).includes("!")) return true;
	}
	return false;
}

/** FIFO/socket 有界探测（git 视野外：porcelain/ls-files --others 不列非常规文件；checkout 向
 *  FIFO 写入会阻塞，不能让它们静默留在备份通道外）。pathspec 顶层段解析 → 有界 BFS
 *  （深度≤8、条目≤10,000，.git 跳过）；发现非常规条目返回清单（非空 = 拒绝）。 */
function scanIrregularEntries(repoRoot: string, specs: readonly string[]): string[] | null {
	const roots: string[] = [];
	for (const spec of specs) {
		const stripped = spec.replace(/^:\([^)]*\)/, "").replace(/^:\/?:?/, "");
		if (!stripped || stripped === ".") { roots.push(repoRoot); continue; }
		const top = stripped.split("/")[0]!;
		roots.push(path.join(repoRoot, top));
	}
	const irregular: string[] = [];
	const seen = new Set<string>();
	let scanned = 0;
	const queue: Array<{ dir: string; depth: number }> = [];
	for (const root of [...new Set(roots)]) {
		let st: fs.Stats;
		try { st = fs.lstatSync(root); } catch { continue; }
		if (st.isDirectory()) queue.push({ dir: root, depth: 0 });
		else if (!st.isFile() && !st.isSymbolicLink()) irregular.push(path.relative(repoRoot, root));
	}
	while (queue.length) {
		const { dir, depth } = queue.shift()!;
		if (depth > 8 || scanned > 10_000) return null; // 扫描不完整：探测能力有限，如实返回 null（不伪称无 FIFO）
		let dirents: fs.Dirent[];
		try { dirents = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
		for (const dirent of dirents) {
			if (dirent.name === ".git") continue;
			scanned++;
			const abs = path.join(dir, dirent.name);
		if (seen.has(abs)) continue;
			seen.add(abs);
			if (dirent.isDirectory()) { queue.push({ dir: abs, depth: depth + 1 }); continue; }
			if (dirent.isSymbolicLink() || dirent.isFile()) continue;
			irregular.push(path.relative(repoRoot, abs).split(path.sep).join("/"));
		}
	}
	return irregular;
}

// ══════════════════ 签发与验真（宿主 API） ══════════════════

export interface IssueDiscardApprovalParams {
	command: string;
	cwd: string;
	inspection: DiscardInspection;
	/** 有效期（默认 10 分钟）。 */
	ttlMs?: number;
	/** 签发渠道（缺省 ui-confirm）。 */
	issuedVia?: "slash-command" | "ui-confirm" | "task-dispatch";
}

export type IssueDiscardApprovalResult =
	| { ok: true; approval: DiscardApproval; ref: string }
	| { ok: false; reason: string };

/** 签发丢弃授权（宿主内部：TUI 确认渠道或任务派发预授权调用；记录落宿主受保护目录）。
 *  签发即采集字节级内容指纹与目标路径全集——消费时重新采集比对，内容变化即拒绝。 */
export function issueDiscardApproval(params: IssueDiscardApprovalParams): IssueDiscardApprovalResult {
	const { command, cwd, inspection } = params;
	if (!inspection.repoRoot) return { ok: false, reason: "仓库根不可定位，无法签发丢弃授权" };
	if (!inspection.pathspecs.length) return { ok: false, reason: "全仓形态（无 pathspec）不进入授权通道，走人工处置" };
	if (inspection.unknownReason) return { ok: false, reason: `影响范围不可信（${inspection.unknownReason}），无法签发授权` };
	const impactResult = collectDiscardImpact(inspection.cwd, inspection.repoRoot, inspection.pathspecs);
	if (!impactResult.ok) return impactResult;
	const approval: DiscardApproval = {
		approvalId: `dga-${randomUUID().replaceAll("-", "").slice(0, 16)}`,
		repoIdentity: repoIdentityOf(inspection.repoRoot),
		canonicalCommand: canonicalCommandOf(command),
		targetPaths: impactResult.impact.paths,
		sides: { ...inspection.sides },
		contentFingerprint: impactResult.impact.fingerprint,
		expiresAt: Date.now() + (params.ttlMs ?? DISCARD_APPROVAL_TTL_MS),
		maxUses: 1,
		actor: "user",
		createdAt: Date.now(),
		issuedVia: params.issuedVia ?? "ui-confirm",
	};
	try {
		fs.mkdirSync(approvalsDir(), { recursive: true, mode: 0o700 });
		fs.writeFileSync(path.join(approvalsDir(), `${approval.approvalId}.json`), JSON.stringify(approval, null, "\t"), { mode: 0o600 });
	} catch (e) {
		return { ok: false, reason: `授权记录写入失败（${(e as Error).message}）——签发不成立` };
	}
	return { ok: true, approval, ref: approval.approvalId };
}

/** 读取授权记录（引用 → 宿主受保护文件；结构/actor/maxUses 校验）。 */
function loadDiscardApproval(ref: string): { ok: true; approval: DiscardApproval } | { ok: false; reason: string } {
	const id = ref.trim();
	if (!id || !/^dga-[0-9a-f-]+$/.test(id) || id.includes("/") || id.includes("..")) return { ok: false, reason: `丢弃授权引用「${ref}」格式非法` };
	const file = path.join(approvalsDir(), `${id}.json`);
	let raw: string;
	try { raw = fs.readFileSync(file, "utf8"); } catch { return { ok: false, reason: `丢弃授权 ${id} 不存在（未签发/已过期清理/宿主记录不可读）——授权不成立` }; }
	let parsed: unknown;
	try { parsed = JSON.parse(raw); } catch { return { ok: false, reason: `丢弃授权 ${id} 记录损坏——授权不成立` }; }
	const a = parsed as Partial<DiscardApproval>;
	if (a.actor !== "user" || a.maxUses !== 1 || typeof a.approvalId !== "string" || a.approvalId !== id) {
		return { ok: false, reason: `丢弃授权 ${id} 归属/用量字段非法——授权不成立` };
	}
	return { ok: true, approval: parsed as DiscardApproval };
}

/** 已消费探测（只读；claim 写入在验真+备份+复核之后）——重复消费的拒绝语义优先于内容
 *  变化暴露；claim 落盘持久，重启不复活成可重复消费。 */
function alreadyClaimed(approvalId: string): boolean {
	try { fs.accessSync(path.join(claimsDir(), `${approvalId}.claim`)); return true; } catch { return false; }
}

/** 原子消费授权（O_EXCL claim 文件；已存在 = 已消费/并发消费中 → 拒绝）。 */
function claimDiscardApproval(approval: DiscardApproval, backupId: string): { ok: true } | { ok: false; reason: string } {
	try {
		fs.mkdirSync(claimsDir(), { recursive: true, mode: 0o700 });
		const fd = fs.openSync(path.join(claimsDir(), `${approval.approvalId}.claim`), "wx", 0o600);
		try {
			fs.writeSync(fd, JSON.stringify({ claimedAt: Date.now(), canonicalCommand: approval.canonicalCommand, backupId }) + "\n");
		} finally { fs.closeSync(fd); }
		return { ok: true };
	} catch (e) {
		if ((e as NodeJS.ErrnoException).code === "EEXIST") return { ok: false, reason: `丢弃授权 ${approval.approvalId} 已被消费（maxUses=1，单次消费）——不得重复使用；如需再次丢弃须重新签发` };
		return { ok: false, reason: `丢弃授权 ${approval.approvalId} 消费记录写入失败（${(e as Error).message}）——保守拒绝` };
	}
}

/** 派发注入的不透明引用（子进程 env；任务角色自行设置无法通过宿主记录验真）。 */
export function discardApprovalRefFromEnv(env: NodeJS.ProcessEnv = process.env): string | null {
	const v = env[DISCARD_APPROVAL_REF_ENV]?.trim();
	return v ? v : null;
}

/** 为派发 env 构造引用注入（宿主派发侧辅助；子进程侧只读）。 */
export function discardApprovalEnvOf(ref: string): { [DISCARD_APPROVAL_REF_ENV]: string } {
	return { [DISCARD_APPROVAL_REF_ENV]: ref };
}

// ══════════════════ 活跃写租约（并行写窗口保守拒绝） ══════════════════

/** 已知活跃 lease（进程内 worktree 注册表 + 注入补充）：repoRoot 是任一活跃 lease 的
 *  worktree 路径或其主仓根 → 视为并行写窗口，保守拒绝。未知外部写者不声称可排除。 */
export function activeLeaseConflictFor(repoRoot: string, extra?: Array<{ leaseId: string; taskId?: string; path?: string; root?: string }>): { leaseId: string; taskId?: string; detail: string } | null {
	const identity = repoIdentityOf(repoRoot);
	const candidates = [...activeWorktreeLeasesFor(repoRoot), ...(extra ?? [])];
	for (const lease of candidates) {
		const leasePath = lease.path ? repoIdentityOf(lease.path) : null;
		const leaseRoot = lease.root ? repoIdentityOf(lease.root) : null;
		if (leasePath === identity || leaseRoot === identity) {
			return { leaseId: lease.leaseId, taskId: lease.taskId, detail: `仓库存在活跃任务租约（leaseId=${lease.leaseId}${lease.taskId ? `，taskId=${lease.taskId}` : ""}）——并行写窗口内不进入 unattended 放行，保守拒绝` };
		}
	}
	return null;
}

// ══════════════════ 备份落盘（prepare / verify / restore） ══════════════════

export interface DiscardBackupManifest {
	schema: 1;
	state: "ready";
	backupId: string;
	approvalId: string;
	createdAt: number;
	/** 原始命令文本（审计）。 */
	command: string;
	/** 执行 cwd（与授权一致）。 */
	cwd: string;
	repoRoot: string;
	headOid: string;
	affectedPaths: string[];
	entries: DiscardImpactEntry[];
	totalBytes: number;
	contentFingerprint: string;
	restoreNotes: string;
}

export type PrepareDiscardBackupResult =
	| { ok: true; backupId: string; backupDir: string; manifestPath: string; manifest: DiscardBackupManifest }
	| { ok: false; reason: string };

function fsyncFile(file: string): void {
	const fd = fs.openSync(file, "r");
	try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
}

function fsyncDir(dir: string): void {
	try {
		const fd = fs.openSync(dir, "r");
		try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
	} catch { /* 平台不支持目录 fsync 时尽力而为 */ }
}

/**
 * 备份落盘：staging 目录写 files/<n> + manifest（0600/0700）→ 全量 fsync → rename 发布
 * ready → fsync 父目录。任一步失败清 staging 并拒绝（不放行、原命令不执行）。
 * 内容来源：工作树字节 / index blob（cat-file）/ symlink 链接文本 / tombstone（manifest 记录）。
 */
export function prepareDiscardBackup(params: {
	cwd: string;
	repoRoot: string;
	command: string;
	approvalId: string;
	impact: DiscardImpact;
	deadline?: number;
}): PrepareDiscardBackupResult {
	const { cwd, repoRoot, command, approvalId, impact } = params;
	const backupId = `dgb-${randomUUID().replaceAll("-", "").slice(0, 16)}`;
	const baseDir = backupBaseDir(repoRoot);
	const finalDir = path.join(baseDir, backupId);
	const stagingDir = path.join(baseDir, `.staging-${backupId}`);
	try {
		fs.mkdirSync(path.join(stagingDir, "files"), { recursive: true, mode: 0o700 });
	} catch (e) {
		return { ok: false, reason: `备份目录创建失败（${(e as Error).message}）——不放行、原命令不执行` };
	}
	const fail = (reason: string): PrepareDiscardBackupResult => {
		try { fs.rmSync(stagingDir, { recursive: true, force: true }); } catch { /* 残留 staging 不影响拒绝语义 */ }
		return { ok: false, reason };
	};
	if (fs.existsSync(finalDir)) return fail(`备份目录冲突（${backupId} 已存在）`);
	const written: string[] = [];
	try {
		for (let i = 0; i < impact.entries.length; i++) {
			if (params.deadline !== undefined && Date.now() > params.deadline) {
				return fail(`备份预算超限（${DISCARD_BACKUP_LIMITS.budgetMs / 1000}s）——已写 ${written.length}/${impact.entries.length} 条，拒绝放行（不截断后放行）`);
			}
			const entry = impact.entries[i]!;
			const file = path.join(stagingDir, "files", String(i).padStart(5, "0"));
			// index 内容一律 .idx（cat-file blob）；工作树内容一律主文件（symlink 为链接文本）——
			// 混合条目（tracked M：工作树与 index 不同内容）双文件各自保全，恢复互不覆盖。
			if (entry.blobOid) {
				const blob = runGitRawBuffer(cwd, entry.blobOid);
				if (blob === null) return fail(`index blob ${entry.blobOid}（${entry.path}）读取失败（missing blob）——无法保全，不放行`);
				fs.writeFileSync(`${file}.idx`, blob, { mode: 0o600 });
				written.push(`${file}.idx`);
			}
			if (entry.isSymlink) {
				let target: string;
				try { target = fs.readlinkSync(path.join(repoRoot, entry.path)); } catch { return fail(`读取符号链接 ${entry.path} 失败——无法保全，不放行`); }
				fs.writeFileSync(file, target, { encoding: "utf8", mode: 0o600 });
				written.push(file);
			} else if (!entry.worktreeTombstone && entry.sha256 !== undefined) {
				const bytes = readWorktreeBytes(path.join(repoRoot, entry.path));
				if (!bytes.ok) return fail(`${bytes.reason}——无法保全，不放行`);
				fs.writeFileSync(file, bytes.data, { mode: 0o600 });
				written.push(file);
			}
		}
		const manifest: DiscardBackupManifest = {
			schema: 1,
			state: "ready",
			backupId,
			approvalId,
			createdAt: Date.now(),
			command,
			cwd,
			repoRoot,
			headOid: impact.headOid,
			affectedPaths: impact.paths,
			entries: impact.entries,
			totalBytes: impact.totalBytes,
			contentFingerprint: impact.fingerprint,
			restoreNotes: "恢复是独立、再次授权的操作：先人工核对当前状态（git status/diff），确认需要恢复后按 manifest 逐条恢复（restoreFromDiscardBackup）；恢复不自动回滚、备份不随版本回滚删除。执行结果审计见同目录 outcome.jsonl。",
		};
		const manifestPath = path.join(stagingDir, "manifest.json");
		fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, "\t"), { mode: 0o600 });
		for (const file of written) fsyncFile(file);
		fsyncFile(manifestPath);
		fsyncDir(path.join(stagingDir, "files"));
		fsyncDir(stagingDir);
		fs.renameSync(stagingDir, finalDir);
		fsyncDir(baseDir);
		return { ok: true, backupId, backupDir: finalDir, manifestPath: path.join(finalDir, "manifest.json"), manifest };
	} catch (e) {
		return fail(`备份落盘失败（${(e as Error).message}）——不放行、原命令不执行`);
	}
}

/** cat-file blob（Buffer；失败 null）。 */
function runGitRawBuffer(cwd: string, oid: string): Buffer | null {
	try {
		return execFileSync("git", ["cat-file", "blob", oid], { cwd, encoding: "buffer", stdio: ["ignore", "pipe", "pipe"], timeout: 10_000 }) as Buffer;
	} catch { return null; }
}

export type VerifyDiscardBackupResult =
	| { ok: true; manifest: DiscardBackupManifest; backupDir: string }
	| { ok: false; reason: string; mismatches?: string[] };

/** 放行前全量复核：manifest ready + 逐条重读备份文件重算 sha256/bytes 比对（可恢复字节）。 */
export function verifyDiscardBackup(backupDir: string): VerifyDiscardBackupResult {
	let manifest: DiscardBackupManifest;
	try {
		manifest = JSON.parse(fs.readFileSync(path.join(backupDir, "manifest.json"), "utf8")) as DiscardBackupManifest;
	} catch (e) {
		return { ok: false, reason: `manifest 读取/解析失败（${(e as Error).message}）` };
	}
	if (manifest.state !== "ready") return { ok: false, reason: `manifest state=${String(manifest.state)} 非 ready（未发布完成）` };
	const mismatches: string[] = [];
	for (let i = 0; i < manifest.entries.length; i++) {
		const entry = manifest.entries[i]!;
		const file = path.join(backupDir, "files", String(i).padStart(5, "0"));
		// 工作树内容（主文件）：symlink 对比链接文本，常规文件重算 sha256/bytes
		if (!entry.worktreeTombstone && (entry.sha256 !== undefined || entry.symlinkTarget !== undefined)) {
			let data: Buffer;
			try { data = fs.readFileSync(file); } catch {
				mismatches.push(`${entry.path}：备份文件缺失（${file}）`);
				data = Buffer.alloc(0);
			}
			if (data.length > 0 || entry.bytes === 0) {
				if (entry.isSymlink && entry.symlinkTarget !== undefined) {
					if (data.toString("utf8") !== entry.symlinkTarget) mismatches.push(`${entry.path}：symlink 链接文本与 manifest 不一致`);
				} else {
					const actual = sha256(data);
					if (entry.sha256 !== undefined && actual !== entry.sha256) mismatches.push(`${entry.path}：sha256 不一致（manifest=${entry.sha256.slice(0, 12)}… 实际=${actual.slice(0, 12)}…）`);
					if (entry.bytes !== undefined && data.length !== entry.bytes) mismatches.push(`${entry.path}：字节数不一致（manifest=${entry.bytes} 实际=${data.length}）`);
				}
			}
		}
		// index blob（.idx 文件）：重算 blobSha256/blobBytes 对比
		if (entry.blobOid) {
			let idx: Buffer;
			try { idx = fs.readFileSync(`${file}.idx`); } catch {
				mismatches.push(`${entry.path}：index blob 备份缺失（${file}.idx）`);
				continue;
			}
			const actualIdx = sha256(idx);
			if (entry.blobSha256 !== undefined && actualIdx !== entry.blobSha256) mismatches.push(`${entry.path}：index blob sha256 不一致`);
			if (entry.blobBytes !== undefined && idx.length !== entry.blobBytes) mismatches.push(`${entry.path}：index blob 字节数不一致（manifest=${entry.blobBytes} 实际=${idx.length}）`);
		}
	}
	if (mismatches.length) return { ok: false, reason: `备份复核未通过（${mismatches.length} 条不一致）`, mismatches };
	return { ok: true, manifest, backupDir };
}

export type RestoreDiscardBackupResult =
	| { ok: true; restored: string[]; skipped: string[] }
	| { ok: false; reason: string; restoredSoFar?: string[] };

/**
 * 按恢复（独立授权路径）：verifyDiscardBackup 指纹复核通过后，按 manifest 精确恢复
 * 工作树与 index——只碰 manifest 内路径；失败即停（不做二次自动回滚）。冲突 stage（>0）
 * 条目保守拒绝（需人工处理）。本函数不判断「是否应该恢复」——那是再次授权的判断。
 */
export function restoreFromDiscardBackup(backupDir: string): RestoreDiscardBackupResult {
	const verify = verifyDiscardBackup(backupDir);
	if (!verify.ok) return { ok: false, reason: `恢复前复核未通过：${verify.reason}` };
	const { manifest } = verify;
	const repoRoot = manifest.repoRoot;
	const restored: string[] = [];
	const skipped: string[] = [];
	// 冲突 stage 保守拒绝（merge 冲突现场的恢复需人工）
	for (const entry of manifest.entries) {
		if ((entry.stage ?? 0) > 0) return { ok: false, reason: `路径 ${entry.path} 存在冲突 stage（stage=${entry.stage}）——按 manifest 精确恢复无法表达，需人工处置`, restoredSoFar: restored };
	}
	for (const entry of manifest.entries) {
		const abs = path.join(repoRoot, entry.path);
		const relCheck = path.relative(repoRoot, abs);
		if (!relCheck || (relCheck === ".." || relCheck.startsWith(`..${path.sep}`)) || path.isAbsolute(relCheck)) {
			return { ok: false, reason: `manifest 路径 ${entry.path} 越出仓库根——拒绝恢复（manifest 完整性存疑）`, restoredSoFar: restored };
		}
		try {
			if (entry.worktreeTombstone) {
				try { fs.unlinkSync(abs); restored.push(`${entry.path}（删除事实恢复）`); } catch (e) {
					if ((e as NodeJS.ErrnoException).code === "ENOENT") skipped.push(`${entry.path}（本就无文件）`);
					else throw e;
				}
			} else {
				const file = path.join(backupDir, "files", String(manifest.entries.indexOf(entry)).padStart(5, "0"));
				if (entry.isSymlink) {
					const target = fs.readFileSync(file, "utf8");
					try { if (fs.lstatSync(abs)) fs.rmSync(abs, { force: true }); } catch { /* 不存在即跳过 */ }
					fs.symlinkSync(target, abs);
					restored.push(`${entry.path}（symlink→${target}）`);
				} else if (entry.sha256 !== undefined) {
					const data = fs.readFileSync(file);
					fs.mkdirSync(path.dirname(abs), { recursive: true });
					fs.writeFileSync(abs, data);
					if (entry.mode !== undefined) { try { fs.chmodSync(abs, entry.mode & 0o7777); } catch { /* chmod 失败不回滚内容 */ } }
					restored.push(`${entry.path}（${entry.bytes ?? data.length} 字节）`);
				}
			}
			// index 侧恢复
			if (entry.indexAbsent) {
				const rm = runGitText(repoRoot, ["update-index", "--force-remove", "--", entry.path]);
				if (rm === null && runGitRaw(repoRoot, ["ls-files", "-z", "--", entry.path])) {
					return { ok: false, reason: `index 移除 ${entry.path} 失败`, restoredSoFar: restored };
				}
		} else if (entry.blobOid && entry.indexMode) {
				// blob 从 .idx 备份重新入对象库（内容寻址幂等：原 blob 在则同 oid；混合条目的工作树
				// 字节与 index blob 是两份内容，互不覆盖）
				const data = fs.readFileSync(path.join(backupDir, "files", `${String(manifest.entries.indexOf(entry)).padStart(5, "0")}.idx`));
				const hash = spawnSync("git", ["hash-object", "-w", "--stdin"], { cwd: repoRoot, input: data });
				const oid = hash.status === 0 ? String(hash.stdout).trim() : null;
				if (!oid || oid !== entry.blobOid) {
					return { ok: false, reason: `index blob 重建失败（${entry.path}：期望 ${entry.blobOid}，得到 ${oid ?? "错误"}）`, restoredSoFar: restored };
				}
				const up = runGitText(repoRoot, ["update-index", "--add", "--cacheinfo", `${entry.indexMode},${entry.blobOid},${entry.path}`]);
				if (up === null) return { ok: false, reason: `index 恢复 ${entry.path} 失败（update-index）`, restoredSoFar: restored };
			}
		} catch (e) {
			return { ok: false, reason: `恢复 ${entry.path} 失败：${(e as Error).message}`, restoredSoFar: restored };
		}
	}
	return { ok: true, restored, skipped };
}

// ══════════════════ 一次性放行凭证（执行边界） ══════════════════

/** 一次性放行凭证：绑定 toolCallId/canonicalCommand/cwd——预检后换命令即失效。 */
export interface DiscardExecutionTicket {
	toolCallId: string;
	canonicalCommand: string;
	cwd: string;
	backupId: string;
	backupDir: string;
	manifestPath: string;
	affectedCount: number;
	issuedAt: number;
	expiresAt: number;
}

/** 模块级（进程内）凭证表：guards 预检签发、bash-override 执行边界消费。 */
const executionTickets = new Map<string, DiscardExecutionTicket>();
/** 执行结果待发送 guard-note（toolCallId → 人类可读摘要；guards tool_result 消费）。 */
const pendingOutcomeNotes = new Map<string, string>();

/** 签发放行凭证（guards 预检通过后调用；同 toolCallId 覆盖旧凭证）。 */
export function grantDiscardExecutionTicket(ticket: DiscardExecutionTicket): void {
	executionTickets.set(ticket.toolCallId, ticket);
}

/** 消费放行凭证（bash-override 执行边界）：toolCallId 存在且 canonicalCommand/cwd 匹配
 *  且未过期 → 取走（一次性）；不匹配/过期 → 丢弃并返回 mismatch（命令不因此重拦——guard
 *  已放行同一调用；不匹配即异常路径，记录审计）。无凭证返回 null（常规路径零开销）。 */
export function takeDiscardExecutionTicket(toolCallId: string, actual: { command: string; cwd: string }): { ticket: DiscardExecutionTicket } | { mismatch: string } | null {
	const ticket = executionTickets.get(toolCallId);
	if (!ticket) return null;
	executionTickets.delete(toolCallId);
	if (Date.now() > ticket.expiresAt) return { mismatch: `放行凭证已过期（toolCallId=${toolCallId}）` };
	if (canonicalCommandOf(actual.command) !== ticket.canonicalCommand) return { mismatch: `放行凭证命令不匹配（预检 ${ticket.canonicalCommand.slice(0, 60)}，实际 ${canonicalCommandOf(actual.command).slice(0, 60)}）——凭证失效` };
	if (path.resolve(actual.cwd) !== path.resolve(ticket.cwd)) return { mismatch: `放行凭证 cwd 不匹配（预检 ${ticket.cwd}，实际 ${actual.cwd}）——凭证失效` };
	return { ticket };
}

/** 记录执行结果（outcome.jsonl 落盘 = 持久事实；guard-note 待发送文本挂起——发送失败不抹掉落盘）。 */
export function recordDiscardExecutionOutcome(ticket: DiscardExecutionTicket, outcome: { ok: boolean; exitCode?: number; errorMessage?: string }): void {
	const at = new Date().toISOString();
	const record = { at, backupId: ticket.backupId, command: ticket.canonicalCommand, cwd: ticket.cwd, ok: outcome.ok, ...(outcome.exitCode !== undefined ? { exitCode: outcome.exitCode } : {}), ...(outcome.errorMessage ? { errorMessage: outcome.errorMessage.slice(0, 400) } : {}) };
	try {
		fs.appendFileSync(path.join(ticket.backupDir, "outcome.jsonl"), JSON.stringify(record) + "\n");
	} catch { /* 落盘失败时 guard-note 仍尝试发送（双向独立，不互相抹掉） */ }
	pendingOutcomeNotes.set(ticket.toolCallId, `[amagi·丢弃备份] 已执行授权丢弃（backupId=${ticket.backupId}，影响 ${ticket.affectedCount} 个路径）：${outcome.ok ? "执行成功" : `执行失败${outcome.exitCode !== undefined ? `（exit ${outcome.exitCode}）` : ""}`}。备份与 manifest：${ticket.manifestPath}；恢复是独立、再次授权的操作（按 manifest 人工核对后执行），备份不随版本回滚删除。`);
}

/** 取走待发送 guard-note 文本（guards tool_result 消费；无则 null）。 */
export function takePendingDiscardOutcomeNote(toolCallId: string): string | null {
	const note = pendingOutcomeNotes.get(toolCallId);
	if (note !== undefined) pendingOutcomeNotes.delete(toolCallId);
	return note ?? null;
}

// ══════════════════ 总入口：授权 + 备份 + 复核 + 消费 ══════════════════

export type AuthorizeDiscardResult =
	| { ok: true; ticket: DiscardExecutionTicket; backupId: string; backupDir: string; manifestPath: string; affectedCount: number }
	| { ok: false; reason: string; approvalText?: string };

/**
 * backup-and-execute 总入口（guards 无 UI 分支调用；全同步）：
 * 验真（记录/有效期/归属/命令/内容指纹/目标集合）→ lease 检查 → 备份 → 全量复核 →
 * 备份后指纹复验 → 原子 claim → 签发一次性放行凭证。任一步失败零放行（原命令不执行）。
 * 先跑全部硬门是调用方职责（guards 接线顺序：B0 串联门 → discard confirm → 本入口）。
 */
export function authorizeDiscardBackupAndExecute(params: {
	command: string;
	cwd: string;
	inspection: DiscardInspection;
	ref: string;
	toolCallId: string;
	extraActiveLeases?: Array<{ leaseId: string; taskId?: string; path?: string; root?: string }>;
}): AuthorizeDiscardResult {
	const { command, cwd, inspection, ref, toolCallId } = params;
	const startedAt = Date.now();
	const deadline = startedAt + DISCARD_BACKUP_LIMITS.budgetMs;
	const loaded = loadDiscardApproval(ref);
	if (!loaded.ok) return loaded;
	const approval = loaded.approval;
	if (Date.now() > approval.expiresAt) return { ok: false, reason: `丢弃授权 ${approval.approvalId} 已过期（${new Date(approval.expiresAt).toISOString()} 到期，有效期 10 分钟）——重新签发后重试`, approvalText: approvalTextOf(approval) };
	if (!inspection.repoRoot) return { ok: false, reason: "仓库根不可定位——授权归属无法验真" };
	if (repoIdentityOf(inspection.repoRoot) !== approval.repoIdentity) {
		return { ok: false, reason: `丢弃授权归属不匹配（授权仓库 ${approval.repoIdentity}，当前仓库 ${repoIdentityOf(inspection.repoRoot)}）——拒绝`, approvalText: approvalTextOf(approval) };
	}
	if (canonicalCommandOf(command) !== approval.canonicalCommand) {
		return { ok: false, reason: `丢弃授权命令不匹配（授权「${approval.canonicalCommand.slice(0, 80)}」，当前「${canonicalCommandOf(command).slice(0, 80)}」）——授权绑定签发时的命令，换命令须重新签发`, approvalText: approvalTextOf(approval) };
	}
	if (inspection.unknownReason) return { ok: false, reason: `影响范围不可信（${inspection.unknownReason}）——不进入 backup-and-execute` };
	// 已消费优先暴露（单次消费是授权状态，先于内容比对与租约检查）
	if (alreadyClaimed(approval.approvalId)) {
		return { ok: false, reason: `丢弃授权 ${approval.approvalId} 已被消费（maxUses=1，单次消费）——不得重复使用；如需再次丢弃须重新签发`, approvalText: approvalTextOf(approval) };
	}
	if (!inspection.pathspecs.length) return { ok: false, reason: "全仓形态（无 pathspec）不在 backup-and-execute 支持范围（reset --hard / checkout --force / clean / stash 等走人工处置）" };
	if (inspection.kind !== "checkout-paths" && inspection.kind !== "restore") {
		return { ok: false, reason: `丢弃形态 ${inspection.kind} 不在 backup-and-execute 支持范围（仅路径级 checkout/restore；全仓/force 形态走人工处置）` };
	}
	if (inspection.splitBefore) return { ok: false, reason: `复合命令需拆开执行（${inspection.splitBefore}）——预检针对旧状态` };
	// lease：并行写窗口保守拒绝
	const lease = activeLeaseConflictFor(inspection.repoRoot, params.extraActiveLeases);
	if (lease) return { ok: false, reason: lease.detail };
	// 内容指纹验真（字节级）
	const firstImpact = collectDiscardImpact(inspection.cwd, inspection.repoRoot, inspection.pathspecs, { deadline });
	if (!firstImpact.ok) return firstImpact;
	const impact = firstImpact.impact;
	if (impact.fingerprint !== approval.contentFingerprint) {
		return { ok: false, reason: `授权后内容已变化（字节级指纹不一致）——授权不能跨状态生效，拒绝执行；如需丢弃须重新签发授权`, approvalText: approvalTextOf(approval) };
	}
	const targetSet = [...impact.paths].sort().join("\n");
	if (targetSet !== [...approval.targetPaths].sort().join("\n")) {
		return { ok: false, reason: `授权目标集合与当前影响路径不一致（授权 ${approval.targetPaths.length} 条，当前 ${impact.paths.length} 条）——拒绝`, approvalText: approvalTextOf(approval) };
	}
	// 备份 → 全量复核
	const prepared = prepareDiscardBackup({ cwd: inspection.cwd, repoRoot: inspection.repoRoot, command, approvalId: approval.approvalId, impact, deadline });
	if (!prepared.ok) return prepared;
	const verified = verifyDiscardBackup(prepared.backupDir);
	if (!verified.ok) return { ok: false, reason: `备份复核未通过（${verified.reason}）——不放行、原命令不执行；备份保留于 ${prepared.backupDir}` };
	// 备份后指纹复验（备份期间内容未变）
	const secondImpact = collectDiscardImpact(inspection.cwd, inspection.repoRoot, inspection.pathspecs, { deadline });
	if (!secondImpact.ok) return { ok: false, reason: `备份后复验失败（${secondImpact.reason}）——不放行、原命令不执行` };
	if (secondImpact.impact.fingerprint !== approval.contentFingerprint) {
		return { ok: false, reason: "备份期间工作区内容发生变化（指纹不一致）——预检授权不跨状态生效，本次拒绝；备份已保留", approvalText: approvalTextOf(approval) };
	}
	// 原子消费授权（claim 失败 = 已消费/并发消费 → 拒绝）
	const claimed = claimDiscardApproval(approval, prepared.backupId);
	if (!claimed.ok) return { ok: false, reason: claimed.reason, approvalText: approvalTextOf(approval) };
	const ticket: DiscardExecutionTicket = {
		toolCallId,
		canonicalCommand: approval.canonicalCommand,
		cwd: path.resolve(cwd),
		backupId: prepared.backupId,
		backupDir: prepared.backupDir,
		manifestPath: prepared.manifestPath,
		affectedCount: impact.paths.length,
		issuedAt: Date.now(),
		expiresAt: Date.now() + DISCARD_TICKET_TTL_MS,
	};
	grantDiscardExecutionTicket(ticket);
	return { ok: true, ticket, backupId: prepared.backupId, backupDir: prepared.backupDir, manifestPath: prepared.manifestPath, affectedCount: impact.paths.length };
}

/** 授权摘要（拒绝文案附给有权会话核对）。 */
function approvalTextOf(approval: DiscardApproval): string {
	return `授权 ${approval.approvalId}：命令「${approval.canonicalCommand}」，目标 ${approval.targetPaths.length} 条，${new Date(approval.expiresAt).toISOString()} 到期，签发渠道 ${approval.issuedVia}`;
}

/**
 * 工具化执行（测试/独立调用）：凭已签发凭证 spawnSync 执行授权命令并记录结果。
 * 主链路的实际执行由 bash-override 承接（原生 bash + 结果记录）；本函数提供同一审计
 * 语义的独立执行入口，不绕过任何已跑硬门（调用前授权与备份必须已完成）。
 */
export function executeApprovedDiscard(params: { command: string; cwd: string; ticket: DiscardExecutionTicket; timeoutMs?: number }): { exitCode: number | null; ok: boolean; stdout: string; stderr: string; outcomeRecorded: boolean } {
	const run = spawnSync("bash", ["-c", params.command], { cwd: params.cwd, encoding: "utf8", timeout: params.timeoutMs ?? 60_000, stdio: ["ignore", "pipe", "pipe"] });
	const ok = run.status === 0;
	recordDiscardExecutionOutcome(params.ticket, { ok, exitCode: run.status ?? undefined, ...(run.error ? { errorMessage: String(run.error.message) } : {}) });
	return { exitCode: run.status, ok, stdout: String(run.stdout ?? ""), stderr: String(run.stderr ?? ""), outcomeRecorded: true };
}

// ══════════════════ 测试辅助 ══════════════════

/** 复位进程内凭证/通知状态（测试专用；生产不调用）。 */
export function resetDiscardBackupRuntimeForTest(): void {
	executionTickets.clear();
	pendingOutcomeNotes.clear();
}
