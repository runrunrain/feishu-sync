import { freezeSelectedEvidence } from "./dispatch-handoff.ts";
import { captureLeaderContext, prepareDispatchContext, validateDispatchContext, type DispatchContextRequest, type DispatchContextSession } from "./dispatch-context.ts";
/**
 * tool-surface.ts — amagi-pi v2 I2（方案 §4.2/§4.3/§6.1 动态工具行/§8.2-I2）：会话工具面管理。
 *
 * 职责（单一）：高级分面（task_batch、后续扩展面）的显式启用与会话面治理——
 *  - 显式 enableFacet：高级分面仅显式启用才可见（默认会话 = 四稳定工具 task-facets；
 *    legacy task/query_task 模型面 W1.2 起单轨翻转：新会话默认剔除出活跃集——工具仍注册，
 *    双轨留档（v1）会话 resume 或 AMAGI_SURFACE_LEGACY=1 逃生舱保留，会话级定格不热切换）。
 *  - 只追加（分面）：会话工具面对分面工具只增不减（setActiveTools 对 facet 严格 additive——
 *    保留内置与其他扩展工具，pi 宿主对纯追加变更走 deferred 工具结果位或完整表回退，两路均
 *    可用）；唯一例外是 W1.2 legacy 模型面剔除（翻转语义本体，见 onSessionStart）；surfaceVersion
 *    会话内固定（appendEntry 留档 amagi:tool-surface；旧会话按留档面加载，版本不匹配不自动
 *    迁移）；session 定版后锁定分面定义（运行中换 schema 拒绝）。
 *  - 纯读无副作用：enableFacet 是纯面操作——零子进程 spawn、零任务状态写（registry/内核不动；
 *    会话留档 appendEntry 属 harness 记录面，非任务状态）。
 *  - 子进程拒绝：AMAGI_SUBAGENT 永远不能启用派发分面（防递归派发；子 Agent 资源读取不受影响）。
 *  - 降级路径：宿主无 setActiveTools/getActiveTools（非原生动态工具面）→ 分面工具懒注册
 *    （注册即激活，无法逐会话收窄）；四稳定工具注册即恒可用，不依赖动态工具能力（§4.3
 *    「常用批次可在会话开始预启用」的固定小工具集回退）。
 *
 * task_batch 分面（§4.1 按需工具）：静态图校验（节点≤32/依赖≤32、边去重、验环、未知节点、
 * 输出冲突、混合 requires——全通过才开始任何节点，失败零节点启动）+ sharedInputs（required
 * 存在性预检）→ submitGroup（K8b 组调度：dependsOn[{nodeId,requires}] 复用回执边语义
 * accepted/ready/settled；上游回执 hash 经 handoffBlock 固定进下游 spec）→ 立即返回组句柄
 * 与逐节点状态（等待人工接受时暂停组已建——onPaused steer 通知，Leader task_control accept
 * 后自动续跑，I1 已接 K8b resumeGroupAfterAcceptance 接缝）。
 *
 * 与 legacy 共存：本模块不触碰 legacy task/query_task 的注册（index.ts 双注册）；W1.2 起
 * 治理其模型面可见性（legacyToolNames 从活跃集剔除/保留，注册面与内部链路——#agent 硬路由、
 * amagi-commands、shortcuts、WebUI resume——不经模型面，零影响）；task_batch 的
 * dependsOn 字符串边经 prepareArguments 无歧义提升为对象边（requires 缺省=accepted 即新面
 * 缺省语义；旧 task 工具 batch 模式仍由 legacy 工具原样承接，不互相转译——§4.2「旧 resume/
 * batch 调用不能伪装成新 task 提交」由四稳定工具封闭规格拒绝保障）。
 */
import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
import type { AgentConfig } from "./agents-loader.ts";
import { findAgentByRequest } from "./agent-aliases.ts";
import { runTask } from "./task-tool.ts";
import { sendMachineNotice, GROUP_TERMINAL_TYPE, type TaskCompletionSink } from "./evidence-context.ts";
import { runResumeTask } from "./task-resume.ts";
import {
	submitGroup, handoffBlock,
	type GroupNode, type GroupRunDeps, type GroupRunOutcome, type ResultEnvelope,
} from "./group-scheduler.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import { validateCallerContext, type CallerContext } from "./contracts/command.ts";
import { CONTRACT_ERROR_CODES, err, normalizeToolArgumentArtifacts, ok, type ContractError, type Result } from "./contracts/view.ts";
import { contractErrorReturn, guardedExecute, type FacetToolReturn } from "./tool-result-adapter.ts";
import { createFilePermissionEnforcer } from "./file-permission.ts";
import { declaredOutputWriteHint } from "./dispatch-preflight.ts";
import { computeEffectiveGrant, unlimitedUserAuthority, JSON_BACKEND_CAPS } from "./task-permission.ts";
import { awaitPendingFileMutations, fileMutationSessionId } from "./file-mutation-tracker.ts";
import {
	DispatchInputSchema, DispatchOutputSchema, normalizeInputReferences, normalizeOutputReferences,
	validateTaskSource, readTaskFile, DISPATCH_TASK_GUIDELINES, type DispatchInput, type DispatchOutput,
} from "./dispatch-input.ts";

// ── 常量（§4.1 批次上限；升版须同步说明档 resources/core/tools-facets.md） ──────

export const BATCH_MAX_NODES = 32;
export const BATCH_MAX_DEPS_PER_NODE = 32;
/** K8b 回执边语义（accepted=默认产物边 / ready=审查边 / settled=诊断边）。 */
export const BATCH_EDGE_REQUIRES = ["accepted", "ready", "settled"] as const;
export type BatchEdgeRequires = (typeof BATCH_EDGE_REQUIRES)[number];

/** 会话工具面留档 customType（§4.2「会话启动时固定 surfaceVersion 与说明档并用 appendEntry 留档」）。 */
export const TOOL_SURFACE_ENTRY_TYPE = "amagi:tool-surface";

/** 双轨面版本（W1.2 前史）：v1 留档 = legacy task/query_task 与四稳定工具双在的双轨会话——
 *  resume 此类旧会话保留 legacy 模型面（旧会话旧 schema 不撤）；v2 起单轨（新会话默认剔除）。 */
export const DUAL_TRACK_SURFACE_VERSION = 1;

/** legacy 模型面可见性逃生舱 env（W1.2：=1 一律保留 legacy 活跃集；会话级定格，不热切换）。 */
export const SURFACE_LEGACY_ENV = "AMAGI_SURFACE_LEGACY";

// ── 工具面治理（SurfaceHost = 宿主动态工具契约子集：registerTool/setActiveTools/appendEntry） ──

/** 宿主能力面（ExtensionAPI 结构子集；弱宿主缺 get/setActiveTools 时走懒注册降级）。 */
export interface SurfaceHost {
	registerTool(def: unknown): void;
	getActiveTools?(): string[];
	setActiveTools?(names: string[]): void;
	appendEntry?(customType: string, data?: unknown): void;
}

export interface ToolSurfaceOptions {
	subagent: boolean;
	/** 受信调用者上下文（组合根构造；分面启用上限 authority.facets 在此判定）。 */
	caller: CallerContext;
	/** 基础面版本（组合根注入 task-facets 的 TASK_FACET_SURFACE_VERSION；本模块不反向依赖）。 */
	surfaceVersion: number;
	/** 基础面留档戳（组合根注入 taskFacetSurfaceStamp()）。 */
	baseStamp: string;
	/** legacy 模型面工具名（组合根注入，如 ["task","query_task"]；空数组=不治理（测试/子进程装配）。 */
	legacyToolNames?: readonly string[];
}

/** 会话工具面留档记录（旧会话恢复依据）。 */
export interface ToolSurfaceRecord {
	surfaceVersion: number;
	stamp: string;
	facets: readonly string[];
	subagent: boolean;
	hostCanManageActive: boolean;
	/** legacy 工具模型面可见性（W1.2 翻转留档：会话内定格；弱宿主无法收窄时如实记 true）。 */
	legacyModelSurface: boolean;
	at: number;
}

export type FacetEnableResult =
	| { ok: true; added: readonly string[]; message: string }
	| { ok: false; code: "unknown-facet" | "facet-denied-subagent" | "facet-not-authorized" | "facet-locked"; message: string };

/** 分面工具定义（与 pi registerTool 契约结构一致；本模块产出 task_batch 等高级分面）。 */
export interface SurfaceToolDefinition<P = never> {
	name: string;
	label: string;
	description: string;
	promptSnippet?: string;
	promptGuidelines?: string[];
	parameters: object;
	prepareArguments?(args: unknown): unknown;
	execute: (toolCallId: string, params: P, signal: AbortSignal | undefined, onUpdate: undefined, ctx: unknown) => Promise<FacetToolReturn>;
}

export interface ToolSurfaceController {
	/** 注册分面工具工厂（组合根 load 期一次；session 定版后拒绝——运行中不换 schema）。 */
	registerFacets(facets: Record<string, { tools: () => SurfaceToolDefinition[] }>): FacetEnableResult;
	/** 会话启动：过滤未启用分面工具出 active 集（保留他扩展工具）、按留档恢复旧会话面、留档版本戳。 */
	onSessionStart(entries: ReadonlyArray<{ customType?: string; data?: unknown }>): { restored: readonly string[]; note: string };
	/** 显式启用高级分面（纯面操作：零 spawn 零任务状态写；只追加不移除；幂等）。 */
	enableFacet(name: string): FacetEnableResult;
	/** 当前已启用分面（只读投影）。 */
	activeFacets(): readonly string[];
	/** 全部已注册分面工具名（只读投影）。 */
	facetToolNames(): readonly string[];
	/** 当前留档记录（只读投影）。 */
	surfaceRecord(): ToolSurfaceRecord;
}

/**
 * 创建会话工具面治理器。CallerContext 非法即抛（组合根接线错误，不是模型可修复错误）。
 * 强宿主（get/setActiveTools 齐备）：registerFacets 即前置注册（pi getAllTools 可发现），
 * onSessionStart 过滤出 active 集——pi 官方 search_tools 同款生命周期；弱宿主：懒注册降级。
 */
export function createToolSurface(host: SurfaceHost, opts: ToolSurfaceOptions): ToolSurfaceController {
	const callerCheck = validateCallerContext(opts.caller);
	if (!callerCheck.ok) {
		throw new Error(`[tool-surface] CallerContext 非法（组合根接线错误；CallerContext 不能从模型参数构造）：${callerCheck.error.message}`);
	}
	const canManageActive = typeof host.getActiveTools === "function" && typeof host.setActiveTools === "function";
	const legacyToolNames = new Set(opts.legacyToolNames ?? []);
	let legacyModelSurface = false; // W1.2：legacy 模型面可见性（onSessionStart 定格一次，会话内不热切换）
	const facetFactories = new Map<string, { tools: () => SurfaceToolDefinition[] }>();
	const facetTools = new Map<string, SurfaceToolDefinition[]>(); // 创建即冻结（定义缓存，运行中不换 schema）
	const activeFacetsSet = new Set<string>();
	let pinned = false;

	const record = (): ToolSurfaceRecord => ({
		surfaceVersion: opts.surfaceVersion,
		stamp: opts.baseStamp,
		facets: [...activeFacetsSet],
		subagent: opts.subagent,
		hostCanManageActive: canManageActive,
		legacyModelSurface,
		at: Date.now(),
	});

	const appendRecord = (): void => { try { host.appendEntry?.(TOOL_SURFACE_ENTRY_TYPE, record()); } catch { /* 留档失败不阻断面操作 */ } };

	/** 分面工具（memo：首次创建后冻结；弱宿主懒创建点同样经此收敛）。 */
	const toolsOf = (name: string): SurfaceToolDefinition[] => {
		let tools = facetTools.get(name);
		if (!tools) {
			const factory = facetFactories.get(name);
			if (!factory) return [];
			tools = factory.tools();
			facetTools.set(name, tools);
			// ev-20260920：分面工厂产出的工具自带 prepareArguments 伪影剥离（定义冻结契约：注册对象
			// 与工厂产品同一引用，不得在注册路径克隆包装——I2 幂等启用 strictEqual 同一性断言）
			for (const t of tools) host.registerTool(t);
		}
		return tools;
	};

	const authorized = (name: string): boolean => opts.caller.authority.facets.includes(name as "batch");

	return {
		registerFacets(facets) {
			if (pinned) {
				return { ok: false, code: "facet-locked", message: `会话已定版（session_start 已触发）——运行中不换分面 schema（§4.2 surfaceVersion 会话内固定）；已注册分面: ${[...facetFactories.keys()].join(", ") || "（无）"}` };
			}
			for (const [name, factory] of Object.entries(facets)) facetFactories.set(name, factory);
			// 强宿主：前置注册（inactive 直到 onSessionStart 过滤 + enableFacet 追加激活）——
			// pi 官方动态工具生命周期（registerTool 进 getAllTools，setActiveTools 控激活）。
			if (canManageActive) for (const name of Object.keys(facets)) toolsOf(name);
			return { ok: true, added: [], message: `分面已注册（未激活——显式 enableFacet 才可见）: ${Object.keys(facets).join(", ")}` };
		},

		onSessionStart(entries) {
			pinned = true;
			// 末条 amagi:tool-surface 留档 = 上会话面（旧会话旧 schema：按留档恢复；版本不匹配不自动迁移）
			let recorded: { surfaceVersion?: unknown; facets?: unknown } | undefined;
			for (let i = entries.length - 1; i >= 0; i--) {
				const e = entries[i];
				if (e?.customType === TOOL_SURFACE_ENTRY_TYPE) { recorded = (e.data ?? {}) as typeof recorded; break; }
			}
			// W1.2 单轨翻转：legacy 模型面可见性（会话级定格——session_start 判定一次，不热切换）：
			//  ①无留档（新会话）或留档面版本非双轨 → 剔除出活跃集（工具仍注册，内部链路不经模型面）；
			//  ②双轨留档（v1 旧会话 resume）→ 保留；③SURFACE_LEGACY_ENV=1 逃生舱 → 一律保留。
			legacyModelSurface = legacyToolNames.size > 0 && (
				process.env.AMAGI_SURFACE_LEGACY === "1"
				|| recorded?.surfaceVersion === DUAL_TRACK_SURFACE_VERSION
			);
			let restored: string[] = [];
			let note = "新会话默认面（无留档——四稳定工具；legacy 模型面已剔除（W1.2 单轨，注册面保留）；高级分面需显式 enableFacet）";
			if (recorded) {
				if (recorded.surfaceVersion === opts.surfaceVersion && Array.isArray(recorded.facets)) {
					restored = recorded.facets.filter((f): f is string => typeof f === "string" && facetFactories.has(f));
					note = restored.length > 0 ? `旧会话面恢复: ${restored.join(", ")}（schema 不变续用）` : "留档无已启用分面——默认面";
				} else {
					note = `留档面版本不匹配（v${String(recorded.surfaceVersion)} ≠ 当前 v${opts.surfaceVersion}）——旧会话按留档面加载原则不自动迁移，本会话回归默认面（如需高级分面请重新 enableFacet）`;
				}
			}
			// 子进程/授权过滤（恢复面同样不越过权限上限）
			restored = restored.filter((f) => !opts.subagent && authorized(f));
			activeFacetsSet.clear();
			if (canManageActive) {
				const allFacetNames = new Set<string>();
				for (const name of facetFactories.keys()) for (const t of toolsOf(name)) allFacetNames.add(t.name);
				const keep = new Set<string>();
				for (const name of restored) for (const t of toolsOf(name)) keep.add(t.name);
				const active = host.getActiveTools!();
				host.setActiveTools!(active.filter((n) => (!allFacetNames.has(n) || keep.has(n)) && (legacyModelSurface || !legacyToolNames.has(n))));
				// 追加恢复目标（幂等：已在 active 则无变化）
				const after = host.getActiveTools!();
				const missing = [...keep].filter((n) => !after.includes(n));
				if (missing.length > 0) host.setActiveTools!([...new Set([...after, ...missing])]);
			} else {
				// 弱宿主降级：注册即激活（无法逐会话收窄——四稳定工具不受影响恒可用；legacy 同理保持可见，如实留档）
				if (legacyToolNames.size > 0) legacyModelSurface = true;
				for (const name of restored) toolsOf(name);
			}
			for (const name of restored) activeFacetsSet.add(name);
			appendRecord();
			// legacy 面状态尾注（无治理名单的装配不附加）
			if (legacyToolNames.size > 0) {
				note += legacyModelSurface
					? `；legacy ${[...legacyToolNames].join("/")} 模型面保留（双轨留档会话或 ${SURFACE_LEGACY_ENV}=1）`
					: `；legacy ${[...legacyToolNames].join("/")} 已从模型面剔除（旧语法语义见 amagi_resource({ resource: "tools-legacy" })；注册面与内部链路不变）`;
			}
			return { restored, note };
		},

		enableFacet(name) {
			if (opts.subagent) {
				return { ok: false, code: "facet-denied-subagent", message: "子进程（AMAGI_SUBAGENT）不能启用派发分面——派发分面只对 Leader 会话开放（防递归派发）；只读资源读取不受影响" };
			}
			if (!facetFactories.has(name)) {
				return { ok: false, code: "unknown-facet", message: `未知分面 "${name}"（可用: ${[...facetFactories.keys()].join(", ") || "（无）"}——分面清单由组合根注册，模型参数不能构造）` };
			}
			if (!authorized(name)) {
				return { ok: false, code: "facet-not-authorized", message: `分面 "${name}" 不在调用者授权上限（CallerContext.authority.facets: ${opts.caller.authority.facets.join(", ") || "（空）"}）——授权由组合根注入` };
			}
			if (activeFacetsSet.has(name)) {
				return { ok: true, added: [], message: `分面 "${name}" 已启用（幂等——工具定义不变，运行中不换 schema）` };
			}
			const tools = toolsOf(name); // 创建即冻结；强宿主已注册，弱宿主此处懒注册（注册即激活）
			if (canManageActive) {
				const active = host.getActiveTools!();
				const add = tools.map((t) => t.name).filter((n) => !active.includes(n));
				if (add.length > 0) host.setActiveTools!([...new Set([...active, ...add])]); // 只追加不移除
			}
			activeFacetsSet.add(name);
			appendRecord();
			return { ok: true, added: tools.map((t) => t.name), message: `分面 "${name}" 已启用并加入当前工具面（只追加；surfaceVersion=${opts.surfaceVersion} 会话内固定）` };
		},

		activeFacets: () => [...activeFacetsSet],
		facetToolNames: () => [...facetTools.values()].flat().map((t) => t.name),
		surfaceRecord: record,
	};
}

// ── task_batch 分面工具（§4.1 按需；静态校验全通过才开始节点，失败零节点启动） ───

export interface BatchEdgeParam { nodeId: string; requires?: BatchEdgeRequires }
export interface BatchNodeParam extends DispatchContextRequest {
	id: string;
	agent: string;
	task: string;
	taskFile?: string;
	model?: string;
	name?: string;
	cwd?: string;
	allowedPaths?: string[];
	reportPath?: string;
	outputs?: Array<{ path: string; kind?: "file" | "tree"; required?: boolean }>;
	dependsOn?: BatchEdgeParam[];
}
export interface BatchToolParams extends DispatchContextRequest {
	nodes: BatchNodeParam[];
	sharedInputs?: Array<{ path: string; purpose: string; required?: boolean }>;
}
export interface BatchToolInput extends DispatchContextRequest {
	nodes: Array<Omit<BatchNodeParam, "task" | "outputs" | "dependsOn"> & {
		task?: string; outputs?: DispatchOutput[]; dependsOn?: Array<string | BatchEdgeParam>;
	}>;
	sharedInputs?: DispatchInput[];
}

/** 宿主预处理与 execute 同源且幂等；只展开语义唯一的简写，不读取任务书文件。 */
function prepareBatchArguments(args: unknown): unknown {
	const input = normalizeToolArgumentArtifacts(args);
	if (!input || typeof input !== "object" || Array.isArray(input)) return input;
	const p = input as Record<string, unknown>;
	const nodes = Array.isArray(p.nodes) ? p.nodes.map((n) => {
		if (!n || typeof n !== "object" || Array.isArray(n)) return n;
		const node = n as Record<string, unknown>;
		return { ...node,
			...(node.outputs !== undefined ? { outputs: normalizeOutputReferences(node.outputs) } : {}),
			...(Array.isArray(node.dependsOn) ? { dependsOn: node.dependsOn.map((e) => typeof e === "string" ? { nodeId: e } : e) } : {}),
		};
	}) : p.nodes;
	return { ...p, nodes,
		...(p.sharedInputs !== undefined ? { sharedInputs: normalizeInputReferences(p.sharedInputs) } : {}),
	};
}

/** 静态校验后的批次图（边已去重归一；requires 缺省=accepted；调度侧按节点统一解锁条件）。 */
export interface BatchGraphNode {
	param: BatchNodeParam;
	edges: ReadonlyArray<{ nodeId: string; requires: BatchEdgeRequires }>;
	requires: BatchEdgeRequires | null; // null = 无依赖边
}
export interface BatchGraph {
	nodes: ReadonlyArray<BatchGraphNode>;
	byId: ReadonlyMap<string, BatchGraphNode>;
	edgeCount: number;
	dedupedEdges: number;
}

const BATCH_MINIMAL_EXAMPLES: readonly object[] = [
	{ nodes: [{ id: "<节点id>", agent: "<角色名>", task: "<任务书正文（目标/边界/验收）>" }] },
	{
		nodes: [
			{ id: "impl", agent: "<实现角色>", task: "<实现任务书>", outputs: [{ path: "out/impl-report.md" }] },
			{ id: "review", agent: "<审查角色>", task: "<审查任务书>", dependsOn: [{ nodeId: "impl", requires: "ready" }] },
		],
		sharedInputs: [{ path: "docs/spec.md", purpose: "需求来源", required: true }],
	},
];

const fail = (r: Result<never>): FacetToolReturn => contractErrorReturn((r as { error: ContractError }).error);
const withRepair = (e: Readonly<ContractError>, repairExamples: readonly object[]): ContractError =>
	({ code: e.code, message: e.message, fields: [...e.fields], effects: e.effects, repairExamples });

/** 参数封闭规格：schema 外字段整单拒绝（§4.2 不自动删字段后执行）。 */
function rejectUnknownParams(params: Record<string, unknown>, known: readonly string[]): ContractError | null {
	const unknown = Object.keys(params).filter((k) => !known.includes(k) && params[k] !== undefined);
	return unknown.length
		? (err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, `参数含未知字段 ${unknown.join(",")}（task_batch 封闭规格；legacy task 编排参数不属于本工具面）`, [`params.${unknown[0]}`]) as { error: ContractError }).error
		: null;
}

/**
 * 批次图静态校验（纯函数，零副作用）：上限（节点≤32/原始边≤32 每节点）、节点 id 去重、角色名册、
 * 边去重（同上游不同 requires=冲突拒绝）、未知节点、混合 requires（当前调度面按节点统一解锁条件）、
 * 环检测（Kahn）、输出路径冲突（按节点 cwd 归一后全图唯一）。任一失败零节点启动。
 */
export function validateBatchGraph(params: BatchToolParams, agentNames: readonly string[], groupCwd: string): Result<BatchGraph> {
	if (!Array.isArray(params.nodes) || params.nodes.length === 0) {
		return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "nodes 必须是非空数组（至少 1 个节点）", ["nodes"], "none", BATCH_MINIMAL_EXAMPLES);
	}
	if (params.nodes.length > BATCH_MAX_NODES) {
		return err("batch-limit", `节点数 ${params.nodes.length} 超上限 ${BATCH_MAX_NODES}（§4.1）——更大编排请拆批次`, ["nodes"], "none", BATCH_MINIMAL_EXAMPLES);
	}
	const idSet = new Set<string>();
	for (const n of params.nodes) {
		const id = typeof n?.id === "string" ? n.id.trim() : "";
		if (!id) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 id 必须是非空字符串（收到 ${JSON.stringify(n?.id)}）`, ["nodes.id"], "none", BATCH_MINIMAL_EXAMPLES);
		if (idSet.has(id)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 id 重复: "${id}"（批次内唯一）`, ["nodes.id"], "none", BATCH_MINIMAL_EXAMPLES);
		idSet.add(id);
		if (typeof n.task !== "string" || n.task.trim() === "") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 "${id}" 的 task 必须是非空任务书正文`, ["nodes.task"], "none", BATCH_MINIMAL_EXAMPLES);
		if (!agentNames.includes(n.agent)) {
			return err("unknown-agent", `节点 "${id}" 的角色 "${n.agent}" 不在名册（可用: ${agentNames.join(", ") || "（空）"}）`, ["nodes.agent"], "none",
				agentNames.slice(0, 2).map((a) => ({ nodes: [{ id, agent: a, task: "<任务书>" }] })));
		}
		if (n.outputs !== undefined) {
			if (!Array.isArray(n.outputs)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `节点 "${id}" 的 outputs 必须是数组`, ["nodes.outputs"], "none", BATCH_MINIMAL_EXAMPLES);
			for (const o of n.outputs) {
				if (!o || typeof o.path !== "string" || o.path.trim() === "") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 "${id}" 的 outputs[].path 必须是非空路径`, ["nodes.outputs.path"], "none", BATCH_MINIMAL_EXAMPLES);
				if (o.kind !== undefined && o.kind !== "file" && o.kind !== "tree") return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `节点 "${id}" 的 outputs[].kind 必须是 file/tree（收到 "${String(o.kind)}"）`, ["nodes.outputs.kind"], "none", BATCH_MINIMAL_EXAMPLES);
				if (o.required !== undefined && typeof o.required !== "boolean") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 "${id}" 的 outputs[].required 必须是布尔值`, ["nodes.outputs.required"], "none", BATCH_MINIMAL_EXAMPLES);
			}
		}
		if (n.dependsOn !== undefined && !Array.isArray(n.dependsOn)) {
			return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `节点 "${id}" 的 dependsOn 必须是数组；单条边也请使用 ["上游id"]`, ["nodes.dependsOn"], "none", BATCH_MINIMAL_EXAMPLES);
		}
	}
	// 边归一（去重 + 冲突检测 + 未知节点 + requires 枚举）
	let edgeCount = 0;
	let rawEdgeCount = 0;
	const edgesByNode = new Map<string, Array<{ nodeId: string; requires: BatchEdgeRequires }>>();
	for (const n of params.nodes) {
		const edges: Array<{ nodeId: string; requires: BatchEdgeRequires }> = [];
		const seen = new Map<string, BatchEdgeRequires>();
		const raw = Array.isArray(n.dependsOn) ? n.dependsOn : [];
		if (raw.length > BATCH_MAX_DEPS_PER_NODE) {
			return err("batch-limit", `节点 "${n.id}" 依赖边 ${raw.length} 条超上限 ${BATCH_MAX_DEPS_PER_NODE}（§4.1）`, ["nodes.dependsOn"], "none", BATCH_MINIMAL_EXAMPLES);
		}
		for (const e of raw) {
			rawEdgeCount++;
			if (!e || typeof e.nodeId !== "string" || e.nodeId.trim() === "") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `节点 "${n.id}" 的 dependsOn[].nodeId 必须是非空上游节点 id`, ["nodes.dependsOn.nodeId"], "none", BATCH_MINIMAL_EXAMPLES);
			if (e.requires !== undefined && !BATCH_EDGE_REQUIRES.includes(e.requires)) {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `节点 "${n.id}" 对 "${e.nodeId}" 的 requires 必须是 ${BATCH_EDGE_REQUIRES.join("/")}（收到 "${String(e.requires)}"）`, ["nodes.dependsOn.requires"], "none", BATCH_MINIMAL_EXAMPLES);
			}
			const dep = e.nodeId.trim();
			if (!idSet.has(dep)) {
				return err("unknown-node", `节点 "${n.id}" 依赖未知节点 "${dep}"（批次内节点: ${[...idSet].join(", ")}）`, ["nodes.dependsOn.nodeId"], "none", BATCH_MINIMAL_EXAMPLES);
			}
			const requires: BatchEdgeRequires = e.requires ?? "accepted"; // 缺省=默认产物边（K8b 语义）
			const prev = seen.get(dep);
			if (prev === requires) continue; // 重复边去重（幂等声明）
			if (prev !== undefined) {
				return err("edge-conflict", `节点 "${n.id}" 对上游 "${dep}" 声明了冲突的 requires（${prev} 与 ${requires}）——同上游边语义须唯一`, ["nodes.dependsOn"], "none", BATCH_MINIMAL_EXAMPLES);
			}
			seen.set(dep, requires);
			edges.push({ nodeId: dep, requires });
		}
		const distinct = new Set(edges.map((e) => e.requires));
		if (distinct.size > 1) {
			return err("mixed-requires", `节点 "${n.id}" 的依赖边声明了不同 requires（${[...distinct].join(" + ")}）——当前调度面按节点统一解锁条件；请统一 requires 或将不同解锁条件的消费拆为独立节点`, ["nodes.dependsOn.requires"], "none", BATCH_MINIMAL_EXAMPLES);
		}
		edgesByNode.set(n.id, edges);
		edgeCount += edges.length;
	}
	// 环检测（Kahn：拓扑排序不完整 = 有环）
	const indegree = new Map<string, number>([...idSet].map((id) => [id, edgesByNode.get(id)!.length]));
	const dependents = new Map<string, string[]>([...idSet].map((id) => [id, []]));
	for (const n of params.nodes) for (const e of edgesByNode.get(n.id)!) dependents.get(e.nodeId)!.push(n.id);
	const queue = [...idSet].filter((id) => indegree.get(id) === 0);
	let processed = 0;
	while (queue.length > 0) {
		const id = queue.shift()!;
		processed++;
		for (const next of dependents.get(id)!) {
			const d = indegree.get(next)! - 1;
			indegree.set(next, d);
			if (d === 0) queue.push(next);
		}
	}
	if (processed < idSet.size) {
		const cyclic = [...idSet].filter((id) => (indegree.get(id) ?? 0) > 0);
		return err("batch-cycle", `依赖图存在环（涉及节点: ${cyclic.join(" → ")}）——静态校验失败零节点启动，请断开环后重发`, ["nodes.dependsOn"], "none", BATCH_MINIMAL_EXAMPLES);
	}
	// 输出冲突（按节点 cwd 归一为绝对路径后全图唯一）
	const outputOwners = new Map<string, string[]>();
	for (const n of params.nodes) {
		const nodeCwd = typeof n.cwd === "string" && n.cwd.trim() !== "" ? path.resolve(groupCwd, n.cwd) : groupCwd;
		for (const o of n.outputs ?? []) {
			const abs = path.resolve(nodeCwd, o.path);
			const owners = outputOwners.get(abs) ?? [];
			owners.push(n.id);
			outputOwners.set(abs, owners);
		}
	}
	for (const [abs, owners] of outputOwners) {
		if (owners.length > 1) {
			return err("output-conflict", `输出路径冲突: ${abs} 被节点 ${owners.join("、")} 同时声明（批次内输出路径须唯一——避免并行覆写）`, ["nodes.outputs.path"], "none", BATCH_MINIMAL_EXAMPLES);
		}
	}
	const nodes: BatchGraphNode[] = params.nodes.map((n) => ({
		param: n,
		edges: edgesByNode.get(n.id)!,
		requires: (edgesByNode.get(n.id)!.length > 0 ? edgesByNode.get(n.id)![0].requires : null),
	}));
	return ok({ nodes, byId: new Map(nodes.map((n) => [n.param.id, n])), edgeCount, dedupedEdges: rawEdgeCount - edgeCount });
}

export interface TaskBatchDeps {
	agents: AgentConfig[];
	/** 受信调用者上下文（组合根提供；非法即接线错误抛出）。 */
	caller: CallerContext;
	/** 组终局/暂停 steer 通知（缺省无通知——组状态经留档与查询可观察）。ev-20261101-7fffc6：
	 *  有 sendMessage 时走 custom 机器通道（amagi:group-terminal + details.runId 回源）。 */
	pi?: TaskCompletionSink;
	/** 测试注入（fake 子进程命令/结构化证据；生产不传）。 */
	testOpts?: { testCommand?: { command: string; args: string[] }; evidence?: GroupRunDeps["evidence"] };
	/** 服务覆写（默认真实链 runTask/runResumeTask；测试注入真实内核 fake 链）。 */
	services?: { runTask?: GroupRunDeps["runTask"]; runResume?: GroupRunDeps["runResume"] };
}

interface BatchCtx { sessionManager?: DispatchContextSession; cwd?: string; modelRegistry?: unknown; isProjectTrusted?: () => boolean }

/** 组终局通知文本（有界：逐节点一行 + 跳过明细）。 */
function batchOutcomeText(label: string, o: Readonly<GroupRunOutcome>): string {
	const lines = [`[task_batch ${label} ${o.runId}]`];
	const order = Object.keys(o.envelopes);
	for (const nodeId of order) {
		const env = o.envelopes[nodeId];
		lines.push(`  ${nodeId} ${env.status}${env.taskId && env.taskId !== "?" ? ` taskId=${env.taskId.slice(0, 8)}` : ""}${env.error ? `（${env.error.code}: ${env.error.message.slice(0, 120)}）` : ""}`);
	}
	if (o.skipped.length > 0) {
		lines.push(`跳过 ${o.skipped.length}（依赖未满足——如实记录不静默）:`);
		for (const s of o.skipped) lines.push(`  ${s.nodeId}: ${s.reason}`);
	}
	if (o.awaitingAcceptance?.length) {
		lines.push("待接受上游（accept 后自动续跑）:");
		for (const a of o.awaitingAcceptance) {
			lines.push(`  ${a.nodeId} taskId=${a.taskId.slice(0, 8)} receiptId=${a.receiptId}（阻塞: ${a.blockedNodes.join(", ")}）`);
			lines.push(`  引导: task_query({ handle: "${a.taskId.slice(0, 8)}", view: "receipt" }) 取 revision → task_control({ action: "accept", handle: "${a.taskId.slice(0, 8)}", receiptId: "${a.receiptId}", expectedRevision: <revision>, reason: "<理由>" })`);
		}
	}
	return lines.join("\n");
}

/** 创建 task_batch 分面工具（注册就绪；仅经 tool-surface 显式启用才对会话可见）。 */
export function createTaskBatchTool(deps: TaskBatchDeps): SurfaceToolDefinition<BatchToolInput> {
	const callerCheck = validateCallerContext(deps.caller);
	if (!callerCheck.ok) {
		throw new Error(`[task-batch] CallerContext 非法（组合根接线错误；CallerContext 不能从模型参数构造）：${callerCheck.error.message}`);
	}
	const agentNames = deps.agents.map((a) => a.name);
	const agentEnum = agentNames.length > 0 ? StringEnum(agentNames) : Type.String();
	const svc = {
		runTask: deps.services?.runTask ?? (runTask as unknown as GroupRunDeps["runTask"]),
		runResume: deps.services?.runResume ?? (runResumeTask as unknown as GroupRunDeps["runResume"]),
	};

	return {
		name: "task_batch",
		label: "Amagi Task Batch",
		description: [
			"提交一个批次（DAG）：静态校验全通过才开始任何节点（失败零节点启动），立即返回组句柄与逐节点状态。",
			"nodes 必填（≤32；每节点 id/agent + task/taskFile 恰选一个）；新任务书无论长短直接放各节点 task，一次提交批次，harness 自动保存，无需先 Write；taskFile 引用已有文件（相对调用者 cwd；同批并行写该文件的 Write/Edit 自动等待完成后再读）；outputs/sharedInputs 支持路径字符串简写。dependsOn=[\"上游id\"] 缺省 accepted，需 ready/settled 时用 [{nodeId,requires}]（≤32/节点；同一节点全部边 requires 须一致）；sharedInputs 缺失即整单拒绝。",
			"上游回执 hash 在解锁时固定进下游任务书（不追随最新结果）；requires=accepted 边遇上游回执待接受时组暂停并通知——task_control accept 后自动续跑。",
			"contextMode=isolated/selected/fork 可在批次或节点选择，节点覆盖批次；同次调用捕获同一 Leader 快照，延迟节点不追随以后历史。",
			"输出路径批次内唯一（冲突拒绝）；环/未知节点/超限均整单拒绝（effects=none）。",
		].join(" "),
		promptSnippet: `task_batch({ contextMode: "selected", nodes: [{ id, agent, task, dependsOn: [nodeId] }], sharedInputs: [path] }) — 模式可逐节点覆盖；新任务书直接传正文，一次派发整个批次；依赖简写仍需显式接受`,
		promptGuidelines: DISPATCH_TASK_GUIDELINES,
		parameters: Type.Object({
			contextMode: Type.Optional(StringEnum(["isolated", "selected", "fork"], { description: "Leader 上下文模式（缺省 isolated）；selected=要求/观察/待核验判断及按需原文，fork=全部可见文本。关键约束写入 task；节点可覆盖，不继承权限。" })),
			contextRefs: Type.Optional(Type.Array(Type.String(), { description: "selected 可选来源引用：文件路径/工具调用id/消息id，至多16个；无需先 Write" })),
			nodes: Type.Array(Type.Object({
				id: Type.String({ description: "节点 id（批次内唯一；dependsOn 引用它）" }),
				agent: agentEnum,
				contextMode: Type.Optional(StringEnum(["isolated", "selected", "fork"], { description: "Leader 上下文模式（缺省 isolated）；selected=要求/观察/待核验判断及按需原文，fork=全部可见文本。关键约束写入 task；节点可覆盖，不继承权限。" })),
				contextRefs: Type.Optional(Type.Array(Type.String(), { description: "selected 可选来源引用：文件路径/工具调用id/消息id，至多16个；无需先 Write" })),

				task: Type.Optional(Type.String({ description: "节点新任务书完整正文（长短均可）；harness 自动冻结保存，无需先 Write；与 taskFile 恰选一个" })),
				taskFile: Type.Optional(Type.String({ description: "已有 UTF-8 任务书文件（≤1MiB，相对调用者 cwd，与 task 互斥）；同批并行写此文件的 Write/Edit 自动等待完成后再读；全部文件读取快照成功后才启动任何节点" })),
				model: Type.Optional(Type.String({ description: "节点模型覆盖（受信解析链）" })),
				name: Type.Optional(Type.String({ description: "稳定用户句柄名" })),
				cwd: Type.Optional(Type.String({ description: "节点工作目录（相对调用者目录；缺省继承）" })),
				allowedPaths: Type.Optional(Type.Array(Type.String(), { description: "节点写入白名单（相对节点 cwd）" })),
				reportPath: Type.Optional(Type.String({ description: "节点报告落盘路径（相对节点 cwd）" })),
				outputs: Type.Optional(Type.Array(DispatchOutputSchema, { description: "节点预期产物：路径字符串或完整对象（批次内路径唯一）" })),
				dependsOn: Type.Optional(Type.Array(Type.Union([Type.String({ description: "上游节点 id 简写（requires=accepted）" }), Type.Object({
					nodeId: Type.String({ description: "上游节点 id" }),
					requires: Type.Optional(StringEnum([...BATCH_EDGE_REQUIRES], { description: "解锁条件：accepted（缺省，上游回执经显式接受）/ready（回执 ready 即解锁，审查型）/settled（回执已发布即解锁，诊断型）" })),
				})]), { description: "依赖边（≤32；同节点全部边 requires 须一致）" })),
			}), { description: `节点清单（1..${BATCH_MAX_NODES}）` }),
			sharedInputs: Type.Optional(Type.Array(DispatchInputSchema, { description: "批次共享输入：路径字符串或完整对象（相对调用者目录，注入全部节点任务书）" })),
		}),
		prepareArguments(args: unknown): unknown {
			// ev-20260920：宿主 validateToolArguments 之前先剥 strict 采样伪影（null 键与 "null" 字符串）——
			// 枚举位伪影（nodes[].dependsOn[].requires 等）不再结构性拒收；定义冻结契约要求本钩子内重
			// 自带而非注册路径克隆包装（I2 幂等启用同一性断言）。
			return prepareBatchArguments(args);
		},
		execute: async (_id, rawParams, _signal, _onUpdate, ctxRaw) => guardedExecute("task_batch", async () => {
			let params = prepareBatchArguments(rawParams) as BatchToolParams;
			const shape = rejectUnknownParams(params as unknown as Record<string, unknown>, ["nodes", "sharedInputs", "contextMode", "contextRefs"]);
			if (shape) return contractErrorReturn(shape);
			// 子进程双保险（surface 已拒启用；直调工具对象同样拒——测试与防御纵深）
			if (process.env.AMAGI_SUBAGENT === "1") {
				return fail(err("facet-denied-subagent", "子进程（AMAGI_SUBAGENT）不能调用 task_batch——派发分面只对 Leader 会话开放（防递归派发）", ["task_batch"], "none", []));
			}
			const ctx = (ctxRaw ?? {}) as BatchCtx;
			const groupCwd = typeof ctx.cwd === "string" && ctx.cwd !== "" ? ctx.cwd : process.cwd();
			const defaultContext = validateDispatchContext(params);
			if (!defaultContext.ok) return contractErrorReturn(defaultContext.error);
			let needsContext = defaultContext.value !== "isolated";
			for (const node of Array.isArray(params.nodes) ? params.nodes : []) {
				const mode = validateDispatchContext({ contextMode: node.contextMode ?? params.contextMode, contextRefs: node.contextRefs ?? (node.contextMode === undefined ? params.contextRefs : undefined) });
				if (!mode.ok) return contractErrorReturn(mode.error);
				if (mode.value !== "isolated") needsContext = true;
			}
			const contextSnapshot = needsContext ? captureLeaderContext(ctx.sessionManager, _id) : undefined;
			if (contextSnapshot && !contextSnapshot.ok) return contractErrorReturn(contextSnapshot.error);
			const contextNotices: string[] = [];
			// 全部任务来源组合先验形状；文件正文占位仅供图校验，不进入调度器。
			if (Array.isArray(params.nodes)) {
				const nodes: BatchNodeParam[] = [];
				for (const n of params.nodes) {
					if (!n || typeof n !== "object") return fail(err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "nodes[] 必须是节点对象", ["nodes"], "none", BATCH_MINIMAL_EXAMPLES));
					const source = validateTaskSource(n);
					if (!source.ok) return contractErrorReturn(withRepair(source.error, BATCH_MINIMAL_EXAMPLES));
					nodes.push({ ...n, task: source.value.task });
				}
				params = { ...params, nodes };
			}
			const graphR = validateBatchGraph(params, agentNames, groupCwd);
			if (!graphR.ok) return contractErrorReturn(withRepair(graphR.error, BATCH_MINIMAL_EXAMPLES));
			const graph = graphR.value;
			// sharedInputs 形状 + required 存在性（零节点启动前提）
			if (params.sharedInputs !== undefined && !Array.isArray(params.sharedInputs)) return fail(err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "sharedInputs 必须是数组（路径字符串或完整对象）", ["sharedInputs"], "none", BATCH_MINIMAL_EXAMPLES));
			const sharedInputs = Array.isArray(params.sharedInputs) ? params.sharedInputs : [];
			for (const inp of sharedInputs) {
				if (!inp || typeof inp.path !== "string" || inp.path.trim() === "" || typeof inp.purpose !== "string" || !inp.purpose.trim() || (inp.required !== undefined && typeof inp.required !== "boolean")) {
					return fail(err(CONTRACT_ERROR_CODES.INVALID_FIELD, "sharedInputs[].{path,purpose} 必填（path 非空 + purpose 用途说明）", ["sharedInputs"], "none", BATCH_MINIMAL_EXAMPLES));
				}
				// diting 审核 M2：required 缺省=必需（!== false），与 task_submit 面及 outputs 声明契约
				//（required ?? true，ev-20260920-61839b）统一口径；文档 tools-facets.md 同步声明。
				if (inp.required !== false && !fs.existsSync(path.resolve(groupCwd, inp.path))) {
					return fail(err("missing-required-input", `共享输入 "${inp.path}" 标记 required 但不存在（${path.resolve(groupCwd, inp.path)}）——整单拒绝零节点启动`, ["sharedInputs.path"], "none", BATCH_MINIMAL_EXAMPLES));
				}
			}
			// 每个节点在启动前冻结角色/调用者/后端交集；不能只核验 taskFile 而漏掉执行授权。
			// batch 现有角色派发语义申请角色通道；显式 allowedPaths 收窄写面，不放大角色能力。
			const nodeGrants = new Map<string, PermissionGrant>();
			const outputWriteHints: string[] = [];
			for (const n of graph.nodes) {
				const agent = findAgentByRequest(deps.agents, n.param.agent)!;
				const nodeCwd = n.param.cwd !== undefined ? path.resolve(groupCwd, n.param.cwd) : groupCwd;
				const caps = agent.capabilities;
				const grant = computeEffectiveGrant({
					role: { name: agent.name, capabilities: caps, ...(agent.capabilitiesError !== undefined ? { capabilitiesError: agent.capabilitiesError } : {}) },
					user: unlimitedUserAuthority(deps.caller.authority.maxAssurance), backend: JSON_BACKEND_CAPS, cwd: nodeCwd,
					...(caps ? { scope: { read: [...caps.read], write: n.param.allowedPaths ?? [...caps.write], reportFiles: [...caps.report], shell: caps.shell, mcp: [...caps.mcp], lsp: [...caps.lsp] } } : {}),
					inputs: [...sharedInputs.map((i) => ({ ...i, path: path.resolve(groupCwd, i.path) })), ...(n.param.taskFile ? [{ path: path.resolve(groupCwd, n.param.taskFile) }] : [])],
					outputs: n.param.outputs ?? [],
				});
				if (!grant.ok) return contractErrorReturn(grant.error);
				nodeGrants.set(n.param.id, grant.value);
				const outputHint = declaredOutputWriteHint(nodeCwd, grant.value, n.param.outputs ?? []);
				if (outputHint) outputWriteHints.push(`${n.param.id} ${outputHint}`);
				const files = createFilePermissionEnforcer(grant.value, nodeCwd);
				for (const input of sharedInputs) {
					const verdict = files.checkRead(path.resolve(groupCwd, input.path));
					if (!verdict.ok) return fail(err("input-in-deny-region", verdict.reason ?? "共享输入不可读", ["sharedInputs.path"], "none", BATCH_MINIMAL_EXAMPLES));
				}
				if (n.param.taskFile !== undefined) {
					// 同批并行的同文件 Write/Edit 先完成再读（工具侧自动串行，模型无需记调用时序）。
					const settled = await awaitPendingFileMutations(n.param.taskFile, groupCwd, { signal: _signal, sessionId: fileMutationSessionId(ctxRaw, groupCwd) });
					if (!settled.ok) return fail(err("task-file-write-pending", `${n.param.id}: ${settled.error!}`, ["nodes.taskFile"], "none"));
					const loaded = readTaskFile(n.param.taskFile, groupCwd, files.checkRead);
					if (!loaded.ok) return contractErrorReturn(withRepair(loaded.error, BATCH_MINIMAL_EXAMPLES));
					n.param.task = `${loaded.value.task}\n\n[任务书来源] ${JSON.stringify(loaded.value.input.path)}（正文已冻结，不追随文件变化）`;
				}
				const inherited = prepareDispatchContext({ contextMode: n.param.contextMode ?? params.contextMode, contextRefs: n.param.contextRefs ?? (n.param.contextMode === undefined ? params.contextRefs : undefined) }, n.param.task, contextSnapshot?.ok ? contextSnapshot.value : undefined, { cwd: nodeCwd, inputPaths: sharedInputs.map(i => i.path), hasDeny: grant.value.deny.length > 0, checkRead: files.checkRead, degradeRefsToInputs: true });
				if (!inherited.ok) return contractErrorReturn(inherited.error);
				n.param.contextMode = inherited.value.mode;
				contextNotices.push(`${n.param.id} ${inherited.value.notice}`);
				// ev-20261031-da3f86：contextRef 降级条目注入该节点 task 正文 [任务输入] 段（不进 sharedInputs——
				// 广播全节点=语义污染；注入在任务书冻结前完成，notice 已含降级披露）。
				const degradedBlock = (inherited.value.degradedRefs ?? []).length > 0
					? `\n\n[任务输入]（contextRef 降级登记；按用途取用）\n${inherited.value.degradedRefs!.map((d) => `- ${JSON.stringify(d.path)}：${d.purpose}（必读）`).join("\n")}`
					: "";
				n.param.task = freezeSelectedEvidence(inherited.value.assignment, inherited.value.archive) + degradedBlock;
			}
			// GroupSpec 构造（K8b 调度面）：共享输入/预期产物注入任务书；依赖节点经 buildTask 在
			// 解锁时刻固定上游回执 hash（handoffBlock 锚点行——归档版本，不随后续决策变化）。
			const runId = `batch-${randomUUID().slice(0, 8)}`;
			const sharedBlock = sharedInputs.length > 0
				? `\n\n[批次共享输入]（task_batch sharedInputs；按用途取用）\n${sharedInputs.map((i) => `- ${JSON.stringify(path.resolve(groupCwd, i.path))}：${i.purpose}（${i.required === false ? "可选" : "必读"}）`).join("\n")}`
				: "";
			const groupNodes: GroupNode[] = graph.nodes.map((n) => {
				const p = n.param;
				const outputsBlock = (p.outputs ?? []).length > 0
					? `\n\n[节点预期产物]（声明冻结进批次图；终态与回执核对）\n${p.outputs!.map((o) => `- ${o.path}${o.kind === "tree" ? "（tree）" : ""}`).join("\n")}`
					: "";
				const base = `${p.task}${sharedBlock}${outputsBlock}`;
				const handoff = (depEnvs: Record<string, ResultEnvelope>): string => {
					const blocks = n.edges.map((e) => handoffBlock(`上游 ${e.nodeId}（requires=${e.requires}）`, depEnvs[e.nodeId]));
					return `${base}\n\n[上游交接·回执已固定]\n${blocks.join("\n\n")}`;
				};
				return {
					nodeId: p.id,
					contextMode: p.contextMode,
					agent: p.agent,
					permission: nodeGrants.get(p.id)!,
					outputs: (p.outputs ?? []).map((o) => ({ ...o, kind: o.kind ?? "file", required: o.required ?? true })),
					...(p.model !== undefined ? { model: p.model } : {}),
					...(p.name !== undefined ? { name: p.name } : {}),
					...(p.cwd !== undefined ? { cwd: p.cwd } : {}),
					...(p.allowedPaths !== undefined ? { allowedPaths: p.allowedPaths } : {}),
					...(p.reportPath !== undefined ? { reportPath: p.reportPath } : {}),
					...(n.edges.length > 0
						? { dependsOn: n.edges.map((e) => e.nodeId), requires: n.requires ?? "accepted", buildTask: handoff }
						: { task: base }),
				};
			});
			const groupDeps: GroupRunDeps = {
				cwd: groupCwd,
				...(ctx.modelRegistry !== undefined ? { modelRegistry: ctx.modelRegistry } : {}),
				...(deps.testOpts?.testCommand !== undefined ? { command: deps.testOpts.testCommand } : {}),
				...(deps.testOpts?.evidence !== undefined ? { evidence: deps.testOpts.evidence } : {}),
				runTask: svc.runTask,
				runResume: svc.runResume,
				findAgent: (name: string) => findAgentByRequest(deps.agents, name),
				trusted: ctx.isProjectTrusted?.() ?? false,
			};
			// ev-20261101-7fffc6：batch 组终局/暂停走 custom 机器通道（details.runId，不冒充 taskId）。
			const notify = (msg: string): void => { try { sendMachineNotice(deps.pi, GROUP_TERMINAL_TYPE, msg, { runId }); } catch { /* 通知失败不回滚组状态 */ } };
			const handle = submitGroup({ runId, nodes: groupNodes }, groupDeps, {
				onDone: (outcome) => notify(batchOutcomeText("终局", outcome)),
				onPaused: (outcome) => notify(batchOutcomeText("暂停·等待人工接受", outcome)),
			});
			// 立即返回组句柄 + 逐节点静态状态（异步提交——不阻塞等完整图，§4.1「输出组句柄和逐节点状态」）
			const taskIds = handle.taskIds();
			const lines = [`[task_batch 已提交 ${runId} · ${graph.nodes.length} 节点 · ${graph.edgeCount} 依赖边 · 静态校验通过]`];
			lines.push(...contextNotices, ...outputWriteHints);
			if (graph.dedupedEdges > 0) lines.push(`（${graph.dedupedEdges} 条重复边已去重）`);
			for (const n of graph.nodes) {
				const started = taskIds[n.param.id];
				lines.push(started
					? `  ${n.param.id} ${n.param.agent} · 已启动 taskId=${started.slice(0, 8)}`
					: n.edges.length === 0
						? `  ${n.param.id} ${n.param.agent} · 启动中（无依赖——进入共享准入队列）`
						: `  ${n.param.id} ${n.param.agent} · 等待 ${n.edges.map((e) => `${e.nodeId}[requires=${e.requires}]`).join(" + ")}`);
			}
			// ev-20260930-2b34b2（R4b §⑥-8）：组说明明确 task_control wait 不接受组句柄——首次使用即知去向，
			// 无需对组 wait 试错（组终局自动通知；单节点控制用节点 taskId）。
			lines.push(`组句柄: ${runId}（节点逐个终态自动通知；requires=accepted 边遇上游回执待接受时组暂停并通知——task_control accept 后自动续跑；单节点控制/查询用各节点 taskId；task_control wait 不接受组句柄——组终局自动通知，无需对组 wait）`);
			return {
				content: [{ type: "text", text: lines.join("\n") }],
				details: { runId, nodeCount: graph.nodes.length, edgeCount: graph.edgeCount, awaiting: false },
			};
		}),
	};
}
