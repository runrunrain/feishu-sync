/**
 * residue.ts — ev-20260905-f51a49（P0）：失败任务的半成品残留检测（轻护栏强感知）。
 *
 * 实战事故：cangjie/e351d4ab——429 失败收场，但中断前子 Agent 已在目标目录写入 33 个半成品
 * 文件；插件与 Leader 均不知情，重派任务书还写「当前为空目录」给了错误世界状态，半成品直接
 * 污染新一轮交付基线。本模块把「失败前到底动了哪些文件」变成可观测、可查询的事实。
 *
 * 归因口径（两档弱断言，与 task-write-log 的登记口径对齐）：
 *   - 确认档：task-write-log 登记命中（子进程 write/edit/bash 成功写盘后登记的绝对路径，
 *     ev-20260903-64641c）且文件仍存在——「确认写入」；
 *   - 疑似档：任务 cwd（+allowedPaths 根）有界浅层扫描（深度≤3、≤200 条目，参照
 *     workspace-preflight 的有界扫描模式）中 mtime ≥ 派发 startedAt 的常规文件——bash 复杂
 *     写法/外部进程写入都可能命中，只提示不回滚。
 *   - 残留数据不自动清理、不阻断任何流程（失败后世界状态如实可见，处置权在 Leader）。
 *
 * 模块纪律（同 fs-mutation-tracker）：零 pi 依赖、纯函数 + node:fs——task-write-log 只作
 * 数据源 import（登记方与消费方互不焊死，无循环边）；pi 句柄不存在于本模块任何路径。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { readTaskWrites } from "./task-write-log.ts";

/** 浅扫排除目录（ev-20260905-f51a49 约定：git 元数据/依赖树/多工作树根不属残留候选）。 */
const RESIDUE_SKIP_DIRS = new Set([".git", "node_modules", ".amagi-worktrees"]);
/** 有界扫描缺省上限（条目；与任务书口径一致）。 */
export const RESIDUE_MAX_ENTRIES = 200;
/** 有界扫描缺省深度。 */
export const RESIDUE_MAX_DEPTH = 3;
/** 残留附注列出的路径上限（其余以总数概括）。 */
export const RESIDUE_NOTE_MAX_PATHS = 5;

export interface ResidueResult {
	/** 确认档：写入登记命中且仍存在的绝对路径（子进程写盘归因，强档）。 */
	confirmed: string[];
	/** 疑似档：扫描命中的派发后改动文件（弱断言，可能含外部写入/未覆盖 bash 写法）。 */
	suspected: string[];
	/** confirmed + suspected 去重合计。 */
	total: number;
}

export interface CollectResidueOpts {
	/** 任务工作目录（扫描根之一）。 */
	cwd?: string;
	/** 派发时刻（mtime 门槛：仅统计该时刻之后改动的文件；缺省则跳过扫描，只读登记档）。 */
	startedAt?: number;
	/** 白名单路径（额外扫描根；与派发时 allowedPaths 同口径）。 */
	allowedPaths?: string[];
	/** 扫描条目上限（缺省 200）。 */
	maxEntries?: number;
	/** 扫描深度上限（缺省 3）。 */
	maxDepth?: number;
}

/**
 * 采集失败任务的残留文件（确认档=写入登记命中；疑似档=mtime 扫描命中）。
 * 纯同步有界（≤maxEntries 条目、≤maxDepth 深度），任何异常静默降级为空结果——
 * 观测数据绝不影响执行路径。
 */
export function collectResidue(taskId: string, opts: CollectResidueOpts = {}): ResidueResult {
	const confirmed: string[] = [];
	const seen = new Set<string>();
	// ① 确认档：写入登记（登记方负责绝对路径解析；文件已删除的不算残留）。
	try {
		for (const w of readTaskWrites(taskId)) {
			const p = path.normalize(String(w.file || ""));
			if (!p || seen.has(p)) continue;
			try { if (!fs.existsSync(p)) continue; } catch { continue; }
			seen.add(p);
			confirmed.push(p);
		}
	} catch { /* 登记读取失败静默 */ }
	// ② 疑似档：有界浅扫（startedAt 缺省/非法时跳过——无派发基线的扫描会把存量文件全误报）。
	const startedAt = typeof opts.startedAt === "number" && Number.isFinite(opts.startedAt) && opts.startedAt > 0 ? opts.startedAt : undefined;
	const suspected: string[] = [];
	if (startedAt !== undefined) {
		const roots = [...new Set([opts.cwd, ...(opts.allowedPaths || [])].map((p) => (typeof p === "string" ? p.trim() : "")).filter(Boolean).map((p) => path.resolve(p)))];
		const budget = Math.max(1, Math.floor(opts.maxEntries ?? RESIDUE_MAX_ENTRIES));
		const maxDepth = Math.max(0, Math.floor(opts.maxDepth ?? RESIDUE_MAX_DEPTH));
		let visited = 0;
		const walk = (dir: string, depth: number): void => {
			if (depth > maxDepth || visited >= budget) return;
			let entries: fs.Dirent[];
			try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
			for (const e of entries) {
				if (visited >= budget) return;
				visited++;
				if (RESIDUE_SKIP_DIRS.has(e.name)) continue;
				const abs = path.join(dir, e.name);
				try {
					if (e.isDirectory()) walk(abs, depth + 1);
					else if (e.isFile()) {
						if (fs.statSync(abs).mtimeMs >= startedAt - 1 && !seen.has(abs)) {
							seen.add(abs);
							suspected.push(abs);
						}
					}
				} catch { /* 单项失败跳过 */ }
			}
		};
		for (const r of roots) { walk(r, 0); if (visited >= budget) break; }
	}
	return { confirmed, suspected, total: confirmed.length + suspected.length };
}

/**
 * 残留附注文案（N=0 返回空串，调用方不追加）。文案口径：任务书 ev-20260905-f51a49——
 * 「重派前请先核验，避免半成品污染交付基线」。
 */
export function residueNote(r: ResidueResult | null | undefined, maxPaths: number = RESIDUE_NOTE_MAX_PATHS): string {
	if (!r || r.total === 0) return "";
	const paths = [...r.confirmed, ...r.suspected].slice(0, Math.max(1, maxPaths));
	const more = r.total > paths.length ? `（共 ${r.total} 个，列出前 ${paths.length} 个）` : "";
	return `[残留半成品] 该失败任务已写入/改动 ${r.total} 个文件（${r.confirmed.length} 个确认、${r.suspected.length} 个疑似）：${paths.join("、")}${more} ——重派前请先核验，避免半成品污染交付基线`;
}
