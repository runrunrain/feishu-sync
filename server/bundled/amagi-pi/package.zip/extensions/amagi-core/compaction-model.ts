/** 在 pi 原生压缩生命周期中切换摘要模型；摘要算法、切点与会话落盘仍由宿主提供。 */
import * as pi from "@earendil-works/pi-coding-agent";
import * as piAi from "@earendil-works/pi-ai";
import * as path from "node:path";
import { bindCompactionConfig, compactionConfigCwd, resolveCompactionConfig, takeCompactionAuthEnv, loadCompactionNativeAi } from "./compaction-config.ts";
import { getGlobalConfigPath } from "./model-resolver.ts";
import { redactCredentials } from "./task-query-wire.ts";

export function registerCompactionModel(api: pi.ExtensionAPI): void {
	const authEnv = takeCompactionAuthEnv();
	api.on("session_start", async (_event, ctx) => {
		await loadCompactionNativeAi();
		bindCompactionConfig(ctx.cwd, (provider) => ctx.modelRegistry.getRegisteredProviderConfig?.(provider));
	});
	api.on("session_before_compact", async (event, ctx) => {
		let selected: string | null = null;
		try {
			const config = resolveCompactionConfig(compactionConfigCwd(ctx.cwd));
			selected = config.model;
			if (!selected) return undefined;
			const nativeAi = await loadCompactionNativeAi();
			const model = ctx.modelRegistry.find(config.provider!, config.id!);
			if (!model) throw new Error("compaction.model 未在 pi 模型目录中注册；请检查 /amagi doctor 和 /model");
			if (config.thinkingLevel && !piAi.getSupportedThinkingLevels(model).includes(config.thinkingLevel)) throw new Error("compaction.model 请求的 thinking 档位不受模型支持");
			if (typeof pi.compact !== "function") throw new Error("当前 pi 未提供公开 compact 接口");
			const stream: Parameters<typeof pi.compact>[7] = async (target, context, options) => {
				event.signal.throwIfAborted();
				// 检查原生算法最终构造的摘要请求；插件不为适配小模型额外裁剪正文或旧摘要。
				const input = context.messages.reduce((total, message) => total + pi.estimateTokens(message), 0);
				if (input + (options?.maxTokens ?? target.maxTokens) + 256 > target.contextWindow) throw new Error("压缩模型上下文窗口不足；插件未裁剪原生摘要请求，请配置更大窗口模型");
				const request = { ...options, env: { ...options?.env, ...(authEnv.provider === target.provider ? authEnv.values : {}) } };
				let emitted;
				if (typeof ctx.modelRegistry.streamSimple === "function") emitted = ctx.modelRegistry.streamSimple(target, context, request);
				else {
					// 旧宿主仍使用公开原生认证/流接口；不修改宿主 process.env 或会话工作模型。
					const auth = await ctx.modelRegistry.getApiKeyAndHeaders(target);
					if (auth.ok === false) throw new Error("压缩模型原生认证失败");
					if (!nativeAi.streamSimple) throw new Error("当前 pi 未提供公开模型流接口");
					const requestModel = auth.baseUrl ? { ...target, baseUrl: auth.baseUrl } : target;
					emitted = await nativeAi.streamSimple(requestModel, context, { ...request, apiKey: auth.apiKey, headers: auth.headers, env: { ...auth.env, ...request.env } });
				}
				const response = await emitted.result();
				// 原生 helper 已拒绝 error/length/aborted；补齐空白或意外工具调用，防文件列表掩盖空摘要。
				if (response.stopReason !== "error" && response.stopReason !== "length" && response.stopReason !== "aborted"
					&& (!response.content.some(c => c.type === "text" && c.text.trim()) || response.content.some(c => c.type === "toolCall"))) {
					throw new Error("压缩模型未返回有效文本摘要");
				}
				return emitted;
			};
			const retry = pi.SettingsManager.create(ctx.cwd, path.dirname(getGlobalConfigPath()), { projectTrusted: ctx.isProjectTrusted?.() ?? true }).getRetrySettings();
			const compaction = await pi.compact(event.preparation, model, undefined, undefined, event.customInstructions,
				event.signal, config.thinkingLevel, stream, undefined, retry, {
					onRetryScheduled: (attempt, maxAttempts) => ctx.ui.notify(`统一模型压缩重试 ${attempt}/${maxAttempts}`, "info"),
				}, ctx.sessionManager.getSessionId());
			return { compaction };
		} catch (error) {
			// pi 的事件分发器会吞掉 handler 异常并继续默认压缩；必须显式 cancel 才能禁止静默回退。
			const message = redactCredentials(error instanceof Error ? error.message : "原生摘要生成失败");
			try { ctx.ui.notify(`统一模型压缩未完成${selected ? `（${selected}）` : ""}：${message}`, "error"); } catch { /* UI 故障不能放行默认压缩。 */ }
			return { cancel: true };
		}
	});
}
