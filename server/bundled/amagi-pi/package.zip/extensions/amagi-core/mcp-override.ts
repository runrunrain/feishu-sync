/**
 * mcp-override.ts — mcp_call 参数形状纠错包装（无感知辅助，不阻断）+ P2 wire 定义面。
 *
 * 实战痛点（复盘 2026-08-20《跨仓webui六连修》§mcp_call 连败 4 次）：模型把业务字段
 * （image_source/prompt 等）直接放 mcp_call 参数顶层，或嵌进 arguments 却漏掉 server/tool。
 * pi 核心对工具参数的 TypeBox 校验发生在 beforeToolCall 事件与 execute 之前——错形调用
 * 根本到不了 execute，模型拿到的是裸 `Validation failed for tool "mcp_call": - server:
 * must have required properties server, tool`，无形状示例、无纠错指引，连败 4 次（含嵌套
 * arguments 尝试）。（pi 1.5.0 起宿主改 pi-schema 校验，文案变为 `- server: missing` 形态；
 * 本包装的宽松 schema + 自持形状预检不依赖任何宿主校验文案匹配，两代文案下行为不变。）v1.5.250 起 mcp_call 是 MCP 唯一通道（远端工具直连注册已删），错形纠错
 * 从锦上添花变为关键防线，本包装保持原职责不变。
 *
 * 接线策略（bash-override/edit-override 同族的「同名覆盖 + 委托原生」模式；mcp_call 非内建
 * 而由 mcp-client.ts 注册，故用注册流捕获而非 import 原生定义）：
 *  - index.ts 在调用 registerConfiguredMcpServers 时传入 createMcpCallCapturePi(pi) 的
 *    Proxy——只拦截 registerTool 透传原行为，途经 name==="mcp_call" 的定义（含 transport
 *    闭包）即被捕获；注册完成后 registerMcpCallShapeOverride 以同名再注册覆盖版
 *    （pi extension.tools 为 Map，同名后注册者胜）。捕获失败/覆盖注册抛错 → 原生已注册，
 *    静默保持原生（零行为变化）。
 *  - 覆盖版 schema 放宽为 server/tool/arguments 全 Optional + additionalProperties——错形
 *    调用得以通过 pi 校验进入 execute（原生严格 schema 下这些调用只会吃裸校验错误）；
 *  - execute 先做轻量形状预检（纯函数 detectMcpCallShapeIssue，不改写、不自动纠正）：
 *      ① server/tool 不完整（业务字段在顶层或嵌在 arguments）→ 不调远端，返回含实际
 *         字段名的可复制正确形状示例；
 *      ② server/tool 齐备但 arguments 缺席、已知业务字段错放顶层（会被原生静默丢弃）→ 同上；
 *  - 正确形状 → 原样委托捕获的原生 execute（transport/截断/错误模型/details 零变化）。
 *  - 纠错结果 isError:true（与 mcp-client 自身失败口径一致：模型视作失败调用，按示例重发；
 *    「不阻断」指绝不拦截重试）。
 *  - promptGuidelines 追加一行形状约定（该工具激活时进系统提示，事前预防优于事后纠错）。
 */

import { Type } from "typebox";
// P2-mcp-connect（设计 §3.1–§3.3 + §9 P2 行）：mcp_call 结构化输出接线——本模块职责边界裁定
// （任务书把 wire 映射列在 override 名下，但「同一远端返回对象/异常实例」只在 mcp-client native
// execute 内可达：经 details 透传原始载荷会造成未脱敏第二副本与双倍载荷，违反 single-read 与
// 脱敏纪律）——wire 载体（成功/权限/远端错/分类错）在 mcp-client native execute 同次构造；本模块
// 携带：①定义面 outputSchema（P1 唯一规格；原生注册面已同款双保险，捕获覆盖失败也不丢 schema）；
// ②错形参数路径的 Failure wire（shape 预检是本模块自有职责，错误在此产生也在此分类）；
// ③正确形状原样透传（native 返回携 structuredContent，随原样展开保留——正文字节契约红线）。
import { McpCallOutputSchema, toMcpCallErrorWire } from "./mcp-wire.ts";
// B6a（十月迭代 M3，设计 §5.3/§7.2-3）：入口分流——正确形状的 mcp_call 若指向 host-owner
// server，在包装层直接返回「请使用原生工具」指引（不透传原生 execute）；文本与原生层
// fallback 同源（mcp-host-bridge 单一来源），捕获/覆盖失败时原生层同样拦截，双保险。
import { hostOwnerGuidanceText, ownerOfServerInPlan, type McpOwnershipPlan } from "./mcp-host-bridge.ts";

/** 宿主 structuredContent 载面桥（同 mcp-client.asWireContent；本模块保持零 mcp-client import
 *  纪律，仅类型层桥接——值本身 JSON-safe 由 P1 测试实证）。 */
const asWireContent = (w: unknown) => w as never;

/** mcp_call 的三个 envelope 键（meta）；其余顶层键都视为疑似错放的业务字段。 */
const MCP_CALL_META_KEYS = new Set(["server", "tool", "arguments"]);

/**
 * 已知 MCP 业务字段启发集（仅用于「server/tool 齐备 + arguments 缺席」分支判定顶层
 * 错放字段——该场景下原生会静默丢弃顶层字段，宁可提示也不静默丢参）。
 * 来源：仓内智谱 MCP 工具参数（search_query/repo_name/url…，含原 mcp-tools.ts 时代积累，
 * v1.5.245 起由 mcp-client.ts 承载）+ 智谱视觉理解 MCP（实战连败当事参数 image_source/prompt）
 * + 常见 MCP 工具参数。
 */
const KNOWN_MCP_BUSINESS_FIELDS = new Set([
	// 智谱 web-search-prime / zread×3 / web-reader（原 mcp-tools.ts，现 mcp-client.ts）
	"search_query", "search_domain_filter", "search_recency_filter", "content_size", "location",
	"repo_name", "query", "language", "file_path", "dir_path",
	"url", "timeout", "no_cache", "return_format", "retain_images", "no_gfm", "keep_img_data_url",
	"with_images_summary", "with_links_summary",
	// 智谱视觉理解 MCP（@z_ai/mcp-server，实战连败 4 次的当事参数）
	"image_source", "image", "images", "prompt",
	// 常见 MCP 工具业务参数
	"input", "input_text", "text", "content", "message", "messages", "question",
	"keyword", "keywords", "code", "data", "body", "title", "description",
	"file", "files", "file_name", "path", "target", "command", "cmd",
]);

export type McpCallShapeIssueKind = "missing-envelope" | "flat-fields";

export interface McpCallShapeIssue {
	/** missing-envelope：server/tool 不完整；flat-fields：齐备但业务字段错放顶层（会被静默丢弃）。 */
	kind: McpCallShapeIssueKind;
	/** 收到的原始参数对象（示例构造用）。 */
	params: Record<string, unknown>;
	/** 错放的业务字段（名→实际值，取自嵌套 arguments 或顶层），用于纠错示例填充。 */
	sampleArgs: Record<string, unknown>;
	/** 顶层出现的非 envelope 键（诊断行用）。 */
	topLevelFields: string[];
	/** 是否存在嵌套 arguments 对象。 */
	hasNestedArguments: boolean;
}

/**
 * 纯函数：轻量形状预检。返回 null = 正确形状（透传原生，零干预）。
 *  - ① server/tool 任一缺失/非字符串：原生严格 schema 必拒（裸 Validation failed），无论
 *    业务字段在顶层还是嵌在 arguments——统一给形状纠错而非裸校验错误；
 *  - ② server/tool 齐备 + arguments 缺席 + 已知业务字段在顶层：原生会接受该调用但静默丢弃
 *    顶层业务字段（远端按空参执行几乎必错），提前给纠错。
 */
export function detectMcpCallShapeIssue(params: unknown): McpCallShapeIssue | null {
	if (!params || typeof params !== "object" || Array.isArray(params)) return null;
	const p = params as Record<string, unknown>;
	const hasServer = typeof p.server === "string" && p.server.trim() !== "";
	const hasTool = typeof p.tool === "string" && p.tool.trim() !== "";
	const nested = p.arguments && typeof p.arguments === "object" && !Array.isArray(p.arguments)
		? (p.arguments as Record<string, unknown>) : null;
	const topLevelFields = Object.keys(p).filter((k) => !MCP_CALL_META_KEYS.has(k));
	if (!hasServer || !hasTool) {
		const sampleArgs = nested
			? { ...nested }
			: Object.fromEntries(topLevelFields.map((k) => [k, p[k]]));
		return { kind: "missing-envelope", params: p, sampleArgs, topLevelFields, hasNestedArguments: nested !== null };
	}
	if (!nested) {
		const flat = topLevelFields.filter((k) => KNOWN_MCP_BUSINESS_FIELDS.has(k));
		if (flat.length > 0) {
			return {
				kind: "flat-fields", params: p,
				sampleArgs: Object.fromEntries(flat.map((k) => [k, p[k]])),
				topLevelFields, hasNestedArguments: false,
			};
		}
	}
	return null;
}

/** 示例值预览：字符串保留 JSON 引号、超长截断（防 base64/超长路径刷屏）。 */
function previewValue(v: unknown): string {
	if (v === undefined) return "<值>";
	if (typeof v === "string") {
		const s = v.length > 60 ? `${v.slice(0, 57)}…` : v;
		return JSON.stringify(s);
	}
	try {
		const s = JSON.stringify(v) ?? "<值>";
		return s.length > 80 ? `${s.slice(0, 77)}…` : s;
	} catch { return "<值>"; }
}

/**
 * 纯函数：构造纠错文本（无形状问题 → null）。含：诊断行 + 用实际字段名填充的正确形状
 * 可复制示例 + server/tool 说明 + 不阻断重试语义。
 */
export function mcpCallShapeAdviceText(params: unknown): string | null {
	const issue = detectMcpCallShapeIssue(params);
	if (!issue) return null;
	const p = issue.params;
	const server = typeof p.server === "string" && p.server.trim() !== "" ? JSON.stringify(p.server) : "\"<server名>\"";
	const tool = typeof p.tool === "string" && p.tool.trim() !== "" ? JSON.stringify(p.tool) : "\"<远端工具名>\"";
	const argsEntries = Object.entries(issue.sampleArgs).map(([k, v]) => `${JSON.stringify(k)}:${previewValue(v)}`);
	const example = `{"server":${server},"tool":${tool},"arguments":{${argsEntries.join(",")}}}`;
	const diagnosis = issue.kind === "flat-fields"
		? `本次收到顶层字段：${issue.topLevelFields.join(", ") || "（无）"}（server/tool 齐备但 arguments 缺席——顶层业务字段会被静默丢弃）`
		: `本次收到顶层字段：${[...issue.topLevelFields, ...(issue.hasNestedArguments ? ["arguments"] : [])].join(", ") || "（无）"}（server/tool 不完整${issue.hasNestedArguments ? "；业务字段已嵌在 arguments，只差 envelope" : ""}）`;
	const lines = [
		`[AMAGI mcp_call] 参数形状不匹配（未发出远端调用）：${diagnosis}`,
		`- 正确形状（业务字段全部放进 arguments，已用本次实际字段名填充，可复制修改）：${example}`,
		"- server=已配置的 MCP server 名、tool=远端工具名（清单与参数用 mcp_list_tools 查看）；顶层只允许 server/tool/arguments 三键。",
	];
	lines.push("本提示不阻断重试：按上方形状重发 mcp_call 即可。");
	return lines.join("\n");
}

/** mcp_call 原生定义的最小结构面（mcp-client.ts 注册形状；方法语法保证参数双向兼容）。
 *  P2：outputSchema 槽透传（宿主 0.99+ ToolDefinition.outputSchema——原生注册面已挂 P1 wire
 *  schema；wrapper 携带它随同名覆盖落到最终注册面）。 */
export interface McpCallNativeTool {
	name: "mcp_call";
	label?: string;
	description: string;
	parameters: object;
	outputSchema?: unknown;
	execute(toolCallId: string, params: unknown, signal: AbortSignal | undefined, onUpdate: ((partial: unknown) => void) | undefined, ctx: unknown): Promise<unknown>;
	promptGuidelines?: unknown;
	[k: string]: unknown;
}

/** 覆盖版宽松 schema：server/tool/arguments 全 Optional——错形调用得以进入 execute 做形状预检。 */
const McpCallShapeParams = Type.Object({
	server: Type.Optional(Type.String({ description: "MCP server 名（必填；配置于 mcp.json/.mcp.json，用 mcp_list_tools 查看）" })),
	tool: Type.Optional(Type.String({ description: "远端工具名（必填；用 mcp_list_tools 查看）" })),
	arguments: Type.Optional(Type.Record(Type.String(), Type.Any(), { description: "工具参数对象（业务字段全部放这里，不要放参数顶层）" })),
}, { additionalProperties: true });

/** 取字符串值（details 构造用；非字符串返回空串）。 */
function strOrEmpty(v: unknown): string {
	return typeof v === "string" ? v : "";
}

/** 取已解析 server/tool（wire 只放已解析值——非法原值不回显，§3.2）；空串/非字符串 → null。 */
function resolvedOrNull(v: unknown): string | null {
	return typeof v === "string" && v.trim() !== "" ? v : null;
}

/**
 * 包装 mcp_call：形状预检（错形 → 纠错文本，isError:true，不调远端）+ 正确形状原样委托原生。
 * B6a：opts.ownershipPlan（mode=mixed）时，正确形状先做 host-owner 入口分流——不向原生
 * execute 透传（零嵌套重试）；无计划/非 mixed → 零行为变化。
 * renderCall/renderResult 省略继承默认渲染；结果 shape 由原生 execute 产出，天然一致。
 */
export function createMcpCallShapeOverrideTool(nativeTool: McpCallNativeTool, opts?: { ownershipPlan?: McpOwnershipPlan }): McpCallNativeTool {
	const guidelines: string[] = Array.isArray(nativeTool.promptGuidelines)
		? nativeTool.promptGuidelines.map((g) => String(g)) : [];
	guidelines.push("mcp_call 业务参数必须全部放进 arguments：{server, tool, arguments:{业务字段}}；顶层只允许这三键");
	return {
		...nativeTool,
		name: "mcp_call" as const,
		label: nativeTool.label ?? "MCP Call",
		description: `${nativeTool.description} 参数形状：{"server":"...","tool":"...","arguments":{业务字段}}——业务字段必须全部放进 arguments，不要放参数顶层。`,
		parameters: McpCallShapeParams,
		// P2：wrapper 携带 outputSchema（同名覆盖后这是最终注册面）——原生携带则透传（随原生演进），
		// 缺省回退 P1 唯一规格（stub 原生/旧版原生也不丢 schema 声明）。
		outputSchema: (nativeTool.outputSchema as object | undefined) ?? McpCallOutputSchema,
		promptGuidelines: guidelines,
		async execute(toolCallId, params, signal, onUpdate, ctx) {
			const issue = detectMcpCallShapeIssue(params);
			if (issue) {
				const text = mcpCallShapeAdviceText(params)
				?? "[AMAGI mcp_call] 参数形状不匹配：业务字段必须全部放进 arguments（{server, tool, arguments:{业务字段}}）。本提示不阻断重试。";
				// isError:true 与 mcp-client 自身失败口径一致（模型按失败处理并依示例重发）
				// P2：错形双载体——正文照旧 + Failure wire（code=shape，预 transport 零副作用 → effects 缺省 none；
				// repairExamples 用实际字段名回填的最小合法调用，与正文示例同源）。
				const server = resolvedOrNull(issue.params.server);
				const tool = resolvedOrNull(issue.params.tool);
				return {
					content: [{ type: "text" as const, text }],
					isError: true as const,
					details: { mcpServer: strOrEmpty(issue.params.server), remoteTool: strOrEmpty(issue.params.tool), isError: true, shapeAdvice: issue.kind },
					structuredContent: asWireContent(toMcpCallErrorWire({
						server,
						tool,
						error: {
							code: "shape",
							message: text,
							repairExamples: [{ server: server ?? "<server名>", tool: tool ?? "<远端工具名>", arguments: { ...issue.sampleArgs } }],
						},
					})),
				};
			}
			// B6a（设计 §7.2-3）：host owner 入口分流——预 transport 零副作用，不透传原生（双保险的
			// 前置层；捕获失败时 mcp-client 原生 execute 同样拦截）。wire 载体复用 permission code
			// （通道路由拒绝，effects=none），details 加 hostOwnerRedirect 标记。
			const p = params as { server: string; tool: string; arguments?: Record<string, unknown> };
			if (ownerOfServerInPlan(opts?.ownershipPlan, p.server) === "host") {
				const text = hostOwnerGuidanceText(p.server, p.tool);
				return {
					content: [{ type: "text" as const, text }],
					isError: true as const,
					details: { mcpServer: p.server, remoteTool: p.tool, isError: true, hostOwnerRedirect: true, shapeAdvice: undefined },
					structuredContent: asWireContent(toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code: "permission", message: text, repairExamples: [] } })),
				};
			}
			// 正确形状 → 只取三键委托原生（顶层多余键本就会被原生忽略；不透传保持原生输入干净）。
			// P2：native 返回携同次 wire（structuredContent）——原样透传即双载体，零二次投影。
			const nativeArgs: Record<string, unknown> = { server: p.server, tool: p.tool };
			if (p.arguments !== undefined) nativeArgs.arguments = p.arguments;
			return nativeTool.execute(toolCallId, nativeArgs, signal, onUpdate, ctx);
		},
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// 接线件：注册流捕获（mcp_call 非内建工具，原生定义藏在 mcp-client.ts 闭包里）。
// ─────────────────────────────────────────────────────────────────────────────

/** 形状纠错接线所需的最小 pi 面。 */
export interface McpCallOverridePi {
	registerTool(tool: unknown): void;
}

/**
 * 捕获注册流中的原生 mcp_call 定义：返回 Proxy pi（只拦截 registerTool，原样透传注册；
 * 途经 name==="mcp_call" 的定义即被记录）+ takeNative()。mcp-client 其余注册/事件不受影响。
 */
export function createMcpCallCapturePi<T extends { registerTool(tool: unknown): void }>(pi: T): { pi: T; takeNative: () => McpCallNativeTool | undefined } {
	let native: McpCallNativeTool | undefined;
	const proxy = new Proxy(pi, {
		get(target, prop, receiver) {
			if (prop === "registerTool") {
				return (tool: unknown): void => {
					if (tool && typeof tool === "object" && (tool as { name?: unknown }).name === "mcp_call") {
						native = tool as McpCallNativeTool;
					}
					target.registerTool(tool);
				};
			}
			return Reflect.get(target, prop, receiver);
		},
	}) as T;
	return { pi: proxy, takeNative: () => native };
}

/**
 * 原生注册完成后以同名再注册覆盖版（同名后注册者胜）：形状预检对错形调用生效；
 * B6a：opts.ownershipPlan 传入时同步做 host-owner 入口分流（与 mcp-client 原生层双保险）。
 * 捕获缺席/覆盖注册抛错 → 原生已注册，静默保持原生（零行为变化，原生层仍拦截 host owner）。返回是否覆盖成功。
 */
export function registerMcpCallShapeOverride(pi: McpCallOverridePi, native: McpCallNativeTool | undefined, opts?: { ownershipPlan?: McpOwnershipPlan }): boolean {
	if (!native) return false;
	try {
		pi.registerTool(createMcpCallShapeOverrideTool(native, opts));
		return true;
	} catch { return false; /* 静默回退：原生 mcp_call 不受影响 */ }
}
