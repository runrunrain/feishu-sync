/**
 * win-exec-config.ts — 项目 amagi.json 的 `windows` 段解析（win_exec 工具配置面）。
 *
 * 容错口径与 shell.pathPrepend / evidenceTimeouts 一致：文件缺失/非法 JSON/形状非法 →
 * 空配置零问题（现状行为零变化）；段内非法条目跳过并收集 problems（doctor 可见，不阻断
 * 派发）。每次读取现盘（KB 级文件，spawn 频率下开销微秒级，改动即时生效）。
 *
 * 结构（schemas/amagi-config.json `windows` 节为权威 schema）：
 *   windows.exec.enabled        —— 总开关（缺省 true；false 显式关闭注册）
 *   windows.exec.programs       —— name → 路径(string) 或 {path, longRunning?, exclusive?, supervised?, timeoutS?}
 *   windows.exec.allowRoots     —— 显式路径放行根（Windows 绝对路径或 /mnt 形态均可）
 *   windows.exec.envAllow       —— env 白名单键扩展（默认空）
 *   windows.exec.groups         —— { <name>: { killImages: string[], longRunning?: bool, timeoutS?: number } }
 *   windows.exec.defaultTimeoutS / maxTimeoutS / fallbackEncoding
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { isWindowsAbsolutePath, isUnderMnt } from "./win-exec-paths.ts";

/** 单个显式程序声明（覆盖内置表）。 */
export interface WinExecProgramConfig {
	path: string;
	longRunning?: boolean;
	exclusive?: string;
	supervised?: boolean;
	timeoutS?: number;
}

export interface WinExecGroupConfig {
	name: string;
	killImages: string[];
	longRunning: boolean;
	timeoutS?: number;
}

export interface WinExecConfig {
	enabled: boolean;
	programs: Map<string, WinExecProgramConfig>;
	allowRoots: string[];
	envAllow: string[];
	groups: Map<string, WinExecGroupConfig>;
	defaultTimeoutS: number;
	maxTimeoutS: number;
	fallbackEncoding?: string;
	/** M2：powershell/cmd 是否对模型开放（仅受信配置生效；默认 false）。 */
	allowShells: boolean;
	/** M2：git -c 全局配置参数是否放行（仅受信配置生效；默认 false——core.sshCommand 等执行类注入面）。 */
	gitAllowDashC: boolean;
	problems: string[];
}

export const WIN_EXEC_DEFAULT_TIMEOUT_S = 120;
export const WIN_EXEC_LONGRUN_TIMEOUT_S = 1800;
export const WIN_EXEC_MAX_TIMEOUT_S = 3600;

export function emptyWinExecConfig(): WinExecConfig {
	return {
		enabled: true,
		programs: new Map(),
		allowRoots: [],
		envAllow: [],
		groups: new Map(),
		defaultTimeoutS: WIN_EXEC_DEFAULT_TIMEOUT_S,
		maxTimeoutS: WIN_EXEC_MAX_TIMEOUT_S,
		allowShells: false,
		gitAllowDashC: false,
		problems: [],
	};
}

/** M3：安全敏感字段集——只从全局配置或受信项目读取；不受信项目忽略并记 doctor 问题。 */
const TRUSTED_ONLY_FIELDS = ["programs", "allowRoots", "groups.*.killImages", "envAllow", "allowShells", "gitAllowDashC"] as const;

/**
 * M3 信任门：不受信项目的 amagi.json 只允许 enabled=false（关闭总是安全）；安全敏感字段
 * （programs/allowRoots/groups/envAllow/allowShells/gitAllowDashC）忽略并逐项记 problems。
 * 返回剥离后的新配置对象（原对象不改写；调用方持有受信全局配置时另行合并——本仓项目级
 * 读取链只有 cwd/amagi.json 一处，受信判定由调用方注入）。
 */
export function applyWinExecConfigTrust(cfg: WinExecConfig, projectTrusted: boolean): WinExecConfig {
	if (projectTrusted) return cfg;
	const next: WinExecConfig = {
		...cfg,
		programs: new Map(),
		allowRoots: [],
		envAllow: [],
		groups: new Map(),
		allowShells: false,
		gitAllowDashC: false,
		problems: [...cfg.problems],
	};
	if (cfg.programs.size > 0 || cfg.allowRoots.length > 0 || cfg.envAllow.length > 0 || cfg.groups.size > 0 || cfg.allowShells || cfg.gitAllowDashC) {
		next.problems.push(`项目 amagi.json 未受信（trust context）：windows.exec 的 ${TRUSTED_ONLY_FIELDS.join("、")} 已忽略——安全敏感配置只从全局配置（~/.pi/agent/amagi.json）或受信项目读取；本文件仅允许 windows.exec.enabled=false`);
	}
	return next;
}

function str(v: unknown): string | null {
	return typeof v === "string" && v.trim() !== "" ? v : null;
}

function positiveInt(v: unknown): number | undefined {
	return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : undefined;
}

/** 程序映射值解析：string=路径；object={path,...}；其余跳过记 problems。 */
function parseProgramValue(name: string, v: unknown, problems: string[]): WinExecProgramConfig | null {
	if (typeof v === "string") {
		if (v.trim() === "") { problems.push(`windows.exec.programs["${name}"] 是空字符串，跳过`); return null; }
		return { path: v.trim() };
	}
	if (v !== null && typeof v === "object" && !Array.isArray(v)) {
		const o = v as Record<string, unknown>;
		const p = str(o.path);
		if (!p) { problems.push(`windows.exec.programs["${name}"].path 缺失或非字符串，跳过`); return null; }
		const cfg: WinExecProgramConfig = { path: p };
		if (o.longRunning !== undefined) {
			if (typeof o.longRunning === "boolean") cfg.longRunning = o.longRunning;
			else problems.push(`windows.exec.programs["${name}"].longRunning 须为 boolean，已忽略`);
		}
		const ex = str(o.exclusive);
		if (ex !== null) cfg.exclusive = ex;
		if (o.supervised !== undefined) {
			if (typeof o.supervised === "boolean") cfg.supervised = o.supervised;
			else problems.push(`windows.exec.programs["${name}"].supervised 须为 boolean，已忽略`);
		}
		const t = positiveInt(o.timeoutS);
		if (t !== undefined) cfg.timeoutS = t;
		else if (o.timeoutS !== undefined) problems.push(`windows.exec.programs["${name}"].timeoutS 须为正数（秒），已忽略`);
		return cfg;
	}
	problems.push(`windows.exec.programs["${name}"] 须为路径字符串或 {path,...} 对象，跳过`);
	return null;
}

/**
 * 读取 <cwd>/amagi.json 的 windows.exec 段。readFileSync 可注入供测试隔离；文件缺失/非法
 * JSON → 空配置（零问题）——未配置 win_exec 是正常态，不是问题。
 */
export function readWinExecConfig(
	cwd: string | undefined,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): WinExecConfig {
	if (typeof cwd !== "string" || !cwd) return emptyWinExecConfig();
	return parseWinExecConfigFile(path.join(cwd, "amagi.json"), readFileSync);
}

/** 全局 amagi.json（$PI_CODING_AGENT_DIR 或 ~/.pi/agent）的 windows.exec 段——天然受信，安全字段只在此或受信项目生效。 */
export function globalWinExecConfigPath(env: NodeJS.ProcessEnv = process.env): string {
	return path.join(env.PI_CODING_AGENT_DIR ?? path.join(String(env.HOME ?? ""), ".pi", "agent"), "amagi.json");
}

export function readGlobalWinExecConfig(
	env: NodeJS.ProcessEnv = process.env,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): WinExecConfig {
	return parseWinExecConfigFile(globalWinExecConfigPath(env), readFileSync);
}

/**
 * 合并：全局（受信）为底，项目层（已过 applyWinExecConfigTrust）叠加。enabled 任一层 false 即关闭；
 * programs/groups 同名项目覆盖不允许（全局优先，防不受信/受信项目重定向全局声明）；列表并集去重。
 */
export function mergeWinExecConfig(globalCfg: WinExecConfig, projectCfg: WinExecConfig): WinExecConfig {
	const programs = new Map(projectCfg.programs);
	for (const [k, v] of globalCfg.programs) programs.set(k, v);
	const groups = new Map(projectCfg.groups);
	for (const [k, v] of globalCfg.groups) groups.set(k, v);
	const uniq = (a: string[], b: string[]) => [...new Set([...a, ...b])];
	return {
		...projectCfg,
		enabled: globalCfg.enabled && projectCfg.enabled,
		programs,
		groups,
		allowRoots: uniq(globalCfg.allowRoots, projectCfg.allowRoots),
		envAllow: uniq(globalCfg.envAllow, projectCfg.envAllow),
		allowShells: globalCfg.allowShells || projectCfg.allowShells,
		gitAllowDashC: globalCfg.gitAllowDashC || projectCfg.gitAllowDashC,
		fallbackEncoding: globalCfg.fallbackEncoding ?? projectCfg.fallbackEncoding,
		problems: [...globalCfg.problems.map((x) => `[全局] ${x}`), ...projectCfg.problems],
	};
}

function parseWinExecConfigFile(
	file: string,
	readFileSync: (p: string, enc: "utf8") => string,
): WinExecConfig {
	const cfg = emptyWinExecConfig();
	let raw: string;
	try {
		raw = readFileSync(file, "utf8");
	} catch { /* lint-exempt:文件缺失/不可读 → 空配置（容错口径同 pathPrepend） */ return cfg; }
	let parsed: unknown;
	try { parsed = JSON.parse(raw); } catch { /* lint-exempt:非法 JSON → 空配置（不阻断） */ return cfg; }
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return cfg;
	const windows = (parsed as Record<string, unknown>).windows;
	if (windows === undefined) return cfg;
	if (windows === null || typeof windows !== "object" || Array.isArray(windows)) {
		cfg.problems.push("windows 段必须是对象，实际不是——整段忽略");
		return cfg;
	}
	const exec = (windows as Record<string, unknown>).exec;
	if (exec === undefined) return cfg;
	if (exec === null || typeof exec !== "object" || Array.isArray(exec)) {
		cfg.problems.push("windows.exec 段必须是对象，实际不是——整段忽略");
		return cfg;
	}
	const o = exec as Record<string, unknown>;

	if (o.enabled !== undefined) {
		if (typeof o.enabled === "boolean") cfg.enabled = o.enabled;
		else cfg.problems.push(`windows.exec.enabled 须为 boolean（收到 ${JSON.stringify(o.enabled)}），已忽略`);
	}
	for (const [key, field] of [["allowShells", "allowShells"], ["gitAllowDashC", "gitAllowDashC"]] as const) {
		if (o[key] !== undefined) {
			if (typeof o[key] === "boolean") (cfg as unknown as Record<string, unknown>)[field] = o[key];
			else cfg.problems.push(`windows.exec.${key} 须为 boolean，已忽略`);
		}
	}

	if (o.programs !== undefined) {
		if (o.programs !== null && typeof o.programs === "object" && !Array.isArray(o.programs)) {
			for (const [name, v] of Object.entries(o.programs as Record<string, unknown>)) {
				const pc = parseProgramValue(name, v, cfg.problems);
				if (pc) {
					if (isUnderMnt(pc.path) || isWindowsAbsolutePath(pc.path)) cfg.programs.set(name, pc);
					else cfg.problems.push(`windows.exec.programs["${name}"].path "${pc.path}" 既不是 /mnt/<盘>/… 也不是 Windows 绝对路径，跳过`);
				}
			}
		} else {
			cfg.problems.push("windows.exec.programs 必须是对象（name→路径/声明），实际不是");
		}
	}

	if (o.allowRoots !== undefined) {
		if (Array.isArray(o.allowRoots)) {
			for (const [i, v] of o.allowRoots.entries()) {
				const s = str(v);
				if (s === null) { cfg.problems.push(`windows.exec.allowRoots[${i}] 须为非空字符串，跳过`); continue; }
				const t = s.trim();
				if (isUnderMnt(t) || isWindowsAbsolutePath(t)) cfg.allowRoots.push(t);
				else cfg.problems.push(`windows.exec.allowRoots[${i}]=${t} 既不是 /mnt/<盘>/… 也不是 Windows 绝对路径，跳过`);
			}
		} else cfg.problems.push("windows.exec.allowRoots 必须是字符串数组，实际不是");
	}

	if (o.envAllow !== undefined) {
		if (Array.isArray(o.envAllow)) {
			for (const [i, v] of o.envAllow.entries()) {
				const s = str(v);
				if (s === null) { cfg.problems.push(`windows.exec.envAllow[${i}] 须为非空字符串，跳过`); continue; }
				if (/^[A-Za-z_][A-Za-z0-9_() .-]*$/.test(s)) cfg.envAllow.push(s);
				else cfg.problems.push(`windows.exec.envAllow[${i}]=${s} 不是合法 Windows 环境变量名形态，跳过`);
			}
		} else cfg.problems.push("windows.exec.envAllow 必须是字符串数组，实际不是");
	}

	if (o.groups !== undefined) {
		if (o.groups !== null && typeof o.groups === "object" && !Array.isArray(o.groups)) {
			for (const [name, v] of Object.entries(o.groups as Record<string, unknown>)) {
				if (v === null || typeof v !== "object" || Array.isArray(v)) {
					cfg.problems.push(`windows.exec.groups["${name}"] 须为对象，跳过`);
					continue;
				}
				const g = v as Record<string, unknown>;
				const killImages: string[] = [];
				if (Array.isArray(g.killImages)) {
					for (const img of g.killImages) {
						const s = str(img);
						if (s === null) { cfg.problems.push(`windows.exec.groups["${name}"].killImages 含非字符串项，跳过该项`); continue; }
						killImages.push(s.trim());
					}
				} else if (g.killImages !== undefined) {
					cfg.problems.push(`windows.exec.groups["${name}"].killImages 须为字符串数组，按空处理`);
				}
				const group: WinExecGroupConfig = { name, killImages, longRunning: g.longRunning === true };
				if (g.longRunning !== undefined && typeof g.longRunning !== "boolean") cfg.problems.push(`windows.exec.groups["${name}"].longRunning 须为 boolean，已忽略`);
				const t = positiveInt(g.timeoutS);
				if (t !== undefined) group.timeoutS = t;
				else if (g.timeoutS !== undefined) cfg.problems.push(`windows.exec.groups["${name}"].timeoutS 须为正数（秒），已忽略`);
				cfg.groups.set(name, group);
			}
		} else cfg.problems.push("windows.exec.groups 必须是对象，实际不是");
	}

	const dt = positiveInt(o.defaultTimeoutS);
	if (dt !== undefined) cfg.defaultTimeoutS = dt;
	else if (o.defaultTimeoutS !== undefined) cfg.problems.push("windows.exec.defaultTimeoutS 须为正数（秒），已忽略");
	const mt = positiveInt(o.maxTimeoutS);
	if (mt !== undefined) cfg.maxTimeoutS = mt;
	else if (o.maxTimeoutS !== undefined) cfg.problems.push("windows.exec.maxTimeoutS 须为正数（秒），已忽略");
	const fe = str(o.fallbackEncoding);
	if (fe !== null) cfg.fallbackEncoding = fe;
	else if (o.fallbackEncoding !== undefined) cfg.problems.push("windows.exec.fallbackEncoding 须为非空字符串（TextDecoder 标签，如 gbk），已忽略");

	return cfg;
}
