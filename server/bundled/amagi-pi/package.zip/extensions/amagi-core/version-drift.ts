/**
 * version-drift.ts — ev-20260930-08a8e7 切片2：宿主升级窗口提示（版本漂移中性提醒）。
 *
 * 背景：宿主升级后文件替换、运行时重启、in-flight 子进程被杀——重启前无任何提示，
 * Leader 只能在恢复对账里事后还原现场。本切片只做**提示**，不做处置：
 *   - 扩展初始化捕获进程启动时的宿主包版本（detectHostPackageVersion 同一包定位路径；启动值冻结一次）；
 *   - 派发与完成通知时同路径探测安装文件版本；
 *   - 两值均已知且不相等 → 附中性提示（「安装版本已变化，当前进程仍使用启动版本；建议在途任务
 *     结束后重启」）；同版本对只主动提示一次；
 *   - 任一探测失败（未知）→ 如实标未知，不假报升级（同版本文件替换无法靠 version 判断——不猜）；
 *   - 不拒绝派发、不杀子进程、不执行更新、不重启；重启恢复主报告不把版本变化推断为已证实中断
 *     原因（版本变化只是事实观测，中断原因由恢复对账按 N9 语义判定）。
 *
 * 边界冻结：不借机重做 effective 配置冻结（spec.effective.hostVersion 历史占位串不动）、
 * 不改历史 TaskSpec（digest 零回写）——本模块只读探测 + 一次性提示。
 */
import { detectHostPackageVersion } from "./host-capabilities.ts";

/** 启动时冻结的宿主包版本（captureStartupHostVersion 首次调用定格；null = 探测失败/未捕获）。 */
let startupVersion: string | null | undefined;
/** 已提示过的版本对（`${startup}→${installed}`）——同版本对只主动提示一次。 */
let lastNoticedPair: string | undefined;
/** 安装版本探测函数（缺省 detectHostPackageVersion；测试注入替换）。 */
let installedProbe: () => string | null = detectHostPackageVersion;

/** 版本漂移探测三态（未知 = 任一侧探测失败——不假报升级）。 */
export interface VersionDriftProbe {
	/** same=两值已知且相等；changed=两值已知且不等；unknown=任一探测失败（如实标注，不猜）。 */
	state: "same" | "changed" | "unknown";
	/** 进程启动时捕获的宿主包版本（未捕获/探测失败 = null）。 */
	startup: string | null;
	/** 本次探测的安装文件版本（探测失败 = null）。 */
	installed: string | null;
}

/** 扩展初始化时冻结启动版本（幂等：只冻结第一次探测结果；失败=未知定格）。探测与安装面同路径
 *  （installedProbe 单源——测试可注入，缺省 detectHostPackageVersion）。 */
export function captureStartupHostVersion(): void {
	if (startupVersion === undefined) {
		try {
			startupVersion = installedProbe();
		} catch {
			/* lint-exempt:启动探测失败=未知定格（不猜）——提示面如实缺席 */
			startupVersion = null;
		}
	}
}

/** 探测当前版本漂移状态（纯读：同路径探测安装文件版本；启动值缺省先冻结一次）。 */
export function probeVersionDrift(): VersionDriftProbe {
	if (startupVersion === undefined) captureStartupHostVersion();
	const startup = startupVersion ?? null;
	let installed: string | null = null;
	try {
		installed = installedProbe();
	} catch {
		/* lint-exempt:安装探测失败=未知态（不猜）——state=unknown，不假报升级 */
		installed = null;
	}
	const state: VersionDriftProbe["state"] = startup !== null && installed !== null ? (startup === installed ? "same" : "changed") : "unknown";
	return { state, startup, installed };
}

/**
 * 升级窗口中性提示（派发/完成通知接缝消费）：
 *   - changed → 提示一次（同版本对去重），文本含启动与安装两值；
 *   - same / unknown / 未捕获 → null（未知绝不假报升级）。
 * 派发/通知链路对返回 null 必须零附加（提示缺席不影响任何主流程）。
 */
export function versionDriftNotice(): string | null {
	const p = probeVersionDrift();
	if (p.state !== "changed") return null;
	const pair = `${p.startup}→${p.installed}`;
	if (lastNoticedPair === pair) return null;
	lastNoticedPair = pair;
	return `[amagi 升级提示] pi 包安装版本已变化（启动 ${p.startup} → 安装 ${p.installed}）；当前进程仍使用启动版本，不自动重启、不影响在途任务——建议在途任务结束后重启 pi 生效。`;
}

/** 测试注入：替换安装版本探测函数（undefined 还原缺省真实探测）。 */
export function setInstalledVersionProbeForTest(fn: (() => string | null) | undefined): void {
	installedProbe = fn ?? detectHostPackageVersion;
}

/** 测试复位（启动冻结值与去重对清零；生产不调用）。 */
export function resetVersionDriftForTest(): void {
	startupVersion = undefined;
	lastNoticedPair = undefined;
	installedProbe = detectHostPackageVersion;
}
