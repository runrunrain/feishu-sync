/** Advisor 的受信选模和凭据交付。子端只消费冻结 grant，不从可写项目配置扩大授权。 */
import * as fs from "node:fs";
import * as path from "node:path";
import { getGlobalConfigPath, SUPPORTED_THINKING_LEVELS } from "./model-resolver.ts";
import { providerEnvKeys } from "./compaction-config.ts";
import { advisorGrantProblem, type AdvisorGrant } from "./contracts/advisor.ts";
const AUTH_ENV = "AMAGI_ADVISOR_AUTH_ENV";
export function splitAdvisorModel(model: string): { provider: string; id: string; thinking?: string } {
	const slash = model.indexOf("/"), provider = model.slice(0, slash), tail = model.slice(slash + 1), colon = tail.lastIndexOf(":");
	const thinking = colon < 0 ? undefined : tail.slice(colon + 1);
	return thinking && SUPPORTED_THINKING_LEVELS.includes(thinking) ? { provider, id: tail.slice(0, colon), thinking } : { provider, id: tail };
}
export function resolveAdvisorConfig(cwd: string, projectTrusted: boolean): { grant?: AdvisorGrant; leader: boolean; roles: ReadonlySet<string> } {
	for (const file of [...new Set([...(projectTrusted ? [path.join(cwd, "amagi.json")] : []), getGlobalConfigPath()])]) {
		let raw: any;
		try { raw = JSON.parse(fs.readFileSync(file, "utf8")); } catch (e) { if ((e as NodeJS.ErrnoException).code === "ENOENT") continue; throw new Error("Advisor 配置不可读或 JSON 无效"); }
		if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new Error("Advisor 配置根必须为对象");
		if (!("advisor" in raw)) continue;
		const c = raw.advisor;
		if (!c || typeof c !== "object" || Array.isArray(c) || Object.keys(c).some(k => !["model", "leader", "roles", "maxCalls", "maxTokens", "timeoutMs", "backend", "codex"].includes(k))) throw new Error("advisor 配置字段无效");
		if (c.model === null && c.backend !== "codex-chat") return { leader: false, roles: new Set() };
		if (c.codex !== undefined && (!c.codex || typeof c.codex !== "object" || Array.isArray(c.codex))) throw new Error("advisor.codex 必须为对象");
		let target = c.codex ?? { mode: "managed" };
		const managed = (target.mode ?? (target.threadId ? "existing" : "managed")) === "managed";
		if (c.backend === "codex-chat" && managed) target = { ...target, model: target.model === undefined ? "gpt-6-astra" : target.model, reasoningEffort: target.reasoningEffort === undefined ? "high" : target.reasoningEffort };
		const grant: AdvisorGrant = { ...(c.backend !== undefined ? { backend: c.backend } : {}), ...(c.backend === "codex-chat" ? { codex: target } : c.codex !== undefined ? { codex: c.codex } : {}), model: c.backend === "codex-chat" ? managed ? "codex-chat/managed" : `codex-chat/${target.threadId}` : c.model, maxCalls: c.maxCalls ?? 5, maxTokens: c.maxTokens ?? 4096, timeoutMs: c.timeoutMs ?? 120000 };
		const problem = advisorGrantProblem(grant);
		if (problem) throw new Error(problem);
		if (c.leader !== undefined && typeof c.leader !== "boolean") throw new Error("advisor.leader 须为 boolean");
		if (c.roles !== undefined && (!Array.isArray(c.roles) || c.roles.some((r: unknown) => typeof r !== "string" || !/^[a-z][a-z0-9-]*$/.test(r as string)))) throw new Error("advisor.roles 须为 canonical 角色名数组");
		return { grant, leader: c.leader ?? true, roles: new Set<string>(c.roles ?? []) };
	}
	return { leader: false, roles: new Set() };
}
export function advisorAuthorityOf(cwd: string, projectTrusted: boolean): { grant: AdvisorGrant; roles: ReadonlySet<string> } | undefined {
	const config = resolveAdvisorConfig(cwd, projectTrusted);
	return config.grant ? { grant: config.grant, roles: config.roles } : undefined;
}
export function appendAdvisorEnv(env: Record<string, string>, grant: AdvisorGrant | undefined): void {
	delete env[AUTH_ENV];
	if (!grant) return;
	if (grant.backend === "codex-chat") {
		if (process.env.CODEX_HOME) env[AUTH_ENV] = Buffer.from(JSON.stringify({ model: grant.model, values: { CODEX_HOME: process.env.CODEX_HOME } })).toString("base64");
		return;
	}
	const { provider, id } = splitAdvisorModel(grant.model);
	const values = Object.fromEntries(providerEnvKeys(provider, id).flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]));
	env[AUTH_ENV] = Buffer.from(JSON.stringify({ model: grant.model, values })).toString("base64");
}
export function takeAdvisorAuthEnv(): { model?: string; values: Record<string, string> } {
	const raw = process.env[AUTH_ENV]; delete process.env[AUTH_ENV];
	try {
		const c = JSON.parse(Buffer.from(raw ?? "", "base64").toString("utf8"));
		if (typeof c.model !== "string" || !c.values || typeof c.values !== "object" || Array.isArray(c.values)) throw new Error();
		return { model: c.model, values: Object.fromEntries(Object.entries(c.values).filter(([k, v]) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(k) && typeof v === "string")) as Record<string, string> };
	} catch { /* lint-exempt:非法交付不接受凭据，认证仍由宿主明确失败。 */ return { values: {} }; }
}
export function stripAdvisorEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv { const copy = { ...env }; delete copy[AUTH_ENV]; return copy; }
