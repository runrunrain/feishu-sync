import { canonicalJson } from "./contracts/task.ts";
import { leaseAdvisorSession } from "./advisor-session.ts";
import { randomUUID, createHash } from "node:crypto";
import * as fs from "node:fs";
import { execFile } from "node:child_process";
import * as path from "node:path";
import { findExecutableFile } from "./shell-env.ts";
/** 自有咨询使用本机 Codex/Work 原生会话（不是普通 ChatGPT Chat）；指定已有聊天时只连接共享服务，不接管其他桌面历史。 */
import crossSpawn from "cross-spawn";
import { createInterface } from "node:readline";
import type { Usage } from "@earendil-works/pi-ai";
import type { AdvisorGrant } from "./contracts/advisor.ts";
export type CodexAdvisorUsage = Omit<Usage, "cost"> & { cost?: Usage["cost"] };

export interface CodexBackendDiagnostic {
	id: string; command: "codex"; executable?: string; pathDigest: string; cwd: string; checkedAt: number;
	stage: "locating" | "spawned" | "ready" | "failed";
	failureKind?: "not-found" | "not-executable" | "spawn-error" | "invalid-working-directory" | "early-exit" | "service-closed" | "protocol-error" | "cancelled";
	code?: string; exitCode?: number | null; signal?: string | null;
}
export class CodexBackendError extends Error {
	constructor(message: string, readonly diagnostic: CodexBackendDiagnostic) { super(`${message}；backend=${JSON.stringify(diagnostic)}`); }
}
const backendPaths = new Map<string, { path: string; at: number }>();
/** 缓存只复用路径发现；每次重查文件与执行位，不缓存“服务已就绪”。 */
export function inspectCodexBackend(env: NodeJS.ProcessEnv = process.env, cwd = process.cwd()): CodexBackendDiagnostic {
	const pathDigest = createHash("sha256").update(JSON.stringify([env.PATH, env.PATHEXT, cwd])).digest("hex");
	const base: CodexBackendDiagnostic = { id: randomUUID(), command: "codex", pathDigest, cwd: path.resolve(cwd), checkedAt: Date.now(), stage: "locating" };
	const cached = backendPaths.get(pathDigest);
	if (cached && Date.now() - cached.at < 5000 && findExecutableFile(cached.path, env) === cached.path) return { ...base, executable: cached.path };
	backendPaths.delete(pathDigest);
	const dirs = [...(process.platform === "win32" ? [cwd] : []), ...(env.PATH ?? "").split(path.delimiter)];
	let nonExecutable: string | undefined;
	for (const dir of dirs) {
		const candidate = path.resolve(cwd, dir.replace(/^"|"$/g, ""), "codex");
		const found = findExecutableFile(candidate, env);
		if (found) {
			if (backendPaths.size >= 16) backendPaths.delete(backendPaths.keys().next().value!);
			backendPaths.set(pathDigest, { path: found, at: Date.now() });
			return { ...base, executable: found };
		}
		try { if (fs.statSync(candidate).isFile()) nonExecutable = candidate; } catch { /* lint-exempt:PATH候选不存在，不等于未安装。 */ }
	}
	return { ...base, stage: "failed", failureKind: nonExecutable ? "not-executable" : "not-found", ...(nonExecutable ? { executable: nonExecutable } : {}), code: nonExecutable ? "EACCES" : "ENOENT" };
}

export async function consultCodexChat(grant: AdvisorGrant, question: string, signal: AbortSignal, identity?: string, cwd = process.cwd(), nativeEnv: Record<string, string> = {}, onDiagnostic?: (d: CodexBackendDiagnostic) => void): Promise<{ stopReason: string; content: { type: "text"; text: string }[]; usage?: CodexAdvisorUsage; codexThreadId?: string; model?: string; reasoningEffort?: string; backendDiagnostic?: CodexBackendDiagnostic }> {
	const target = grant.codex;
	if (!target) throw new Error("Codex 聊天授权缺少连接及目标会话");
	const managed = (target.mode ?? (target.threadId ? "existing" : "managed")) === "managed";
	if (managed && !identity) throw new Error("自有 Codex 咨询缺少调用者身份");
	const model = target.model ?? "gpt-6-astra", effort = target.reasoningEffort ?? "high";
	const modelConfig = { model, config: { model_reasoning_effort: effort } };
	const lease = managed ? leaseAdvisorSession(`${identity}:${nativeEnv.CODEX_HOME ?? process.env.CODEX_HOME ?? "default"}:${canonicalJson(grant)}`) : undefined;
	let threadId = lease?.threadId ?? target.threadId;
	let bridge: CodexChatConnection;
	try { bridge = new CodexChatConnection(managed ? undefined : target.socketPath, signal, nativeEnv, cwd, onDiagnostic); }
	catch (error) { lease?.release(); throw error; }
	let ownTurn: string | undefined, actualModel: string | undefined, mustInterrupt = false;
	try {
		await bridge.initialize();
		if (managed && !threadId) {
			const created = await bridge.request("thread/start", { cwd, ...modelConfig, allowProviderModelFallback: false, sandbox: "read-only", approvalPolicy: "never", serviceName: "amagi-advisor", developerInstructions: "你是咨询者，只给建议，不调用工具、不修改文件、不派发任务。原执行者负责实现和验证。" });
			threadId = created.thread?.id; actualModel = created.model;
			if (actualModel !== model || created.reasoningEffort !== effort) throw new Error("Codex Work 未使用指定的咨询模型或思考档位；不会回退到其他模型");
			if (!threadId) throw new Error("Codex 未创建咨询会话");
			lease!.save(threadId);
			try { await bridge.request("thread/name/set", { threadId, name: `Amagi Advisor ${threadId.slice(0,8)}` }); } catch { /* lint-exempt:标题不影响咨询与会话身份。 */ }
		} else {
			const read = await bridge.request("thread/read", { threadId, includeTurns: false });
			if (read.thread?.status?.type !== "idle" && !(managed && read.thread?.status?.type === "notLoaded")) throw new Error("目标 Codex 聊天未空闲；不会接管或打断已有任务");
			const resumed = await bridge.request("thread/resume", { threadId, excludeTurns: true, ...(managed ? modelConfig : {}) }); actualModel = resumed.model;
			if (managed && (actualModel !== model || resumed.reasoningEffort !== effort)) throw new Error("Codex Work 续接未使用指定的咨询模型或思考档位；不会回退到其他模型");
		}
		const result = new Promise<{ stopReason: string; content: { type: "text"; text: string }[]; usage?: CodexAdvisorUsage }>((resolve, reject) => {
			let text = "", usage: CodexAdvisorUsage | undefined;
			const early: Array<[string, any]> = [];
			bridge.onNotification = (method, p) => {
				if (p.threadId !== threadId) return;
				if (!ownTurn) { if (early.length < 256) early.push([method, p]); return; }
				if ((p.turnId ?? p.turn?.id) !== ownTurn) return;
				if (method === "item/completed" && p.item?.type === "agentMessage") text += String(p.item.text ?? "") + "\n";
				if (method === "thread/tokenUsage/updated") {
					const u = p.tokenUsage?.last;
					if (u) {
						// Codex 不报告金额；保持 cost 缺席，不把未知价格写成免费。
						usage = { input: Math.max(0, u.inputTokens - u.cachedInputTokens), output: u.outputTokens, cacheRead: u.cachedInputTokens,
							cacheWrite: u.cacheWriteInputTokens ?? 0, totalTokens: u.totalTokens };
						if (u.outputTokens > grant.maxTokens) { mustInterrupt = true; resolve({ stopReason: "length", content: [{ type: "text", text }], usage }); }
					}
				}
				if (method === "turn/completed") {
					if (p.turn?.status !== "completed") reject(new Error(`Codex 咨询未完成（${p.turn?.status ?? "unknown"}）`));
					else resolve({ stopReason: "stop", content: [{ type: "text", text }], ...(usage ? { usage } : {}) });
				}
			};
			bridge.onFailure = reject;
			bridge.replay = () => { for (const [method, p] of early.splice(0)) bridge.onNotification?.(method, p); };
		});
		// 安装监听早于启动；服务端可能在 turn/start 响应之前发送 turn/started。
		void result.catch(() => {}); // 启动失败时也处理通知 promise 的拒绝。
		const started = await bridge.request("turn/start", { threadId: threadId, ...(managed ? { model, effort } : {}),
			clientUserMessageId: randomUUID(), input: [{ type: "text", text: `【Amagi 咨询；只给文本建议，原执行者自行落实】\n请勿调用工具、改文件或创建任务；输出不超过 ${grant.maxTokens} tokens。\n\n${question}` }],
			approvalPolicy: "never", sandboxPolicy: { type: "readOnly", networkAccess: false } });
		ownTurn ??= started.turn?.id;
		if (!ownTurn) throw new Error("Codex 未返回本次咨询 turnId");
		bridge.replay?.();
		return { ...await result, codexThreadId: threadId, backendDiagnostic: { ...bridge.diagnostic }, ...(actualModel ? { model: actualModel } : {}), ...(managed ? { reasoningEffort: effort } : {}) };
	} finally { if ((signal.aborted || mustInterrupt) && ownTurn) await bridge.interrupt(threadId!, ownTurn); await bridge.close(); lease?.release(); }
}

/** JSONL 经官方 proxy 进入已运行的共享服务。原生凭据留在 Codex 服务，不进入 pi。 */
export class CodexChatConnection {
	private child;
	readonly diagnostic: CodexBackendDiagnostic;
	private pending = new Map<number, { resolve: (value: any) => void; reject: (error: Error) => void }>();
	private seq = 0;
	onNotification?: (method: string, params: any) => void;
	replay?: () => void;
	private closedError?: Error;
	private closing = false;
	private closePromise?: Promise<void>;
	onFailure?: (error: Error) => void;
	private abort = () => this.fail(new Error("Codex 咨询已取消"));
	constructor(socketPath: string | undefined, private signal: AbortSignal, nativeEnv: Record<string, string> = {}, cwd = process.cwd(), private onDiagnostic?: (d: CodexBackendDiagnostic) => void) {
		const env: NodeJS.ProcessEnv = {};
		for (const k of ["PATH", "HOME", "USERPROFILE", "USER", "LOGNAME", "TMPDIR", "TEMP", "TMP", "SystemRoot", "WINDIR", "CODEX_HOME", "PATHEXT", "ComSpec"]) if (process.env[k] !== undefined) env[k] = process.env[k];
		if (nativeEnv.CODEX_HOME) env.CODEX_HOME = nativeEnv.CODEX_HOME;
		this.diagnostic = inspectCodexBackend(env, cwd);
		this.reportDiagnostic();
		this.child = crossSpawn.spawn(this.diagnostic.executable ?? "codex", socketPath === undefined ? ["app-server", "--listen", "stdio://"] : ["app-server", "proxy", ...(socketPath === "auto" ? [] : ["--sock", socketPath])], { cwd, env, stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
		this.child.on("spawn", () => { if (this.closedError || this.closing) return; this.diagnostic.stage = "spawned"; delete this.diagnostic.failureKind; delete this.diagnostic.code; this.reportDiagnostic(); });
		const lines = createInterface({ input: this.child.stdout });
		lines.on("line", line => {
			if (this.closedError || this.closing) return;
			if (Buffer.byteLength(line) > 2 * 1024 * 1024) { this.fail(new Error("Codex 协议帧过大")); this.close(); return; }
			let m: any; try { m = JSON.parse(line); } catch { /* lint-exempt:非 JSON stdout 明确令连接失败。 */ this.fail(new Error("Codex 返回非法协议帧")); return; }
			if (!m || typeof m !== "object" || Array.isArray(m)) { this.fail(new Error("Codex 返回非法协议对象")); return; }
			if (m.id !== undefined && m.method) { this.write({ id: m.id, error: { code: -32601, message: "Advisor refuses external tool/approval requests" } }); return; }
			if (m.id !== undefined) {
				const waiting = this.pending.get(m.id); if (!waiting) return;
				this.pending.delete(m.id);
				const code = Number.isSafeInteger(m.error?.code) ? String(m.error.code) : "unknown";
				m.error ? waiting.reject(new CodexBackendError(`Codex 请求失败（${code}）`, { ...this.diagnostic, stage: "failed", failureKind: "protocol-error", code })) : waiting.resolve(m.result);
			} else if (typeof m.method === "string") { this.onNotification?.(m.method, m.params ?? {}); }
		});
		this.child.on("error", (error: NodeJS.ErrnoException) => {
			let cwdExists = false;
			try { cwdExists = fs.statSync(cwd).isDirectory(); } catch { /* lint-exempt:只判断 cwd 是否仍存在，不猜其他启动归因。 */ }
			this.diagnostic.failureKind = !cwdExists ? "invalid-working-directory" : error.code === "ENOENT" && !this.diagnostic.executable ? "not-found" : error.code === "EACCES" || error.code === "EPERM" ? "not-executable" : "spawn-error";
			this.diagnostic.code = error.code;
			const hint = !cwdExists ? "实际工作目录不存在或不是目录，核对 cwd" : this.diagnostic.failureKind === "not-found" ? "当前子进程 PATH 未定位到命令，不等于未安装；核对启动 pi 时继承的 PATH" : this.diagnostic.executable && error.code === "ENOENT" ? "程序已定位，OS 仍返回 ENOENT；核对脚本解释器与启动依赖，不等于程序未安装" : "核对已定位程序执行权限与启动条件";
			this.fail(new Error(`本机 codex 代理不可启动（code=${error.code ?? "unknown"}）；${hint}`));
		});
		this.child.on("close", (code, signal) => {
			if (this.closedError || this.closing) return;
			this.diagnostic.failureKind = this.diagnostic.stage === "ready" ? "service-closed" : "early-exit";
			this.diagnostic.exitCode = code; this.diagnostic.signal = signal;
			this.fail(new Error(socketPath === undefined ? "本机 Codex 会话服务已关闭；按backend诊断核对启动条件" : "Codex 共享服务连接已关闭；核对桌面端共享 socket"));
		});
		this.child.stderr.resume(); // 可能含用户配置或历史信息，不转发原始 stderr。
		signal.addEventListener("abort", this.abort, { once: true });
		if (signal.aborted) this.abort();
	}
	async initialize(): Promise<void> {
		await this.request("initialize", { clientInfo: { name: "amagi_advisor", title: "Amagi Advisor", version: "1" }, capabilities: { experimentalApi: true } });
		if (this.closedError) throw this.closedError;
		this.write({ method: "initialized" });
		this.diagnostic.stage = "ready";
		this.reportDiagnostic();
	}
	request(method: string, params: unknown): Promise<any> {
		this.signal.throwIfAborted();
		if (this.closedError) return Promise.reject(this.closedError);
		const id = ++this.seq;
		return new Promise((resolve, reject) => { this.pending.set(id, { resolve, reject }); this.write({ id, method, params }); });
	}
	async interrupt(threadId: string, turnId: string): Promise<void> {
		if (this.child.stdin.destroyed) return;
		const id = ++this.seq;
		await new Promise<void>(resolve => {
			const finish = () => { clearTimeout(timer); this.pending.delete(id); resolve(); };
			const timer = setTimeout(finish, 500);
			this.pending.set(id, { resolve: finish, reject: finish });
			this.write({ id, method: "turn/interrupt", params: { threadId, turnId } });
		});
	}
	private reportDiagnostic(): void {
		try { this.onDiagnostic?.({ ...this.diagnostic }); } catch { /* lint-exempt:观测回调不改变后端执行。 */ }
	}
	private write(message: unknown): void { if (!this.child.stdin.destroyed) this.child.stdin.write(JSON.stringify(message) + "\n", () => {}); }
	private fail(error: Error): void {
		if (this.closedError) return;
		this.diagnostic.failureKind ??= this.signal.aborted ? "cancelled" : "protocol-error";
		this.diagnostic.stage = "failed";
		this.reportDiagnostic();
		const diagnosed = new CodexBackendError(error.message, { ...this.diagnostic });
		this.closedError = diagnosed; for (const p of this.pending.values()) p.reject(diagnosed); this.pending.clear(); this.onFailure?.(diagnosed);
	}
	close(): Promise<void> {
		if (this.closePromise) return this.closePromise;
		this.closing = true; this.signal.removeEventListener("abort", this.abort);
		const child = this.child;
		// Windows 的 .cmd 入口只是父壳；先杀父会使真实代理脱离树。对仍由本连接持有的活进程树回收。
		this.closePromise = new Promise<void>(resolve => {
			if (!child.pid || child.exitCode !== null || child.signalCode !== null) { resolve(); return; }
			if (process.platform === "win32" && process.env.SystemRoot && path.isAbsolute(process.env.SystemRoot)) {
				execFile(path.join(process.env.SystemRoot, "System32", "taskkill.exe"), ["/PID", String(child.pid), "/T", "/F"], { windowsHide: true, timeout: 2000 }, error => {
					if (error && child.exitCode === null && child.signalCode === null) child.kill();
					resolve();
				});
			} else {
				const timer = setTimeout(() => { if (child.exitCode === null && child.signalCode === null) child.kill("SIGKILL"); resolve(); }, 500);
				child.once("close", () => { clearTimeout(timer); resolve(); });
				child.stdin.end(); child.kill();
			}
		});
		return this.closePromise;
	}
}
