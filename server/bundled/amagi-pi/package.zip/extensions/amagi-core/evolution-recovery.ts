/** Explicit recovery copies: preserve IDs and evidence bytes; never switch process roots or chmod the source. */
import * as fs from "node:fs";
import * as path from "node:path";
import { isUtf8 } from "node:buffer";
import { createHash } from "node:crypto";
import { evolutionRoot, parseItem } from "./evolution-log.ts";
import { enforceWriteTarget, resolveEvolutionRecoverySource, resolveManagedEvolutionRoot } from "./evolution-evidence.ts";
import { redactCredentials } from "./task-query-wire.ts";

interface FileSnapshot { path: string; bytes: number; digest: string }
interface Snapshot { files: FileSnapshot[]; ids: string[]; warnings: string[] }
interface RecoveryManifest { version: 1; state: "verified-copy"; source: string; target: string; createdAt: string; snapshot: Snapshot }
const manifestName = "recovery-manifest.json";
const digest = (s: string) => `sha256:${createHash("sha256").update(s).digest("hex")}`;
const exists = (p: string) => { try { fs.lstatSync(p); return true; } catch (e) { if ((e as NodeJS.ErrnoException).code === "ENOENT") return false; throw e; } };
const within = (child: string, parent: string) => { const r = path.relative(parent, child); return !r || (!path.isAbsolute(r) && r !== ".." && !r.startsWith(`..${path.sep}`)); };

function readFile(root: string, relative: string): string {
 const target = path.join(root, relative);
 enforceWriteTarget(target); // same existing deny check as managed evolution reads; no new authorization surface
 const st = fs.lstatSync(target);
 if (st.isSymbolicLink() || !st.isFile()) throw new Error(`恢复源须为普通文件: ${relative}`);
 if (st.size > 16 * 1024 * 1024) throw new Error(`恢复源单文件超过 16 MiB；请分批保留历史: ${relative}`);
 const fd = fs.openSync(target, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW ?? 0));
 try {
  const opened = fs.fstatSync(fd);
  if (!opened.isFile() || opened.size > 16 * 1024 * 1024) throw new Error(`恢复文件读取前变化: ${relative}`);
  const bytes = Buffer.alloc(opened.size); let offset = 0;
  while (offset < bytes.length) { const n = fs.readSync(fd, bytes, offset, bytes.length - offset, null); if (!n) break; offset += n; }
  if (offset !== bytes.length || !isUtf8(bytes)) throw new Error(`恢复源不完整或不是 UTF-8 文本: ${relative}`);
  return bytes.toString("utf8");
 } finally { fs.closeSync(fd); }
}

function snapshot(root: string): Snapshot {
 const files: FileSnapshot[] = [], ids: string[] = [], warnings: string[] = [];
 let bytes = 0;
 const locks = path.join(root, ".locks");
 if (exists(locks) && fs.readdirSync(locks).length) throw new Error("源仍有 evolution 条目锁；待写入者结束后重试（不删除锁）");
 const visit = (rel: string, depth: number) => {
  const p = path.join(root, rel); enforceWriteTarget(p);
  const st = fs.lstatSync(p);
  if (st.isSymbolicLink()) throw new Error(`恢复源含链接，未复制: ${rel}`);
  if (st.isDirectory()) {
   if (depth > 3) throw new Error(`恢复源目录结构异常: ${rel}`);
   for (const name of fs.readdirSync(p).sort()) visit(path.join(rel, name), depth + 1);
   return;
  }
  const content = readFile(root, rel), size = Buffer.byteLength(content);
  bytes += size;
  if (files.length >= 10000 || bytes > 128 * 1024 * 1024) throw new Error("恢复源超过 10000 文件或 128 MiB；请分批保留历史");
  files.push({ path: rel.split(path.sep).join("/"), bytes: size, digest: digest(content) });
  if (/^(open|resolved)[\\/][^\\/]+\.md$/.test(rel)) {
   const item = parseItem(content);
   if (!item || item.id !== path.basename(rel, ".md") || item.status !== rel.split(path.sep)[0] || item.evidenceInvalid) throw new Error(`条目身份/证据清单损坏: ${rel}`);
   if (ids.includes(item.id)) throw new Error(`同 ID 跨状态冲突，原文件均保留: ${item.id}`);
   ids.push(item.id);
   for (const evidence of item.evidence ?? []) {
    if (evidence.state !== "retained") continue;
    const evidencePath = path.resolve(path.dirname(p), evidence.path);
    if (!within(evidencePath, path.join(root, "evidence"))) throw new Error(`证据路径越界: ${item.id}`);
    // Components are checked in the full traversal before any destination is created.
    const content = readFile(root, path.relative(root, evidencePath));
    if (digest(content) !== evidence.digest || Buffer.byteLength(content) !== evidence.bytes) throw new Error(`证据 digest/bytes 不一致: ${item.id}/${evidence.key}`);
   }
  }
 };
 for (const name of fs.readdirSync(root).sort()) {
  if (["open", "resolved", "evidence", "index.ndjson"].includes(name)) visit(name, 0);
  else if (name !== ".locks" && name !== manifestName) warnings.push(`未复制非存储内容: ${name}`);
 }
 return { files, ids: ids.sort(), warnings };
}
const sameSnapshot = (a: Snapshot, b: Snapshot) => JSON.stringify(a.files) === JSON.stringify(b.files) && JSON.stringify(a.ids) === JSON.stringify(b.ids);

export interface EvolutionRecoveryRequest { action?: "inspect" | "copy" | "rollback"; source?: string; target?: string }
export function recoverEvolution(request: EvolutionRecoveryRequest): { ok: true; text: string; source: string; target?: string; manifest?: string; files: number; ids: string[] } {
 const action = request.action ?? "inspect";
 if (!["inspect", "copy", "rollback"].includes(action)) throw new Error("action 须为 inspect/copy/rollback");
 if (action === "rollback") {
  if (!request.target) throw new Error("rollback 需要已复制的 target");
  const target = resolveManagedEvolutionRoot(path.resolve(request.target)).canonical;
  const parsed = JSON.parse(readFile(target, manifestName)) as RecoveryManifest;
  if (parsed.version !== 1 || parsed.state !== "verified-copy" || parsed.target !== target || typeof parsed.source !== "string") throw new Error("恢复清单无效；未切换或删除任何目录");
  const source = resolveEvolutionRecoverySource(parsed.source).canonical;
  const original = snapshot(source), current = snapshot(target);
  const sourceChanged = !sameSnapshot(original, parsed.snapshot), targetChanged = !sameSnapshot(current, parsed.snapshot);
  return { ok: true, source, target, files: original.files.length, ids: original.ids,
   text: `回滚准备已核对：原根 ${source}；副本 ${target}。原根${sourceChanged ? "已变化" : "与复制时一致"}，副本${targetChanged ? "有后续变更，须另行保留" : "与复制时一致"}。两份均保留，未删除、未自动切换环境。可将启动进程的 AMAGI_EVOLUTION_ROOT 恢复为原根；原根原有拒写原因仍可能存在。` };
 }
 const source = resolveEvolutionRecoverySource(path.resolve(request.source ?? evolutionRoot())).canonical;
 const before = snapshot(source);
 if (action === "inspect") return { ok: true, source, files: before.files.length, ids: before.ids, text: `恢复源校验完成：${before.ids.length} 条记录，${before.files.length} 个文件，条目 ID 与留存 evidence digest 已核对。只读检查不代表源根可写。${before.warnings.join("；")}` };
 if (!request.target) throw new Error("copy 需要 target（新建的私有存储目录）；原根不修改");
 const target = path.resolve(request.target);
 if (exists(target)) throw new Error("target 已存在，未覆盖；请选择新目录，或用 inspect 核对已有副本");
 const managed = resolveManagedEvolutionRoot(target);
 if (within(managed.canonical, source) || within(source, managed.canonical)) throw new Error("恢复源与目标不能嵌套；原根未修改");
 fs.mkdirSync(managed.canonical, { mode: 0o700 });
 // Failures retain the partial copy and the untouched source; never erase uncertain data.
 try {
  for (const file of before.files) {
   const content = readFile(source, file.path);
   if (digest(content) !== file.digest) throw new Error(`复制期间源变化: ${file.path}`);
   const out = path.join(managed.canonical, file.path); enforceWriteTarget(out);
   fs.mkdirSync(path.dirname(out), { recursive: true, mode: 0o700 });
   fs.writeFileSync(out, content, { flag: "wx", mode: 0o600 });
  }
  if (!sameSnapshot(before, snapshot(source)) || !sameSnapshot(before, snapshot(managed.canonical))) throw new Error("复制期间发生变更或复核不一致");
  resolveManagedEvolutionRoot(managed.canonical);
  const manifest: RecoveryManifest = { version: 1, state: "verified-copy", source, target: managed.canonical, createdAt: new Date().toISOString(), snapshot: before };
  const manifestPath = path.join(managed.canonical, manifestName); enforceWriteTarget(manifestPath);
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + "\n", { flag: "wx", mode: 0o600 });
  return { ok: true, source, target: managed.canonical, manifest: manifestPath, files: before.files.length, ids: before.ids,
   text: `恢复副本已验证：${before.ids.length} 条记录，${before.files.length} 个文件；ID、逐文件 SHA-256 与 evidence digest 保持一致。目标 ${managed.canonical}。原根保留，未切换环境；为目标进程指定 AMAGI_EVOLUTION_ROOT 后，可用 list/show 验证并继续真实 log。回滚检查：/amagi evolution-recover ${JSON.stringify({ action: "rollback", target: managed.canonical })}。${before.warnings.join("；")}` };
 } catch (e) { throw new Error(`恢复未完成，原根未修改，部分副本保留于 ${managed.canonical}；${e instanceof Error ? e.message : String(e)}`); }
}

export function runEvolutionRecoveryCommand(json: string): string {
 try {
  const parsed: unknown = JSON.parse(json || "{}");
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("参数须为 JSON 对象");
  const p = parsed as Record<string, unknown>;
  if (Object.keys(p).some(k => !["action", "source", "target"].includes(k)) || ["action", "source", "target"].some(k => p[k] !== undefined && typeof p[k] !== "string")) throw new Error("仅支持 action/source/target 字符串字段");
  return redactCredentials(recoverEvolution(p as EvolutionRecoveryRequest).text);
 } catch (e) { return `evolution 恢复失败：${redactCredentials(e instanceof Error ? e.message : String(e))}。用法：/amagi evolution-recover {"action":"inspect","source":"原根"} 或 {"action":"copy","source":"原根","target":"新私有目录"}`; }
}
