/**
 * auth-preflight.ts — 8月迭代 pi-0.84 配合 P1②：SubAgent 派发前的 pi auth 凭据预检。
 *
 * 动机：凭据缺失（not_ready）的 provider 派发后每次请求 401/403，重试 + 自动续跑把整轮
 * token/时间烧完才失败。本模块在 spawn 前用 pi 官方 `auth check --provider <p> --json`
 * 做一次廉价探测，把确定性失败拦截在启动前（fail-fast，不进 spawn 后的运行窗口）。
 *
 * 输出契约（Leader 实测）：
 *   {"status":"ready", ...}                                → 放行
 *   {"status":"not_ready","reason":"provider_not_found"}   → 放行（自定义/未注册 provider 防误伤）
 *   {"status":"not_ready","reason":其他}                  → 抛错（actionable：指明 provider +
 *                                                           核对凭据 / pi auth 登录，文案风格对齐 terminal-doctor）
 *   spawn 失败 / 超时 / JSON 解析失败 / 契约外 status      → 一律放行（环境抖动不拦截派发）
 *
 * env 开关：AMAGI_AUTH_PREFLIGHT=0 整体关闭；AMAGI_AUTH_PREFLIGHT_TTL_MS 覆盖缓存 TTL
 * （0 = 不缓存；缺省 300s）。缓存按 provider 键，只缓存「spawn 成功且输出可解析」的判定
 * ——抖动结论（spawn 失败/超时/解析失败）不粘滞，下一轮重试真实探测。
 */
import { spawn } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";

/** 测试注入用的最小子进程面（真实 ChildProcess 的结构子集）。 */
export interface PreflightChildLike {
	on(event: "error", listener: (err: Error) => void): unknown;
	on(event: "close", listener: (code: number | null, signal: NodeJS.Signals | null) => void): unknown;
	kill(signal?: NodeJS.Signals): unknown;
	stdout?: { on(event: "data", listener: (chunk: string | Buffer) => void): unknown } | null;
	stderr?: { on(event: "data", listener: (chunk: string | Buffer) => void): unknown } | null;
}

/** auth check 判定的 TTL 缓存条目（按 provider 键）。 */
export interface PreflightCacheEntry {
	ok: boolean;
	message?: string;
	at: number;
}

export interface AuthPreflightDeps {
	/** spawn 注入（测试用）；缺省真实 spawn（stdio ignore/pipe/pipe + 超时强杀）。 */
	spawnFn?: (command: string, args: string[]) => PreflightChildLike;
	/** 当前时刻注入（测试用）；缺省 Date.now。 */
	now?: () => number;
	/** 判定缓存注入（测试用；换新 Map 即隔离）；缺省模块级共享缓存。 */
	cache?: Map<string, PreflightCacheEntry>;
	/** 预检超时注入（测试用）；缺省 10s。 */
	timeoutMs?: number;
}

const DEFAULT_TTL_MS = 300_000;
const DEFAULT_TIMEOUT_MS = 10_000;
const MAX_STDOUT_BYTES = 64 * 1024;

const providerCache = new Map<string, PreflightCacheEntry>();

function preflightEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return env.AMAGI_AUTH_PREFLIGHT !== "0";
}

function resolveTtlMs(env: NodeJS.ProcessEnv = process.env): number {
	const v = Number(env.AMAGI_AUTH_PREFLIGHT_TTL_MS);
	return Number.isFinite(v) && v >= 0 ? v : DEFAULT_TTL_MS;
}

/**
 * pi 调用形态解析——与 task-run.ts getPiInvocation 等价（官方 getPiInvocation 同款逻辑）。
 * 不 import 复用是为避免 task-run ⇄ auth-preflight 值级循环（.dependency-cruiser no-cycles
 * 硬门禁）；两处如需改动须同步（本注释为锚点）。
 */
function resolvePiInvocation(args: string[]): { command: string; args: string[] } {
	const current = process.argv[1];
	const isBunVirtual = current?.startsWith("/$bunfs/root/");
	if (current && !isBunVirtual && fs.existsSync(current)) {
		return { command: process.execPath, args: [current, ...args] };
	}
	const execName = path.basename(process.execPath).toLowerCase();
	if (!/^(node|bun)(\.exe)?$/.test(execName)) {
		return { command: process.execPath, args };
	}
	return { command: "pi", args };
}

/** 解析 auth check 的 stdout JSON（容忍前导日志行：整体解析失败时逐行回退取最后一个可解析对象）。 */
function parseAuthCheckJson(out: string): { status?: string; reason?: string } | null {
	const text = (out || "").trim();
	if (!text) return null;
	const via = (v: unknown): { status?: string; reason?: string } | null => {
		if (!v || typeof v !== "object" || Array.isArray(v)) return null;
		const o = v as Record<string, unknown>;
		return {
			status: typeof o.status === "string" ? o.status : undefined,
			reason: typeof o.reason === "string" ? o.reason : undefined,
		};
	};
	try {
		const hit = via(JSON.parse(text));
		if (hit) return hit;
	} catch { /* 整体解析失败 → 逐行回退 */ }
	const lines = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.startsWith("{"));
	for (let i = lines.length - 1; i >= 0; i--) {
		try {
			const hit = via(JSON.parse(lines[i]));
			if (hit) return hit;
		} catch { /* 跳过不可解析行 */ }
	}
	return null;
}

/** not_ready 定根因文案（actionable：provider 名 + 修复方向 + 开关出口；风格对齐 terminal-doctor 诊断）。 */
function notReadyMessage(provider: string, reason: string | undefined): string {
	return `[auth 预检] provider "${provider}" 凭据未就绪${reason ? `（reason: ${reason}）` : ""}——已在 spawn 前拦截本轮派发，避免整轮 401/403 空烧。建议：核对该 provider 的 API key/凭据配置，或运行 pi auth 登录该 provider 后重试；确认属环境误报可设 AMAGI_AUTH_PREFLIGHT=0 临时关闭预检`;
}

interface AuthCheckOutcome {
	ok: boolean;
	message?: string;
	/** true = 判定可入 TTL 缓存（spawn 成功且输出可解析；抖动/超时/解析失败不缓存）。 */
	cacheable: boolean;
}

async function runAuthCheck(provider: string, deps: AuthPreflightDeps): Promise<AuthCheckOutcome> {
	const doSpawn = deps.spawnFn
		?? ((command: string, args: string[]) => spawn(command, args, {
			stdio: ["ignore", "pipe", "pipe"],
			timeout: deps.timeoutMs ?? DEFAULT_TIMEOUT_MS,
		}) as unknown as PreflightChildLike);
	let child: PreflightChildLike;
	try {
		const inv = resolvePiInvocation(["auth", "check", "--provider", provider, "--json"]);
		child = doSpawn(inv.command, inv.args);
	} catch {
		return { ok: true, cacheable: false }; // spawn 同步抛错（参数/环境问题）→ 放行
	}
	const timeoutMs = deps.timeoutMs ?? DEFAULT_TIMEOUT_MS;
	return await new Promise<AuthCheckOutcome>((resolve) => {
		let out = "";
		let outBytes = 0;
		let settled = false;
		const finish = (r: AuthCheckOutcome) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			resolve(r);
		};
		const timer = setTimeout(() => {
			try { child.kill("SIGKILL"); } catch { /* 已退出的子进程 kill 失败无害 */ }
			finish({ ok: true, cacheable: false }); // 超时（挂起/网络抖动）→ 放行且不缓存
		}, timeoutMs);
		timer.unref?.();
		try {
			child.stdout?.on("data", (chunk) => {
				outBytes += Buffer.byteLength(String(chunk));
				if (outBytes <= MAX_STDOUT_BYTES) out += String(chunk);
			});
			child.stderr?.on("data", () => { /* 排空 stderr 管道防子进程阻塞；判定只认 stdout --json 契约 */ });
			child.on("error", () => finish({ ok: true, cacheable: false })); // ENOENT 等 spawn 失败 → 放行
			child.on("close", (code, signal) => {
				void code; // 退出码不参与判定：--json 契约下失败信息也在 stdout
				if (signal !== null) { finish({ ok: true, cacheable: false }); return; } // 被 kill（含 Node timeout SIGTERM）→ 抖动放行
				const parsed = parseAuthCheckJson(out);
				if (!parsed) { finish({ ok: true, cacheable: false }); return; } // 解析失败 → 放行
				if (parsed.status === "ready") { finish({ ok: true, cacheable: true }); return; }
				if (parsed.status === "not_ready") {
					if (parsed.reason === "provider_not_found") { finish({ ok: true, cacheable: true }); return; } // 自定义 provider 防误伤
					finish({ ok: false, cacheable: true, message: notReadyMessage(provider, parsed.reason) });
					return;
				}
				finish({ ok: true, cacheable: false }); // 契约外 status → 放行不缓存
			});
		} catch {
			finish({ ok: true, cacheable: false }); // 监听注册异常（畸形子进程对象）→ 放行
		}
	});
}

/**
 * 派发前凭据预检（P1②）。model 形如 "provider/model"（trim 后无 "/" 前缀或为空则直接放行，
 * 不做探测）。判定按 provider 记 TTL 缓存；not_ready（非 provider_not_found）抛 Error，
 * 由调用方（runPiTask）按启动失败收口。
 */
export async function authPreflight(model: string | undefined, deps: AuthPreflightDeps = {}): Promise<void> {
	if (!preflightEnabled()) return;
	const spec = (model || "").trim();
	const slash = spec.indexOf("/");
	if (slash <= 0) return; // 空 / 无 provider 前缀（裸模型名）→ 不预检
	// 8月迭代 pi-0.84 配合 修复轮（Major-4）：测试注入开关——命中时对任何含 / 的 model 直接
	// 抛错（入口级 fail-fast 验证用：无建档、无占槽）；生产环境不设置，不参与缓存。
	if (process.env.AMAGI_AUTH_PREFLIGHT_FORCE_FAIL === "1") {
		throw new Error(`[auth 预检·测试注入] AMAGI_AUTH_PREFLIGHT_FORCE_FAIL=1 强制预检失败（provider "${spec.slice(0, slash)}"）`);
	}
	const provider = spec.slice(0, slash);
	const now = deps.now ?? Date.now;
	const cache = deps.cache ?? providerCache;
	const ttl = resolveTtlMs();
	const hit = cache.get(provider);
	if (hit && ttl > 0 && now() - hit.at < ttl) {
		if (hit.ok) return;
		throw new Error(hit.message || notReadyMessage(provider, undefined)); // 缓存命中的 not_ready 同样拦截（TTL 内不重复探测）
	}
	const outcome = await runAuthCheck(provider, deps);
	if (outcome.cacheable && ttl > 0) cache.set(provider, { ok: outcome.ok, message: outcome.message, at: now() });
	if (!outcome.ok) throw new Error(outcome.message);
}
