/** ev-20261031-80292c：codemode 沙箱保留名错误增强——纯函数层，零 pi/fs 依赖。
 *
 * 根因：宿主把脚本包装为 `(async (tools, console) => {<code>\n})`（pi-codemode vm.js）后交给
 * QuickJS 编译，顶层 const/let/class/解构绑定声明 `tools`/`console` 在编译期撞包装函数参数名，
 * 报 `SyntaxError: invalid redefinition of parameter name`——消息不含冲突标识符、位置只指向
 * 声明初始化器（实测指向 `=` 或块边界），保留名事实只存在于沙箱内部硬编码里，对执行者完全
 * 不可见（信息断层）。amagi 作为装配层在两个透传点（codemode-runtime own 路径 / codemode-
 * adapter 受控路径）补齐该上下文：SyntaxError 触发 + 顶层声明名扫描 ∩ 保留名清单 → 追加
 * 「冲突名 + 完整清单 + 可照做换名示例」。交集空原样返回（零拒绝、纯增强、不引入新失败）。
 *
 * 遮蔽类运行时错误（const text=1 后调用 → TypeError: not a function）不在本轮语法错误面，
 * 行为保持现状（ev-20261031-80292c 裁定：留二期）。 */

/** codemode 沙箱保留名全集（宿主升级时按以下四来源锚点核对；无导出面可编程获取）：
 *  ① 包装函数参数（pi-codemode dist/runtime/vm.js：`(async (tools, console) => {`）——
 *     顶层 const/let/class/解构绑定声明即编译期 SyntaxError；var/函数声明/嵌套作用域合法遮蔽。
 *  ② prelude 全局（prelude-source.js 尾部/中部 defineProperty 注入 globalThis）：ALL_TOOLS、
 *     text、image、exit、store、load——声明=合法遮蔽（全局功能静默失效），建议整体避开。
 *  ③ 宿主发现面（pi-coding-agent codemode execute.js createDiscoveryGlobals 恒注入）：
 *     searchTools、describeTool、describeNamespace——同上。
 *  ④ 宿主自身保留集（pi-codemode execution.js RESERVED_GLOBALS，模块私有未导出）+ 语言内置
 *     globalThis；models 仅 models:true 时注入（amagi 两工厂恒 false，不列入）。
 * 实测时间 2026-11-02（pi 1.3.0 devDeps / 1.4.0 全局，锚点逐字一致）；pi 1.5.0 基线升级
 * （2026-11-05，pi-codemode 1.5.0）四来源复核仍逐字一致；pi 1.5.1 基线升级（2026-11-09，pi-codemode
 * 1.5.1）四来源复核仍逐字一致（vm.js:274 包装参数、prelude-source.js:450-455+333-334 全局注入、
 * codemode execute.js:592-637 发现面、execution.js:28-38 RESERVED_GLOBALS）。 */
export const CODEMODE_RESERVED_NAMES: readonly string[] = [
	"tools", "console", // ① 包装函数参数（撞名=SyntaxError）
	"ALL_TOOLS", "text", "image", "exit", "store", "load", // ② prelude 全局
	"searchTools", "describeTool", "describeNamespace", // ③ 宿主发现面
	"globalThis", // ④ 语言内置/宿主保留集
];
const RESERVED_NAME_SET = new Set(CODEMODE_RESERVED_NAMES);

/** 顶层（花括号深度 0 且不在圆括号内——for-head 的 const/let 绑定于循环块，不撞包装参数）
 *  const/let/class/解构绑定声明名提取。跟踪字符串/模板字面量与行/块注释状态；嵌套作用域（函数
 *  体/块/class 体）不扫——此类声明本不产生包装参数冲突（实测）。精度要求有限：残余误报上限=
 *  交集非空时多一行无害提示，无任何拒绝路径。 */
export function topLevelDeclaredNames(code: string): string[] {
	const out: string[] = [];
	const n = code.length;
	let i = 0;
	let depth = 0;
	let parenDepth = 0;
	const isIdentChar = (c: string): boolean => /[\w$]/.test(c);
	while (i < n) {
		const ch = code[i]!;
		if (ch === '"' || ch === "'" || ch === "`") {
			const quote = ch;
			i++;
			while (i < n) {
				const c = code[i]!;
				if (c === "\\") { i += 2; continue; }
				i++;
				if (c === quote) break;
				}
			continue;
		}
		if (ch === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; }
		if (ch === "/" && code[i + 1] === "*") {
			i += 2;
			while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
			i += 2;
			continue;
		}
		if (ch === "{") { depth++; i++; continue; }
		if (ch === "}") { if (depth > 0) depth--; i++; continue; }
		if (ch === "(") { parenDepth++; i++; continue; }
		if (ch === ")") { if (parenDepth > 0) parenDepth--; i++; continue; }
		if (depth === 0 && parenDepth === 0 && (i === 0 || !isIdentChar(code[i - 1]!))) {
			// 注：不用 ^ 锚——sticky(y) 已保证从 lastIndex 起匹配，而无 m 标志的 ^ 锚定字符串开头，
			// 两者联立会使 lastIndex>0（声明不在首行，如 @options 首行后）时永远失配（实测踩坑）。
			// 后瞻用负字符锚而非正向 [\s{]：`const[tools]`/`const/*c*/tools` 同样是合法声明头
			// （diting 遗留观察：正向后瞻漏掉无空白形态）。
			const decl = /(?:const|let|class)(?![\w$])/y;
			decl.lastIndex = i;
			const m = decl.exec(code);
			if (m) {
				i += m[0].length;
				const collected = collectBindingNames(code, i);
				out.push(...collected.names);
				i = collected.end;
				continue;
			}
		}
		i++;
	}
	return [...new Set(out)];
}

/** 跳过空白与行/块注释（扫描器共享；越界安全）。 */
function skipTrivia(code: string, start: number): number {
	let i = start;
	const n = code.length;
	while (i < n) {
		const ch = code[i]!;
		if (/\s/.test(ch)) { i++; continue; }
		if (ch === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; }
		if (ch === "/" && code[i + 1] === "*") {
			i += 2;
			while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
			i += 2;
			continue;
		}
		return i;
	}
	return i;
}

/** 位置 i 处的标识符（无则 null）。不用 ^ 锚：sticky 从 lastIndex 起匹配即可（^+y 联立在
 *  lastIndex>0 时永远失配，实测踩坑）。 */
function identifierAt(code: string, i: number): { name: string; end: number } | null {
	const re = /[A-Za-z_$][\w$]*/y;
	re.lastIndex = i;
	const m = re.exec(code);
	return m ? { name: m[0], end: i + m[0].length } : null;
}

/** 正则字面量跳过：i 指向开 `/`（调用方已判定非除法），跳过主体（`\/` 转义、`[...]` 字符类内
 *  `/` 不闭合）与尾 flags。diting F01：`const {x=/}/, tools}` 中 `/}/` 被当解构闭合/注释。 */
function skipRegExpLiteral(code: string, i: number): number {
	const n = code.length;
	let j = i + 1;
	let inClass = false;
	while (j < n) {
		const c = code[j]!;
		if (c === "\\") { j += 2; continue; }
		if (c === "[") inClass = true;
		else if (c === "]") inClass = false;
		else if (c === "/" && !inClass) { j++; break; }
		if (c === "\n") break; // 正则字面量不得跨行（词法事实）：防不平衡输入吞到末尾
		j++;
	}
	while (j < n && /[a-z]/i.test(code[j]!)) j++; // flags
	return j;
}

/** 表达式位置关键字：其后跟 `/` 是正则字面量而非除法（diting 增量反例：`return /}/` 曾被单字符
 *  回看误判为除法）。值形态关键字（this/true/false/null/super）不在列——其后 `/` 是除法。 */
const REGEX_PRECEDING_KEYWORDS = new Set([
	"return", "case", "typeof", "instanceof", "in", "of", "new", "delete", "void",
	"do", "else", "yield", "await", "throw", "extends",
]);

/** 正向词法 prev 状态：上一个有效 token 的尾字符 + 是否表达式起始关键字结尾。注释不更新状态
 *  （diting 增量反例：标识符后接块注释再接除号时，注释尾斜杠曾被当有效 token 误判正则）。 */
interface PrevToken { last?: string; wordKeyword?: boolean }

/** prev 状态判定 `/` 是否除法位置：值结束 token（非关键字标识符/数字/`)`/`]`/`}`/字符串）后是除法；
 *  否则（值开头/运算符/`,`/`=`/`(`/关键字后）→ 正则。启发式残余误判上限=漏/多收一个绑定
 *  （无害提示或漏提示，无拒绝路径）；`}` 后按除法（值语境对象字面量后除法多于块后正则）。 */
function slashDivisionFromPrev(prev: PrevToken): boolean {
	if (prev.last === undefined) return false; // 值开头 → 正则
	if (/[\w$]/.test(prev.last)) return prev.wordKeyword !== true;
	return /[)\]}`"']/.test(prev.last);
}

/** code[i] 为 `{`/`[`/`(` 时返回配对闭合**后**的位置（跳字符串/模板/注释/正则字面量/嵌套）。 */
function scanBracketed(code: string, i: number): number {
	const open = code[i]!;
	const close = open === "{" ? "}" : open === "[" ? "]" : ")";
	let d = 0;
	let j = i;
	const n = code.length;
	const prev: PrevToken = {};
	while (j < n) {
		const ch = code[j]!;
		if (/\s/.test(ch)) { j++; continue; } // 空白不更新 prev（词法状态只记有效 token）
		if (ch === '"' || ch === "'" || ch === "`") {
			j++;
			while (j < n && code[j] !== ch) { if (code[j] === "\\") j++; j++; }
			j++;
			prev.last = ch; prev.wordKeyword = false;
			continue;
		}
		if (ch === "/" && code[j + 1] === "/") { while (j < n && code[j] !== "\n") j++; continue; } // 注释不更新 prev
		if (ch === "/" && code[j + 1] === "*") {
			j += 2;
			while (j < n && !(code[j] === "*" && code[j + 1] === "/")) j++;
			j += 2;
			continue; // 注释不更新 prev
		}
		if (/[A-Za-z_$]/.test(ch)) {
			const id = identifierAt(code, j);
			if (id) {
				j = id.end;
				prev.last = id.name.at(-1); prev.wordKeyword = REGEX_PRECEDING_KEYWORDS.has(id.name);
				continue;
			}
		}
		if (ch === "/" && !slashDivisionFromPrev(prev)) { j = skipRegExpLiteral(code, j); prev.last = "/"; prev.wordKeyword = false; continue; }
		if (ch === open) d++;
		else if (ch === close) { d--; if (d === 0) return j + 1; }
		prev.last = ch; prev.wordKeyword = false;
		j++;
	}
	return j;
}

/** 从表达式开头扫到深度 0 的边界：`,` `;`（声明列表分隔/结束）、`}` `]`（解构闭合，防御）、
 *  ASI 边界（换行后是新声明关键字）或末尾。返回停点（停点字符未消费）。调用点内值中逗号
 *  （函数实参/数组字面量等）都在嵌套深度内不会误停；箭头体 `{...}` 内的分隔符同理。 */
function scanValueEnd(code: string, start: number): number {
	let i = start;
	const n = code.length;
	const prev: PrevToken = {};
	while (i < n) {
		const ch = code[i]!;
		if (/\s/.test(ch) && ch !== "\n") { i++; continue; } // 空白不更新 prev；换行例外（ASI 边界检查在 \n 分支）
		if (ch === '"' || ch === "'" || ch === "`") {
			i++;
			while (i < n && code[i] !== ch) { if (code[i] === "\\") i++; i++; }
			i++;
			prev.last = ch; prev.wordKeyword = false;
			continue;
		}
		if (ch === "/" && code[i + 1] === "/") { while (i < n && code[i] !== "\n") i++; continue; } // 注释不更新 prev
		if (ch === "/" && code[i + 1] === "*") {
			i += 2;
			while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
			i += 2;
			continue; // 注释不更新 prev
		}
		if (/[A-Za-z_$]/.test(ch)) {
			const id = identifierAt(code, i);
			if (id) {
				i = id.end;
				prev.last = id.name.at(-1); prev.wordKeyword = REGEX_PRECEDING_KEYWORDS.has(id.name);
				continue;
			}
		}
		if (ch === "/" && !slashDivisionFromPrev(prev)) { i = skipRegExpLiteral(code, i); prev.last = "/"; prev.wordKeyword = false; continue; }
		if (ch === "{" || ch === "[" || ch === "(") {
			i = scanBracketed(code, i);
			prev.last = code[i - 1] ?? ")"; prev.wordKeyword = false;
			continue;
		}
		if (ch === "," || ch === ";" || ch === "}" || ch === "]") return i;
		// ASI 边界：换行后接新声明关键字（无分号风格的连续声明，值到此为止）
		if (ch === "\n") {
			const ahead = skipTrivia(code, i + 1);
			if (/^(?:const|let|var|class|function)\b/.test(code.slice(ahead, ahead + 10))) return i;
		}
		prev.last = ch; prev.wordKeyword = false;
		i++;
	}
	return i;
}

/** 绑定后可选初始化器 `= 值` 的跳过：无 `=`（含 `==`/`=>` 误防御）时原位返回；有则扫值到边界。 */
function skipInitializer(code: string, start: number): number {
	const i = skipTrivia(code, start);
	if (code[i] !== "=" || code[i + 1] === "=" || code[i + 1] === ">") return i;
	return scanValueEnd(code, i + 1);
}

/** 声明头（const/let）之后的绑定名收集：`name`、`a = 1, b = f(x, y)`、`{a, b: c, ...r}`、
 *  `[a, [b]]`（含默认值/重命名/rest/嵌套/逗号分隔绑定列表——diting F01：旧版首个绑定即 return、
 *  解构遇默认值 token 失配终止，`const n=1, tools=2` 与 `{x=0, tools}` 均漏收）。返回 end=
 *  绑定列表结束位置（主扫描从此继续）。class 名由本函数首绑定分支顺带收集（后随 `{` 交回主扫描
 *  降深度）。 */
function collectBindingNames(code: string, start: number): { names: string[]; end: number } {
	const names: string[] = [];
	let i = skipTrivia(code, start);
	while (i < code.length) {
		const ch = code[i]!;
		if (ch === "{" || ch === "[") {
			const close = scanBracketed(code, i);
			names.push(...destructureNames(code.slice(i, close)));
			i = close;
		} else if (/[A-Za-z_$]/.test(ch)) {
			const id = identifierAt(code, i);
			if (!id) return { names, end: i };
			names.push(id.name);
			i = id.end;
		} else {
			// 非绑定形态（class 后直接 `{` 已被标识符分支收集类名）：交回主扫描
			return { names, end: i };
		}
		// 可选 `= 初始化器`（停点为深度 0 的 `,`/`;`/ASI 边界），逗号 → 下一绑定，否则声明结束
		i = skipInitializer(code, i);
		if (code[i] === ",") { i = skipTrivia(code, i + 1); continue; }
		return { names, end: i };
	}
	return { names, end: i };
}

/** 解构模式（含最外层 `{}`/`[]`）绑定名：对象简写/重命名/rest/默认值/嵌套；数组元素位。属性名
 *  不是绑定；字符串/数值/计算键（diting F04：`{"tools": x}` 键曾被误认成绑定）与键表达式整体
 *  跳过，只扫冒号后目标；默认值表达式整体跳过（到深度 0 的 `,`/闭合）。 */
function collectTarget(pattern: string, colonPos: number, out: string[]): number {
	const targetStart = skipTrivia(pattern, colonPos + 1);
	const tch = pattern[targetStart]!;
	if (tch === "{" || tch === "[") {
		const close = scanBracketed(pattern, targetStart);
		out.push(...destructureNames(pattern.slice(targetStart, close)));
		return skipInitializer(pattern, close);
	}
	const target = identifierAt(pattern, targetStart);
	if (target) { out.push(target.name); return skipInitializer(pattern, target.end); }
	return targetStart;
}

function destructureNames(pattern: string): string[] {
	const out: string[] = [];
	let i = skipTrivia(pattern, 1); // 跳过开括号
	const n = pattern.length;
	while (i < n) {
		const ch = pattern[i]!;
		if (ch === "}" || ch === "]") return out;
		if (ch === ",") { i = skipTrivia(pattern, i + 1); continue; }
		if (ch === "." && pattern.slice(i, i + 3) === "...") {
			i = skipTrivia(pattern, i + 3);
			const id = identifierAt(pattern, i);
			if (id) { out.push(id.name); i = id.end; }
			i = skipInitializer(pattern, i);
			continue;
		}
		if (ch === '"' || ch === "'") {
			// 字符串键 {"tools": x}：键不是绑定（F04），目标在冒号后
			let j = i + 1;
			while (j < n && pattern[j] !== ch) { if (pattern[j] === "\\") j++; j++; }
			const colon = skipTrivia(pattern, j + 1);
			if (pattern[colon] === ":") { i = collectTarget(pattern, colon, out); continue; }
			i = j + 1; // 理论不可达（对象位字符串必为键）：前进防死循环
			continue;
		}
		if (/[0-9]/.test(ch)) {
			// 数值键 {0: x} / {1.5: x}
			let j = i;
			while (j < n && /[\w.$]/.test(pattern[j]!)) j++;
			const colon = skipTrivia(pattern, j);
			if (pattern[colon] === ":") { i = collectTarget(pattern, colon, out); continue; }
			i = j; // 数组位数字非绑定（不可达）：前进防死循环
			continue;
		}
		if (ch === "{" || ch === "[") {
			const close = scanBracketed(pattern, i);
			const after = skipTrivia(pattern, close);
			if (pattern[after] === ":") {
				// 计算键 {[expr]: target}：键表达式整体跳过，不递归当数组模式（F04）
				i = collectTarget(pattern, after, out);
				continue;
			}
			out.push(...destructureNames(pattern.slice(i, close)));
			i = skipInitializer(pattern, close);
			continue;
		}
		if (/[A-Za-z_$]/.test(ch)) {
			const id = identifierAt(pattern, i);
			if (!id) { i++; continue; }
			i = id.end;
			const after = skipTrivia(pattern, i);
			if (pattern[after] === ":") { i = collectTarget(pattern, after, out); continue; }
			out.push(id.name); // 简写位（可带默认值）
			i = skipInitializer(pattern, after);
			continue;
		}
		i++; // 其它字符（理论不可达）：前进防死循环
	}
	return out;
}

/** 追加文案：冲突名 + 完整清单 + 可照做换名示例（SyntaxError 触发 + 交集非空时才生成）。 */
function reservedNameAppendix(conflicts: readonly string[]): string {
	return `[codemode 保留名] "${conflicts.join('", "')}" 是 codemode 沙箱保留名——脚本在 (async (tools, console) => {...}) 内执行，tools/console 不能用 const/let/class/解构声明（编译期撞包装参数名）；其余沙箱全局 ${CODEMODE_RESERVED_NAMES.filter((n) => n !== "tools" && n !== "console").join("、")} 建议整体避开（顶层声明会静默遮蔽全局功能）。可照做换名示例：const found = await searchTools("read", { limit: 1 });（冲突名换成 found 等自定义名）`;
}

/** 错误文本增强：SyntaxError 且脚本顶层声明名 ∩ 保留名清单非空 → 追加保留名指引；交集空原样
 *  返回（降级不引入新失败；quickjs 措辞升级不失稳——触发只看 "SyntaxError" 字样）。 */
export function enhanceCodemodeErrorText(text: string, code: string): string {
	if (!text.includes("SyntaxError")) return text;
	const conflicts = topLevelDeclaredNames(code).filter((name) => RESERVED_NAME_SET.has(name));
	if (conflicts.length === 0) return text;
	return `${text}\n${reservedNameAppendix(conflicts)}`;
}

/** 工具结果透传点共用：isError 且首个 text 块含 SyntaxError 时增强该块文本（其余块原样）。
 *  amagi 两个透传点（codemode-runtime own / codemode-adapter 受控）单一来源；host 模式
 *  （CLI 显式 -e builtin:codemode 前置）无 result 重写点，不可达如实标注。 */
export function enhanceCodemodeErrorResult<T extends { isError?: boolean; content?: unknown }>(result: T, code: string): T {
	if (result.isError !== true || !Array.isArray(result.content)) return result;
	let enhanced = false;
	const content = result.content.map((block): unknown => {
		if (enhanced || typeof block !== "object" || block === null) return block;
		const b = block as { type?: unknown; text?: unknown };
		if (b.type !== "text" || typeof b.text !== "string") return block;
		// 仅当文本真实改写才占用增强位：首个 text 块可能是不含 SyntaxError 的状态行（如
		// "Script failed\n…"），无条件置位会把唯一增强名额耗在未改写块上（实测踩坑）。
		const text = enhanceCodemodeErrorText(b.text, code);
		if (text === b.text) return block;
		enhanced = true;
		return { ...b, text };
	});
	return enhanced ? { ...result, content } as T : result;
}
