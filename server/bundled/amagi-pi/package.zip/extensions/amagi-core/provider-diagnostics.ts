/** Passive provider diagnostics. Transport events are time-correlated only, never attributed as causes. */
import { subscribe, unsubscribe } from "node:diagnostics_channel";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { networkRecoveryState } from "./child-network-recovery.ts";

export interface ProviderDiagnostic {
 diagVersion: 1;
 at: number;
 model: { provider: string; id: string };
 modelChanged: boolean;
 category: "network" | "rate-limit" | "authentication" | "other";
 transport: Array<{ code: string; correlation: "temporal-unconfirmed" }>;
 consecutiveErrors: number;
 hostRetryBudget: "unknown";
 amagiRecovery?: { attempts: number; max: number; windowMs: number };
 anchors: { lastSuccessfulTool?: { toolName: string; toolCallId: string; at: number } };
 sideEffectReplay: false;
}
const codes = new Set(["ECONNRESET", "ECONNREFUSED", "EPIPE", "ENOTFOUND", "ETIMEDOUT", "ENETUNREACH", "EHOSTUNREACH", "UND_ERR_SOCKET", "UND_ERR_CONNECT_TIMEOUT", "UND_ERR_HEADERS_TIMEOUT", "UND_ERR_BODY_TIMEOUT"]);
function safeIdentifier(value: string): string {
 return /^[A-Za-z0-9_.:-]{1,128}$/.test(value) && !/sentinel|bearer|authorization|(?:^|[-_])(?:sk|key|token)[-_]/i.test(value) ? value : "unknown";
}
function classify(message: string): ProviderDiagnostic["category"] {
 if (/\b429\b|rate.?limit/i.test(message)) return "rate-limit";
 if (/\b(?:401|403)\b|authentication|unauthorized/i.test(message)) return "authentication";
 if (/fetch failed|connection|socket|network|timeout|timed out|ECONN|EPIPE|UND_ERR/i.test(message)) return "network";
 return "other";
}
export function registerProviderDiagnostics(pi: ExtensionAPI): void {
 let listening = false;
 let faults: ProviderDiagnostic["transport"] = [];
 let lastTool: ProviderDiagnostic["anchors"]["lastSuccessfulTool"];
 let previousModel: string | undefined;
 let errors = 0;
 let pending: ProviderDiagnostic | undefined;
 const receive = (message: unknown) => {
  const code = (message as { error?: { code?: unknown } } | null)?.error?.code;
  if (typeof code === "string" && codes.has(code)) faults = [...faults, { code, correlation: "temporal-unconfirmed" as const }].slice(-8);
 };
 const start = () => {
  faults = []; lastTool = undefined; previousModel = undefined; errors = 0; pending = undefined;
  if (!listening) { subscribe("undici:request:error", receive); subscribe("undici:client:connectError", receive); listening = true; }
 };
 const stop = () => {
  if (listening) { unsubscribe("undici:request:error", receive); unsubscribe("undici:client:connectError", receive); listening = false; }
  faults = []; pending = undefined;
 };
 pi.on("session_start", start);
 pi.on("session_shutdown", stop);
 pi.on("before_agent_start", () => { faults = []; pending = undefined; });
 pi.on("turn_start", () => { faults = []; });
 pi.on("tool_execution_end", event => {
  if (!event.isError) lastTool = { toolName: safeIdentifier(event.toolName), toolCallId: safeIdentifier(event.toolCallId), at: Date.now() };
 });
 pi.on("message_end", event => {
  const m = event.message;
  if (m.role !== "assistant") return;
  const key = `${m.provider}/${m.model}`;
  const changed = previousModel !== undefined && previousModel !== key;
  previousModel = key;
  if (m.stopReason !== "error") { errors = 0; return; }
  errors++;
  const recovery = networkRecoveryState();
  pending = { diagVersion: 1, at: Date.now(), model: { provider: safeIdentifier(m.provider), id: safeIdentifier(m.model) }, modelChanged: changed, category: classify(m.errorMessage ?? ""), transport: faults.slice(), consecutiveErrors: errors, hostRetryBudget: "unknown", ...(recovery ? { amagiRecovery: recovery } : {}), anchors: { ...(lastTool ? { lastSuccessfulTool: lastTool } : {}) }, sideEffectReplay: false };
 });
 pi.on("turn_end", (_event, ctx) => {
  if (!pending) return;
  const diagnostic = pending; pending = undefined;
  try { pi.appendEntry("amagi:provider-diagnostic", diagnostic); } catch { /* journal: diagnostic persistence unavailable */ console.warn("[amagi] provider diagnostic: session entry unavailable"); }
  if (ctx.hasUI) {
   const tool = diagnostic.anchors.lastSuccessfulTool?.toolName;
   try { ctx.ui.notify(`Provider ${diagnostic.category} ×${diagnostic.consecutiveErrors}; retry budget unknown${tool ? `; last successful tool: ${tool}` : ""}`, "warning"); } catch { /* journal: provider diagnostic UI unavailable */ console.warn("[amagi] provider diagnostic: notification unavailable"); }
  }
 });
}
