/**
 * run-bg-wire.ts — P4（寄生增强方案 §4.2，pi-0.99.1 批 W2）：run_bg 结构化输出 wire v1。
 *
 * 纯 schema/投影模块（纪律沿 task-query-wire §4.1）：零 I/O、零宿主私有依赖（仅 typebox +
 * task-query-wire 的纯字符串脱敏函数 import 复用——§4.3「先允许直接引用已有导出」）；不读
 * 用户现场、不 spawn/不 kill/不碰进程组（§4.1「DTO 接线不能重复 spawn 或 cancel」——mapper
 * 只做投影）。调用点在 run-bg.ts 接线层：runBgAction 单次执行内部对象（RunBgRecord/RunBgState/
 * stateOf 产物/tail 同次读取）→ 本模块 DTO → 封闭 envelope。
 *
 * wire 身份：kind="amagi.run-bg"、wireVersion=1、schemaVersion=1、action、ok、isError。
 * 成功分支带 data；失败分支带 error:{code,message}（code ∈ invalid-input/not-found/permission/
 * operation/internal；message 过 redactCredentials 同源脱敏）。action 非法映射 null。
 * URN：urn:amagi:run-bg:<分支>:1。v1 冻结；增删字段先升 schemaVersion。
 *
 * 分支投影（源闭合锚点=run-bg.ts RunBgRecord/RunBgState/stateOf/tailLog）：
 *  - start/status/cancel：handle 状态投影 14 字段（handle/state/pid/ownerPid/exitCode/timedOut/
 *    cancelled/logPath/startedAt/finishedAt + 源记录 command/label/timeoutMs + stateOf().elapsedMs）；
 *    未知/未发生 → null。state 为 string 投影（合法值 running/done/failed/cancelled/timed-out 由
 *    生产 stateOf 单源定义——§4.2「state 枚举直接复用生产定义，不新增成功捷径」；未知值原字面
 *    透传）。cancel 双态（已结束免取消/已发 SIGTERM）均走本档——wire 携带发令时刻的真实状态。
 *  - result：上述状态投影 + text/textTruncated（同次 tailLog 读取；日志不可读 text=null）。
 *    进程非零 exitCode 是业务事实（state=failed、ok=true），与工具失败（error 档）分开——
 *    isError 语义不因退出码改变（§4.2 result 行）。
 *  - list：records（同状态投影，行序=正文行序——现行 slice(-30) 语义原样保留，本批不修排序）+
 *    returned/truncated。
 *  - error：{code,message} 封闭 envelope（§4.3：不强转任务契约 ContractError）。
 */
import { Type } from "typebox";
import { redactCredentials } from "./task-query-wire.ts";

// ── wire 身份常量（固定字面量；接线层与测试共用） ──────────────────────────────

export const RUN_BG_WIRE_KIND = "amagi.run-bg";
export const RUN_BG_WIRE_VERSION = 1;
export const RUN_BG_SCHEMA_VERSION = 1;
/** list 行上限（现行 slice(-30) 语义；超限 truncated=true——不扩历史）。 */
export const RUN_BG_LIST_MAX = 30;

export const RUN_BG_WIRE_URNS = {
	start: "urn:amagi:run-bg:start:1",
	status: "urn:amagi:run-bg:status:1",
	result: "urn:amagi:run-bg:result:1",
	cancel: "urn:amagi:run-bg:cancel:1",
	list: "urn:amagi:run-bg:list:1",
	error: "urn:amagi:run-bg:error:1",
} as const;

export const RUN_BG_ERROR_CODES = ["invalid-input", "not-found", "permission", "operation", "internal"] as const;
export type RunBgErrorCode = (typeof RUN_BG_ERROR_CODES)[number];

export type RunBgAction = "start" | "status" | "result" | "cancel" | "list";

// ── 共享子 schema ─────────────────────────────────────────────────────────────

const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });
const SignedSafeInt = Type.Integer({ minimum: -Number.MAX_SAFE_INTEGER, maximum: Number.MAX_SAFE_INTEGER });
const NullableString = Type.Union([Type.String(), Type.Null()]);

const WireCommonProperties = {
	kind: Type.Literal(RUN_BG_WIRE_KIND),
	wireVersion: Type.Literal(RUN_BG_WIRE_VERSION),
	schemaVersion: Type.Literal(RUN_BG_SCHEMA_VERSION),
};

const ErrorCodeSchema = Type.Union(RUN_BG_ERROR_CODES.map((c) => Type.Literal(c)));

/** 句柄状态投影 14 字段（start/status/cancel/result 共用；§4.2 固定投影 + 源记录直投影补充）。 */
const RecordProperties = {
	handle: Type.String({ description: "run_bg 句柄（=RunBgRecord.id 全字面）" }),
	state: Type.String({ description: "进程状态（合法值 running/done/failed/cancelled/timed-out 由生产 stateOf 单源定义；未知值原字面透传）" }),
	pid: NonNegativeSafeInt,
	ownerPid: NonNegativeSafeInt,
	exitCode: Type.Union([SignedSafeInt, Type.Null()], { description: "退出码（可负安全整数；未收口 null）" }),
	timedOut: Type.Boolean(),
	cancelled: Type.Boolean(),
	logPath: Type.String(),
	startedAt: NonNegativeSafeInt,
	finishedAt: Type.Union([NonNegativeSafeInt, Type.Null()], { description: "完成时刻 ms；未完成 null" }),
	command: Type.String({ description: "启动命令全字面（非正文 48 字符短形）" }),
	label: NullableString,
	timeoutMs: Type.Union([NonNegativeSafeInt, Type.Null()]),
	elapsedMs: NonNegativeSafeInt,
};

// ── 分支 schema（§4.2 规格块逐字段） ──────────────────────────────────────────

export const RunBgStartWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("start"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object(RecordProperties, { additionalProperties: false, description: "启动时刻句柄投影（state=running、exitCode/finishedAt=null）" }),
}, { $id: RUN_BG_WIRE_URNS.start, additionalProperties: false, description: "run_bg start 档 wire（§4.2）" });

export const RunBgStatusWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("status"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object(RecordProperties, { additionalProperties: false, description: "查询时刻句柄投影（跨会话句柄经 ndjson 重建只读视图，同一投影）" }),
}, { $id: RUN_BG_WIRE_URNS.status, additionalProperties: false, description: "run_bg status 档 wire（§4.2）" });

export const RunBgResultWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("result"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		...RecordProperties,
		text: NullableString,
		textTruncated: Type.Boolean({ description: "日志尾部是否截断（>TAIL_BYTES；text=null 时恒 false）" }),
	}, { additionalProperties: false, description: "状态投影 + 同次 tail 读取（进程非零 exit 是业务事实 state=failed，不是工具失败）" }),
}, { $id: RUN_BG_WIRE_URNS.result, additionalProperties: false, description: "run_bg result 档 wire（§4.2）" });

export const RunBgCancelWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("cancel"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object(RecordProperties, { additionalProperties: false, description: "发令时刻句柄投影（已结束免取消=终态；已发 SIGTERM=cancelled 且 finishedAt=null）" }),
}, { $id: RUN_BG_WIRE_URNS.cancel, additionalProperties: false, description: "run_bg cancel 档 wire（§4.2）" });

export const RunBgListWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("list"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		records: Type.Array(Type.Object(RecordProperties, { additionalProperties: false }), { maxItems: RUN_BG_LIST_MAX, description: "行序=正文行序（现行排序+slice 语义原样保留）" }),
		returned: NonNegativeSafeInt,
		truncated: Type.Boolean({ description: "合并视图总数超 30（现行最近条数语义）" }),
	}, { additionalProperties: false }),
}, { $id: RUN_BG_WIRE_URNS.list, additionalProperties: false, description: "run_bg list 档 wire（§4.2）" });

export const RunBgErrorWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Union([Type.Literal("start"), Type.Literal("status"), Type.Literal("result"), Type.Literal("cancel"), Type.Literal("list"), Type.Null()]),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	error: Type.Object({
		code: ErrorCodeSchema,
		message: Type.String(),
	}, { additionalProperties: false }),
}, { $id: RUN_BG_WIRE_URNS.error, additionalProperties: false, description: "run_bg 工具内失败 wire（§4.2 error 分支；message 已同源脱敏）" });

/** 六封闭分支 Union（含 error——注册面统一校验器；消费者判据 kind/wireVersion/action/ok/schemaVersion）。 */
export const RunBgOutputSchema = Type.Union(
	[RunBgStartWireSchema, RunBgStatusWireSchema, RunBgResultWireSchema, RunBgCancelWireSchema, RunBgListWireSchema, RunBgErrorWireSchema],
	{ description: "run_bg 结构化输出 wire v1（六封闭分支：start/status/result/cancel/list/error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；一致性由专项测试 Value.Check+键集对照双断言） ──

export interface RunBgWireCommon {
	kind: typeof RUN_BG_WIRE_KIND;
	wireVersion: typeof RUN_BG_WIRE_VERSION;
	schemaVersion: typeof RUN_BG_SCHEMA_VERSION;
}

export interface RunBgRecordWire {
	handle: string;
	state: string;
	pid: number;
	ownerPid: number;
	exitCode: number | null;
	timedOut: boolean;
	cancelled: boolean;
	logPath: string;
	startedAt: number;
	finishedAt: number | null;
	command: string;
	label: string | null;
	timeoutMs: number | null;
	elapsedMs: number;
}
export interface RunBgStartWire extends RunBgWireCommon { action: "start"; ok: true; isError: false; data: RunBgRecordWire }
export interface RunBgStatusWire extends RunBgWireCommon { action: "status"; ok: true; isError: false; data: RunBgRecordWire }
export interface RunBgResultWire extends RunBgWireCommon { action: "result"; ok: true; isError: false; data: RunBgRecordWire & { text: string | null; textTruncated: boolean } }
export interface RunBgCancelWire extends RunBgWireCommon { action: "cancel"; ok: true; isError: false; data: RunBgRecordWire }
export interface RunBgListWire extends RunBgWireCommon { action: "list"; ok: true; isError: false; data: { records: RunBgRecordWire[]; returned: number; truncated: boolean } }
export interface RunBgErrorWire extends RunBgWireCommon {
	action: RunBgAction | null; ok: false; isError: true;
	error: { code: RunBgErrorCode; message: string };
}
export type RunBgWireOutput = RunBgStartWire | RunBgStatusWire | RunBgResultWire | RunBgCancelWire | RunBgListWire | RunBgErrorWire;

// ── 投影源（run-bg.ts 单次执行内部对象的结构声明——本模块不 import run-bg.ts 防循环依赖；
//    字段闭合锚点=run-bg.ts RunBgRecord/RunBgState/stateOf 返回值，见 P4 报告源形状闭合表） ──

export interface RunBgRecordSource {
	/** = RunBgRecord.id。 */
	handle: string;
	/** = stateOf().state（生产枚举值）。 */
	state: string;
	/** = RunBgRecord.pid / ownerPid。 */
	pid: number;
	ownerPid: number;
	/** = stateOf().exitCode / RunBgState.exitCode（未收口 → null）。 */
	exitCode?: number | null;
	/** = RunBgState.timedOut / cancelled（缺省 false）。 */
	timedOut?: boolean;
	cancelled?: boolean;
	/** = RunBgRecord.command / label / logPath / startedAt / timeoutMs。 */
	command: string;
	label?: string | null;
	logPath: string;
	startedAt: number;
	timeoutMs?: number | null;
	/** = RunBgState.finishedAt（未完成 → null）。 */
	finishedAt?: number | null;
	/** = stateOf().elapsedMs。 */
	elapsedMs?: number;
}

// ── 字段归一小件（未知/类型不合 → null / 缺省值） ──────────────────────────────

const numOrNull = (v: unknown): number | null =>
	typeof v === "number" && Number.isInteger(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER ? v : null;
const nonNegOrNull = (v: unknown): number | null => {
	const n = numOrNull(v);
	return n !== null && n >= 0 ? n : null;
};
const boolOr = (v: unknown, dflt: boolean): boolean => (typeof v === "boolean" ? v : dflt);

function recordOf(r: Readonly<RunBgRecordSource>): RunBgRecordWire {
	return {
		handle: r.handle,
		state: r.state,
		pid: nonNegOrNull(r.pid) ?? 0,
		ownerPid: nonNegOrNull(r.ownerPid) ?? 0,
		exitCode: numOrNull(r.exitCode),
		timedOut: boolOr(r.timedOut, false),
		cancelled: boolOr(r.cancelled, false),
		logPath: r.logPath,
		startedAt: nonNegOrNull(r.startedAt) ?? 0,
		finishedAt: nonNegOrNull(r.finishedAt),
		command: typeof r.command === "string" ? redactCredentials(r.command) : r.command,
		label: typeof r.label === "string" ? redactCredentials(r.label) : null,
		timeoutMs: nonNegOrNull(r.timeoutMs),
		elapsedMs: nonNegOrNull(r.elapsedMs) ?? 0,
	};
}

// ── 各档映射 ─────────────────────────────────────────────────────────────────

export function toStartWire(r: Readonly<RunBgRecordSource>): RunBgStartWire {
	return { kind: RUN_BG_WIRE_KIND, wireVersion: RUN_BG_WIRE_VERSION, schemaVersion: RUN_BG_SCHEMA_VERSION, action: "start", ok: true, isError: false, data: recordOf(r) };
}

export function toStatusWire(r: Readonly<RunBgRecordSource>): RunBgStatusWire {
	return { kind: RUN_BG_WIRE_KIND, wireVersion: RUN_BG_WIRE_VERSION, schemaVersion: RUN_BG_SCHEMA_VERSION, action: "status", ok: true, isError: false, data: recordOf(r) };
}

export function toResultWire(r: Readonly<RunBgRecordSource>, text: string | null, textTruncated: boolean): RunBgResultWire {
	return { kind: RUN_BG_WIRE_KIND, wireVersion: RUN_BG_WIRE_VERSION, schemaVersion: RUN_BG_SCHEMA_VERSION, action: "result", ok: true, isError: false, data: { ...recordOf(r), text: text === null ? null : redactCredentials(text), textTruncated: text === null ? false : textTruncated === true } };
}

export function toCancelWire(r: Readonly<RunBgRecordSource>): RunBgCancelWire {
	return { kind: RUN_BG_WIRE_KIND, wireVersion: RUN_BG_WIRE_VERSION, schemaVersion: RUN_BG_SCHEMA_VERSION, action: "cancel", ok: true, isError: false, data: recordOf(r) };
}

export function toListWire(records: readonly RunBgRecordSource[], returned: number, truncated: boolean): RunBgListWire {
	return {
		kind: RUN_BG_WIRE_KIND, wireVersion: RUN_BG_WIRE_VERSION, schemaVersion: RUN_BG_SCHEMA_VERSION,
		action: "list", ok: true, isError: false,
		data: {
			records: records.slice(0, RUN_BG_LIST_MAX).map(recordOf),
			returned: Math.max(0, Math.trunc(returned) || 0),
			truncated: truncated === true,
		},
	};
}

/** error 档：action 只认合法五档字面（非法/缺席 → null）；message 同源脱敏。
 *  code 语义：invalid-input（参数）/ not-found（句柄）/ permission（策略门拒：stash 串联门、
 *  Windows node 预检、跨进程 cancel）/ operation（spawn 等操作失败）/ internal（意外异常兜底）。 */
export function toRunBgErrorWire(action: unknown, code: RunBgErrorCode, message: string): RunBgErrorWire {
	const known: RunBgAction | null =
		action === "start" || action === "status" || action === "result" || action === "cancel" || action === "list" ? action : null;
	return {
		kind: RUN_BG_WIRE_KIND,
		wireVersion: RUN_BG_WIRE_VERSION,
		schemaVersion: RUN_BG_SCHEMA_VERSION,
		action: known,
		ok: false,
		isError: true,
		error: { code, message: redactCredentials(message) },
	};
}
