/**
 * rpc-pool.ts — T2-9 RPC 常驻进程池（独立运行时 API，暂不在 index.ts 接线）。
 *
 * 设计边界：
 * - steer 是“调整下一步”，不会抢占当前 assistant stream/tool；idle 会话改用 prompt。
 * - controller WAL 先于 stdin 写入并 fsync；pi session JSONL 仅用于完成 entry 对账。
 * - extension_ui input/select/confirm/editor 经 request id 桥接；custom() 由 pi RPC 自身降级为 unsupported。
 * - 池容量有界，worker 同一时刻只服务一个 task cycle；跨 sessionKey 复用前先 new_session。
 */

import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { RUNTIME_FINGERPRINT, newRuntimeEventAccumulator, observeRuntimeEvent, runtimeObservation } from "./runtime-fingerprint.ts";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import { appendCompactionEnv } from "./compaction-config.ts";
import { prependPathEntries, readProjectShellPathPrepend } from "./shell-env.ts";
import * as os from "node:os";
import * as path from "node:path";
import { StringDecoder } from "node:string_decoder";
import { amagiDataDir } from "./data-dir.ts";
// B7（十月迭代 §5.4）：RPC extension UI 子协议分发与 pending 表（对话框经 broker 建远程应答面；
// fire-and-forget 单向投影；未知方法降级告警）。
import { DEFAULT_REMOTE_DIALOG_DEADLINE_MS, RpcDialogBroker, type RpcDialogAnswer, type RpcDialogKey, type RpcDialogResolvedAnswer, type RpcDialogSubmitResult } from "./rpc-extension-ui.ts";
// P4（amagi-pi v2，方案 §5.2 RPC 行/§8.3-P4）：worker 权限指纹——启动携带有效授权 digest；
// 不同权限/资源集不复用进程（闲置即退役重建，运行中不热改）；复用前校验指纹一致。
import { PERMISSION_CWD_ENV, PERMISSION_DIGEST_ENV, PERMISSION_GRANT_ENV, permissionGrantDigest } from "./file-permission.ts";
// B5B（ev-20261012-7517d8 批B §5.3）：codemode 持久账户——RPC 按任务锚派生账户，进指纹与 worker env。
import { CODEMODE_LEDGER_ASSEMBLY_VERSION, codemodeAccountIdOfRawGrant } from "./codemode-ledger.ts";
import { validatePermissionGrant, type PermissionGrant } from "./contracts/permission.ts";
import { appendMcpCredentialEnv, normalizeMcpPermission } from "./mcp-config.ts";

const MAX_POOL_SIZE = 4;
const DEFAULT_POOL_SIZE = 2;
const DEFAULT_IDLE_TIMEOUT_MS = 5 * 60_000;
const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;
const DEFAULT_UI_TIMEOUT_MS = 60_000;
const DEFAULT_SHUTDOWN_GRACE_MS = 2_000;
const MAX_RPC_LINE_BYTES = 4 * 1024 * 1024;
const MAX_WAL_COMMAND_BYTES = 2 * 1024 * 1024;
const WAL_VERSION = 2;
const GENERATION_META_VERSION = 1;
const GENERATION_FILE = "generation.json";
const CONTROLLER_LOCK_FILE = "controller.lock";
const DEFAULT_RECOVERY_PROMPT = "Continue the last unanswered request from the recovered session. Do not repeat completed work.";

type WorkerState = "starting" | "reserved" | "idle" | "running" | "ui_wait" | "recovering" | "stopping" | "dead";
export type RpcTaskState = "starting" | "running" | "ui_wait" | "recovering" | "settled" | "error";

export interface RpcCommand {
	id?: string;
	type: string;
	[key: string]: unknown;
}

export interface RpcResponse {
	id?: string;
	type: "response";
	command: string;
	success: boolean;
	data?: any;
	error?: string;
}

// ── P7（寄生增强方案 §7.2）：RPC disposition 接缝 ──────────────────────────────
// 宿主 0.99+ 对 prompt/steer/follow_up 响应携带 data.disposition 三态，描述「本次提交的输入」
// 的去向——非 run 完成保证，也非扩展独立工作的边界（H9：handled 不保证扩展没有独立启动工作）。

export type RpcDisposition = "started" | "queued" | "handled";

export type RpcDispositionOutcome =
	| { kind: "known"; disposition: RpcDisposition }
	| { kind: "missing" }
	| { kind: "unknown"; value: string };

/** 解析响应 disposition：三态字面量为 known；缺失为 missing；其它值原样保留为 unknown
 *  （由调用方记录兼容诊断并走旧路径，不猜为 started）。 */
export function parseRpcDisposition(response: RpcResponse): RpcDispositionOutcome {
	const value = (response?.data as Record<string, unknown> | undefined)?.disposition;
	if (value === undefined || value === null) return { kind: "missing" };
	if (typeof value === "string" && (value === "started" || value === "queued" || value === "handled")) {
		return { kind: "known", disposition: value };
	}
	return { kind: "unknown", value: typeof value === "string" ? value : JSON.stringify(value) };
}

export interface RpcExtensionUIRequest {
	type: "extension_ui_request";
	id: string;
	method: "select" | "confirm" | "input" | "editor" | "notify" | "setStatus" | "setWidget" | "setTitle" | "set_editor_text" | string;
	[key: string]: any;
}

export type RpcLeaderAnswer = string | boolean | undefined | { value: string } | { confirmed: boolean } | { cancelled: true };

export interface RpcLeaderQuestion {
	requestId: string;
	taskId?: string;
	workerId: string;
	method: RpcExtensionUIRequest["method"];
	title?: string;
	message?: string;
	placeholder?: string;
	options?: string[];
	timeoutMs: number;
	signal: AbortSignal;
}

export interface RpcTaskInput {
	taskId?: string;
	sessionKey?: string;
	prompt: string;
	/** 已落盘 user 但 assistant partial 丢失时，用该消息启动恢复 turn。 */
	recoveryPrompt?: string;
	/** 当前仅支持 user 已落盘后的受控 continuation；字段持久化到 WAL，便于后续策略演进。 */
	recoveryStrategy?: RpcRecoveryStrategy;
	/** v2 P4（§8.3-P4）：本任务授权（覆盖池级 permissionGrant；worker 按其指纹 spawn，不与其他权限复用）。
	 *  非法/空工具面 fail-closed 拒绝启动（不建档不 spawn）。 */
	permissionGrant?: Readonly<PermissionGrant>;
}

export type RpcRecoveryStrategy = "continue_if_user_persisted";
export type RpcRecoverySource = "caller" | "default" | "legacy_default";

export interface RpcWalRecoveryPolicy {
	version: 1;
	strategy: RpcRecoveryStrategy;
	prompt: string;
	source: RpcRecoverySource;
}

export interface RpcTaskResult {
	runtimeObservation?: import("./runtime-fingerprint.ts").RuntimeObservation;
	taskId: string;
	workerId: string;
	sessionId?: string;
	sessionFile?: string;
	state: "settled" | "error";
	recovered: boolean;
	lastAssistantText: string;
	entries: any[];
	leafId?: string | null;
	error?: string;
	/** 宿主真实布尔事实；旧载荷缺字段时省略。 */
	aborted?: boolean;
}

export interface RpcTaskHandle {
	taskId: string;
	workerId: string;
	sessionId?: string;
	sessionFile?: string;
	/** 当前 cycle 的完成 Promise；running steer 不替换它，idle prompt 会返回新的 completion。 */
	completion: Promise<RpcTaskResult>;
}

export interface RpcAdjustmentResult {
	taskId: string;
	workerId: string;
	delivery: "adjust-next-step" | "prompt-start";
	description: string;
	response: RpcResponse;
	completion: Promise<RpcTaskResult>;
}

export interface RpcReconcileResult {
	taskId: string;
	status: "completed" | "continued" | "replayed" | "manual" | "failed";
	sessionFile?: string;
	entryCount: number;
	leafId?: string | null;
	reason: string;
	recoverySource?: RpcRecoverySource;
}

export interface RpcPoolEvent {
	type: "worker_spawn" | "worker_exit" | "worker_idle" | "worker_recovering" | "rpc_event" | "ui_event" | "task_settled" | "task_error";
	at: number;
	workerId?: string;
	taskId?: string;
	event?: any;
	message?: string;
}

export interface RpcPoolOptions {
	cwd: string;
	maxWorkers?: number;
	idleTimeoutMs?: number;
	requestTimeoutMs?: number;
	uiTimeoutMs?: number;
	shutdownGraceMs?: number;
	model?: string;
	thinking?: string;
	tools?: string[];
	sessionDir?: string;
	walDir?: string;
	piCommand?: string;
	piArgs?: string[];
	extensionPaths?: string[];
	appendSystemPrompt?: string;
	disableInstalledExtensions?: boolean;
	disableSkills?: boolean;
	disablePromptTemplates?: boolean;
	disableThemes?: boolean;
	disableContextFiles?: boolean;
	env?: Record<string, string>;
	/** v2 P4（方案 §5.2 RPC 行/§8.3-P4）：池级冻结授权策略（worker --tools 严格名单与权限 env 派生基准；
	 *  缺省 legacy 无执法面——不注入 env、--tools 维持原样）。startTask 的 permissionGrant 覆盖本值。 */
	permissionGrant?: Readonly<PermissionGrant>;
	autoRecover?: boolean;
	askLeader?: (question: RpcLeaderQuestion) => Promise<RpcLeaderAnswer> | RpcLeaderAnswer;
	/** 无直接 UI 时可通知 Leader，再由 answerLeaderQuestion() 完成闭环。 */
	notifyLeader?: (question: Omit<RpcLeaderQuestion, "signal">) => void;
	onEvent?: (event: RpcPoolEvent) => void;
	/** B7（十月迭代 §5.4）：共享对话框 broker（跨 pool 汇聚/测试注入）；缺省内建单池实例。 */
	dialogBroker?: RpcDialogBroker;
	/** K6（amagi-pi v2，方案 §8.1-K6/§3.4-N9）：WAL 恢复对账门。recoverPendingFromWal 对每个
	 *  recoverable 任务先问询；返回 auto:false 的任务不自动重建/不自动 continuation（新契约任务
	 *  经内核 reconcile 命令标 needs-reconciliation，WAL/session 原样保留供对账）。策略由适配层
	 *  （rpc-pool-tool）注入——池内部不依赖内核/registry，worker 状态保持私有。 */
	recoveryGate?: (taskId: string) => Promise<RpcRecoveryDecision> | RpcRecoveryDecision;
	/** @deprecated 仅兼容旧池配置，普通工具组合不读取此开关。 */
	codemode?: { rpcEnabled: boolean };
}

/** K6：恢复对账门决策（auto=false 时 reason 必填语义——进恢复报告供 Leader 对账）。 */
export interface RpcRecoveryDecision {
	auto: boolean;
	reason?: string;
}

interface Deferred<T> {
	promise: Promise<T>;
	resolve: (value: T) => void;
	reject: (error: Error) => void;
	settled: boolean;
}

interface WalContext {
	taskId?: string;
	workerId?: string;
	sessionId?: string;
	sessionFile?: string;
	sessionKey?: string;
}

type RpcWalPhase = "prepared" | "sent" | "ack" | "one_way_sent" | "task_settled" | "task_error" | "worker_exit" | "reconciled";
const RPC_WAL_PHASES = new Set<RpcWalPhase>(["prepared", "sent", "ack", "one_way_sent", "task_settled", "task_error", "worker_exit", "reconciled"]);

interface RpcWalRecordBase {
	recordId: string;
	poolId: string;
	seq: number;
	at: number;
	phase: RpcWalPhase;
	commandId?: string;
	commandType?: string;
	taskId?: string;
	workerId?: string;
	sessionId?: string;
	sessionFile?: string;
	sessionKey?: string;
	payloadHash?: string;
	command?: RpcCommand;
	/** v2 actionable prepared 的恢复语义；旧 v1/早期 v2 可能缺失，reader 必须显式 legacy fallback。 */
	recovery?: RpcWalRecoveryPolicy;
	success?: boolean;
	error?: string;
	data?: Record<string, unknown>;
}

export interface RpcWalRecordV1 extends RpcWalRecordBase {
	version: 1;
}

export interface RpcWalRecordV2 extends RpcWalRecordBase {
	version: 2;
	generation: number;
}

export type RpcWalRecord = RpcWalRecordV1 | RpcWalRecordV2;

export interface RecoverableWalTask {
	taskId: string;
	sessionKey: string;
	sessionFile?: string;
	sessionId?: string;
	prompt: string;
	commandId: string;
	recoveryPrompt: string;
	recoveryStrategy: RpcRecoveryStrategy;
	recoverySource: RpcRecoverySource;
}

export interface RpcWalManualTask {
	taskId: string;
	status: "legacy_ambiguous";
	reason: string;
	poolIds: string[];
}

export interface RpcWalInspection {
	records: RpcWalRecord[];
	recoverable: RecoverableWalTask[];
	manual: RpcWalManualTask[];
	diagnostics: string[];
}

interface InternalTask {
	runtimeEvents?: import("./runtime-fingerprint.ts").RuntimeEventAccumulator;
	taskId: string;
	sessionKey: string;
	prompt: string;
	recoveryPrompt: string;
	recoveryStrategy: RpcRecoveryStrategy;
	recoverySource: RpcRecoverySource;
	state: RpcTaskState;
	worker?: RpcWorker;
	lastWorkerId?: string;
	sessionId?: string;
	sessionFile?: string;
	deferred: Deferred<RpcTaskResult>;
	recovered: boolean;
	recoveryCount: number;
	recoveryPromise?: Promise<RpcReconcileResult>;
	sawAgentStart: boolean;
	lastAssistantText: string;
	lastAssistantStopReason?: string;
	entries: any[];
	leafId?: string | null;
	settling: boolean;
	hostAborted?: boolean;
	cancelReason?: string;
	/** P4：本任务有效授权（per-task 覆盖池级；恢复重派同指纹）。 */
	permissionGrant?: Readonly<PermissionGrant>;
	/** P4：权限指纹（grant 序列化 digest；空串=legacy 无执法面）。 */
	permissionFingerprint: string;
	/** B5B：codemode 任务锚账户（grant 携带 codemode 时在场；指纹与 worker env 同源）。 */
	codemodeAccount?: string;
}

interface AcquireWaiter {
	taskId: string;
	sessionKey: string;
	/** P4：等待者所需权限指纹（同指纹 worker 才可交接；不匹配的退役 worker 不复用）。 */
	fingerprint: string;
	/** P4：等待者重建 worker 时携带的授权。 */
	grant?: Readonly<PermissionGrant>;
	/** B5B：等待者重建 worker 时携带的 codemode 账户（指纹同源）。 */
	codemodeAccount?: string;
	resolve: (worker: RpcWorker) => void;
	reject: (error: Error) => void;
}

// ── P4（§8.3-P4）：权限指纹与 worker 工具面派生 ──────────────────────────────

/** 任务有效授权（per-task 覆盖池级；非法/空工具面 fail-closed 抛错——真实授权恒含 amagi_resource）。 */
/** worker 启动面沿用任务契约校验；不再单独要求 CodeMode 授权。 */
export function resolveEffectiveGrant(
	taskGrant: Readonly<PermissionGrant> | undefined,
	poolGrant: Readonly<PermissionGrant> | undefined,
	codemodeRpcEnabled = false,
): Readonly<PermissionGrant> | undefined {
	const raw = taskGrant ?? poolGrant;
	if (raw === undefined) return undefined;
	const v = validatePermissionGrant(raw);
	if (!v.ok) throw new Error(`[rpc-pool] permissionGrant 未通过契约校验（fail-closed 拒绝启动 worker）：${v.error.message}`);
	if (v.value.tools.length === 0) throw new Error("[rpc-pool] permissionGrant.tools 为空（真实授权恒含 amagi_resource；空工具面=无操作能力，拒绝启动 worker）");
	assertRpcGrantCodemodeFree(v.value, codemodeRpcEnabled);
	return v.value;
}

/** @deprecated 旧签名兼容；CodeMode 工具组合无需单独 RPC 授权。 */
export function assertRpcGrantCodemodeFree(_grant: Readonly<PermissionGrant>, _rpcEnabled = false): void {
	// 兼容旧调用签名：codemode 已改为普通工具组合通道，不再使用独立 RPC 授权门。
}

/** 权限指纹（grant 规范序列化 digest；undefined=legacy 无执法面，空串）。
 *  B5B（§5.3「池指纹含grant摘要、装配版本、主体及账户」）：codemode grant 的指纹并入
 *  装配版本与任务锚账户（账户缺席标记 no-account——与任何真实账户指纹恒不等，防错配复用）。 */
export function permissionFingerprintOf(grant: Readonly<PermissionGrant> | undefined, codemodeAccount?: string): string {
	if (grant === undefined) return "";
	const digest = permissionGrantDigest(JSON.stringify(grant));
	if (grant.codemode === undefined) return digest;
	return `${digest}|codemode:v${CODEMODE_LEDGER_ASSEMBLY_VERSION}|${codemodeAccount ?? "no-account"}`;
}

/** B5B：任务锚账户派生（RPC 账户属于任务——taskId 锚；grant 缺 codemode 子对象时 undefined）。 */
export function codemodeAccountOfGrant(grant: Readonly<PermissionGrant> | undefined, taskId: string): string | undefined {
	if (grant?.codemode === undefined) return undefined;
	return codemodeAccountIdOfRawGrant(JSON.stringify(grant), `task|${taskId}`);
}

function validateRpcToolNames(tools: readonly string[]): void {
	for (const raw of tools) {
		const name = raw.trim();
		if (/^[+-]/.test(name)) throw new Error(`[rpc-pool tools] 拒绝修饰语法 "${name}"；请改用完整显式名单；权限交集不会展开宿主 defaultTools`);
		if (/[*?\[\]]/.test(name)) throw new Error(`[rpc-pool tools] 拒绝工具 pattern "${name}"；请列全确切工具名字`);
	}
}
/** 选项扫描结果：--tools/-t 索引与真正选项位置的正文分隔符索引（-1 = 无）。
 *  P3-01（diting）：分隔符只在选项位置命中——值选项（如 --system-prompt）消费的字面 `--` 是参数值
 *  不是分隔符；无上下文 indexOf 会把生成选项搬进值位/正文位（mode/tools 落位丢失）。 */
interface RpcArgScan { selector: number; bodySeparator: number; }
function rpcScanArgs(args: readonly string[]): RpcArgScan {
	const scan: RpcArgScan = { selector: -1, bodySeparator: -1 };
	const values = new Set(["--mode", "--provider", "--model", "--api-key", "--system-prompt", "--append-system-prompt", "--name", "-n", "--session", "--session-id", "--fork", "--session-dir", "--models", "--exclude-tools", "-xt", "--thinking", "--export", "--extension", "-e", "--skill", "--prompt-template", "--theme", "--use-theme", "--tui-mode"]);
	for (let i = 0; i < args.length; i++) {
		const arg = args[i];
		if (arg === "--") { scan.bodySeparator = i; break; }
		if (arg.startsWith("--tools=") || arg.startsWith("-t=")) throw new Error("[rpc-pool tools] 不支持 --tools= / -t= 拼写");
		if (arg === "--tools" || arg === "-t") {
			if (scan.selector >= 0) throw new Error("[rpc-pool tools] 重复工具选择器");
			if (args[i + 1] === undefined || args[i + 1] === "--") throw new Error("[rpc-pool tools] 工具选择器缺值");
			scan.selector = i++;
			validateRpcToolNames(args[i].split(",").map(t => t.trim()).filter(Boolean));
		} else if (values.has(arg)) i++;
		else if (arg === "-p" || arg === "--print" || arg === "--list-models") {
			const next = args[i + 1];
			if (next !== undefined && !next.startsWith("@") && (!next.startsWith("-") || next.startsWith("---"))) i++;
		} else if (arg.startsWith("--") && !arg.includes("=")) {
			const next = args[i + 1];
			if (next !== undefined && !next.startsWith("-") && !next.startsWith("@") && !/^(?:--no-|--continue$|--resume$|--verbose$|--offline$|--approve$|--help$|--version$)/.test(arg)) i++;
		}
	}
	return scan;
}
function rpcToolsSelector(args: readonly string[]): number {
	return rpcScanArgs(args).selector;
}

/** worker --tools = 池工具面 ∩ grant 工具面（两侧都必须允许；shell=deny 的 grant 不含 bash——严格名单不可调用）。
 *  池未设工具面时 grant 面即严格名单；交集为空（配置冲突）抛错拒启动，不取任一单侧名单。 */
function workerToolsOf(poolTools: readonly string[] | undefined, grant: Readonly<PermissionGrant>): string[] {
	const grantTools = [...grant.tools];
	if (poolTools === undefined || poolTools.length === 0) return grantTools;
	const pool = new Set(poolTools);
	const out = grantTools.filter((t) => pool.has(t));
	if (out.length === 0) {
		throw new Error(`[rpc-pool] 授权工具面（${grantTools.join(", ")}）与池工具面（${poolTools.join(", ")}）交集为空，拒绝启动 worker`);
	}
	return out;
}

/** 权限 env 注入（与 task-run appendPermissionGrantEnv 同三变量；字面量与 file-permission 权威常量防漂移断言）。 */
function appendWorkerPermissionEnv(env: Record<string, string>, rawGrantJson: string, cwd: string, digest: string): void {
	if (PERMISSION_GRANT_ENV !== "AMAGI_PERMISSION_GRANT" || PERMISSION_CWD_ENV !== "AMAGI_PERMISSION_CWD" || PERMISSION_DIGEST_ENV !== "AMAGI_PERMISSION_DIGEST") {
		throw new Error("[amagi] 权限 env 常量漂移：rpc-pool 注入字面量与 file-permission 权威常量不一致，拒绝注入");
	}
	env.AMAGI_PERMISSION_GRANT = rawGrantJson;
	env.AMAGI_PERMISSION_CWD = cwd;
	env.AMAGI_PERMISSION_DIGEST = digest;
}

function deferred<T>(): Deferred<T> {
	let resolveRaw!: (value: T) => void;
	let rejectRaw!: (error: Error) => void;
	const d: Deferred<T> = {
		promise: new Promise<T>((resolve, reject) => { resolveRaw = resolve; rejectRaw = reject; }),
		resolve: (value) => { if (!d.settled) { d.settled = true; resolveRaw(value); } },
		reject: (error) => { if (!d.settled) { d.settled = true; rejectRaw(error); } },
		settled: false,
	};
	return d;
}

function boundedInt(value: number | undefined, fallback: number, min: number, max: number): number {
	if (!Number.isFinite(value)) return fallback;
	return Math.max(min, Math.min(max, Math.floor(value!)));
}

function messageText(message: any): string {
	if (!message) return "";
	if (typeof message.content === "string") return message.content;
	if (!Array.isArray(message.content)) return "";
	return message.content.map((part: any) => typeof part?.text === "string" ? part.text : "").join("");
}

function lastAssistantText(entries: any[]): string {
	for (let i = entries.length - 1; i >= 0; i--) {
		const entry = entries[i];
		if (entry?.type === "message" && entry.message?.role === "assistant") return messageText(entry.message);
	}
	return "";
}

function safeTaskFileName(taskId: string): string {
	return taskId.replace(/[^A-Za-z0-9_.-]/g, "_").slice(0, 120) || "_pool";
}

function commandHash(command: RpcCommand, recovery?: RpcWalRecoveryPolicy): string {
	return crypto.createHash("sha256").update(JSON.stringify({ command, recovery: recovery || null })).digest("hex");
}

function isPositiveSafeInteger(value: unknown): value is number {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0;
}

function compareV2Order(a: Pick<RpcWalRecordV2, "generation" | "seq">, b: Pick<RpcWalRecordV2, "generation" | "seq">): number {
	return a.generation - b.generation || a.seq - b.seq;
}

function rpcWalError(code: string, message: string): Error {
	const error = new Error(`${code}: ${message}`);
	(error as NodeJS.ErrnoException).code = code;
	return error;
}

/** v1.5.216: RPC 任务未找到统一引导文案——实战高频误用是把 task({background:true}) 的
 * 后台/batch 句柄当 RPC 句柄调 adjust/reconcile/wait；给出正确去向，避免盲重试 RPC 路径。 */
function rpcTaskNotFoundError(taskId: string): Error {
	return new Error(`RPC task not found: ${taskId}；若句柄来自 task({background:true})（batch/后台派发），它不是 RPC 任务——等待自动通知或 query_task({session}) 查询`);
}

function fsyncDirectory(dir: string): void {
	const fd = fs.openSync(dir, "r");
	try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
}

function writeJsonAtomic(file: string, value: unknown): void {
	const dir = path.dirname(file);
	const temp = path.join(dir, `.${path.basename(file)}.${process.pid}.${crypto.randomUUID()}.tmp`);
	const fd = fs.openSync(temp, "wx", 0o600);
	try {
		fs.writeFileSync(fd, `${JSON.stringify(value, null, 2)}\n`, "utf8");
		fs.fsyncSync(fd);
	} finally { fs.closeSync(fd); }
	try {
		fs.renameSync(temp, file);
		fsyncDirectory(dir);
	} catch (error) {
		try { fs.unlinkSync(temp); } catch {}
		throw error;
	}
}

function processIsAlive(pid: number): boolean {
	try { process.kill(pid, 0); return true; }
	catch (error) { return (error as NodeJS.ErrnoException).code !== "ESRCH"; }
}

interface WalLockOwner {
	version: 1;
	controllerId: string;
	token: string;
	hostname: string;
	pid: number;
	startedAt: number;
}

class WalControllerLease {
	readonly lockFile: string;
	readonly claimFile: string;
	readonly owner: WalLockOwner;
	private released = false;

	constructor(private dir: string, controllerId: string) {
		fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
		const token = crypto.randomUUID();
		this.lockFile = path.join(dir, CONTROLLER_LOCK_FILE);
		this.claimFile = path.join(dir, `.controller-claim-${safeTaskFileName(controllerId)}-${token}.json`);
		this.owner = { version: 1, controllerId, token, hostname: os.hostname(), pid: process.pid, startedAt: Date.now() };
		const fd = fs.openSync(this.claimFile, "wx", 0o600);
		try {
			fs.writeFileSync(fd, `${JSON.stringify(this.owner)}\n`, "utf8");
			fs.fsyncSync(fd);
		} finally { fs.closeSync(fd); }
		try { this.acquire(); }
		catch (error) { try { fs.unlinkSync(this.claimFile); } catch {}; throw error; }
	}

	private readOwner(): WalLockOwner {
		let value: any;
		try { value = JSON.parse(fs.readFileSync(this.lockFile, "utf8")); }
		catch { throw rpcWalError("RPC_WAL_LOCK_UNKNOWN_OWNER", `无法解析 ${this.lockFile}`); }
		if (value?.version !== 1 || typeof value.controllerId !== "string" || typeof value.token !== "string" || typeof value.hostname !== "string" || !isPositiveSafeInteger(value.pid)) {
			throw rpcWalError("RPC_WAL_LOCK_UNKNOWN_OWNER", `lock owner schema 非法: ${this.lockFile}`);
		}
		return value;
	}

	private acquire(): void {
		for (let attempt = 0; attempt < 4; attempt++) {
			try {
				fs.linkSync(this.claimFile, this.lockFile);
				fsyncDirectory(this.dir);
				return;
			} catch (error) {
				if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
			}
			const current = this.readOwner();
			if (current.hostname !== os.hostname()) throw rpcWalError("RPC_WAL_LOCK_UNKNOWN_OWNER", `lock 属于其他 host ${current.hostname}`);
			if (processIsAlive(current.pid)) throw rpcWalError("RPC_WAL_LOCKED", `controller ${current.controllerId} pid=${current.pid} 持有 walDir`);
			const confirmed = this.readOwner();
			if (confirmed.token !== current.token) continue;
			try { fs.unlinkSync(this.lockFile); fsyncDirectory(this.dir); }
			catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
		}
		throw rpcWalError("RPC_WAL_LOCKED", "竞争 stale lock 超过重试上限");
	}

	release(): void {
		if (this.released) return;
		this.released = true;
		try {
			const current = this.readOwner();
			if (current.token === this.owner.token) { fs.unlinkSync(this.lockFile); fsyncDirectory(this.dir); }
		} catch (error) {
			if ((error as NodeJS.ErrnoException).code !== "ENOENT" && (error as NodeJS.ErrnoException).code !== "RPC_WAL_LOCK_UNKNOWN_OWNER") throw error;
		} finally { try { fs.unlinkSync(this.claimFile); } catch {} }
	}
}

function walFilesFingerprint(dir: string): string {
	if (!fs.existsSync(dir)) return "";
	return fs.readdirSync(dir).filter((name) => name.endsWith(".ndjson")).sort().map((name) => {
		const stat = fs.statSync(path.join(dir, name));
		return `${name}:${stat.size}:${stat.mtimeMs}`;
	}).join("|");
}

function assertWalBase(record: any, file: string): void {
	if (typeof record?.recordId !== "string" || !record.recordId || typeof record.poolId !== "string" || !record.poolId || !isPositiveSafeInteger(record.seq) || typeof record.at !== "number" || !Number.isFinite(record.at) || !RPC_WAL_PHASES.has(record.phase)) {
		throw rpcWalError("RPC_WAL_CORRUPT", `非法 WAL record: ${file}`);
	}
	if (record.recovery !== undefined && (record.recovery?.version !== 1 || record.recovery.strategy !== "continue_if_user_persisted" || typeof record.recovery.prompt !== "string" || !record.recovery.prompt.trim() || !["caller", "default", "legacy_default"].includes(record.recovery.source))) {
		throw rpcWalError("RPC_WAL_CORRUPT", `非法 recovery policy: ${file}`);
	}
}

function isActionable(record: RpcWalRecord): boolean {
	return record.phase === "prepared" && (record.commandType === "prompt" || record.commandType === "steer") && typeof record.commandId === "string" && record.commandId.length > 0 && typeof record.command?.message === "string";
}

function isTerminal(record: RpcWalRecord): boolean {
	return record.phase === "task_settled" || record.phase === "task_error";
}

function recoverableFrom(record: RpcWalRecord, context: RpcWalRecord, diagnostics: string[]): RecoverableWalTask {
	const recovery = record.recovery;
	const recoverySource: RpcRecoverySource = recovery?.source || "legacy_default";
	if (!recovery) diagnostics.push(`recovery_policy_defaulted:${record.taskId}:${record.version === 1 ? "v1" : "v2_missing"}`);
	return {
		taskId: record.taskId!,
		sessionKey: record.sessionKey || record.taskId!,
		sessionFile: context.sessionFile,
		sessionId: context.sessionId,
		prompt: String(record.command!.message),
		commandId: record.commandId!,
		recoveryPrompt: recovery?.prompt || DEFAULT_RECOVERY_PROMPT,
		recoveryStrategy: recovery?.strategy || "continue_if_user_persisted",
		recoverySource,
	};
}

function inspectWalDirectory(dir: string): RpcWalInspection {
	if (!fs.existsSync(dir)) return { records: [], recoverable: [], manual: [], diagnostics: [] };
	const diagnostics: string[] = [];
	const legacy: RpcWalRecordV1[] = [];
	const v2: RpcWalRecordV2[] = [];
	const generationPools = new Map<number, string>();
	const orderKeys = new Map<string, RpcWalRecordV2>();
	const legacyKeys = new Map<string, RpcWalRecordV1>();

	for (const name of fs.readdirSync(dir).filter((entry) => entry.endsWith(".ndjson")).sort()) {
		const file = path.join(dir, name);
		let raw: string;
		try { raw = fs.readFileSync(file, "utf8"); }
		catch (error) { throw rpcWalError("RPC_WAL_CORRUPT", `无法读取 ${file}: ${String(error)}`); }
		const lines = raw.split("\n");
		let previousV2: RpcWalRecordV2 | undefined;
		for (let index = 0; index < lines.length; index++) {
			const line = lines[index];
			if (!line.trim()) continue;
			let record: any;
			try { record = JSON.parse(line); }
			catch {
				if (index === lines.length - 1 && !raw.endsWith("\n")) { diagnostics.push(`ignored_tail_fragment:${name}`); break; }
				throw rpcWalError("RPC_WAL_CORRUPT", `非尾部坏 JSON: ${name}:${index + 1}`);
			}
			assertWalBase(record, file);
			if (record.version === 1) {
				const key = `${record.poolId}:${record.seq}`;
				const prior = legacyKeys.get(key);
				if (prior && JSON.stringify(prior) !== JSON.stringify(record)) throw rpcWalError("RPC_WAL_CORRUPT", `legacy seq 冲突 ${key}`);
				if (!prior) { legacyKeys.set(key, record); legacy.push(record); }
				continue;
			}
			if (record.version !== WAL_VERSION || !isPositiveSafeInteger(record.generation)) throw rpcWalError("RPC_WAL_CORRUPT", `未知 WAL version/generation: ${name}:${index + 1}`);
			const pool = generationPools.get(record.generation);
			if (pool && pool !== record.poolId) throw rpcWalError("RPC_WAL_CORRUPT", `generation ${record.generation} 出现多个 poolId`);
			generationPools.set(record.generation, record.poolId);
			if (previousV2 && previousV2.generation === record.generation && record.seq <= previousV2.seq) throw rpcWalError("RPC_WAL_CORRUPT", `文件内 seq 非递增: ${name}`);
			previousV2 = record;
			const key = `${record.generation}:${record.seq}`;
			const prior = orderKeys.get(key);
			if (prior) {
				if (prior.recordId !== record.recordId || JSON.stringify(prior) !== JSON.stringify(record)) throw rpcWalError("RPC_WAL_CORRUPT", `OrderKey 冲突 ${key}`);
				continue;
			}
			orderKeys.set(key, record); v2.push(record);
		}
	}

	legacy.sort((a, b) => a.poolId.localeCompare(b.poolId) || a.seq - b.seq);
	v2.sort(compareV2Order);
	const recoverable: RecoverableWalTask[] = [];
	const manual: RpcWalManualTask[] = [];
	const legacyByTask = new Map<string, RpcWalRecordV1[]>();
	const v2ByTask = new Map<string, RpcWalRecordV2[]>();
	for (const record of legacy) if (record.taskId && record.taskId !== "_pool") {
		const records = legacyByTask.get(record.taskId) || []; records.push(record); legacyByTask.set(record.taskId, records);
	}
	for (const record of v2) if (record.taskId && record.taskId !== "_pool") {
		const records = v2ByTask.get(record.taskId) || []; records.push(record); v2ByTask.set(record.taskId, records);
	}
	const taskIds = new Set([...legacyByTask.keys(), ...v2ByTask.keys()]);

	for (const taskId of taskIds) {
		const taskV2 = v2ByTask.get(taskId) || [];
		const latestAction = taskV2.filter(isActionable).at(-1);
		const latestTerminal = taskV2.filter(isTerminal).at(-1);
		if (latestAction || latestTerminal) {
			if (latestAction && (!latestTerminal || compareV2Order(latestAction, latestTerminal) > 0)) {
				const cycle = taskV2.filter((record) => (!latestTerminal || compareV2Order(record, latestTerminal) > 0) && (!!record.sessionFile || !!record.sessionId));
				recoverable.push(recoverableFrom(latestAction, cycle.at(-1) || latestAction, diagnostics));
			}
			continue;
		}

		const byPool = new Map<string, RpcWalRecordV1[]>();
		for (const record of legacyByTask.get(taskId) || []) {
			const records = byPool.get(record.poolId) || []; records.push(record); byPool.set(record.poolId, records);
		}
		const localOpen: Array<{ action: RpcWalRecordV1; context: RpcWalRecordV1 }> = [];
		for (const records of byPool.values()) {
			const action = records.filter(isActionable).at(-1);
			const terminal = records.filter(isTerminal).at(-1);
			if (action && (!terminal || action.seq > terminal.seq)) {
				const context = records.filter((record) => (!terminal || record.seq > terminal.seq) && (!!record.sessionFile || !!record.sessionId)).at(-1) || action;
				localOpen.push({ action, context });
			}
		}
		if (byPool.size === 1 && localOpen.length === 1) recoverable.push(recoverableFrom(localOpen[0].action, localOpen[0].context, diagnostics));
		else if (byPool.size > 1 && localOpen.length) manual.push({ taskId, status: "legacy_ambiguous", poolIds: [...byPool.keys()].sort(), reason: "RPC_WAL_LEGACY_AMBIGUOUS: 多个 v1 pool 存在开放 prepared，禁止猜测跨 pool 顺序" });
	}

	return { records: [...legacy, ...v2], recoverable, manual, diagnostics };
}

function buildWorkerEnv(model: string | undefined, overrides: Record<string, string> | undefined): Record<string, string> {
	const env: Record<string, string> = {};
	// v1.5.195: 代理变量与 task-tool buildMinimalEnv 同步透传（子进程网络条件与主进程一致，
	// 否则 openai-codex 等被墙 provider 在 worker 中 fetch failed）
	for (const key of ["PATH", "HOME", "USER", "SHELL", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR", "TERM", "TZ",
		"HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "all_proxy", "no_proxy", "AMAGI_AUTORETRY_OFF"]) {
		if (process.env[key] !== undefined) env[key] = process.env[key]!;
	}
	for (const key of Object.keys(process.env)) if (key.startsWith("PI_")) env[key] = process.env[key]!;
	const provider = model?.split("/")[0]?.toLowerCase();
	const providerKeys: Record<string, string[]> = {
		openrouter: ["OPENROUTER_API_KEY"], openai: ["OPENAI_API_KEY"], anthropic: ["ANTHROPIC_API_KEY"],
		google: ["GOOGLE_API_KEY", "GEMINI_API_KEY"], zhipuai: ["ZHIPU_API_KEY"], deepseek: ["DEEPSEEK_API_KEY"],
		moonshot: ["MOONSHOT_API_KEY", "KIMI_API_KEY"], minimax: ["MINIMAX_API_KEY"], yescode: ["YES_API_KEY"],
	};
	for (const key of providerKeys[provider || ""] || []) if (process.env[key] !== undefined) env[key] = process.env[key]!;
	env.AMAGI_SUBAGENT = "1";
	env.AMAGI_RPC_WORKER = "1";
	if (model) env.AMAGI_DISPATCH_MODEL = model;
	if (process.env.AMAGI_CODEX_FRONTLINE !== undefined) env.AMAGI_CODEX_FRONTLINE = process.env.AMAGI_CODEX_FRONTLINE;
	const merged = { ...env, ...(overrides || {}) };
	if (RUNTIME_FINGERPRINT.hostVersion && RUNTIME_FINGERPRINT.digest) merged.AMAGI_LEADER_RUNTIME_DIGEST = RUNTIME_FINGERPRINT.digest;
	else delete merged.AMAGI_LEADER_RUNTIME_DIGEST;
	return merged;
}

class RpcWalStore {
	readonly poolId: string;
	readonly dir: string;
	readonly file: string;
	readonly generation: number;
	readonly diagnostics: string[];
	private seq = 0;
	private lease: WalControllerLease;

	constructor(dir: string, poolId: string) {
		this.poolId = poolId;
		this.dir = path.resolve(dir);
		fs.mkdirSync(this.dir, { recursive: true, mode: 0o700 });
		this.lease = new WalControllerLease(this.dir, poolId);
		try {
			const before = walFilesFingerprint(this.dir);
			const inspection = inspectWalDirectory(this.dir);
			this.diagnostics = [...inspection.diagnostics];
			const maxWalGeneration = inspection.records.reduce((max, record) => record.version === WAL_VERSION ? Math.max(max, record.generation) : max, 0);
			const generationFile = path.join(this.dir, GENERATION_FILE);
			let lastAllocated = 0;
			if (fs.existsSync(generationFile)) {
				let meta: any;
				try { meta = JSON.parse(fs.readFileSync(generationFile, "utf8")); }
				catch { throw rpcWalError("RPC_WAL_CORRUPT", `generation.json 无法解析: ${generationFile}`); }
				if (meta?.version !== GENERATION_META_VERSION || !isPositiveSafeInteger(meta.lastAllocatedGeneration)) throw rpcWalError("RPC_WAL_CORRUPT", "generation.json schema 非法");
				lastAllocated = meta.lastAllocatedGeneration;
				if (lastAllocated < maxWalGeneration) this.diagnostics.push(`generation_metadata_behind:${lastAllocated}<${maxWalGeneration}`);
			} else if (maxWalGeneration > 0 && inspection.diagnostics.some((item) => item.startsWith("ignored_tail_fragment:"))) {
				throw rpcWalError("RPC_WAL_CORRUPT", "generation.json 缺失且 v2 WAL 含尾部残帧，禁止猜测 generation");
			}
			const base = Math.max(lastAllocated, maxWalGeneration);
			if (!Number.isSafeInteger(base + 1) || base + 1 <= 0) throw rpcWalError("RPC_WAL_GENERATION_OVERFLOW", `无法从 ${base} 分配下一 generation`);
			this.generation = base + 1;
			writeJsonAtomic(generationFile, { version: GENERATION_META_VERSION, lastAllocatedGeneration: this.generation, lastControllerId: poolId, updatedAt: Date.now() });
			const after = walFilesFingerprint(this.dir);
			if (before !== after) throw rpcWalError("RPC_WAL_LEGACY_WRITER_ACTIVE", "generation 分配期间 WAL 文件发生变化；请先停止全部 v1 writer");
			this.file = path.join(this.dir, `wal-g${String(this.generation).padStart(8, "0")}-${safeTaskFileName(poolId)}-s00000001.ndjson`);
		} catch (error) {
			this.lease.release();
			throw error;
		}
	}

	append(input: Omit<RpcWalRecordV2, "version" | "generation" | "recordId" | "poolId" | "seq" | "at">): RpcWalRecordV2 {
		if (!Number.isSafeInteger(this.seq + 1)) throw rpcWalError("RPC_WAL_GENERATION_OVERFLOW", "WAL seq overflow");
		const record: RpcWalRecordV2 = {
			version: WAL_VERSION,
			generation: this.generation,
			recordId: crypto.randomUUID(),
			poolId: this.poolId,
			seq: ++this.seq,
			at: Date.now(),
			...input,
		};
		const line = `${JSON.stringify(record)}\n`;
		if (Buffer.byteLength(line, "utf8") > MAX_WAL_COMMAND_BYTES) throw new Error(`RPC WAL record 超过 ${MAX_WAL_COMMAND_BYTES} bytes`);
		const fd = fs.openSync(this.file, "a", 0o600);
		try {
			fs.writeFileSync(fd, line, "utf8");
			fs.fsyncSync(fd);
		} finally { fs.closeSync(fd); }
		return record;
	}

	prepare(command: RpcCommand, context: WalContext, recovery?: RpcWalRecoveryPolicy): RpcWalRecord {
		const actionableRecovery = (command.type === "prompt" || command.type === "steer") ? recovery : undefined;
		return this.append({
			phase: "prepared",
			commandId: command.id,
			commandType: command.type,
			payloadHash: commandHash(command, actionableRecovery),
			command,
			...(actionableRecovery ? { recovery: actionableRecovery } : {}),
			...context,
		});
	}

	close(): void { this.lease.release(); }

	static inspect(dir: string): RpcWalInspection { return inspectWalDirectory(path.resolve(dir)); }
	static readAll(dir: string): RpcWalRecord[] { return RpcWalStore.inspect(dir).records; }
	static recoverableTasks(dir: string): RecoverableWalTask[] { return RpcWalStore.inspect(dir).recoverable; }
}

class RpcWorker {
	readonly id = crypto.randomUUID();
	readonly child: ChildProcessWithoutNullStreams;
	/** P4：本 worker 启动时携带的授权（spawn 后不可变——不热改；策略变化走退役重建）。 */
	readonly permissionGrant: Readonly<PermissionGrant> | undefined;
	/** P4：权限指纹（permissionFingerprintOf(permissionGrant)；复用前校验一致）。 */
	readonly permissionFingerprint: string;
	state: WorkerState = "starting";
	sessionKey?: string;
	sessionId?: string;
	sessionFile?: string;
	currentTask?: InternalTask;
	idleTimer?: ReturnType<typeof setTimeout>;
	intentionalStop = false;
	private decoder = new StringDecoder("utf8");
	private buffer = "";
	private requestSeq = 0;
	private pending = new Map<string, Deferred<RpcResponse> & { acknowledged: Deferred<void> }>();
	/** 只拦已收到 response、尚未落 ack 的续发；未响应请求不能阻塞 UI 应答/abort。 */
	private receivedResponseAcks = new Set<Promise<void>>();
	private spawned = deferred<void>();
	private closed = deferred<{ code: number | null; signal: NodeJS.Signals | null }>();

	constructor(private pool: RpcPool, resumeSessionFile?: string, grant?: Readonly<PermissionGrant>, codemodeAccount?: string) {
		this.permissionGrant = grant;
		this.permissionFingerprint = permissionFingerprintOf(grant, codemodeAccount);
		const { command, args, env } = pool.workerInvocation(resumeSessionFile, grant, codemodeAccount);
		this.child = spawn(command, args, { cwd: pool.options.cwd, shell: false, stdio: ["pipe", "pipe", "pipe"], env });
		this.child.once("spawn", () => this.spawned.resolve());
		this.child.once("error", (error) => {
			this.spawned.reject(error);
			for (const d of this.pending.values()) d.reject(error);
			this.pending.clear();
		});
		this.child.stdout.on("data", (chunk: Buffer) => this.onStdout(chunk));
		this.child.stderr.on("data", (chunk: Buffer) => pool.emit({ type: "rpc_event", workerId: this.id, taskId: this.currentTask?.taskId, event: { type: "stderr", text: chunk.toString("utf8").slice(-4096) } }));
		// K6：worker 快速退出/被杀后向 stdin 写入会触发 socket 'error' 事件（EPIPE）——写失败已由
		// write 回调→request 异常路径上报，此处必须挂接 listener，否则成为 uncaughtException。
		this.child.stdin.on("error", () => { /* 写失败走 request 异常路径，不重复上报 */ });
		this.child.once("close", (code, signal) => {
			this.state = "dead";
			const error = new Error(`RPC worker ${this.id.slice(0, 8)} exited code=${code} signal=${signal || "none"}`);
			for (const d of this.pending.values()) d.reject(error);
			this.pending.clear();
			this.closed.resolve({ code, signal });
			pool.onWorkerClose(this, code, signal);
		});
	}

	async ready(): Promise<void> {
		await this.spawned.promise;
		const response = await this.request({ type: "get_state" }, { taskId: "_pool" });
		this.applyState(response.data);
		this.state = "idle";
	}

	private applyState(state: any): void {
		if (!state || typeof state !== "object") return;
		if (typeof state.sessionId === "string") this.sessionId = state.sessionId;
		if (typeof state.sessionFile === "string") this.sessionFile = state.sessionFile;
	}

	private onStdout(chunk: Buffer): void {
		this.buffer += this.decoder.write(chunk);
		if (Buffer.byteLength(this.buffer, "utf8") > MAX_RPC_LINE_BYTES * 2) {
			this.pool.emit({ type: "rpc_event", workerId: this.id, taskId: this.currentTask?.taskId, event: { type: "protocol_error", error: "RPC stdout buffer exceeded" } });
			this.child.kill("SIGKILL");
			return;
		}
		while (true) {
			const newline = this.buffer.indexOf("\n");
			if (newline < 0) break;
			let line = this.buffer.slice(0, newline);
			this.buffer = this.buffer.slice(newline + 1);
			if (line.endsWith("\r")) line = line.slice(0, -1);
			if (!line) continue;
			if (Buffer.byteLength(line, "utf8") > MAX_RPC_LINE_BYTES) {
				this.pool.emit({ type: "rpc_event", workerId: this.id, taskId: this.currentTask?.taskId, event: { type: "protocol_error", error: "RPC line exceeded" } });
				continue;
			}
			let value: any;
			try { value = JSON.parse(line); }
			catch {
				this.pool.emit({ type: "rpc_event", workerId: this.id, taskId: this.currentTask?.taskId, event: { type: "protocol_error", line: line.slice(0, 200) } });
				continue;
			}
			if (value?.type === "response" && typeof value.id === "string") {
				const d = this.pending.get(value.id);
				if (d) {
					this.pending.delete(value.id);
					// 同一 stdout 批次的后续事件可同步发起新命令；先挂 ack 闸，再交付响应。
					this.receivedResponseAcks.add(d.acknowledged.promise);
					d.resolve(value);
				}
			}
			void this.pool.onWorkerEvent(this, value);
		}
	}

	private context(taskId?: string): WalContext {
		return {
			taskId: taskId || this.currentTask?.taskId || "_pool",
			workerId: this.id,
			sessionId: this.sessionId,
			sessionFile: this.sessionFile,
			sessionKey: this.currentTask?.sessionKey || this.sessionKey,
		};
	}

	private recoveryPolicy(taskId?: string): RpcWalRecoveryPolicy | undefined {
		const task = this.currentTask;
		if (!task || taskId === "_pool") return undefined;
		return {
			version: 1,
			strategy: task.recoveryStrategy,
			prompt: task.recoveryPrompt,
			source: task.recoverySource,
		};
	}

	private async write(command: RpcCommand): Promise<void> {
		if (this.state === "dead" || this.state === "stopping") throw new Error(`RPC worker ${this.id.slice(0, 8)} unavailable`);
		const line = `${JSON.stringify(command)}\n`;
		if (Buffer.byteLength(line, "utf8") > MAX_RPC_LINE_BYTES) throw new Error(`RPC command exceeds ${MAX_RPC_LINE_BYTES} bytes`);
		await new Promise<void>((resolve, reject) => this.child.stdin.write(line, (error) => error ? reject(error) : resolve()));
	}

	async request(command: RpcCommand, context: { taskId?: string; timeoutMs?: number } = {}): Promise<RpcResponse> {
		// response 已到达但 request 的 await 续体尚未写 ack 时，后续 prepared 必须等待。
		// 不锁住尚无 response 的命令：prompt 可能正等待 extension_ui_response 才能响应。
		while (this.receivedResponseAcks.size) await Promise.all(this.receivedResponseAcks);
		const id = command.id || `${this.id}:${++this.requestSeq}`;
		const payload = { ...command, id };
		const walContext = this.context(context.taskId);
		this.pool.wal.prepare(payload, walContext, this.recoveryPolicy(context.taskId)); // WAL-before-send hard invariant + recovery contract
		const d = Object.assign(deferred<RpcResponse>(), { acknowledged: deferred<void>() });
		this.pending.set(id, d);
		const timeoutMs = context.timeoutMs ?? this.pool.options.requestTimeoutMs;
		let timer: ReturnType<typeof setTimeout> | undefined;
		try {
			try {
				await this.write(payload);
				this.pool.wal.append({ phase: "sent", commandId: id, commandType: payload.type, ...walContext });
			} catch (error) {
				// K6：write 失败发生在任何等待方挂接（Promise.race）之前——孤儿 rejection 须就地吞掉，
				// 不留 unhandledRejection（worker 快速退出/被杀时的高频路径）。
				d.promise.catch(() => { /* 无在途等待方 */ });
				d.reject(error instanceof Error ? error : new Error(String(error)));
				throw error;
			}
			const response = await Promise.race([
				d.promise,
				new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error(`RPC ${payload.type} timeout ${timeoutMs}ms`)), timeoutMs); }),
			]);
			this.pool.wal.append({ phase: "ack", commandId: id, commandType: payload.type, success: response.success, error: response.error, ...this.context(context.taskId) });
			if (!response.success) throw new Error(response.error || `RPC ${payload.type} failed`);
			if (payload.type === "get_state") this.applyState(response.data);
			return response;
		} finally {
			if (timer) clearTimeout(timer);
			this.pending.delete(id);
			this.receivedResponseAcks.delete(d.acknowledged.promise);
			d.acknowledged.resolve(); // 错误/超时/write 失败同样放闸，不留下永久等待者。
		}
	}

	async sendOneWay(command: RpcCommand, taskId?: string): Promise<void> {
		while (this.receivedResponseAcks.size) await Promise.all(this.receivedResponseAcks);
		const walContext = this.context(taskId);
		this.pool.wal.prepare(command, walContext, this.recoveryPolicy(taskId));
		await this.write(command);
		this.pool.wal.append({ phase: "one_way_sent", commandId: command.id, commandType: command.type, ...walContext });
	}

	async refreshState(taskId?: string): Promise<any> {
		const response = await this.request({ type: "get_state" }, { taskId });
		return response.data;
	}

	async stop(graceMs: number): Promise<void> {
		if (this.state === "dead") return;
		this.intentionalStop = true;
		this.state = "stopping";
		if (this.idleTimer) clearTimeout(this.idleTimer);
		try { this.child.stdin.end(); } catch {}
		const graceful = await Promise.race([this.closed.promise.then(() => true), new Promise<boolean>((resolve) => setTimeout(() => resolve(false), graceMs))]);
		if (!graceful) {
			try { this.child.kill("SIGTERM"); } catch {}
			const terminated = await Promise.race([this.closed.promise.then(() => true), new Promise<boolean>((resolve) => setTimeout(() => resolve(false), graceMs))]);
			if (!terminated) try { this.child.kill("SIGKILL"); } catch {}
			await this.closed.promise.catch(() => undefined);
		}
	}
}

export class RpcPool {
	readonly id = crypto.randomUUID();
	readonly options: Required<Pick<RpcPoolOptions, "cwd" | "maxWorkers" | "idleTimeoutMs" | "requestTimeoutMs" | "uiTimeoutMs" | "shutdownGraceMs" | "thinking" | "sessionDir" | "walDir" | "piCommand" | "autoRecover">> & RpcPoolOptions;
	readonly wal: RpcWalStore;
	/** B7（§5.4）：对话框 pending 表（WebUI/rpc_task answer 的共享应答面；askLeader 缺席时启用）。 */
	readonly dialogs: RpcDialogBroker;
	private workers = new Map<string, RpcWorker>();
	private tasks = new Map<string, InternalTask>();
	private waiters: AcquireWaiter[] = [];
	private listeners = new Set<(event: RpcPoolEvent) => void>();
	private uiControllers = new Map<string, { workerId: string; controller: AbortController; cycle?: Deferred<RpcTaskResult> }>();
	private shuttingDown = false;
	private creating = 0;

	constructor(options: RpcPoolOptions) {
		const sessionDir = path.resolve(options.sessionDir || process.env.AMAGI_RPC_SESSION_DIR || path.join(amagiDataDir(), "rpc-sessions"));
		const walDir = path.resolve(options.walDir || process.env.AMAGI_RPC_WAL_DIR || path.join(amagiDataDir(), "rpc-wal"));
		this.options = {
			...options,
			cwd: path.resolve(options.cwd),
			maxWorkers: boundedInt(options.maxWorkers, DEFAULT_POOL_SIZE, 1, MAX_POOL_SIZE),
			idleTimeoutMs: boundedInt(options.idleTimeoutMs, DEFAULT_IDLE_TIMEOUT_MS, 10, 24 * 60 * 60_000),
			requestTimeoutMs: boundedInt(options.requestTimeoutMs, DEFAULT_REQUEST_TIMEOUT_MS, 10, 30 * 60_000),
			uiTimeoutMs: boundedInt(options.uiTimeoutMs, DEFAULT_UI_TIMEOUT_MS, 10, 30 * 60_000),
			shutdownGraceMs: boundedInt(options.shutdownGraceMs, DEFAULT_SHUTDOWN_GRACE_MS, 10, 60_000),
			thinking: options.thinking || "minimal",
			sessionDir,
			walDir,
			piCommand: options.piCommand || "pi",
			autoRecover: options.autoRecover !== false,
		};
		fs.mkdirSync(sessionDir, { recursive: true, mode: 0o700 });
		this.wal = new RpcWalStore(walDir, this.id);
		this.dialogs = options.dialogBroker ?? new RpcDialogBroker();
		if (options.onEvent) this.listeners.add(options.onEvent);
	}

	workerInvocation(resumeSessionFile?: string, grant?: Readonly<PermissionGrant>, codemodeAccount?: string): { command: string; args: string[]; env: Record<string, string> } {
		const prefix = [...(this.options.piArgs || [])];
		const scan = rpcScanArgs(prefix);
		const selector = scan.selector;
		const prefixTools = selector < 0 ? undefined : prefix[selector + 1].split(",").map(t => t.trim()).filter(Boolean);
		if (this.options.tools !== undefined) validateRpcToolNames(this.options.tools);
		if (grant !== undefined) validateRpcToolNames(grant.tools);
		if (prefixTools !== undefined && this.options.tools?.length) throw new Error("[rpc-pool tools] 重复工具选择器（piArgs 与 pool.tools）");
		const poolTools = this.options.tools?.length ? this.options.tools : prefixTools;
		if (selector >= 0) prefix.splice(selector, 2);
		const args = [...prefix, "--mode", "rpc"];
		if (resumeSessionFile) args.push("--session", resumeSessionFile);
		else args.push("--session-dir", this.options.sessionDir);
		if (this.options.model) args.push("--model", this.options.model);
		if (this.options.thinking) args.push("--thinking", this.options.thinking);
		// P4：授权任务的 --tools 严格名单（grant.tools ∩ 池工具面；无授权维持池配置不变）。
		if (grant !== undefined) {
			args.push("--tools", [...new Set([...workerToolsOf(poolTools, grant), "codemode", "toolcall_continue"])].join(","));
		} else if (poolTools !== undefined) {
			args.push("--tools", [...new Set([...poolTools, "toolcall_continue"])].join(","));
		}
		if (this.options.appendSystemPrompt) args.push("--append-system-prompt", this.options.appendSystemPrompt);
		if (this.options.disableInstalledExtensions) args.push("--no-extensions");
		if (this.options.disableSkills !== false) args.push("--no-skills");
		if (this.options.disablePromptTemplates !== false) args.push("--no-prompt-templates");
		if (this.options.disableThemes !== false) args.push("--no-themes");
		if (this.options.disableContextFiles !== false) args.push("--no-context-files");
		for (const extension of this.options.extensionPaths || []) args.push("--extension", extension);
		const env = buildWorkerEnv(this.options.model, this.options.env);
		// evolve 2.21.11 复审 F-R4-2：worker 自身直接子进程（MCP stdio 等）与 JSON 子进程同源——
		// 注入项目受信 shell.pathPrepend（只读 <cwd>/amagi.json；幂等前置，与 task-run 同一 reader）。
		const pathPrepend = readProjectShellPathPrepend(this.options.cwd).dirs;
		if (pathPrepend.length > 0) env.PATH = prependPathEntries(env.PATH ?? process.env.PATH, pathPrepend);
		appendCompactionEnv(env, this.options.cwd);
		appendMcpCredentialEnv(env, this.options.cwd, env.AMAGI_AGENT, grant ? normalizeMcpPermission(grant.mcp) : undefined);
		// P4：权限 env 注入（子端 file-permission bootstrap 校验 digest 一致才激活；失败 exit 1）。
		if (grant !== undefined) {
			const raw = JSON.stringify(grant);
			appendWorkerPermissionEnv(env, raw, this.options.cwd, permissionGrantDigest(raw));
			// B5B：codemode 任务锚账户交付（子端适配器经 env 账户打开持久账本——grant+账户+装配
			//  三重身份隔离）。账户缺席时不交付（子端 fail-closed 拒绝 codemode）——绝不猜一个
			// 锚账户（错锚=额度串账，比缺失更糟）。
			if (grant.codemode !== undefined && codemodeAccount !== undefined) env.AMAGI_CODEMODE_ACCOUNT = codemodeAccount;
		}
		// piArgs 中的 -- 正文必须保持正文；生成的选项不能落到它后面。
		// P3-01（diting）：分隔符取选项扫描位置（值选项消费的字面 `--` 是参数值不是分隔符，
		// 无上下文 indexOf 会把 --mode 搬进值位）；--tools 选择器已 splice 时正文索引同步左移 2。
		const rawBody = scan.bodySeparator;
		const body = rawBody < 0 ? -1 : selector >= 0 && rawBody > selector ? rawBody - 2 : rawBody;
		if (body >= 0) {
			const positional = args.splice(body, prefix.length - body);
			args.push(...positional);
		}
		return { command: this.options.piCommand, args, env };
	}

	emit(event: Omit<RpcPoolEvent, "at">): void {
		const full = { at: Date.now(), ...event } as RpcPoolEvent;
		for (const listener of this.listeners) {
			try { listener(full); } catch {}
		}
	}

	subscribe(listener: (event: RpcPoolEvent) => void): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	private async spawnWorker(resumeSessionFile?: string, grant?: Readonly<PermissionGrant>, codemodeAccount?: string): Promise<RpcWorker> {
		if (this.shuttingDown) throw new Error("RPC pool is shutting down");
		this.creating++;
		const worker = new RpcWorker(this, resumeSessionFile, grant, codemodeAccount);
		this.workers.set(worker.id, worker);
		this.emit({ type: "worker_spawn", workerId: worker.id, event: { resumeSessionFile, permissionFingerprint: worker.permissionFingerprint } });
		try {
			await worker.ready();
			return worker;
		} catch (error) {
			this.workers.delete(worker.id);
			throw error;
		} finally { this.creating--; }
	}

	private clearIdle(worker: RpcWorker): void {
		if (worker.idleTimer) { clearTimeout(worker.idleTimer); worker.idleTimer = undefined; }
	}

	private reserve(worker: RpcWorker): RpcWorker {
		this.clearIdle(worker);
		worker.state = "reserved";
		return worker;
	}

	private async acquire(taskId: string, sessionKey: string, fingerprint: string, grant?: Readonly<PermissionGrant>): Promise<RpcWorker> {
		if (this.shuttingDown) throw new Error("RPC pool is shutting down");
		// P4（§5.2 RPC 行）：不同权限指纹不复用进程——指纹不符的闲置 worker 即刻退役销毁（需求侧重建于本指纹）；
		// 运行中 worker 不热改（完成当前任务后经 handoffOrIdle 按需退役）。
		for (const worker of [...this.workers.values()]) {
			if (worker.state === "idle" && worker.permissionFingerprint !== fingerprint) {
				this.workers.delete(worker.id);
				void worker.stop(this.options.shutdownGraceMs).catch(() => { /* 退役失败交 idle 超时/退出链 */ });
			}
		}
		const matching = [...this.workers.values()].find((worker) => worker.state === "idle" && worker.permissionFingerprint === fingerprint && worker.sessionKey === sessionKey);
		if (matching) return this.reserve(matching);
		const idle = [...this.workers.values()].find((worker) => worker.state === "idle" && worker.permissionFingerprint === fingerprint);
		if (idle) return this.reserve(idle);
		if (this.workers.size < this.options.maxWorkers) return this.reserve(await this.spawnWorker(undefined, grant, this.tasks.get(taskId)?.codemodeAccount));
		return new Promise<RpcWorker>((resolve, reject) => this.waiters.push({ taskId, sessionKey, fingerprint, grant, codemodeAccount: this.tasks.get(taskId)?.codemodeAccount, resolve, reject }));
	}

	private handoffOrIdle(worker: RpcWorker): void {
		worker.currentTask = undefined;
		if (this.shuttingDown || worker.state === "dead") return;
		const waiterIdx = this.waiters.findIndex((w) => w.fingerprint === worker.permissionFingerprint);
		if (waiterIdx >= 0) {
			const [waiter] = this.waiters.splice(waiterIdx, 1);
			worker.state = "reserved";
			waiter.resolve(worker);
			return;
		}
		// P4：存在等待者但无同指纹匹配——本 worker 属旧策略，退役销毁并为等待者重建新 worker
		//（不同权限/资源集不复用进程；本 worker 不携带新任务权限）。
		if (this.waiters.length > 0) {
			this.workers.delete(worker.id);
			void worker.stop(this.options.shutdownGraceMs).catch(() => { /* 同上 */ });
			this.fillWaiters();
			return;
		}
		worker.state = "idle";
		this.emit({ type: "worker_idle", workerId: worker.id });
		worker.idleTimer = setTimeout(() => { void this.retireWorker(worker); }, this.options.idleTimeoutMs);
		worker.idleTimer.unref?.();
	}

	private async retireWorker(worker: RpcWorker): Promise<void> {
		if (worker.state !== "idle") return;
		this.workers.delete(worker.id);
		await worker.stop(this.options.shutdownGraceMs);
	}

	private async prepareWorker(worker: RpcWorker, task: InternalTask): Promise<void> {
		this.clearIdle(worker);
		if (worker.sessionKey && worker.sessionKey !== task.sessionKey) {
			for (const oldTask of this.tasks.values()) if (oldTask.worker === worker && oldTask !== task) oldTask.worker = undefined;
			await worker.request({ type: "new_session" }, { taskId: task.taskId });
			await worker.refreshState(task.taskId);
		}
		worker.sessionKey = task.sessionKey;
		worker.currentTask = task;
		task.worker = worker;
		task.lastWorkerId = worker.id;
		task.sessionId = worker.sessionId;
		task.sessionFile = worker.sessionFile;
	}

	private makeTask(input: RpcTaskInput, restoredSource?: RpcRecoverySource): InternalTask {
		const taskId = input.taskId || crypto.randomUUID();
		if (this.tasks.has(taskId)) throw new Error(`RPC taskId already exists: ${taskId}`);
		if (input.recoveryStrategy && input.recoveryStrategy !== "continue_if_user_persisted") throw new Error(`Unsupported RPC recoveryStrategy: ${input.recoveryStrategy}`);
		// P4：授权解析先于建档（非法/空工具面 fail-closed 抛错——任务不建档、不 spawn）。
		// 原任务契约校验；旧 codemode.rpc 开关不参与准入。
		const grant = resolveEffectiveGrant(input.permissionGrant, this.options.permissionGrant, this.options.codemode?.rpcEnabled === true);
		this.workerInvocation(undefined, grant); // 完整参数面校验先于建档、acquire/spawn。
		const callerRecoveryPrompt = input.recoveryPrompt?.trim() ? input.recoveryPrompt : undefined;
		const task: InternalTask = {
			taskId,
			sessionKey: input.sessionKey || taskId,
			prompt: input.prompt,
			recoveryPrompt: callerRecoveryPrompt || DEFAULT_RECOVERY_PROMPT,
			recoveryStrategy: input.recoveryStrategy || "continue_if_user_persisted",
			recoverySource: restoredSource || (callerRecoveryPrompt ? "caller" : "default"),
			state: "starting",
			deferred: deferred<RpcTaskResult>(),
			recovered: false,
			recoveryCount: 0,
			sawAgentStart: false,
			lastAssistantText: "",
			entries: [],
			settling: false,
			...(grant !== undefined ? { permissionGrant: grant } : {}),
			permissionFingerprint: permissionFingerprintOf(grant, codemodeAccountOfGrant(grant, taskId)),
			...(codemodeAccountOfGrant(grant, taskId) !== undefined ? { codemodeAccount: codemodeAccountOfGrant(grant, taskId)! } : {}),
		};
		this.tasks.set(taskId, task);
		return task;
	}

	private handle(task: InternalTask): RpcTaskHandle {
		return {
			taskId: task.taskId,
			workerId: task.worker?.id || task.lastWorkerId || "pending",
			sessionId: task.sessionId,
			sessionFile: task.sessionFile,
			completion: task.deferred.promise,
		};
	}

	async startTask(input: RpcTaskInput): Promise<RpcTaskHandle> {
		if (!input.prompt?.trim()) throw new Error("RPC task prompt is required");
		const task = this.makeTask(input);
		let worker: RpcWorker;
		try {
			// K6：acquire 失败（worker 未就绪即退出/FIFO 等待中被取消 reject）也必须终结 deferred，
			// 否则任务永久滞留 starting、等待方悬挂（旧路径 acquire 在 try 外，失败即泄漏）。
			// P4：acquire 携带任务权限指纹（同指纹才可复用；闲置异指纹 worker 退役重建）。
			worker = await this.acquire(task.taskId, task.sessionKey, task.permissionFingerprint, task.permissionGrant);
		} catch (error) {
			this.failTask(task, error instanceof Error ? error.message : String(error));
			throw error;
		}
		await this.prepareWorker(worker, task);
		task.state = "running";
		worker.state = "running";
		try {
			const response = await worker.request({ type: "prompt", message: task.prompt }, { taskId: task.taskId });
			this.consumeInputDisposition(worker, task, response, "probe");
			return this.handle(task);
		} catch (error) {
			if (task.state === "recovering" as RpcTaskState) return this.handle(task);
			this.failTask(task, error instanceof Error ? error.message : String(error));
			throw error;
		}
	}

	/** P7（§7.2 disposition 接缝）：prompt/steer 响应按 disposition 分派，统一供 start/adjust/
	 *  recover/resume 各调用点消费（WAL/工具文本/三轴面不变——只改等待策略，不改收口语义）：
	 *  - started：宿主已接受输入并启动 run——agent_settled 事件流是权威收口（H2：agent_end ≠
	 *    settled，宿主 _runAgentPrompt finally 必发 agent_settled），跳过 30ms probe 定时猜测与
	 *    其额外 get_state；run 失败也只走事件流（无第二个 response），不由本层猜完成。
	 *  - queued：输入入队、不等待执行——不立即判完成，等当前/后续 run 的 agent_settled。
	 *  - handled：输入被 extension command/input handler 处理——不直接当 done（U11：handled 后
	 *    扩展独立 run 与本任务的关联须 commandId/taskId/事件顺序证明；未证等价保留现有扩展
	 *    命令完成路径 probe 收口——probe 经 get_state+无 agent_start 复核后 settle，可观察面
	 *    与旧路径一致）。
	 *  - missing/unknown：回退现有 probe 语义（零行为变化兜底）；unknown 追加兼容诊断事件。
	 *  steer 消费点（adjustTask adjust-next-step）发送时必有在途 run（isStreaming 才走 steer），
	 *  三态语义均为等待在途事件流，无 probe 兜底面——与旧路径一致。 */
	private consumeInputDisposition(worker: RpcWorker, task: InternalTask, response: RpcResponse, fallback: "probe" | "await-events"): void {
		const outcome = parseRpcDisposition(response);
		if (outcome.kind === "unknown") {
			this.emit({ type: "rpc_event", workerId: worker.id, taskId: task.taskId, event: { type: "disposition_unknown", command: response.command, commandId: response.id, value: outcome.value, fallback } });
		}
		if (outcome.kind === "known" && (outcome.disposition === "started" || outcome.disposition === "queued")) return; // 等事件流收口，不 probe 不猜完成
		if (fallback === "probe") this.probeExtensionCommandCompletion(worker, task); // handled/missing/unknown → 现有 probe 路径
	}

	private probeExtensionCommandCompletion(worker: RpcWorker, task: InternalTask): void {
		setTimeout(() => {
			if (task.state !== "running" || task.sawAgentStart || worker.currentTask !== task || worker.state === "dead") return;
			void worker.refreshState(task.taskId).then((state) => {
				if (!state?.isStreaming && task.state === "running" && !task.sawAgentStart) { void this.settleTask(worker, task); return; }
				return;
			}).catch(() => undefined);
		}, 30).unref?.();
	}

	async adjustTask(taskId: string, message: string): Promise<RpcAdjustmentResult> {
		const task = this.tasks.get(taskId);
		if (!task) throw rpcTaskNotFoundError(taskId);
		if (!message.trim()) throw new Error("RPC adjustment message is required");
		let worker = task.worker;
		if (!worker || worker.state === "dead" || worker.sessionKey !== task.sessionKey) throw new Error(`RPC task ${taskId} has no reusable worker session`);
		const state = await worker.refreshState(taskId);
		if (state?.isStreaming) {
			task.prompt = message; // crash 对账必须以最新待交付 steer 为目标
			const response = await worker.request({ type: "steer", message }, { taskId });
			this.consumeInputDisposition(worker, task, response, "await-events");
			return { taskId, workerId: worker.id, delivery: "adjust-next-step", description: "已排队调整下一步；不会打断当前 turn/tool。", response, completion: task.deferred.promise };
		}

		if (worker.state === "idle") this.reserve(worker);
		if (task.state === "settled" || task.state === "error") {
			task.deferred = deferred<RpcTaskResult>();
			task.runtimeEvents = newRuntimeEventAccumulator();
			task.lastAssistantStopReason = undefined;
			task.hostAborted = undefined;
			task.cancelReason = undefined;
			task.settling = false;
			task.lastAssistantText = "";
			task.entries = [];
			task.leafId = undefined;
		}
		task.state = "running";
		task.prompt = message;
		task.sawAgentStart = false;
		worker.currentTask = task;
		worker.state = "running";
		const response = await worker.request({ type: "prompt", message }, { taskId });
		this.consumeInputDisposition(worker, task, response, "probe");
		return { taskId, workerId: worker.id, delivery: "prompt-start", description: "会话 idle，已用 prompt 启动新 turn。", response, completion: task.deferred.promise };
	}

	async getEntries(taskId: string, since?: string): Promise<{ entries: any[]; leafId: string | null }> {
		const task = this.tasks.get(taskId);
		const worker = task?.worker;
		if (!task || !worker || worker.state === "dead") throw new Error(`RPC task ${taskId} has no live worker`);
		const response = await worker.request({ type: "get_entries", ...(since ? { since } : {}) }, { taskId });
		return response.data;
	}

	async onWorkerEvent(worker: RpcWorker, event: any): Promise<void> {
		const task = worker.currentTask;
		if (task) { task.runtimeEvents ??= newRuntimeEventAccumulator(); observeRuntimeEvent(task.runtimeEvents, event); }
		if (event?.type === "agent_start" && task) task.sawAgentStart = true;
		if (event?.type === "message_end" && event.message?.role === "assistant" && task) {
			task.lastAssistantText = messageText(event.message);
			task.lastAssistantStopReason = typeof event.message.stopReason === "string" ? event.message.stopReason : undefined;
		}
		if (event?.type === "extension_ui_request") {
			await this.handleExtensionUI(worker, event);
			return;
		}
		this.emit({ type: "rpc_event", workerId: worker.id, taskId: task?.taskId, event });
		// H2（§8.4-H2/§6.2.9）agent_end ≠ settled：宿主 agent-session.js 以 willRetry 重发
		// agent_end（自动重试/压缩/排队续跑仍可能在途），agent_settled 才是全结算权威信号
		// （AgentSettledEvent：「no automatic retry, compaction, or queued continuation will run」）。
		// 此处只认 agent_settled 触发 settle；agent_end 仅经上方 emit 透传（观测面）。
		if (event?.type === "agent_settled" && task && (task.state === "running" || task.state === "ui_wait")) {
			const aborted = typeof event.aborted === "boolean" ? event.aborted : undefined;
			if (event.aborted !== undefined && aborted === undefined) this.emit({ type: "rpc_event", workerId: worker.id, taskId: task.taskId, event: { type: "aborted_unknown", value: event.aborted } });
			await this.settleTask(worker, task, aborted);
		}
	}

	private async handleExtensionUI(worker: RpcWorker, request: RpcExtensionUIRequest): Promise<void> {
		const task = worker.currentTask;
		this.emit({ type: "ui_event", workerId: worker.id, taskId: task?.taskId, event: request });
		if (!["select", "confirm", "input", "editor"].includes(request.method)) {
			// B7（§5.4）：fire-and-forget 单向投影（notify/setStatus/setWidget/setTitle/set_editor_text）
			// 不建 pending、不给 ack；未知方法降级告警（broker.project 内判定）。
			this.dialogs.project(
				{ key: worker.id, generation: this.wal.generation, sessionId: worker.sessionId ?? "", ...(task?.taskId !== undefined ? { taskId: task.taskId } : {}) },
				request,
			);
			return;
		}
		const cycle = task?.deferred;
		const ownsCycle = () => worker.currentTask === task && task?.deferred === cycle && cycle?.settled !== true && worker.state !== "dead";
		const previousState = worker.state;
		worker.state = "ui_wait";
		if (task) task.state = "ui_wait";
		const controller = new AbortController();
		this.uiControllers.set(request.id, { workerId: worker.id, controller, cycle });
		let timer: ReturnType<typeof setTimeout> | undefined;
		try {
			let answer: RpcLeaderAnswer;
			if (this.options.askLeader) {
				// TUI 直答路径（原样保留）：本地对话框超时 = uiTimeoutMs 覆盖语义。
				const timeoutMs = boundedInt(request.timeout, this.options.uiTimeoutMs, 10, 30 * 60_000);
				const question: RpcLeaderQuestion = {
					requestId: request.id,
					taskId: task?.taskId,
					workerId: worker.id,
					method: request.method,
					title: request.title,
					message: request.message,
					placeholder: request.placeholder,
					options: request.options,
					timeoutMs,
					signal: controller.signal,
				};
				answer = await Promise.race([
					Promise.resolve(this.options.askLeader(question)),
					new Promise<undefined>((resolve) => { timer = setTimeout(() => { controller.abort(); resolve(undefined); }, timeoutMs); }),
					new Promise<undefined>((resolve) => controller.signal.addEventListener("abort", () => resolve(undefined), { once: true })),
				]);
			} else {
				// B7（§5.4）远程应答路径：broker 建 pending 表（deadline = 宿主 timeout ?? 120s 本地默认），
				// WebUI（完整关联键）与 Leader（rpc_task answer，requestId）的应答汇于 broker.submit；
				// 超时/取消由 broker 内部 timer/signal 收口（resolve undefined → 此处发送 cancelled）。
				// notifyLeader 照发——远程值守可从 WebUI 或 Leader 侧任一路径应答，不重复建设。
				const asked = this.dialogs.ask({
					workerKey: worker.id,
					workerGeneration: this.wal.generation,
					sessionId: worker.sessionId ?? "",
					requestId: request.id,
					method: request.method as "select" | "confirm" | "input" | "editor",
					...(task?.taskId !== undefined ? { taskId: task.taskId } : {}),
					title: typeof request.title === "string" ? request.title : undefined,
					message: typeof request.message === "string" ? request.message : undefined,
					placeholder: typeof request.placeholder === "string" ? request.placeholder : undefined,
					options: Array.isArray(request.options) ? request.options : undefined,
					timeoutMs: typeof request.timeout === "number" ? request.timeout : undefined,
					signal: controller.signal,
				});
				if (!asked.ok) {
					// 超限/非法：立即取消本对话（不排队不加长窗口）+ 可见错误事件（设计 §5.4）。
					this.emit({ type: "rpc_event", workerId: worker.id, taskId: task?.taskId, event: { type: "dialog_rejected", requestId: request.id, method: request.method, code: asked.code, reason: asked.message } });
					await worker.sendOneWay({ type: "extension_ui_response", id: request.id, cancelled: true }, task?.taskId);
					return;
				}
				this.options.notifyLeader?.({
					requestId: request.id,
					taskId: task?.taskId,
					workerId: worker.id,
					method: request.method,
					title: request.title,
					message: request.message,
					placeholder: request.placeholder,
					options: request.options,
					timeoutMs: typeof request.timeout === "number" && request.timeout > 0 ? request.timeout : DEFAULT_REMOTE_DIALOG_DEADLINE_MS,
				});
				answer = await asked.answer;
			}
			if (ownsCycle()) await worker.sendOneWay(this.uiResponse(request, controller.signal.aborted ? undefined : answer), task?.taskId);
		} catch {
			if (ownsCycle()) await worker.sendOneWay({ type: "extension_ui_response", id: request.id, cancelled: true }, task?.taskId).catch(() => undefined);
		} finally {
			if (timer) clearTimeout(timer);
			if (this.uiControllers.get(request.id)?.controller === controller) this.uiControllers.delete(request.id);
			if (ownsCycle()) {
				worker.state = previousState === "recovering" ? "recovering" : "running";
				if (task && task.state === "ui_wait") task.state = previousState === "recovering" ? "recovering" : "running";
			}
		}
	}

	private uiResponse(request: RpcExtensionUIRequest, answer: RpcLeaderAnswer): RpcCommand {
		if (answer && typeof answer === "object") return { type: "extension_ui_response", id: request.id, ...answer };
		if (request.method === "confirm" && typeof answer === "boolean") return { type: "extension_ui_response", id: request.id, confirmed: answer };
		if (typeof answer === "string") return { type: "extension_ui_response", id: request.id, value: answer };
		return { type: "extension_ui_response", id: request.id, cancelled: true };
	}

	/** W2-R1 三语义 → broker 类型化应答转换（rpc_task answer 兼容路径）。 */
	static dialogAnswerOf(answer: RpcLeaderAnswer): RpcDialogAnswer {
		if (answer && typeof answer === "object") {
			if ((answer as { cancelled?: true }).cancelled === true) return { kind: "cancelled" };
			if (typeof (answer as { confirmed?: boolean }).confirmed === "boolean") return { kind: "confirmed", confirmed: (answer as { confirmed: boolean }).confirmed };
			if (typeof (answer as { value?: string }).value === "string") return { kind: "value", value: (answer as { value: string }).value };
			return { kind: "cancelled" };
		}
		if (typeof answer === "boolean") return { kind: "confirmed", confirmed: answer };
		if (typeof answer === "string") return { kind: "value", value: answer };
		return { kind: "cancelled" };
	}

	answerLeaderQuestion(requestId: string, answer: RpcLeaderAnswer): boolean {
		return this.dialogs.submitByRequestId(requestId, RpcPool.dialogAnswerOf(answer)).ok;
	}

	/** B7（§5.4）：完整关联键应答（WebUI 远程应答面；与 rpc_task answer 汇于同一 broker）。 */
	answerDialog(key: RpcDialogKey, answer: RpcDialogAnswer): RpcDialogSubmitResult {
		return this.dialogs.submit(key, answer);
	}

	private async settleTask(worker: RpcWorker, task: InternalTask, aborted?: boolean): Promise<void> {
		if (task.deferred.settled || worker.currentTask !== task || worker.state === "dead") return;
		if (aborted !== undefined) task.hostAborted = aborted;
		if (aborted === true) {
			for (const pending of this.uiControllers.values()) if (pending.workerId === worker.id && pending.cycle === task.deferred) pending.controller.abort();
			this.failTask(task, `${task.cancelReason ? `cancelled: ${task.cancelReason} ` : ""}[host-aborted] 宿主报告本轮中止（agent_settled.aborted=true）`, true);
			return; // 不为 entries 完整性再等待 RPC。
		}
		if (task.settling) return;
		const cycle = task.deferred;
		const ownsCycle = () => task.deferred === cycle && !cycle.settled && worker.currentTask === task && worker.state !== "dead";
		task.settling = true;
		try {
			const response = await worker.request({ type: "get_entries" }, { taskId: task.taskId });
			if (!ownsCycle()) return; // abort/cancel 或新 cycle 已接管；旧回包不写 WAL、不再归还。
			task.entries = response.data?.entries || [];
			task.leafId = response.data?.leafId;
			task.lastAssistantText = lastAssistantText(task.entries) || task.lastAssistantText;
			task.sessionId = worker.sessionId;
			task.sessionFile = worker.sessionFile;
			// agent_settled means idle, not success: a final provider error must not become done.
			if (task.lastAssistantStopReason === "error") {
				const category = task.runtimeEvents?.latest?.category;
				this.failTask(task, `[provider error] ${category ?? "unknown"}`);
				return;
			}
			task.state = "settled";
			this.wal.append({ phase: "task_settled", taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: task.sessionKey, data: { entryCount: task.entries.length, leafId: task.leafId, recovered: task.recovered } });
			const result: RpcTaskResult = { runtimeObservation: runtimeObservation(task.runtimeEvents ?? newRuntimeEventAccumulator()), taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, state: "settled", recovered: task.recovered, lastAssistantText: task.lastAssistantText, entries: task.entries, leafId: task.leafId, ...(task.hostAborted !== undefined ? { aborted: task.hostAborted } : {}) };
			task.deferred.resolve(result);
			this.emit({ type: "task_settled", workerId: worker.id, taskId: task.taskId, event: result });
			this.handoffOrIdle(worker);
		} catch (error) {
			if (ownsCycle()) this.failTask(task, error instanceof Error ? error.message : String(error));
		} finally { if (task.deferred === cycle) task.settling = false; }
	}

	private failTask(task: InternalTask, message: string, aborted?: boolean): void {
		// 8月迭代 pi-0.84 配合 修复轮：幂等口径加固为 deferred.settled 单一权威终态标记——
		// 自然 settle（settleTask/forceSettleAll 均经 deferred.resolve 终结）后任何路径再调
		// failTask 都不得改写终态（旧口径 state==="error"&&settled 漏掉 settled 后被收编为 error
		// 的状态分裂）；WAL/registry 书写者职责不变，仅拒绝二次结算。
		if (task.deferred.settled) return;
		task.state = "error";
		if (aborted !== undefined) task.hostAborted = aborted;
		const worker = task.worker;
		try { this.wal.append({ phase: "task_error", taskId: task.taskId, workerId: worker?.id || task.lastWorkerId, sessionId: task.sessionId, sessionFile: task.sessionFile, sessionKey: task.sessionKey, error: message }); }
		catch (walError) { this.emit({ type: "rpc_event", workerId: worker?.id, taskId: task.taskId, event: { type: "wal_error", error: String(walError) } }); }
		const result: RpcTaskResult = { runtimeObservation: runtimeObservation(task.runtimeEvents ?? newRuntimeEventAccumulator()), taskId: task.taskId, workerId: worker?.id || task.lastWorkerId || "unknown", sessionId: task.sessionId, sessionFile: task.sessionFile, state: "error", recovered: task.recovered, lastAssistantText: task.lastAssistantText, entries: task.entries, leafId: task.leafId, error: message, ...(task.hostAborted !== undefined ? { aborted: task.hostAborted } : {}) };
		task.deferred.resolve(result);
		this.emit({ type: "task_error", workerId: result.workerId, taskId: task.taskId, message });
		if (worker && worker.state !== "dead" && worker.currentTask === task) this.handoffOrIdle(worker);
	}

	onWorkerClose(worker: RpcWorker, code: number | null, signal: NodeJS.Signals | null): void {
		this.workers.delete(worker.id);
		for (const [requestId, pending] of this.uiControllers) {
			if (pending.workerId !== worker.id) continue;
			pending.controller.abort();
			this.uiControllers.delete(requestId);
		}
		// B7（§5.4）：worker 退出 → 该 worker 全部 pending 对话失效（旧页面不能回答重启后的新进程；
		// signal abort 已触发的条目在此幂等 no-op）。
		this.dialogs.cancelByWorker(worker.id, "worker-exit");
		this.emit({ type: "worker_exit", workerId: worker.id, taskId: worker.currentTask?.taskId, event: { code, signal, intentional: worker.intentionalStop } });
		const task = worker.currentTask;
		try { this.wal.append({ phase: "worker_exit", taskId: task?.taskId || "_pool", workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: worker.sessionKey, data: { code, signal, intentional: worker.intentionalStop } }); }
		catch (walError) { this.emit({ type: "rpc_event", workerId: worker.id, taskId: task?.taskId, event: { type: "wal_error", error: String(walError) } }); }
		if (!task || worker.intentionalStop || this.shuttingDown || task.deferred.settled) {
			this.fillWaiters();
			return;
		}
		task.worker = undefined;
		task.lastWorkerId = worker.id;
		task.sessionId = worker.sessionId || task.sessionId;
		task.sessionFile = worker.sessionFile || task.sessionFile;
		task.state = "recovering";
		task.recovered = true;
		this.emit({ type: "worker_recovering", workerId: worker.id, taskId: task.taskId });
		if (this.options.autoRecover) void this.reconcileTask(task.taskId).catch((error) => this.failTask(task, String(error)));
		else this.fillWaiters();
	}

	private fillWaiters(): void {
		while (this.waiters.length && this.workers.size < this.options.maxWorkers) {
			const waiter = this.waiters.shift()!;
			// P4：按等待者自身指纹/授权重建 worker（同指纹闲置 worker 已在 acquire/handoff 消化）。
			void this.spawnWorker(undefined, waiter.grant, waiter.codemodeAccount).then((worker) => waiter.resolve(this.reserve(worker))).catch(waiter.reject);
		}
	}

	private reconcileEntries(task: InternalTask, entries: any[]): { targetFound: boolean; completed: boolean; completedAssistantText: string; danglingTool: boolean; lastRole?: string } {
		const messageEntries = entries.filter((entry) => entry?.type === "message" && entry.message);
		// 同一 session 可多次发送相同 prompt；恢复必须锚定最后一次已落盘的目标 user，
		// 否则第一次 prompt 的旧 assistant 会被误认成当前 turn 的完成结果。
		const targetIndex = messageEntries.findLastIndex((entry) => entry.message.role === "user" && messageText(entry.message) === task.prompt);
		const after = targetIndex < 0 ? [] : messageEntries.slice(targetIndex + 1);
		const completedAssistant = after.find((entry) => entry.message.role === "assistant" && entry.message.stopReason !== "toolUse");
		const completed = !!completedAssistant;
		let danglingTool = false;
		for (let i = 0; i < after.length; i++) {
			const message = after[i].message;
			if (message.role !== "assistant") continue;
			const toolCalls = (message.content || []).filter((part: any) => part.type === "toolCall");
			for (const call of toolCalls) if (!after.slice(i + 1).some((entry) => entry.message.role === "toolResult" && entry.message.toolCallId === call.id)) danglingTool = true;
		}
		return { targetFound: targetIndex >= 0, completed, completedAssistantText: messageText(completedAssistant?.message), danglingTool, lastRole: messageEntries.at(-1)?.message?.role };
	}

	async reconcileTask(taskId: string): Promise<RpcReconcileResult> {
		const task = this.tasks.get(taskId);
		if (!task) throw rpcTaskNotFoundError(taskId);
		if (task.recoveryPromise) return task.recoveryPromise;
		task.recoveryPromise = this.doReconcile(task).finally(() => { task.recoveryPromise = undefined; });
		return task.recoveryPromise;
	}

	private async doReconcile(task: InternalTask): Promise<RpcReconcileResult> {
		task.recoveryCount++;
		if (task.recoveryCount > 3) throw new Error(`RPC task ${task.taskId} recovery limit exceeded`);
		const sessionExists = !!task.sessionFile && fs.existsSync(task.sessionFile);
		// P4：恢复重派同授权同指纹（不携带新任务权限；与原任务授权面一致）。
		// B5B：同任务同账户（恢复重派沿用原账户——额度不因 worker 重建归零）。
		const worker = await this.spawnWorker(sessionExists ? task.sessionFile : undefined, task.permissionGrant, task.codemodeAccount);
		worker.state = "recovering";
		worker.sessionKey = task.sessionKey;
		worker.currentTask = task;
		task.worker = worker;
		task.lastWorkerId = worker.id;
		task.sessionId = worker.sessionId;
		task.sessionFile = worker.sessionFile;
		task.state = "recovering";

		if (!sessionExists) {
			task.state = "running"; worker.state = "running"; task.sawAgentStart = false;
			const replayResponse = await worker.request({ type: "prompt", message: task.prompt }, { taskId: task.taskId });
			this.wal.append({ phase: "reconciled", taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: task.sessionKey, data: { action: "replay", reason: "session file missing" } });
			this.consumeInputDisposition(worker, task, replayResponse, "probe");
			return { taskId: task.taskId, status: "replayed", sessionFile: worker.sessionFile, entryCount: 0, reason: "session 文件不存在；根据 controller WAL 在新 session 重放首 prompt", recoverySource: task.recoverySource };
		}

		const response = await worker.request({ type: "get_entries" }, { taskId: task.taskId });
		const entries = response.data?.entries || [];
		task.entries = entries; task.leafId = response.data?.leafId;
		const reconciled = this.reconcileEntries(task, entries);
		if (reconciled.danglingTool) {
			const reason = "检测到缺失 toolResult 的悬空 toolCall；任务不可自动恢复，已拒绝重放并终结为 error";
			this.wal.append({ phase: "reconciled", taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: task.sessionKey, data: { action: "manual", danglingTool: true, entryCount: entries.length } });
			this.failTask(task, reason);
			return { taskId: task.taskId, status: "manual", sessionFile: worker.sessionFile, entryCount: entries.length, leafId: task.leafId, reason, recoverySource: task.recoverySource };
		}
		if (reconciled.completed) {
			task.lastAssistantText = reconciled.completedAssistantText;
			task.state = "running"; worker.state = "running";
			this.wal.append({ phase: "reconciled", taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: task.sessionKey, data: { action: "completed", entryCount: entries.length } });
			await this.settleTask(worker, task);
			return { taskId: task.taskId, status: "completed", sessionFile: worker.sessionFile, entryCount: entries.length, leafId: task.leafId, reason: "get_entries 已存在目标 user 后的完整 assistant", recoverySource: task.recoverySource };
		}

		task.state = "running"; worker.state = "running"; task.sawAgentStart = false;
		const continuation = reconciled.targetFound ? task.recoveryPrompt : task.prompt;
		const continuationResponse = await worker.request({ type: "prompt", message: continuation }, { taskId: task.taskId });
		this.wal.append({ phase: "reconciled", taskId: task.taskId, workerId: worker.id, sessionId: worker.sessionId, sessionFile: worker.sessionFile, sessionKey: task.sessionKey, data: { action: reconciled.targetFound ? "continue" : "replay", entryCount: entries.length, lastRole: reconciled.lastRole } });
		this.consumeInputDisposition(worker, task, continuationResponse, "probe");
		return { taskId: task.taskId, status: reconciled.targetFound ? "continued" : "replayed", sessionFile: worker.sessionFile, entryCount: entries.length, leafId: task.leafId, reason: reconciled.targetFound ? "目标 user 已落盘但无完整 assistant；发送恢复 continuation" : "session 中未找到目标 user；根据 WAL 重放", recoverySource: task.recoverySource };
	}

	/** Controller 自身重启后，从 WAL 重建未终结任务并对账。
	 *  K6（N9）：recoveryGate 拒绝（auto:false）的在途任务不自动接管——不 makeTask、不 spawn，
	 *  只补一条 reconciled/manual WAL 记录并返回 manual 结果（证据保留，接管与否由对账决策）。 */
	async recoverPendingFromWal(): Promise<RpcReconcileResult[]> {
		const inspection = RpcWalStore.inspect(this.options.walDir);
		const results: RpcReconcileResult[] = inspection.manual.map((item) => ({ taskId: item.taskId, status: "manual", entryCount: 0, reason: item.reason }));
		for (const item of inspection.recoverable) {
			if (this.options.recoveryGate) {
				let decision: RpcRecoveryDecision;
				try { decision = await this.options.recoveryGate(item.taskId); }
				catch (error) { decision = { auto: false, reason: `K6_RECOVERY_GATE_ERROR: ${String(error instanceof Error ? error.message : error).slice(0, 120)}` }; }
				if (!decision.auto) {
					const reason = decision.reason || "recovery gate refused auto takeover";
					try {
						this.wal.append({ phase: "reconciled", taskId: item.taskId, sessionKey: item.sessionKey, ...(item.sessionId ? { sessionId: item.sessionId } : {}), ...(item.sessionFile ? { sessionFile: item.sessionFile } : {}), data: { action: "manual", gate: "recovery-gate", reason } });
					} catch { /* WAL 记录失败不影响对账决策本身 */ }
					results.push({ taskId: item.taskId, status: "manual", entryCount: 0, reason });
					continue;
				}
			}
			if (!this.tasks.has(item.taskId)) {
				const task = this.makeTask({ taskId: item.taskId, sessionKey: item.sessionKey, prompt: item.prompt, recoveryPrompt: item.recoveryPrompt, recoveryStrategy: item.recoveryStrategy }, item.recoverySource);
				task.state = "recovering"; task.recovered = true; task.sessionFile = item.sessionFile; task.sessionId = item.sessionId;
			}
			results.push(await this.reconcileTask(item.taskId));
		}
		return results;
	}

	/** 运维/故障注入入口；生产取消优先使用 abort RPC，此方法模拟进程级 crash。 */
	killTaskWorker(taskId: string, signal: NodeJS.Signals = "SIGKILL"): boolean {
		const worker = this.tasks.get(taskId)?.worker;
		if (!worker || worker.state === "dead") return false;
		return worker.child.kill(signal);
	}

	/** v2 批次D：生产取消路径（killTaskWorker 注释指定的 abort RPC 路线）。
	 *  - running/ui_wait/recovering：向 worker 先 clear_queue 后 abort（尽力送达；8月迭代 pi-0.84
	 *    配合 P2⑤——pi 官方 Esc 配方要求 clear_queue 先于 abort，abort 会续跑会话队列中残留的
	 *    排队 steer/follow_up，先排空才取消彻底），进行中的 UI 提问一并收口；
	 *    往返期间任务自然 settle 时不改写终态（返回 true = 取消动作已处理但任务已自然
	 *    结算，8月迭代 pi-0.84 配合 修复轮）；
	 *    终态统一走 failTask（error + "cancelled:" 前缀——主 registry 的 cancelled 由
	 *    task-service.cancelTask 唯一书写，此处只终止后端执行并 resolve 等待方）。
	 *  - acquire 排队中（waiters）：出队并 reject，startTask 调用方如实收到取消错误。
	 *  - 幂等：deferred 已 settle 返回 false。 */
	async cancelTask(taskId: string, reason?: string): Promise<boolean> {
		const task = this.tasks.get(taskId);
		if (!task || task.deferred.settled) return false;
		const cycle = task.deferred;
		task.cancelReason = reason || "任务被取消";
		const wi = this.waiters.findIndex((w) => w.taskId === taskId);
		if (wi >= 0) { const [w] = this.waiters.splice(wi, 1); w.reject(new Error(`RPC task cancelled: ${reason || "cancelled"}`)); }
		const worker = task.worker;
		// 8月迭代 pi-0.84 配合 P2⑤：clear_queue 排空计数注记（零条/失败不追加）。
		let drainedNote = "";
		if (worker && worker.state !== "dead" && (task.state === "running" || task.state === "ui_wait" || task.state === "recovering")) {
			for (const pending of this.uiControllers.values()) if (pending.workerId === worker.id) pending.controller.abort();
			// 8月迭代 pi-0.84 配合 P2⑤：clear_queue 必须先于 abort——abort 会续跑会话队列中残留的
			// steer/follow_up（adjustTask 排队路径），先排空才能取消彻底；与 abort 同走 worker.request，
			// 超时/失败静默 catch，不阻断取消主链；只计数不回显文本（排队消息可能含敏感任务内容）。
			// H2 复核：顺序与「中途自然结束竞态」夹具见 tests/rpc-clear-queue.test.mjs
			// （clear_queue 先于 abort + CQ_SETTLE_ON_CLEAR 竞态收口）。
			try {
				const cleared = await worker.request({ type: "clear_queue" }, { taskId });
				const steeringCount = Array.isArray(cleared.data?.steering) ? cleared.data.steering.length : 0;
				const followUpCount = Array.isArray(cleared.data?.followUp) ? cleared.data.followUp.length : 0;
				if (steeringCount + followUpCount > 0) drainedNote = `（已排空排队消息 ${steeringCount + followUpCount} 条：steering ${steeringCount} / followUp ${followUpCount}）`;
			} catch {}
			if (task.deferred !== cycle || cycle.settled || worker.currentTask !== task) return true;
			try { await worker.request({ type: "abort" }, { taskId }); } catch {}
		}
		// 8月迭代 pi-0.84 配合 修复轮：clear_queue/abort 往返拉宽了入口 settled 检查到 failTask
		// 的窗口——任务在此期间自然 settle 时不得改写终态（failTask 幂等加固双保险），
		// 返回 true 语义：取消动作已处理但任务已自然结算（worker 交还由 settleTask 完成）。
		if (task.deferred !== cycle || cycle.settled) return true;
		this.failTask(task, `cancelled: ${reason || "任务被取消"}${drainedNote}`);
		// 兜底：abort/UI 竞态后 worker 无任务却停在 running（handoffOrIdle 被 settle guard 跳过）→ 交还
		if (worker) setTimeout(() => { if (!worker.currentTask && worker.state === "running") this.handoffOrIdle(worker); }, 200).unref?.();
		return true;
	}

	getTaskState(taskId: string): RpcTaskState | undefined { return this.tasks.get(taskId)?.state; }

	waitForTask(taskId: string): Promise<RpcTaskResult> {
		const task = this.tasks.get(taskId);
		if (!task) return Promise.reject(rpcTaskNotFoundError(taskId));
		return task.deferred.promise;
	}

	snapshot(): { poolId: string; generation: number; size: number; maxWorkers: number; waiting: number; workers: Array<{ id: string; state: WorkerState; sessionKey?: string; sessionId?: string; sessionFile?: string; taskId?: string; permissionFingerprint: string }>; tasks: Array<{ taskId: string; state: RpcTaskState; workerId?: string; sessionId?: string; sessionFile?: string; recovered: boolean; permissionFingerprint: string }> } {
		return {
			poolId: this.id,
			generation: this.wal.generation,
			size: this.workers.size,
			maxWorkers: this.options.maxWorkers,
			waiting: this.waiters.length,
			workers: [...this.workers.values()].map((worker) => ({ id: worker.id, state: worker.state, sessionKey: worker.sessionKey, sessionId: worker.sessionId, sessionFile: worker.sessionFile, taskId: worker.currentTask?.taskId, permissionFingerprint: worker.permissionFingerprint })),
			tasks: [...this.tasks.values()].map((task) => ({ taskId: task.taskId, state: task.state, workerId: task.worker?.id || task.lastWorkerId, sessionId: task.sessionId, sessionFile: task.sessionFile, recovered: task.recovered, permissionFingerprint: task.permissionFingerprint })),
		};
	}

	async shutdown(): Promise<void> {
		if (this.shuttingDown) return;
		this.shuttingDown = true;
		for (const waiter of this.waiters.splice(0)) waiter.reject(new Error("RPC pool shutdown"));
		for (const pending of this.uiControllers.values()) pending.controller.abort();
		this.uiControllers.clear();
		// B7（§5.4）：关闭远程应答面——先取消全部 pending（旧页面迟到回答被拒），再停 worker；
		// 已送出的确认不重放（sent 条目已从 pending 移除）。
		this.dialogs.shutdown("rpc-pool-shutdown");
		try {
			await Promise.all([...this.workers.values()].map((worker) => worker.stop(this.options.shutdownGraceMs)));
			this.workers.clear();
		} finally { this.wal.close(); }
	}
}

/** 直接使用主会话 ctx.ui 构建 ask_leader 闭环；适合作为 RpcPoolOptions.askLeader。 */
export function createUiAskLeaderBridge(ui: {
	input?: (title: string, placeholder?: string, opts?: { timeout?: number; signal?: AbortSignal }) => Promise<string | undefined>;
	select?: (title: string, options: string[], opts?: { timeout?: number; signal?: AbortSignal }) => Promise<string | undefined>;
	confirm?: (title: string, message: string, opts?: { timeout?: number; signal?: AbortSignal }) => Promise<boolean>;
}): (question: RpcLeaderQuestion) => Promise<RpcLeaderAnswer> {
	return async (question) => {
		const opts = { timeout: question.timeoutMs, signal: question.signal };
		if (question.method === "confirm" && ui.confirm) return ui.confirm(question.title || "子 Agent 提问", question.message || "确认？", opts);
		if (question.method === "select" && ui.select) return ui.select(question.title || "子 Agent 提问", question.options || [], opts);
		if ((question.method === "input" || question.method === "editor") && ui.input) return ui.input(question.title || "子 Agent 提问", question.placeholder || question.message, opts);
		return undefined;
	};
}

export function inspectRpcWal(walDir = process.env.AMAGI_RPC_WAL_DIR || path.join(amagiDataDir(), "rpc-wal")): RpcWalInspection {
	const resolved = path.resolve(walDir);
	return RpcWalStore.inspect(resolved);
}
