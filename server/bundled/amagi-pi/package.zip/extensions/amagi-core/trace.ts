/**
 * trace.ts — T2-8：任务轨迹采集（§9.3 质量反馈循环）。
 *
 * 结构化记录每次子 Agent 任务的完整轨迹到 data/traces/traces.ndjson（append NDJSON，原子单行写入），
 * 供 T2-3（路由记忆聚合）与 T3-3（evals 重生）消费。
 *
 * 接入点：task-tool.ts runPiTask 统一 finalize（sync/background/resume 三路径共享）。
 * 字段供数：taskId/agent/mode/时长/token/成本/工具调用计数/终态/resume轮次。
 *
 * 路径模式：AMAGI_TRACES_PATH（测试隔离注入）|| <amagiDataDir>/traces/traces.ndjson（E2 起迁出包目录，见 data-dir.ts）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataFile } from "./data-dir.ts";
import { isContextLimitError, isToolOrder400 } from "./session-repair.ts";
import { isStreamDisconnectError, isContentPolicyRejection, isAccountQuotaError } from "./reliability.ts";
// B0-1（附录 B.1）：UsageFigures/CallUsage 与解析域同一口径（type-only，零运行时依赖）。
import type { UsageFigures, CallUsage } from "./task-jsonl.ts";
import type { CostSource } from "./cost-source.ts";

// ── P2-A（2026-08-19 插件进化）：errorKind 错误分类枚举 ──────────────────────────
// 观测层增强：status=error 的 trace 行只落分类枚举（errorKind），绝不落 errorMessage 明文
// （隐私/体积；分类即可作后续结构手术的回归信号）。读侧兼容旧 formatVersion（见 errorKindOfEntry）。

/** errorKind 枚举值。读侧归一另含 "unknown"（旧行/不可分类），不在写侧枚举内。 */
export type ErrorKind = "quota" | "transient-400" | "context-limit" | "timeout" | "policy" | "doom-loop" | "stall" | "model" | "aborted" | "other";

// 分类契约（顺序=确定性匹配序：先具体签名后宽泛兜底，自上而下先命中先返回。
// 本注释即测试契约，改动顺序/规则必须同步 tests/trace-error-kind.test.mjs）：
//  1. 空消息（undefined/空串）→ undefined（无错误不分类）；
//  2. transient-400：isToolOrder400 命中——2026-08-19 Kimi 过载窗口 400 tool 消息序误拒
//     （会话校验干净、provider 端瞬时误拒），与配额/模型侧故障区分；
//  2b. aborted（ev-20261011-094b9f/c77487）：用户/控制面主动中止签名——「[中止] 收到 abort 信号」
//     （task-run.ts 真实 abort 布尔根因文案）与「[host-aborted] 宿主报告本轮中止」（agent_settled 中止）。
//     非能力、非 provider 健康信号：路由成功率与熔断均不得计入；
//  3. context-limit：isContextLimitError 命中——401/400 上下文超限族（实战：luoshen 401 context 上限）；
//  4. doom-loop：/死循环|doom-?loop/i——watchdog/doom-loop 主动终止文案；
//  5. stall：/停滞|无输出|stall/i——与停滞看门狗术语对齐；
//  6. timeout：/timed?\s*out|timeout|超时/i——含 harness [超时]/[启动就绪超时] 中文 kill 根因前缀
//     （ETIMEDOUT 也由此命中："etimedout" 含 "timedout"）；
//  6b. policy（ev-20261012-21074e① / ev-20261017-88cb27）：isContentPolicyRejection 命中——provider
//     内容/安全策略拒绝文案（provider-safety-refusal：『flagged for possible … risk』『content
//     policy』『usage policy』『safety system』『Daybreak access』等）。实战：diting 审核任务被
//     openai-codex 网络安全策略拦截，旧归 other 泛化；策略拦截是任务内容触发的确定性拒绝（非配额/
//     瞬时/容量），terminal-doctor/stats 单独聚合不混入 other。置于 quota/model 之前：策略文案可含
//     forbidden/unauthorized 词根（403 表述），误入 model 会丢针对性修因；quota（rate limit/1308）
//     与 context-limit 复合签名不与本类相交，不误分；
//  7. quota：账号级/硬额度耗尽（provider-quota-exhausted）——isAccountQuotaError 命中（硬额度签名
//     单源在 reliability：『usage limit has been reached』『exceeded your current quota』『额度已
//     耗尽』等无需 429 共现；或 429/限流信号 + 账号级词族双命中），或 QUOTA_RE 命中且非过载
//     （/使用上限|配额|1308|rate.?limit|too many requests/i 且 !/overload/i；纯瞬时 429 退避可
//     恢复，不算硬额度耗尽）；
//  8. model：其余 provider/模型侧故障——429 engine_overloaded **明确归 model**（provider 容量
//     问题，与配额耗尽语义区分）、残留 429、5xx（500/502/503/504）、invalid api key/
//     unauthorized/forbidden、model not found、网络层可达性（fetch failed/ECONNRESET 等）；
//  9. other：兜底（非空但无已知特征）。
const QUOTA_RE = /使用上限|配额|1308|rate.?limit|too many requests/i;
const OVERLOAD_RE = /overload/i;
const MODEL_RE = /\b429\b|overloaded|\b50[0234]\b|internal server error|service unavailable|bad gateway|invalid api key|api key (invalid|not valid|not found)|incorrect api key|unauthorized|forbidden|model_not_found|model not found|fetch failed|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|socket hang up|network error|connection error|getaddrinfo|oauth|access token (?:has been )?revoked/i;

/**
 * P2-A：错误文本 → errorKind 纯分类（规则与匹配顺序见上方契约注释；无错误 → undefined）。
 * 输入为任务终态根因消息（task-tool finalize 的 finalErrorMessage / 启动失败消息）。
 */
export function classifyErrorKind(errorMessage?: string): ErrorKind | undefined {
	if (!errorMessage) return undefined;
	if (isToolOrder400(errorMessage)) return "transient-400";
	if (/收到 abort 信号|\[中止\]|\[host-aborted\]/i.test(errorMessage)) return "aborted";
	if (isContextLimitError(errorMessage)) return "context-limit";
	// ev-20261021-fix（diting F9）：策略拦截优先于 timeout/额度/model 兜底——安全拒绝文案可与
	// timeout/403 等词根共现（如「403 … flagged … safety policy timeout」），先归 timeout 会丢失
	// policy 专属恢复路径；与 lastErrorKindOfMessage 同一优先级口径。
	if (isContentPolicyRejection(errorMessage)) return "policy";
	if (/死循环|doom-?loop/i.test(errorMessage)) return "doom-loop";
	if (/停滞|无输出|stall/i.test(errorMessage)) return "stall";
	if (/timed?\s*out|timeout|超时/i.test(errorMessage)) return "timeout";
	if (isAccountQuotaError(errorMessage) || (QUOTA_RE.test(errorMessage) && !OVERLOAD_RE.test(errorMessage))) return "quota";
	if (isStreamDisconnectError(errorMessage) || MODEL_RE.test(errorMessage)) return "model";
	return "other";
}

/**
 * errorKind 读侧归一（新旧 formatVersion 兼容）：
 *  - status=error 且有 errorKind → 原值；
 *  - status=error 无 errorKind（旧 v1 行，或 v2 行错误无消息分类为 undefined）→ "unknown"
 *    （未知——聚合时归「未知」，绝不误报 other）；
 *  - 非 error 行（done/blocked/truncated/cancelled）→ undefined。
 */
export function errorKindOfEntry(e: { status?: string; errorKind?: ErrorKind }): ErrorKind | "unknown" | undefined {
	if (e.status !== "error") return undefined;
	return e.errorKind ?? "unknown";
}

export interface TraceEntry {
	/** v3（B0-1，附录 B.1）：新增累计用量字段（usageScope/assistantCalls/firstCallContext/lastCall/
	 *  nestedUsage/compactionUsage/leaderSession/runKey/preflightBytes/usageCoverage）；
	 *  v2（P2-A）新增 errorKind；旧 v1/v2 行读侧按 last-call 口径单独分组（不与新行混加）。 */
	formatVersion: 2 | 3;
	taskId: string;
	agent: string;
	/** sync | background | resume | bg-resume（由 mode + resumeRounds 推断）。 */
	mode: string;
	/** done | blocked | error。 */
	status: string;
	durationMs?: number;
	/** token：输入/输出。 */
	input?: number;
	output?: number;
	/** 缓存命中：本任务所有请求 prompt_cache 命中 token 累计（v1.5.226 P0-2；源 pi-ai Usage.cacheRead）。 */
	cacheRead?: number;
	/** 缓存写入：Anthropic 系写入计费 token 累计（其余 provider 常为 0/缺省）。 */
	cacheWrite?: number;
	/** 成本（美元）。 */
	cost?: number;
	/** pi 1.5.0 计费口径（provider=供应商计费/estimate=目录估算/mixed/unknown=口径缺失——旧宿主）；缺席=无成本观测。 */
	costSource?: CostSource;
	/** 工具调用计数（子进程 assistant message 中 toolCall part 数）。 */
	toolCalls: number;
	blocked: boolean;
	/** resume 轮次数（registry.rounds.length；>0 表示经历过 resume）。 */
	resumeRounds: number;
	model?: string;
	/** A10: 启发式任务类别（bug-fix/feature/test/review/refactor/doc）。 */
	taskCategory?: string;
	/** A10: 工具名序列（去重，从 toolCall parts 提取 name）。 */
	toolNames?: string[];
	/** v1.5.184 耗时拆分：模型生成累计 ms（message_start→message_end，含 thinking）。 */
	thinkMs?: number;
	/** v1.5.184 耗时拆分：工具执行累计 ms（tool_execution_start→end）。 */
	toolMs?: number;
	/** v1.5.185 provider 重试风暴：auto_retry_start 次数 / 退避等待累计 ms。 */
	retryAttempts?: number;
	retryWaitMs?: number;
	/** v1.5.187 冷启动延迟 ms（spawn→首个 stdout 事件；grok PromptLatency pre_model 对应）。 */
	startupMs?: number;
	/** v1.5.188 自动续跑轮数（>0：本次逻辑任务因模型早停被自动续接了 N 轮，统计已聚合为单条）。 */
	autoContinueRounds?: number;
	/** Deterministic baseline failures handed back to the same session for repair. */
	autoRepairRounds?: number;
	/** Harness-owned baseline/diff collection time, separate from model/tool execution. */
	verificationMs?: number;
	/** v2 批次A 运行图：编排 group id（一次 orchestrate 调用一个 runId；独立任务缺省）。 */
	runId?: string;
	/** v2 批次A 运行图：父任务（fork 分叉记录源 taskId）。 */
	parentTaskId?: string;
	/** v2 批次A 运行图：group 内节点 id（如 pipeline-2 / tournament-judge）。 */
	nodeId?: string;
	/** v2 批次A 运行图：节点级真实依赖（同 runId 内前置 nodeId 列表）。 */
	dependsOn?: string[];
	/** v2 批次A：执行后端（json=pi 子进程，rpc=RPC pool；registry 迁移默认 json）。 */
	backend?: string;
	/** v2 批次A：任务修订号（stale result 判定基线；registry 迁移默认 0）。 */
	revision?: number;
	/** v2 批次A：准入排队观测（ queuedAt=入队时刻 ms，queueMs=排队耗时；共享 admission 上线前缺省）。 */
	queuedAt?: number;
	queueMs?: number;
	/** P2-A（v2）：错误分类枚举（仅 status=error 行写入；值为 classifyErrorKind 结果，不含 errorMessage 明文）。 */
	errorKind?: ErrorKind;
	// ── B0-1（附录 B.1）v3 字段：累计用量口径 ──
	/** "cumulative" = 本次运行可见事件累计；旧行无此标记 → 读侧按 last-call 单独统计。 */
	usageScope?: "cumulative";
	/** 已观察到的 assistant 完结事件数（可观测模型轮次，非供应商账单请求数）。 */
	assistantCalls?: number;
	/** 完结帧缺 usage 的 assistant 事件数（流前失败/内部重试无完结帧另列，不机械相加）。 */
	usageMissingCalls?: number;
	/** 第一条带 usage 的 assistant 调用的 input+cacheRead+cacheWrite（首条缺 usage → 缺席=未知）。 */
	firstCallContext?: number;
	/** 末次 assistant 调用诊断快照（错误尾帧可为 0；不覆盖累计；三输入分项供上下文规模）。 */
	lastCall?: CallUsage;
	/** toolResult.message_end 可选 usage 的和（工具内嵌模型调用单列，不混入 assistant）。 */
	nestedUsage?: UsageFigures;
	/** compaction_end.result.usage 的可见和（压缩模型单列；无来源归未知，不归工作模型）。 */
	compactionUsage?: UsageFigures;
	/** 派发会话标识（task-service 会话盖章；按会话聚合/本会话视图过滤用）。 */
	leaderSession?: string;
	/** 一次真实子运行的稳定标识（taskId+轮序+spawn 时刻派生；resume/自动修复各有各自增量）。 */
	runKey?: string;
	/** 本次实际注入预检快照的 UTF-8 字节数（未注入=0；不是 token 数）。 */
	preflightBytes?: number;
	/** 可见事件计量覆盖度："complete" 或 "|" 连接的 missing-usage/output-truncated/abnormal-exit。 */
	usageCoverage?: string;
	/** deferStats 多轮聚合行的分轮身份（每轮一行；读侧不再把被包含的分轮行加总——分轮行不落盘）。 */
	runs?: TraceRunSlice[];
	/** deferStats 多轮聚合行的分模型小计（自动续跑/修复/模型切换按实际模型拆桶）。 */
	modelSubtotals?: TraceModelSubtotal[];
	at: number;
}

/** deferStats 聚合行携带的分轮身份（附录 B.1：首上下文取第一轮首调用、末上下文取最后轮末调用，
 *  每轮数据仍可追踪；分轮行不单独落盘，本数组是各轮增量的唯一留痕）。 */
export interface TraceRunSlice {
	runKey: string;
	model?: string;
	/** 该轮终态（done/error/blocked/…）。 */
	status: string;
	/** F3（diting，附录 B.1）：以下分项 undefined=该轮未观察（未知，非 0）；不入账不补零。 */
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	cost?: number;
	/** 该轮已观察成本的计费口径（与顶层 costSource 同枚举；缺席=该轮无成本观测）。 */
	costSource?: CostSource;
	/** 该轮 assistant 完结事件数（0=真实零调用）。 */
	assistantCalls: number;
	/** 该轮是否观察到任何 usage（false=上列分项缺席是未知非零；读侧按覆盖位呈现）。 */
	usageObserved: boolean;
}

/** 分模型小计（按各轮实际模型拆桶，不把全部 token 填到最后一轮模型下）。分项 undefined=
 *  桶内无任何已观察轮（下界）；coverage 标注桶内是否存在未观察轮（partial=至少一轮未知）。 */
export interface TraceModelSubtotal {
	model: string;
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	cost?: number;
	/** 桶内已观察成本的计费口径（各轮合并；缺席=桶内无成本观测）。 */
	costSource?: CostSource;
	assistantCalls: number;
	runs: number;
	coverage: "complete" | "partial";
}

export function tracesFile(): string {
	return process.env.AMAGI_TRACES_PATH || amagiDataFile("traces", "traces.ndjson");
}

/** 追加一条 trace（原子单行 append，同 writeStats 模式）。容错：不可写时静默。 */
export function writeTrace(entry: TraceEntry): void {
	try {
		const line = JSON.stringify(entry) + "\n";
		const file = tracesFile();
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.appendFileSync(file, line, { encoding: "utf8", mode: 0o600 });
	} catch {
		// 容错：trace 写失败不影响主流程（同 stats 哲学）
	}
}

/** 读取全部 trace（按时间顺序）。供 T2-3 聚合/T3-3 evals 消费。 */
export function readTraces(file?: string): TraceEntry[] {
	try {
		const f = file || tracesFile();
		const content = fs.readFileSync(f, "utf8");
		return content
			.split("\n")
			.filter(Boolean)
			.map((l) => {
				try {
					return JSON.parse(l) as TraceEntry;
				} catch {
					return null;
				}
			})
			.filter((x): x is TraceEntry => x !== null);
	} catch {
		return [];
	}
}

// ── B0-3（Leader 成本效率编排 §3.4 / 附录 B.2）：重复全套与大发射观测落盘 ────────
//
// 观测行 append-only 追加到 <traces 目录>/observations.ndjson（复用本模块数据目录解析与
// AMAGI_TRACES_PATH 测试隔离；AMAGI_OBSERVATIONS_PATH 可独立覆盖）。设计约束（§9.2 B0-3）：
//   - 观测行在结算后另行追加，不重排结算、不回写旧行；子运行 trace 可能早于父侧回归落盘，
//     由 /amagi stats 按 taskId/runKey 关联；
//   - 观测写失败只报 bounded 诊断（调用方单行 stderr/tuiWarn），不影响 settlement；
//   - 不写工具输出正文、密钥或完整任务书（命令标识/cwd/计数与状态即可）；
//   - 无法完整关联记 unknown（区别于 0）；未调用到观察点的任务不算「没有重复」。

/** 子代理重复全套观测行（kind="child-full-suite"；父侧 finalizer 结算后追加）。 */
export interface ChildSuiteObservationEntry {
	formatVersion: 1;
	kind: "child-full-suite";
	taskId: string;
	/** 末轮（或单轮）子运行标识——与 trace 行 runKey 对齐；无法关联 → \"unknown\"。 */
	runKey: string;
	agent?: string;
	/** 已发布候选回执的 receiptId（已有时）；未发布/不可达 → 缺席。 */
	receiptId?: string;
	/** 探测到的基线命令标识（argv 空格连接；有界截断）。 */
	command: string;
	cwd: string;
	/** 已结束、可识别、cwd 匹配的基线命令执行次数（下界观测）。 */
	childFullSuiteRuns: number | "unknown";
	/** 命中命令但 cwd 不匹配/不可确证的执行数。 */
	childCwdMismatchRuns: number | "unknown";
	/** 末次候选存在布尔（只证明最近命中后无 unsafe 工具，不证明文件状态）。 */
	childSuiteCandidate: boolean | "unknown";
	/** harness 是否真的跑了基线（由真实结构化检查回执给出；无结构化事实=false）。 */
	harnessBaselineRan: boolean | "unknown";
	/** 结构化检查回执的验证对象指纹；无法关联 → \"unknown\"。 */
	verificationObjectId: string;
	at: number;
}

/** 大发射守卫阻断观测行（kind="large-emission-block"；子进程实际阻断分支记录一次）。 */
export interface LargeEmissionObservationEntry {
	formatVersion: 1;
	kind: "large-emission-block";
	/** 子进程 env（AMAGI_TASK_ID/AMAGI_RUN_KEY）；Leader 直跑无任务上下文 → 缺席。 */
	taskId?: string;
	runKey?: string;
	tool: "write" | "edit";
	/** 被拦截目标路径（有界截断；不含内容）。 */
	target: string;
	bytes: number;
	maxBytes: number;
	provider: string;
	at: number;
}

export type ObservationEntry = ChildSuiteObservationEntry | LargeEmissionObservationEntry;

/** 观测文件路径：AMAGI_OBSERVATIONS_PATH || <traces 目录>/observations.ndjson（与 traces 同目录）。 */
export function observationsFile(): string {
	return process.env.AMAGI_OBSERVATIONS_PATH || path.join(path.dirname(tracesFile()), "observations.ndjson");
}

/** 追加一行观测（原子单行 append）。返回是否写成功——失败时调用方只报 bounded 诊断，绝不反噬主流程。 */
export function writeObservation(entry: ObservationEntry): boolean {
	try {
		const file = observationsFile();
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.appendFileSync(file, JSON.stringify(entry) + "\n", { encoding: "utf8", mode: 0o600 });
		return true;
	} catch { /* lint-exempt:观测写失败返回 false 交调用方 bounded 诊断——绝不反噬主流程（同 writeTrace 容错哲学） */
		return false;
	}
}

/** 读取全部观测行（按时间顺序）；文件缺失/损坏行跳过。 */
export function readObservations(file?: string): ObservationEntry[] {
	try {
		const f = file || observationsFile();
		return fs.readFileSync(f, "utf8")
			.split("\n")
			.filter(Boolean)
			.map((l) => {
				try { return JSON.parse(l) as ObservationEntry; } catch { /* lint-exempt:损坏行跳过（同 readTraces 口径） */ return null; }
			})
			.filter((x): x is ObservationEntry => x !== null);
	} catch { /* lint-exempt:文件缺失/不可读返回空数组（观测面只读降级） */
		return [];
	}
}
