/**
 * guard-notes.ts — ev-20260916-c1a50c：守卫提示会话计次（有界，无注册副作用）。
 *
 * 背景：非限频的可纠正诊断（rg/BSD 参数错误等）在同一会话内反复命中时，每次都是同一句
 * 文案——模型无从感知「这是第 N 次犯同类错误」，修复优先级不会提升。本模块为提示接线层
 * 提供 `ruleId -> count` 的会话计数：第二次起在文案头部标注「本会话第 N 次出现」。
 *
 * 边界（方案 §3.5）：
 *  - 仅限非限频的可纠正诊断；敏感哨兵的去重预算、stash 同状态一次性提示等既有限频机制
 *    不受影响（不强行重复提示，也不为计数突破预算）。
 *  - 仍为软提示：计数不升级为 terminate、不改变任何阻断语义。
 *  - 映射有界：最多 GUARD_REPEAT_NOTE_MAX_RULES 个已知 ruleId，超界后新 ruleId 不登记
 *    （返回 1，等价于不标注），防长会话无界增长。
 *  - ruleId 只允许稳定短标识（规则类别 + 可执行名），不记录命令正文或凭据——调用方构造
 *    key 时必须遵守（见 guards.ts diagnosticRuleKey）。
 *  - 生命周期 = 会话（registerGuards 的 session_start/session_shutdown 复位）。
 *
 * 回滚：AMAGI_GUARD_REPEAT_NOTE=0/false/off 关闭（回旧文案；计数状态仍维护但不再标注）。
 */

/** 已知 ruleId 上限（有界映射；超界新 id 不登记）。 */
export const GUARD_REPEAT_NOTE_MAX_RULES = 64;

/** 会话计次器：ruleId → 出现次数。零 pi 依赖，由接线方持有并随 session 重置。 */
export class RepeatNoteTracker {
	private counts = new Map<string, number>();

	/** 记录一次出现并返回累计次数（1 起）；映射满后新 ruleId 返回 1（不标注语义）。 */
	note(ruleId: string): number {
		const id = String(ruleId || "").slice(0, 64);
		if (!id) return 1;
		const known = this.counts.get(id);
		if (known !== undefined) {
			this.counts.set(id, known + 1);
			return known + 1;
		}
		if (this.counts.size >= GUARD_REPEAT_NOTE_MAX_RULES) return 1;
		this.counts.set(id, 1);
		return 1;
	}

	/** 会话复位（session_start / session_shutdown / 测试隔离）。 */
	reset(): void {
		this.counts.clear();
	}

	/** 单 ruleId 计次复位（ev-20260929-ddf3c9：合规结构出现即清零——Agent 已按建议整改，
	 * 后续风险形态从首报计，升级提示不因历史次数立即复现）。 */
	resetRule(ruleId: string): void {
		this.counts.delete(String(ruleId || "").slice(0, 64));
	}

	/** 已登记 ruleId 数（观测/测试）。 */
	get size(): number {
		return this.counts.size;
	}
}

/** AMAGI_GUARD_REPEAT_NOTE 开关解析：默认开启；显式 0/false/off 关闭；非法值回安全默认（开）。 */
export function guardRepeatNoteEnabled(env: string | undefined = process.env.AMAGI_GUARD_REPEAT_NOTE): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/**
 * 第二次起在文案头部标注「本会话第 N 次出现」：
 * 文案以方括号标签（如 `[AMAGI Bash 诊断·软提示]`）开头时标注插在标签之后，否则整体前置。
 * 第一次（count<2）原样返回。
 */
export function withRepeatNoteHeader(text: string, count: number): string {
	if (!Number.isFinite(count) || count < 2) return text;
	const marker = `（本会话第 ${Math.floor(count)} 次出现）`;
	const tagMatch = /^(\s*\[[^\]\n]+\])/.exec(text);
	if (tagMatch) return `${tagMatch[1]}${marker}${text.slice(tagMatch[1].length)}`;
	return `${marker}${text}`;
}

/** ev-20260926-19d1bb：升级阈值——同键第 GUARD_NOTE_ESCALATE_AT 次起追加升级段（可复制修正）。
 *  背景：实战 rg -rn 同型警示单会话触发 10 次、全部当轮挽救但「第二次不再发生」未达成——
 *  仅标注次数不足以打断肌肉记忆型复发，第 3 次起必须给出可直接执行的固化建议（修正命令/alias）。 */
export const GUARD_NOTE_ESCALATE_AT = 3;

/** ev-20260926-19d1bb：计次标注 + 升级段组合（软提示升级通道）——
 *  count<2 原文；count≥2 头部标注「本会话第 N 次出现」；count≥GUARD_NOTE_ESCALATE_AT 再追加
 *  `[amagi 升级提示]` 段（escalation 为空则退化为纯标注）。仍为软提示：不升级为阻断。 */
export function withEscalatedNote(text: string, count: number, escalation: string): string {
	let out = withRepeatNoteHeader(text, count);
	if (escalation && Number.isFinite(count) && count >= GUARD_NOTE_ESCALATE_AT) {
		out += `\n[amagi 升级提示] ${escalation}`;
	}
	return out;
}

// ── ev-20261002-f9f167（ux/P2）：可纠正型软提示降频（升级接管，不再重复全文） ──
// 背景：实战单会话同类软提示重复轰炸（git 层级×4、异源暂存×5+、管道退出码×3）——19d1bb 的
// 升级段是「全文+标注+升级段」三段叠加，恰是最轰炸形态；重复全文只剩注意力税。语义分层：可纠正
// 型软提示（同类失误已知修正法）首次见全文后升级提示直接接管（一行计数+修正建议）；污染级
// （rg -r 输出被静默改写，每轮输出都需当轮全文对照）与低频新提示仍走 withEscalatedNote。
// 降频模式关（AMAGI_GUARD_NOTE_COMPACT=0）回 19d1bb 旧行为。开关独立于 AMAGI_GUARD_REPEAT_NOTE
//（后者关的是计次标注，本开关关的是正文折叠）。
// ev-20261031-a25f7a（复盘 §2.6 裁定）：阈值 3→2——用户要求「首次全文、第二次起一行折叠」
//（复盘原文误以为管道退出码已做到首次即折，实际旧实现是首两次全文；本改动把全部 compact
// 接线族统一到用户口径）。污染级 withEscalatedNote 不受影响（每轮需当轮全文对照）。

/** 降频阈值：第 GUARD_NOTE_COMPACT_AT 次起正文折叠为一行（用户口径：首次全文、第二次起折叠）。 */
export const GUARD_NOTE_COMPACT_AT = 2;

/** AMAGI_GUARD_NOTE_COMPACT 开关解析：默认开启；显式 0/false/off 回旧全文行为。 */
export function guardNoteCompactEnabled(env: string | undefined = process.env.AMAGI_GUARD_NOTE_COMPACT): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** ev-20261002-f9f167：可纠正型软提示降频（ev-20261031-a25f7a 阈值 3→2）——首次原文；
 *  第 2 次起升级接管：保留原标签头 + 一行计数 + 修正建议，正文折叠（首次全文见会话历史）。
 *  供 bash-override/guards 的可纠正型接线使用。 */
export function withCompactEscalatedNote(text: string, count: number, escalation: string): string {
	if (!guardNoteCompactEnabled()) return withEscalatedNote(text, count, escalation);
	if (!Number.isFinite(count) || count < GUARD_NOTE_COMPACT_AT) return withEscalatedNote(text, count, escalation);
	const tagMatch = /^(\s*\[[^\]\n]+\])/.exec(text);
	const tag = tagMatch ? tagMatch[1] : "[amagi 软提示]";
	return `${tag}（本会话第 ${Math.floor(count)} 次·正文已折叠，首次全文见会话历史）${escalation ? `修正建议：${escalation}` : ""}`;
}
