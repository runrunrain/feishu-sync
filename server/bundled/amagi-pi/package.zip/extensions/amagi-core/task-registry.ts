/**
 * task-registry.ts — SubAgent 任务注册表（内存）。
 * P1.5 终审修复：snapshot 不可突破字节上限 + restore 全字段校验+预算 + getInternal 移除 + query 时间防御。
 * v2 批次B：create metadata 接受 name（UTF-8 裁剪入 record/snapshot）+ resolveSession 裸 name 与 `runId/name` 解析。
 * ev-20260910-0f59ce（P3）：终态迁移顺带触发 task-writes 登记 GC（链闭合定向回收 + TTL/上限
 * 兜底清扫，见 gcTaskWritesOnSettled；GC 失败静默，绝不反噬状态机）。
 *
 * amagi-pi v2 K3（§3.1/§8.1-K3）：本表降为「legacy 兼容投影」——内部可变表写入权移交内核
 * （task-kernel.ts）：① 新增内核注入点 kernelProjection()（仅 task-kernel 经此写）；② 现有写方法
 * 在迁移桥（RegistryKernelBridge，task-kernel 安装）接管后经桥转译为内核命令（状态变化→命令映射；
 * 观测补录→内存投影；其余字段→受控白名单写入），未安装时 legacy 直写语义不变（现有测试零破坏）；
 * ③ 终态 GC 改为 settle 钩子（installSettleHook 注入；桥模式下由内核 deps.onSettle 触发，
 * attachRegistry 缺省接 settleGc；K8c 已拆 legacy 缺省钩子（settleHook 缺省 no-op，等价回调由组合根注入）。
 * K4-K8 逐片拆除桥与 legacy 写面，收敛到「内核唯一写入口 + 本表只读投影」。
 */

import { reapTaskWrites, sweepTaskWrites } from "./task-write-log.ts";
import type { RuntimeObservation } from "./runtime-fingerprint.ts";

export type TaskStatus = "queued" | "running" | "done" | "blocked" | "error" | "answered" | "answering" | "cancelled" | "truncated" | "resolved-external";
export type TaskMode = "sync" | "background";

export interface ActivityEvent { type: string; summary: string; ts: number; }
/** A4（ev-20260910-d86779）：RoundRecord 增 model——本轮实际使用的模型 spec（resume 续轮由调用方携带；
 *  历次使用模型序列可从 rounds 推导，供 A3 建议与看板展示）。 */
export interface RoundRecord { task: string; at: number; status?: TaskStatus; model?: string; }

export interface TaskRecord {
	runtimeObservation?: RuntimeObservation;
	taskId: string; agent: string; sessionId?: string; name?: string;
	status: TaskStatus; result?: string; model?: string;
	goal?: string; blockedQuestions?: string[]; artifactRefs?: string[];
	/** P1-C（8.19 迭代）：派发契约 refs 快照（任务文本引用 ∪ resume 直接父任务的交接入口）——
	 *  create 时定格，终态前不被 output refs 合并污染；finalizer 据此写入 artifact
	 *  metadata.upstreamArtifactReferences（无 refs 时空数组，不发明内容）。 */
	upstreamArtifactRefs?: string[];
	/** ev-20260909-1af2ca：派发时定格的解析后绝对路径快照（resume 续轮继承；无白名单为 undefined）。 */
	allowedPaths?: string[];
	/** v1.5.223（diting Major-4）：blocked 的结构化原因——"questions"（QUESTIONS 待答，缺省/遗留语义）
	 *  vs "needs-handoff"（settle 产出窗口收口：resume 接手开工，非逐项答复）。
	 *  通知/wait/answer-queue/resume 状态机据此区分两类行动语义，杜绝 handoff 被当成待答问题。 */
	blockReason?: "questions" | "needs-handoff";
	/** 任务工作目录（spawn/证据/artifact 落点）；resume 复用该目录（跨 cwd resume 修复）。 */
	cwd?: string;
	startedAt: number; endedAt?: number; mode?: TaskMode;
	/** 首次进入 blocked 的时刻；与 endedAt（真正终态）分离，供待答时长与排序使用。 */
	blockedAt?: number;
	child?: unknown; rounds?: RoundRecord[]; activityWindow?: ActivityEvent[];
	stopReason?: string; errorMessage?: string; signal?: string | null;
	timedOut?: boolean; aborted?: boolean;
	/** v1.5.184 耗时拆分：模型生成累计 ms / 工具执行累计 ms（query_task 展示用）。 */
	thinkMs?: number; toolMs?: number;
	/** v1.5.185 provider 重试风暴：auto_retry_start 次数 / 退避等待累计 ms。 */
	retryAttempts?: number; retryWaitMs?: number;
	/** v1.5.248：完成契约标注（runPiTask finalize 唯一收口计算后回写；看板 truncated 态展示，此前仅回流消费、registry 缺字段致看板恒走缺省文案）。 */
	completionAnnotation?: string;
	/** ev-20260908-f189e7：外部处置收口注记（blocked/排队任务产物已在外部采用，resolve(external)
	 *  轻量收口时写入——与 cancelled 区分：非放弃而是已采用，不 spawn 不重跑；query_task/看板展示）。 */
	resolveNote?: string;
	/** v1.5.187 冷启动延迟 ms（spawn→首个 stdout 事件）。 */
	startupMs?: number;
	/** A4（ev-20260910-d86779）：最近一次 error 终态的错误类别（policy/transient/quota/other；
	 *  task-run finalize 唯一收口写入，非 error 终态清除）——连续瞬时错误可从 rounds[].status + 本字段
	 *  推导，不引入独立计数器。policy=v2.21.6（ev-20261017-88cb27）：provider 安全拦截（内容策略
	 *  拒绝）可区分标签，resume 中断包/快照往返可见；口径单源 reliability.lastErrorKindOfMessage。 */
	lastErrorKind?: "policy" | "transient" | "quota" | "other";
	/** Wave C2（8月迭代）：写入路径可观测——最近成功写盘的文件路径（滚动 ≤8 去重队列，绝对路径）。
	 *  子进程轨迹解析（write/edit 的 file_path/path + bash 高置信写形态目标）成功核销时入列；
	 *  query_task running 态展示 + 主进程并行冲突软提示消费（复盘 §2.6）。 */
	lastWritePaths?: string[];
	/** v2 批次A 运行图：编排 group id（一次 orchestrate 调用一个 runId；独立任务缺省）。 */
	runId?: string;
	/** v2 批次A 运行图：父任务（fork 分叉记录源 taskId）。 */
	parentTaskId?: string;
	/** v2 批次A 运行图：group 内节点 id（如 pipeline-2 / tournament-judge）。 */
	nodeId?: string;
	/** v2 批次A 运行图：节点级真实依赖（同 runId 内前置 nodeId 列表）。 */
	dependsOn?: string[];
	/** v2 批次A：执行后端（json=pi 子进程，rpc=RPC pool）；旧 snapshot 迁移默认 json。 */
	backend?: "json" | "rpc";
	/** v2 批次A：任务修订号（stale result 判定基线）；旧 snapshot 迁移默认 0。 */
	revision?: number;
	/** v2 批次A：进入准入队列时刻 ms（批次 B 共享 admission 前缺省）。 */
	queuedAt?: number;
	/** v2 批次A：排队耗时 ms（启动时刻 - queuedAt；共享 admission 前缺省）。 */
	queueMs?: number;
	/** ev-20260916-101d8a（方案 §4.2）：排队原因展示元数据——cooldown=链尽 429 单次冷却等待
	 *  （不占并发槽，retryAt 到期重入 FIFO）；capacity=常规准入排队。不新增顶层 status 枚举，
	 *  旧 UI 最差仍显示 queued。 */
	queueReason?: "cooldown" | "capacity";
	/** ev-20260916-101d8a：冷却到期时刻（epoch ms；仅 queueReason=cooldown 时携带；旧记录无字段仍可读）。 */
	retryAt?: number;
	/** ev-20260916-101d8a：本逻辑派发的链尽冷却机会已消费（每派发最多一次；展示元数据，不参与状态机）。 */
	cooldownUsed?: boolean;
}

const MAX_ACTIVITY = 50;
const MAX_SNAPSHOT_DONE = 50;
const MAX_SNAP_ROUNDS = 10;
const MAX_SNAP_BYTES = 65536;
const MAX_SNAP_ROUND_BYTES = 500; // P1-2: 单条 round 文本字节上限
const MAX_RESTORE_ITEMS = 500; // P1-4: restore 条目数预算
const MAX_RESTORE_MS = 200; // P1-4: restore 时间预算
const MAX_TASK_ID_BYTES = 256;
const MAX_CWD_BYTES = 1024;
const MAX_AGENT_BYTES = 128;
const MAX_SESSION_ID_BYTES = 512;
const MAX_MODEL_BYTES = 256;
const MAX_NAME_BYTES = 256;
const MAX_RESULT_BYTES = 50 * 1024;
const MAX_META_TEXT_BYTES = 2048;
const MAX_SNAPSHOT_RESULT_BYTES = 4096;
const MAX_GOAL_BYTES = 2048;
const MAX_ARTIFACT_REFS = 10;
const MAX_ARTIFACT_REF_BYTES = 512;
const MAX_BLOCKED_QUESTIONS = 10;
const MAX_QUESTION_BYTES = 512;
const MAX_RUN_ID_BYTES = 128;
const MAX_NODE_ID_BYTES = 128;
const MAX_DEPENDS_ON = 8;
const MAX_WRITE_PATHS = 8; // Wave C2：滚动写入路径队列上界
const MAX_WRITE_PATH_BYTES = 1024; // Wave C2：单条写入路径字节上限
// P1（8月迭代第三轮）：truncated 为终态——输出超限截断≠执行失败（终稿帧丢失但会话/产物在）。
// 证据绿时 finalizer 可升级 truncated→done（见 patch 的升级白名单）。
const TERMINAL = new Set<TaskStatus>(["done", "error", "answered", "cancelled", "truncated", "resolved-external"]);
/** ev-20260910-0f59ce：仍可 resume / 运行中的活跃链状态——登记 GC 的保护集（其登记文件绝不回收）。 */
const LIVE_CHAIN_STATUS = new Set<TaskStatus>(["queued", "running", "blocked", "answering"]);
/** ev-20260910-0f59ce：成功收口的链尾状态——触发同会话链前驱登记回收（done/截断/外部处置收口）。 */
const CLOSED_CHAIN_TAIL = new Set<TaskStatus>(["done", "truncated", "resolved-external"]);

/** ed-20260910 diting m-2：adoptExternal 收编记录的登记 GC 保护窗口（默认 30min）。
 *  >24h 中断会话 resume 收编的 error 记录，其登记文件 mtime 已超 TTL 且 error ∉ LIVE_CHAIN_STATUS——
 *  同帧/后续清扫会直接回收，「resume 链归因不被误清」不成立；收编后窗口内并入 protect，
 *  超窗（链已实际接过手/不再依赖登记）恢复常规回收。 */
export const ADOPT_GC_PROTECT_DEFAULT_MS = 30 * 60 * 1000;
let adoptGcProtectMs = ADOPT_GC_PROTECT_DEFAULT_MS;
/** 测试隔离：调整收编保护窗口（undefined/非法值回落默认；0 = 关闭保护）。生产不调用。 */
export function _setAdoptGcProtectMsForTest(ms: number | undefined): void {
	adoptGcProtectMs = typeof ms === "number" && Number.isFinite(ms) && ms >= 0 ? ms : ADOPT_GC_PROTECT_DEFAULT_MS;
}

/** ev-20260910-7f6a90：终态对账口径——与 task-tool createStallAlarm 的发射前过滤同语义：
 *  记录缺失 / 非 running / endedAt 已设（重开/回填竞态）→ 视为已终结（关联的停滞告警应丢弃）。 */
export function isTaskResolved(rec: Readonly<TaskRecord> | undefined): boolean {
	return !rec || rec.status !== "running" || !!rec.endedAt;
}

/** ev-20260914-4150dd：终态判定共享口径——journal 残留对账等只读消费方复用（不改状态机语义）。 */
export function isTerminalStatus(s: TaskStatus): boolean { return TERMINAL.has(s); }

/** ev-20260914-4150dd：歧义错误回显统一口径——resolveSession 歧义消息含多行可复制候选清单
 *  （完整 taskId/runId/name/agent/创建时间），消费端 160 字截断会砍掉候选行；歧义整段透传，
 *  其余 registry 错误维持短截断（超限尾部 … 标注）。 */
export function registryErrorEcho(e: unknown, cap = 160): string {
	const msg = e instanceof Error ? e.message : String(e);
	// diting n-2：优先结构化 ambiguous 标记；字符串前缀仅作旧实例兼容回退（同批构造已全部带标记）
	const ambiguous = (e instanceof RegistryError && e.ambiguous) || msg.startsWith("歧义 ");
	return ambiguous ? msg : (msg.length > cap ? `${msg.slice(0, cap)}…` : msg);
}

const VALID_STATUS = new Set(["queued", "running", "done", "blocked", "error", "answered", "answering", "cancelled", "resolved-external"]);
const VALID_MODES = new Set(["sync", "background", undefined]);
const VALID_BACKENDS = new Set(["json", "rpc"]);
/** v1.5.223（diting Major-4）：blockReason 合法值校验（patch/snapshot/restore 共用）。 */
const VALID_BLOCK_REASON = new Set(["questions", "needs-handoff"]);
/** ev-20260916-101d8a：queueReason 合法值（snapshot/restore/patch 共用）。 */
const VALID_QUEUE_REASON = new Set(["cooldown", "capacity"]);
function queueReasonOf(v: unknown): TaskRecord["queueReason"] {
	return typeof v === "string" && VALID_QUEUE_REASON.has(v) ? v as TaskRecord["queueReason"] : undefined;
}
/** A4（ev-20260910-d86779）：lastErrorKind 合法值（snapshot/restore 共用）。ev-20261017-88cb27：新增
 *  policy（provider 安全拦截）——旧快照不含该值，读侧兼容不受影响。 */
const VALID_ERROR_KIND = new Set(["policy", "transient", "quota", "other"]);
function blockReasonOf(v: unknown): TaskRecord["blockReason"] {
	return typeof v === "string" && VALID_BLOCK_REASON.has(v) ? v as TaskRecord["blockReason"] : undefined;
}

/** Wave C2：写入路径比较键（统一分隔符/去尾斜杠；不做 symlink/case 折叠——宁可漏报不误报）。 */
function writePathKey(p: string): string {
	let s = p.replaceAll("\\", "/").trim();
	while (s.length > 1 && s.endsWith("/")) s = s.slice(0, -1);
	return s;
}

const PATCHABLE = new Set<keyof TaskRecord>([
	"sessionId","name","status","result","model","goal","blockedQuestions","artifactRefs","blockReason","stopReason","errorMessage","signal","timedOut","aborted","child","endedAt","thinkMs","toolMs","retryAttempts","retryWaitMs","startupMs","completionAnnotation",
	"revision","queueMs","queueReason","retryAt","cooldownUsed","lastWritePaths","resolveNote","lastErrorKind","runtimeObservation",
]);
const TRANSITIONS: Record<TaskStatus, Set<TaskStatus>> = {
	queued: new Set(["running", "cancelled", "resolved-external"]), // v2 批次B：准入队列态——晋级 running 或被取消；ev-20260908-f189e7：排队中可外部处置收口
	running: new Set(["done","blocked","error","cancelled","truncated"]),
	done: new Set(), error: new Set(), cancelled: new Set(), // 终态
	blocked: new Set(["answering", "cancelled", "resolved-external"]), // C3-R: blocked→answering（resume 发起时）；v2 批次B: 可取消；f189e7: 可外部处置收口（不 spawn 不重跑）
	answering: new Set(["answered", "blocked", "cancelled", "resolved-external"]), // C3-R: answering→answered（成功启动）；answering→blocked（启动失败恢复）
	answered: new Set(), // 终态
	// P1（8月迭代第三轮）：truncated 终态可被证据升级为 done（finalizer：测试绿+有交付 diff）。
	truncated: new Set(["done"]),
	// ev-20260908-f189e7：外部处置终态（产物已在外部采用；与 cancelled 区分——非放弃）。
	"resolved-external": new Set(),
};

function deepFreeze<T>(o: T): Readonly<T> {
	if (o === null || typeof o !== "object") return o;
	if (Array.isArray(o)) return Object.freeze((o as any[]).map(deepFreeze)) as any;
	const c: any = {};
	for (const k of Object.keys(o as any)) c[k] = deepFreeze((o as any)[k]);
	return Object.freeze(c);
}

/** P1-4: 校验有限时间戳 */
function isFiniteTime(v: any): boolean { return typeof v === "number" && Number.isFinite(v) && v > 0; }

/** UTF-8 字节裁剪，不切断多字节字符，也不附加会突破预算的 marker。 */
function trimUtf8(value: string, maxBytes: number): string {
	const buf = Buffer.from(value, "utf8");
	if (buf.length <= maxBytes) return value;
	let cut = maxBytes;
	while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--;
	return buf.subarray(0, cut).toString("utf8");
}

function optionalString(value: unknown, maxBytes: number): string | undefined {
	return typeof value === "string" ? trimUtf8(value, maxBytes) : undefined;
}

function stringArray(value: unknown, maxItems: number, maxItemBytes: number, unique = false): string[] | undefined {
	if (!Array.isArray(value)) return undefined;
	const strings = value.filter((item): item is string => typeof item === "string" && item.trim() !== "");
	const result = (unique ? [...new Set(strings)] : strings).slice(0, maxItems).map((item) => trimUtf8(item, maxItemBytes));
	return result.length ? result : undefined;
}

/** v2 批次A：非负有限数字（revision/queuedAt/queueMs 校验）。 */
function nonNegativeNumber(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : undefined;
}

/** v2 批次A：create metadata 的运行图字段（编排 group 关联）。 */
export interface TaskRelationMeta {
	runId?: string; parentTaskId?: string; nodeId?: string; dependsOn?: string[];
	backend?: "json" | "rpc"; revision?: number; queuedAt?: number;
}

/** 运行图字段统一校验/裁剪（create 与 restore 共用；非法值静默丢弃，不阻断主流程）。 */
function sanitizeRelation(meta: TaskRelationMeta | undefined): Partial<TaskRecord> {
	const out: Partial<TaskRecord> = {};
	const m = meta || {};
	const runId = optionalString(m.runId, MAX_RUN_ID_BYTES); if (runId) out.runId = runId;
	const parentTaskId = optionalString(m.parentTaskId, MAX_TASK_ID_BYTES); if (parentTaskId) out.parentTaskId = parentTaskId;
	const nodeId = optionalString(m.nodeId, MAX_NODE_ID_BYTES); if (nodeId) out.nodeId = nodeId;
	const dependsOn = stringArray(m.dependsOn, MAX_DEPENDS_ON, MAX_TASK_ID_BYTES); if (dependsOn) out.dependsOn = dependsOn;
	out.backend = VALID_BACKENDS.has(m.backend as string) ? m.backend : "json";
	const revision = nonNegativeNumber(m.revision); out.revision = revision ?? 0;
	const queuedAt = nonNegativeNumber(m.queuedAt); if (queuedAt !== undefined) out.queuedAt = queuedAt;
	return out;
}

/** P1-2: 裁剪单条 round 到字节上限 */
function trimRound(r: any): RoundRecord | undefined {
	if (!r || typeof r !== "object") return undefined;
	const task = typeof r.task === "string" ? trimUtf8(r.task, MAX_SNAP_ROUND_BYTES) : "";
	const at = isFiniteTime(r.at) ? r.at : Date.now();
	// A4（ev-20260910-d86779）：本轮 model 随 round 快照/恢复（缺省字段不发明）
	const model = optionalString(r.model, MAX_MODEL_BYTES);
	return model !== undefined ? { task, at, status: VALID_STATUS.has(r.status) ? r.status : undefined, model } : { task, at, status: VALID_STATUS.has(r.status) ? r.status : undefined };
}

/** diting n-2（ev-20260914-4150dd 后续）：歧义错误带结构化标记——消费端 registryErrorEcho 靠
 *  `new RegistryError(…, { ambiguous: true })` 判定整段透传，不再依赖「歧义 」字符串前缀（改文案即静默失效）。 */
export class RegistryError extends Error {
	/** resolveSession 前缀命中多条时的歧义标记（消息含多行可复制候选清单，须整段透传）。 */
	ambiguous?: boolean;
	constructor(message: string, opts?: { ambiguous?: boolean }) {
		super(message);
		this.ambiguous = opts?.ambiguous ?? false;
	}
}

// ── K3：内核注入点与迁移命令桥（task-kernel.ts 消费；结构化接口避免 task-registry→task-kernel import 环） ──

/** @internal K3 内核投影写入面：仅 task-kernel（及其迁移桥）经此写内部可变表；公开读方法（get/snapshot/list 等）不变。 */
export interface RegistryKernelProjection {
	upsert(rec: TaskRecord): void;
	mutate(taskId: string, fn: (rec: TaskRecord) => void): TaskRecord | undefined;
	replace(taskId: string, rec: TaskRecord | undefined): void;
	notify(): void;
	raw(taskId: string): TaskRecord | undefined;
}

/** @deprecated K3 迁移命令桥（K4-K8 逐片拆除）：registry legacy 写方法经此转译为内核命令
 *  （状态变化→命令映射；观测补录→内存投影；其余字段→受控白名单写入），绝不开放任意 patch 直写内部表。 */
export interface RegistryKernelBridge {
	/** 内核是否持有该任务（registry.create 碰撞预检）。 */
	hasTask(taskId: string): boolean;
	/** registry.create 经此：内核 register（+ 非 queued 记录 grant-start）+ 记录投影。 */
	create(rec: TaskRecord, opts: { startQueued: boolean }): Readonly<TaskRecord>;
	/** registry.patch 经此（前置校验已在 registry 侧完成，语义/文案不变）。 */
	patch(taskId: string, patch: Partial<TaskRecord>): Readonly<TaskRecord> | undefined;
	/** registry.adoptExternal 经此：内核种子收编（bridge seed，K8a 收敛为对账命令）。 */
	adoptExternal(rec: TaskRecord): Readonly<TaskRecord>;
	/** 观测补录（activity/rounds/writePath/artifactRef/cancelledResult——内存投影，不推进 stateSeq/CAS）。 */
	observeLegacy(taskId: string, kind: "activity" | "round" | "writePath" | "artifactRef" | "cancelledResult", payload: unknown, apply: (rec: TaskRecord) => void): void;
	/** registry.reopenForAutoContinue 经此（v1 自动续跑机制的桥专用受控迁移，K4/K5 拆除）。 */
	reopenForAutoContinue(taskId: string): void;
	/** registry.clear/restoreFromSnapshot 经此复位内核态（记录重建仍走 registry 自身，K8a 收敛）。 */
	reset(): void;
}

class TaskRegistry {
	private tasks = new Map<string, TaskRecord>();
	private leases = new Set<string>();
	private shuttingDown = false;
	/** ed-20260910 diting m-2：adoptExternal 收编时刻（登记 GC 保护窗口判定；进程内观测，不入 snapshot）。 */
	private adoptedAt = new Map<string, number>();
	/** v1.5.185 事件响应订阅者：状态/活动任何变更立即通知（UI 加速刷新主通道，轮询降为兜底心跳）。 */
	private changeListeners = new Set<() => void>();
	/** K3：内核迁移桥（task-kernel.attachRegistry 安装；null = legacy 直写语义）。 */
	private kernelBridge: RegistryKernelBridge | null = null;
	/** K3（§3.1：task-writes GC 迁至结算后的可选清理适配器）：终态清理钩子。K8c 拆缺省后缺省为
	 *  no-op——组合根（index.ts）注入等价 GC 回调（onSettle → settleGc）；桥路径由内核 deps.onSettle
	 *  触发。GC 失败静默，不影响事实提交。 */
	private settleHook: (taskId: string) => void = () => {};

	/** @internal K3：安装/卸载内核迁移桥（task-kernel.attachRegistry 调用；每进程唯一内核）。 */
	installKernelBridge(bridge: RegistryKernelBridge | null): void { this.kernelBridge = bridge; }
	/** 内核桥是否接管（诊断/测试用）。 */
	hasKernelBridge(): boolean { return this.kernelBridge !== null; }
	/** K3：终态清理钩子注入（K8c 起缺省为 no-op——组合根/测试注入等价 GC 回调 `(id) => registry.settleGc(id)`）。 */
	installSettleHook(fn: (taskId: string) => void): void {
		this.settleHook = fn ?? (() => {});
	}
	/** K3：旧 gcTaskWritesOnSettled 的公开收口（内核 onSettle/清理适配器/缺省钩子复用）。 */
	settleGc(taskId: string): void {
		const rec = this.tasks.get(taskId);
		if (rec) this.gcTaskWritesOnSettled(rec);
	}

	/** @internal K3 内核注入点：仅 task-kernel（及其迁移桥）经此写内部可变表。 */
	kernelProjection(): RegistryKernelProjection {
		return {
			upsert: (rec) => { this.tasks.set(rec.taskId, rec); },
			mutate: (taskId, fn) => { const r = this.tasks.get(taskId); if (!r) return undefined; fn(r); return r; },
			replace: (taskId, rec) => { if (rec === undefined) this.tasks.delete(taskId); else this.tasks.set(taskId, rec); },
			notify: () => this.emitChange(),
			raw: (taskId) => this.tasks.get(taskId),
		};
	}

	/** 订阅 registry 变更（create/patch/appendActivity/appendRound）；返回退订函数。 */
	onChange(fn: () => void): () => void {
		this.changeListeners.add(fn);
		return () => { this.changeListeners.delete(fn); };
	}
	private emitChange(): void {
		for (const fn of this.changeListeners) { try { fn(); } catch {} }
	}

	/** @deprecated K3 迁移桥接入点（K4-K8 逐片拆除）：桥安装后本方法写入经桥转译为内核命令（register [+grant-start]）+ 记录投影；
	 *  前置校验（shutdown/碰撞）与记录构造留在此处，legacy 语义/文案不变。 */
	create(agent: string, taskId: string, model?: string, mode: TaskMode = "sync", metadata?: { name?: string; goal?: string; artifactRefs?: string[]; upstreamArtifactRefs?: string[]; cwd?: string; startQueued?: boolean; allowedPaths?: string[]; /** ev-20260916-101d8a：排队原因展示元数据（cooldown=链尽 429 冷却等待）。 */ queueReason?: "cooldown" | "capacity"; /** ev-20260916-101d8a：冷却到期时刻（epoch ms）。 */ retryAt?: number } & TaskRelationMeta): Readonly<TaskRecord> {
		if (this.shuttingDown) throw new RegistryError("registry 正在 shutdown");
		if (this.tasks.has(taskId) || (this.kernelBridge?.hasTask(taskId) ?? false)) throw new RegistryError(`taskId 碰撞: ${taskId}`);
		// v2 批次B：startQueued 时记录为 queued（准入队列等待态），queuedAt 记排队起点；
		// 晋级 running 由准入层显式 patch（queued→running + queueMs）。
		const rec: TaskRecord = { taskId, agent, status: metadata?.startQueued ? "queued" : "running", model, startedAt: Date.now(), mode };
		if (metadata?.startQueued && metadata?.queuedAt === undefined) rec.queuedAt = rec.startedAt;
		// ev-20260916-101d8a：排队原因/冷却到期时刻（展示元数据，非法值静默丢弃）
		const queueReason = queueReasonOf(metadata?.queueReason); if (queueReason) rec.queueReason = queueReason;
		const retryAt = nonNegativeNumber(metadata?.retryAt); if (retryAt !== undefined) rec.retryAt = retryAt;
		const goal = optionalString(metadata?.goal, MAX_GOAL_BYTES); if (goal) rec.goal = goal;
		const artifactRefs = stringArray(metadata?.artifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true); if (artifactRefs) rec.artifactRefs = artifactRefs;
		// P1-C：upstream 快照恒为数组（无 refs → []）；不可 patch（契约字段，create 后定型）。
		rec.upstreamArtifactRefs = stringArray(metadata?.upstreamArtifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true) ?? [];
		// ev-20260909-1af2ca：派发时定格的解析后绝对路径快照（create 后定型，不被 patch 污染）
		const allowedPaths = stringArray(metadata?.allowedPaths, 64, 1024); if (allowedPaths) rec.allowedPaths = allowedPaths;
		const cwd = optionalString(metadata?.cwd, MAX_CWD_BYTES); if (cwd) rec.cwd = cwd;
		// v2 批次B：节点名（批次唯一性契约的解析键）；走既有 UTF-8 上限裁剪。
		const name = optionalString(metadata?.name, MAX_NAME_BYTES); if (name) rec.name = name;
		Object.assign(rec, sanitizeRelation(metadata)); // v2 批次A：backend/revision 默认 json/0，运行图字段随编排注入
		if (this.kernelBridge) return this.kernelBridge.create(rec, { startQueued: !!metadata?.startQueued });
		this.tasks.set(taskId, rec);
		this.emitChange();
		return deepFreeze(rec);
	}

	get(taskId: string): Readonly<TaskRecord> | undefined {
		const r = this.tasks.get(taskId);
		return r ? deepFreeze(r) : undefined;
	}

	/**
	 * ev-20260910-7f6a90：短 id（≥8 位）唯一前缀解析——只认 taskId 前缀（与 resolveSession 的
	 * 模糊面区分：不混 sessionId/name、不抛错）；过短或前缀歧义 → undefined（调用方按「身份
	 * 不可还原」保守处理）。供只携带 8 位短 id 的迟到停滞告警在投递侧还原完整任务身份。
	 */
	findByPrefix(prefix: string): Readonly<TaskRecord> | undefined {
		if (typeof prefix !== "string" || prefix.length < 8) return undefined;
		let hit: TaskRecord | undefined;
		for (const [id, rec] of this.tasks) {
			if (!id.startsWith(prefix)) continue;
			if (hit) return undefined; // 歧义：宁可判「无法还原」也不误指
			hit = rec;
		}
		return hit ? deepFreeze(hit) : undefined;
	}

	/**
	 * v2 批次B：解析会话/节点标识。精确 taskId 是一等身份键，命中立即返回（旧语义，前缀不参与）。
	 * 未命中精确时：含 `/` 的 query 只按精确 `runId/name` 组合匹配（runId 精确、name 部分大小写
	 * 不敏感；不做前缀，不混入 taskId/sessionId 前缀）；其余 query 按记录去重收集模糊命中
	 * （taskId/sessionId 前缀 + 唯一裸 name，同 record 多路只计一次）。模糊命中去重集多于 1
	 * 即抛 RegistryError（错误文本可诊断）。
	 */
	resolveSession(idOrPrefix: string): { taskId: string; record: Readonly<TaskRecord> } | undefined {
		const q = idOrPrefix;
		const exact = this.tasks.get(q);
		if (exact) return { taskId: q, record: deepFreeze(exact) };
		const matched = new Map<string, TaskRecord>(); // key=taskId：跨方式去重
		if (q.includes("/")) {
			// `runId/name` 只做精确组合，不做前缀。
			const slash = q.indexOf("/");
			if (slash > 0 && slash < q.length - 1) {
				const runPart = q.slice(0, slash);
				const namePart = q.slice(slash + 1).toLowerCase();
				for (const rec of this.tasks.values()) {
					if (rec.runId === runPart && rec.name && rec.name.toLowerCase() === namePart)
						matched.set(rec.taskId, rec);
				}
			}
		} else {
			for (const rec of this.tasks.values()) {
				if (rec.taskId.startsWith(q)
					|| (rec.sessionId && (rec.sessionId === q || rec.sessionId.startsWith(q)))
					|| (rec.name && rec.name.toLowerCase() === q.toLowerCase()))
					matched.set(rec.taskId, rec);
			}
		}
		if (matched.size > 1) {
			// ev-20260914-4150dd：歧义 detail 升级为多行候选清单——每行含完整可复制 taskId（+ runId/name
			// 消歧键）、agent 角色名、创建时间与任务摘要（~40 字截断）；消费端经 registryErrorEcho 整段
			// 透传（不被 160 字截断砍掉候选），Leader 直接复制粘贴，无需再从列表人工拼 Id。
			const pad2 = (n: number) => String(n).padStart(2, "0");
			const lines = [...matched.values()].map((r) => {
				const ts = new Date(r.startedAt);
				const created = `${pad2(ts.getMonth() + 1)}-${pad2(ts.getDate())} ${pad2(ts.getHours())}:${pad2(ts.getMinutes())}:${pad2(ts.getSeconds())}`;
				const goal = (r.goal || "").replace(/\s+/g, " ").trim().slice(0, 40);
				return `  • taskId=${r.taskId}${r.runId ? ` runId=${r.runId}` : ""}${r.name ? ` name=${r.name}` : ""} agent=${r.agent} 创建=${created}${goal ? ` 任务=${goal}` : ""}`;
			});
			throw new RegistryError(`歧义 "${q}" 匹配 ${matched.size} 个记录（复制完整 taskId 或改用 runId/name 精确指定）:\n${lines.join("\n")}`, { ambiguous: true }); // diting n-2：结构化标记，文案改动静不失效透传
		}
		const entry = matched.values().next().value as TaskRecord | undefined;
		return entry ? { taskId: entry.taskId, record: deepFreeze(entry) } : undefined;
	}

	// P2-3: 移除公开 getInternal；内部直接 this.tasks.get()

	acquireLease(s: string): boolean { if (this.leases.has(s)) return false; this.leases.add(s); return true; }
	releaseLease(s: string): void { this.leases.delete(s); }
	setShuttingDown(v: boolean): void { this.shuttingDown = v; }
	isShuttingDown(): boolean { return this.shuttingDown; }
	/** P1-3: spawn 前二次检查 */
	preSpawnCheck(): void { if (this.shuttingDown) throw new RegistryError("registry 正在 shutdown，拒绝 spawn"); }

	/** @deprecated K3 迁移桥接入点（K4-K8 逐片拆除）：桥安装后本方法写入经桥转译为内核命令（状态变化→命令映射；
	 *  字段→受控白名单写入，每写一次 store CAS）；前置校验（终态保护/字段白名单/迁移表）留在此处不变，
	 *  legacy 错误语义与文案完全一致。 */
	patch(taskId: string, patch: Partial<TaskRecord>): Readonly<TaskRecord> | undefined {
		const rec = this.tasks.get(taskId);
		if (!rec) return undefined;
		// P1：truncated→done 是证据驱动的升级（finalizer 测试绿+有交付 diff），非状态回退，放行。
		if (TERMINAL.has(rec.status) && !(rec.status === "truncated" && patch.status === "done")) throw new RegistryError(`终态不可回退: ${rec.taskId} ${rec.status}`);
		for (const k of Object.keys(patch as any)) if (!PATCHABLE.has(k as any)) throw new RegistryError(`字段不可 patch: ${k}`);
		if (patch.status && !TRANSITIONS[rec.status].has(patch.status)) throw new RegistryError(`非法转换: ${rec.status}→${patch.status}`);
		if (this.kernelBridge) return this.kernelBridge.patch(taskId, patch);
		Object.assign(rec, patch);
		if (patch.status === "blocked" && rec.blockedAt === undefined) rec.blockedAt = Date.now();
		if (patch.status && TERMINAL.has(patch.status)) { if (!rec.endedAt) rec.endedAt = Date.now(); rec.child = undefined; }
		this.emitChange();
		if (patch.status && TERMINAL.has(patch.status)) this.settleHook(taskId);
		return deepFreeze(rec);
	}

	/**
	 * ev-20260910-0f59ce（P3）：终态写盘登记回收（GC）——口径见 task-write-log.ts 模块头。
	 * ① 链闭合定向回收：成功收口（done/truncated/外部处置）即会话链尾——同 sessionId 链路上
	 *    已收口前驱（error/answered/cancelled...）的登记一次清掉（error 保留策略的回收方）；
	 *    blocked/answering/queued/running 属活跃链（仍可 resume），绝不回收。
	 * ② TTL/上限兜底清扫（task-write-log 内 30min 节流，正常零动作）：保护集 = 本表活跃任务 + 本任务
	 *    （后者收尾链 evidence 归因/迟终态回推还要读自己的登记，不得被同帧上限兜底抢删）。
	 * GC 是空间治理，失败静默，绝不影响状态机与调用方（子进程/未隔离测试进程内部自带守卫）。
	 */
	private gcTaskWritesOnSettled(rec: TaskRecord): void {
		try {
			if (CLOSED_CHAIN_TAIL.has(rec.status) && rec.sessionId) {
				const closed: string[] = [];
				for (const r of this.tasks.values()) {
					if (r.taskId === rec.taskId || r.sessionId !== rec.sessionId) continue;
					if (LIVE_CHAIN_STATUS.has(r.status)) continue;
					closed.push(r.taskId);
				}
				if (closed.length) reapTaskWrites(closed, "chain");
			}
			const protect: string[] = [rec.taskId]; // 稳定保护：本任务收尾链（evidence/迟终态回推）仍需读自己的登记
			for (const r of this.tasks.values()) if (LIVE_CHAIN_STATUS.has(r.status)) protect.push(r.taskId);
			const now = Date.now();
			for (const [id, at] of this.adoptedAt) if (now - at < adoptGcProtectMs) protect.push(id); // m-2：近窗收编记录
			sweepTaskWrites({ protect });
		} catch { /* GC 失败静默：空间治理不得反噬状态机 */ }
	}

	/** @deprecated K3 迁移桥接入点：桥安装后观测补录走内核内存投影（不推进 stateSeq/CAS）。 */
	appendActivity(taskId: string, ev: ActivityEvent): void {
		const rec = this.tasks.get(taskId); if (!rec) return;
		if (this.kernelBridge) {
			this.kernelBridge.observeLegacy(taskId, "activity", ev, (r) => {
				if (!r.activityWindow) r.activityWindow = [];
				r.activityWindow.push(ev);
				if (r.activityWindow.length > MAX_ACTIVITY) r.activityWindow = r.activityWindow.slice(-MAX_ACTIVITY);
			});
			return;
		}
		if (!rec.activityWindow) rec.activityWindow = [];
		rec.activityWindow.push(ev);
		if (rec.activityWindow.length > MAX_ACTIVITY) rec.activityWindow = rec.activityWindow.slice(-MAX_ACTIVITY);
		this.emitChange();
	}
	/**
	 * v1.5.188 自动续跑专用豁免：done → running（仅 runTask 自动续跑调用）。
	 * 模型早停的任务被自动续接同一 taskId 时，需要重开终态记录以允许新一轮
	 * spawn/patch；不走 patch 转换表（保持 done 终态对其它路径不可回退的语义）。
	 */
	/** @deprecated K3 迁移桥接入点：桥安装后走桥专用受控迁移（v1 机制，K4/K5 换新 taskId 后拆除）。 */
	reopenForAutoContinue(taskId: string, opts?: { allowError?: boolean }): void {
		const rec = this.tasks.get(taskId);
		if (!rec) return;
		// 2026-08-16 复盘 P0-1：error→running 仅限 400 tool 消息序自愈（会话历史损坏非任务失败，
		// 清理后同 taskId 重派；其余 error 仍终态——stale 防护语义不变）。
		if (rec.status !== "done" && !(opts?.allowError && rec.status === "error")) throw new RegistryError(`仅 done 可自动续跑重开: ${rec.taskId} ${rec.status}`);
		if (this.kernelBridge) { this.kernelBridge.reopenForAutoContinue(taskId); return; }
		rec.status = "running";
		rec.endedAt = undefined;
		// R3（Major-2）：重置 startedAt——否则本轮 payload 的 duration 是「首轮开始→本轮结束」
		// 的累计值，runTask 再逐轮求和会重复计算前轮时长。
		rec.startedAt = Date.now();
		this.emitChange();
	}

	/**
	 * Wave C2（8月迭代）：滚动 ≤8 去重写入路径队列。重复写入刷新到队尾（最新优先保留），
	 * 越界淘汰最旧；与 appendActivity/appendArtifactRef 同型（观测补录，不走 patch 状态机）。
	 */
	/** @deprecated K3 迁移桥接入点：桥安装后走内核内存投影（观测补录，不推进 stateSeq）。 */
	appendWritePath(taskId: string, p: string): void {
		const rec = this.tasks.get(taskId); if (!rec) return;
		const clean = optionalString(p, MAX_WRITE_PATH_BYTES); if (!clean) return;
		if (this.kernelBridge) {
			this.kernelBridge.observeLegacy(taskId, "writePath", clean, (r) => {
				const cur = (r.lastWritePaths || []).filter((x) => x !== clean);
				cur.push(clean);
				r.lastWritePaths = cur.slice(-MAX_WRITE_PATHS);
			});
			return;
		}
		const cur = (rec.lastWritePaths || []).filter((x) => x !== clean);
		cur.push(clean);
		rec.lastWritePaths = cur.slice(-MAX_WRITE_PATHS);
		this.emitChange();
	}

	/** Wave C2：主进程并行冲突匹配——目标绝对路径与任一 running 任务 lastWritePaths 规范化相等即命中。 */
	findRunningWriteConflicts(targetAbs: string): Array<{ taskId: string; agent: string; name?: string; paths: string[] }> {
		const key = writePathKey(String(targetAbs || ""));
		if (!key) return [];
		const hits: Array<{ taskId: string; agent: string; name?: string; paths: string[] }> = [];
		for (const r of this.tasks.values()) {
			if (r.status !== "running" || !r.lastWritePaths?.length) continue;
			const matched = r.lastWritePaths.filter((p) => writePathKey(p) === key);
			if (matched.length) hits.push({ taskId: r.taskId, agent: r.agent, name: r.name, paths: matched });
		}
		return hits;
	}

	/** @deprecated K3 迁移桥接入点：桥安装后走内核内存投影（观测补录，不推进 stateSeq）。 */
	appendRound(taskId: string, round: RoundRecord): void {
		const rec = this.tasks.get(taskId); if (!rec) return;
		if (this.kernelBridge) {
			this.kernelBridge.observeLegacy(taskId, "round", round, (r) => {
				if (!r.rounds) r.rounds = [];
				r.rounds.push(round);
			});
			return;
		}
		if (!rec.rounds) rec.rounds = [];
		rec.rounds.push(round);
		this.emitChange();
	}

	/**
	 * v2 批次B：终态安全收编 artifact 引用（统一收尾链专用）。
	 * 终态任务的 artifact 落盘登记是簿记而非状态回退——与 appendRound/appendActivity 同型豁免；
	 * 编排分支/硬路由的 refs 交接（批次C）依赖此登记真实落账。
	 */
	/** @deprecated K3 迁移桥接入点：桥安装后走内核内存投影（观测补录，不推进 stateSeq）。 */
	appendArtifactRef(taskId: string, ref: string): void {
		const rec = this.tasks.get(taskId); if (!rec) return;
		const clean = optionalString(ref, MAX_ARTIFACT_REF_BYTES); if (!clean) return;
		if (this.kernelBridge) {
			this.kernelBridge.observeLegacy(taskId, "artifactRef", clean, (r) => {
				const refs = [...(r.artifactRefs || [])];
				if (!refs.includes(clean)) refs.push(clean);
				r.artifactRefs = refs.slice(-MAX_ARTIFACT_REFS);
			});
			return;
		}
		const refs = [...(rec.artifactRefs || [])];
		if (!refs.includes(clean)) refs.push(clean);
		rec.artifactRefs = refs.slice(-MAX_ARTIFACT_REFS);
		this.emitChange();
	}

	/**
	 * 取消终态的只读观测补录。状态机仍禁止终态 patch；仅保存 SIGTERM 前已收到的真实输出与
	 * 会话标识，供 query_task / 后续 resume 使用，不改变取消事实、revision 或 artifactRefs。
	 */
	/** @deprecated K3 迁移桥接入点：桥安装后走内核内存投影（观测补录，不推进 stateSeq）。 */
	recordCancelledResult(taskId: string, observation: { result?: string; sessionId?: string; model?: string }): void {
		const rec = this.tasks.get(taskId);
		if (!rec || rec.status !== "cancelled") return;
		if (this.kernelBridge) {
			this.kernelBridge.observeLegacy(taskId, "cancelledResult", observation, (r) => {
				const result = optionalString(observation.result, MAX_RESULT_BYTES);
				const sessionId = optionalString(observation.sessionId, MAX_SESSION_ID_BYTES);
				const model = optionalString(observation.model, MAX_MODEL_BYTES);
				if (result !== undefined) r.result = result;
				if (sessionId !== undefined) r.sessionId = sessionId;
				if (model !== undefined) r.model = model;
			});
			return;
		}
		const result = optionalString(observation.result, MAX_RESULT_BYTES);
		const sessionId = optionalString(observation.sessionId, MAX_SESSION_ID_BYTES);
		const model = optionalString(observation.model, MAX_MODEL_BYTES);
		if (result !== undefined) rec.result = result;
		if (sessionId !== undefined) rec.sessionId = sessionId;
		if (model !== undefined) rec.model = model;
		this.emitChange();
	}

	list(): Readonly<TaskRecord>[] { return Array.from(this.tasks.values()).map(deepFreeze); }

	/**
	 * P1-2: snapshot — 单条 round/task 文本裁剪 → 排序 → 序列化 → 硬字节校验 → 无条件满足 cap。
	 * active 超限时降级为摘要（taskId+agent+status，丢弃 rounds/model/sessionId）。
	 */
	snapshot(): any[] {
		const active: any[] = [], done: any[] = [];
		for (const r of this.tasks.values()) {
			const item: any = {
				taskId: trimUtf8(r.taskId, MAX_TASK_ID_BYTES),
				agent: trimUtf8(r.agent, MAX_AGENT_BYTES),
				sessionId: optionalString(r.sessionId, MAX_SESSION_ID_BYTES),
				// v2 批次B：节点名随 snapshot 记录；极端降级摘要不含 name（有界标识，不破硬上限）。
				name: optionalString(r.name, MAX_NAME_BYTES),
				status: r.status,
				model: optionalString(r.model, MAX_MODEL_BYTES),
				mode: r.mode,
				startedAt: isFiniteTime(r.startedAt) ? r.startedAt : Date.now(),
				endedAt: isFiniteTime(r.endedAt) ? r.endedAt : undefined,
				rounds: r.rounds ? r.rounds.slice(-MAX_SNAP_ROUNDS).map(trimRound).filter(Boolean) : undefined,
				goal: optionalString(r.goal, MAX_GOAL_BYTES),
				cwd: optionalString(r.cwd, MAX_CWD_BYTES),
				artifactRefs: stringArray(r.artifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true),
				upstreamArtifactRefs: stringArray(r.upstreamArtifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true) ?? [],
				// ev-20260909-1af2ca：白名单快照随 snapshot 持久化
				allowedPaths: stringArray(r.allowedPaths, 64, 1024),
				blockedQuestions: stringArray(r.blockedQuestions, MAX_BLOCKED_QUESTIONS, MAX_QUESTION_BYTES),
				// v1.5.223（diting Major-4）：handoff/questions 语义随 snapshot 持久化（重启后待答队列不过收 handoff）
				blockReason: blockReasonOf(r.blockReason),
				// v2 批次A 运行图字段（可选，仅编排任务携带）
				runId: optionalString(r.runId, MAX_RUN_ID_BYTES),
				parentTaskId: optionalString(r.parentTaskId, MAX_TASK_ID_BYTES),
				nodeId: optionalString(r.nodeId, MAX_NODE_ID_BYTES),
				dependsOn: stringArray(r.dependsOn, MAX_DEPENDS_ON, MAX_TASK_ID_BYTES),
				backend: VALID_BACKENDS.has(r.backend as string) ? r.backend : "json",
				revision: nonNegativeNumber(r.revision) ?? 0,
				queuedAt: nonNegativeNumber(r.queuedAt),
				queueMs: nonNegativeNumber(r.queueMs),
				// ev-20260916-101d8a：冷却展示元数据随 snapshot 持久化（旧记录无字段仍可读）
				queueReason: queueReasonOf(r.queueReason),
				retryAt: nonNegativeNumber(r.retryAt),
				cooldownUsed: r.cooldownUsed === true || undefined,
				// Wave C2：写入路径随快照持久化（running 重启后转 error，字段仍保留供审计/查询）
				lastWritePaths: stringArray(r.lastWritePaths, MAX_WRITE_PATHS, MAX_WRITE_PATH_BYTES),
				blockedAt: isFiniteTime(r.blockedAt) ? r.blockedAt : undefined,
				// C3-R4-B: answering 是尚未确认 spawn 的 blocked 过渡态；崩溃恢复需保留问题正文。
				result: r.status === "blocked" || r.status === "answering" ? optionalString(r.result, MAX_SNAPSHOT_RESULT_BYTES) : undefined,
				// ev-20260908-f189e7：外部处置收口注记随 snapshot 持久化（重启后 query_task/看板仍可解释终态来源）
				resolveNote: optionalString(r.resolveNote, MAX_META_TEXT_BYTES),
				// A4（ev-20260910-d86779）：错误类别随 snapshot 持久化（重启后看板/建议推导仍可解释终态）
				lastErrorKind: r.lastErrorKind !== undefined && VALID_ERROR_KIND.has(r.lastErrorKind) ? r.lastErrorKind : undefined,
			};
			(r.status === "running" || r.status === "answering" || r.status === "queued" ? active : done).push(item);
		}
		done.sort((a, b) => (b.endedAt || b.startedAt || 0) - (a.endedAt || a.startedAt || 0));
		let result = [...active, ...done.slice(0, MAX_SNAPSHOT_DONE)];
		const bytes = () => Buffer.byteLength(JSON.stringify(result), "utf8");
		// 先删除最旧终态；正常数量的 active 不受影响。
		while (bytes() > MAX_SNAP_BYTES && result.some((r) => r.status !== "running" && r.status !== "answering" && r.status !== "queued")) {
			const idx = result.findLastIndex((r) => r.status !== "running" && r.status !== "answering" && r.status !== "queued");
			result.splice(idx, 1);
		}
		// active 仍超限时降级为有界标识摘要。
		if (bytes() > MAX_SNAP_BYTES) {
			result = result.map((r) => ({ taskId: r.taskId, agent: r.agent, status: r.status }));
		}
		// 极端 active 数量下允许丢弃最后一条；硬上限优先于“全保留”。
		while (bytes() > MAX_SNAP_BYTES && result.length > 0) result.pop();
		if (bytes() > MAX_SNAP_BYTES) return []; // 理论兜底：[] 恒为 2 bytes
		return result;
	}

	/** P1-4: restore 顶层校验 + 逐 record 全字段 schema + replace + 预算上限 */
	restoreFromSnapshot(snapshot: any): string[] {
		const warnings: string[] = [];
		this.kernelBridge?.reset(); // K3：内核态随表复位（重建记录无内核态，后续桥写惰性重收编——K8a 收敛为对账）
		this.tasks.clear();
		this.leases.clear();
		if (!Array.isArray(snapshot)) { warnings.push("snapshot 顶层非数组，跳过恢复"); return warnings; }
		if (snapshot.length > MAX_RESTORE_ITEMS) { warnings.push(`snapshot ${snapshot.length} 条超过上限 ${MAX_RESTORE_ITEMS}，截断`); }
		const restoreStart = Date.now();
		let restoredBytes = 2; // []
		for (let idx = 0; idx < Math.min(snapshot.length, MAX_RESTORE_ITEMS); idx++) {
			if (Date.now() - restoreStart > MAX_RESTORE_MS) { warnings.push(`restore 超时 ${MAX_RESTORE_MS}ms，剩余跳过`); break; }
			const item = snapshot[idx];
			try {
				if (!item || typeof item !== "object") { warnings.push(`#${idx} 跳过非对象`); continue; }
				if (typeof item.taskId !== "string" || !item.taskId) { warnings.push(`#${idx} 跳过缺 taskId`); continue; }
				if (Buffer.byteLength(item.taskId, "utf8") > MAX_TASK_ID_BYTES) { warnings.push(`#${idx} 跳过超长 taskId`); continue; }
				if (typeof item.agent !== "string" || !item.agent) { warnings.push(`#${idx} 跳过缺 agent`); continue; }
				if (!VALID_STATUS.has(item.status)) { warnings.push(`#${idx} 跳过非法 status: ${item.status}`); continue; }
				// C3-R4-B: answering 没有可核验 child/lease；重启后保守回到待答队列。
				// v2 批次B: queued 重启时从未启动（无子进程、未占槽），恢复为 cancelled 而非 error——
				// 语义准确且与 admission 内存态一致（队列不跨重启，重启后准入重新计数）。
				const status: TaskStatus = item.status === "running" ? "error" : item.status === "answering" ? "blocked" : item.status === "queued" ? "cancelled" : item.status;
				if (item.status === "answering") warnings.push(`#${idx} answering 未确认启动，恢复为 blocked`);
				if (item.status === "queued") warnings.push(`#${idx} queued 重启时仍在队列，恢复为 cancelled`);
				const rec: TaskRecord = {
					taskId: item.taskId,
					agent: trimUtf8(item.agent, MAX_AGENT_BYTES),
					status,
					startedAt: isFiniteTime(item.startedAt) ? item.startedAt : Date.now(),
				};
				if (VALID_MODES.has(item.mode)) rec.mode = item.mode;
				const sessionId = optionalString(item.sessionId, MAX_SESSION_ID_BYTES); if (sessionId !== undefined) rec.sessionId = sessionId;
				const model = optionalString(item.model, MAX_MODEL_BYTES); if (model !== undefined) rec.model = model;
				const name = optionalString(item.name, MAX_NAME_BYTES); if (name !== undefined) rec.name = name;
				const result = optionalString(item.result, MAX_RESULT_BYTES); if (result !== undefined) rec.result = result;
				const goal = optionalString(item.goal, MAX_GOAL_BYTES); if (goal !== undefined) rec.goal = goal;
				const cwd = optionalString(item.cwd, MAX_CWD_BYTES); if (cwd !== undefined) rec.cwd = cwd;
				const artifactRefs = stringArray(item.artifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true); if (artifactRefs) rec.artifactRefs = artifactRefs;
				rec.upstreamArtifactRefs = stringArray(item.upstreamArtifactRefs, MAX_ARTIFACT_REFS, MAX_ARTIFACT_REF_BYTES, true) ?? [];
				// ev-20260909-1af2ca：白名单快照随 restore 恢复
				const allowedPaths = stringArray(item.allowedPaths, 64, 1024); if (allowedPaths) rec.allowedPaths = allowedPaths;
				const blockedQuestions = stringArray(item.blockedQuestions, MAX_BLOCKED_QUESTIONS, MAX_QUESTION_BYTES); if (blockedQuestions) rec.blockedQuestions = blockedQuestions;
				// ev-20260908-f189e7：外部处置收口注记（终态解释性字段，与 stopReason 同型恢复）
				const resolveNote = optionalString(item.resolveNote, MAX_META_TEXT_BYTES); if (resolveNote !== undefined) rec.resolveNote = resolveNote;
				// A4（ev-20260910-d86779）：错误类别随 restore 恢复（非法值静默丢弃，不阻断主流程）
				if (typeof item.lastErrorKind === "string" && VALID_ERROR_KIND.has(item.lastErrorKind)) rec.lastErrorKind = item.lastErrorKind;
				const blockReason = blockReasonOf(item.blockReason); if (blockReason) rec.blockReason = blockReason;
				const stopReason = optionalString(item.stopReason, MAX_META_TEXT_BYTES); if (stopReason !== undefined) rec.stopReason = stopReason;
				const restoredError = optionalString(item.errorMessage, MAX_META_TEXT_BYTES);
				rec.errorMessage = item.status === "running" ? "interrupted: 会话重启" : item.status === "queued" ? "cancelled: 会话重启时仍在准入队列（未启动）" : restoredError;
				if (item.signal === null) rec.signal = null;
				else { const signal = optionalString(item.signal, 64); if (signal !== undefined) rec.signal = signal; }
				if (typeof item.timedOut === "boolean") rec.timedOut = item.timedOut;
				if (typeof item.aborted === "boolean") rec.aborted = item.aborted;
				if (isFiniteTime(item.endedAt)) rec.endedAt = item.endedAt;
				if (isFiniteTime(item.blockedAt)) rec.blockedAt = item.blockedAt;
				if (Array.isArray(item.rounds)) rec.rounds = item.rounds.slice(0, MAX_SNAP_ROUNDS).map(trimRound).filter((r: RoundRecord | undefined): r is RoundRecord => !!r);
				// v2 批次A 迁移：旧 snapshot 缺 backend/revision → 默认 json/0；运行图字段经同一校验恢复。
				Object.assign(rec, sanitizeRelation(item));
				if (typeof item.queueMs === "number") { const q = nonNegativeNumber(item.queueMs); if (q !== undefined) rec.queueMs = q; }
				// ev-20260916-101d8a：冷却展示元数据随 restore 恢复（非法值静默丢弃）
				const rQueueReason = queueReasonOf(item.queueReason); if (rQueueReason) rec.queueReason = rQueueReason;
				const rRetryAt = nonNegativeNumber(item.retryAt); if (rRetryAt !== undefined) rec.retryAt = rRetryAt;
				if (item.cooldownUsed === true) rec.cooldownUsed = true;
				// Wave C2：写入路径随 restore 恢复（同 appendArtifactRef 的补录语义，不参与状态机校验）
				const lastWritePaths = stringArray(item.lastWritePaths, MAX_WRITE_PATHS, MAX_WRITE_PATH_BYTES); if (lastWritePaths) rec.lastWritePaths = lastWritePaths;
				if (status === "error" && item.status === "running" && !rec.endedAt) rec.endedAt = Date.now();
				if (status === "cancelled" && item.status === "queued" && !rec.endedAt) rec.endedAt = Date.now();
				if (this.tasks.has(rec.taskId)) { warnings.push(`#${idx} 跳过重复 taskId`); continue; }
				const recBytes = Buffer.byteLength(JSON.stringify(rec), "utf8") + 1;
				if (restoredBytes + recBytes > MAX_SNAP_BYTES) { warnings.push(`#${idx} 起超过 restore 字节预算 ${MAX_SNAP_BYTES}，剩余跳过`); break; }
				restoredBytes += recBytes;
				this.tasks.set(rec.taskId, rec);
			} catch (e) { warnings.push(`#${idx} 恢复失败: ${String(e).slice(0,80)}`); }
		}
		return warnings;
	}

	/**
	 * v1.5.222 跨进程 resume 磁盘回填：Leader 重启后 registry 为空，从磁盘 artifact 恢复的
	 * 记录收编（session-backfill.ts 供给）。与 restoreFromSnapshot 的重启语义一致：
	 * running→error（原 Leader 已死）/ queued→cancelled；仅接受终态。已存在 taskId 静默跳过
	 * （幂等）；返回收编后的记录（未收编返回 undefined）。
	 */
	/** ev-20261005-055864（diting F-02）：内核权威投影收编（resume 契约候选专用）——直接写入投影层
	 *  （tasks.set + notify），不经迁移桥/不触发 ensureAdopted 重种子/不写 store；调用方（task-resume
	 *  adoptContractProjection）保证字段来自内核 TaskView 权威（execution 原值/revision/sessionId）。
	 *  已存在记录覆盖（与桥投影 project() 的 upsert 分支同语义：重建最新内核视图）。 */
	projectFromKernel(rec: TaskRecord): Readonly<TaskRecord> {
		this.tasks.set(rec.taskId, rec);
		this.emitChange();
		return deepFreeze(rec);
	}

	adoptExternal(item: { taskId: string; agent: string; sessionId?: string; model?: string; name?: string; status: string; startedAt: number; endedAt?: number; blockedAt?: number; cwd?: string; result?: string; blockReason?: "questions" | "needs-handoff"; lastWritePaths?: string[]; allowedPaths?: string[] }): Readonly<TaskRecord> | undefined {
		try {
			if (!item || typeof item.taskId !== "string" || !item.taskId) return undefined;
			if (Buffer.byteLength(item.taskId, "utf8") > MAX_TASK_ID_BYTES) return undefined;
			if (typeof item.agent !== "string" || !item.agent) return undefined;
			if (!VALID_STATUS.has(item.status as TaskStatus)) return undefined;
			if (this.tasks.has(item.taskId)) return this.get(item.taskId) ?? undefined;
			const rec: TaskRecord = {
				taskId: item.taskId,
				agent: trimUtf8(item.agent, MAX_AGENT_BYTES),
				status: item.status as TaskRecord["status"],
				startedAt: isFiniteTime(item.startedAt) ? item.startedAt : Date.now(),
			};
			if (item.status === "running" || item.status === "answering") rec.status = "error"; // 原进程已死，非终态不可信
			if (item.status === "queued") rec.status = "cancelled";
			const sessionId = optionalString(item.sessionId, MAX_SESSION_ID_BYTES); if (sessionId !== undefined) rec.sessionId = sessionId;
			const model = optionalString(item.model, MAX_MODEL_BYTES); if (model !== undefined) rec.model = model;
			const name = optionalString(item.name, MAX_NAME_BYTES); if (name !== undefined) rec.name = name;
			const result = optionalString(item.result, MAX_RESULT_BYTES); if (result !== undefined) rec.result = result;
			if (typeof item.cwd === "string" && item.cwd) rec.cwd = item.cwd;
			const blockReason = blockReasonOf(item.blockReason); if (blockReason) rec.blockReason = blockReason;
			// Wave C2：磁盘回填同步携带写入路径（只读观测字段；回填仅收编终态，不参与冲突匹配）
			const lastWritePaths = stringArray(item.lastWritePaths, MAX_WRITE_PATHS, MAX_WRITE_PATH_BYTES); if (lastWritePaths) rec.lastWritePaths = lastWritePaths;
			// ev-20260909-1af2ca：磁盘回填同步携带白名单快照
			const allowedPaths = stringArray(item.allowedPaths, 64, 1024); if (allowedPaths) rec.allowedPaths = allowedPaths;
			if (isFiniteTime(item.endedAt)) rec.endedAt = item.endedAt;
			if (isFiniteTime(item.blockedAt)) rec.blockedAt = item.blockedAt;
			if ((rec.status === "error" || rec.status === "cancelled") && !rec.endedAt) rec.endedAt = item.endedAt ?? Date.now();
			// m-2：收编时刻登记（GC 保护窗口）——过期条目顺手清理，Map 有界
			const adoptAt = Date.now();
			for (const [id, at] of this.adoptedAt) if (adoptAt - at >= adoptGcProtectMs) this.adoptedAt.delete(id);
			this.adoptedAt.set(rec.taskId, adoptAt);
			// K5a 修复（K3 桥潜伏 bug，随统一 submit 使内核/桥安装常态化而暴露）：先把记录写入内部表再派发桥——
			// 桥 adoptRecord 的 ensureAdopted 以 registry 记录为种子源，记录缺位即抛「registry 无记录」→旧序在桥
			// 安装后 adoptExternal 恒 undefined（session-backfill 磁盘回填全哑）。先落表后桥发与直写路径的 tasks.set
			// 语义一致；内核种子（bridge seed，目录已存→degraded）与投影由桥按既有设计接管。
			this.tasks.set(rec.taskId, rec);
			if (this.kernelBridge) return this.kernelBridge.adoptExternal(rec);
			this.emitChange();
			return deepFreeze(rec);
		} catch {
			return undefined;
		}
	}

	countRunningBackground(): number {
		let n = 0; for (const r of this.tasks.values()) if (r.mode === "background" && r.status === "running") n++; return n;
	}
	getRunningChildren(): Array<{ taskId: string; child: any }> {
		const res: Array<{ taskId: string; child: any }> = [];
		for (const r of this.tasks.values()) if (r.status === "running" && r.child) res.push({ taskId: r.taskId, child: r.child });
		return res;
	}
	clear(): void { this.kernelBridge?.reset(); this.tasks.clear(); this.leases.clear(); this.adoptedAt.clear(); this.shuttingDown = false; }
}

export const registry = new TaskRegistry();
