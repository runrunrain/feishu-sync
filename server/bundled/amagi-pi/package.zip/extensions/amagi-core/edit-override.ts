/**
 * edit-override.ts — Wave B3：同名覆盖内置 edit，扩展表达力（regex / 多文件 / 错发提示）。
 *
 * 痛点（复盘 §2.2）：edit 失败 7 次，其中 5 次批量修改全部退化为 python heredoc——
 * 精确字面 oldText 对「多处同构改动」表达力不足的直接证据；且 stream.ts 的 edit 错发
 * projection.ts 时插件只报了目标文件名，模型无从自救。
 *
 * 实现策略（pi extensions.md「Overriding Built-in Tools」官方模式，bash-override 同构）：
 *  - 非 regex 单文件路径：**先委托原生** createEditToolDefinition(cwd).execute（BOM/行尾/
 *    fuzzy 匹配/重叠检测/diff/patch/withFileMutationQueue 全走原生路径，成功行为与原生一致）；
 *    原生失败时进入 recover——直接复用 edit-guard.ts 导出的 locateEdit/editGuardReason：
 *    形态差异唯一命中 → 按文件真实原文改写 oldText 自愈重试一次；歧义/未命中 → 拒绝并给出
 *    真实片段诊断（+ 错发提示）。先委托的原因：原生 fuzzy（行尾空白/弯引号/Unicode 连字符）
 *    与 locateEdit 归一化（CRLF/全角空格/NFC）覆盖面互不包含，预检 strict 化会误伤原生
 *    本可成功的编辑；失败后增强则只有收益没有回归。event 链上的 registerEditGuard 注册
 *    保持不动（对 path 形态入参零干预，不冲突：若其在某 pi 版本生效则执行前拦截，语义一致）。
 *  - edits[].regex: true：oldText 为正则源（仅 'm' 语义：^/$ 按行边界，固定启用，无其他
 *    flags），newText 支持 $1-$9/$&/$$。匹配空间为「去 BOM + LF 归一」文本（与原生匹配
 *    空间一致，解析出的字面 oldText 委托原生后必然精确命中）。匹配数必须恰 1：
 *    0 → 拒绝 + edit-guard 最近窗口诊断；N → 拒绝 + 各匹配行首与行号；非法 → 拒绝 + 原文。
 *    防爆炸：regex 总替换长度（被替换 span 之和）≤100KB。混合调用中非 regex 项尽力自愈、
 *    否则原样透传交原生裁决（原生失败统一走 recover 增强）。
 *  - files: string[]（与 path 互斥）：同一组 edits 逐文件独立解析与应用。两阶段：先全量
 *    校验（读文件 + 解析 edits），任一文件校验失败 → 所有文件零写入（重跑同参数幂等）；
 *    校验全过再逐文件写入，写入阶段中途失败 → 已写入文件保留改动（不回滚、明确标注），
 *    其后文件中止未写。整体 isError 且汇总列明各文件状态（成功行「f.ts: 2/2 edits」）。
 *  - 跨文件错发检测：会话内跟踪最近 read 的文件（tool_execution_start 事件，容量 ≤10
 *    LRU，去重最新优先）。目标文件 not-found（经 edit-guard 确认非形态差异）或目标不可读
 *    时，若 oldText 在某近期 read 文件中唯一命中 → 诊断追加
 *    「oldText 在近期读过的 <file> 中唯一存在，是否想编辑它？」。
 *  - renderCall/renderResult 省略 → 继承内置渲染（含 diff 预览；regex 调用的预览按字面
 *    匹配会短暂显示未命中，属纯 UI 预览，执行结果落地后即修正）。
 *    提示与渲染元数据继承原生定义，仅追加 regex/files 能力说明。
 *  - 错误以 throw 表达（pi agent-loop 对成功返回一律 isError:false，原生 edit 同口径）。
 *
 * 0.85.1 原生返回契约（H3 复核，dist/core/tools/edit.d.ts EditToolDetails + edit.js execute 实证）：
 *  - details 是单对象 {diff, patch, firstChangedLine?}——非数组；成功 content 为
 *    「Successfully replaced N block(s) in <path>.」；失败 throw。
 *  - delegateNative 将原生返回原样透传（单文件模式含自愈重试均如此）；多文件模式聚合
 *    同形态 {diff（── file ── 分隔）, patch, firstChangedLine}；edit-diagnostics.attach 浅克隆
 *    仅替换 content[0].text，details 原样保留。regex/多文件预检语义不变（详见 tests/v2-H3-native）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { createEditToolDefinition, type EditOperations } from "@earendil-works/pi-coding-agent";
import { builtinFileCwd, resolveBuiltinFileTarget, resolveBuiltinReadTarget } from "./builtin-file-target.ts";
import { locateEdit, editGuardReason, headingDeletionReasons, coalesceEditTargets } from "./edit-guard.ts";
import { checkHeadingDeletion, headingDeletionDisclosure } from "./edit-guard.ts";
import { guardRuleOf, guardProjectTrustedOf, guardRegexReplaceBytesLimitOf } from "./guard-policy.ts";
import { fsMutationRaceHint } from "./fs-mutation-tracker.ts";
import { enforceFileWriteTargets, failStrictTaskStartup, strictEnforcementActive, fileReadPermissionBlockReason, getActiveFilePermissionEnforcer } from "./file-permission.ts";
import { enforceLargeEditEmission } from "./large-emission-guard.ts";
import { recordTaskWrite } from "./task-write-log.ts";
import { resolveBuiltinConstrainedSampling } from "./host-capabilities.ts";
import { isPosixStyleAbsolutePath, posixToWindowsVisible, probeBashRuntime } from "./runtime-env.ts";
import { resolveEditPatch, normalizeEditPatchOptions, EDIT_PATCH_GUIDELINE } from "./edit-patch.ts";
import { defaultEditSnapshots, recordEditingRegistration, composeSelection, normalizeSelectionOptions, validateSelectionInput, snapshotScope, snapshotNotice, snapshotText, type EditSelection, type EditSnapshot, type EditSnapshotStore } from "./edit-snapshot.ts";
import { canRecoverEdit, classifyEditFailure, EditFailure, type EditWriteState } from "./edit-recovery.ts";

// ── 常量 ────────────────────────────────────────────────────────────────────

/** regex 总替换长度（被替换 span 之和）上限：100KB。 */
const MAX_REGEX_REPLACE_BYTES = 100 * 1024;
/** N 命中诊断最多列出的匹配行数。 */
const MAX_REGEX_MATCH_LIST = 10;
/** 匹配计数早停上限（防海量命中撑爆诊断）。 */
const MAX_REGEX_MATCH_SCAN = 51;
/** 错发跟踪的近期 read 文件容量（LRU）。 */
export const RECENT_READ_CAPACITY = 10;

const REGEX_GUIDELINE = "Leave regex unset for ordinary code/text, including CSS selectors and locator calls. Use edits[].regex: true only for an intentional regex pattern (multiline 'm': ^/$ are line anchors, not whole-file anchors); it must match exactly once. newText then supports $1-$9 backreferences. Prefer patch with surrounding context for repeated lines; never use whole-file regex to append or rewrite a file.";
const FILES_GUIDELINE = "edit 多文件模式：传 files: string[] 把同一组 edits 独立应用到每个文件；path/files 同时指向同一目标时自动归一为单文件，真实目标不同仍互斥。先全量校验再写入，任一文件校验失败则所有文件零写入，汇总逐文件列明「f.ts: 2/2 edits」状态。";

const schema = Type.Object({
	path: Type.Optional(Type.String({ description: "Path to the file to edit (relative or absolute). Redundant path/files naming the same target are accepted; different targets conflict." })),
	files: Type.Optional(Type.Array(Type.String(), { description: "Multiple files: apply the same edits to each file independently (at least 1). Redundant path/files naming the same target are accepted. Validation happens for all files before anything is written." })),
	patch: Type.Optional(Type.String({description: "Single-file Codex-style update diff: @@ then space/-/+ lines. Use with path; mutually exclusive with edits/files. No file headers or full-patch wrappers."})),
	selection: Type.Optional(Type.Object({ snapshotId: Type.String(), startLine: Type.Integer({ minimum: 1 }), endLine: Type.Integer({ minimum: 1 }) }, { description: "Whole-line range from a fully shown read({editReference:true}) or failure candidate. Snapshot coordinates; file must remain byte-identical. Mutually exclusive with edits/patch/files." })),
	newText: Type.Optional(Type.String({ description: "Replacement for selection only; no oldText needed. Non-EOF whole-line replacement must end with a newline, or be empty to delete." })),
	edits: Type.Optional(Type.Array(
		Type.Object({
			oldText: Type.String({ description: "Exact text for one targeted replacement (or regular expression source when regex: true)." }),
			newText: Type.String({ description: "Replacement text for this targeted edit (supports $1-$9 backreferences when regex: true)." }),
			regex: Type.Optional(Type.Boolean({ description: "true: treat oldText as a regular expression source (multiline; exactly one match required)." })),
		}),
		{ description: "One or more targeted replacements. Each edit is matched against the original file, not incrementally. Do not include overlapping or nested edits." },
	)),
});

export interface EditOverrideInput {
	path?: string;
	files?: string[];
	patch?: string;
	selection?: EditSelection;
	newText?: string;
	edits?: Array<{ oldText: string; newText: string; regex?: boolean }>;
}
type ReplacementInput = EditOverrideInput & {edits: NonNullable<EditOverrideInput["edits"]>};

// ── 纯函数：regex 解析与诊断 ────────────────────────────────────────────────

/** 去 BOM + LF 归一（与原生 edit 匹配空间一致：stripBom + normalizeToLF）。 */
function toMatchSpace(text: string): string {
	const body = text.startsWith("\uFEFF") ? text.slice(1) : text;
	return body.replace(/\r\n?/g, "\n");
}

/** 收集全部匹配（计数早停防海量命中）；over=true 表示命中数已达扫描上限（实际 ≥ matches.length）。 */
function collectMatches(re: RegExp, text: string): { matches: RegExpMatchArray[]; over: boolean } {
	const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
	const matches: RegExpMatchArray[] = [];
	let over = false;
	for (const m of text.matchAll(g)) {
		matches.push(m);
		if (matches.length >= MAX_REGEX_MATCH_SCAN) { over = true; break; }
	}
	return { matches, over };
}

/** 行号（1 基）与行首文本（截 120 字符），基于匹配所在文本空间。 */
function matchLineInfo(text: string, index: number): { line: number; head: string } {
	const before = text.slice(0, index);
	const line = before.split("\n").length;
	const lines = text.split("\n");
	const head = (lines[line - 1] ?? "").slice(0, 120).trimEnd();
	return { line, head };
}

/** 展开 $1-$9 / $& / $$（未参与匹配的组展开为空串）。 */
function expandReplacement(template: string, m: RegExpMatchArray): string {
	return template.replace(/\$(\$|&|[1-9])/g, (_all, tok: string) => {
		if (tok === "$") return "$";
		if (tok === "&") return m[0];
		const v = m[Number(tok)];
		return v === undefined ? "" : v;
	});
}

interface ResolvedEdit { oldText: string; newText: string }

/** 全量计数（无早停；诊断用，受文件规模约束）。 */
function countAll(haystack: string, needle: string): number {
	if (!needle) return 0;
	let count = 0, idx = 0;
	while ((idx = haystack.indexOf(needle, idx)) !== -1) { count++; idx += needle.length; }
	return count;
}

interface FileResolution {
	/** 解析后的字面 edits（regex → 唯一命中的字面片段；非 regex → 原样或自愈后的原文；标题吞噬项被拒绝不产出）。 */
	edits: ResolvedEdit[];
	/** 拒绝原因（非空 → 该文件不写）。 */
	reasons: string[];
	/** 非 regex 且真 not-found（非形态差异）的 oldText，供错发检测。 */
	notFoundOldTexts: string[];
	/** B4·批B（D7/D8 disclose）：放行披露（标题删除行范围/regex 超阈值字节数——成功写入后附加到结果）。 */
	disclosures: string[];
}

/** 行范围（1 基）：needle 在 space 中首次命中的起止行（唯一性由 resolveEditsForFile 上游保证）。 */
function lineRangeOfSpace(space: string, needle: string): { start: number; end: number } | undefined {
	const idx = space.indexOf(needle);
	if (idx < 0) return undefined;
	const start = space.slice(0, idx).split("\n").length;
	return { start, end: start + needle.split("\n").length - 1 };
}

/** 非 regex 项的三种口径：passthrough（尽力自愈、否则原样，交原生裁决）；strict（未命中/歧义 → reason，recover 诊断用）；strict-unique（strict + 多处命中也 reason，files 校验用——保证零写入契约）。 */
type LiteralMode = "passthrough" | "strict" | "strict-unique";

/**
 * 对单个文件解析整组 edits（在「去 BOM + LF 归一」匹配空间上）：
 * regex → 恰 1 命中才产出字面替换（0/N/非法/零宽/超限 → reason）；
 * 非 regex → edit-guard 兼容（healed-unique 自愈 / exact-multi 放行交原生报非唯一；
 * ambiguous、not-found 按 literalMode 决定 reason 或透传）。在 LF 归一空间上定位，
 * 避免 CRLF 行尾在 locateEdit 行窗口比较中的假阴性。
 */
export function resolveEditsForFile(
	absFile: string,
	space: string,
	edits: NonNullable<EditOverrideInput["edits"]>,
	literalMode: LiteralMode,
	opts?: { cwd?: string; projectTrusted?: boolean },
): FileResolution {
	const base = path.basename(absFile);
	const out: ResolvedEdit[] = [];
	const reasons: string[] = [];
	const notFoundOldTexts: string[] = [];
	const disclosures: string[] = [];
	let regexSpanTotal = 0;
	// B4·批B（D7/D8）：rule 值经 guard-policy 投影（与 /amagi config explain 同源；opts 缺省
	// process.cwd()/无 trust——项目层不消费，全局层与 env 归一照常生效）。阈值同源（limits.regexReplaceBytes）。
	const ruleCwd = opts?.cwd ?? process.cwd();
	const ruleTrust = opts?.projectTrusted;
	const headingDisclose = guardRuleOf("edit.headingDeletion", ruleCwd, ruleTrust) === "disclose";
	const spanLimit = guardRegexReplaceBytesLimitOf(ruleCwd, ruleTrust);
	const spanDisclose = guardRuleOf("edit.regexSpan", ruleCwd, ruleTrust) === "disclose";
	// A1（ev-20260921-2e6b4f）：解析成实际字面编辑后才做标题检查（写入前；regex 的 oldText 是
	// pattern 源，直接查会漏判）。markdown 目标上疑似误吞标题 → 该条拒绝不产出（files 模式即
	// 该文件校验失败 → 全体零写入）。本函数不修改入参 edits——每文件从原始输入独立解析，
	// 禁止为文件 A 自愈而原地改写共享 edits 使文件 B 错配。
	const pushResolved = (index: number, oldText: string, newText: string): void => {
		// B4B 修复轮 R04：Markdown 目标限定恢复——headingDeletionReasons 只对 .md/.markdown/.mdx
		// 检出（非 Markdown 目标恒空数组）；reasons 为空（含非 MD 与无删除）一律照常产出，
		// 仅在确有 block reason 时拒绝（拒绝必带真实 reason，不静默丢弃编辑）。
		const hr = headingDeletionReasons(absFile, [{ index, oldText, newText }]);
		if (hr.length > 0) {
			if (headingDisclose) {
				// B4·批B（D7 disclose）：收集披露（含行范围）后照常产出——写入由成功路径附加说明；
				// block 模式保持既有整条拒绝（文件级零写入契约不变）。
				disclosures.push(headingDeletionDisclosure(absFile, index, checkHeadingDeletion(oldText, newText).deletedHeadings, lineRangeOfSpace(space, oldText)));
			} else {
				reasons.push(...hr);
				return;
			}
		}
		out.push({ oldText, newText });
	};
	for (let i = 0; i < edits.length; i++) {
		const e = edits[i];
		if (typeof e?.oldText !== "string" || typeof e?.newText !== "string") {
			reasons.push(`[amagi edit-override] ${base} edits[${i}]：oldText/newText 必须是字符串（收到 oldText:${typeof e?.oldText} newText:${typeof e?.newText}）`);
			continue;
		}
		if (e.regex === true) {
			let re: RegExp;
			try { re = new RegExp(e.oldText, "m"); }
			catch (err) {
				reasons.push(`[amagi edit-override] ${base} edits[${i}]：regex 非法（${err instanceof Error ? err.message : String(err)}）。oldText 原文：${e.oldText}`);
				continue;
			}
			const { matches, over } = collectMatches(re, space);
			if (matches.length === 0) {
				// 0 命中：沿用 edit-guard 最近窗口诊断（首行词锚粗筛，把目标位置真实内容喂到嘴边）
				let nearby = "";
				try {
					const loc = locateEdit(space, e.oldText);
					if (loc.nearby) nearby = `\n最接近位置（第 ${loc.nearby.line} 行附近）——若此处即目标，按真实内容修正 pattern 或改用字面 oldText：\n${loc.nearby.text}`;
				} catch { /* 诊断增强失败不影响主诊断 */ }
				reasons.push(`[amagi edit-override] ${base} edits[${i}]：regex 在文件中 0 处命中（必须恰 1 处）。oldText 原文：${e.oldText}${space.includes(e.oldText) ? "\n原文按字面确实存在：这是 regex 解释失配，普通代码/选择器请省略 regex，按字面替换。" : ""}${nearby}`);
				continue;
			}
			if (over || matches.length > 1) {
				const listed = matches.slice(0, MAX_REGEX_MATCH_LIST).map((m) => {
					const { line, head } = matchLineInfo(space, m.index ?? 0);
					return `  L${line}: ${head}`;
				});
				const count = over ? `≥${matches.length}` : `${matches.length}`;
				const more = matches.length > MAX_REGEX_MATCH_LIST ? `\n  …（命中过多，仅列前 ${MAX_REGEX_MATCH_LIST} 处）` : "";
				reasons.push(`[amagi edit-override] ${base} edits[${i}]：regex 命中 ${count} 处（必须恰 1 处才能替换）。\n${listed.join("\n")}${more}\n收窄 pattern 使其唯一命中（加 ^/$ 行锚或上下文捕获组），或改用字面 oldText。oldText 原文：${e.oldText}`);
				continue;
			}
			const m = matches[0];
			if ((m[0] ?? "").length === 0) {
				reasons.push(`[amagi edit-override] ${base} edits[${i}]：regex 命中零宽匹配（空串），零宽替换不被支持；请收窄 pattern 使其匹配至少 1 个字符，或改用字面 oldText。oldText 原文：${e.oldText}`);
				continue;
			}
			regexSpanTotal += Buffer.byteLength(m[0], "utf8");
			if (regexSpanTotal > spanLimit) {
				if (spanDisclose) {
					// B4·批B（D8 disclose）：唯一非零匹配契约与权限校验不变；超阈值只披露（字节数/行范围）
					// 照常产出——贪婪 regex 误吞风险由披露+diff 呈现，不再硬拒。
					const { line } = matchLineInfo(space, m.index ?? 0);
					disclosures.push(`[amagi guard:edit.regexSpan｜已放行] ${base} edits[${i}]：regex 总替换长度 ${regexSpanTotal} 字节超过阈值 ${spanLimit}（约 ${Math.round(spanLimit / 1024)}KB）。检测事实：唯一非零匹配（恰 1 命中契约与权限校验照常执行），替换起于 L${line}；推测：贪婪 pattern 可能误吞比预期更大的段落——请核对本次结果 diff 的删除范围是否符合意图。恢复路径：diff 含被替换原文（用户认可后可据此反向恢复）。配置：阈值经 guards.limits.regexReplaceBytes 有界调整；rule 可收紧回 block（来源见 /amagi config explain）。`);
				} else {
					reasons.push(`[amagi edit-override] ${base}：regex 总替换长度 ${regexSpanTotal} 字节超过 ${spanLimit}（约 ${Math.round(spanLimit / 1024)}KB）上限，已整体拒绝（防贪婪 pattern 吞掉大段文件）。edits[${i}] oldText 原文：${e.oldText}`);
					continue;
				}
			}
			pushResolved(i, m[0], expandReplacement(e.newText, m));
			continue;
		}
		// 非 regex：edit-guard 兼容（逻辑复用，不复制；在 LF 归一空间上定位）
		try {
			const res = locateEdit(space, e.oldText);
			if (res.status === "healed-unique" && res.healedText !== undefined) {
				pushResolved(i, res.healedText, e.newText); // 仅形态自愈，内容零改动
				// ev-20261005-109214：转义层级自愈不静默——收集注记（重试成功后附结果，意图错配可核对）
			} else if (res.status === "ambiguous" || res.status === "not-found") {
				if (literalMode === "passthrough") {
					pushResolved(i, e.oldText, e.newText); // 透传：原生 fuzzy 可能仍命中，失败统一走 recover
				} else {
					// ev-20260905-4c9d82③：补传 e.oldText——editGuardReason 的 firstDiff 首差异定位与
					// 超长行逃生通道（v1.5.260 已实现）在此主路径因缺参而失效（实战：Tab 缩进差异无诊断）。
					reasons.push(editGuardReason(absFile, i, res, e.oldText));
					if (res.status === "not-found") notFoundOldTexts.push(e.oldText);
				}
			} else if (res.status === "exact-multi" && literalMode === "strict-unique") {
				reasons.push(`[amagi edit-override] ${base} edits[${i}]：oldText 在文件中出现 ${countAll(space, e.oldText)} 处（必须唯一）——用 read 查看目标后扩大上下文使其唯一，或改用 edits[].regex。`);
			} else {
				pushResolved(i, e.oldText, e.newText); // exact-unique / exact-multi（后者原生报非唯一）
			}
		} catch {
			pushResolved(i, e.oldText, e.newText); // 单条校验异常放行原生语义（edit-guard 同口径）
		}
	}
	return { edits: out, reasons, notFoundOldTexts, disclosures };
}

// ── 近期 read 跟踪（错发检测） ──────────────────────────────────────────────

/** ev-20260901-91d4ae：读取/执行错误是否为 ENOENT（文件不存在）——code 优先，文本兜底。 */
function isEnoentLike(e: unknown): boolean {
	if (e && typeof e === "object" && (e as NodeJS.ErrnoException).code === "ENOENT") return true;
	return /ENOENT/.test(e instanceof Error ? e.message : String(e ?? ""));
}

/** 会话内最近 read 的文件 LRU（绝对路径、最新优先、去重、容量 ≤capacity）。 */
export function createRecentReadTracker(cwd: string = process.cwd(), capacity: number = RECENT_READ_CAPACITY) {
	const order: string[] = [];
	return {
		observe(event: { toolName?: string; args?: unknown }, ctx?: unknown): void {
			if (event?.toolName !== "read") return;
			const args = event.args as { path?: unknown } | undefined;
			const p = args && typeof args.path === "string" ? args.path : "";
			if (!p) return;
			let abs: string;
			try { abs = resolveBuiltinReadTarget(p, builtinFileCwd(cwd, ctx)); } catch { return; }
			const idx = order.indexOf(abs);
			if (idx === 0) return; // 已是最新
			if (idx > 0) order.splice(idx, 1);
			order.unshift(abs);
			if (order.length > capacity) order.length = capacity;
		},
		snapshot(): string[] {
			return [...order];
		},
	};
}
export type RecentReadTracker = ReturnType<typeof createRecentReadTracker>;

// ── 工具工厂 ────────────────────────────────────────────────────────────────

export interface EditOverrideDeps {
	snapshots?: EditSnapshotStore;
	/** Public native filesystem operations, also used for deterministic failure/race tests. */
	operations?: EditOperations;
	/** 工作目录（path/files 相对解析基准）。 */
	cwd?: string;
	/** 近期 read 文件（绝对路径、最新优先）；缺省空集（registerEditOverrideTool 自动接线跟踪器）。 */
	recentReads?: () => string[];
	/** 测试注入读取器。 */
	readFile?: (p: string) => string;
	/** 诊断输出（缺省 console.warn；传 null 静音）。 */
	diag?: ((msg: string) => void) | null;
	/** P1-D（插件进化8.19）：成功写盘后的 LSP 诊断注入器（可选；缺省无注入，行为与 B3 一致）。 */
	editDiagnostics?: { attach(result: unknown, files: string[]): Promise<unknown> };
	/** ev-20260925-287e93：宿主平台注入（测试；缺省 process.platform）。 */
	hostPlatform?: string;
}

/** 创建覆盖内置 edit 的同名工具：schema 增加 edits[].regex 与 files；省略 renderCall/renderResult 以继承内置渲染。 */
export function createEditOverrideTool(baseCwd: string = process.cwd(), deps: EditOverrideDeps = {}) {
	const baseDef = createEditToolDefinition(baseCwd);
	const snapshots = deps.snapshots ?? defaultEditSnapshots;
	const operations: EditOperations = deps.operations ?? { access: file => fs.promises.access(file, fs.constants.R_OK | fs.constants.W_OK),
		readFile: file => fs.promises.readFile(file), writeFile: (file, content) => fs.promises.writeFile(file, content, "utf8") };
	const scopeAt = (ctx: unknown) => snapshotScope(builtinFileCwd(baseCwd, ctx), ctx, getActiveFilePermissionEnforcer());
	const requireRead = (file: string, ctx: unknown) => {
		const reason = fileReadPermissionBlockReason(builtinFileCwd(baseCwd, ctx), file, false);
		if (reason) throw new EditFailure("permission", reason);
	};
	const read = deps.readFile ?? ((p: string) => fs.readFileSync(p, "utf8"));
	const diag = deps.diag === null ? undefined : deps.diag ?? ((m: string) => console.warn(m));
	const recentReads = deps.recentReads ?? (() => []);
	const resolveAbs = (p: string, ctx?: unknown) => resolveBuiltinFileTarget(p, builtinFileCwd(baseCwd, ctx));
	// P1-D：成功写盘后的诊断注入——只包成功返回（失败路径 throw 不经过此处）；注入器缺席/内部
	// 失败均原样返回，绝不阻断写入路径（edit-override 主语义零变化）。
	const attachDiag = async (r: unknown, files: string[], ctx?: unknown): Promise<unknown> => {
		const injector = deps.editDiagnostics;
		if (!injector) return r;
		try { return await injector.attach(r, files.map((f) => resolveAbs(f, ctx))); } catch { return r; }
	};

	const delegateNative = async (
		toolCallId: string,
		filePath: string,
		edits: ResolvedEdit[],
		signal: AbortSignal | undefined,
		onUpdate: ((partial: unknown) => void) | undefined,
		ctx: unknown,
		expected?: { snapshot: EditSnapshot; bytes: Buffer; target: string },
	) => {
		let writeState: EditWriteState = "not-written";
		const native = createEditToolDefinition(baseCwd, { operations: {
			access: file => operations.access(file),
			readFile: async file => {
				if (expected) requireRead(file, ctx);
				const bytes = await operations.readFile(file);
				if (expected) { requireRead(file, ctx); snapshots.verify(expected.snapshot, expected.target, bytes, scopeAt(ctx)); }
				return bytes;
			},
			writeFile: async (file, content) => {
				if (expected) {
					enforceFileWriteTargets(builtinFileCwd(baseCwd, ctx), [file, expected.target]); requireRead(file, ctx); requireRead(expected.target, ctx);
					snapshots.verify(expected.snapshot, expected.target, await operations.readFile(file), scopeAt(ctx));
					if (!Buffer.from(content).equals(expected.bytes)) throw new EditFailure("unsupported-content", "原生结果与预期字节不一致；未写入。");
				}
				if (signal?.aborted) throw new EditFailure("aborted", "Operation aborted");
				writeState = "unknown"; // an I/O exception can occur after a partial write
				await operations.writeFile(file, content);
				writeState = "written";
				// A later abort can still make native execute throw; attribute the completed write now.
				recordTaskWrite(resolveAbs(filePath, ctx), "edit");
			},
		} });
		let r: Awaited<ReturnType<typeof native.execute>>;
		try { r = await native.execute(toolCallId, { path: filePath, edits: edits.map((e) => ({ oldText: e.oldText, newText: e.newText })) }, signal, onUpdate as never, ctx as never); }
		catch (error) {
			const failure = classifyEditFailure(error, writeState); snapshots.recordFailure(failure.code);
			if (failure.code === "ambiguous") throw new EditFailure(failure.code, `${failure.message}\n可使用 {path, patch} 的 @@ 修改块加入目标附近上下文来区分重复行；普通文本不需要改成 regex。`, writeState);
			throw failure;
		}
		return r;
	};

	/** B4·批B：成功结果追加披露段（浅克隆替换 content[0].text——与 attachDiag 的 appendSection
	 *  均为纯追加，互不覆盖；无 text 首条目时静默跳过，不改变原生返回结构）。 */
	const appendDisclosures = (r: unknown, notes: string[]): unknown => {
		if (notes.length === 0) return r;
		const res = r as { content?: Array<{ type?: string; text?: string }> };
		if (!Array.isArray(res?.content) || res.content.length === 0) return r;
		const first = res.content[0];
		if (first?.type !== "text" || typeof first.text !== "string") return r;
		const content = [...res.content];
		content[0] = { ...first, text: `${first.text}\n\n${notes.join("\n\n")}` };
		return { ...res, content };
	};

	/** 错发检测：oldText 在近期 read 的某文件中唯一命中（精确或归一化唯一）→ 返回该文件，否则 null。 */
	const findRecentUniqueHit = (oldText: string, targetAbs: string, ctx: unknown): string | null => {
		for (const f of recentReads()) {
			const abs = resolveAbs(f, ctx);
			if (abs === targetAbs) continue; // 目标自身不算错发线索
			let text: string;
			try { requireRead(abs, ctx); text = read(abs); } catch { continue; }
			try {
				const res = locateEdit(toMatchSpace(text), oldText);
				if (res.status === "exact-unique" || res.status === "healed-unique") return abs;
			} catch { /* 跳过该文件 */ }
		}
		return null;
	};

	/** 对一组 not-found oldText 生成（至多一条）错发提示。 */
	const misTargetHint = (oldTexts: string[], targetAbs: string, ctx: unknown): string | null => {
		for (const oldText of oldTexts) {
			const hit = findRecentUniqueHit(oldText, targetAbs, ctx);
			if (hit !== null) {
				return `[amagi edit-override] 疑似错发：oldText 在近期读过的 ${hit} 中唯一存在，是否想编辑它？`;
			}
		}
		return null;
	};

	/**
	 * 原生失败后的增强恢复：strict 定位非 regex 项——
	 * 有 reason → edit-guard 诊断（+错发提示）；全部自愈 → 自愈后重试一次；
	 * 无 reason 无自愈（duplicate/overlap/no-change 等原生裁决）→ 原生错误原样。
	 */
	const recoverNativeFailure = async (
		toolCallId: string,
		filePath: string,
		edits: NonNullable<EditOverrideInput["edits"]>,
		err: unknown,
		signal: AbortSignal | undefined,
		onUpdate: ((partial: unknown) => void) | undefined,
		ctx: unknown,
	) => {
		const abs = resolveAbs(filePath, ctx);
		if (!canRecoverEdit(err)) {
			// Missing-path hints are read-only diagnostics, never a retry or candidate reference.
			if (err instanceof EditFailure && err.code === "io" && err.writeState === "not-written" && isEnoentLike(err)) {
				const hints = [misTargetHint(edits.map(e => e.oldText).filter(Boolean), abs, ctx), fsMutationRaceHint(abs)].filter(Boolean);
				if (hints.length) throw new EditFailure(err.code, `${err.message.replace(/^\[amagi edit:[^\]]+\] /, "")}\n${hints.join("\n")}`, err.writeState);
			}
			throw err;
		}
		let space: string;
		let raw: string;
		try {
			requireRead(abs, ctx);
			raw = read(abs);
			space = toMatchSpace(raw);
		} catch (readErr) {
			// 目标不可读（多半 ENOENT）：保留原生错误；oldText 在近期 read 文件唯一命中 → 追加错发提示；
			// ev-20260901-91d4ae：ENOENT × 近 60s 内 bash mv/rm 影响过该路径 → 追加同轮并行竞态提示
			const hints = [
				misTargetHint(edits.map((e) => (typeof e?.oldText === "string" ? e.oldText : "")).filter(Boolean), abs, ctx),
				isEnoentLike(readErr) ? fsMutationRaceHint(abs) : null,
			].filter(Boolean).join("\n");
			if (hints && err instanceof Error) throw new Error(`${err.message}\n${hints}`);
			throw err;
		}
		const resolution = resolveEditsForFile(abs, space, edits, "strict", { cwd: builtinFileCwd(baseCwd, ctx), projectTrusted: guardProjectTrustedOf(ctx) });
		if (resolution.reasons.length > 0) {
			diag?.(`[amagi edit-override] ${path.basename(abs)}：原生失败后定位到 ${resolution.reasons.length} 处 edit 无法定位，改报 edit-guard 诊断`);
			const hint = misTargetHint(resolution.notFoundOldTexts, abs, ctx);
			const candidates: string[] = [];
			for (const edit of edits.slice(0, 3)) {
				if (edit.regex) continue;
				const located = locateEdit(space, edit.oldText);
				if (located.candidateStatus !== "unique" || (located.candidateStartOffset ?? 0) !== 0 || !located.candidateStartLine) continue;
				try {
					const parsed = snapshotText(Buffer.from(raw));
					const start = located.candidateStartLine, end = start + edit.oldText.replace(/\r\n?/g, "\n").split("\n").length - 1;
					const shown = parsed.lines.slice(start - 1, end).join("");
					if (Buffer.byteLength(shown) > 8192) continue;
					const snapshot = snapshots.issue(abs, Buffer.from(raw), scopeAt(ctx), start, end);
					candidates.push(`候选真实整行（需核对目标，不自动应用）：\n${shown}\n${snapshotNotice(snapshot)}`);
				} catch (error) { if (!(error instanceof EditFailure)) throw error; }
			}
			throw new EditFailure("not-found", [resolution.reasons.join("\n\n"), hint, ...candidates].filter(Boolean).join("\n\n"));
		}
		const healed = resolution.edits.some((r, i) => edits[i]?.regex !== true && r.oldText !== edits[i]?.oldText);
		if (healed) {
			// 形态差异自愈：按文件真实原文重写 oldText 后重试一次（重试失败则报重试错误）。
			// ev-20261005-109214（diting quick F1/F3）：转义层级命中不在此路径——已降为 escape-level
			// 诊断候选（editGuardReason 专用分支，零写入）；本分支仅空白形态自愈（既有语义不变）。
			// B4·批B：自愈重试成功后同样附加披露（与主路径同文案）。
			return appendDisclosures(await delegateNative(toolCallId, filePath, resolution.edits, signal, onUpdate, ctx), resolution.disclosures);
		}
		if (err instanceof Error && /Found \d+ occurrences/.test(err.message)) throw new Error(`${err.message}\n可使用 {path, patch} 的 @@ 修改块加入目标附近上下文来区分重复行；普通文本不需要改成 regex。`);
		throw err;
	};

	const applySelection = async (toolCallId: string, input: EditOverrideInput, signal: AbortSignal | undefined, onUpdate: ((partial: unknown) => void) | undefined, ctx: unknown) => {
		const selection = validateSelectionInput(input as unknown as Record<string, unknown>);
		const cwd = builtinFileCwd(baseCwd, ctx), abs = resolveAbs(input.path!, ctx);
		enforceFileWriteTargets(cwd, [abs]); requireRead(abs, ctx);
		const snapshot = snapshots.resolve(abs, selection, scopeAt(ctx));
		const composed = composeSelection(snapshot, selection, input.newText!);
		enforceLargeEditEmission(abs, input.newText!, cwd);
		const heading = checkHeadingDeletion(composed.selectedOldText, input.newText!);
		const reasons = headingDeletionReasons(abs, [{ index: 0, oldText: composed.selectedOldText, newText: input.newText! }]);
		if (reasons.length && guardRuleOf("edit.headingDeletion", cwd, guardProjectTrustedOf(ctx)) !== "disclose") throw new EditFailure("permission", reasons.join("\n\n"));
		// Canonical paths share the native per-file queue, including calls through different symlinks.
		const result = await delegateNative(toolCallId, snapshot.canonicalPath, [{oldText: composed.oldText, newText: composed.newText}], signal, onUpdate, ctx, {snapshot, bytes: composed.expectedBytes, target: abs});
		return appendDisclosures(result, reasons.length ? [headingDeletionDisclosure(abs, 0, heading.deletedHeadings, {start: selection.startLine, end: selection.endLine})] : []);
	};

	/** 单文件路径：无 regex → 先委托原生（成功行为与原生一致），失败走 recover；有 regex → 预解析（恰 1 命中等语义）后委托。
	 *  P2（方案 §5.2 write/edit 通道）：任何原生委托/预解析之前先做执行前权限校验（目标越界 → throw 零写入；
	 *  权限只校验目标，oldText 匹配/fuzzy 自愈逻辑零干预——合法 fuzzy edit 不误伤）。 */
	const applySingleFile = async (
		toolCallId: string,
		filePath: string,
		input: ReplacementInput,
		signal: AbortSignal | undefined,
		onUpdate: ((partial: unknown) => void) | undefined,
		ctx: unknown,
	) => {
		const cwd = builtinFileCwd(baseCwd, ctx);
		const abs = resolveAbs(filePath, ctx);
		enforceFileWriteTargets(cwd, [abs]);
		// v2.15.0 大发射守卫（工具层硬闸）：逐段 edits[].newText 超限 throw（oldText 不罚——锚点原文
		// 由既有文件决定；任何原生委托/自愈重试之前执行 → 零写入；files 多文件模式在 applyFilesMode
		// 同款整单预检）。
		for (const e of input.edits) {
			if (typeof e?.newText === "string") enforceLargeEditEmission(abs, e.newText, cwd);
		}
		const hasRegex = input.edits.some((e) => e?.regex === true);
		const plain = input.edits.map((e) => ({ oldText: String(e?.oldText ?? ""), newText: String(e?.newText ?? "") }));
		if (!hasRegex) {
			// A1（ev-20260921-2e6b4f）：字面标题删除检查在任何写入前完成（事件守卫同判定、同文案；
			// 此处是守卫注册缺席/事件被旁路时的执法兜底——override 自身仍是防线）。
			// B4·批B（D7 disclose）：rule=disclose → 不拒绝，收集披露（读文件算行范围——本分支此前
			// 未读盘，仅为披露补一次读；读失败时降级为无行范围披露）附加到成功结果。
			const headingReasons = headingDeletionReasons(abs, plain.map((e, i) => ({ index: i, ...e })));
			let headingDisclosures: string[] = [];
			if (headingReasons.length > 0) {
				const trust = guardProjectTrustedOf(ctx);
				if (guardRuleOf("edit.headingDeletion", cwd, trust) !== "disclose") throw new Error(headingReasons.join("\n\n"));
				let space: string | null = null;
				try { space = toMatchSpace(read(abs)); } catch { /* lint-exempt:读失败时披露降级为无行范围（不改变写入判定） */ }
				headingDisclosures = plain
					.map((e, i) => ({ e, hc: checkHeadingDeletion(e.oldText, e.newText) }))
					.filter(({ hc }) => hc.deletedHeadings.length > 0)
					.map(({ e, hc }, i) => headingDeletionDisclosure(abs, i, hc.deletedHeadings, space !== null ? lineRangeOfSpace(space, e.oldText) : undefined));
			}
			try {
				return appendDisclosures(await delegateNative(toolCallId, filePath, plain, signal, onUpdate, ctx), headingDisclosures);
			} catch (e) {
				return await recoverNativeFailure(toolCallId, filePath, input.edits, e, signal, onUpdate, ctx);
			}
		}
		// regex 预解析（非 regex 项 passthrough：尽力自愈、否则原样，交原生 fuzzy 裁决）
		let space: string;
		try {
			space = toMatchSpace(read(abs));
		} catch (e) {
			// 目标不可读：regex 语义无法预解析（绝不退化为字面替换），报错 + 错发提示；
			// ev-20260901-91d4ae：ENOENT × 近 60s 内 bash mv/rm 影响过该路径 → 追加同轮并行竞态提示
			const hint = misTargetHint(plain.map((e) => e.oldText).filter(Boolean), abs, ctx);
			const race = isEnoentLike(e) ? fsMutationRaceHint(abs) : null;
			throw new Error(`[amagi edit-override] ${filePath}：无法读取（${e instanceof Error ? e.message : String(e)}）——文件不存在或不可读，regex 预解析无法进行。${hint ? `\n${hint}` : ""}${race ? `\n${race}` : ""}`);
		}
		const resolution = resolveEditsForFile(abs, space, input.edits, "passthrough", { cwd, projectTrusted: guardProjectTrustedOf(ctx) });
		if (resolution.reasons.length > 0) {
			diag?.(`[amagi edit-override] ${path.basename(abs)}：${resolution.reasons.length} 处 regex edit 拒绝（0/N/非法/超限）并附诊断`);
			throw new Error(resolution.reasons.join("\n\n"));
		}
		try {
			return appendDisclosures(await delegateNative(toolCallId, filePath, resolution.edits, signal, onUpdate, ctx), resolution.disclosures);
		} catch (e) {
			return await recoverNativeFailure(toolCallId, filePath, input.edits, e, signal, onUpdate, ctx);
		}
	};

	/** 多文件路径：两阶段（先全量校验零写入，再逐文件写入；中途失败已写文件保留并标注）。
	 *  P2（§5.2）：权限校验先于一切读盘/校验/写入——files[] 全部目标整单校验，任一越界零写入。 */
	const applyFilesMode = async (
		toolCallId: string,
		files: string[],
		input: ReplacementInput,
		signal: AbortSignal | undefined,
		onUpdate: ((partial: unknown) => void) | undefined,
		ctx: unknown,
	) => {
		const cwd = builtinFileCwd(baseCwd, ctx);
		const targets = files.map((f) => resolveAbs(f, ctx));
		enforceFileWriteTargets(cwd, targets);
		const seen = new Set<string>();
		for (const target of targets) {
			let identity = target;
			try { identity = fs.realpathSync(target); } catch { /* 不存在时由后续校验报错 */ }
			if (process.platform === "win32") identity = identity.toLowerCase();
			if (seen.has(identity)) throw new Error(`[amagi edit-override] files 存在重复目标：${target}；同一文件只需出现一次，去重后可直接重发（本次全部文件零写入）。`);
			seen.add(identity);
		}
		// v2.15.0 大发射守卫（工具层硬闸，files 模式）：同一组 edits 应用于每个文件——逐文件×逐段
		// 预检，任一超限整单拒绝（与两阶段零写入契约同构，同参数重跑幂等）。
		for (const f of files) {
			for (const e of input.edits) {
				if (typeof e?.newText === "string") enforceLargeEditEmission(resolveAbs(f, ctx), e.newText, cwd);
			}
		}
		type Ready = { file: string; edits: ResolvedEdit[] };
		const ready = new Map<string, Ready>();
		const failed = new Map<string, string>();
		// B4·批B（D7/D8 disclose）：各文件披露按文件归集（键与 ready 对齐），成功返回统一附加。
		const fileDisclosures = new Map<string, string[]>();
		for (const f of files) {
			const abs = resolveAbs(f, ctx);
			try {
				const snapshot = read(abs);
				const space = toMatchSpace(snapshot);
				const resolution = resolveEditsForFile(abs, space, input.edits, "strict-unique", { cwd, projectTrusted: guardProjectTrustedOf(ctx) });
				if (resolution.reasons.length > 0) {
					const hint = misTargetHint(resolution.notFoundOldTexts, abs, ctx);
					failed.set(f, hint ? `${resolution.reasons.join("\n\n")}\n${hint}` : resolution.reasons.join("\n\n"));
				} else {
					if (resolution.disclosures.length > 0) fileDisclosures.set(f, resolution.disclosures);
					// 原生 in-memory 演练：复用 fuzzy 唯一性/overlap/no-change 校验，write 操作不触盘。
					// 仍由写入阶段处理并发变更与真实 I/O 失败，不能承诺跨文件事务回滚。
					const preview = createEditToolDefinition(cwd, { operations: {
						access: async () => {}, readFile: async () => Buffer.from(snapshot), writeFile: async () => {},
					} });
					try {
						await preview.execute(toolCallId, { path: abs, edits: resolution.edits }, signal, undefined, ctx as never);
						ready.set(f, { file: f, edits: resolution.edits });
					} catch (e) { failed.set(f, e instanceof Error ? e.message : String(e)); }
				}
			} catch (e) {
				// ev-20260901-91d4ae：ENOENT × 近 60s 内 bash mv/rm 影响过该路径 → 追加同轮并行竞态提示
				const race = isEnoentLike(e) ? fsMutationRaceHint(abs) : null;
				failed.set(f, `[amagi edit-override] ${f}：无法读取（${e instanceof Error ? e.message : String(e)}）——文件不存在或不可读。${race ? `\n${race}` : ""}`);
			}
		}
		if (failed.size > 0) {
			// 校验阶段失败：所有文件零写入（同参数重跑幂等）
			const lines = files.map((f) => {
				const reason = failed.get(f);
				if (reason !== undefined) return `- ${f}: FAILED（未写入，已解析到 ${resolveAbs(f, ctx)}）— ${reason.split("\n")[0]}`;
				return `- ${f}: 校验通过，未写入（整体失败零写入，已解析到 ${resolveAbs(f, ctx)}）`;
			});
			const details = [...failed.entries()].map(([f, r]) => `${f}（已解析到 ${resolveAbs(f, ctx)}）失败详情：\n${r}`).join("\n\n");
			throw new Error(`[amagi edit-override] files 模式校验失败：${failed.size}/${files.length} 个文件未过校验，全部文件零写入（修正后可原参数重跑）。\n${lines.join("\n")}\n\n${details}`);
		}
		// 写入阶段：顺序逐文件；中途失败 → 已写入保留（不回滚、明确标注），其后中止
		const okLines: string[] = [];
		const diffParts: string[] = [];
		const patchParts: string[] = [];
		let firstChangedLine: number | undefined;
		const disclosureNotes: string[] = [];
		for (let k = 0; k < files.length; k++) {
			const f = files[k];
			const plan = ready.get(f)!;
			try {
				const r = await delegateNative(toolCallId, f, plan.edits, signal, onUpdate, ctx);
				okLines.push(`- ${f}: ${plan.edits.length}/${plan.edits.length} edits`);
				disclosureNotes.push(...(fileDisclosures.get(f) ?? []));
				const d = (r as { details?: { diff?: string; patch?: string; firstChangedLine?: number } }).details;
				if (d?.diff) diffParts.push(`── ${f} ──\n${d.diff}`);
				if (d?.patch) patchParts.push(d.patch);
				if (firstChangedLine === undefined && d?.firstChangedLine !== undefined) firstChangedLine = d.firstChangedLine;
			} catch (e) {
				const applied = files.slice(0, k).map((q) => `- ${q}: 已写入（${ready.get(q)!.edits.length}/${input.edits.length} edits，保留改动，不回滚）`);
				const pending = files.slice(k + 1).map((q) => `- ${q}: 未写入（中止）`);
				throw new Error(`[amagi edit-override] files 模式写入失败：${f} 写入异常，其后文件中止。\n${[...applied, `- ${f}: FAILED（未写入）— ${e instanceof Error ? e.message : String(e)}`, ...pending].join("\n")}`);
			}
		}
		// B4·批B：多文件成功回执统一附加披露段（各文件 note 已按序收集；零披露时文本与既有完全一致）。
		const filesText = `edit files 模式：${files.length} 个文件全部成功（每组 ${input.edits.length}/${input.edits.length} edits）。\n${okLines.join("\n")}`;
		return {
			content: [{ type: "text" as const, text: disclosureNotes.length > 0 ? `${filesText}\n\n${disclosureNotes.join("\n\n")}` : filesText }],
			details: { diff: diffParts.join("\n\n"), patch: patchParts.join("\n"), firstChangedLine },
		};
	};

	return {
		...baseDef,
		name: "edit" as const,
		label: "edit",
		description: `${baseDef.description} For long whole-line rewrites, use {path, selection:{snapshotId,startLine,endLine}, newText} from read({editReference:true}) or a fully shown failure candidate; the entire file version is checked. Alternatively use {path, patch} for context hunks. Optional edits[].regex and files apply as documented.`,
		promptGuidelines: [...(baseDef.promptGuidelines ?? []), REGEX_GUIDELINE, FILES_GUIDELINE, EDIT_PATCH_GUIDELINE],
		parameters: schema,
		prepareArguments(input: unknown) {
			const prepared = baseDef.prepareArguments?.(input) ?? input;
			if (prepared && typeof prepared === "object" && !Array.isArray(prepared)) { normalizeEditPatchOptions(prepared as Record<string, unknown>); normalizeSelectionOptions(prepared as Record<string, unknown>); }
			return prepared;
		},
		// pi 0.86.0 配合：对齐内置 edit 默认 strict:prefer（AMAGI_BUILTIN_CONSTRAINED=0 逃生舱），见 host-capabilities.resolveBuiltinConstrainedSampling
		constrainedSampling: resolveBuiltinConstrainedSampling(),
		async execute(
			toolCallId: string,
			args: EditOverrideInput,
			signal: AbortSignal | undefined,
			onUpdate: ((partial: unknown) => void) | undefined,
			ctx: unknown,
		) {
			if (args && typeof args === "object") { normalizeEditPatchOptions(args as unknown as Record<string, unknown>); normalizeSelectionOptions(args as unknown as Record<string, unknown>); }
			// ev-20260925-287e93（双宿主根治 §2.2，与 write-override 同源）：win32 宿主 + bash 跑在 WSL
			// 时，POSIX 绝对路径会被原生 edit 按当前盘根解析（X:\tmp\x.py）——读不到 bash 侧文件、
			// 改动落错文件系统。path 与 files[] 逐项重定向到 WSL 侧可见路径（/mnt/<盘>/P → <盘>:\P
			// 确定性映射零探测；其余 → \\wsl.localhost\<distro><P>，distro 未知不重定向，维持原语义）。
			// 读改写全走重定向后路径（同一文件）；诊断/登记同样以实际目标为准。
			if ((deps.hostPlatform ?? process.platform) === "win32") {
				const redirectTo = (p: string): string => {
					const raw = p;
					if (!raw || !isPosixStyleAbsolutePath(raw)) return p;
					let target = posixToWindowsVisible(raw, { probed: false, wsl: false });
					if (target === null) {
						try { target = posixToWindowsVisible(raw, probeBashRuntime(builtinFileCwd(baseCwd, ctx))); } catch { /* lint-exempt:探测失败不重定向，后续 files 校验/原生语义接管 */ }
					}
					return target ?? p;
				};
				if (typeof args?.path === "string" && args.path.trim() !== "") args = { ...args, path: redirectTo(args.path) };
				// 非字符串项不整体改写（交给后续 files 校验报原生错语）；全部为字符串才逐项重定向。
				if (Array.isArray(args?.files) && (args.files as unknown[]).every((f) => typeof f === "string")) {
					args = { ...args, files: (args.files as string[]).map((f) => redirectTo(f)) };
				}
			}
			if (args?.selection !== undefined) return await attachDiag(await applySelection(toolCallId, args, signal, onUpdate, ctx), [args.path!], ctx);
			if (args?.newText !== undefined) throw new EditFailure("invalid-input", "顶层 newText 仅用于 selection。");
			if (args && typeof args === "object") coalesceEditTargets(args as unknown as Record<string, unknown>, builtinFileCwd(baseCwd, ctx));
			if (args?.patch !== undefined) {
				if (typeof args.path !== "string" || !args.path.trim() || args.files !== undefined || args.edits !== undefined || Object.hasOwn(args, "file_path")) throw new Error("[amagi edit patch] 仅支持 {path, patch}，不能混用 edits/files/file_path。");
				const abs = resolveAbs(args.path, ctx);
				enforceFileWriteTargets(builtinFileCwd(baseCwd, ctx), [abs]); // 禁入目标不读盘。
				const edits = resolveEditPatch(read(abs), args.patch);
				return await attachDiag(await applySingleFile(toolCallId, args.path, {edits}, signal, onUpdate, ctx), [args.path], ctx);
			}
			const edits = Array.isArray(args?.edits) ? args.edits : [];
			if (edits.length === 0) {
				throw new Error("Edit tool input is invalid. edits must contain at least one replacement.");
			}
			const hasPath = typeof args?.path === "string" && args.path.trim() !== "";
			const hasFiles = Array.isArray(args?.files);
			// ev-20260922-146773：归一化 schema（Type.Optional → required+nullable）＋ XML 参数格式无法
			// 表达 JSON null，会把缺省 path 序列化为字符串 "null"。files 模式下字面量 "null" 视为
			// 缺省（消解互斥假冲突）；真名为 null 的文件仍可走单文件 path 模式（无 files 时不吞并）。
			if (hasPath && hasFiles && (args.path as string).trim() !== "null") {
				throw new Error(`[amagi edit-override] path 与 files 互斥：单文件编辑传 path，多文件传 files（本次同时收到 path=${JSON.stringify(args.path)} 与 files×${args.files!.length}）`);
			}
			if (hasFiles) {
				const files = args.files as unknown[];
				if (files.length === 0) throw new Error("[amagi edit-override] files 不能为空数组（多文件模式至少 1 个）");
				const bad = files.find((f) => typeof f !== "string" || f.trim() === "");
				if (bad !== undefined) throw new Error(`[amagi edit-override] files 每项必须是非空字符串路径（收到 ${JSON.stringify(bad)}）`);
				return await attachDiag(await applyFilesMode(toolCallId, files as string[], { edits }, signal, onUpdate, ctx), files as string[], ctx);
			}
			if (hasPath) {
				return await attachDiag(await applySingleFile(toolCallId, args.path as string, { edits }, signal, onUpdate, ctx), [args.path as string], ctx);
			}
			throw new Error("[amagi edit-override] 缺少编辑目标：单文件编辑传 path，多文件传 files: string[]（至少 1 个）");
		},
	};
}

// ── 注册器 ──────────────────────────────────────────────────────────────────

export interface EditOverridePi {
	registerTool(tool: unknown): void;
	on(event: "tool_execution_start", handler: (event: { toolName?: string; args?: unknown }, ctx?: unknown) => void | unknown): void;
}

/**
 * 注册 edit 覆盖版：接线近期 read 跟踪（tool_execution_start）+ 注册同名工具。
 * 注册失败由调用方静默降级（原生 edit 不受影响）——**严格任务例外（P2 §8.3-5）**：
 * 活动权限上下文为 tool-enforced 时注册失败即 failStrictTaskStartup（exit 1）——
 * 同名 override 是 write/edit 通道逐次权限校验的执法点，静默降级为原生 edit = 校验旁路，
 * 任务启动即拒，不静默降级为无包装器原生工具。
 */
export function registerEditOverrideTool(pi: EditOverridePi, deps: EditOverrideDeps = {}): void {
	const cwd = deps.cwd ?? process.cwd();
	const tracker = createRecentReadTracker(cwd);
	try { pi.on("tool_execution_start", (event, ctx) => tracker.observe(event, ctx)); } catch { /* 事件不可用防御 */ }
	try {
		pi.registerTool(createEditOverrideTool(cwd, { ...deps, recentReads: deps.recentReads ?? (() => tracker.snapshot()) }));
		recordEditingRegistration(pi, "edit", deps.snapshots ?? defaultEditSnapshots);
	} catch (e) {
		const cause = e instanceof Error ? e.message : String(e);
		if (strictEnforcementActive()) {
			failStrictTaskStartup(`edit override 注册失败（${cause}）——tool-enforced 任务的 write/edit 通道逐次权限校验依赖同名 override，禁止静默降级为无包装器原生 edit。`);
		}
		throw e; // legacy：调用方静默降级（原生 edit 不受影响）
	}
}
