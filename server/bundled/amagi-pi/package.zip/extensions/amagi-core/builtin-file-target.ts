/** 文件工具适配层：与 pi 内置工具共用 cwd/路径语义，避免检查目标与执行目标分裂。
 * pi 的 path-utils 未从包根导出；这里按开发基线 1.1.0 固定其解析规则，由真实原生工具回归守护。
 * 不用于普通 fs 通道：@、Unicode 空格和 read 的文件名回退仅属内置工具协议。 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

export function builtinFileCwd(baseCwd: string, ctx?: unknown): string {
	return (ctx as { cwd?: string } | undefined)?.cwd || baseCwd;
}

function normalizePath(input: string, toolPath = false): string {
	let value = toolPath ? input.replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, " ").replace(/^@/, "") : input;
	if (process.platform === "win32" && value.startsWith("/") && !value.startsWith("//") && !value.includes("\\")) {
		const match = value.match(/^\/(?:mnt\/|cygdrive\/)?([a-z])(?:\/(.*))?$/i);
		if (match) value = `${match[1].toUpperCase()}:\\${match[2]?.replaceAll("/", "\\") ?? ""}`;
	}
	if (value === "~") return os.homedir();
	if (value.startsWith("~/") || (process.platform === "win32" && value.startsWith("~\\"))) return path.join(os.homedir(), value.slice(2));
	return /^file:\/\//.test(value) ? fileURLToPath(value) : value;
}

export function resolveBuiltinFileTarget(input: string, cwd: string): string {
	return path.resolve(normalizePath(cwd), normalizePath(input, true));
}

/** read 的 macOS 截图/NFD/弯引号回退顺序必须与原生一致，deny 也检查最终读到的文件。 */
export function resolveBuiltinReadTarget(input: string, cwd: string): string {
	const target = resolveBuiltinFileTarget(input, cwd);
	const nfd = target.normalize("NFD");
	const candidates = [target, target.replace(/ (AM|PM)\./gi, "\u202F$1."), nfd, target.replace(/'/g, "\u2019"), nfd.replace(/'/g, "\u2019")];
	for (const candidate of candidates) {
		try { fs.accessSync(candidate, fs.constants.F_OK); return candidate; } catch { /* 按原生顺序尝试下一项 */ }
	}
	return target;
}
