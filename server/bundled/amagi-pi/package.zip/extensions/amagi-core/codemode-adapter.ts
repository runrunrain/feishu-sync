/**
 * codemode-adapter.ts — B5A（ev-20261012-7517d8 设计 §4）：codemode 受控装配适配器。
 *
 * 物理隔离方案（设计 §4.1/§4.2，主上 Q-C1 批准；物理隔离证明为硬门槛）：
 *  - 经宿主公开导出工厂 `createCodemodeExtension({ models: false, mode: "on", inlineBudget })`
 *    构造同名 codemode 工具——models 桥在工厂装配面物理不存在（execute.js createModelGlobals
 *    仅在 options.models===true 时注入 globals），非提示词承诺；
 *  - 同名注册替换 CLI 内置 codemode（宿主 omitReplacedExtensions：builtin codemode 为
 *    replaceable，同名工具出现即整体卸载内置实例）——不存在回落到 models 默认 true 的内置工具；
 *  - 装饰截获的 ToolDefinition：execute 传入的 ExtensionToolContext 用 Proxy 过滤——`tools`
 *    getter 只暴露冻结只读集（read/grep/find）∩ 当前注册表，`executeTool` 转发前验证 name
 *    ∈ 冻结集 + 预留 + 装配身份；宿主 executeCodemode 的 sandbox 工具映射表、searchTools/
 *    describeTool/describeNamespace 发现面、prepareLoadout 描述全部派生自该 ctx.tools（宿主
 *    dist/extensions/codemode/execute.js:379-415、tool.js prepareCodemodeLoadout 实证）——
 *    write/bash/MCP/models 在 sandbox 发现与执行双不可达；
 *  - nested 转发必须走真实 ctx.executeTool（宿主 tool 管线：参数校验、tool_call/tool_result
 *    钩子、权限守卫、事件链），绝不直接调用工具定义的 execute；
 *  - 预算执法（§5 全部预算以进程内状态强制）挂 execute 入口：准入预留→摘要复核→nested 闸
 *    （128/脚本、4 在途、1024 会话）→结束登记；allow/deny/end 审计随会话 appendEntry 记录。
 *
 * 失败语义（fail-closed，不回落内置实例）：宿主无公开工厂/装配校验失败 → 注册恒拒 codemode
 * 哨兵（同名占位替换内置，每次调用返回 STATE_UNAVAILABLE 错误）——已准入任务在该会话拿不到
 * 任何可用 codemode，其余工具不受影响；绝不能 catch 后继续使用内置实例。
 *
 * 不修改宿主对象、不导入 dist 私有执行模块——只消费公开导出与公开 ToolDefinition 契约。
 */
import type { ExtensionAPI, ToolDefinition } from "@earendil-works/pi-coding-agent";
import * as nodePath from "node:path";
import { fileURLToPath } from "node:url";
import type { ReadOnlyCodemodeGrant } from "./contracts/permission.ts";
import type { CodemodeGrantBudget } from "./contracts/permission.ts";
import { enhanceCodemodeErrorResult } from "./codemode-errors.ts";
import { compareVersions, detectHostPackageVersion } from "./host-capabilities.ts";
// B5B（ev-20261012-7517d8 批B）：持久预算账本——内存预留切为持久账户（§5.3 跨进程强制）。
import {
	CODEMODE_ACCOUNT_ID_PATTERN,
	codemodeAccountIdOfRawGrant,
	codemodeAccountArtifacts,
	openCodemodeLedger,
	readCodemodeLedgerSnapshot,
	scanCodemodeSessionAnchorArgv,
	type CodemodeLedgerHandle,
} from "./codemode-ledger.ts";
import {
	admitControlledCodemodeScript,
	admitControlledNestedCall,
	applyCodemodeLedgerSnapshot,
	newCodemodeControlledState,
	recordControlledDenyEntry,
	recordControlledStart,
	settleControlledCodemodeScript,
	type CodemodeControlledAuditEntry,
	type CodemodeControlledState,
	type CodemodeReservation,
} from "./codemode-policy.ts";

// ── 宿主公开工厂探测（懒加载 + 进程内缓存；缺导出的旧宿主 → 不可用 → 受控模式关闭） ──

type CodemodeExtensionFactory = (pi: unknown) => void;
let hostFactoryProbe: Promise<CodemodeExtensionFactory | null> | undefined;

/**
 * 探测宿主公开 `createCodemodeExtension` 工厂（Pi/dist/index.d.ts:29 公开导出）。
 * 动态 import + typeof 探测（命名导出缺失的旧宿主不炸模块加载）；结果进程内缓存。
 * 返回 null = 宿主无公开工厂（受控装配不可用——父端 BackendCaps.codemode=false，子端拒哨兵）。
 */
export function ensureControlledCodemodeFactory(): Promise<CodemodeExtensionFactory | null> {
	if (hostFactoryProbe === undefined) {
		hostFactoryProbe = import("@earendil-works/pi-coding-agent")
			.then((mod) => {
				const fn = (mod as { createCodemodeExtension?: unknown }).createCodemodeExtension;
				return typeof fn === "function" ? (fn as CodemodeExtensionFactory) : null;
			})
			.catch(() => null); /* lint-exempt:宿主缺公开导出时受控装配关闭（探测结果，非吞错） */
	}
	return hostFactoryProbe;
}

/** 首批受控装配接受的最低宿主版本（7517d8 设计 §10.2：1.0.2 工厂选项未核验；仅接受 1.1.0 组合）。 */
export const CODEMODE_CONTROLLED_MIN_HOST_VERSION = "1.1.0";

let backendAvailableProbe: Promise<boolean> | undefined;

/**
 * 父端后端能力探测：公开工厂可导入 且 宿主包版本 ≥ 1.1.0（设计 §3.1：不能仅以版本置 true，
 * 也不接受未核验工厂选项的旧宿主——工厂导入 + 版本门双条件；同仓父子进程共用同一宿主安装）。
 * 结果进程内缓存（探测含动态 import，首次后零成本）。 */
export function controlledCodemodeBackendAvailable(): Promise<boolean> {
	if (backendAvailableProbe === undefined) {
		backendAvailableProbe = (async () => {
			const [factory, version] = await Promise.all([ensureControlledCodemodeFactory(), Promise.resolve(detectHostPackageVersion())]);
			return factory !== null && version !== null && compareVersions(version, CODEMODE_CONTROLLED_MIN_HOST_VERSION) >= 0;
		})();
	}
	return backendAvailableProbe;
}

// ── B5C（ev-20261012-7517d8 设计 §7 意识层）：实际生效工具面状态行——子端投影与注入钩子 ──
//
// 只描述真实开关状态（grant/账户/账本），不代替批A/B 机制；off 措辞不暗示可调用。以下两个
// 锚点解析函数由 registerControlledCodemode 闭包提升至模块级：projectCodemodeChildFace 与
// ensureAccount 同源复用（B5C），避免两份解析漂移。

/** F03（审核终裁）：RPC/父端交付语义识别——RPC worker env（AMAGI_RPC_WORKER=1，池 spawn 注入）
 *  或 argv --mode rpc。该语义下账户只能来自父端 env 交付，缺席即拒绝（不回退会话/argv 自派生
 *  新账——身份链断裂=重建 worker 可获全新额度，fail-closed）。 */
export function isRpcDeliverySemantic(env: NodeJS.ProcessEnv, argv: readonly string[]): boolean {
	if (env.AMAGI_RPC_WORKER === "1") return true;
	for (let i = 0; i < argv.length; i++) {
		const a = argv[i]!;
		if (a === "--") return false;
		if (a === "--mode" && argv[i + 1] === "rpc") return true;
		if (a === "--mode=rpc") return true;
	}
	return false;
}

/** 本会话自身锚（sessionManager 面读取；不可用 → undefined 按无锚处理）。 */
export function ownSessionAnchorOf(ctx: unknown): string | undefined {
	try {
		const sm = (ctx as { sessionManager?: { getSessionId?: () => unknown; getSessionFile?: () => unknown } })?.sessionManager;
		const sid = typeof sm?.getSessionId === "function" ? sm.getSessionId() : undefined;
		if (typeof sid === "string" && sid !== "") return `session|${sid}`;
		const sf = typeof sm?.getSessionFile === "function" ? sm.getSessionFile() : undefined;
		if (typeof sf === "string" && sf !== "") return `session|${sf}`;
	} catch { /* lint-exempt:会话面不可用按无锚处理 */ }
	return undefined;
}

/** 子端 off 状态行（措辞不暗示可调用——不可用事实 + 既有只读工具去向）。
 *  B5C 修复轮二 R1-02：理由与证据均为封闭枚举（CODEMODE_CHILD_OFF_REASONS/
 *  CODEMODE_CHILD_OFF_EVIDENCE）——状态行不含任何自由文本，门禁可断言整行 ∈ 模板展开集；
 *  自由文本诊断只存在于 codemode 调用返回与审计，不进状态行。off 行不等于执行面已硬拒绝
 *  （执行面由批A/B 机制裁决，本行只是意识层投影）。 */
export const CODEMODE_CHILD_OFF_REASONS = Object.freeze({
	assemblyClosed: "运行期已关闭（细节见 codemode 调用返回与审计）",
	assemblyUnavailable: "受控装配未成立（不回落内置实例）",
	accountInvalid: "账户上下文非法（须受控 24-hex 格式）——STATE_UNAVAILABLE",
	rpcAccountMissing: "RPC/父端交付语义下 AMAGI_CODEMODE_ACCOUNT 缺席——账户只能经父端任务锚交付，STATE_UNAVAILABLE",
	anchorUnresolvable: "账户锚点/grant 原文不可解析——STATE_UNAVAILABLE（不开无账户执行的洞）",
	ledgerCorrupt: "持久账本不可读（corrupt）——codemode 已按 §5.3 关闭",
	ledgerMissingRecovered: "持久账本不可用（恢复证据在场而账本缺失/空——历史状态不确定，保守 off）",
});
export type CodemodeChildOffReasonKey = keyof typeof CODEMODE_CHILD_OFF_REASONS;
/** 恢复证据封闭词表（顺序固定：与代码内拼接序一致）。 */
export const CODEMODE_CHILD_OFF_EVIDENCE = Object.freeze(["租约在场", "torn 封存在场", "别名入度>0", "argv 续接锚", "别名链重放", "本进程已开账而账本消失"] as const);
export type CodemodeChildOffEvidence = (typeof CODEMODE_CHILD_OFF_EVIDENCE)[number];

function childOffLine(reasonKey: CodemodeChildOffReasonKey, evidence?: readonly CodemodeChildOffEvidence[]): string {
	const reason = CODEMODE_CHILD_OFF_REASONS[reasonKey];
	if (reason === undefined) throw new Error(`[codemode-adapter] 未知 off 理由键：${String(reasonKey)}`);
	const evidenceNote = evidence !== undefined && evidence.length > 0 ? `；证据：${[...new Set(evidence)].join("、")}` : "";
	return `[amagi codemode 状态] codemode: off｜${reason}${evidenceNote}——本会话 codemode 不可用（不暗示可调用；直接用既有只读工具，不花轮次尝试解锁）`;
}

export interface CodemodeChildFaceInput {
	/** 冻结只读授予（已过契约校验）。 */
	readonly grant: { readonly tools: readonly string[]; readonly budget: CodemodeGrantBudget };
	/** 显式账户注入（测试/嵌入面；生产缺省 env/argv/会话自解析）。 */
	readonly account?: { accountId: string };
	/** 装配状态快照读取（闭包动态读 verification/closedReason）。 */
	readonly status: { assembled: boolean; reason?: string; closedReason?: string };
	/** before_agent_start ctx（会话锚解析；无会话面时仍可按 env/argv 投影）。 */
	readonly ctx: unknown;
	/** B5C 修复轮二 R1-03：本注册闭包的已开账事实（ledgerHandle.accountId + 进程内已预留三轴）。
	 *  在场且与解析账户一致时，空快照=「本进程新开未消费」（read-only 满额）而非历史丢账；
	 *  在场且进程内已预留>0 而账本空=「本进程已开账而账本消失」（保守 off）。 */
	readonly owned?: { accountId: string; reserved: { scripts: number; tokens: number; ms: number } };
}

/**
 * 子端实际生效工具面状态行（同步、零租约——readCodemodeLedgerSnapshot 只读重放，不干扰写者）。
 * 取自真实运行态：grant（冻结子对象）+ 账户锚（同 ensureAccount 解析序）+ 持久账本快照（已预留三轴）。
 * 返回值恒为一行文本；执行期准入仍以策略/账本执法为准，本行不构成可用性承诺的替代。
 */
export function projectCodemodeChildFace(input: CodemodeChildFaceInput): string {
	if (input.status.closedReason !== undefined) {
		return childOffLine("assemblyClosed");
	}
	if (!input.status.assembled) {
		return childOffLine("assemblyUnavailable");
	}
	// 账户解析（同 ensureAccount 序：opts.account → env 交付 → RPC 语义检查 → argv/会话锚）。
	const delivered = input.account?.accountId ?? process.env.AMAGI_CODEMODE_ACCOUNT;
	let accountId: string | undefined;
	if (delivered !== undefined) {
		if (!CODEMODE_ACCOUNT_ID_PATTERN.test(delivered)) {
			return childOffLine("accountInvalid");
		}
		accountId = delivered;
	} else if (isRpcDeliverySemantic(process.env, process.argv)) {
		return childOffLine("rpcAccountMissing");
	} else {
		const raw = process.env.AMAGI_PERMISSION_GRANT;
		const argvAnchor = scanCodemodeSessionAnchorArgv(process.argv) ?? undefined;
		const anchor = argvAnchor ?? ownSessionAnchorOf(input.ctx);
		if (typeof raw !== "string" || raw === "" || anchor === undefined) {
			return childOffLine("anchorUnresolvable");
		}
		accountId = codemodeAccountIdOfRawGrant(raw, anchor);
	}
	const snap = readCodemodeLedgerSnapshot(accountId);
	if (!snap.ok) {
		return childOffLine("ledgerCorrupt");
	}
	// B5C 修复轮一 F06 + 修复轮二 R1-03：恢复账户不得猜满额度；本进程新开未消费的活账户不误伤。
	// ENOENT 重放为空快照（批B 既有口径），与首次新建账户不可区分——判据序：
	//  ① 本注册闭包已开账事实（R1-03）：owned 与解析账户同源且进程内零预留 → 本进程新开未消费
	//     → read-only 满额度（live lease 持有中不是丢账）；owned 在场且进程内已预留>0 而快照零
	//     事件 → 账本在手却消失 → 保守 off（证据：本进程已开账而账本消失）。
	//  ② 只读工件证据（租约/torn/别名入度/argv 续接锚/别名链）任一在场且零事件 → 保守 off
	//     （宁 off 不夸大；不改批B 执行语义——执行面仍由 ensureAccount/openCodemodeLedger 裁决，
	//     off 行不等于执行面已硬拒绝）。
	//  ③ 无任何证据的空快照按首次新建账户满额度展示（无证据丢账不保证检出——批B 机制依赖缺口，
	//     见报告未覆盖项：需机制提供「新建/已打开/恢复账户」可靠事实）。
	if (snap.snapshot.events === 0) {
		const owned = input.owned;
		// 对比用重放最终计费账户（alias 链下解析起点 ≠ 计费账户——owned 来自 ledgerHandle.accountId）
		const ownedHere = owned !== undefined && owned.accountId === snap.snapshot.accountId;
		if (ownedHere && owned!.reserved.scripts === 0 && owned!.reserved.tokens === 0 && owned!.reserved.ms === 0) {
			// R1-03：本进程新开未消费（含 live lease 持有中）——不是丢账，走 read-only 满额度。
		} else if (ownedHere) {
			return childOffLine("ledgerMissingRecovered", ["本进程已开账而账本消失"]);
		} else {
			const artifacts = codemodeAccountArtifacts(accountId);
			const argvResume = scanCodemodeSessionAnchorArgv(process.argv) !== null;
			const evidence: CodemodeChildOffEvidence[] = [
				...(artifacts.lease ? (["租约在场"] as CodemodeChildOffEvidence[]) : []),
				...(artifacts.torn ? (["torn 封存在场"] as CodemodeChildOffEvidence[]) : []),
				...(artifacts.aliasReferenced ? (["别名入度>0"] as CodemodeChildOffEvidence[]) : []),
				...(argvResume ? (["argv 续接锚"] as CodemodeChildOffEvidence[]) : []),
				...(snap.chain.length > 1 ? (["别名链重放"] as CodemodeChildOffEvidence[]) : []),
			];
			if (evidence.length > 0) {
				return childOffLine("ledgerMissingRecovered", evidence);
			}
		}
	}
	const b = input.grant.budget;
	const remScripts = Math.max(0, b.maxScriptsPerSession - snap.snapshot.reservedScripts);
	const remTokens = Math.max(0, b.maxTotalOutputTokens - snap.snapshot.reservedTokens);
	const remMs = Math.max(0, b.maxTotalTimeoutMs - snap.snapshot.reservedMs);
	// B5C 修复轮一 F04：主账户用重放最终账户（计费账户——alias 链终点）；起始账户另标 alias 起点
	//（与实际写账账户同源，取证不再错位）。
	const billingAccount = snap.snapshot.accountId;
	const aliasNote = snap.chain.length > 1 ? `｜alias起点=${accountId}` : "";
	return `[amagi codemode 状态] codemode: read-only｜tools=${[...input.grant.tools].join(",")}｜单次≤${b.maxOutputTokensPerScript}tok/${b.maxTimeoutMsPerScript}ms｜剩余额度=脚本 ${remScripts}/${b.maxScriptsPerSession}·tokens ${remTokens}/${b.maxTotalOutputTokens}·ms ${remMs}/${b.maxTotalTimeoutMs}（剩余/总）｜models=off｜账户=${billingAccount}${aliasNote}（每次调用仍经准入预留与审计；节选≠完整读过）`;
}

/** 意识行注入钩子：宿主携可写 sections 时写独占键 amagi_codemode_face（每轮先删后赋，diff 零负担），
 *  否则回退 forced systemPrompt 追加（首次计算后缓存——回退路径无 diff 面，保字节稳定）。
 *  行计算失败 → 无状态行（fail-open 至「无信息」，不误导可用方向；任务执行不受影响）。 */
function registerCodemodeFaceLineHook(pi: ExtensionAPI, computeLine: (ctx: unknown) => Promise<string> | string): void {
	try {
		let cachedFallbackLine: string | undefined;
		pi.on("before_agent_start", async (event: any, ctx: any): Promise<any> => {
			try {
				const sectionsRecord: unknown = event?.systemPromptOptions?.sections;
				if (sectionsRecord !== null && typeof sectionsRecord === "object") {
					const sections = sectionsRecord as Record<string, string>;
					delete sections[CODEMODE_FACE_SECTION_KEY];
					const line = await computeLine(ctx);
					if (line) sections[CODEMODE_FACE_SECTION_KEY] = line;
					return undefined;
				}
				if (cachedFallbackLine === undefined) cachedFallbackLine = (await computeLine(ctx)) || "";
				if (!cachedFallbackLine) return undefined;
				return { systemPrompt: `${String(event.systemPrompt || "")}\n\n${cachedFallbackLine}` };
			} catch (e) {
				try { console.error(`[amagi-core] codemode 状态行计算失败（B5C，无状态行注入）：${e instanceof Error ? e.message : String(e)}`); } catch { /* lint-exempt:诊断尽力而为 */ }
				return undefined;
			}
		});
	} catch { /* lint-exempt:事件不可用防御（无状态行，不影响任务执行） */ }
}

/** 意识行独占分节键（宿主节名约束 ^[a-z][a-z0-9_-]*$）。 */
const CODEMODE_FACE_SECTION_KEY = "amagi_codemode_face";

// ── 注册结果与审计通道 ─────────────────────────────────────────────────────────

/** 装配校验结果（物理隔离证明的机器可读面；diting 独立审核消费）。 */
export interface CodemodeAssemblyVerification {
	/** 受控实例装配成立（工厂导入→截获→形状校验全过）。 */
	readonly assembled: boolean;
	/** 工厂公开导出导入成败。 */
	readonly factoryImported: boolean;
	/** ToolDefinition 截获成败。 */
	readonly captured: boolean;
	/** 截获定义关键面断言（name/exposure/defaultActive/execute/prepareLoadout）。 */
	readonly capturedShapeOk: boolean;
	/** models 桥关闭证据：工厂 options.models === false（sandbox typeof models 复核见 e2e）。 */
	readonly modelsDisabled: boolean;
	/** 注册后 getAllTools 中 codemode 恰 1 个（替换证明；运行时复核用 verifySingleCodemodeInstance）。 */
	readonly singleInstanceVerified: boolean;
	readonly scriptTools: readonly string[];
	readonly reason?: string;
}

export interface ControlledCodemodeRegistration {
	readonly verification: CodemodeAssemblyVerification;
	/** 审计快照导出（策略内存态 + 会话记录转发失败标记；测试/查询消费）。 */
	auditLog(): readonly CodemodeControlledAuditEntry[];
	/** 诊断单行（子端启动日志/测试断言面）。 */
	readonly note: string;
	/** 注册失败/审计关闭后是否已进入恒拒（fail-closed 态）。 */
	readonly closedReason?: string;
}

export interface RegisterControlledCodemodeOptions {
	/** 冻结授权（须含 codemode 子对象；mode=read-only、models=false 已过契约校验）。 */
	grant: { codemode?: ReadOnlyCodemodeGrant };
	/** 任务身份（审计关联；缺省 unknown）。 */
	identity?: { taskId?: string; agent?: string; runId?: string };
	/** 审计落盘通道（会话 appendEntry；reserve/deny 段写失败 → 拒绝本次执行并关闭，§5.4）。 */
	auditSink?: (entry: CodemodeControlledAuditEntry) => boolean;
	/** B5B：显式账户注入（测试/嵌入面；生产缺省——子端按 env AMAGI_CODEMODE_ACCOUNT → argv
	 *  会话续接锚 → 本会话自身锚 解析，见 resolveAccountContext）。格式非法即拒绝。 */
	account?: { accountId: string };
}

/**
 * 注册受控 codemode 工具（index.ts 子端接线；grant.codemode 缺席时调用方不应调用——缺省零注册）。
 *
 * 时序：宿主工厂探测为动态 import——注册在探测续体内完成（宿主 0.55.4+ 动态工具注册即时刷新；
 * 批A 真机试点断言工具可达）。探测/截获/形状校验任一失败 → 恒拒哨兵（同名占位）。
 */
export function registerControlledCodemode(pi: ExtensionAPI, opts: RegisterControlledCodemodeOptions): ControlledCodemodeRegistration {
	// B5A 修复轮 F08：紧急关闭在装配面直接消费（§6.2：子端即使携带历史 grant 也拒绝）——
	// 不依赖调用方接线时机；恒拒哨兵同名替换内置，绝不回落原生实例。
	if (process.env.AMAGI_CODEMODE_DISABLE === "1") {
		return registerDenyStub(pi, "AMAGI_CODEMODE_DISABLE=1 紧急关闭（§6.2：即使携带历史 grant 也拒绝，不回落内置实例）", opts);
	}
	const grant = opts.grant.codemode;
	if (grant === undefined || grant.mode !== "read-only" || grant.models !== false) {
		return registerDenyStub(pi, "受控装配输入非法（codemode 子对象缺席或非只读——GRANT_MISSING）", opts);
	}
	const allowed = new Set<string>(grant.tools);

	// ── B5A 修复轮 F06：审计转发不再对策略 FIFO 数组保存绝对下标（溢出裁剪后增量循环永不进入，
	// 静默停写）。改为 adapter 自持增量队列：策略 onAudit 观察者推入（单一事实源仍在策略执法态），
	// forwardAudit 顺序冲刷；队列溢出（预算内不应发生）→ 显式关闭，不静默丢弃。
	const AUDIT_QUEUE_MAX = 4096;
	const auditQueue: CodemodeControlledAuditEntry[] = [];
	let auditQueueOverflow = false;
	let closedReason: string | undefined;
	const onAuditEntry = (entry: CodemodeControlledAuditEntry): void => {
		if (auditQueue.length >= AUDIT_QUEUE_MAX) {
			auditQueueOverflow = true;
			closedReason = "审计转发队列溢出（≥4096）——后续 codemode 已关闭（降级显式关闭，不静默停写）";
			return;
		}
		auditQueue.push(entry);
	};
	// reserve/deny 段失败 → 拒绝本次执行并关闭；end 段失败 → 保留宿主结果、关闭后续（§5.4）。
	// 失败条目保留在队首（下次冲刷重试/随关闭终止），绝不静默丢弃。
	const forwardAudit = (phase: "reserve" | "tail"): boolean => {
		if (opts.auditSink === undefined) return true;
		if (auditQueueOverflow && phase === "reserve") return false;
		try {
			while (auditQueue.length > 0) {
				const entry = auditQueue[0]!;
				if (!opts.auditSink(entry)) {
					if (phase === "reserve") return false;
					closedReason = "审计写入失败（end 段）——后续 codemode 已关闭（§5.4）";
					return true;
				}
				auditQueue.shift();
			}
			return true;
		} catch {
			if (phase === "reserve") return false;
			closedReason = "审计写入异常（end 段）——后续 codemode 已关闭（§5.4）";
			return true;
		}
	};
	const state: CodemodeControlledState = newCodemodeControlledState(grant, { identity: opts.identity, onAudit: onAuditEntry });

	// ── B5B：持久账户（惰性——首次外层执行时解析锚点并打开账本；冲突可重试、损坏/IO 永久关闭）。
	//  锚点解析序（§5.3 恢复语义）：opts.account（测试）→ env AMAGI_CODEMODE_ACCOUNT（RPC/父端
	//  交付）→ argv --session/--session-id/--fork 值（reload/resume/fork 续接同锚）→ 本会话自身
	//  sessionId（全新会话）。均无 → STATE_UNAVAILABLE 拒绝（不开无账户执行的洞）。
	let ledgerHandle: CodemodeLedgerHandle | undefined;
	let accountFatal: string | undefined;
	const rawGrantForDigest = (): string | undefined => {
		const raw = process.env.AMAGI_PERMISSION_GRANT;
		return typeof raw === "string" && raw !== "" ? raw : undefined;
	};
	// F03（审核终裁）与锚点解析函数已提升至模块级（B5C：projectCodemodeChildFace 与
	// ensureAccount 同源复用，避免两份解析漂移）。
	type AccountOutcome = { ok: true } | { ok: false; retryable: boolean; reason: string };
	const denyAccount = (reason: string): AccountOutcome => {
		// 永久失败（损坏/IO/无锚）记审计（零正文）并冲刷；调用方已置 closedReason。
		recordControlledDenyEntry(state, { code: "STATE_UNAVAILABLE" });
		forwardAudit("reserve");
		return { ok: false, retryable: false, reason };
	};
	const ensureAccount = (toolCallId: string, ctx: unknown): AccountOutcome => {
		if (ledgerHandle !== undefined) return { ok: true };
		if (accountFatal !== undefined || closedReason !== undefined) return { ok: false, retryable: false, reason: accountFatal ?? closedReason! };
		// ① 显式注入（测试/嵌入）与 ② 父端交付账户：格式校验后直接使用。
		const delivered = opts.account?.accountId ?? process.env.AMAGI_CODEMODE_ACCOUNT;
		let accountId: string | undefined;
		let argvAnchor: string | undefined;
		if (delivered !== undefined) {
			if (!CODEMODE_ACCOUNT_ID_PATTERN.test(delivered)) {
				accountFatal = `账户上下文非法（AMAGI_CODEMODE_ACCOUNT 须受控 24-hex 格式，实得 ${JSON.stringify(delivered.slice(0, 40))}）——STATE_UNAVAILABLE`;
				closedReason = accountFatal;
				return denyAccount(accountFatal);
			}
			accountId = delivered;
		} else if (isRpcDeliverySemantic(process.env, process.argv)) {
			// F03（审核终裁）：RPC/父端交付语义下账户 env 缺席 → 拒绝执行（不回退 session/argv 新账）。
			accountFatal = "RPC/父端交付语义下 AMAGI_CODEMODE_ACCOUNT 缺席——账户只能经父端任务锚交付（缺席=身份链断裂，不回退会话自派生新账），STATE_UNAVAILABLE fail-closed";
			closedReason = accountFatal;
			return denyAccount(accountFatal);
		} else {
			// ③/④ 子端自解析：argv 续接锚 → 本会话锚；派生需要冻结 grant 原文（env 交付）。
			const raw = rawGrantForDigest();
			argvAnchor = scanCodemodeSessionAnchorArgv(process.argv) ?? undefined;
			const ownAnchor = ownSessionAnchorOf(ctx);
			const anchor = argvAnchor ?? ownAnchor;
			if (raw === undefined || anchor === undefined) {
				accountFatal = argvAnchor === undefined && ownAnchor === undefined
					? "账户锚点不可解析（无 env 交付、无会话续接参数、会话面不可用）——STATE_UNAVAILABLE：不开无账户执行的洞"
					: "冻结 grant 原文缺席（AMAGI_PERMISSION_GRANT）——无法派生持久账户，STATE_UNAVAILABLE";
				closedReason = accountFatal;
				return denyAccount(accountFatal);
			}
			accountId = codemodeAccountIdOfRawGrant(raw, anchor);
		}
		const opened = openCodemodeLedger(accountId);
		if (!opened.ok) {
			if (opened.kind === "conflict") {
				// 可重试：本轮拒绝（不关闭）——写者退出后自动接管。
				recordControlledDenyEntry(state, { code: "STATE_UNAVAILABLE", toolCallId });
				forwardAudit("reserve");
				return { ok: false, retryable: true, reason: `[amagi codemode] ${opened.reason}` };
			}
			accountFatal = `[amagi codemode] 持久账本不可用（${opened.kind}）：${opened.reason}——codemode 已关闭（§5.3 损坏/缺失恢复状态使 codemode 关闭）`;
			closedReason = accountFatal;
			return denyAccount(accountFatal);
		}
		// fork 系别名收口：argv 续接锚 ≠ 本会话自身锚（fork 新会话沿用原账户）时，在本会话账户
		// 写 alias → 原账户（防「fork → resume 该 fork 会话」绕回新账户逃逸额度）。写失败即拒绝
		// （缺 alias 的未来 resume 会拿到全新账户——额度逃逸洞，fail-closed 不放行）。
		if (argvAnchor !== undefined) {
			const ownAnchor = ownSessionAnchorOf(ctx);
			if (ownAnchor !== undefined && ownAnchor !== argvAnchor) {
				const raw = rawGrantForDigest();
				if (raw !== undefined) {
					const ownAccountId = codemodeAccountIdOfRawGrant(raw, ownAnchor);
					const ownOpened = openCodemodeLedger(ownAccountId);
					if (ownOpened.ok) {
						const aliased = ownOpened.ledger.appendAlias(opened.ledger.accountId);
						ownOpened.ledger.release();
						if (!aliased) {
							accountFatal = "[amagi codemode] fork 会话别名记账失败（alias 落盘失败——防额度逃逸，fail-closed）——codemode 已关闭";
							closedReason = accountFatal;
							opened.ledger.release();
							return denyAccount(accountFatal);
						}
					} else {
						accountFatal = `[amagi codemode] fork 会话别名账本不可开（${ownOpened.kind}）——保守关闭`;
						closedReason = accountFatal;
						opened.ledger.release();
						return denyAccount(accountFatal);
					}
				}
			}
		}
		ledgerHandle = opened.ledger;
		// 快照播种（跨进程续跑：已用额度/保守 nested/执行资格消费集进入本进程执法状态）+
		// 账本通道挂接（此后 policy 预留/开始/结束先落盘成功才放行/登记——§5.3）。
		const consumed = applyCodemodeLedgerSnapshot(state, opened.snapshot);
		for (const id of consumed) consumedExecutes.add(id);
		state.ledger = opened.ledger;
		try { console.error(`[amagi-core] codemode 持久账户已打开（B5B）：account=${opened.ledger.accountId} · 已预留 scripts=${opened.snapshot.reservedScripts} tokens=${opened.snapshot.reservedTokens} ms=${opened.snapshot.reservedMs} · 保守nested=${opened.snapshot.sessionNestedCalls} · 消费集=${opened.snapshot.consumedToolCallIds.length}${opened.chain.length > 1 ? ` · alias链=${opened.chain.join("→")}` : ""}`); } catch { /* lint-exempt:诊断尽力而为 */ }
		return { ok: true };
	};

	// ── B5A 修复轮 F09：装配期身份认证基座。受控 scriptTools 的注册实现必须是宿主内置
	// （sourceInfo.path 前缀 builtin:，宿主加载器分配不可伪造）或 amagi 自身注册（amagi-core
	// 目录范围，如 win32 read override）实现；外部扩展同名覆盖（可携带任意副作用）在装配认证
	// 即关闭，不以「首次执行遇到的引用」冒充装配基线（运行期引用漂移检查保留为第二道验证）。
	const controlledToolDir = nodePath.dirname(fileURLToPath(import.meta.url)) + nodePath.sep;
	type ToolInfoLike = { name: string; parameters?: unknown; sourceInfo?: { path?: string; baseDir?: string } };
	const safeGetAllTools = (target: unknown): ToolInfoLike[] => {
		try {
			const fn = (target as { getAllTools?: () => unknown }).getAllTools;
			const out = typeof fn === "function" ? fn.call(target) : undefined;
			return Array.isArray(out) ? (out as ToolInfoLike[]) : [];
		} catch { /* lint-exempt:宿主注册表暂不可用按空面处理（认证保守延后） */ return []; }
	};
	const acceptableSource = (info: ToolInfoLike | undefined): boolean => {
		const src = info?.sourceInfo;
		if (src === undefined) return false;
		const p = String(src.path ?? "");
		if (p.startsWith("builtin:")) return true;
		const base = src.baseDir !== undefined ? String(src.baseDir) + nodePath.sep : "";
		return p.startsWith(controlledToolDir) || (base !== "" && base.startsWith(controlledToolDir));
	};

	// 延迟绑定真实 pi（截获定义闭包经 capturePi 转发 appendEntry/getAllTools）。
	let realPi: ExtensionAPI = pi;
	const capturePi = {
		registerTool(def: unknown): void {
			if (captured !== undefined) { captureError = "工厂注册了第二个工具（非预期）"; return; }
			captured = def as (ToolDefinition & Record<string, unknown>) | undefined;
		},
		appendEntry(customType: string, data: unknown): void {
			// 工厂内置 store 持久化（codemode-store 条目）——转发真实 pi（分支语义保留）。
			try { realPi.appendEntry(customType as never, data as never); } catch { /* lint-exempt:store 持久化尽力而为（会话分支语义保留） */ }
		},
		getAllTools(): Array<{ name: string; namespace?: unknown; promptGuidelines?: readonly string[] }> {
			try {
				return (realPi.getAllTools?.() ?? []) as Array<{ name: string; namespace?: unknown; promptGuidelines?: readonly string[] }>;
			} catch { /* lint-exempt:宿主注册表暂不可用按空面处理（过滤保守） */ return []; }
		},
		getSettings(): Record<string, unknown> { return {}; },
	} as never;

	let captured: (ToolDefinition & Record<string, unknown>) | undefined;
	let captureError: string | undefined;
	let registered = false;

	// ── 包装件（截获完成后装配） ──
	const inFlight = makeInFlightGate(4);
	const toolIdentityBaseline = new Map<string, unknown>();
	let assemblyReason: string | undefined;
	// B5A 修复轮 F05：外层结算等待在途 nested 真实收口（未确认收口不释放外层槽位）；
	// 同 toolCallId 并发重复 execute 去重（单一执行事实——审核 §5 DUPLICATE_EXECUTE 收口）。
	let nestedActive = 0;
	let pendingSettle: { toolCallId: string; outcome: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean } } | undefined;
	const executingIds = new Set<string>();
	// B5A 修复轮二 R2-02：执行资格消费集——toolCallId 一旦进入过 VM 即永久消费（含超时未收口期间与
	// 结算后重发）；幂等重复事件不再启动 VM，重试须新 toolCallId 重新准入计费（单一执行事实，§3.2/§5.2）。
	const consumedExecutes = new Set<string>();
	let certificationPending = false;
	const finalizeScript = (toolCallId: string, outcome: { ok: boolean; durationMs: number; nestedCalls: number; callsComplete: boolean }): void => {
		if (!settleControlledCodemodeScript(state, toolCallId, outcome)) {
			closedReason = "持久账本 end 写入失败——宿主真实结果保留，审计缺口已标记，后续 codemode 已关闭（§5.4）";
		}
		forwardAudit("tail");
	};
	const settleIfDrained = (): void => {
		if (pendingSettle !== undefined && nestedActive === 0) {
			const p = pendingSettle;
			pendingSettle = undefined;
			finalizeScript(p.toolCallId, p.outcome);
		}
	};

	const assembly = (): { ok: true; def: ToolDefinition & Record<string, unknown> } | { ok: false; reason: string } => {
		if (assemblyReason !== undefined) return { ok: false, reason: assemblyReason };
		return { ok: true, def: captured! };
	};

	const lookupFilteredTools = (ctxTools: readonly { name: string }[]): Array<{ name: string }> => {
		const out: Array<{ name: string }> = [];
		for (const t of ctxTools) {
			if (!allowed.has(t.name)) continue;
			const baseline = toolIdentityBaseline.get(t.name);
			if (baseline === undefined) toolIdentityBaseline.set(t.name, t);
			else if (baseline !== t) closedReason = `TOOLS_CHANGED：工具 ${t.name} 的注册身份在会话中被替换（名字白名单不再足够）`;
			out.push(t);
		}
		return out;
	};

	const filteredContextFor = (ctx: unknown, reservation: CodemodeReservation): unknown => {
		// 宿主 createToolContext 用 defineProperties 定义 tools（getter）与 executeTool（只读非可配置
		// 数据属性）——Proxy get 陷阱改值会违反 JS 不变量（真机试点实测报错）。改用原型委托：
		// Object.create(ctx) 保留全部懒 getter/原属性（零拷贝零路出新对象），仅在自有层覆写
		// tools（过滤投影）与 executeTool（验证转发）两项——新对象的自有覆写不触碰原属性不变量。
		const target = ctx as object;
		const filteredCtx: Record<string, unknown> = Object.create(target);
		Object.defineProperty(filteredCtx, "tools", {
			configurable: true,
			get() {
				const real = Reflect.get(target, "tools", target) as readonly { name: string }[];
				return lookupFilteredTools(Array.isArray(real) ? real : []);
			},
		});
		Object.defineProperty(filteredCtx, "executeTool", {
			configurable: true,
			writable: true,
			value: async (name: string, args: unknown, options?: { signal?: AbortSignal; onUpdate?: unknown }) => {
				if (closedReason !== undefined) {
					return nestedDeny(name, reservation, `[amagi codemode] ${closedReason}`);
				}
				if (!allowed.has(name)) {
					return nestedDeny(name, reservation, `[amagi codemode] TOOL_OUTSIDE_READ_SET：nested 工具 "${name}" 不在冻结只读集（${[...allowed].join(",")}）内——sandbox 物理不可达，拒绝`);
				}
				const nestedAdmission = admitControlledNestedCall(state, reservation);
				if (!nestedAdmission.ok) {
					return nestedDeny(name, reservation, `[amagi codemode] ${nestedAdmission.reason}`);
				}
				// B5A 修复轮 F05：闸等待绑定每请求 signal——abort 即移出队列取消；拿到槽位后仍复核
				// signal/预留代际，不复核不转发；在途未收口不释放外层（pendingSettle 收口）。
				const slot = await inFlight.acquire(options?.signal);
				if (!slot.ok) {
					return nestedDeny(name, reservation, `[amagi codemode] ${slot.reason}`);
				}
				nestedActive += 1;
				try {
					if (options?.signal?.aborted) {
						return nestedDeny(name, reservation, "[amagi codemode] 转发前复核：调用已中止（aborted）——取消转发（§5.2）");
					}
					if (state.active.get(reservation.toolCallId) !== reservation) {
						return nestedDeny(name, reservation, "[amagi codemode] 转发前复核：预留已结算/代际变化——取消转发（§5.2）");
					}
					const realExecute = Reflect.get(target, "executeTool", target) as (n: string, a: unknown, o?: unknown) => Promise<unknown>;
					// 转发前身份复核（第二道）：当前真实注册表中该名字实现须与基线一致且来源可信（F09）。
					const realTools = (Reflect.get(target, "tools", target) ?? []) as readonly { name: string }[];
					const current = Array.isArray(realTools) ? realTools.find((x) => x.name === name) : undefined;
					const baseline = toolIdentityBaseline.get(name);
					if (current === undefined || (baseline !== undefined && baseline !== current)) {
						return nestedDeny(name, reservation, `[amagi codemode] TOOLS_CHANGED：工具 ${name} 当前注册身份与装配基线不一致——拒绝转发`);
					}
					const registryEntry = safeGetAllTools(realPi).find((t) => t.name === name);
					if (registryEntry !== undefined && !acceptableSource(registryEntry)) {
						return nestedDeny(name, reservation, `[amagi codemode] TOOLS_CHANGED：工具 ${name} 注册来源非宿主内置/amagi 受控（${String(registryEntry.sourceInfo?.path ?? "unknown")}）——外部同名实现不可信，拒绝转发`);
					}
					return await realExecute(name, args, options);
				} finally {
					nestedActive = Math.max(0, nestedActive - 1);
					slot.release();
					settleIfDrained();
				}
			},
		});
		return filteredCtx;
	};

	const wrappedExecute = async (
		toolCallId: string,
		params: { code: string },
		signal: AbortSignal | undefined,
		onUpdate: ((result: unknown) => void) | undefined,
		ctx: unknown,
	): Promise<unknown> => {
		const assembled = assembly();
		if (!assembled.ok) {
			return toolDeny(`[amagi codemode] STATE_UNAVAILABLE：受控装配未成立（${assembled.reason}）——本会话 codemode 不可用，不回落内置实例`);
		}
		if (closedReason !== undefined) {
			return toolDeny(`[amagi codemode] ${closedReason}`);
		}
		// B5A 修复轮（审核 §5 DUPLICATE_EXECUTE）：同 toolCallId 并发重复 execute 去重——第二个并发
		// 进入直接拒绝，不重复进入真实 VM（预留幂等去重不覆盖双执行）。
		if (executingIds.has(toolCallId)) {
			return toolDeny(`[amagi codemode] 同一 toolCallId "${toolCallId}" 并发重复执行（STATE_UNAVAILABLE）——单一执行事实，重复进入拒绝（§3.2-4）`);
		}
		// B5A 修复轮二 R2-02：已消费的 toolCallId 永不重入（超时未收口/结算后同 ID 重发均拒）。
		if (consumedExecutes.has(toolCallId)) {
			return toolDeny(`[amagi codemode] toolCallId "${toolCallId}" 已消费单一执行（STATE_UNAVAILABLE）——重试须新 toolCallId 重新准入计费；未收口在途期间同 ID 重入同样拒绝（§3.2 单一执行事实/§5.2 未收口不复用）`);
		}
		executingIds.add(toolCallId);
		try {
			// B5A 修复轮 F07/F09：首次执行时延迟身份认证（注册表此时已活；真机实证装配时点过早必假失败）。
			if (certificationPending) {
				certificationPending = false;
				const certification = certifyAssemblyIdentity();
				verification.singleInstanceVerified = certification.ok;
				if (!certification.ok) {
					closedReason = `装配身份认证失败：${certification.reason}（TOOLS_CHANGED 口径关闭；§4.2-5）`;
					verification.reason = closedReason;
					registerCodemodeBlockHook(pi, closedReason);
					recordControlledDenyEntry(state, { code: "STATE_UNAVAILABLE", toolCallId, script: String(params?.code ?? "") });
					forwardAudit("reserve");
					try { console.error(`[amagi-core] 受控 codemode 装配身份认证失败（B5A 修复轮）：${certification.reason}——已挂拒钩子阻断`); } catch { /* lint-exempt:诊断尽力而为 */ }
					return toolDeny(`[amagi codemode] ${closedReason}`);
				}
				try { console.error("[amagi-core] codemode 装配身份认证通过（B5A 修复轮）：唯一受控实例 + scriptTools 来源白名单"); } catch { /* lint-exempt:诊断尽力而为 */ }
			}
			// B5B：持久账户开箱（首次执行时；冲突可重试拒绝、损坏/IO/无锚永久关闭）。
			const accountReady = ensureAccount(toolCallId, ctx);
			if (!accountReady.ok) {
				if (accountReady.retryable) {
					return toolDeny(`${accountReady.reason}——本轮 codemode 拒绝（写者退出后自动接管，可新 toolCallId 重试）`);
				}
				recordControlledDenyEntry(state, { code: "STATE_UNAVAILABLE", toolCallId, script: String(params?.code ?? "") });
				return toolDeny(accountReady.reason);
			}
			// 准入预留（原子；不返还；ledger 在场时先落盘成功才放行——§5.3）。B5A 修复轮二 R2-02：
			// 不复用旧预留——同 ID 重入已在消费集拒；每次进入 VM 都是新 toolCallId 的一次计费。
			const admission = admitControlledCodemodeScript(state, { code: String(params?.code ?? "") }, { toolCallId });
			if (!admission.allowed) {
				if (!forwardAudit("reserve")) {
					closedReason = "审计写入失败（reserve/deny 段）——后续 codemode 已关闭（§5.4）";
				}
				return toolDeny(admission.reason);
			}
			const reservation = admission.reservation;
			if (!forwardAudit("reserve")) {
				closedReason = "审计写入失败（reserve 段）——后续 codemode 已关闭（§5.4）";
				state.active.delete(toolCallId);
				return toolDeny("[amagi codemode] 审计写入失败（§5.4 fail-closed）——本次 codemode 不执行");
			}
			consumedExecutes.add(toolCallId);
			// B5A 修复轮二 R2-04：执行前 start 审计冲刷必须成功才启动 VM（§5.4 fail-closed）——
			// 已预留额度不退还；失败即拒绝本次并关闭后续（结算为失败，end 尽力冲刷）。
			if (!recordControlledStart(state, toolCallId)) {
				closedReason = "持久账本 start 写入失败——执行前账本不可用，后续 codemode 已关闭（§5.4 fail-closed）";
				settleControlledCodemodeScript(state, toolCallId, { ok: false, durationMs: 0, nestedCalls: reservation.nestedCalls, callsComplete: false });
				forwardAudit("reserve");
				return toolDeny("[amagi codemode] 持久账本 start 写入失败（§5.4 fail-closed）——本次 codemode 不执行（已预留额度不退还）");
			}
			if (!forwardAudit("reserve")) {
				closedReason = "审计写入失败（start 段）——执行前审计不可用，后续 codemode 已关闭（§5.4）";
				settleControlledCodemodeScript(state, toolCallId, { ok: false, durationMs: 0, nestedCalls: reservation.nestedCalls, callsComplete: false });
				forwardAudit("tail");
				return toolDeny("[amagi codemode] 审计写入失败（start 段，§5.4 fail-closed）——本次 codemode 不执行（已预留额度不退还）");
			}
			const startedAt = Date.now();
			let outcomeOk = false;
			try {
				const outcome = await (assembled.def.execute as (id: string, p: { code: string }, s: AbortSignal | undefined, u: ((r: unknown) => void) | undefined, c: unknown) => Promise<{ isError?: boolean }>) (
					toolCallId, params, signal, onUpdate, filteredContextFor(ctx, reservation),
				);
				outcomeOk = outcome?.isError !== true;
				// ev-20261031-80292c：保留名 SyntaxError 增强（交集空原样返回，纯增强零拒绝）。
				return enhanceCodemodeErrorResult(outcome, params.code);
			} catch (e) {
				outcomeOk = false;
				throw e;
			} finally {
				// B5A 修复轮 F05：在途 nested 未收口不释放外层（预留保留占用外层并发 ≤1 槽位，后续脚本
				// 拒绝）；最后一个 nested 收口时结算（真实结束状态/耗时/nested 数/完整性）。
				const outcome = { ok: outcomeOk, durationMs: Date.now() - startedAt, nestedCalls: reservation.nestedCalls, callsComplete: reservation.nestedCalls <= 256 };
				if (nestedActive > 0) {
					pendingSettle = { toolCallId, outcome };
				} else {
					finalizeScript(toolCallId, outcome);
				}
			}
		} finally {
			executingIds.delete(toolCallId);
		}
	};

	const wrappedPrepareLoadout = (loadout: unknown): unknown => {
		const assembled = assembly();
		if (!assembled.ok) return undefined;
		const original = assembled.def.prepareLoadout as (l: unknown) => unknown;
		const l = loadout as {
			declared: readonly { name: string }[]; callable: readonly { name: string }[]; registered: readonly { name: string }[];
			getExposure: (name: string) => unknown; getNamespace: (name: string) => unknown; getPromptGuidelines: (name: string) => readonly string[];
		};
		const filter = (list: readonly { name: string }[]): Array<{ name: string }> => list.filter((t) => allowed.has(t.name));
		const projected = {
			declared: filter(l.declared),
			callable: filter(l.callable),
			registered: filter(l.registered),
			getExposure: (name: string) => l.getExposure(name),
			getNamespace: (name: string) => l.getNamespace(name),
			getPromptGuidelines: (name: string) => l.getPromptGuidelines(name),
		};
		return original(projected);
	};

		// ── 注册主体（工厂探测续体内完成：capture → 形状校验 → 包装注册/哨兵）──
	// B5A 修复轮 F07：verification 是动态快照（异步探测期间消费方读到的必须是 pending 而非先验
	// 硬编码成功）；注册成功后立即做装配身份认证（codemode 唯一实例 + parameters 引用 + scriptTools
	// 来源白名单），认证失败 → 关闭 + 拒钩子；注册双失败（受控+哨兵）→ 拒钩子阻断原生实例一切调用。
	type WritableVerification = { -readonly [K in keyof CodemodeAssemblyVerification]: CodemodeAssemblyVerification[K] };
	const verification: WritableVerification = {
		assembled: false, factoryImported: false, captured: false, capturedShapeOk: false,
		modelsDisabled: false, singleInstanceVerified: false,
		scriptTools: [...allowed],
		reason: "装配探测进行中（异步）——动态快照，注册续体完成后更新",
	};
	const certifyAssemblyIdentity = (): { ok: true } | { ok: false; reason: string } => {
		const tools = safeGetAllTools(realPi);
		const codemodeEntries = tools.filter((t) => t.name === "codemode");
		if (codemodeEntries.length !== 1) {
			return { ok: false, reason: `getAllTools 中 codemode 实例数 ${codemodeEntries.length}（期望恰 1——同名替换未证明）` };
		}
		if (codemodeEntries[0]!.parameters !== captured?.parameters) {
			return { ok: false, reason: "注册表中 codemode 非本受控实例（parameters 引用不一致——身份认证失败）" };
		}
		for (const name of allowed) {
			const entries = tools.filter((t) => t.name === name);
			if (entries.length !== 1) {
			return { ok: false, reason: `工具 ${name} 在注册表出现 ${entries.length} 次（期望 1）` };
			}
			if (!acceptableSource(entries[0])) {
				return { ok: false, reason: `工具 ${name} 注册来源非宿主内置/amagi 受控（${String(entries[0]!.sourceInfo?.path ?? "unknown")}）——外部同名实现不可信（§4.2-5）` };
			}
		}
		return { ok: true };
	};
	// B5C（设计 §7 意识层）：子端实际生效工具面状态行注入——grant/账户/账本真实运行态投影
	//（闭包动态读 verification/closedReason；探测 promise 先 await 再计算，避免冻结「探测中」假 off）。
	registerCodemodeFaceLineHook(pi, async (ctx) => {
		await ensureControlledCodemodeFactory();
		return projectCodemodeChildFace({
			grant: { tools: [...allowed], budget: grant.budget },
			...(opts.account !== undefined ? { account: opts.account } : {}),
			status: { assembled: verification.assembled, ...(verification.reason !== undefined ? { reason: verification.reason } : {}), ...(closedReason !== undefined ? { closedReason } : {}) },
			// R1-03：本注册闭包已开账事实（零预留=本进程新开未消费，不按恢复丢账误伤）。
			...(ledgerHandle !== undefined ? { owned: { accountId: ledgerHandle.accountId, reserved: { scripts: state.reservedScripts, tokens: state.reservedTokens, ms: state.reservedMs } } } : {}),
			ctx,
		});
	});
	void ensureControlledCodemodeFactory().then((factory) => {
		if (registered) return;
		if (factory === null) {
			registered = true;
			verification.reason = "宿主无公开 createCodemodeExtension 工厂导出（STATE_UNAVAILABLE）";
			registerDenyStub(pi, verification.reason, opts);
			return;
		}
		verification.factoryImported = true;
		try {
			// 柯里工厂：createCodemodeExtension(options) 返回 ExtensionFactory(pi)——第一层传组合选项
			// （models:false 关桥 + mode 固定 on + 显式 inlineBudget 避免 getSettings 依赖），第二层截获注册。
			const extensionFactory = factory({ models: false, mode: "on", inlineBudget: 3000 }) as unknown as (pi: unknown) => void;
			if (typeof extensionFactory !== "function") throw new Error(`工厂返回非函数（${typeof extensionFactory}）`);
			extensionFactory(capturePi);
		} catch (e) {
			assemblyReason = `工厂执行失败：${e instanceof Error ? e.message : String(e)}`;
		}
		if (captureError !== undefined) assemblyReason = captureError;
		const def = captured;
		if (def === undefined) {
			assemblyReason = assemblyReason ?? "工厂未截获到 ToolDefinition";
		} else if (!(
			def.name === "codemode"
			&& def.exposure === "model-only"
			&& def.defaultActive === false
			&& typeof def.execute === "function"
			&& typeof def.prepareLoadout === "function"
		)) {
			assemblyReason = "截获定义形状与宿主 codemode 契约不符（name/exposure/defaultActive/execute/prepareLoadout）";
		}
		if (def !== undefined) {
			verification.captured = true;
			verification.modelsDisabled = true; // 工厂 options.models===false（装配面；沙箱探针见 e2e）
		}
		if (assemblyReason !== undefined) {
			registered = true;
			verification.reason = `${assemblyReason}（STATE_UNAVAILABLE）`;
			registerDenyStub(pi, verification.reason, opts);
			return;
		}
		verification.capturedShapeOk = true;
		try {
			pi.registerTool({
				...def!,
				name: "codemode",
				exposure: "model-only",
				defaultActive: false,
				execute: wrappedExecute,
				prepareLoadout: wrappedPrepareLoadout,
			} as unknown as ToolDefinition);
			registered = true;
			// B5A 修复轮二 R2-03：身份门附着于宿主最终分派入口——每次 codemode 外层 tool_call
			// 核对最终注册身份（唯一实例 + parameters 引用 === 受控截获定义）；替换窗口内宿主
			// 最终注册的其它实现（晚于/早于本注册，first-wins 任一方向）在调用点被拒，不依赖
			// 被替换实现自己调用认证。正常受控调用零影响（钩子只验身份，沙箱过滤仍在受控实例内）。
			registerCodemodeIdentityHook(pi, certifyAssemblyIdentity);
			// B5A 修复轮 F07/F09：身份认证为「首次执行时延迟认证」（真机实证：装配微任务时点
			// pi.getAllTools() 注册表尚未填充——宿主会话工具装配晚于扩展初始化，过早认证必假失败；
			// 首次执行时注册表已活，认证唯一实例 + parameters 引用 + scriptTools 来源白名单），
			// 失败→关闭+拒钩子；注册双失败（受控+哨兵）→ 拒钩子阻断原生实例一切调用。
			certificationPending = true;
			verification.assembled = true;
			verification.reason = undefined;
			try { console.error(`[amagi-core] 受控 codemode 已装配（B5A）：read-only tools=${[...allowed].join(",")} · models=off · budget=${grant.budget.maxScriptsPerSession}脚本/${grant.budget.maxTotalOutputTokens}tok/${grant.budget.maxTotalTimeoutMs}ms`); } catch { /* lint-exempt:装配成功诊断尽力而为 */ }
		} catch (e) {
			registered = true;
			verification.reason = `受控 codemode 注册失败（${e instanceof Error ? e.message : String(e)}；STATE_UNAVAILABLE）`;
			registerDenyStub(pi, verification.reason, opts);
		}
	});

	// B5B：会话关停释放租约（clean 退出；append close 见证 best-effort——账本本体不删不归零）。
	try {
		pi.on("session_shutdown", () => {
			try {
				if (ledgerHandle !== undefined) {
					ledgerHandle.appendClose("session_shutdown");
					ledgerHandle.release();
				}
			} catch { /* lint-exempt:释放失败留待 pid 死亡接管 */ }
		});
	} catch { /* lint-exempt:事件不可用防御 */ }

	const budget = grant.budget;
	return {
		// B5A 修复轮 F07：动态快照——异步装配期间读 pending；注册续体完成后更新（不先验硬编码成功）。
		verification,
		auditLog: () => [...state.audit],
		note: `read-only · tools=${[...allowed].join(",")} · models=off（工厂装配面） · budget=${budget.maxScriptsPerSession}×(${budget.maxOutputTokensPerScript}tok/${budget.maxTimeoutMsPerScript}ms) 聚合 ${budget.maxTotalOutputTokens}tok/${budget.maxTotalTimeoutMs}ms`,
		get closedReason() { return closedReason; },
	} as ControlledCodemodeRegistration;
}

// ── 拒绝结果与哨兵 ─────────────────────────────────────────────────────────────

function toolDeny(text: string): { content: Array<{ type: "text"; text: string }>; isError: true } {
	return { content: [{ type: "text", text }], isError: true };
}

function nestedDeny(name: string, reservation: CodemodeReservation, text: string): unknown {
	return {
		toolCall: { type: "toolCall", id: `${reservation.toolCallId}/0`, name, arguments: {} },
		result: toolDeny(text),
		isError: true,
	};
}

/** 恒拒哨兵（同名占位替换内置 codemode——物理保证无 models:true 实例可回落）。 */
function registerDenyStub(pi: ExtensionAPI, reason: string, opts: RegisterControlledCodemodeOptions): ControlledCodemodeRegistration {
	// B5C（设计 §7 意识层）：哨兵路径同样注入状态行——off 事实 + 拒因（措辞不暗示可调用）。
	// B5C 修复轮二 R1-02：状态行不含自由文本——哨兵细节（reason）留在 codemode 调用返回与
	// stderr 诊断，状态行用封闭枚举短语（整行 ∈ 模板展开集，门禁可冻结）。
	registerCodemodeFaceLineHook(pi, () => childOffLine("assemblyUnavailable"));
	try {
		pi.registerTool({
			name: "codemode",
			label: "codemode (unavailable)",
			description: `codemode 本会话不可用：${reason}（受控装配 fail-closed，不回落内置实例）`,
			promptSnippet: "codemode: off（受控装配未成立）",
			parameters: {
				type: "object",
				properties: { code: { type: "string", description: "codemode 脚本（本会话不可用——受控装配未成立）" } },
				required: ["code"],
				additionalProperties: false,
			},
			exposure: "model-only",
			defaultActive: false,
			execute: async () => toolDeny(`[amagi codemode] STATE_UNAVAILABLE：${reason}——受控装配未成立，本会话 codemode 恒拒（不回落内置实例）`),
		} as unknown as ToolDefinition);
	} catch {
		/* B5A 修复轮 F07：哨兵同名注册也失败（注册面冲突/异常）→ 挂 tool_call 拒钩子阻断 codemode
		 * 一切调用（含未被替换的原生实例）——不以「试图注册哨兵」冒充关闭。 */
		registerCodemodeBlockHook(pi, `恒拒哨兵注册失败（${reason}）`);
	}
	return {
		verification: {
			assembled: false, factoryImported: false, captured: false, capturedShapeOk: false,
			modelsDisabled: false, singleInstanceVerified: false, scriptTools: [], reason,
		},
		auditLog: () => [],
		note: `deny-stub：${reason}`,
		closedReason: reason,
	};
}

/** B5A 修复轮 F08：子端紧急关闭/无受控 grant 时的哨兵注册导出（index.ts 消费——同名替换内置，
 * 不回落原生实例；拒绝理由随调用返回）。 */
export function registerControlledCodemodeDenyStub(pi: ExtensionAPI, reason: string): ControlledCodemodeRegistration {
	return registerDenyStub(pi, reason, { grant: {} });
}

/** B5A 修复轮 F07：tool_call 拒钩子——注册（受控/哨兵）双失败或装配身份认证失败时阻断 codemode
 * 一切调用（含同名未被替换的原生实例）。钩子注册自身失败时 deny-stub/关闭态已是最后防线。 */
function registerCodemodeBlockHook(pi: ExtensionAPI, reason: string): void {
	try {
		(pi as unknown as {
			on: (event: "tool_call", handler: (ev: { toolName?: string }) => { block: boolean; reason: string } | undefined) => () => void;
		}).on("tool_call", (ev) => {
			if (ev.toolName === "codemode") {
				return { block: true, reason: `[amagi codemode] STATE_UNAVAILABLE：${reason}——本会话 codemode 全部调用阻断（fail-closed，不回落内置实例）` };
			}
			return undefined;
		});
	} catch { /* lint-exempt:钩子注册失败时 deny-stub/关闭态已是最后防线 */ }
}

/** B5A 修复轮二 R2-03：codemode 身份钩子——附着于宿主最终分派入口的稳定身份门。每次 codemode
 * 外层 tool_call 现场核对最终注册身份（certifyAssemblyIdentity：唯一实例 + parameters 引用 +
 * scriptTools 来源白名单）；非受控实例（同名替换/first-wins 落败）调用即拒，不依赖被替换实现
 * 自己调用认证。正常受控调用返回 undefined 放行（沙箱物理过滤仍在受控实例内，不以钩子替代）。 */
function registerCodemodeIdentityHook(pi: ExtensionAPI, certify: () => { ok: true } | { ok: false; reason: string }): void {
	try {
		(pi as unknown as {
			on: (event: "tool_call", handler: (ev: { toolName?: string }) => { block: boolean; reason: string } | undefined) => () => void;
		}).on("tool_call", (ev) => {
			if (ev.toolName !== "codemode") return undefined;
			const certification = certify();
			if (certification.ok) return undefined;
			return {
				block: true,
				reason: `[amagi codemode] TOOLS_CHANGED：最终注册的 codemode 非本受控实例（${certification.reason}）——调用阻断，不回落未认证实现（§4.2-5，修复轮二 R2-03）`,
			};
		});
	} catch { /* lint-exempt:钩子注册失败时首执延迟认证与 deny-stub 仍是防线 */ }
}

/** 注册后运行时替换证明（session_start/执行期调用）：getAllTools 中 codemode 恰 1 个。 */
export function verifySingleCodemodeInstance(pi: Pick<ExtensionAPI, "getAllTools">): boolean {
	try {
		return (pi.getAllTools?.() ?? []).filter((t) => t.name === "codemode").length === 1;
	} catch {
		/* lint-exempt:宿主 getAllTools 不可用按单实例未证明处理（保守拒绝） */
		return false;
	}
}

/** 嵌套在途闸（§5.1：nested 并发 4；acquire 前已计入 128/排队限额）。
 *  B5A 修复轮 F05：闸等待绑定每请求 signal——abort 即移出队列取消（不转发）；拿到槽位后
 *  由调用方复核 signal/预留代际再转发。 */
function makeInFlightGate(max: number): {
	acquire(signal?: AbortSignal): Promise<{ ok: true; release(): void } | { ok: false; reason: string }>;
	activeCount(): number;
} {
	let active = 0;
	type Waiter = { resolve: (v: { ok: true; release(): void } | { ok: false; reason: string }) => void; onAbort: () => void };
	const queue: Waiter[] = [];
	const drain = (): void => {
		while (active < max && queue.length > 0) {
			active += 1;
			queue.shift()!.resolve({
				ok: true,
				release: (): void => {
					active = Math.max(0, active - 1);
					drain();
				},
			});
		}
	};
	return {
		acquire(signal) {
			return new Promise((resolve) => {
				if (signal?.aborted) {
					resolve({ ok: false, reason: "脚本超时/中止（aborted）——排队 nested 调用取消转发（§5.2）" });
					return;
				}
				const waiter: Waiter = {
					resolve,
					onAbort: (): void => {
						const idx = queue.indexOf(waiter);
						if (idx >= 0) {
								queue.splice(idx, 1);
								resolve({ ok: false, reason: "脚本超时/中止（aborted）——排队 nested 调用移出闸并取消（§5.2）" });
						}
					},
				};
				signal?.addEventListener("abort", waiter.onAbort, { once: true });
				queue.push(waiter);
				drain();
			});
		},
		activeCount: (): number => active,
	};
}
