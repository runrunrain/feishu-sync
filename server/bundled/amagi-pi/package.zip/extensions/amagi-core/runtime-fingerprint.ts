/** Load-time source snapshot. This identifies observed source bytes, not jiti's module cache. */
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { ProviderDiagnostic } from "./provider-diagnostics.ts";
import { detectRunningHostVersion } from "./host-capabilities.ts";

export interface RuntimeFingerprint {
	fingerprintVersion: 1;
	amagiVersion: string | null;
	commit: { sha: string | null; source: "git-fs" | "none" };
	source: { status: "ok" | "unknown"; digest: string | null; scope: "source-snapshot-not-loaded-modules"; reason?: "source-unavailable" };
	hostVersion: string | null;
	loadedAt: number;
	pid: number;
	loadSeq: number;
	role: "leader" | "subagent";
	digest: string | null;
}

function sha(value: string | Buffer): string { return createHash("sha256").update(value).digest("hex"); }
function gitCommit(root: string): RuntimeFingerprint["commit"] {
	try {
		let dir = path.join(root, ".git");
		if (fs.statSync(dir).isFile()) {
			const link = fs.readFileSync(dir, "utf8").trim().match(/^gitdir:\s*(.+)$/);
			if (!link) throw new Error("invalid gitdir");
			dir = path.resolve(root, link[1]);
		}
		const head = fs.readFileSync(path.join(dir, "HEAD"), "utf8").trim();
		let value = head;
		if (head.startsWith("ref: ")) {
			const ref = head.slice(5);
			let common = dir;
			try { common = path.resolve(dir, fs.readFileSync(path.join(dir, "commondir"), "utf8").trim()); } catch { /* lint-exempt: ordinary repositories have no commondir; use git dir */ }
			try { value = fs.readFileSync(path.join(dir, ref), "utf8").trim(); }
			catch { /* journal: loose ref absent, try common repository */
				try { value = fs.readFileSync(path.join(common, ref), "utf8").trim(); }
				catch { /* journal: loose ref absent, try packed refs */ value = fs.readFileSync(path.join(common, "packed-refs"), "utf8").split(/\r?\n/).find((line) => line.endsWith(` ${ref}`))?.split(" ")[0] ?? ""; }
			}
		}
		if (!/^[a-f0-9]{40,64}$/i.test(value)) throw new Error("invalid sha");
		return { sha: value, source: "git-fs" };
	} catch { /* journal: unresolvable commit is explicitly unknown */ return { sha: null, source: "none" }; }
}

/** The entire snapshot is unknown if any member cannot be read; never hash a partial tree. */
export function captureRuntimeFingerprint(root: string, options: { hostVersion: string | null; loadSeq: number; role: "leader" | "subagent" }): Readonly<RuntimeFingerprint> {
	let version: string | null = null;
	let sourceDigest: string | null = null;
	try {
		const pkg = fs.readFileSync(path.join(root, "package.json"));
		const parsed = JSON.parse(pkg.toString("utf8"));
		if (typeof parsed.version === "string" && /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(parsed.version)) version = parsed.version;
		const files: string[] = [];
		const walk = (dir: string): void => {
			for (const entry of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
				const rel = path.join(dir, entry.name);
				if (rel === path.join("extensions", "amagi-core", "webui", "static")) continue;
				if (entry.isSymbolicLink()) throw new Error("source symlink not captured");
				if (entry.isDirectory()) walk(rel);
				else if (entry.isFile() && entry.name.endsWith(".ts")) files.push(rel);
			}
		};
		walk(path.join("extensions", "amagi-core"));
		files.sort();
		const hash = createHash("sha256");
		hash.update(JSON.stringify(["package.json", sha(pkg)]));
		for (const file of files) hash.update(JSON.stringify([file.split(path.sep).join("/"), sha(fs.readFileSync(path.join(root, file)))]));
		sourceDigest = hash.digest("hex");
	} catch { /* journal: source-unavailable reported below, never hash a partial snapshot */ }
	const commit = Object.freeze(gitCommit(root));
	const source = Object.freeze({ status: sourceDigest ? "ok" as const : "unknown" as const, digest: sourceDigest, scope: "source-snapshot-not-loaded-modules" as const, ...(sourceDigest ? {} : { reason: "source-unavailable" as const }) });
	const digest = sourceDigest ? sha(JSON.stringify([version, commit.sha, sourceDigest, options.hostVersion])).slice(0, 16) : null;
	return Object.freeze({ fingerprintVersion: 1 as const, amagiVersion: version, commit, source, hostVersion: options.hostVersion, loadedAt: Date.now(), pid: process.pid, loadSeq: options.loadSeq, role: options.role, digest });
}

const globalCounter = globalThis as typeof globalThis & { __amagiRuntimeLoadSeq?: number };
const loadSeq = (globalCounter.__amagiRuntimeLoadSeq ?? 0) + 1;
globalCounter.__amagiRuntimeLoadSeq = loadSeq;
// Resolve the executing CLI, not this extension's local development dependency.
// SDK embedding without a pi CLI entry is explicitly unknown.
const hostVersion = detectRunningHostVersion();
export const RUNTIME_FINGERPRINT = captureRuntimeFingerprint(path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../.."), { hostVersion, loadSeq, role: process.env.AMAGI_SUBAGENT === "1" ? "subagent" : "leader" });

export interface SessionRuntimeStamp { fingerprint: Readonly<RuntimeFingerprint>; reason: string; surfaceHash: string | null; scope?: "session" | "transport"; leaderDigest?: string; mismatch?: boolean }
// Internal parent→child delivery, captured once; absent/invalid never implies equality.
const inheritedLeaderDigest = /^[a-f0-9]{16}$/.test(process.env.AMAGI_LEADER_RUNTIME_DIGEST ?? "") ? process.env.AMAGI_LEADER_RUNTIME_DIGEST : undefined;
function freezeSnapshot<T>(value: T): T {
	if (value && typeof value === "object" && !Object.isFrozen(value)) {
		for (const item of Object.values(value)) freezeSnapshot(item);
		Object.freeze(value);
	}
	return value;
}
let currentStamp: SessionRuntimeStamp | undefined;
export function currentSessionRuntimeStamp(): SessionRuntimeStamp | undefined { return currentStamp; }
function stable(value: unknown): unknown {
	if (Array.isArray(value)) return value.map(stable);
	if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => [key, stable(item)]));
	return value;
}
export function runtimeSurfaceHash(pi: Pick<ExtensionAPI, "getAllTools" | "getActiveTools">): string | null {
	try {
		const tools = pi.getAllTools().map((t) => ({ name: t.name, parameters: t.parameters })).sort((a, b) => a.name.localeCompare(b.name));
		return sha(JSON.stringify(stable([tools, [...pi.getActiveTools()].sort()])));
	} catch { /* journal: unavailable tool surface reported as unknown */ return null; }
}
export function registerRuntimeFingerprint(pi: ExtensionAPI, surfaceVersion?: number): void {
	pi.on("session_start", (event, ctx) => {
		const hash = runtimeSurfaceHash(pi);
		const stamp: SessionRuntimeStamp = freezeSnapshot({ fingerprint: RUNTIME_FINGERPRINT, reason: event.reason, surfaceHash: hash && surfaceVersion !== undefined ? sha(JSON.stringify([hash, surfaceVersion])) : hash, scope: "session", ...(RUNTIME_FINGERPRINT.role === "subagent" && inheritedLeaderDigest ? { leaderDigest: inheritedLeaderDigest, ...(RUNTIME_FINGERPRINT.hostVersion && RUNTIME_FINGERPRINT.digest ? { mismatch: inheritedLeaderDigest !== RUNTIME_FINGERPRINT.digest } : {}) } : {}) });
		currentStamp = stamp;
		if (!RUNTIME_FINGERPRINT.source.digest || !stamp.surfaceHash) console.warn("[amagi] runtime fingerprint incomplete: source or tool surface unknown");
		let previous: ReturnType<typeof ctx.sessionManager.getBranch>[number] | undefined;
		try { previous = [...ctx.sessionManager.getBranch()].reverse().find((entry) => entry.type === "custom" && entry.customType === "amagi:runtime-fingerprint"); }
		catch { /* journal: prior entries unavailable */ console.warn("[amagi] runtime fingerprint: prior session entries unavailable"); }
		const data = previous && "data" in previous ? previous.data as SessionRuntimeStamp | undefined : undefined;
		if (event.reason === "reload" || !data || data.fingerprint?.digest !== stamp.fingerprint.digest || data.surfaceHash !== stamp.surfaceHash) {
			try { pi.appendEntry("amagi:runtime-fingerprint", stamp); } catch { /* journal: session entry unavailable */ console.warn("[amagi] runtime fingerprint: session entry unavailable"); }
		}
		// print/json subscribes after startup; re-emit at first prompt so the parent can observe it.
	});
	pi.on("before_agent_start", () => {
		if (!currentStamp) return;
		try { pi.appendEntry("amagi:runtime-fingerprint", { ...currentStamp, scope: "transport" }); } catch { /* journal: transport entry unavailable */ console.warn("[amagi] runtime fingerprint: transport entry unavailable"); }
	});
}

/** Per-run facts: unknown fields remain absent, never filled from current source. */
export interface RuntimeObservation {
	runtime: { leader: Readonly<RuntimeFingerprint>; child?: SessionRuntimeStamp; mismatch?: boolean };
	providerDiagnostic?: { latest: ProviderDiagnostic; hostAttempt: number | null; hostMaxAttempts: number | null; lastDelayMs: number | null };
}
export interface RuntimeEventAccumulator {
	child?: SessionRuntimeStamp;
	latest?: ProviderDiagnostic;
	hostAttempt: number | null;
	hostMaxAttempts: number | null;
	lastDelayMs: number | null;
}
export function newRuntimeEventAccumulator(): RuntimeEventAccumulator {
	return { hostAttempt: null, hostMaxAttempts: null, lastDelayMs: null };
}
function safeId(value: unknown): string {
	return typeof value === "string" && /^[A-Za-z0-9_.:-]{1,128}$/.test(value) && !/sentinel|bearer|authorization|(?:^|[-_])(?:sk|key|token)[-_]/i.test(value) ? value : "unknown";
}
function safeDiagnostic(data: any): ProviderDiagnostic | undefined {
	if (data?.diagVersion !== 1 || data.sideEffectReplay !== false || !["network", "rate-limit", "authentication", "other"].includes(data.category)) return undefined;
	const number = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : 0;
	const anchor = data.anchors?.lastSuccessfulTool;
	const recovery = data.amagiRecovery;
	const allowed = new Set(["ECONNRESET", "ECONNREFUSED", "EPIPE", "ENOTFOUND", "ETIMEDOUT", "ENETUNREACH", "EHOSTUNREACH", "UND_ERR_SOCKET", "UND_ERR_CONNECT_TIMEOUT", "UND_ERR_HEADERS_TIMEOUT", "UND_ERR_BODY_TIMEOUT"]);
	return { diagVersion: 1, at: number(data.at), model: { provider: safeId(data.model?.provider), id: safeId(data.model?.id) }, modelChanged: data.modelChanged === true, category: data.category, transport: Array.isArray(data.transport) ? data.transport.filter((x: any) => allowed.has(x?.code)).slice(-8).map((x: any) => ({ code: x.code, correlation: "temporal-unconfirmed" as const })) : [], consecutiveErrors: number(data.consecutiveErrors), hostRetryBudget: "unknown", ...(recovery && typeof recovery === "object" ? { amagiRecovery: { attempts: number(recovery.attempts), max: number(recovery.max), windowMs: number(recovery.windowMs) } } : {}), anchors: { ...(anchor && typeof anchor === "object" ? { lastSuccessfulTool: { toolName: safeId(anchor.toolName), toolCallId: safeId(anchor.toolCallId), at: number(anchor.at) } } : {}) }, sideEffectReplay: false };
}
function safeStamp(data: any): SessionRuntimeStamp | undefined {
	const f = data?.fingerprint;
	const hex = (v: unknown, n: number) => typeof v === "string" && new RegExp(`^[a-f0-9]{${n}}$`).test(v) ? v : null;
	if (f?.fingerprintVersion !== 1 || !["leader", "subagent"].includes(f.role)) return undefined;
	const sourceDigest = hex(f.source?.digest, 64);
	const version = (v: unknown) => typeof v === "string" && /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(v) ? v : null;
	const number = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : 0;
	const commit = typeof f.commit?.sha === "string" && /^[a-f0-9]{40,64}$/.test(f.commit.sha) ? f.commit.sha : null;
	const leaderDigest = hex(data.leaderDigest, 16);
	const childDigest = hex(f.digest, 16);
	return { fingerprint: { fingerprintVersion: 1, amagiVersion: version(f.amagiVersion), commit: { sha: commit, source: commit ? "git-fs" : "none" }, source: { status: sourceDigest ? "ok" : "unknown", digest: sourceDigest, scope: "source-snapshot-not-loaded-modules", ...(sourceDigest ? {} : { reason: "source-unavailable" as const }) }, hostVersion: version(f.hostVersion), loadedAt: number(f.loadedAt), pid: number(f.pid), loadSeq: number(f.loadSeq), role: f.role, digest: childDigest }, reason: ["startup", "reload", "new", "resume", "fork"].includes(data.reason) ? data.reason : "unknown", surfaceHash: hex(data.surfaceHash, 64), scope: data.scope === "transport" ? "transport" : "session", ...(leaderDigest ? { leaderDigest, ...(childDigest && version(f.hostVersion) ? { mismatch: leaderDigest !== childDigest } : {}) } : {}) };
}
export function observeRuntimeEvent(acc: RuntimeEventAccumulator, event: any): void {
	if (event?.type === "auto_retry_start") {
		const number = (v: unknown) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : null;
		acc.hostAttempt = number(event.attempt); acc.hostMaxAttempts = number(event.maxAttempts); acc.lastDelayMs = number(event.delayMs);
	} else if (event?.type === "entry_appended" && event.entry?.type === "custom") {
		const data = event.entry.data;
		if (event.entry.customType === "amagi:runtime-fingerprint") { const stamp = safeStamp(data); if (stamp) acc.child = stamp; }
		if (event.entry.customType === "amagi:provider-diagnostic") { const diag = safeDiagnostic(data); if (diag) acc.latest = diag; }
	}
}
export function runtimeObservation(acc: RuntimeEventAccumulator, leader: Readonly<RuntimeFingerprint> = RUNTIME_FINGERPRINT): RuntimeObservation {
	const child = acc.child;
	const a = leader.source.digest, b = child?.fingerprint.source.digest;
	const mismatch = a && b ? (a !== b ? true : leader.hostVersion && child?.fingerprint.hostVersion ? leader.digest !== child.fingerprint.digest : undefined) : undefined;
	return freezeSnapshot({ runtime: { leader, ...(child ? { child } : {}), ...(mismatch !== undefined ? { mismatch } : {}) }, ...(acc.latest ? { providerDiagnostic: { latest: acc.latest, hostAttempt: acc.hostAttempt, hostMaxAttempts: acc.hostMaxAttempts, lastDelayMs: acc.lastDelayMs } } : {}) });
}
export function formatRuntimeObservation(value: RuntimeObservation): string {
	const r = value.runtime, d = value.providerDiagnostic;
	return `runtime amagi ${r.leader.amagiVersion ?? "unknown"} src=${r.leader.source.digest?.slice(0, 12) ?? "unknown"} child=${r.child?.fingerprint.digest ?? "unknown"}${r.mismatch ? " 子≠Leader!" : ""}` + (d ? ` | provider ${d.latest.category} ×${d.latest.consecutiveErrors} host ${d.hostAttempt ?? "unknown"}/${d.hostMaxAttempts ?? "unknown"} amagi ${d.latest.amagiRecovery ? `${d.latest.amagiRecovery.attempts}/${d.latest.amagiRecovery.max}` : "unknown"}${d.latest.anchors.lastSuccessfulTool ? ` 最近成功工具 ${d.latest.anchors.lastSuccessfulTool.toolName}` : ""}` : "");
}
