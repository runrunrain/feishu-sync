/** 按主题帮助；用户命令使用非上下文 custom entry，模型显式读取才进入工具结果。
 * 方法参考 nicobailon/pi-subagents 的 guide/doctor 与 slim completion；实现由 amagi 自有契约生成。
 */
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Text } from "@earendil-works/pi-tui";
import { tuiLog } from "./tui-console.ts";

export const HARNESS_GUIDE_TOPICS = ["overview", "tasks", "config", "mcp", "recovery"] as const;
export type HarnessGuideTopic = typeof HARNESS_GUIDE_TOPICS[number];
export const HARNESS_INFO_ENTRY = "amagi:harness-info";

/** 用户命令的长说明持久化为原生 custom entry，宿主不将其投影进模型上下文。 */
export function harnessInfoEmitter(pi: Pick<ExtensionAPI, "appendEntry">, rendererAvailable: boolean) {
	return (text: string, ctx: { mode?: string }): void => {
		if (rendererAvailable && ctx.mode === "tui") {
			try { pi.appendEntry(HARNESS_INFO_ENTRY, { text }); return; }
			catch { /* lint-exempt:展示不可用时回落用户输出，不注入模型消息 */ }
		}
		tuiLog(text);
	};
}

const guides: Record<HarnessGuideTopic, string> = {
	overview: [
		"amagi 起步：当前 pi 提供普通工具、模型认证和 MCP；amagi 提供任务契约与验收。",
		"先用 /amagi doctor 检查模型与宿主，再用 /amagi config explain 看选模来源。",
		"需要继承当前模型：/amagi config init inherit（只创建项目配置；已有配置不覆盖）。",
		"可用 task_submit({ agent: \"luban\", task: \"目标、边界与验收要求\" })；已有任务书用 taskFile。",
		"执行完成 ≠ 结算就绪 ≠ 验收通过；状态 task_query，接受 task_control accept。",
		"详细主题：/amagi guide tasks | config | mcp | recovery；模型可显式读 amagi_resource({resource:\"guide-tasks\"})。",
	].join("\n"),
	tasks: [
		"任务派发：只手写目标、边界、验收和必要输入；模型、报告位置及内部标识沿用运行时。",
		'task_submit({ agent: "luban", task: "完整任务书：目标、边界、验收要求", inputPaths: ["src"], outputPaths: ["reports/result.md"], delivery: "handle" })',
		"新任务书无论长短直接传 task，一次派发，harness 自动冻结保存后启动子 Agent，无需先 Write。",
		"contextMode 按任务选：selected 自动选相关调查与最近用户要求，fork 继承当前可见文本历史，isolated 独立执行（兼容缺省）。selected 可用 contextRefs 指定来源锚点；快照、冻结、派发同次完成。",
		"task/taskFile 恰选一个；taskFile 引用已有文件，在调用者 cwd 读取 UTF-8 快照；同批并行写同一文件的 Write/Edit 会被自动等待完成后再读。",
		"inputPaths 是必读输入简写；outputPaths 是必需文件产物简写。可选/目录树用 inputs/outputs 对象。",
		"权限仍由请求∩角色∩用户∩后端冻结；缺少 shell/MCP/LSP 授权时应明确声明或由主会话代验，不自动扩权。",
		'task_query({ handle: "任务句柄" })；task_control({ action: "wait", handles: ["任务句柄"] })。',
		"task_query receipt 查看当前 receiptId/revision；task_control accept 必须引用它们，不能把 done 当 accepted。",
		'amagi_resource({ resource: "tools", enableFacet: "batch" }) 显式启用 task_batch；依赖简写缺省 requires=accepted。',
	].join("\n"),
	config: [
		"配置：/amagi config explain [角色] 显示最终模型、来源、覆盖关系和未设置的层级。",
		"顺序：本次显式模型 → 项目 amagi.json → 全局 amagi.json → profile → 角色 frontmatter → 当前 pi 模型。",
		"/amagi config init inherit 为起步预设；init tiered 保留分层选模。仅创建当前项目 amagi.json，不覆盖已有文件或改 pi 设置。",
		"既有个人配置、环境变量、角色上限及恢复身份不被预设重置；解释和 doctor 不创建配置。",
		"模型目录与登录由 pi 管理；MCP 原生配置与 /mcp 由 pi 管理；amagi.json 只表达 amagi 策略。",
		'统一压缩模型：amagi.json 的 compaction.model="provider/model[:thinking]"；Leader 与子 Agent 的 /compact 及自动压缩共用。项目优先于全局；未设置沿用原生当前模型，null 禁用继承。',
		"完整字段：amagi_resource({resource:\"config-reference\"})；本文件从配置 schema 生成。",
	].join("\n"),
	mcp: [
		"MCP：优先用 pi 原生 /mcp 管理连接、发现、禁用与认证。amagi 只增补角色路由和冻结授权。",
		"宿主发现的工具及 codemode 嵌套调用均经过权限事件链；兼容 mcp_call 也委托同一链。",
		"工具尚未可见时查看 /mcp，不新建第二条连接。复杂/hash 名称缺少可信原名映射时拒绝猜测。",
		"mcp_call/mcp_list_tools 保留供旧角色、旧会话及明确兼容后端使用；业务 arguments 原样传递。",
		"原生禁用不能被旧配置重启；mixed owner 只决定连接分工，不授予权限。",
	].join("\n"),
	recovery: [
		"恢复：/amagi recovery 只读检查；/amagi recovery show <完整taskId> 显式展开断点。",
		"task_resume 继承原任务权限、模型和工作目录；续接产生新 taskId，不能把它当旧回执的接受。",
		"本机待对账记录用 task_control reconcile（按启动锚点证明退出：已退出→按未完成关闭，仍存活/证据不足→拒绝；无锚点旧记录先 /amagi recovery confirm-exited <taskId> 人工确认）；foreign-owner 收口用 /amagi recovery adopt <taskId>；跨会话历史保持 pull-only。",
		"summary/wait/压缩只携带当前决策需要的摘要与归档引用；完整输出通过 task_query output 显式读取。",
		"会话修复使用原生分支投影和独立 fork，不物理删除源历史；旧宿主能力不足时明确拒绝自动改历史。",
	].join("\n"),
};

export function harnessGuide(topic: string = "overview"): { ok: boolean; text: string } {
	if (!HARNESS_GUIDE_TOPICS.includes(topic as HarnessGuideTopic)) return { ok: false, text: `未知帮助主题：${topic}；可用 ${HARNESS_GUIDE_TOPICS.join(", ")}` };
	return { ok: true, text: guides[topic as HarnessGuideTopic] };
}

export function registerHarnessInfoRenderer(pi: ExtensionAPI): boolean {
	if (typeof pi.registerEntryRenderer !== "function") return false;
	pi.registerEntryRenderer<{ text: string }>(HARNESS_INFO_ENTRY, (entry) => new Text(entry.data?.text ?? "amagi 帮助记录", 0, 0));
	return true;
}
