/**
 * baseline-scope.ts — B10（ev-20261008-eb1e27，主上裁定①+②）：隔离任务终态自动基线检查的
 * 写面感知与兄弟切片干扰豁免——判定输入构造面（判定执行面在 evidence.ts runStructuredCheck）。
 *
 * 背景（三次活体：本仓 evolve 会话 B7/B8/B9 批次，回执佐证 chk-auto-baseline-test-* exit=0
 * 仍 ✗/incomplete）：隔离子任务终态自动检查在临时副本运行**根 npm test 全量**（21-22s/任务），
 * 与任务书/AGENTS「按变更局部验证」约定冲突；共享树其他独立切片的修改（含全量跑触发的跨包
 * runner 状态写入冻结依赖副本）使 exit=0 的检查被 object-changed 渲染为 ✗ 失败、
 * settlement=incomplete、missing chk-auto-baseline-test-*，Leader 三次手工豁免。
 *
 * 本模块（有界文件系统探测 + 纯数据构造，不执行任何命令）：
 *   1. collectTaskWriteSurface：任务 own 写面登记 = 冻结 spec outputs / permission.write /
 *      reportFiles 声明路径 + 子进程写面登记（readTaskWrites）+ 可选 fresh 变更∩声明面前缀
 *      ——具体文件与目录前缀两档（保守方向：声明面内并行改动计入 own，宁可少豁免）。
 *   2. selectBaselineSubset：按 own 写面推导相关测试集——测试文件与写面文件名 stem 前缀/
 *      目录前缀匹配 + 测试文件直接 import 链文本引用；探测 scripts.test 为 node --test 直跑
 *      形态时构造子集 argv；写面为空/无匹配/子集=全集/runner 不支持 → full（保守回退，
 *      basis 披露——不做默认全仓冗余执行，全量跑保留给 Leader 最终收口/发布门禁）。
 *   3. collectSiblingSurfaces：同 cwd 并行任务写面（豁免归属披露用；登记缺失=如实「未归属」）。
 *
 * 边界（本片冻结）：不执行检查（evidence.ts）、不结算（deriveSettlementFace/finalizer）、
 * 不改变 Leader 侧最终验收全量跑义务、不动三轴语义与 accept 栅栏；豁免判定不在本模块。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { contractStoreRoot, sanitizeId } from "./artifact.ts";
import { freshChangedPaths, type BaselineScopeGuard, type TestExecutionPlan } from "./evidence.ts";
import { readTaskWrites } from "./task-write-log.ts";
import { registry } from "./task-registry.ts";
import type { PathRule } from "./contracts/permission.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 公共类型
// ─────────────────────────────────────────────────────────────────────────────

/** 任务 own 写面（相对 cwd 的 POSIX 相对路径；prefix 目录形态含尾 /，prefix 语法形态原样）。 */
export interface BaselineWriteSurface {
	/** 具体文件（排序去重；含声明文件面、写面登记、声明面前缀内 fresh 变更）。 */
	files: string[];
	/** 目录/前缀声明面（含 outputs kind=tree、PathRule directory/prefix、glob 静态前缀）。 */
	prefixes: string[];
	/** 披露片段（选择依据进回执/详情）。 */
	basisParts: string[];
}

/** 并行切片写面（归属披露）。 */
export interface SiblingSurface {
	label: string;
	files: string[];
	prefixes: string[];
}

/** 写面感知准备结果（selectBaselineSubset 与 scopeGuardOf 共用；避免重复目录扫描）。 */
export interface PreparedBaselineScope {
	/** null = 无法建立（无 taskId）。写面为空以 { files: [], prefixes: [] } 表达（full 回退 + 无守卫）。 */
	surface: BaselineWriteSurface | null;
	siblings: SiblingSurface[];
	/** 已发现测试文件（相对 cwd，POSIX；失败归属解析字典）。 */
	testFiles: string[];
}

/** 子集选择结果。mode=full 时 basis 说明回退原因；mode=subset 时携带 files（相对 execCwd）与 argv。
 *  修复轮 F-02/F-03：responsibleTests 为 own 责任测试集（直接命中+传递命中+不可判定纳入），
 *  subset/full 两种形态都携带——豁免判定把责任测试失败视为 own 责任（不得豁免）。 */
export interface BaselineSubsetSelection {
	mode: "subset" | "full";
	basis: string;
	/** mode=subset：选中的测试文件（相对 verificationRoot=cwd，POSIX）。 */
	files?: string[];
	/** mode=subset：子集执行 argv（node --test 直跑形态）。 */
	argv?: string[];
	/** own 责任测试集（排序去重）。 */
	responsibleTests?: string[];
}

// ─────────────────────────────────────────────────────────────────────────────
// 内部常量与工具
// ─────────────────────────────────────────────────────────────────────────────

/** 测试发现上限（文件/目录）与深度（典型 JS 仓 tests/ 一层；monorepo 子包 ≤4 层可达）。 */
const TEST_DISCOVERY_MAX_FILES = 2000;
const TEST_DISCOVERY_MAX_DIRS = 4000;
const TEST_DISCOVERY_MAX_DEPTH = 4;
/** 子集上限（超过视为选择失效，回退全量——推导面失控时保守）。 */
const SUBSET_MAX_FILES = 256;
/** own 写面文件登记上限（与 task-write-log 512 行口径同量级）。 */
const SURFACE_MAX_FILES = 512;
/** 内容引用匹配的读取上限（单测试文件字节）。 */
const CONTENT_SCAN_MAX_BYTES = 512 * 1024;
/** 兄弟面归集上限。 */
const SIBLING_MAX = 32;

/** 测试文件名形态（*.test.* / *.spec.*）。 */
const TEST_FILE_RE = /(^|\/)[^/]+\.(test|spec)\.(mjs|cjs|js|ts|mts|cts|tsx|jsx)$/;
/** 目录发现跳过集（外部依赖/构建产物/采集输出，非测试域）。 */
const DISCOVERY_SKIP_DIRS = new Set([
	"node_modules", ".git", "dist", "build", "out", "coverage", ".nyc_output",
	".agent-outputs", "agent-outputs", ".amagi-worktrees", ".reports", ".cache", ".turbo",
]);

/** 相对路径归一（→ POSIX、去 "./"、绝对路径按 cwd 相对化；越界返回 null）。 */
function toRelPosix(p: string, cwd: string): string | null {
	const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
	const rel = path.relative(path.resolve(cwd), abs);
	if (rel === "" || rel === ".." || rel.startsWith(`..${path.sep}`)) return null;
	return rel.split(path.sep).join("/");
}

/** PathRule → 前缀（kind 语义保守归一：directory→尾 /；prefix→原样；glob→首个通配符前静态段）。 */
function prefixOfRule(value: string, kind: PathRule["kind"]): string | null {
	if (kind === "directory") return value.endsWith("/") ? value : `${value}/`;
	if (kind === "prefix") return value;
	// glob：取首个通配符前的静态前缀（无通配符的 glob=精确文件语义，交给调用方文件档）
	const idx = [...value].findIndex((ch) => ch === "*" || ch === "?");
	if (idx < 0) return null;
	return value.slice(0, idx);
}

/** stem（basename 去扩展名；小写归一由调用方）。 */
function stemOf(p: string): string {
	const base = p.split("/").pop() ?? p;
	const dot = base.lastIndexOf(".");
	return dot > 0 ? base.slice(0, dot) : base;
}

/** 测试 stem（额外剥 .test/.spec 中缀）。 */
function testStemOf(rel: string): string {
	const stem = stemOf(rel);
	return stem.replace(/\.(test|spec)$/, "");
}

// ─────────────────────────────────────────────────────────────────────────────
// 冻结 spec 写面读取（K5a 冻结面只读；读失败 → undefined，不臆造）
// ─────────────────────────────────────────────────────────────────────────────

export interface FrozenSurfaceFacts {
	outputs: ReadonlyArray<{ path: string; kind: "file" | "tree" }>;
	writeRules: readonly PathRule[];
	reportFiles: readonly string[];
}

/** 只读读回冻结 spec 的声明写面（outputs + permission.write + reportFiles；旧 spec 缺字段如实空）。 */
export function frozenSurfaceOf(taskId: string, specId: string): FrozenSurfaceFacts | undefined {
	try {
		const specPath = path.join(contractStoreRoot(), sanitizeId(taskId), `spec-${sanitizeId(specId)}.json`);
		const raw = JSON.parse(fs.readFileSync(specPath, "utf8")) as {
			outputs?: unknown;
			permission?: { write?: unknown; reportFiles?: unknown };
		};
		const outputs = Array.isArray(raw.outputs)
			? raw.outputs
				.map((o) => o as { path?: unknown; kind?: unknown })
				.filter((o) => typeof o.path === "string" && (o.kind === "file" || o.kind === "tree"))
				.map((o) => ({ path: o.path as string, kind: o.kind as "file" | "tree" }))
			: [];
		const writeRules = Array.isArray(raw.permission?.write)
			? (raw.permission!.write as unknown[]).filter((r): r is PathRule => {
				const rr = r as { kind?: unknown; value?: unknown };
				return typeof rr?.value === "string" && rr.value !== "" && ["file", "directory", "glob", "prefix"].includes(rr.kind as string);
			})
			: [];
		const reportFiles = Array.isArray(raw.permission?.reportFiles)
			? (raw.permission!.reportFiles as unknown[]).filter((v): v is string => typeof v === "string" && v !== "")
			: [];
		return { outputs, writeRules, reportFiles };
	} catch { /* lint-exempt:冻结面只读探测失败→undefined（不臆造声明面） */
		return undefined;
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// ① own 写面归集
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 任务 own 写面登记。保守方向：声明面前缀内的 fresh 变更（含并行切片越入本任务声明面的写入）
 * 计入 own 文件——宁可少豁免，不把可能属于自己的漂移豁免成绿。返回 null 仅当 taskId 缺失。
 */
export function collectTaskWriteSurface(taskId: string, cwd: string, opts: { specId?: string; baselinePorcelain?: string[] | null } = {}): BaselineWriteSurface | null {
	if (!taskId) return null;
	const files = new Set<string>();
	const prefixes = new Set<string>();
	const basisParts: string[] = [];

	const declared = opts.specId ? frozenSurfaceOf(taskId, opts.specId) : undefined;
	if (declared) {
		let outFiles = 0, outTrees = 0;
		for (const o of declared.outputs) {
			const rel = toRelPosix(o.path, cwd);
			if (rel === null) continue;
			if (o.kind === "tree") { prefixes.add(rel.endsWith("/") ? rel : `${rel}/`); outTrees++; }
			else { files.add(rel); outFiles++; }
		}
		if (outFiles + outTrees > 0) basisParts.push(`冻结 spec outputs ${outFiles} 文件/${outTrees} 树`);
		let ruleFiles = 0, rulePrefixes = 0;
		for (const rule of declared.writeRules) {
			const rel = toRelPosix(rule.value, cwd);
			if (rel === null) continue;
			const prefix = prefixOfRule(rel, rule.kind);
			if (prefix !== null) { prefixes.add(prefix); rulePrefixes++; }
			else if (rule.kind === "file" || rule.kind === "glob") { files.add(rel); ruleFiles++; }
		}
		if (ruleFiles + rulePrefixes > 0) basisParts.push(`permission.write ${ruleFiles} 文件/${rulePrefixes} 前缀`);
		const relReports = declared.reportFiles
			.map((p) => toRelPosix(p, cwd))
			.filter((p): p is string => p !== null);
		for (const rel of relReports) {
			if (rel.endsWith("/")) prefixes.add(rel);
			else files.add(rel);
		}
		if (relReports.length > 0) basisParts.push(`reportFiles ${relReports.length} 项`);
	}

	// 子进程写面登记（真实写入事实；越界/依赖目录条目跳过——node_modules 写入不构成源码写面）
	const registered = readTaskWrites(taskId)
		.map((w) => toRelPosix(w.file, cwd))
		.filter((rel): rel is string => rel !== null && !rel.startsWith("node_modules/") && !rel.startsWith(".git/"));
	for (const rel of registered) files.add(rel);
	if (registered.length > 0) basisParts.push(`写面登记 ${registered.length} 项`);

	// fresh 变更 ∩ 声明面前缀（有基线快照才可算；无基线=保守跳过，不臆测变更集）
	if (opts.baselinePorcelain !== undefined) {
		const fresh = freshChangedPaths(cwd, opts.baselinePorcelain);
		if (fresh !== null) {
			let n = 0;
			for (const raw of fresh) {
				const rel = raw.split(path.sep).join("/");
				if (prefixes.size === 0) break;
				const hit = [...prefixes].some((p) => (p.endsWith("/") ? rel.startsWith(p) : rel.startsWith(p) || rel === p));
				if (hit && !rel.startsWith("node_modules/")) { files.add(rel); n++; }
			}
			if (n > 0) basisParts.push(`声明面内 fresh 变更 ${n} 项`);
		}
	}

	const fileList = [...files].sort().slice(0, SURFACE_MAX_FILES);
	return { files: fileList, prefixes: [...prefixes].sort(), basisParts };
}

// ─────────────────────────────────────────────────────────────────────────────
// 兄弟面归集（归属披露）
// ─────────────────────────────────────────────────────────────────────────────

/** 同 cwd（或互为祖先目录）并行任务写面：写面登记 + registry allowedPaths 快照。 */
export function collectSiblingSurfaces(taskId: string, cwd: string): SiblingSurface[] {
	const rootAbs = path.resolve(cwd);
	const related = (other: string | undefined): boolean => {
		if (!other) return false;
		const o = path.resolve(other);
		return o === rootAbs || o.startsWith(rootAbs + path.sep) || rootAbs.startsWith(o + path.sep);
	};
	const out: SiblingSurface[] = [];
	for (const rec of registry.list()) {
		if (rec.taskId === taskId || out.length >= SIBLING_MAX) continue;
		if (!related(rec.cwd)) continue;
		const files = new Set<string>();
		const prefixes = new Set<string>();
		for (const w of readTaskWrites(rec.taskId)) {
			const rel = toRelPosix(w.file, cwd);
			if (rel !== null && !rel.startsWith("node_modules/") && !rel.startsWith(".git/")) files.add(rel);
		}
		for (const ap of rec.allowedPaths ?? []) {
			const rel = toRelPosix(ap, cwd);
			if (rel === null) continue;
			if (rel.endsWith("/")) prefixes.add(rel);
			else { files.add(rel); prefixes.add(`${rel}/`); }
		}
		if (files.size === 0 && prefixes.size === 0) continue;
		out.push({ label: `${rec.agent}/${rec.taskId.slice(0, 8)}`, files: [...files].sort(), prefixes: [...prefixes].sort() });
	}
	return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// 测试发现与 ② 子集选择
// ─────────────────────────────────────────────────────────────────────────────

/** 有界测试文件发现（cwd 与 execDir 双起点；深度/数量受限；非测试域目录跳过）。 */
function discoverTestFiles(cwd: string, execDirAbs: string): string[] {
	const found = new Set<string>();
	let dirCount = 0;
	const walk = (dirAbs: string, relDir: string, depth: number): void => {
		if (depth > TEST_DISCOVERY_MAX_DEPTH || found.size >= TEST_DISCOVERY_MAX_FILES || dirCount >= TEST_DISCOVERY_MAX_DIRS) return;
		dirCount++;
		let ents: fs.Dirent[];
		try { ents = fs.readdirSync(dirAbs, { withFileTypes: true }); } catch { /* lint-exempt:目录不可读跳过（有界发现尽力口径） */ return; }
		for (const ent of ents.sort((a, b) => a.name.localeCompare(b.name))) {
			if (found.size >= TEST_DISCOVERY_MAX_FILES) return;
			const rel = relDir ? `${relDir}/${ent.name}` : ent.name;
			if (ent.isDirectory()) {
				if (DISCOVERY_SKIP_DIRS.has(ent.name)) continue;
				walk(path.join(dirAbs, ent.name), rel, depth + 1);
			} else if (ent.isFile() && TEST_FILE_RE.test(rel)) {
				found.add(rel);
			}
		}
	};
	walk(path.resolve(cwd), "", 0);
	const execRel = path.relative(path.resolve(cwd), execDirAbs);
	if (execRel !== "" && !execRel.startsWith("..")) walk(execDirAbs, execRel.split(path.sep).join("/"), 0);
	else if (execRel.startsWith("..")) walk(execDirAbs, "", 0); // 子包 execDir 在根外（级联命中）——独立起点扫描
	return [...found].sort();
}

/** 测试文件与 own 写面的匹配（写面文件/文件名 stem 前缀/目录前缀/直接 import 链文本引用）。 */
function matchReasonOf(testRel: string, testContent: string | null, surface: BaselineWriteSurface): string | null {
	if (surface.files.includes(testRel)) return "写面文件";
	const tStem = testStemOf(testRel).toLowerCase();
	if (tStem.length >= 3) {
		for (const own of surface.files) {
			const oStem = stemOf(own).toLowerCase();
			if (oStem.length >= 3 && (tStem.startsWith(oStem) || oStem.startsWith(tStem))) return `文件名前缀≈${own}`;
		}
	}
	for (const p of surface.prefixes) {
		if (p.endsWith("/") ? testRel.startsWith(p) : testRel.startsWith(p) || testRel === p) return `目录前缀 ${p}`;
	}
	if (testContent !== null) {
		for (const own of surface.files) {
			// 直接 import 链引用：完整相对路径或「父目录/文件名」两段后缀（覆盖 ../x/y.ts 与
			// loadModule("./x/y.ts") 等形态）；根级文件只匹配 basename（同名面小，保守可用）
			const segs = own.split("/");
			const suffix2 = segs.length >= 2 ? segs.slice(-2).join("/") : own;
			if (testContent.includes(own) || testContent.includes(suffix2)) return `直接引用 ${own}`;
		}
	}
	return null;
}

/** 读取测试文件文本（有界；失败 → null=不做内容匹配）。 */
function readBounded(abs: string): string | null {
	try {
		const st = fs.statSync(abs);
		if (!st.isFile() || st.size > CONTENT_SCAN_MAX_BYTES) return null;
		return fs.readFileSync(abs, "utf8");
	} catch { /* lint-exempt:stat/读失败→null（内容引用匹配降级跳过） */
		return null;
	}
}

/** scripts.test token → 测试宇宙根（`node --test $(ls tests/*.test.mjs …)` 的 glob 目录段 /
 *  `node --test tests/` 目录段）。空集=无法从脚本推导（保持发现全集，不臆造收窄）。 */
function scriptTestRoots(tokens: readonly string[]): string[] {
	const roots = new Set<string>();
	for (let i = 2; i < tokens.length; i++) {
		const t = tokens[i].replace(/[);,\u3001]+$/, ""); // 剥 shell 替换闭合标点（$(…) 尾括号）
		if (/[*?]/.test(t) && t.includes("/")) {
			const dir = t.slice(0, t.lastIndexOf("/"));
			if (dir && !/[*?$(`|;&<>'"]/.test(dir)) roots.add(`${dir}/`);
		} else if (/^[.A-Za-z0-9_-]+\/$/.test(t) && !t.startsWith("/")) {
			roots.add(t);
		}
	}
	return [...roots];
}

/** scripts.test token → 排除模式（`| grep -v <pat>` 的 pat；无通配/无 shell 元字符才采信）。 */
function scriptExcludes(tokens: readonly string[]): string[] {
	const out: string[] = [];
	for (let i = 0; i < tokens.length - 1; i++) {
		if (tokens[i] === "-v" || (tokens[i - 1] === "grep" && tokens[i] === "-v")) {
			const pat = tokens[i + 1].replace(/[);,]+$/, ""); // 剥 $(…) 尾括号（grep -v 模式尾巴）
			if (pat && !/[*?|;&<>('"]/.test(pat) && !pat.startsWith("$") && !pat.startsWith("--")) out.push(pat);
		}
	}
	return out;
}

/** 读 execDir 的 scripts.test 并 tokenize（剥 env 前缀赋值）。无声明 → null。 */
function scriptTokensOf(execDirAbs: string): string[] | null {
	try {
		const pj = JSON.parse(fs.readFileSync(path.join(execDirAbs, "package.json"), "utf8")) as { scripts?: { test?: unknown } };
		if (typeof pj.scripts?.test !== "string" || pj.scripts.test.trim() === "") return null;
		return pj.scripts.test.trim().split(/\s+/).filter(Boolean);
	} catch { /* lint-exempt:package.json 不可读→无声明 script（全量回退保守） */
		return null;
	}
}

/** 相对 import/loadModule 说明符提取（静态 import/export from、动态 import()、loadModule 字符串
 *  形态——与内容引用匹配同源的尽力口径；F-03 传递消费者跟踪输入）。 */
function specifiersOf(content: string): string[] {
	const out: string[] = [];
	const re = /(?:from\s*['"](\.[^'"]+)['"]|import\s*\(\s*['"](\.[^'"]+)['"]\s*\)|loadModule\(\s*['"](\.[^'"]+)['"]|import\s*['"](\.[^'"]+)['"])/g;
	for (const m of content.matchAll(re)) {
		const s = m[1] ?? m[2] ?? m[3] ?? m[4];
		if (s) out.push(s);
	}
	return [...new Set(out)];
}

/** 说明符多基准解析（相对说明者目录标准 ESM 语义 + 相对仓库根 loadModule 约定）→ 仓内 rel POSIX。
 *  null = 不可解析（目标不存在——该测试的引用链无法证明完整）。 */
function resolveSpecifier(spec: string, fromAbs: string, root: string): string | null {
	const exists = (p: string): boolean => {
		try { return fs.statSync(p).isFile(); } catch { /* lint-exempt:stat 失败→不存在（说明符解析尽力口径） */ return false; }
	};
	for (const base of [path.resolve(path.dirname(fromAbs), spec), path.resolve(root, spec)]) {
		const cands = [base, ...[".mjs", ".js", ".ts", ".json", ".cjs", ".mts"].map((e) => base + e), path.join(base, "index.mjs"), path.join(base, "index.js")];
		const hit = cands.find(exists);
		if (hit !== undefined) {
			const rel = path.relative(root, hit);
			if (rel !== "" && !rel.startsWith("..") && !path.isAbsolute(rel)) return rel.split(path.sep).join("/");
		}
	}
	return null;
}

/** 单测试传递消费者判定（F-03，一层转导）：测试直接 import 的仓内模块内容引用 own → 传递命中。
 *  deps 超上限或存在不可解析说明符 → unresolved=true（调用方纳入执行面，不臆断无关）。 */
const TRANSITIVE_MAX_DEPS = 12;

function transitiveReasonOf(
	testRel: string,
	content: string,
	surface: BaselineWriteSurface,
	root: string,
	depContentCache: Map<string, string | null>,
): { reason: string | null; unresolved: boolean } {
	const ownSet = new Set(surface.files);
	const specs = specifiersOf(content);
	if (specs.length > TRANSITIVE_MAX_DEPS) return { reason: null, unresolved: true };
	const contentOf = (rel: string): string | null => {
		if (!depContentCache.has(rel)) depContentCache.set(rel, readBounded(path.join(root, rel)));
		return depContentCache.get(rel) ?? null;
	};
	const ownHitVia = (depRel: string, c: string): string | null => {
		for (const own of surface.files) {
			const segs = own.split("/");
			const suffix2 = segs.length >= 2 ? segs.slice(-2).join("/") : own;
			if (c.includes(own) || c.includes(suffix2)) return `传递引用（经 ${depRel} 验证 ${own}）`;
		}
		return null;
	};
	// 扫单层：返回 hit=own 命中原因；succs=该层非 own 后继（供下一层/边界判定）。
	const scanLayer = (deps: string[]): { hit: string | null; succs: string[]; boundary: boolean } => {
		const succs: string[] = [];
		for (const dep of deps) {
			// F-03-R1 终裁：超大/IO 不可读=不可判定（无证据不判无关），交调用方纳入执行面。
			const c = contentOf(dep);
			if (c === null) return { hit: null, succs: [], boundary: true };
			const hit = ownHitVia(dep, c);
			if (hit !== null) return { hit, succs: [], boundary: false };
			const depSpecs = specifiersOf(c);
			if (depSpecs.length > TRANSITIVE_MAX_DEPS) return { hit: null, succs: [], boundary: true };
			for (const s of depSpecs) {
				const r = resolveSpecifier(s, path.join(root, dep), root);
				if (r === null) return { hit: null, succs: [], boundary: true };
				if (ownSet.has(r)) return { hit: `传递引用（经 ${dep} → ${r}）`, succs: [], boundary: false };
				succs.push(r);
			}
		}
		return { hit: null, succs, boundary: false };
	};
	// F-03-R2 终裁：有界两层 BFS——第一层命中即返；第二层扫描后仍有后继/不可读 → unresolved
	//（有限深度不得伪称证明无关，不递归展开；成本边界=TRANSITIVE_MAX_DEPS×去重两层）。
	const first = scanLayer(specs.map((spec) => {
		const dep = resolveSpecifier(spec, path.join(root, testRel), root);
		if (dep === null) return null;
		return dep;
	}).filter((d): d is string => d !== null));
	// 测试直接说明符不可解析 → 不可判定（原口径保持）
	if (specs.some((spec) => resolveSpecifier(spec, path.join(root, testRel), root) === null)) {
		return { reason: null, unresolved: true };
	}
	if (first.hit !== null) return { reason: first.hit, unresolved: false };
	if (first.boundary) return { reason: null, unresolved: true };
	const uniq = [...new Set(first.succs)];
	if (uniq.length === 0) return { reason: null, unresolved: false }; // 叶闭合：可证明无关
	const second = scanLayer(uniq.slice(0, TRANSITIVE_MAX_DEPS));
	if (second.hit !== null) return { reason: second.hit, unresolved: false };
	// 第二层扫描后：边界（不可读/超限/不可解析）或仍有后继 → 未证明闭合 → 不可判定
	if (second.boundary || second.succs.length > 0 || uniq.length > TRANSITIVE_MAX_DEPS) {
		return { reason: null, unresolved: true };
	}
	return { reason: null, unresolved: false };
}

/** own 责任测试推导（写面匹配/直接引用/一层传递引用；不可读/不可解析=不可判定一并纳入）——与 runner
 *  形态无关，是豁免守卫的保护面（ev-20261021-54b4e3 diting F-02 复核：从子集构造中独立出来）。 */
function deriveResponsibleTests(cwd: string, universe: readonly string[], surface: BaselineWriteSurface): { responsible: string[]; reasons: Set<string> } {
	// 修复轮 F-03：匹配循环恒跑（subset/full 决策之前）——命中集同时是 own 责任测试面
	//（F-02：其失败不得豁免）；传递消费者（经一层转导验证 own 的测试）纳入命中；引用链不可
	// 解析/不可读的测试无法证明无关 → 纳入执行面（覆盖完整性：执行域 ⊇ 可证明相关 ∪ 不可判定）。
	const hits: string[] = [];
	const reasons = new Set<string>();
	const undecidable: string[] = [];
	const depContentCache = new Map<string, string | null>();
	for (const t of universe) {
		const fast = matchReasonOf(t, null, surface);
		if (fast !== null) {
			hits.push(t);
			reasons.add(fast);
			continue;
		}
		const content = readBounded(path.join(cwd, t));
		if (content === null) {
			undecidable.push(t); // 不可读（超大/IO）：无法证明无关——纳入执行面
			continue;
		}
		const slow = matchReasonOf(t, content, surface);
		if (slow !== null) {
			hits.push(t);
			reasons.add(slow);
			continue;
		}
		const transitive = transitiveReasonOf(t, content, surface, path.resolve(cwd), depContentCache);
		if (transitive.unresolved) {
			undecidable.push(t); // 引用链不可完全解析——无法证明无关，纳入执行面（不臆断）
			continue;
		}
		if (transitive.reason !== null) {
			hits.push(t);
			reasons.add(transitive.reason);
		}
	}
	const responsible = [...new Set([...hits, ...undecidable])].sort();
	if (undecidable.length > 0) {
		reasons.add(`引用链不可完全解析 ${undecidable.length} 项已纳入执行面（无法证明无关——覆盖完整性保守）`);
	}
	return { responsible, reasons };
}

/**
 * B10 ①：写面感知子集选择。保守回退（full）条件：写面为空 / 未发现测试 / 无匹配 / 匹配=全集 /
 * 匹配超上限 / scripts.test 非 node --test 直跑形态。全量跑义务保留给 Leader 收口与发布门禁
 * （本函数不提供任何「跳过检查」的出口——full 仍是真实全量执行）。
 *  宇宙保真：子集文件域以 scripts.test 可推导的目录根/排除项（如 `$(ls tests/*.test.mjs |
 *  grep -v smoke)`）为准——子集不引入全量本不会执行的测试（含被脚本排除的冒烟测试）。
 */
/** Same runner-shape decision used for subset selection; no task writes or test execution. */
export function baselineRunnerSupport(cwd: string, plan: TestExecutionPlan): { tokens: string[] | null; directNodeTest: boolean } {
	const execDirAbs = plan.cwdRel === "." ? path.resolve(cwd) : path.resolve(cwd, plan.cwdRel);
	const raw = scriptTokensOf(execDirAbs);
	const tokens = raw === null ? null : [...raw];
	while (tokens && tokens.length > 0 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(tokens[0])) tokens.shift();
	return { tokens, directNodeTest: tokens !== null && tokens[0] === "node" && tokens[1] === "--test" };
}

export function selectBaselineSubset(cwd: string, plan: TestExecutionPlan, prepared: PreparedBaselineScope): BaselineSubsetSelection {
	const discovered = prepared.testFiles;
	if (discovered.length === 0) {
		// ev-20261101-bcee0f：文案明确「Node 测试文件」——该发现面只服务于 node --test 子集推导；
		// 非 Node 入口（ctest/make/cargo/go）不依赖 Node 测试文件发现，全量执行不受此噪声误导。
		return { mode: "full", basis: `写面感知回退全量：未发现 Node 测试文件（发现深度 ≤${TEST_DISCOVERY_MAX_DEPTH}、目录上限 ${TEST_DISCOVERY_MAX_DIRS}；该发现面仅用于 node --test 子集推导，非 Node 入口（ctest/make/cargo/go 等）全量执行不受影响）——无法推导子集` };
	}
	const surface = prepared.surface;
	if (!surface || surface.files.length === 0) {
		return { mode: "full", basis: `写面感知回退全量：任务 own 写面为空${surface && surface.basisParts.length > 0 ? `（${surface.basisParts.join("；")}）` : ""}——无法推导相关测试集，保守全量` };
	}
	const execDirAbs = plan.cwdRel === "." ? path.resolve(cwd) : path.resolve(cwd, plan.cwdRel);
	// runner 形态与测试宇宙：scripts.test 须为 node --test 直跑才可构造子集命令；
	// 宇宙根/排除项从脚本 token 推导（不可推导=发现全集——不臆造收窄）。
	// ev-20261021-54b4e3（diting F-02 复核）：「能否构造子集 argv」与「own 责任测试集」是两个问题——
	// runner 非 node --test 直跑（guarded wrapper/无 scripts.test）只否定前者；责任集照常在发现全集上推导
	//（宇宙不收窄=责任集取超集，豁免守卫只会更保守），不得以「不能构造命令」冒充「无 own 责任测试」。
	const { tokens: scriptTokens, directNodeTest } = baselineRunnerSupport(cwd, plan);
	const roots = scriptTokens !== null && directNodeTest ? scriptTestRoots(scriptTokens) : [];
	const excludes = scriptTokens !== null && directNodeTest ? scriptExcludes(scriptTokens) : [];
	let all = discovered;
	if (roots.length > 0) all = all.filter((f) => roots.some((r) => f.startsWith(r)));
	if (excludes.length > 0) all = all.filter((f) => !excludes.some((x) => f.includes(x)));
	const universeNote = roots.length > 0 || excludes.length > 0
		? `；测试宇宙按 scripts.test 收窄：根=[${roots.join(", ") || "（未推导）"}]${excludes.length > 0 ? ` 排除=[${excludes.join(", ")}]` : ""}（${all.length}/${discovered.length}）`
		: "";
	if (all.length === 0) {
		return { mode: "full", basis: `写面感知回退全量：scripts.test 测试宇宙（根=[${roots.join(", ")}]）内未发现测试文件——无法推导子集` };
	}
	const { responsible, reasons } = deriveResponsibleTests(cwd, all, surface);
	if (scriptTokens === null || !directNodeTest) {
		const runnerNote = scriptTokens === null
			? "scripts.test 无声明/不可读"
			: `scripts.test 非 node --test 直跑形态（实际：${scriptTokens.join(" ").slice(0, 80)}）`;
		return {
			mode: "full",
			basis: `写面感知回退全量：${runnerNote}——无法安全构造子集命令，保守全量${responsible.length > 0 ? `；own 责任测试 ${responsible.length} 项按发现全集推导（不收窄宇宙，供豁免守卫）` : ""}`,
			...(responsible.length > 0 ? { responsibleTests: responsible } : {}),
		};
	}
	if (responsible.length === 0) {
		return { mode: "full", basis: `写面感知回退全量：写面 ${surface.files.length} 项文件无相关测试匹配（匹配规则：写面文件/文件名前缀/目录前缀/直接引用/一层传递引用；写面=[${surface.files.slice(0, 6).join(", ")}${surface.files.length > 6 ? " …" : ""}]）` };
	}
	if (responsible.length >= all.length) {
		const filesRelExec = responsible.map((f) => path.relative(execDirAbs, path.resolve(cwd, f))).map((rel) => (rel === "" ? "." : rel.split(path.sep).join("/")));
		return {
			mode: "full",
			basis: `写面感知回退全量：匹配/纳入测试 ${responsible.length}/${all.length} 与全集相等——等效全量，直接执行探测命令`,
			responsibleTests: responsible,
			// 披露性携带（mode=full 不被子集执行采用）：命中集含传递消费者与不可判定项，供复核
			files: responsible,
			argv: [process.execPath, "--test", ...filesRelExec],
		};
	}
	if (responsible.length > SUBSET_MAX_FILES) {
		return { mode: "full", basis: `写面感知回退全量：匹配/纳入测试 ${responsible.length} 项超上限 ${SUBSET_MAX_FILES}——推导面失控，保守全量`, responsibleTests: responsible };
	}
	const filesRelExec = responsible.map((f) => {
		const rel = path.relative(execDirAbs, path.resolve(cwd, f));
		return rel === "" ? "." : rel.split(path.sep).join("/");
	});
	return {
		mode: "subset",
		files: responsible,
		argv: [process.execPath, "--test", ...filesRelExec],
		responsibleTests: responsible,
		basis: `写面感知子集 ${responsible.length}/${all.length} 个测试（${responsible.slice(0, 6).join(", ")}${responsible.length > 6 ? " …" : ""}）；依据：${[...reasons].slice(0, 4).join("、")}${reasons.size > 4 ? ` 等` : ""}（写面 ${surface.files.length} 项：${surface.files.slice(0, 4).join(", ")}${surface.files.length > 4 ? " …" : ""}${surface.basisParts.length > 0 ? `；${surface.basisParts.join("；")}` : ""}）；runner：node --test 直跑（scripts.test="${scriptTokens.join(" ").slice(0, 60)}"）${universeNote}`,
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// 组装入口（finalizer 消费）
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 一次性准备（写面 + 兄弟面 + 测试发现共用一次目录扫描）。taskId 缺失 → surface=null
 * （无守卫、无子集——同步/后台注入面零行为变化）。
 */
export function prepareBaselineScope(cwd: string, taskId: string | undefined, opts: { specId?: string; baselinePorcelain?: string[] | null } = {}): PreparedBaselineScope {
	if (!taskId) return { surface: null, siblings: [], testFiles: [] };
	const surface = collectTaskWriteSurface(taskId, cwd, opts);
	const siblings = collectSiblingSurfaces(taskId, cwd);
	// 测试发现与 execDir 无关（execDir 只影响子集 argv 相对化）；从 cwd 单起点扫描即可覆盖 monorepo 子包
	const testFiles = discoverTestFiles(cwd, path.resolve(cwd));
	return { surface, siblings, testFiles };
}

/** 守卫组装：写面为空（无 own 文件）→ null（不豁免——空写面无法证明任何漂移「非本任务」，
 *  全量回退已由 selectBaselineSubset 处理）。selection 提供时填 own 责任测试面（F-02）。 */
export function scopeGuardOf(prepared: PreparedBaselineScope, selection?: { responsibleTests?: string[] } | null): BaselineScopeGuard | null {
	if (!prepared.surface || prepared.surface.files.length === 0) return null;
	return {
		ownFiles: prepared.surface.files,
		ownPrefixes: prepared.surface.prefixes,
		siblings: prepared.siblings.map((s) => ({ label: s.label, files: s.files, prefixes: s.prefixes })),
		testFiles: prepared.testFiles,
		...(selection?.responsibleTests ? { responsibleTests: selection.responsibleTests } : {}),
	};
}
