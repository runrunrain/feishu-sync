# 只读调查：7 个模块现状与代码位置（amagi-pi）

调查范围：/Users/maorun/maorun-workpace/amagi-pi（只读，未改任何源码；本报告为唯一写盘产物）
日期：2026-09-15 ｜ 方法：grep 定位 + 全文 read 关键模块（watchdog/admission/reliability/model-resolver/task-service/worktree/evidence/finalizer/task-query/process-audit/bash-override 片段、task-tool/task-run 相关段落）

---

## 1. 看门狗（watchdog）

**实现模块**：`extensions/amagi-core/watchdog.ts`（单文件，370 行；注册入口 `registerWatchdog` L357）

- **静默阈值**（watchdog.ts:91,98）：
  - `DEFAULT_WATCHDOG_SILENCE_MS = 30 * 60_000`（主阈值 30min）。
  - `DEFAULT_WATCHDOG_TUI_SILENCE_MS = 10 * 60_000`（TUI 零工具在飞专属告警阈值）。
  - env：`AMAGI_WATCHDOG_SILENCE_MS`（0=禁用，`resolveSilenceMsEnv` L263）；`AMAGI_WATCHDOG_TUI_SILENCE_MS`（`resolveTuiSilenceMs` L274，优先级 tui>全局>默认10min）。graceMs=15s、tickMs=5s 为冻结常量（L363-365）。
- **判定条件——基于事件间隔**（watchdog.ts:81-123,158,168-176）：
  - `ACTIVITY_EVENTS = ["message_start","message_update","message_end","turn_start","turn_end","tool_execution_update"]`，每个事件 handler 调 `bump()` 重置 `lastActivity`；另监听 `agent_start/agent_end/agent_settled/session_start/tool_execution_start/tool_execution_end`。
  - tick（`setInterval` 5s，L168）内：`agentActive=false` 直接 return（L178）；`silence = now() - lastActivity`。
  - **判定就是"无任何上述事件"的时长**；注意 ACTIVITY_EVENTS 不含 `tool_execution_start/end`（后两者只增减 `toolsInFlight` 并 bump，见 L159-161——实际也 bump）。
- **豁免/心跳机制**：
  - **同步派发豁免**：`syncWaitsInFlight() > 0` → 每 tick 强制刷新活性（L169-171，`sync-wait.ts` 模块计数）；派发在 tick 间隙开始/结束用代次 `syncWaitGeneration()` 校准（L172-174）。
  - **无"registry 活跃子进程"豁免**——watchdog 不查询 task-registry 是否有 running child；主进程豁免只有 sync-wait 计数一条。
  - **bash 心跳**：`bash-override.ts:43-44,262-330`。原生 bash 只在有输出时发 onUpdate partial（pi dist bash.js scheduleOutputUpdate 由 handleData 驱动）；`withBashHeartbeat` 包裹 execute，静默期周期性发心跳 partial → pi 转发为 `tool_execution_update`（重置子进程 watchdog），stdout JSONL 行同时刷新父进程侧 `lastActivity/execSilentMs`。周期=静默窗/6（钳 1s..5min）、总窗=2× 窗口，均由 `resolveSilenceMsEnv` 推导（`bashHeartbeatPlan` L282-285）；自然输出周期内抑制（`bashHeartbeatDue` L287-292）。
  - 子进程侧另有 runPiTask 停滞看门狗（`task-run.ts:1166-1210`）：`AMAGI_STALL_MS`（默认 5min，`reliability.getStallThresholdMs` L33-36）只 onStall 告警不杀；工具在飞时挂起常规告警，累计 3× 阈值才提示一次（L1192-1199）；provider 重试退避窗口 `retryQuietUntil` 内静默抑制（L1180-1183）。
- **abort 机制**（watchdog.ts:214-251）：
  - TUI（`isTui = hasUI===true || mode==="tui"` L182）：只分级 notify 告警，绝不 abort/exit（L184-208）；工具在飞时用主阈值单次告警（L209-221）。
  - 非 TUI：`phase="aborted"` + `lastCtx.abort?.()`（L214-239）；宽限 15s 后仍无活性 → 仅当 `noUI && allowExit`（allowExit 缺省 = `AMAGI_SUBAGENT==="1"`，L146-148）执行 `exit(3)` 硬退出（L241-247）；主进程绝不杀。
- **bash 工具执行期间的会话事件**：
  - 原生行为：无输出 → 零 update（bash-override.ts:265-267 注释明确）；amagi 心跳补发 `tool_execution_update` 等价活性（见上）。
  - 交互式 shell 命令在执行前即被 guards.ts 拦截（watchdog.ts:82-85 注释）。

## 2. model-resolver + autoRetry / 降级链

**降档纯函数**：`extensions/amagi-core/reliability.ts`
- `PROVIDER_ERROR_RE`（L45）/ `isProviderError`（L48）：rate limit/429/quota/timeout/503/网络层词族。
- `downgradeModel`（L56）：`:max→:high→:medium`，有界降一档；`:medium`/无 tier → undefined（不可降）。
- 账号级限额：`isAccountQuotaError`（L78）= 429/限流信号（L71）**与** workspace/账号配额词族（L69）同时命中；命中则优先跨 provider 候选链 `crossProviderDowngrade`（L94，候选来自 `model-resolver.loadFallbackModels` L234：env `AMAGI_FALLBACK_MODELS` > amagi.json `fallbackModels`，每次读盘）。
- `resolveDowngrade`（L118）：账号限额→跨 provider；否则 tier 降一档；均不可降→undefined。
- **autoRetry**：
  - 覆盖错误类型：`isTransientProviderError`（L193）正则含 `429|too many requests|rate.?limit|timeout|ETIMEDOUT|5xx|ECONNRESET|fetch failed|socket hang up` 等——**429 在内**。
  - `nextAutoRetryPlan`（L327）：仅 `status==="error"` + 瞬时 + `attempt < retries`（缺省 2，0..10，`normalizeAutoRetryConfig` L297）；退避 = `backoffMs×2^n`（缺省 90s），**不早于熔断 Open 剩余恢复时间**（`providerBreakerPeek` L266，L336），封顶 30min（L288）。**未解析 HTTP Retry-After**（全仓无 Retry-After 解析；冷却=熔断窗 `AMAGI_CB_OPEN_MS` 默认 5min，L217-219）。
  - 账号配额且无备选 model → 不重派（L334）。
  - `buildRetryAdvice`（L360）：链尽/未启用 autoRetry 时的 A3 建议段（退避阶梯 90/180/360s + 备选模型 + 可复制重派命令）。
  - 熔断：`providerBreakerCheck/Failure/Success`（L234/254/226），阈值 `AMAGI_CB_THRESHOLD` 默认 3，Open 窗默认 5min，HalfOpen 单探针。

**消费点**：`extensions/amagi-core/task-tool.ts`
- 派发前熔断 fail-fast：runTask L183-187——Open 且非探针 → 直接返回 `status:"error"`（不 spawn、不排队）。
- sync autoRetry 循环：L2167-2215（`for(;;)` 调 `nextAutoRetryPlan`；落盘分流 `collectResidue` L2189-2192——有真实工作区写入则不重派；退避 sleep 可被 AbortSignal 中止 L2200-2206）。
- sync 降级链循环：L2226-2310——数组链（`model` 参数传数组，schema L1363；字符串化数组恢复 `parseStringifiedModelArray` model-resolver.ts:569）瞬时错误依次 resume 下一 model（L2243-2248）；链尽或非瞬时 → tier 降档一次（L2250，`_tierTried` 有界）；**`!_dgDec` → `_takeoverHint=true; break`（L2252）**——无候选时落回原 res 的 error 返回路径（L2320-2340：`[失败根因]` + 手动接管提示 L2326 + A3 建议段 L2330-2333），**终态即 error**。
- background：onComplete 内 A2 计划 → 主进程 `setTimeout` 退避后 `launchBg(nextModel)` fresh spawn（timer `.unref()`，L2101-2113）；计划 undefined → 通知附 A3 建议（L2116-2122）。

**admission 是否支持冷却排队**：`extensions/amagi-core/admission.ts`——**不支持时间/冷却语义**。
- `tryOccupy`（L127）/`waitForGrant`（L153）只有两种终局 `"running"|"cancelled"`，纯容量 FIFO（`capacityOf` L86：models 精确键 > providers > `AMAGI_ADMISSION_MAX` env > `concurrency.default` > 4）。
- 退避等待发生在**槽位外**：A2 注释（L166-172）"重派不占着旧槽位 sleep——槽位由 onFinalize 链 release，退避定时器在槽位外等待"；bg 用独立 timer、sync 用 await sleep，均不经 admission 队列。
- 熔断 Open 的新派发也不入队——runTask 直接 error（task-tool.ts:183-187）。

## 3. task cancel 级联

- **服务层 cancel**：`task-service.ts:152-198`（`cancelTask`）。
  - queued → `cancelQueued` 出队 + registry 置 cancelled（零副作用，L176-186）。
  - running → 先 `registry.patch({status:"cancelled", revision+1})`（stale 防护），再从 `registry.getRunningChildren()` 取**原始 child 引用**（L180-182 注释：deepFreeze 拷贝会丢 kill 方法）→ `child.kill("SIGTERM")`；`setTimeout(..., SIGKILL_GRACE_MS).unref()` 补 `SIGKILL`。**task-service.ts:42 `SIGKILL_GRACE_MS = 2000`（2s）**。
  - 无本地 child（RPC 等后端）→ `notifyCancelInterceptors`（L146-149,189）。
  - blocked/answering → 仅状态迁移；answering 的 resume 新任务不级联（L191-198）。槽位不由 cancelTask 释放（由 finalize 链恰好一次归还，L190 注释）。
- **引擎层杀法**：`task-run.ts:1249-1259` `killTimer` = `p.kill("SIGTERM")` + `SIGKILL` 定时器；**task-run.ts:62 `SIGKILL_GRACE_MS = 3000`（3s）**——与 service 层 2s 不同值。触发点：显式超时（L1257）、AbortSignal（L1258-1259）、启动就绪零输出守卫（L1172-1177，`AMAGI_SPAWN_READY_MS` 默认 30s）、doom-loop（L1575-1578）、settle 兜底（L1243）。
- **spawn 形态**：`task-run.ts:1116-1119` `spawn(command, args, { cwd, shell:false, stdio:["ignore","pipe","pipe"], env })`——**无 `detached:true`、无进程组**；kill 目标只是子进程 pid 本身。（对照：证据命令的 defaultRunCmd 反而用 detached 进程组杀，evidence.ts:151,161-165。）
- **孙进程**：`process-audit.ts`（`ProcessAuditor`，task-run.ts:1130-1133 创建）——运行期 `sample()` 周期 `ps axo pid,ppid,command` 构建"曾见过"后代集（SAMPLE_THROTTLE_MS=1s）；子进程终态 `auditAndClean()`（task-run.ts:1429-1436 调用）对存活后代 SIGTERM→2s→SIGKILL（TERM_GRACE_MS=2000，process-audit.ts:47），仅 darwin/linux、仅确认血缘、pid≤1 拒绝；`AMAGI_PROC_AUDIT=0` 关闭。**cancel 路径本身不调用 auditor**（audit 在 runPiTask finalize 的 close/error 收尾；cancel 杀进程后走同一 finalize 才审计）。

## 4. worktree.ts 生命周期

文件：`extensions/amagi-core/worktree.ts`（477 行）
- **创建/复用**：`setupWorktree`（L371-458）。约定路径 `<gitroot>/.amagi-worktrees/<name>`、分支 `amagi/<name>`；路径已存在且 `rev-parse --show-toplevel` 相符 → `reused:true`（L419-425）；约定路径未命中 → 按 `git worktree list --porcelain` 分支反查复用（`listRegisteredWorktrees` L308、`findWorktreeForBranch`、`reuseBlocker` 不可复用原因：bare/主检出/prunable/目录缺失/元数据损坏）；分支已存在则直接挂（`worktree add wtPath branch`），否则 `-b` 新切（L449-453）。创建前采集主仓基线 `snapshotMainBaseline`（L98，porcelain 滤除 `.amagi-worktrees/` 条目）与 `baseCommit`（L398-400）。v2 批次D：`leaseId` 原子占有（`acquireWorktree` L199，活跃冲突显式拒绝）；派发后 `attachWorktreeTask`（L216）回填 taskId。
- **释放/删除**：`releaseWorktreeOwnership`（L222）任务终态释放租约，**目录默认保留**（异常也保留）；`cleanupWorktree`（L231-256）显式删除——活跃 owner 拒绝；**删除前脏树检查**（L237-239）：`git status --porcelain` 非空且无 `force` → fail-closed 拒绝；`git worktree remove [--force]`，分支保留供审计。审计环 `worktreeAuditLog`（≤200 条）。
- **回流汇总**：`worktreeSummary`（L460）= `git diff --stat HEAD` + 未跟踪列表 + 主仓漂移 `checkMainDrift`（L106，与基线 porcelain 行集比对）；patch 产物 `worktreePatch`（L266）。
- **soft suggestion（worktree 软建议）**：`task-tool.ts`
  - 定义 `suggestWorktreeDispatch`（L850-929）；触发特征 `LARGE_CHANGE_RE`（L736）或任务书 ≥600 字（`looksLikeLargeChange` L739-743）；抑制：只读语义 `looksLikeReadOnlyTask`（L774-790）/ 角色章程只读 `agentCharterReadOnly`（L797-800）/ 非 git 目录 / 已在 linked worktree 内（`isInsideLinkedWorktree` worktree.ts:135）/ exportPrompt / resume / 带 worktree 参数。
  - 会话级去重：同 cwd（realpath 键，L809-812）+ 同 git 脏/干净状态至多提示一次；脏树→分流为"主树作业更优"结论且记忆粘滞（`mainTreeSeen`，L872-876）；脏树探测 `probeGitDirtyState`（L812-818，2s timeout）；`AMAGI_WORKTREE_SUGGEST=0` 关闭（L814-816）。
  - **注入时点**：execute 内、cwd 解析后、resume/background/sync 分流之前，单次 `pi.sendMessage({customType:"amagi:worktree-suggest"}, {deliverAs:"steer"})`（task-tool.ts:1852-1853；消息 `display:false`）。

## 5. evidence.ts / finalizer.ts

文件：`extensions/amagi-core/evidence.ts`（1075 行）、`finalizer.ts`（172 行）
- **收尾链序**（finalizer.ts 模块头 L13-16）：幂等去重（taskId LRU ≤256，L162-176）→ stale revision 检查 → artifact 落盘 → 折叠 → 证据采集（门控 `shouldGatherEvidence` evidence.ts:1031：仅 `DEFAULT_CODE_AGENTS = {luban,laojun,luoshen,wukong,hongjun}` + 非 running/blocked/cancelled/resolved-external）。
- **改动文件统计来源**（两条输出口径共用同一分类器 `classifyFreshPaths` evidence.ts:661）：
  - 基线：spawn 前 `takeGitStatusSnapshot`（evidence.ts:440，`git -C cwd status --porcelain`，`gitEnv` 剥 GIT_DIR 等覆盖）；基线快照在 task-run.ts:1100 采集（v1.5.233：必须严格先于 spawn）。
  - 结算：`buildArtifactDiffSummary`（evidence.ts:851）——fresh 差集（vs 派发基线）≤15 行 + `git diff --stat HEAD -- .` 尾 5 行 + 未跟踪段；归因行 `attributionLine`（L698）。
  - 写入登记：`task-write-log.ts` 的 `readTaskWrites`（子进程 write/edit/bash 成功写盘登记，≤512 行/任务）。
- **共享工作树噪音区分**（四档归因）：
  - own（命中本任务登记）/ **sibOnly ↔sib**（同 `runId` 兄弟节点的登记 ∪ `lastWritePaths`，`collectSiblingWrites` L625，扫描上限 `SIBLING_SCAN_MAX=12` L615）/ multi（双登记，本任务优先+多方注记）/ unattributed `⚠ext`（弱断言警示 `EXT_WRITE_WARN` L462）。
  - 时间窗豁免（§5#6）：无登记路径 mtime 落在 startedAt/endedAt ± `EXT_EXEMPT_SLACK_MS=2min`（L548）且位于任务 cwd 下 → 不标 ⚠ext（`windowCwdExemption` L545-565）。
  - linked worktree 标注：`gitPathBaselineNote`（L765）"路径基准：worktree <toplevel>（分支 <branch>）/主仓 <toplevel>"；`resolveGitCwd`（L391）同源判定（--git-dir ≠ --git-common-dir）附 `[linked worktree]` note；diff `-- .` 子树限幅防误标并行写入者。
- **finalizer 消费**：finalizer.ts:110-126（truncated 升级 done：测试绿+有 diff）、L128-129（evidenceText 复用 sync auto-verifier 结果，不重跑）、L131（否则 `appendEvidence`）、L136-150（done/error/truncated 追加产物摘要块；之后 `clearTaskWrites`——error 不清，供 resume 后归因）。

## 6. query_task 时间戳

文件：`extensions/amagi-core/task-query.ts`
- **格式化**：`safeTime`（L45-51）——`new Date(ts).toISOString().slice(11,19)` → **UTC 的 HH:MM:SS，无时区标注**（坏时间戳回落 `"??:??:??"`）。消费点：启动/结束行（L300-301）、活动窗口逐条 `safeTime(e.ts)`、`summarizeEntry` 会话轨迹逐条（L54）。
- **混用本地时基的事实**：board 分支 journal 中断残留行用 `new Date(d.at).toTimeString().slice(0,8)`（L253）= **本地时区**；task-tool.ts:975（停滞告警附时刻）、task-run.ts:532/629/636（进程实况 fmtClock）、journal.ts:439 同为 `toTimeString()` 本地时间。registry 侧 startedAt/endedAt 为 `Date.now()` epoch ms（task-run.ts:544 `const endedAt = o.endedAt ?? Date.now()`）。

## 7. 证据采集超时

- **定义位置**：`extensions/amagi-core/evidence.ts`——**模块级 const，不可经 env 配置**：
  - `TEST_TIMEOUT_MS = 120_000`（L80，基线测试；`defaultRunCmd` L137 超时 SIGTERM，+3s SIGKILL 进程组 L164-166）
  - `GIT_TIMEOUT_MS = 10_000`（L81，diff/rev-parse/status 快照）
  - `SUMMARY_GIT_TIMEOUT_MS = 5_000`（L741，产物摘要块 `gitQuiet`）
  - 邻近有界值（同样 const）：worktree.ts:31 git 超时 30s；task-tool.ts probeGitDirtyState 2s；evidence.ts:548 归因豁免 ±2min；task-write-log 登记上限 512 行。
- **触发链**（子任务结束后的基线测试/证据采集）：
  - task-tool.ts:384-431——runTask 内 auto-verify 循环：`shouldAutoVerify`（L146）→ `gatherEvidenceReport(cwd,{trusted:true, preverifiedTest})`（L388，复用子代理末次同命令测试结果 `findReusableTestEvidence`，task-jsonl）→ 失败则注入 nudge resume 修复（`repairMax` 轮）。
  - finalizer.ts:111-131——truncated/done 路径 `gatherReport ?? gatherEvidenceReport` 与 `appendEvidence`（evidence.ts:1059），均落入上述 const 超时。
  - **无任何 `AMAGI_EVIDENCE*` env 读取点**（grep 全仓无命中）；evidence 超时调整只能改常量。可配的相关超时属于其他机制：`AMAGI_STALL_MS`（停滞告警 5min，reliability.ts:33）、`AMAGI_SPAWN_READY_MS`（启动就绪 30s，reliability.ts:50）、`AMAGI_SETTLED_EXIT_MS`/`AMAGI_SETTLE_REF_GRACE_MS`（task-run.ts:1207-1222）。

---

### 未覆盖 / 待核验
- task-background.ts / rpc-pool.ts 的 cancel 分支只核对了拦截器注册面（task-service.ts:139-150），未逐行读其内部实现。
- `repairMax` 的取值点（task-tool.ts runTask 上段）未回读精确行号；`shouldAutoVerify` 的完整判定体（task-tool.ts:146）未全文摘录。
- 主进程 watchdog 与 registry running child 之间确无豁免关系——结论基于 watchdog.ts 全文（无 registry import 之外的活跃子进程查询；它 import task-registry 仅用于 stall 告警对账，L18）。
