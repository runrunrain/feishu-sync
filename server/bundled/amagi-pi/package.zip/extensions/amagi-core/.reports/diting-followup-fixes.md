# diting 阶段集成审核（APPROVE WITH CONCERNS）4 项 findings + 2 项 Note 增量修复报告

**基线**：三批已合入改动（工作树未提交，`git diff HEAD`）+ 本增量修复。
**审核输入**：`/Users/maorun/.pi/agent/amagi/artifacts/d5fb8955-0b98-4456-ba39-01f46ccd6bd3/result.md`（M-1 为 diting 端到端复现的 Major）。
**纪律**：不回退既有修复语义；每项修复均带正/负成对测试与真实返回值关键词断言。

## 门禁结果（本机当前树实跑）

| 门禁 | 命令 | 结果 |
|---|---|---|
| 类型 | `npm run typecheck` | 绿（0 error） |
| 依赖 | `npm run depcruise` | 绿（101 模块 / 397 依赖，0 violation） |
| 全量 | `npm test` | **1971 tests / 1969 pass / 0 fail / 2 skipped**（既有 win32 skip） |
| 针对性 | 5 个受影响测试文件 | 全绿（见下逐项证据） |

---

## M-1（Major）· 守卫变量空格分词误放行

**根因**：`expandShellTarget` 做纯文本替换后，`W="/abs/x y"; cd $W` 被当成「cd 到整串 `/abs/x y`」。bash 对未引用 `$W` 做词分裂，真实 `cd` 落首字段 `/abs/x`——若首字段目录含 `.env` 而整串目录干净，守卫探整串放行（diting 端到端复现的 .env 泄漏路径）。lexer 剥离引号后 `cd $W` 与 `cd "$W"` 文本相同，原实现无从区分。

**修复**：
- `shell-lexer.ts`：tokenizer 核心升级为带引号语义的 `ShellTokenMeta { text, unquotedVar }`——`unquotedVar` 只在**引号外**遇到 `$` 时置位（`cd "$W"` 为 false）；`shellTokens`/`shellSegments` 由 meta 派生，token 文本序列与旧实现逐字节等价（零语义回退）。
- `guards.ts`：`parseGitInvocations` 改用 `shellSegmentsMeta`，cd / `-C` / `--git-dir` / `--work-tree` 六处目标解析全部携带 `unquotedVar`；`expandShellTarget` 对「未引用变量展开 + 结果含 IFS 空白/glob 元字符（`\s*?[`）」**或展开为空/纯空白**（bash 分词后零字段 = `cd` 落 HOME，不是 `path.resolve(base,"")`）标 unresolved → 走既有 cwd-uncertain 保守阻断文案。不模拟首分词取位（避免把 `cd "$W"` 引向探错仓库）。

**测试**：`tests/ev-20260910-919667.test.mjs` 新增「diting M-1…」：
- negative：`W="<base>/x y"; cd $W && git add -A && git commit` → 拦截且文案 `无法确定 git add 将在哪个仓库/目录执行` + `字面路径`；`git -C $W` 同形态同样拦截。
- happy 成对：`cd "$W"`（引号引用，干净整串目录）→ `null` 放行；值无空格 `cd $W` → 照常解析并精确拦截 `.env`（`提交包含不该提交的内容` + `.env`）；`cd "$W"` 指向含 `.env` 目录仍拦截。
- 结果：8/8 pass（既有 7 个 919667 用例全量回归通过，含「变量引号 `$W`」「`${W}`」形态）。

**残余风险**：误伤面仅限「引号外变量值含空格/通配符 + git add/commit」的罕见组合，文案已给字面路径/引号变通；恶意对抗仍可用多层间接展开绕过（模块头既有安全边界声明不变）。

## m-1（Minor）· journal goal 留档预算被 fullRepoCheckoutNote 前缀侵蚀

**根因**：single dispatch 的 `taskText = assembleSingleTaskText(_wtPreNote + task, …)` 同时流向「子进程任务书」与 `journalDispatch({goal: task})`；worktree+子目录时前缀 271–389 字吃满 `JOURNAL_GOAL_CAP=500`，352a91 接力包 journal 回读被截到 111–229 字。

**修复**：用途分离——`RunTaskOptions.journalGoal` / `BackgroundOpts.journalGoal` 新增（缺省回落 `task`，其它调用方行为不变）；single dispatch 的 sync `runTask` 与 background `runBackgroundTask` 均传 `journalGoal: params.task`（原始任务书）。`[全仓检出]` 标注仍进子进程任务书、回流文案与 registry goal（既有定位修复语义不回退）。

**测试**：`tests/ev-20260910-worktree-lifecycle.test.mjs` 两个 cc75b2 e2e 断言更新为新契约：
- sync：`journal goal === "在子目录项目里干活"`、`doesNotMatch /\[全仓检出\]/`；同用例 `ARGV:` 仍断言子进程任务书含全仓检出标注与项目根。
- background：`journal goal === "后台在子目录项目里干活"`、`doesNotMatch /\[全仓检出\]/`；`journal.cwd` 语义不变。
- 结果：14/14 pass（e3906c 复用反查、cc75b2 正反例等既有用例全量回归）。

**残余风险**：无（纯用途分离，journal 记录内容对既有消费者是更强留档）。

## m-2（Minor）· adoptExternal 回填 error 记录不在 GC 保护集

**根因**：`adoptExternal` 收编的 `status=error` 记录 ∉ `LIVE_CHAIN_STATUS`，其登记文件 mtime 已超 24h TTL——同帧 `gcTaskWritesOnSettled` 或后续清扫可直接回收，违背「resume 链归因不被误清」。

**修复**：`task-registry.ts` 增加进程内 `adoptedAt` 登记表 + `ADOPT_GC_PROTECT_DEFAULT_MS = 30min`；`adoptExternal` 打收编时间戳（顺手淘汰超窗旧条目，Map 有界）；`gcTaskWritesOnSettled` 的 protect 集并入窗口内收编记录；`clear()` 同步清空。新增测试缝 `_setAdoptGcProtectMsForTest`（0 = 关闭保护，undefined 回落默认）。

**测试**：`tests/ev-20260910-0f59ce.test.mjs` 新增「diting m-2…」：
- negative（误清回归）：48h mtime 的收编登记 + 终态钩子触发清扫 → 文件保留、回收审计不含该 taskId；同帧非收编陈旧孤儿照常回收（保护集不放大）。
- 超窗正例：窗口置 0 后再次终态清扫 → 收编登记正常回收并写入审计（保护不永久化）。
- 结果：12/12 pass。

**残余风险**：仅进程内保护（跨进程重启后窗口重置，但重启场景 registry 已重建、登记也由回填链重新收编）；30min 窗口内的极端「收编后立即长挂起 + 另一任务终态」会多留一份登记，属保守方向。

## m-3（Minor）· worktree 反查可能把主检出当工作树复用

**根因**：`reuseBlocker` 仅比对 `registered.path === root`。从 linked worktree 内派发（root=该树）且 `amagi/<name>` 被主检出占用时，反查命中主检出且无 blocker → 以 worktree 语义「复用」主检出，隔离语义不成立。

**修复**：`setupWorktree` 反查命中时取 `git worktree list` **首条（恒为主工作区）** 作为 `mainWorktreePath` 传入 `reuseBlocker`；命中即拒，返回含「主检出」原因的既有冲突文案（保留 `可改用 cwd=<path> 派发` 与「去掉 worktree 参数」建议，不透传裸 git 原文）。

**测试**：`tests/ev-20260910-worktree-lifecycle.test.mjs` 新增：
- negative：linked worktree 内 `setupWorktree(wt, "occupied")`（主检出占用 `amagi/occupied`）→ `ok:false`，文案含「主检出/同名工作树已存在」+ `cwd=<主检出>` 建议 + 「去掉 worktree 参数」，无 `fatal:`，不落盘。
- 正向配套：分支在另一棵 linked worktree（非主检出）→ 复用照旧（`reused + reusedOutsideConvention`，路径指向该树），证明新判定不扩大化。
- 结果：14/14 pass。

**残余风险**：无（`git worktree list` 首条为主工作区是 git 文档保证；探测失败时 `mainWorktree` 为 undefined → 退回原判定，不引入新误拒）。

## n-1（Note）· watchdog 注释口径 + details.taskId 结构化落地

**根因**：`registryStallAlarmResolved` 对「正则命中但前缀未命中/歧义」走 `isTaskResolved(undefined)=true` 剔除，与模块注释「无法还原保守保留」的字面口径不符；发射点仍只带正文短 id，对账依赖文案格式。

**修复**：
- 发射点（7f6a90 §6.1 方案落地）：`createStallAlarm` 的 `sendMessage` 增加 `details: { taskId: info.taskId }`（全量 id）；对账侧 `stallAlarmTaskRef` 早已 `details.taskId` 优先、正文正则降为旧消息后备。
- `watchdog.ts` 模块头注释改写为如实两档口径：身份不可还原（正则失败）→ 保守保留；身份可还原但 registry 未命中/前缀歧义 → 按陈旧（非本进程任务）剔除（8-hex 碰撞 <10⁻⁶）。

**测试**：`tests/ev-20260910-7f6a90.test.mjs` 新增「diting n-1…」：发射真实消息断言 `details.taskId === 全量 id`、`stallAlarmTaskRef` 经 details 还原；用发射消息 + 伪造正文短 id 的诱饵驱动对账 → 各按 details 精确对齐（终态剔、运行中留）；负向既有用例（身份不可还原保守保留）保持。10/10 pass。

**残余风险**：正文正则仅服务升级前旧消息；旧消息歧义剔除口径已由注释如实说明。

## n-3（Note）· _bgResumeNotes 缺 modelNote

**根因**：后台 resume 完成通知的注记数组不含 `r.modelNote`，与 sync resume 不一致；且实测后台完成 payload 由 task-run finalize 构造、本就没有 modelNote（归一注记 spawn 时只挂到 BackgroundStart）——只补数组是死代码。

**修复**：`task-resume.ts` `wrappedFinalize` 在调用 `onComplete` 前把 `_nm.note` 补挂到完成 payload（`!r.modelNote` 守卫，sync 返回值对象另行挂载不回退）；`task-tool.ts` `_bgResumeNotes` 增列 `r.modelNote`，与 `_resumeNotes` 对齐。

**测试**：`tests/ev-20260910-model-route.test.mjs` 新增 happy/negative 对：
- happy：`model: "deepseek-flash"`（唯一裸名）后台 resume 完成通知含 `[model 归一] 裸模型名 "deepseek-flash" → amagi-deepseek/deepseek-flash`，完成正文照常回流。
- negative：全限定 `amagi-deepseek/deepseek-v4-pro` → 通知照常但无 `[model 归一]` 行（零噪音）。
- 结果：17/17 pass。

**残余风险**：无。

---

## 修改文件清单

| 文件 | 内容 |
|---|---|
| `extensions/amagi-core/shell-lexer.ts` | `ShellTokenMeta` + 引号感知 tokenizer；`shellSegmentsMeta`；旧导出派生等价 |
| `extensions/amagi-core/guards.ts` | M-1：六处目标解析携带 `unquotedVar`，未引用空白/glob/空展开 → cwd-uncertain 保守阻断 |
| `extensions/amagi-core/task-tool.ts` | m-1 `journalGoal` 选项与两处派发传参；n-1 `details.taskId`；n-3 `_bgResumeNotes` 补 `r.modelNote` |
| `extensions/amagi-core/task-run.ts` | `BackgroundOpts.journalGoal` |
| `extensions/amagi-core/task-background.ts` | background journal goal 用 `journalGoal ?? task` |
| `extensions/amagi-core/task-registry.ts` | m-2 收编保护窗口 + `_setAdoptGcProtectMsForTest` |
| `extensions/amagi-core/task-resume.ts` | n-3 后台完成 payload 补挂 `_nm.note` |
| `extensions/amagi-core/worktree.ts` | m-3 主工作区不可复用判定 |
| `extensions/amagi-core/watchdog.ts` | n-1 注释口径如实化 |
| `tests/ev-20260910-919667.test.mjs` | M-1 正/负用例 + fixture |
| `tests/ev-20260910-worktree-lifecycle.test.mjs` | m-1 断言更新 + m-3 正/负用例 |
| `tests/ev-20260910-0f59ce.test.mjs` | m-2 正/负用例 |
| `tests/ev-20260910-7f6a90.test.mjs` | n-1 发射/对账耦合用例 |
| `tests/ev-20260910-model-route.test.mjs` | n-3 正/负用例 |

## 未覆盖 / 保留项

- n-2（`gitFileSet` 的 `-u` 未跟踪文件保守误拦面）与审核报告 §7.5 的既有取舍一致，按 diting 结论「可接受」未改动。
- n-4/n-5/n-6/n-7 为非本 4 findings + 2 Note 范围，未处理（其中 n-4 文档行数漂移属独立小修，本任务未授权）。
- 未跑真实 pi 进程级 e2e（沿用 diting 盲区声明）；新增用例全部经真实入口/真实 git fixture 驱动。
