/**
 * watchdog.ts — 活性看门狗。
 *
 * 背景（2026-07-31 实战卡点）：pi --print 会话模型请求挂起 259s 无任何输出也不退出，
 * 只能人工中断。模型/网络挂起在插件边界外，但「无活性时长」可在插件内观测——
 * 看门狗对**沉默**触发而非总时长：正常长任务（SubAgent 数分钟、模型长思考流）持续
 * 有事件流不会误杀；无事件场景也保留 30 分钟窗口，兼容 provider 缓冲超长思考。
 *
 * 活性与委托规则：
 *   1) 内置工具的 start/update/end 都是新动作，都会重置静默计时；工具在飞本身不构成
 *      无限豁免，开始后连续 30min 无 update/end 仍会触发兜底；
 *   2) 同步 SubAgent 派发在飞（sync-wait.ts 计数 >0）由子进程自己的 watchdog 监视。pi 0.83.0
 *      虽会为自定义 task 工具发射 start/end，但长等待期间未必持续有 update；模块计数提供更精确的
 *      领域状态豁免并刷新活性时间戳，避免健康的长任务因事件间隔过长被误判。
 *
 * TUI 双阈值（ev-20260903-6ce4a9，实战 2026-09-04 两次）：provider 连接级挂起可穿透 pi
 * retry.provider（timeoutMs=300000 + maxRetries=3 全程零 token、无重试、无错误帧）——主会话冻结
 * 13.5min 无任何提示，用户只能手动终止。TUI 分支因此细化双阈值判定：
 *   a) toolsInFlight === 0（纯模型请求等待，正是挂起形态）→ TUI 专属阈值
 *      AMAGI_WATCHDOG_TUI_SILENCE_MS（默认 10min；未设回退 AMAGI_WATCHDOG_SILENCE_MS，≤0 禁用
 *      TUI 告警），每阈值窗口重复 notify 且文案分级：首次温和提示（可 Esc 中止本轮），
 *      第二次起升级为「疑似 provider 连接挂起」判读；
 *   b) toolsInFlight > 0（可能是长 bash/构建无 update）→ 维持旧阈值单次告警，防误报。
 *
 * 触发（默认 30min 无事件，AMAGI_WATCHDOG_SILENCE_MS 可调，0=禁用）：
 *   1) 诊断行落盘 <amagiData>/watchdog.log + stderr 可见输出；
 *   2) TUI 主会话只告警，绝不调用 ctx.abort()——模型首 token 延迟不是挂死证据（双阈值细化见上节）；
 *   3) 非 TUI 会话调用 ctx.abort() 优雅中断当前 run；宽限（默认 15s，已冻结为常量——原 AMAGI_WATCHDOG_GRACE_MS）后仍无活性 →
 *      **仅子进程（AMAGI_SUBAGENT=1，print/json 无 UI）硬退出 exit(3)**；
 *      主进程绝不杀——TUI 仅 notify 告警一次，print 主会话 abort 后 run 自然收口。
 *      （v1.5.197 硬性约束：主进程不可被杀；可注入 deps.allowExit 覆盖，测试用。）
 *
 * ev-20260910-7f6a90：本模块同时承担「停滞告警投递侧终态对账」（与静默计时/阈值开关解耦，
 * 注册于 registerWatchdog）：`context` 事件在每次 provider 请求前剔除已终结任务遗留的
 * `amagi:stall-warn`——sync 子任务运行期生成的告警只能随 steer 队列在该任务终态后投递，
 * 对账让这类迟到告警自行消解（详见文末 registerStallAlarmReconciler）。
 *
 * 定时器 unref——看门狗自身绝不阻止进程退出。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataFile } from "./data-dir.ts";
import { syncWaitsInFlight, syncWaitGeneration } from "./sync-wait.ts";
import { registry, isTaskResolved } from "./task-registry.ts";

/** pi ExtensionAPI 最小面（仅 watchdog 所需）。v1.5.248：导出供 index 注册点窄化断言（ExtensionAPI.on 泛型重载与结构面不兼容，运行时兼容）。 */
export interface WatchdogPi {
	on(event: string, handler: (event: unknown, ctx: WatchdogCtx) => unknown): void;
}

interface WatchdogCtx {
	mode?: string;
	hasUI?: boolean;
	abort?: () => void;
	ui?: { notify?: (msg: string, level?: string) => void };
	/** ev-20260914-8f2669③：abort 文案 resume 句式用（真实 pi ExtensionContext 恒有；缺省安全退化）。 */
	sessionManager?: { getSessionId?: () => string };
}

export interface WatchdogDeps {
	silenceMs?: number;
	/** ev-20260903-6ce4a9：TUI 零工具在飞时的专属告警阈值（生产由 resolveTuiSilenceMs 解析注入）。≤0 = TUI 告警禁用。 */
	tuiSilenceMs?: number;
	graceMs?: number;
	tickMs?: number;
	now?: () => number;
	exit?: (code: number) => void;
	stderr?: (s: string) => void;
	logFile?: string;
	/** 宽限后允许硬退出 exit(3)。缺省 = AMAGI_SUBAGENT=1（子进程）；主进程恒 false（不可杀主进程）。 */
	allowExit?: boolean;
}

export interface WatchdogHandle {
	/** 测试/观测用：当前相位与计数（tuiNotifies：TUI 分级告警已触发窗口数）。 */
	state(): { phase: string; aborts: number; exits: number; tuiNotifies: number; toolsInFlight: number; syncWaits: number; agentActive: boolean };
	dispose(): void;
}

const ACTIVITY_EVENTS = [
	"message_start", "message_update", "message_end",
	"turn_start", "turn_end",
	"tool_execution_update",
] as const;

/**
 * 普通模型思考/网络静默的生产兜底。已知交互式 shell 命令由 guards.ts 在执行前直接拦截，
 * 不应再用分钟级无事件启发式猜测“挂起”，否则会误杀 provider 缓冲的超长思考。
 */
export const DEFAULT_WATCHDOG_SILENCE_MS = 30 * 60_000;

/**
 * TUI 主会话零工具在飞（纯模型请求等待）时的专属告警阈值（ev-20260903-6ce4a9）。
 * 10min：远小于全局兜底 30min——挂起形态下用户应尽早拿到「可 Esc」提示；又大于 provider
 * 缓冲长思考的常见首 token 延迟，避免频繁打扰。优先级链见 resolveTuiSilenceMs。
 */
export const DEFAULT_WATCHDOG_TUI_SILENCE_MS = 10 * 60_000;

export function createWatchdog(pi: WatchdogPi, deps?: WatchdogDeps): WatchdogHandle | null {
	const silenceMs = deps?.silenceMs ?? DEFAULT_WATCHDOG_SILENCE_MS;
	if (!silenceMs || silenceMs <= 0) return null; // 0=禁用（全局禁用同时覆盖 TUI 分支）
	// ev-20260903-6ce4a9：TUI 专属阈值仅约束 TUI 分支；≤0 只禁用 TUI 告警，不影响非 TUI 路径。
	// ev-20260903-6ce4a9 兼容链：显式 tuiSilenceMs > 调用方注入的 silenceMs（测试/程序化调用保持旧语义）
	// > 默认 10min。生产唯一入口 registerWatchdog 显式传 resolveTuiSilenceMs，env 优先级链不受本回退影响。
	const tuiSilenceMs = deps?.tuiSilenceMs ?? deps?.silenceMs ?? DEFAULT_WATCHDOG_TUI_SILENCE_MS;
	const graceMs = deps?.graceMs ?? 15_000;
	const tickMs = deps?.tickMs ?? 5_000;
	const now = deps?.now ?? (() => Date.now());
	const exit = deps?.exit ?? ((code: number) => process.exit(code));
	const stderr = deps?.stderr ?? ((s: string) => process.stderr.write(s + "\n"));
	const logFile = deps?.logFile ?? amagiDataFile("watchdog.log");
	// v1.5.197：硬退出权限仅授予子进程（AMAGI_SUBAGENT=1）。主进程（TUI/print）绝不 exit——
	// TUI 仅 notify；print 主会话 abort 后 run 结束自然收口，无需强杀。
	const allowExit = deps?.allowExit ?? process.env.AMAGI_SUBAGENT === "1";

	let agentActive = false;
	let toolsInFlight = 0;
	let lastActivity = now();
	let lastEvent = "(none)";
	let phase: "armed" | "aborted" | "notified" | "exited" = "armed";
	let abortAt = 0;
	let aborts = 0;
	let exits = 0;
	/** TUI 分级告警已触发的窗口数（0=未触发；恢复活性时复位，见 bump）。 */
	let tuiNotifyCount = 0;
	let lastCtx: WatchdogCtx | undefined;
	/** 已见 sync-wait 变更代次（纯序号比较，不跨时钟基——now 可注入，绝不引入 Date.now() 时间戳）。 */
	let seenSyncWaitGen = syncWaitGeneration();

	function appendLog(line: string): void {
		try {
			fs.mkdirSync(path.dirname(logFile), { recursive: true });
			// 体积护栏：>256KB 截断保留尾部一半
			try {
				const st = fs.statSync(logFile);
				if (st.size > 256 * 1024) {
					const tail = fs.readFileSync(logFile, "utf8").slice(-128 * 1024);
					fs.writeFileSync(logFile, tail, "utf8");
				}
			} catch { /* 文件不存在 */ }
			fs.appendFileSync(logFile, line + "\n", "utf8");
		} catch { /* 日志失败不阻断看门狗 */ }
	}

	function bump(name: string): void {
		lastActivity = now();
		lastEvent = name;
		tuiNotifyCount = 0; // ev-20260903-6ce4a9：新动作重开 TUI 告警分级阶梯
		if (phase === "aborted" || phase === "notified") {
			const previous = phase;
			appendLog(`${new Date().toISOString()} RECOVERED event=${name} previous=${previous}（恢复活性）`);
			phase = "armed";
		}
		// exited 为终态（真实进程已死；测试注入场景不复活）
	}

	for (const ev of ACTIVITY_EVENTS) pi.on(ev, (_e, ctx) => { lastCtx = ctx; bump(ev); });
	pi.on("agent_start", (_e, ctx) => { lastCtx = ctx; agentActive = true; bump("agent_start"); });
	pi.on("agent_end", (_e, ctx) => { lastCtx = ctx; agentActive = false; phase = "armed"; bump("agent_end"); });
	pi.on("agent_settled", (_e, ctx) => { lastCtx = ctx; agentActive = false; phase = "armed"; });
	pi.on("session_start", () => { agentActive = false; toolsInFlight = 0; phase = "armed"; bump("session_start"); });
	pi.on("tool_execution_start", (_e, ctx) => { lastCtx = ctx; toolsInFlight += 1; bump("tool_execution_start"); });
	pi.on("tool_execution_end", (_e, ctx) => { lastCtx = ctx; toolsInFlight = Math.max(0, toolsInFlight - 1); bump("tool_execution_end"); });

	const timer = setInterval(() => {
		// 同步 SubAgent 派发在飞 = 合法沉默。即使自定义 task 有 start/end 边界事件，长等待期间
		// 也未必持续有 update；逐 tick 刷新活性——等待结束后从新时间戳起算完整静默窗口，避免
		// "派发 10 分钟 → 结束瞬间沉默计时已超阈值 → 下一 tick 立即误 abort"。
		if (syncWaitsInFlight() > 0) { lastActivity = now(); lastEvent = "sync_task_wait"; tuiNotifyCount = 0; seenSyncWaitGen = syncWaitGeneration(); return; }
		// 派发在两个 tick 间隙开始/结束：代次变化即"刚发生 begin/end"，以自家时钟 now() 校准活性，
		// 防旧时间戳下一 tick 立即误 abort（快审 major-1）；序号比较杜绝混合时基永不 abort（快审 R3）。
		const gen = syncWaitGeneration();
		if (gen !== seenSyncWaitGen) { seenSyncWaitGen = gen; lastActivity = now(); lastEvent = "sync_task_wait_end"; tuiNotifyCount = 0; }
		if (!agentActive) return;
		const silence = now() - lastActivity;
		// v1.5.199：TUI 是人在环主会话。零事件只能证明 provider 尚未产出首个事件，不能
		// 区分“正常长思考”和“网络挂死”。旧实现先 abort 再声称“TUI 不杀会话”，实际会
		// 立即产生 Operation aborted 并中断当轮。TUI 因此严格保持被动告警，绝不 abort/exit。
		// ev-20260903-6ce4a9 双阈值：零工具在飞（纯模型请求等待，挂起形态）用 TUI 专属阈值
		// 每窗口重复告警并分级；工具在飞（长 bash/构建）维持旧阈值单次告警，防误报。
		const isTui = lastCtx?.hasUI === true || lastCtx?.mode === "tui";
		if (isTui) {
			if (!(tuiSilenceMs > 0)) return; // AMAGI_WATCHDOG_TUI_SILENCE_MS≤0：TUI 告警禁用（与 0=禁用语义一致）
			if (toolsInFlight === 0) {
				// 每阈值窗口重复 notify：第 1 窗口温和提示，第 2 窗口起升级为疑似挂起判读。
				if (silence >= tuiSilenceMs * (tuiNotifyCount + 1)) {
					tuiNotifyCount += 1;
					const tail = `（最后: ${lastEvent}，mode=${lastCtx?.mode || "?"}，AMAGI_WATCHDOG_TUI_SILENCE_MS=0 可禁用）`;
					const diag = tuiNotifyCount >= 2
						? `[amagi-watchdog] ${Math.round(silence / 1000)}s 无事件且无工具在飞——疑似 provider 连接挂起（本会话实战同型：零 token 无重试无错误帧）。建议 Esc 中止本轮（上下文保留），必要时换 provider/模型重试${tail}`
						: `[amagi-watchdog] ${Math.round(silence / 1000)}s 无事件且无工具在飞——可能是 provider 缓冲长思考；若确认长时间无输出，可 Esc 中止本轮后重试，会话与在途子任务不受影响${tail}`;
					stderr(diag);
					appendLog(`${new Date().toISOString()} TUI_WARN silence=${Math.round(silence)}ms n=${tuiNotifyCount} tools=0 last=${lastEvent} mode=${lastCtx?.mode || "?"} pid=${process.pid}`);
					if (lastCtx?.ui?.notify) {
						try { lastCtx.ui.notify(diag, "warning"); } catch { /* 通知失败不阻断 */ }
					}
					if (phase === "armed") phase = "notified"; // 恢复活性时 bump 记 RECOVERED 并复位阶梯
				}
				return;
			}
			// 工具在飞：可能是合法长命令（bash/构建）无 update——维持旧阈值、单次、文案不变。
			if (phase === "armed" && silence >= silenceMs) {
				phase = "notified";
				const diag = `[amagi-watchdog] ${Math.round(silence / 1000)}s 无事件（最后: ${lastEvent}，mode=${lastCtx?.mode || "?"}）——响应较慢，仅告警，不中断 TUI 会话（AMAGI_WATCHDOG_SILENCE_MS=0 可禁用）`;
				stderr(diag);
				appendLog(`${new Date().toISOString()} WARN silence=${Math.round(silence)}ms last=${lastEvent} mode=${lastCtx?.mode || "?"} pid=${process.pid}`);
				if (lastCtx?.ui?.notify) {
					try { lastCtx.ui.notify(diag, "warning"); } catch { /* 通知失败不阻断 */ }
				}
			}
			return;
		}
		if (phase === "armed" && silence >= silenceMs) {
			// 非 TUI（print/json/子进程）——行为、阈值不变；文案按 ev-20260914-8f2669③ 直接附可复制的
			// 调整与续接建议：env 示例与实际 env 名一致；resume 句式用真实 sessionId 前 8 位（缺省给格式占位）。
			phase = "aborted";
			abortAt = now();
			aborts += 1;
			let sessionRef: string | undefined;
			try {
				const sid = lastCtx?.sessionManager?.getSessionId?.();
				if (typeof sid === "string" && sid) sessionRef = `"${sid.slice(0, 8)}"`;
			} catch { /* 取不到则退化为占位格式 */ }
			const diag = `[amagi-watchdog] ${Math.round(silence / 1000)}s 无事件（最后: ${lastEvent}，mode=${lastCtx?.mode || "?"}）——达到静默超时兜底，执行 abort；${Math.round(graceMs / 1000)}s 宽限内无恢复将硬退出。可复制调整：AMAGI_WATCHDOG_SILENCE_MS=3600000（放宽至 60 分钟，0=禁用）；会话与已落盘产物保留，可续接：task({ session: ${sessionRef || '"<sessionId 前 8 位>"'}, task: "续接完成剩余工作" })`;
			stderr(diag);
			appendLog(`${new Date().toISOString()} ABORT silence=${Math.round(silence)}ms last=${lastEvent} mode=${lastCtx?.mode || "?"} pid=${process.pid}`);
			if (lastCtx?.hasUI && lastCtx.ui?.notify) {
				try { lastCtx.ui.notify(diag, "warning"); } catch { /* 通知失败不阻断 */ }
			}
			try { lastCtx?.abort?.(); } catch { /* abort 失败由宽限段兜底 */ }
			return;
		}
		if (phase === "aborted" && now() - abortAt >= graceMs) {
			const noUI = !lastCtx?.hasUI;
			const canHardExit = noUI && allowExit;
			const diag = `[amagi-watchdog] abort 后 ${Math.round((now() - abortAt) / 1000)}s 仍无活性——${canHardExit ? "子进程硬退出(exit 3)" : "保持会话存活，仅告警（主进程绝不杀）"}`;
			stderr(diag);
			appendLog(`${new Date().toISOString()} HARD noUI=${noUI} allowExit=${allowExit} last=${lastEvent} pid=${process.pid}`);
			if (canHardExit) {
				exits += 1;
				phase = "exited"; // 终态：exit 被拦截（测试注入）也不重复调用
				exit(3);
			} else {
				if (lastCtx?.ui?.notify) {
					try { lastCtx.ui.notify(diag, "warning"); } catch { /* ignore */ }
				}
				phase = "notified"; // 只告警一次；下次 bump 复位
			}
		}
	}, tickMs);
	timer.unref?.();

	return {
		state: () => ({ phase, aborts, exits, tuiNotifies: tuiNotifyCount, toolsInFlight, syncWaits: syncWaitsInFlight(), agentActive }),
		dispose: () => clearInterval(timer),
	};
}

/** ev-20260914-8f2669②：全局静默窗口 env 解析（纯函数）。bash 静默心跳（bash-override.ts）与
 *  registerWatchdog 共用同一窗口口径——心跳周期/总窗按本值推导，不新增独立 env 开关
 *  （env-knobs 出处对账：env 读取点统一留在本模块）。非法/负值按未设回退默认，0=禁用语义透出。 */
export function resolveSilenceMsEnv(env: NodeJS.ProcessEnv = process.env): number {
	const v = Number(env.AMAGI_WATCHDOG_SILENCE_MS);
	return Number.isFinite(v) && v >= 0 ? v : DEFAULT_WATCHDOG_SILENCE_MS;
}

/**
 * ev-20260903-6ce4a9：TUI 专属阈值 env 解析（纯函数，测试注入校验优先级链）。
 * 优先级：AMAGI_WATCHDOG_TUI_SILENCE_MS（显式设置，含 0=禁用 TUI 告警）
 *   → AMAGI_WATCHDOG_SILENCE_MS（用户设过全局则尊重，含 0）
 *   → DEFAULT_WATCHDOG_TUI_SILENCE_MS（10min）。非法值（非数/负数）按未设回退，与既有 num 语义一致。
 */
export function resolveTuiSilenceMs(tuiEnv: string | undefined, silenceEnv: string | undefined): number {
	const num = (env: string | undefined, dflt: number): number => {
		const v = Number(env);
		return Number.isFinite(v) && v >= 0 ? v : dflt;
	};
	return num(tuiEnv, num(silenceEnv, DEFAULT_WATCHDOG_TUI_SILENCE_MS));
}

// ════════════════════════════════════════════════════════════════════════════
// ev-20260910-7f6a90：停滞告警投递侧终态对账（迟到告警自行消解）
// ════════════════════════════════════════════════════════════════════════════
//
// 事故（2026-09-10 battle-sim/unit-face-settlement，会话 JSONL 可回溯）：diting 任务 30f2bd74
// 于 16:58:37 正常 done 回流，却紧跟在同一条 toolResult 之后出现 16:45:32 生成、静默排队 13min
// 的 `amagi:stall-warn`（静默 456s）——Leader 只能人工判断「任务已结束，忽略迟到告警」。
//
// 根因不在发射判定（告警生成时任务确在运行，发射前过滤已按 registry 终态拦截），而在投递链路：
// sync 子任务执行期 Leader 正在 stream，`sendMessage({deliverAs:"steer"})` 只能排队；pi 的
// agent loop 在「当前 turn 的工具结果全部落账后」才取走 steer 消息。于是任务运行期生成的告警
// 必然在该任务终态之后才进入上下文——发射前检查管不到投递时刻。
//
// 对账因此发生在 LLM 实际看到消息之前：pi `context` 事件在每个 provider 请求前给出完整 messages，
// 返回剔除后的数组即可。口径与发射前过滤一致（终态/记录缺失 → 丢弃），按身份可还原性分两档：
//   · 身份不可还原（正则失败/非停滞告警）→ 保守保留（不误删）；
//   · 身份可还原（details.taskId 优先，正文 8-hex 短 id 后备）但 registry 未命中/前缀歧义 →
//     按陈旧（非本进程任务）剔除。歧义面为 8-hex 前缀碰撞（<10⁻⁶/告警），未命中即非本进程任务；
//     发射点已带 details.taskId，正文正则仅作旧消息后备，不再是对账的身份主通道。
// 查询异常静默放行（对账绝不阻断 provider 请求）。消息仍留在会话 JSONL（可观测性不丢），
// 只是不再消耗 Leader 的注意力。

/** 停滞告警 custom 消息类型（协议字面；发射点 task-tool.ts createStallAlarm）。 */
export const STALL_WARN_CUSTOM_TYPE = "amagi:stall-warn";

/** 从停滞告警消息还原任务身份：details.taskId（全量 id）优先，回退正文 `[停滞警告] <agent>/<短 id>`。
 *  非停滞告警 / 无法识别 → undefined（调用方保守保留）。 */
export function stallAlarmTaskRef(message: unknown): string | undefined {
	const m = message as { role?: unknown; customType?: unknown; details?: unknown; content?: unknown } | null;
	if (!m || typeof m !== "object" || m.role !== "custom" || m.customType !== STALL_WARN_CUSTOM_TYPE) return undefined;
	const detailRef = (m.details as { taskId?: unknown } | undefined)?.taskId;
	if (typeof detailRef === "string" && detailRef.trim()) return detailRef.trim();
	const text = typeof m.content === "string"
		? m.content
		: Array.isArray(m.content)
			? m.content.map((p) => (typeof (p as { text?: unknown })?.text === "string" ? (p as { text: string }).text : "")).join("")
		: "";
	// 正文形态：[停滞警告] diting/30f2bd74 静默 456s（检测于 16:45:32…）
	return /\[停滞警告\][^\n]*?\/\s*([0-9a-fA-F]{8,})\b/.exec(text)?.[1];
}

/** 纯决策：消息是否为「任务已终结」的停滞告警（身份不可还原 → 不算，保守保留）。 */
function isResolvedStallAlarm(message: unknown, isResolved: (taskRef: string) => boolean): boolean {
	const ref = stallAlarmTaskRef(message);
	if (ref === undefined) return false;
	try { return isResolved(ref); } catch { return false; }
}

/** 纯函数：剔除已终结任务的停滞告警；无命中时原样返回原数组（避免无谓的 messages 替换）。 */
export function pruneResolvedStallAlarms(messages: readonly unknown[], isResolved: (taskRef: string) => boolean): readonly unknown[] {
	if (!Array.isArray(messages) || messages.length === 0) return messages;
	if (!messages.some((m) => isResolvedStallAlarm(m, isResolved))) return messages;
	return messages.filter((m) => !isResolvedStallAlarm(m, isResolved));
}

/** 生产口径：身份还原（details.taskId 优先 → 正文短 id）后按 registry 终态判定（与发射前过滤同语义）。
 *  还原出身份但 registry 未命中/前缀歧义 → isTaskResolved(undefined)=true 按陈旧剔除（该分支不属于
 *  「身份不可还原」的保守保留，口径分档见模块头）。 */
function registryStallAlarmResolved(taskRef: string): boolean {
	return isTaskResolved(registry.get(taskRef) ?? registry.findByPrefix(taskRef));
}

/** 注册 `context` 对账 handler（provider 请求前执行；异常静默放行，绝不阻断请求）。 */
export function registerStallAlarmReconciler(pi: WatchdogPi): void {
	pi.on("context", (event: unknown) => {
		try {
			const messages = (event as { messages?: unknown })?.messages;
			if (!Array.isArray(messages)) return undefined;
			const next = pruneResolvedStallAlarms(messages, registryStallAlarmResolved);
			return next === messages ? undefined : { messages: next };
		} catch { return undefined; }
	});
}

/** 生产接线：读 env 装配。 */
export function registerWatchdog(pi: WatchdogPi): WatchdogHandle | null {
	// ev-20260910-7f6a90：投递侧对账独立于沉默阈值开关——AMAGI_WATCHDOG_SILENCE_MS=0 只关闭本进程
	// 沉默计时兜底，不关闭迟到告警消解（两者关注点不同）。
	registerStallAlarmReconciler(pi);
	// P3-D 冻结：graceMs 冻结自 AMAGI_WATCHDOG_GRACE_MS（默认 15000）、tickMs 冻结自
	// AMAGI_WATCHDOG_TICK_MS（默认 5000）——审计无差异化使用证据；如需恢复 env 读取请回看 git 历史。
	// ev-20260914-8f2669②：silenceMs 改经 resolveSilenceMsEnv（与 bash 心跳共用口径，语义不变）。
	return createWatchdog(pi, {
		silenceMs: resolveSilenceMsEnv(process.env),
		tuiSilenceMs: resolveTuiSilenceMs(process.env.AMAGI_WATCHDOG_TUI_SILENCE_MS, process.env.AMAGI_WATCHDOG_SILENCE_MS),
		graceMs: 15_000,
		tickMs: 5_000,
	});
}
