/**
 * tool-result-adapter.ts — amagi-pi v2 I1（方案 §4.1/§4.2/§8.2-I1）：统一 Result→工具返回适配。
 *
 * 职责（单一）：把契约层 Result<T>/ContractError/内核 TaskView 投影适配为宿主工具返回
 * （AgentToolResult 形状：content 文本 + details + isError）。分面工具（task-facets.ts）与后续
 * I2 组合根只消费本模块，不各自拼装错误正文：
 *  - 成功正文：details 行（surfaceVersion/viewVersion/taskId/revision/三轴/receiptRef/
 *    nextActions/degraded）+ 调用方正文（携带真实回执/产物关键词；全文引用走 query 分面，不展开）。
 *  - 失败正文：ContractError 结构化块（code/message/fields/effects/repairExamples）——
 *    repairExamples 是最小合法调用样例，模型可据此自修后重发（§4.2「返回两种最小合法调用，
 *    不自动删字段后执行」）。
 *  - 异常兜底：execute 抛错统一捕获为 internal-tool-error ContractError（effects=unknown——
 *    副作用状态不可确认）。宿主错误标志语义（N4 复核更新，pi 0.99.1：docs/extensions.md
 *    「Signaling errors」+ pi-agent-core dist/agent-loop.js executePreparedToolCall）：宿主采纳
 *    返回体的 isError 字段（isError: result.isError === true），execute 抛错仍归一为
 *    isError:true + 错误文本——即「返回 isError:true」与「抛错」双轨都正确标错。历史备注：
 *    0.85.1 曾为「返回值永不置错误标志，仅抛错派生」——本适配器当时选择带内返回（in-band）
 *    保住结构化错误正文与 repairExamples，代价是宿主标志位为 false；0.99.1 起该代价消失：
 *    带内返回的 isError:true 同时被宿主采纳（tool_execution_end 与 toolResult 消息帧同源
 *    finalized.isError，实测一致，N4 pi-099 冒烟 deny/dispatch 场景证据），结构化正文与
 *    repairExamples 仍原样保留（不被宿主错误替换）。返回结构零变化——旧语义下的设计在
 *    新宿主上行为更正确，无需适配。
 *  ev-20260920 增职责：withArgumentArtifactNormalization——模型面工具注册统一伪影接线
 *  （宿主 schema 校验前剥 ev-20260919 null 键与 "null" 字符串伪影；详见该函数注释）。
 */
import type { ContractError } from "./contracts/view.ts";
import type { TaskView } from "./contracts/task.ts";
import { normalizeToolArgumentArtifacts } from "./contracts/view.ts";

/** 工具成功 details 块（§4.1 公共成功返回；内核未持有视图时各轴为 null）。 */
export interface ToolDetailsBlock {
	surfaceVersion: number;
	viewVersion: number | null;
	taskId: string | null;
	revision: number | null;
	execution: string | null;
	settlement: string | null;
	acceptance: string | null;
	/** diting-M3-A4：承诺等级可见（tool-enforced=逐次执法 / guarded=壳承诺非对抗隔离）。 */
	assurance: string | null;
	receiptRef: string | null;
	nextActions: readonly string[];
	degraded: readonly string[];
	/** ev-20261017-589e6d：非单任务返回的显式作用域——multi=多句柄控制 / list=多条查询页 / none=无任务
	 *  （dryRun 未入队）。缺席=单任务投影。非单任务时逐任务字段恒 null，details 行不再拼 `taskId=? revision=?`
	 *  （「?」读作未知，与正文真实值矛盾）。 */
	scope?: "multi" | "list" | "none";
}

/** ev-20261017-589e6d：非单任务 details 块（逐任务字段 null + 显式 scope）——替代各调用点手写全 null 块。 */
export function aggregateDetailsBlock(surfaceVersion: number, scope: "multi" | "list" | "none", nextActions: readonly string[] = []): ToolDetailsBlock {
	return {
		surfaceVersion, viewVersion: null, taskId: null, revision: null, execution: null, settlement: null,
		acceptance: null, assurance: null, receiptRef: null, nextActions, degraded: [], scope,
	};
}

/** 适配后的分面工具返回（isError 缺省=非错误；pi 0.99.1 宿主语义：execute 抛错与返回体
 *  isError:true 双轨都置宿主错误标志——本扩展带内错误返回（isError:true + 结构化正文）
 *  同时获得宿主标志与模型可见 [ContractError …] 正文，两口径一致）。 */
export interface FacetToolReturn {
	content: Array<{ type: "text"; text: string }>;
	details?: unknown;
	isError?: boolean;
	/** O3b（pi-0.99.1 机会批 §4.7.2）：结构化输出载体——宿主 AgentToolResult.structuredContent 通道
	 *  （宿主 0.99+：声明 outputSchema 的工具应始终携带；codemode 脚本面收到结构化值而非文本）。
	 *  仅 task_query 填充（task-query-wire 四分支投影）；其余工具缺省不带。content/details/isError
	 *  既有消费者零感知——新增可选键不进入任何旧消费路径（JSON stdout 旧消费者忽略逻辑不变）。 */
	structuredContent?: unknown;
}

/** 内核 TaskView → details 块（视图缺位时以 null 占位——如实，不臆造三轴）。 */
export function detailsBlockOf(
	view: Readonly<TaskView> | undefined,
	surfaceVersion: number,
	taskIdFallback?: string,
): ToolDetailsBlock {
	return {
		surfaceVersion,
		viewVersion: view?.viewVersion ?? null,
		taskId: view?.taskId ?? taskIdFallback ?? null,
		revision: view?.revision ?? null,
		execution: view?.execution ?? null,
		settlement: view?.settlement ?? null,
		acceptance: view?.acceptance ?? null,
		assurance: view?.assurance ?? null,
		receiptRef: view?.receipt?.receiptId ?? null,
		nextActions: view?.nextActions ?? [],
		degraded: view?.degraded ?? [],
	};
}

/** details 行（正文首行：模型可直接解析的状态与下一步引用；全文走 query 分面）。 */
export function renderDetailsLine(d: Readonly<ToolDetailsBlock>): string {
	if (d.scope) return `[details surfaceVersion=${d.surfaceVersion} scope=${d.scope} nextActions=[${d.nextActions.join(",")}] degraded=[${d.degraded.join(",")}]]`;
	return `[details surfaceVersion=${d.surfaceVersion} viewVersion=${d.viewVersion ?? "?"} taskId=${d.taskId ?? "?"} revision=${d.revision ?? "?"} execution=${d.execution ?? "?"} settlement=${d.settlement ?? "?"} acceptance=${d.acceptance ?? "?"} 承诺=${d.assurance ?? "?"}${d.receiptRef ? ` receiptRef=${d.receiptRef}` : ""} nextActions=[${d.nextActions.join(",")}] degraded=[${d.degraded.join(",")}]]`;
}

/** ContractError → 结构化错误正文（模型可据 repairExamples 自修后重发）。 */
export function renderContractError(e: Readonly<ContractError>): string {
	const lines = [
		`[ContractError code=${e.code} effects=${e.effects}]`,
		`message: ${e.message}`,
	];
	if (e.fields.length > 0) lines.push(`fields: ${e.fields.join(", ")}`);
	if (e.repairExamples.length > 0) {
		lines.push("repairExamples:");
		for (const ex of e.repairExamples) lines.push(`  - ${JSON.stringify(ex)}`);
	} else {
		lines.push("repairExamples: （本错误无自动修复样例——按 message 修正后重发）");
	}
	return lines.join("\n");
}

/** 失败返回：结构化错误块 + 可选正文附录（引擎失败根因/终稿上下文）。 */
export function contractErrorReturn(
	e: Readonly<ContractError>,
	appendix?: string,
): FacetToolReturn {
	const text = appendix ? `${renderContractError(e)}\n\n${appendix}` : renderContractError(e);
	return {
		content: [{ type: "text", text }],
		isError: true,
		details: { code: e.code, fields: [...e.fields], effects: e.effects, error: e.message },
	};
}

/** 成功返回：details 行（有块时）+ 正文。 */
export function okReturn(body: string, details?: Readonly<ToolDetailsBlock>): FacetToolReturn {
	const text = details ? `${renderDetailsLine(details)}\n\n${body}` : body;
	return { content: [{ type: "text", text }], ...(details ? { details } : {}) };
}

/** 异常兜底：副作用不可确认（unknown），repairExamples 给最小重试/观察路径。 */
export function adaptThrown(e: unknown, context: string): FacetToolReturn {
	const message = e instanceof Error ? e.message : String(e);
	const thrown: ContractError = {
		code: "internal-tool-error",
		message: `[${context}] 工具执行异常（已捕获，未上抛宿主）：${message.slice(0, 400)}`,
		fields: [],
		effects: "unknown",
		repairExamples: [
			{ retry: "同参数重试一次（多为睺时故障）".replace("睺", "瞬") },
			{ retry: "仍失败则先 query_task 观察任务三轴，再决定重发或取消" },
		],
	};
	return contractErrorReturn(thrown);
}

/** 分面 execute 统一异常守卫：正常路径返回原样；抛错转 internal-tool-error（isError=true）。 */
export async function guardedExecute(
	context: string,
	fn: () => Promise<FacetToolReturn>,
): Promise<FacetToolReturn> {
	try {
		return await fn();
	} catch (e) {
		return adaptThrown(e, context);
	}
}

/** 模型面工具注册统一接线（ev-20260920 P1：strict 采样字符串位伪影死锁修复）：宿主在
 *  validateToolArguments **之前**调用 prepareArguments（pi-agent-core prepareToolCall 实证）——在此
 *  剥离序列化伪影（ev-20260919 null 键 + ev-20260920 "null" 字符串，normalizeToolArgumentArtifacts）
 *  再进 schema 校验，枚举位伪影不再结构性拒收（task_control accept 的 mode 等）。已带自有
 *  prepareArguments 的工具链式叠加（伪影剥离在前——结构归一不受伪影干扰）。
 *  约定：本扩展新注册的模型面工具一律经此接线；承载任意业务载荷的工具（如 mcp_call 的
 *  arguments——"null" 可以是合法字段值）不入此通道。 */
export function withArgumentArtifactNormalization<T extends object>(tool: T): T {
	const holder = tool as { prepareArguments?: unknown };
	const own = typeof holder.prepareArguments === "function"
		? (holder.prepareArguments as (args: unknown) => unknown).bind(tool)
		: undefined;
	return {
		...tool,
		prepareArguments: (args: unknown): unknown => {
			const stripped = normalizeToolArgumentArtifacts(args);
			return own ? own(stripped) : stripped;
		},
	} as T;
}
