/** codemode 是现有工具的组合调用方式；没有独立角色/scope 授权，嵌套调用走宿主原工具事件链。 */
import type { ExtensionAPI, ExtensionContext, ToolDefinition } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { ensureControlledCodemodeFactory, registerControlledCodemodeDenyStub } from "./codemode-adapter.ts";
import { enhanceCodemodeErrorResult } from "./codemode-errors.ts";
import { resolveProjectTrusted } from "./trust-context.ts";
import { CODEMODE_USAGE, CODEMODE_EXAMPLE, withCodemodeDefaults, codemodePreferenceLine } from "./codemode-guidance.ts";

export interface CodemodeRuntimeConfig { preference: "auto" | "prefer"; maxOutputTokensPerScript: number; maxTimeoutMsPerScript: number }
export function resolveCodemodeRuntimeConfig(cwd: string, trusted = false): CodemodeRuntimeConfig {
	const sections: Record<string, any>[] = [];
	const agentDir = process.env.PI_CODING_AGENT_DIR ?? path.join(os.homedir(), ".pi", "agent");
	for (const file of [path.join(agentDir, "amagi.json"), ...(trusted ? [path.join(cwd, "amagi.json")] : [])]) {
		try { const c = JSON.parse(fs.readFileSync(file, "utf8")).codemode; if (c && typeof c === "object" && !Array.isArray(c)) sections.push(c); }
		catch { /* lint-exempt:偏好/默认值读取失败不授予能力，也不阻断原工具，使用运行默认值。 */ }
	}
	const out: CodemodeRuntimeConfig = { preference: "auto", maxOutputTokensPerScript: 2000, maxTimeoutMsPerScript: 60000 };
	for (const c of sections) {
		if (c.preference === "auto" || c.preference === "prefer") out.preference = c.preference;
		for (const k of ["maxOutputTokensPerScript", "maxTimeoutMsPerScript"] as const) {
			const n = c.budget?.[k]; if (Number.isSafeInteger(n) && n > 0 && n <= (k === "maxTimeoutMsPerScript" ? 2147483647 : 1000000)) out[k] = n;
		}
	}
	return out;
}

const codemodeParameters = Type.Object({ code: Type.String({ description: "原始 JavaScript。可调用 tools.<工具名>；默认输出和时限自动补齐，也可自行声明 @options。" }) });

export function registerCodemodeRuntime(api: ExtensionAPI): void {
	if (process.env.AMAGI_CODEMODE_DISABLE === "1") { registerControlledCodemodeDenyStub(api, "AMAGI_CODEMODE_DISABLE=1 紧急关闭"); return; }
	let definition: ToolDefinition | undefined;
	const ready = ensureControlledCodemodeFactory().then(factory => {
		if (!factory) return;
		const capture = new Proxy(api, { get(target, key) { if (key === "registerTool") return (d: ToolDefinition) => { definition = d; }; return Reflect.get(target, key, target); } });
		// 只组合已存在的工具；models 不是工具，不在此另外提供模型调用桥。
		(factory({ models: false, mode: "on", inlineBudget: 1600 }) as unknown as (p: ExtensionAPI) => void)(capture);
	});
	const description = `${CODEMODE_USAGE}\n示例为两个独立片段，按需选择，不要整段照抄：\n${CODEMODE_EXAMPLE}`;
	const ownTool: ToolDefinition<typeof codemodeParameters> = { name: "codemode", label: "codemode", exposure: "model-only", defaultActive: true,
		description, promptSnippet: "codemode：用 JavaScript 组合当前已有工具，模型自行选择。",
		// MCP 依此识别脚本入口并在执行前等待惰性工具注册；缺失会误报不可达，且首次调用可能找不到工具。
		// 工厂尚未装配时保守等待全部；就绪后沿用宿主的脚本/命名空间匹配，不另写一套解析器。
		reachesTools: input => definition?.reachesTools?.(input) ?? "all",
		promptGuidelines: [CODEMODE_USAGE], parameters: codemodeParameters,
		prepareLoadout(loadout) {
			const change = definition?.prepareLoadout?.(loadout);
			// 宿主 on 模式会展开其他工具的完整 description；保留其原有 promptSnippet，避免重复注入长说明。
			return { ...change, descriptions: { codemode: `${change?.descriptions?.codemode ?? description}\n${CODEMODE_USAGE}\n两个独立示例：\n${CODEMODE_EXAMPLE}` } };
		},
		async execute(id, params, signal, onUpdate, ctx) {
			await ready;
			if (!definition) return { content: [{ type: "text", text: "当前宿主没有可用 codemode 工厂；直接调用已有工具。" }], details: {}, isError: true };
			const config = resolveCodemodeRuntimeConfig(ctx.cwd, resolveProjectTrusted(ctx));
			let nestedCalls = 0, settledCalls = 0; const started = Date.now();
			const record = (data: Record<string, unknown>) => {
				try { api.appendEntry("amagi-codemode-run", { toolCallId: id, sessionId: ctx.sessionManager.getSessionId(), ...data }); }
				catch { /* lint-exempt:使用观测不作为准入条件，落盘失败不改写已完成工具的执行结果。 */ }
			};
			// 仅观测嵌套调用，不过滤、不直接调用工具实现。参数校验与原任务权限仍由真实 executeTool 裁决。
			const forwarded = Object.create(ctx);
			Object.defineProperty(forwarded, "executeTool", { value: async (...args: Parameters<typeof ctx.executeTool>) => { nestedCalls++; try { return await ctx.executeTool(...args); } finally { settledCalls++; } } });
			record({ phase: "start", started });
			try {
				const result = await definition.execute(id, { ...params, code: withCodemodeDefaults(params.code, config) }, signal, onUpdate, forwarded);
				record({ phase: "end", durationMs: Date.now() - started, nestedCalls, settledCalls, ok: result.isError !== true });
				// ev-20261031-80292c：保留名 SyntaxError 增强（交集空原样返回，纯增强零拒绝）。
				return enhanceCodemodeErrorResult(result, params.code);
			} catch (error) {
				record({ phase: "end", durationMs: Date.now() - started, nestedCalls, settledCalls, ok: false });
				return { content: [{ type: "text", text: error instanceof Error ? error.message : String(error) }], details: {}, isError: true };
			}
		},
	};
	// 宿主内置 builtin:codemode 默认加载（pi ≥1.1）；扩展在装载期注册同名工具会被宿主判定为「替换」，
	// 卸载内置并报 Extension issues 警告。内置可能加载时改为会话绑定后注册：此时宿主不再做替换判定，
	// 工具按扩展顺序 first-wins（包扩展先于追加在末尾的内置），amagi 实现照常生效且无警告。
	// 若最终生效的仍是宿主实例（如 CLI 显式 `-e builtin:codemode` 排在前面），退为沿用宿主实现，
	// 以事件补默认值与观测，不另行阻断。
	let mode: "pending" | "own" | "host" = "pending";
	const registerOwn = (): boolean => {
		try { api.registerTool(ownTool); return true; }
		catch (error) { try { console.error(`[amagi-core] codemode 注册失败：${error instanceof Error ? error.message : String(error)}`); } catch { /* lint-exempt:诊断尽力而为 */ } return false; }
	};
	if (!builtinCodemodeMayLoad(process.cwd(), process.argv)) { mode = "own"; registerOwn(); }
	const ensure = (): void => {
		if (mode !== "pending") return;
		let effective: Array<{ name: string; parameters?: unknown }> = [];
		const readEffective = () => { effective = (api.getAllTools?.() ?? []).filter(t => t.name === "codemode") as typeof effective; };
		try { readEffective(); }
		catch { /* lint-exempt:注册表暂不可读按未判定处理，下一事件再判定。 */ return; }
		if (!effective.some(t => t.parameters === codemodeParameters)) {
			registerOwn();
			try { readEffective(); } catch { /* lint-exempt:读回失败按宿主实例处理，仍补默认值与观测 */ effective = []; }
		}
		if (effective.some(t => t.parameters === codemodeParameters)) { mode = "own"; return; }
		if (effective.length === 0) return;
		mode = "host";
		// 宿主实现默认不激活；会话未显式选择工具集时保持 amagi 默认可用，显式 --tools/--no-tools 按用户选择。
		if (!hasExplicitToolSelection(process.argv)) {
			try { const active = api.getActiveTools(); if (!active.includes("codemode")) api.setActiveTools([...active, "codemode"]); }
			catch { /* lint-exempt:激活失败不影响其他工具，状态行如实报告未启用。 */ }
		}
	};
	const hostRuns = new Map<string, { started: number; nestedCalls: number; settledCalls: number; sessionId?: string }>();
	const recordHost = (toolCallId: string, data: Record<string, unknown>) => {
		try { api.appendEntry("amagi-codemode-run", { toolCallId, ...data }); }
		catch { /* lint-exempt:使用观测不作为准入条件。 */ }
	};
	api.on("session_start", () => { ensure(); });
	api.on("tool_call", (event: any, ctx: ExtensionContext): undefined => {
		if (mode !== "host") return undefined;
		if (event?.toolName === "codemode" && event.input && typeof event.input.code === "string") {
			const config = resolveCodemodeRuntimeConfig(ctx.cwd, resolveProjectTrusted(ctx));
			event.input.code = withCodemodeDefaults(event.input.code, config);
			let sessionId: string | undefined; try { sessionId = ctx.sessionManager.getSessionId(); } catch { /* lint-exempt:观测字段可缺 */ }
			const run = { started: Date.now(), nestedCalls: 0, settledCalls: 0, ...(sessionId ? { sessionId } : {}) };
			hostRuns.set(event.toolCallId, run);
			recordHost(event.toolCallId, { ...(sessionId ? { sessionId } : {}), phase: "start", started: run.started, implementation: "host" });
		} else if (typeof event?.parentToolCallId === "string") {
			const run = hostRuns.get(event.parentToolCallId); if (run) run.nestedCalls++;
		}
		return undefined;
	});
	api.on("tool_result", (event: any): undefined => {
		if (mode !== "host") return undefined;
		if (typeof event?.parentToolCallId === "string") { const run = hostRuns.get(event.parentToolCallId); if (run) run.settledCalls++; return undefined; }
		const run = event?.toolName === "codemode" ? hostRuns.get(event.toolCallId) : undefined;
		if (!run) return undefined;
		hostRuns.delete(event.toolCallId);
		recordHost(event.toolCallId, { ...(run.sessionId ? { sessionId: run.sessionId } : {}), phase: "end", durationMs: Date.now() - run.started, nestedCalls: run.nestedCalls, settledCalls: run.settledCalls, ok: event.isError !== true, implementation: "host" });
		return undefined;
	});
	api.on("before_agent_start", async (event: any, ctx: ExtensionContext): Promise<any> => {
		ensure();
		await ready;
		const config = resolveCodemodeRuntimeConfig(ctx.cwd, resolveProjectTrusted(ctx));
		const active = api.getActiveTools().includes("codemode");
		const available = mode === "host" || definition !== undefined;
		const usage = mode === "host" ? `\n${CODEMODE_USAGE}` : "";
		const line = available && active ? `[amagi codemode 状态] codemode 可用，沿用已有工具权限，无需独立 scope/角色授权。默认 ${config.maxOutputTokensPerScript} tokens/${config.maxTimeoutMsPerScript}ms，可自行声明 @options。\n${codemodePreferenceLine(config.preference)}${usage}` : "[amagi codemode 状态] 当前未启用或宿主不支持；直接调用已有工具。";
		const sections = event.systemPromptOptions?.sections;
		if (sections) { sections.amagi_codemode_face = line; return undefined; }
		return { systemPrompt: `${event.systemPrompt}\n\n${line}` };
	});
}

/** 会话是否由命令行显式选择了工具集（此时不替用户激活宿主 codemode）。 */
export function hasExplicitToolSelection(argv: readonly string[]): boolean {
	return argv.some(a => a === "--tools" || a === "-t" || a.startsWith("--tools=") || a === "--no-tools" || a === "--no-builtin-tools");
}

function extensionEntries(file: string): string[] {
	try { const v = JSON.parse(fs.readFileSync(file, "utf8"))?.extensions; return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []; }
	catch { /* lint-exempt:设置缺失或不可解析按未声明处理（保守视为内置可能加载，改走绑定后注册）。 */ return []; }
}
function builtinOverride(entries: readonly string[]): boolean | undefined {
	let out: boolean | undefined;
	for (const e of entries) {
		if (e === "+builtin:codemode") out = true;
		else if (e === "-builtin:codemode" || e === "!builtin:codemode") out = false;
	}
	return out;
}
/** 装载期判定宿主内置 codemode 是否可能加载。只有确定不会加载时才在装载期注册（与旧行为一致）；
 * 不确定一律按「可能加载」走绑定后注册——两条路径最终都由 amagi 实现生效，判定误差只影响注册时点。 */
export function builtinCodemodeMayLoad(cwd: string, argv: readonly string[], agentDir = process.env.PI_CODING_AGENT_DIR ?? path.join(os.homedir(), ".pi", "agent")): boolean {
	for (let i = 0; i < argv.length - 1; i++) if ((argv[i] === "-e" || argv[i] === "--extension") && argv[i + 1] === "builtin:codemode") return true;
	if (argv.includes("--no-extensions") || argv.includes("-ne")) return false;
	const project = builtinOverride(extensionEntries(path.join(cwd, ".pi", "settings.json")));
	if (project !== undefined) return project;
	return builtinOverride(extensionEntries(path.join(agentDir, "settings.json"))) ?? true;
}
