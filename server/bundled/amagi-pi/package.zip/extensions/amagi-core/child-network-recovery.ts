/** 子端在原生重试耗尽后原会话续跑；不重派任务、不重放工具、不改写原始历史。 */
import { setTimeout as sleep } from "node:timers/promises";
import type { ExtensionAPI, SessionBoundaryDraft } from "@earendil-works/pi-coding-agent";
import { capabilityEnabledByVersion, detectHostPackageVersion } from "./host-capabilities.ts";
import { implicitRetryApplicable, isAutoRetryEnabled, isContentPolicyRejection, isRateLimitSignal } from "./reliability.ts";

export const CHILD_NETWORK_RECOVERY_WINDOW_MS = 120_000;
export const CHILD_NETWORK_RECOVERY_DELAYS_MS = [5_000, 15_000, 30_000] as const;

let recoverySnapshot: { attempts: number; max: number; windowMs: number } | undefined;
/** Snapshot of this process's active child recovery budget; absent if not registered. */
export function networkRecoveryState(): Readonly<{ attempts: number; max: number; windowMs: number }> | undefined {
	return recoverySnapshot && { ...recoverySnapshot };
}

/** 明确的确定性拒绝优先于错误正文内偶然出现的 timeout/5xx。 */
export function isRecoverableChildNetworkError(message?: string): boolean {
	return !!message && !isContentPolicyRejection(message) && !isRateLimitSignal(message)
		&& !/\b(?:400|401|403|404|422)\b|unauthorized|forbidden|invalid.?api.?key|authentication|permission denied|quota|insufficient.credit|context.{0,20}(?:length|limit|exceed)|token limit|abort|cancel/i.test(message)
		&& (implicitRetryApplicable(message) || /\b(?:500|502|503|504|520|521|522|523|524|529)\b|\b(?:EPIPE|ENETUNREACH|EHOSTUNREACH|UND_ERR_SOCKET|UND_ERR_CONNECT_TIMEOUT|UND_ERR_HEADERS_TIMEOUT|UND_ERR_BODY_TIMEOUT)\b|error decoding response body|premature (?:close|end)|connection (?:reset|closed unexpectedly)/i.test(message));
}

export interface ChildNetworkRecoveryDeps {
	version?: string | null;
	now?: () => number;
	windowMs?: number;
	delaysMs?: readonly number[];
}

export function registerChildNetworkRecovery(pi: ExtensionAPI, deps: ChildNetworkRecoveryDeps = {}): void {
	if (!capabilityEnabledByVersion("agentBeforeSettleBoundary", deps.version === undefined ? detectHostPackageVersion() : deps.version)) return;
	const now = deps.now ?? Date.now;
	const windowMs = deps.windowMs ?? CHILD_NETWORK_RECOVERY_WINDOW_MS;
	const delays = deps.delaysMs ?? CHILD_NETWORK_RECOVERY_DELAYS_MS;
	let firstFailureAt: number | undefined;
	let attempts = 0;
	let lastError: string | undefined;
	let pendingDelay: number | undefined;
	let waiting: AbortController | undefined;
	const publish = () => { recoverySnapshot = { attempts, max: delays.length, windowMs }; };
	publish();
	const reset = () => {
		waiting?.abort(); waiting = undefined;
		firstFailureAt = undefined; attempts = 0; lastError = undefined; pendingDelay = undefined;
		publish();
	};
	pi.on("session_start", reset);
	pi.on("session_shutdown", reset);
	pi.on("before_agent_start", reset); // 新 prompt（包括 RPC worker 复用）独立预算。
	pi.on("message_end", (event) => {
		if (event.message.role !== "assistant") return;
		if (event.message.stopReason !== "error") { reset(); return; }
		lastError = event.message.errorMessage;
		// 从第一条错误起计时，原生自动重试耗时也计入窗口。
		firstFailureAt ??= now();
	});
	pi.on("agent_before_settle", (event, ctx) => {
		if (!isAutoRetryEnabled() || event.outcome !== "error" || event.continue || ctx.hasPendingMessages()
			|| !isRecoverableChildNetworkError(lastError) || firstFailureAt === undefined) return;
		const delay = delays[attempts];
		if (delay === undefined || now() - firstFailureAt + delay >= windowMs) return;
		// 只排除当前可见的失败 assistant；原始消息与既有工具调用/结果均留在历史。
		const tail = event.context.contextEntries.findLast(entry => entry.messages.length > 0);
		const message = tail?.messages.at(-1);
		if (!tail || message?.role !== "assistant" || message.stopReason !== "error" || message.errorMessage !== lastError) return;
		const entries: SessionBoundaryDraft[] = [...event.entries,
			{ type: "context_edit", targetId: tail.sourceEntry.id, replacement: null },
			{ type: "custom", customType: "amagi:network-recovery", data: { attempt: attempts + 1, delayMs: delay, elapsedMs: now() - firstFailureAt } },
		];
		attempts++;
		publish();
		pendingDelay = delay;
		return { entries, continue: true };
	});
	// 在下一轮已建立 abort signal 后等待；不要在不可中断的结算边界里 sleep。
	pi.on("turn_start", async (_event, ctx) => {
		if (pendingDelay === undefined) return;
		const delay = pendingDelay; pendingDelay = undefined;
		const controller = new AbortController(); waiting = controller;
		const signal = ctx.signal;
		const abort = () => controller.abort();
		if (signal?.aborted) abort(); else signal?.addEventListener("abort", abort, { once: true });
		try { await sleep(delay, undefined, { signal: controller.signal }); }
		catch (error) { if (!controller.signal.aborted) throw error; }
		finally { signal?.removeEventListener("abort", abort); if (waiting === controller) waiting = undefined; }
	});
}
