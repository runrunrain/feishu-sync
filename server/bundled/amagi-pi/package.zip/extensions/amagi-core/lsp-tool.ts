/**
 * lsp-tool.ts — 单工具 `lsp`：LSP 能力的 LLM 入口（B1 装配批）。
 *
 * 动态启用：首次调用 detectLspServers(cwd) 一次并缓存（rootMarkers ∩ cwd + 二进制可解析），
 * 检测为空时所有 action 返回可用性提示而非报错；语言服务器懒 spawn（首次真实请求才起进程），
 * 由 LspClientPool 空闲回收。rename 默认 preview，apply:true 才写盘；readOnly 拒绝写。
 *
 * symbol 选择器：读文件内容按行匹配 —— "foo"（含 foo 的第一行）→ 大小写不敏感 →
 * "foo#2"（含 foo 的第 2 行）→ 无 symbol 用 line 首个非空白字符。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { StringEnum } from "@earendil-works/pi-ai";
import { Type } from "typebox";
import { LspClientPool, type LspDiagnostic } from "./lsp-client.ts";
import { detectLspServers, resolveLspRuntimeConfig, routeFileToServers, builtinServerDefs, binaryResolvable, rootMarkerHit } from "./lsp-config.ts";
import { filterEnvironmentNoise, hasCppCompileDatabaseInDir } from "./lsp-diagnostics.ts";
import {
	LSP_SEVERITY_LABELS,
	LspOutputSchema,
	hoverBodyOf,
	toLspCapabilitiesWire,
	toLspDiagnosticsWire,
	toLspErrorWire,
	toLspHoverWire,
	toLspLocationsWire,
	toLspRenameWire,
	toLspStatusWire,
	toLspSymbolsWire,
	type LspLocationAction,
	type LspRenameTargetSource,
	type LspStatusSource,
	type LspWireErrorCode,
	type LspWireOutput,
	classifyLspWireError,
} from "./lsp-wire.ts";
import type { DetectedLspServer, LspRuntimeConfig } from "./lsp-types.ts";
import { LSP_CAPABILITIES, type LspCapability, type PathRule } from "./contracts/permission.ts";
import { matchPathRule } from "./task-permission.ts";


// 2026-08-16 复盘 P3-7：LSP doctor 安装指引——大仓类型反馈前置（实战：子 Agent 手改类型错到验证
// 阶段才暴露；lsp 空检测时只报「0 个」不可操作）。安装命令均真实可执行；status/错误文案共用。
const LSP_INSTALL_GUIDE: Record<string, string> = {
	"typescript-language-server": "npm i -g typescript-language-server typescript",
	pyright: "npm i -g pyright（或 pipx install pyright）",
	gopls: "go install golang.org/x/tools/gopls@latest",
	"rust-analyzer": "rustup component add rust-analyzer",
	clangd: "brew install clangd",
	"lua-language-server": "brew install lua-language-server",
	"bash-language-server": "npm i -g bash-language-server",
	marksman: "brew install marksman",
};

/** 按项目根文件推测语言对应的候选服务器（有界扫描：根目录直接条目，不递归）。 */
function projectLanguageCandidates(cwd: string): string[] {
	let entries: string[];
	try { entries = fs.readdirSync(cwd); } catch { return []; }
	const top = new Set(entries.slice(0, 500).map((e) => e.toLowerCase()));
	const has = (re: RegExp) => [...top].some((e) => re.test(e));
	const hints: string[] = [];
	if (has(/^package\.json$|^tsconfig\.json$|^jsconfig\.json$|\.tsx?$|\.jsx?$|\.mjs$/)) hints.push("typescript-language-server");
	if (has(/^pyproject\.toml$|^requirements\.txt$|^setup\.py$|^setup\.cfg$|\.py$|^\.pyi$/)) hints.push("pyright");
	if (has(/^go\.(mod|work)$/)) hints.push("gopls");
	if (has(/^cargo\.toml$/)) hints.push("rust-analyzer");
	if (has(/^cmakelists\.txt$|^compile_commands\.json$|^compile_flags\.txt$|\.cpp$|\.c$|\.hpp$/)) hints.push("clangd");
	if (has(/^\.luarc\.json(c)?$|^\.luacheckrc$/)) hints.push("lua-language-server");
	if (has(/^\.shellcheckrc$|\.sh$|^\.bash$/)) hints.push("bash-language-server");
	if (has(/^\.marksman\.toml$/)) hints.push("marksman");
	return hints;
}

export interface LspToolOptions {
	cwd?: string;
	/** 测试注入共享池；缺省内部懒建。 */
	pool?: LspClientPool;
	/** 测试注入配置加载。 */
	loadConfig?: (cwd: string) => LspRuntimeConfig;
	/** 测试注入检测。 */
	detect?: (cwd: string, config: LspRuntimeConfig) => DetectedLspServer[];
	/** 单请求超时（ms）；缺省 15s。 */
	requestTimeoutMs?: number;
	/** 角色级强制只读（如 baize 纯只读角色，审核 Major-1）；优先于配置。 */
	readOnlyOverride?: boolean;
	/** v2 P3（方案 §5.2 LSP 行）：LSP 能力执法面（注入后生效；P4 接线点——子进程从
	 *  spec.permission.lsp/write/deny 构造，主进程从用户/角色名单）。未注入=legacy 行为不变。 */
	permission?: LspPermission;
}

/** LSP 能力执法面：能力名单（契约枚举五项）+ rename 应用写盘的目标授权（P1 冻结 PathRule）。 */
export interface LspPermission {
	/** 授权能力名单（contracts/permission.ts LSP_CAPABILITIES 子集；非法名忽略——fail-closed 不放大）。 */
	lsp: readonly LspCapability[];
	/** rename 应用写盘的目标授权（P1 冻结 PathRule）；未提供=无写面——rename apply 一律拒绝。 */
	writeRules?: readonly PathRule[];
	/** 禁入面（P1 冻结 PathRule；WorkspaceEdit 目标命中即整单拒绝，恒优先于写授权）。 */
	denyRules?: readonly PathRule[];
}

/** LSP 动作 → 契约能力映射（契约枚举五项：diagnostics/definition/references/hover/rename）：
 *  type_definition/implementation 属定义族（契约无独立项）；symbols 为只读检视面就近映射 hover；
 *  status/capabilities 为元信息面（可用性/doctor 诊断），不设能力卡。 */
export const LSP_ACTION_CAPABILITY: Readonly<Record<string, LspCapability | "metadata">> = {
	status: "metadata",
	capabilities: "metadata",
	diagnostics: "diagnostics",
	definition: "definition",
	type_definition: "definition",
	implementation: "definition",
	references: "references",
	hover: "hover",
	symbols: "hover",
	rename: "rename",
};

// ── v2 P3（§8.3-P3）：缺必要服务派发前给具体缺项（不静默空名单）──

export interface LspRequirementGap {
	capability: LspCapability;
	/** 具体缺项说明（含任务要求的能力与实际不可用原因）。 */
	reason: string;
}

/** 检查任务声明的 LSP 能力 vs 配置/检测可用性：LSP 未启用/只读配置/零检测服务器为具体缺项。
 *  纯静态检查（不 spawn 语言服务器）；P4 接线点：dispatch-preflight 派发前用冻结 grant.lsp 调用。 */
export function findLspRequirementGaps(
	cwd: string,
	required: readonly LspCapability[],
	hooks: { loadConfig?: (cwd: string) => LspRuntimeConfig; detect?: (cwd: string, config: LspRuntimeConfig) => DetectedLspServer[] } = {},
): LspRequirementGap[] {
	const gaps: LspRequirementGap[] = [];
	const wanted = (Array.isArray(required) ? required : []).filter((c) => LSP_CAPABILITIES.includes(c as LspCapability)) as LspCapability[];
	if (wanted.length === 0) return gaps;
	const cfg = hooks.loadConfig ? hooks.loadConfig(cwd) : resolveLspRuntimeConfig(cwd);
	if (!cfg.enabled) {
		return wanted.map((c) => ({ capability: c, reason: `任务要求 lsp:${c}，但 LSP 通道未启用（amagi.json lsp.enabled=false）` }));
	}
	if (cfg.readOnly && wanted.includes("rename")) {
		gaps.push({ capability: "rename", reason: "任务要求 lsp:rename，但 LSP 只读配置生效（lsp.readOnly=true）——rename 无法应用" });
	}
	const detectedServers = hooks.detect ? hooks.detect(cwd, cfg) : detectLspServers(cwd, cfg);
	if (detectedServers.length === 0) {
		for (const c of wanted) {
			if (c === "rename" && cfg.readOnly) continue; // 已有更具体缺项
			gaps.push({ capability: c, reason: `任务要求 lsp:${c}，但项目未检测到可用的语言服务器（0 个；可用 lsp status 查看候选与安装指引）` });
		}
	}
	return gaps;
}

/** P6 双载体（寄生增强方案 §9 P6 行）：ok/err 正文契约字节不变，只加 structuredContent 新键
 *  （旧消费者面零变化）；wire 投影单源在 lsp-wire.ts，错误文案两载体同文（wire 内过同源脱敏）。 */
function ok(text: string, wire: LspWireOutput) {
	return { content: [{ type: "text" as const, text }], structuredContent: wire };
}
function err(action: unknown, code: LspWireErrorCode, text: string) {
	return { content: [{ type: "text" as const, text }], isError: true as const, structuredContent: toLspErrorWire(action, code, text) };
}

const SEVERITY_LABEL = LSP_SEVERITY_LABELS; // P6：severity 标签与 lsp-wire severityLabel 同源（正文/wire 单一来源）

function formatDiagnostics(file: string, diags: LspDiagnostic[]): string {
	if (diags.length === 0) return `${file}: 0 条诊断`;
	const lines = diags.map((d) => {
		const sev = SEVERITY_LABEL[d.severity ?? 1] ?? "?";
		const pos = `${(d.range?.start?.line ?? 0) + 1}:${(d.range?.start?.character ?? 0) + 1}`;
		const code = d.code !== undefined ? ` [${String(d.code)}]` : "";
		return `  ${sev} ${pos}${code} ${d.message}${d.source ? ` (${d.source})` : ""}`;
	});
	return `${file}: ${diags.length} 条诊断\n${lines.join("\n")}`;
}

interface LspLocationLike { uri?: string; targetUri?: string; range?: { start?: { line?: number; character?: number }; end?: { line?: number; character?: number } }; targetRange?: { start?: { line?: number; character?: number }; end?: { line?: number; character?: number } } }

function formatLocations(result: unknown): string {
	const arr = Array.isArray(result) ? result : result ? [result] : [];
	const locs = (arr as LspLocationLike[]).filter((l) => l && (l.uri || l.targetUri));
	const items = locs.map((l) => {
		const uri = l.uri ?? l.targetUri ?? "";
		const file = (() => { const p = uriToPath(uri); return p ?? uri; })();
		const r = l.range ?? l.targetRange;
		const pos = r?.start ? `${(r.start.line ?? 0) + 1}:${(r.start.character ?? 0) + 1}` : "?";
		return `  ${file}:${pos}`;
	});
	return items.length > 0 ? items.join("\n") : "(无结果)";
}

function uriToPath(uri: string): string | null {
	// v1.5.220 审核修复（Major-3）：fileURLToPath 正确解码 %20/%E4 等百分号编码（空格/CJK 路径）；拒绝非 file URI
	if (!uri.startsWith("file:")) return null;
	try { return fileURLToPath(uri); } catch { return null; }
}

interface RenameEdit { range: { start: { line: number; character: number }; end: { line: number; character: number } }; newText: string }

/** 校验 range 合法（边界内、start<=end、同文件互不重叠）并返回编辑后全文；任一非法抛错（审核 Major-2）。 */
function applyTextEdits(original: string, edits: RenameEdit[]): string {
	const lines = original.split("\n");
	const sorted = [...edits].sort((a, b) => (a.range.start.line - b.range.start.line) || (a.range.start.character - b.range.start.character));
	let prevEnd: { line: number; character: number } | null = null;
	for (const e of sorted) {
		const s = e.range?.start, t = e.range?.end;
		if (!s || !t) throw new Error("rename range 缺失");
		if (typeof e.newText !== "string") throw new Error("rename newText 非字符串（结构非法）");
		for (const p of [s, t]) {
			if (!Number.isInteger(p.line) || !Number.isInteger(p.character) || p.line < 0 || p.character < 0) throw new Error(`rename range 非法 (${p.line}:${p.character})`);
			if (p.line >= lines.length) throw new Error(`rename range 越界：line ${p.line} >= 文件行数 ${lines.length}`);
			if (p.character > (lines[p.line]?.length ?? 0)) throw new Error(`rename range 越界：line ${p.line} 字符 ${p.character} 超出行长`);
		}
		if (s.line > t.line || (s.line === t.line && s.character > t.character)) throw new Error("rename range start > end");
		if (prevEnd && (s.line < prevEnd.line || (s.line === prevEnd.line && s.character < prevEnd.character))) throw new Error("rename range 重叠");
		prevEnd = t;
	}
	for (let i = sorted.length - 1; i >= 0; i--) {
		const e = sorted[i];
		const s = e.range.start, t = e.range.end;
		const startLine = lines[s.line] ?? "";
		const endLine = lines[t.line] ?? "";
		const merged = startLine.slice(0, s.character) + e.newText + endLine.slice(t.character);
		lines.splice(s.line, t.line - s.line + 1, merged);
	}
	return lines.join("\n");
}

/** symbol → {line, character}：#N 第 N 个出现（1 基），先精确后大小写不敏感；行内取 symbol 首现位。 */
function resolvePosition(text: string, line: number | undefined, symbol: string | undefined): { line: number; character: number } {
	if (!symbol) {
		const ln = Math.max(0, line ?? 0);
		const lines = text.split("\n");
		const content = lines[ln] ?? "";
		const m = /\S/.exec(content);
		return { line: ln, character: m ? m.index : 0 };
	}
	const hashIdx = symbol.lastIndexOf("#");
	let base = symbol, occurrence = 1;
	if (hashIdx > 0 && /^#(\d+)$/.test(symbol.slice(hashIdx))) {
		base = symbol.slice(0, hashIdx);
		occurrence = Math.max(1, Number(symbol.slice(hashIdx + 1)));
	}
	const lines = text.split("\n");
	const tryMatch = (needle: string): number[] => {
		const hits: number[] = [];
		for (let i = 0; i < lines.length; i++) if (lines[i].includes(needle)) hits.push(i);
		return hits;
	};
	let hits = tryMatch(base);
	if (hits.length === 0) {
		const lower = base.toLowerCase();
		hits = [];
		for (let i = 0; i < lines.length; i++) if (lines[i].toLowerCase().includes(lower)) hits.push(i);
	}
	const ln = hits[Math.min(occurrence - 1, hits.length - 1)] ?? 0;
	const col = Math.max(0, lines[ln]?.indexOf(base) ?? 0);
	return { line: ln, character: col };
}

export function createLspTool(options: LspConfigHooksPlus = {}) {
	const cwd = options.cwd ?? process.cwd();
	// v2 P3（§5.2 LSP 行）：能力执法面——非法能力名丢弃（fail-closed 不放大），status/capabilities 元信息面免卡。
	const grantedCaps = new Set<LspCapability>((options.permission?.lsp ?? []).filter((c) => LSP_CAPABILITIES.includes(c as LspCapability)) as LspCapability[]);
	// v1.5.220 审核修复（Major-1）：工作区边界（realpath 含 symlink escape；目标不存在时以父目录 realpath + basename 判定）
	const rootReal = (() => { try { return fs.realpathSync(cwd); } catch { return cwd; } })();
	const withinWorkspace = (target: string): boolean => {
		let real: string;
		try { real = fs.realpathSync(target); } catch {
			try { real = path.join(fs.realpathSync(path.dirname(target)), path.basename(target)); } catch { return false; }
		}
		const rel = path.relative(rootReal, real);
		return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
	};
	let pool = options.pool;
	let detectedCache: DetectedLspServer[] | null = null;
	let configCache: LspRuntimeConfig | null = null;

	const getConfig = (): LspRuntimeConfig => {
		if (!configCache) {
			configCache = options.loadConfig ? options.loadConfig(cwd) : resolveLspRuntimeConfig(cwd);
			if (options.readOnlyOverride === true) configCache = { ...configCache, readOnly: true };
		}
		return configCache;
	};
	const detected = (): DetectedLspServer[] => {
		if (!detectedCache) {
			const cfg = getConfig();
			detectedCache = options.detect ? options.detect(cwd, cfg) : detectLspServers(cwd, cfg);
		}
		return detectedCache;
	};
	const ensurePool = (): LspClientPool => {
		if (!pool) {
			const cfg = getConfig();
			pool = new LspClientPool({ cwd, idleTimeoutMs: cfg.idleTimeoutMs, ...(options.requestTimeoutMs ? { requestTimeoutMs: options.requestTimeoutMs } : {}) });
		}
		return pool;
	};
	/** 检测结果 → spawn 定义：池 spawn 用 def.command，故用已解析 commandPath 覆盖。 */
	const spawnDef = (d: DetectedLspServer): DetectedLspServer => ({ ...d, command: d.commandPath || d.command });
	const clientForFile = async (file: string) => {
		const routed = routeFileToServers(file, detected());
		if (routed.length === 0) {
			const names = detected().map((d) => `${d.name}(${(d.fileTypes ?? []).join("/")})`).join(", ") || "无";
			return { error: `文件 "${file}" 不匹配任何已启用的语言服务器。可用: ${names}。可先 lsp({action:"status"}) 查看。` };
		}
		const def = routed[0] as DetectedLspServer;
		return { client: await ensurePool().getOrCreate(spawnDef(def)) };
	};

	const description = `LSP 语言服务器查询：按当前项目语言动态启用（检测 rootMarkers + 服务器二进制）。action：status（服务器列表/实例状态）| capabilities | diagnostics（file 的诊断）| definition | type_definition | implementation | references | hover | symbols | rename。file 相对当前项目根；position 由 line（0 基，缺省 0）+ symbol 决定——symbol 为文件内符号文本，支持 #N 第 N 个出现（如 "foo#2"），无 symbol 用 line 首个非空白字符。rename 需 newName，默认 preview 返回编辑摘要，apply:true 才写盘（readOnly 配置时拒绝）。${options.permission ? `任务权限过滤已启用：授权能力 [${[...grantedCaps].join("/") || "无"}]，未授权 action 将被拒绝。` : ""}`;

	const tool = {
		name: "lsp",
		label: "LSP",
		description,
		promptSnippet: `lsp({ action: "diagnostics", file: "src/a.ts" })`,
		parameters: Type.Object({
			action: StringEnum(["status", "capabilities", "diagnostics", "definition", "type_definition", "implementation", "references", "hover", "symbols", "rename"]),
			file: Type.Optional(Type.String({ description: "相对项目根的文件路径（status 可省；单服务器场景其余 action 可省略自动选用）" })),
			line: Type.Optional(Type.Number({ description: "0 基行号（缺省 0）" })),
			symbol: Type.Optional(Type.String({ description: '符号选择器：文件内文本，支持 "#N" 第 N 个出现' })),
			newName: Type.Optional(Type.String({ description: "rename 新名（rename 必填）" })),
			apply: Type.Optional(Type.Boolean({ description: "rename 默认 preview；true 才写盘" })),
		}),
		/** P6（寄生增强方案 §9 P6 行）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema：TSchema）。
		 *  声明后 execute 成功/失败均携 structuredContent（十一封闭分支 Union：十 action 成功形状 +
		 *  error Failure）；消费者判据 kind/wireVersion/action/ok/schemaVersion。正文 content 契约字节
		 *  不变；rename preview/apply 权限校验路径零变化（wire 只投影既有出口，不新增成功捷径）。 */
		outputSchema: LspOutputSchema,
		async execute(_id: string, params: Record<string, unknown>) {
			try {
				const action = String(params.action ?? "");
			const file = typeof params.file === "string" ? params.file : undefined;
			const detectedList = detected();
			const cfg = getConfig();
			const ACTIONS = ["status", "capabilities", "diagnostics", "definition", "type_definition", "implementation", "references", "hover", "symbols", "rename"];
			if (!ACTIONS.includes(action)) return err(action, "shape", `未知 action: "${action}"。可用: ${ACTIONS.join(" | ")}`);

			// v2 P3（§5.2 LSP 行）：操作入口校验能力名单——零副作用拒绝（不 detect、不 spawn）；
			// 只读默认拒绝 rename（名单无 rename 即拒，含 preview）。
			const requiredCap = LSP_ACTION_CAPABILITY[action];
			if (options.permission && requiredCap && requiredCap !== "metadata" && !grantedCaps.has(requiredCap)) {
				return err(action, "permission", `lsp 权限拒绝：action "${action}" 需要能力 "${requiredCap}"，任务授权的 LSP 能力：${[...grantedCaps].join(", ") || "（空）"}（只读默认拒绝 rename；能力名单由任务授权冻结）`);
			}

				if (action === "status") {
					const statusAll = ensurePool().statusAll();
					const instances = statusAll.map((s) => `  · ${s.name} pid=${s.pid ?? "-"} alive=${s.alive} initialized=${s.initialized} openFiles=${s.openFiles} diagFiles=${s.diagnosticFiles}`);
					const lines = detectedList.map((d) => `  · ${d.name} [${(d.fileTypes ?? []).join(" ")}] → ${d.commandPath}`);
					// 2026-08-16 复盘 P3-7：status 尾部 doctor 段——语言命中但二进制未装的内置服务器给安装命令，
					// 把「为什么我的项目没有 lsp」变成可操作信息（rootMarker 命中为准，与 detect 同口径）。
					const doctorEntries: Array<{ name: string; rootMarker: string | null; installCommand: string }> = [];
					try {
						for (const [name, def] of Object.entries(builtinServerDefs())) {
							if (detectedList.some((d) => d.name === name)) continue;
							if (!def.command || def.disabled) continue;
							if (!rootMarkerHit(cwd, def.rootMarkers)) continue;
							if (binaryResolvable(def.command, cwd)) continue; // 已装但被关闭——属配置问题，doctor 段不重复报
							doctorEntries.push({ name, rootMarker: def.rootMarkers?.[0] ?? null, installCommand: LSP_INSTALL_GUIDE[name] ?? `安装 ${def.command}` });
						}
					} catch { /* best-effort */ }
					const doctorLines = doctorEntries.map((e) => `  · ${e.name}（项目命中 ${e.rootMarker ?? "rootMarker"} 但未装）→ ${e.installCommand}`);
					// ev-20261007：clangd 已启用但项目无编译数据库——include 类诊断将按环境噪音抑制
					//（UE/UBT 等工程典型；提前告知比事后大量误报可解释性好）。
					const envNoise = detectedList.some((d) => d.name === "clangd") && !hasCppCompileDatabaseInDir(cwd);
					const statusText = `LSP 可用服务器（${detectedList.length}，enabled=${cfg.enabled} autoDetect=${cfg.autoDetect} readOnly=${cfg.readOnly}）：\n${lines.join("\n") || "  (无——项目未命中任何语言标记或服务器二进制不可用)"}\n运行中实例：\n${instances.join("\n") || "  (无)"}${doctorLines.length ? `\n[doctor] 以下服务器命中本项目语言但二进制未装（装后重启会话生效）：\n${doctorLines.join("\n")}` : ""}${envNoise ? `\n[环境提示] clangd 已启用但项目未发现编译数据库（compile_commands.json / compile_flags.txt / .clangd）——include 未找到类诊断将按环境噪音抑制（UE/UBT 等工程典型；生成编译数据库或配置 .clangd 可恢复透传）。` : ""}`;
					return ok(statusText, toLspStatusWire({ enabled: cfg.enabled, autoDetect: cfg.autoDetect, readOnly: cfg.readOnly, servers: detectedList, instances: statusAll, doctor: doctorEntries } satisfies LspStatusSource));
				}
				if (detectedList.length === 0) {
					// 2026-08-16 复盘 P3-7：空检测给可操作指引（rootMarkers 摘要 + 按语言推测的安装命令 + 配置入口）。
					const cands = projectLanguageCandidates(cwd);
					const installLines = (cands.length ? cands : Object.keys(LSP_INSTALL_GUIDE).slice(0, 3)).map((n) => `  · ${n} → ${LSP_INSTALL_GUIDE[n] ?? "见官方文档"}`);
					return err(action, "unavailable", `当前项目未检测到可用的语言服务器（0 个）。常见原因与修复：\n  1) 二进制未装（按项目语言推测的候选）：\n${installLines.join("\n")}\n  2) 项目根未命中 rootMarkers（检测覆盖 cwd 根 + 一级子目录 + 向上至 .git 边界；均未命中时为 0）：内置标记摘要——TS/JS: package.json|tsconfig.json；Python: pyproject.toml|requirements.txt；Go: go.mod；Rust: Cargo.toml；C/C++: compile_commands.json|CMakeLists.txt\n  3) 配置问题：lsp.enabled=false 或 amagi.json lsp.servers 覆盖错误（可用 lsp({action:"status"}) 查看合并后配置，amagi.json lsp.servers 可自定义 command/args/rootMarkers）。`);
				}

				// 其余 action 需要文件；未给且恰好一个服务器时允许隐式（capabilities 场景）——但没有文件无法定位，仅 capabilities 支持
				let absFile: string | undefined;
				if (file) {
					absFile = path.isAbsolute(file) ? file : path.resolve(cwd, file);
					if (!fs.existsSync(absFile)) return err(action, "shape", `文件不存在: ${file}`);
					if (!withinWorkspace(absFile)) return err(action, "permission", `文件在工作区外: ${file}（lsp 仅限当前项目根内）`);
				} else if (detectedList.length === 1 && action === "capabilities") {
					absFile = undefined;
				} else {
					return err(action, "shape", `action "${action}" 需要 file（相对项目根）。`);
				}

				if (action === "capabilities") {
					let client;
					if (absFile) {
					const r = await clientForFile(absFile);
						if (r.error) return err(action, "unavailable", r.error);
						client = r.client!;
					} else {
						client = await ensurePool().getOrCreate(spawnDef(detectedList[0]));
					}
					return ok(`${client.definition.name} capabilities:\n${JSON.stringify(client.serverCapabilities, null, 2)}`, toLspCapabilitiesWire(client.definition.name, client.serverCapabilities));
				}

				// 文件型 action
				if (!absFile) return err(action, "shape", `action "${action}" 需要 file。`);
				const rel = path.relative(cwd, absFile) || absFile;
				const r = await clientForFile(absFile);
				if (r.error) return err(action, "unavailable", r.error);
				const client = r.client!;
				const text = fs.readFileSync(absFile, "utf8");
				client.ensureOpenFile(absFile, text);
				const pos = resolvePosition(text, typeof params.line === "number" ? params.line : undefined, typeof params.symbol === "string" ? params.symbol : undefined);
				const uri = pathToFileURL(absFile).href;
				const td = { textDocument: { uri }, position: { line: pos.line, character: pos.character } };

				switch (action) {
					case "diagnostics": {
						const raw = await client.waitForDiagnostics(absFile);
						// ev-20261007：环境噪音降噪（clangd 无编译数据库的 include 误报）——过滤后透传，
						// 抑制发生时披露一行原因（拉取面显式查询，须知道有过滤与如何消除，不静默）。
						const { kept, note } = filterEnvironmentNoise(client.definition.name, absFile, raw);
						return ok(formatDiagnostics(rel, kept) + note, toLspDiagnosticsWire(rel, kept));
					}
					case "definition":
					case "type_definition":
					case "implementation":
					case "references": {
						const method = action === "definition" ? "textDocument/definition"
							: action === "type_definition" ? "textDocument/typeDefinition"
							: action === "implementation" ? "textDocument/implementation"
							: "textDocument/references";
						const result = await client.request(method, action === "references" ? { ...td, context: { includeDeclaration: true } } : td);
						return ok(`${action} "${rel}" @ ${pos.line + 1}:${pos.character + 1}:\n${formatLocations(result)}`, toLspLocationsWire(action as LspLocationAction, { file: rel, position: pos }, result));
					}
					case "hover": {
						const hover = await client.request("textDocument/hover", td);
						// P6：hover 正文提取与 wire 投影同源（lsp-wire hoverBodyOf 单源，不做第二套提取）
						const { present, body } = hoverBodyOf(hover);
						if (!present) return ok(`hover "${rel}" @ ${pos.line + 1}:${pos.character + 1}: (无 hover 内容)`, toLspHoverWire({ file: rel, position: pos }, null));
						return ok(`hover "${rel}" @ ${pos.line + 1}:${pos.character + 1}:\n${body}`, toLspHoverWire({ file: rel, position: pos }, hover));
					}
					case "symbols": {
						const symbols = await client.request("textDocument/documentSymbol", { textDocument: { uri } });
						return ok(`symbols "${rel}":\n${JSON.stringify(symbols, null, 2)}`, toLspSymbolsWire(rel, symbols));
					}
					case "rename": {
						if (typeof params.newName !== "string" || params.newName.length === 0) return err(action, "shape", "rename 需要 newName。");
						if (cfg.readOnly) return err(action, "permission", "rename 被拒绝（只读模式：lsp.readOnly=true 或只读角色强制）；可先用 references 列出全部引用位置，由有写权限的一方用 edit 逐处修改。");
						if (!client.serverCapabilities.renameProvider) return err(action, "unavailable", `服务器 ${client.definition.name} 未声明 renameProvider 能力。`);
						const edit = await client.request("textDocument/rename", { ...td, newName: params.newName });
						if (!edit) return ok(`rename "${rel}" → "${params.newName}": 无可应用编辑（未找到符号）。`, toLspRenameWire(rel, params.newName, "preview", "none", [], null));
						const we = edit as { changes?: Record<string, RenameEdit[]>; documentChanges?: unknown[] };
						const changes = we.changes ?? {};
						// Phase 1（全量内存校验，审核 Major-1/2/3）：URI 解码 + 工作区边界 + 文件存在 + range 合法/非重叠；任一失败零写入
						const groups: Array<{ file: string; original: string; result: string; edits: RenameEdit[] }> = [];
						for (const [u, edits] of Object.entries(changes)) {
							// 快审加固：任一结构非法（非数组/空）即整体拒绝，不与合法条目混合部分写入
							if (!Array.isArray(edits)) return err(action, "operation", `rename 拒绝：changes[${String(u).slice(0, 120)}] 非数组（结构非法）；零写入。`);
							if (edits.length === 0) continue;
							const target = uriToPath(u);
							if (!target) return err(action, "operation", `rename 拒绝：非 file: URI 或解码失败（${String(u).slice(0, 160)}）。`);
							if (!withinWorkspace(target)) return err(action, "permission", `rename 拒绝：目标在工作区外（${target}）；零写入。`);
							if (!fs.existsSync(target)) return err(action, "operation", `rename 拒绝：目标文件不存在（${path.relative(cwd, target) || target}）；零写入。`);
							let original: string, result: string;
							try {
								original = fs.readFileSync(target, "utf8");
								result = applyTextEdits(original, edits);
							} catch (e) {
								return err(action, "operation", `rename 拒绝：${target} 编辑校验失败（${e instanceof Error ? e.message : String(e)}）；零写入。`);
							}
							groups.push({ file: target, original, result, edits });
						}
						if (groups.length === 0) return ok(`rename "${rel}" → "${params.newName}" preview:\n(WorkspaceEdit 为 documentChanges 形态，V1 仅支持 changes 形态，未自动写盘)\n${JSON.stringify(edit, null, 2)}`, toLspRenameWire(rel, params.newName, "preview", "documentChanges", [], edit));
						const summary = groups.map((g) => `  ${path.relative(cwd, g.file)}: ${g.edits.map((e) => `${e.range.start.line + 1}:${e.range.start.character + 1} → ${JSON.stringify(e.newText)}`).join("; ")}`).join("\n");
						// P6：targets wire 投影源（单次读取直投影——file 与正文 summary 同一相对化口径）
						const targetsWire: LspRenameTargetSource[] = groups.map((g) => ({ file: path.relative(cwd, g.file) || g.file, edits: g.edits }));
						// v2 P3（§5.2 LSP 行）：rename 返回的每个 WorkspaceEdit 目标全授权后才继续——
						// 任一目标未被写面覆盖或命中 deny 即整单拒绝（部分写拒绝），零写入。授权检查先于
						// preview 返回：preview 不写盘，但权限面注入时同样整单拒（未注入权限面时 preview 照常返回）。
						if (options.permission) {
							const writeRules = options.permission.writeRules ?? [];
							const denyRules = options.permission.denyRules ?? [];
							for (const g of groups) {
								const relTarget = path.relative(cwd, g.file) || g.file;
								if (denyRules.some((r) => matchPathRule(g.file, r))) {
									return err(action, "permission", `rename 拒绝：WorkspaceEdit 目标 "${relTarget}" 落在 deny 禁入区（deny 恒优先）；全目标授权才应用（部分写拒绝），零写入。`);
								}
								if (!writeRules.some((r) => matchPathRule(g.file, r))) {
									return err(action, "permission", `rename 拒绝：WorkspaceEdit 目标 "${relTarget}" 未被任务写授权覆盖（write=${writeRules.length} 条规则）；全目标授权才应用（部分写拒绝），零写入。`);
								}
							}
						}
						if (params.apply !== true) {
							return ok(`rename "${rel}" → "${params.newName}" preview（${groups.reduce((n, g) => n + g.edits.length, 0)} 处编辑，未写盘；apply:true 应用）:\n${summary}`, toLspRenameWire(rel, params.newName, "preview", "changes", targetsWire, null));
						}
						// Phase 2（写盘 + 失败回滚，快审 Major-1）：备份先于写入登记，回滚失败显式报告
						const written: Array<{ file: string; original: string }> = [];
						const rollback = (): string => {
							const rolled: string[] = [], failed: string[] = [];
							for (const w of written.reverse()) {
								try { fs.writeFileSync(w.file, w.original); rolled.push(path.relative(cwd, w.file)); } catch { failed.push(path.relative(cwd, w.file)); }
							}
							return failed.length > 0 ? `已回滚: ${rolled.join(", ") || "(无)"}；回滚失败需手动恢复: ${failed.join(", ")}` : `已回滚: ${rolled.join(", ") || "(无)"}`;
						};
						try {
							for (const g of groups) {
								written.push({ file: g.file, original: g.original }); // 登记先于写入：写入中失败当前文件也在回滚范围
								fs.writeFileSync(g.file, g.result);
								client.ensureOpenFile(g.file, g.result);
							}
						} catch (e) {
							return err(action, "operation", `rename 写盘失败（${e instanceof Error ? e.message : String(e)}），${rollback()}。`);
						}
						return ok(`rename "${rel}" → "${params.newName}" 已应用 ${groups.length} 个文件:\n${summary}`, toLspRenameWire(rel, params.newName, "applied", "changes", targetsWire, null));
					}
					default:
						return err(action, "shape", `未知 action: "${action}"。`);
				}
			} catch (e) {
			// P6：意外异常兑底分类（超时/$/cancelRequest 取消/JSON-RPC error/进程退出 → operation；
			// 其余 internal）——分类只影响 wire code，不改正文文案与行为。
				return err(params?.action, classifyLspWireError(e), `lsp 工具错误: ${e instanceof Error ? e.message : String(e)}`);
			}
		},
	};
	return {
		...tool,
		/** 供 session_shutdown 清理（index.ts 持有调用）。 */
		close: async () => { try { await pool?.closeAll(); } catch {} },
	};
}

type LspConfigHooksPlus = LspToolOptions;
