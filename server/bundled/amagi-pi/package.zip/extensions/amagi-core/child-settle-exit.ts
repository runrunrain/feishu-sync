/**
 * child-settle-exit.ts — 子进程 settle 权威自退（v1.5.222）。
 *
 * 背景（实战 cbc75699）：print 模式子进程终稿交付后若事件循环被句柄挂住（v1.5.218 教训：
 * MCP stdio 子进程），进程不自然退出。此前由**父进程**靠「最后 assistant 帧后 25s 无新帧」
 * 猜测式 SIGTERM 兜底——外部猜测在 toolUse 轮慢首 token、provider error SDK 退避重试等
 * 静默期连续误杀真实在飞的任务（两轮实战事故，且误标 done）。
 *
 * 根治分工（谁掌握真相谁负责）：
 *   - **子进程内 `agent_settled` 才是权威信号**——它在 pi agent 循环真正收口后触发（工具轮
 *     在飞/重试在飞绝不触发）。子进程在 settle 后清理句柄（MCP/LSP close，见 index.ts），
 *     再宽限等待 stdout 终稿行 flush 与自然退出；仍未退（句柄泄漏）→ process.exit(0) 自收口。
 *   - 父进程 25s 猜测兜底降级为最后防线，且只认真终稿帧（task-tool.ts 白名单）——正常情况
 *     子进程早已自退，兜底几乎不触发。
 *
 * 开关：AMAGI_CHILD_SELF_EXIT_MS（默认 1500，0=关闭）。测试可注入 exit/schedule。
 */

export interface SettleExitDeps {
	/** 可注入退出（测试）。 */
	exit?: (code: number) => void;
	/** 可注入定时器（测试）；返回句柄供 unref/cancel。 */
	schedule?: (fn: () => void, ms: number) => { unref?: () => void; cancel?: () => void };
}

/** 解析环境宽限（缺省 1500ms；AMAGI_CHILD_SELF_EXIT_MS=0 关闭）。 */
export function settleSelfExitMs(env: NodeJS.ProcessEnv = process.env): number {
	const v = Number(env.AMAGI_CHILD_SELF_EXIT_MS);
	return Number.isFinite(v) && v >= 0 ? v : 1500;
}

/**
 * 调度 settle 自退：宽限 ms 后仍存活则 exit(0)（等待 stdout 终稿行 flush / 自然退出先行）。
 * 返回取消函数（unref 计时器不阻止退出，正常路径无需手动取消）。
 */
export function scheduleChildSettleExit(deps: SettleExitDeps = {}): () => void {
	const ms = settleSelfExitMs();
	if (ms <= 0) return () => {};
	const doExit = deps.exit ?? ((code: number) => process.exit(code));
	const schedule = deps.schedule ?? ((fn: () => void, delay: number) => {
		const t = setTimeout(fn, delay);
		return { unref: () => t.unref(), cancel: () => clearTimeout(t) };
	});
	const handle = schedule(() => { try { doExit(0); } catch { /* 已在退出中 */ } }, ms);
	try { handle.unref?.(); } catch { /* ignore */ }
	return () => { try { handle.cancel?.(); } catch { /* ignore */ } };
}
