/**
 * win-exec-advisory.ts — bash 侧 drvfs 慢路径软提示（纯函数 + 可用性标记）。
 *
 * 痛点：/mnt/x（drvfs）上批量 git/grep/find 明显慢于 NTFS 原生 git.exe/rg.exe。本模块提供
 * 建议级软提示的判定纯函数（不阻断、不改写命令）：WSL 内且 cwd 位于 /mnt/<盘>/ 且命令首词
 * 为 git/rg（或 grep -r / find 大范围扫描）时提示改用 win_exec。每会话至多一次（去重由
 * bash-override 的 advisoryDedup 承接，与本模块判定分离）；仅在 win_exec 已注册（setWinExecAvailable）
 * 时出现；沿用 AMAGI_BASH_ADVISORY_POLICY 开关（legacy 策略不注入新提示）。
 *
 * 零依赖（纯 env 解析 + 词法），bash-override 直接 import 不拉起重 spawn 面。
 */

/** win_exec 注册成功时置位（index.ts）；bash 软提示仅在 true 时出现。 */
let winExecAvailable = false;
export function setWinExecAvailable(v: boolean): void { winExecAvailable = v; }
export function isWinExecAvailable(): boolean { return winExecAvailable; }

/** WSL 环境纯 env 判定（无 fs 依赖；/proc/version 兜底由 win-exec.ts 完整版承担，此处够用）。 */
export function wslEnvHint(env: NodeJS.ProcessEnv = process.env): boolean {
	return Boolean(env.WSL_DISTRO_NAME) || Boolean(env.WSL_INTEROP);
}

/**
 * m8（diting 审核）：只推荐 win_exec 白名单内的程序——判定面收敛为 git/rg；grep -r/find
 * 不再给 win_exec 建议（两者不在白名单，建议了也用不了）。宁可漏报不误报：管道第二段之后
 * 的消费者（wc/xargs 等）不算；环境变量前缀与 wrapper 剥离经轻量词法完成。
 */
export function drvfsSlowCommandHit(command: string): { hit: true; tool: "git" | "rg" } | { hit: false } {
	const first = String(command ?? "").split(/(?:&&|\|\||;|&|\||\n)/)[0] ?? "";
	const words = first.trim().split(/\s+/).filter(Boolean);
	// 剥环境变量前缀（FOO=bar git …）与常见 wrapper（command/exec/env/nohup/sudo）
	let i = 0;
	while (i < words.length && (/^[A-Za-z_][A-Za-z0-9_]*=/.test(words[i]!) || ["command", "exec", "env", "nohup", "sudo"].includes(words[i]!))) i++;
	const name = ((words[i] ?? "").split("/").pop() ?? "").toLowerCase();
	if (name === "git" || name === "rg") return { hit: true, tool: name };
	return { hit: false };
}

/**
 * bash 软提示文案（null=不提示）：win_exec 可用 + WSL + cwd 在 /mnt/<盘>/ + 命令命中慢路径
 * 形态。env/cwd 由调用方注入（bash-override 持有执行 cwd）；会话级去重不在本函数（调用方
 * advisoryDedup 承接）。
 */
export function drvfsSlowPathNote(command: string, execCwd: string, opts: { available?: boolean; env?: NodeJS.ProcessEnv } = {}): string | null {
	const available = opts.available ?? isWinExecAvailable();
	if (!available) return null;
	if (!wslEnvHint(opts.env)) return null;
	if (!/^\/mnt\/[A-Za-z](\/|$)/.test(String(execCwd ?? ""))) return null;
	const hit = drvfsSlowCommandHit(command);
	if (!hit.hit) return null;
	return `[amagi 软提示·drvfs 慢路径] 当前在 /mnt 挂载（drvfs）上跑 ${hit.tool}——批量扫描在 drvfs 上明显慢于 NTFS 原生；本会话已注册 win_exec 工具，可改用 win_exec({ program: "${hit.tool}", args: [...] })（路径参数自动翻译为 Windows 形态、git.exe/rg.exe 在 NTFS 原生执行）。本提示不阻断、不改写命令；仅每会话提示一次。`;
}
