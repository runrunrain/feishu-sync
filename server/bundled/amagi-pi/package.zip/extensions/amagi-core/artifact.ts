/**
 * artifact.ts — E10：Artifact 落盘契约标准化（迭代期望 §四-2）+ 全局分类归档（实战反馈）。
 *
 * 约定结构（v1.5.171 起迁出项目目录）：
 *   <agentDir>/amagi/artifacts/<taskId>/result.md      — 任务完整回流（终态 output 原文）
 *   <agentDir>/amagi/artifacts/<taskId>/metadata.json  — taskId/agent/model/status/时长/项目cwd/上游 artifact 引用（formatVersion 1）
 *   <agentDir>/amagi/artifacts/index.ndjson            — 分类归档索引（每 artifact 一行：
 *                                                        taskId/agent/status/model/项目cwd/时间/字节数，
 *                                                        可按角色/日期/项目聚合浏览）
 *
 * 设计理由：
 *   - SubAgent 产出脱离对话流独立存活；跨会话 resume 时直接挂载旧 artifact（task-tool findArtifact）。
 *   - **全局路径而非项目内 agent-outputs/**：项目仓库不被 SubAgent 产出污染（实战反馈：
 *     battle-sim 等工作区 git status 出现散乱 agent-outputs/ 未跟踪目录）；项目归属记录在 metadata/索引。
 *   - v1.5.170 的项目内 legacy artifact（<cwd>/agent-outputs/<taskId>/）由 findArtifact 回退兼容。
 *
 * 边界：
 *   - AMAGI_ARTIFACT_OFF=1 关闭；AMAGI_ARTIFACT_ROOT 覆盖根目录（测试/运维注入）。
 *   - 写失败返回 null（不抛错、不影响回流主流程）；E8 折叠复用 result.md 路径，不重复落盘。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export function artifactEnabled(): boolean {
	const v = process.env.AMAGI_ARTIFACT_OFF;
	return !(v === "1" || v === "true");
}

/** 查询/压缩面只引用确实存在的归档文件；不展开终稿或自动采集正文。 */
export function archivedTaskContextRefs(taskId: string): string[] {
	if (!artifactEnabled()) return [];
	try {
		const dir = path.join(artifactRoot(), sanitizeId(taskId));
		return ["result.md", "evidence.md"].map((name) => path.join(dir, name)).filter((file) => {
			try { return fs.statSync(file).isFile(); } catch { return false; }
		});
	} catch { return []; }
}

/** 路径去重只作用于引用投影，不改写任务正文；保持首项顺序和原始可读路径。 */
export function uniqueArtifactRefs(refs: readonly string[], cwd: string): string[] {
	const seen = new Set<string>();
	return refs.filter((ref) => {
		if (typeof ref !== "string" || !ref.trim()) return false;
		const key = path.resolve(cwd, ref);
		if (seen.has(key)) return false;
		seen.add(key);
		return true;
	});
}

/** 续接/下游只挂直接前序的终稿入口；祖先引用由其 metadata/result 按需追溯。
 * 无终稿归档时按冻结的输入引用排除历史来源，不凭文件名猜测所有权。 */
export function taskContextArtifactRefs(taskId: string, refs: readonly string[], upstream: readonly string[], cwd: string): string[] {
	const archived = artifactEnabled() ? findArtifact(cwd, taskId) : null;
	if (archived) return [archived.relDir];
	const inputs = uniqueArtifactRefs(upstream, cwd).map((ref) => path.resolve(cwd, ref));
	return uniqueArtifactRefs(refs, cwd).filter((ref) => {
		const abs = path.resolve(cwd, ref);
		return !inputs.some((input) => {
			const rel = path.relative(input, abs);
			return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
		});
	});
}

function agentDir(): string {
	return process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

/** artifact 全局根目录：AMAGI_ARTIFACT_ROOT（测试/运维注入）|| <agentDir>/amagi/artifacts。 */
export function artifactRoot(_cwd?: string): string {
	return process.env.AMAGI_ARTIFACT_ROOT || path.join(agentDir(), "amagi", "artifacts");
}

/** amagi-pi v2（K2）：契约存储根目录——task-store.ts 消费（spec/receipt/current/owner-lease）。
 *  AMAGI_CONTRACT_ROOT（测试/运维注入）|| <agentDir>/amagi/v2-store。
 *  只做路径解析不触盘；目录 0o700 / 文件 0o600 由 task-store 写入原语保证。 */
export function contractStoreRoot(): string {
	return process.env.AMAGI_CONTRACT_ROOT || path.join(agentDir(), "amagi", "v2-store");
}

// ev-20261012-4afdc8：回执归档相对引用的正文呈现辅助——展示面与解析面同源（均由
// contractStoreRoot() 实际配置解析，AMAGI_CONTRACT_ROOT 注入随之变化），不硬编码任何用户目录
// 也不猜存储子目录；可见路径不授予读写权限（契约存储禁写/跨 owner/deny 边界不变）。

/** 基准提示行（正文展示层）：标明「回执归档」相对路径相对 v2 契约存储根解析。
 *  多任务分页由调用方控制每页至多渲染一次（不刷屏）。 */
export function contractRefBaseHint(): string {
	return `    归档基准: 「回执归档」相对路径按 v2 契约存储根解析——本机根: ${contractStoreRoot()}（相对引用拼此根读取；勿猜其它目录）`;
}

/** 行内标注：相对引用标「相对 v2 契约存储根」；已是绝对路径的引用返回空串（不二次拼接/二次标注）。 */
export function contractRefInlineNote(refPath: string): string {
	return path.isAbsolute(refPath) ? "" : "（相对 v2 契约存储根）";
}

/** 项目内 legacy 根（v1.5.170 兼容回退查找用）。 */
function legacyProjectRoot(cwd: string): string {
	return path.join(cwd || process.cwd(), "agent-outputs");
}

/** taskId → 目录安全片段（resume 磁盘回填/索引前缀扫描复用）。 */
export function sanitizeId(taskId: string): string {
	return String(taskId || "unknown").replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 64) || "unknown";
}

export interface ArtifactWrite {
	runtimeObservation?: import("./runtime-fingerprint.ts").RuntimeObservation;
	taskId: string;
	agent: string;
	model?: string;
	status: string;
	blocked: boolean;
	/** diting Major-4：blocked 结构化原因（questions/needs-handoff），随 metadata 持久化供磁盘回填。 */
	blockReason?: "questions" | "needs-handoff";
	/** 终态完整 output（result.md 原文）。 */
	output: string;
	sessionId?: string;
	durationMs?: number;
	startedAt?: number;
	endedAt?: number;
	rounds?: number;
	/** 任务执行的项目 cwd（traceability；artifact 不再落在这里）。 */
	cwd: string;
	/** P1-C（8.19 迭代）：上游 artifact 引用——派发契约（任务文本 refs ∪ resume 直接父交接入口）
	 *  的定格快照，由 finalizer 从 registry 取（不发明内容）；无 refs 时为空数组。 */
	upstreamArtifactReferences?: string[];
}

export interface ArtifactPaths {
	dir: string;
	resultPath: string;
	metadataPath: string;
	/** 展示用路径（全局绝对路径；回流/registry.artifactRefs 引用口径）。 */
	relDir: string;
	relResult: string;
}

/** 追加分类归档索引行（原子单行 append；失败静默不影响主流程）。 */
function appendIndex(root: string, entry: Record<string, unknown>): void {
	try {
		fs.mkdirSync(root, { recursive: true });
		fs.appendFileSync(path.join(root, "index.ndjson"), JSON.stringify(entry) + "\n", { encoding: "utf8", mode: 0o600 });
	} catch {}
}

/** P1-C：上游引用清洗（非字符串/空白/去重/上界10；非数组 → 空数组，无 refs 不报错）。 */
function sanitizeUpstreamRefs(v: unknown): string[] {
	if (!Array.isArray(v)) return [];
	const out: string[] = [];
	for (const item of v) {
		if (typeof item !== "string" || item.trim() === "" || out.includes(item)) continue;
		out.push(item);
		if (out.length >= 10) break;
	}
	return out;
}

/** 写 artifact（result.md + metadata.json + 索引行）。失败/关闭 → null。 */
export function writeArtifact(w: ArtifactWrite): ArtifactPaths | null {
	if (!artifactEnabled()) return null;
	try {
		const root = artifactRoot();
		const dir = path.join(root, sanitizeId(w.taskId));
		fs.mkdirSync(dir, { recursive: true });
		const resultPath = path.join(dir, "result.md");
		const metadataPath = path.join(dir, "metadata.json");
		fs.writeFileSync(resultPath, w.output || "", "utf8");
		const outputBytes = Buffer.byteLength(w.output || "", "utf8");
		const metadata = {
			formatVersion: 1,
			...(w.runtimeObservation ? { runtime: w.runtimeObservation.runtime, ...(w.runtimeObservation.providerDiagnostic ? { providerDiagnostic: w.runtimeObservation.providerDiagnostic } : {}) } : {}),
			taskId: w.taskId,
			agent: w.agent,
			model: w.model,
			status: w.status,
			blocked: w.blocked,
			blockReason: w.blockReason,
			sessionId: w.sessionId,
			durationMs: w.durationMs,
			startedAt: w.startedAt,
			endedAt: w.endedAt ?? Date.now(),
			rounds: w.rounds,
			outputBytes,
			cwd: w.cwd, // 项目归属（traceability）
			upstreamArtifactReferences: sanitizeUpstreamRefs(w.upstreamArtifactReferences), // P1-C：派发契约 refs，空数组合法
		};
		fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2) + "\n", "utf8");
		appendIndex(root, {
			taskId: w.taskId, agent: w.agent, status: w.status, model: w.model,
			// v1.5.222：索引行补 sessionId——Leader 重启后 resume 磁盘回填优先从索引定位会话，
			// 免扫 sessions 目录（实战：cbc75699 元数据缺 sessionId，回填只能靠目录扫描兜底）。
			sessionId: w.sessionId,
			cwd: w.cwd, at: metadata.endedAt, outputBytes,
		});
		return { dir, resultPath, metadataPath, relDir: dir, relResult: resultPath };
	} catch {
		return null; // 容错：artifact 写失败不影响回流主流程
	}
}

/** 自动采集详情独立留档；成功后才允许把上下文中的原文替换为摘要。 */
export function writeAutomaticEvidence(ap: ArtifactPaths | null, text: string): string | null {
	if (!ap || !text) return null;
	try {
		const file = path.join(ap.dir, "evidence.md");
		fs.writeFileSync(file, text, "utf8");
		return file;
	} catch {
		return null;
	}
}

/** 读旧 artifact（resume 挂载用）：全局根优先，项目内 legacy（v1.5.170）回退；存在 result.md 才返回。 */
export function findArtifact(cwd: string, taskId: string): { relDir: string; relResult: string } | null {
	const safe = sanitizeId(taskId);
	try {
		const globalDir = path.join(artifactRoot(), safe);
		const globalResult = path.join(globalDir, "result.md");
		if (fs.statSync(globalResult).isFile()) return { relDir: globalDir, relResult: globalResult };
	} catch {}
	try {
		const legacyDir = path.join(legacyProjectRoot(cwd), safe);
		const legacyResult = path.join(legacyDir, "result.md");
		if (fs.statSync(legacyResult).isFile()) return { relDir: legacyDir, relResult: legacyResult };
	} catch {}
	return null;
}

// ── S5/01ef8c（方案 §5.4）：证据归因结构化快照（classification.json）──────────────
// 有界完整分类结果随任务证据保存一份（finalizer 采集 → 落盘 artifact 目录）；
// query_task evidenceDetail=full 从它展开——结束后工作树改动不改变旧详情。
// 旧任务无快照 → read 返回 null（明确不可用，不臆造）；字段解析/校验在 evidence.ts
// parseEvidenceClassificationSnapshot（artifact 层只负责存取，不 import 证据层类型，保持独立）。

/** 快照文件名（artifact 目录内，与 result.md/metadata.json 同级）。 */
export const EVIDENCE_CLASSIFICATION_FILENAME = "classification.json";

/** 写结构化分类快照到 artifact 目录（失败静默 false；不影响主回流）。接受任意可 JSON 化对象。 */
export function writeEvidenceClassification(artifactDir: string, snapshot: object): boolean {
	try {
		fs.mkdirSync(artifactDir, { recursive: true });
		fs.writeFileSync(path.join(artifactDir, EVIDENCE_CLASSIFICATION_FILENAME), JSON.stringify(snapshot) + "\n", "utf8");
		return true;
	} catch {
		return false;
	}
}

/** 读结构化分类快照（无文件/解析失败 → null：旧任务明确不可用，不臆造）。 */
export function readEvidenceClassification(artifactDir: string): unknown {
	try {
		return JSON.parse(fs.readFileSync(path.join(artifactDir, EVIDENCE_CLASSIFICATION_FILENAME), "utf8"));
	} catch {
		return null;
	}
}
