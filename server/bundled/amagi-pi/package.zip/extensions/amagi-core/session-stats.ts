/**
 * session-stats.ts — ev-20261027-4c5b1c：会话级工具调用/失败统计（只读聚合 + /amagi stats 附段供给）。
 *
 * 背景（evolution 现象）：长会话压缩后，各工具调用数 / isError / 软提示分布只存在于会话
 * JSONL，复盘需手写临时脚本逐次解析——本模块把该口径沉淀为 /amagi stats 的常驻附段。
 *
 * 口径（已裁定，输出随行披露）：
 *  - 全会话完整 append 历史：sessionManager.getEntries()（公开契约，含全部分支与压缩前条目；
 *    pi 压缩不改写历史条目，故压缩后仍可统计——pi docs session-format.md/CompactionEntry）。
 *    全分支=含被放弃分支（与活跃分支口径不同，输出写清）。
 *  - 顶层调用与结果分别计数：assistant content 的 toolCall 块、role=toolResult 消息；
 *    无结果不伪造成功（差额如实列示）。
 *  - 嵌套调用（ctx.executeTool / CodeMode）不产生 transcript 条目，只以 nestedCalls bounded
 *    记录载于调用方结果消息（pi docs extensions.md/messages 公开契约）——单列计数，
 *    不并入顶层工具表、不双计。
 *  - 软提示=可观察注记标签（toolResult 文本行首方括号标签，封闭谓词：软提示/预警/升级提示/
 *    已放行/等待建议/等待提示）；阻断类标签（已阻止/被拒）与状态标签不计入。
 *  - 子任务终态=traces 按 leaderSession 盖章精确匹配（与 aggregateSessionUsage 同一投影），
 *    按 taskId 去重取末次行；无盖章=不可用，不跨会话冒算。
 *
 * 边界：纯函数聚合 + 文本渲染 + 会话面提取（sessionToolStatsSection 含诚实降级文案）；
 * 零写入、零模型调用、零新增监听/状态机/缓存/工具名。
 */

import type { TraceEntry } from "./trace.ts";

export interface SessionToolStatRow {
	tool: string;
	/** 顶层 assistant toolCall 块数（显示面口径；嵌套调用不计入）。 */
	calls: number;
	/** role=toolResult 消息数。 */
	results: number;
	/** toolResult isError===true 数。 */
	errors: number;
}

export interface SessionSoftPromptRow {
	/** 注记标签原文（超长截断；如 `[AMAGI Bash 诊断·软提示]`）。 */
	category: string;
	count: number;
}

export interface SessionToolStatsView {
	/** 扫描条目总数（getEntries 全量，不含 header）。 */
	entries: number;
	/** message 条目数。 */
	messages: number;
	/** compaction 条目数（压缩不改写历史——只是计数量，不是丢弃量）。 */
	compactions: number;
	totalCalls: number;
	totalResults: number;
	totalErrors: number;
	byTool: SessionToolStatRow[];
	/** 有调用无结果（不伪造成功；含被放弃分支/中断轮的调用）。 */
	callsWithoutResult: number;
	/** 有结果无对应调用记录（罕见：旧版会话/外部恢复历史）。 */
	resultsWithoutCall: number;
	softPrompts: SessionSoftPromptRow[];
	/** 嵌套调用 bounded 记录（toolResult.nestedCalls；单列，不并入 byTool）。 */
	nested: { records: number; error: number; unfinished: number; onResults: number; complete: boolean } | undefined;
}

/** 软提示标签谓词（封闭词表——amagi 注记通道的可观察形态；阻断/状态标签不入列）。 */
const SOFT_PROMPT_TAG_WORDS = /软提示|预警|升级提示|已放行|等待建议|等待提示/;

/** 行首方括号标签（跨行边界/行首缩进容差；标签本体不含换行，长度有界）——amagi 注记的可见形态是行前缀。捕获含括号（可观察原文形态）。 */
const TAG_LINE_RE = /(?:^|\n)[ \t]*(\[[^\]\n]{1,80}\])/g;

/** 类别标签上限（超长截断防状态输出无界）。 */
const MAX_CATEGORY_LABEL = 48;

/** 单个标签是否软提示类；命中返回归一化类别，否则 null。 */
function softPromptCategory(tag: string): string | null {
	if (!SOFT_PROMPT_TAG_WORDS.test(tag)) return null;
	return tag.length > MAX_CATEGORY_LABEL ? `${tag.slice(0, MAX_CATEGORY_LABEL)}…` : tag;
}

/** toolResult 文本中的软提示标签计数（每个匹配行首标签计一次）。 */
function countSoftPrompts(text: string, into: Map<string, number>): void {
	if (!text) return;
	for (const match of text.matchAll(TAG_LINE_RE)) {
		const raw = match[1];
		if (raw === undefined) continue;
		const cat = softPromptCategory(raw);
		if (cat) into.set(cat, (into.get(cat) ?? 0) + 1);
	}
}

/**
 * 会话工具统计聚合（纯函数）。entries：sessionManager.getEntries() 投影（容忍任意形态——
 * 只读 type==="message" 的 assistant toolCall 块与 toolResult 消息、compaction 条目计数）。
 */
export function aggregateSessionToolStats(entries: readonly unknown[]): SessionToolStatsView {
	const byTool = new Map<string, SessionToolStatRow>();
	const idName = new Map<string, string>();
	const callIds = new Set<string>();
	const resultIds = new Set<string>();
	const soft = new Map<string, number>();
	let messages = 0, compactions = 0, totalCalls = 0, totalResults = 0, totalErrors = 0;
	let nested: SessionToolStatsView["nested"];
	const row = (tool: string): SessionToolStatRow => {
		let r = byTool.get(tool);
		if (!r) { r = { tool, calls: 0, results: 0, errors: 0 }; byTool.set(tool, r); }
		return r;
	};
	for (const entry of entries) {
		const e = entry as { type?: unknown; message?: unknown } | null;
		if (!e || typeof e !== "object") continue;
		if (e.type === "compaction") compactions++;
		if (e.type !== "message") continue;
		messages++;
		const m = e.message as {
			role?: unknown; content?: unknown; toolCallId?: unknown; toolName?: unknown; isError?: unknown; nestedCalls?: unknown;
		} | null;
		if (!m || typeof m !== "object") continue;
		if (m.role === "assistant" && Array.isArray(m.content)) {
			for (const block of m.content) {
				const b = block as { type?: unknown; id?: unknown; name?: unknown } | null;
				if (!b || b.type !== "toolCall") continue;
				const name = typeof b.name === "string" && b.name ? b.name : "?";
				if (typeof b.id === "string" && b.id) { callIds.add(b.id); idName.set(b.id, name); }
				row(name).calls++;
				totalCalls++;
			}
		} else if (m.role === "toolResult") {
			const name = typeof m.toolName === "string" && m.toolName
				? m.toolName
				: typeof m.toolCallId === "string" ? idName.get(m.toolCallId) : undefined;
			if (typeof m.toolCallId === "string" && m.toolCallId) resultIds.add(m.toolCallId);
			row(name ?? "?").results++;
			totalResults++;
			if (m.isError === true) { row(name ?? "?").errors++; totalErrors++; }
			for (const part of Array.isArray(m.content) ? m.content : []) {
				const text = (part as { text?: unknown } | null)?.text;
				if (typeof text === "string") countSoftPrompts(text, soft);
			}
			// nestedCalls：嵌套调用 bounded 记录——单列计数，不并入 byTool（不混顶层/不双计）。
			const nc = m.nestedCalls as { calls?: unknown; complete?: unknown } | null | undefined;
			if (nc && Array.isArray(nc.calls) && nc.calls.length > 0) {
				let error = 0, unfinished = 0;
				for (const c of nc.calls) {
					const st = (c as { status?: unknown } | null)?.status;
					if (st === "error") error++;
					else if (st === "unfinished") unfinished++;
				}
				if (!nested) nested = { records: 0, error: 0, unfinished: 0, onResults: 0, complete: true };
				nested.records += nc.calls.length;
				nested.error += error;
				nested.unfinished += unfinished;
				nested.onResults++;
				if (nc.complete === false) nested.complete = false;
			}
		}
	}
	let callsWithoutResult = 0;
	for (const id of callIds) if (!resultIds.has(id)) callsWithoutResult++;
	let resultsWithoutCall = 0;
	for (const id of resultIds) if (!callIds.has(id)) resultsWithoutCall++;
	return {
		entries: Array.isArray(entries) ? entries.length : 0,
		messages,
		compactions,
		totalCalls,
		totalResults,
		totalErrors,
		byTool: [...byTool.values()].sort((a, b) => b.calls - a.calls || a.tool.localeCompare(b.tool)),
		callsWithoutResult,
		resultsWithoutCall,
		softPrompts: [...soft.entries()]
			.map(([category, count]) => ({ category, count }))
			.sort((a, b) => b.count - a.count || a.category.localeCompare(b.category)),
		nested,
	};
}

export type SessionChildTasksView =
	| { available: false; reason: string }
	| { available: true; total: number; byStatus: Array<{ status: string; tasks: number }> };

/**
 * 本会话子任务终态（纯函数）。traces 按 leaderSession 盖章精确匹配（与
 * aggregateSessionUsage 的 childThisSession 同一投影口径），按 taskId 去重取末次行
 * （resume/续接多行时以末次状态为准）；无盖章=不可用，不跨会话冒算。
 */
export function aggregateSessionChildTaskStatuses(traces: readonly TraceEntry[], leaderSession: string | undefined): SessionChildTasksView {
	if (typeof leaderSession !== "string" || !leaderSession) {
		return { available: false, reason: "无会话盖章（leaderSession 缺席）——不跨会话冒算" };
	}
	const latest = new Map<string, TraceEntry>();
	for (const t of traces) {
		if (!t || t.leaderSession !== leaderSession) continue;
		if (typeof t.taskId === "string" && t.taskId) latest.set(t.taskId, t);
	}
	const byStatus = new Map<string, number>();
	for (const t of latest.values()) {
		const s = typeof t.status === "string" && t.status ? t.status : "?";
		byStatus.set(s, (byStatus.get(s) ?? 0) + 1);
	}
	return {
		available: true,
		total: latest.size,
		byStatus: [...byStatus.entries()]
			.map(([status, tasks]) => ({ status, tasks }))
			.sort((a, b) => b.tasks - a.tasks || a.status.localeCompare(b.status)),
	};
}

function childTasksLines(childTasks: SessionChildTasksView): string[] {
	if (!childTasks.available) {
		return [`  本会话子任务终态: 不可用（${childTasks.reason}）`];
	}
	const parts = childTasks.byStatus.map((s) => `${s.status} ${s.tasks}`).join(" · ");
	return [`  本会话子任务终态（traces 按 leaderSession 匹配，按 taskId 去重取末次）: ${childTasks.total === 0 ? "0（本会话无已落 trace 的子任务）" : `${parts}（共 ${childTasks.total}）`}`];
}

/** 渲染（口径声明必须随行——全分支 ≠ 活跃分支账单）。 */
export function renderSessionToolStatsText(view: SessionToolStatsView, childTasks: SessionChildTasksView): string {
	const lines: string[] = [];
	lines.push("本会话工具统计（口径：全会话完整 append 历史——含压缩前条目与全部分支（含被放弃分支）；pi 压缩不改写历史，压缩后仍可统计；嵌套调用不计入下表）");
	if (view.entries === 0) {
		lines.push("  无会话条目（空会话——不计数）");
		lines.push(...childTasksLines(childTasks));
		return lines.join("\n");
	}
	lines.push(`  条目 ${view.entries}（消息 ${view.messages} · 压缩 ${view.compactions} 次）· 顶层调用 ${view.totalCalls} · 结果 ${view.totalResults} · isError ${view.totalErrors}`);
	if (view.byTool.length > 0) {
		lines.push("  工具 | 调用 | 结果 | isError");
		for (const r of view.byTool) lines.push(`    ${r.tool} | ${r.calls} | ${r.results} | ${r.errors}`);
	} else {
		lines.push("  无工具调用");
	}
	const unmatched: string[] = [];
	if (view.callsWithoutResult > 0) unmatched.push(`无结果调用 ${view.callsWithoutResult}（含被放弃分支/中断轮——不伪造成功）`);
	if (view.resultsWithoutCall > 0) unmatched.push(`无调用对应的结果 ${view.resultsWithoutCall}（旧版会话/外部恢复历史形态）`);
	if (unmatched.length > 0) lines.push(`  差额: ${unmatched.join(" · ")}`);
	if (view.nested) {
		lines.push(`  嵌套调用（CodeMode/ctx.executeTool 的 bounded 记录，单列不并入上表）: 记录 ${view.nested.records} · error ${view.nested.error} · 未完成 ${view.nested.unfinished}（载于 ${view.nested.onResults} 个结果${view.nested.complete ? "" : "；complete:false——记录有丢弃"}）`);
	}
	if (view.softPrompts.length > 0) {
		lines.push("  可观察软提示（注记标签计数；阻断类不计入）:");
		for (const s of view.softPrompts) lines.push(`    ${s.category} ×${s.count}`);
	} else {
		lines.push("  可观察软提示: 无命中（本会话 toolResult 文本未见软提示类注记标签——是 0 命中，非未扫描）");
	}
	lines.push(...childTasksLines(childTasks));
	return lines.join("\n");
}

/**
 * /amagi stats 附段供给（组合根接线用；含诚实降级）。ctxRaw：命令 handler 原始上下文——
 * 经公开 sessionManager.getEntries() 取全会话条目；无会话面/异常 → 如实缺席文案，不计数。
 */
export function sessionToolStatsSection(ctxRaw: unknown, traces: readonly TraceEntry[], leaderSession: string | undefined): string {
	try {
		const sm = (ctxRaw as { sessionManager?: { getEntries?: () => unknown[] } } | null | undefined)?.sessionManager;
		const entries = typeof sm?.getEntries === "function" ? sm.getEntries() : undefined;
		if (!Array.isArray(entries)) {
			return "本会话工具统计: 不可用（无会话面 sessionManager.getEntries——非交互/宿主未注入；如实缺席，不计数）";
		}
		return renderSessionToolStatsText(aggregateSessionToolStats(entries), aggregateSessionChildTaskStatuses(traces, leaderSession));
	} catch (e) {
		return `本会话工具统计: 失败（${e instanceof Error ? e.message : String(e)}——零副作用，可重试）`;
	}
}
