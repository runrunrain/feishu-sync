/**
 * shell-lexer.ts — 有界 shell 词法解析纯函数集（自 guards.ts P3-A 拆出，纯函数零 pi 依赖）。
 *
 * 提供：保留引号内 payload 的 tokenizer（shellTokens）、控制操作符分段（shellSegments）、
 * 包裹器剥离（executableWords：env/sudo/timeout/xargs…）、$() 与 `` 命令替换 payload 提取
 * （commandSubstitutions / scanBackticks 系列）、heredoc 拆分（splitHeredocs）、以及
 * ev-20260922-e44fe9/2d5a76（B0）新增的可执行 shell 语义视图（analyzeExecutableShell：
 * span 语义 token + kind 标记，供 stash 串联门与 heredoc 入口对称守卫共用单源）。
 * 守卫策略（危险命令判定、交互式拦截、git 等价调用解析、探针、哨兵、接线）仍全部留在 guards.ts。
 *
 * ev-20261012 N2（8c51c0/647bc5/af9e9a/551137 结构性批次）：heredoc 词法升级为引号/注释感知的
 *  字符级扫描（伪引入不吞行）、反斜杠续行在词法层丢弃（不再产出换行文本的伪控制符词）、精确
 *  闭合定界行结构性剔除、命令替换/反引号边界识别；地面真值探针与差分验收见
 *  .agent-outputs/evolve/2.19.3/N2-report.md。
 *
 * 安全边界声明（随迁自 guards.ts）：这是“有界 lexer 安全网”，不是安全边界；刻意对抗仍可能绕过。
 * 深度防御依赖系统层沙箱（T3-1），本模块只承担确定性文本解析原语职责。
 */

import * as path from "node:path";

export const CONTROL_OPERATORS = new Set(["&&", "||", ";", "|", "\n"]);

/** 带引号语义的 token（ed-20260910 diting M-1）：text 与 shellTokens 完全一致（引号剥离后的 payload），
 *  unquotedVar 标记 token 是否含「引号外」的参数展开（`$W`/`${W}`/`$(…)`）。bash 只对未引用展开做
 *  分词与通配，守卫据此区分 `cd $W`（值含空格会分裂）与 `cd "$W"`（单字段）。 */
export interface ShellTokenMeta {
	text: string;
	unquotedVar: boolean;
}

/** 轻量 shell lexer 核心：保留引号内 payload，但只在引号外切控制操作符；同时记录引号外参数展开。 */
function tokenizeShell(input: string): ShellTokenMeta[] {
	const tokens: ShellTokenMeta[] = [];
	let token = "";
	let unquotedVar = false;
	let quote: "'" | '"' | null = null;
	let escaped = false;
	const push = () => {
		if (token) tokens.push({ text: token, unquotedVar });
		token = "";
		unquotedVar = false;
	};
	const pushOperator = (text: string) => { tokens.push({ text, unquotedVar: false }); };
	for (let i = 0; i < input.length; i++) {
		const ch = input[i];
		if (escaped) { token += ch; escaped = false; continue; }
		if (ch === "\\" && quote !== "'") {
			// ev-20261012-647bc5：引号外反斜杠+换行是行续接（含 \r\n）——两字符在词法层直接丢弃，
			// 续接词跨行拼接（不再产出文本恰为 "\n" 的伪控制符词）；单引号内 \⏎ 保持字面；
			// `\\`⏎（转义反斜杠后的真换行）仍按换行操作符切分。
			if (input[i + 1] === "\n") { i++; continue; }
			if (input[i + 1] === "\r" && input[i + 2] === "\n") { i += 2; continue; }
			escaped = true; continue;
		}
		if (quote) {
			if (ch === quote) quote = null;
			else token += ch;
			continue;
		}
		if (ch === "'" || ch === '"') { quote = ch; continue; }
		if (ch === "#" && token === "" && (i === 0 || /\s/.test(input[i - 1]))) {
			while (i < input.length && input[i] !== "\n") i++;
			push(); pushOperator("\n");
			continue;
		}
		const pair = input.slice(i, i + 2);
		if (pair === "&&" || pair === "||") { push(); pushOperator(pair); i++; continue; }
		if (ch === ";" || ch === "|" || ch === "\n") { push(); pushOperator(ch); continue; }
		if (/\s/.test(ch)) { push(); continue; }
		if (ch === "$") unquotedVar = true;
		token += ch;
	}
	if (escaped) token += "\\";
	push();
	return tokens;
}

/** 轻量 shell lexer：保留引号内 payload，但只在引号外切控制操作符。 */
export function shellTokens(input: string): string[] {
	return tokenizeShell(input).map((t) => t.text);
}

export function shellSegmentsMeta(input: string): ShellTokenMeta[][] {
	const result: ShellTokenMeta[][] = [];
	let current: ShellTokenMeta[] = [];
	for (const token of tokenizeShell(input)) {
		if (CONTROL_OPERATORS.has(token.text)) {
			if (current.length) result.push(current);
			current = [];
		} else current.push(token);
	}
	if (current.length) result.push(current);
	return result;
}

export function shellSegments(input: string): string[][] {
	return shellSegmentsMeta(input).map((segment) => segment.map((t) => t.text));
}

/** ev-20261005-7b6d68（diting M1）：管道链分组——`|` 续链（同链内段），`&&`/`||`/`;`/换行断链。
 *  返回每条管道链的段（词组）序列：`npx tsc | head -5 && echo OK` → [[[npx,tsc,|],[head,-5]],
 *  [[echo,OK]]]——与 shellSegments 的差异：不丢失分隔符类型，可判「管道末段」vs「命令末段」。 */
export function shellPipelineChains(input: string): string[][][] {
	const chains: string[][][] = [];
	let current: string[][] = [];
	let seg: string[] = [];
	for (const token of tokenizeShell(input)) {
		if (token.text === "|") {
			if (seg.length) current.push(seg);
			seg = [];
			continue;
		}
		if (token.text === "&&" || token.text === "||" || token.text === ";" || token.text === "\n") {
			if (seg.length) current.push(seg);
			seg = [];
			if (current.length) { chains.push(current); current = []; }
			continue;
		}
		seg.push(token.text);
	}
	if (seg.length) current.push(seg);
	if (current.length) chains.push(current);
	return chains;
}

/** ev-20261017-6d2825（diting F1）：与 shellPipelineChains 同序的「各链前置分隔符」——首链为 ""，
 *  其余为 `&&`/`||`/`;`/`\n`。末链由 `&&` 引入时前段失败会短路末链，整条退出码不再属于末链。 */
export function shellChainOperators(input: string): string[] {
	const ops: string[] = [];
	let pendingOp = "";
	let chainOpen = false;
	for (const token of tokenizeShell(input)) {
		if (token.text === "&&" || token.text === "||" || token.text === ";" || token.text === "\n") {
			if (chainOpen) { chainOpen = false; pendingOp = token.text; }
			else if (ops.length) pendingOp = token.text; // 空链（连续分隔符）：取最近一个
			continue;
		}
		if (token.text === "|") continue;
		if (!chainOpen) { ops.push(ops.length ? pendingOp : ""); chainOpen = true; }
	}
	return ops;
}

export function executableWords(tokens: string[], unwrapTimeout = false): string[] {
	let current = [...tokens];
	while (current.length && /^[A-Za-z_][A-Za-z0-9_]*=.*/.test(current[0])) current.shift();
	const valuesByWrapper: Record<string, Set<string>> = {
		env: new Set(["-u", "--unset", "-C", "--chdir", "-S", "--split-string"]),
		sudo: new Set(["-u", "--user", "-g", "--group", "-h", "--host", "-p", "--prompt", "-r", "--role", "-t", "--type", "-C", "--close-from", "-D", "--chdir", "-R", "--chroot"]),
		time: new Set(["-f", "--format", "-o", "--output"]),
		timeout: new Set(["-k", "--kill-after", "-s", "--signal"]),
		nice: new Set(["-n", "--adjustment"]),
		ionice: new Set(["-c", "--class", "-n", "--classdata", "-p", "--pid", "-P", "--pgid", "-u", "--uid"]),
		stdbuf: new Set(["-i", "--input", "-o", "--output", "-e", "--error"]),
		command: new Set(), builtin: new Set(), nohup: new Set(),
	};
	for (let depth = 0; depth < 8 && current.length; depth++) {
		const wrapper = path.basename(current[0]).toLowerCase();
		if (wrapper === "timeout" && !unwrapTimeout) break;
		if (valuesByWrapper[wrapper]) {
			let i = 1;
			while (i < current.length) {
				const token = current[i];
				if (token === "--") { i++; break; }
				if (wrapper === "env" && /^[A-Za-z_][A-Za-z0-9_]*=.*/.test(token)) { i++; continue; }
				if (!token.startsWith("-")) break;
				const option = token.includes("=") ? token.slice(0, token.indexOf("=")) : token;
				if (valuesByWrapper[wrapper].has(option) && token === option) i += 2;
				else i++;
			}
			if (wrapper === "timeout" && i < current.length) i++; // duration
			current = current.slice(i);
			continue;
		}
		if (wrapper === "xargs") {
			let i = 1;
			const optionNeedsValue = new Set(["-a", "--arg-file", "-d", "--delimiter", "-E", "--eof", "-I", "--replace", "-L", "--max-lines", "-n", "--max-args", "-P", "--max-procs", "-s", "--max-chars"]);
			while (i < current.length) {
				const token = current[i];
				if (token === "--") { i++; break; }
				if (optionNeedsValue.has(token)) { i += 2; continue; }
				if ((token.startsWith("--") && token.includes("=")) || /^-(?:[adEILnPs]).+/.test(token) || /^-[0prt]+$/.test(token)) { i++; continue; }
				if (token.startsWith("-")) { i++; continue; }
				break;
			}
			current = current.slice(i);
			continue;
		}
		break;
	}
	return current;
}

export function commandSubstitutions(input: string): string[] {
	const payloads: string[] = [];
	let outerQuote: "'" | '"' | null = null, outerEscaped = false;
	for (let i = 0; i < input.length - 1; i++) {
		const outer = input[i];
		if (outerEscaped) { outerEscaped = false; continue; }
		if (outer === "\\" && outerQuote !== "'") { outerEscaped = true; continue; }
		if (outerQuote === "'") { if (outer === "'") outerQuote = null; continue; }
		if (outer === "'") { outerQuote = "'"; continue; }
		if (outer === '"') { outerQuote = outerQuote === '"' ? null : '"'; continue; }
		if (input[i] !== "$" || input[i + 1] !== "(") continue;
		let depth = 1, quote: string | null = null, escaped = false;
		const start = i + 2;
		for (let j = start; j < input.length; j++) {
			const ch = input[j];
			if (escaped) { escaped = false; continue; }
			if (ch === "\\" && quote !== "'") { escaped = true; continue; }
			if (quote) { if (ch === quote) quote = null; continue; }
			if (ch === "'" || ch === '"') { quote = ch; continue; }
			if (ch === "(") depth++;
			if (ch === ")" && --depth === 0) { payloads.push(input.slice(start, j)); i = j; break; }
		}
	}
	return payloads;
}

export const UNCLOSED_BACKTICK = "__AMAGI_UNCLOSED_BACKTICK__";
export const UNSAFE_DOUBLE_QUOTED_BACKTICK = "__AMAGI_UNSAFE_DOUBLE_QUOTED_BACKTICK__";
const SIMPLE_DOUBLE_QUOTED_BACKTICK = /^[-A-Za-z0-9_|.\\ ]+$/;

export interface BacktickScan {
	substitutions: string[];
	doubleQuotedLiterals: string[];
	/** B4·批C（D3）：UNSAFE_DOUBLE_QUOTED_BACKTICK 的 payload 原文（双引号内含 shell 元字符的
	 *  反引号替换——bash 真实执行且守卫无法安全展开；原文供危险段扫描，哨兵仍走 substitutions）。 */
	unsafePayloads: string[];
	/** B4C-R02：首个未闭合反引号在 input 中的起点 index（无未闭合→null）。供调用方把
	 *  「零执行」判定限定在同一解析单元（起点所在行之前的完整命令仍真实执行）。 */
}

export function hasUnescapedBacktickMetachar(payload: string): boolean {
	let escaped = false;
	for (const ch of payload) {
		if (escaped) { escaped = false; continue; }
		if (ch === "\\") { escaped = true; continue; }
		if (ch === "$" || ch === ";" || ch === "|" || ch === "&") return true;
	}
	return false;
}

export function scanBackticks(input: string): BacktickScan {
	const substitutions: string[] = [];
	const doubleQuotedLiterals: string[] = [];
	const unsafePayloads: string[] = [];
	let quote: "'" | '"' | null = null;
	let start = -1;
	let openingQuote: '"' | null = null;
	let escaped = false;
	for (let i = 0; i < input.length; i++) {
		const ch = input[i];
		if (start >= 0) {
			if (escaped) { escaped = false; continue; }
			if (ch === "\\") { escaped = true; continue; }
			if (ch !== "`") continue;
			const payload = input.slice(start, i);
			if (openingQuote === '"') {
				if (SIMPLE_DOUBLE_QUOTED_BACKTICK.test(payload) && !hasUnescapedBacktickMetachar(payload)) doubleQuotedLiterals.push(payload);
				else { substitutions.push(UNSAFE_DOUBLE_QUOTED_BACKTICK); unsafePayloads.push(payload); }
			} else substitutions.push(payload);
			start = -1;
			openingQuote = null;
			continue;
		}
		if (quote === "'") {
			if (ch === "'") quote = null;
			continue;
		}
		if (escaped) { escaped = false; continue; }
		if (ch === "\\") { escaped = true; continue; }
		if (ch === "'") { quote = "'"; continue; }
		if (ch === '"') { quote = quote === '"' ? null : '"'; continue; }
		if (ch === "`") { start = i + 1; openingQuote = quote; }
	}
	if (start >= 0) substitutions.push(UNCLOSED_BACKTICK);
	return { substitutions, doubleQuotedLiterals, unsafePayloads };
}

export function backtickSubstitutions(input: string): string[] {
	return scanBackticks(input).substitutions;
}

export function substitutionPayloads(input: string): string[] {
	return [...commandSubstitutions(input), ...backtickSubstitutions(input)];
}

export function shellWrapperPayloads(input: string): string[] {
	const payloads = substitutionPayloads(input);
	for (const segment of shellSegments(input)) {
		const words = executableWords(segment, true);
		const executable = path.basename(words[0] || "").toLowerCase();
		if (["sh", "bash", "zsh"].includes(executable)) {
			const cIndex = words.findIndex((word, index) => index > 0 && /^-[A-Za-z]*c[A-Za-z]*$/.test(word));
			let payloadIndex = cIndex + 1;
			if (words[payloadIndex] === "--") payloadIndex++;
			if (cIndex >= 0 && words[payloadIndex]) payloads.push(words[payloadIndex]);
		}
		if (executable === "eval" && words.length > 1) payloads.push(words.slice(1).join(" "));
	}
	return payloads;
}

export function containsDownloader(input: string): boolean {
	return shellSegments(input).some((segment) => {
		const executable = path.basename(executableWords(segment, true)[0] || "").toLowerCase();
		return executable === "curl" || executable === "wget";
	});
}

// ── P3（8月迭代第三轮复盘）：heredoc 字面量放行 ──
// 实战误报：用 heredoc 写 markdown/代码文件时，body 里的反引号代码段、`while True:`、
// `input(` 等字面文本被当成真实 shell/Python 片段拦截。引用定界符（<< 'EOF'）的 body 是
// 纯字面文本，零执行；未引用定界符的 body 在展开期会执行 $()/`` 替换，需保留检查。
export interface HeredocSplit {
	/** 剥除 heredoc body 与精确闭合定界行后的可执行域文本（引入行/容忍闭合行/替换边界行保留原文）。 */
	stripped: string;
	/** 未引用定界符的 heredoc body（其 $()/反引号替换在展开期真实执行，需递归检查；含 EOF 未闭合
	 *  与替换边界定稿的 body——两类场景 bash 实测展开均执行，见 N2 报告地面真值探针）。 */
	unquotedBodies: string[];
	/** 精确闭合的定界行清单（line=输入行号 0 起；delimiter=定界词）。容忍闭合与未闭合不在列。 */
	closingDelimiters: Array<{ line: number; delimiter: string }>;
}

/** heredoc 引入（逻辑行内识别）：delimiter=定界词，dash=`<<-`，quoted=定界词带引号。 */
interface HeredocIntroInfo {
	delimiter: string;
	dash: boolean;
	quoted: boolean;
}

const HEREDOC_DELIM_WORD = /^[A-Za-z_][\w-]*$/;

/** 精确闭合（bash 口径，N2 实测锁定）：整行恰等于定界词；`<<-` 允许剥前导 tab。尾随空白/CRLF/
 *  无 dash 的前导 tab 均不闭合（bash 视这些行为 body）——它们落入容忍闭合分支保留在可执行域。 */
function isExactHeredocClose(line: string, delimiter: string, dash: boolean): boolean {
	return dash ? line.replace(/^\t+/, "") === delimiter : line === delimiter;
}

/** 容忍闭合（fail-closed 保守口径，与旧版一致）：剥前导 tab 后首词等于定界词。bash 视这类行为
 *  body（数据），但守卫无法证伪其可执行性——body 在此结束，该行保留在可执行域供各入口检查。 */
function isTolerantHeredocClose(line: string, delimiter: string): boolean {
	return line.replace(/^\t+/, "").split(/\s/)[0] === delimiter;
}

/** 替换边界观察器：heredoc 引入逻辑行结束时处于未闭合 $()/<( )/`（反引号）上下文时，body 扫描
 *  期间检测配平 `)`（弹出的栈顶须为命令/进程替换）或闭合反引号——bash 在命令替换边界终止未闭合
 *  heredoc（G2-A-02 实测：`x=$(cat <<node⏎x⏎)⏎node` 的外层 node 真实执行；边界前已收集的
 *  unquoted body 展开亦实测执行）。无未闭合上下文时返回 null（零成本短路）。 */
interface HeredocBoundaryWatcher {
	/** 扫描一行（有状态：引号/栈跨行延续）；命中边界返回 true。 */
	closesAt(line: string): boolean;
	/** 从当前状态克隆（前瞻探测用，不动本体状态）。 */
	clone(): HeredocBoundaryWatcher;
	/** 边界命中后的残余替换上下文（同步回普通态扫描器）。 */
	residual(): { stack: Array<"c" | "s">; backtick: boolean };
	/** 当前未闭合替换栈深（B3-01：body 行归属层的当前深度）。 */
	depth(): number;
	/** 最近一次边界命中的类型（backtick=反引号闭合；paren=替换配平 )）；仅紧跟 true 返回后读取有意义。 */
	lastBoundaryKind(): "backtick" | "paren" | null;
}

interface BoundaryScanState {
	stack: Array<"c" | "s">;
	backtick: boolean;
	quote: string | null;
	escaped: boolean;
}

function makeHeredocBoundaryWatcher(stack0: Array<"c" | "s">, backtick0: boolean, state0?: BoundaryScanState): HeredocBoundaryWatcher | null {
	if (!state0 && stack0.length === 0 && !backtick0) return null;
	let s: BoundaryScanState = state0 ? { ...state0, stack: [...state0.stack] } : { stack: [...stack0], backtick: backtick0, quote: null, escaped: false };
	let lastKind: "backtick" | "paren" | null = null;
	return {
		closesAt(line: string): boolean {
			const entryDepth = s.stack.length; // 行首栈深：本行内开合的替换（内联 $(x)/反引号）不构成外层边界
			const entryBacktick = s.backtick; // 行首已开启的反引号才在闭合时构成边界
			let fired = false;
			for (let k = 0; k < line.length; k++) {
				const ch = line[k];
				if (s.escaped) { s.escaped = false; continue; }
				if (ch === "\\" && s.quote !== "'") { s.escaped = true; continue; }
				if (s.quote) { if (ch === s.quote) s.quote = null; continue; }
				if (ch === "'" || ch === '"') { s.quote = ch; continue; }
				if (ch === "`") {
					if (s.backtick) { if (entryBacktick) { fired = true; lastKind = "backtick"; s.backtick = false; break; } s.backtick = false; continue; }
					s.backtick = true; continue;
				}
				if (ch === "$" && line[k + 1] === "(") { s.stack.push("c"); k++; continue; }
				if (ch === "(") { s.stack.push("s"); continue; }
				if (ch === ")") {
					const top = s.stack.pop();
					// 仅当弹出的命令/进程替换在行首已开启（栈深低于行首）才是外层边界；嵌套 $( $(… 的
					// 内层闭合同样命中（E5 实测：内层 ) 终止 pending heredoc）。
					if (top === "c" && s.stack.length < entryDepth) { fired = true; lastKind = "paren"; break; }
					continue;
				}
			}
			// B3-02：heredoc body 是物理行域——行末反斜杠是字面数据，不得把 escape 状态带入下一行
			//（被物理行切分省略的换行真实存在：`\` 行后紧邻的 `)` 不得被当作转义字符跳过）。
			s.escaped = false;
			return fired;
		},
		clone(): HeredocBoundaryWatcher {
			return makeHeredocBoundaryWatcher([], false, s)!;
		},
		residual: (): { stack: Array<"c" | "s">; backtick: boolean } => ({ stack: [...s.stack], backtick: s.backtick }),
		depth: (): number => s.stack.length + (s.backtick ? 1 : 0), // B3-R01：反引号占位帧计入层属身份
		lastBoundaryKind: (): "backtick" | "paren" | null => lastKind,
	};
}

/** `<<[-]?[空白]*(逻辑词)` 匹配（调用点已确认 src[j:j+2]==="<<" 且非 <<<）。
 *  B3-T02：定界词按「逻辑词」完整拼接——词由 bare 字符、引号片段（含空引号）、转义字符与续行拼接
 *  组成；每个成分都可证明为字面（引号片段仅含 [\w-]，无 $/反引号/未闭合）时，真实定界词＝拼接
 *  结果，正常识别：`<<'EOF'\`⏎''` 的真词仍是 EOF（空引号不延长词）、`<<'E'\`⏎OF` 的真词是 EOF、
 *  `<<\`⏎'EOF'` 定界词前置续行同样识别（bash 实测：续行属词法拼接，先于分词消除）。含不可证明
 *  成分（`E$F` 的 $ 展开依赖环境；词跨断行）→ 不当引入，后续行保留可执行域（fail-closed）。 */
function matchHeredocIntro(src: string, j: number): { intro: HeredocIntroInfo; next: number } | null {
	let k = j + 2;
	let dash = false;
	if (src[k] === "-") { dash = true; k++; }
	while (src[k] === " " || src[k] === "\t") k++;
	let word = "";
	let quoted = false;
	let ok = true;
	let p = k;
	for (;;) {
		const c = src[p];
		if (c === undefined) break;
		if (c === "\\" && (src[p + 1] === "\n" || (src[p + 1] === "\r" && src[p + 2] === "\n"))) {
			p += src[p + 1] === "\r" ? 3 : 2; // 续行拼接：逻辑词在此延续
			while (src[p] === " " || src[p] === "\t") p++; // 拼接后的词间空白（`<<\`⏎ 'EOF'`）
			continue;
		}
		if (c === "\\" && src[p + 1] !== undefined && src[p + 1] !== "\n" && src[p + 1] !== "\r") {
			word += src[p + 1]; // 转义字符＝字面成分
			p += 2;
			continue;
		}
		if (c === "'" || c === '"') {
			const close = src.indexOf(c, p + 1);
			if (close < 0) { ok = false; break; } // 引号未闭合/跨断行：异形，不当引入
			const seg = src.slice(p + 1, close);
			if (!/^[A-Za-z0-9_-]*$/.test(seg)) { ok = false; break; } // 片段含元字符：不可证明为字面
			quoted = true;
			word += seg;
			p = close + 1;
			continue;
		}
		if (/[A-Za-z0-9_-]/.test(c)) { word += c; p++; continue; }
		break; // 空白/操作符/其它字符：逻辑词终止
	}
	if (!ok) return null;
	if (!word || !HEREDOC_DELIM_WORD.test(word)) return null; // 空词/首字符约束
	// 词终止后继仍是词字符（`$`/反引号/`.` 等）：真实词未被证明完整（含展开或字符集外成分）→
	// 不当引入，后续行保留可执行域（fail-closed；B3-03/已披露保守面：E$F 家族）。
	const after = src[p];
	if (after !== undefined && !/[\s|&;()<>]/.test(after)) return null;
	return { intro: { delimiter: word, dash, quoted }, next: p };
}

/** 拆分 heredoc（ev-20261012-8c51c0/af9e9a/647bc5/551137 结构性重写，N2 批）：
 *  - 引入识别在引号/注释感知的字符扫描上进行（单/双引号、$'…'、注释、转义、herestring <<< 内的
 *    `<<X` 不开启 heredoc——伪引入后续行留在可执行域）；反斜杠续行并入同一逻辑行
 *    （`cat <<EOF \`⏎`| cat` 的引入与管道同属一个逻辑命令，闭合剔除不会与后续命令发生词法拼接——G2-A-01）。
 *  - 精确闭合定界行（整行恰等于定界词；`<<-` 剥前导 tab）是语法标记：从可执行域剔除（af9e9a）。
 *  - 容忍闭合（首词等于定界词但非整行相等）：body 在此结束、该行保留在可执行域（fail-closed）；
 *    无任何闭合迹象时剩余行按 body 处理（bash EOF 闭合：unquoted 展开实测执行，与旧版一致）。
 *  - 命令替换/进程替换/反引号边界：未闭合 heredoc 在配平 `)` 或闭合反引号处终止，其后回到
 *    可执行域（G2-A-02）；边界行属外层语法、原样保留。
 *  永不抛错。 */
export function splitHeredocs(input: string): HeredocSplit {
	try {
		const src = String(input);
		const n = src.length;
		const outParts: string[] = [];
		const unquoted: string[] = [];
		const closings: Array<{ line: number; delimiter: string }> = [];
		// 普通态跨逻辑行持续追踪的替换上下文（c=$(/<(/>( 命令/进程替换；s=裸括号子 shell）
		let substStack: Array<"c" | "s"> = [];
		let inBacktick = false;
		// B3-T01：替换上下文实例身份——同深度先后两个替换（反引号/cmdsub）是不同实例；引入行内
		// 已闭合的实例所拥有的 heredoc 在该替换边界就地定稿（bash：EOF 定稿，不读后续行），不得
		// 留在待消费集合污染同深度的后续替换。
		let ctxId = 0;
		const ctxOwnerIds: number[] = []; // 与 substStack 平行：每个括号帧的实例 id
		let btOwnerId: number | null = null; // 未闭合反引号实例 id
		let i = 0;
		let lineIndex = 0;
		while (i < n) {
			// ── 普通态：扫描一个逻辑行（续行/跨行引号并入），识别真实 heredoc 引入 ──
			const logicalStart = i;
			const intros: HeredocIntroInfo[] = [];
			const introDepths: number[] = []; // 每个引入捕获时刻的完整上下文层属（B3-R01）：括号栈深+反引号占位帧
			const introOwners: Array<number | null> = []; // 捕获时刻最内层开启替换的实例 id（B3-T01；null=顶层）
			let quote: "'" | '"' | null = null;
			let escaped = false;
			let comment = false;
			let j = i;
			let lineEnd = -1; // 逻辑行终止换行的 offset；-1=EOF 结束
		while (j < n) {
				const ch = src[j];
				if (comment) { if (ch === "\n") { lineEnd = j; break; } j++; continue; } // 注释吞到行尾（实测反斜杠不延续注释）
				if (escaped) { escaped = false; j++; continue; }
				if (ch === "\\" && quote !== "'") {
					if (src[j + 1] === "\n") { j += 2; continue; }
					if (src[j + 1] === "\r" && src[j + 2] === "\n") { j += 3; continue; }
					escaped = true; j++; continue;
				}
				if (quote) { if (ch === quote) quote = null; j++; continue; }
				if (ch === "'" || ch === '"') { quote = ch; j++; continue; }
				if (ch === "#" && (j === logicalStart || /\s/.test(src[j - 1]))) { comment = true; j++; continue; }
				if (ch === "<" && src[j + 1] === "<") {
					if (src[j + 2] === "<") { j += 3; continue; } // <<< herestring 不是 heredoc
					const intro = matchHeredocIntro(src, j);
					if (intro) {
						intros.push(intro.intro);
						introDepths.push(substStack.length + (inBacktick ? 1 : 0));
						introOwners.push(ctxOwnerIds.length ? ctxOwnerIds[ctxOwnerIds.length - 1]! : btOwnerId);
						j = intro.next; continue;
					}
					j += 2; continue; // 无有效定界词（如 `<< $(x)`）：不当引入
				}
				if (ch === "$" && src[j + 1] === "(") { substStack.push("c"); ctxOwnerIds.push(++ctxId); j += 2; continue; }
				if ((ch === "<" || ch === ">") && src[j + 1] === "(") { substStack.push("c"); ctxOwnerIds.push(++ctxId); j += 2; continue; }
				if (ch === "(") { substStack.push("s"); ctxOwnerIds.push(++ctxId); j++; continue; }
				if (ch === ")") { substStack.pop(); ctxOwnerIds.pop(); j++; continue; }
				if (ch === "`") { if (inBacktick) { btOwnerId = null; } else { btOwnerId = ++ctxId; } inBacktick = !inBacktick; j++; continue; }
				if (ch === "\n") { lineEnd = j; break; }
				j++;
			}
			const logicalEnd = lineEnd >= 0 ? lineEnd + 1 : n;
			outParts.push(src.slice(logicalStart, logicalEnd));
			lineIndex += src.slice(logicalStart, logicalEnd).split("\n").length - 1;
			i = logicalEnd;
			if (!intros.length) continue;
			// ── body 消费态：按 shell 上下文层属解析闭合（B3-01/B3-R01：pending 携带所属完整上下文层，
			// 内层替换/反引号结束只终止内层拥有的 heredoc，外层重定向存活继续消费）──
			// 层属身份＝括号栈深 + 反引号占位帧（B3-R01：反引号不增括号栈深，但它是独立的拥有层——
			// `cat <<'A' \`cat <<'B'` 中 A 属 0 层、B 属反引号层 1，B 的 body 先消费，闭合后内层命令
			// 可见、A 存活到反引号外）。每行归属当前最内层仍开启的解析上下文：contextDepth ===
			// 当前层属的 pending 消费 body；更深层无 pending（内层命令段）→ 行保留可见（真实执行域）；
			// 边界（) 配平或反引号闭合）只终止层属大于边界后残余层的 pending（统一帧数比较，无需
			// 反引号特判），浅层 pending 存活。前瞻优先级（G2-A-03）：边界/精确闭合 先于 容忍闭合。
			interface PendingHeredoc { info: HeredocIntroInfo; contextDepth: number; collected: string[]; }
			// B3-T01：引入行内已闭合替换实例拥有的 heredoc 就地定稿（bash：该替换 EOF 定稿、body 不读
			// 后续行——`cat <<'A' \`cat <<'B' \` \`cat <<'C'` 中 B 属第一个反引号，行内已闭合即终结，
			// 不得以同帧数身份污染第二个反引号里的 C）。
			const aliveOwners = new Set<number>([...ctxOwnerIds, ...(btOwnerId !== null ? [btOwnerId] : [])]);
			const pending: PendingHeredoc[] = [];
			intros.forEach((info, idx) => {
				const owner = introOwners[idx] ?? null;
				if (owner !== null && !aliveOwners.has(owner)) return; // 陈旧实例：就地定稿（空 body），不入待消费集合
				pending.push({ info, contextDepth: introDepths[idx] ?? 0, collected: [] as string[] });
			});
			const flushPendingAt = (idx: number): void => {
				const entry = pending[idx]!;
				const text = entry.collected.join("\n");
				if (!entry.info.quoted && text) unquoted.push(text);
			};
			const lineAt = (offset: number): { text: string; end: number } => {
				let nl = src.indexOf("\n", offset);
				if (nl < 0) nl = n;
				return { text: src.slice(offset, nl), end: nl };
			};
			let watcher: HeredocBoundaryWatcher | null = makeHeredocBoundaryWatcher(substStack, inBacktick);
			const liveDepth = (): number => (watcher ? watcher.depth() : 0);
			const consumeBodyTo = (stop: number, target: PendingHeredoc): void => {
				while (i < stop) {
					const line = lineAt(i);
					if (watcher) watcher.closesAt(line.text); // 状态推进（结果恒 false：探测克隆同序扫描未命中）
					target.collected.push(line.text);
					i = line.end + 1;
					lineIndex++;
				}
			};
			while (pending.length > 0) {
				if (i > n) { for (let p = 0; p < pending.length; p++) flushPendingAt(p); pending.length = 0; break; }
				const depth = liveDepth();
				let consumingIdx = -1;
				for (let p = 0; p < pending.length; p++) if (pending[p]!.contextDepth === depth) { consumingIdx = p; break; }
				if (consumingIdx < 0) {
					// 内层可见窗：当前层无 pending——行属于更深开启上下文的内层真实执行域，保留可见；
					// watcher 扫描推进（边界可能在本行闭合一层：统一帧数终止被闭合层拥有的 pending）
					const line = lineAt(i);
					const boundaryHit = watcher ? watcher.closesAt(line.text) : false;
					if (boundaryHit) {
						const residual = liveDepth();
						for (let p = pending.length - 1; p >= 0; p--) {
							if (pending[p]!.contextDepth > residual) { flushPendingAt(p); pending.splice(p, 1); }
						}
					}
					outParts.push(line.end < n ? src.slice(i, line.end + 1) : src.slice(i));
					i = line.end + 1; lineIndex++;
					continue;
				}
				const consuming = pending[consumingIdx]!;
				// 前瞻：首个「替换边界」或「精确闭合」行；顺带记录首个容忍闭合行（探测用克隆，不动本体）
				const probe = watcher ? watcher.clone() : null;
				let exactOff = -1;
				let boundaryOff = -1;
				let tolOff = -1;
				let k = i;
				while (k <= n) {
					const line = lineAt(k);
					if (probe && probe.closesAt(line.text)) { boundaryOff = k; break; }
					if (isExactHeredocClose(line.text, consuming.info.delimiter, consuming.info.dash)) { exactOff = k; break; }
					if (tolOff < 0 && isTolerantHeredocClose(line.text, consuming.info.delimiter)) tolOff = k;
					if (line.end >= n) break;
					k = line.end + 1;
				}
				if (boundaryOff >= 0) {
					// 边界（) 配平或反引号闭合）：body=[i, boundaryOff) 归当前层；层属大于边界后残余层
					// 的 pending 全部终止定稿（E8：unquoted 展开仍执行——反引号/替换占位帧在残余层深里扣除）；
					// 边界行属外层语法保留；浅层 pending 存活。统一帧数比较，无反引号特判（B3-R01）。
					consumeBodyTo(boundaryOff, consuming);
					watcher = probe; // 探测已扫到边界行（含配平 pop/反引号闭合），本体接管其状态
					const residualDepth = liveDepth();
					for (let p = pending.length - 1; p >= 0; p--) {
						if (pending[p]!.contextDepth > residualDepth) { flushPendingAt(p); pending.splice(p, 1); }
					}
					const line = lineAt(i);
					outParts.push(line.end < n ? src.slice(i, line.end + 1) : src.slice(i));
					i = line.end + 1; lineIndex++;
					continue;
				}
				if (exactOff >= 0) {
					// 精确闭合：body 行丢弃、闭合定界行剔除（语法标记，af9e9a）；同层后续引入依次接续
					consumeBodyTo(exactOff, consuming);
					closings.push({ line: lineIndex, delimiter: consuming.info.delimiter });
					i = lineAt(exactOff).end + 1; lineIndex++;
					flushPendingAt(consumingIdx); pending.splice(consumingIdx, 1);
					watcher = probe; // 探测已扫过 [i..exactOff]，后续 pending 从该状态续扫
					continue;
				}
				if (tolOff >= 0) {
					// 容忍闭合（无精确闭合时的 fail-closed 兕底）：body 丢弃、容忍行保留在可执行域
					consumeBodyTo(tolOff, consuming);
					flushPendingAt(consumingIdx); pending.splice(consumingIdx, 1);
					const line = lineAt(i);
					if (watcher) watcher.closesAt(line.text);
					outParts.push(line.end < n ? src.slice(i, line.end + 1) : src.slice(i));
					i = line.end + 1; lineIndex++;
					continue;
				}
				// 无精确闭合/边界/容忍：EOF 闭合——剩余全部 body（bash EOF 语义：unquoted 展开实测执行）
				consumeBodyTo(n + 1, consuming);
				for (let p = 0; p < pending.length; p++) flushPendingAt(p);
				pending.length = 0;
				break;
			}
			// body 区域结束：残余替换上下文同步回普通态扫描器（后续逻辑行/边界追踪连续）
			if (watcher) {
				const residual = watcher.residual();
				substStack = residual.stack;
				inBacktick = residual.backtick;
			}
		}
		return { stripped: outParts.join(""), unquotedBodies: unquoted, closingDelimiters: closings };
	} catch {
		return { stripped: input, unquotedBodies: [], closingDelimiters: [] };
	}
}

// ── ev-20260916-8c55a2：进程替换 <(…) / >(…) 参数边界识别 ──
// 实战误报：`diff <(svn propget … && svn info …) local.txt` exit=1 时，词法层把替换内部的
// `&&` 当顶层控制符切段，`svn info …)` 成了「并列顶层命令」——不在语义退出白名单 → 误追加
// bash 诊断。本函数把 <(…)/>(…) 整体剥除（保留 payload 供上层另行处置），顶层判定只看
// 剥除后的段结构；不执行替换内容，子命令真实错误仍由 stderr 签名兜底（不能从 exit=1
// 推断子命令一定成功）。未闭合形态按普通字符回退（bash 亦会报语法错，不值得拦）。
export interface ProcessSubstitutionSplit {
	/** 剥除全部 <(…)/>(…)（含定界符）后的顶层命令文本。 */
	stripped: string;
	/** 各替换的内部 payload（按出现顺序）。 */
	payloads: string[];
}

export function stripProcessSubstitutions(input: string): ProcessSubstitutionSplit {
	const payloads: string[] = [];
	let out = "";
	let i = 0;
	const n = input.length;
	while (i < n) {
		const ch = input[i];
		if ((ch === "<" || ch === ">") && input[i + 1] === "(") {
			let depth = 1, quote: string | null = null, escaped = false;
			let j = i + 2;
			for (; j < n; j++) {
				const c = input[j];
				if (escaped) { escaped = false; continue; }
				if (c === "\\" && quote !== "'") { escaped = true; continue; }
				if (quote) { if (c === quote) quote = null; continue; }
				if (c === "'" || c === '"') { quote = c; continue; }
				if (c === "(") depth++;
				else if (c === ")" && --depth === 0) break;
			}
			if (j >= n) { out += ch; i++; continue; } // 未闭合：按普通字符处理
			payloads.push(input.slice(i + 2, j));
			i = j + 1;
			continue;
		}
		out += ch;
		i++;
	}
	return { stripped: out, payloads };
}


// ══════════════════ ev-20260922-e44fe9 / 2d5a76（B0）：可执行 shell 语义视图 ══════════════════
// 背景：ShellTokenMeta 只留 text，不能证明引号内的 ";" 是分隔符还是数据；splitHeredocs 只有
// guards 侧部分入口消费——assertCommitSafe 没有剥除 heredoc，导致同一命令（python3 - <<'PYEOF'
// body 含奇数反引号）在 assertSafeCommand 放行、assertCommitSafe 误拦 UNCLOSED_BACKTICK（入口
// 不对称，ev-20260922-2d5a76）。本节提供单源语义视图 analyzeExecutableShell：span 语义 token
//（kind: word|operator + 原始 offset）、heredoc 剥除后的主命令、真实展开子命令、解析错误分类。
// 所有守卫入口（危险命令/提交/stash 串联/子 Agent stash）共用该视图，不再各自拼预处理。

/** span 语义 token：kind 区分 word/operator，start/end 是相对本次词法输入的原始 offset。
 *  word 的 text 是引号剥离后的 payload；$() 与反引号替换作为原子成分并入所在 word（其内部的
 *  ;/|/& 不再被误切为控制符）；unquotedVar 与 ShellTokenMeta 同义（引号外参数展开）。 */
export interface ShellTokenSpan {
	kind: "word" | "operator";
	text: string;
	start: number;
	end: number;
	unquotedVar: boolean;
}

/** span 视图的控制操作符集合：比 legacy CONTROL_OPERATORS 多一个单 &（后台串联——
 *  `git stash push & git stash pop` 是真实链）；&>/>& 重定向复合词按字面 word 起头不拆。 */
const SPAN_CONTROL_OPERATORS = new Set(["&&", "||", ";", "|", "\n", "&"]);

/** $() 配平扫描：返回闭合括号后的独占 end，未闭合返回 -1（引号/转义按 commandSubstitutions 同规则）。 */
function matchCommandSubstitutionSpan(input: string, start: number): number {
	let depth = 1;
	let quote: string | null = null;
	let escaped = false;
	for (let j = start; j < input.length; j++) {
		const ch = input[j];
		if (escaped) { escaped = false; continue; }
		if (ch === "\\" && quote !== "'") { escaped = true; continue; }
		if (quote) { if (ch === quote) quote = null; continue; }
		if (ch === "'" || ch === '"') { quote = ch; continue; }
		if (ch === "(") depth++;
		else if (ch === ")") { if (--depth === 0) return j + 1; }
	}
	return -1;
}

/** 反引号配对扫描：返回闭合反引号后的独占 end，未闭合返回 -1（转义/内部引号按 scanBackticks 同规则）。 */
function matchBacktickSpan(input: string, start: number): number {
	let quote: string | null = null;
	let escaped = false;
	for (let j = start; j < input.length; j++) {
		const ch = input[j];
		if (escaped) { escaped = false; continue; }
		if (ch === "\\") { escaped = true; continue; }
		if (quote) { if (ch === quote) quote = null; continue; }
		if (ch === "'" || ch === '"') { quote = ch; continue; }
		if (ch === "`") return j + 1;
	}
	return -1;
}

/** 未引用 heredoc body 的反引号配对（引号盲 + heredoc 转义规则：\\ 只转义 $ ` \\ 三者）。 */
function matchBlindBacktickSpan(body: string, start: number): number {
	let j = start;
	while (j < body.length) {
		const ch = body[j];
		if (ch === "\\" && (body[j + 1] === "$" || body[j + 1] === "`" || body[j + 1] === "\\")) { j += 2; continue; }
		if (ch === "`") return j + 1;
		j++;
	}
	return -1;
}

/** span 语义 tokenizer：与 tokenizeShell 同规则（引号 payload 保留、注释吞到行尾、&&/|| 双字符
 *  优先），差异：① $()/反引号替换作为原子成分并入 word（内部控制符不切分）；② 单 & 在词边界
 *  是控制操作符（&> 重定向复合词除外）。未闭合替换/反引号吞到串尾作 word（解析错误由
 *  scanBackticks/heredocExpansionPayloads 单独报告）；本函数不报错、永不抛出。 */
export function tokenizeShellSpans(input: string): ShellTokenSpan[] {
	const tokens: ShellTokenSpan[] = [];
	let token = "";
	let tokenStart = -1;
	let unquotedVar = false;
	let quote: "'" | '"' | null = null;
	let escaped = false;
	const pushWord = (end: number): void => {
		if (tokenStart >= 0) tokens.push({ kind: "word", text: token, start: tokenStart, end, unquotedVar });
		token = "";
		tokenStart = -1;
		unquotedVar = false;
	};
	const pushOperator = (text: string, start: number, end: number): void => {
		tokens.push({ kind: "operator", text, start, end, unquotedVar: false });
	};
	for (let i = 0; i < input.length; i++) {
		const ch = input[i];
		if (escaped) { token += ch; escaped = false; continue; }
		if (ch === "\\" && quote !== "'") {
			// ev-20261012-647bc5：行续接同 tokenizeShell——引号外 \+换行（含 \r\n）词法层丢弃，
			// span 视图不再产出含换行文本的 word（G2-A-01：此类词曾把续行拼接后的真实命令并成首段参数）。
			if (input[i + 1] === "\n") { i++; continue; }
			if (input[i + 1] === "\r" && input[i + 2] === "\n") { i += 2; continue; }
			if (tokenStart < 0) tokenStart = i;
			escaped = true; continue;
		}
		if (quote) {
			if (ch === quote) quote = null;
			else token += ch;
			continue;
		}
		if (ch === "'" || ch === '"') { quote = ch; if (tokenStart < 0) tokenStart = i; continue; }
		if (ch === "#" && tokenStart < 0 && (i === 0 || /\s/.test(input[i - 1]))) {
			while (i < input.length && input[i] !== "\n") i++;
			pushOperator("\n", i, Math.min(i + 1, input.length));
			continue;
		}
		const pair = input.slice(i, i + 2);
		if (pair === "&&" || pair === "||") { pushWord(i); pushOperator(pair, i, i + 2); i++; continue; }
		if (ch === ";" || ch === "|" || ch === "\n") { pushWord(i); pushOperator(ch, i, i + 1); continue; }
		if (ch === "&" && tokenStart < 0 && input[i + 1] !== ">") { pushOperator("&", i, i + 1); continue; }
		if (/\s/.test(ch)) { pushWord(i); continue; }
		if (tokenStart < 0) tokenStart = i;
		if (ch === "$") {
			if (input[i + 1] === "(") {
				const end = matchCommandSubstitutionSpan(input, i + 2);
				const stop = end > 0 ? end : input.length;
				token += input.slice(i, stop);
				unquotedVar = true;
				i = stop - 1;
				continue;
			}
			unquotedVar = true;
		}
		if (ch === "`") {
			const end = matchBacktickSpan(input, i + 1);
			const stop = end > 0 ? end : input.length;
			token += input.slice(i, stop);
			i = stop - 1;
			continue;
		}
		token += ch;
	}
	if (escaped) token += "\\";
	pushWord(input.length);
	return tokens;
}

/** span token → 可执行段序列（控制操作符切分；段内 token 保留 span 与语义标记）。 */
export function segmentShellSpans(tokens: ShellTokenSpan[]): ShellTokenSpan[][] {
	const result: ShellTokenSpan[][] = [];
	let current: ShellTokenSpan[] = [];
	for (const token of tokens) {
		if (token.kind === "operator" && SPAN_CONTROL_OPERATORS.has(token.text)) {
			if (current.length) result.push(current);
			current = [];
		} else current.push(token);
	}
	if (current.length) result.push(current);
	return result;
}

export const UNCLOSED_COMMAND_SUBSTITUTION = "__AMAGI_UNCLOSED_COMMAND_SUBSTITUTION__";

export interface HeredocExpansionScan {
	/** 展开期真实执行的 payload（$() 与反引号内容）。 */
	payloads: string[];
	/** 未闭合替换（body 内 $() 或反引号无配对）——bash 执行期报语法错，按解析错误上报。 */
	parseError: string | null;
}

/** 未引用 heredoc body 的展开扫描（引号盲：body 内引号不抑制展开；\$ \` \\ 转义按 heredoc 规则）。 */
export function heredocExpansionPayloads(body: string): HeredocExpansionScan {
	const payloads: string[] = [];
	let i = 0;
	while (i < body.length) {
		const ch = body[i];
		if (ch === "\\" && (body[i + 1] === "$" || body[i + 1] === "`" || body[i + 1] === "\\")) { i += 2; continue; }
		if (ch === "$" && body[i + 1] === "(") {
			const end = matchCommandSubstitutionSpan(body, i + 2);
			if (end < 0) return { payloads, parseError: UNCLOSED_COMMAND_SUBSTITUTION };
			payloads.push(body.slice(i + 2, end - 1));
			i = end;
			continue;
		}
		if (ch === "`") {
			const end = matchBlindBacktickSpan(body, i + 1);
			if (end < 0) return { payloads, parseError: UNCLOSED_BACKTICK };
			payloads.push(body.slice(i + 1, end - 1));
			i = end;
			continue;
		}
		i++;
	}
	return { payloads, parseError: null };
}

/** 可执行 shell 语义视图（单源）：所有入口共享的 heredoc/替换/wrapper/解析错误分类。 */
export interface ExecutableShellView {
	/** 剥除全部 heredoc body 与精确闭合定界行后的主命令（引入行/容忍闭合行保留；与
	 *  splitHeredocs().stripped 同口径——ev-20261012 N2 起精确闭合行也剔除）。 */
	stripped: string;
	/** 未引用定界符的 heredoc body 原文（引用定界符 body 只作数据，不在此列）。 */
	unquotedBodies: string[];
	/** stripped 可执行域真实执行的 $()/反引号 payload（引号内数据不提取；哨兵错误不混入）。 */
	substitutionPayloads: string[];
	/** stripped 上 sh/bash/zsh -c 与 eval 的包裹 payload（不含 substitutionPayloads）。 */
	wrapperPayloads: string[];
	/** 未引用 body 按展开规则扫描出的真实执行 payload（body 内引号不抑制展开）。 */
	unquotedBodyPayloads: string[];
	/** 双引号内简单反引号字面量（既有软提示沿用；不属解析错误）。 */
	doubleQuotedLiterals: string[];
	/** B4·批C（D3）：不可安全展开的双引号内反引号 payload 原文（哨兵在 parseErrors；
	 *  原文供危险段扫描——已识别不可逆段不因解析失败放行）。 */
	unsafeBacktickPayloads: string[];
	/** 可执行域解析错误（UNCLOSED_BACKTICK / UNSAFE_DOUBLE_QUOTED_BACKTICK / UNCLOSED_COMMAND_SUBSTITUTION）。 */
	parseErrors: string[];
	/** span 语义段（控制操作符切分；供串联类守卫按真实可执行段判断）。 */
	segments: ShellTokenSpan[][];
}

/** 统一语义视图：quoted delimiter body 只作数据；unquoted body 的 $()/反引号按 heredoc 展开规则
 *  扫描；可执行域解析错误单独分类（quoted 数据中的不平衡字符不报错）。永不抛出。
 *  注：精确闭合定界行已由 splitHeredocs 结构性剔除（closingDelimiters 单源）——`git stash push …
 *  <<'MSG' … MSG` 不会再产生第二段；本函数不再按名称过滤段（名称过滤会把与定界词同名的真实
 *  命令一并剔出可执行域——G2-A-02 实测放行面，ev-20261012 N2 批移除）。 */
export function analyzeExecutableShell(command: string): ExecutableShellView {
	const { stripped, unquotedBodies } = splitHeredocs(command);
	const segments = segmentShellSpans(tokenizeShellSpans(stripped));
	const backtickScan = scanBackticks(stripped);
	const parseErrors: string[] = [];
	const substitutionPayloads = [...commandSubstitutions(stripped)];
	for (const sub of backtickScan.substitutions) {
		if (sub === UNCLOSED_BACKTICK || sub === UNSAFE_DOUBLE_QUOTED_BACKTICK) parseErrors.push(sub);
		else substitutionPayloads.push(sub);
	}
	const wrapperPayloads: string[] = [];
	for (const segment of segments) {
		const words = executableWords(segment.map((token) => token.text), true);
		const executable = path.basename(words[0] || "").toLowerCase();
		if (["sh", "bash", "zsh"].includes(executable)) {
			const cIndex = words.findIndex((word, index) => index > 0 && /^-[A-Za-z]*c[A-Za-z]*$/.test(word));
			let payloadIndex = cIndex + 1;
			if (words[payloadIndex] === "--") payloadIndex++;
			if (cIndex >= 0 && words[payloadIndex]) wrapperPayloads.push(words[payloadIndex]);
		}
		if (executable === "eval" && words.length > 1) wrapperPayloads.push(words.slice(1).join(" "));
	}
	const unquotedBodyPayloads: string[] = [];
	for (const body of unquotedBodies) {
		const scan = heredocExpansionPayloads(body);
		unquotedBodyPayloads.push(...scan.payloads);
		if (scan.parseError) parseErrors.push(scan.parseError);
	}
	return { stripped, unquotedBodies, substitutionPayloads, wrapperPayloads, unquotedBodyPayloads, doubleQuotedLiterals: backtickScan.doubleQuotedLiterals, unsafeBacktickPayloads: backtickScan.unsafePayloads, parseErrors, segments };
}
