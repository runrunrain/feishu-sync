import * as fs from "node:fs";
import * as path from "node:path";

const SKIP = new Set([".git", "node_modules", ".amagi-worktrees", "dist", "build", "target", ".next"]);
/** Resolve only a unique readable in-workspace basename. Partial scans and links never justify auto-correction. */
export function normalizeMissingInputs<T extends { path: string; required?: boolean }>(cwd: string, inputs: readonly T[], canRead: (abs: string) => boolean,
	producers: readonly { taskId: string; cwd: string; outputs: readonly { path: string }[] }[] = []): { inputs: T[]; notes: string[] } {
	const missing = inputs.filter(i => i.required !== false && !fs.existsSync(path.resolve(cwd, i.path)));
	if (!missing.length) return { inputs: [...inputs], notes: [] };
	const notes: string[] = [], replacements = new Map<string, string>();
	const wanted = new Map<string, string[]>();
	for (const i of missing) {
		const abs = path.resolve(cwd, i.path);
		const upstream = producers.filter(p => p.outputs.some(o => path.resolve(p.cwd, o.path) === abs));
		if (upstream.length) { notes.push(`[输入尚未产出] ${i.path} 由任务 ${upstream.map(p => p.taskId).join("、")} 声明产出，尚未完成；可 wait 后再提交。`); continue; }
		if (abs.startsWith(path.resolve(cwd) + path.sep) && canRead(abs)) wanted.set(path.basename(abs), []);
	}
	let complete = true, visited = 0;
	const queue = wanted.size ? [path.resolve(cwd)] : [];
	while (queue.length && complete) {
		const dir = queue.shift()!;
		let entries: fs.Dirent[];
		try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
		catch { /* lint-exempt:扫描不完整只给候选，不自动改路径 */ complete = false; break; }
		for (const entry of entries) {
			if (++visited > 10000) { complete = false; break; }
			if (entry.isSymbolicLink() || (entry.isDirectory() && SKIP.has(entry.name))) continue;
			const abs = path.join(dir, entry.name);
			if (!canRead(abs)) continue;
			const bucket = wanted.get(entry.name);
			if (bucket && (entry.isDirectory() || entry.isFile())) bucket.push(abs);
			if (entry.isDirectory()) queue.push(abs);
		}
	}
	for (const i of missing) {
		const abs = path.resolve(cwd, i.path);
		if (!abs.startsWith(path.resolve(cwd) + path.sep) || !canRead(abs)) continue;
		if (producers.some(p => p.outputs.some(o => path.resolve(p.cwd, o.path) === abs))) continue;
		const candidates = wanted.get(path.basename(abs)) ?? [];
		if (complete && candidates.length === 1) {
			const actual = path.relative(cwd, candidates[0]!);
			replacements.set(i.path, actual);
			notes.push(`[输入路径归一] ${i.path} → ${actual}（可读工作区内唯一同名候选，已核验存在）。`);
		} else if (candidates.length) notes.push(`[输入路径候选] ${i.path}：${candidates.slice(0, 8).map(p => path.relative(cwd, p)).join("、")}${!complete ? "（扫描未覆盖全部，未自动替换）" : "（多个同名候选，未自动替换）"}。`);
	}
	return { inputs: inputs.map(i => replacements.has(i.path) ? { ...i, path: replacements.get(i.path)! } : i), notes };
}
