/**
 * tui-console.ts — A1b（pi 1.0.2 fullscreen 兼容）：amagi 诊断输出 TUI 安全化。
 *
 * 实测根因（tmux 真机字节流取证，2026-10-04）：pi 1.0.2 fullscreen TUI 用同步更新
 * （ESC[?2026h/l）+ 差分渲染持有 pty；extension 的 console.warn/error/log 以裸字节写入
 * 同一 pty，会覆盖已绘制的 editor/footer 行——渲染器内部缓存认为这些行仍是最新，永不修复
 * → 启动后底部 UI 长期显示为警告文本（表现为「启动挂死」，实测 3/3 复现；重定 stderr 到
 * 文件即恢复）。0.99.x 内嵌渲染器无此问题。pi 的扩展契约通道是 ctx.ui.notify（非阻塞反馈）。
 *
 * 设计（最小入侵，非 TUI 行为零变化）：
 * - `activateTuiDiagSink(ui)`：session_start（ctx.mode==="tui"，leader）安装；session_shutdown 卸载。
 * - `tuiWarn/tuiLog`：sink 未安装时保持 console.warn/log 原语义（rpc/json/print/子进程不变——
 *   既有冒烟对 stderr 的断言不受影响）；sink 安装后聚合（250ms 窗口）经 ctx.ui.notify 呈现
 *   （有界摘要），全文追加落 amagi 数据目录 tui-console.log（可审计）。
 * - 聚合窗口内的多条诊断合并为单条 notify，避免启动预检 N 条警告刷屏。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataFile } from "./data-dir.ts";

type NotifyFn = (message: string, notifyType?: "info" | "warning" | "error") => void;

interface DiagEntry { text: string; level: "warning" | "error" | "info"; at: number }

let notify: NotifyFn | undefined;
let pending: DiagEntry[] = [];
let flushTimer: ReturnType<typeof setTimeout> | undefined;

const FLUSH_WINDOW_MS = 250;
/** notify 正文上限（终端格近似；长文截断引导到落盘全文）。 */
const NOTIFY_BODY_MAX = 700;

function logFilePath(): string {
	try { return amagiDataFile("tui-console.log"); } catch { /* lint-exempt:数据目录解析失败=禁用落盘，仅 notify */ return ""; }
}

function appendLog(lines: string[]): void {
	const file = logFilePath();
	if (!file || lines.length === 0) return;
	try { fs.mkdirSync(path.dirname(file), { recursive: true }); } catch { /* lint-exempt:目录已存在或不可创建=跳过落盘不抛错 */ }
	try {
		fs.appendFileSync(file, lines.map((l) => `${new Date().toISOString()} ${l}`).join("\n") + "\n");
	} catch { /* lint-exempt:落盘失败不影响主流程（notify 仍可达） */ }
}

function flush(): void {
	flushTimer = undefined;
	const batch = pending;
	pending = [];
	if (batch.length === 0) return;
	appendLog(batch.map((e) => `[${e.level}] ${e.text}`));
	if (!notify) return;
	const worst: "info" | "warning" | "error" = batch.some((e) => e.level === "error") ? "error" : batch.some((e) => e.level === "warning") ? "warning" : "info";
	const body = batch.map((e) => e.text).join("\n");
	const shown = body.length > NOTIFY_BODY_MAX ? `${body.slice(0, NOTIFY_BODY_MAX)}…（已截断，全文见 ${logFilePath()}）` : body;
	try { notify(`[amagi] ${batch.length > 1 ? `${batch.length} 条诊断：\n` : ""}${shown}`, worst); } catch { /* lint-exempt:notify 失败不反噬（落盘仍保留全文） */ }
}

function emit(text: string, level: DiagEntry["level"]): void {
	if (!notify) return;
	pending.push({ text, level, at: Date.now() });
	if (flushTimer === undefined) {
		flushTimer = setTimeout(flush, FLUSH_WINDOW_MS);
		try { (flushTimer as { unref?: () => void }).unref?.(); } catch { /* lint-exempt:unref 缺失时定时器照常触发 */ }
	}
}

/** session_start 安装（leader TUI 分支；子进程分支不触达）。幂等。 */
export function activateTuiDiagSink(ui: { notify?: NotifyFn }): void {
	notify = typeof ui?.notify === "function" ? (m, t) => { try { ui.notify!(m, t); } catch { /* lint-exempt:notify 抛错吞掉保诊断不反噬 */ } } : undefined;
}

/** session_shutdown 卸载：未冲刷的诊断立即冲刷，随后恢复 console 原语义。 */
export function deactivateTuiDiagSink(): void {
	if (flushTimer !== undefined) { clearTimeout(flushTimer); try { flush(); } catch { /* lint-exempt:冲刷失败不阻塞卸载 */ } }
	notify = undefined;
}

/** TUI 安全 warn：sink 未安装（非 TUI/子进程）保持 console.warn 原语义。 */
export function tuiWarn(text: string): void {
	if (!notify) { console.warn(text); return; }
	emit(text, "warning");
}

/** TUI 安全 error：sink 未安装保持 console.error 原语义。 */
export function tuiError(text: string): void {
	if (!notify) { console.error(text); return; }
	emit(text, "error");
}

/** TUI 安全 info：sink 未安装保持 console.log 原语义。 */
export function tuiLog(text: string): void {
	if (!notify) { console.log(text); return; }
	emit(text, "info");
}

/** 测试观测：当前 sink 是否激活。 */
export function tuiDiagSinkActive(): boolean {
	return notify !== undefined;
}
