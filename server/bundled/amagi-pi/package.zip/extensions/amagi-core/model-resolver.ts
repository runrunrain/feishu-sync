/**
 * model-resolver.ts — 多级覆盖模型解析 + profile 选择 + schema 校验 + thinking 精确匹配 + model 元数据校验。
 *
 * 配置优先级链（高 → 低）：
 *   1. 参数 --model（paramModel）
 *   2. 项目 amagi.json（cwd/amagi.json）角色覆盖
 *   3. 全局 amagi.json（~/.pi/agent/amagi.json，尊重 PI_CODING_AGENT_DIR）角色覆盖
 *   4. profile 默认（profiles/<profile>.json：agentOverrides → tier model）
 *   5. agent frontmatter model
 *   6. ctx fallbackModel
 *
 * 项目级与全局级 agents 合并（项目键优先）；profile 选择：项目 > 全局 > tiered。
 * 全局文件首次加载不存在时自动写入自描述默认内容（对齐 opencode 全局配置体验）。
 *
 * M1 修复：生产路径注入已知角色列表（由 createTaskTool 从 discoverAgents 传入）。
 * M2 修复：validateModelSpec 接收 model 元数据（reasoning/thinkingLevelMap），校验请求档位合法性。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import { createHash } from "node:crypto";
import type { AgentConfig, AgentType } from "./agents-loader.ts";
import { codexModelIdFromSpec, synthesizeFrontlineModel } from "./codex-models.ts";

export interface Profiles {
	leader?: string | null;
	fast?: string | null;
	work?: string | null;
	expert?: string | null;
	agentOverrides?: Record<string, string>;
}

export interface UserConfig {
	profile?: "tiered" | "inherit";
	/** agents.<role> 节：可选 model 覆盖 + 可选技能 allowlist（§9.5 G20；项目级整项覆盖全局级）。 */
	agents?: Record<string, { model?: string; skills?: string[] }>;
	/** amagi.json `concurrency` 分池限流段（校验+诊断用；admission.ts 每次读盘消费，见 loadConcurrencyLimits）。 */
	concurrency?: ConcurrencyLimits;
	/** amagi.json `fallbackModels` 跨 provider 降档候选链（ev-20260905-fdbb89；reliability.ts 跨 provider 降档消费，见 loadFallbackModels）。 */
	fallbackModels?: string[];
}

/** amagi.json `concurrency` 分池限流（归一后只含合法正整数条目；非法值仅诊断不抛）。 */
export interface ConcurrencyLimits {
	/** 缺省池容量（缺省 4；AMAGI_ADMISSION_MAX 环境变量优先于本值）。 */
	default?: number;
	/** 按 provider 分池容量（键 = model spec 的 `/` 前缀，无前缀 = "default"）。 */
	providers: Record<string, number>;
	/** 按 provider/model 精确分池容量（键 = 去 thinking 档后缀的 `provider/model`；优先于 providers）。 */
	models: Record<string, number>;
}

/** M2: 模型元数据（从 pi model runtime 或注入获取） */
export interface ModelMeta {
	reasoning?: boolean;
	thinkingLevelMap?: Record<string, string | null> | null;
}

const VALID_THINKING_LEVELS = ["off", "minimal", "low", "medium", "high", "xhigh", "max"];
// B5（采样分层）：合法 thinking 档位集（pi 预留全档；模型实际支持面由 thinkingLevelMap 决定，
// 见 checkModelThinking）。导出供守护测试与文档引用——amagi 只选档位，采样参数归宿主 models.json
// 的 samplingParams/samplingParamsByThinkingLevel（仅三类 OpenAI 兼容 API 生效，见 host-capabilities）。
export const SUPPORTED_THINKING_LEVELS: readonly string[] = VALID_THINKING_LEVELS;
const VALID_THINKING_SET = new Set(VALID_THINKING_LEVELS);

/** 只移除合法 thinking 档位；qwen:32b 等原生模型 ID 的冒号属于模型身份。 */
export function stripModelThinkingSuffix(spec: string): string {
	const colon = spec.lastIndexOf(":");
	return colon > Math.max(spec.indexOf("/"), 0) && VALID_THINKING_SET.has(spec.slice(colon + 1))
		? spec.slice(0, colon) : spec;
}
// $schema 为 JSON Schema 元数据引用（文档用途），放行不诊断
import { tuiWarn } from "./tui-console.ts";

let configurationSchema: any;
/** 运行根键检查、用户 doctor 与字段文档共同使用 schemas/amagi-config.json。 */
export function getAmagiConfigurationSchema(): any {
	if (!configurationSchema) {
		const parsed = JSON.parse(fs.readFileSync(new URL("../../schemas/amagi-config.json", import.meta.url), "utf8"));
		if (!parsed?.properties || typeof parsed.properties !== "object") throw new Error("amagi 配置 schema 无效");
		configurationSchema = parsed;
	}
	return configurationSchema;
}
const ALLOWED_TOP_KEYS = (() => {
	try { return new Set(Object.keys(getAmagiConfigurationSchema().properties)); }
	catch { return new Set(["profile", "agents", "$schema", "mcp", "concurrency", "fallbackModels", "ui", "lsp", "decision", "emojiGuard", "cacheWarming", "inProcessAdvisory", "largeEmissionGuard"]); }
})();

/** 全局 amagi.json 默认内容中的 $schema 引用（相对包根 schemas/amagi-config.json，文档用途） */
const SCHEMA_REF = "./schemas/amagi-config.json";

function diag(msg: string): void {
	// A1b：TUI 会话经 notify+落盘（裸 stderr 写入会破坏 fullscreen 差分渲染器）；非 TUI 保持 stderr 原语义
	tuiWarn(`[amagi-core] ${msg}`);
}

let cachedProfiles: Profiles | null = null;
let cachedProfileName: string | null = null;
// ev-20261005-115191：全局/项目 amagi.json 缓存携内容 digest——会话中途写入的热重载依赖它
// （根因：装配时读一次的缓存语义使运行中写入静默失效，无法从 Leader 侧感知，叠加令牌失效双重排障；
// digest 而非 mtime：diting F-12 同 tick 同水位写入盲区；文件 KB 级逐次读+hash 微秒级）。
let cachedGlobalConfig: { digest: string; config: UserConfig } | null = null;
const cachedProjectConfig: Map<string, { digest: string; config: UserConfig }> = new Map();

/** M1: 生产路径注入已知角色（由 createTaskTool 调用 setKnownAgents） */
let knownAgents: Set<string> = new Set();
/** M2: 模型元数据查询函数（由 createTaskTool 从 pi ctx 注入） */
let modelMetaProvider: ((provider: string, model: string) => ModelMeta | undefined) | null = null;

/** 测试注入接口（null=恢复默认真实路径；""=显式"无此文件"——测试隔离真实 ~/.pi/ 与 cwd 发现的哨兵） */
let injectedGlobalConfigPath: string | null = null;
let injectedProjectConfigPath: string | null = null;
let injectedProfilesDir: string | null = null;
/** 全局 amagi.json 自动创建开关（生产默认开；测试套件关闭以隔离真实 ~/.pi/） */
let autoCreateEnabled = true;

export function setKnownAgents(agents: Set<string>): void { knownAgents = agents; resetModelResolverCache(); }
export function setModelMetaProvider(fn: ((p: string, m: string) => ModelMeta | undefined) | null): void { modelMetaProvider = fn; }
export function _setConfigPathForTest(p: string | null): void { injectedGlobalConfigPath = p; resetModelResolverCache(); }
export function _setProjectConfigPathForTest(p: string | null): void { injectedProjectConfigPath = p; resetModelResolverCache(); cachedProjectConfig.clear(); }
export function _setProfilesDirForTest(p: string | null): void { injectedProfilesDir = p; resetModelResolverCache(); }
export function _setAutoCreateForTest(enabled: boolean): void { autoCreateEnabled = enabled; }

// ── 配置路径解析（对齐 pi dist config.js getAgentDir：PI_CODING_AGENT_DIR env 优先） ──

/** 全局 agent 配置目录（~/.pi/agent/，或 PI_CODING_AGENT_DIR 覆盖）。对齐 dist config.js:412-418 getAgentDir()。 */
function getGlobalConfigDir(): string {
	const envDir = process.env.PI_CODING_AGENT_DIR;
	if (envDir) return envDir;
	return path.join(os.homedir(), ".pi", "agent");
}

export function getGlobalConfigPath(): string {
	return path.join(getGlobalConfigDir(), "amagi.json");
}

/** 项目级配置路径（cwd/amagi.json）；cwd 缺省返回 null。 */
function getProjectConfigPath(cwd?: string): string | null {
	if (!cwd) return null;
	return path.join(cwd, "amagi.json");
}

/** 全局 amagi.json 自描述默认内容（首次运行自动写入）。 */
function defaultGlobalConfigContent(): string {
	return JSON.stringify({ $schema: SCHEMA_REF, profile: "tiered", agents: {} }, null, 2) + "\n";
}

/**
 * 全局 amagi.json 首次运行自动创建（幂等：存在则跳过）。
 * 目录不存在则递归创建（mode 0o700）；写失败仅 stderr 诊断，不阻塞主功能。
 */
function ensureGlobalConfig(configPath: string): void {
	if (!autoCreateEnabled) return;
	try {
		fs.statSync(configPath);
		return; // 已存在
	} catch {}
	try {
		fs.mkdirSync(path.dirname(configPath), { recursive: true, mode: 0o700 });
		fs.writeFileSync(configPath, defaultGlobalConfigContent(), { mode: 0o700 });
	} catch (e) {
		diag(`全局 amagi.json 自动创建失败（${configPath}）: ${e instanceof Error ? e.message : String(e)}（不影响功能，使用默认配置）`);
	}
}

/** session_start 启动时确保全局配置存在（index.ts 装配调用；失败同样不阻塞）。 */
export function ensureGlobalConfigOnStartup(): void {
	ensureGlobalConfig(getGlobalConfigPath());
}

/* 正整数容量归一（非 number（含 bool/字符串数字）/非有限/≤0 → undefined；合法 → 向下取整）。 */
function positiveIntCap(value: unknown): number | undefined {
	if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return undefined;
	return Math.floor(value);
}

/**
 * 解析 amagi.json `concurrency` 段：三键全部可选；非法值（非对象/非正整数）仅 stderr 诊断不抛，
 * 返回的归一结果只含合法条目（沿用本模块 diag 容错风格；消费方 admission.ts 按缺省容量兜底）。
 */
export function parseConcurrencySection(raw: unknown, label: string, report = diag): ConcurrencyLimits {
	const limits: ConcurrencyLimits = { providers: {}, models: {} };
	if (raw === undefined || raw === null) return limits;
	if (typeof raw !== "object" || Array.isArray(raw)) {
		report(`amagi.json(${label}) concurrency 非法（期望对象 {default?, providers?, models?}），整段忽略`);
		return limits;
	}
	const obj = raw as Record<string, unknown>;
	const d = positiveIntCap(obj.default);
	if (d !== undefined) limits.default = d;
	else if (obj.default !== undefined) report(`amagi.json(${label}) concurrency.default=${JSON.stringify(obj.default)} 非法（期望正整数），忽略`);
	for (const field of ["providers", "models"] as const) {
		const section = obj[field];
		if (section === undefined) continue;
		if (typeof section !== "object" || section === null || Array.isArray(section)) {
			report(`amagi.json(${label}) concurrency.${field} 非法（期望对象），忽略`);
			continue;
		}
		for (const [key, value] of Object.entries(section)) {
			if (field === "models" && !key.includes("/")) {
				report(`amagi.json(${label}) concurrency.models."${key}" 键形非法（期望 "provider/model" 含 /，与 providers 键区分），忽略`);
				continue;
			}
			const cap = positiveIntCap(value);
			if (cap === undefined) {
				report(`amagi.json(${label}) concurrency.${field}."${key}"=${JSON.stringify(value)} 非法（期望正整数），忽略`);
				continue;
			}
			limits[field][key] = cap;
		}
	}
	return limits;
}

/**
 * 读取全局+项目 amagi.json 的 `concurrency` 分池限流；项目键优先（每次读盘，改动即时生效——
 * 与 mcp-config.loadMcpRouting 同款模式；派发频率低，直读可接受）。
 * default 取项目>全局；providers/models 逐键浅合并（项目键胜）。
 */
export function loadConcurrencyLimits(cwd?: string): ConcurrencyLimits {
	const merged: ConcurrencyLimits = { providers: {}, models: {} };
	const globalDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const files = [path.join(globalDir, "amagi.json"), ...(cwd ? [path.join(path.resolve(cwd), "amagi.json")] : [])];
	for (const file of files) {
		let json: any;
		try { json = JSON.parse(fs.readFileSync(file, "utf8")); } catch { continue; }
		const section = parseConcurrencySection(json?.concurrency, file);
		if (section.default !== undefined) merged.default = section.default;
		Object.assign(merged.providers, section.providers);
		Object.assign(merged.models, section.models);
	}
	return merged;
}

// ── ev-20260905-fdbb89：跨 provider 降档候选链（账号级限额事故）──
// 实战：kimi-k3:high 429 后自动降档到同 provider kimi-k3:medium，但 opencode.ai workspace 限额
// 是账号级共享，同 provider 必然再 429。候选链来源：env AMAGI_FALLBACK_MODELS（逗号分隔全限定
// spec）→ amagi.json `fallbackModels`（schema 已同步）；消费方 reliability.ts crossProviderDowngrade。

/**
 * 解析 amagi.json `fallbackModels`（非字符串数组/非空字符串条目仅诊断忽略，不抛）。
 */
export function parseFallbackModels(raw: unknown, label: string, report = diag): string[] {
	if (raw === undefined || raw === null) return [];
	if (!Array.isArray(raw)) {
		report(`amagi.json(${label}) fallbackModels 非法（期望 string[]，如 ["openai/gpt-5.2"]），整段忽略`);
		return [];
	}
	const out: string[] = [];
	for (const item of raw) {
		if (typeof item !== "string" || !item.trim()) {
			report(`amagi.json(${label}) fallbackModels 条目 ${JSON.stringify(item)} 非法（期望非空字符串），忽略`);
			continue;
		}
		out.push(item.trim());
	}
	return out;
}

/**
 * 读取跨 provider 降档候选链（每次读盘即时生效，与 loadConcurrencyLimits 同款模式）：
 * env AMAGI_FALLBACK_MODELS（逗号分隔全限定 spec，非空即整体优先）→ 全局+项目 amagi.json
 * `fallbackModels` 合并（全局在前、项目追加，去重保序）。
 */
export function loadFallbackModels(cwd?: string): string[] {
	const fromEnv = (process.env.AMAGI_FALLBACK_MODELS || "").split(",").map((s) => s.trim()).filter(Boolean);
	if (fromEnv.length > 0) return fromEnv;
	const merged: string[] = [];
	const globalDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const files = [path.join(globalDir, "amagi.json"), ...(cwd ? [path.join(path.resolve(cwd), "amagi.json")] : [])];
	for (const file of files) {
		let json: any;
		try { json = JSON.parse(fs.readFileSync(file, "utf8")); } catch { continue; }
		for (const m of parseFallbackModels(json?.fallbackModels, file)) {
			if (!merged.includes(m)) merged.push(m);
		}
	}
	return merged;
}

function validateUserConfig(raw: any, label: string, report = diag): UserConfig {
	const config: UserConfig = {};
	if (!raw || typeof raw !== "object" || Array.isArray(raw)) return config;
	for (const key of Object.keys(raw)) {
		if (!ALLOWED_TOP_KEYS.has(key)) report(`amagi.json(${label}) 未知键 "${key}"（合法: ${[...ALLOWED_TOP_KEYS].join(", ")}）`);
	}
	if (raw.profile === "tiered" || raw.profile === "inherit") config.profile = raw.profile;
	else if (raw.profile !== undefined) report(`amagi.json(${label}) profile "${raw.profile}" 非法（合法: tiered|inherit），默认 tiered`);
	if (raw.agents && typeof raw.agents === "object" && !Array.isArray(raw.agents)) {
		config.agents = {};
		for (const [name, val] of Object.entries(raw.agents)) {
			// M1: 生产路径用 knownAgents（由 createTaskTool 注入）
			if (knownAgents.size > 0 && !knownAgents.has(name)) {
				report(`amagi.json(${label}) agents 未知角色 "${name}"（可用: ${[...knownAgents].join(", ")}）`);
				continue;
			}
			const rawSkills = val && typeof val === "object" ? (val as any).skills : undefined;
			let skills: string[] | undefined;
			if (rawSkills !== undefined) {
				// §9.5 G20：agents.<role>.skills 技能 allowlist（路径数组，语义同 pi --skill）。
				// 非 "-" 开头的非空字符串才合法（"-" 开头会被宿主 CLI 解析为旗标）。非法整组拒收（保 model），只诊断不抛。
				if (Array.isArray(rawSkills) && rawSkills.every((s: unknown) => typeof s === "string" && s.trim() !== "" && !s.trim().startsWith("-"))) {
					skills = rawSkills.map((s: string) => s.trim());
				} else {
					report(`amagi.json(${label}) agents."${name}".skills 格式无效（期望技能文件/目录路径的非空字符串数组，语义同 pi --skill；已整组忽略）`);
				}
			}
			const model = val && typeof val === "object" && typeof (val as any).model === "string" ? (val as any).model : undefined;
			if (model !== undefined || skills !== undefined) {
				config.agents[name] = { ...(model !== undefined ? { model } : {}), ...(skills !== undefined ? { skills } : {}) };
			} else {
				report(`amagi.json(${label}) agents."${name}" 格式无效（期望 {model: "provider/model"} 和/或 {skills: ["/path/..."]}）`);
			}
		}
	}
	if (raw.concurrency !== undefined) config.concurrency = parseConcurrencySection(raw.concurrency, label, report);
	if (raw.fallbackModels !== undefined) config.fallbackModels = parseFallbackModels(raw.fallbackModels, label, report);
	return config;
}

function loadProfiles(profileName: string): Profiles {
	const moduleDir = path.dirname(new URL(import.meta.url).pathname);
	if (injectedProfilesDir === "") return {}; // 测试哨兵：显式无 profiles
	const profilesDir = injectedProfilesDir || path.resolve(moduleDir, "..", "..", "profiles");
	const profilesPath = path.join(profilesDir, `${profileName}.json`);
	try {
		const raw = JSON.parse(fs.readFileSync(profilesPath, "utf8"));
		const valid: Profiles = {};
		for (const key of ["leader", "fast", "work", "expert"]) {
			if (raw[key] === null || typeof raw[key] === "string") (valid as any)[key] = raw[key];
		}
		if (raw.agentOverrides && typeof raw.agentOverrides === "object") {
			valid.agentOverrides = {};
			for (const [k, v] of Object.entries(raw.agentOverrides)) {
				if (typeof v === "string") valid.agentOverrides[k] = v;
			}
		}
		return valid;
	} catch { return {}; }
}

/** 加载全局 amagi.json（不存在则自动创建；损坏/非法仅诊断，不抛）。
 *  ev-20261005-115191：内容 digest 失效（diting F-12：mtime 同水位写入盲区——同 tick 改内容
 *  不触发重读；amagi.json 体量 KB 级，逐次读+hash 微秒级，派发频率下可忽略）——热重载彻底。 */
function loadGlobalConfig(readOnly = false): UserConfig {
	if (injectedGlobalConfigPath === "") return {}; // 测试哨兵：显式无全局配置
	const configPath = injectedGlobalConfigPath || getGlobalConfigPath();
	let content: string | null = null;
	try { if (!readOnly) ensureGlobalConfig(configPath); content = fs.readFileSync(configPath, "utf8"); } catch { /* lint-exempt:不可读→缓存空配置 */ }
	const digest = `${readOnly ? "explain:" : "run:"}${content === null ? "unreadable" : createHash("sha256").update(content, "utf8").digest("hex")}`;
	if (cachedGlobalConfig !== null && cachedGlobalConfig.digest === digest) return cachedGlobalConfig.config;
	if (content === null) {
		cachedGlobalConfig = { digest, config: {} };
		return cachedGlobalConfig.config;
	}
	try {
		cachedGlobalConfig = { digest, config: validateUserConfig(JSON.parse(content), configPath, readOnly ? () => {} : diag) };
	} catch (parseErr) {
		if (!readOnly) diag(`amagi.json(${configPath}) JSON 解析失败: ${(parseErr as Error).message}，使用默认配置`);
		cachedGlobalConfig = { digest, config: {} };
	}
	return cachedGlobalConfig.config;
}

/** 加载项目级 amagi.json（cwd/amagi.json；不存在为正常，静默；损坏诊断）。
 *  ev-20261005-115191：内容 digest 失效（同 loadGlobalConfig，diting F-12）。 */
function loadProjectConfig(cwd?: string, readOnly = false): UserConfig {
	const configPath = injectedProjectConfigPath === "" ? null : injectedProjectConfigPath || getProjectConfigPath(cwd); // ""=测试哨兵：显式无项目配置（不做 cwd 发现）
	if (!configPath) return {};
	let content: string | null = null;
	try { content = fs.readFileSync(configPath, "utf8"); } catch { /* lint-exempt:不存在为正常，静默（缓存空配置） */ }
	const digest = `${readOnly ? "explain:" : "run:"}${content === null ? "missing" : createHash("sha256").update(content, "utf8").digest("hex")}`;
	const cached = cachedProjectConfig.get(configPath);
	if (cached !== undefined && cached.digest === digest) return cached.config;
	let result: UserConfig = {};
	if (content !== null) {
		try {
			result = validateUserConfig(JSON.parse(content), configPath, readOnly ? () => {} : diag);
		} catch (parseErr) {
			if (!readOnly) diag(`amagi.json(${configPath}) JSON 解析失败: ${(parseErr as Error).message}，使用默认配置`);
		}
	}
	cachedProjectConfig.set(configPath, { digest, config: result });
	return result;
}

/** 合并全局+项目配置：profile 项目优先；agents 项目键优先覆盖全局。
 *  ev-20261005-115191：projectAgentKeys 返回项目级覆盖键集（模型标签区分项目/全局——实战覆写
 *  写入项目层而生效的是全局层旧值，标签不区分导致双重排障）。 */
function resolveEffectiveConfig(cwd?: string, readOnly = false): { profile: "tiered" | "inherit"; agents: Record<string, { model?: string; skills?: string[] }>; projectAgentKeys: Set<string> } {
	const globalCfg = loadGlobalConfig(readOnly);
	const projectCfg = loadProjectConfig(cwd, readOnly);
	const profile = projectCfg.profile ?? globalCfg.profile ?? "tiered";
	const agents: Record<string, { model?: string; skills?: string[] }> = {};
	if (globalCfg.agents) for (const [k, v] of Object.entries(globalCfg.agents)) agents[k] = { ...v };
	const projectAgentKeys = new Set<string>(Object.keys(projectCfg.agents ?? {}));
	if (projectCfg.agents) for (const [k, v] of Object.entries(projectCfg.agents)) agents[k] = { ...v };
	return { profile, agents, projectAgentKeys };
}

function getActiveProfiles(profileName: "tiered" | "inherit"): Profiles {
	if (cachedProfiles === null || cachedProfileName !== profileName) {
		cachedProfiles = loadProfiles(profileName);
		cachedProfileName = profileName;
	}
	return cachedProfiles;
}

/** §9.5 G20（Batch 3·技能 allowlist）：读取 agents.<role>.skills 配置。
 *  返回 undefined = 未配置（派发零注入 = 现状全量技能发现，行为零变化）。
 *  返回数组（含空数组）= 已配置 allowlist（空数组语义 = 该角色子代理不接收任何技能描述）。
 *  只读访问（不自动创建全局配置）；digest 缓存随 resolveEffectiveConfig，与选模链同源。 */
export function agentSkillAllowlist(agentName: string, cwd?: string): string[] | undefined {
	const eff = resolveEffectiveConfig(cwd, true);
	const skills = eff.agents[agentName]?.skills;
	return skills === undefined ? undefined : [...skills];
}

/**
 * M2: 解析 spec 为 {provider, model, thinkingLevel} 三段。
 * 从右往左精确匹配合法档名；不匹配则冒号段视为模型 ID。
 */
function parseSpec(spec: string): { provider: string; model: string; thinkingLevel?: string; fullSpec: string } {
	const slashIdx = spec.indexOf("/");
	const provider = slashIdx > 0 ? spec.slice(0, slashIdx) : "";
	const rest = slashIdx > 0 ? spec.slice(slashIdx + 1) : spec;
	const colonIdx = rest.lastIndexOf(":");
	if (colonIdx > 0 && VALID_THINKING_SET.has(rest.slice(colonIdx + 1))) {
		return { provider, model: rest.slice(0, colonIdx), thinkingLevel: rest.slice(colonIdx + 1), fullSpec: spec };
	}
	// 无合法 thinking 后缀 → 整个 rest 是 model（可能含冒号）
	return { provider, model: rest, fullSpec: spec };
}

/**
 * M2: 校验 thinking 档名 + model 元数据（reasoning/thinkingLevelMap）。
 */
export function validateModelSpec(spec: string | undefined): string | undefined {
	if (!spec) return spec;
	const colonIdx = spec.lastIndexOf(":");
	if (colonIdx <= 0) return spec;
	const suffix = spec.slice(colonIdx + 1);
	// 精确匹配合法档名
	if (VALID_THINKING_SET.has(suffix)) { checkModelThinking(spec, suffix); return spec; }
	// 大小写修正
	const lowerSuffix = suffix.toLowerCase();
	if (VALID_THINKING_SET.has(lowerSuffix)) {
		diag(`thinking 档名 "${suffix}" 大小写不正确（合法: ${lowerSuffix}），自动修正`);
		const fixed = spec.slice(0, colonIdx) + ":" + lowerSuffix;
		checkModelThinking(fixed, lowerSuffix);
		return fixed;
	}
	// Levenshtein ≤ 2 修正
	if (suffix.length <= 8 && /^[a-z]+$/i.test(suffix)) {
		for (const valid of VALID_THINKING_LEVELS) {
			if (levenshtein(lowerSuffix, valid) <= 2) {
				diag(`thinking 档名 "${suffix}" 不在合法集，最近匹配 "${valid}"，已修正`);
				const fixed = spec.slice(0, colonIdx) + ":" + valid;
				checkModelThinking(fixed, valid);
				return fixed;
			}
		}
	}
	// 不匹配 → 模型 ID 一部分（不误删）
	return spec;
}

/**
 * M2: 检查目标 model 是否支持请求的 thinking 档位。
 * 对齐 dist pi-ai/dist/models.js:392-402 getSupportedThinkingLevels():
 *   reasoning=false → 仅 off 支持
 *   reasoning=true + 有 map:
 *     null = 不支持
 *     xhigh/max not in map (undefined) = 不支持
 *     标准档(≤high) not in map = 支持（走 provider 默认映射）
 *   reasoning=true + 无 map: 标准档(≤high) 支持，xhigh/max 不支持
 */
const STANDARD_THINKING = new Set(["off", "minimal", "low", "medium", "high"]);

function checkModelThinking(spec: string, level: string): void {
	if (!modelMetaProvider) return;
	const parsed = parseSpec(spec);
	if (!parsed.provider) return;
	const meta = modelMetaProvider(parsed.provider, parsed.model);
	if (!meta) return;
	// 对齐 dist getSupportedThinkingLevels (pi-ai/dist/models.js:392-402):
	//   reasoning=false → 仅 off 支持
	//   reasoning=true:
	//     map[level] === null → 不支持（含 off:null）
	//     xhigh/max not in map → 不支持
	//     其余 → 支持
	if (!meta.reasoning) {
		if (level !== "off") {
			diag(`模型 ${parsed.provider}/${parsed.model} 不支持 reasoning（reasoning:false），请求的 ${level} 将被忽略`);
		}
		return;
	}
	// reasoning=true
	if (meta.thinkingLevelMap) {
		const mapped = meta.thinkingLevelMap[level];
		if (mapped === null) {
			diag(`模型 ${parsed.provider}/${parsed.model} thinkingLevelMap 显式标记 "${level}" 为不支持（null），将被 clamp`);
		} else if ((level === "xhigh" || level === "max") && mapped === undefined) {
			diag(`模型 ${parsed.provider}/${parsed.model} thinkingLevelMap 不含 "${level}"（xhigh/max 需显式声明），将被 clamp`);
		}
		// 标准档(≤high) 缺失 → 支持（provider 默认），无诊断
	} else {
		// 无 map：标准档(≤high) 走 provider 默认=支持，xhigh/max 不支持
		if (!STANDARD_THINKING.has(level)) {
			diag(`模型 ${parsed.provider}/${parsed.model} reasoning=true 但未声明 thinkingLevelMap，:${level} 超出默认支持范围(≤high)，将被 pi 静默 clamp`);
		}
	}
}

function levenshtein(a: string, b: string): number {
	const m = a.length, n = b.length;
	const d: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
	for (let i = 0; i <= m; i++) d[i][0] = i;
	for (let j = 0; j <= n; j++) d[0][j] = j;
	for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
		d[i][j] = a[i-1] === b[j-1] ? d[i-1][j-1] : Math.min(d[i-1][j], d[i][j-1], d[i-1][j-1]) + 1;
	return d[m][n];
}

/**
 * 解析 agent 最终 model。优先级链见文件头注释。
 * cwd 用于定位项目级 amagi.json；缺省时跳过项目级。
 */
/** 模型解析命中来源（优先级链中的哪一级命中）。dryRun/preflight 用于标注解析来源。 */
export type ModelSource = "param" | "amagi.json" | "profile" | "frontmatter" | "fallback";

export interface ModelSelectionCandidate {
	spec: string | undefined;
	source: ModelSource;
	amagiOrigin?: "project" | "global";
	label: string;
}

/** 运行和配置解释共用优先级链；只读解释不创建全局配置，不枚举凭据或 MCP 业务配置。 */
function modelSelectionCandidates(agent: AgentConfig, opts: { paramModel?: string; fallbackModel?: string; cwd?: string }, readOnly = false): { profile: "tiered" | "inherit"; candidates: ModelSelectionCandidate[] } {
	const eff = resolveEffectiveConfig(opts.cwd, readOnly);
	const profiles = getActiveProfiles(eff.profile);
	const origin = eff.projectAgentKeys.has(agent.name) ? "project" : "global";
	return { profile: eff.profile, candidates: [
		{ spec: opts.paramModel, source: "param", label: "本次显式模型" },
		{ spec: eff.agents[agent.name]?.model, source: "amagi.json", amagiOrigin: origin, label: `${origin === "project" ? "项目" : "全局"} amagi.json agents.${agent.name}` },
		{ spec: profiles.agentOverrides?.[agent.name], source: "profile", label: `profiles/${eff.profile}.json agentOverrides.${agent.name}` },
		{ spec: profiles[agent.type] ?? undefined, source: "profile", label: `profiles/${eff.profile}.json ${agent.type}` },
		{ spec: agent.model, source: "frontmatter", label: `角色 ${agent.name} frontmatter` },
		{ spec: opts.fallbackModel, source: "fallback", label: "当前 pi 会话模型" },
	] };
}

export function explainModelSelection(agent: AgentConfig, opts: { paramModel?: string; fallbackModel?: string; cwd?: string }) {
	const trace = modelSelectionCandidates(agent, opts, true);
	const selected = trace.candidates.find((candidate) => !!candidate.spec) ?? trace.candidates[trace.candidates.length - 1]!;
	return { ...trace, selected: { ...selected, spec: selected.source === "fallback" ? selected.spec : validateModelSpec(selected.spec) } };
}

/**
 * 解析 agent 最终 model + 命中来源（优先级链内部统一实现，供 resolveModel / resolveModelWithSource 复用，避免链路重复导致漂移）。
 * cwd 用于定位项目级 amagi.json；缺省时跳过项目级。
 */
function resolveModelInternal(agent: AgentConfig, opts: { paramModel?: string; fallbackModel?: string; cwd?: string }): { spec: string | undefined; source: ModelSource; amagiOrigin?: "project" | "global" } {
	if (opts.paramModel) return { spec: validateModelSpec(opts.paramModel), source: "param" };
	const { candidates } = modelSelectionCandidates(agent, opts);
	const selected = candidates.find((candidate) => !!candidate.spec) ?? candidates[candidates.length - 1]!;
	return { spec: selected.source === "fallback" ? selected.spec : validateModelSpec(selected.spec), source: selected.source, ...(selected.amagiOrigin ? { amagiOrigin: selected.amagiOrigin } : {}) };
}

/**
 * 解析 agent 最终 model。优先级链见文件头注释。
 * cwd 用于定位项目级 amagi.json；缺省时跳过项目级。
 */
export function resolveModel(agent: AgentConfig, opts: { paramModel?: string; fallbackModel?: string; cwd?: string }): string | undefined {
	return resolveModelInternal(agent, opts).spec;
}

/** dryRun 用：返回解析后 spec + 命中来源（供 task dryRun 标注解析来源）。 */
export function resolveModelWithSource(agent: AgentConfig, opts: { paramModel?: string; fallbackModel?: string; cwd?: string }): { spec: string | undefined; source: ModelSource; amagiOrigin?: "project" | "global" } {
	return resolveModelInternal(agent, opts);
}

/**
 * v1.5.216: param model 覆盖自省提示。当显式 param model 生效（优先级链最高级）且与
 * 去 param 后的配置解析值（amagi.json/profile/frontmatter/fallback）不同时，生成覆盖 note，
 * 提醒确认非笔误并告知缺省派发仍用角色配置；相同或配置无解析值时返回 undefined（不提示）。
 * effectiveSpec 为归一后的最终 param spec（裸名→全限定归一后参与比较，避免形式差异造成假阳性）。
 */
export function modelOverrideNote(agent: AgentConfig, opts: { paramModel?: string; effectiveSpec?: string; fallbackModel?: string; cwd?: string }): string | undefined {
	if (!opts.paramModel) return undefined;
	const explicit = opts.effectiveSpec ?? validateModelSpec(opts.paramModel);
	const configured = resolveModelInternal(agent, { fallbackModel: opts.fallbackModel, cwd: opts.cwd });
	if (!configured.spec || configured.spec === explicit) return undefined;
	// 8月迭代 F6a：同进程同 agent 同覆盖只提示一次（一贯派发策略下重复警告纯噪音）
	const seen = modelOverrideNoteSeen;
	const key = `${agent.name}→${explicit}`;
	if (seen.has(key)) return undefined;
	seen.add(key);
	return `⚠ model 覆盖：角色配置 ${configured.spec} → 显式 ${explicit}（确认非笔误；缺省派发用角色配置；本进程后续同覆盖不再提示）`;
}
const modelOverrideNoteSeen = new Set<string>();

/** 测试隔离：清空覆盖提示去重集。 */
export function resetModelOverrideNoteSeen(): void {
	modelOverrideNoteSeen.clear();
}

// ── E4: 模型可达性预检（启动期 / dryRun 前置探测） ──────────────────────────

/** 单 agent 的预检结果项。 */
export interface PreflightItem {
	/** 角色文件名 */
	agent: string;
	/** 角色类型 */
	type: AgentType;
	/** 解析后最终 model spec（含 thinking 后缀）；解析失败为 undefined */
	modelSpec: string | undefined;
	/** spec 拆分（provider/model/thinkingLevel）；无 spec 时不填 */
	parsed?: { provider: string; model: string; thinkingLevel?: string };
	/** 可达性判定：ok=可达 / model-not-found=未注册 / no-auth=未配置凭据 / skip=未传 registry 不探测 */
	reachable?: "ok" | "model-not-found" | "no-auth" | "skip";
	/** 诊断/原因说明 */
	note?: string;
}

/** preflight 用的最小 registry 接口（与 pi ModelRegistry 子集兼容，便于测试 mock）。 */
export interface PreflightModelRegistry {
	find(provider: string, modelId: string): unknown;
	hasConfiguredAuth?(model: unknown): boolean;
	/** ev-20260905-c4cc4f：枚举全部模型供相近候选排序（pi 真实 ModelRegistry 有 getAll）。 */
	getAll?(): Array<RegistryModelEntry>;
	/** pi-1.3-adapt P2（fuxi P0 切片）：有凭据模型快照（pi 真实 ModelRegistry.getAvailable）——诊断投影裸名归一用；可选，旧宿主缺席时按未验证降级。 */
	getAvailable?(): Array<RegistryModelEntry>;
}

/**
 * E4: 逐 agent 解析最终 model 并探测可达性。
 * 内部复用 resolveEffectiveConfig/getActiveProfiles/parseSpec + 已导出的 resolveModel；
 * 不触发 checkModelThinking 的 stderr 副作用（预检期间临时关 modelMetaProvider）；
 * 可达性用传入的 modelRegistry.find/hasConfiguredAuth；registry 未传时 reachable="skip"。
 * 全程不抛错：单 agent 解析失败进 note 并继续。
 */
export function preflightModels(
	agents: AgentConfig[],
	opts: { cwd?: string; fallbackModel?: string; modelRegistry?: PreflightModelRegistry },
): PreflightItem[] {
	const items: PreflightItem[] = [];
	// 预检期间临时关 modelMetaProvider，抑制 checkModelThinking 的 stderr 副作用（预检只探测可达性，不校验 thinking 档）
	const savedProvider = modelMetaProvider;
	modelMetaProvider = null;
	try {
		for (const agent of agents) {
			const item: PreflightItem = { agent: "?", type: "fast", modelSpec: undefined };
			try {
				item.agent = String((agent as AgentConfig)?.name ?? "?");
				item.type = (agent as AgentConfig)?.type ?? "fast";
				const spec = resolveModel(agent, { fallbackModel: opts.fallbackModel, cwd: opts.cwd });
				item.modelSpec = spec;
				if (spec) {
					const parsed = parseSpec(spec);
					item.parsed = { provider: parsed.provider, model: parsed.model, thinkingLevel: parsed.thinkingLevel };
					const reg = opts.modelRegistry;
					if (!reg) {
						item.reachable = "skip";
					} else if (!parsed.provider) {
						item.reachable = "model-not-found";
						item.note = `spec "${spec}" 无 provider 段（期望 provider/model 格式）`;
					} else {
						const registered = reg.find(parsed.provider, parsed.model);
						const synthetic = registered ? undefined : codexDispatchTemplate(spec, reg);
						const m = registered ?? synthetic;
						if (!m) {
							item.reachable = "model-not-found";
							// ev-20260905-c4cc4f：报错自动附相近候选（registry 枚举可得时），Leader 不必手翻 ~/.pi/agent/models.json
							const _cand = modelCandidates(spec, reg);
							item.note = `${parsed.provider}/${parsed.model} 未在 registry 注册（检查 provider 注册或模型 ID 拼写）${_cand.length ? `；相近候选: ${_cand.join(", ")}` : ""}`;
						} else if (typeof reg.hasConfiguredAuth === "function" && !reg.hasConfiguredAuth(m)) {
							item.reachable = "no-auth";
							item.note = `${parsed.provider}/${parsed.model} 未配置凭据（检查 provider OAuth/API Key）`;
						} else {
							item.reachable = "ok";
							if (synthetic) item.note = "目录未收录；将按 Codex 模板注册，远端支持与模型元数据未经验证";
						}
					}
				} else {
					item.reachable = opts.modelRegistry ? "model-not-found" : "skip";
					item.note = "未能解析出任何 model（param/amagi.json/profile/frontmatter/fallback 均无）";
				}
			} catch (e) {
				item.note = `解析异常: ${e instanceof Error ? e.message : String(e)}`;
			} finally {
				// modelMetaProvider 在整个预检期间保持 null，循环内不动；统一在 try/finally 外层恢复
			}
			items.push(item);
		}
	} finally {
		modelMetaProvider = savedProvider;
	}
	return items;
}

export function resetModelResolverCache(): void {
	cachedProfiles = null;
	cachedProfileName = null;
	cachedGlobalConfig = null;
	cachedProjectConfig.clear();
}

// ── v1.5.173: 派发前模型 spec 归一/校验 ─────────────────────────────────────
// 实战事故：task({ model: "glm-5.2" }) 裸模型名经 --model 传给 pi 后，pi 静默回退到
// 默认模型（openai-codex/gpt-5.6-sol），registry 记录 spec 与实际运行模型不符，
// 既骗过 Leader 又污染路由记忆。normalizeModelSpec 在派发前把 spec 对齐 registry：
// 全限定 spec 校验注册（显式 Codex 支持目录模板）；裸名跨 provider 唯一匹配则归一、歧义/未知/无凭据则诚实报错不派发。

/** registry 枚举条目宽松形状（pi Model 的 provider/id 主字段 + modelId/name 兼容形态；ev-20260905-c4cc4f）。 */
export interface RegistryModelEntry {
	provider?: string;
	id?: string;
	modelId?: string;
	name?: string;
}

/** pi ModelRegistry 结构子集（dist model-registry.d.ts: find L?, getAll L25, getAvailable L26）。 */
export interface ModelRegistryLike {
	find(provider: string, modelId: string): unknown;
	getAvailable?(): Array<{ provider: string; id: string }>;
	getAll?(): Array<RegistryModelEntry>;
}

export type NormalizeModelResult =
	| { ok: true; spec: string | undefined; note?: string }
	| { ok: false; error: string };

// ── ev-20260905-c4cc4f：模型报错自动附相近候选 ──
// 实战（模型纠偏事故）：模型配置错误三次才跑通——401 "Model k3 is not supported" →
// "amagi-Deepseek-go/k3 不在 modelRegistry" → 429，报错全程不提示正确拼写（registry 实为
// amagi-kimi/k3），Leader 只能手动翻 ~/.pi/agent/models.json。normalizeModelSpec 失败文案与
// preflight note 自动追加相近候选：同短名（provider 打错）＞同 provider 前缀（模型名打错）＞
// 短名相近（编辑距离≤2 或前缀/子串，不引新依赖）。

/** 枚举条目归一：取 provider + (id || modelId) 主字段；缺任一 → null（跳过，不拋）。 */
function normalizeRegistryEntry(entry: RegistryModelEntry): { provider: string; id: string } | null {
	const provider = typeof entry?.provider === "string" ? entry.provider.trim() : "";
	const id = typeof entry?.id === "string" && entry.id.trim() ? entry.id.trim() : (typeof entry?.modelId === "string" ? entry.modelId.trim() : "");
	if (!provider || !id) return null;
	return { provider, id };
}

/** 短名相近判定（宽松，避免噪声）：相等 / 前缀 / 子串包含 / 编辑距离≤2（复用本模块 levenshtein）。 */
function modelNameSimilar(a: string, b: string): boolean {
	if (!a || !b) return false;
	const la = a.toLowerCase(), lb = b.toLowerCase();
	if (la === lb) return true;
	if (la.length >= 2 && lb.length >= 2 && (la.startsWith(lb) || lb.startsWith(la))) return true;
	if (la.length >= 3 && lb.length >= 3 && (la.includes(lb) || lb.includes(la))) return true;
	return levenshtein(la, lb) <= 2;
}

/**
 * 相近模型候选（纯函数）：从 registry.getAll() 枚举（无 getAll / 异常 / 条目残缺 → 空数组），
 * 按相近度排序：同短名（/ 后去 :thinking 后缀完全相等，provider 打错）＞同 provider 前缀
 * （模型名打错）＞短名相近（编辑距离≤2 或前缀/子串）。返回 "provider/id" 列表（去重、
 * 字典序稳定、≤limit）；与失败 spec 完全相同者排除。
 */
export function modelCandidates(badSpec: string, registry: { getAll?(): Array<RegistryModelEntry> } | undefined, limit = 5): string[] {
	if (!badSpec || !registry || typeof registry.getAll !== "function") return [];
	let raw: RegistryModelEntry[];
	try { raw = registry.getAll() ?? []; } catch { return []; }
	const parsed = parseSpec(badSpec);
	const scored: Array<{ tier: number; spec: string }> = [];
	for (const entry of raw) {
		const m = normalizeRegistryEntry(entry);
		if (!m) continue;
		if (m.provider === parsed.provider && m.id === parsed.model) continue; // 与失败 spec 完全相同无意义
		let tier = -1;
		if (m.id === parsed.model) tier = 0; // 同短名（换个 provider 就能跑）
		else if (m.provider === parsed.provider && modelNameSimilar(parsed.model, m.id)) tier = 1; // 同 provider 名相近
		else if (modelNameSimilar(parsed.model, m.id)) tier = 2; // 名相近（含跨 provider）
		if (tier >= 0) scored.push({ tier, spec: `${m.provider}/${m.id}` });
	}
	scored.sort((a, b) => a.tier - b.tier || (a.spec < b.spec ? -1 : a.spec > b.spec ? 1 : 0));
	const out: string[] = [];
	for (const s of scored) {
		if (!out.includes(s.spec)) out.push(s.spec);
		if (out.length >= limit) break;
	}
	return out;
}

/** 失败文案的候选后缀（无候选 → 空串，不追加段落）。 */
function candidateSuffix(badSpec: string, registry: { getAll?(): Array<RegistryModelEntry> } | undefined): string {
	const c = modelCandidates(badSpec, registry);
	return c.length > 0 ? `相近候选: ${c.join(", ")}。` : "";
}

// ── ev-20260912-90c1ca：model 参数「字符串化 JSON 数组」形态恢复 ──
// 实战（不朽宗门 08 重派，2026-09-12 两次实测）：模型把降级链数组序列化成 JSON 字符串发出
//（model: "[\"openai-codex/gpt-6-astra:high\", \"openai-codex/gpt-6-astra:medium\"]"）——单标量路径把
// 整串当 spec 拆解成 garbage provider（`["openai-codex"`）/model，报「不在 modelRegistry」却附上以
// substring 相似度凑出的「相近候选」；候选本身合法但 Leader 以同样字符串形态重发必然再被拒，自相矛盾。

/** parseStringifiedModelArray 结果：not-array=正常标量；ok=恢复出的链元素；invalid=形似但解析失败（显式报错）。 */
export type StringifiedModelArrayResult = { kind: "not-array" } | { kind: "ok"; values: string[] } | { kind: "invalid"; error: string };

/** 识别并解析 model 参数的字符串化 JSON 数组形态（纯函数）：
 *  - 非 `[` 起始 → not-array（走正常标量路径）；
 *  - `[` 起始且 JSON.parse 成功、元素全为非空字符串 → ok（恢复出的降级链元素）；
 *  - `[` 起始但解析失败/元素非字符串 → invalid（显式报错引导传真数组，绝不静默当普通 spec 拆解）。 */
export function parseStringifiedModelArray(spec: string): StringifiedModelArrayResult {
	const trimmed = spec.trim();
	if (!trimmed.startsWith("[")) return { kind: "not-array" };
	let parsed: unknown;
	try { parsed = JSON.parse(trimmed); } catch { return { kind: "invalid", error: `model 参数以 "[" 起始但不是合法 JSON（${trimmed.slice(0, 80)}…）——降级链请传真正的数组 model: ["provider/model", …]，不要 JSON 字符串` }; }
	if (!Array.isArray(parsed) || parsed.length === 0 || !parsed.every((e) => typeof e === "string" && e.trim())) {
		return { kind: "invalid", error: `model 参数是字符串化的 JSON 但不是非空字符串数组（${trimmed.slice(0, 80)}…）——降级链请传真正的数组 model: ["provider/model", …]` };
	}
	return { kind: "ok", values: parsed as string[] };
}

function safeModelList(fn?: () => Array<RegistryModelEntry>): Array<{ provider: string; id: string }> {
	if (!fn) return [];
	let raw: RegistryModelEntry[];
	try { raw = fn() ?? []; } catch { return []; }
	const out: Array<{ provider: string; id: string }> = [];
	for (const entry of raw) {
		const n = normalizeRegistryEntry(entry);
		if (n) out.push(n);
	}
	return out;
}

/** 派发与预检共用：仅完整指定 Codex 身份，复用宿主目录中已有的协议模板。 */
function codexDispatchTemplate(spec: string, registry: { getAll?(): Array<RegistryModelEntry> }): unknown {
	const id = codexModelIdFromSpec(spec);
	if (!id || id !== parseSpec(spec).model || process.env.AMAGI_CODEX_FRONTLINE === "0" || !registry.getAll) return undefined;
	try {
		const base = registry.getAll().filter((m) => m.provider === "openai-codex" && typeof m.id === "string") as Array<{ id: string; [key: string]: unknown }>;
		return synthesizeFrontlineModel(id, base) ?? undefined;
	} catch { return undefined; }
}

/**
 * 归一/校验最终解析 spec（thinking 后缀保留）。registry 缺省时直通（测试/headless）。
 * - spec undefined（fallback ctx.model 路径）→ 直通：pi 会话默认模型是诚实默认值。
 * - 全限定 provider/model → find 校验；显式 Codex 可用宿主目录模板注册并在子端核验，其他未注册报错。
 * - 裸模型名 → getAvailable 跨 provider 匹配：唯一 → 归一+note；多个 → 歧义错误；
 *   零匹配 → getAll 有 → 无凭据错误；getAll 也无 → 未知错误。
 */
export function normalizeModelSpec(spec: string | undefined, registry?: ModelRegistryLike): NormalizeModelResult {
	if (!spec || !registry) return { ok: true, spec };
	const parsed = parseSpec(spec);
	const suffix = parsed.thinkingLevel ? `:${parsed.thinkingLevel}` : "";
	if (parsed.provider) {
		try {
			if (registry.find(parsed.provider, parsed.model)) return { ok: true, spec };
		} catch { /* find 异常按未注册处理，诚实报错 */ }
		// 仅明确的 Codex 引用：子进程按同一机制注册并用原 provider 发请求，
		// 不把目录猜测当作远端支持或认证成功的证据。
		if (codexModelIdFromSpec(spec) === parsed.model && codexDispatchTemplate(spec, registry)) return { ok: true, spec, note: `[model] ${parsed.provider}/${parsed.model} 未收录，将按目录模板元数据注册（能力、上下文和价格未核实）；实际支持以供应商响应为准` };
		// ev-20260912-90c1ca：spec 含引号/方括号等不可能出现在合法 spec 中的字符时，问题不是「拼写」
		// ——substring 相似度凑出的相近候选对该形态必为误导（候选合法但原样重发仍被拒），换成形态提示。
		const _shapeHint = /["\[\],]/.test(spec)
			? "model 值含引号/方括号等非法字符（疑似字符串化的 JSON 数组）——请传真正的数组 model: [\"provider/model\", …] 或单标量 \"provider/model[:thinking]\"，而不是 JSON 字符串。"
			: "";
		// v2.21.24：openai-codex 新模型常先于 pi.dev 官方目录上线——这不是拼写问题，给出
		// 配置引用自动合成的出路（codex-models collectCodexFrontlineReferences），避免误导向。
		const _catalogHint = parsed.provider === "openai-codex" && !_shapeHint
			? " openai-codex 目录可能滞后：自动合成抢先注册需要宿主 Codex 目录模板；模板能力及远端支持均需实际验证。"
			: "";
		return { ok: false, error: `[模型未注册] ${parsed.provider}/${parsed.model} 不在 modelRegistry——请核对 provider/model 拼写；未派发。${_shapeHint || candidateSuffix(spec, registry)}${_catalogHint}` };
	}
	const matches = safeModelList(registry.getAvailable?.bind(registry)).filter((m) => m.id === parsed.model);
	if (matches.length === 1) {
		const full = `${matches[0].provider}/${parsed.model}${suffix}`;
		return { ok: true, spec: full, note: `[model 归一] 裸模型名 "${parsed.model}" → ${full}（多 provider 环境请用全限定 spec，避免 pi 静默回退默认模型）` };
	}
	if (matches.length > 1) {
		// ev-20260910-316c6e：歧义拒单直接列全限定候选清单。实战（battle-sim workflow P1）：三个 provider 都
		// 注册了 deepseek-v4-pro，旧文案只列 provider 名（deepseek / opencode-go / amagi-deepseek），Leader 仍需
		// 逐个试前缀才试出 amagi-deepseek/ 才跑通——一次给出 provider/model 清单让其一选定。
		// 保持 registry 枚举顺序（即 pi 模型目录顺序），不做字典序重排——顺序稳定且对 Leader 无信息损失。
		const candidates = [...new Set(matches.map((m) => `${m.provider}/${parsed.model}${suffix}`))];
		return { ok: false, error: `[模型歧义] 裸模型名 "${parsed.model}" 匹配多个 provider——候选全限定名: ${candidates.join(" / ")}；请从中选定 provider/model 重派（未派发）。` };
	}
	const known = safeModelList(registry.getAll?.bind(registry)).filter((m) => m.id === parsed.model);
	if (known.length > 0) {
		// ev-20260910-316c6e：与歧义拒单同口径——列全限定候选（而不是仅 provider 名），便于一步定位登录对象。
		const candidates = [...new Set(known.map((m) => `${m.provider}/${m.id}`))];
		return { ok: false, error: `[模型无凭据] "${parsed.model}" 已知（候选: ${candidates.join(" / ")}）但无可用凭据——请针对该 provider 先 /login 或配置 API Key；未派发。` };
	}
	return { ok: false, error: `[模型未知] 裸模型名 "${parsed.model}" 不在 modelRegistry——请用全限定 provider/model（如 zhipuai/glm-5.2）；未派发。${candidateSuffix(spec, registry)}` };
}

// ── ev-20260910-060c3a / ev-20260910-316c6e：模型路由可观测性（实际生效回显 + 偏离警示 + 失败归因）──
// 实证根因（battle-sim/unit-face-settlement workflow 2026-09-10 原始记录）：显式覆盖链路本身是通的——
//   · task 618d4376（未传 model）→ journal model=amagi-deepseek/deepseek-v4.1-flash:max，provider 400
//     "you passed deepseek-v4.1-flash"；
//   · task 88b36a6c（显式 model=amagi-deepseek/deepseek-v4-pro）→ journal model 与子会话 model_change
//     均为 deepseek-v4-pro，运行 41min 正常（无 400）。
// 「覆盖未生效」是结果不回显模型导致的误判（4xx 报错不归属到具体派发）。以下四个纯函数把「实际生效模型」
// 变成每次派发结果都可见的事实，并在模型类 provider 报错时直接给出替代候选。

/** 模型解析来源的人类可读标签（effectiveModelNote 用）。 */
function modelSourceLabel(source?: ModelSource, origin?: "project" | "global"): string {
	switch (source) {
		case "param": return "显式覆盖";
		case "amagi.json": return origin === "project" ? "amagi.json 项目配置" : origin === "global" ? "amagi.json 全局配置" : "amagi.json 角色配置";
		case "profile": return "profile 配置";
		case "frontmatter": return "角色 frontmatter";
		case "fallback": return "fallback 解析";
		default: return "解析值";
	}
}

/**
 * ev-20260910-060c3a：派发结果模型回显行——任何派发都能一眼看到本次实际生效的模型与其来源。
 * 实战：显式覆盖派发与缺省派发的错误结果混在同一会话里，400 报错无法归属到哪一次派发，
 * Leader 据此误判「覆盖未生效」。spec 缺失（fallback ctx 路径）返回 undefined 不产生噪音行。
 */
export function effectiveModelNote(spec: string | undefined, source?: ModelSource, amagiOrigin?: "project" | "global"): string | undefined {
	if (!spec) return undefined;
	return `[model] 实际生效：${spec}（${modelSourceLabel(source, amagiOrigin)}）`;
}

/** spec 尾名（去 provider 前缀与 :thinking 后缀，小写）——跨形式比较（"p/m:max" ≡ "m"）。 */
function bareModelId(spec: string): string {
	const stripped = stripModelThinkingSuffix(spec);
	const tail = stripped.includes("/") ? stripped.split("/").pop()! : stripped;
	return tail.toLowerCase();
}

/**
 * ev-20260910-060c3a：子进程实际运行模型与请求 spec 偏离的警示（pi 宿主静默回退的可观测兜底）。
 * pi 流内 message.model 与 spawn 的 --model 尾名不一致即视为偏离（task-jsonl 同源判据）；
 * 尾名一致（provider/思考档形式差异）不告警；任一侧缺失返回 undefined。override=true 用
 * 「覆盖未生效」措辞（显式传参场景），否则报「路由偏离」。
 */
export function modelDeviationNote(opts: { expectedSpec?: string; actualSpec?: string; override?: boolean }): string | undefined {
	const { expectedSpec, actualSpec } = opts;
	if (!expectedSpec || !actualSpec) return undefined;
	if (bareModelId(expectedSpec) === bareModelId(actualSpec)) return undefined;
	return opts.override
		? `⚠ model 覆盖未生效：请求 ${expectedSpec}，实际运行 ${actualSpec}（pi 子进程未接受请求模型——核对 models.json 注册与拼写；可 dryRun 核验或换模型重派）`
		: `⚠ model 路由偏离：请求 ${expectedSpec}，实际运行 ${actualSpec}（pi 子进程静默回退——核对 provider 注册与模型名拼写）`;
}

/** 模型不可用类 provider 报错的签名（下线/不支持/未知/不存在）。 */
const MODEL_PROVIDER_ERROR_RES: RegExp[] = [
	/supported\s+API\s+model\s+names/i, // deepseek："The supported API model names are …, but you passed …"
	/\bmodel\b[^\n]{0,80}(?:not\s+(?:found|exist|supported|available|valid)|unsupported|unknown|invalid|decommission\w*|delisted|deprecated)/i,
	/(?:unsupported|unknown|invalid|decommissioned|delisted)\s+model\b/i,
	/模型[^\n]{0,40}(?:不存在|不支持|已下线|已废弃|未找到|无效)/,
];

/**
 * ev-20260910-316c6e：判定错误文本是否为「模型不可用」类 provider 报错（只认模型语义，避免
 * 把 401 凭据/503 过载/429 限额等常规 provider 错误误判为模型下线）。
 */
export function isModelProviderError(errorText?: string): boolean {
	if (!errorText) return false;
	return MODEL_PROVIDER_ERROR_RES.some((re) => re.test(errorText));
}

/**
 * ev-20260910-316c6e：模型类 provider 错误的归因建议——列出本次请求模型、角色配置解析缺省与可用
 * 替代候选（fallbackModels 登记链 ＞ 同 provider 注册模型 ＞ 相近名），让 Leader 一次选定而非试探。
 * 无 failedSpec（未解析出模型）返回 undefined；无候选时如实说明 registry 枚举不到替代。
 */
export function modelFailureAdvice(opts: {
	failedSpec?: string;
	configuredSpec?: string;
	registry?: ModelRegistryLike;
	fallbackModels?: string[];
	limit?: number;
}): string | undefined {
	const { failedSpec } = opts;
	if (!failedSpec) return undefined;
	const parsed = parseSpec(failedSpec);
	const candidates: string[] = [];
	const push = (s: string) => { if (s && s !== failedSpec && !candidates.includes(s)) candidates.push(s); };
	// 1) 用户登记的降档链（amagi.json fallbackModels / env）——最贴合的替代来源
	for (const m of opts.fallbackModels ?? []) push(m);
	// 2) 同 provider 注册模型——provider 侧支持的本地快照（models.json）
	for (const m of safeModelList(opts.registry?.getAll?.bind(opts.registry))) {
		if (m.provider === parsed.provider && m.id !== parsed.model) push(`${m.provider}/${m.id}`);
	}
	// 3) 相近名候选（跨 provider，复用 ev-20260905-c4cc4f 排序）
	for (const s of modelCandidates(failedSpec, opts.registry, 8)) push(s);
	const shown = candidates.slice(0, opts.limit ?? 6);
	const req = opts.configuredSpec && opts.configuredSpec !== failedSpec
		? `本次请求模型: ${failedSpec}（显式覆盖）；角色配置解析缺省: ${opts.configuredSpec}`
		: `本任务请求模型（角色配置解析值）: ${failedSpec}`;
	const tail = shown.length > 0
		? `可用替代候选: ${shown.join(", ")}——重派时用 model 参数一次选定，勿按 provider 前缀逐个试探。`
		: `registry 未枚举到可用替代——核对 provider 注册/凭据，或先 task({ …, dryRun: true }) 核验模型名。`;
	return `[model 归因] provider 报错指向模型不可用（已下线/不支持/未知）。${req}；${tail}`;
}

// ── ev-20261031-7110a8：quota 恢复换模候选（配置枚举 + registry 只读探测） ──
// 实战（kb-org-orchestration-dev 复盘 §2.1）：fuxi 连续 3 轮 anthropic 429 后，恢复全靠 Leader
// 手改 ~/.pi/agent/amagi.json 换 provider 再改回——「配置里还有哪些可用角色模型」这一插件内事实
// 没有进入恢复指引。本节把配置可枚举的模型（fallbackModels ＞ amagi.json agents.*.model ＞
// profiles）收为换模候选，registry 可用时逐条只读探测注册/凭据配置状态；额度与服务端实际
// 可调用性不可探测——reach 只声明到「注册/凭据配置」为止，不假称可用。

/** 换模候选的 registry 探测结果（诚实分级：不包含额度/可用性断言）。 */
export type QuotaCandidateReach = "auth" | "registered" | "unverified";

export interface QuotaRecoveryCandidate {
	/** 归一后模型 spec（探测 ok 时含裸名归一；thinking 后缀保留配置原形）。 */
	spec: string;
	/** provider 段（无 / → 空串）。 */
	provider: string;
	/** 配置来源标签（fallbackModels / amagi.json agents.<role> / profiles/<p> <key>）。 */
	source: string;
	/** auth=已注册且凭据已配置；registered=已注册（凭据未证实）；unverified=registry 缺席/探测异常，状态未证实。 */
	reach: QuotaCandidateReach;
}

export interface QuotaRecoveryCandidates {
	/** 已排除确认同 provider 的候选；provider 空串仍未确认，渲染不得冒称已跨 provider。 */
	cross: QuotaRecoveryCandidate[];
	/** 因同 provider 被排除的配置候选数（披露计数；quota 语义下同 provider 候选无恢复价值）。 */
	sameProviderSkipped: number;
}

/** spec 的 provider 段（本地小件，避免循环依赖 reliability）。 */
function quotaProviderSegment(spec: string): string {
	const i = spec.indexOf("/");
	return i > 0 ? spec.slice(0, i) : "";
}

/** quota 恢复候选 registry（ModelRegistryLike + 可选凭据探测；与 PreflightModelRegistry 兼容）。 */
export type QuotaCandidateRegistry = ModelRegistryLike & { hasConfiguredAuth?(model: unknown): boolean };

/** 单候选 registry 探测结果：no-registry/probe-error=状态未证实（保留候选，reach=unverified）；
 *  not-registered=明确未注册（过滤——推荐必失败）；ok=注册+凭据事实。F2（diting quick）：明确未注册与
 *  探测异常分流——find/getAvailable 抛错不折为未注册过滤，保留「配置存在但状态未证实」的事实。 */
// 身份与探测状态正交：每个分支携带当前已确认的 spec，递归归一后即使探测失败也不丢 provider。
type QuotaCandidateProbe = { spec: string } & ({ kind: "no-registry" | "probe-error" | "not-registered" } | { kind: "ok"; reach: "auth" | "registered" });

/** 单候选只读探测：全限定 spec 经 find（未命中=明确未注册；抛错=探测异常；命中后 hasConfiguredAuth
 *  定 auth/registered——凭据探测异常维持 registered，注册事实已由 find 证实）；裸名经 getAvailable
 *  唯一命中归一为全限定后递归探测（枚举缺席=旧宿主 no-registry；零/多命中=不采用）。 */
function probeQuotaCandidate(rawSpec: string, registry: QuotaCandidateRegistry | undefined): QuotaCandidateProbe {
	if (!registry || typeof registry.find !== "function") return { kind: "no-registry", spec: rawSpec };
	const parsed = parseSpec(rawSpec);
	if (parsed.provider) {
		let m: unknown;
		try { m = registry.find(parsed.provider, parsed.model); }
		catch { /* lint-exempt:find 抛错只降级探测状态，保留已归一身份供同 provider 排除 */ return { kind: "probe-error", spec: rawSpec }; }
		if (!m) return { kind: "not-registered", spec: rawSpec };
		let reach: "auth" | "registered" = "registered";
		if (typeof registry.hasConfiguredAuth === "function") {
			try { if (registry.hasConfiguredAuth(m)) reach = "auth"; } catch { /* lint-exempt:注册已由 find 证实；凭据探测异常维持 registered（凭据未证实） */ }
		}
		return { kind: "ok", spec: rawSpec, reach };
	}
	if (typeof registry.getAvailable !== "function") return { kind: "no-registry", spec: rawSpec };
	let rawList: Array<RegistryModelEntry>;
	try { rawList = registry.getAvailable() ?? []; } catch { /* lint-exempt:枚举抛错=探测异常，尚无归一身份则保留原始 spec */ return { kind: "probe-error", spec: rawSpec }; }
	const matches = rawList.map(normalizeRegistryEntry).filter((x): x is { provider: string; id: string } => x !== null).filter((x) => x.id === parsed.model);
	if (matches.length !== 1) return { kind: "not-registered", spec: rawSpec };
	return probeQuotaCandidate(`${matches[0].provider}/${rawSpec}`, registry);
}

/**
 * 枚举当前配置可用的换模候选（只读，零写入；readOnly 配置访问不自动创建全局文件）。
 * 来源优先序：fallbackModels（env/amagi.json 用户登记链——最贴切的恢复意图）＞ amagi.json
 * agents.<role>.model（项目+全局合并）＞ profiles（agentOverrides + tier 模型）。去重保序、逐条只读
 * 探测（F2：明确未注册过滤，探测异常保留且 reach=unverified）；failedSpec 的 provider 条目被排除
 * （quota 语义：账号级配额共享，同 provider 换模型/思考档不恢复额度）并计入 sameProviderSkipped。
 * 额度与实际可调用不可探测——reach 不含可用性断言，渲染层负责明示边界。
 */
export function collectQuotaRecoveryCandidates(opts: {
	failedSpec?: string;
	cwd?: string;
	registry?: QuotaCandidateRegistry;
	limit?: number;
}): QuotaRecoveryCandidates {
	const failedProvider = opts.failedSpec ? quotaProviderSegment(stripModelThinkingSuffix(opts.failedSpec)) : "";
	const raw: Array<{ spec: string; source: string }> = [];
	const push = (spec: unknown, source: string): void => {
		if (typeof spec !== "string" || !spec.trim()) return;
		raw.push({ spec: spec.trim(), source });
	};
	for (const m of loadFallbackModels(opts.cwd)) push(m, "fallbackModels");
	const eff = resolveEffectiveConfig(opts.cwd, true);
	for (const [name, v] of Object.entries(eff.agents)) push(v?.model, `amagi.json agents.${name}`);
	const profiles = getActiveProfiles(eff.profile);
	for (const [k, v] of Object.entries({
		...(profiles.agentOverrides ?? {}),
		leader: profiles.leader, fast: profiles.fast, work: profiles.work, expert: profiles.expert,
	})) push(v, `profiles/${eff.profile} ${k}`);
	const seen = new Set<string>();
	const cross: QuotaRecoveryCandidate[] = [];
	let sameProviderSkipped = 0;
	for (const r of raw) {
		// F2（diting quick）：不再经 normalizeModelSpec 折叠（其 find 异常→未注册语义属正式执行校验，
		// 不适用于候选探测）——探测分流：明确未注册才过滤；探测异常保留候选（reach=unverified）。
		const probe = probeQuotaCandidate(r.spec, opts.registry);
		if (probe.kind === "not-registered") continue;
		const spec = probe.spec;
		if (seen.has(spec)) continue;
		seen.add(spec);
		const provider = quotaProviderSegment(spec);
		if (failedProvider && provider === failedProvider) { sameProviderSkipped++; continue; }
		if (cross.length >= (opts.limit ?? 6)) continue;
		cross.push({ spec, provider, source: r.source, reach: probe.kind === "ok" ? probe.reach : "unverified" });
	}
	return { cross, sameProviderSkipped };
}
