/** 派发工具边界：简写确定性展开；内核继续只接收完整契约，不推断权限或验收。 */
import * as fs from "node:fs";
import * as path from "node:path";
import { TextDecoder } from "node:util";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
import { CONTRACT_ERROR_CODES, err, ok, normalizeToolArgumentArtifacts, type Result } from "./contracts/view.ts";

export interface InputReference { path: string; purpose: string; required?: boolean }
export interface OutputReference { path: string; kind?: "file" | "tree"; required?: boolean; purpose?: string }
export type DispatchInput = string | InputReference;
export type DispatchOutput = string | OutputReference;

/** 单任务与批次共用的调用纪律；新任务书走内核落盘，不依赖另一次 Write 的完成时序。 */
export const DISPATCH_TASK_GUIDELINES = [
	"codemode 是普通工具组合方式，不需在任务 scope 里单独申请；子任务模型自行选择，所有嵌套调用继承原任务工具权限。",
	"新写任务书无论长短，直接通过 task 传完整正文，一次调用完成派发；harness 自动冻结并持久化任务契约后才启动子 Agent，无需先调用 Write 保存任务书。",
	"taskFile 引用已有任务书文件；同批并行的同文件 Write/Edit 由工具自动等待完成后再读取。",
	"按任务显式选择 contextMode：普通承接任务用 selected；依赖大量讨论背景的攻坚/咨询用 fork；独立审核和新探索用 isolated。同一任务续接优先 task_resume。contextRefs 可在同次调用指定已有来源，不额外 Write 上下文文件。",
];

export const InputReferenceSchema = Type.Object({
		path: Type.String({ description: "输入文件/目录路径" }),
		purpose: Type.String({ description: "该输入的用途说明" }),
		required: Type.Optional(Type.Boolean({ description: "缺省 true；可缺输入显式 false" })),
});
export const DispatchInputSchema = Type.Union([
	Type.String({ description: "必读输入路径简写（purpose=任务参考输入，required=true）" }),
	InputReferenceSchema,
]);
export const OutputReferenceSchema = Type.Object({
		path: Type.String({ description: "预期产物路径" }),
		kind: Type.Optional(StringEnum(["file", "tree"], { description: "产物形态（缺省 file）" })),
		required: Type.Optional(Type.Boolean({ description: "缺省 true；可选产物显式 false" })),
		purpose: Type.Optional(Type.String({ description: "产物用途说明" })),
});
export const DispatchOutputSchema = Type.Union([
	Type.String({ description: "必需文件产物路径简写（kind=file，required=true）；目录树用对象显式 kind=tree" }),
	OutputReferenceSchema,
]);

/** 不删未知字段、不修正路径字节、不吞非法非数组；后续完整校验负责拒单。 */
export function normalizeInputReferences(value: unknown): InputReference[] | undefined {
	return (Array.isArray(value) ? value.map((v) => typeof v === "string"
		? { path: v, purpose: "任务参考输入", required: true } : v) : value) as InputReference[] | undefined;
}
export function normalizeOutputReferences(value: unknown): OutputReference[] | undefined {
	return (Array.isArray(value) ? value.map((v) => typeof v === "string"
		? { path: v, kind: "file", required: true } : v) : value) as OutputReference[] | undefined;
}

/** 单任务入口共用的简写展开。保留冲突/非法字段交给执行前校验，正文和路径不做 Unicode 改写。 */
export function prepareDispatchArguments(args: unknown): unknown {
	const normalized = normalizeToolArgumentArtifacts(args);
	if (!normalized || typeof normalized !== "object" || Array.isArray(normalized)) return normalized;
	const p = { ...(normalized as Record<string, unknown>) };
	for (const [short, full, normalize] of [
		["inputPaths", "inputs", normalizeInputReferences], ["outputPaths", "outputs", normalizeOutputReferences],
	] as const) {
		if (p[full] !== undefined) p[full] = normalize(p[full]);
		else if (Array.isArray(p[short]) && (p[short] as unknown[]).every((v) => typeof v === "string")) {
			p[full] = normalize(p[short]);
			delete p[short];
		}
	}
	return p;
}

/** 输入清单由工具注入 assignment，避免 Leader 在 task 与 inputs 中重复手写路径和用途。 */
export function appendInputsSection(task: string, inputs: readonly InputReference[], cwd: string): string {
	if (!inputs.length) return task;
	return `${task}\n\n[任务输入]（按用途取用；任务书来源正文已冻结，不以重读源文件替换当前任务书）\n${inputs.map((i) =>
		`- ${JSON.stringify(path.resolve(cwd, i.path))}：${i.purpose}（${i.required === false ? "可选" : "必读"}）`).join("\n")}`;
}

/** task/taskFile 恰好一个；文件占位正文只用于前置结构校验，绝不交付子进程。 */
export function validateTaskSource(value: { task?: unknown; taskFile?: unknown }): Result<{ task: string; taskFile?: string }> {
	if (value.task !== undefined && value.taskFile !== undefined) {
		return err("task-source-conflict", "task 与 taskFile 互斥：任务书正文或任务书文件恰好提供一个；新任务书直接传 task，harness 自动保存，无需先 Write", ["task", "taskFile"], "none");
	}
	if (value.taskFile !== undefined) {
		if (typeof value.taskFile !== "string" || !value.taskFile.trim()) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "taskFile 必须是非空文件路径", ["taskFile"], "none");
		}
		return ok({ task: "<待读取任务书文件>", taskFile: value.taskFile });
	}
	if (typeof value.task !== "string" || !value.task.trim()) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "task（assignment）必须是非空任务书正文；已有任务书可改用 taskFile", ["task"], "none");
	}
	return ok({ task: value.task });
}

/** 本地 UTF-8 任务书有界快照。相对调用者 cwd；不随 workspace/worktree 重定位，不 trim 正文。 */
export const TASK_FILE_MAX_BYTES = 1024 * 1024;
export function readTaskFile(
	taskFile: string, callerCwd: string,
	checkRead: (absolutePath: string) => { ok: boolean; reason?: string },
): Result<{ task: string; input: InputReference }> {
	const absolutePath = path.resolve(callerCwd, taskFile);
	const allowed = checkRead(absolutePath);
	if (!allowed.ok) return err("task-file-denied", allowed.reason ?? "任务书文件落在 deny 禁入区", ["taskFile"], "none");
	let fd: number | undefined;
	try {
		// 非阻塞打开使 FIFO 等特殊文件也能立即拒绝；限制读取而非只检查 stat，防增长越界。
		fd = fs.openSync(absolutePath, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
		if (!fs.fstatSync(fd).isFile()) return err("task-file-invalid", `任务书必须是普通文件: ${absolutePath}`, ["taskFile"], "none");
		const bytes = Buffer.alloc(TASK_FILE_MAX_BYTES + 1);
		let length = 0;
		while (length < bytes.length) {
			const n = fs.readSync(fd, bytes, length, bytes.length - length, null);
			if (n === 0) break;
			length += n;
		}
		if (length > TASK_FILE_MAX_BYTES) return err("task-file-too-large", `任务书超过 ${TASK_FILE_MAX_BYTES} 字节: ${absolutePath}；请拆分任务书，将参考资料放入 inputs`, ["taskFile"], "none");
		const task = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes.subarray(0, length));
		if (!task.trim()) return err("task-file-empty", `任务书正文为空: ${absolutePath}`, ["taskFile"], "none");
		if (task.includes("\0")) return err("task-file-invalid", `任务书包含 NUL 字符，不能作为子进程任务文本: ${absolutePath}`, ["taskFile"], "none");
		return ok({ task, input: { path: absolutePath, purpose: "任务书来源（正文在提交时冻结）", required: true } });
	} catch (e) {
		return err("task-file-read-failed", `读取 UTF-8 任务书失败: ${absolutePath}（${e instanceof Error ? e.message : String(e)}）。若正文是本轮新写的，请改用 task 直接提交完整正文（与 taskFile 互斥），harness 自动保存；引用已有文件时确认路径正确且写入已成功。`, ["taskFile"], "none");
	} finally {
		if (fd !== undefined) fs.closeSync(fd);
	}
}
