/**
 * win-exec-lock.ts — win_exec 互斥组锁（ue-run.sh 串行锁的 WSL 侧等价物）。
 *
 * v2（diting 审核 m1）：锁文件记录 {pid, starttime, group, token, relayPid?}——判活校验
 * pid + /proc/<pid>/stat 第 22 列 starttime（pid 复用免疫）；陈旧回收改为 rename 到唯一名
 * 再 unlink 的原子两步（防并发双取）；release 校验 token 才删（防误删他人新锁）；锁绑定
 * 「持有者 pi pid + 当前 relay pid」双校验——pi 异常退出但 relay 仍在跑时不判陈旧（relay
 * 活着 = 组仍在使用，视为活锁）。
 *
 * 锁目录放 runBgRoot() 同级（AMAGI_WINEXEC_ROOT 可覆盖测试）。fs/clock/存活判定全注入。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { runBgRoot } from "./run-bg.ts";

export interface LockDeps {
	fs?: Pick<typeof fs, "mkdirSync" | "openSync" | "readFileSync" | "writeFileSync" | "unlinkSync" | "closeSync" | "writeSync" | "renameSync" | "existsSync">;
	now?: () => number;
	/** pid 存活（缺省 kill(pid,0)；EPERM=存活）。 */
	pidAlive?: (pid: number) => boolean;
	/** /proc/<pid>/stat 第 22 列 starttime（jiffies）；不可读返回 null。缺省真实读取。 */
	procStarttime?: (pid: number) => number | null;
	/** 陈旧阈值 ms（缺省 24h）。 */
	staleAfterMs?: number;
}

export interface ExclusiveLockHandle {
	group: string;
	lockPath: string;
	pid: number;
	token: string;
	acquiredAt: number;
	/** 是否经陈旧锁自愈取得。 */
	recoveredFromStale?: boolean;
	/** 登记当前 relay pid（spawn 后调用；relay 活着时锁不判陈旧）。 */
	bindRelay(pid: number): void;
	/** 释放锁（token 匹配才删；幂等）。 */
	release(): void;
}

export type AcquireResult =
	| { ok: true; handle: ExclusiveLockHandle }
	| { ok: false; kind: "conflict" | "stale-unrecoverable"; reason: string };

function defaultPidAlive(pid: number): boolean {
	if (!Number.isInteger(pid) || pid <= 1) return false;
	try { process.kill(pid, 0); return true; } catch (e) { return (e as NodeJS.ErrnoException)?.code === "EPERM"; /* lint-exempt:EPERM=进程存在（权限不足） */ }
}

/** /proc/<pid>/stat 第 22 列：comm 含空格/括号，从最后一个 ')' 之后切分（纯函数）。 */
export function parseProcStatStarttime(statLine: string): number | null {
	const close = statLine.lastIndexOf(")");
	if (close < 0) return null;
	const fields = statLine.slice(close + 2).split(/\s+/);
	// close+2 后字段序：state(1) ppid(2) pgrp(3) session(4) tty_nr(5) tpgid(6) flags(7) minflt(8)
	// cminflt(9) majflt(10) cmajflt(11) utime(12) stime(13) cutime(14) cstime(15) priority(16)
	// nice(17) num_threads(18) itrealvalue(19) starttime(20) —— 相对切片下标 19（0 起）
	const v = Number(fields[19]);
	return Number.isFinite(v) && v > 0 ? v : null;
}

function defaultProcStarttime(pid: number): number | null {
	if (!Number.isInteger(pid) || pid <= 1) return null;
	try {
		return parseProcStatStarttime(fs.readFileSync(`/proc/${pid}/stat`, "utf8"));
	} catch { return null; /* lint-exempt:进程已死/不可读 → null（调用方回退 pid 存活判定） */ }
}

function randomToken(): string {
	return `${Date.now().toString(36)}-${Math.random().toString(16).slice(2, 10)}`;
}

export function winExecRoot(): string {
	return process.env.AMAGI_WINEXEC_ROOT || path.join(path.dirname(runBgRoot()), "win-exec");
}

export function lockDirFor(root: string = winExecRoot()): string {
	return path.join(root, "locks");
}

interface LockFileData {
	pid: number;
	starttime: number | null;
	startedAt: number;
	group: string;
	token: string;
	relayPid?: number;
}

function readLockFile(fsD: NonNullable<LockDeps["fs"]>, lockPath: string): LockFileData | null {
	try {
		const parsed = JSON.parse(fsD.readFileSync(lockPath, "utf8")) as Partial<LockFileData>;
		if (typeof parsed.pid !== "number" || typeof parsed.startedAt !== "number" || typeof parsed.token !== "string") return null;
		return { pid: parsed.pid, starttime: typeof parsed.starttime === "number" ? parsed.starttime : null, startedAt: parsed.startedAt, group: String(parsed.group ?? ""), token: parsed.token, ...(typeof parsed.relayPid === "number" ? { relayPid: parsed.relayPid } : {}) };
	} catch { return null; /* lint-exempt:锁文件不可读/损坏 → null（触发自愈判定） */ }
}

function writeLockFile(fsD: NonNullable<LockDeps["fs"]>, lockPath: string, data: LockFileData): void {
	const fd = fsD.openSync(lockPath, "wx");
	try {
		fsD.writeSync(fd, `${JSON.stringify(data)}\n`);
	} finally {
		fsD.closeSync(fd);
	}
}

/** m1：持有者身份判定——pid 活 +（starttime 可读时必须匹配）；relay 已登记且活 = 组仍在使用。 */
function holderActive(data: LockFileData, deps: Required<Pick<LockDeps, "pidAlive" | "procStarttime">>): boolean {
	const pidOk = (() => {
		if (!deps.pidAlive(data.pid)) return false;
		if (data.starttime === null) return true; // starttime 不可读（权限/非 Linux）→ 回退 pid 存活
		const current = deps.procStarttime(data.pid);
		return current !== null ? current === data.starttime : true; // 现值不可读 → 不以 starttime 误判
	})();
	if (pidOk) return true;
	if (typeof data.relayPid === "number" && Number.isInteger(data.relayPid) && data.relayPid > 1 && deps.pidAlive(data.relayPid)) {
		return true; // pi 已退出但 relay 仍在跑——组仍在使用，视为活锁（不判陈旧）
	}
	return false;
}

/**
 * 获取互斥组锁。返回 handle 时调用方必须最终 release()（finally 兜底）。陈旧判定：持有者
 * 不活（pi 死且 relay 死）或锁龄超阈值 → rename 到唯一名（原子让位）再 unlink，重试一次。
 */
export function acquireExclusiveLock(group: string, deps: LockDeps = {}, root: string = winExecRoot()): AcquireResult {
	const g = String(group ?? "").trim();
	if (!g) return { ok: false, kind: "conflict", reason: "exclusive 组名不能为空" };
	if (!/^[A-Za-z0-9._-]{1,64}$/.test(g)) return { ok: false, kind: "conflict", reason: `exclusive 组名 "${g}" 非法（1-64 位字母/数字/._-）` };
	const fsD = deps.fs ?? fs;
	const now = deps.now ?? Date.now;
	const pidAlive = deps.pidAlive ?? defaultPidAlive;
	const procStarttime = deps.procStarttime ?? defaultProcStarttime;
	const staleAfterMs = deps.staleAfterMs ?? 24 * 3600 * 1000;
	const dir = lockDirFor(root);
	fsD.mkdirSync(dir, { recursive: true });
	const lockPath = path.join(dir, `${g}.lock`);
	const currentPid = process.pid;
	const makeData = (at: number): LockFileData => ({ pid: currentPid, starttime: procStarttime(currentPid), startedAt: at, group: g, token: randomToken() });

	let data = makeData(now());
	let recovered = false;
	try {
		writeLockFile(fsD, lockPath, data);
	} catch (e) {
		if ((e as NodeJS.ErrnoException)?.code !== "EEXIST") throw e; // 权限/磁盘错误如实上抛
		// 已存在：判活/陈旧 → 原子两步回收（rename 让位 + unlink）
		const held = readLockFile(fsD, lockPath);
		const t = now();
		const staleReason = held === null
			? "锁文件损坏（无法解析）"
			: !holderActive(held, { pidAlive, procStarttime })
				? `持有者 pi pid ${held.pid} 与 relay ${held.relayPid ?? "（未登记）"} 均已退出`
				: held.startedAt > 0 && t - held.startedAt > staleAfterMs
					? `锁龄超 ${Math.round(staleAfterMs / 1000)}s 阈值`
					: null;
		if (staleReason === null) {
			return {
				ok: false,
				kind: "conflict",
				reason: `互斥组 "${g}" 正被 pid ${held!.pid}（${new Date(held!.startedAt).toISOString()} 起${held!.relayPid ? ` · relay pid ${held!.relayPid}` : ""}）持有——同组同时只允许一个 win_exec 在跑；等待其完成或换组名。锁文件：${lockPath}`,
			};
		}
		// m1：rename 到唯一名（原子让位——并发方不再看到同名锁文件可抢）再 unlink
		const tomb = path.join(dir, `${g}.stale-${randomToken()}.lock`);
		try { fsD.renameSync(lockPath, tomb); } catch { /* lint-exempt:竞争：他人已处理 → 重试创建 */ }
		try { fsD.unlinkSync(tomb); } catch { /* lint-exempt:tomb 不存在/清理失败无害（唯一名残留） */ }
		data = makeData(t);
		recovered = true;
		try {
			writeLockFile(fsD, lockPath, data);
		} catch { /* lint-exempt:并发竞争：他人已处理 → 后续按存在路径处理 */
			return { ok: false, kind: "stale-unrecoverable", reason: `互斥组 "${g}" 的陈旧锁（${staleReason}）清理后仍无法取得锁（疑似并发竞争）；请重试` };
		}
	}
	const acquiredAt = now();
	const writeBack = (d: LockFileData): void => {
		try { fsD.writeFileSync(lockPath, `${JSON.stringify(d)}\n`, "utf8"); } catch { /* lint-exempt:relay 登记写回失败——锁仍在（原 token），最坏退化为无 relay 兜底 */ }
	};
	return {
		ok: true,
		handle: {
			group: g, lockPath, pid: currentPid, token: data.token, acquiredAt, ...(recovered ? { recoveredFromStale: true } : {}),
			bindRelay: (relayPid: number): void => {
				data.relayPid = relayPid;
				writeBack(data);
			},
			release: (): void => {
				// token 校验后才删：防误删他人陈旧回收后的新锁
				const current = readLockFile(fsD, lockPath);
				if (current === null || current.token !== data.token) return;
				try { fsD.unlinkSync(lockPath); } catch { /* lint-exempt:已释放/进程死后自愈（幂等） */ }
			},
		},
	};
}
