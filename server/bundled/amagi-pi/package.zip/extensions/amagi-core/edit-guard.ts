/**
 * edit-guard.ts — edit 工具事件护栏（v2.7.6；A1 ev-20260921-2e6b4f 职责重排）。
 *
 * 实证背景（2026-08-15 会话复盘）：edit "Could not find the exact text" 3 连败，
 * 全部退化为 python 裸替换。根因两类：A 模型凭记忆重构 oldText 引入内容误差；
 * B 不可见形态差异（CRLF/行尾空白/全角空格/Unicode NFC-NFD）。
 *
 * 形状契约（ev-20260921-2e6b4f 根治）：pi 0.86.0 实测 tool_call 事件输入为现代形态
 * { path, edits: [{oldText, newText}] }（dist/core/tools/edit.d.ts EditToolInput = Static<editSchema>，
 * 由 tests/pi-edit-shape-contract.test.mjs 以安装包类型解析 + 真实调用双重锁定）。
 * 旧 0.84.2 的 { file_path, edits } 仅作为读入兼容保留一个发布版本：normalizeEditInput
 * 归一时写回 path 并去掉旧键；错误提示不推荐旧字段。本文件不把 dist 的单文件类型当
 * files/regex 扩展参数的权威来源（那是 edit-override 的扩展面）。
 *
 * 职责边界（A1 裁决：恢复守卫责任，不恢复错误的前置匹配顺序）：
 * - 本护栏只做①输入形状归一（normalizeEditInput：path / files / 旧 file_path 三形态，
 *   冲突报错不静默任选）②可独立判断的字面标题删除检查（checkHeadingDeletion——
 *   不依赖文件内容匹配，任何写入前完成）。
 * - 匹配、自愈、not-found 诊断全部归 edit-override.ts 的 recoverNativeFailure /
 *   resolveEditsForFile（复用本文件导出的 locateEdit/editGuardReason，不增加第二份
 *   匹配算法）。原生 fuzzy（弯引号/Unicode 连字符/行尾空白）不被本护栏抢先拒绝。
 *
 * 诊断精度（ev-20260922-960cb3：只修诊断失真，不动匹配本体）：
 * - locateEdit 匹配判定保持原样（exact 计数 + 归一化窗口扫描快慢路径不变）；
 * - not-found 诊断资料扩为：启发式候选（首行整行锚 → 原文子串锚 → 去缩进码点公共前缀
 *   ——CJK 无词边界，word-split 启发式对中文失效）、候选起点后 oldText 对应跨度的
 *   比较窗口（candidateText）、围绕实际差异 ±3 行的展示窗口（contextText）——
 *   比较与展示不再共用 nearby.text；
 * - firstDiffAt 按码点遍历（code-unit offset 供 slice、码点索引供 ASCII 字符位）；
 *   displayChar 接收完整码点（emoji 不再拆成孤立 surrogate）；∅ 只在字符串真结束时
 *   出现且注明 EOF 语义；非 ASCII 行不报屏幕列，另给实际差异字符与码点位置。
 * - 2026-10-10：长中文行围绕首差截取；旧开头 60 字展示把「减损/减员」差异藏在窗口外，
 *   两侧显示相同导致模型误判 JSON 转义。此次失配不是 read 字符转换故障，须修正诊断证据。
 */

import * as path from "node:path";
import { parseEditPatch, normalizeEditPatchOptions } from "./edit-patch.ts";
import { normalizeSelectionOptions, validateSelectionInput, type EditSelection } from "./edit-snapshot.ts";
import { resolveBuiltinFileTarget } from "./builtin-file-target.ts";
import { guardRuleOf, guardProjectTrustedOf } from "./guard-policy.ts";

/** Equivalent path/files targets are redundant arguments, not a conflict. No filesystem IO. */
export function coalesceEditTargets(input: Record<string, unknown>, cwd: string): void {
	if (typeof input.path !== "string" || !input.path.trim() || input.path.trim() === "null"
		|| !Array.isArray(input.files) || !input.files.length) return;
	if (!input.files.every(f => typeof f === "string" && f.trim())) return;
	try {
		const target = resolveBuiltinFileTarget(input.path, cwd);
		if (input.files.every(f => resolveBuiltinFileTarget(f as string, cwd) === target)) delete input.files;
	} catch { /* Invalid paths retain the existing shape/permission error, never guess a target. */ }
}

// ── 归一化（纯函数） ────────────────────────────────────────────────────────

/**
 * 形态归一化：CRLF/CR→LF、去每行行尾空白、全角空格 U+3000→半角、Unicode NFC。
 * 语义内容保持不变——归一后相等即"仅形态差异"。
 */
export function normalizeText(text: string): string {
	return String(text)
		.replace(/\r\n?/g, "\n")
		.split("\n")
		.map((ln) => ln.replace(/[ \t\u3000]+$/g, "").replace(/\u3000/g, " "))
		.join("\n")
		.normalize("NFC");
}

// ── ev-20261005-109214：转义层级自愈与诊断（reflect 复盘：转义密集文件 oldText 连环失配 9 次，
// 全部为「文件真实字节不在执行者脑内」的上下文缺失型，占全部工具失败 60%）──

/** 单层 JSON 转义解码（保守）：`\\\\`→`\\`、`\\"`→`"`、`\\n`→LF、`\\t`→TAB、`\\r`→CR、
 *  `\\uXXXX`→字符。只处理一层（oldText 比 文件多一层转义的高频形态）；无转义面原样返回。 */
const UNESCAPE_ONCE_RE = /\\\\|\\"|\\n|\\t|\\r|\\u([0-9a-fA-F]{4})/g;
export function unescapeOnce(s: string): string {
	if (!s.includes("\\")) return s;
	return s.replace(UNESCAPE_ONCE_RE, (m, hex: string) => {
		switch (m) {
			case "\\\\": return "\\";
			case '\\"': return '"';
			case "\\n": return "\n";
			case "\\t": return "\t";
			case "\\r": return "\r";
			default: return String.fromCharCode(parseInt(hex, 16));
		}
	});
}

/** ev-20261005-109214（diting quick F1/F2 重定向）：转义层级候选——仅诊断不执行。
 *  两方向单向解码：①unescape(oldText) vs 文件原文（oldText 多一层转义——edit 参数编码失误高频形态）；
 *  ②unescape(文件) vs oldText 原文（文件多一层）。全部候选窗口如实报告（合并），不内定唯一
 *  目标（F2：单方向唯一但并集≥2 时选择属越权）；零候选 → null（回退通用 not-found 诊断）。
 *  normLines 复用主扫描结果（省一次全文件归一化——diting 性能观察）。 */
export interface EscapeLevelCandidateWindow {
	/** 文件行号（1 基）。 */
	startLine: number;
	/** 窗口真实原文（可直接复制重写 oldText）。 */
	text: string;
	/** 命中方向：1=oldText 多一层；2=文件多一层。 */
	direction: 1 | 2;
}
export interface EscapeLevelCandidates {
	windows: EscapeLevelCandidateWindow[];
	/** 方向①候选数。 */
	dir1Count: number;
	/** 方向②候选数。 */
	dir2Count: number;
}
function escapeLevelCandidates(rawLines: string[], normLines: string[], nOldLines: string[]): EscapeLevelCandidates | null {
	const hasEscape = (arr: readonly string[]) => arr.some((l) => l.includes("\\"));
	if (!hasEscape(nOldLines) && !hasEscape(normLines)) return null;
	const decOld = nOldLines.map((l) => unescapeOnce(l));
	const decFile = normLines.map((l) => unescapeOnce(l));
	const windows: EscapeLevelCandidateWindow[] = [];
	const scan = (needle: readonly string[], haystack: readonly string[], direction: 1 | 2): number => {
		let count = 0;
		for (let i = 0; i + needle.length <= haystack.length; i++) {
			if (haystack[i] !== needle[0]) continue;
			let eq = true;
			for (let j = 1; j < needle.length; j++) {
				if (haystack[i + j] !== needle[j]) { eq = false; break; }
			}
			if (eq) {
				count++;
				windows.push({ startLine: i + 1, text: rawLines.slice(i, i + needle.length).join("\n"), direction });
			}
		}
		return count;
	};
	const dir1Count = decOld.some((l, i) => l !== nOldLines[i]) ? scan(decOld, normLines, 1) : 0;
	const dir2Count = decFile.some((l, i) => l !== normLines[i]) ? scan(nOldLines, decFile, 2) : 0;
	return windows.length > 0 ? { windows, dir1Count, dir2Count } : null;
}

// ── 输入形状归一（ev-20260921-2e6b4f：现代 path / 扩展 files / 旧 file_path 三形态）──

/** 归一化后的 edit 元素（守卫消费口径：oldText/newText 必为 string；regex 为扩展参数，守卫跳过其标题检查）。 */
export interface NormalizedEditItem {
	oldText: string;
	newText: string;
	regex?: unknown;
}

/** normalizeEditInput 结果：现代契约 path 或 files 二选一 + 已校验的 edits。 */
export type NormalizeEditOutcome =
	| { ok: true; kind: "selection"; path: string; selection: EditSelection; newText: string }
	| { ok: true; kind: "patch"; path: string; patch: string }
	| { ok: true; kind: "single"; path: string; edits: NormalizedEditItem[] }
	| { ok: true; kind: "files"; files: string[]; edits: NormalizedEditItem[] }
	| { ok: false; reason: string };

/**
 * edit 输入形状归一（纯函数，无 IO；归一写回发生在入参对象上——pi tool_call 事件的
 * input 是官方文档化的原地改写通道，"Mutate it in place to patch tool arguments"）。
 *
 * - 现代 `path` / 扩展 `files` / 显式旧 `file_path` 三形态归一；现代键优先，但真实目标
 *   冲突（path 与 files 指向不同目标、file_path 与 path 值不同、file_path 与 files 并存）
 *   必须报错，不静默任选。
 * - 旧 `file_path` 仅保留一个发布版本的读入兼容：归一时写回 `path` 并删除旧键；
 *   错误提示不推荐旧字段。
 * - files 模式下 path 字符串 "null" 视为缺省（归一化 schema 对 XML 参数格式把缺省
 *   path 序列化为 "null" 的既有兼容，与 edit-override.execute 同口径）；无 files 时
 *   名为 null 的文件仍是合法单文件目标。
 * - 空 edits / 非法类型 / 目标缺失 → 明确形状错误（非 edit 事件不经此函数，零干预）。
 */
export function normalizeEditInput(input: Record<string, unknown> | null | undefined, cwd = process.cwd()): NormalizeEditOutcome {
	if (!input || typeof input !== "object" || Array.isArray(input)) {
		return { ok: false, reason: "[amagi edit-guard] edit 输入必须是对象（现代形态：{ path, edits } 或 { files: string[], edits }）。" };
	}
	normalizeEditPatchOptions(input);
	normalizeSelectionOptions(input);
	if (input.selection !== undefined) {
		try { const selection = validateSelectionInput(input); return { ok: true, kind: "selection", path: input.path as string, selection, newText: input.newText as string }; }
		catch (error) { return { ok: false, reason: error instanceof Error ? error.message : String(error) }; }
	}
	coalesceEditTargets(input, cwd);
	if (input.newText !== undefined) return { ok: false, reason: "[amagi edit-guard] 顶层 newText 仅用于 selection；字面替换请使用 edits[].newText。" };
	if (input.patch !== undefined) {
		if (typeof input.path !== "string" || !input.path.trim() || input.files !== undefined || input.file_path !== undefined || input.edits !== undefined) {
			return {ok: false, reason: "[amagi edit patch] 仅支持 {path, patch}，不能混用 edits/files/file_path。"};
		}
		try { parseEditPatch(input.patch as string); } catch (e) {return {ok: false, reason: e instanceof Error ? e.message : String(e)};}
		return {ok: true, kind: "patch", path: input.path, patch: input.patch as string};
	}
	const editsRaw = input.edits;
	if (!Array.isArray(editsRaw)) {
		return { ok: false, reason: `[amagi edit-guard] edits 必须是数组（收到 ${typeof editsRaw}）。现代形态：{ path, edits: [{ oldText, newText }] }。` };
	}
	if (editsRaw.length === 0) {
		return { ok: false, reason: "[amagi edit-guard] edits 不能为空数组（至少 1 条 { oldText, newText }）。" };
	}
	const edits: NormalizedEditItem[] = [];
	for (let i = 0; i < editsRaw.length; i++) {
		const e = editsRaw[i] as { oldText?: unknown; newText?: unknown; regex?: unknown } | null;
		if (!e || typeof e !== "object" || Array.isArray(e)) {
			return { ok: false, reason: `[amagi edit-guard] edits[${i}] 必须是对象（收到 ${e === null ? "null" : typeof e}）。` };
		}
		if (typeof e.oldText !== "string" || typeof e.newText !== "string") {
			return { ok: false, reason: `[amagi edit-guard] edits[${i}].oldText/newText 必须是字符串（收到 oldText:${typeof e.oldText} newText:${typeof e.newText}）。` };
		}
		edits.push({ oldText: e.oldText, newText: e.newText, regex: e.regex });
	}
	// 目标键类型检查（先于存在性判断——非法类型给明确形状错误而非当作缺省）
	if (input.path !== undefined && typeof input.path !== "string") {
		return { ok: false, reason: `[amagi edit-guard] path 必须是字符串（收到 ${typeof input.path}）。` };
	}
	if (input.files !== undefined && !Array.isArray(input.files)) {
		return { ok: false, reason: `[amagi edit-guard] files 必须是 string[]（收到 ${typeof input.files}）。` };
	}
	if (input.file_path !== undefined && typeof input.file_path !== "string") {
		return { ok: false, reason: `[amagi edit-guard] file_path 字段类型非法（收到 ${typeof input.file_path}）；现代形态用 path。` };
	}
	const hasPath = typeof input.path === "string" && input.path.trim() !== "";
	const hasFiles = Array.isArray(input.files);
	const hasLegacy = typeof input.file_path === "string" && input.file_path.trim() !== "";
	// 真实目标冲突：报错，不静默任选（现代键优先只用于「旧键等值重写」，不吞并冲突值）
	if (hasLegacy && hasPath && input.file_path !== input.path) {
		return { ok: false, reason: `[amagi edit-guard] 目标冲突：同时收到 path=${JSON.stringify(input.path)} 与 file_path=${JSON.stringify(input.file_path)} 且两者不同——单文件编辑只传 path（现代形态），去掉多余字段后重试。` };
	}
	if (hasLegacy && hasFiles) {
		return { ok: false, reason: `[amagi edit-guard] 目标冲突：同时收到旧字段 file_path=${JSON.stringify(input.file_path)} 与多文件 files（×${(input.files as unknown[]).length}）——多文件编辑只传 files: string[]，去掉 file_path 后重试。` };
	}
	if (hasPath && hasFiles && (input.path as string).trim() !== "null") {
		return { ok: false, reason: `[amagi edit-guard] 目标冲突：path 与 files 互斥——单文件编辑传 path，多文件传 files（本次同时收到 path=${JSON.stringify(input.path)} 与 files×${(input.files as unknown[]).length}）。` };
	}
	if (hasFiles) {
		const files: string[] = [];
		for (const f of input.files as unknown[]) {
			if (typeof f !== "string" || f.trim() === "") {
				return { ok: false, reason: `[amagi edit-guard] files 每项必须是非空字符串路径（收到 ${JSON.stringify(f)}）。` };
			}
			files.push(f);
		}
		if (files.length === 0) {
			return { ok: false, reason: "[amagi edit-guard] files 不能为空数组（多文件模式至少 1 个）。" };
		}
		// 归一写回：files 模式下字符串 "null" 是缺省 path 的序列化产物，删除之
		if ("path" in input) delete input.path;
		if ("file_path" in input) delete input.file_path; // 冲突已上方报错；此处仅清理等值残留
		return { ok: true, kind: "files", files, edits };
	}
	const target = hasPath ? (input.path as string) : hasLegacy ? input.file_path : undefined;
	if (target === undefined) {
		return { ok: false, reason: "[amagi edit-guard] 缺少编辑目标：单文件编辑传 path，多文件传 files: string[]（至少 1 个）。" };
	}
	// 归一写回：旧 file_path 兼容读入一个发布版本——写回 path、去掉旧键
	if (!hasPath && hasLegacy) input.path = input.file_path;
	if ("file_path" in input) delete input.file_path;
	return { ok: true, kind: "single", path: target, edits };
}

// ── 定位（纯函数；匹配判定保持原样——ev-20260922-960cb3 只扩诊断资料） ─────────

export type EditLocateStatus =
	| "exact-unique"      // 精确命中且唯一（放行）
	| "exact-multi"       // 精确命中多处（放行，pi 原生报非唯一）
	| "healed-unique"     // 归一化后唯一命中（静默自愈：返回文件真实原文）
	| "ambiguous"         // 归一化命中多处（block + 诊断）
	| "not-found";        // 无命中（block + 候选/窗口诊断）

/** 候选置信口径（not-found 诊断用；候选是启发式，不是确认目标）。 */
export type CandidateStatus = "unique" | "tied" | "low-confidence" | "escape-level";

export interface EditLocateResult {
	status: EditLocateStatus;
	/** healed-unique：文件中的真实原文（含原始行尾/空白形态），用于原地替换 oldText。 */
	healedText?: string;
	/** healed 来源标记（whitespace：形态自愈静默——空白差异无语义风险；转义层级自愈已被 diting
	 *  审核否决并降为 escape-level 诊断候选，不再自动执行）。 */
	healedVia?: "whitespace";
	/** not-found + 唯一候选：候选锚点行（1 基）。模板/行号类诊断的替换起点。 */
	candidateStartLine?: number;
	/** 诊断子串锚在首行内的 UTF-16 偏移（非屏幕列）；缺省 0。只定位，不参与匹配/自愈。 */
	candidateStartOffset?: number;
	/** 子串锚之前的码点数；首行文件侧差异位置须加此偏移。 */
	candidateStartCodepointOffset?: number;
	/**
	 * not-found + 唯一候选：比较窗口——候选起点后 oldText 对应跨度的文件真实原文
	 * （行数受文件末尾截断）。firstDiffLine 的对账基准，与展示窗口 contextText 分离。
	 */
	candidateText?: string;
	/** not-found：展示窗口行界（1 基、含端点）——围绕实际差异 ±contextLines 行。 */
	contextStartLine?: number;
	contextEndLine?: number;
	/** not-found：展示窗口文本（供人核对的文件片段）。 */
	contextText?: string;
	/** not-found + 并列候选：并列锚点行号（1 基，升序，至多 8 个）——不捏造唯一目标。 */
	tiedCandidateLines?: number[];
	/** not-found：候选置信口径（low-confidence = 无候选，不捏造位置）。 */
	candidateStatus?: CandidateStatus;
	/** ev-20261005-109214：candidateStatus=escape-level 时的两方向候选清单（仅诊断不执行）。 */
	escapeCandidates?: EscapeLevelCandidates;
	/**
	 * 兼容投影（既有消费者）：not-found 时 line=候选锚点行（1 基）、text=展示窗口文本。
	 * 新代码请消费 candidateStartLine/contextText；比较窗口用 candidateText，勿再用
	 * nearby.text 对账（展示截断会制造假 ∅/假差异——ev-20260922-960cb3 根因）。
	 */
	nearby?: { line: number; text: string };
}

/** 统计子串出现次数（快速路径用；上限 2 即早停——只需区分 0/1/多）。 */
function countOccurrences(haystack: string, needle: string): number {
	if (!needle) return 0;
	let count = 0, idx = 0;
	while ((idx = haystack.indexOf(needle, idx)) !== -1) {
		count++;
		if (count >= 2) return count; // 早停
		idx += needle.length;
	}
	return count;
}

/** 去缩进后码点公共前缀长度（ev-20260922-960cb3：CJK 无词边界，word-split 启发式对中文失效）。 */
function codepointCommonPrefix(a: string, b: string): number {
	let i = 0, j = 0, n = 0;
	while (i < a.length && j < b.length) {
		const ca = a.codePointAt(i)!, cb = b.codePointAt(j)!;
		if (ca !== cb) break;
		i += ca > 0xffff ? 2 : 1;
		j += cb > 0xffff ? 2 : 1;
		n++;
	}
	return n;
}

/** 码点前缀候选的最低置信阈值（去缩进后公共前缀码点数低于此值 → low-confidence，不捏造位置）。 */
export const CANDIDATE_MIN_PREFIX_CP = 3;

/** 并列候选在诊断中列出的上限（防海量并列行撑爆 reason）。 */
const MAX_TIED_LIST = 8;

/**
 * 定位单个 edit 的 oldText 在文件中的状态。
 * healed 路径：行级窗口对齐——对文件每一窗口（与 oldText 行数相同）做归一化比较，
 * 全文唯一相等窗口 → 返回该窗口的文件真实原文。
 * 匹配判定（exact 计数 + 窗口扫描）保持原样；not-found 仅扩诊断资料（候选启发式 +
 * 比较窗口/展示窗口分离；原文子串锚只用于诊断）。oldText 行数超过文件时不提前返回——候选窗口截断到文件
 * 末尾，差异对账能如实报 EOF。
 */
export function locateEdit(fileText: string, oldText: string, contextLines = 3): EditLocateResult {
	const exact = countOccurrences(fileText, oldText);
	if (exact === 1) return { status: "exact-unique" };
	if (exact >= 2) return { status: "exact-multi" };

	// ── 归一化窗口扫描 ──
	const nOld = normalizeText(oldText);
	if (!nOld.trim()) return { status: "not-found" };
	const rawLines = fileText.split("\n");
	const normLines = rawLines.map((ln) => normalizeText(ln));
	const nOldLines = nOld.split("\n");
	const w = nOldLines.length;
	if (w === 0) return { status: "not-found" };
	const hits: number[] = []; // 窗口起始行号（0 基，行数组坐标）
	// 锚优化：先用首行归一化形式粗筛，再做整窗比较（大文件 O(lines) 而非 O(lines×w)）
	const anchor = nOldLines[0];
	for (let i = 0; i + w <= normLines.length; i++) {
		if (normLines[i] !== anchor) continue;
		let eq = true;
		for (let j = 1; j < w; j++) {
			if (normLines[i + j] !== nOldLines[j]) { eq = false; break; }
		}
		if (eq) { hits.push(i); if (hits.length >= 2) break; }
	}
	if (hits.length === 1) {
		const start = hits[0];
		// 原文窗口：保留文件真实形态（含最后一行的行尾衔接——用原行数组重组）
		const raw = rawLines.slice(start, start + w).join("\n");
		return { status: "healed-unique", healedText: raw, healedVia: "whitespace" };
	}
	if (hits.length >= 2) return { status: "ambiguous" };
	// ev-20261005-109214（diting quick F1 重定向）：转义层级命中**不自动执行**——转义在正则/JSON/
	// String.raw 中承载语义，oldText 的反斜杠层级可能是真实意图（实测：双反斜杠意图被自愈改坏单层
	// 正则的字符集合），「解码后相等」不能推断调用者意图。降为诊断候选（not-found 零写入 + 精确
	// 改写指引 + 可直接复制的文件真实片段）；两方向候选全量报告，不指认唯一目标（F2：跨方向并集
	// 唯一性不可内定）。
	if (hits.length === 0) {
		const escapeDiag = escapeLevelCandidates(rawLines, normLines, nOldLines);
		if (escapeDiag !== null) return { status: "not-found", candidateStatus: "escape-level", escapeCandidates: escapeDiag, candidateStartLine: escapeDiag.windows[0]!.startLine, candidateText: escapeDiag.windows[0]!.text, contextStartLine: escapeDiag.windows[0]!.startLine, contextEndLine: escapeDiag.windows[0]!.startLine + w - 1, contextText: escapeDiag.windows[0]!.text };
	}

	// ── not-found：候选启发式（首行整行锚 → 原文子串锚 → 去缩进码点公共前缀）──
	// 候选只是启发式非确认目标：唯一 → 给比较/展示窗口；并列 → 列行号不捏造；低置信 → 明示无法可靠定位。
	const anchorLines: number[] = [];
	for (let i = 0; i < normLines.length; i++) {
		if (normLines[i] === anchor) { anchorLines.push(i); if (anchorLines.length > MAX_TIED_LIST) break; }
	}
	let candidate = -1;
	let candidateStartOffset = 0;
	if (anchorLines.length === 1) {
		candidate = anchorLines[0]!;
	} else if (anchorLines.length >= 2) {
		return { status: "not-found", candidateStatus: "tied", tiedCandidateLines: anchorLines.slice(0, MAX_TIED_LIST).map((l) => l + 1) };
	} else {
		// oldText 可从行中间开始（原生支持子串匹配）。首行整行锚未命中时，先找真实原文
		// 子串锚；仅增强 not-found 诊断，绝不把其余行的内容差异改成 healed-unique。
		const rawAnchor = oldText.split("\n")[0]!;
		const substringHits: Array<{ line: number; offset: number }> = [];
		if (codepointCount(rawAnchor.trim()) >= CANDIDATE_MIN_PREFIX_CP) {
			for (let i = 0; i < rawLines.length && substringHits.length <= MAX_TIED_LIST; i++) {
				let offset = rawLines[i]!.indexOf(rawAnchor);
				while (offset !== -1 && substringHits.length <= MAX_TIED_LIST) {
					substringHits.push({ line: i, offset });
					offset = rawLines[i]!.indexOf(rawAnchor, offset + 1);
				}
			}
		}
		if (substringHits.length === 1) {
			candidate = substringHits[0]!.line;
			candidateStartOffset = substringHits[0]!.offset;
		} else if (substringHits.length >= 2) {
			return { status: "not-found", candidateStatus: "tied", tiedCandidateLines: [...new Set(substringHits.map((h) => h.line + 1))].slice(0, MAX_TIED_LIST) };
		}
		if (candidate === -1) {
			// 首行锚不足：去缩进后码点公共前缀选唯一候选（并列/低置信如实报告）
			const aStripped = anchor.replace(/^[\t ]+/, "");
			let bestCp = 0;
			const bestLines: number[] = [];
			for (let i = 0; i < normLines.length; i++) {
				const l = normLines[i]!;
				if (l.trim() === "") continue;
				const cp = codepointCommonPrefix(aStripped, l.replace(/^[\t ]+/, ""));
				if (cp === 0) continue;
				if (cp > bestCp) { bestCp = cp; bestLines.length = 0; bestLines.push(i); }
				else if (cp === bestCp) bestLines.push(i);
			}
			if (bestCp < CANDIDATE_MIN_PREFIX_CP) {
				return { status: "not-found", candidateStatus: "low-confidence" };
			}
			if (bestLines.length === 1) {
				candidate = bestLines[0]!;
			} else {
				return { status: "not-found", candidateStatus: "tied", tiedCandidateLines: bestLines.slice(0, MAX_TIED_LIST).map((l) => l + 1) };
			}
		}
	}

	// ── 唯一候选：比较窗口（候选起点后 oldText 对应跨度）+ 展示窗口（实际差异 ±3 行）──
	const spanEnd = Math.min(rawLines.length, candidate + w); // 行数受文件末尾截断（EOF 如实呈现）
	const candidateText = rawLines.slice(candidate, spanEnd).join("\n").slice(candidateStartOffset);
	let displayCenter = candidate; // 差异行（0 基）缺省锚点行；可算出实际差异时围绕差异
	const d = firstDiffAt(oldText, candidateText);
	if (d) {
		displayCenter = candidate + oldText.slice(0, d.index).split("\n").length - 1;
	}
	const dispFrom = Math.max(0, displayCenter - contextLines);
	const dispTo = Math.min(rawLines.length, displayCenter + contextLines + 1);
	const contextText = rawLines.slice(dispFrom, dispTo).join("\n");
	return {
		status: "not-found",
		candidateStatus: "unique",
		candidateStartLine: candidate + 1,
		candidateStartOffset,
		candidateStartCodepointOffset: codepointCount(rawLines[candidate]!.slice(0, candidateStartOffset)),
		candidateText,
		contextStartLine: dispFrom + 1,
		contextEndLine: dispTo,
		contextText,
		nearby: { line: candidate + 1, text: contextText },
	};
}

/** 由定位结果生成 block reason 诊断（把正确 oldText 喂到嘴边）。
 * v1.5.260：可选 oldText——not-found 且超长行场景时在诊断尾部追加「按行号替换」逃生通道；
 * 不传/短行时逃生通道不触发。
 * 复盘 2026-09-03 §5#4：not-found 且有比较窗口时追加「首个差异」定位行（见 firstDiffLine）；
 * 不传 oldText 时输出与历史逐字一致。ev-20260922-960cb3：并列候选列行号、低置信明示
 * 「无法可靠定位」，不捏造位置。 */
export function editGuardReason(file: string, index: number, res: EditLocateResult, oldText?: string): string {
	const at = res.nearby ? `（最接近位置：第 ${res.nearby.line} 行附近）` : "";
	if (res.status === "ambiguous") {
		return `[amagi edit-guard] ${path.basename(file)} edits[${index}]：oldText 归一化后在文件中出现多处（行尾/空白形态差异）（已解析基准：${path.resolve(file)}）。请用 read 查看目标位置后，复制文件真实原文作为 oldText（含足够上下文使其唯一）。${at}`;
	}
	// ev-20261005-109214（diting quick F1/F2）：转义层级候选——专用诊断（两方向计数 + 逐窗口真实片段
	// + 改写指引），不指认唯一目标、零写入；返回不落入通用 diff 诊断（口径不同）。若你的意图本就是
	// 匹配字面转义形态，请确认目标文件/位置（转义在正则/JSON/String.raw 中承载语义，不自动执行）。
	if (res.candidateStatus === "escape-level" && res.escapeCandidates) {
		const ec = res.escapeCandidates;
		const dirNote = `方向①（oldText 比 文件多一层 JSON 转义——edit 参数编码失误高频形态）候选 ${ec.dir1Count} 处；方向②（文件比 oldText 多一层）候选 ${ec.dir2Count} 处`;
		const winLines = ec.windows.slice(0, 4).map((w) => `  • 文件第 ${w.startLine} 行起（方向${w.direction}）：${truncateCodepoints(w.text.split("\n")[0]!, 70)}`);
		const firstWin = ec.windows[0]!;
		return `[amagi edit-guard] ${path.basename(file)} edits[${index}]：oldText 与文件在单层 JSON 转义解码后一致（疑似转义层级差异）——不自动执行（转义承载语义，反斜杠层级可能是你的真实意图）。${dirNote}${ec.windows.length > 4 ? `（共 ${ec.windows.length} 处，仅列前 4）` : ""}。\n修正：按下方窗口真实原文逐字复制重写 oldText（多一层转义通常应删一层）；若意图本就是匹配字面转义形态，请用 read 确认目标文件与位置。\n候选窗口：\n${winLines.join("\n")}\n首候选完整原文（可直接复制）：\n${firstWin.text}`;
	}
	const ctx = res.nearby ? `\n\n文件真实内容片段（第 ${res.nearby.line} 行附近，复制此段作 oldText，按需收窄到唯一）：\n${res.nearby.text}` : "";
	// v1.5.259：候选片段含不可见/可疑空白时附标注版（实战 2026-09-02：逐字复制仍 2 连败，
	// 缺字节级自证）——只在确实存在可疑字符时输出，正常内容差异零噪音。
	const annotated = res.nearby ? whitespaceAnnotation(res.nearby.text) : null;
	// ev-20260930-2ca29f：图例补 N⇥ 含义——行首缩进层数直接可见，不靠人眼逐个数 ⇥。
	const wsHint = annotated
		? `\n\n⚠ 该片段含不可见/可疑空白，标注版如下（␍=CR ⏎=行尾 ·＝行尾空格 ⇥=Tab N⇥=行首 N 层 Tab 缩进 □=异常空白）：\n${annotated}`
		: "";
	// v1.5.260（ev-20260903-96b827①）：超长行场景追加按行号替换逃生通道；条件不满足时追加空串，
	// 诊断文案与现状逐字一致（零噪音原则）。
	const escape = oldText !== undefined ? longLineEscapeHatch(file, res, oldText) : null;
	// ev-20260922-960cb3：候选是启发式非确认目标——并列列行号；低置信明示无法可靠定位。
	const tiedList = res.tiedCandidateLines ?? [];
	const candidateNote = tiedList.length > 0
		? `\n\n启发式并列候选：第 ${tiedList.slice(0, MAX_TIED_LIST).join("、")} 行${tiedList.length > MAX_TIED_LIST ? ` 等 ${tiedList.length} 处` : ""}——候选只是启发式，无法唯一确定目标位置（不捏造定位）。请用 read 打开确认后逐字复制真实原文。`
		: res.candidateStatus === "low-confidence"
			? "\n\n无法可靠定位：首行锚与码点公共前缀均无足够置信的候选，不捏造文件位置——请用 read 打开目标区域确认真实内容。"
			: "";
	// 复盘 2026-09-03 §5#4 + ev-20260922-960cb3：有比较窗口（candidateText）时高亮首个差异——
	// 对账基准是比较窗口（候选起点后 oldText 对应跨度），不再从展示窗口猜比较起点。
	const diffLine = oldText !== undefined && res.candidateText !== undefined ? firstDiffLine(oldText, res) : null;
	return `[amagi edit-guard] ${path.basename(file)} edits[${index}]：oldText 与文件内容不匹配${at}（已解析基准：${path.resolve(file)}）。禁止凭记忆重构 oldText——用 read 打开目标区域，从输出中逐字复制。${candidateNote}${ctx}${wsHint}${diffLine ? `\n\n${diffLine}` : ""}${escape ?? ""}`;
}

// ── 首个差异字符高亮（复盘 2026-09-03 §5#4；ev-20260922-960cb3 升级为码点遍历） ──────

/** 首个差异（纯函数结果）：code-unit offset 供 slice；codepointIndex 供 ASCII 诊断。 */
export interface FirstDiff {
	/** 首个不等处的 code-unit 偏移（两侧按码点同步推进，等码点等长度——偏移对两侧一致，可直接 slice）。 */
	index: number;
	/** 首个不等处的码点序号（0 基）；ASCII 行的 1 基字符位 = 行内码点数 + 1。 */
	codepointIndex: number;
	/** oldText 侧完整码点（字符串真结束时为空串——∅ 只在该语义下出现）。 */
	aChar: string;
	/** 比较目标侧完整码点（真结束时为空串）。 */
	bChar: string;
}

/**
 * 计算首个差异（纯函数）：按码点遍历到首个不等处；任一方先结束也算差异（位置取已推进
 * 的 code-unit 偏移，先结束方字符为空串）；完全相等 → null。
 * ev-20260922-960cb3：emoji 等 astral 字符按完整码点比较与返回——不再把代理对拆成
 * 孤立 surrogate（UTF-16 code-unit 直比的假差异/假定位）。
 */
export function firstDiffAt(a: string, b: string): FirstDiff | null {
	let ai = 0, bi = 0, cp = 0;
	while (ai < a.length && bi < b.length) {
		const aCp = a.codePointAt(ai)!;
		const bCp = b.codePointAt(bi)!;
		if (aCp !== bCp) {
			return { index: ai, codepointIndex: cp, aChar: String.fromCodePoint(aCp), bChar: String.fromCodePoint(bCp) };
		}
		ai += aCp > 0xffff ? 2 : 1;
		bi += bCp > 0xffff ? 2 : 1;
		cp++;
	}
	if (ai < a.length || bi < b.length) {
		return {
			index: Math.min(ai, bi),
			codepointIndex: cp,
			aChar: ai < a.length ? String.fromCodePoint(a.codePointAt(ai)!) : "",
			bChar: bi < b.length ? String.fromCodePoint(b.codePointAt(bi)!) : "",
		};
	}
	return null;
}

/** 差异字符展示：不可见字符显示转义形式（\t、\r、\n）；空格显示 ␠；一方真结束显示 ∅。
 *  ev-20260922-960cb3：接收完整码点——astral 字符（emoji 等）整字展示，不拆孤立 surrogate。 */
function displayChar(ch: string): string {
	if (ch === "") return "∅";
	if (ch === "\t") return "\\t";
	if (ch === "\r") return "\\r";
	if (ch === "\n") return "\\n";
	if (ch === " ") return "␠";
	return ch;
}

// ── ev-20260924-ec1285：差异字符分类（纯函数，与位置口径解耦） ───────────────────

/** 全角↔半角标点映射（中文场景高频失配族）。 */
const FULLWIDTH_PUNCT_MAP: ReadonlyMap<string, string> = new Map([
	["，", ","], ["。", "."], ["：", ":"], ["；", ";"], ["！", "!"], ["？", "?"],
	["（", "("], ["）", ")"], ["【", "["], ["】", "]"], ["《", "<"], ["》", ">"], ["〈", "<"], ["〉", ">"],
	["、", ","], ["～", "~"], ["％", "%"], ["＆", "&"], ["＊", "*"], ["＋", "+"], ["＝", "="], ["－", "-"], ["／", "/"], ["｜", "|"],
]);
const CURLY_QUOTES = new Set(["“", "”", "‘", "’"]);
const STRAIGHT_QUOTES = new Set(['"', "'"]);
const SPACES = new Set(["\u3000", "\u00A0", " ", "\u2002", "\u2003", "\u2007", "\u202F"]);
const ZERO_WIDTH = new Set(["\u200B", "\u200C", "\u200D", "\uFEFF"]);

/** 不可见字符只显码位（空格族/零宽/控制符等），可见字符「字符」U+XXXX 形态。
 *  diting F6 修复：ASCII 可见区收窄 0x21-0x7E——C1 控制符（U+0080-U+009F）不再被判可见
 *  原样直出 reason 文本（原始控制字符不经转义进入终端）。 */
function quoteWithCodepoint(ch: string): string {
	if (ch === "") return "∅";
	const cp = ch.codePointAt(0)!;
	const visible = !/[\p{C}\p{Z}]/u.test(ch);
	return visible ? `「${ch}」U+${cp.toString(16).toUpperCase().padStart(4, "0")}` : `「U+${cp.toString(16).toUpperCase().padStart(4, "0")}」`;
}

/**
 * ev-20260924-ec1285（P2）：差异字符分类（纯函数）——中文场景高频失配是全角/半角引号、
 * 中英文标点、全角空格 U+3000、NBSP、零宽字符等视觉等价字符；模型对两段 60 字片段肉眼
 * 对比看不出差别，只能整段重抄，每次多耗 1-2 轮。分类行把差异字符本身讲清楚。
 * 返回类别说明（null=无分类价值，如 EOF ∅ 或完全同字符）；不改 locateEdit 匹配判定
 * （不做归一化自愈——静默改写字面内容越权，诊断只负责把差异讲清楚）。
 */
export function classifyCharDiff(aChar: string, bChar: string): string | null {
	if (aChar === "" || bChar === "" || aChar === bChar) return null;
	if (ZERO_WIDTH.has(aChar) || ZERO_WIDTH.has(bChar)) return "零宽字符（U+200B-U+200D/U+FEFF——零宽空格/连接符不可见，常由复制粘贴混入）";
	if (SPACES.has(aChar) && SPACES.has(bChar)) {
		const name = (c: string) => c === " " ? "普通空格" : c === "\u3000" ? "全角空格 U+3000" : c === "\u00A0" ? "NBSP U+00A0" : `U+${c.codePointAt(0)!.toString(16).toUpperCase()}`;
		return `空格形态（${name(aChar)} ⇄ ${name(bChar)}——视觉等价不可见差异）`;
	}
	if ((CURLY_QUOTES.has(aChar) || CURLY_QUOTES.has(bChar)) && (STRAIGHT_QUOTES.has(aChar) || STRAIGHT_QUOTES.has(bChar))) return "弯引号↔直引号（中文排版“”‘’ ⇄ 英文直引号——最高频失配源）";
	const fullA = FULLWIDTH_PUNCT_MAP.get(aChar), fullB = FULLWIDTH_PUNCT_MAP.get(bChar);
	if ((fullA !== undefined && fullA === bChar) || (fullB !== undefined && fullB === aChar)) return "全角↔半角标点（中文标点 ⇄ 英文标点）";
	if ((aChar === "\t" || bChar === "\t") && (aChar === " " || bChar === " ")) return "Tab↔空格（缩进形态不同）";
	if (aChar.toLowerCase() === bChar.toLowerCase() && /\p{L}/u.test(aChar)) return "大小写（仅大小写不同）";
	return null; // 其他类不硬分类——给出误导性类别比不给更糟
}

/** 上下文片段展示：仅转义控制字符（保持单行），空格等可见形态原样（差异点才用 ␠ 聚焦）。 */
function ctxEscape(s: string): string {
	return s.replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}

/** 行是否纯 ASCII（任一侧对应行含非 ASCII → 不报字符列号，只给行号与两侧片段）。 */
function isAsciiLine(s: string): boolean {
	for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) > 0x7f) return false;
	return true;
}

/** 候选清单无差异位置时按码点截头；firstDiffLine 必须使用 focusedLine。 */
function truncateCodepoints(s: string, max: number): string {
	const cps = Array.from(s);
	return cps.length <= max ? s : `${cps.slice(0, max).join("")}…`;
}

/** 长行围绕实际差异截取，不能只截共同前缀；完整码点切片，隐形字符显式转义。 */
function focusedLine(s: string, codepointIndex: number, char: string): string {
	const cps = Array.from(s);
	if (cps.length <= 60) return s;
	const start = Math.max(0, codepointIndex - 25);
	const end = Math.min(cps.length, codepointIndex + (char ? 1 : 0) + 25);
	const escape = (text: string): string => ctxEscape(text).replace(/[\p{C}\p{Z}]/gu, (ch) =>
		ch === " " ? ch : `\\u{${ch.codePointAt(0)!.toString(16).toUpperCase()}}`);
	return `${start > 0 ? "…" : ""}${escape(cps.slice(start, codepointIndex).join(""))}▸${escape(displayChar(char))}◂${escape(cps.slice(codepointIndex + (char ? 1 : 0), end).join(""))}${end < cps.length ? "…" : ""}`;
}

/** 取 offset 所在行（不含换行符）。 */
function lineAt(text: string, offset: number): string {
	const start = text.lastIndexOf("\n", Math.max(0, offset - 1)) + 1;
	const nl = text.indexOf("\n", start);
	return nl === -1 ? text.slice(start) : text.slice(start, nl);
}

/** 行首缩进（tab/空格）。 */
function indentOf(s: string): string {
	return /^[\t ]*/.exec(s)?.[0] ?? "";
}

/** 字符串码点计数。 */
function codepointCount(s: string): number {
	let n = 0;
	for (let i = 0; i < s.length; n++) i += s.codePointAt(i)! > 0xffff ? 2 : 1;
	return n;
}

/**
 * oldText 与比较窗口（candidateText）的首个差异定位行（无差异/无比较窗口 → null，零噪音）。
 * ev-20260922-960cb3 重排：
 *  - 接收定位资料（EditLocateResult），对账基准是候选起点后 oldText 对应跨度的比较窗口——
 *    不再从展示窗口（±3 行）猜比较起点（旧法在 oldText 超过窗口行数时必在窗口终点报
 *    假 ∅/假差异）；
 *  - ASCII 行报 1 基字符位（码点计）与文件对应行号；非 ASCII 行报行号、两侧差异片段与
 *    码点位置，明确不当作屏幕列（组合字符/全角宽度下码点 ≠ 屏幕列）；
 *  - ∅ 只在字符串真结束时出现：文件侧 ∅ = 比较窗口已延伸到文件末尾（EOF，非展示截断）；
 *    oldText 侧 ∅ = oldText 在此结束而文件侧仍有内容。空行/换行形态差异显式标注。
 *  - 缩进形态差异直出两侧行首转义形态（ev-20260920-d146cc① 的实战价值保留）。
 */
export function firstDiffLine(oldText: string, res: EditLocateResult): string | null {
	const candidateText = res.candidateText;
	if (candidateText === undefined) return null; // 并列/低置信/无定位资料——不猜比较起点
	const d = firstDiffAt(oldText, candidateText);
	if (!d) return null; // 与比较窗口完全一致（差异在窗口外/仅展示截断）——零噪音，不报 ∅
	const prefixA = oldText.slice(0, d.index);
	const lineNo = prefixA.split("\n").length; // 差异在 oldText 第几行（1 基）
	const prefixB = candidateText.slice(0, d.index);
	const windowLineNo = prefixB.split("\n").length; // 比较窗口内行号（1 基；对账同步推进）
	const fileLineNo = (res.candidateStartLine ?? res.nearby?.line ?? 1) + windowLineNo - 1;
	const oldLine = lineAt(oldText, d.index);
	const fileLine = lineAt(candidateText, d.index);
	// EOF/结束语义：∅ 只在真结束时出现，且注明是 EOF 还是 oldText 先结束（区分展示截断）
	const endNote = d.bChar === ""
		? "（文件侧：比较窗口已延伸到文件末尾——EOF，非展示截断）"
		: d.aChar === ""
			? "（oldText 在此结束；文件侧仍有内容）"
			: "";
	const lineEndNote = endNote === "" && (d.aChar === "\n" || d.aChar === "\r" || d.bChar === "\n" || d.bChar === "\r")
		? "（差异在行尾/换行形态——两侧的换行或空行结构不同）"
		: "";
	const ascii = isAsciiLine(oldLine) && isAsciiLine(fileLine);
	// ev-20260924-ec1285：差异字符分类行——ASCII/非 ASCII 行都追加（与位置口径解耦：分类讲
	// “差在哪个字符类型”，定位仍按原口径不给非 ASCII 列号）；EOF ∅/无分类价值时零噪音不追加。
	const klass = classifyCharDiff(d.aChar, d.bChar);
	const klassNote = klass ? `\n差异字符类型：${klass}（oldText ${quoteWithCodepoint(d.aChar)} ⇄ 文件 ${quoteWithCodepoint(d.bChar)}）` : "";
	// ev-20261005-109214：转义层级差异识别——两侧行单层解码后一致而原行不等 → 明示改写方向
	// （字符级差异显示转义字符本身，难以直接翻译成「减一层转义」的改写动作；healed 第二层未
	// 命中时（解码后也非唯一/行数不同）此诊断是最后防线）。
	// diting quick F4：单向层级关系才标「层级差异」（旧双侧解码相等会把「两侧各含不同转义写法」
	// 误标为层级差异——差异与层级无关时误导改写方向）。
	const escapeNote = oldLine !== fileLine && (unescapeOnce(oldLine) === fileLine || oldLine === unescapeOnce(fileLine))
		? `\n疑似转义层级差异（单向：一侧解码一层后等于另一侧原文）——请按上方「文件该行＝」逐字复制真实形态重写 oldText（常见：oldText 的 \\uXXXX/\\\\ 比文件多一层转义；若意图本就是字面转义形态请先 read 确认目标）`
		: "";
	const lineStart = prefixA.lastIndexOf("\n") + 1;
	const cpOffset = codepointCount(oldText.slice(lineStart, d.index));
	const fileCpOffset = cpOffset + (windowLineNo === 1 ? res.candidateStartCodepointOffset ?? 0 : 0);
	if (!ascii) {
		// 码点位置与终端屏幕列明确分开；任意真实字差都给两侧码点，不依赖有限的分类词表。
		const pointNote = `\n差异码点（oldText 行内第 ${cpOffset + 1} 个码点；文件行内第 ${fileCpOffset + 1} 个码点，非屏幕列）：oldText ${quoteWithCodepoint(d.aChar)} ⇄ 文件 ${quoteWithCodepoint(d.bChar)}`;
		return `首个差异在 oldText 第 ${lineNo} 行 / 文件第 ${fileLineNo} 行（该行含非 ASCII 字符，不报字符列号）：oldText 该行＝「${focusedLine(oldLine, cpOffset, d.aChar)}」 ⇄ 文件该行＝「${focusedLine(fileLine, cpOffset, d.bChar)}」${pointNote}${lineEndNote}${endNote}${klassNote}${escapeNote}`;
	}
	const col = cpOffset + 1; // 1 基字符位（码点计）
	const before = oldText.slice(Math.max(lineStart, d.index - 20), d.index);
	// ◂ 后文取文件侧（ev-20260920-d146cc②：读者核对的是文件内容）；按完整码点推进
	const afterStart = d.index + d.bChar.length;
	const fileAfter = candidateText.slice(afterStart, afterStart + 20);
	const oldIndent = indentOf(oldLine);
	const fileIndent = indentOf(fileLine);
	const indentNote = oldIndent !== fileIndent && d.index - lineStart <= Math.max(oldIndent.length, fileIndent.length)
		? `；行首 oldText=${JSON.stringify(oldIndent)} ⇄ 文件=${JSON.stringify(fileIndent)}`
		: "";
	return `首个差异在 oldText 第 ${lineNo} 行第 ${col} 个字符（文件对应第 ${fileLineNo} 行${indentNote}）：…${ctxEscape(before)} ▸ oldText=${displayChar(d.aChar)} ⇄ 文件=${displayChar(d.bChar)}${endNote}${lineEndNote}${klassNote}${escapeNote} ◂ 后文(文件)=${ctxEscape(fileAfter)}…`;
}

// ── 超长行定向读取与范围引用恢复 ────────────────────────────────────────────────

/** v1.5.260（ev-20260903-96b827①）：超长行阈值——oldText 任一行字符数超过该值即视为超长行场景。 */
export const LONG_LINE_THRESHOLD = 500;

/**
 * 长中文行细节误记时，引导模型取得完整原文与版本引用。
 * 仅 not-found + 唯一候选锚点 + 超长行时输出；歧义位置不给定向建议。
 */
export function longLineEscapeHatch(file: string, res: EditLocateResult, oldText: string): string | null {
	if (res.status !== "not-found" || !res.nearby) return null;
	if ((res.candidateStartOffset ?? 0) > 0) return null; // 行中锚不能用整行替换模板（会误吞前缀）
	const oldLines = String(oldText).replace(/\r\n?/g, "\n").split("\n");
	if (!oldLines.some((ln) => ln.length > LONG_LINE_THRESHOLD)) return null;
	return `\n\n超长行恢复：用 read(${JSON.stringify({ path: file, offset: res.nearby.line, limit: oldLines.length, editReference: true })}) 取得完整真实范围与版本引用，再用 edit 的 selection + newText 替换整行；文件发生变化时重新读取，不直接沿用裸行号写入。`;
}

/** v1.5.259：可疑空白检测与可视化。返回标注版文本；无任何可疑字符时返回 null（零噪音）。
 *  ev-20260930-2ca29f：行首连续 Tab 聚合为「N⇥」（N=层数，含 1⇥——口径统一）——机器已知道
 *  层数，直接给出，消除「tab 层数凭记忆数错」的 2-3 轮往返；行内 Tab 与其它可疑空白
 *  标记维持单字符现状（⇥/·/␍/□）。标注版仅是对照辅助，不改变 oldText 匹配语义。 */
export function whitespaceAnnotation(text: string): string | null {
	if (!text) return null;
	const lines = text.split("\n");
	const annotated = lines.map((line) => {
		let suspicious = false;
		// 顺序：先标行尾空格（CR 前或行尾），再标 CR——否则 ␍ 在末尾时 ` +$` 匹配不到
		let out = line.replace(/( +)(\r?$)/, (_m, spaces: string, tail: string) => { suspicious = true; return spaces.replace(/ /g, "·") + tail; });
		out = out.replace(/\r$/, () => { suspicious = true; return "␍"; });
		// ev-20260930-2ca29f：行首连续 Tab 先聚合为「N⇥」（其余位置——空格后/行内——仍是单字符 ⇥）
		out = out.replace(/^\t+/, (m) => { suspicious = true; return `${m.length}⇥`; });
		out = out.replace(/[\t]/g, () => { suspicious = true; return "⇥"; });
		out = out.replace(/[\u00a0\u2000-\u200a\u202f\u205f\u3000\ufeff\u200b\u200c\u200d]/g, () => { suspicious = true; return "□"; });
		return suspicious ? out : null;
	});
	if (annotated.every((line) => line === null)) return null;
	return annotated.map((line, i) => line ?? lines[i]).join("\n");
}

// ── 标题结构防护（8月迭代第三轮 P1：文档回填「标题吞噬」3 次/会话） ─────────────

const ATX_HEADING = /^#{1,6}\s+\S/;

function isMarkdownFile(p: string): boolean {
	return /\.(md|markdown|mdx)$/i.test(p);
}

/** 提取文本块中的 ATX 标题行（归一化后去重，保持出现顺序）。 */
function headingLines(text: string): string[] {
	const seen = new Set<string>();
	const out: string[] = [];
	for (const ln of String(text).split("\n")) {
		if (!ATX_HEADING.test(ln)) continue;
		const n = normalizeText(ln).trim();
		if (n && !seen.has(n)) { seen.add(n); out.push(n); }
	}
	return out;
}

export interface HeadingCheckResult {
	/** 疑似误吞被删除的标题行（归一化形式）。 */
	deletedHeadings: string[];
}

/**
 * 标题吞噬检测（纯函数）：oldText 中的标题行若在 newText 中整体消失，且没有同等数量的
 * 新标题补位（重命名/降级会 1:1 替换），即疑似锚点过宽误吞相邻标题——文档回填场景
 * 最常见事故（2026-08-18 会话 3 次，每次 3-5 轮修复）。
 * 逃生门：oldText 只由标题行（含空行）组成 → 明确的最小化删除意图，放行。
 */
export function checkHeadingDeletion(oldText: string, newText: string): HeadingCheckResult {
	const oldH = headingLines(oldText);
	if (oldH.length === 0) return { deletedHeadings: [] };
	const newSet = new Set(headingLines(newText));
	const deleted = oldH.filter((h) => !newSet.has(h));
	if (deleted.length === 0) return { deletedHeadings: [] };
	// 重命名/换级 1:1 替换：新增标题数 == 删除标题数 → 视为有意替换，放行
	const oldSet = new Set(oldH);
	const added = headingLines(newText).filter((h) => !oldSet.has(h));
	if (deleted.length <= added.length) return { deletedHeadings: [] };
	// 逃生门：oldText 仅含标题行与空行 → 最小化删除意图，放行
	const nonHeading = String(oldText).split("\n").some((ln) => ln.trim() !== "" && !ATX_HEADING.test(ln));
	if (!nonHeading) return { deletedHeadings: [] };
	return { deletedHeadings: deleted };
}

/** 标题防护 block reason（列出被吞标题 + 拆分编辑指引）。
 *  B4A（ev-20261012-af58eb 批A）：携 guard-rule 标签 edit.headingDeletion（信号层）；对照式
 *  披露——把删除意图写明确（最小 edit 只含标题行）是本门要求的形态而非绕过，判定不变。 */
export function headingGuardReason(file: string, index: number, deleted: string[]): string {
	const listed = deleted.slice(0, 5).map((h) => `  ${h}`).join("\n") + (deleted.length > 5 ? `\n  …另有 ${deleted.length - 5} 行` : "");
	return `[amagi edit-guard·edit.headingDeletion] ${path.basename(file)} edits[${index}]：本次编辑将删除 ${deleted.length} 行 markdown 标题，但未发现同等数量的新标题补位（非重命名）——疑似锚点过宽误吞相邻标题（文档回填高频事故）：\n${listed}\n若为有意删除：请拆分编辑，单独发一条只含标题行的最小 edit（oldText=标题行本身，newText=空）删除标题——对照：这不是绕过，正是把删除意图写明确；若为误吞：缩小 oldText 范围排除标题行后重试。`;
}

/** B4·批B（D7 disclose）披露文案：含行范围（lineRange 缺席时仅标题计数——事件链/不可读
 *  场景的降级形态）；恢复路径指向本次结果 diff 的删除行（用户认可后可反向恢复，共享树
 *  不被自动覆盖）。事实/推测分句（批A 对照式规范）。 */
export function headingDeletionDisclosure(file: string, index: number, deleted: string[], lineRange?: { start: number; end: number }): string {
	const listed = deleted.slice(0, 5).map((h) => `  ${h}`).join("\n") + (deleted.length > 5 ? `\n  …另有 ${deleted.length - 5} 行` : "");
	return `[amagi guard:edit.headingDeletion｜已放行] ${path.basename(file)} edits[${index}]：本次编辑删除了 ${deleted.length} 行 markdown 标题${lineRange ? `（行范围 L${lineRange.start}-L${lineRange.end}）` : ""}且无补位。检测事实：疑似锚点过宽误吞（文档回填高频形态）；推测：这可能是有意的结构重组，也可能是误删——已按 disclose 放行，不阻断。恢复路径：本次结果的 diff 已含被删标题原文（用户认可后可据此反向恢复；未自动覆盖共享树或回滚任何文件）。配置：rule 可收紧回 block（仅影响新调用；来源见 /amagi config explain）。\n${listed}`;
}

/**
 * 标题删除检查（守卫与 override 共用的接点）：给定目标文件与 (index, oldText, newText)
 * 对，返回 block reasons。非 markdown 目标或无违规 → 空数组。检查只依赖编辑自身的字面
 * 内容（不依赖文件内容匹配）——可在任何写入前独立完成（A1 ev-20260921-2e6b4f）。
 */
export function headingDeletionReasons(file: string, pairs: ReadonlyArray<{ index: number; oldText: string; newText: string }>): string[] {
	if (!isMarkdownFile(file)) return [];
	const reasons: string[] = [];
	for (const p of pairs) {
		const hc = checkHeadingDeletion(p.oldText, p.newText);
		if (hc.deletedHeadings.length > 0) reasons.push(headingGuardReason(file, p.index, hc.deletedHeadings));
	}
	return reasons;
}

// ── 注册器 ─────────────────────────────────────────────────────────────────

export interface EditGuardPi {
	on(event: "tool_call", handler: (event: { toolName: string; input: Record<string, unknown> }, ctx?: {cwd?: string}) => { block?: boolean; reason?: string } | void): void;
}

export interface EditGuardDeps {
	/** 工作目录（path/files 相对解析基准）。 */
	cwd?: string;
	/** 诊断输出（缺省 console.warn；传 null 静音）。 */
	diag?: ((msg: string) => void) | null;
}

/**
 * 注册 edit 事件护栏。返回处理函数（测试可直接驱动）。
 * A1（ev-20260921-2e6b4f）职责边界——只做两件事，均可在执行前独立完成：
 *  ① normalizeEditInput 形状归一（现代 path / 扩展 files / 旧 file_path；冲突报错；
 *    归一写回 event.input——官方原地改写通道）；
 *  ② 字面标题删除检查（markdown 目标；regex 项跳过——由 edit-override 解析成实际
 *    字面编辑后在写入前检查，守卫不持有第二份匹配算法）。
 * 匹配/自愈/not-found 拒绝全部不在本护栏（原生 fuzzy 不得被抢先拒绝；失败增强归
 * edit-override 的 recoverNativeFailure）。形状错误（空 edits/非法类型/目标冲突/目标
 * 缺失）明确 block；非 edit 事件零干预。守卫自身零文件 IO。
 */
export function registerEditGuard(pi: EditGuardPi, deps: EditGuardDeps = {}): (event: { toolName: string; input: Record<string, unknown> }, ctx?: {cwd?: string}) => { block?: boolean; reason?: string } | void {
	const diag = deps.diag === null ? undefined : deps.diag ?? ((m: string) => console.warn(m));
	const handle = (event: { toolName: string; input: Record<string, unknown> }, ctx?: {cwd?: string}): { block?: boolean; reason?: string } | void => {
		if (event.toolName !== "edit") return; // 非 edit 事件零干预
		const cwd = ctx?.cwd || deps.cwd || process.cwd();
		const outcome = normalizeEditInput(event.input, cwd);
		if (!outcome.ok) {
			diag?.(`[amagi edit-guard] edit 输入形状错误，已 block：${outcome.reason}`);
			return { block: true, reason: outcome.reason };
		}
		if (outcome.kind === "patch" || outcome.kind === "selection") return; // 实际删除标题检查由 override 解析后、写入前执行。
		const targets = outcome.kind === "single" ? [outcome.path] : outcome.files;
		const reasons: string[] = [];
		for (const t of targets) {
			const abs = resolveBuiltinFileTarget(t, cwd);
			const pairs: Array<{ index: number; oldText: string; newText: string }> = [];
			for (let i = 0; i < outcome.edits.length; i++) {
				const e = outcome.edits[i]!;
				if (e.regex === true) continue; // regex 由 override 解析为字面编辑后再检查（写入前）
				pairs.push({ index: i, oldText: e.oldText, newText: e.newText });
			}
			reasons.push(...headingDeletionReasons(abs, pairs));
		}
		// B4·批B（D7）：rule=disclose → 不 block（检测照常；披露由 edit-override 写入路径附加到
		// 成功结果——含行范围；事件链无结果注入通道，此处只留 diag 观测，不放行面无第二判定）。
		if (guardRuleOf("edit.headingDeletion", cwd, guardProjectTrustedOf(ctx)) === "disclose") {
			if (reasons.length > 0) diag?.(`[amagi edit-guard] ${reasons.length} 处标题删除按 edit.headingDeletion=disclose 放行（披露由 edit 工具结果附加）`);
			return;
		}
		if (reasons.length > 0) {
			diag?.(`[amagi edit-guard] ${reasons.length} 处编辑疑似误吞 markdown 标题，已 block（多文件一项失败全体零写入）`);
			return { block: true, reason: reasons.join("\n\n") };
		}
		return;
	};
	pi.on("tool_call", handle as Parameters<EditGuardPi["on"]>[1]);
	return handle;
}
