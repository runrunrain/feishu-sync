/**
 * orphan-reaper.ts — amagi 血统孤儿进程扫描与级联回收（ev-20260917-7b9298 / P2）。
 *
 * 痛点：bash 600s 超时父进程被杀，但命令树中脱离进程组的孙进程（node --test 挂起子进程、
 * 命令内部自行 setsid/新组的进程）不受 pi 原生 killProcessTree(-pgid) 覆盖，跨会话累积僵尸。
 * ProcessAuditor（ev-1face0）只覆盖「子 pi 派发树」且依赖运行期 ps 采样曾见过；Leader 自身
 * bash 超时遗留与跨会话历史残留均无回收链。
 *
 * 机制（环境标记识别，evo 方向 b）：
 *   - bash-override spawnHook 为每次 bash 注入 AMAGI_BASH_INVOCATION=<uuid> +
 *     AMAGI_BASH_ROOT_PID=<pi进程pid>（env 随命令树全层继承，setsid 也不丢）。
 *   - invocation 精确回收（自动，bash 超时/中止收尾触发）：扫描 env 同时命中本次
 *     invocation 与 root pid 的进程，在候选捕获时形成不可变出生锚点后逐进程回收
 *     （个人 PID 的 SIGTERM→宽限→SIGKILL，不使用进程组信号）。tag 唯一 → 只杀本次
 *     超时命令树遗孤，绝不波及：并行 rpc/任务进程（不同 env）、历史故意后台进程
 *     （不同 invocation tag）、run_bg 登记进程（run-bg 模块独立 spawn，不经 bash hook）。
 *   - 全局孤儿诊断（/amagi orphans）：ppid=1（init 收养=父链已死）且 env 带 amagi 血统标记
 *     （AMAGI_BASH_INVOCATION/AMAGI_SUBAGENT/AMAGI_TASK_ID）→ 诊断时以「出生读取 → 归属/
 *     ppid/keep 资格快照 → 出生重读」括号形成不可变出生锚点（I2），列出 pid/命令/标记；
 *     /amagi orphans clean 显式回收（排除 run_bg 活跃句柄 pid，防误杀托管后台任务）。
 *
 * 平台与安全底线：仅 darwin/linux；ps/proc 不可用静默降级不杀（best-effort 绝不误杀）；
 * pid<=1 硬拒绝；AMAGI_BASH_ORPHAN_REAPER=0 关闭自动回收路径（诊断入口不受开关影响）。
 *
 * ev-20261008-30e744（R3 + F-01 切片 A「不可变诊断证据对象」）：env tag 只是路由逃选器，
 * 不是原子身份。清理授权只绑定诊断（候选捕获）时刻的不可变证据：精确内核出生 token
 * （darwin libproc 微秒级 birth token / linux /proc stat starttime）+ 全部血统键的归属值
 * （键名交集不构成授权，I3）。锚点只在括号双读一致时形成（Object.freeze，I2/I8）；无锚点
 * 目标（旧形态诊断、探针不可用、双读不一致）一律不发任何信号并按原因披露（I1）。清理侧
 * 不从当前 PID 首次学习授权——期望恒为诊断记录，当前快照只做核对（I4）；TERM 与 KILL 前
 * 各自重读出生 token 与锚点比较，宽限窗内 token 改变（无法排除 PID 复用）→ 跳过 KILL（I5）；
 * 清理时仍复核诊断资格（存活/ppid===1/keepPids，I6）。禁止回退 command 文本、启动时间
 * 容差、PID 数值作为授权依据。数值 PID 从查询到发信号存在非原子窗口，不构成原子句柄保证。
 *
 * env 读取（ev-20261012-2ca6a7 argv/env 分离 + B7 修复轮 F03 加固）：macOS 包围式三快照——
 * args 前读（`ps axww -o pid=,ppid=,args=`）→ eww（`ps axeww -o pid=,ppid=,command=`）→ args
 * 复读；eww 行剥去 argv 前缀（后随空白）得 env 尾，前缀不匹配（exec/退出/渲染差异）→ env
 * 未知 → 不匹配血统（保守）。血统解析只作用于 env 尾——argv 伪造 AMAGI_XXX= 字样不再命中；
 * 同化身 setproctitle/title 前缀扩展竞态（diting title-race 实测形态）由包围式复读拒绝：前后
 * 两次 args 对同一 pid 的 argv/ppid 不一致 → env 未知。出生锚点只验证化身同一性，**不构成
 * argv/env 字符串来源证明**（同化身改 title 对出生 token 不可见）——不得以锚点兜底该风险。
 * 残余非原子窗口如实披露：括号内状态「变去又变回」或末读之后变化无法由有限次采样排除，不
 * 承诺零 argv 影响。OrphanProc.command 只存 argv（进程展示脱敏策略完整遮蔽后截断，F01），
 * 诊断摘要零 env 片段。Linux 逐 /proc/<pid>/environ（argv 与 env 天然分离，路径保持）。
 */

import { execFile } from "node:child_process";
import { promisify } from "node:util";
import * as fs from "node:fs";
import { readKernelProcessIdentities, type KernelProcessIdentity } from "./process-audit.ts";
import { redactProcessDisplayText } from "./task-query-wire.ts";

const execFileAsync = promisify(execFile);

export const ENV_INVOCATION = "AMAGI_BASH_INVOCATION";
export const ENV_ROOT_PID = "AMAGI_BASH_ROOT_PID";
/** amagi 血统标记（诊断孤儿命中任一即列；不含 AMAGI_* 开关键，防误报）。 */
export const AMAGI_LINEAGE_ENV_KEYS: readonly string[] = [ENV_INVOCATION, ENV_ROOT_PID, "AMAGI_SUBAGENT", "AMAGI_TASK_ID", "AMAGI_AGENT"];

export interface OrphanProc {
	pid: number;
	ppid: number;
	command: string;
	/** 命中的 amagi 血统 env 键。 */
	tags: string[];
	/** 本进程 env 中的 invocation tag（命中 AMAGI_BASH_INVOCATION 时非空）。 */
	invocation?: string;
	/** 本进程 env 中的 root pid 字符串（命中 AMAGI_BASH_ROOT_PID 时非空）。 */
	rootPid?: string;
	/** 全部命中血统键 → 值（I3 归属值入锚；旧形态 entry 可能缺失，回退合成 invocation/rootPid）。 */
	ownership?: Readonly<Record<string, string>>;
	/** 诊断期不可变出生锚点（I1：无锚点的目标一律不可清理，fail-closed）。 */
	anchor?: Readonly<OrphanAnchor>;
	/** 诊断期无法绑定身份的原因（探针不可用/抛错、括号双读不一致、括号内资格漂移）。 */
	unanchored?: string;
}

/**
 * ev-20261008-30e744 F-01 切片 A：诊断期不可变出生锚点。只在诊断/候选捕获阶段经
 * 「出生读取 → 归属/ppid/keep 资格快照 → 出生重读」括号形成（I2）；清理侧禁止从当前
 * PID 首次学习授权——TERM/KILL 准入与锚点比较（I5），归属值逐键核对（I3）。
 */
export interface OrphanAnchor {
	/** 诊断时刻的精确内核出生 token（括号双读一致才形成）。 */
	identityToken: string;
	/** 括号中资格快照记录的全部血统键值（键名交集不构成授权）。 */
	ownership: Readonly<Record<string, string>>;
	/** 括号快照中的父进程号（诊断清理路径恒为 1；清理时复核不回退）。 */
	ppid: number;
	/** 锚点形成时刻（ISO 8601，仅证据时间戳，不作为授权依据）。 */
	observedAt: string;
}

export interface OrphanDeps {
	platform?: NodeJS.Platform;
	env?: NodeJS.ProcessEnv;
	/** 覆盖「全进程 env 快照」实现（默认按平台 ps axeww / /proc；测试注入）。 */
	snapshotEnvs?: () => Promise<OrphanProc[]>;
	kill?: (pid: number, signal: NodeJS.Signals) => void;
	isAlive?: (pid: number) => boolean;
	sleep?: (ms: number) => Promise<void>;
	log?: (msg: string) => void;
	/** 精确内核出生身份读取（默认复用 process-audit 的真实探针；测试注入）。 */
	readIdentities?: (pids: readonly number[]) => Map<number, KernelProcessIdentity>;
	/** 清理时复核 keepPids（run_bg 活跃句柄等；I6，仅诊断清理路径采用）。 */
	keepPids?: ReadonlySet<number>;
}

const TERM_GRACE_MS = 2_000;

/** 自动回收开关（诊断入口不受此开关影响）。 */
export function orphanReaperEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return !(env.AMAGI_BASH_ORPHAN_REAPER === "0" || /^(false|off|no)$/i.test(env.AMAGI_BASH_ORPHAN_REAPER || ""));
}

function parseEnvValue(raw: string, key: string): string | undefined {
	const m = raw.match(new RegExp(`(?:^|\\s)${key}=([^\\s]+)`));
	return m ? m[1] : undefined;
}

/** 从单进程 env 原始串提取 amagi 血统命中（纯函数，供测试直测；I3 键值一并记录）。 */
export function lineageFromEnvRaw(envRaw: string): Pick<OrphanProc, "tags" | "invocation" | "rootPid" | "ownership"> {
	const tags: string[] = [];
	const ownership: Record<string, string> = {};
	let invocation: string | undefined;
	let rootPid: string | undefined;
	for (const key of AMAGI_LINEAGE_ENV_KEYS) {
		const v = parseEnvValue(envRaw, key);
		if (v === undefined) continue;
		tags.push(key);
		ownership[key] = v;
		if (key === ENV_INVOCATION) invocation = v;
		if (key === ENV_ROOT_PID) rootPid = v;
	}
	return { tags, ownership, ...(invocation ? { invocation } : {}), ...(rootPid ? { rootPid } : {}) };
}

/** darwin 双快照分离行：pid/ppid + 精确 argv + env 尾（ev-20261012-2ca6a7）。 */
export interface DarwinProcessRow {
	pid: number;
	ppid: number;
	/** `ps axo args=` 渲染的精确 argv（空串=argv 不可见，env 视为未知）。 */
	argv: string;
	/** eww 行剥去 argv 前缀后的 env 尾；undefined=前缀不匹配（两次调用间进程变化），env 未知。 */
	envTail: string | undefined;
}

/**
 * ev-20261012-2ca6a7 + B7 修复轮 F03：darwin argv/env 分离解析（纯函数，供测试直测）。
 * args 前读快照（`ps axww -o pid=,ppid=,args=`）与 eww 快照（`ps axeww -o pid=,ppid=,command=`）
 * 按 pid 对齐；eww 行尾以「argv + 后随空白」为前缀才剥离出 env 尾，否则 env 未知
 * （undefined）——保守处理两次调用间的 exec/退出/渲染差异，绝不把 argv 文本当 env 解析。
 * 严格前缀判定（后随空白或整串相等）防「node foo」误配「node foobar …」形态。
 * 包围式复读（F03）：args 复读快照（argvOut2，采样于 eww 之后）与前读对同一 pid 的
 * argv/ppid 必须一致——同化身 setproctitle/title 竞态（前读旧 title、eww 恰取扩展后新
 * title、复读新 title）→ env 未知。无包围（argvOut2 缺省，含 JS 调用方漏参）一律
 * fail-closed：全部行 env 未知——无包围的二元组证明不了 env 来源。
 */
export function parseDarwinProcessRows(argvOut: string, ewwOut: string, argvOut2: string): DarwinProcessRow[] {
	const parseArgvSnapshot = (out: string): Map<number, { ppid: number; argv: string }> => {
		const byPid = new Map<number, { ppid: number; argv: string }>();
		for (const line of String(out).split("\n")) {
			const m = line.match(/^\s*(\d+)\s+(\d+)\s+(.*\S)/);
			if (!m) continue;
			byPid.set(Number(m[1]), { ppid: Number(m[2]), argv: m[3].trim() });
		}
		return byPid;
	};
	const argvByPid = parseArgvSnapshot(argvOut);
	// 运行时防漏参（TS 签名已必填）：复读缺位 → 无法证明 argv 稳定 → 全部 env 未知。
	const argv2ByPid = argvOut2 === undefined || argvOut2 === null ? null : parseArgvSnapshot(argvOut2);
	const rows: DarwinProcessRow[] = [];
	for (const line of String(ewwOut).split("\n")) {
		const m = line.match(/^\s*(\d+)\s+(\d+)\s+(.*\S)/);
		if (!m) continue;
		const pid = Number(m[1]);
		const ppid = Number(m[2]);
		const rest = m[3].trim();
		const a = argvByPid.get(pid);
		// env 未知面：argv 快照缺失（两次调用间新进程）/空 argv/前缀不匹配（进程已变化）。
		if (!a || !a.argv) { rows.push({ pid, ppid, argv: a?.argv ?? "", envTail: undefined }); continue; }
		if (argv2ByPid !== null) {
			const a2 = argv2ByPid.get(pid);
			// 包围式复读：前后 args 对该 pid 的 argv/ppid 不一致（同化身 title 变化/exec/复用/
			// 退出）→ 拒绝解析，env 未知（F03）。
			if (!a2 || a2.argv !== a.argv || a2.ppid !== a.ppid) { rows.push({ pid, ppid, argv: a.argv, envTail: undefined }); continue; }
		} else { rows.push({ pid, ppid, argv: a.argv, envTail: undefined }); continue; }
		const envTail = rest === a.argv ? "" : rest.startsWith(`${a.argv} `) ? rest.slice(a.argv.length).trim() : undefined;
		rows.push({ pid, ppid, argv: a.argv, envTail });
	}
	return rows;
}

/** OrphanProc.command 只存 argv：进程展示脱敏策略（F01）完整遮蔽 KEY/TOKEN/SECRET 类赋值
 *  值（任意长度/unicode/引号/多赋值/混合值）后再截断——截断可切标记，但绝不把值切成明文前缀。 */
export function orphanCommandFromArgv(argv: string): string {
	return redactProcessDisplayText(argv).slice(0, 120);
}

/** darwin 分离行 → 血统命中条目：env 尾才参与血统解析；env 未知行保守跳过（2ca6a7）。 */
export function orphansFromDarwinRows(rows: readonly DarwinProcessRow[]): OrphanProc[] {
	const out: OrphanProc[] = [];
	for (const row of rows) {
		if (row.envTail === undefined) continue;
		const hit = lineageFromEnvRaw(row.envTail);
		if (hit.tags.length === 0) continue;
		out.push({ pid: row.pid, ppid: row.ppid, command: orphanCommandFromArgv(row.argv), ...hit });
	}
	return out;
}

async function defaultSnapshotEnvs(platform: NodeJS.Platform): Promise<OrphanProc[]> {
	if (platform === "darwin") {
		// 2ca6a7 + F03：args 前读 → eww → args 复读，串行执行保证包围时序成立（同 uid 才可见；
		// 输出可能大，maxBuffer 放宽；axww 显式无限宽防宽度截断制造伪前缀）。任一失败整体抛错 →
		// 调用方按快照不可用降级（绝不误杀）。前后 args 不一致的 pid 按 env 未知拒绝解析。
		const psOpts = { timeout: 5000, killSignal: "SIGKILL" as const, maxBuffer: 64 * 1024 * 1024 };
		const argvSnapshot = () => execFileAsync("ps", ["axww", "-o", "pid=,ppid=,args="], psOpts);
		const before = await argvSnapshot();
		const ewwRes = await execFileAsync("ps", ["axeww", "-o", "pid=,ppid=,command="], psOpts);
		const after = await argvSnapshot();
		return orphansFromDarwinRows(parseDarwinProcessRows(String(before.stdout), String(ewwRes.stdout), String(after.stdout)));
	}
	if (platform === "linux") {
		// /proc 全扫：pid/ppid 从 stat 第 4 字段；environ NUL 分隔。仅同 uid 可读（EPERM/ENOENT 跳过）
		const out: OrphanProc[] = [];
		let entries: string[];
		try { entries = fs.readdirSync("/proc"); } catch { return out; }
		for (const name of entries) {
			if (!/^\d+$/.test(name)) continue;
			const pid = Number(name);
			if (pid <= 1) continue;
			let envRaw = "";
			try { envRaw = fs.readFileSync(`/proc/${pid}/environ`, "utf8").replace(/\0/g, " "); } catch { continue; }
			const hit = lineageFromEnvRaw(envRaw);
			if (hit.tags.length === 0) continue;
			let ppid = 0;
			let command = "";
			try {
				const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf8");
				const close = stat.lastIndexOf(")");
				const fields = stat.slice(close + 2).split(" ");
				ppid = Number(fields[1]) || 0;
				command = stat.slice(stat.indexOf("(") + 1, close).slice(0, 120);
			} catch { /* stat 丢失跳过 ppid（仍可回收，pid 唯一） */ }
			out.push({ pid, ppid, command, ...hit });
		}
		return out;
	}
	return [];
}

/** ev-20261021-a8de95：任务血统存活探测（只读，不发任何信号）——列出 env 带 AMAGI_TASK_ID=<taskId> 且
 *  当前存活的进程（子 pi 进程在 task-run spawn 点注入该标记，env 随进程树继承；不要求 ppid=1——仍挂在
 *  另一个活 Leader 下的子进程同样算存活）。快照不可用/平台不支持 → ok=false（调用方 fail-closed，
 *  不把「看不见」当「已退出」）。 */
export async function findTaskLineageProcesses(
	taskId: string,
	opts: { platform?: NodeJS.Platform; snapshotEnvs?: () => Promise<OrphanProc[]>; isAlive?: (pid: number) => boolean } = {},
): Promise<{ ok: true; procs: OrphanProc[] } | { ok: false; reason: string }> {
	const platform = opts.platform ?? process.platform;
	if (platform !== "darwin" && platform !== "linux") return { ok: false, reason: `平台 ${platform} 不支持进程环境快照` };
	let procs: OrphanProc[];
	try {
		procs = await (opts.snapshotEnvs ?? (() => defaultSnapshotEnvs(platform)))();
	} catch (e) {
		return { ok: false, reason: `进程环境快照失败（${e instanceof Error ? e.message.slice(0, 120) : String(e).slice(0, 120)}）` };
	}
	const isAlive = opts.isAlive ?? defaultIsAlive;
	return { ok: true, procs: procs.filter((p) => p.pid > 1 && p.pid !== process.pid && p.ownership?.AMAGI_TASK_ID === taskId && isAlive(p.pid)) };
}

function defaultIsAlive(pid: number): boolean {
	if (!Number.isInteger(pid) || pid <= 1) return false;
	try {
		process.kill(pid, 0);
		return true;
	} catch (e: any) {
		return e?.code === "EPERM";
	}
}

function defaultKill(pid: number, signal: NodeJS.Signals): void {
	if (!Number.isInteger(pid) || pid <= 1) return;
	// A verified individual PID never authorizes unrelated members of its process group.
	process.kill(pid, signal);
}

function defaultSleep(ms: number): Promise<void> {
	return new Promise((r) => setTimeout(r, ms));
}

export interface ReapResult {
	cleanedCount: number;
	pids: number[];
	summary: string;
}

/** 旧形态 entry（无 ownership 记录）回退合成：只保留 invocation/rootPid 值（无法追回通用键值）。 */
function ownershipOf(e: OrphanProc): Readonly<Record<string, string>> {
	if (e.ownership) return e.ownership;
	const own: Record<string, string> = {};
	if (e.invocation !== undefined) own[ENV_INVOCATION] = e.invocation;
	if (e.rootPid !== undefined) own[ENV_ROOT_PID] = e.rootPid;
	return own;
}

/** I3：逐键比较——锚点（期望）内的每个键都必须仍以同值出现；键名交集不构成授权。 */
function ownershipMatches(expected: Readonly<Record<string, string>>, current: Readonly<Record<string, string>>): boolean {
	for (const [k, v] of Object.entries(expected)) if (current[k] !== v) return false;
	return true;
}

/** 括号一致性：候选快照与括号中快照的键集与键值完全一致，否则证据为拼凑、不形成锚点。 */
function ownershipConsistent(a: Readonly<Record<string, string>>, b: Readonly<Record<string, string>>): boolean {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	return ownershipMatches(a, b) && ownershipMatches(b, a);
}

interface AnchoredTarget {
	pid: number;
	anchor: Readonly<OrphanAnchor>;
}
interface SkipRecord {
	pid: number;
	reason: string;
}

/** F2（独立审核 E-review-C）：锚点来源登记。冻结只防篡改、不能证明来源；只有 formAnchors 产出的
 *  锚点对象才有授权资格——JSON 往返、浅拷贝重建或手工构造的对象不在册，reapDiagnosedOrphans 拒绝。
 *  模块私有 WeakSet：不可序列化、不可从外部登记、不阻止 GC。 */
const issuedAnchors = new WeakSet<object>();

/**
 * I2 锚点形成（仅诊断/候选捕获阶段）：出生读取 → 归属/ppid/keep 资格快照 → 出生重读。
 * 任一缺失/不一致 → 不形成锚点（该 PID 可列出但不可清理）；探针抛错保守拒绝。
 */
async function formAnchors(
	candidates: readonly OrphanProc[],
	snapshot: () => Promise<OrphanProc[]>,
	readIdentities: (pids: readonly number[]) => Map<number, KernelProcessIdentity>,
	requirePpid1: boolean,
): Promise<{ anchored: Map<number, Readonly<OrphanAnchor>>; skips: SkipRecord[]; snapshotFailed: boolean }> {
	const anchored = new Map<number, Readonly<OrphanAnchor>>();
	const skips: SkipRecord[] = [];
	const pids = candidates.map((c) => c.pid);
	let birth1: Map<number, KernelProcessIdentity> | null = null;
	let birth2: Map<number, KernelProcessIdentity> | null = null;
	try { birth1 = readIdentities(pids); } catch { /* lint-exempt:probe failure cannot authorize an anchor */ birth1 = null; }
	let snap2: OrphanProc[];
	try { snap2 = await snapshot(); } catch {
		return { anchored, skips: candidates.map((c) => ({ pid: c.pid, reason: "诊断期快照不可用" })), snapshotFailed: true };
	}
	try { birth2 = readIdentities(pids); } catch { /* lint-exempt:probe failure cannot authorize an anchor */ birth2 = null; }
	const snap2ByPid = new Map(snap2.map((p) => [p.pid, p]));
	for (const c of candidates) {
		const t1 = birth1?.get(c.pid)?.identityToken;
		const t2 = birth2?.get(c.pid)?.identityToken;
		if (birth1 === null || birth2 === null) { skips.push({ pid: c.pid, reason: "探针不可用或抛错" }); continue; }
		if (!t1 || !t2) { skips.push({ pid: c.pid, reason: "探针不可用或身份缺失" }); continue; }
		if (t1 !== t2) { skips.push({ pid: c.pid, reason: "诊断期身份双读不一致" }); continue; }
		const cur2 = snap2ByPid.get(c.pid);
		if (!cur2) { skips.push({ pid: c.pid, reason: "诊断期快照缺失" }); continue; }
		if (requirePpid1 && cur2.ppid !== 1) { skips.push({ pid: c.pid, reason: "诊断期 ppid 已变化" }); continue; }
		const ownershipNow = ownershipOf(cur2);
		// F1（独立审核 E-review-C）：空归属对象的锚点会让清理期的逐键比较恒真（fail-open）——
		// 没有任何归属值可入锚的条目不得形成锚点（默认快照总带归属值；注入/旧形态快照可达）。
		if (Object.keys(ownershipNow).length === 0) { skips.push({ pid: c.pid, reason: "诊断期归属值缺失" }); continue; }
		if (!ownershipConsistent(ownershipOf(c), ownershipNow)) { skips.push({ pid: c.pid, reason: "诊断期归属值变化" }); continue; }
		// I8：证据对象不可变——锚点只在此处（诊断/候选捕获）产生，并登记来源（F2）。
		const anchor: Readonly<OrphanAnchor> = Object.freeze({
			identityToken: t1,
			ownership: Object.freeze({ ...ownershipNow }),
			ppid: cur2.ppid,
			observedAt: new Date().toISOString(),
		});
		issuedAnchors.add(anchor);
		anchored.set(c.pid, anchor);
	}
	return { anchored, skips, snapshotFailed: false };
}

function buildReapSummary(considered: number, cleaned: readonly number[], skips: readonly SkipRecord[], signalledCount: number): string {
	let summary = `[amagi 孤儿回收] 已回收 ${cleaned.length}/${considered} 个进程: ${cleaned.join(", ") || "-"}`;
	if (skips.length) {
		const groups = new Map<string, number[]>();
		for (const s of skips) {
			const list = groups.get(s.reason) ?? [];
			list.push(s.pid);
			groups.set(s.reason, list);
		}
		const detail = [...groups.entries()].map(([reason, pids]) => `${reason}: ${pids.join(", ")}`).join("；");
		summary += `；安全跳过 ${new Set(skips.map((s) => s.pid)).size} 个（${detail}）`;
	}
	if (signalledCount === 0 && considered > 0) summary += `（未发送任何信号）`;
	return summary;
}

/**
 * 锚定清理引擎（自动/诊断两路径共用）：期望恒为诊断期锚点（I4——当前快照只做归属/ppid
 * 核对，绝不以当前条目替换期望）；TERM 前、KILL 前各自重读出生 token 与锚点比较（I5）；
 * 资格复核（I6：存活/ppid===1/keepPids）；信号只发个人 PID（I7）。查询到发信号存在非原子
 * 窗口，保守 best-effort；探针失败/缺失不授权任何信号。
 */
async function reapAnchored(
	targets: readonly AnchoredTarget[],
	preSkips: readonly SkipRecord[],
	deps: OrphanDeps,
	opts: { requirePpid1: boolean },
): Promise<ReapResult> {
	const kill = deps.kill ?? defaultKill;
	const isAlive = deps.isAlive ?? defaultIsAlive;
	const sleep = deps.sleep ?? defaultSleep;
	const readIdentities = deps.readIdentities ?? readKernelProcessIdentities;
	const considered = targets.length + preSkips.length;
	if (considered === 0) return { cleanedCount: 0, pids: [], summary: "" };
	const skips: SkipRecord[] = [...preSkips];
	let current = new Map<number, OrphanProc>();
	if (targets.length > 0) {
		const snapshot = deps.snapshotEnvs ?? (() => defaultSnapshotEnvs(deps.platform ?? process.platform));
		try { current = new Map((await snapshot()).map((p) => [p.pid, p])); }
		catch {
			const summary = `[amagi 孤儿回收] 环境快照不可用，身份核对未完成，已安全跳过全部 ${considered} 个目标（未发送任何信号）。`;
			deps.log?.(summary);
			return { cleanedCount: 0, pids: [], summary };
		}
	}
	const readToken = (pid: number): { token?: string; probeFailed: boolean } => {
		try { return { token: readIdentities([pid]).get(pid)?.identityToken, probeFailed: false }; }
		catch { /* lint-exempt:probe failure cannot authorize a signal */ return { probeFailed: true }; }
	};
	const anchorByPid = new Map(targets.map((t) => [t.pid, t.anchor]));
	const signalled: number[] = [];
	for (const t of targets) {
		if (!isAlive(t.pid)) { skips.push({ pid: t.pid, reason: "已退出" }); continue; }
		if (deps.keepPids?.has(t.pid)) { skips.push({ pid: t.pid, reason: "keepPids 命中" }); continue; }
		// F1 纵深防御：空期望归属对 ownershipMatches 恒真，fail-closed（formAnchors 已不产出此类锚点）。
		if (Object.keys(t.anchor.ownership).length === 0) { skips.push({ pid: t.pid, reason: "锚点归属值为空" }); continue; }
		const birth = readToken(t.pid);
		if (birth.probeFailed) { skips.push({ pid: t.pid, reason: "探针不可用或抛错" }); continue; }
		if (!birth.token) { skips.push({ pid: t.pid, reason: "探针不可用或身份缺失" }); continue; }
		if (birth.token !== t.anchor.identityToken) { skips.push({ pid: t.pid, reason: "出生身份已变（非诊断时刻化身）" }); continue; }
		const cur = current.get(t.pid);
		if (!cur) { skips.push({ pid: t.pid, reason: "当前快照缺失（无法核对归属）" }); continue; }
		if (opts.requirePpid1 && cur.ppid !== 1) { skips.push({ pid: t.pid, reason: "ppid 不再为 1" }); continue; }
		if (!ownershipMatches(t.anchor.ownership, ownershipOf(cur))) { skips.push({ pid: t.pid, reason: "归属值不一致" }); continue; }
		try { kill(t.pid, "SIGTERM"); signalled.push(t.pid); }
		catch { /* journal:orphan-term-failed */ skips.push({ pid: t.pid, reason: "信号发送失败" }); }
	}
	if (signalled.length) {
		await sleep(TERM_GRACE_MS);
		for (const pid of signalled) {
			if (!isAlive(pid)) continue;
			const birth = readToken(pid);
			if (birth.probeFailed || !birth.token) { skips.push({ pid, reason: "宽限窗内探针不可用或身份缺失" }); continue; }
			if (birth.token !== anchorByPid.get(pid)!.identityToken) { skips.push({ pid, reason: "宽限窗内出生身份已变（无法排除 PID 复用）" }); continue; }
			try { kill(pid, "SIGKILL"); }
			catch { /* journal:orphan-kill-failed */ skips.push({ pid, reason: "信号发送失败" }); }
		}
	}
	const cleaned = signalled.filter((pid) => !isAlive(pid));
	const summary = buildReapSummary(considered, cleaned, skips, signalled.length);
	deps.log?.(summary);
	return { cleanedCount: cleaned.length, pids: cleaned, summary };
}

/**
 * invocation 精确回收（自动路径）：env 同时命中 AMAGI_BASH_INVOCATION=<invocation> 与
 * AMAGI_BASH_ROOT_PID=<rootPid> 的进程逐个回收（个人 PID，无进程组信号）。tag 唯一 →
 * 零误杀面（见节首注释）。F-01 切片 A：候选捕获时即形成不可变出生锚点，清理全程与
 * 锚点比较（不存在陈旧诊断交接，但同样不例外地从当前 PID 自学授权）。
 */
export async function reapInvocationOrphans(
	opts: { invocation: string; rootPid: number },
	deps: OrphanDeps = {},
): Promise<ReapResult> {
	const platform = deps.platform ?? process.platform;
	if (platform !== "darwin" && platform !== "linux") return { cleanedCount: 0, pids: [], summary: "" };
	const snapshot = deps.snapshotEnvs ?? (() => defaultSnapshotEnvs(platform));
	let procs: OrphanProc[];
	try { procs = await snapshot(); } catch { return { cleanedCount: 0, pids: [], summary: `[amagi 孤儿回收] 环境快照不可用，已跳过本次回收（安全跳过，不杀任何进程）。` }; }
	const candidates = procs
		.filter((p) => p.invocation === opts.invocation && p.rootPid === String(opts.rootPid) && p.pid > 1 && p.pid !== process.pid);
	if (candidates.length === 0) return { cleanedCount: 0, pids: [], summary: "" };
	const formed = await formAnchors(candidates, snapshot, deps.readIdentities ?? readKernelProcessIdentities, false);
	if (formed.snapshotFailed) {
		return { cleanedCount: 0, pids: [], summary: `[amagi 孤儿回收] 环境快照不可用，身份绑定未完成，已安全跳过 ${candidates.length} 个候选目标（未发送任何信号）。` };
	}
	const targets = [...formed.anchored.entries()].map(([pid, anchor]) => ({ pid, anchor }));
	const preSkips = formed.skips.map((s) => ({ pid: s.pid, reason: `无法绑定身份（${s.reason}）` }));
	return reapAnchored(targets, preSkips, deps, { requirePpid1: false });
}

/**
 * 全局孤儿诊断：ppid=1（父链已死被 init 收养）+ env 带 amagi 血统标记（排除 keepPids）。
 * F-01 切片 A：诊断用「出生读取 → 归属/ppid/keep 资格快照 → 出生重读」括号为每个孤儿
 * 形成不可变出生锚点（I2/I3）；无法绑定身份的条目仍列出但标注 clean 将跳过（I1）。
 */
export async function diagnoseOrphans(
	opts: { keepPids?: ReadonlySet<number>; platform?: NodeJS.Platform; snapshotEnvs?: () => Promise<OrphanProc[]>; isAlive?: (pid: number) => boolean; readIdentities?: (pids: readonly number[]) => Map<number, KernelProcessIdentity> } = {},
): Promise<{ orphans: OrphanProc[]; summary: string }> {
	const platform = opts.platform ?? process.platform;
	if (platform !== "darwin" && platform !== "linux") {
		return { orphans: [], summary: "[amagi 孤儿诊断] 仅 darwin/linux 支持（当前平台跳过）。" };
	}
	const snapshot = opts.snapshotEnvs ?? (() => defaultSnapshotEnvs(platform));
	let procs: OrphanProc[];
	try { procs = await snapshot(); } catch {
		return { orphans: [], summary: "[amagi 孤儿诊断] 进程环境快照不可用（ps/proc 失败），已降级跳过——不杀任何进程。" };
	}
	const keep = opts.keepPids ?? new Set<number>();
	const isAlive = opts.isAlive ?? defaultIsAlive;
	const candidates = procs.filter((p) => p.pid > 1 && p.ppid === 1 && !keep.has(p.pid) && isAlive(p.pid));
	if (candidates.length === 0) {
		return { orphans: [], summary: "[amagi 孤儿诊断] 无 amagi 血统孤儿进程（ppid=1 且 env 带标记：0 个）。" };
	}
	const formed = await formAnchors(candidates, snapshot, opts.readIdentities ?? readKernelProcessIdentities, true);
	const skipByPid = new Map(formed.skips.map((s) => [s.pid, s.reason]));
	const orphans = candidates.map((c) => {
		const anchor = formed.anchored.get(c.pid);
		const reason = anchor ? undefined : formed.snapshotFailed ? "诊断期快照不可用" : skipByPid.get(c.pid) ?? "无法绑定身份";
		// I8：证据对象不可变；entry 与锚点/归属值全冻结。
		return Object.freeze({ ...c, ...(anchor ? { anchor } : { unanchored: reason }) }) as OrphanProc;
	});
	const lines = orphans.map((o) => `- pid ${o.pid}（${o.tags.join(",")}）${o.command || "unknown"}${o.unanchored ? `（无法绑定身份：${o.unanchored}；clean 将跳过）` : ""}`);
	return {
		orphans,
		summary: `[amagi 孤儿诊断] 发现 ${orphans.length} 个孤儿进程（父链已死、env 带 amagi 标记、排除 run_bg 活跃句柄）：\n${lines.join("\n")}\n清理：/amagi orphans clean`,
	};
}

/**
 * 显式回收诊断出的孤儿（/amagi orphans clean）。
 * F-01 切片 A（I1/I4）：期望恒为诊断记录自带的出生锚点——无锚点目标（旧形态列表/探针
 * 失败/双读不一致）一律不发信号并按原因披露；当前快照只做归属/ppid 核对，绝不以当前
 * 条目替换期望。逐信号与锚点比较（I5）+ 清理时资格复核（I6：存活/ppid===1/keepPids）。
 */
export async function reapDiagnosedOrphans(
	orphans: OrphanProc[],
	deps: OrphanDeps = {},
): Promise<ReapResult> {
	const platform = deps.platform ?? process.platform;
	if (platform !== "darwin" && platform !== "linux") return { cleanedCount: 0, pids: [], summary: "" };
	const targets: AnchoredTarget[] = [];
	const skips: SkipRecord[] = [];
	const seen = new Set<number>();
	for (const o of orphans) {
		if (seen.has(o.pid)) continue;
		seen.add(o.pid);
		if (!Number.isInteger(o.pid) || o.pid <= 1 || o.pid === process.pid) { skips.push({ pid: o.pid, reason: "非法 PID 边界（仅个人 PID）" }); continue; }
		if (!o.anchor?.identityToken) {
			skips.push({ pid: o.pid, reason: o.unanchored ? `缺诊断期身份锚点（${o.unanchored}）` : "缺诊断期身份锚点" });
			continue;
		}
		// F2：锚点对象必须是 formAnchors 本进程产出的那一个（JSON 往返/浅拷贝/手工构造不在册）。
		if (!issuedAnchors.has(o.anchor)) { skips.push({ pid: o.pid, reason: "锚点来源未登记（非诊断期产出）" }); continue; }
		targets.push({ pid: o.pid, anchor: o.anchor });
	}
	return reapAnchored(targets, skips, deps, { requirePpid1: true });
}
