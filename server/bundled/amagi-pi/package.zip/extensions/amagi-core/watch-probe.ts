/**
 * watch-probe.ts — watch/dev 型常驻命令探测（ev-20260904-0678c1 误报根治）。
 *
 * 独立零 pi 依赖纯函数模块（同 env-flip / task-write-log / shell-lexer 纪律）：
 * bash-override（bash 命令）与 rpc-pool-tool（任务文本）共同 import，探测口径单一不漂移
 * （原两侧各持一份正则，注释互喊「勿单边漂移」，本次收敛为同一实现）。
 *
 * 2026-09-04 复盘根因（当日 Leader 会话三连误报当场复现）：
 *  1) 程序词无词边界——`ts`（tsx? 的可选分支）匹配 "tests"、`node` 匹配 "node_modules"；
 *  2) `\bdev\b` 匹配 /dev/null、/dev/stdout 等设备路径；
 *  3) 程序词与 watch/dev 关键词可跨 `;`/`|`/`&&` 段远距组合——`rg "WATCH" tests/` 命中
 *     （tests 提供 ts + 搜索词字面量 WATCH）。
 * 修复口径：
 *  - 程序词两侧加 \b，且不再把裸 `ts` 当程序词（tsc --watch 由 tsc 分支覆盖）；
 *  - 探测前剥离 /dev/* 设备路径与含 / 的路径形 token（`node --test tests/watch-probe.test.mjs`
 *    的文件名 watch 词、`scripts/dev-server.js` 路径段都不是常驻意图；裸参数 watch/dev
 *    不含 / 不受影响）；
 *  - 程序词与 watch/dev 关键词约束在同一 pipeline 段内（[^\n;&|]*），跨段不再组合；
 *  - 全程只读搜索命令（rg/grep/find/ls 等无命令替换、无后台 &）直接判非 watch。
 *
 * 残余局限（接受）：非白名单只读工具（如 xxd jest dev）仍可能远距组合误报——主防线
 * 已覆盖高频搜索/查看命令，软提示不阻断，残余误报成本低于漏报 watch 型任务。
 */

import { executableWords, shellSegments } from "./shell-lexer.ts";

/** /dev/* 设备路径引用：探测前剥离，防 \bdev\b 误匹配（/dev/null、/dev/stdout、/dev/fd/3 …）。 */
export const DEVICE_PATH_RE = /\/dev\/(?:null|stdin|stdout|stderr|zero|random|urandom|tty[a-z0-9]*|fd\/\d+)/gi;

/** 含 / 的路径形 token：探测前一并剥离（文件名/路径段里的 watch/dev 词不是常驻意图）。 */
export const PATH_TOKEN_RE = /[^\s;&|]*\/[^\s;&|]*/g;

/**
 * watch 型常驻特征（2026-09-04 收紧版）：
 *  - 程序词分支：\b 包边 + 与 watch/dev 同 pipeline 段（[^\n;&|]* 不跨段）；
 *  - pnpm/npm dev 分支：dev 词尾加 \b（防 "dev-server.js" 之类长词误配）；
 *  - --watch 全局有效（无歧义）。
 */
export const WATCH_COMMAND_RE =
	/\b(?:tsx|nodemon|node|vite|next|webpack|jest|tsc)\b[^\n;&|]*\b(?:watch|dev)\b|\bpnpm\s+(?:run\s+)?dev\b|\bnpm\s+(?:run\s+)?dev\b|--watch\b/i;

/**
 * 全程只读命令白名单（首词级，含管道各段）：搜索/查看/统计/文本加工类。
 * 含 sed/awk（可 -i/system() 写盘，但不会常驻——本白名单只豁免 watch/longrun 关键词
 * 提示，写盘追踪与守卫另行覆盖）；不含 node/python/perl 等可跑任意常驻程序的解释器。
 */
const READONLY_EXECUTABLES = new Set([
	"rg", "grep", "egrep", "fgrep", "find", "fd", "fdfind", "ls", "echo", "printf",
	"head", "tail", "cat", "wc", "sort", "uniq", "diff", "cmp", "cut", "tr", "sed",
	"awk", "nl", "column", "basename", "dirname", "realpath", "readlink", "stat",
	"file", "pwd", "which", "type", "printenv", "env", "tree", "du", "df", "md5",
	"md5sum", "shasum", "sha1sum", "sha256sum", "jq", "yq", "git",
]); // 注意不含 xargs——xargs 执行任意后续命令（… | xargs npm run dev 可穿透白名单）

/**
 * 纯函数：命令是否为「全程只读搜索/查看」——每个 pipeline 段（含 `;`/`&&`/`||`/`|` 分段）
 * 的主执行程序（剥 env 前缀与 env/sudo/time/timeout/nice 包装）都在白名单内。
 * 命令替换（$()/反引号，可执行任意命令）与裸 `&` 后台（剔除 &&、N>&M、&> 重定向形态后
 * 仍残留 &）一律保守判非只读。循环/常驻词（for/while/watch/exec/source/…）天然不在
 * 白名单，无需单列。
 */
export function isReadonlySearchCommand(command: string): boolean {
	if (!command || !command.trim()) return false;
	// 命令替换展开内容不受 lexer 约束——不短路
	if (/\$\(|`/.test(command)) return false;
	// 后台 &：剥掉合法复合形态后仍有 & 即视为后台化，退出白名单语义
	const ampStripped = command.replace(/&&/g, " ").replace(/\d*>&\d*/g, " ").replace(/&>/g, " ");
	if (ampStripped.includes("&")) return false;
	const segments = shellSegments(command);
	if (!segments.length) return false;
	for (const segment of segments) {
		const words = executableWords(segment, true);
		if (!words.length) return false;
		const executable = words[0].toLowerCase().replace(/^.*[\\/]/, "");
		if (!READONLY_EXECUTABLES.has(executable)) return false;
	}
	return true;
}

/**
 * 纯函数：输入（bash 命令或任务文本）是否疑似 watch/dev 型常驻。
 * 只读搜索命令直接短路为 false；其余剥 /dev/* 设备路径与路径形 token 后按收紧正则判定。
 */
export function looksLikeWatchCommand(input: string): boolean {
	if (!input) return false;
	if (isReadonlySearchCommand(input)) return false;
	const probe = input.replace(DEVICE_PATH_RE, " ").replace(PATH_TOKEN_RE, " ");
	return WATCH_COMMAND_RE.test(probe);
}
