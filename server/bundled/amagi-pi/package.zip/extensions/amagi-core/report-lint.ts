/**
 * report-lint.ts — b6f343（ev-20261019-b6f343）：子 Agent 终稿/声明产物的轻量内容 lint。
 *
 * 背景（ev-20261019-b6f343，M01 hybrid-conversion 同类实证 6 起）：结算面（N7）只认结构化
 * 机器事实——验证命令执行（checks）与产物存在性（artifact-integrity）；报告/声明产物的
 * **陈述内容**是结算盲区：「回滚方式：`git checkout -- …`」「✅ …同条目写未闭合」这类
 * 夸大/危险回退表述可以无提示进入 ready 回执，全靠 Leader/diting 人工复核兜底。
 *
 * 本模块是纯扫描面（+ 有界只读 IO），产出 advisory 检查（finalizer 接线进回执 checks）：
 *  - 规则 1 report-unsafe-rollback：共享树（workspace.mode=existing）或任务书显式禁 Git 写
 *    （gitWriteForbiddenInAssignment 命中）时，终稿/声明产物含 `git checkout --`/`git reset
 *    --hard`/`git clean`/`rm -rf` 等整文件回退指令 → 按命中单元出 check（id 携 来源:行号）。
 *  - 规则 2 report-contradictory-status（b4345b）：只检查显式状态标签的值及 Markdown
 *    表头声明的状态列。字段值须完全由状态枚举构成，且内部同时声明通过和否定才提示。
 *    自由叙述、说明列、跨列、不同声明和未知值不推断矛盾；不根据角色或语义词表豁免。
 *  - 数量声明 vs 引用证据计数（「2 条 warning」vs 原始 JSON 53）：**不做**——需理解任意格式
 *    证据文件的计数语义（什么算一条 warning 由格式决定），无格式知识必然高误报（任务书
 *    禁止高误报启发式）；见 fix 报告说明。
 *
 * 误报控制（任务书要求，负例测试成对覆盖）：
 *  - 围栏代码块（```/~~~）内的命令引用不报（实现：扫描前按围栏切分，围栏内容整段跳过）；
 *  - 否定/劝阻语境不报（「不得 git checkout」「禁止 rm -rf」「不可整文件 checkout」——单元内
 *    含劝阻标记即跳过该单元的回退指令扫描）；
 *  - 混合计数汇总行不报（「20 通过，4 失败」两侧均有数字前缀 → 合法汇总，非自相矛盾）；
 *  - 零量否定不报（「全部通过（0 失败）」——否定侧是 0/无/零前缀 = 否定事实缺席）；
 *  - b4345b：状态字段「PASS / FAIL」「状态：通过，未通过」提示；「结果：测试通过，
 *    审核失败」和说明列「覆盖 PASS / FAIL 分支」均是叙述，不能据词共现推断矛盾。
 *
 * 契约：检查恒 required:false（deriveSettlementFace 只对 required 检查判定 failed/missing——
 * advisory 不参与 settlement，永不阻断）；status="failed" 是 lint 命中的如实陈述；id 经
 * newCheckId 分配（规则名@来源:行号 进规格名段，回执渲染可见定位）；objectId 绑被扫描文本
 * 的内容 digest（N7 语义：检查对象真实存在且可复核）。lint 自身异常 → 无 advisory（缺席，
 * 不伪造通过）——由 finalizer 侧 fail-closed 兜底，本模块扫描函数不吞错。
 */

import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { newCheckId } from "./evidence.ts";
import type { CheckResult } from "./contracts/evidence.ts";

export type ReportLintRuleId = "report-unsafe-rollback" | "report-contradictory-status";

export interface ReportLintFinding {
	rule: ReportLintRuleId;
	/** 命中单元的来源标签（"final-report" 或声明产物相对路径）。 */
	source: string;
	/** 命中单元起始行（1 基）。 */
	line: number;
	/** 命中摘录（有界、去换行——回执 id 只带定位，摘录供日志/调试消费）。 */
	excerpt: string;
	/** rule=report-unsafe-rollback 时命中的指令形态（如 "git checkout --"）。 */
	detail?: string;
	/** 被扫描文本的 sha256 前 16 位（检查 objectId 锚定被检对象内容）。 */
	objectRef: string;
}

/** 有界上限：扫描行数/单文件字节/声明产物文件数/每规则命中数/回执 advisory 检查总数。 */
const MAX_SCAN_LINES = 5000;
const MAX_SCAN_BYTES = 1 << 20;
const MAX_OUTPUT_FILES = 8;
const MAX_FINDINGS_PER_RULE = 4;
export const MAX_REPORT_LINT_CHECKS = 8;

/** lint 策略 digest（规则集版本的稳定指纹——检查配置可追溯，规则变更即换 digest）。 */
export const REPORT_LINT_POLICY_DIGEST: string = createHash("sha256")
	.update("amagi-report-lint:v4:report-unsafe-rollback,report-contradictory-status:explicit-state-values")
	.digest("hex");

// ── 单元切分（条目/表格行/段落；围栏代码块整体跳过） ───────────────────────────

const FENCE_RE = /^\s{0,3}(?:`{3,}|~{3,})/;
const HEADING_RE = /^\s{0,3}#{1,6}(?:\s|$)/;
const TABLE_ROW_RE = /^\s*\|/;
const TABLE_SEPARATOR_RE = /^\s*\|(?:[\s:|-]*\|)+\s*$/;
const LIST_ITEM_RE = /^(\s*)(?:[-*+]|\d{1,3}[.)])\s+/;

interface LintUnit {
	/** 起始行（1 基）。 */
	start: number;
	/** 单元文本（续行以空格拼接）。 */
	text: string;
	/** Only cells whose column is declared as a status field by a Markdown header. */
	statusFields?: string[];
}

/** 围栏代码块内容不参与任何规则（命令样例/引用原文是合法存在）。 */
export function splitLintUnits(text: string): LintUnit[] {
	const normalized = text.replace(/\r\n?/g, "\n");
	const lines = normalized.split("\n").slice(0, MAX_SCAN_LINES);
	const units: LintUnit[] = [];
	let inFence = false;
	let statusColumns: number[] = [];
	let cur: { unit: LintUnit; isList: boolean; listIndent: number } | null = null;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		if (FENCE_RE.test(line)) { inFence = !inFence; cur = null; statusColumns = []; continue; }
		if (inFence) continue;
		if (line.trim() === "") { cur = null; statusColumns = []; continue; }
		if (HEADING_RE.test(line) || TABLE_ROW_RE.test(line)) {
			if (TABLE_ROW_RE.test(line) && !TABLE_SEPARATOR_RE.test(line)) {
				const cells = tableCells(line);
				if (TABLE_SEPARATOR_RE.test(lines[i + 1] ?? "")) {
					statusColumns = cells.flatMap((cell, col) => STATUS_FIELD_NAME_RE.test(cell.replace(/列$/, "")) ? [col] : []);
					units.push({ start: i + 1, text: line });
				} else units.push({ start: i + 1, text: line, statusFields: statusColumns.map((col) => cells[col] ?? "") });
			} else if (HEADING_RE.test(line)) {
				statusColumns = [];
				units.push({ start: i + 1, text: line.trim() });
			}
			cur = null;
			continue;
		}
		statusColumns = [];
		const listMatch = LIST_ITEM_RE.exec(line);
		if (listMatch) {
			const unit = { start: i + 1, text: line.trim() };
			units.push(unit);
			cur = { unit, isList: true, listIndent: listMatch[1].length };
			continue;
		}
		const indent = line.length - line.trimStart().length;
		if (cur && cur.isList && indent > cur.listIndent) {
			cur.unit.text = `${cur.unit.text} ${line.trim()}`;
			continue;
		}
		if (cur && !cur.isList) { cur.unit.text = `${cur.unit.text} ${line.trim()}`; continue; }
		const unit = { start: i + 1, text: line.trim() };
		units.push(unit);
		cur = { unit, isList: false, listIndent: 0 };
	}
	return units;
}

// ── 规则 1：危险回退指令（门控：共享树 / 任务书禁 Git 写） ─────────────────────

/** 劝阻/否定语境标记：单元含任一标记 → 该单元的回退指令不报（「不得 git checkout」「禁止 rm -rf」）。 */
const PROHIBITION_RE = /不得|不要|请勿|禁止|切勿|不可|避免|未执行|未运行|未使用|never|must\s+not|don'?t/i;

const ROLLBACK_COMMAND_PATTERNS: ReadonlyArray<{ re: RegExp; label: string }> = [
	{ re: /\bgit\s+checkout\s+(?:--|(?:\S+\s+)--)/i, label: "git checkout --" },
	{ re: /\bgit\s+checkout\s+\.(?!\S)/, label: "git checkout ." },
	{ re: /\bgit\s+reset\b[^|;&]{0,48}--hard\b/i, label: "git reset --hard" },
	{ re: /\bgit\s+clean\b/i, label: "git clean" },
];

/** rm 递归强制形态（-r 与 -f 同时出现：-rf/-fr/-r … -f/--recursive --force）。 */
function rmForceRecursiveHit(text: string): boolean {
	const rmRe = /\brm\b/g;
	let m: RegExpExecArray | null;
	while ((m = rmRe.exec(text)) !== null) {
		const tokens = text.slice(m.index + m[0].length).trimStart().split(/\s+/);
		let hasR = false, hasF = false, sawOperand = false;
		for (const t of tokens.slice(0, 12)) {
			if (t === "" ) continue;
			if (!sawOperand && t.startsWith("-") && t.length > 1) {
				if (t === "--recursive" || t === "--recursive=") hasR = true;
				else if (t === "--force") hasF = true;
				else if (!t.startsWith("--")) {
					if (/[rR]/.test(t.slice(1))) hasR = true;
					if (/[fF]/.test(t.slice(1))) hasF = true;
				}
			} else if (!t.startsWith("-")) sawOperand = true;
		}
		if (hasR && hasF) return true;
	}
	return false;
}

function scanUnsafeRollback(units: readonly LintUnit[]): Array<LintUnit & { detail: string }> {
	const hits: Array<LintUnit & { detail: string }> = [];
	for (const unit of units) {
		if (PROHIBITION_RE.test(unit.text)) continue;
		const pattern = ROLLBACK_COMMAND_PATTERNS.find((p) => p.re.test(unit.text));
		if (pattern) { hits.push({ ...unit, detail: pattern.label }); continue; }
		if (rmForceRecursiveHit(unit.text)) hits.push({ ...unit, detail: "rm -rf" });
	}
	return hits;
}

// ── 规则 2：明确状态字段内部的相反声明（b4345b：有限状态字段语法，自由叙述不猜） ────

/** Only explicit state values are understood; narrative text is deliberately unknown. */
const POSITIVE_STATES = new Set(["✅", "🟢", "PASS", "PASSED", "通过"]);
const NEGATIVE_STATES = new Set(["FAIL", "FAILED", "FIX", "未闭合", "未验证", "未通过", "未覆盖", "未完成", "失败", "缺失"]);
const STATUS_FIELD_NAME_RE = /^(?:verdict|status|result|[A-Za-z0-9_\-\u4e00-\u9fff]*(?:结论|状态|结果|判定|裁定))$/i;
const plainField = (value: string): string => value.replace(/\*\*|__|`/g, "").trim();

/** A field must consist entirely of state tokens, not prose containing state words. */
function fieldContradicts(value: string): boolean {
	const tokens = plainField(value).toUpperCase().split(/[\s/，,、]+/).filter(Boolean);
	if (!tokens.length || tokens.some((s) => !POSITIVE_STATES.has(s) && !NEGATIVE_STATES.has(s))) return false;
	return tokens.some((s) => POSITIVE_STATES.has(s)) && tokens.some((s) => NEGATIVE_STATES.has(s));
}

/** Each declaration is its own field; repeated names do not establish object identity. */
function labelContradicts(text: string): boolean {
	return plainField(text).split(/[。；;|]/).some((part) => {
		const field = /(?:^|[\s：:])([A-Za-z0-9_\-\u4e00-\u9fff]+)\s*[:：]\s*([^:：]*)$/.exec(part);
		return !!field && STATUS_FIELD_NAME_RE.test(field[1]) && fieldContradicts(field[2]);
	});
}

/** Markdown cells, retaining escaped pipes inside a cell. */
function tableCells(text: string): string[] {
	return text.trim().replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map(plainField);
}

/**
 * Only declared status columns and explicitly labelled fields are inspected. Other cells,
 * free prose, unknown values and separate declarations never acquire an inferred identity.
 */
function scanContradictoryStatus(units: readonly LintUnit[]): LintUnit[] {
	return units.filter((unit) => unit.statusFields?.some(fieldContradicts)
		|| (TABLE_ROW_RE.test(unit.text) ? tableCells(unit.text).some(labelContradicts) : labelContradicts(unit.text)));
}

// ── 任务书禁 Git 写识别（规则 1 门控输入；纯文本匹配显式劝阻句式） ─────────────

const GIT_WRITE_FORBID_PATTERNS: readonly RegExp[] = [
	/(不要|不得|请勿|禁止|切勿|不可|避免)\s*(?:git\s+)?(?:commit|push|rebase|merge|tag|checkout|reset|revert)/i,
	/不\s*(?:commit|push|rebase|merge)/i,
	/(do\s+not|don'?t|never)\s+(?:git\s+)?(?:commit|push|rebase|merge)/i,
];

/** 任务书是否显式禁止 Git 写操作（「不要 git commit」「不 push」等；命中即放宽规则 1 门控）。 */
export function gitWriteForbiddenInAssignment(assignment: string): boolean {
	return typeof assignment === "string" && GIT_WRITE_FORBID_PATTERNS.some((re) => re.test(assignment));
}

// ── 扫描编排（终稿 + 声明产物；有界只读） ────────────────────────────────────

export interface ReportLintTarget {
	/** 来源标签（"final-report" 或声明产物相对路径）。 */
	source: string;
	text: string;
}

/** 纯扫描：多目标 → 命中清单（每规则有界；source/line 定位，excerpt 摘录）。 */
export function scanReportTargets(
	targets: readonly ReportLintTarget[],
	opts: { rollbackLint: boolean },
): ReportLintFinding[] {
	const findings: ReportLintFinding[] = [];
	const perRule = new Map<ReportLintRuleId, number>();
	const push = (rule: ReportLintRuleId, source: string, objectRef: string, unit: LintUnit, detail?: string): void => {
		const n = perRule.get(rule) ?? 0;
		if (n >= MAX_FINDINGS_PER_RULE || findings.length >= MAX_REPORT_LINT_CHECKS) return;
		perRule.set(rule, n + 1);
		findings.push({
			rule, source, line: unit.start,
			excerpt: unit.text.replace(/\s+/g, " ").slice(0, 160),
			...(detail ? { detail } : {}),
			objectRef,
		});
	};
	for (const target of targets) {
		const digest16 = createHash("sha256").update(target.text).digest("hex").slice(0, 16);
		const units = splitLintUnits(target.text);
		if (opts.rollbackLint) {
			for (const hit of scanUnsafeRollback(units)) push("report-unsafe-rollback", target.source, digest16, hit, hit.detail);
		}
		for (const hit of scanContradictoryStatus(units)) push("report-contradictory-status", target.source, digest16, hit);
	}
	return findings;
}

export interface ReportLintBundleInput {
	cwd: string;
	/** 终稿原文（finalizer 的原始终稿；null/空 → 只扫声明产物）。 */
	reportText: string | null;
	/** 终稿来源标签（缺省 "final-report"）。 */
	reportLabel?: string;
	/** 冻结 spec.outputs 的相对路径清单（存在且可读才扫描；二进制/超限跳过）。 */
	declaredOutputs?: readonly string[];
	/** 规则 1 门控（共享树或任务书禁 Git 写）。 */
	rollbackLint: boolean;
}

export interface ReportLintBundle {
	findings: readonly ReportLintFinding[];
	startedAt: number;
	endedAt: number;
}

/** 有界读盘 + 扫描（finalizer 收尾链消费；单文件读失败/二进制 → 该文件无发现——缺席而非伪造）。 */
export function lintReportBundle(input: ReportLintBundleInput): ReportLintBundle {
	const startedAt = Date.now();
	const targets: ReportLintTarget[] = [];
	if (typeof input.reportText === "string" && input.reportText.trim() !== "") {
		targets.push({ source: input.reportLabel ?? "final-report", text: input.reportText.slice(0, MAX_SCAN_BYTES) });
	}
	for (const rel of (input.declaredOutputs ?? []).slice(0, MAX_OUTPUT_FILES)) {
		if (typeof rel !== "string" || rel.trim() === "") continue;
		try {
			const abs = path.resolve(input.cwd, rel);
			const st = fs.statSync(abs);
			if (!st.isFile() || st.size === 0 || st.size > MAX_SCAN_BYTES) continue;
			const text = fs.readFileSync(abs, "utf8");
			if (text.slice(0, 4096).includes("\u0000")) continue; // 二进制产物不适用文本 lint
			targets.push({ source: rel, text });
		} catch { /* lint-exempt:advisory 缺席——产物不可读（不存在/权限）如实跳过，不阻断结算 */ }
	}
	const findings = scanReportTargets(targets, { rollbackLint: input.rollbackLint });
	return { findings, startedAt, endedAt: Date.now() };
}

// ── advisory 检查构造（finalizer 回执 checks 接线面） ─────────────────────────

/**
 * 命中 → advisory CheckResult（required:false——不参与 settlement 判定；status="failed" 如实
 * 陈述 lint 命中；id 规格名段携带 规则@来源:行号，回执渲染可见定位；可经 decide.waivedCheckIds
 * 显式 waive——availableWaiverIds 覆盖 checks[].id 全集）。
 */
export function reportLintFindingsToChecks(
	lint: ReportLintBundle,
	cwd: string,
): CheckResult[] {
	return lint.findings.slice(0, MAX_REPORT_LINT_CHECKS).map((f) => ({
		id: newCheckId(`${f.rule}@${f.source}:${f.line}`),
		required: false,
		objectId: `report-lint@${f.objectRef}`,
		policyDigest: REPORT_LINT_POLICY_DIGEST,
		status: "failed" as const,
		argv: [],
		cwd,
		startedAt: lint.startedAt,
		endedAt: lint.endedAt,
	}));
}
