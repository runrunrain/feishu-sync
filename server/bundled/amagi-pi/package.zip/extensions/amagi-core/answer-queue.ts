/**
 * answer-queue.ts — T2-2：blocked TUI 待答队列（README §9.5；执行计划 T2-2）。
 *
 * 形态决策：§9.5 要求"问题进 TUI 待答队列（widget 常驻显示计数）"——workflow-board（T2-1）
 * 是模态 overlay（按需开合），无法满足"常驻"可见性；故采用**常驻队列 widget（blocked>0 时自动
 * 出现/消失）+ 快捷键 select→input→resume 作答流**。看板内 blocked 区块与本队列同读 registry，
 * 数据同源自然联动，无需跨模块调用（解耦）。
 *
 * 全链路：blocked 任务（registry，blockedQuestions 来自 P1-4 fence 协议）→ 常驻 widget 计数
 * → ctrl+shift+a → ctx.ui.select 选中任务 → ctx.ui.input 输入答案 → 回车 → runResumeTask
 * （answer 作为 resume 文本，session 取 rec.taskId——runResumeTask 内部 resolveSession 兼容
 * taskId/sessionId 前缀）→ sendUserMessage 回流结果。
 *
 * K5b（方案 §3.4-N5/N6）：注入的 runResumeTask 已接内核 begin-resume/finish-resume——blocked
 * →answering 迁移时内核投影同步 registry 记录，任务自动离开本队列（blocked 过滤语义不变）；
 * 并发续接被 N6 session lease 拒绝时，拒单根因经 ResumeResult.errorMessage 原样回流，不重试不吞错。
 *
 * dist 机制证据（node_modules/@earendil-works/pi-coding-agent/dist/core/extensions/types.d.ts）：
 * - L68-69 `select(title, options: string[], opts?): Promise<string | undefined>`——Esc 返回 undefined
 * - L72-73 `input(title, placeholder?, opts?): Promise<string | undefined>`——取消返回 undefined；
 *   ExtensionUIDialogOptions { signal?, timeout? }（L35-39，timeout 自动倒计时关闭）
 * - L95-99 setWidget 常驻队列展示（与 status-ui/shortcuts 同机制，独立 key）
 * - L211 + docs L2863：非 TUI 守卫。hongjun 实测：RPC 模式 input() 350ms 超时握手即返回，
 *   TUI 正常——本模块 select/input 仅在 TUI 路径调用，非 TUI 一律 no-op。
 * - resume 路径：task-tool.ts runResumeTask（既有导出，不改 task-tool.ts）——内部含
 *   no-session/运行中/无 sessionId/lease 防御（L549-555），回流文本如实呈现。
 * - session 生命周期：M5-b 同模式——模块内订阅 session_start（捕获新 ctx 并起轮询）/
 *   session_shutdown（停轮询清状态），index.ts 零新增接线。
 *
 * 接线说明（index.ts 一处，与 registerAmagiShortcuts 同处；本任务不改 index.ts）：
 *   import { registerAnswerQueue } from "./answer-queue.ts";
 *   registerAnswerQueue(pi, { agents, taskRegistry: registry, runResumeTask });
 *   —— runResumeTask 为 task-tool.ts 既有导出，直接透传。
 */

import type { AgentConfig } from "./agents-loader.ts";
import { findAgentByRequest } from "./agent-aliases.ts";
import type { TaskRecord } from "./task-registry.ts";
import { formatDuration, trimDisplay } from "./status-ui.ts";
import { blockedReplyDirective } from "./task-tool.ts";
import { sendTaskCompletion, sendMachineNotice, MACHINE_NOTICE_TYPE, type TaskCompletionSink } from "./evidence-context.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 类型（结构子集，mock 友好）
// ─────────────────────────────────────────────────────────────────────────────

export interface QueueCtx {
	cwd: string;
	mode: string;
	ui: {
		select(title: string, options: string[], opts?: { signal?: AbortSignal; timeout?: number }): Promise<string | undefined>;
		input(title: string, placeholder?: string, opts?: { signal?: AbortSignal; timeout?: number }): Promise<string | undefined>;
		notify(message: string, type?: "info" | "warning" | "error"): void;
		setWidget(key: string, content: string[] | undefined, options?: { placement?: "aboveEditor" | "belowEditor" }): void;
	};
}

export interface QueuePi extends TaskCompletionSink {
	registerShortcut(shortcut: string, options: { description?: string; handler: (ctx: QueueCtx) => Promise<void> | void }): void;
	on(event: string, handler: (event: unknown, ctx: QueueCtx) => void): void;
	sendUserMessage(content: string): void;
}

/** runResumeTask 返回的最小结构（RunResult 子集；taskId 供 blockedReplyDirective 回流）。 */
export interface ResumeResult {
	status: string;
	output: string;
	taskId?: string;
	errorMessage?: string;
	blocked?: boolean;
	/** diting Major-4：blocked 结构化原因——needs-handoff 的续跑回流显示「接手开工」而非逐项答复。 */
	blockReason?: "questions" | "needs-handoff";
}

export interface AnswerQueueDeps {
	agents: AgentConfig[];
	taskRegistry: { list(): Readonly<TaskRecord>[] };
	/** 注入 task-tool 既有 runResumeTask（sync resume：不传 background）。 */
	runResumeTask: (
		agent: AgentConfig,
		params: { session: string; task: string },
		opts: { cwd: string; signal?: AbortSignal },
	) => Promise<ResumeResult>;
	/** 键位覆盖；默认 ctrl+shift+a。 */
	key?: string;
	/** 队列轮询间隔 ms，默认 2000；测试可注入。 */
	intervalMs?: number;
}

export const DEFAULT_QUEUE_KEY = "ctrl+shift+a";
const QUEUE_WIDGET_KEY = "amagi:answer-queue";
const DEFAULT_INTERVAL_MS = 2000;
const MAX_QUEUE_LINES = 5;
const MAX_WIDTH = 96;

// ─────────────────────────────────────────────────────────────────────────────
// 队列渲染（纯函数，可测）
// ─────────────────────────────────────────────────────────────────────────────

function summaryOf(rec: Readonly<TaskRecord>): string {
	return rec.goal || rec.name || rec.taskId.slice(0, 12);
}

function questionOf(rec: Readonly<TaskRecord>): string {
	if (rec.blockedQuestions && rec.blockedQuestions.length > 0) return rec.blockedQuestions[0];
	if (rec.result) return trimDisplay(rec.result.replace(/\s+/g, " ").trim(), 120);
	return "（无问题摘要）";
}

/** 仅 QUESTIONS 待答进队列（diting Major-4）：blockReason="needs-handoff" 的 blocked 是
 *  settle 产出窗口收口——行动语义是 resume 接手开工而非逐项答复，不入待答队列/不作答流；
 *  无 blockReason 的遗留记录保持 QUESTIONS 语义（默认不变）。 */
export function blockedTasks(tasks: Readonly<TaskRecord>[]): Readonly<TaskRecord>[] {
	return tasks
		.filter((r) => r.status === "blocked" && r.blockReason !== "needs-handoff")
		.sort((a, b) => (a.endedAt || a.startedAt) - (b.endedAt || b.startedAt)); // 等待最久的在前
}

/** 常驻队列 widget 行；无 blocked 返回 []（调用方传 undefined 清除）。 */
export function buildQueueLines(tasks: Readonly<TaskRecord>[], now: number = Date.now(), maxWidth: number = MAX_WIDTH, keyHint: string = DEFAULT_QUEUE_KEY): string[] {
	const blocked = blockedTasks(tasks);
	if (blocked.length === 0) return [];
	const lines: string[] = [trimDisplay(`amagi 待答队列 · ${blocked.length} 个 blocked 待答复（${keyHint} 作答）`, maxWidth)];
	for (const rec of blocked.slice(0, MAX_QUEUE_LINES)) {
		const wait = formatDuration(now - (rec.endedAt || rec.startedAt));
		lines.push(trimDisplay(`  ${rec.agent} · ${summaryOf(rec)} · 等待 ${wait}`, maxWidth));
		lines.push(trimDisplay(`    ? ${questionOf(rec)}`, maxWidth));
	}
	if (blocked.length > MAX_QUEUE_LINES) lines.push(trimDisplay(`  …另有 ${blocked.length - MAX_QUEUE_LINES} 个待答`, maxWidth));
	return lines;
}

// ─────────────────────────────────────────────────────────────────────────────
// 注册
// ─────────────────────────────────────────────────────────────────────────────

export interface AnswerQueueController {
	queueKey: string;
	/** 立即刷新队列 widget（事件加速/测试用）。 */
	refresh(): void;
	/** 当前捕获的 TUI ctx 是否存在（测试观测用）。 */
	hasCtx(): boolean;
}

export function registerAnswerQueue(pi: QueuePi, deps: AnswerQueueDeps): AnswerQueueController {
	const queueKey = deps.key ?? DEFAULT_QUEUE_KEY;
	const intervalMs = deps.intervalMs ?? DEFAULT_INTERVAL_MS;
	let currentCtx: QueueCtx | undefined;
	let timer: ReturnType<typeof setInterval> | undefined;
	let unsubChange: (() => void) | undefined;
	let answering = false; // 作答流进行中不重入

	const uiWritable = (): boolean => !!currentCtx && currentCtx.mode === "tui";

	function refresh(): void {
		if (!uiWritable()) return;
		try {
			const lines = buildQueueLines(deps.taskRegistry.list(), Date.now(), MAX_WIDTH, queueKey);
			currentCtx!.ui.setWidget(QUEUE_WIDGET_KEY, lines.length > 0 ? lines : undefined, { placement: "aboveEditor" });
		} catch {}
	}

	function stopPoll(): void {
		unsubChange?.(); unsubChange = undefined;
		if (timer) { clearInterval(timer); timer = undefined; }
	}

	// session 生命周期（模块内订阅，M5-b 模式）：新 session 捕获 ctx 并起轮询；shutdown 清理
	pi.on("session_start", (_event: unknown, ctx: QueueCtx) => {
		currentCtx = ctx;
		stopPoll();
		if (ctx.mode === "tui") {
			refresh();
			// v1.5.185 事件响应：registry 变更立即刷新（主通道）；interval 仅为兜底心跳。
			unsubChange = (deps.taskRegistry as { onChange?: (fn: () => void) => () => void }).onChange?.(() => { try { refresh(); } catch {} });
			timer = setInterval(refresh, intervalMs);
			timer.unref?.();
		}
	});
	pi.on("session_shutdown", () => {
		stopPoll();
		if (currentCtx && currentCtx.mode === "tui") {
			try { currentCtx.ui.setWidget(QUEUE_WIDGET_KEY, undefined); } catch {}
		}
		currentCtx = undefined;
		answering = false;
	});

	// ── 作答流：select 选中 → input 答案 → runResumeTask 续跑 → 回流 ──
	async function answerFlow(ctx: QueueCtx): Promise<void> {
		const blocked = blockedTasks(deps.taskRegistry.list());
		if (blocked.length === 0) {
			try { ctx.ui.notify("amagi: 当前无 blocked 待答任务", "info"); } catch {}
			return;
		}
		// 1) 选中任务（C8-R fix: 选项含数组 index（唯一），防 startsWith 前缀碰撞）
		const options = blocked.map((rec, i) => {
			const wait = formatDuration(Date.now() - (rec.endedAt || rec.startedAt));
			const tid = rec.taskId.slice(0, 8);
			return trimDisplay(`[${i}:${tid}] ${rec.agent} · ${questionOf(rec)} · ${wait}`, 80);
		});
		const picked = await ctx.ui.select(`amagi 待答队列（${blocked.length}）`, options);
		if (picked === undefined) return; // Esc 取消：静默退出
		// C8-R fix: 回映用数组 index（唯一），不再用 startsWith（deadbeef-1111/deadbeef-2222 碰撞）
		const idxMatch = picked.match(/^\[(\d+):/);
		const rec = idxMatch ? blocked[parseInt(idxMatch[1], 10)] : undefined;
		if (!rec) return;

		// 2) 输入答案
		const answer = await ctx.ui.input(`${rec.agent} 提问：${trimDisplay(questionOf(rec), 60)}`, "输入答复，回车后续跑该任务");
		if (answer === undefined || answer.trim() === "") {
			try { ctx.ui.notify("amagi: 已取消作答，任务保持 blocked", "info"); } catch {}
			return;
		}

		// 3) 前置防御（runResumeTask 内部还有 no-session/lease 等防御，此处给即时反馈）
		const agent = findAgentByRequest(deps.agents, rec.agent);
		if (!agent) {
			try { ctx.ui.notify(`amagi: 角色 ${rec.agent} 未注册，无法续跑`, "error"); } catch {}
			return;
		}
		if (!rec.sessionId) {
			try { ctx.ui.notify(`amagi: 任务 ${rec.taskId.slice(0, 8)} 无 sessionId，无法续跑`, "error"); } catch {}
			return;
		}

		// 4) 异步续跑（answer 作为 resume 文本；不阻塞 handler；完成后回流）
		try { ctx.ui.notify(`amagi: 已续跑 ${rec.agent}（taskId ${rec.taskId.slice(0, 8)}），完成自动回流`, "info"); } catch {}
		void (async () => {
			try {
				const res = await deps.runResumeTask(agent, { session: rec.taskId, task: answer.trim() }, { cwd: ctx.cwd });
				const status = res.blocked ? "blocked" : res.status;
				// ev-20261101-7fffc6：续跑回流通 custom 机器通道（amagi:task-completion + details.taskId）
				// ——不再以无标记 role=user 进入会话被 selected 交接当不可裁剪用户要求累积。
				sendTaskCompletion(pi, `[待答续跑 ${rec.agent} · ${status}]\n\n${res.output || res.errorMessage || "(无输出)"}${blockedReplyDirective(res.taskId || rec.taskId, !!res.blocked, res.blockReason)}`, res.taskId || rec.taskId);
			} catch (e) {
				const msg = e instanceof Error ? e.message : String(e);
				try { sendMachineNotice(pi, MACHINE_NOTICE_TYPE, `[待答续跑 ${rec.agent}] 异常：${msg}`); } catch {}
			} finally {
				refresh(); // 队列即时更新（该任务已转 running 或终态）
			}
		})();
	}

	pi.registerShortcut(queueKey, {
		description: "amagi: blocked 待答队列（选中→作答→续跑）",
		handler: async (ctx) => {
			if (ctx.mode !== "tui") return; // dist docs L2863 + hongjun 实测 RPC input 超时
			if (answering) return; // 防重入：一次一个作答流
			answering = true;
			try { await answerFlow(ctx); } finally { answering = false; refresh(); }
		},
	});

	return { queueKey, refresh, hasCtx: () => !!currentCtx };
}
