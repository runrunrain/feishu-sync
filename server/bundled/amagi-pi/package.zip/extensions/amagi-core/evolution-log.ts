/**
 * evolution-log.ts — 插件自进化：摩擦点/期望改进的全局归类日志（v1.5.174）。
 *
 * 触发沉淀时（Leader/SubAgent 发现阻断点、摩擦点、期望改进）→ logItem 归类记录到全局根；
 * 已解决 ↔ 未解决自动位置调整：resolveItem 物理迁移 open/→resolved/；listItems 携带
 * currentVersion 时，fixVersion ≤ 当前版本却仍滞留 open/ 的条目自愈迁移（版本漂移兜底）。
 * 主上显式要求升级迭代插件时 → listItems({status:"open"}) 取未解决项，迭代后 resolveItem。
 *
 * 布局（全局，不写项目目录）：
 *   <root>/open/<id>.md       未解决条目（frontmatter + 现象 + 期望改进）
 *   <root>/resolved/<id>.md   已解决条目（resolveItem 迁移至此）
 *   <root>/evidence/<id>/<sha256>.txt   B9 证据留存副本（状态无关——open/resolved 同深度，
 *                                       相对链接 ../evidence/<id>/... 两态同形，迁移不搬移）
 *   <root>/.locks/<id>.lock   条目迁移排他锁（仅防并发迁移同一条目）
 *   <root>/index.ndjson       事件索引（log/resolve 追加行，可按 category/severity/时间聚合）
 *
 * 根解析：AMAGI_EVOLUTION_ROOT || <PI_CODING_AGENT_DIR || ~/.pi/agent>/amagi/evolution
 *
 * B9（ev-20261012-04b7b9，v2.19.3 证据留存）：
 *  - EvolutionItem 增 evidenceVersion/evidence/sourceContext/note（frontmatter 单行 JSON，沿用
 *    sessionRef 载体思路；旧条目缺省=legacy，读取不炸、resolve/export 兼容）；
 *  - logItem 写前脱敏（title/phenomenon/expected/source/note/sessionRef 先脱敏再 trim/截断——
 *    防截出低于匹配阈值的密钥残片）并把 source 解析基准记为结构化字段（cwd/gitRoot）；
 *  - 证据单项缺失/超限/被拒 → 条目照常落盘，回执披露『未留存：原因』（不阻断沉淀）；
 *  - resolve：清单与 digest 原样带入（身份不变）；首次可携 resolve 阶段附件；open 删除失败
 *    诚实报告『resolved 已写，open 未清除』；同 id 双份先报冲突不用 open 优先遮蔽。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as crypto from "node:crypto";
import { redactCredentials } from "./task-query-wire.ts";
import { resolveGitRoot } from "./task-export.ts";
import {
	type EvidenceInput, type EvidenceRecord, type EvidenceResult, type ManagedEvolutionRoot,
	EVIDENCE_INPUT_MAX, resolveManagedEvolutionRoot, captureEvidence, verifyEvidenceAt,
	validateEvidenceManifest, evidenceManifestCharsOk, globalEvidencePathFor, withItemLock,
	pushWarning, EvidenceSecurityError, safeWriteRegularFile, appendIndexEvent, enforceWriteTarget,
} from "./evolution-evidence.ts";

export type EvolutionCategory = "bug" | "friction" | "ux" | "capability";
// ev-20260901-cd4173 A：severity 放宽加 P3（对齐 session-friction-review 复盘的 P0-P3 优先级标准，
// 此前 P3 条目工具层无处归档）；缺省/未知回退仍 P2，向后兼容。
export type EvolutionSeverity = "P0" | "P1" | "P2" | "P3";
export type EvolutionStatus = "open" | "resolved";

export interface EvolutionSessionRef {
	sessionId: string;
	jsonlPath: string;
}

/** B9：source 相对锚点的解析基准（log 时点快照；探测失败字段为 null，不猜仓库名）。 */
export interface EvolutionSourceContext {
	cwd: string | null;
	gitRoot: string | null;
}

export interface EvolutionItem {
	id: string;
	title: string;
	category: EvolutionCategory;
	severity: EvolutionSeverity;
	status: EvolutionStatus;
	createdAt: string;
	resolvedAt?: string;
	fixVersion?: string;
	source?: string;
	/** 自动探测的 pi 会话现场；不替代或覆盖用户提供的 source。 */
	sessionRef?: EvolutionSessionRef;
	phenomenon: string;
	expected: string;
	/** B9：证据清单版本（只在显式传 evidence 时写；旧条目缺省 = legacy）。 */
	evidenceVersion?: 1;
	/** B9：留存/遗漏记录（retained|omitted 封闭清单；损坏时 evidenceInvalid 置位）。 */
	evidence?: EvidenceRecord[];
	/** B9：source 解析基准（新 log 写入）。 */
	sourceContext?: EvolutionSourceContext;
	/** B9：首次有效 resolve 的备注（脱敏后单行 JSON 存元数据；旧条目缺省）。 */
	note?: string;
	/** 运行时派生（不序列化）：evidence 元数据存在但校验失败（invalid-manifest）。 */
	evidenceInvalid?: boolean;
}

const CATEGORIES: readonly EvolutionCategory[] = ["bug", "friction", "ux", "capability"];
const SEVERITIES: readonly EvolutionSeverity[] = ["P0", "P1", "P2", "P3"];

export function evolutionRoot(): string {
	if (process.env.AMAGI_EVOLUTION_ROOT) return process.env.AMAGI_EVOLUTION_ROOT;
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi", "evolution");
}

/** semver -ish 比较：a<b→-1 a=b→0 a>b→1；非数字段按字典序兜底。 */
export function cmpVersion(a: string, b: string): number {
	const pa = a.split("."), pb = b.split(".");
	for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
		const xa = pa[i] ?? "0", xb = pb[i] ?? "0";
		const na = Number(xa), nb = Number(xb);
		if (Number.isFinite(na) && Number.isFinite(nb)) { if (na !== nb) return na < nb ? -1 : 1; }
		else if (xa !== xb) return xa < xb ? -1 : 1;
	}
	return 0;
}

function itemPath(root: string, status: EvolutionStatus, id: string): string {
	return path.join(root, status === "open" ? "open" : "resolved", `${id}.md`);
}

/** 条目文件路径单源导出（P5 wire：list/show 投影 path 槽复用；纯路径推导，零 I/O 零副作用）。 */
export function itemFilePath(root: string, status: EvolutionStatus, id: string): string {
	return itemPath(root, status, id);
}

/** 单行元数据字段注入防护：CR/LF/NUL 归一为空格（JSON 字段由 JSON.stringify 保证单行）。 */
function flattenInline(v: string): string {
	return v.replace(/[\r\n\u0000]+/g, " ");
}

function redactSessionRef(ref?: EvolutionSessionRef): EvolutionSessionRef | undefined {
	if (!ref) return undefined;
	return { sessionId: redactCredentials(ref.sessionId), jsonlPath: redactCredentials(ref.jsonlPath) };
}

/** 证据记录输出净化（F02）：summary/origin 路径描述过凭据形态脱敏——digest/bytes/lines 不动。 */
function redactEvidenceRecordForOutput(rec: EvidenceRecord): EvidenceRecord {
	const out: EvidenceRecord = { ...rec };
	if (rec.origin) {
		out.origin = {
			base: rec.origin.base,
			path: rec.origin.path !== null ? redactCredentials(rec.origin.path) : null,
			cwd: rec.origin.cwd !== null ? redactCredentials(rec.origin.cwd) : null,
			gitRoot: rec.origin.gitRoot !== null ? redactCredentials(rec.origin.gitRoot) : null,
		};
	}
	if (rec.summary !== undefined) (out as { summary?: string }).summary = redactCredentials(rec.summary);
	return out;
}

/** 完整条目输出/写前净化（B9 修复轮 F02：历史未脱敏正文与新输入同口径）——show 投影、resolve
 *  写 resolved md、export 写导出 md 共用；与 wire 同源（redactCredentials）。不修改磁盘源文件。 */
export function redactItemForOutput(it: EvolutionItem): EvolutionItem {
	return {
		...it,
		title: redactCredentials(it.title),
		source: it.source !== undefined ? redactCredentials(it.source) : undefined,
		fixVersion: it.fixVersion !== undefined ? redactCredentials(it.fixVersion) : undefined,
		sessionRef: redactSessionRef(it.sessionRef),
		phenomenon: redactCredentials(it.phenomenon),
		expected: redactCredentials(it.expected),
		note: it.note !== undefined ? redactCredentials(it.note) : undefined,
		evidence: it.evidence !== undefined ? it.evidence.map(redactEvidenceRecordForOutput) : undefined,
	};
}

export function serializeItem(it: EvolutionItem): string {
	const fm = [
		"---",
		`id: ${it.id}`,
		`title: ${flattenInline(it.title)}`,
		`category: ${it.category}`,
		`severity: ${it.severity}`,
		`status: ${it.status}`,
		`createdAt: ${it.createdAt}`,
	];
	if (it.resolvedAt) fm.push(`resolvedAt: ${it.resolvedAt}`);
	if (it.fixVersion) fm.push(`fixVersion: ${flattenInline(it.fixVersion)}`);
	if (it.source) fm.push(`source: ${flattenInline(it.source)}`);
	if (it.sourceContext) fm.push(`sourceContext: ${JSON.stringify(it.sourceContext)}`);
	if (it.evidenceVersion) fm.push(`evidenceVersion: ${it.evidenceVersion}`);
	if (it.evidence) fm.push(`evidence: ${JSON.stringify(it.evidence)}`);
	if (it.note !== undefined) fm.push(`note: ${JSON.stringify(it.note)}`);
	if (it.sessionRef) fm.push(`sessionRef: ${JSON.stringify(it.sessionRef)}`);
	fm.push("---", "", "## 现象", "", it.phenomenon.trim(), "", "## 期望改进", "", it.expected.trim(), "");
	if (it.sessionRef) {
		fm.push("## 现场", "", `现场：会话 ${it.sessionRef.sessionId}（jsonl 可回溯：task({session}) 或直接读文件）`, "");
	}
	return fm.join("\n");
}

function parseSessionRef(value: string | undefined): EvolutionSessionRef | undefined {
	if (!value) return undefined;
	try {
		const parsed = JSON.parse(value) as Partial<EvolutionSessionRef>;
		if (typeof parsed.sessionId !== "string" || !parsed.sessionId.trim()) return undefined;
		if (typeof parsed.jsonlPath !== "string" || !parsed.jsonlPath.trim()) return undefined;
		return { sessionId: parsed.sessionId, jsonlPath: parsed.jsonlPath };
	} catch { return undefined; }
}

export function parseItem(content: string): EvolutionItem | undefined {
	const m = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(content);
	if (!m) return undefined;
	const kv: Record<string, string> = {};
	for (const line of m[1].split("\n")) {
		const i = line.indexOf(":");
		if (i > 0) kv[line.slice(0, i).trim()] = line.slice(i + 1).trim();
	}
	if (!kv.id || !kv.title) return undefined;
	const body = m[2];
	const sec = (name: string): string => {
		const r = new RegExp(`## ${name}\\s*\\n([\\s\\S]*?)(?=\\n## |$)`).exec(body);
		return (r?.[1] ?? "").trim();
	};
	// B9：证据清单解析——损坏（JSON 非法/形状越界/超 96KiB/未知版本）→ evidenceInvalid，
	// 现象可展示但 resolve/export 拒绝（不伪装成无 evidence 旧条目吞掉）。
	let evidence: EvidenceRecord[] | undefined;
	let evidenceInvalid = false;
	if (kv.evidenceVersion !== undefined && kv.evidenceVersion !== "1") evidenceInvalid = true;
	if (kv.evidence !== undefined) {
		try {
			const parsed: unknown = JSON.parse(kv.evidence);
			if (!evidenceManifestCharsOk([kv.evidence, kv.sourceContext, kv.note])) evidenceInvalid = true;
			else {
				const manifest = validateEvidenceManifest(kv.id, parsed);
				if (manifest.ok) evidence = manifest.value;
				else evidenceInvalid = true;
			}
		} catch { /* lint-exempt:evidence JSON 非法 → invalid-manifest（拒绝 resolve/export，不吞错） */
			evidenceInvalid = true;
		}
	}
	let sourceContext: EvolutionSourceContext | undefined;
	if (kv.sourceContext !== undefined) {
		try {
			const sc = JSON.parse(kv.sourceContext) as Partial<EvolutionSourceContext>;
			sourceContext = { cwd: typeof sc.cwd === "string" ? sc.cwd : null, gitRoot: typeof sc.gitRoot === "string" ? sc.gitRoot : null };
		} catch { /* lint-exempt:溯源辅助字段损坏容忍：不作硬门 */ }
	}
	let note: string | undefined;
	if (kv.note !== undefined) {
		try {
			const n: unknown = JSON.parse(kv.note);
			if (typeof n === "string") note = n;
		} catch { /* lint-exempt:note 损坏容忍：不作硬门 */ }
	}
	return {
		id: kv.id,
		title: kv.title,
		category: (CATEGORIES.includes(kv.category as EvolutionCategory) ? kv.category : "friction") as EvolutionCategory,
		severity: (SEVERITIES.includes(kv.severity as EvolutionSeverity) ? kv.severity : "P2") as EvolutionSeverity,
		status: kv.status === "resolved" ? "resolved" : "open",
		createdAt: kv.createdAt || "",
		resolvedAt: kv.resolvedAt || undefined,
		fixVersion: kv.fixVersion || undefined,
		source: kv.source || undefined,
		sourceContext,
		evidenceVersion: kv.evidenceVersion === "1" ? 1 : undefined,
		evidence,
		note,
		evidenceInvalid: evidenceInvalid || undefined,
		sessionRef: parseSessionRef(kv.sessionRef),
		phenomenon: sec("现象"),
		expected: sec("期望改进"),
	};
}

/** 索引事件追加（F05：运行期失败传播为回执 warnings——条目已发布不回滚；安全追加不跟随链接）。 */
function appendIndex(root: string, ev: Record<string, unknown>): { ok: boolean; error?: string } {
	return appendIndexEvent(root, ev);
}

function writeItemAtomic(root: string, it: EvolutionItem): string {
	const p = itemPath(root, it.status, it.id);
	fs.mkdirSync(path.dirname(p), { recursive: true });
	const tmp = `${p}.tmp-${process.pid}`;
	enforceWriteTarget(p); // F01 终裁：条目 md 目标点逐 deny（file 规则不被目录检查代表）
	enforceWriteTarget(tmp); // F01 终裁：临时目标点
	safeWriteRegularFile(tmp, serializeItem(it)); // F04：预存链接拒绝重写 + O_NOFOLLOW
	fs.renameSync(tmp, p);
	return p;
}

export interface LogItemInput {
	title: string;
	category?: EvolutionCategory;
	severity?: EvolutionSeverity;
	phenomenon: string;
	expected: string;
	source?: string;
	sessionRef?: EvolutionSessionRef;
	/** B9：留存的证据文件（≤3 个；结构校验由工具面完成，直调调用方自保证形状）。 */
	evidence?: EvidenceInput[];
}

export interface LogItemResult {
	id: string;
	path: string;
	/** 本次证据留存结果（retained/omitted 逐项；未请求留存时 undefined）。 */
	evidenceResults?: EvidenceResult[];
	warnings?: string[];
}

/** 解析基准探测：cwd 词法值 + canonical 值 + git root（失败 null，不猜）。 */
function resolveContextBases(): { rawCwd: string; canonicalCwd: string; gitRoot: string | null } {
	const rawCwd = process.cwd();
	let canonicalCwd = rawCwd;
	try { canonicalCwd = fs.realpathSync.native(rawCwd); } catch { /* lint-exempt:realpath 失败保留词法值（后续安全检查兜底） */ }
	return { rawCwd, canonicalCwd, gitRoot: resolveGitRoot(rawCwd) ?? null };
}

/** 沉淀一条改进项到 open/（附证据留存与 sourceContext）。返回 id 与落盘路径。 */
export function logItem(input: LogItemInput, root: string = evolutionRoot()): LogItemResult {
	const now = new Date();
	const day = now.toISOString().slice(0, 10).replace(/-/g, "");
	const id = `ev-${day}-${crypto.randomBytes(3).toString("hex")}`;
	const managed = resolveManagedEvolutionRoot(root); // 安全拒斥抛 EvidenceSecurityError（工具面 → operation）
	const { rawCwd, canonicalCwd, gitRoot } = resolveContextBases();
	const warnings: string[] = [];
	let evidenceResults: EvidenceResult[] | undefined;
	let evidenceRecords: EvidenceRecord[] | undefined;
	if (input.evidence !== undefined) {
		if (input.evidence.length > EVIDENCE_INPUT_MAX) {
			throw new EvidenceSecurityError(`evidence 最多 ${EVIDENCE_INPUT_MAX} 个文件（收到 ${input.evidence.length}）`);
		}
		const cap = captureEvidence(input.evidence, { canonicalRoot: managed.canonical, id, phase: "log", cwd: canonicalCwd, gitRoot });
		evidenceRecords = cap.results.map((r) => r.record);
		evidenceResults = cap.results;
		warnings.push(...cap.warnings);
	}
	const it: EvolutionItem = {
		id,
		title: redactCredentials(input.title).trim().slice(0, 120),
		category: input.category && CATEGORIES.includes(input.category) ? input.category : "friction",
		severity: input.severity && SEVERITIES.includes(input.severity) ? input.severity : "P2",
		status: "open",
		createdAt: now.toISOString(),
		source: input.source !== undefined ? redactCredentials(input.source).slice(0, 300) : undefined,
		sessionRef: redactSessionRef(input.sessionRef),
		phenomenon: redactCredentials(input.phenomenon),
		expected: redactCredentials(input.expected),
		sourceContext: { cwd: rawCwd, gitRoot },
		evidenceVersion: input.evidence !== undefined ? 1 : undefined,
		evidence: evidenceRecords,
	};
	const p = writeItemAtomic(managed.root, it);
	const idx = appendIndex(managed.root, { op: "log", id, title: it.title, category: it.category, severity: it.severity });
	if (!idx.ok) pushWarning(warnings, `索引事件失败（log）：${idx.error ?? "未知原因"}——条目已发布不回滚`);
	return { id, path: p, evidenceResults, warnings };
}

function readDirItems(root: string, status: EvolutionStatus): EvolutionItem[] {
	const dir = path.join(root, status === "open" ? "open" : "resolved");
	let files: string[] = [];
	try { files = fs.readdirSync(dir).filter((f) => f.endsWith(".md")); } catch { return []; }
	const items: EvolutionItem[] = [];
	for (const f of files) {
		try {
			const it = parseItem(fs.readFileSync(path.join(dir, f), "utf8"));
			if (it) items.push(it);
		} catch { /* 单条损坏不拖垮列表 */ }
	}
	return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export interface ListOpts {
	/** 缺省 open；传 "all" 取全部。 */
	status?: EvolutionStatus | "all";
	/** 当前插件版本：open 中 fixVersion ≤ 该版本的滞留条目自动迁移 resolved（自愈位置调整）。 */
	currentVersion?: string;
}

/** 列出条目；携带 currentVersion 时执行自愈迁移（fixVersion 已发布但仍在 open/）。
 *  B9：warningsOut（可选出参）承接自愈失败/证据健康警告——list 面正文不变，仅 wire 携带。 */
export function listItems(opts: ListOpts = {}, root: string = evolutionRoot(), warningsOut?: string[]): EvolutionItem[] {
	const open = readDirItems(root, "open");
	const resolved = readDirItems(root, "resolved");
	if (opts.currentVersion) {
		for (const it of [...open]) {
			if (it.fixVersion && cmpVersion(it.fixVersion, opts.currentVersion) <= 0) {
				const r = resolveItem(it.id, { fixVersion: it.fixVersion, note: "版本自愈迁移（fixVersion ≤ 当前版本）" }, root);
				if (r.ok) {
					open.splice(open.indexOf(it), 1);
					resolved.push({ ...it, status: "resolved", resolvedAt: new Date().toISOString() });
				} else if (warningsOut) {
					pushWarning(warningsOut, `版本自愈迁移失败（${it.id}）：${r.error ?? "未知原因"}——条目保留 open`);
				}
			}
		}
	}
	const all = [...open, ...resolved];
	if (!opts.status || opts.status === "open") return open;
	if (opts.status === "resolved") return resolved;
	return all.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

type FindResult = { kind: "found"; it: EvolutionItem; status: EvolutionStatus } | { kind: "conflict"; id: string } | undefined;

/** id 前缀解析（open 优先，再 resolved）；同 id 双份（open+resolved 并存）→ 冲突报告，
 *  不用 open 优先遮蔽（B9：避免把 note/evidence 不同的两份误判为同一记录）。 */
function findItem(root: string, idOrPrefix: string): FindResult {
	for (const status of ["open", "resolved"] as const) {
		const hits = readDirItems(root, status).filter((i) => i.id === idOrPrefix || i.id.startsWith(idOrPrefix));
		if (hits.length === 1) {
			if (status === "open" && readDirItems(root, "resolved").some((i) => i.id === hits[0].id)) {
				return { kind: "conflict", id: hits[0].id };
			}
			return { kind: "found", it: hits[0], status };
		}
		if (hits.length > 1) return undefined; // 歧义
	}
	return undefined;
}

export interface ResolveItemOpts {
	fixVersion?: string;
	note?: string;
	/** B9：首次 resolve 可携 resolve 阶段附件（≤3；键 resolve-1..3；幂等分支不重采）。 */
	evidence?: EvidenceInput[];
}

export interface ResolveItemResult {
	ok: boolean;
	id?: string;
	path?: string;
	fixVersion?: string;
	error?: string;
	/** 工具面错误码映射：not-found（未找到/歧义）/ invalid-input / operation（安全拒斥、半提交、锁）。 */
	errorCode?: "not-found" | "invalid-input" | "operation";
	/** 本次 resolve 阶段附件留存结果（未携附件时 undefined）。 */
	evidenceResults?: EvidenceResult[];
	warnings?: string[];
}

function resolveLocked(managed: ManagedEvolutionRoot, id: string, opts: ResolveItemOpts): ResolveItemResult {
	// B9 修复轮 F03（diting 终裁）：锁内重读——并发迁移完成后本调用走幂等分支，不覆盖已提交的
	// note/fixVersion；冲突与状态以锁内快照为准，不用锁外旧快照。
	const refound = findItem(managed.root, id);
	if (!refound) return { ok: false, error: `未找到（或前缀歧义）: ${id}`, errorCode: "not-found" };
	if (refound.kind === "conflict") {
		return { ok: false, error: `同 id 双份（open 与 resolved 均有 ${refound.id}）——先核对两份与回执再人工恢复，不用 open 优先遮蔽`, errorCode: "operation" };
	}
	const prior = refound.it;
	if (refound.status === "resolved") {
		// 幂等：不改 fixVersion、不重采附件、不覆盖 note；传入新 note/evidence 时警告未应用
		const warnings: string[] = [];
		if (opts.note !== undefined || opts.evidence !== undefined) {
			pushWarning(warnings, "条目已 resolved：本次传入的 note/evidence 未应用（幂等不覆盖）");
		}
		return { ok: true, id: prior.id, path: itemPath(managed.root, "resolved", prior.id), fixVersion: prior.fixVersion, warnings };
	}
	if (prior.evidenceInvalid) {
		return { ok: false, error: `条目 ${prior.id} 证据清单损坏（invalid-manifest）——拒绝迁移，须人工核对 evidence 字段`, errorCode: "operation" };
	}
	const warnings: string[] = [];
	// 既有清单健康检查：missing/drifted 只警告不阻断（证据健康不替代人工修复判断）
	if (prior.evidence !== undefined && prior.evidence.length > 0) {
		const v = verifyEvidenceAt(path.join(managed.canonical, "open"), prior.evidence, (hex) => globalEvidencePathFor(prior.id, hex));
		warnings.push(...v.warnings);
		for (const r of v.results) {
			if (r.record.state === "retained" && r.health !== "verified") {
				pushWarning(warnings, `既有证据 ${r.record.key} 状态 ${r.health}——迁移照常进行；须人工核对/修复`);
			}
		}
	}
	// 首次 resolve 可携新附件（resolve 阶段名额；幂等分支已提前返回，不会重采）
	let evidenceResults: EvidenceResult[] | undefined;
	let newRecords: EvidenceRecord[] | undefined;
	if (opts.evidence !== undefined && opts.evidence.length > 0) {
		if (opts.evidence.length > EVIDENCE_INPUT_MAX) {
			return { ok: false, error: `evidence 最多 ${EVIDENCE_INPUT_MAX} 个文件（收到 ${opts.evidence.length}）`, errorCode: "invalid-input" };
		}
		const { canonicalCwd, gitRoot } = resolveContextBases();
		const cap = captureEvidence(opts.evidence, { canonicalRoot: managed.canonical, id: prior.id, phase: "resolve", cwd: canonicalCwd, gitRoot });
		newRecords = cap.results.map((r) => r.record);
		evidenceResults = cap.results;
		warnings.push(...cap.warnings);
	}
	// B9 修复轮 F02：展开 prior 后的 resolved md 与新输入同口径净化（历史未脱敏正文写前脱敏）
	const clean = redactItemForOutput(prior);
	const note = opts.note !== undefined ? redactCredentials(opts.note) : clean.note;
	const mergedEvidence = clean.evidence !== undefined || newRecords !== undefined
		? [...(clean.evidence ?? []), ...(newRecords ?? [])]
		: undefined;
	const rawFix = opts.fixVersion || clean.fixVersion;
	const it: EvolutionItem = {
		...clean,
		status: "resolved",
		resolvedAt: new Date().toISOString(),
		fixVersion: rawFix !== undefined && rawFix !== "" ? redactCredentials(rawFix) : undefined,
		note,
		evidenceVersion: mergedEvidence !== undefined ? 1 : clean.evidenceVersion,
		evidence: mergedEvidence,
	};
	const newPath = writeItemAtomic(managed.root, it);
	try { fs.unlinkSync(itemPath(managed.root, "open", it.id)); }
	catch (e) {
		// 半提交诚实披露：resolved 已写、open 未清除——保留两份，不能报迁移完成
		return {
			ok: false, id: it.id, path: newPath,
			error: `resolved 已写，open 未清除（保留两份，人工核对后处理）: ${e instanceof Error ? e.message : String(e)}`,
			errorCode: "operation", warnings,
		};
	}
	const idx = appendIndex(managed.root, { op: "resolve", id: it.id, fixVersion: it.fixVersion, note });
	if (!idx.ok) pushWarning(warnings, `索引事件失败（resolve）：${idx.error ?? "未知原因"}——条目已发布不回滚`);
	return { ok: true, id: it.id, path: newPath, fixVersion: it.fixVersion, evidenceResults, warnings };
}

/** 标记解决并自动迁移 open/→resolved/（位置调整主路径）。
 *  P5 wire DTO 增量：成功回执附 fixVersion（迁移后条目真实生效值——幂等分支携条目原值）。
 *  B9：证据清单原样随条目带入（路径/digest 不变，不搬移不重采）；条目级排他锁防并发迁移。 */
export function resolveItem(idOrPrefix: string, opts: ResolveItemOpts = {}, root: string = evolutionRoot()): ResolveItemResult {
	let managed: ManagedEvolutionRoot;
	try {
		managed = resolveManagedEvolutionRoot(root);
	} catch (e) {
		return { ok: false, error: e instanceof Error ? e.message : String(e), errorCode: "operation" };
	}
	const found = findItem(managed.root, idOrPrefix);
	if (!found) return { ok: false, error: `未找到（或前缀歧义）: ${idOrPrefix}`, errorCode: "not-found" };
	if (found.kind === "conflict") {
		return { ok: false, error: `同 id 双份（open 与 resolved 均有 ${found.id}）——先核对两份与回执再人工恢复，不用 open 优先遮蔽`, errorCode: "operation" };
	}
	try {
		return withItemLock(managed.canonical, found.it.id, () => resolveLocked(managed, found.it.id, opts));
	} catch (e) {
		return { ok: false, error: e instanceof Error ? e.message : String(e), errorCode: "operation" };
	}
}

/** 文本渲染（工具输出用）。 */
export function renderItemsText(items: EvolutionItem[], title: string): string {
	if (items.length === 0) return `${title}：无条目`;
	const lines = [`${title}（${items.length} 条）`];
	for (const it of items) {
		lines.push(`${it.status === "open" ? "○" : "●"} ${it.id} [${it.category}/${it.severity}] ${it.title}${it.fixVersion ? ` → v${it.fixVersion}` : ""}`);
	}
	return lines.join("\n");
}
