import type { AdvisorGrant } from "./contracts/advisor.ts";
/**
 * task-permission.ts — amagi-pi v2 P1（方案 §5.1/§8.3-P1）：授权交集计算与冻结 PermissionGrant。
 *
 * 实际权限 = 角色能力上限 ∩ 用户/受信授权 ∩ 任务请求 ∩ 后端可兑现能力；deny 恒优先（§5.1）。
 * 本片只做**授予计算与冻结**：产出通过 validatePermissionGrant 的冻结 PermissionGrant（供
 * submitTaskKernel 冻结进 TaskSpec / P4 交付子进程）；每通道执行点执法属 P2/P3（§5.2 通道执行点表）。
 *
 * 通道 × 语义矩阵（computeEffectiveGrant，K1 缺口「输出覆盖校验」在此补齐）：
 * | 通道           | role 上限                          | user 收紧                    | task 请求                                              | backend      | 空交集/超限语义 |
 * |----------------|-----------------------------------|------------------------------|--------------------------------------------------------|--------------|------------------|
 * | read           | **不设上限（声明性通道，ev-20260919）**：恒冻结全仓读 ["**"]，不做角色/用户/请求三方交集，scope.read 仅作任务输入面声明留档；执行期读不设范围限制（仅 deny 禁入护读，P2 checkRead） | 不参与 | 声明性（不影响授予） | 无关 | 恒授予（无空交集态） |
 * | write/reportFiles | 请求逐条须被角色上限覆盖（matchPathRule 覆盖检查；超上限→整任务拒绝：任务要求超出角色职责，明确错误+修复提示） | 交集收窄（未覆盖条目**丢弃不拒绝**；全部丢弃→空交集拒绝） | scope.write 未声明→缺省回退角色卡 capabilities.write（ev-20261016 主上裁定）；显式空数组=显式收紧不回退；reportFiles 未声明不授予（仅 reportFiles 基线） | 无关 | 显式请求非空而交集为空→整任务拒绝（必需通道） |
 * | deny           | 角色 deny ∪ 用户 deny（恒并入）    | —                            | scope.deny ∪                                            | —            | 任何授予不覆盖 deny；输出落在 deny 区→整任务拒绝 |
 * | shell          | role.shell                        | authority.maxAssurance       | scope.shell（缺省 deny）                                | backend.shell | guarded 需四方全过；请求 guarded 而交集为 deny→整任务拒绝 |
 * | assurance      | role.assurance                    | authority.maxAssurance       | 由 shell 推导                                            | —            | shell=guarded→guarded；否则 tool-enforced（K1 校验器保证 tool-enforced⇒shell deny） |
 * | mcp/lsp        | 请求 ⊆ 角色名单（超上限→拒绝）     | 名单交集收窄                  | 显式请求（缺省 ∅）                                       | 不支持→能力空 | 显式请求非空而交集为空→拒绝 |
 * | outputs        | —                                 | —                            | outputs[].path                                          | —            | 每条被 reportFiles∪write 覆盖且不中 deny，否则整任务拒绝 |
 *
 * 双格式归一化（防迁移误放权，§8.3-P1 风险项）：tools 字段接受逗号字符串与 YAML 字符串数组
 * （normalizeToolsField 单一实现，agents-loader 调用）；capabilities 结构化字段是能力上限唯一来源——
 * 非法值 fail-closed（该角色任务在授权计算处拒绝，不回退无限权限）；未声明 capabilities 的角色
 * 一切通道上限为空（任何请求/只读基线都无法覆盖→任务拒绝）。
 *
 * 消费面（P2/P4 接线点）：task-facets task_submit 的 scope 参数 → computeEffectiveGrant →
 * submitTaskKernel({ permission })（本片冻结入口）；P2 文件工具执法与 P4 子进程 --tools/RPC 权限
 * 指纹从 spec.permission 读取。user 受信配置面（amagi.json 授权字段）属 P2/P4 配置接线。
 */
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { globToRegExp } from "./path-match.ts";
import {
	LSP_CAPABILITIES,
	PERMISSION_ASSURANCES,
	SHELL_POLICIES,
	validatePermissionGrant,
	type CodemodeGrantBudget,
	type LspCapability,
	type PathRule,
	type PermissionAssurance,
	type PermissionGrant,
	type ReadOnlyCodemodeGrant,
	type ShellPolicy,
} from "./contracts/permission.ts";
import type { ShellChannelRequest, SubmitScope } from "./contracts/command.ts";
import {
	CONTRACT_ERROR_CODES,
	err,
	isNonEmptyString,
	isRecord,
	ok,
	rejectUnknownKeys,
	type Result,
} from "./contracts/view.ts";

// ── 角色能力上限（agents/*.md capabilities 字段的冻结形状；agents-loader 消费本校验器） ──

/** 角色能力上限声明（模式串为工作区相对或绝对路径；绝对化在 computeEffectiveGrant 按冻结 cwd 进行）。 */
export interface RoleCapabilitySpec {
	/** 角色可承诺的最高保证等级（tool-enforced ⇒ shell 必须 deny，镜像 K1 校验语义）。 */
	assurance: PermissionAssurance;
	shell: ShellPolicy;
	/** 读范围模式串（glob/prefix:/目录尾斜杠；无通配符=精确路径等值匹配）。 */
	read: readonly string[];
	write: readonly string[];
	deny: readonly string[];
	/** 报告可写模式串（reportFiles 通道的角色上限）。 */
	report: readonly string[];
	/** 允许的统一 MCP 通道工具名（"*"=通道内任意工具，仅上限声明；P3 按 server/tool 执法收紧）。 */
	mcp: readonly string[];
	lsp: readonly LspCapability[];
	/** B5A（7517d8 设计 §3.1）：codemode 能力上限。缺省 deny；read-only 只是角色上限——还需角色卡
	 *  tools 列 codemode、受信配置角色开关、本次 scope.codemode 显式请求、后端已验证装配四方
	 *  同时成立才授予（双门：capabilities 与 tools 缺一不可）。 */
	codemode?: "deny" | "read-only";
	advisor?: "deny" | "consult";
	/** 角色章程（纯声明，不参与授权交集）：read-only=只读+报告（不改项目文件）；artifact=只写任务授权
	 *  artifact（不改项目代码）；write=可改项目文件。缺省按 write 推导（非空→write，空→read-only）。
	 *  只读判定（worktree 建议抑制）与名册权限标签唯一据此投影，不再匹配 description 措辞。 */
	charter?: RoleCharter;
}

export type RoleCharter = "read-only" | "artifact" | "write";
export const ROLE_CHARTERS: readonly RoleCharter[] = ["read-only", "artifact", "write"];

/** 角色章程投影（单源）：显式 charter 优先，缺省按 write 上限推导；无 capabilities 返回 undefined。 */
export function roleCharterOf(caps: Pick<RoleCapabilitySpec, "write" | "charter"> | undefined): RoleCharter | undefined {
	if (!caps) return undefined;
	if (caps.charter !== undefined) return caps.charter;
	return caps.write.length > 0 ? "write" : "read-only";
}

const CAP_STRING_ARRAY_FIELDS = ["read", "write", "deny", "report", "mcp"] as const;

/** capabilities 结构校验（agents-loader 在发现期调用；失败即 fail-closed，不做宽松回退）。 */
export function validateRoleCapabilities(v: unknown): Result<RoleCapabilitySpec> {
	if (!isRecord(v)) {
		return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "capabilities 必须是对象（字段：assurance/shell/read/write/deny/report/mcp/lsp/codemode/advisor/charter）", ["capabilities"]);
	}
	const shape = rejectUnknownKeys(v, ["assurance", "shell", "read", "write", "deny", "report", "mcp", "lsp", "codemode", "advisor", "charter"], "capabilities");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["capabilities"]);
	if (!PERMISSION_ASSURANCES.includes(v.assurance as PermissionAssurance)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `capabilities.assurance 必须是 ${PERMISSION_ASSURANCES.join("/")} 之一`, ["capabilities.assurance"]);
	}
	if (!SHELL_POLICIES.includes(v.shell as ShellPolicy)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `capabilities.shell 必须是 ${SHELL_POLICIES.join("/")} 之一`, ["capabilities.shell"]);
	}
	// 镜像 K1 冻结语义（§5.1）：tool-enforced 保证等级下通用 shell 必须禁用。
	if (v.assurance === "tool-enforced" && v.shell !== "deny") {
		return err(
			CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
			"capabilities.assurance=tool-enforced 时 shell 必须为 deny（受控工具通道不接受通用 shell）",
			["capabilities.assurance", "capabilities.shell"],
			"none",
			[{ assurance: "tool-enforced", shell: "deny" }],
		);
	}
	const out: Record<string, readonly string[]> = {};
	for (const f of CAP_STRING_ARRAY_FIELDS) {
		const list = v[f];
		if (!Array.isArray(list)) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `capabilities.${f} 必须是字符串数组（空数组=该通道无上限授予）`, [`capabilities.${f}`]);
		}
		for (let i = 0; i < list.length; i++) {
			if (!isNonEmptyString(list[i])) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `capabilities.${f}[${i}] 必须是非空字符串`, [`capabilities.${f}[${i}]`]);
		}
		out[f] = [...list] as readonly string[];
	}
	if (!Array.isArray(v.lsp)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "capabilities.lsp 必须是数组", ["capabilities.lsp"]);
	for (let i = 0; i < v.lsp.length; i++) {
		if (!LSP_CAPABILITIES.includes(v.lsp[i] as LspCapability)) {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `capabilities.lsp[${i}] 必须是 ${LSP_CAPABILITIES.join("/")} 之一`, [`capabilities.lsp[${i}]`]);
		}
	}
	if (v.advisor !== undefined && v.advisor !== "deny" && v.advisor !== "consult") return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "capabilities.advisor 只认 deny/consult", ["capabilities.advisor"]);
	if (v.codemode !== undefined && v.codemode !== "deny" && v.codemode !== "read-only") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "capabilities.codemode 必须是 deny/read-only 之一（缺省 deny）", ["capabilities.codemode"]);
	}
	if (v.charter !== undefined) {
		if (!ROLE_CHARTERS.includes(v.charter as RoleCharter)) {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `capabilities.charter 必须是 ${ROLE_CHARTERS.join("/")} 之一`, ["capabilities.charter"]);
		}
		// 章程与写上限必须一致：只读/artifact 章程不得声明项目写上限，write 章程必须有写上限。
		const hasWrite = out.write!.length > 0;
		if ((v.charter === "write") !== hasWrite) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `capabilities.charter=${String(v.charter)} 与 write 上限矛盾（write 章程要求 write 非空；read-only/artifact 要求 write 为空）`, ["capabilities.charter", "capabilities.write"]);
		}
	}
	return ok({
		assurance: v.assurance as PermissionAssurance,
		shell: v.shell as ShellPolicy,
		read: out.read!,
		write: out.write!,
		deny: out.deny!,
		report: out.report!,
		mcp: out.mcp!,
		lsp: [...v.lsp] as LspCapability[],
		...(v.advisor !== undefined ? { advisor: v.advisor as "deny" | "consult" } : {}),
		...(v.codemode !== undefined ? { codemode: v.codemode as "deny" | "read-only" } : {}),
		...(v.charter !== undefined ? { charter: v.charter as RoleCharter } : {}),
	});
}

// ── 角色通道能力面速查（ev-20260923-93ede6）────────────────────────────────────

/** 通道名单展示归一：空=「无」；含 "*"=通道内任意（仅上限声明）；其余逐项 join。 */
export function formatChannelList(list: readonly string[]): string {
	if (list.length === 0) return "无";
	if (list.includes("*")) return "*（通道内任意）";
	return list.join(",");
}

/** 角色通道上限速查行（单源格式，例：`<角色> 角色通道上限：shell=deny、mcp=无、lsp=无`——自定义受限角色）。
 *  消费面：交集拒绝文案（required-channel-empty）、task_submit dryRun 预检摘要、
 *  amagi_resource({resource:"agents"}) 机器投影段——三处共用同一投影，不维护第二份手写配置。 */
export function roleChannelCapsSummary(
	name: string,
	caps: { shell: ShellPolicy; mcp: readonly string[]; lsp: readonly LspCapability[] },
): string {
	return `${name} 角色通道上限：shell=${caps.shell}、mcp=${formatChannelList(caps.mcp)}、lsp=${caps.lsp.length > 0 ? caps.lsp.join(",") : "无"}`;
}

// ── tools 双格式归一化（§5.1：逗号字符串与 YAML 字符串数组等价；单一实现） ─────────

/** tools 字段归一化：逗号分隔字符串（既有格式）或字符串数组（YAML 数组格式）→ 去空格/小写/去空项。
 *  其余形态归一化为空数组（调用方按「tools 为空」拒收，不回退宽权限）。 */
export function normalizeToolsField(v: unknown): string[] {
	const raw = typeof v === "string" ? v.split(",") : Array.isArray(v) ? v : [];
	const out: string[] = [];
	for (const t of raw) {
		if (typeof t !== "string") continue;
		const s = t.trim().toLowerCase();
		if (s) out.push(s);
	}
	return out;
}

// ── 用户/受信授权上限与后端能力（四方交集的另两方） ─────────────────────────────

/** 用户/受信配置授权面：各通道可收紧上限（缺省某通道=不设额外上限，角色上限即上限；
 *  提供后=交集收窄：未覆盖请求条目丢弃，不整任务拒绝——与角色超限语义区分，§5.1）。 */
export interface UserAuthorityCaps {
	maxAssurance: PermissionAssurance;
	read?: readonly string[];
	write?: readonly string[];
	reportFiles?: readonly string[];
	/** 用户禁入面（恒生效，与角色/请求 deny 取并集）。 */
	deny: readonly string[];
	/** MCP 工具名白名单（含 "*"=不收紧该名单）。 */
	mcp?: readonly string[];
	lsp?: readonly LspCapability[];
	/** B5A：codemode 受信授权面（amagi.json codemode 节解析产物，task-facets 接线注入）。
	 *  缺席=无主体开启（任何 scope.codemode 请求都拒）；roles 是已开主体名单（canonical 名），
	 *  budget 是受信配置物化的冻结预算（预算只在受信配置冻结，避免三份数字漂移）。 */
	codemode?: { roles: ReadonlySet<string>; budget: CodemodeGrantBudget };
	advisor?: { roles: ReadonlySet<string>; grant: AdvisorGrant };
}

/** 未接线受信配置时的过渡授权面（P2/P4 由 amagi.json/CallerContext 构造注入；测试注入收紧面）。 */
export function unlimitedUserAuthority(maxAssurance: PermissionAssurance = "guarded"): UserAuthorityCaps {
	return { maxAssurance, deny: [] };
}

/** 后端可兑现能力（§5.1 第四方：json 后端 --tools/shell 可控；rpc 后端经 worker 权限指纹）。 */
export interface BackendCaps {
	backend: "json" | "rpc";
	codemodeComposition?: boolean;
	shell: boolean;
	mcp: boolean;
	lsp: boolean;
	/** B5A：是否具备受控工厂装配能力（公开 createCodemodeExtension 工厂导入探测 + 同名替换可验证）。
	 *  不能仅以版本 ≥1.1.0 置 true——父端经 codemode-adapter 的运行时探测结果构造（task-facets 接线）。
	 *  RPC 本批恒 false（Q-C2）。 */
	codemode?: boolean;
	advisor?: boolean;
}

export const JSON_BACKEND_CAPS: Readonly<BackendCaps> = { backend: "json", codemodeComposition: true, shell: true, mcp: true, lsp: true, advisor: true };
export const RPC_BACKEND_CAPS: Readonly<BackendCaps> = { backend: "rpc", codemodeComposition: true, shell: true, mcp: true, lsp: true, codemode: false };

/** scope 缺省时的只读基线请求（§5.1「项目只读任务默认 tool-enforced」：全仓读 + 报告路径写）。 */
export const READ_ONLY_BASELINE_SCOPE: Readonly<SubmitScope> = { read: ["**"], reportFiles: ["agent-outputs/**"] };

// ── 模式串 → PathRule 归一化与匹配（匹配语义与 path-match.ts 单源一致） ───────────

/** 模式串（工作区相对或绝对）按冻结 cwd 绝对化，通配符原样透传（path.resolve 视为普通字符）。 */
function absPattern(p: string, cwd: string): string {
	const t = p.trim();
	return path.isAbsolute(t) ? path.normalize(t) : path.resolve(cwd, t);
}

/** 模式串 → 显式 PathRule：`prefix:` 前缀 / 尾斜杠=directory / 含通配符或无语法=glob
 *  （无通配符 glob 即精确等值匹配；prefix 不隐式当目录，§5.2）。 */
export function pathPatternToRule(pattern: string, cwd: string): PathRule {
	const t = pattern.trim();
	if (t.startsWith("prefix:")) return { kind: "prefix", value: absPattern(t.slice("prefix:".length), cwd) };
	if (t.endsWith("/")) return { kind: "directory", value: absPattern(t.slice(0, -1), cwd) };
	return { kind: "glob", value: absPattern(t, cwd) };
}

/** ev-20260919（目录请求语义修复）：无通配符请求条目的目录感知归一——条目存在且是**文件** → 保持
 *  精确（file 意图）；目录或不存在 → 补尾斜杠（directory 规则=自身+子树）。动机：write:["<dir>"]（无
 *  /**）被「无通配符 glob=精确等值」冻成仅授权目录路径本身，子 Agent 写 <dir>/任何文件全部「越界」
 *  （battle-sim worktree 实战：授权扩宽后仍全拒的真正根因——不是 grant 陈旧）。通配符/prefix:/已带尾
 *  斜杠条目原样返回（显式语法不动）。 */
export function dirAwareEntryAbs(entryAbs: string): string {
	if (entryAbs.startsWith("prefix:")) return entryAbs;
	if (entryAbs.includes("*") || entryAbs.endsWith("/")) return entryAbs;
	try {
		const st = fs.statSync(entryAbs);
		if (st.isFile()) return entryAbs; // 文件意图：保持精确等值
	} catch { /* 不存在：按目录意图（新建目录树授予） */ }
	return entryAbs + "/";
}

/** agent-outputs 报告目录判定（ev-20260919 写面豁免）：绝对路径中任一目录段 === "agent-outputs" 即 true。
 *  框架约定报告目录（角色卡 report 上限本就是 agent-outputs/**）从写执法面豁免——worktree 任务的
 *  任务 cwd 是工作树，角色 "**" 写上限锚定工作树后，主树 agent-outputs 报告路径全部被「超出写上限」
 *  硬拦（纯摩擦）。豁免在 P1 上限/覆盖校验、P2 checkWrite、P4 父子闸三处同步生效；deny 恒优先不变。 */
export function isAgentOutputsPath(targetAbs: string): boolean {
	const segs = path.normalize(targetAbs).split(path.sep);
	return segs.includes("agent-outputs");
}

/** PathRule 匹配器（P2 执行点执法复用；glob 语义=globToRegExp 单源）。 */
export function matchPathRule(targetAbs: string, rule: Readonly<PathRule>): boolean {
	const target = path.normalize(targetAbs);
	const value = path.normalize(rule.value);
	switch (rule.kind) {
		case "file":
			return target === value;
		case "directory":
			return target === value || target.startsWith(value + path.sep);
		case "prefix":
			return target === value || target.startsWith(value);
		case "glob":
			return globToRegExp(value).test(target);
	}
}

/** 覆盖检查（保守 containment）：条目（含通配符的模式串原样）是否被任一上限规则覆盖。
 *  具体路径=精确匹配语义；模式串=按字符串测试（请求 "**" 不会被 "src/**" 覆盖；"src/**" 会被 "**" 覆盖）。
 *  保守方向：宁可拒绝（任务明确报错）也不放大授予。 */
// ── shell 四方交集（ev-20260930-c703e3 拆出单源）：guarded 拒单文案与 optional 降级告警共用 ───────────

/** shell 四方交集缺口清单（角色∩用户∩后端三方检查——请求方是调用前提，不入本清单）。
 *  返回非空 = guarded 请求将整任务拒单、optional 请求将降级 deny。 */
export function shellGuardBlockers(
	roleShell: ShellPolicy,
	userMaxAssurance: PermissionAssurance,
	backend: Readonly<BackendCaps>,
): string[] {
	const blockers: string[] = [];
	if (roleShell !== "guarded") blockers.push(`角色上限 shell=${roleShell}`);
	if (userMaxAssurance !== "guarded") blockers.push(`用户授权上限 maxAssurance=${userMaxAssurance}`);
	if (!backend.shell) blockers.push(`后端 ${backend.backend} 不可兑现 shell 通道`);
	return blockers;
}

/** ev-20260930-c703e3：scope.shell=optional 降级告警行——请求 shell 但非任务必需（设计/审读类任务），
 *  四方交集为空时自动降级 deny（收紧方向，无安全放宽：guarded→tool-enforced）不拒单；返回告警文本
 *  或 undefined（未请求 optional，或交集全过已按 guarded 授予）。任务书含验证命令时的另一重提示
 *  见 task-facets 的 shellVerificationGapHint（两行独立成立：授权事实 vs 验证自检缺口）。 */
export function optionalShellDowngradeNotice(
	scopeShell: string | undefined,
	role: RoleCapsInput,
	userMaxAssurance: PermissionAssurance,
	backend: Readonly<BackendCaps>,
): string | undefined {
	if (scopeShell !== "optional") return undefined;
	if (!role.capabilities) return undefined; // 求值层对缺失/非法 capabilities fail-closed 拒单，此函数不会到达
	const blockers = shellGuardBlockers(role.capabilities.shell, userMaxAssurance, backend);
	if (blockers.length === 0) return undefined;
	return `[通道降级] scope.shell=optional 请求未获授权（${blockers.join("；")}）——已自动降级 shell=deny 派发，未拒单（ev-20260930-c703e3）；任务若需子进程产出（git diff/验证命令），请 Leader 先落盘材料为 inputs 或注明代跑`;
}

// ── 四方交集：computeEffectiveGrant ───────────────────────────────────────────

/** 角色能力输入（结构兼容 AgentConfig 的 capabilities/capabilitiesError 投影——本模块不 import agents-loader）。 */
export interface RoleCapsInput {
	tools?: readonly string[];
	name: string;
	capabilities?: RoleCapabilitySpec;
	/** agents-loader 发现期记录的 capabilities 非法原因（存在即 fail-closed 拒绝该角色任务）。 */
	capabilitiesError?: string;
}

export interface EffectiveGrantInput {
	role: RoleCapsInput;
	user: UserAuthorityCaps;
	/** 任务请求面（I1 冻结形状；缺省=READ_ONLY_BASELINE_SCOPE 只读基线）。 */
	scope?: SubmitScope;
	/** 声明输入（每条 path 不得落在 deny 禁入区——deny 读写双禁，必读输入与禁入区自相矛盾，提交即拒）。 */
	inputs?: ReadonlyArray<{ path: string }>;
	/** 声明产物（每条 path 须被 reportFiles 或 write 覆盖——K1 缺口补齐）。 */
	outputs: ReadonlyArray<{ path: string }>;
	backend: Readonly<BackendCaps>;
	/** 冻结工作目录（模式串绝对化基准，§5.2 路径统一以冻结 cwd 解析）。 */
	cwd: string;
}

const CHANNEL_LABEL: Record<"read" | "write" | "reportFiles", string> = {
	read: "read（读范围）",
	write: "write（写范围）",
	reportFiles: "reportFiles（报告可写）",
};

/** 目录感知归一（字符串条目版）：prefix:/通配符/尾斜杠原样；其余存在且是文件保持，否则补尾斜杠。 */
function dirAwareEntry(entry: string, cwd: string): string {
	const t = entry.trim();
	if (t.startsWith("prefix:") || t.includes("*") || t.endsWith("/")) return t;
	return dirAwareEntryAbs(absPattern(t, cwd));
}

/** 非空字符串数组断言（scope 请求面已在 I1 校验过形状；此处对直接调用方做同语义防崩）。 */
function requireNonEmptyStrings(list: ReadonlyArray<string>, field: string): Result<readonly string[]> {
	for (const s of list) {
		if (typeof s !== "string" || !s.trim()) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field} 含非法条目（须为非空字符串）：${JSON.stringify(s)}`, [field]);
		}
	}
	return ok(list.map((s) => s.trim()));
}

function validateUserAuthority(user: UserAuthorityCaps): Result<void> {
	if (!isRecord(user)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "user 授权面必须是对象", ["user"]);
	if (!PERMISSION_ASSURANCES.includes(user.maxAssurance)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `user.maxAssurance 必须是 ${PERMISSION_ASSURANCES.join("/")} 之一`, ["user.maxAssurance"]);
	}
	if (!Array.isArray(user.deny)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "user.deny 必须是字符串数组", ["user.deny"]);
	for (const f of ["read", "write", "reportFiles", "deny", "mcp"] as const) {
		if (user[f] !== undefined) {
			const r = requireNonEmptyStrings(user[f]!, `user.${f}`);
			if (!r.ok) return r;
		}
	}
	if (user.lsp !== undefined) {
		for (const c of user.lsp) {
			if (!LSP_CAPABILITIES.includes(c)) return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `user.lsp 非法能力名 ${JSON.stringify(c)}`, ["user.lsp"]);
		}
	}
	return ok(undefined);
}

/** MCP 授予条目策略摘要（冻结时刻可复算：策略版本 + 工具名）。 */
function mcpPolicyDigest(tool: string): string {
	return createHash("sha256").update(`amagi-mcp-policy/v1:${tool}`).digest("hex");
}

/** 由冻结授予推导受控工具名单（P4 子进程 --tools 消费；信息面，非执法）。 */
function deriveTools(grant: Omit<PermissionGrant, "tools">): readonly string[] {
	const tools = new Set<string>(["amagi_resource"]);
	if (grant.read.length > 0) tools.add("read"), tools.add("grep"), tools.add("find");
	if (grant.write.length > 0 || grant.reportFiles.length > 0) {
		tools.add("write");
		if (grant.write.length > 0) tools.add("edit");
	}
	if (grant.shell === "guarded") tools.add("bash");
	if (grant.mcp.length > 0) tools.add("mcp_call"), tools.add("mcp_list_tools");
	if (grant.lsp.length > 0) tools.add("lsp");
	// B5A：codemode 授予成立才进入顶层工具面（--tools 严格名单才会包含它；未授予时角色卡
	//  即便声明 codemode 也会被交集剥除）。
	if (grant.codemode !== undefined) tools.add("codemode");
	if (grant.advisor !== undefined) tools.add("amagi_advisor");
	return [...tools];
}

/** B5A：codemode 四方交集（设计 §3.1：computeEffectiveGrant 在四方交集成立后构造子对象，
 *  deriveTools 才加入 codemode）。返回错误=必需通道未兑现（显式 read-only 请求不能兑现时
 *  返回必需通道错误，未请求不产生新的拒单）；未请求 → undefined。本函数只做主体/配置/后端
 *  三方门禁，scriptTools ∩ 顶层工具面在组装段（base 已知后）完成。 */
function computeCodemodeGrant(
	input: EffectiveGrantInput,
	role: RoleCapabilitySpec,
	backend: Readonly<BackendCaps>,
): Result<CodemodeGrantBudget | undefined> {
	if (input.scope?.codemode !== "read-only") return ok(undefined);
	const blockers: Array<{ code: string; text: string }> = [];
	if (role.codemode !== "read-only") {
		blockers.push({ code: "ROLE_NOT_GRANTED", text: `角色上限 codemode=${role.codemode ?? "deny（缺省）"}（角色卡 capabilities.codemode 须为 read-only）` });
	}
	const userCodemode = input.user.codemode;
	if (userCodemode === undefined || !userCodemode.roles.has(input.role.name)) {
		blockers.push({ code: "NOT_ENABLED", text: `受信配置未为主体 "${input.role.name}" 开启 codemode（amagi.json codemode.mode/roles；未配置=零激活）` });
	}
	if (backend.codemode !== true) {
		blockers.push({ code: "BACKEND_UNVERIFIED", text: `后端 ${backend.backend} 未验证受控装配能力（公开 createCodemodeExtension 工厂探测未通过；RPC 本批恒拒）` });
	}
	if (blockers.length > 0) {
		return err(
			"required-channel-empty",
			`scope.codemode=read-only 请求被交集拒绝（${blockers.map((b) => `[${b.code}] ${b.text}`).join("；")}）——必需通道无授权，整任务拒绝`,
			["scope.codemode"],
			"none",
			[
				{ hint: "在受信配置 amagi.json 增加 codemode 节（mode=read-only + roles.<角色>=read-only）并在角色卡同时声明 capabilities.codemode=read-only 与 tools 含 codemode（双门缺一不可）" },
				{ hint: "后端未验证时检查宿主版本（首批准入=已验证装配的 1.1.0 组合）；或移除 scope.codemode 请求按普通任务派发" },
			],
		);
	}
	return ok(userCodemode!.budget);
}

/**
 * 四方交集 → 冻结 PermissionGrant（§5.1）。失败（超角色上限/空交集必需通道/输出未覆盖/deny 命中输出/
 * 能力声明非法）一律整任务拒绝：明确错误 + 修复提示，effects=none（计算纯函数，零副作用）。
 */
export function computeEffectiveGrant(input: EffectiveGrantInput): Result<PermissionGrant> {
	// ── 0) fail-closed 前置：角色能力声明缺失或非法 → 该任务关闭（不回退无限权限） ──
	if (input.role.capabilitiesError !== undefined) {
		return err(
			"role-capability-invalid",
			`角色 "${input.role.name}" capabilities 能力声明非法（fail-closed，不回退宽权限）：${input.role.capabilitiesError}`,
			["agent"],
			"none",
			[{ hint: "修正角色卡 capabilities 字段后重新提交（字段：assurance/shell/read/write/deny/report/mcp/lsp）" }],
		);
	}
	if (input.role.capabilities === undefined) {
		return err(
			"role-capability-missing",
			`角色 "${input.role.name}" 未声明 capabilities 能力上限（P1 fail-closed：一切通道上限为空，任何请求都无法授予）`,
			["agent"],
			"none",
			[{ hint: "在角色卡 frontmatter 增加 capabilities 结构化字段（assurance/shell/read/write/deny/report/mcp/lsp）" }],
		);
	}
	const role = input.role.capabilities;
	const uv = validateUserAuthority(input.user);
	if (!uv.ok) return uv;
	if (!Array.isArray(input.outputs)) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "outputs 必须是数组", ["outputs"]);
	}
	for (const o of input.outputs) {
		if (!isRecord(o) || !isNonEmptyString(o.path)) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "outputs[].path 必须是非空字符串", ["outputs"]);
		}
	}
	if (!isNonEmptyString(input.cwd)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "cwd 必须是非空字符串（冻结绝对化基准）", ["cwd"]);
	const backend = input.backend;
	if (backend.backend !== "json" && backend.backend !== "rpc") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "backend.backend 必须是 json/rpc 之一", ["backend.backend"]);
	}

	const scope: SubmitScope = input.scope ?? READ_ONLY_BASELINE_SCOPE;
	const cwd = input.cwd;
	const grantedPatterns: Record<"read" | "write" | "reportFiles", string[]> = { read: [], write: [], reportFiles: [] };

	// ── 1) read：声明性通道（ev-20260919 主上裁定）——读不设范围限制，恒冻结全仓读 ["**"]。
	// scope.read 仅作任务输入面声明留档（不参与交集、不做角色上限/用户收紧/空交集拒绝）——
	// 实测定量收窄（worktree/邻包路径被「read 目标不在读范围内」硬拦）对子 Agent 纯摩擦、对安全
	// 无增益（bash 读不受限、且真实防护点在 write/deny）；执行期仅 deny 禁入护读（P2 checkRead）。
	grantedPatterns.read = ["**"];

	// ── 1b) write/reportFiles：声明性通道（ev-20260919 主上裁定「门禁减重」）——请求面目录感知归一化后恒授予，
	// 不再做角色上限拒单/用户收紧丢弃/空交集拒单（对称 read；实战：目录无 /** 全拒、worktree/主树锚定越界、
	// output-not-covered 屡屡整单拒，子 Agent 被迫中断报告重派，自主性被重门禁压制；且 bash 写不受拦，
	// 执法不对称=纯摩擦）。授予面仍冻结进 grant（声明性，供回执/审计展示）；执行期硬保护仅 deny 禁入/
	// 契约存储重叠/跨根（P2 checkWrite）；deny 命中输出仍拒（§6 output-in-deny-region）。──
	for (const f of ["write", "reportFiles"] as const) {
		const requested = scope[f];
		if (requested === undefined || requested.length === 0) {
			// ev-20261016（write 缺省回退角色卡，主上裁定 2026-10-16）：「派发时没有每次任务重新授权的
			// 必要性，按照 agent 文件的 tools 完全是足够的」——scope.write 未声明时写面缺省取角色卡
			// capabilities.write（luban/luoshen=["**"] 锚定任务 cwd；fuxi/baize/diting=[] 回退后仍空，
			// artifact-only 围栏不变），同 read 面先例（ev-20260919 恒全仓读）。事故背景：派发只带
			// outputPaths+shell=guarded 未声明 scope.write → grantedPatterns.write 空 → deriveTools
			// 不授 edit，子 Agent 有 write 独缺 edit，被迫 python heredoc 改代码 47 次（2026-10-16
			// 会话任务 69100254）。条目与请求路径同归一（absPattern+dirAwareEntryAbs）；scope.write=[]
			// （显式空数组）=显式无该项声明（收紧），不回退；reportFiles 通道不回退（outputPaths
			// 报告机制照旧）；deny 恒优先语义不变（deny ∪ 后续执法照旧）。
			if (f === "write" && requested === undefined) {
				for (const entry of role.write) grantedPatterns.write.push(dirAwareEntryAbs(absPattern(entry, cwd)));
			}
			continue;
		}
		const rv = requireNonEmptyStrings(requested, `scope.${f}`);
		if (!rv.ok) return rv;
		for (const entry of rv.value) {
			// ev-20260919（目录请求语义修复）：无通配符条目目录感知归一——目录意图自动扩为子树。
			grantedPatterns[f].push(dirAwareEntryAbs(absPattern(entry, cwd)));
		}
	}

	// ── 2) deny：角色 ∪ 用户 ∪ 请求，恒并入（任何授予不得覆盖 deny——执法在 P2，冻结面先保证恒在）；
	//  同批目录感知归一：deny ["secrets"]（无通配符）从「仅禁该路径本身」恢复为禁入目录树常识语义） ──
	const denyPatterns = [...role.deny, ...input.user.deny, ...(scope.deny ?? [])];
	const denyRules = denyPatterns.map((p) => pathPatternToRule(dirAwareEntry(p, cwd), cwd));

	// ── 3) shell/assurance：guarded 需角色∩用户∩请求∩后端四方全过（fail-closed 必需语义不变）；
	//  optional=非必需请求（ev-20260930-c703e3）——交集为空自动降级 deny（收紧方向，无安全放宽）
	//  并在提交回执告警（optionalShellDowngradeNotice），不拒单：根除「Leader 惯性 guarded 请求 ×
	//  通道受限角色（v2.21.9 前 fuxi 设计/baize 探证同属此类——五内置角色现均可 guarded，受限仅适用于自定义 shell=deny 角色）」每会话固定一轮
	//  required-channel-empty 试错（实战 2026-09-30：fuxi 设计任务惯性带 shell=guarded 必遭拒单重提）。 ──
	const requestedShell: ShellChannelRequest = scope.shell ?? "deny";
	let shell: ShellPolicy = "deny";
	if (requestedShell === "guarded" || requestedShell === "optional") {
		const blockers = shellGuardBlockers(role.shell, input.user.maxAssurance, backend);
		if (blockers.length === 0) {
			shell = "guarded";
		} else if (requestedShell === "guarded") {
			return err(
				"required-channel-empty",
				`scope.shell=guarded 请求被交集拒绝（${blockers.join("；")}）——必需通道无授权，整任务拒绝。${roleChannelCapsSummary(input.role.name, role)}——请去掉 shell 请求、改用 optional（非必需自动降级）或改派具备该通道的角色`,
				["scope.shell"],
				"none",
				[{ hint: "shell 非任务必需时改用 scope.shell=\"optional\"：交集为空自动降级 deny 并在提交回执告警，不拒单（ev-20260930-c703e3）" },
				{ hint: "改派声明 guarded shell 的角色（如授权 Git 操作的 manager 类），或在受信配置中提升 maxAssurance" },
				// ev-20260918-e066cd（ev-20260930-c703e3 泛化）：对通道受限角色（自定义 shell=deny 角色——
				// 五内置角色 v2.21.9 起均可 guarded）——任务材料需要 shell 产出（git diff/跑命令）时，正确解法是 Leader 先行落盘
				// 材料为 inputs 再派（实战：7881 行 diff 手动落盘重派多耗一轮）；「提升 maxAssurance」对只读角色是错误方向。
				{ hint: "通道受限角色（自定义 shell=deny 角色；内置五角色均可 guarded）：先由 Leader 落盘所需材料（如 git diff > review-full.diff）再以 shell=deny（或 optional）+ inputs=[diff 路径] 提交——审读不需要子进程 shell" }],
			);
		}
		// optional + blockers 非空 → 降级 deny；告警行由 task-facets 三出口透出（本函数只求值）。
	}
	const assurance: PermissionAssurance = shell === "guarded" ? "guarded" : "tool-enforced";

	// ── 4) mcp/lsp：请求 ⊆ 角色名单；∩ 用户名单；后端不可兑现→空；显式请求空交集→拒绝 ──
	const mcpGranted: { server: string; tool: string; policyDigest: string }[] = [];
	if (scope.mcp !== undefined && scope.mcp.length > 0) {
		if (!backend.mcp) {
			return err(
				"required-channel-empty",
				`scope.mcp 显式请求但后端 ${backend.backend} 不可兑现 MCP 通道——必需通道无授权，整任务拒绝`,
				["scope.mcp"],
				"none",
				[{ hint: "换用可兑现 MCP 的后端，或移除该请求" }],
			);
		}
		const userMcp = input.user.mcp;
		for (const name of scope.mcp) {
			if (!isNonEmptyString(name)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `scope.mcp 含非法条目：${JSON.stringify(name)}`, ["scope.mcp"]);
			if (!(role.mcp.includes("*") || role.mcp.includes(name))) {
				return err(
					"request-exceeds-role-ceiling",
					`scope.mcp 请求 "${name}" 超出角色 "${input.role.name}" 能力上限（${role.mcp.join(", ") || "（空）"}），整任务拒绝`,
					["scope.mcp"],
					"none",
					[{ hint: "改派持有该 MCP 工具的角色，或从请求中移除" }],
				);
			}
			if (userMcp !== undefined && !(userMcp.includes("*") || userMcp.includes(name))) continue; // 用户收紧：丢弃
			mcpGranted.push({ server: "amagi-mcp", tool: name, policyDigest: mcpPolicyDigest(name) });
		}
		if (mcpGranted.length === 0) {
			return err(
				"required-channel-empty",
				`scope.mcp 显式请求 ${scope.mcp.length} 项但交集为空（用户 MCP 授权面未覆盖）——必需通道无授权，整任务拒绝`,
				["scope.mcp"],
				"none",
				[{ hint: "在受信配置 user.mcp 授权面加入所请求的工具名" }],
			);
		}
	}
	let lspGranted: readonly LspCapability[] = [];
	if (scope.lsp !== undefined && scope.lsp.length > 0) {
		if (!backend.lsp) {
			return err(
				"required-channel-empty",
				`scope.lsp 显式请求但后端 ${backend.backend} 不可兑现 LSP 通道——必需通道无授权，整任务拒绝`,
				["scope.lsp"],
				"none",
				[{ hint: "换用可兑现 LSP 的后端，或移除该请求" }],
			);
		}
		const userLsp = input.user.lsp;
		lspGranted = scope.lsp.filter(
			(c) => role.lsp.includes(c) && (userLsp === undefined || userLsp.includes(c)),
		);
		if (lspGranted.length === 0) {
			const roleMissing = scope.lsp.filter((c) => !role.lsp.includes(c));
			return err(
				roleMissing.length > 0 ? "request-exceeds-role-ceiling" : "required-channel-empty",
				roleMissing.length > 0
					? `scope.lsp 请求 [${roleMissing.join(",")}] 超出角色 "${input.role.name}" LSP 能力上限（${role.lsp.join(",") || "（空）"}），整任务拒绝`
					: `scope.lsp 显式请求但交集为空（用户 LSP 授权面未覆盖）——必需通道无授权，整任务拒绝`,
				["scope.lsp"],
				"none",
				[{ hint: "改派持有该 LSP 能力的角色，或从请求中移除/在受信配置授权" }],
			);
		}
	}

	// ── 5) 组装冻结授予（tools 由通道推导；自校验通过才返回——构造 bug 同样 fail-closed） ──
	const codemodeGrantResult = backend.codemodeComposition ? ok(undefined) : computeCodemodeGrant(input, role, backend);
	if (!codemodeGrantResult.ok) return codemodeGrantResult;
	const base: Omit<PermissionGrant, "tools"> = {
		policyVersion: 1,
		assurance,
		read: grantedPatterns.read.map((p) => pathPatternToRule(p, cwd)),
		write: grantedPatterns.write.map((p) => pathPatternToRule(p, cwd)),
		deny: denyRules,
		reportFiles: grantedPatterns.reportFiles,
		shell,
		mcp: mcpGranted,
		lsp: lspGranted,
	};
	// B5A：四方门禁已过（codemodeGrantResult.value=冻结预算）→ scriptTools = 封闭只读集 ∩ 顶层
	//  推导工具面（read 恒授予放交集至少含 read；空交集=构造缺陷 fail-closed）→ 构造子对象，
	//  deriveTools 才加入 codemode，policyVersion 升 2（未携带时保持 1，旧 grant 字节级/digest 不变）。
	let codemodeGrant: ReadOnlyCodemodeGrant | undefined;
	if (codemodeGrantResult.value !== undefined) {
		const topTools = new Set(deriveTools(base));
		if (!topTools.has("read")) {
			return err(
				"required-channel-empty",
				"scope.codemode=read-only 请求被交集拒绝：顶层工具面不含 read（构造缺陷 fail-closed）——脚本工具集为空，整任务拒绝",
				["scope.codemode"],
			"none",
			[{ hint: "内部一致性缺陷（read 恒授予）——请报告框架维护者（不应发生）" }],
			);
		}
		// F01 冻结：受控 scriptTools 仅 read（宿主 grep/find 搜索根粒度校验无法证明 deny 子树排除；
		// deny 感知受控搜索属后续批）；脚本外普通工具面现状不动。
		const scriptTools: ReadOnlyCodemodeGrant["tools"] = ["read"];
		codemodeGrant = { mode: "read-only", tools: scriptTools, models: false, budget: codemodeGrantResult.value };
		base.policyVersion = 2;
		base.codemode = codemodeGrant;
	}
	if (input.scope?.advisor === "consult") {
		if (role.advisor !== "consult" || !input.role.tools?.includes("amagi_advisor") || !input.user.advisor?.roles.has(input.role.name) || backend.advisor !== true) {
			return err("required-channel-empty", "scope.advisor=consult 未通过角色、受信配置或后端授权交集", ["scope.advisor"]);
		}
		if (input.user.advisor.grant.backend === "codex-chat" && (assurance === "tool-enforced" || denyRules.length > 0)) return err("required-channel-empty", "Codex 咨询仅支持无 deny 的 guarded 授权；有禁入要求请使用 pi 无工具咨询", ["scope.advisor"]);
		base.advisor = { ...input.user.advisor.grant };
		base.policyVersion = 3;
	}
	const grant: PermissionGrant = { ...base, tools: [...new Set([...deriveTools(base), ...(backend.codemodeComposition ? ["codemode"] : [])])] };
	const selfCheck = validatePermissionGrant(grant);
	if (!selfCheck.ok) {
		return err(
			"permission-grant-invalid",
			`授权交集计算产物未通过契约自校验（fail-closed）：${selfCheck.error.message}`,
			selfCheck.error.fields,
			"none",
			[{ hint: "内部一致性缺陷——请报告框架维护者（不应发生）" }],
		);
	}

	// ── 6) 输入 × deny 冲突校验（ev-2026 deny 误伤根除：deny 读写双禁——必读输入落禁入区
	//  是任务自相矛盾，提交点整单拒绝，替代子 Agent 运行中 read 硬拒的高频阻断形态）。──
	for (const i of input.inputs ?? []) {
		const inAbs = path.isAbsolute(i.path) ? path.normalize(i.path) : path.resolve(cwd, i.path);
		if (denyRules.some((r) => matchPathRule(inAbs, r))) {
			return err(
				"input-in-deny-region",
				`输入 "${i.path}" 落在 deny 禁入区（deny 读写双禁：read 同样被硬拒）——必读输入与禁入区自相矛盾，整任务拒绝`,
				["inputs"],
				"none",
				[
					{ hint: "deny 是读写双禁的安全红线（密钥/凭据类），不是写保护——保护路径不被写入无需 deny：未授予 write/reportFiles 即零写入" },
					{ hint: `若该输入确需读取：从 scope.deny 移除条目后重派（当前 deny=[${denyRules.map((r) => `${r.kind}:${r.value}`).join("、")}]）` },
					{ hint: "若该输入不应触达：从 inputs 移除该条目，并同步改写任务书正文中的对应路径引用" },
				],
			);
		}
	}

	// ── 7) 输出与 deny 冲突校验（ev-20260919 门禁减重：K1 覆盖拒单随 write 声明性化退役——
	//  outputs 路径无须再被 reportFiles/write 覆盖才能提交；仅 deny 冲突保留硬拒（deny 恒优先）。──
	for (const o of input.outputs) {
		const outAbs = path.isAbsolute(o.path) ? path.normalize(o.path) : path.resolve(cwd, o.path);
		if (denyRules.some((r) => matchPathRule(outAbs, r))) {
			return err(
				"output-in-deny-region",
				`输出 "${o.path}" 落在 deny 禁入区（deny 恒生效：任何授予不得覆盖 deny）——整任务拒绝`,
				["outputs"],
				"none",
				[{ hint: "将输出移出禁入路径，或从 scope.deny/角色 deny/受信配置 deny 中移除该路径" }],
			);
		}
	}

	return ok(grant);
}

// ── 任务书正文 × deny 禁入区冲突扫描（ev-2026 deny 误伤根除，第二道拦截）──────────

/** 正文路径 token 提取：以 / 开头的多段绝对路径（排除空白与中英文成对标点/句读）；
 *  含空格路径会在空格处截断——截断前缀对 directory 前缀型 deny 仍可命中，不降低拦截率。 */
const ASSIGNMENT_PATH_TOKEN_RE = /(?:\/[^(\s<>"'`\[\]{}，。；：！？、）】「」…]+){2,}/g;

/** 任务书正文引用的绝对路径 × deny 禁入区冲突扫描（词法判定，不触盘）：
 *  必读文件常写在任务书正文而非 inputs——本文扫描把「deny 误伤必读输入」从子 Agent 运行中
 *  read 硬拒前移到提交点（fail-closed 整单拒绝，一次修复重派，不再运行中报废）。 */
export function findAssignmentDenyConflicts(
	assignment: string,
	denyRules: ReadonlyArray<PathRule>,
	cwd: string,
): string[] {
	if (denyRules.length === 0 || !assignment) return [];
	const hits = new Set<string>();
	for (const m of assignment.matchAll(ASSIGNMENT_PATH_TOKEN_RE)) {
		const raw = m[0].replace(/[,.;:!?\)\]}>,，。；：）】」]+$/, "");
		if (raw.length < 2) continue;
		const abs = path.isAbsolute(raw) ? path.normalize(raw) : path.resolve(cwd, raw);
		if (denyRules.some((r) => matchPathRule(abs, r))) hits.add(raw);
	}
	return [...hits];
}
