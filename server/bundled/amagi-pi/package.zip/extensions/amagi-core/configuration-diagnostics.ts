/** 用户侧配置诊断：读取选模单源、公开宿主能力和声明授权；不恢复任务、不连接服务、不探测网络。 */
import * as fs from "node:fs";
import * as path from "node:path";
import { Value } from "typebox/value";
import type { AgentConfig } from "./agents-loader.ts";
import { findAgentByRequest } from "./agent-aliases.ts";
import { explainModelSelection, getGlobalConfigPath, getAmagiConfigurationSchema, normalizeModelSpec, SUPPORTED_THINKING_LEVELS, type PreflightModelRegistry, type RegistryModelEntry } from "./model-resolver.ts";
// ev-20261020（c8ca99/d56baa）：verification.testCommand / shell.pathPrepend 语义校验（doctor）
import { readProjectVerificationPolicy } from "./evidence-options.ts";
import { readProjectShellPathPrepend, tokenResolvableInPath } from "./shell-env.ts";
import { detectHostPackageVersion, nativeMcpRegistrationAvailable } from "./host-capabilities.ts";
import { redactCredentials } from "./task-query-wire.ts";
import { compactionConfigCwd, resolveCompactionConfig } from "./compaction-config.ts";
// CodeMode 调用偏好与可覆盖默认值（explain/doctor 只读）。
import { resolveCodemodeRuntimeConfig } from "./codemode-runtime.ts";
// B4A（ev-20261012-af58eb 批A）：护栏策略投影（解释层）——规则与来源、env 归一、项目/角色覆盖投影。
import { resolveGuardPolicy, summarizeGuardPolicy } from "./guard-policy.ts";
import { getSupportedThinkingLevels, type Model, type Api } from "@earendil-works/pi-ai";
import { editingCapabilityStatus } from "./edit-snapshot.ts";

// Capture the extension package version when this module loads, not a later installation's version.
const loadedAmagiVersion = (() => {
	try { return String(JSON.parse(fs.readFileSync(path.resolve(import.meta.dirname, "..", "..", "package.json"), "utf8")).version ?? "unknown"); }
	catch { /* lint-exempt:诊断来源不可读时明确显示 unknown */ return "unknown"; }
})();

export interface ConfigurationContext {
	cwd: string;
	model?: { provider: string; id: string };
	modelRegistry?: PreflightModelRegistry;
	/** B5A 修复轮 F04：统一 trust 结果（可选——缺席按 untrusted 保守处理，项目层不消费）。 */
	isProjectTrusted?: () => boolean;
}
export interface ConfigurationReport { ok: boolean; text: string }

function compactionStatus(ctx: ConfigurationContext, verify: boolean): ConfigurationReport {
	try {
		const config = resolveCompactionConfig(compactionConfigCwd(ctx.cwd));
		if (!config.model) return { ok: true, text: `压缩：pi 原生当前会话模型${config.source ? ` ← ${config.source}（compaction.model=null）` : "（compaction.model 未设置）"}` };
		let state = "Leader/子 Agent 共用；每次压缩读取";
		let ok = true;
		if (verify && ctx.modelRegistry) {
			const model = ctx.modelRegistry.find(config.provider!, config.id!);
			if (!model) { ok = false; state = "模型未注册"; }
			else if (config.thinkingLevel && !getSupportedThinkingLevels(model as Model<Api>).includes(config.thinkingLevel)) { ok = false; state = "thinking 档位不受支持"; }
			else if (ctx.modelRegistry.hasConfiguredAuth?.(model) === false) { ok = false; state = "未配置凭据"; }
			else state = "目录/认证配置可用（未发请求）";
		}
		return { ok, text: `压缩：${config.model} ← ${config.source} · ${state}` };
	} catch (error) { return { ok: false, text: `压缩配置检查失败：${error instanceof Error ? error.message : "未知错误"}` }; }
}

// ── pi-1.3-adapt P2（fuxi P0 切片）：模型诊断投影——doctor 与 config explain 共用 ─────────
// 只读：不发请求、不刷新凭据、不触 runtime.refresh/getAuth；复用派发同源 normalizeModelSpec，
// 预读快照与绑定方法色装后调用，避免 safeModelList 吞异常把「读取失败」显示成「模型未知」。
// 弱宿主缺能力（无 registry/缺 getAvailable/getAll/hasConfiguredAuth）→ 未验证不硬失败；
// 归一器拒绝与检查抛错 → doctor 明确失败；快照 ≠ 真实 HTTP 成功（未发请求口径性恒在）。

/** 模型诊断判定（两表面共用；不进持久契约）。 */
interface ModelDiagnostic {
	/** 归一后全限定 spec（仅归一成功时；thinking 后缀保留）。 */
	normalizedSpec?: string;
	state: "configured" | "auth-unverified" | "rejected" | "unverified" | "check-failed";
	/** 展示段（两表面逐字共用；最终经 redactCredentials）。 */
	segment: string;
}

const DIAG_NO_REGISTRY = "未验证（无宿主模型目录）；不推断模型未注册";
const DIAG_CHECK_FAILED = "宿主模型目录/认证检查失败（未发请求，未改变模型）";

/** 快照预读：缺方法=missing；抛错/非数组=error；成功=归一后条目（保留 raw 供 hasConfiguredAuth）。 */
type ListSnapshot = { kind: "ok"; entries: Array<{ provider: string; id: string; raw: RegistryModelEntry }> } | { kind: "missing" } | { kind: "error" };

function snapshotRegistryList(method: (() => Array<RegistryModelEntry>) | undefined): ListSnapshot {
	if (typeof method !== "function") return { kind: "missing" };
	try {
		const raw = method() ?? [];
		if (!Array.isArray(raw)) return { kind: "error" };
		const entries: Array<{ provider: string; id: string; raw: RegistryModelEntry }> = [];
		for (const entry of raw) {
			const provider = typeof entry?.provider === "string" ? entry.provider.trim() : "";
			const id = typeof entry?.id === "string" && entry.id.trim() ? entry.id.trim() : (typeof entry?.modelId === "string" ? entry.modelId.trim() : "");
			if (provider && id) entries.push({ provider, id, raw: entry });
		}
		return { kind: "ok", entries };
	} catch { /* lint-exempt:目录快照不可读是诊断事实非错误——分类为 error 供下游判 check-failed，不静默降格成空目录 */ return { kind: "error" }; }
}

/** 归一成功后的认证判定（步罫4：只有明确 true 才称可用；缺方法/结果未知=auth-unverified；false=rejected）。 */
function authDiagnostic(normalized: string, model: unknown, registry: PreflightModelRegistry): ModelDiagnostic {
	if (typeof registry.hasConfiguredAuth !== "function")
		return { normalizedSpec: normalized, state: "auth-unverified", segment: `派发归一 ${normalized}；已注册，认证未验证（宿主缺 hasConfiguredAuth）` };
	let value: boolean | undefined;
	try { value = registry.hasConfiguredAuth(model); } catch { /* lint-exempt:认证探测抛错固定映射 check-failed（不发请求不改模型），不外泄异常原文 */ return { state: "check-failed", segment: DIAG_CHECK_FAILED }; }
	if (value === true) return { normalizedSpec: normalized, state: "configured", segment: `派发归一 ${normalized}；目录/认证配置可用（未发请求）` };
	if (value === false) return { normalizedSpec: normalized, state: "rejected", segment: `未配置凭据（${normalized}）——请针对该 provider 先 /login 或配置 API Key` };
	return { normalizedSpec: normalized, state: "auth-unverified", segment: `派发归一 ${normalized}；已注册，认证未验证（宿主认证结果未知）` };
}

/** 单 agent 诊断：explainModelSelection 选模来源（步罫1）→ 归一/认证投影。无 spec 时 diagnostic 缺席（沿既有未解析语义）。 */
function diagnoseModelSelection(agent: AgentConfig, ctx: ConfigurationContext): { trace: ReturnType<typeof explainModelSelection>; diagnostic?: ModelDiagnostic } {
	const trace = explainModelSelection(agent, { cwd: ctx.cwd, fallbackModel: ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : undefined });
	const spec = trace.selected.spec;
	if (!spec) return { trace };
	const registry = ctx.modelRegistry;
	if (!registry) return { trace, diagnostic: { state: "unverified", segment: DIAG_NO_REGISTRY } };
	// spec 拆分（诊断只读镜像 parseSpec 语义：仅剥离合法 thinking 档；qwen3-coder:exacto 等原生冒号 ID 保留）
	const slash = spec.indexOf("/");
	const providerPart = slash > 0 ? spec.slice(0, slash) : "";
	const rest = slash > 0 ? spec.slice(slash + 1) : spec;
	const colon = rest.lastIndexOf(":");
	const stripSuffix = colon > 0 && (SUPPORTED_THINKING_LEVELS as readonly string[]).includes(rest.slice(colon + 1));
	const idPart = stripSuffix ? rest.slice(0, colon) : rest;
	const suffix = stripSuffix ? rest.slice(colon) : "";
	if (providerPart) {
		// 全限定：仅需 find（预读防归一器内部 try/catch 把抛错吞成未注册）
		let found: unknown;
		try { found = registry.find(providerPart, idPart); }
		catch { /* lint-exempt:find 抛错固定映射 check-failed（预读防归一器吞错），不外泄异常原文 */ return { trace, diagnostic: { state: "check-failed", segment: DIAG_CHECK_FAILED } }; }
		const available = snapshotRegistryList(registry.getAvailable?.bind(registry));
		const all = snapshotRegistryList(registry.getAll?.bind(registry));
		const wrapper = {
			find: () => found,
			...(available.kind === "ok" ? { getAvailable: () => available.entries.map((e) => ({ provider: e.provider, id: e.id })) } : {}),
			...(all.kind === "ok" ? { getAll: () => all.entries.map((e) => ({ provider: e.provider, id: e.id })) } : {}),
		};
		const nm = normalizeModelSpec(spec, wrapper);
		if (!nm.ok) return { trace, diagnostic: { state: "rejected", segment: nm.error } };
		return { trace, diagnostic: authDiagnostic(spec, found, registry) };
	}
	// 裸名：归一需要真实 getAvailable 快照（缺席=未验证不推断；抛错=check-failed）
	const available = snapshotRegistryList(registry.getAvailable?.bind(registry));
	if (available.kind === "missing") return { trace, diagnostic: { state: "unverified", segment: "未验证（宿主缺 getAvailable 快照）；不推断模型未注册" } };
	if (available.kind === "error") return { trace, diagnostic: { state: "check-failed", segment: DIAG_CHECK_FAILED } };
	// getAll 仅在零可用候选时才被咨询（区分未知/无凭据）；缺席不阻断归一，抛错只在被需要时判 check-failed
	const all = snapshotRegistryList(registry.getAll?.bind(registry));
	const wrapper = {
		find: (p: string, m: string) => available.entries.find((e) => e.provider === p && e.id === m)?.raw,
		getAvailable: () => available.entries.map((e) => ({ provider: e.provider, id: e.id })),
		...(all.kind === "ok" ? { getAll: () => all.entries.map((e) => ({ provider: e.provider, id: e.id })) } : {}),
	};
	const nm = normalizeModelSpec(spec, wrapper);
	if (!nm.ok) {
		// 零可用候选：只有 getAll 成功取得才允许区分未知/无凭据——缺席=未验证；不可读=check-failed；
		// getAll 可读且无此 id 才是真正的「模型未知」拒绝（不降格、不伪装）
		if (nm.error.startsWith("[模型未知]") && all.kind !== "ok")
			return { trace, diagnostic: all.kind === "error"
				? { state: "check-failed", segment: DIAG_CHECK_FAILED }
				: { state: "unverified", segment: "未验证（宿主缺 getAll，无法区分未知/无凭据）；不推断模型未注册" } };
		return { trace, diagnostic: { state: "rejected", segment: nm.error } };
	}
	// 归一成功：从快照取同 id 匹配项做认证检查（构造性存在；防御不一致时诚实标未验证）
	const match = available.entries.find((e) => e.id === idPart && nm.spec === `${e.provider}/${idPart}${suffix}`);
	if (!match) return { trace, diagnostic: { state: "unverified", segment: "未验证（目录快照与归一结果不一致）；不推断模型未注册" } };
	return { trace, diagnostic: authDiagnostic(nm.spec ?? spec, match.raw, registry) };
}

function configStatus(file: string): string {
	try {
		const value: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
		if (!value || typeof value !== "object" || Array.isArray(value)) return "格式错误（应为对象）";
		// 与配置文档共用仓库 schema；只报字段路径，不回显配置值或凭据。
		try {
			const schema = getAmagiConfigurationSchema();
			return Value.Check(schema, value) ? "可读" : `字段校验失败（${[...Value.Errors(schema, value)].slice(0, 8).map((error) => error.instancePath || "/").join(", ")}）`;
		} catch { return "配置 schema 不可读（未完成字段校验）"; }
	} catch (error) {
		return (error as NodeJS.ErrnoException).code === "ENOENT" ? "未创建" : "不可读或 JSON 无效";
	}
}

/** ev-20261020（c8ca99/d56baa）：项目 verification / shell 段语义诊断（schema 形状之外的运行时校验）。
 *  返回逐条问题行（空数组=无问题/未声明）；只读，不回显凭据。 */
function projectVerificationIssues(cwd: string): string[] {
	const issues: string[] = [];
	const policy = readProjectVerificationPolicy(cwd);
	if (policy.problem) issues.push(`${policy.problem}（自动检查记 unavailable，不退回探测链——ev-20261021-54b4e3）`);
	const declared = policy.testCommand;
	if (declared) {
		// reader 已拒绝对路径/..；这里验声明目录真实存在与首 token 可解析性
		// ev-20261111-fix（diting F03）：预检与实际 spawn 同源——pathPrepend 从受信配置根读，
		// 显式相对 token 按声明的实际 execDir 解析（不再按 harness 进程 cwd 误判）。
		const execDir = declared.cwdRel === "." ? cwd : path.resolve(cwd, declared.cwdRel);
		if (!fs.existsSync(execDir)) issues.push(`verification.testCommand.cwd=${declared.cwdRel} 目录不存在（自动检查执行将失败——修正 cwd）`);
		else if (!tokenResolvableInPath(declared.argv[0], { configRoot: cwd, execDir })) issues.push(`verification.testCommand.argv[0]=${declared.argv[0]} 在 shell.pathPrepend ∪ 系统 PATH（或声明 cwd）不可解析（检查将记 unavailable——修正 argv 或声明 shell.pathPrepend）`);
	}
	for (const p of readProjectShellPathPrepend(cwd).problems) issues.push(p);
	return issues;
}

export function explainConfiguration(agents: AgentConfig[], ctx: ConfigurationContext, requested?: string): ConfigurationReport {
	const selected = requested ? findAgentByRequest(agents, requested) : undefined;
	if (requested && !selected) return { ok: false, text: `未知角色 ${requested}；可用 ${agents.map((a) => a.name).join(", ")}` };
	const project = path.join(ctx.cwd, "amagi.json");
	const projectStatus = configStatus(project), globalStatus = configStatus(getGlobalConfigPath());
	const lines = ["amagi 有效配置（只读；不创建文件、不连接服务）",
		`项目：${project} · ${projectStatus}`, `全局：${getGlobalConfigPath()} · ${globalStatus}`];
	const compaction = compactionStatus(ctx, false);
	lines.push(compaction.text);
	// ev-20261020（c8ca99/d56baa）：验证链声明投影——声明优先于探测；pathPrepend 生效目录数。
	{
		const vpolicy = readProjectVerificationPolicy(ctx.cwd);
		const declaredTest = vpolicy.testCommand;
		const prepend = readProjectShellPathPrepend(ctx.cwd);
		const envNote = declaredTest?.env ? `；资源环境 ${Object.keys(declaredTest.env).join(",")}` : "";
		lines.push(`验证链：${vpolicy.problem ? `声明非法（${vpolicy.problem}）——自动检查 unavailable，不退回探测` : declaredTest ? `声明 ${declaredTest.argv.join(" ")}${declaredTest.cwdRel !== "." ? `（cwd=${declaredTest.cwdRel}）` : ""}${envNote} ← amagi.json verification.testCommand（优先于探测）` : vpolicy.autoBaseline === "declared-only" ? "declared-only 且无声明——自动检查 unavailable（不探测）" : "无项目声明（自动基线走探测链：package.json/Makefile/Cargo/go.mod/CMakeLists.txt）"}${prepend.dirs.length > 0 ? `；PATH 前置 ${prepend.dirs.length} 目录 ← shell.pathPrepend` : ""}${prepend.problems.length > 0 ? `；pathPrepend ${prepend.problems.length} 条非法（/amagi doctor 查看）` : ""}`);
	}
	// CodeMode 不另设角色授权；只投影调用偏好和默认值。
	// 修复轮 F04：explain 同面消费统一 trust 结果（缺席=untrusted 保守：项目层不消费）。
	const codemode = resolveCodemodeRuntimeConfig(ctx.cwd, ctx.isProjectTrusted?.() === true);
	lines.push(`codemode：模型自行决定，无独立角色/scope 授权 · preference=${codemode.preference} · 默认 ${codemode.maxOutputTokensPerScript}tokens/${codemode.maxTimeoutMsPerScript}ms（脚本可覆盖）`);
	// B4A：护栏规则投影（解释层；判定与现状一致）。指定角色时附该角色的覆盖视角（旧 stem 名归一）。
	const guardTrust = { projectTrusted: ctx.isProjectTrusted?.() };
	const guardBase = resolveGuardPolicy({ cwd: ctx.cwd, env: process.env, ...guardTrust });
	const roleViews = selected ? [resolveGuardPolicy({ cwd: ctx.cwd, env: process.env, role: selected.name, ...guardTrust })] : [];
	lines.push(summarizeGuardPolicy(guardBase, roleViews));
	for (const agent of selected ? [selected] : agents) {
		// P2（fuxi P0 切片）：选模来源链保持原样（不以归一结果冒充用户原配置），附派发归一/拒绝同一投影；
		// 目录缺失不使解释不可用（ok 语义不变）。
		const { trace, diagnostic } = diagnoseModelSelection(agent, ctx);
		lines.push(`${agent.name}：${trace.selected.spec ?? "未解析"} ← ${trace.selected.label}（profile=${trace.profile}）${diagnostic ? `；${diagnostic.segment}` : ""}`);
		if (selected) for (const candidate of trace.candidates) lines.push(`  ${candidate.label}：${candidate.spec ?? "未设置"}${candidate === trace.candidates.find((c) => !!c.spec) ? "（命中）" : candidate.spec ? "（被更高优先级覆盖）" : ""}`);
	}
	lines.push("未设置 shell/MCP/LSP 不自动扩权；旧会话恢复和 receipt+revision 验收仍沿用原契约。", "起步预设：/amagi config init inherit；已有配置不会覆盖。详情 /amagi guide config。");
	return { ok: compaction.ok && [projectStatus, globalStatus].every((status) => status === "未创建" || status === "可读"), text: redactCredentials(lines.join("\n")) };
}

export function configurationDoctor(agents: AgentConfig[], host: unknown, ctx: ConfigurationContext): ConfigurationReport {
	const issues: string[] = [];
	const compaction = compactionStatus(ctx, true);
	if (!compaction.ok) issues.push(compaction.text);
	for (const file of [path.join(ctx.cwd, "amagi.json"), getGlobalConfigPath()]) {
		const status = configStatus(file);
		if (status !== "未创建" && status !== "可读") issues.push(`${file}：${status}`);
	}
	// ev-20261020（c8ca99/d56baa）：项目 verification.testCommand / shell.pathPrepend 语义诊断
	// （声明 cwd 存在性 / 首 token 可解析性 / pathPrepend 绝对与存在性；只计入 issues 不阻断）。
	for (const issue of projectVerificationIssues(ctx.cwd)) issues.push(issue);
	const rows = agents.map((agent) => {
		// P2（fuxi P0 切片）：与 config explain 同一诊断投影——rejected/check-failed 计失败；
		// 缺能力（无 registry/缺 getAvailable/getAll/hasConfiguredAuth）只提示未验证，弱宿主不硬失败。
		const { trace, diagnostic } = diagnoseModelSelection(agent, ctx);
		if (!trace.selected.spec) { issues.push(`${agent.name}：未解析模型`); return `${agent.name}：未解析 · 未解析模型`; }
		const d = diagnostic ?? { state: "unverified" as const, segment: DIAG_NO_REGISTRY };
		if (d.state === "rejected" || d.state === "check-failed") issues.push(`${agent.name}：${d.segment}`);
		if (!agent.capabilities || agent.capabilitiesError !== undefined) issues.push(`${agent.name}：角色授权声明缺失或非法（派发仍拒绝扩权）`);
		return `${agent.name}：${trace.selected.spec} · ${d.segment}`;
	});
	return { ok: issues.length === 0, text: redactCredentials([
		`amagi doctor · pi ${detectHostPackageVersion() ?? "unknown"} · Node ${process.versions.node} · amagi ${loadedAmagiVersion}`,
		editingCapabilityStatus(host),
		`MCP：${nativeMcpRegistrationAvailable(host) ? "原生公开接口可用；连接/登录状态查看 /mcp" : "原生接口不完整；兼容后端仍须权限和配置校验"}`,
		compaction.text,
		...rows, issues.length ? `发现 ${issues.length} 项需处理：\n${issues.join("\n")}` : "未发现配置阻塞项；真实模型、OAuth 往返与终端交互未在 doctor 中测试。",
		"SDK 执行仅隔离验证，生产继续使用 JSON/RPC 子进程；执行/结算/接受三轴不变。", "选模来源 /amagi config explain [角色]；恢复断点 /amagi recovery；帮助 /amagi guide。",
	].join("\n")) };
}

/** 用户显式创建项目起步预设。wx 保证已有文件/符号链接不覆盖；不修改全局 pi 或权限配置。 */
export function initializeProjectConfiguration(cwd: string, preset: string): ConfigurationReport {
	if (preset !== "inherit" && preset !== "tiered") return { ok: false, text: "预设必须为 inherit 或 tiered：/amagi config init inherit" };
	const file = path.join(cwd, "amagi.json");
	try {
		fs.writeFileSync(file, JSON.stringify({ profile: preset, agents: {} }, null, 2) + "\n", { flag: "wx", mode: 0o600 });
		return { ok: true, text: `已创建项目配置 ${file}（profile=${preset}）；现有全局配置、角色授权和任务恢复数据保留。用 /amagi config explain 检查生效来源。` };
	} catch (error) {
		return { ok: false, text: (error as NodeJS.ErrnoException).code === "EEXIST" ? `项目配置已存在：${file}；未覆盖。用 /amagi config explain 查看。` : `项目配置创建失败：${file}；检查目录是否存在且可写。` };
	}
}
