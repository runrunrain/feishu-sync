/**
 * mcp-host-bridge.ts — B6a（十月迭代 M3，设计 §5.3 + §7）：MCP 混合路线基座。
 *
 * 设计 §7.1 裁定：自研单通道保持默认；推荐逐 server 显式混合试点。本模块承载混合模式的
 * **基座**（清单预检 / owner 协议 / 准入数据流 / 拒绝语义 / 回滚事务编排），不含真实启用——
 * B6b（真实 server 混合启用）需真机验证启动连接隔离与 /mcp 命令所有权后才允许激活（§7.2-2）。
 *
 * 三层状态：
 *   inactive  —— 无显式混合声明（amagi.json `mcp.hybrid.host` 缺省/空）或 AMAGI_MCP_HYBRID=0：
 *                默认关闭，自研单通道行为逐字节不变（golden 测试钉住）。
 *   rejected  —— 有声明但准入失败：拒绝理由结构化返回（调用方落日志），自研单通道行为不变；
 *                准入失败保留 `-builtin:mcp` 和自研配置，显式报 mixed unavailable（设计 §5.3）。
 *   mixed     —— 全部准入门通过：owner 计划按会话冻结（加载期成形），双通道按 owner 分流。
 *
 * owner 协议（设计 §5.3 内部提议结构落地）：
 *   McpOwnershipPlan { mode, servers: [{ name, canonicalName, owner, source, allowedRoleScope }] }
 *   只含标识与配置来源摘要，不存 token/header（endpoint/命令仅本地判定用，报告只写脱敏摘要）。
 *   owner 是路由决定：allowedRoleScope 仍与实际 grant 求交，不能单独授予权限（grant 执法在
 *   mcp-config.checkMcpCallPermission 与 guards 原生工具复用检查，本模块不复制执法逻辑）。
 *
 * 与既有模块的关系（不替换 mcp-client）：
 *   - mcp-config.ts：owner 解析不改动其加载链——本模块独立读宿主 native 配置面
 *     （~/.pi/agent/mcp.json + 项目 .pi/mcp.json；注意自研链还含 settings/.agents/.mcp.json 等
 *     宿主不读的来源，两通道来源集合不同，恰好是「同 server 双通道」风险的根源）。
 *   - mcp-client.ts：混合激活时 owner=host 的 server 不进自研连接列表；mcp_call 收到 host owner
 *     返回「请使用原生工具」指引（hostOwnerGuidanceText 单一来源），不双通道转发。
 *   - guards.ts：原生 mcp__* 工具与资源工具复用 grant 检查（本模块提供解析件，执法组合在 guards）。
 *   - host-capabilities.ts：只读消费（mcpProjectOverrides@1.0.1 / mcpAuthProvider@0.99.2 能力门）。
 *
 * 纪律：本模块零真实 ~/.pi 写入、零 mcp.json 写入、零 token 读取；预检只读配置与标识。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import * as piHost from "@earendil-works/pi-coding-agent";
import { loadMcpServerConfigs, type McpServerConfig } from "./mcp-config.ts";
import { tuiWarn } from "./tui-console.ts";
import { resolveHostCapabilities, type HostCapabilities } from "./host-capabilities.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 名称协议：canonicalName 归一（宿主 -/_ 等价规则）+ 原生工具名解析
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 宿主 canonicalName 归一：docs/mcp.md §Configuration rules「Server names that differ only in
 * `-` and `_` count as the same server」。实现：每个 `-`/`_` 替换为 `_` 后比较——`a-b`≡`a_b`、
 * `a--b`≢`a_b`（连续分隔不折叠，忠实宿主语义）。同名与归一名都只允许一个 owner（§7.2）。
 */
export function canonicalMcpServerName(name: string): string {
	return name.replace(/[-_]/g, "_");
}

/** 宿主 server 名合法字符（letters/digits/_/-）；非法名条目宿主会跳过不连接。 */
export function isValidNativeServerName(name: string): boolean {
	return /^[A-Za-z0-9_-]+$/.test(name);
}

export interface NativeMcpToolNameParts {
	/** server 名（按分隔规则恢复；宿主注册时 `-` 已被折叠为 `_`——与 canonical 语义一致）。 */
	server: string;
	tool: string;
	/** 名字含多个 `__` 分隔段（server 名本身可含 `_`，字符串切分不唯一）→ 必须用宿主注册元数据映射。 */
	ambiguous: boolean;
}

/**
 * 解析宿主原生工具名 `mcp__<server>__<tool>`（工具名=非 [字母数字_] 字符折叠为 `_`）。
 * 设计 §7.2 明令：工具名带 hash / 含歧义分隔的情况**不能字符串切分猜 server/tool**——本函数
 * 在 rest 含多个 `__` 分隔时标 ambiguous=true，执法方（guards）须要求 registeredServerNames
 * 元数据映射（B6b 接线宿主实际注册表），否则按拒绝处理，不放行猜测结果。
 */
export function parseNativeMcpToolName(toolName: string, opts?: { registeredServerNames?: readonly string[] }): NativeMcpToolNameParts | null {
	if (typeof toolName !== "string" || !toolName.startsWith("mcp__")) return null;
	const rest = toolName.slice("mcp__".length);
	const registered = opts?.registeredServerNames;
	if (registered && registered.length > 0) {
		// 最长前缀 server 名优先（元数据映射权威；宿主折叠后的注册名即 canonical 形态）
		const sorted = [...registered].map((n) => canonicalMcpServerName(n)).sort((a, b) => b.length - a.length);
		for (const server of sorted) {
			if (rest.startsWith(`${server}__`)) {
				const tool = rest.slice(server.length + 2);
				if (tool) return { server, tool, ambiguous: false };
			}
		}
		return null; // 注册表内无匹配：非本计划 server 的原生工具
	}
	const idx = rest.indexOf("__");
	if (idx <= 0) return null;
	const server = rest.slice(0, idx);
	const tool = rest.slice(idx + 2);
	if (!server || !tool) return null;
	return { server, tool, ambiguous: rest.slice(idx + 2).includes("__") || server.includes("__") };
}

// ─────────────────────────────────────────────────────────────────────────────
// native 配置面读取（宿主 MCP 专属来源：用户 mcp.json + 项目 .pi/mcp.json）
// ─────────────────────────────────────────────────────────────────────────────

/** native 条目原始形状（解析层；不插值 env/header——预检不执行 env/header 命令，§7.2-1）。 */
export interface NativeMcpEntryRaw {
	name: string;
	/** 来源文件（诊断/来源摘要用）。 */
	file: string;
	layer: "user" | "project";
	/** 完整条目（含 command/url/type 任一）；项目层完整条目=全量替换（视作新 server 重新审批）。 */
	hasFullDefinition: boolean;
	/** enabled 显式值（undefined=未声明，宿主默认 true=连接）。 */
	enabledExplicit?: boolean;
	/** 浅覆写出现的键（合法集 ⊆ enabled/exposure/toolExposure）。 */
	shallowKeys: string[];
	/** 项目层条目声明了 auth（任何形态——宿主规则 auth.provider 仅限全局 mcp.json）。 */
	hasAuth: boolean;
	authProvider?: string;
	url?: string;
	command?: string;
	args?: string[];
}

export interface NativeMcpParseWarning {
	file: string;
	message: string;
}

export interface NativeMcpFileParseResult {
	entries: NativeMcpEntryRaw[];
	warnings: NativeMcpParseWarning[];
}

/** 项目浅覆写合法键集（宿主规则：无 command/url/type 的项目条目只可覆写这三键）。 */
const PROJECT_SHALLOW_KEYS = new Set(["enabled", "exposure", "toolExposure"]);

/** 解析单个 mcp.json（用户层或项目层；纯函数，输入 JSON 文本）。 */
export function parseNativeMcpJson(text: string, file: string, layer: "user" | "project"): NativeMcpFileParseResult {
	const out: NativeMcpFileParseResult = { entries: [], warnings: [] };
	let json: any;
	try { json = JSON.parse(text); } catch (e) {
		out.warnings.push({ file, message: `JSON 解析失败（${e instanceof Error ? e.message : e}）` });
		return out;
	}
	const map = json?.mcpServers;
	if (map === undefined) return out;
	if (!map || typeof map !== "object" || Array.isArray(map)) {
		out.warnings.push({ file, message: "mcpServers 非对象，忽略" });
		return out;
	}
	for (const [name, cfg] of Object.entries<any>(map)) {
		if (!cfg || typeof cfg !== "object") { out.warnings.push({ file, message: `server "${name}" 条目非对象，宿主将跳过` }); continue; }
		if (!isValidNativeServerName(name)) { out.warnings.push({ file, message: `server 名 "${name}" 含非法字符（宿主仅允许字母数字_-），宿主将跳过` }); continue; }
		const hasFullDefinition = cfg.command !== undefined || cfg.url !== undefined || cfg.type !== undefined;
		const entry: NativeMcpEntryRaw = {
			name, file, layer, hasFullDefinition,
			enabledExplicit: typeof cfg.enabled === "boolean" ? cfg.enabled : undefined,
			shallowKeys: Object.keys(cfg).filter((k) => k !== "description" && k !== "timeout"),
			hasAuth: cfg.auth !== undefined && cfg.auth !== null && typeof cfg.auth === "object",
			authProvider: typeof cfg.auth?.provider === "string" ? cfg.auth.provider : undefined,
		};
		if (typeof cfg.url === "string") entry.url = cfg.url;
		if (typeof cfg.command === "string") entry.command = cfg.command;
		if (Array.isArray(cfg.args)) entry.args = cfg.args.filter((a: unknown): a is string => typeof a === "string");
		out.entries.push(entry);
	}
	return out;
}

/** native 有效条目（用户层 + 项目浅覆写/全量替换合并后；含 provenance）。 */
export interface EffectiveNativeEntry {
	name: string;
	canonicalName: string;
	/** 宿主是否会连接（enabled:false → 不连接；hidden 也连接——exposure 不是连接开关，§7.2-2）。 */
	enabled: boolean;
	/** 该 server 定义所在层（项目全量替换 → project）。 */
	definedIn: "user" | "project";
	/** 项目全量替换条目（含 command/url/type）——视作新 server，混合准入整体拒绝。 */
	projectFullReplacement: boolean;
	/** 项目层声明了 auth——拒绝（宿主规则亦不允许）。 */
	authFromProject: boolean;
	hasAuthProvider: boolean;
	authProvider?: string;
	/** 脱敏 endpoint 摘要（url 原文或 command+args；不含 headers/env 值）。 */
	endpointKey?: string;
	source: string;
}

export interface NativeMcpView {
	user: NativeMcpEntryRaw[];
	project: NativeMcpEntryRaw[];
	effective: EffectiveNativeEntry[];
	warnings: NativeMcpParseWarning[];
}

/** 合并用户层 + 项目层（宿主优先级：项目覆盖用户；浅覆写只改 enabled/exposure/toolExposure）。 */
export function mergeNativeLayers(user: NativeMcpEntryRaw[], project: NativeMcpEntryRaw[]): EffectiveNativeEntry[] {
	// 同名分层收集（用户定义 + 项目覆写可共存：浅覆写只改三键，定义仍取用户层）
	const userByName = new Map(user.map((e) => [e.name, e]));
	const projectByName = new Map(project.map((e) => [e.name, e]));
	const names = [...new Set([...userByName.keys(), ...projectByName.keys()])];
	const out: EffectiveNativeEntry[] = [];
	for (const name of names) {
		const projectEntry = projectByName.get(name);
		const userEntry = userByName.get(name);
		// 浅覆写：项目条目无 command/url/type → 覆写 enabled/exposure/toolExposure，定义仍取用户层
		const definition = projectEntry?.hasFullDefinition ? projectEntry : userEntry ?? projectEntry;
		const enabledExplicit = projectEntry !== undefined && projectEntry.enabledExplicit !== undefined
			? projectEntry.enabledExplicit
			: definition?.enabledExplicit;
		out.push({
			name,
			canonicalName: canonicalMcpServerName(name),
			enabled: enabledExplicit !== false,
			definedIn: definition?.layer ?? projectEntry?.layer ?? "user",
			projectFullReplacement: projectEntry?.hasFullDefinition === true,
			authFromProject: projectEntry?.hasAuth === true,
			hasAuthProvider: (definition?.authProvider ?? projectEntry?.authProvider) !== undefined,
			authProvider: definition?.authProvider ?? projectEntry?.authProvider,
			endpointKey: endpointKeyOfRaw(definition ?? projectEntry),
			source: definition?.file ?? projectEntry?.file ?? "",
		});
	}
	return out;
}

/** 条目 endpoint 脱敏摘要（本地判定用；不写入 headers/env 值）。 */
function endpointKeyOfRaw(e: NativeMcpEntryRaw | undefined): string | undefined {
	if (!e) return undefined;
	if (typeof e.url === "string" && e.url) return `url:${e.url.trim()}`;
	if (typeof e.command === "string" && e.command) return `cmd:${e.command} ${(e.args || []).join(" ")}`;
	return undefined;
}

/** 自研通道 server 的同款 endpoint 摘要（与 native 条目同口径比较；插值差异见模块头注）。 */
export function endpointKeyOfCustomServer(cfg: McpServerConfig): string | undefined {
	if (cfg.url) return `url:${cfg.url.trim()}`;
	if (cfg.command) return `cmd:${cfg.command} ${(cfg.args || []).join(" ")}`;
	return undefined;
}

export interface NativeMcpReadOptions {
	/** 用户层 mcp.json 路径（测试注入；缺省 PI_CODING_AGENT_DIR || ~/.pi/agent/mcp.json）。 */
	userMcpJsonPath?: string;
	/** 项目层 .pi/mcp.json 路径（测试注入；缺省 <cwd>/.pi/mcp.json）。 */
	projectMcpJsonPath?: string;
}

/** 读取 native 有效配置视图（只读；真实 ~/.pi 零写入）。 */
export function loadNativeMcpView(cwd: string, opts?: NativeMcpReadOptions): NativeMcpView {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const userFile = opts?.userMcpJsonPath ?? path.join(agentDir, "mcp.json");
	const projectFile = opts?.projectMcpJsonPath ?? path.join(path.resolve(cwd), ".pi", "mcp.json");
	const view: NativeMcpView = { user: [], project: [], effective: [], warnings: [] };
	for (const [file, layer] of [[userFile, "user"], [projectFile, "project"]] as const) {
		let text: string;
		try { text = fs.readFileSync(file, "utf8"); } catch { continue; /* lint-exempt:文件缺席=该层无条目，静默跳过 */ }
		const parsed = parseNativeMcpJson(text, file, layer);
		(layer === "user" ? view.user : view.project).push(...parsed.entries);
		view.warnings.push(...parsed.warnings);
	}
	view.effective = mergeNativeLayers(view.user, view.project);
	return view;
}

/** 检测内置 MCP 是否被显式禁用（settings.json extensions 含 "-builtin:mcp" → 已知不可用）。 */
export function builtinMcpExplicitlyDisabled(settingsJsonPath?: string, cliArgs = process.argv.slice(2)): boolean {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const file = settingsJsonPath ?? path.join(agentDir, "settings.json");
	// 装配时还未有项目信任事实，不用项目文件触发兼容后端接管。
	const files = [file];
	for (const candidate of files) {
		try {
			const json = JSON.parse(fs.readFileSync(candidate, "utf8"));
			if (Array.isArray(json?.extensions) && json.extensions.includes("-builtin:mcp")) return true;
		} catch { /* lint-exempt:settings 缺席/非法=未证明禁用 */ }
	}
	// 复用宿主解析，参数值与 -- 正文中的字面 --no-mcp 不触发后端接管。
	return !settingsJsonPath && typeof piHost.parseArgs === "function" && piHost.parseArgs(cliArgs).noMcp === true;
}

// ─────────────────────────────────────────────────────────────────────────────
// 混合声明（amagi.json `mcp.hybrid.host`）——显式声明才会尝试混合（默认关闭）
// ─────────────────────────────────────────────────────────────────────────────

export interface McpHybridDeclaration {
	/** 显式声明 owner=host 的 server 名（会话冻结输入；未声明 server 一律 owner=amagi）。 */
	host: string[];
	/** 读取来源（诊断）。 */
	source: string;
}

/** 读取混合声明（全局 amagi.json + 项目 amagi.json，项目键优先；无/非法 → null=未声明）。 */
export function loadMcpHybridDeclaration(cwd: string): McpHybridDeclaration | null {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const files = [path.join(agentDir, "amagi.json"), path.join(path.resolve(cwd), "amagi.json")];
	let decl: McpHybridDeclaration | null = null;
	for (const file of files) {
		let json: any;
		try { json = JSON.parse(fs.readFileSync(file, "utf8")); } catch { continue; /* lint-exempt:amagi.json 缺席/非法=该层无声明，静默跳过 */ }
		const hybrid = json?.mcp?.hybrid;
		if (!hybrid || typeof hybrid !== "object" || Array.isArray(hybrid)) continue;
		if (!Array.isArray(hybrid.host)) continue;
		const host: string[] = hybrid.host.filter((n: unknown): n is string => typeof n === "string" && n.trim() !== "");
		decl = { host: [...new Set(host)], source: file };
	}
	return decl && decl.host.length > 0 ? decl : null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 准入决议：拒绝矩阵（设计 §7.2 七步的 1/2/4/6 预检面 + 能力门）
// ─────────────────────────────────────────────────────────────────────────────

export type McpServerOwner = "amagi" | "host";

export interface McpOwnershipPlanServer {
	/** 具体名（配置原文；mcp-client 过滤与指引用具体名+归一名双匹配）。 */
	name: string;
	canonicalName: string;
	owner: McpServerOwner;
	/** 配置来源摘要（文件路径；不含 header/env 值）。 */
	source: string;
	/** 冻结时的 endpoint 脱敏摘要（漂移重验比对用；自研链专属 server 亦可携带）。 */
	endpointKey?: string;
	/** 与实际 grant 求交的角色范围占位（默认 ["*"]——不单独授权，执法在 grant 检查）。 */
	allowedRoleScope: string[];
}

export interface McpOwnershipPlan {
	mode: "custom" | "mixed";
	servers: McpOwnershipPlanServer[];
	/** 计划冻结时刻（会话冻结；reload/fork 重新检验 owner 与实际配置）。 */
	frozenAt: number;
}

export type McpHybridRejectCode =
	| "capability-gate" // mcpProjectOverrides/mcpAuthProvider 能力门未过 → 基座整体不激活
	| "builtin-mcp-unavailable" // /mcp 命令所有权未证明（被扩展接管或显式禁用）
	| "startup-isolation-unproven" // 启动连接隔离未真机证明（B6b 前置）
	| "project-full-replacement" // 项目全量替换条目（视作新 server，须重新审批）
	| "project-auth-provider" // 项目侧声明 auth（auth.provider 仅限全局 mcp.json）
	| "project-override-invalid" // 项目浅覆写带越界键（宿主行为未定义，无法证明 → 拒绝）
	| "canonical-name-dual-owner" // 同名/归一名双 owner（或用户+项目归一名冲突——宿主拒绝第二条）
	| "declared-host-server-missing" // 声明为 host 的 server 不在 native 有效配置
	| "native-server-not-in-plan" // 未列入计划（owner=amagi）的 native server 处于 enabled
	| "endpoint-dual-owner" // 同 endpoint 双 owner
	| "auth-provider-not-approved" // auth.provider 未在批准 provider 名单（B6b 建名单）
	| "auth-provider-non-https"; // auth.provider 用于非 https 且非回环的 HTTP server

export interface McpHybridRejection {
	code: McpHybridRejectCode;
	message: string;
	/** B6b 需补的证据要求（builtin/isolation 类拒绝给真机验证判据）。 */
	evidenceRequired?: string;
}

export type McpHybridStatus = "inactive" | "mixed" | "rejected";

export interface McpHybridResolution {
	status: McpHybridStatus;
	plan?: McpOwnershipPlan;
	rejection?: McpHybridRejection;
	/** inactive 的具体原因（no-declaration / rollback-env）；非错误。 */
	inactiveReason?: "no-declaration" | "rollback-env";
	warnings: string[];
}

/** 能力门输入（host-capabilities 只读消费；测试可注入）。 */
export type McpHybridGates = Pick<HostCapabilities["capabilities"], "mcpProjectOverrides" | "mcpAuthProvider">;

export function hybridBaseGatesAvailable(gates: McpHybridGates): boolean {
	return gates.mcpProjectOverrides === true && gates.mcpAuthProvider === true;
}

/** B6b 真机验证判据文本（isolation / builtin-mcp 拒绝时随 rejection 返回，供报告与验收）。 */
export const HYBRID_EVIDENCE_REQUIREMENTS = {
	builtinMcp:
		"B6b 前置：真机证明原生 /mcp 命令在场——①settings.json extensions 无 \"-builtin:mcp\"；②无其它扩展注册 /mcp（docs/mcp.md §Replace the built-in MCP support：任何扩展注册 /mcp 即整体替换内置实现）；③会话内 /mcp 列表可见宿主原生 server 与连接状态。三者齐备才置 builtinMcpCommandAvailable=true。",
	startupIsolation:
		"B6b 前置：真机证明启动连接隔离——混合计划应用后会话启动，/mcp 连接清单 ⊆ 计划 host owner 集（hidden 也算连接，enabled:false 才不连接；宿主 session_start 后台连接所有 enabled server，文档未证明 amagi 能在全部装配顺序下阻止名单外连接，必须真机验证，不能先连上再注销）。",
} as const;

export interface McpHybridAdmissionInput {
	declaration: McpHybridDeclaration | null;
	native: NativeMcpView;
	/** 自研通道连接名单（amagi 视角 server 名+endpoint 摘要；mcp-client 过滤前的全集）。 */
	customServers: ReadonlyArray<{ name: string; endpointKey?: string }>;
	gates: McpHybridGates;
	/** settings.json 显式禁用了内置 MCP（已知不可用；比 unproven 更强的拒绝证据）。 */
	builtinMcpDisabled?: boolean;
	evidence?: {
		/** 原生 /mcp 命令在场（B6b 真机证明后置 true；缺省 undefined=未证明 → 拒绝）。 */
		builtinMcpCommandAvailable?: boolean;
		/** 启动连接隔离已真机证明（B6b 后置 true）。 */
		startupIsolationProven?: boolean;
		/** 批准的 auth.provider 名单（B6b 建；缺省空=任何 auth.provider 都未批准）。 */
		approvedAuthProviders?: readonly string[];
	};
	now?: number;
}

const reject = (code: McpHybridRejectCode, message: string, evidenceRequired?: string): McpHybridResolution =>
	({ status: "rejected", rejection: { code, message, ...(evidenceRequired ? { evidenceRequired } : {}) }, warnings: [] });

/**
 * 混合准入决议（纯函数；拒绝矩阵逐条覆盖见 tests/mcp-host-bridge.test.mjs）。
 * 检查顺序固定（先全局门，后逐 server 条目），任一失败即拒绝混合启动——不降级、不自动改名。
 */
export function resolveMcpHybridAdmission(input: McpHybridAdmissionInput): McpHybridResolution {
	const warnings: string[] = [];
	if (!input.declaration || input.declaration.host.length === 0) {
		return { status: "inactive", inactiveReason: "no-declaration", warnings };
	}
	// 能力门（§7.2 前提；未过 → 混合基座整体不激活，自研单通道行为不变）
	if (!hybridBaseGatesAvailable(input.gates)) {
		return reject("capability-gate", `混合基座能力门未过：mcpProjectOverrides=${input.gates.mcpProjectOverrides} mcpAuthProvider=${input.gates.mcpAuthProvider}（A2 受测版本表判定；未过门不激活，自研单通道行为不变）`);
	}
	// §7.2-1 清单预检第一步：built-in MCP 必须确实加载（任何扩展注册 /mcp 即整体替换内置实现）
	if (input.builtinMcpDisabled === true) {
		return reject("builtin-mcp-unavailable", "settings.json 显式禁用了内置 MCP（extensions 含 \"-builtin:mcp\"）——混合模式不可启动", HYBRID_EVIDENCE_REQUIREMENTS.builtinMcp);
	}
	if (input.evidence?.builtinMcpCommandAvailable !== true) {
		return reject("builtin-mcp-unavailable", "原生 /mcp 命令所有权未证明（可能被其它扩展接管）——混合模式不可仅靠注册 server 启动，须先解决命令所有权并验证原生命令在场", HYBRID_EVIDENCE_REQUIREMENTS.builtinMcp);
	}
	// §7.2-2 启动连接隔离：无法在装配顺序上证明的路径按设计拒绝（B6b 真机验证后置 true）
	if (input.evidence?.startupIsolationProven !== true) {
		return reject("startup-isolation-unproven", "启动连接隔离未真机证明（宿主 session_start 后台连接所有 enabled server；hidden 不能当成不连接）——按设计拒绝 mixed，不能先连上再注销", HYBRID_EVIDENCE_REQUIREMENTS.startupIsolation);
	}
	const declaredHost = new Set(input.declaration.host);
	// 项目层条目预检（§7.2-1/4/6）
	for (const p of input.native.project) {
		if (p.hasFullDefinition) {
			return reject("project-full-replacement", `项目条目 "${p.name}"（${p.file}）含 command/url/type=全量替换，视作新 server 配置，须重新审批后方可混合（本会话拒绝）`);
		}
		const outOfScope = p.shallowKeys.filter((k) => !PROJECT_SHALLOW_KEYS.has(k));
		if (outOfScope.length > 0) {
			if (p.hasAuth || p.authProvider !== undefined) {
				return reject("project-auth-provider", `项目条目 "${p.name}"（${p.file}）声明了 auth——auth.provider 仅允许出现在全局 mcp.json（设计 §7.2-6：项目直接声明 auth.provider 拒绝）`);
			}
			return reject("project-override-invalid", `项目浅覆写条目 "${p.name}"（${p.file}）带越界键 [${outOfScope.join(", ")}]（宿主只定义 enabled/exposure/toolExposure 覆写语义，无法证明行为）——按设计拒绝`);
		}
	}
	// 声明的 host server 必须存在于 native 有效配置（host 无法拥有不在其配置面的 server）
	const effectiveByName = new Map(input.native.effective.map((e) => [e.name, e]));
	for (const name of declaredHost) {
		if (!effectiveByName.has(name)) {
			return reject("declared-host-server-missing", `声明 owner=host 的 server "${name}" 不在 native 有效配置（用户 mcp.json / 项目 .pi/mcp.json）——宿主无法拥有该 server，请修正 mcp.hybrid.host 声明`);
		}
	}
	// §7.2-3 配置所有权：owner=amagi 的 server 不进入有效 native enabled 列表
	const offPlan = input.native.effective.filter((e) => e.enabled && !declaredHost.has(e.name));
	if (offPlan.length > 0) {
		return reject("native-server-not-in-plan", `native enabled server 未列入 host 计划（owner=amagi 却会被宿主连接，双通道）：${offPlan.map((e) => e.name).join(", ")}——须在 mcp.hybrid.host 声明为 host，或在 native 配置 enabled:false`);
	}
	// 归一名唯一 owner（含用户+项目同名归一冲突——宿主拒绝第二条，混合下同样拒绝）
	const ownerOf = (name: string): McpServerOwner => (declaredHost.has(name) ? "host" : "amagi");
	const ownerByCanonical = new Map<string, { owner: McpServerOwner; names: string[] }>();
	const canonicalGroups = new Map<string, string[]>();
	for (const name of [...input.native.effective.map((e) => e.name), ...input.customServers.map((s) => s.name)]) {
		const c = canonicalMcpServerName(name);
		const group = canonicalGroups.get(c) ?? [];
		if (!group.includes(name)) group.push(name);
		canonicalGroups.set(c, group);
	}
	for (const [canonical, names] of canonicalGroups) {
		const owners = new Set(names.map(ownerOf));
		if (owners.size > 1) {
			return reject("canonical-name-dual-owner", `归一名 "${canonical}"（${names.join(", ")}）被声明为不同 owner（${[...owners].join(", ")}）——同名和归一名只允许一个 owner`);
		}
		ownerByCanonical.set(canonical, { owner: owners.values().next().value!, names });
	}
	// 同 endpoint 双 owner（跨通道：native 定义条目 + 自研通道 server）
	const endpointOwners = new Map<string, { owner: McpServerOwner; names: string[] }>();
	const addEndpoint = (key: string, name: string): void => {
		const rec = endpointOwners.get(key) ?? { owner: ownerOf(name), names: [] };
		if (!rec.names.includes(name)) rec.names.push(name);
		endpointOwners.set(key, rec);
	};
	for (const e of input.native.effective) if (e.endpointKey) addEndpoint(e.endpointKey, e.name);
	for (const s of input.customServers) if (s.endpointKey) addEndpoint(s.endpointKey, s.name);
	for (const [key, rec] of endpointOwners) {
		const owners = new Set(rec.names.map(ownerOf));
		if (owners.size > 1) {
			return reject("endpoint-dual-owner", `同 endpoint 双 owner（${rec.names.join(", ")}）：${key.slice(0, 120)}——两通道连接同一远端，须收敛为单一 owner`);
		}
	}
	// §7.2-6 认证：auth.provider 限批准 provider 与批准 endpoint；HTTP 非回环拒绝（镜像宿主规则）
	const approved = new Set(input.evidence?.approvedAuthProviders ?? []);
	for (const e of input.native.effective) {
		if (!e.hasAuthProvider || e.authProvider === undefined) continue;
		if (!approved.has(e.authProvider)) {
			return reject("auth-provider-not-approved", `server "${e.name}" 的 auth.provider "${e.authProvider}" 不在批准名单（B6b 建立 approvedAuthProviders 后方可准入；不把未知配置键透传称为已支持）`);
		}
		const url = input.native.user.find((u) => u.name === e.name)?.url ?? input.native.project.find((p) => p.name === e.name)?.url;
		if (typeof url === "string" && /^http:\/\//i.test(url) && !isLoopbackUrl(url)) {
			return reject("auth-provider-non-https", `server "${e.name}" 声明 auth.provider 但 endpoint 为非 https 非回环 HTTP（${redactUrl(url)}）——auth.provider 要求 https（回环除外）`);
		}
	}
	// 全部通过 → 构建冻结计划（加载期成形，会话冻结）
	const servers: McpOwnershipPlanServer[] = [];
	const seenCanonical = new Set<string>();
	const customEndpointByName = new Map(input.customServers.map((s) => [s.name, s.endpointKey]));
	for (const e of input.native.effective) {
		if (seenCanonical.has(e.canonicalName)) continue; // 归一去重（同一 canonical 以定义条目为准）
		seenCanonical.add(e.canonicalName);
		servers.push({ name: e.name, canonicalName: e.canonicalName, owner: ownerOf(e.name), source: e.source, ...(e.endpointKey ? { endpointKey: e.endpointKey } : {}), allowedRoleScope: ["*"] });
	}
	for (const s of input.customServers) {
		const c = canonicalMcpServerName(s.name);
		if (seenCanonical.has(c)) continue; // native 面已有（同 canonical 单 owner，计划取 native 面）
		seenCanonical.add(c);
		servers.push({ name: s.name, canonicalName: c, owner: "amagi", source: "custom-chain", ...(s.endpointKey ? { endpointKey: s.endpointKey } : {}), allowedRoleScope: ["*"] });
	}
	return { status: "mixed", plan: { mode: "mixed", servers, frozenAt: input.now ?? Date.now() }, warnings };
}

/** 回环 URL 判定（auth.provider 宿主规则：https 除 localhost/127.0.0.1/[::1] 外）。 */
function isLoopbackUrl(url: string): boolean {
	try {
		const u = new URL(url);
		return u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "[::1]" || u.hostname === "::1";
	} catch { return false; /* lint-exempt:非法 URL 按非回环处理（保守拒绝面） */ }
}

/** URL 脱敏（摘除 userinfo/query——报告与拒绝理由不携带凭据）。 */
function redactUrl(url: string): string {
	try {
		const u = new URL(url);
		u.username = "";
		u.password = "";
		u.search = "";
		return u.toString();
	} catch { return url.slice(0, 60); /* lint-exempt:非法 URL 截断回退，不携带凭据 */ }
}

// ─────────────────────────────────────────────────────────────────────────────
// 计划查询件（mcp-client / mcp-override / guards 消费）
// ─────────────────────────────────────────────────────────────────────────────

/** 计划中某 server 的 owner（具体名或归一名匹配；不在计划 → undefined=无混合路由语义）。 */
export function ownerOfServerInPlan(plan: McpOwnershipPlan | undefined, name: string): McpServerOwner | undefined {
	if (!plan || plan.mode !== "mixed" || typeof name !== "string" || !name) return undefined;
	const canonical = canonicalMcpServerName(name);
	for (const s of plan.servers) {
		if (s.name === name || s.canonicalName === canonical) return s.owner;
	}
	return undefined;
}

/** host-owner 指引文本（单一来源：mcp-client native execute 与 mcp-override 入口分流共用）。 */
export function hostOwnerGuidanceText(server: string, tool: string | undefined): string {
	return `[amagi-mcp] server "${server}" 由宿主原生 MCP 通道拥有（owner=host）——自研 mcp_call 不向该 server 转发（避免双通道嵌套重试）。请使用原生工具：先经 /mcp 查看连接与登录状态，工具调用用原生工具名 mcp__<server>__<tool>${tool ? `（本次目标 tool=${tool}）` : ""}；资源用 list_mcp_resources / read_mcp_resource。自研 mcp_call 仅服务 owner=amagi 的 server。`;
}

// ─────────────────────────────────────────────────────────────────────────────
// 项目浅覆写 × 冻结 grant 求交（设计 §7.2-4：覆写是宿主配置优先级，不是 amagi 授权）
// ─────────────────────────────────────────────────────────────────────────────

export interface ProjectShallowOverride {
	enabled?: boolean;
	exposure?: string;
	toolExposure?: Record<string, string>;
}

export interface OverrideGrantIntersection {
	/** 有效启用 = 覆写 enabled ∧ 冻结授权命中该 server（禁用立即收紧；启用不扩大授权）。 */
	effectiveEnabled: boolean;
	/** 有效可见工具：通配授权 "*" 时= 覆写未隐藏的全部；列表授权时 = 授权 ∩ 覆写未隐藏。 */
	effectiveVisibleTools: "*" | string[];
	/** 是否发生收紧（覆写隐藏了授权内工具）。 */
	narrowed: boolean;
}

/**
 * 浅覆写与冻结 grant 求交（纯函数）：enabled/exposure/toolExposure 变化不扩大冻结授权——
 * 禁用可立即收紧；启用/暴露 widening 与 grant 求交后生效；完整条目替换不走本函数（准入已拒）。
 * toolExposure 覆写值：hidden=收紧；direct/codemode/deferred 对授权外工具仍不可见。
 */
export function intersectProjectOverrideWithGrant(
	override: ProjectShallowOverride,
	serverGranted: boolean,
	grantedTools: "*" | readonly string[],
): OverrideGrantIntersection {
	const effectiveEnabled = (override.enabled !== false) && serverGranted;
	const hiddenByOverride = new Set<string>();
	for (const [tool, exposure] of Object.entries(override.toolExposure ?? {})) {
		if (exposure === "hidden") hiddenByOverride.add(tool);
	}
	if (override.exposure === "hidden") {
		return { effectiveEnabled, effectiveVisibleTools: [], narrowed: true };
	}
	if (grantedTools === "*") {
		const narrowed = hiddenByOverride.size > 0;
		return narrowed
			? { effectiveEnabled, effectiveVisibleTools: ["*"], narrowed: true } // 通配授权 + 部分隐藏：授权面仍全量，隐藏在宿主注册面生效（记录收紧事实）
			: { effectiveEnabled, effectiveVisibleTools: "*", narrowed: false };
	}
	const visible = grantedTools.filter((t) => !hiddenByOverride.has(t));
	return { effectiveEnabled, effectiveVisibleTools: visible, narrowed: visible.length < grantedTools.length };
}

// ─────────────────────────────────────────────────────────────────────────────
// 漂移重验（设计 §7.2-7 生命周期：reload/fork/恢复须重新检验 owner 与实际配置）
// ─────────────────────────────────────────────────────────────────────────────

export type OwnershipDriftKind =
	| "new-native-server" // 出现计划外 native enabled server
	| "endpoint-changed" // 计划内 server endpoint 变化（完整替换视作新 server）
	| "owner-flipped" // owner 分配与冻结计划不一致
	| "server-removed"; // 计划内 server 从有效配置消失

export interface OwnershipDrift {
	kind: OwnershipDriftKind;
	server: string;
	detail: string;
}

/** 冻结计划 vs 当前 native 视图的重验（纯函数；有漂移 → 调用方关闭混合并要求重开会话）。 */
export function detectOwnershipDrift(plan: McpOwnershipPlan, current: NativeMcpView): OwnershipDrift[] {
	const drifts: OwnershipDrift[] = [];
	const currentByName = new Map(current.effective.map((e) => [e.name, e]));
	const currentByCanonical = new Map(current.effective.map((e) => [e.canonicalName, e]));
	const plannedByCanonical = new Map(plan.servers.map((s) => [s.canonicalName, s]));
	for (const s of plan.servers) {
		if (s.source === "custom-chain") continue; // 自研链专属 server 的漂移由自研配置面自证，不在 native 视图比对
		const e = currentByName.get(s.name) ?? currentByCanonical.get(s.canonicalName);
		if (!e) {
			drifts.push({ kind: "server-removed", server: s.name, detail: `计划内 server 从 native 有效配置消失（${s.canonicalName}）` });
			continue;
		}
		if (e.projectFullReplacement) {
			drifts.push({ kind: "endpoint-changed", server: s.name, detail: `项目全量替换条目出现（${e.name}）——视作新 server，须重新审批` });
			continue;
		}
		if (s.endpointKey !== undefined && e.endpointKey !== undefined && s.endpointKey !== e.endpointKey) {
			drifts.push({ kind: "endpoint-changed", server: s.name, detail: `endpoint 与冻结计划不一致（${redactEndpoint(s.endpointKey)} → ${redactEndpoint(e.endpointKey)}）——视作新 server 配置，须重新审批` });
		}
	}
	for (const e of current.effective) {
		if (!e.enabled) continue;
		const planned = plannedByCanonical.has(e.canonicalName);
		if (!planned) {
			drifts.push({ kind: "new-native-server", server: e.name, detail: `native enabled server 不在冻结计划（${e.canonicalName}）——条件变化，须关闭混合并重开会话` });
		}
	}
	return drifts;
}

/** endpoint 摘要脱敏（截断即可——摘要本身不含凭据，截断防长命令行刷屏）。 */
function redactEndpoint(key: string): string {
	return key.length > 80 ? `${key.slice(0, 77)}…` : key;
}

// ─────────────────────────────────────────────────────────────────────────────
// 回滚事务编排（设计 §7.3；B6b 消费——端口注入，编排器自身零文件操作）
// ─────────────────────────────────────────────────────────────────────────────

export const HYBRID_ROLLBACK_STEPS = [
	"stop-new-requests", // ① 停止新请求
	"drain-in-flight", // ② 等待/取消在途请求并记录未知外部效果
	"close-native-owner", // ③ 关闭 native owner
	"restore-self-config", // ④ 恢复该 server 原自研配置
	"start-single-channel-session", // ⑤ 新开单通道会话
	"positive-call-probe", // ⑥ 正向调用一次确认
] as const;

export type HybridRollbackStepName = (typeof HYBRID_ROLLBACK_STEPS)[number];

export interface HybridRollbackPorts {
	/** ① 停止新请求（该 server 的自研 mcp_call 与原生调用一律拒绝进入）。 */
	stopNewRequests(server: string): Promise<void> | void;
	/** ② 等待在途（graceMs 内完成计 awaited）；超时取消计 cancelled，逐条记录未知外部效果。 */
	drainInFlight(server: string, opts: { graceMs: number }): Promise<{ awaited: number; cancelled: number; unknownExternalEffects: string[] }>;
	/** ③ 关闭 native owner（会话内停用/注销扩展注册；不改用户文件配置）。 */
	closeNativeOwner(server: string): Promise<void> | void;
	/** ④ 恢复原自研配置（内存路由恢复；凭据保持宿主原存储位置，不读取/复制 auth.json）。 */
	restoreSelfConfig(server: string): Promise<void> | void;
	/** ⑤ 新开单通道会话（新会话内 owner=amagi 生效的自检由端口实现承担）。 */
	startSingleChannelSession(server: string): Promise<void> | void;
	/** ⑥ 正向调用一次确认（单通道恢复后真实调用验证）。 */
	positiveCallProbe(server: string): Promise<{ ok: boolean; detail?: string }>;
}

export interface HybridRollbackStepRecord {
	step: HybridRollbackStepName;
	status: "ok" | "failed";
	detail?: string;
}

export interface HybridRollbackReport {
	server: string;
	/** completed=六步全过；probe-failed=结构完成但正向确认失败；aborted=中途失败（含失败步）。 */
	status: "completed" | "probe-failed" | "aborted";
	steps: HybridRollbackStepRecord[];
	/** ② 取消的在途请求的未知外部效果（逐条保留，不吞——已执行的外部副作用无法由切换 owner 撤销）。 */
	unknownExternalEffects: string[];
	failure?: { step: HybridRollbackStepName; detail: string };
}

/** 回滚步骤序（纯函数：测试与 B6b 文档锚点）。 */
export function planHybridRollbackSteps(): readonly HybridRollbackStepName[] {
	return HYBRID_ROLLBACK_STEPS;
}

/**
 * 执行回滚事务（§7.3 顺序编排）。编排器自身零文件操作、零业务写回放、不自动清理用户文件——
 * 全部副作用经端口注入（B6b 接线真实端口；测试注入伪端口验证顺序与失败语义）。
 * 失败语义：③④ 失败即中止（防双通道并存）；② 取消属既定动作（未知外部效果记录后继续）；
 * ⑥ 失败报 probe-failed（结构完成、确认缺失，由调用方决定处置）。
 */
export async function executeHybridRollback(
	server: string,
	ports: HybridRollbackPorts,
	opts?: { graceMs?: number },
): Promise<HybridRollbackReport> {
	const graceMs = opts?.graceMs ?? 10_000;
	const report: HybridRollbackReport = { server, status: "aborted", steps: [], unknownExternalEffects: [] };
	const step = async (name: HybridRollbackStepName, fn: () => Promise<string | void> | string | void): Promise<boolean> => {
		try {
			const detail = await fn();
			report.steps.push({ step: name, status: "ok", ...(typeof detail === "string" && detail ? { detail } : {}) });
			return true;
		} catch (e) {
			const detail = e instanceof Error ? e.message : String(e);
			report.steps.push({ step: name, status: "failed", detail });
			report.failure = { step: name, detail };
			return false;
		}
	};
	if (!(await step("stop-new-requests", () => ports.stopNewRequests(server)))) return report;
	if (!(await step("drain-in-flight", async () => {
		const drained = await ports.drainInFlight(server, { graceMs });
		report.unknownExternalEffects.push(...drained.unknownExternalEffects);
		return `awaited=${drained.awaited} cancelled=${drained.cancelled} unknownEffects=${drained.unknownExternalEffects.length}`;
	}))) return report;
	if (!(await step("close-native-owner", () => ports.closeNativeOwner(server)))) return report;
	if (!(await step("restore-self-config", () => ports.restoreSelfConfig(server)))) return report;
	if (!(await step("start-single-channel-session", () => ports.startSingleChannelSession(server)))) return report;
	let probeDetail = "";
	const probeOk = await step("positive-call-probe", async () => {
		const probe = await ports.positiveCallProbe(server);
		if (!probe.ok) throw new Error(probe.detail ?? "正向调用确认失败（单通道恢复未证实）");
		probeDetail = probe.detail ?? "ok";
		return probeDetail;
	});
	report.status = probeOk ? "completed" : "probe-failed";
	return report;
}

// ─────────────────────────────────────────────────────────────────────────────
// 会话级组装件（B6b 接线消费：index.ts 装配期调用一次，计划随会话冻结）
// ─────────────────────────────────────────────────────────────────────────────

export interface SessionHybridOptions {
	/** 测试注入：宿主版本覆盖（host-capabilities 版本判定面）。 */
	versionOverride?: string | null;
	/** 测试注入：native 配置读取路径。 */
	nativeRead?: NativeMcpReadOptions;
	/** 测试注入：B6b 真机证据（缺省未证明 → 拒绝 mixed，正是 B6a 的默认关闭语义）。 */
	evidence?: {
		builtinMcpCommandAvailable?: boolean;
		startupIsolationProven?: boolean;
		approvedAuthProviders?: readonly string[];
	};
	/** 测试注入：settings.json 路径（builtin 显式禁用检测）。 */
	settingsJsonPath?: string;
	now?: number;
}

export interface SessionHybridResult extends McpHybridResolution {
	/** 决议时的声明来源与宿主版本（诊断）。 */
	diagnostics: { declarationSource?: string; hostVersion: string | null };
}

/**
 * 会话级混合决议（装配期一次；拒绝理由落日志后由调用方按 status 分发）。
 * 默认（无声明/证据未证明/能力门未过）→ inactive/rejected——自研单通道行为逐字节不变。
 */
export function resolveSessionMcpHybrid(cwd: string, opts?: SessionHybridOptions): SessionHybridResult {
	const rollbackEnv = (process.env.AMAGI_MCP_HYBRID ?? "").trim().toLowerCase();
	const diagnostics: SessionHybridResult["diagnostics"] = { hostVersion: null };
	if (rollbackEnv === "0" || rollbackEnv === "false" || rollbackEnv === "off") {
		return { status: "inactive", inactiveReason: "rollback-env", warnings: [], diagnostics };
	}
	const declaration = loadMcpHybridDeclaration(cwd);
	diagnostics.declarationSource = declaration?.source;
	const caps = resolveHostCapabilities(null, opts?.versionOverride !== undefined ? { versionOverride: opts.versionOverride } : undefined);
	diagnostics.hostVersion = caps.hostVersion;
	const native = loadNativeMcpView(cwd, opts?.nativeRead);
	const custom = loadMcpServerConfigs(cwd);
	const customServers = Object.values(custom.servers).map((cfg) => ({ name: cfg.name, endpointKey: endpointKeyOfCustomServer(cfg) }));
	const resolution = resolveMcpHybridAdmission({
		declaration,
		native,
		customServers,
		gates: caps.capabilities,
		builtinMcpDisabled: builtinMcpExplicitlyDisabled(opts?.settingsJsonPath),
		evidence: opts?.evidence,
		now: opts?.now,
	});
	if (resolution.status === "rejected" && resolution.rejection) {
		tuiWarn(`[amagi-mcp-hybrid] 混合启动拒绝（${resolution.rejection.code}）：${resolution.rejection.message}${resolution.rejection.evidenceRequired ? ` 证据要求：${resolution.rejection.evidenceRequired}` : ""}`);
	}
	return { ...resolution, diagnostics };
}
