/** Preserve raw tool argument deltas across a length failure. No failed call is run automatically. */
import { createHash, randomBytes } from "node:crypto";
import { closeSync, fstatSync, linkSync, openSync, readFileSync, readSync, unlinkSync, writeFileSync } from "node:fs";
import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";

const ENTRY = "amagi:toolcall-continuation";
const params = Type.Object({
 token: Type.String({ description: "版本化续传 token，必须使用最近返回的版本。" }),
 append: Type.String({ description: "从断点之后继续的原始 JSON 文本，不重复前缀。" }),
 final: Type.Boolean({ description: "仅完整 JSON 时设 true；之后经原工具链校验执行。" }),
});
type Phase = "open" | "executing" | "executed";
type RecordEntry = { v: 1; nonce: string; session: string; id: string; kind: "create" | "append" | "executing" | "executed" | "reopen"; tool?: string; call?: string; originalActive?: boolean; raw?: string; version?: number; append?: string; final?: boolean; result?: any; budget?: number; output?: number; rawSha256?: string; appendSha256?: string; fullSha256?: string; bytes?: number };
type State = { id: string; tool: string; call: string; originalActive: boolean; raw: string; version: number; phase: Phase; budget?: number; output?: number; history: Map<number, { append: string; final: boolean; result: any }> };
const sha = (s: string) => createHash("sha256").update(s).digest("hex");
const token = (s: State) => `${s.id}.${s.version}`;
const result = (text: string, error = false) => ({ content: [{ type: "text" as const, text }], details: {}, ...(error ? { isError: true } : {}) });
/** Serialize only recovery of a dead legacy reclaim. SQLite's OS lock is released on death;
 * the legacy claim still arbitrates with old processes and is never replaced by this lock. */
async function recoverDeadClaim(reclaim: string, alive: (pid: unknown) => boolean): Promise<void> {
 const { DatabaseSync } = await import("node:sqlite");
 const db = new DatabaseSync(`${reclaim}.sqlite`);
 let transaction = false;
 try {
  try { db.exec("BEGIN IMMEDIATE"); transaction = true; }
  catch (error) {
   if ((error as { errcode?: number }).errcode === 5) return; // another recovery owns the OS lock
   throw error;
  }
  let raw: string;
  try { raw = readFileSync(reclaim, "utf8"); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return; throw error; }
  let claim: { pid?: unknown; nonce?: unknown };
  try { claim = JSON.parse(raw); }
  catch { /* journal: corrupt claim must fail closed */ throw new Error("续传锁恢复记录不可读"); }
  if (typeof claim.nonce !== "string" || !claim.nonce || typeof claim.pid !== "number" || !Number.isSafeInteger(claim.pid) || claim.pid <= 0) throw new Error("续传锁恢复记录不可读");
  if (!alive(claim.pid) && readFileSync(reclaim, "utf8") === raw && !alive(claim.pid)) unlinkSync(reclaim);
 } finally {
  try { if (transaction) db.exec("ROLLBACK"); } finally { db.close(); }
 }
}
/** Serialize the short read/commit transitions across processes sharing a session.
 * The tool itself runs outside the lock, after its durable executing transition. */
async function withSessionLock<T>(ctx: ExtensionContext, _id: string, signal: AbortSignal | undefined, fn: () => T): Promise<T> {
 const file = ctx.sessionManager.getSessionFile();
 if (!file) throw new Error("会话没有持久化文件");
 const lock = `${file}.amagi-length.lock`, reclaim = `${lock}.reclaim`;
 const owner = JSON.stringify({ pid: process.pid, nonce: randomBytes(16).toString("hex") });
 const alive = (pid: unknown): boolean => {
  if (typeof pid !== "number" || !Number.isSafeInteger(pid) || pid <= 0) return true;
  try { process.kill(pid, 0); return true; } catch (e) { return (e as NodeJS.ErrnoException).code !== "ESRCH"; }
 };
 for (;;) {
  if (signal?.aborted) throw new Error("续传等待已取消");
  const temp = `${lock}.${randomBytes(8).toString("hex")}.tmp`;
  let acquired = false;
  try {
   writeFileSync(temp, owner, { flag: "wx", mode: 0o600 });
   try { linkSync(temp, lock); acquired = true; }
   catch (e) { if ((e as NodeJS.ErrnoException).code !== "EEXIST") throw e; }
  } finally { try { unlinkSync(temp); } catch { /* lint-exempt: private candidate cleanup cannot affect lock ownership */ } }
  if (acquired) {
   try { return fn(); }
   finally { try { if (readFileSync(lock, "utf8") === owner) unlinkSync(lock); } catch { /* lint-exempt: ownership uncertain; retain lock rather than delete another holder */ } }
  }
  try {
   const prior = readFileSync(lock, "utf8"); const parsed = JSON.parse(prior) as { pid?: unknown; nonce?: unknown } | null;
   if (!parsed || typeof parsed.pid !== "number" || !Number.isSafeInteger(parsed.pid) || parsed.pid <= 0 || typeof parsed.nonce !== "string" || !parsed.nonce) throw new Error("续传锁记录不可读");
   if (!alive(parsed.pid)) {
    let claim = false;
    const candidate = `${reclaim}.${randomBytes(8).toString("hex")}.tmp`;
    try {
     writeFileSync(candidate, owner, { flag: "wx", mode: 0o600 });
     linkSync(candidate, reclaim); claim = true;
     if (readFileSync(lock, "utf8") === prior && !alive(parsed.pid)) unlinkSync(lock);
    } catch (e) {
     const code = (e as NodeJS.ErrnoException).code;
     if (code === "EEXIST") {
      let claimant: { pid?: unknown; nonce?: unknown } | null;
      try { claimant = JSON.parse(readFileSync(reclaim, "utf8")); }
      catch (error) {
       if ((error as NodeJS.ErrnoException).code === "ENOENT") continue; // another contender removed it
       throw new Error(`续传锁恢复记录不可读：${reclaim}`);
      }
      if (!claimant || typeof claimant.pid !== "number" || !Number.isSafeInteger(claimant.pid) || claimant.pid <= 0 || typeof claimant.nonce !== "string" || !claimant.nonce) throw new Error("续传锁恢复记录不可读");
      if (!alive(claimant.pid)) await recoverDeadClaim(reclaim, alive);
     } else if (code !== "ENOENT") throw e;
    }
    finally {
     try { unlinkSync(candidate); } catch { /* lint-exempt: private candidate cleanup cannot affect claim ownership */ }
     if (claim) { try { if (readFileSync(reclaim, "utf8") === owner) unlinkSync(reclaim); } catch { /* lint-exempt: ownership uncertain; preserve claim */ } }
    }
   }
  } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
  await new Promise<void>(resolve => setTimeout(resolve, 15));
 }
}
function textOf(s: State): string {
 const complete = (() => { try { JSON.parse(s.raw); return true; } catch { /* journal: incomplete JSON reported to caller */ return false; } })();
 return `[amagi 续传] 原调用未执行；已保存 ${Buffer.byteLength(s.raw)} 字节 sha256=${sha(s.raw)}。token=${token(s)} tool=${s.tool} 状态=${complete ? "完整" : "截断"}。调用 toolcall_continue({token,append,final})；append 是原始 JSON 文本，严格从断点后续写，不重复前缀；完整后 final=true。${complete ? "完整参数可用 append=空字符串、final=true。" : ""}${s.budget === undefined ? "" : ` 实际请求输出预算=${s.budget}。`}\n${s.raw.slice(-300)}⟨断点⟩`;
}
/** appendEntry is synchronous but in-memory sessions and failed disk writes need explicit detection. */
function persist(pi: ExtensionAPI, ctx: ExtensionContext, data: Omit<RecordEntry, "v" | "nonce" | "session">): void {
 const file = ctx.sessionManager.getSessionFile();
 if (!file) throw new Error("会话没有持久化文件，不能生成可恢复 token");
 const fd = openSync(file, "r");
 try {
  const before = fstatSync(fd).size;
  const entry: RecordEntry = { v: 1, nonce: randomBytes(16).toString("hex"), session: ctx.sessionManager.getSessionId(), ...data,
   ...(data.raw !== undefined ? { rawSha256: sha(data.raw), bytes: Buffer.byteLength(data.raw) } : {}),
   ...(data.append !== undefined ? { appendSha256: sha(data.append), bytes: Buffer.byteLength(data.append) } : {}) };
  pi.appendEntry(ENTRY, entry);
  const after = fstatSync(fd).size;
  const buf = Buffer.alloc(Math.max(0, after - before));
  let n = 0; while (n < buf.length) { const count = readSync(fd, buf, n, buf.length - n, before + n); if (!count) break; n += count; }
  const found = buf.subarray(0, n).toString("utf8").split("\n").some(line => {
   try { const e = JSON.parse(line); return e.type === "custom" && e.customType === ENTRY && e.data?.nonce === entry.nonce; } catch { /* journal: malformed line cannot verify write */ return false; }
  });
  if (!found) throw new Error("会话条目未通过写后核验");
  // A previous failed host append can leave an in-memory parent absent on disk.
  // Seeing the new line alone is insufficient: it would be orphaned on resume.
  const ids = new Set<string>();
  for (const line of readFileSync(file, "utf8").split("\n")) {
   try { const e = JSON.parse(line); if (typeof e.id === "string") ids.add(e.id); } catch { /* lint-exempt: malformed or incomplete line is not a persisted ancestor */ }
  }
  const branch = ctx.sessionManager.getBranch();
  if (!branch.some(e => e.type === "custom" && e.customType === ENTRY && (e.data as RecordEntry | undefined)?.nonce === entry.nonce) || branch.some(e => !ids.has(e.id))) {
   throw new Error("会话分支存在未持久化祖先，续传未提交");
  }
 } finally { closeSync(fd); }
}
function states(ctx: ExtensionContext, allBranches = false): Map<string, State> {
 const out = new Map<string, State>();
 const branch = ctx.sessionManager.getBranch();
 if (!branch.some(e => e.type === "custom" && e.customType === ENTRY)) return out;
 // The host mutates its in-memory branch before writing. Never trust an entry
 // that is absent from the actual session file after a failed append.
 const file = ctx.sessionManager.getSessionFile();
 if (!file) return out;
 const durable = new Set<string>();
 const fileEntries: any[] = [];
 const persistedById = new Map<string, any>();
 try {
  for (const line of readFileSync(file, "utf8").split("\n")) {
   try {
    const e = JSON.parse(line);
    if (typeof e.id === "string") persistedById.set(e.id, e);
    if (e.type === "custom" && e.customType === ENTRY && typeof e.data?.nonce === "string") { durable.add(e.data.nonce); fileEntries.push(e); }
   } catch { /* lint-exempt: malformed or incomplete line cannot establish durable state */ }
  }
 } catch { /* journal: unreadable session cannot establish durable state */ return out; }
 const hasDurableAncestry = (id: string): boolean => {
  const visited = new Set<string>(); let current: string | null | undefined = id;
  while (current) {
   if (visited.has(current)) return false;
   visited.add(current); const e = persistedById.get(current); if (!e) return false;
   current = e.parentId;
  }
  return true;
 };
 // Membership comes from the current branch; operation outcomes are global to
 // this session so navigating to an older branch cannot replay a side effect.
 for (const entry of allBranches ? fileEntries : branch) {
  if (entry.type !== "custom" || entry.customType !== ENTRY) continue;
  const d = entry.data as RecordEntry | undefined;
  if (!d || d.v !== 1 || !durable.has(d.nonce) || !hasDurableAncestry(entry.id) || d.session !== ctx.sessionManager.getSessionId()) continue;
  if (d.kind === "create" && typeof d.raw === "string" && d.tool && d.call && d.rawSha256 === sha(d.raw) && d.bytes === Buffer.byteLength(d.raw)) {
   out.set(d.id, { id: d.id, tool: d.tool, call: d.call, originalActive: d.originalActive === true, raw: d.raw, version: 0, phase: "open", budget: d.budget, output: d.output, history: new Map() });
  } else {
   const s = out.get(d.id); if (!s) continue;
   if ((d.kind === "append" || d.kind === "executing") && (typeof d.append !== "string" || d.appendSha256 !== sha(d.append) || d.bytes !== Buffer.byteLength(d.append) || (d.kind === "executing" && d.fullSha256 !== sha(s.raw + d.append)))) { out.delete(d.id); continue; }
   if (d.kind === "append" && typeof d.append === "string" && d.version === s.version) {
    s.raw += d.append; s.history.set(s.version, { append: d.append, final: false, result: d.result }); s.version++;
   } else if (d.kind === "executing" && typeof d.append === "string" && d.version === s.version) {
    s.raw += d.append; s.phase = "executing"; s.history.set(s.version, { append: d.append, final: true, result: undefined });
   } else if (d.kind === "executed" && d.version === s.version) {
    s.phase = "executed"; const h = s.history.get(s.version); if (h) h.result = d.result;
   } else if (d.kind === "reopen" && d.version === s.version) {
    const h = s.history.get(s.version); if (h) s.raw = s.raw.slice(0, s.raw.length - h.append.length);
    s.history.delete(s.version); s.phase = "open";
   }
  }
 }
 return out;
}

export function registerLengthContinuation(pi: ExtensionAPI): void {
 let chunks = new Map<number, string>(); let budget: number | undefined;
 const notices = new Map<string, string>();
 const queues = new Map<string, Promise<void>>();
 const active = new Set<string>();
 pi.on("session_start", () => { chunks.clear(); notices.clear(); });
 pi.on("session_tree", () => { chunks.clear(); notices.clear(); });
 // A provider without request instrumentation must not inherit an earlier budget.
 pi.on("turn_start", () => { budget = undefined; });
 pi.on("before_provider_request", (e) => {
  const p = e.payload as Record<string, unknown> | null;
  const n = p?.max_completion_tokens ?? p?.max_tokens ?? p?.max_output_tokens;
  budget = typeof n === "number" && Number.isFinite(n) ? n : undefined;
 });
 pi.on("message_start", e => { if (e.message.role === "assistant") chunks = new Map(); });
 pi.on("message_update", e => {
  const a = e.assistantMessageEvent;
  if (a.type === "toolcall_start") chunks.set(a.contentIndex, "");
  if (a.type === "toolcall_delta") chunks.set(a.contentIndex, (chunks.get(a.contentIndex) ?? "") + a.delta);
 });
 pi.on("message_end", async (e, ctx) => {
  const m = e.message;
  if (m.role === "assistant" && m.stopReason === "length") {
   for (const [index, block] of m.content.entries()) {
    if (block.type !== "toolCall") continue;
    const raw = chunks.get(index);
    if (!raw) { notices.set(block.id, "[amagi 续传] 未收到参数增量，无法恢复前缀；没有生成 token。原调用未执行。"); continue; }
    const id = `tc_${randomBytes(16).toString("hex")}`;
    try {
     const s = await withSessionLock(ctx, id, ctx.signal, () => {
      persist(pi, ctx, { id, kind: "create", tool: block.name, call: block.id, originalActive: pi.getActiveTools().includes(block.name), raw, budget, output: m.usage?.output });
      const saved = states(ctx).get(id);
      if (!saved) throw new Error("持久条目不在当前会话分支");
      return saved;
     });
     notices.set(block.id, textOf(s));
    } catch (error) { notices.set(block.id, `[amagi 续传] 保存失败，未生成 token：${error instanceof Error ? error.message : String(error)}`); }
   }
  } else if (m.role === "toolResult") {
   const notice = notices.get(m.toolCallId);
   if (notice) { notices.delete(m.toolCallId); return { message: { ...m, content: [...m.content, { type: "text" as const, text: notice }] } }; }
  }
  return undefined;
 });
 pi.on("context", (e, ctx) => {
  const branch = states(ctx); const global = states(ctx, true);
  const open = [...branch.keys()].map(id => global.get(id)).filter((s): s is State => s !== undefined && s.phase === "open");
  if (!open.length) return;
  const existing = JSON.stringify(e.messages);
  const missing = open.filter(s => !existing.includes(`token=${token(s)}`));
  if (!missing.length) return;
  return { messages: [...e.messages, { role: "user" as const, content: [{ type: "text" as const, text: missing.map(textOf).join("\n\n") }], timestamp: Date.now() }] };
 });
 pi.registerTool({
  name: "toolcall_continue", label: "toolcall_continue", parameters: params,
  description: "续传被输出上限截断的工具参数。token 为版本化令牌；append 是断点后的原始 JSON。final=true 时完整解析并经原工具链执行；重复同一版本和内容不会重复追加或执行。失败的原调用不会自动执行。",
  async execute(_callId, input, signal, _update, ctx) {
   const match = /^(tc_[0-9a-f]{32})\.(0|[1-9][0-9]*)$/.exec(input.token);
   if (!match || !Number.isSafeInteger(Number(match[2]))) return result("无效续传 token", true);
   const id = match[1]!; const version = Number(match[2]);
   const key = `${ctx.sessionManager.getSessionId()}:${id}`;
   if (active.has(key)) return result("此 token 正在执行，结果未知时请核查现场；不会重放。", true);
   const previous = queues.get(key) ?? Promise.resolve();
   let release!: () => void; const done = new Promise<void>(resolve => { release = resolve; });
   queues.set(key, done); await previous;
   try {
    const prepared = await withSessionLock<{ result: any } | { tool: string; args: unknown }>(ctx, id, signal, () => {
    if (!states(ctx).has(id)) return { result: result("token 不存在或不属于当前会话分支", true) };
    const s = states(ctx, true).get(id);
    if (!s) return { result: result("token 持久记录不可用或校验失败", true) };
    const old = s.history.get(version);
    if (old) {
     if (old.append !== input.append || old.final !== input.final) return { result: result(`旧版本 token 已使用；当前 token=${token(s)}`, true) };
     if (old.result !== undefined) return { result: old.result };
     return { result: result("执行状态未知，请先核查现场；不会重放。", true) };
    }
    if (version !== s.version) return { result: result(`token 版本不匹配；当前 token=${token(s)}`, true) };
    if (s.phase !== "open") return { result: result("执行状态未知或已执行；不会重放。", true) };
    if (!input.final) {
     const updated = { ...s, raw: s.raw + input.append, version: s.version + 1 };
     const r = result(`追加成功；token=${token(updated)} bytes=${Buffer.byteLength(updated.raw)} sha256=${sha(updated.raw)}\n${updated.raw.slice(-120)}⟨断点⟩`);
     persist(pi, ctx, { id, kind: "append", version, append: input.append, result: r });
     return { result: r };
    }
    let args: unknown;
    try { args = JSON.parse(s.raw + input.append); }
    catch (error) { return { result: result(`JSON 不完整或非法：${error instanceof Error ? error.message : String(error)}；本次追加未保存，请用原 token 修正。`, true) }; }
    // Only the original active tool is eligible. Callable-only/deferred tools must not
    // be reached through a forged failed tool call.
    if (!s.originalActive || !pi.getActiveTools().includes(s.tool) || !ctx.tools.some(t => t.name === s.tool)) return { result: result(`原工具 ${s.tool} not available in the active tool set；未执行。`, true) };
    // Avoid a continuation referring to itself, including a cycle through nested continuations.
    if (s.tool === "toolcall_continue" && args && typeof args === "object") {
     const nested = (args as { token?: unknown }).token;
     if (typeof nested === "string" && (nested.split(".")[0] === id || active.has(`${ctx.sessionManager.getSessionId()}:${nested.split(".")[0]}`))) return { result: result("续传循环，未执行；请修正追加内容。", true) };
    }
    persist(pi, ctx, { id, kind: "executing", version, append: input.append, final: true, fullSha256: sha(s.raw + input.append) });
    return { tool: s.tool, args };
    });
    if ("result" in prepared) return prepared.result;
    active.add(key);
    try {
     const outcome = await ctx.executeTool(prepared.tool, prepared.args, { signal });
     if (outcome.durationMs === undefined) {
      await withSessionLock(ctx, id, undefined, () => persist(pi, ctx, { id, kind: "reopen", version }));
      return { ...outcome.result, isError: true };
     }
     const r = { ...outcome.result, ...(outcome.isError ? { isError: true } : {}) };
     await withSessionLock(ctx, id, undefined, () => persist(pi, ctx, { id, kind: "executed", version, result: r }));
     return r;
    } finally { active.delete(key); }
   } catch (error) { return result(`续传持久化或执行失败：${error instanceof Error ? error.message : String(error)}；如执行已开始请核查现场，不要重放。`, true); }
   finally { release(); if (queues.get(key) === done) queues.delete(key); }
  },
 });
}
