/**
 * launch-anchor.ts — ev-20261021-a8de95（diting F-01 + 复核）：任务运行实体的持久启动锚点与退出证明。
 *
 * 问题：恢复对账（task_control reconcile）曾以「进程环境快照里没看到 AMAGI_TASK_ID」当作「已退出」——
 * 环境标签不是退出证据（macOS 平台二进制 env 对 ps 不可见、他人 uid 不可读、setsid 逃逸出进程组）。
 *
 * 根治：退出须有**正向证据**，证据覆盖不到的形态一律 unknown（fail-closed，主上人工确认收口）。
 *   锚点：子 pi spawn 后**同步**追加运行实体（backendRunId/rootPid/pgid/Leader pid；出生令牌异步补齐），
 *        先于 started 观察提交——契约记录出现的每个 backendRunId 都必有锚点，缺失即证据不全。
 *   判定（逐 run，全部 run 证明退出才算 exited）：
 *   - env 血统命中 → live（确凿）；
 *   - 契约记录最新 backendRunId 不在锚点 / 锚点有截断 / 无锚点 → unknown（人工确认可收口）；
 *   - 原 Leader（非本进程）存活且出生令牌一致 → live（归其会话管辖）；令牌不可比对 → unknown；
 *   - 未启用进程组（非 detached）→ 后代不受进程组约束 → unknown（人工确认可收口）；
 *   - rootPid 在且令牌一致 → live；令牌不同（pid 复用：POSIX 组存续期间组长 pid 不复用）→ 原组已空；
 *     令牌不可比对 → unknown；rootPid 不在而组内仍有成员（孙进程，含 env 不可见者）→ live；
 *   - 逃逸后代（setsid 离组，原组清空也不证明它退出）：同 uid、启动于首个 run 之后、其祖先链经
 *     收养者（pid 1 / systemd 用户实例）断开且链上全部启动于 run 之后、不在本进程链上的进程是
 *     **疑似后代**——存在即 unknown 并列 pid（不能归因 ≠ 不存在）；人工确认（晚于最新 run）可收口。
 *   证据边界（如实）：经既存守护进程代派生的进程（tmux server/launchctl/docker 等）不是进程树后代，
 *   本证明不覆盖；人工确认注记的信任面同 adopted.json（文件工具不可写契约存储；guarded shell 不是
 *   文件系统沙箱——同 uid 脚本 I/O 可绕过，保证等级与 adopt 一致）。
 *
 * ev-20261026-165da9（设备重启自动恢复）：锚点同步记录**系统启动身份**（bootId+bootTimeMs，
 * boot-identity.ts 探测）。退出证明新增逐 run boot 定位（严→宽，全部 fail-closed）：
 *   - 锚点 boot id ≠ 当前 boot id（或 Linux 出生令牌内嵌 boot id ≠ 当前）⇒ 该 run 属此前系统启动
 *     会话——根进程、进程组与全部后代（含逃逸后代）已随重启退出，PID/PGID 复用不构成阻断；全部
 *     run 均如此时跳过疑似逃逸后代扫描（本次 boot 的任何进程都不可能是其后代——修复重启后 509 个
 *     系统进程被误列疑似后代、要求人工 confirm-exited 的事故）。
 *   - legacy 锚点无 boot 字段且无 Linux 令牌时，不凭日历时刻推断重启：当前时钟正常不能证明历史
 *     run.at 未受校时影响。继续既有进程与后代证明，证据不足保持 unknown（F-01）。
 *   - 有新 run（同 boot/身份未知）不整体当旧 boot 关闭：逐 run 判定，未证明的 run 照旧走既有核验与疑似
 *     后代扫描（sinceMs 取未证明 run 的最早锚定时刻）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { execFile } from "node:child_process";
import { amagiDataFile } from "./data-dir.ts";
import { contractStoreRoot, sanitizeId } from "./artifact.ts";
import { readKernelProcessIdentitiesAsync } from "./process-audit.ts";
import { findTaskLineageProcesses } from "./orphan-reaper.ts";
import { BOOT_ID_RE, bootIdFromIdentityToken, probeBootIdentity, type BootIdentity } from "./boot-identity.ts";

export interface LaunchAnchorRun {
	/** 运行身份（与契约记录 run.backendRunId 同源；旧锚点缺席）。 */
	backendRunId?: string;
	rootPid: number;
	/** 进程组 id（detached spawn 时 === rootPid；未启用进程组时缺席）。 */
	pgid?: number;
	/** 子进程内核出生令牌（异步补齐；缺席时 rootPid 仍在只能判 unknown）。 */
	rootIdentityToken?: string;
	leaderPid: number;
	leaderIdentityToken?: string;
	at: number;
	/** ev-20261026-165da9：派发时刻系统启动身份（成对写入；探测失败/旧版本锚点缺席 → legacy 判定）。 */
	bootId?: string;
	bootTimeMs?: number;
}

export interface LaunchAnchor {
	version: 1;
	taskId: string;
	/** 同一任务的全部运行实体（首派发 + 续接/续跑），须逐个证明退出。 */
	runs: LaunchAnchorRun[];
	/** 超出保留上限被丢弃的 run 数（>0 即证据不全 → unknown；不静默截断）。 */
	droppedRuns?: number;
}

const RUNS_MAX = 256;
const ANCHOR_FILE = "launch-anchor.json";
export const EXIT_ATTESTATION_FILE = "exit-attested.json";

function safeId(taskId: string): string {
	return taskId.replace(/[^a-zA-Z0-9_-]/g, "_");
}

export function launchAnchorPath(taskId: string): string {
	return amagiDataFile("process-audits", safeId(taskId), ANCHOR_FILE);
}

export function readLaunchAnchor(taskId: string): LaunchAnchor | undefined {
	let raw: string;
	try { raw = fs.readFileSync(launchAnchorPath(taskId), "utf8"); } catch { return undefined; } /* lint-exempt:锚点缺席=无证据（调用方判 unknown） */
	try {
		const v = JSON.parse(raw) as Partial<LaunchAnchor>;
		if (v?.version !== 1 || v.taskId !== taskId || !Array.isArray(v.runs)) return undefined;
		// ev-20261026-165da9：boot 字段成对且形态合法（半缺/畸形 = 写入异常或篡改 → 整体不可信，fail-closed）
		const bootFieldsOk = (r: unknown): boolean => {
			const o = r as { bootId?: unknown; bootTimeMs?: unknown };
			const hasId = o.bootId !== undefined;
			const hasTime = o.bootTimeMs !== undefined;
			if (hasId !== hasTime) return false;
			if (hasId && (typeof o.bootId !== "string" || !BOOT_ID_RE.test(o.bootId) || !(typeof o.bootTimeMs === "number" && Number.isSafeInteger(o.bootTimeMs) && o.bootTimeMs > 0))) return false;
			return true;
		};
		const runs = v.runs.filter((r): r is LaunchAnchorRun => !!r && Number.isInteger(r.rootPid) && r.rootPid > 1 && Number.isInteger(r.leaderPid) && r.leaderPid > 0 && bootFieldsOk(r));
		if (runs.length !== v.runs.length) return undefined; // 任一条目损坏 → 整体不可信
		const dropped = Number.isInteger(v.droppedRuns) && (v.droppedRuns as number) > 0 ? (v.droppedRuns as number) : 0;
		return { version: 1, taskId, runs, ...(dropped > 0 ? { droppedRuns: dropped } : {}) };
	} catch { return undefined; } /* lint-exempt:损坏锚点不可作证据——按缺席处理（fail-closed） */
}

function writeAnchor(taskId: string, anchor: LaunchAnchor): void {
	const abs = launchAnchorPath(taskId);
	const tmp = `${abs}.tmp-${process.pid}-${Date.now()}`;
	try {
		fs.mkdirSync(path.dirname(abs), { recursive: true, mode: 0o700 });
		fs.writeFileSync(tmp, `${JSON.stringify(anchor, null, 2)}\n`, { mode: 0o600 });
		fs.renameSync(tmp, abs);
	} finally {
		try { fs.rmSync(tmp, { force: true }); } catch { /* lint-exempt:临时文件清理 best-effort */ }
	}
}

/** 同步追加一个运行实体锚点（tmp+rename 原子替换；超上限计入 droppedRuns 而非静默丢弃）。失败返回原因。 */
export function appendLaunchAnchor(taskId: string, run: LaunchAnchorRun): string | undefined {
	try {
		const prev = readLaunchAnchor(taskId);
		const all = [...(prev?.runs ?? []), run];
		const over = Math.max(0, all.length - RUNS_MAX);
		const dropped = (prev?.droppedRuns ?? 0) + over;
		writeAnchor(taskId, { version: 1, taskId, runs: all.slice(over), ...(dropped > 0 ? { droppedRuns: dropped } : {}) });
		return undefined;
	} catch (e) {
		return e instanceof Error ? e.message : String(e);
	}
}

/** 异步补齐出生令牌（按 backendRunId 定位；锚点已不含该 run 时无操作）。 */
function patchAnchorTokens(taskId: string, backendRunId: string, tokens: { rootIdentityToken?: string; leaderIdentityToken?: string }): string | undefined {
	try {
		const prev = readLaunchAnchor(taskId);
		if (!prev) return "锚点不可读";
		const runs = prev.runs.map((r) => (r.backendRunId === backendRunId ? { ...r, ...tokens } : r));
		writeAnchor(taskId, { ...prev, runs });
		return undefined;
	} catch (e) {
		return e instanceof Error ? e.message : String(e);
	}
}

/** 派发侧：spawn 后**同步**记录锚点（先于 started 观察提交），出生令牌异步补齐。
 *  返回同步写入失败原因与令牌补齐 promise（失败只影响日后对账能否自证——届时如实 unknown）。 */
export function recordLaunchAnchor(taskId: string, root: { backendRunId: string; pid: number; pgid?: number; identityToken: Promise<string | undefined> }): { failure?: string; tokens: Promise<string | undefined> } {
	// ev-20261026-165da9：派发时刻同步记录系统启动身份（进程内记忆化探测；失败如实缺席 → 该 run 日后按 legacy 判定）
	const boot = probeBootIdentity();
	const failure = appendLaunchAnchor(taskId, {
		backendRunId: root.backendRunId,
		rootPid: root.pid,
		...(root.pgid !== undefined ? { pgid: root.pgid } : {}),
		leaderPid: process.pid,
		at: Date.now(),
		...(boot ? { bootId: boot.bootId, bootTimeMs: boot.bootTimeMs } : {}),
	});
	const tokens = Promise.all([
		root.identityToken.catch(() => undefined),
		readKernelProcessIdentitiesAsync([process.pid]).catch(() => new Map<number, { identityToken: string }>()),
	]).then(([rootToken, leaderIds]) => {
		const leaderToken = leaderIds.get(process.pid)?.identityToken;
		if (!rootToken && !leaderToken) return undefined;
		return patchAnchorTokens(taskId, root.backendRunId, { ...(rootToken ? { rootIdentityToken: rootToken } : {}), ...(leaderToken ? { leaderIdentityToken: leaderToken } : {}) });
	});
	return { ...(failure ? { failure } : {}), tokens };
}

// ── 主上人工退出确认（无锚点记录的唯一收口证据；与 adopted.json 同处契约目录、同一信任面） ──

export interface ExitAttestation { formatVersion: 1; taskId: string; attestedAt: number; attestedBy: string; note: string; }

export function exitAttestationPath(taskId: string, root: string = contractStoreRoot()): string {
	return path.join(root, sanitizeId(taskId), EXIT_ATTESTATION_FILE);
}

export function readExitAttestation(taskId: string, root?: string): { text: string; at: number } | undefined {
	try {
		const v = JSON.parse(fs.readFileSync(exitAttestationPath(taskId, root), "utf8")) as Partial<ExitAttestation>;
		if (v.formatVersion !== 1 || v.taskId !== taskId || typeof v.attestedAt !== "number" || typeof v.attestedBy !== "string") return undefined;
		return { at: v.attestedAt, text: `${v.attestedBy} 于 ${new Date(v.attestedAt).toISOString()} 确认无残留进程${v.note ? `（${v.note}）` : ""}` };
	} catch { return undefined; } /* lint-exempt:缺席/损坏=无人工确认（不作证据） */
}

export function writeExitAttestation(taskId: string, attestedBy: string, note: string, root?: string): void {
	const abs = exitAttestationPath(taskId, root);
	const tmp = `${abs}.tmp-${process.pid}`;
	fs.writeFileSync(tmp, `${JSON.stringify({ formatVersion: 1, taskId, attestedAt: Date.now(), attestedBy, note: note.slice(0, 400) } satisfies ExitAttestation, null, 2)}\n`, "utf8");
	try { fs.renameSync(tmp, abs); } finally { try { fs.rmSync(tmp, { force: true }); } catch { /* lint-exempt:临时文件清理 best-effort */ } }
}

// ── 退出证明 ────────────────────────────────────────────────────────────────

export interface ProcRow { pid: number; ppid: number; pgid: number; uid?: number; /** 已运行秒数（ps etime）。 */ elapsedSec?: number; comm?: string; }

export type ExitProof =
	| { state: "exited"; evidence: string[]; /** ev-20261026-165da9：退出由跨 boot 证据（全部 run 均经 boot 身份/权威 boot 时刻证明）建立。 */ crossBoot?: boolean }
	| { state: "live"; pids: number[]; detail: string }
	| { state: "unknown"; reason: string };

export interface ExitProofDeps {
	readAnchor?: (taskId: string) => LaunchAnchor | undefined;
	/** 主上人工确认（契约目录 exit-attested.json）；仅晚于最新 run 的确认有效。 */
	readAttestation?: (taskId: string) => { text: string; at: number } | undefined;
	/** 全量进程表；不可用 → null。 */
	snapshot?: () => Promise<ProcRow[] | null>;
	identities?: (pids: readonly number[]) => Promise<Map<number, { identityToken: string }>>;
	/** env 血统扫描（命中即 live；未命中不构成退出证据）。 */
	lineage?: (taskId: string) => Promise<{ ok: true; pids: number[] } | { ok: false; reason: string }>;
	selfPid?: number;
	uid?: number;
	now?: () => number;
	/** ev-20261026-165da9：当前系统启动身份探测（缺省 boot-identity probeBootIdentity；测试注入）。 */
	probeBoot?: () => BootIdentity | undefined;
}

export interface ExitProofTarget {
	/** 契约记录最新运行身份（run.backendRunId）；锚点须覆盖它。 */
	backendRunId?: string;
}

function parseEtime(s: string): number | undefined {
	const m = s.trim().match(/^(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+)$/);
	if (!m) return undefined;
	return Number(m[1] ?? 0) * 86400 + Number(m[2] ?? 0) * 3600 + Number(m[3]) * 60 + Number(m[4]);
}

function snapshotProcessTable(): Promise<ProcRow[] | null> {
	return new Promise((resolve) => {
		execFile("ps", ["-axo", "pid=,ppid=,pgid=,uid=,etime=,comm="], { timeout: 5000, maxBuffer: 16 * 1024 * 1024, encoding: "utf8" }, (err, out) => {
			if (err) { resolve(null); return; }
			const rows: ProcRow[] = [];
			for (const line of out.split("\n")) {
				const m = line.trim().match(/^(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\S+)\s*(.*)$/);
				if (!m) continue;
				const elapsedSec = parseEtime(m[5]);
				rows.push({ pid: Number(m[1]), ppid: Number(m[2]), pgid: Number(m[3]), uid: Number(m[4]), ...(elapsedSec !== undefined ? { elapsedSec } : {}), comm: m[6] });
			}
			resolve(rows.length > 0 ? rows : null); // 空表不可信（ps 至少能看到自身）
		});
	});
}

const defaultLineage: NonNullable<ExitProofDeps["lineage"]> = async (taskId) => {
	const r = await findTaskLineageProcesses(taskId);
	return r.ok ? { ok: true, pids: r.procs.map((p) => p.pid) } : { ok: false, reason: r.reason };
};

const START_SLACK_MS = 5000;

/** 收养者：孤儿进程的新父（pid 1 / Linux systemd 用户实例 subreaper）。 */
function isAdopter(row: ProcRow | undefined, pid: number): boolean {
	if (pid === 1) return true;
	return !!row?.comm && path.basename(row.comm.split(" ")[0] ?? "") === "systemd";
}

/** 疑似逃逸后代：同 uid、祖先链全部启动于 sinceMs 之后并经收养者断开、不在本进程链上。 */
export function suspectedDescendants(table: readonly ProcRow[], sinceMs: number, nowMs: number, selfPid: number, uid: number | undefined): ProcRow[] {
	const byPid = new Map(table.map((r) => [r.pid, r]));
	const startedAfter = (r: ProcRow): boolean | undefined => (r.elapsedSec === undefined ? undefined : nowMs - r.elapsedSec * 1000 + 1000 >= sinceMs - START_SLACK_MS);
	const memo = new Map<number, boolean>();
	const suspect = (r: ProcRow, depth: number): boolean => {
		const cached = memo.get(r.pid);
		if (cached !== undefined) return cached;
		let v: boolean;
		if (r.pid === selfPid || depth > 64) v = false;
		else if (uid !== undefined && r.uid !== undefined && r.uid !== uid) v = false;
		else if (startedAfter(r) === false) v = false;
		else if (isAdopter(byPid.get(r.ppid), r.ppid)) v = true; // 启动时间未知按疑似（不臆断无关）
		else { const parent = byPid.get(r.ppid); v = parent !== undefined && parent.pid !== selfPid && suspect(parent, depth + 1); }
		memo.set(r.pid, v);
		return v;
	};
	return table.filter((r) => r.pid > 1 && !isAdopter(r, r.pid) && suspect(r, 0));
}

/** 证明任务的全部运行实体已退出（见模块头判定表）。只读：不发信号、不改文件。 */
export async function proveTaskExited(taskId: string, target: ExitProofTarget = {}, deps: ExitProofDeps = {}): Promise<ExitProof> {
	const anchor = (deps.readAnchor ?? readLaunchAnchor)(taskId);
	const attRaw = (deps.readAttestation ?? readExitAttestation)(taskId);
	const latestRunAt = anchor && anchor.runs.length > 0 ? Math.max(...anchor.runs.map((r) => r.at)) : 0;
	// 人工确认只覆盖确认时刻之前的运行（之后的续接/续跑须重新确认）
	const attestation = attRaw && attRaw.at > latestRunAt ? attRaw.text : undefined;
	const selfPid = deps.selfPid ?? process.pid;
	const uid = deps.uid ?? (typeof process.getuid === "function" ? process.getuid() : undefined);
	const nowMs = (deps.now ?? Date.now)();
	const lineage = await (deps.lineage ?? defaultLineage)(taskId);
	if (lineage.ok && lineage.pids.length > 0) {
		return { state: "live", pids: lineage.pids, detail: "env AMAGI_TASK_ID 血统匹配" };
	}
	const confirmGuide = `主上人工核对进程后可在 TUI 执行 /amagi recovery confirm-exited ${taskId}`;
	if (!anchor || anchor.runs.length === 0) {
		if (attestation) return { state: "exited", evidence: [`无启动锚点；主上人工确认：${attestation}`] };
		return { state: "unknown", reason: `无启动锚点（本版本前派发或锚点写入失败）——无法证明运行实体已退出；${confirmGuide}` };
	}
	const gaps: string[] = [];
	if (anchor.droppedRuns) gaps.push(`锚点超保留上限丢弃 ${anchor.droppedRuns} 个早期 run`);
	if (target.backendRunId && !anchor.runs.some((r) => r.backendRunId === target.backendRunId)) gaps.push(`契约记录最新运行 ${target.backendRunId.slice(0, 24)} 未锚定`);
	if (gaps.length > 0 && !attestation) return { state: "unknown", reason: `锚点覆盖不全（${gaps.join("；")}）——${confirmGuide}` };
	// ev-20261026-165da9：逐 run boot 定位（严→宽，fail-closed）：锚点 boot 字段 → Linux 出生令牌内嵌
	// boot id → 无法定位（ambiguous）。pre-boot = 精确跨 boot 证据（该 run 全部实体已随系统重启退出，
	// PID/PGID 复用不构成阻断）；current-boot = 同 boot（既有核验）；ambiguous = 无精确 boot 证据，
	// 不凭历史日历时刻绕过后代检查。
	const boot = (deps.probeBoot ?? probeBootIdentity)();
	type RunBootClass = { kind: "pre-boot" | "current-boot" | "ambiguous"; detail?: string };
	const bootClassOf = (run: LaunchAnchorRun): RunBootClass => {
		if (run.bootId !== undefined && boot !== undefined) {
			return run.bootId.toLowerCase() !== boot.bootId.toLowerCase()
				? { kind: "pre-boot", detail: `锚点 boot ${run.bootId.slice(0, 8)}… ≠ 当前 boot ${boot.bootId.slice(0, 8)}…（${boot.source}）` }
				: { kind: "current-boot", detail: `锚点 boot ${run.bootId.slice(0, 8)}… = 当前 boot（${boot.source}）` };
		}
		const tokenBoot = bootIdFromIdentityToken(run.rootIdentityToken) ?? bootIdFromIdentityToken(run.leaderIdentityToken);
		if (tokenBoot !== undefined && boot !== undefined) {
			return tokenBoot.toLowerCase() !== boot.bootId.toLowerCase()
				? { kind: "pre-boot", detail: `出生令牌内嵌 boot ${tokenBoot.slice(0, 8)}… ≠ 当前 boot ${boot.bootId.slice(0, 8)}…（${boot.source}）` }
				: { kind: "current-boot", detail: `出生令牌内嵌 boot = 当前 boot（${boot.source}）` };
		}
		return { kind: "ambiguous" };
	};
	const classes = anchor.runs.map(bootClassOf);
	const preBootLine = (i: number, cls: RunBootClass): string =>
		`run#${i + 1}（root pid ${anchor.runs[i]!.rootPid}）：${cls.detail}——系统重启后该运行的根进程、进程组与全部后代（含逃逸后代）均已退出`;
	if (gaps.length === 0 && classes.every((c) => c.kind === "pre-boot")) {
		// 全部 run 均属此前系统启动会话（精确 boot 证据）：无需进程表快照即可证明退出——本次 boot 的
		// 任何进程（含疑似逃逸后代扫描的全部对象）都不可能是其存活实体（修复重启后 509 个系统进程
		// 被误列疑似后代的事故）。
		return {
			state: "exited",
			crossBoot: true,
			evidence: [
				...gaps.map((g) => `${g}——主上人工确认：${attestation}`),
				...classes.map((c, i) => preBootLine(i, c)),
				`全部 ${anchor.runs.length} 个运行实体均属此前系统启动会话——本次启动后的任何进程不可能是其后代，跳过疑似逃逸后代扫描`,
				...(lineage.ok ? [] : [`env 血统补充扫描不可用（${lineage.reason}）`]),
			],
		};
	}
	const table = await (deps.snapshot ?? snapshotProcessTable)();
	if (!table) return { state: "unknown", reason: "进程表快照不可用（ps 失败/超时）" };
	const byPid = new Map(table.map((r) => [r.pid, r]));
	const tokenPids = new Set<number>();
	for (const [i, run] of anchor.runs.entries()) {
		if (classes[i]!.kind === "pre-boot") continue; // 已证跨 boot：pid 占用/令牌比对无意义（必为复用）
		if (byPid.has(run.rootPid)) tokenPids.add(run.rootPid);
		if (run.leaderPid !== selfPid && byPid.has(run.leaderPid)) tokenPids.add(run.leaderPid);
	}
	const ids = tokenPids.size > 0 ? await (deps.identities ?? readKernelProcessIdentitiesAsync)([...tokenPids]) : new Map<number, { identityToken: string }>();
	const evidence: string[] = gaps.map((g) => `${g}——主上人工确认：${attestation}`);
	// 已证明跨 boot 退出的 run 下标（仅精确 boot 证据）：疑似后代扫描界须排除，
	// 否则本次 boot 的系统进程仍会被误列疑似后代（ev-20261026-165da9 steer #3 根因遗留）。
	const provenPre = new Set<number>(anchor.runs.map((_, i) => (classes[i]!.kind === "pre-boot" ? i : -1)).filter((i) => i >= 0));
	for (const [i, run] of anchor.runs.entries()) {
		const tag = `run#${i + 1}（root pid ${run.rootPid}）`;
		const cls = classes[i]!;
		if (cls.kind === "pre-boot") {
			evidence.push(preBootLine(i, cls));
			continue;
		}
		if (run.leaderPid !== selfPid && byPid.has(run.leaderPid)) {
			const cur = ids.get(run.leaderPid)?.identityToken;
			if (run.leaderIdentityToken && cur === run.leaderIdentityToken) {
				return { state: "live", pids: [run.leaderPid], detail: `原 Leader 进程仍存活（pid ${run.leaderPid}）——任务归其会话管辖` };
			}
			if ((!run.leaderIdentityToken || !cur) && !attestation) {
				return { state: "unknown", reason: `${tag} 原 Leader pid ${run.leaderPid} 仍被占用且出生令牌不可比对——无法区分原 Leader 存活与 pid 复用` };
			}
		}
		const rootRow = byPid.get(run.rootPid);
		if (rootRow) {
			const cur = ids.get(run.rootPid)?.identityToken;
			if (run.rootIdentityToken && cur === run.rootIdentityToken) {
				return { state: "live", pids: [run.rootPid], detail: `${tag} 子进程仍存活（出生令牌一致）` };
			}
			if (!run.rootIdentityToken || !cur) {
				return { state: "unknown", reason: `${tag} pid 仍被占用但出生令牌不可比对——无法区分原进程与 pid 复用` };
			}
			// 令牌不同：pid 复用——POSIX 下组长 pid 在其进程组存续期间不复用，原组必已清空（仍查组成员）
		}
		// legacy 没有精确 boot 身份：组内任何成员先按存活处理，不能被校时后的时间捷径覆盖。
		// 重启后无关进程恰好复用 pgid 只能保守误阻断；新锚点的精确 boot 证明不受此限制。
		const members = run.pgid === undefined ? [] : table.filter((r) => r.pgid === run.pgid && r.pid !== run.rootPid).map((r) => r.pid);
		if (members.length > 0) {
			return { state: "live", pids: members, detail: `${tag} 子进程已退出，但其进程组 ${run.pgid} 仍有成员（孙进程）` };
		}
		if (run.pgid === undefined) {
			// 非 detached：后代不受进程组约束，rootPid 状态也不能代表后代——只能人工确认
			if (attestation) { evidence.push(`${tag} 未启用进程组，后代由主上人工确认：${attestation}`); continue; }
			return { state: "unknown", reason: `${tag} 派发时未启用进程组（AMAGI_TASK_PROCESS_GROUP=0/非 POSIX）——无法证明其后代已退出；${confirmGuide}` };
		}
		evidence.push(`${tag}子进程与进程组 ${run.pgid} 均无存活成员`);
	}
	// 原组清空不证明 setsid 逃逸的后代已退出：疑似后代存在即不能自证。已证跨 boot 的 run
	// 在重启后不可能有存活后代——扫描界只取未证明 run 的最早锚定时刻；全部证毕则
	// 不扫描（不取 Math.min 空集的 Infinity）。
	const openRuns = anchor.runs.filter((_, i) => !provenPre.has(i));
	if (openRuns.length === 0) {
		evidence.push(`现存 ${anchor.runs.length} 个已锚定运行均属此前系统启动会话——其后代已退出${gaps.length > 0 ? "；缺失运行仅有人工确认，不能作为完整跨 boot 证明" : "，跳过疑似逃逸后代扫描"}`);
		if (!lineage.ok) evidence.push(`env 血统补充扫描不可用（${lineage.reason}）`);
		// 覆盖缺口只能被显式人工确认豁免，不能升级为系统跨 boot 证明（F-02）。
		return { state: "exited", evidence, ...(gaps.length === 0 ? { crossBoot: true } : {}) };
	}
	const firstOpenAt = Math.min(...openRuns.map((r) => r.at));
	const suspects = suspectedDescendants(table, firstOpenAt, nowMs, selfPid, uid);
	if (suspects.length > 0) {
		const list = suspects.slice(0, 8).map((r) => `${r.pid}${r.comm ? ` ${path.basename(r.comm.split(" ")[0] ?? "")}` : ""}`).join(", ");
		if (!attestation) {
			return { state: "unknown", reason: `原进程组已清空，但有 ${suspects.length} 个启动于本任务运行之后、父链经收养者断开的同用户进程（疑似逃逸后代，无法归因：${list}${suspects.length > 8 ? " …" : ""}）——${confirmGuide}` };
		}
		evidence.push(`疑似逃逸后代 ${suspects.length} 个（${list}）由主上人工确认无关：${attestation}`);
	} else {
		evidence.push("无疑似逃逸后代（同用户、启动于运行之后、经收养者断开的进程为零）");
	}
	if (!lineage.ok) evidence.push(`env 血统补充扫描不可用（${lineage.reason}）`);
	// crossBoot 语义见上方：全部 run 均经跨 boot 证据证毕时，openRuns 分支已提前返回；此处为混合
	// 证据（部分 run 靠进程表/人工确认退出）的同 boot 完整退出——不标 crossBoot。
	return { state: "exited", evidence };
}
