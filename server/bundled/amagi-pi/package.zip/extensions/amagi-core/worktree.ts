/**
 * worktree.ts — E11：worktree 编排一等公民（迭代期望 §四-1）。
 *
 * task({ worktree: "<name>" }) → 扩展自动 `git worktree add`，子 Agent 在独立工作树中
 * 干活（多 Agent 并行改同一仓库从"能跑"到"敢跑"），结束后汇总 diff 列表随回流附上。
 * v1.5.180 起附主仓工作区基线快照，任务结束漂移比对（主仓未提交改动被还原/新增 → 告警）。
 *
 * 约定：
 *   - 工作树路径 <gitroot>/.amagi-worktrees/<name>，分支 amagi/<name>（从当前 HEAD 切出）。
 *   - 已存在同名工作树 → 复用（如实标注 reused）；约定路径未命中时按分支 amagi/<name> 反查
 *     `git worktree list`（ev-20260910-e3906c：Leader 预建在别处的同一分支工作树同样复用，reusedOutsideConvention
 *     标注非约定路径）；反查命中的树不可复用 → 给出「改用 cwd=<path> 派发」建议，不透传 git 原文。
 *   - 派发 cwd 是仓库子目录（仓库根 ≠ cwd）→ worktree 为整仓检出（ev-20260910-cc75b2）：subdirCheckout 标注
 *     仓库根、cwd 相对仓库根的路径与树内项目根对应路径，供回流/任务书/journal 显式提示；路径被非工作树占用/非 git 仓库 → 如实报错。
 *   - 子 Agent 被告诫**不 commit**（改动留在工作区），由 Leader/已授权 luban 审查 diff 后合并；
 *     汇总 = `git diff --stat HEAD`（跟踪文件）+ `git status --porcelain`（未跟踪）。
 *   - AMAGI_WORKTREE_OFF=1 关闭（参数传入时如实报错说明被禁用）。
 *   - stable task_submit/task_resume 复用这些原语；legacy task 的 session+worktree/编排模式仍不支持。
 *
 * ev-20260916-07e44a（脏 worktree 强删保护）：`cleanupWorktree` 在 force=true 时也检查脏树——
 * `git status --porcelain -z --untracked-files=all` 非空默认拒绝并列出将丢弃文件；active owner 保持
 * 硬拒绝不可被开关豁免；探测失败不当干净。只读检查 `inspectWorktreeRemoval` 供 S1 bash 入口
 * （`git worktree remove` 前置检查）与 S2 终态提示（"树内未提交 N 个路径"）复用，两条入口同一实现。
 * 回滚：AMAGI_WORKTREE_DIRTY_REMOVE=legacy 仅恢复旧 force 行为（非 force 拒绝与 active owner 保护不变）；
 * 部署级开关，拒绝提示中不引导临时设 env 绕过。检查沿用本模块 git 30s 超时，不另设超时体系；
 * 显式回收（cleanupWorktree/inspectWorktreeRemoval）的常规脏态检查不计 ignored 文件（明确限制，
 * 不承诺目录级备份）；自动回滚（rollbackWorktreeCreation）是例外——丢弃面探测计入 ignored
 * 内容（ev-20261021-fix diting F2：自动删除只允许在可证明创建事务无用户产物时）。
 */

import { execFileSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export function worktreeEnabled(): boolean {
	const v = process.env.AMAGI_WORKTREE_OFF;
	return !(v === "1" || v === "true");
}

function git(args: string[], cwd: string): string {
	return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 30_000 }).trim();
}

/** 原样 git 输出（不 trim）——porcelain -z 依赖首列状态空格（如 ` M path`），trim 会把它剥掉导致解析失败。 */
function gitRaw(args: string[], cwd: string): string {
	return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: 30_000 });
}

function sanitizeName(name: string): string {
	const s = String(name || "").replace(/[^A-Za-z0-9_.-]/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);
	// F2（ev-20261007-ef07e6 复审）：`.`/`..`/纯点号是路径段意图——path.join 归一会把 wtPath 逃出
	// .amagi-worktrees（如 ".." → 主仓根，show-toplevel 校验照样通过），按非法名拒绝（消毒后为空）。
	return /^[.]+$/.test(s) ? "" : s;
}

/** 路径等价判定：resolve 优先，realpath 兜底（macOS /var、/tmp 等符号链接前缀差异）。 */
function samePath(a: string, b: string): boolean {
	if (path.resolve(a) === path.resolve(b)) return true;
	try { return fs.realpathSync(a) === fs.realpathSync(b); } catch { return false; }
}

export interface MainBaseline {
	/** 基线 `git status --porcelain`（已滤除 .amagi-worktrees/ 自身条目）。 */
	porcelain: string;
}

/** ev-20261017-cd233f：worktree 检出基线模式。head（缺省）=仓库当前 HEAD（或既有分支）；
 *  dirty-snapshot=主树工作区脏快照 commit（未提交/未跟踪全量带入，临时 index 构建、主树零扰动）。 */
export type WorktreeBaseMode = "head" | "dirty-snapshot";

export interface WorktreeSetup {
	ok: boolean;
	/** git 仓库根（ok 时必有）。 */
	root?: string;
	/** 消毒后的工作树名（ok 时必有；ev-20261007-ef07e6 起 task_submit 派发口消费——lease attach/release 与 spec 冻结事实同用此名，非原始入参）。 */
	name?: string;
	path?: string;
	branch?: string;
	/** true = 复用已存在工作树；false = 新建。 */
	reused?: boolean;
	/** ev-20260910-e3906c：true = 复用路径不是 <root>/.amagi-worktrees/<name> 约定位置——按分支反查 `git worktree list`
	 *  命中既有工作树（Leader 预建在别处）后复用，路径如实标注。 */
	reusedOutsideConvention?: boolean;
	/** 主仓工作区基线快照（worktree 操作前采集；任务结束漂移比对用）。 */
	mainBaseline?: MainBaseline;
	/** v2 批次D：创建/复用时刻的基线 commit（diff 比对与集成责任锚点）。 */
	baseCommit?: string;
	/** ev-20261017-cd233f：本轮实际生效的检出基线（dirty-snapshot=主树工作区脏快照 commit；head/缺省
	 *  不落字段——spec.workspace.base 缺席键口径，历史 specDigest 不回改）。 */
	baseMode?: WorktreeBaseMode;
	/** base 请求未生效时的差异披露（复用树/既有分支挂载——advisory，不拒单、不静默换基）。 */
	baseAdvisory?: string;
	/** ev-20261017-348337：本轮派发前分支已存在（true=挂载既有分支；提交期失败回滚不得删该分支）。 */
	branchPreexisting?: boolean;
	/** ev-20260901-f3879a：嵌套项目根提示（仓库根与项目子目录分离布局）——检测到的真实项目根绝对路径，多个以「、」连接；仅提示不改变 cwd。 */
	projectRootHint?: string;
	/** ev-20260910-cc75b2：派发 cwd 位于仓库子目录（仓库根 ≠ cwd）→ worktree 是整仓检出，项目根在树内按 cwd
	 *  相对仓库根的路径对应。仅提示不改变 cwd（自动改 cwd 是语义变化，决断留给使用者）。 */
	subdirCheckout?: {
		/** git 仓库根（= worktree 检出根；派发 cwd 是它的子目录）。 */
		repoRoot: string;
		/** 派发 cwd 相对仓库根的路径（如 "battle-simulator"；恒为相对路径、不以 .. 开头）。 */
		cwdRel: string;
		/** worktree 内的项目根绝对路径 = <worktree 路径>/<cwdRel>。 */
		projectRoot: string;
		/** 该路径在当前 worktree 中是否存在（主树未提交/未跟踪目录不在检出内 → false，如实标注）。 */
		projectRootExists: boolean;
	};
	/** v2 批次D：所有权租约（冲突拒绝时返回占用方信息）。 */
	owner?: { leaseId: string; taskId?: string; acquiredAt: number };
	/** 创建尝试可能已改变目录/分支登记；失败时不得声称 effects=none。 */
	effects?: "none" | "unknown";
	message?: string;
}

/** worktree 目录自身在主仓 status 中的条目前缀（比对时豁免——它由编排自身产生）。 */
const WT_DIR_PREFIX = ".amagi-worktrees/";

function mainPorcelain(root: string): string {
	try {
		// ev-20261017-348337：纯观测用 status 加 --no-optional-locks——否则首次 status 会机会性刷新
		// 真实 index 的 stat-cache（字节变化），与「主树零扰动/dryRun 只读」纪律冲突。
		return git(["--no-optional-locks", "status", "--porcelain"], root)
			.split("\n")
			.filter((l) => l.trim() && !l.slice(3).startsWith(WT_DIR_PREFIX))
			.join("\n");
	} catch {
		return "";
	}
}

/** 主仓工作区基线快照（worktree 任务防误伤：主仓未提交改动在任务期间被还原/新增的实战检测）。 */
export function snapshotMainBaseline(root: string): MainBaseline {
	return { porcelain: mainPorcelain(root) };
}

/**
 * 主仓漂移比对：任务结束与基线对比，工作区条目集合变化 → 告警文本；无漂移/无基线 → null。
 * 只读；条目级比对（ porcelain 行集合），不比对文件内容（行不变即视为无漂移）。
 */
export function checkMainDrift(root: string, baseline: MainBaseline | undefined): string | null {
	if (!baseline) return null;
	const now = mainPorcelain(root);
	if (now === baseline.porcelain) return null;
	const before = new Set(baseline.porcelain ? baseline.porcelain.split("\n") : []);
	const after = new Set(now ? now.split("\n") : []);
	const gone = [...before].filter((l) => !after.has(l));
	const added = [...after].filter((l) => !before.has(l));
	const parts: string[] = [];
	if (gone.length) parts.push(`消失 ${gone.length} 项: ${gone.slice(0, 5).join(" | ")}${gone.length > 5 ? " …" : ""}`);
	if (added.length) parts.push(`新增 ${added.length} 项: ${added.slice(0, 5).join(" | ")}${added.length > 5 ? " …" : ""}`);
	if (!parts.length) return null;
	return `⚠ 主仓工作区在任务期间发生变化（${parts.join("；")}）——主仓未提交改动可能被动过（如误还原/误新增），请核查`;
}

/** 工作树目录名约定（与 setupWorktree 的 `<root>/.amagi-worktrees/<name>` 同一约定；WT_DIR_PREFIX 去尾斜杠）。 */
const WT_DIR_NAME = WT_DIR_PREFIX.slice(0, -1);

/**
 * 派发 cwd 是否位于独立工作树内（ev-20260910-cfc332，只读、低频路径专用）。
 *
 * 归属判定：linked worktree（含扩展约定路径 `<root>/.amagi-worktrees/<name>` 与 Leader 预建在别处的树）内的
 * 未提交改动是该树自身的产出（本 workflow 前序阶段的合法半成品），不是「主仓未提交前置产物」；主仓工作区
 * 状态的判定只能落到主仓检出（git common dir 所属工作区）上，不能拿派发 cwd 的工作区状态冒充。
 * 命中条件（任一）：① git 判定为 linked worktree——`rev-parse --git-dir`（`<main>/.git/worktrees/<name>`）
 * 与 `--git-common-dir`（共享的 `<main>/.git`）指向不同目录；② 路径含 .amagi-worktrees/ 目录段
 * （git 探测失败/仓库元数据损坏时的约定路径兜底）。
 * 返回 false = 主检出 / 非 git 目录 / 探测失败——调用方不得把探测失败当作「在工作树内」。
 */
export function isInsideLinkedWorktree(cwd: string): boolean {
	let abs: string;
	try { abs = fs.realpathSync(cwd); } catch { abs = path.resolve(cwd); }
	if (abs.split(path.sep).includes(WT_DIR_NAME)) return true;
	try {
		const [gitDir, commonDir] = git(["rev-parse", "--git-dir", "--git-common-dir"], cwd).split("\n");
		if (!gitDir || !commonDir) return false;
		return !samePath(path.resolve(cwd, gitDir), path.resolve(cwd, commonDir));
	} catch {
		return false;
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// v2 批次D：taskId 唯一所有权 + 可审计回收（§10.1）
//  - 一个 worktree（root::name）同一时刻只有一个活跃 owner（lease）；活跃期内第二个
//    任务同名申请 → 冲突显式拒绝（fail-closed，不静默共享写范围；Leader 可换名/等待/重拆）。
//  - owner 在任务终态时释放（releaseWorktreeOwnership，幂等）；目录默认保留（异常保留
//    策略：cancelled/error 现场保留供检查），显式 cleanupWorktree 才删除（脏树 fail-closed）。
//  - 全部 acquire/release/cleanup/conflict 进审计环（worktreeAuditLog）。
// ─────────────────────────────────────────────────────────────────────────────

export interface WorktreeOwner {
	root: string;
	/** git 登记的主检出根（回收/观测用；所有权键实际按 common git dir）。 */
	mainRoot?: string;
	name: string;
	path: string;
	branch: string;
	leaseId: string;
	taskId?: string;
	baseCommit?: string;
	acquiredAt: number;
	releasedAt?: number;
	releaseReason?: string;
}

export interface WorktreeAuditEntry {
	at: number;
	action: "acquire" | "attach" | "release" | "cleanup" | "conflict";
	root: string;
	name: string;
	leaseId?: string;
	taskId?: string;
	detail?: string;
}

const wtOwners = new Map<string, WorktreeOwner>(); // key = `${canonicalCommonGitDir}::${name}`
const wtAudit: WorktreeAuditEntry[] = [];
const WT_AUDIT_MAX = 200;

/** 根路径规范化：realpath 优先（macOS /var→/private/var 符号链接统一），失败退回 resolve。 */
function canonicalRoot(root: string): string {
	try { return fs.realpathSync(root); } catch { return path.resolve(root); }
}

function commonGitDir(root: string): string {
	return canonicalRoot(path.resolve(root, git(["rev-parse", "--git-common-dir"], root)));
}

function wtKey(root: string, name: string): string {
	let identity = canonicalRoot(root);
	try { identity = commonGitDir(root); } catch { /* lint-exempt:非仓库的观测/回收调用按路径键兑底 */ }
	return `${identity}::${name}`;
}

/** 登记首项才是主检出；common-dir 可用 separate-git-dir，不能取其父目录猜主树。 */
function wtMainRoot(root: string): string {
	return canonicalRoot(listRegisteredWorktrees(root)?.[0]?.path ?? root);
}

function pathWithin(target: string, root: string): boolean {
	const rel = path.relative(root, target);
	return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
}

function pathsOverlap(a: string, b: string): boolean {
	return pathWithin(canonicalRoot(a), canonicalRoot(b)) || pathWithin(canonicalRoot(b), canonicalRoot(a));
}

function conflictingOwner(root: string, name: string, treePath: string, leaseId?: string): WorktreeOwner | undefined {
	const named = wtOwners.get(wtKey(root, name));
	return [...wtOwners.values()].find((o) => !o.releasedAt && o.leaseId !== leaseId
		&& (o === named || pathsOverlap(o.path, treePath)));
}

function logWtAudit(e: Omit<WorktreeAuditEntry, "at">): void {
	wtAudit.push({ at: Date.now(), ...e });
	if (wtAudit.length > WT_AUDIT_MAX) wtAudit.splice(0, wtAudit.length - WT_AUDIT_MAX);
}

/** 占有 worktree（同 lease 幂等；他 lease 活跃占用 → 冲突）。
 *  F2：common git dir 统一 nested dispatch 名称键；真实树路径相等或包含关系均拒绝双活跃。 */
export function acquireWorktree(root: string, name: string, leaseId: string, info: { path: string; branch: string; baseCommit?: string }): { ok: boolean; conflict?: WorktreeOwner } {
	const key = wtKey(root, name);
	const cur = wtOwners.get(key);
	if (cur && !cur.releasedAt && cur.leaseId !== leaseId) {
		logWtAudit({ action: "conflict", root, name, leaseId, detail: `被 ${cur.taskId || cur.leaseId} 占用（${new Date(cur.acquiredAt).toISOString()} 起）` });
		return { ok: false, conflict: cur };
	}
	const treeId = canonicalRoot(info.path);
	const aliased = [...wtOwners.values()].find((o) => !o.releasedAt && o.leaseId !== leaseId && pathsOverlap(o.path, treeId));
	if (aliased) {
		logWtAudit({ action: "conflict", root, name, leaseId, detail: `同树双占有拒绝（${info.path} 实体已被 ${aliased.name} 持有，lease ${aliased.leaseId}）` });
		return { ok: false, conflict: aliased };
	}
	if (cur && !cur.releasedAt && cur.leaseId === leaseId) return { ok: true }; // 幂等
	const owner: WorktreeOwner = { root: canonicalRoot(root), mainRoot: wtMainRoot(root), name, path: treeId, branch: info.branch, leaseId, baseCommit: info.baseCommit, acquiredAt: Date.now() };
	wtOwners.set(key, owner);
	logWtAudit({ action: "acquire", root, name, leaseId, detail: `${info.branch} @ ${info.path}` });
	return { ok: true };
}

/** F4：按真实树路径重占有（resume 续接用）——树身份只读探测（toplevel/分支/HEAD），新 lease 原子
 *  占有；树上已有未释放 lease（任意名/同 realpath）→ 冲突拒绝（续接不共享写范围）；不复制父 lease。 */
export function acquireWorktreeAtPath(treePath: string, leaseId: string, expected: { repoRoot: string; branch?: string }): { ok: true; owner: WorktreeOwner } | { ok: false; message: string; conflict?: WorktreeOwner } {
	try {
		const branch = git(["branch", "--show-current"], treePath);
		if (!branch.startsWith("amagi/") || (expected.branch !== undefined && branch !== expected.branch)) {
			return { ok: false, message: "[worktree 续接不适用] 分支身份已改变（或 detached），请新派任务" };
		}
		const regs = listRegisteredWorktrees(expected.repoRoot);
		const reg = regs?.find((r) => samePath(r.path, treePath));
		const blocker = reg ? reuseBlocker(reg, expected.repoRoot, regs?.[0]?.path) : "目标不在原仓工作树登记中";
		if (blocker) return { ok: false, message: `[worktree 续接不适用] ${blocker}——请新派任务` };
		const treeId = canonicalRoot(treePath), name = branch.slice("amagi/".length);
		const head = git(["rev-parse", "HEAD"], treePath);
		const acquired = acquireWorktree(expected.repoRoot, name, leaseId, { path: treeId, branch, baseCommit: head });
		if (!acquired.ok) return { ok: false, message: `[worktree 占用冲突] 续接目标 ${treeId} 被 ${acquired.conflict?.taskId || acquired.conflict?.leaseId} 活跃占用`, conflict: acquired.conflict };
		return { ok: true, owner: wtOwners.get(wtKey(expected.repoRoot, name))! };
	} catch (e) {
		return { ok: false, message: `[worktree 续接不适用] 无法验证原树身份：${String(e instanceof Error ? e.message : e).slice(0, 160)}——请新派任务` };
	}
}

export type WorktreeLeaseClaim =
	| { ok: true; newlyClaimed: boolean }
	| { ok: false; code: "worktree-lease-conflict" | "worktree-lease-inactive"; message: string };

/** 原子排他绑定：检查与写入均同步，调用者须在首个 await 前 claim。
 * 同 taskId 幂等（auto-repair/续轮合法）；其他 taskId、已释放/不存在的 lease 均 fail-closed。
 * newlyClaimed 供提交失败回滚使用：拒绝重复提交不能释放已运行的同任务所有权。 */
export function claimWorktreeLease(leaseId: string, taskId: string): WorktreeLeaseClaim {
	const o = [...wtOwners.values()].find((x) => x.leaseId === leaseId);
	if (!o || o.releasedAt) {
		return { ok: false, code: "worktree-lease-inactive", message: `lease ${leaseId} ${o ? "已释放" : "不存在"}，不能 claim` };
	}
	if (o.taskId !== undefined && o.taskId !== taskId) {
		logWtAudit({ action: "conflict", root: o.root, name: o.name, leaseId, taskId, detail: `claim 被任务 ${o.taskId} 拒绝` });
		return { ok: false, code: "worktree-lease-conflict", message: `lease ${leaseId} 已绑定任务 ${o.taskId}，拒绝任务 ${taskId}` };
	}
	if (o.taskId === taskId) return { ok: true, newlyClaimed: false };
	o.taskId = taskId;
	logWtAudit({ action: "attach", root: o.root, name: o.name, leaseId, taskId, detail: "atomic claim" });
	return { ok: true, newlyClaimed: true };
}

/** 兼容回填口也走排他原语，绝不能覆盖其他 taskId。 */
export function attachWorktreeLease(leaseId: string, taskId: string): void {
	claimWorktreeLease(leaseId, taskId);
}

/** 按 leaseId 释放（幂等、保留目录）：绑定后必须提供匹配 taskId；省略 taskId 仅能回收未绑定租约。
 * 拒单/finally 的无身份清理不得释放他人已 claim 的所有权。 */
export function releaseWorktreeLease(leaseId: string, reason: string, taskId?: string): void {
	const o = [...wtOwners.values()].find((x) => x.leaseId === leaseId && !x.releasedAt);
	if (!o || (o.taskId !== undefined && o.taskId !== taskId)) return;
	o.releasedAt = Date.now();
	o.releaseReason = reason;
	logWtAudit({ action: "release", root: o.root, name: o.name, leaseId, taskId: o.taskId, detail: reason });
}

/** 任务派发后回填 taskId（所有权 → 任务身份绑定）。 */
export function attachWorktreeTask(root: string, name: string, leaseId: string, taskId: string): void {
	const cur = wtOwners.get(wtKey(root, name));
	if (!cur || cur.releasedAt || cur.leaseId !== leaseId) return;
	claimWorktreeLease(leaseId, taskId);
}

/** 任务终态释放所有权（幂等；目录保留，回收走 cleanupWorktree）。 */
export function releaseWorktreeOwnership(root: string, name: string, leaseId: string, reason: string): void {
	const cur = wtOwners.get(wtKey(root, name));
	if (!cur || cur.releasedAt || cur.leaseId !== leaseId) return;
	cur.releasedAt = Date.now();
	cur.releaseReason = reason;
	logWtAudit({ action: "release", root, name, leaseId, taskId: cur.taskId, detail: reason });
}

/** ev-20260922-1eea28（B2）：目标仓库的已知活跃 lease 查询（进程内注册表；未释放条目）。
 *  命中条件：目标路径（canonical）是某活跃 lease 的 worktree 检出路径（owner.path）或其主仓根
 *  （owner.root）——unattended 丢弃备份通道据此拒绝并行写窗口（保守拒绝，未知外部写者不声称可排除；
 *  子代理进程内注册表为空属如实边界，宿主注入见 git-discard-backup.activeLeaseConflictFor）。 */
export function activeWorktreeLeasesFor(target: string): WorktreeOwner[] {
	const identity = canonicalRoot(target);
	const result: WorktreeOwner[] = [];
	for (const owner of wtOwners.values()) {
		if (owner.releasedAt) continue;
		// F2：mainRoot 也参与匹配（nested dispatch 的 root 是 linked tree，主仓根经 mainRoot 命中）
		if (canonicalRoot(owner.path) === identity || canonicalRoot(owner.root) === identity
			|| (owner.mainRoot !== undefined && canonicalRoot(owner.mainRoot) === identity)) result.push(owner);
	}
	return result;
}

// ── ev-20260916-07e44a：脏 worktree 强删保护（API 与 bash 两条入口共用同一检查）──

/** AMAGI_WORKTREE_DIRTY_REMOVE 回滚开关解析：protect（默认）= force 也检查脏树；legacy 仅恢复
 *  旧 force 行为（非 force 拒绝与 active owner 硬拒绝不随开关变化）。非法值回安全默认 protect。 */
export type WorktreeDirtyRemoveMode = "protect" | "legacy";

export function worktreeDirtyRemoveMode(): WorktreeDirtyRemoveMode {
	return process.env.AMAGI_WORKTREE_DIRTY_REMOVE === "legacy" ? "legacy" : "protect";
}

/** `git status --porcelain -z --untracked-files=all` 的 NUL 记录解析（只读事实采集）。
 *  -z 模式条目形如 `XY PATH\0`（XY 两字符状态码 + 空格），rename/copy 追加第二记录 `ORIG_PATH\0`——
 *  新旧两径都属于将被丢弃的范围，一并计入。带空格路径在 -z 下不加引号，原样保留（不拆词）。 */
function parsePorcelainZPaths(out: string): string[] {
	const paths: string[] = [];
	let expectOrig = false;
	for (const rec of out.split("\0")) {
		if (expectOrig) {
			expectOrig = false;
			if (rec) paths.push(rec);
			continue;
		}
		if (rec.length >= 4 && rec[2] === " ") {
			paths.push(rec.slice(3));
			if (rec[0] === "R" || rec[0] === "C") expectOrig = true;
		}
	}
	return paths;
}

/** 工作树脏态探测（只读）：`--porcelain -z --untracked-files=all` 采集将被丢弃的文件清单（含
 *  未跟踪目录内文件）。失败/非工作树根 → probeError——**绝不当作干净树**（调用方默认拒绝）。
 *  ev-20261021-fix（diting F2）：ignored=true 时追加 `--ignored=matching`——自动回滚的丢弃面
 *  判定必须计入 Git 忽略内容（ignored/valuable 类用户产物）；symlink 仍不计入丢弃面（删除链接
 *  不伤目标，单独归类——含被忽略的 node_modules 链接，不阻断保守判定外的误伤）。 */
function probeWorktreeStatus(wtPath: string, opts?: { ignored?: boolean }): { dirtyPaths: string[]; symlinkPaths?: string[] } | { probeError: string } {
	try {
		const out = gitRaw(["status", "--porcelain", "-z", "--untracked-files=all", ...(opts?.ignored ? ["--ignored=matching"] : [])], wtPath);
		// 防错树清单：目标是工作树子目录/非工作树路径时，status 会列出整个上层仓库——用 toplevel
		// 一致性校验兜住（错树清单误导力强，宁可保守拒绝）。samePath 吸收 /var↔/private/var 符号链接差异。
		const top = git(["rev-parse", "--show-toplevel"], wtPath);
		if (!samePath(top, wtPath)) return { probeError: `目标不是该路径的 git 工作树根（--show-toplevel=${top}）` };
		// ev-20260919-c53d2e：symlink 不是实内容（删除链接不伤目标），不计入丢弃面，单独归类；
		// lstat 失败保守计入 dirty（宁可误拒不漏救）。
		const all = parsePorcelainZPaths(out);
		const dirtyPaths: string[] = [];
		const symlinkPaths: string[] = [];
		for (const p of all) {
			let isLink = false;
			try { isLink = fs.lstatSync(path.join(wtPath, p)).isSymbolicLink(); } catch { isLink = false; }
			if (isLink) symlinkPaths.push(p);
			else dirtyPaths.push(p);
		}
		return symlinkPaths.length ? { dirtyPaths, symlinkPaths } : { dirtyPaths };
	} catch (e: any) {
		return { probeError: String(e?.stderr || e?.message || e).slice(0, 160) };
	}
}

/** ev-20260916-07e44a：worktree 删除前置只读检查（S1 bash 入口 / S2 终态提示 / cleanupWorktree 共用）。
 *  只读、不创建、不删除、不改状态；输出结构化事实供调用方决策。
 *  - target 为 worktree 名（约定路径 `<root>/.amagi-worktrees/<name>`，未命中按分支 `amagi/<name>`
 *    反查 `git worktree list`）或绝对路径（S1 解析 bash 参数后传入；相对路径请先由调用方解析为绝对）。
 *  - activeOwner：活跃租约（未 release）→ 硬拒绝，任何开关不可豁免。
 *  - 脏态只采该 worktree 自身状态（在其路径内跑 status），不混入主树文件。
 *  - 探测失败 → probeError 非空且 removable=false——探测失败不当干净。 */
export interface WorktreeRemovalInspection {
	/** 解析后的目标工作树绝对路径（未解析到已登记树时为约定路径候选）。 */
	path: string;
	/** 目标目录是否存在（不存在 = 无文件可丢失，removable 不因探测受阻）。 */
	exists: boolean;
	/** 活跃 owner（未释放租约占用）——删除硬拒绝依据。 */
	activeOwner?: { leaseId: string; taskId?: string; acquiredAt: number };
	/** 将被丢弃的路径清单（相对该 worktree，含未跟踪目录内文件；rename 含新旧两径；未跟踪 symlink 不计入——见 symlinkPaths）；探测失败时空清单。 */
	dirtyPaths: string[];
	/** 未跟踪 symlink 清单（不计入丢弃面——删除链接不伤目标；提示用）。 */
	symlinkPaths?: string[];
	/** git status 探测失败原因——非空时不得当作干净树（removable=false）。 */
	probeError?: string;
	/** 综合判定：无活跃 owner 且（目录不存在 或 探测成功且无任何改动）。 */
	removable: boolean;
}

export function inspectWorktreeRemoval(repoRoot: string, target: string): WorktreeRemovalInspection {
	const root = canonicalRoot(repoRoot);
	// 目标解析：绝对路径直接用；否则按名走约定路径，未命中按分支 amagi/<name> 反查既有登记
	let wtPath: string;
	let name: string | undefined;
	if (path.isAbsolute(target)) {
		wtPath = path.resolve(target);
	} else {
		name = sanitizeName(target);
		wtPath = path.join(root, ".amagi-worktrees", name);
		if (!fs.existsSync(wtPath)) {
			const reg = listRegisteredWorktrees(root)?.find((w) => !w.bare && w.branch === `amagi/${name}`);
			if (reg) wtPath = reg.path;
		}
	}
	// owner 检查（复用所有权表）：名称键命中，或任意活跃租约的登记路径与目标同路径（S1 按绝对路径调用时）
	const keyOwner = name !== undefined ? wtOwners.get(wtKey(root, name)) : undefined;
	const pathOwner = [...wtOwners.values()].find((o) => !o.releasedAt && samePath(o.path, wtPath));
	const active = (keyOwner && !keyOwner.releasedAt ? keyOwner : undefined) ?? pathOwner;
	const activeOwner = active ? { leaseId: active.leaseId, taskId: active.taskId, acquiredAt: active.acquiredAt } : undefined;
	const exists = fs.existsSync(wtPath);
	if (!exists) return { path: wtPath, exists: false, activeOwner, dirtyPaths: [], removable: !activeOwner };
	if (activeOwner) return { path: wtPath, exists: true, activeOwner, dirtyPaths: [], removable: false };
	const probe = probeWorktreeStatus(wtPath);
	if ("probeError" in probe) return { path: wtPath, exists: true, dirtyPaths: [], probeError: probe.probeError, removable: false };
	return { path: wtPath, exists: true, dirtyPaths: probe.dirtyPaths, ...(probe.symlinkPaths?.length ? { symlinkPaths: probe.symlinkPaths } : {}), removable: probe.dirtyPaths.length === 0 };
}

/** 显式回收：删除工作树目录（fail-closed：活跃 owner 硬拒绝；脏树/探测失败默认拒绝——07e44a 起
 *  force 也不例外，legacy 开关仅恢复旧 force 行为；分支保留供审计回溯）。 */
export function cleanupWorktree(root: string, name: string, opts?: { force?: boolean }): { ok: boolean; message: string } {
	const safe = sanitizeName(name);
	const insp = inspectWorktreeRemoval(root, safe);
	if (insp.activeOwner) return { ok: false, message: `[worktree 回收拒绝] ${safe} 仍被任务 ${insp.activeOwner.taskId || insp.activeOwner.leaseId} 活跃占用——先等任务终态或 cancel` };
	if (!insp.exists) {
		logWtAudit({ action: "cleanup", root, name: safe, taskId: wtOwners.get(wtKey(root, safe))?.taskId, detail: "目录不存在（幂等）" });
		return { ok: true, message: `[worktree 回收] ${insp.path} 不存在（幂等）` };
	}
	const mode = worktreeDirtyRemoveMode();
	// force 不是丢弃授权：protect（默认）下脏树/探测失败一律拒绝；legacy 仅回 force 的旧行为
	if (insp.probeError && (mode === "protect" || !opts?.force)) {
		return { ok: false, message: `[worktree 回收拒绝] ${insp.path} 状态探测失败（${insp.probeError}）——未按干净树处理，已拒绝回收；请人工核查目录内容后再回收` };
	}
	if (insp.dirtyPaths.length && (mode === "protect" || !opts?.force)) {
		const list = insp.dirtyPaths.slice(0, 20).join(", ") + (insp.dirtyPaths.length > 20 ? ` …` : "");
		const linkNote = insp.symlinkPaths?.length ? `（另有 ${insp.symlinkPaths.length} 个 symlink 不计入丢弃面：${insp.symlinkPaths.slice(0, 5).join(", ")}——删除链接不伤目标）` : "";
		const guide = mode === "protect"
			? `先把改动显式回流或保全（集成责任在 Leader：在树内 commit 到分支 amagi/${safe} 或导出 patch），再回收；force 不再跳过脏树检查`
			: `先审查 diff 合并（集成责任在 Leader）；确认丢弃用 force`;
		return { ok: false, message: `[worktree 回收拒绝] ${insp.path} 有未提交改动/未跟踪文件 ${insp.dirtyPaths.length} 处——将丢弃: ${list}${linkNote}；${guide}` };
	}
	try {
		git(opts?.force ? ["worktree", "remove", "--force", insp.path] : ["worktree", "remove", insp.path], path.resolve(root));
		logWtAudit({ action: "cleanup", root, name: safe, taskId: wtOwners.get(wtKey(root, safe))?.taskId, detail: `已删除（分支 amagi/${safe} 保留供回溯）` });
		return { ok: true, message: `[worktree 回收] 已删除 ${insp.path}（分支 amagi/${safe} 保留供审计回溯；如需删分支 git branch -D amagi/${safe}）` };
	} catch (e: any) {
		return { ok: false, message: `[worktree 回收失败] ${String(e?.stderr || e?.message || e).slice(0, 200)}` };
	}
}

/** 所有权快照（观测/测试）。 */
export function worktreeOwnership(): WorktreeOwner[] {
	return [...wtOwners.values()].map((o) => ({ ...o }));
}

/** 审计环快照（可审计清理/回收策略的证据面）。 */
export function worktreeAuditLog(): WorktreeAuditEntry[] {
	return [...wtAudit];
}

/** 测试隔离用复位。 */
export function resetWorktreeForTest(): void {
	wtOwners.clear();
	wtAudit.length = 0;
}

/** 完整 patch 产物（git diff HEAD；只读，失败返回空串由调用方如实标注）。 */
/** base=创建/复用时记录的检出基线（baseCommit）：diff 以它为锚，子 Agent 在树内的 commit 也计入
 *  本轮净增量（ev-20261017-cd233f：旧口径 diff HEAD——树内一旦提交，净增量从摘要/patch 中消失）。
 *  未传 base 维持 HEAD 口径（无基线记录的历史调用方）。 */
export function worktreePatch(wtPath: string, base?: string): string {
	try {
		return git(["diff", base || "HEAD"], wtPath);
	} catch {
		return "";
	}
}

/** 项目根标记文件（任一存在于某目录即视为项目根候选；ev-20260901-f3879a 嵌套布局检测用）。 */
const PROJECT_ROOT_MARKERS = ["package.json", "pnpm-workspace.yaml", "go.mod", "Cargo.toml", "pyproject.toml"] as const;

/**
 * 嵌套项目根检测（ev-20260901-f3879a）：worktree 根没有任何项目标记，而某一级子目录有 →
 * 真实项目根在 <worktree>/<子目录>/。实战事故：仓库根 battle-sim/ 下项目 battle-simulator/，
 * 使用者在 worktree 根跑 pnpm install 向上命中主仓 workspace 装错位置、git diff 用无前缀路径
 * 得空输出、写盘落错位置。只读检测；返回检测到的项目根绝对路径（名称序），无嵌套布局 → undefined。
 */
export function detectNestedProjectRoots(wtPath: string): string[] | undefined {
	const hasMarker = (d: string) => PROJECT_ROOT_MARKERS.some((m) => fs.existsSync(path.join(d, m)));
	if (hasMarker(wtPath)) return undefined;
	let ents: fs.Dirent[];
	try { ents = fs.readdirSync(wtPath, { withFileTypes: true }); } catch { return undefined; }
	const hits = ents
		.filter((e) => e.isDirectory() && !e.name.startsWith("."))
		.filter((e) => hasMarker(path.join(wtPath, e.name)))
		.map((e) => path.join(wtPath, e.name));
	return hits.length ? hits.sort() : undefined;
}

/** git worktree 登记项（`git worktree list --porcelain` 解析；ev-20260910-e3906c 按分支反查复用用）。 */
export interface RegisteredWorktree {
	path: string;
	/** 已检出分支名（已去 refs/heads/ 前缀）；detached/bare 登记无此字段。 */
	branch?: string;
	detached: boolean;
	bare: boolean;
	locked?: string;
	prunable?: string;
}

/** 列出本仓库工作树登记（只读）。失败/超时 → undefined——调用方须与「无命中」区分：
 *  探测不可用时不得当作「没有同名工作树」，只能在创建失败后用 git 原文路径兜底。 */
export function listRegisteredWorktrees(root: string): RegisteredWorktree[] | undefined {
	let out: string;
	try { out = git(["worktree", "list", "--porcelain"], root); } catch { return undefined; }
	const entries: RegisteredWorktree[] = [];
	let cur: RegisteredWorktree | undefined;
	const flush = (): void => { if (cur) { entries.push(cur); cur = undefined; } };
	for (const raw of out.split("\n")) {
		const line = raw.trim();
		if (!line) { flush(); continue; }
		const sp = line.indexOf(" ");
		const key = sp === -1 ? line : line.slice(0, sp);
		const val = sp === -1 ? "" : line.slice(sp + 1);
		if (key === "worktree") { flush(); cur = { path: val, detached: false, bare: false }; continue; }
		if (!cur) continue;
		if (key === "branch") cur.branch = val.replace(/^refs\/heads\//, "");
		else if (key === "detached") cur.detached = true;
		else if (key === "bare") cur.bare = true;
		else if (key === "locked") cur.locked = val;
		else if (key === "prunable") cur.prunable = val;
	}
	flush();
	return entries;
}

/** git「分支已被工作树占用」错误里的路径提取（list 探测失败/时序竞态时仍能给出 cwd= 建议，不透传裸原文）。 */
function branchInUsePath(stderr: string): string | undefined {
	return stderr.match(/is already used by worktree at '([^']+)'/)?.[1];
}

/** 反查命中的工作树不可复用时的具体原因（无阻碍 → undefined）；不返回裸 git 原文。
 *  mainWorktreePath：仓库主工作区路径（`git worktree list` 首条恒为主工作区）。从 linked worktree
 *  内派发时 root=该 linked 树，主检出会被 samePath(root) 漏过——分支被主检出占用时「复用」会把
 *  子 Agent 放到主检出上作业（隔离语义不成立），不得自动复用（ed-20260910 diting m-3）。 */
function reuseBlocker(reg: RegisteredWorktree, root: string, mainWorktreePath?: string): string | undefined {
	if (reg.bare) return "该登记是 bare 仓库（无工作区可派发）";
	if (samePath(reg.path, root)) return "该路径是当前派发所在的检出（非独立工作树，worktree 参数的隔离语义不成立）";
	if (mainWorktreePath && samePath(reg.path, mainWorktreePath)) return "该路径是仓库主检出（分支被主检出占用，非独立工作树，隔离语义不成立）";
	if (reg.prunable !== undefined) return `该工作树已被标记可清理（prunable${reg.prunable ? `: ${reg.prunable}` : ""}）`;
	if (!fs.existsSync(reg.path)) return "工作树目录不存在（已被手工删除/移动）";
	try {
		const wtRoot = git(["rev-parse", "--show-toplevel"], reg.path);
		if (!samePath(wtRoot, reg.path)) return "该目录不是本仓库工作树根";
		if (commonGitDir(reg.path) !== commonGitDir(root)) return "common git dir 不属于原仓库";
		if (canonicalRoot(path.resolve(reg.path, git(["rev-parse", "--git-dir"], reg.path))) === commonGitDir(root)) return "该路径是主检出（非 linked worktree）";
		if (reg.detached || !reg.branch || git(["branch", "--show-current"], reg.path) !== reg.branch) return "实际分支与工作树登记不一致";
		git(["rev-parse", "HEAD"], reg.path); // 基线不能用主树 HEAD 兑底
	} catch { return "git 无法在该目录解析仓库（工作树元数据损坏）"; }
	return undefined;
}

/** 同名工作树已存在但不适合自动复用时的建议文案：含「同名工作树已存在于 <path>」与「改用 cwd=<path> 派发」两项具体处置。 */
function registryConflictMessage(reg: RegisteredWorktree, branch: string, wtPath: string, reason: string): string {
	return `[worktree 冲突] 同名工作树已存在于 ${reg.path}（分支 ${branch} 已被检出，不在扩展约定路径 ${wtPath}；不适用的原因：${reason}）——可改用 cwd=${reg.path} 派发（在该既有工作树内作业；若该路径即当前检出，worktree 参数已无隔离意义，请直接去掉 worktree 参数派发）；如该路径不可用，先 git worktree prune 清理登记后重试，或换 worktree 名。`;
}

/**
 * 建/复用工作树。失败诚实返回 message（非 git 仓库/路径占用/git 命令失败），不抛错。
 * v2 批次D：opts.leaseId 传入时随创建/复用原子占有（活跃冲突 → 显式拒绝不共享写范围）；
 * 并记录 baseCommit（集成责任锚点：diff 与合并以此基线为准）。
 * ev-20260910-e3906c：约定路径未命中时按分支反查 `git worktree list` 复用既有工作树；不可复用则给 cwd= 建议。
 * ev-20260910-cc75b2：仓库根 ≠ 派发 cwd 时附 subdirCheckout（整仓检出定位，供回流/任务书显式提示）。
 */
export function setupWorktree(cwd: string, name: string, opts?: { leaseId?: string; base?: WorktreeBaseMode }): WorktreeSetup {
	const plan = probeWorktreePlan(cwd, name);
	if (!plan.ok) return { ok: false, message: plan.message, effects: "none" };
	if (plan.activeLease && plan.activeLease.leaseId !== opts?.leaseId) {
		const message = `[worktree 占用冲突] ${plan.plannedPath} 正被任务 ${plan.activeLease.taskId || plan.activeLease.leaseId} 活跃使用中`;
		logWtAudit({ action: "conflict", root: plan.root!, name: plan.name!, leaseId: opts?.leaseId ?? "", detail: message });
		return { ok: false, message, effects: "none", owner: plan.owner };
	}
	const root = plan.root!, safe = plan.name!, wtPath = plan.plannedPath!, branch = plan.branch!;
	const mainBaseline = snapshotMainBaseline(root);
	let effects: "none" | "unknown" = "none";
	let baseMode: WorktreeBaseMode | undefined;
	let baseAdvisory: string | undefined;
	try {
		let branchPreexisting = plan.reused === true || plan.branchPreexisting === true;
		if (!plan.reused) {
			effects = "unknown"; // mkdir/add 失败可能留下目录/分支；保留现场
			fs.mkdirSync(path.dirname(wtPath), { recursive: true });
			let branchExists = false;
			try { git(["rev-parse", "--verify", "--quiet", `refs/heads/${branch}`], root); branchExists = true; } catch { /* lint-exempt:未存在分支按新分支创建 */ }
			// ev-20261017-cd233f：base=dirty-snapshot 且新建分支时，先冻结主树工作区为悬空快照 commit，
			//  再以 -b <branch> <snapCommit> 建树——分支锚定快照（防 GC），baseCommit=树自身 HEAD 自动取到快照。
			//  顺序先快照后建树：快照失败时零树零分支（effects 可诚实 none，仅剩可 GC 悬空对象）。
			let startCommit: string | undefined;
			if (opts?.base === "dirty-snapshot") {
				if (branchExists) {
					baseAdvisory = `[worktree base] 请求 base=dirty-snapshot，但分支 ${branch} 已存在——挂载既有分支（base=该分支 HEAD，主树脏内容不带入）；需要脏基线请换 worktree 名`;
				} else {
					const snap = createWorktreeBaseSnapshot(root);
					if (!snap.ok) {
							return { ok: false, effects: "none", message: `[worktree 脏快照失败] 主树工作区快照创建失败：${snap.reason}——未建树未建分支（fail-closed，不回落请求 cwd/HEAD 检出）` };
					}
					startCommit = snap.commit;
					baseMode = "dirty-snapshot";
				}
			}
			if (branchExists) git(["worktree", "add", wtPath, branch], root);
			else if (startCommit !== undefined) git(["worktree", "add", wtPath, "-b", branch, startCommit], root);
			else git(["worktree", "add", wtPath, "-b", branch], root);
		} else if (opts?.base === "dirty-snapshot") {
			baseAdvisory = `[worktree base] 请求 base=dirty-snapshot，但复用既有工作树——base=树自身 HEAD（复用不换基，不静默重置）；需要脏基线请换 worktree 名`;
		}
		// add/计划间可能有外部竞态；落盘后仍验证真实登记/分支/common-dir。
		const regs = listRegisteredWorktrees(root);
		const reg = regs?.find((r) => samePath(r.path, wtPath));
		const blocker = reg ? reuseBlocker(reg, root, regs?.[0]?.path) : "无法确认目标工作树登记";
		if (blocker || reg?.branch !== branch) throw new Error(blocker ?? "工作树分支身份已变化");
		// 三成功路径均取实际目标树 HEAD，尤其挂载落后于主树的已有分支。
		const baseCommit = git(["rev-parse", "HEAD"], wtPath);
		if (opts?.leaseId) {
			const acq = acquireWorktree(root, safe, opts.leaseId, { path: canonicalRoot(wtPath), branch, baseCommit });
			if (!acq.ok) return { ok: false, message: `[worktree 占用冲突] ${wtPath} 被 ${acq.conflict?.taskId || acq.conflict?.leaseId} 活跃占用`, effects, owner: acq.conflict };
		}
		const s: WorktreeSetup = { ok: true, root, name: safe, path: canonicalRoot(wtPath), branch, reused: plan.reused, reusedOutsideConvention: plan.reusedOutsideConvention, mainBaseline, baseCommit, branchPreexisting, effects,
			...(baseMode !== undefined ? { baseMode } : {}), ...(baseAdvisory !== undefined ? { baseAdvisory } : {}) };
		const rel = path.relative(root, canonicalRoot(cwd));
		if (rel && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel)) {
			const projectRoot = path.join(s.path!, rel);
			s.subdirCheckout = { repoRoot: root, cwdRel: rel, projectRoot, projectRootExists: fs.existsSync(projectRoot) };
		}
		const nested = detectNestedProjectRoots(s.path!)?.filter((d) => !s.subdirCheckout || !samePath(d, s.subdirCheckout.projectRoot));
		if (nested?.length) s.projectRootHint = nested.join("、");
		return s;
	} catch (e: any) {
		if (opts?.leaseId) releaseWorktreeLease(opts.leaseId, "setup failed");
		const stderr = String(e?.stderr || e?.message || e).slice(0, 300), usedAt = branchInUsePath(stderr);
		return { ok: false, effects, message: usedAt
			? `[worktree 冲突] 同名工作树已存在于 ${usedAt}——可改用 cwd=${usedAt} 派发；不回落请求 cwd`
			: `[worktree 创建失败] git worktree add/身份探测报错: ${stderr}` };
	}
}

export interface WorktreePlanProbe {
	ok: boolean;
	message?: string;
	owner?: WorktreeOwner;
	root?: string;
	name?: string;
	plannedPath?: string;
	branch?: string;
	baseCommit?: string;
	/** 创建/复用计划时刻分支是否已存在（ev-20261017-348337：提交期失败回滚据实决定是否删分支）。 */
	branchPreexisting?: boolean;
	existsAtConvention?: boolean;
	reused?: boolean;
	reusedOutsideConvention?: boolean;
	activeLease?: { leaseId: string; taskId?: string; acquiredAt: number };
}

/** 创建与 dryRun 共用只读计划。通过不承诺免于外部竞态或 git 写入失败。 */
export function probeWorktreePlan(cwd: string, name: string): WorktreePlanProbe {
	if (!worktreeEnabled()) return { ok: false, message: "[worktree 已禁用] AMAGI_WORKTREE_OFF=1 生效中；去掉 worktree 参数" };
	const safe = sanitizeName(name), branch = `amagi/${safe}`;
	if (!safe) return { ok: false, message: `[worktree 名非法] "${name}" 消毒后为空或纯点段` };
	try { git(["check-ref-format", `refs/heads/${branch}`], cwd); } catch { /* lint-exempt:非法 ref 提前拒绝 */
		return { ok: false, message: `[worktree 名非法] "${name}" → ${safe} 不是合法 git ref 名` };
	}
	let root: string;
	try { root = canonicalRoot(git(["rev-parse", "--show-toplevel"], cwd)); } catch { /* lint-exempt:非 git 目录只读拒绝 */
		return { ok: false, message: `[worktree 不适用] ${cwd} 不是 git 仓库` };
	}
	const convention = path.join(root, ".amagi-worktrees", safe);
	try {
		const regs = listRegisteredWorktrees(root);
		if (!regs) return { ok: false, message: "[worktree 冲突] 无法验证 git worktree 登记；预检不能证明可创建/复用" };
		const container = path.dirname(convention);
		try {
			if (!fs.lstatSync(container).isDirectory() || canonicalRoot(container) !== container) return { ok: false, message: `[worktree 冲突] 工作树容器 ${container} 非实体目录（符号链接/真实路径不一致）` };
		} catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
		let reg: RegisteredWorktree | undefined;
		const exists = fs.existsSync(convention);
		if (exists) {
			reg = regs.find((r) => samePath(r.path, convention));
			if (!reg || reg.branch !== branch) return { ok: false, message: `[worktree 冲突] ${convention} 已存在但不是本仓库登记的 ${branch} 工作树` };
		} else {
			try { fs.lstatSync(convention); return { ok: false, message: `[worktree 冲突] ${convention} 已被失效链接占用` }; } catch (e) {
				if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
			}
			reg = regs.find((r) => !r.bare && r.branch === branch);
		}
		if (reg) {
			const blocker = reuseBlocker(reg, root, regs[0]?.path);
			if (blocker) return { ok: false, message: registryConflictMessage(reg, branch, convention, blocker) };
		}
		const plannedPath = reg ? canonicalRoot(reg.path) : convention;
		const active = conflictingOwner(root, safe, plannedPath);
		let baseCommit: string;
		let branchPreexisting = false;
		if (reg) { baseCommit = git(["rev-parse", "HEAD"], plannedPath); branchPreexisting = true; }
		else {
			try { baseCommit = git(["rev-parse", "--verify", `refs/heads/${branch}`], root); branchPreexisting = true; } catch { /* lint-exempt:无旧分支时从当前 HEAD 切出 */
				baseCommit = git(["rev-parse", "HEAD"], root);
			}
		}
		return { ok: true, root, name: safe, plannedPath, branch, baseCommit, branchPreexisting, existsAtConvention: exists, reused: !!reg,
			reusedOutsideConvention: !!reg && !samePath(plannedPath, convention),
			...(active ? { owner: active, activeLease: { leaseId: active.leaseId, taskId: active.taskId, acquiredAt: active.acquiredAt } } : {}) };
	} catch (e) {
		return { ok: false, message: `[worktree 冲突] 无法验证目标身份/基线：${String(e instanceof Error ? e.message : e).slice(0, 180)}` };
	}
}

/** F9：未建树只能证明基线里的普通文件/目录存在；不拿主树未提交文件或链接落点作目标实存证据。
 *  baseCommit 是计划检出的真实提交（可能是旧 amagi 分支而非主 HEAD）。纯只读，未知不冒称通过。 */
export function probeWorktreeInputAtBase(plan: WorktreePlanProbe, relativePath: string): { tracked: boolean; reason?: string } {
	try {
		if (!plan.root || !plan.baseCommit) return { tracked: false, reason: "基线不可读" };
		if (!relativePath) return { tracked: true }; // 检出根本身
		const entries = gitRaw(["ls-tree", "-z", plan.baseCommit, "--", `:(literal)${relativePath}`], plan.root).split("\0");
		const entry = entries.find((e) => e.slice(e.indexOf("\t") + 1) === relativePath);
		if (!entry) return { tracked: false, reason: "基线不含该路径（主树未跟踪/新增未提交文件不会检出）" };
		if (!/^(100644|100755|040000) (blob|tree) /.test(entry)) return { tracked: false, reason: "基线为链接或子模块，目标实存尚未验证" };
		return { tracked: true };
	} catch (e) { return { tracked: false, reason: `基线探测失败：${String(e instanceof Error ? e.message : e).slice(0, 160)}` }; }
}

/** ev-20261017-cd233f：主树工作区脏快照 commit——worktree base=dirty-snapshot 的检出基线。
 *  机制复用 createEvidenceSnapshot（临时 index → read-tree HEAD → add -A → write-tree → commit-tree
 *  -p HEAD 悬空 commit）；主树零扰动（不动真 index、不 stash、不 checkout、不动 HEAD、不建分支）。
 *  pathspec 排除 .amagi-worktrees——兄弟树目录会被收进快照（gitlink/嵌套 tree 污染，repro B9 证据）。
 *  失败如实返回 reason：仅剩可 GC 的悬空对象，未建树未建分支（effects 可诚实 none）。 */
const WT_SNAP_IDENTITY = {
	GIT_AUTHOR_NAME: "amagi-worktree-base",
	GIT_AUTHOR_EMAIL: "amagi@worktree.base.invalid",
	GIT_COMMITTER_NAME: "amagi-worktree-base",
	GIT_COMMITTER_EMAIL: "amagi@worktree.base.invalid",
};

export function createWorktreeBaseSnapshot(root: string): { ok: true; commit: string } | { ok: false; reason: string } {
	let tmpRoot: string;
	try { tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), "amagi-wtbase-")); }
	catch (e: any) { return { ok: false, reason: `临时目录创建失败: ${String(e?.message || e).slice(0, 120)}` }; }
	const idxEnv = { GIT_INDEX_FILE: path.join(tmpRoot, "index") };
	try {
		snapGitStage("read-tree", ["read-tree", "HEAD"], root, idxEnv);
		snapAddWorkingTree(root, idxEnv);
		const tree = snapGitStage("write-tree", ["write-tree"], root, idxEnv).trim();
		const commit = snapGitStage("commit-tree", ["commit-tree", tree, "-p", "HEAD", "-m", "amagi worktree dirty-snapshot base (ev-20261017-cd233f)"], root, WT_SNAP_IDENTITY).trim();
		return { ok: true, commit };
	} catch (e: any) {
		return { ok: false, reason: snapFailureReason(e) };
	} finally {
		try { fs.rmSync(tmpRoot, { recursive: true, force: true }); } catch { /* lint-exempt:临时 index 清理尽力而为，系统 tmp 回收兑底 */ }
	}
}

/** ev-20261017-348337：提交期失败回滚——本轮新建的 worktree 且未产生任何写入时，删除工作树与
 *  （本轮新建的）分支，effects 可诚实 none。复用树/脏树/探测失败/仍有活跃占用 → 不删（保守保留
 *  现场，effects=unknown）。调用前须先释放本 lease（active owner 硬拒绝会使 removable=false）。
 *  setupWorktree 自身失败的半成品现场不经本函数（无法证明创建状态，仍按原语义保留）。
 *  ev-20261021-fix（diting F2）收严「零写入」证明（自动删除工作树只允许在可证明创建事务无用户产物时）：
 *   1. 必须携带 creationBaseCommit（创建时基线）；缺失即无法证明零提交 → 保留现场；
 *   2. 树当前 HEAD ≠ 创建基线 → 已有提交（含任务/用户 commit）→ 保留现场，不删分支；
 *   3. 丢弃面探测计入 ignored 内容（--ignored=matching；symlink 不计——删链接不伤目标）——
 *      「git status 干净」不得推出「零写入」；探测失败同样保留。
 *  仅凭本函数不能证明「尚未派发」——调用方（task-facets）另行把回滚限制在派发尝试之前。 */
export function rollbackWorktreeCreation(root: string, name: string, opts?: { deleteBranch?: boolean; creationBaseCommit?: string }): { ok: boolean; message: string } {
	const safe = sanitizeName(name);
	if (opts?.creationBaseCommit === undefined) {
		logWtAudit({ action: "cleanup", root, name: safe, detail: "回滚跳过：缺创建基线，不能证明零提交（保留现场）" });
		return { ok: false, message: `[worktree 回滚跳过] ${safe} 缺创建基线（creationBaseCommit）——无法证明零提交，保留现场供检查` };
	}
	const insp = inspectWorktreeRemoval(root, safe);
	if (insp.activeOwner) return { ok: false, message: `[worktree 回滚跳过] ${insp.path} 仍被任务 ${insp.activeOwner.taskId || insp.activeOwner.leaseId} 活跃占用——保留现场` };
	if (insp.exists) {
		// F2①：HEAD 与创建基线一致才可能零提交（提交即移动 HEAD，用户产物可能只存于分支引用）。
		let head: string | undefined;
		try { head = git(["rev-parse", "HEAD"], insp.path); } catch { head = undefined; /* lint-exempt:HEAD 探测失败按不可证明零提交保留现场 */ }
		if (head === undefined) {
			return { ok: false, message: `[worktree 回滚跳过] ${insp.path} HEAD 探测失败——不能证明零提交，保留现场供检查` };
		}
		if (head !== opts.creationBaseCommit) {
			return { ok: false, message: `[worktree 回滚跳过] ${insp.path} HEAD 已从创建基线 ${opts.creationBaseCommit.slice(0, 8)} 移动到 ${head.slice(0, 8)}（存在提交/用户产物）——保留现场与分支 amagi/${safe} 供检查` };
		}
		// F2②：丢弃面计入 ignored 内容——status 干净不等于零写入。
		const loss = probeWorktreeStatus(insp.path, { ignored: true });
		if ("probeError" in loss) {
			return { ok: false, message: `[worktree 回滚跳过] ${insp.path} 内容探测失败（${loss.probeError.slice(0, 120)}）——不能证明零写入，保留现场供检查` };
		}
		if (loss.dirtyPaths.length > 0) {
			const list = loss.dirtyPaths.slice(0, 10).join(", ") + (loss.dirtyPaths.length > 10 ? ` …` : "");
			return { ok: false, message: `[worktree 回滚跳过] ${insp.path} 有未提交/未跟踪/ignored 内容 ${loss.dirtyPaths.length} 处（含 Git 忽略内容）：${list}——不能证明零写入，保留现场供检查` };
		}
	}
	if (insp.exists) {
		const rm = cleanupWorktree(root, safe);
		if (!rm.ok) return { ok: false, message: rm.message };
	}
	if (opts?.deleteBranch) {
		try { git(["branch", "-D", `amagi/${safe}`], root); }
		catch (e: any) {
			return { ok: true, message: `[worktree 回滚] 工作树已删除，但分支 amagi/${safe} 删除失败（${String(e?.stderr || e?.message || e).slice(0, 120)}）——分支保留供核查` };
		}
	}
	logWtAudit({ action: "cleanup", root, name: safe, detail: `提交期失败回滚（新建树零写入：HEAD=创建基线，含 ignored 探测无丢弃面；分支${opts?.deleteBranch ? "一并删除" : "保留（派发前已存在）"}）` });
	return { ok: true, message: `[worktree 回滚] 本轮新建的 ${insp.path}${opts?.deleteBranch ? ` 与分支 amagi/${safe}` : ""} 已删除（未产生任何写入，effects=none）；修复后重提将全新创建` };
}

/** ev-20261017-348337：worktree 模式下声明输入路径的统一解析与可达性探测。
 *  解析基准统一为调用者 cwd（与 taskFile 一致）：相对路径先解析为绝对路径（callerAbs），再换算
 *  工作树内对应位置（treeAbs，仅 callerAbs 落在仓库根内时存在），最后探测可达性——新树查基线
 *  检出（probeWorktreeInputAtBase）、复用树查树内磁盘、dirty-snapshot 基线按主树实存（快照
 *  内容=主树工作区）。任一位置可达即通过；两处皆无才拒单（missing）。纯只读，未知不冒称通过。 */
export interface WorktreeInputProbe {
	/** 声明形态（原样回显）。 */
	declared: string;
	/** 调用者 cwd 基准绝对路径（统一解析基准）。 */
	callerAbs: string;
	/** 工作树内对应绝对路径（callerAbs 在仓库根内时可换算）。 */
	treeAbs?: string;
	/** callerAbs 相对仓库根的路径（treeAbs 的换算依据，回显用）。 */
	treeRel?: string;
	/** tree=工作树内可达；caller=仅调用者侧实存（子 Agent 跨树绝对路径读取）；missing=两处皆无。 */
	reachable: "caller" | "tree" | "missing";
	/** reachable=tree 的依据：base=新树基线检出；reused-disk=复用树磁盘实存；snapshot=脏快照基线（Git 可见主树实存）。 */
	treeBasis?: "base" | "reused-disk" | "snapshot";
	/** ev-20261021-fix（diting F5）：路径在主树实存但被 .gitignore 覆盖——不入 dirty-snapshot 快照
	 *  （git add -A 遵守 ignore，不强制收敏感内容），子 Agent 以 callerAbs 跨树读取。 */
	ignoredInSnapshot?: boolean;
	/** ev-20261021-fix（diting F3）：路径在仓库根外但调用者侧实存——无树内对应，跨树读取。 */
	outsideRepo?: boolean;
}

/** 主树路径是否被 Git 忽略（check-ignore -q：exit 0=忽略；非 0/异常=不忽略或不可判——保守按
 *  不入快照处理，不虚称树内可达）。只在 dirty-snapshot 基线判定时调用（ev-20261021-fix diting F5）。 */
function isMainTreeGitIgnored(root: string, absPath: string): boolean {
	try {
		git(["check-ignore", "--quiet", "--", absPath], root);
		return true; // exit 0 = 命中 ignore 规则
	} catch { return false; /* lint-exempt:check-ignore 非 0（不忽略）或不可判——保守按不入快照处理 */ }
}

export function probeWorktreeDeclaredInput(
	plan: WorktreePlanProbe,
	callerCwd: string,
	declared: string,
	opts?: { base?: WorktreeBaseMode },
): WorktreeInputProbe {
	const callerAbs = path.resolve(callerCwd, declared);
	const probe: WorktreeInputProbe = { declared, callerAbs, reachable: "missing" };
	const root = plan.root, planned = plan.plannedPath;
	const callerExists = fs.existsSync(callerAbs);
	if (!root || !planned) return probe;
	// 与 canonical root 同口径比对（macOS /var→/private/var 符号链接前缀差异）：存在则 realpath，
	// 不存在则退回「调用者 cwd 的 realpath + 相对段」——两例都不得把界内路径误判为仓库根外。
	const rel = path.relative(canonicalRoot(root), canonicalCallerPath(callerAbs, callerCwd));
	if (rel === ".." || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) {
		// ev-20261021-fix（diting F3）：仓库根外无树内对应，但**不能据此流称不存在**——调用者侧
		// 实存即合法跨树只读输入（deny/授权由调用方独立校验），不存在才 missing。
		if (callerExists) { probe.reachable = "caller"; probe.outsideRepo = true; }
		return probe;
	}
	probe.treeRel = rel;
	probe.treeAbs = path.join(planned, rel);
	if (plan.reused) {
		if (fs.existsSync(probe.treeAbs)) { probe.reachable = "tree"; probe.treeBasis = "reused-disk"; }
		else if (callerExists) probe.reachable = "caller";
		return probe;
	}
	if (opts?.base === "dirty-snapshot") {
		// ev-20261021-fix（diting F5）：快照=git add -A 的 Git 可见内容（遵守 .gitignore、排除
		// .amagi-worktrees）——主树实存**不等于**已入快照：被 ignore 覆盖的路径不入树（不强制收敏感
		// 内容），走调用者侧跨树读取（caller）；界内且 Git 可见实存才可声称 tree/snapshot。
		if (!callerExists) return probe;
		if (isMainTreeGitIgnored(root, callerAbs)) { probe.reachable = "caller"; probe.ignoredInSnapshot = true; }
		else { probe.reachable = "tree"; probe.treeBasis = "snapshot"; }
		return probe;
	}
	const atBase = probeWorktreeInputAtBase(plan, rel);
	if (atBase.tracked) { probe.reachable = "tree"; probe.treeBasis = "base"; }
	else if (callerExists) probe.reachable = "caller";
	return probe;
}

/** ev-20261017-348337：worktree 模式下声明产物路径的冻结时换算——按调用者 cwd 解析为绝对路径后，
 *  仓库根内路径换算为工作树内形态（相对树根；子 Agent cwd=树根，resolve 即正确落点）；界外保持
 *  绝对（工作区外产物仍须 scope.write/reportFiles 声明）。outputs 语义=子进程在工作树内落产物
 *  （隔离与回流的基础），换算只改落点表达，不改变声明意图。 */
export function convertWorktreeDeclaredOutput(
	plan: WorktreePlanProbe,
	callerCwd: string,
	declared: string,
): { declared: string; callerAbs: string; childPath: string } {
	const callerAbs = path.resolve(callerCwd, declared);
	const root = plan.root, planned = plan.plannedPath;
	if (!root || !planned) return { declared, callerAbs, childPath: declared };
	const rel = path.relative(canonicalRoot(root), canonicalCallerPath(callerAbs, callerCwd));
	if (rel === ".." || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) {
		return { declared, callerAbs, childPath: callerAbs };
	}
	return { declared, callerAbs, childPath: rel };
}

/** 调用者侧路径的 canonical 形态（与 canonicalRoot 同口径比对用）：存在则 realpath；
 *  不存在（拒单披露/产物尚未落盘）则退回 realpath(callerCwd)+相对段，不因符号链接前缀差异误判越界。 */
function canonicalCallerPath(abs: string, callerCwd: string): string {
	try { return fs.realpathSync(abs); } catch { /* lint-exempt:目标不存在时退回 cwd 基准拼接，下一分支处理 */
		try { return path.join(fs.realpathSync(callerCwd), path.relative(callerCwd, abs)); } catch { return path.resolve(abs); /* lint-exempt:cwd 不可 realpath 时按 resolve 归一，探测面如实降级 */ }
	}
}

/** 实际依赖连接核对：visibility 切换拒绝残留外链，不擅自删用户依赖。
 *  portable 供读取复用；tool-enforced 文件写按真实落点执法。guarded shell 不是 OS 沙箱。 */
export function prepareWorktreeDependencies(repoRoot: string, wtPath: string, visibility: "portable" | "main-tree" | "unknown", projectSubdir?: string, dryRun = false): string {
	const externalLinks: string[] = [], externalPackageLinks: string[] = [];
	const packages = new Set<string>([""]);
	const diagnostics: string[] = [];
	let visited = 0;
	const scanLimit = 10000, depthLimit = 12;
	const inspectModules = (dir: string, scoped = false): void => {
		for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
			const item = path.join(dir, entry.name);
			if (entry.isSymbolicLink()) {
				if (!fs.existsSync(item)) diagnostics.push(`${path.relative(wtPath, item)}: 损坏的链接，未替换`);
				else if (!pathWithin(canonicalRoot(item), canonicalRoot(wtPath))) externalPackageLinks.push(path.relative(wtPath, item));
			} else if (!scoped && entry.isDirectory() && entry.name.startsWith("@")) inspectModules(item, true);
		}
	};
	const inspect = (dir: string, depth = 0): void => {
		if (++visited > scanLimit) { if (visited === scanLimit + 1) diagnostics.push(`目录扫描达到 ${scanLimit} 上限，子包发现不完整`); return; }
		if (fs.existsSync(path.join(dir, "package.json"))) packages.add(path.relative(wtPath, dir));
		for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
			if (e.name.startsWith(".") && e.name !== ".") continue;
			const target = path.join(dir, e.name);
			if (e.name === "node_modules") {
				if (e.isSymbolicLink()) {
					if (!fs.existsSync(target)) diagnostics.push(`${path.relative(wtPath, target)}: 损坏的链接，未替换`);
					else if (!pathWithin(canonicalRoot(target), canonicalRoot(wtPath))) externalLinks.push(path.relative(wtPath, target));
				} else if (e.isDirectory()) inspectModules(target);
			} else if (e.isDirectory()) {
				if (depth < depthLimit) inspect(target, depth + 1);
				else diagnostics.push(`${path.relative(wtPath, target)}: 达到目录深度上限，子包发现不完整`);
			}
		}
	};
	inspect(wtPath); // 不跟随目录 symlink；node_modules 仅检查顶层包和 scope
	if (visibility !== "portable") {
		if (externalLinks.length) throw new Error(`[worktree 依赖冲突] 请求 ${visibility}，但复用树仍有外部依赖链接：${externalLinks.join("、")}；未拆链接、未派发，请安全处置或声明 portable`);
		return `依赖可见性 ${visibility}: 主树依赖不接入 worktree（执行者自装）${externalPackageLinks.length ? `；既有包外链保留 ${externalPackageLinks.length} 个（示例: ${externalPackageLinks.slice(0, 3).join("、")}）` : ""}${diagnostics.length ? `；${diagnostics.join("；")}` : ""}`;
	}
	const linked = new Set(externalLinks), locals: string[] = [];
	let addedPackageLinks = 0, addedCommands = 0;
	if (projectSubdir && !path.isAbsolute(projectSubdir) && !projectSubdir.split(/[\\/]/).includes("..")) packages.add(projectSubdir);
	const statuses: string[] = [];
	for (const pkg of packages) {
		const pkgDir = path.join(wtPath, pkg);
		if (!fs.existsSync(pkgDir) || !pathWithin(canonicalRoot(pkgDir), canonicalRoot(wtPath))) {
			statuses.push(`${pkg || "."}: 子包目录缺失或在树外，未接入`); continue;
		}
		const rel = path.join(pkg, "node_modules");
		const src = path.join(repoRoot, rel), dst = path.join(wtPath, rel);
		let existing = false;
		try { fs.lstatSync(dst); existing = true; } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
		if (!existing) {
			if (!fs.existsSync(src)) { statuses.push(`${pkg || "."}: 主树无依赖目录`); continue; }
			if (!dryRun) fs.symlinkSync(src, dst, "dir");
			linked.add(rel); statuses.push(`${pkg || "."}: ${dryRun ? "将链接" : "已链接"}`); continue;
		}
		const dstStat = fs.lstatSync(dst);
		if (dstStat.isSymbolicLink()) { statuses.push(`${pkg || "."}: ${fs.existsSync(dst) ? "已有链接保留" : "损坏链接保留"}`); continue; }
		locals.push(rel);
		if (!dstStat.isDirectory()) { statuses.push(`${pkg || "."}: 依赖路径不是目录，保留`); continue; }
		if (!fs.existsSync(src)) { statuses.push(`${pkg || "."}: 本地目录保留，主树无依赖目录`); continue; }
		// 不能向主树或其他共享目录写入；只遍历实际 worktree 内的本地目录。
		let added = 0;
		const examples: string[] = [];
		const merge = (from: string, to: string, scope = false): void => {
			for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
				if (entry.name.startsWith(".")) continue;
				const source = path.join(from, entry.name), dest = path.join(to, entry.name);
				if (entry.isSymbolicLink() && !fs.existsSync(source)) { diagnostics.push(`${path.relative(repoRoot, source)}: 主树链接损坏，未接入`); continue; }
				if (!scope && entry.name.startsWith("@") && entry.isDirectory()) {
					let stat: fs.Stats | undefined;
					try { stat = fs.lstatSync(dest); } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
					if (stat && (!stat.isDirectory() || stat.isSymbolicLink())) { diagnostics.push(`${path.relative(wtPath, dest)}: scope 非本地目录，保留`); continue; }
					if (!stat && !dryRun) fs.mkdirSync(dest);
					merge(source, dest, true); continue;
				}
				let present = false;
				try { fs.lstatSync(dest); present = true; } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
				if (present) continue;
				if (!dryRun) fs.symlinkSync(source, dest, "dir");
				if (examples.length < 3) examples.push(path.relative(wtPath, dest));
				added++;
			}
		};
		merge(src, dst);
		const sourceBin = path.join(src, ".bin"), destBin = path.join(dst, ".bin");
		let binAdded = 0, binPreserved = 0;
		const binExamples: string[] = [];
		let sourceBinStat: fs.Stats | undefined;
		try { sourceBinStat = fs.lstatSync(sourceBin); } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
		if (sourceBinStat) {
			if (!fs.existsSync(sourceBin)) diagnostics.push(`${path.relative(repoRoot, sourceBin)}: 主树 .bin 链接损坏，未接入`);
			else if (!fs.statSync(sourceBin).isDirectory()) diagnostics.push(`${path.relative(repoRoot, sourceBin)}: 主树 .bin 不是目录，未接入`);
			else {
				let destBinStat: fs.Stats | undefined;
				try { destBinStat = fs.lstatSync(destBin); } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
				if (destBinStat && (!destBinStat.isDirectory() || destBinStat.isSymbolicLink())) diagnostics.push(`${path.relative(wtPath, destBin)}: .bin 非本地目录，保留不写入`);
				else {
					if (!destBinStat && !dryRun) fs.mkdirSync(destBin);
					for (const entry of fs.readdirSync(sourceBin, { withFileTypes: true })) {
						if (entry.name.startsWith(".")) continue;
						const source = path.join(sourceBin, entry.name), dest = path.join(destBin, entry.name);
						if (entry.isSymbolicLink() && !fs.existsSync(source)) { diagnostics.push(`${path.relative(repoRoot, source)}: 主树命令链接损坏，未接入`); continue; }
						if (!fs.statSync(source).isFile()) continue;
						let present = false;
						try { fs.lstatSync(dest); present = true; } catch (e) { if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e; }
						if (present) { binPreserved++; if (!fs.existsSync(dest)) diagnostics.push(`${path.relative(wtPath, dest)}: 命令链接损坏，未替换`); continue; }
						if (!dryRun) fs.symlinkSync(source, dest, "file");
						if (binExamples.length < 3) binExamples.push(path.relative(wtPath, dest));
						binAdded++;
					}
				}
			}
		}
		addedPackageLinks += added; addedCommands += binAdded;
		const existingPackageLinks = externalPackageLinks.filter((p) => p.startsWith(`${rel}${path.sep}`));
		statuses.push(`${pkg || "."}: 本地目录保留，${dryRun ? "将补" : "已补"} ${added} 个包链接${examples.length ? `（示例: ${examples.join("、")}）` : ""}${existingPackageLinks.length ? `；已有外链 ${existingPackageLinks.length} 个（示例: ${existingPackageLinks.slice(0, 3).join("、")}）` : ""}；${dryRun ? "将补" : "已补"} ${binAdded} 个 .bin 命令${binExamples.length ? `（示例: ${binExamples.join("、")}）` : ""}${binPreserved ? `；同名命令保留 ${binPreserved} 个` : ""}`);
	}
	return `依赖复用（portable）: ${linked.size ? `${[...linked].join("、")} → 外部符号链接${dryRun ? "将接入/保留" : "已接入/保留"}（tool-enforced 按真实落点校验写入；guarded shell 非沙箱）` : (addedPackageLinks || addedCommands || externalPackageLinks.length ? "无目录级外链" : "无外部依赖链接，执行者按需自装")}${locals.length ? `；树内已有依赖未替换: ${locals.join("、")}` : ""}；子包状态: ${statuses.join("；")}${diagnostics.length ? `；诊断: ${diagnostics.join("；")}` : ""}`;
}

/** 任务结束汇总：diff --stat HEAD + 未跟踪文件列表 + 主仓漂移告警（只读；失败如实说明）。 */
export function worktreeSummary(wtPath: string, main?: { root: string; baseline?: MainBaseline; base?: string }): string {
	const drift = main?.root ? checkMainDrift(main.root, main.baseline) : null;
	try {
		const stat = git(["diff", "--stat", main?.base || "HEAD"], wtPath);
		const porcelain = git(["status", "--porcelain"], wtPath);
		const untracked = porcelain.split("\n").filter((l) => l.startsWith("?? ")).map((l) => l.slice(3));
		const lines: string[] = [];
		if (stat) lines.push(main?.base ? `净增量（相对检出基线 ${main.base.slice(0, 8)}，含树内提交）:\n${stat}` : stat);
		if (untracked.length) lines.push(`未跟踪新文件(${untracked.length}): ${untracked.slice(0, 20).join(", ")}${untracked.length > 20 ? " …" : ""}`);
		if (!lines.length) lines.push("(工作区无改动)");
		if (drift) lines.push(drift);
		return lines.join("\n");
	} catch (e: any) {
		const lines = [`(diff 汇总失败: ${String(e?.message || e).slice(0, 200)})`];
		if (drift) lines.push(drift);
		return lines.join("\n");
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// v2 V1（方案 §7.1/§8.5-V1）：只读快照捕获入口（窄接口）
// verification-object.ts 消费：mkdtemp 专用捕获目录 + git 基线定位 + linked worktree
// 归属保护探测。全只读：不改用户索引、不 stash、不更新用户分支、不创建工作树——
// §7.1.3「用专用临时 worktree/目录捕获内容，复用 worktree 的归属保护」的落地。
// ─────────────────────────────────────────────────────────────────────────────

/** 捕获槽：mkdtemp 捕获目录 + 源定位事实（只读探测结果，不含任何复制内容）。 */
export interface SnapshotCaptureSlot {
	/** true = 捕获槽已开（captureRoot 已创建；成功对象按 §7.1.5 保留供复核，失败/放弃由调用方 releaseCaptureDir 清理）。 */
	ok: boolean;
	/** mkdtemp 捕获根目录（ok 时必有）。 */
	captureRoot?: string;
	/** git 仓库根（cwd 在 git 仓库内时有；非 git 目录 → undefined：纯目录捕获，无删除项/执行位/基线语义，由调用方降级记录 limitations）。 */
	repoRoot?: string;
	/** 嵌套 cwd：cwd 相对仓库根的相对路径（cwd=repoRoot → ""；探测失败 → undefined）。 */
	cwdRelRepo?: string;
	/** 基线 commit 锚点（`rev-parse HEAD`；空仓/探测失败 → undefined）。 */
	headCommit?: string;
	/** cwd 所属 linked worktree 登记路径（主检出/非 git 目录 → undefined）。 */
	worktreePath?: string;
	/** 该 worktree 的活跃租约（写者可能未退出）——快照期间内容可能被写（撕裂风险如实上报；「等退出」由检查面 V2 执行，本面只报告）。 */
	activeWriter?: { leaseId: string; taskId?: string; acquiredAt: number };
	message?: string;
}

/** 打开只读捕获槽：mkdtemp 专用捕获目录 + git/linked-worktree 归属探测。窄接口（V1）：
 *  不复制内容、不建清单——内容捕获与清单归 verification-object.ts；本函数只提供
 *  安全捕获的位置与归属事实（activeWriter 探测复用本模块所有权表，即 §7.1.3 的归属保护）。 */
export function captureSnapshot(cwd: string, opts?: { tmpDir?: string }): SnapshotCaptureSlot {
	let captureRoot: string;
	try {
		captureRoot = fs.mkdtempSync(path.join(opts?.tmpDir ?? os.tmpdir(), "amagi-vo-"));
	} catch (e: any) {
		return { ok: false, message: `[验证对象] 捕获目录创建失败: ${String(e?.message || e).slice(0, 160)}` };
	}
	const slot: SnapshotCaptureSlot = { ok: true, captureRoot };
	// git 基线定位（非 git 目录照常开槽——纯目录捕获，语义降级由调用方记录 limitations）
	try {
		const root = git(["rev-parse", "--show-toplevel"], cwd);
		slot.repoRoot = root;
		let abs: string;
		try { abs = fs.realpathSync(cwd); } catch { abs = path.resolve(cwd); }
		const rel = path.relative(canonicalRoot(root), abs);
		slot.cwdRelRepo = rel && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel) ? rel : "";
		try { slot.headCommit = git(["rev-parse", "HEAD"], cwd); } catch {}
		// linked worktree 归属：cwd 在登记树内 → 树路径 + 活跃租约（快照撕裂风险上报，等退出属 V2 检查面）。
		// 树匹配取**最深包含者**——约定路径 <主仓>/.amagi-worktrees/<name> 同时被主仓登记包含，
		// 按首条命中会错把主检出当所属树（linked wt 路径更长，排序后优先）。
		if (isInsideLinkedWorktree(cwd)) {
			const inside = (candidate: string): boolean => {
				const c = path.resolve(candidate);
				return abs === c || abs.startsWith(c + path.sep);
			};
			const reg = listRegisteredWorktrees(root)
				?.filter((w) => !w.bare && inside(w.path))
				.sort((a, b) => b.path.length - a.path.length)[0];
			if (reg) {
				slot.worktreePath = reg.path;
			const owner = [...wtOwners.values()].find((o) => !o.releasedAt && samePath(o.path, reg.path));
			if (owner) slot.activeWriter = { leaseId: owner.leaseId, taskId: owner.taskId, acquiredAt: owner.acquiredAt };
			}
		}
	} catch {
		// 非 git 目录：repoRoot 缺席即降级信号（slot.cwdRelRepo 保持 undefined）
	}
	return slot;
}

/** 清理捕获目录（失败路径/放弃保留时；成功对象按 §7.1.5 保留可复核内容，不自动清）。 */
export function releaseCaptureDir(dir: string): void {
	try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
}

// ─────────────────────────────────────────────────────────────────────────────
// v2.3 C1：evidence 隔离快照（v2.1 方案 §6-C1 原文，v2.2 顺延至本版）。
//
// 结算验证（auto-baseline/结构化检查的测试命令）在确定性 git 快照上执行——替代共享树并行
// 干扰豁免（ev-20260903-780da3 时序补丁的根因修复：基线失败曾来自并行节点 in-flight 改动
// 而非本任务缺陷，batch-da11dfaa 假失败事故）。快照 = 临时 index 全量登记共享树当前状态
// （未提交/未跟踪/删除全入）→ 悬空 commit（不建分支、不动 HEAD）→ `git worktree add
// --detach` 物化（复用本模块 worktree 机制约定）；gitignored 依赖目录（node_modules 等）
// 以符号链接复用——快照可真实跑 npm/make 类测试命令，而 V1 验证对象副本因 deps 未捕获
// 不可执行。
//
// 快照全程只读共享树：不动真 index、不 stash、不 checkout/reset、不建分支（临时 index 文件
// + 悬空 commit 由 GC 最终回收）；快照用完即清理（releaseEvidenceSnapshot：worktree remove
// --force → prune 兜底 → rm 临时根，不留半成品 worktree）。
//
// 三档开关（AMAGI_EVIDENCE_SNAPSHOT，缺省 shared-fallback 观察期；docs/env-knobs.md 登记）：
//   off             现状零变化（测试命令直接在共享树执行）；
//   shared-fallback 快照创建失败 → 回退共享树执行并注记 degraded（回执 degraded[] 有据）；
//   strict          快照创建失败 → 检查记 unavailable、回执如实 incomplete，不静默回退
//                   （不猜成功红线）。
//
// 边界：只服务「验证命令」的执行环境；git diff 采集/探针等非验证命令不经快照（归因需要
// 共享树口径）。失败回退/不回退的三档决策不在本节（evidence.ts 消费侧集中封装）。
// ─────────────────────────────────────────────────────────────────────────────

/** 三档模式（resolveEvidenceSnapshotMode 解析；非法值回 shared-fallback——观察期安全默认）。 */
export type EvidenceSnapshotMode = "off" | "shared-fallback" | "strict";

/** 快照模式解析（env 读取唯一入口；缺省/非法值回 shared-fallback）。 */
export function resolveEvidenceSnapshotMode(env: Record<string, string | undefined> = process.env): EvidenceSnapshotMode {
	if (env.AMAGI_EVIDENCE_SNAPSHOT === "off") return "off";
	if (env.AMAGI_EVIDENCE_SNAPSHOT === "strict") return "strict";
	return "shared-fallback";
}

/** env 口径与 evidence.ts gitEnv 同源（剥除 GIT_DIR/GIT_WORK_TREE 等仓库指向覆盖，防跨工作树
 *  污染）——为避免 evidence.ts ⇄ worktree.ts 循环依赖就地复制（本模块零 evidence 依赖），
 *  两处须同步维护。 */
const SNAP_GIT_ENV_STRIP = new Set([
	"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY",
	"GIT_COMMON_DIR", "GIT_NAMESPACE", "GIT_CEILING_DIRECTORIES",
]);

function snapGitEnv(extra?: Record<string, string>): Record<string, string> {
	const out: Record<string, string> = {};
	for (const [k, v] of Object.entries(process.env)) {
		if (!SNAP_GIT_ENV_STRIP.has(k) && v !== undefined) out[k] = v;
	}
	return { ...out, ...extra };
}

function snapGit(args: string[], cwd: string, envExtra?: Record<string, string>): string {
	return execFileSync("git", args, {
		cwd, env: snapGitEnv(envExtra), encoding: "utf8",
		stdio: ["ignore", "pipe", "pipe"], timeout: 30_000,
	});
}

/** ev-20260919-qb1r2（diting Q-B1 第二轮）：快照 git 阶段失败的受控诊断——阶段名 + 退出码 +
 *  stderr 规模（行/字符）+ 固定类别短码。stderr 是不可控自由文本：clean filter/凭据助手可向其
 *  回显任意认证材料（diting 增量复审实证：短 Bearer/Basic/未加引号空白值/换行续值在旧「先拼接
 *  再 redact」口径下 12 例 24 入口中 6 种输入两入口均泄露——有限 token 正则无法证明遮蔽完整），
 *  故诊断面永不携带 stderr 原文。类别短码由本 catch 内联探测（filter 失败/被忽略 pathspec/凭据
 *  特征等）——探测只影响标签选择，安全边界是「原文永不输出」，不依赖探测完整性；
 *  credential-echo-suspected 仅提示优先人工复核，不是遮蔽机制。
 *  注：探测须内联在本 catch 内且不得引入 TS-only 语法——diting 探针对本函数源码切片做
 *  strip-types 注入复跑（.agent-outputs/evolve/2.21.10/diting-probes/qb1-incremental.mjs），
 *  引用切片外 helper 会使其 ReferenceError。 */
class SnapGitStageError extends Error {
	readonly stage: string;
	readonly detail: string;
	// 不用 TS 参数属性：Node strip-only 加载（测试直接 import .ts）不支持该语法
	constructor(stage: string, detail: string) { super(`git ${stage} 失败：${detail}`); this.stage = stage; this.detail = detail; }
}

function snapGitStage(stage: string, args: string[], cwd: string, envExtra?: Record<string, string>): string {
	try { return snapGit(args, cwd, envExtra); }
	catch (e: any) {
		const raw = String(e?.stderr || e?.message || e);
		const lines = raw.split("\n");
		const nonHint = lines.filter((l) => l.trim() && !/^hint:/i.test(l.trim())).length > 0;
		const classes = [];
		if (/external filter .{0,200}failed|(?:clean|smudge) filter .{0,120}failed/i.test(raw)) classes.push("filter-failed");
		if (/ignored by one of your \.gitignore files/i.test(raw)) classes.push("ignored-pathspec");
		if (/not a git repository/i.test(raw)) classes.push("not-a-git-repo");
		if (/authorization|bearer|api[_-]?key|secret|passwd|password|token\s*=|:\/\/[^\s/@]+@/i.test(raw)) classes.push("credential-echo-suspected");
		if (!classes.length) classes.push(nonHint ? "other-git-output" : "advice-hint-only");
		const exit = typeof e?.status === "number" ? `exit ${e.status}` : "未退出";
		throw new SnapGitStageError(stage, `${exit}；stderr ${lines.length} 行 ${raw.length} 字符，类别：${classes.join("+")}（stderr 原文不透传，ev-20260919-qb1r2）`);
	}
}

function snapFailureReason(e: unknown): string {
	if (e instanceof SnapGitStageError) return e.message;
	// qb1r2：异常 fallback 同样不透传自由文本——内部异常 message 可能携带不可控内容（如注入的
	// sanitizer 异常），输出固定诊断而非恢复原始消息（diting 增量复审：错误出口统一安全处理）。
	return `git 快照创建失败：意外异常 ${e instanceof Error ? e.constructor.name : typeof e}（消息不透传）`;
}

const SNAP_WORKTREE_DIR = ".amagi-worktrees";

/** 主树工作区（Git 可见内容）写入临时 index，排除兄弟工作树目录 .amagi-worktrees。
 *  ev-20261018-c0cd17 根因：pathspec 显式点名一个被 .gitignore 覆盖的路径（含 :(exclude) 形式）时，
 *  git add 视为「要求添加被忽略路径」→ exit 1（仅打印路径与 advice hint）——推荐的 .gitignore 写法
 *  恰好让 dirty-snapshot 与证据快照恒失败。被忽略的目录 add -A 本就不会收入，排除 pathspec 只在
 *  未被忽略时需要（否则兄弟树会作为 gitlink/嵌套 tree 污染快照，B9）。check-ignore 退出码：0=忽略、
 *  1=未忽略、其它=探测失败（抛出，如实报告阶段）。 */
function snapAddWorkingTree(root: string, idxEnv: Record<string, string>): void {
	let ignored = true;
	try { snapGitStage("check-ignore", ["check-ignore", "-q", SNAP_WORKTREE_DIR], root, idxEnv); }
	catch (e) {
		if (!(e instanceof SnapGitStageError && /^exit 1；/.test(e.detail))) throw e;
		ignored = false;
	}
	snapGitStage("add", ["add", "-A", "--", ".", ...(ignored ? [] : [`:(exclude)${SNAP_WORKTREE_DIR}`])], root, idxEnv);
}

/** 悬空提交身份（快照 commit 是内部临时对象，不落用户分支；固定身份保证无 git 用户配置的
 *  仓库（测试沙箱/CI）也能创建）。 */
const SNAP_IDENTITY = {
	GIT_AUTHOR_NAME: "amagi-evidence-snapshot",
	GIT_AUTHOR_EMAIL: "amagi@evidence.snapshot.invalid",
	GIT_COMMITTER_NAME: "amagi-evidence-snapshot",
	GIT_COMMITTER_EMAIL: "amagi@evidence.snapshot.invalid",
};

/** gitignored 依赖目录名（不进快照检出，符号链接复用共享树安装产物——检查命令需要在场）。 */
const SNAP_DEP_DIR_NAMES = ["node_modules", "vendor", ".venv", "venv"] as const;

/** 已建立的快照环境（releaseEvidenceSnapshot 清理入参；字段即生命周期契约）。 */
export interface EvidenceSnapshot {
	/** 快照 worktree 根（冻结内容检出）。 */
	worktree: string;
	/** 验证命令执行目录（worktree 内对应源 execDir 的路径）。 */
	execCwd: string;
	/** 符号链接进快照的依赖目录名（去重；展示与注记用）。 */
	linkedDeps: string[];
	/** git 仓库根（清理 worktree 时的 git -C 目标）。 */
	repoRoot: string;
	/** mkdtemp 临时根（worktree + 临时 index 所在；清理整目录）。 */
	tmpRoot: string;
}

export type EvidenceSnapshotAttempt =
	| { ok: true; snapshot: EvidenceSnapshot }
	| { ok: false; reason: string };

/**
 * 建立 evidence 隔离快照（git 快照机制，v2.3 C1）：
 *   ① repoRoot = `rev-parse --show-toplevel`（sourceCwd 自带上探；非 git → 如实失败）；
 *   ② execDir 映射为仓库内相对路径（越界 → 失败，不猜）；
 *   ③ 临时 index（GIT_INDEX_FILE 指向 mkdtemp 内文件，不动共享树真 index）：read-tree HEAD
 *      → add -A（全量登记当前工作树：未提交/未跟踪/删除；gitignored 跳过）→ write-tree
 *      → commit-tree（悬空 commit，-p HEAD 留基线锚）；
 *   ④ `git worktree add --detach <tmp>/<唯一名> <commit>` 物化冻结检出；
 *   ⑤ 依赖目录符号链接（仓库根 + 执行目录两级；目标已存在/链接失败如实跳过）。
 * 任何一步失败：清理半成品后如实返回 reason（三档回退决策在 evidence.ts 消费侧，本函数不做）。
 */
export function createEvidenceSnapshot(sourceCwd: string, execDir: string, opts?: { tmpRoot?: string }): EvidenceSnapshotAttempt {
	let repoRoot: string;
	try {
		repoRoot = snapGit(["rev-parse", "--show-toplevel"], sourceCwd).trim();
	} catch (e: any) {
		// qb1r2：快照入口前置探测同样不透传 stderr 自由文本（与 snapGitStage 同策略；rev-parse 无
		// filter 参与，但错误面不因阶段前置而豁免）。
		const raw = String(e?.stderr || e?.message || e);
		const exit = typeof e?.status === "number" ? `exit ${e.status}` : "未退出";
		const kind = /not a git repository/i.test(raw) ? "not-a-git-repo" : "other";
		return { ok: false, reason: `git rev-parse --show-toplevel 失败（${exit}；类别：${kind}，stderr ${raw.length} 字符原文不透传）` };
	}
	if (!repoRoot) return { ok: false, reason: "git rev-parse --show-toplevel 返回空仓库根" };
	let execReal: string;
	try {
		execReal = fs.realpathSync(execDir);
	} catch {
		return { ok: false, reason: `执行目录不可访问: ${execDir}` };
	}
	const execRel = path.relative(repoRoot, execReal);
	if ((execRel === ".." || execRel.startsWith(`..${path.sep}`)) || path.isAbsolute(execRel)) {
		return { ok: false, reason: `执行目录不在仓库根下（${execDir} vs ${repoRoot}）` };
	}

	let tmpRoot: string;
	try {
		tmpRoot = fs.mkdtempSync(path.join(opts?.tmpRoot ?? os.tmpdir(), "amagi-evsnap-"));
	} catch (e: any) {
		return { ok: false, reason: `临时目录创建失败: ${String(e?.message || e).slice(0, 120)}` };
	}
	const worktree = path.join(tmpRoot, `snap-${randomUUID().slice(0, 8)}`);
	const idxEnv = { GIT_INDEX_FILE: path.join(tmpRoot, "index") };
	try {
		snapGitStage("read-tree", ["read-tree", "HEAD"], repoRoot, idxEnv);
		snapAddWorkingTree(repoRoot, idxEnv);
		const tree = snapGitStage("write-tree", ["write-tree"], repoRoot, idxEnv).trim();
		const commit = snapGitStage("commit-tree", ["commit-tree", tree, "-p", "HEAD", "-m", "amagi evidence snapshot (v2.3 C1)"], repoRoot, SNAP_IDENTITY).trim();
		snapGitStage("worktree add", ["worktree", "add", "--detach", worktree, commit], repoRoot);
	} catch (e: any) {
		// 半成品清理（worktree 未建成/临时 index 残留都不留）
		releaseEvidenceSnapshot({ worktree, execCwd: worktree, linkedDeps: [], repoRoot, tmpRoot });
		return { ok: false, reason: snapFailureReason(e) };
	}

	const linked = new Set<string>();
	const linkDep = (srcAbs: string, dstAbs: string): void => {
		try {
			if (fs.existsSync(dstAbs) || !fs.existsSync(srcAbs)) return;
			fs.symlinkSync(srcAbs, dstAbs, "dir");
			linked.add(path.basename(dstAbs));
		} catch { /* 单个链接失败不阻断：依赖缺失将如实反映为检查命令失败 */ }
	};
	for (const dep of SNAP_DEP_DIR_NAMES) linkDep(path.join(repoRoot, dep), path.join(worktree, dep));
	for (const dep of SNAP_DEP_DIR_NAMES) {
		const src = path.join(execReal, dep);
		if (src !== path.join(repoRoot, dep)) linkDep(src, path.join(worktree, execRel, dep));
	}
	return { ok: true, snapshot: { worktree, execCwd: path.join(worktree, execRel), linkedDeps: [...linked], repoRoot, tmpRoot } };
}

/** 释放快照（幂等、尽力而为）：worktree remove --force → 失败时 prune 兜底；临时根整体删除。 */
export function releaseEvidenceSnapshot(s: EvidenceSnapshot): void {
	try {
		snapGit(["worktree", "remove", "--force", s.worktree], s.repoRoot);
	} catch {
		try { snapGit(["worktree", "prune"], s.repoRoot); } catch { /* 登记残留留待用户 git worktree prune（只读元数据，不伤工作区） */ }
	}
	try {
		fs.rmSync(s.tmpRoot, { recursive: true, force: true });
	} catch { /* 临时目录清理尽力而为（系统 tmp 回收兜底） */ }
}
