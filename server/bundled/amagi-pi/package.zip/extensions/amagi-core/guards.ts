/**
 * guards.ts — 安全守卫、非阻断诊断与高风险哨兵（§3.4 / §4.1）。
 * P2 终审：执行位 shell 解析、Git 等价调用、每会话哨兵预算、JSON 写后校验。
 * P3-A（2026-08-19）：shell 解析纯函数拆出至 shell-lexer.ts（本模块 import 使用并 re-export，外部 import 路径不变）。
 * ev-20260916-S1（已沉淀改进项消化）：图片读取三态守卫（ead537，AMAGI_IMAGE_READ_GUARD）、
 * 丢弃改动确认门与 worktree remove 前置检查（18f0d5/07e44a，git-discard-guard.ts，AMAGI_GIT_DISCARD_POLICY/
 * AMAGI_WORKTREE_DIRTY_REMOVE）、异源暂存弱归因警示（cfb0b5，AMAGI_STAGED_ORIGIN_HINT）、进程替换 diff
 * 诊断（8c55a2，AMAGI_SEMANTIC_EXIT_PROCESS_SUBSTITUTION）、stash 子命令解析+session 生命周期
 *（a7eee1，AMAGI_STASH_HINT_PARSE）、诊断会话计次（c1a50c，AMAGI_GUARD_REPEAT_NOTE）、rm 移动保留
 * 建议（57c1c7，AMAGI_RM_MOVE_ADVICE）、BSD xargs -d 诊断（3324e4）、BSD 平台诊断结构化单源（d9655d）、
 * 批量格式化整包重写软提示（2c709d，AMAGI_BATCH_FORMAT_HINT）。全部开关非法值回安全默认。
 * 安全边界声明：这是“有界 lexer 安全网”，不是安全边界；刻意对抗仍可能绕过。
 * 深度防御依赖系统层沙箱（T3-1），本模块只承担 §4.1 的轻护栏职责。
 */

import { guardRuleOf, guardProjectTrustedOf } from "./guard-policy.ts";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { bashWriteTargets } from "./task-tool.ts";
import { registry as taskRegistry } from "./task-registry.ts";
import { readTaskWrites } from "./task-write-log.ts";
import { probeBashRuntime, type BashRuntimeInfo } from "./runtime-env.ts";
// ev-20260914-9084ee：allowedPaths 白名单共享 matcher（glob/prefix: 语法；与派发端预检同源）
import { matchPathAllowed, whitelistPrefixIntentHint } from "./path-match.ts";
// amagi-pi v2 P2（方案 §5.2 read 通道执行点）：冻结 spec.permission 的读通道逐次校验
//（ev-20260919 读范围限制退役：仅 deny 禁入护读；无活动权限上下文时零干预——legacy
// AMAGI_PROTECTED_PATHS/ALLOWED_PATHS 机制照常生效）。
import { fileReadPermissionBlockReason } from "./file-permission.ts";
import { resolveBuiltinFileTarget } from "./builtin-file-target.ts";
// B6a（十月迭代 M3，设计 §5.3/§7.2-5）：原生 MCP 工具（mcp__*）与资源工具复用 grant 检查——
// 解析件在 mcp-host-bridge（canonical 归一/歧义标记），执法组合（grant 复用/全局 list 拒绝）在本模块。
import { parseNativeMcpToolName, ownerOfServerInPlan, type McpOwnershipPlan } from "./mcp-host-bridge.ts";
import { checkMcpCallPermission, type McpPermission } from "./mcp-config.ts";
// B4A（ev-20261012-af58eb 设计 §8 批A）：护栏策略解释层——判定消息的规则标签（信号层）；
// 判定本身不变（批A 不消费 rule 值；投影与来源见 guard-policy.ts / /amagi config explain）。
import { guardRuleTag } from "./guard-policy.ts";

// P3-A：shell 解析纯函数原语层在 shell-lexer.ts（零 pi 依赖）。此处 import 供守卫策略使用；
// re-export 维持既有外部 import 路径不变（splitHeredocs/HeredocSplit 原为公共导出，
// CONTROL_OPERATORS/UNCLOSED_BACKTICK/UNSAFE_DOUBLE_QUOTED_BACKTICK 为本模块与 lexer 的共享契约）。
import {
	CONTROL_OPERATORS,
	UNCLOSED_BACKTICK,
	UNSAFE_DOUBLE_QUOTED_BACKTICK,
	analyzeExecutableShell,
	commandSubstitutions,
	containsDownloader,
	executableWords,
	scanBackticks,
	segmentShellSpans,
	shellChainOperators,
	shellPipelineChains,
	shellSegments,
	shellSegmentsMeta,
	shellTokens,
	shellWrapperPayloads,
	splitHeredocs,
	stripProcessSubstitutions,
	substitutionPayloads,
	tokenizeShellSpans,
	type ShellTokenMeta,
	type ShellTokenSpan,
} from "./shell-lexer.ts";
// ev-20260916-S1：守卫切片辅助模块（无注册副作用）。Git 调用解析共享层（parseGitInvocations/
// resolveGitCommand/gitOutput/normalizeGuardPath/isReadOnlyCommand）已迁入 git-discard-guard.ts，
// 此处 import 共用（guards → git-discard-guard 单向依赖，无循环）；后两者 re-export 维持外部导入路径。
// M8（diting 审核轮）：win_exec 破坏性 git 门适配（规范化+复用 git-discard 同一判定；本文件仅留调用点）
import { winExecGuardDecision, type WinExecGuardInput } from "./win-exec-guard.ts";
import {
	decideDiscardGate,
	decideStashChainGate,
	decideSubagentStashGate,
	decideWorktreeRemoveGate,
	discardRiskText,
	effectiveBashCwd,
	gitOutput,
	gitOutputRaw,
	inspectDiscard,
	isReadOnlyCommand,
	normalizeGuardPath,
	parseDiscardPolicy,
	parseGitInvocations,
	resolveGitCommand,
	stashRiskOperation,
	type GitInvocation,
} from "./git-discard-guard.ts";
// ev-20260922-1eea28（B2）：unattended 丢弃保全放行——预授权验真 + 备份 + 一次性放行凭证
// （guards → git-discard-backup → git-discard-guard/worktree/data-dir 单向依赖，无循环）。
import {
	authorizeDiscardBackupAndExecute,
	discardApprovalRefFromEnv,
	takePendingDiscardOutcomeNote,
} from "./git-discard-backup.ts";
import { RepeatNoteTracker, guardRepeatNoteEnabled, withRepeatNoteHeader, withEscalatedNote, withCompactEscalatedNote } from "./guard-notes.ts";
export { isReadOnlyCommand, normalizeGuardPath } from "./git-discard-guard.ts";
// ev-20260917-589972：stash 子命令解析（STASH_RISKY_SUBCOMMANDS/stashRiskOperation）已随子 Agent
// stash 拦截门（decideSubagentStashGate）迁入 git-discard-guard.ts——此处 re-export 维持外部导入路径。
export { stashRiskOperation, STASH_RISKY_SUBCOMMANDS } from "./git-discard-guard.ts";
export { CONTROL_OPERATORS, UNCLOSED_BACKTICK, UNSAFE_DOUBLE_QUOTED_BACKTICK, splitHeredocs } from "./shell-lexer.ts";
export type { HeredocSplit } from "./shell-lexer.ts";

/** 风险提示的会话去重状态；不统计模型选择 read 或 shell 的次数。 */
function newGuardAdviceState() {
	return {piSpawnNotified: false, findScanNotified: false, batchFormatNotified: false};
}

/** ev-20260831-56f939（8月迭代 pi-0.84 配合 修复轮）：派生 pi 子进程无 timeout 软提示。
 *  实战事故：Leader 前台 bash spawn 真实 pi 子进程（cli.js --mode json）未传 timeout，
 *  模型调用挂死整会话需人工 Esc 中止。命中=命令含 pi 子进程派生特征（cli.js，或 pi 词与
 *  --mode json|rpc 共现，或 rpc-entry）且 bash 调用未传 timeout 参数且命令无 timeout/gtimeout
 *  外壳兜底——返回一次性中文软提示文案，未命中返回 null（不阻断，同读文件纪律软提示机制）。 */
export function piChildSpawnRisk(command: string, timeoutParam: unknown): string | null {
	const spawnLike = /cli\.js/.test(command)
		|| (/\bpi\b/.test(command) && /--mode\s+(?:json|rpc)\b/.test(command))
		|| /rpc-entry/.test(command);
	if (!spawnLike) return null;
	// 已有兜底则不提示：bash 工具 timeout 参数（truthy 秒数）或 timeout/gtimeout 外壳包裹
	if (timeoutParam) return null;
	if (/\bg?timeout\s/.test(command)) return null;
	// v1.5.259：macOS 无 GNU timeout（实战 2026-09-02：裸 timeout 直接 command not found）——
	// darwin 上不再建议 timeout 外壳，只推 bash 工具内建 timeout 参数 / 后台派发。
	const shell = process.platform === "darwin"
		? "确定性手段（一次性命令 / gtimeout，若已装 coreutils）"
		: "timeout 外壳包裹 / 一次性命令";
	return `[amagi 软提示·pi 子进程兜底] 检测到前台派生 pi 子进程（cli.js/--mode json|rpc）且未传 timeout——子进程模型/MCP 调用挂死会挂起整会话，只能人工 Esc 中止。建议：① bash 调用传 timeout 参数（秒级兜底，如 300）；② 长任务改后台派发（task 工具 background 模式带 timeoutMs）；③ 验证实验优先${shell}。本提示每会话仅一次，不阻断。`;
}

// ── ev-20260923-680943（friction/P3）：全盘 find 无超时预算软提示 ──
// 实战（workflow model-cell-logic T3）：sub-agent 执行 `find / -name "*model-cell*" -type d` 全盘搜索
// 卡死，任务 70 分钟零产出被迫取消重派；重派任务书加「查找只在项目目录内」后 25 分钟完成。
// 判定：shellSegments 真实可执行名为 find（echo 中的 find 字样不误配），首路径参数为全盘/全 home 级
// （/ 、~ 、$HOME 或 ~/ 前缀），且 bash 调用未传 timeout 参数、无 timeout/gtimeout 外壳兑底。
// ev-20261004-e023ed③：判定提纯为 wholeScanFindHit（单一定义）——软提示（Leader 侧，每会话一次
// 不阻断）与子代理硬阻断（bash-override 执行前拒绝）共用同一检测，语义漂移不可能发生。
export function wholeScanFindHit(command: string, timeoutParam: unknown): boolean {
	for (const segment of shellSegments(command)) {
		const tokens = segment.map((t) => path.basename(t).toLowerCase());
		const findIdx = tokens.indexOf("find");
		if (findIdx < 0) continue;
		const firstPathArg = segment.slice(findIdx + 1).find((w) => !w.startsWith("-"));
		if (firstPathArg === undefined) continue;
		const wholeScan = firstPathArg === "/" || firstPathArg === "~" || firstPathArg === "$HOME" || firstPathArg.startsWith("~/");
		if (!wholeScan) continue;
		if (timeoutParam) return false;
		const segmentHasTimeoutPrefix = tokens.slice(0, findIdx).some((t) => t === "timeout" || t === "gtimeout");
		if (segmentHasTimeoutPrefix) return false;
		return true;
	}
	return false;
}

/** 命中只发一次性非阻断 guard-note（全盘 find 合法但罕见，阻断会成新误拦面——Leader 侧；
 *  子代理侧由 bash-override 执行前拒绝）。纯函数。 */
export function fullScanFindRisk(command: string, timeoutParam: unknown): string | null {
	if (!wholeScanFindHit(command, timeoutParam)) return null;
	return `[amagi 软提示·全盘搜索] 检测到 find 从根/全 home 目录起搜且未传 timeout——全盘遍历在大目录树上可长时间无产出（来由：ev-20260923-680943）。建议：① 限定项目目录（find <项目路径> -name …）；② bash 调用传 timeout 参数（秒级兑底，如 120）；③ 查找目标名已知时优先 mdfind/rg（限定目录）。本提示每会话仅一次，不阻断。`;
}

// ── ev-20260830-2c709d（事故剩余缺口·软提示）：批量格式化整包重写 ──
// 实战（2026-08-30）：Leader 对 ./internal/launcher/ 执行 go.exe fmt——go fmt 本身就是写操作
//（内部对包内源文件逐个跑 gofmt -l -w），波及整包 28 文件重写；随后黑名单式批量 git checkout
// 还原又误伤两个 SubAgent 未提交切片（10 文件 140 行，损耗 30 分钟 + 2 次 resume）。事故的
//「批量还原」半面已由 ev-20260916-18f0d5 丢弃确认门（无 UI 即 block）+ ev-20260922-e44fe9
// stash 串联门闭环；本软提示补「批量格式化」半面：命中 go fmt（任意形式）或 gofmt -w 的
//「无显式单文件列表」形态（目录、`.`、`./...`、通配、$动态清单、零目标）→ 一次性 guard-note
// 建议先预览后逐文件写。格式化合法常用（误拦成本高）：只警示不阻断、不改写命令、不碰 index。
// 回滚：AMAGI_BATCH_FORMAT_HINT=0/false/off。

export function batchFormatHintEnabled(env: string | undefined = process.env.AMAGI_BATCH_FORMAT_HINT): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** go 段判定：首个位参为 fmt 子命令（go fmt 即写操作，含 go fmt ./... 等包参数形态）；
 *  -n（go 命令 dry-run：只打印将执行的 gofmt 命令不执行）豁免——它正是预览命令，提示它自相矛盾。
 * F3（diting Minor，对称性）：全部目标为显式 .go 源文件时与 gofmt -w 单文件对称放行；
 * 零目标（默认当前包整包）/包路径/目录/…/通配——go fmt 按包整包执行，写波及面远超单文件，保持提示。 */
function isBatchGoFmtWrite(words: string[]): boolean {
	let subcommand: string | null = null;
	const rest: string[] = [];
	let i = 1;
	while (i < words.length) {
		const token = words[i++];
		if (subcommand === null && token === "-C" && i < words.length) { i++; continue; } // go -C dir fmt
		if (subcommand === null && token.startsWith("-")) { rest.push(token); continue; }
		if (subcommand === null) { subcommand = token; continue; }
		rest.push(token); // 子命令后的旗标/参数一并并入 -n 扫描（go fmt -n ./... 同为 dry-run）
	}
	if (subcommand !== "fmt") return false;
	if (rest.some((f) => f === "-n" || f.startsWith("-n="))) return false;
	const targets = rest.filter((t) => !t.startsWith("-"));
	if (!targets.length) return true; // 零显式目标：默认当前包整包
	// 全部目标为显式 .go 源文件 → 单文件正道放行（与 gofmt -w 单文件对称）；
	// 包路径/目录/…/通配等任一非 .go 目标 → 整包形态提示。
	return !targets.every((t) => /\.go$/i.test(t.replaceAll("\\", "/")));
}

/** gofmt 单个目标 token 的批量形态判定（句法层优先；显式 .go 源文件放行，含 ./path/x.go 形态）。 */
function gofmtTargetIsBatch(target: string, cwd: string | undefined): boolean {
	const t = target.replaceAll("\\", "/");
	if (t.startsWith("$")) return true; // 变量/命令替换展开的动态清单
	if (/[*?\[\]]/.test(t)) return true; // shell 通配展开（gofmt -w *.go）
	if (t.includes("...")) return true; // ./... 包模式
	if (t === "." || t === ".." || t === "./" || t === "../") return true;
	if (t.endsWith("/")) return true; // 目录尾斜杠（实战形态：go fmt ./internal/launcher/）
	if (/\.go$/i.test(t)) return false; // 显式 .go 源文件（含路径前缀形态）——单文件正道
	// 裸名/无扩展路径（internal、./internal/launcher）：fs 只读探测，存在且为目录即批量形态；
	// 探测失败/指向文件按句法结论放行（软提示宁可漏勿扰）。
	if (cwd) {
		try {
			const abs = path.resolve(cwd, t);
			if (fs.existsSync(abs) && fs.statSync(abs).isDirectory()) return true;
		} catch { /* lint-exempt:探测失败保持句法结论——fs 只读探测不可用时不误伤合法命令（ev-20260830-2c709d） */ }
	}
	return false;
}

/** gofmt 段判定：带 -w（写）且目标为无显式单文件列表的批量形态。无 -w（-l/-d 等只读）恒不提示。 */
function isBatchGofmtWrite(words: string[], cwd: string | undefined): boolean {
	const tokens = words.slice(1);
	if (!tokens.some((t) => t === "-w" || t === "-w=true")) return false;
	const targets: string[] = [];
	let i = 0;
	while (i < tokens.length) {
		const token = tokens[i++];
		if (token === "--") { targets.push(...tokens.slice(i)); break; } // -- 后全为目标
		if (token === "-r") { i++; continue; } // -r 'rule'：规则文本不是目标
		if (token.startsWith("-")) continue;
		targets.push(token);
	}
	if (!targets.length) return true; // 零显式目标（stdin/-w 组合无意义形态，保守提示）
	return targets.some((t) => gofmtTargetIsBatch(t, cwd));
}

/** 命中批量格式化整包重写形态 → 软提示文案；未命中/开关关闭返回 null。
 *  纯函数（无 pi 依赖；目录目标判定含只读 fs 探测）。 */
export function batchFormatRewriteRisk(command: string, cwd?: string): string | null {
	if (!batchFormatHintEnabled()) return null;
	for (const segment of shellSegments(command)) {
		const words = executableWords(segment, true);
		if (!words.length) continue;
		const exe = path.basename(words[0]).toLowerCase().replace(/\.exe$/, "");
		const batch = exe === "go" ? isBatchGoFmtWrite(words) : exe === "gofmt" ? isBatchGofmtWrite(words, cwd) : false;
		if (batch) {
			return `[amagi 软提示·批量格式化整包重写] 检测到 go fmt / gofmt -w 批量形态（整包、目录、.、./...、通配或动态清单）——go fmt 本身就是写操作，将原地重写范围内全部文件，批量还原时还容易误伤并行任务的未提交改动（来由：ev-20260830-2c709d）。建议：① 先预览将改写的文件（gofmt -l ./...，或 go fmt -n 只打印不执行）；② 工作区含未提交多源改动时先快照（git stash create 或先提交）再格式化；③ 只对目标文件逐个 gofmt -w <文件>。格式化合法常用，本提示不阻断、每会话仅一次。`;
		}
	}
	return null;
}

// ── ev-20260910-244bbd（ux/P3）：管道吞退出码的假阳性防呆 ──
// 实战现象（子 Agent 验证命令）：`npm test 2>&1 | grep -c "fail" && echo "测试通过"`——管道退出码
// 只取末段（grep 命中无关行即 0；tail/head/wc/cat 等几乎恒 0），左侧命令的真实失败不传播，
// `&&` 成功断言据此输出「测试通过」并回流 Leader 成为假阳性结论。判定（三条同时满足才提示）：
//   ① 命令含管道，且管道末段可执行名属「退出码语义弱」的过滤/透传类（grep/tail/head/wc/cat…）；
//   ② 该管道整体后接 `&&`，断言段为 echo/printf（文案含 通过/成功/ok/pass 语义）或 `exit 0`；
//   ③ 命令内既无 pipefail（set -o pipefail / set -eo pipefail）也无 PIPESTATUS 检查。
// 命中只发一行非阻断 guard-note（误报面大，阻断会成新摩擦）：不改写命令、不阻断、无会话状态
//（不做限频/计数——每条命中命令各提示一次）。纯查看管道（无 && 断言）天然零提示。

/** 末段退出码语义弱（不反映左侧命令成败）的透传/过滤类可执行文件名。 */
const WEAK_PIPE_TAIL_EXECUTABLES = new Set([
	// 匹配类：退出码只表达「是否命中」，与左侧命令成败无关
	"grep", "egrep", "fgrep", "rg", "ag", "ack",
	// 透传/统计类：几乎恒 0
	"cat", "tac", "tail", "head", "wc", "nl", "bat", "tee",
	// 过滤/格式化类：几乎恒 0
	"sed", "awk", "cut", "sort", "uniq", "tr", "column", "fold", "jq",
]);

interface PipeUnit {
	/** 单元内的管道段（不空）。 */
	segments: string[][];
	/** 紧随该单元之后的控制操作符（命令末尾为 null）。 */
	connective: "&&" | "||" | ";" | "\n" | null;
}

/** shellTokens → 管道单元序列：单元内以 `|` 连接，单元间记录紧随其后的控制操作符。 */
function pipeUnits(tokens: string[]): PipeUnit[] {
	const units: PipeUnit[] = [];
	let segments: string[][] = [];
	let words: string[] = [];
	const flushSegment = () => { if (words.length) { segments.push(words); words = []; } };
	const flushUnit = (connective: PipeUnit["connective"]) => {
		flushSegment();
		if (segments.length) units.push({ segments, connective });
		segments = [];
	};
	for (const token of tokens) {
		if (token === "|") { flushSegment(); continue; }
		if (token === "&&" || token === "||" || token === ";" || token === "\n") { flushUnit(token); continue; }
		words.push(token);
	}
	flushUnit(null);
	return units;
}

/** 段的可执行名（经 executableWords 剥 env/sudo/timeout 包裹 + 路径前缀归一）。 */
function unitExecutable(segment: string[]): string {
	const words = executableWords(segment, true);
	return words.length ? path.basename(words[0]).toLowerCase() : "";
}

/** 条件①：单元含管道且末段可执行名属于退出码语义弱的过滤/透传类。 */
function hasWeakPipeTail(unit: PipeUnit): boolean {
	if (unit.segments.length < 2) return false;
	return WEAK_PIPE_TAIL_EXECUTABLES.has(unitExecutable(unit.segments[unit.segments.length - 1]));
}

/** 纯输出/常量生成命令：几乎不可能真实失败，弱尾退出码即作者意图（`echo … | grep -q 判包含`
 *  是合法惯用法）——作为首段不构成“左侧失败被吞”风险，不提示（ev-20260924-92465e 防误报面）。 */
const CONSTANT_HEAD_EXECUTABLES = new Set(["echo", "printf", "yes", "true", "false"]);

/** 条件②（ev-20260924-92465e）：首段是“重命令”——非弱尾族、非常量生成器：左侧可能真实失败
 *  （构建/测试/编译），其失败被弱尾覆盖才是本提示的对象。 */
function hasHeavyPipeHead(unit: PipeUnit): boolean {
	if (unit.segments.length === 0) return false;
	const head = unitExecutable(unit.segments[0]);
	return head !== "" && !WEAK_PIPE_TAIL_EXECUTABLES.has(head) && !CONSTANT_HEAD_EXECUTABLES.has(head);
}

/** 后继单元引用 `$?`（任意连接符；引号内字面 `$?` 属罕见形态，软提示可容忍）。 */
function readsLastStatus(unit: PipeUnit): boolean {
	return unit.segments.some((seg) => seg.some((word) => word.includes("$?")));
}

/**
 * 纯函数：管道退出码被末段覆盖的假阳性防呆（供 tool_call 接线与测试直接断言）。
 * ev-20260924-92465e（P2）：从「文案启发式」改为以语义判定——谁的退出码被消费：
 *   命中 = 存在管道单元（末段弱尾 + 首段重命令），且该管道的退出状态随后被消费：
 *   ① 后继单元以 `&&`/`||` 相连（按退出码分支）；② 后继单元引用 `$?`（任意连接符）。
 *  实战误读形态 `npm run build | tail -20; echo "exit=$?"` / `… | grep -c fail && echo $?`
 *  此前因不满足「成功断言文案」漏报（旧负例把陷阱固化成了预期）。
 * 已设 pipefail / PIPESTATUS 防护不提示（左侧失败可传播，用户已正确处理——非特判）。
 */
export function pipeExitCodeHint(command: string): string | null {
	if (!command || !command.includes("|")) return null;
	// 条件③：已有 pipefail / PIPESTATUS 防护——左侧失败可传播，不提示（文本出现即视为已防护，宁可漏报不误报）
	if (/pipefail|PIPESTATUS/i.test(command)) return null;
	const units = pipeUnits(shellTokens(command));
	for (let i = 0; i + 1 < units.length; i++) {
		if (!hasWeakPipeTail(units[i])) continue;
		if (!hasHeavyPipeHead(units[i])) continue;
		const branches = units[i].connective === "&&" || units[i].connective === "||";
		const consumed = branches || readsLastStatus(units[i + 1]);
		if (!consumed) continue;
		return "[amagi 软提示·管道退出码] 管道退出码被末段覆盖（grep/tail/head/wc/cat 等过滤/透传命令的退出码不反映左侧命令成败）——左侧命令失败不会传播，本命令按该管道退出码分支（&& / ||）或读取 $? 会得出假结论。建议：加 `set -o pipefail`；或改判 `${PIPESTATUS[0]}`（bash 数组，紧随管道后取）；或把左侧输出落盘后单独判退出码。本提示不阻断。";
	}
	return null;
}

// ── ev-20260906-f4e4e8（ux/P2）：预执行拦截原子性说明 ──
// 实战事故：复合命令（curl … && hdiutil … && mv … && rm -rf …）在 tool_call 阶段被 rm 守卫拦截
// ——block 发生在命令启动前（pi 语义：tool_call "before the tool executes"），整条命令（含全部
// 前置段）一个部分都未执行；但拦截消息只说「已阻止递归删除…」，Leader 误判 curl/hdiutil/mv
// 已跑（卷已挂载/旧包已移走的幻觉），基于不存在的中间态继续操作。本函数只在确实预执行语义
// 成立的接线点（tool_call 的 bash/powershell block）统一追加执行状态说明；tool_result 阶段的
// 事后诊断（彼时命令已执行）与 edit/write/read 等非命令 block 不追加。原始 reason 原样保留在
// 前，调用方既有 match 断言不受影响。
export function withPreExecAtomicity(reason: string): string {
	return `${reason}拦截发生在命令启动前：整条命令（含 && / ; / | 连接的全部前置段）均未执行，系统状态未因本次调用改变——请勿基于「部分已执行」的假设继续操作。`;
}

const COMMIT_GUARD = {
	block_sensitive_files: [".env", "*.pem", "*.key", "credentials*", "*secret*", "id_rsa*"],
	block_paths: ["node_modules/", ".git/"],
	max_file_mb: 10,
};

const JSON_MAX_BYTES = 5 * 1024 * 1024;
const SENTINEL_MAX_PER_KEY = 1;
const SENTINEL_MAX_PER_CATEGORY = 2;
const SENTINEL_MAX_PER_SESSION = 5;

const HIGH_RISK_PATTERNS: Array<[RegExp, string]> = [
	[/(?:^|\/)\.env(?:\.|$)/i, "环境变量"],
	[/(?:^|\/)\.ssh(?:\/|$)/i, "SSH 密钥"],
	[/(?:^|\/)migrations?(?:\/|$)/i, "数据库迁移"],
	[/\.sql$/i, "SQL"],
	[/(?:^|\/)credentials?(?:[./]|$)/i, "凭据"],
	[/(?:^|\/)secrets?(?:[./]|$)/i, "密钥"],
	[/(?:^|\/)auth(?:\/|$)/i, "认证"],
	// v1.5.190 实战缺口：auth.json（pi/各工具 provider 凭证集中落盘，含 OAuth refresh token）
	// 不在任何模式内——`auth` 模式要求 `auth/` 或 `auth$`，`auth.json` 恰恰漏网。
	// 边界用 \b 而非 $：哨兵传入的是整条 bash 命令文本，auth.json 后面常跟空格/管道。
	[/(?:^|\/)auth\.json\b/i, "认证凭据"],
	[/(?:^|\/)permissions?(?:\/|$)/i, "权限"],
	[/\.pem$/i, "证书"],
	[/\.key$/i, "密钥文件"],
	[/(?:^|\/)id_rsa(?:[./]|$)/i, "SSH 私钥"],
	[/(?:^|\/)schema(?:\/|$)/i, "Schema"],
	[/(?:^|\/)\.pi\/.*settings/i, "pi 配置"],
];

const DOUBLE_QUOTED_BACKTICK_ADVICE = "[AMAGI 守卫·软提示] 双引号内反引号按字面处理（仅限简单 grep/sed pattern）；shell 本身仍可能展开，请确认命令意图。";

/**
 * v1.5.189 交互式卡死守卫（实战事故：`git rebase --continue` 唤起 vi，无 TTY 的
 * harness bash 挂起 3611s 人工中止）。工具进程 env 兜底（见 tool-process-env.ts）
 * 覆盖 git 系编辑器/分页器；本守卫拦 env 无法覆盖的程序级交互：
 * - 编辑器/分页器/TUI：一律阻止（B4A 措辞修正：按「无 TTY 通道+等待输入直至超时/人工中止」的
 *   对照事实拦告，不断言「必挂」）；应用 edit 工具/直接输出；
 * - REPL/数据库 CLI：零参数裸启动（必进交互）或强制 -i 才阻止，带脚本/-c 放行；
 * - ssh：无 BatchMode=yes 阻止（密码/host key 询问同样卡死）；crontab 仅 -e 阻止。
 */
const INTERACTIVE_ALWAYS: Array<[Set<string>, string, string]> = [
	[new Set(["vi", "vim", "nvim", "nano", "emacs", "pico", "micro", "joe", "hx", "helix"]), "交互式编辑器", "改用 edit 工具 / sed / heredoc 非交互编辑"],
	[new Set(["less", "more", "most", "man"]), "交互式分页器", "去掉分页器直接输出（管道场景已被 PAGER=cat 兜底）"],
	[new Set(["top", "htop", "btop", "glances", "watch"]), "交互式/持续监控", "用单次采样（ps / vm_stat / iostat 1）替代"],
	[new Set(["lazygit", "tig", "ranger", "nnn", "mc", "alsamixer", "k9s", "lazydocker"]), "交互式 TUI 程序", "用对应 CLI 的非交互子命令"],
];
const INTERACTIVE_REPL = new Set(["python", "python3", "node", "ruby", "irb", "perl", "lua", "php", "r"]);
const INTERACTIVE_DBCLI = new Set(["mysql", "mariadb", "psql", "sqlite3", "redis-cli", "mongo", "mongosh", "influx"]);

/** ev-20261108-e73f44③：sqlite3 取值型旗标——跟值 token 不是位参（-init FILE / -cmd COMMAND /
 *  -separator SEP / -nullvalue TEXT / -newline SEP / -maxsize N / -mmap SZ / -repeat N；
 *  e73f44-r3 按 sqlite3 --help 补全：-vfs NAME / -key KEY / -hexkey KEY / -textkey PHRASE /
 *  -alg ALGO / -escape T / -nonce STRING / -screenwidth N / -A ARGS）。 */
const SQLITE3_VALUE_FLAGS = new Set(["-init", "-cmd", "-separator", "-nullvalue", "-newline", "-maxsize", "-mmap", "-repeat", "-vfs", "-key", "-hexkey", "-textkey", "-alg", "-escape", "-nonce", "-screenwidth", "-A"]);
/** 同上，取双值的旗标（-lookaside SIZE N / -pagecache SIZE N）。 */
const SQLITE3_TWO_VALUE_FLAGS = new Set(["-lookaside", "-pagecache"]);

/** ev-20261108-e73f44③：sqlite3 一次性形态判定（true=不进 REPL，不命中交互规则）。
 *  实战 `sqlite3 db ".schema kb_builds"` 被误报「交互式」；实测口径（本机 sqlite3 3.54）：
 *  `sqlite3 <db> "<SQL/.dot命令>"` 带第二个位参即一次性执行（-readonly/-csv 等旗标不改变），
 *  -version/-help 即退；`<`/`<<`/`<<<`（重定向/heredoc/here-string）与管道输入是有限 stdin，
 *  同样不等 TTY。仅裸启动、只给 db 文件（无 SQL）或 -interactive 才进 REPL——sqlite3 的交互
 *  旗标是 -interactive，-i 不是它的交互旗标，不参与强制交互判定。取值型旗标的跟值 token
 *  不计位参，防 `-init x.sql app.db` 被误算成「db 外还有位参」。
 *  e73f44-r2（diting m2）：-cmd/-batch 不构成一次性——开放管道 stdin 实测 `sqlite3 -cmd
 *  "select 1" :memory:` / `sqlite3 -batch :memory:` 均阻塞直至被杀（无 SQL 位参时它们仍读
 *  stdin，仍是 REPL 形态）；一次性只由「≥1 个 SQL/点命令位参」或「有限 stdin」构成。空串
 *  位参计入位参（实测 `sqlite3 :memory: ""` 即退 rc=0）。
 *  e73f44-r3（diting m-a）：空串词的归属由 span 词表统一判定（sqlite3SpanPositionals）——空串
 *  是取值旗标的跟值时不计位参（`sqlite3 db -init ""` 仍读 stdin = REPL，拦），是独立位参时计入
 *  （`sqlite3 db ""`/`sqlite3 :memory: ""` 一次性，放行）；旧「空词无语境全计」会把
 *  `-init ""` 误判一次性。 */
function sqlite3OneShotArgs(rest: string[], pipedStdin: boolean, spanPositionals: number): boolean {
	if (rest.includes("-interactive")) return false;
	if (pipedStdin) return true;
	for (const w of rest) {
		if (w.startsWith("<")) return true;
		const eq = w.indexOf("=");
		const name = eq > 0 ? w.slice(0, eq) : w;
		if (name === "-version" || name === "-help" || name === "--version" || name === "--help") return true;
	}
	return spanPositionals >= 2;
}

/** e73f44-r3（diting m-a）：sqlite3 段的位参计数（span 词表，保留空引号词，带旗标跳值）——
 *  tokenizeShell 丢空词、shellPipelineChains 只剩词数组，改经 tokenizeShellSpans 按控制符切段；
 *  从「剥 wrapper 后首词是 sqlite3」的段内 sqlite3 词之后按同一旗标口径跳取值/双值旗标的跟值，
 *  余下（含空串词）计位参。SPAN 与 legacy 切分差异仅单 & 后台串联；同命令多 sqlite3 段时计数
 *  合并，属刻意对抗形态（本模块申明不防）。 */
function sqlite3SpanPositionals(stripped: string): number {
	let count = 0;
	for (const seg of segmentShellSpans(tokenizeShellSpans(stripped))) {
		const segWords = seg.filter((s) => s.kind === "word");
		const words = executableWords(segWords.map((s) => s.text));
		if (path.basename(words[0] ?? "").toLowerCase() !== "sqlite3") continue;
		const spanTexts = segWords.map((s) => s.text);
		const start = spanTexts.indexOf(words[0]!);
		const args = start >= 0 ? spanTexts.slice(start + 1) : [];
		for (let i = 0; i < args.length; i++) {
			const w = args[i]!;
			if (w === "--") { count += args.length - 1 - i; break; }
			if (w === "-" || !w.startsWith("-")) { count++; continue; }
			const eq = w.indexOf("=");
			if (eq > 0) continue;
			const name = w;
			if (SQLITE3_TWO_VALUE_FLAGS.has(name)) i += 2;
			else if (SQLITE3_VALUE_FLAGS.has(name)) i += 1;
		}
	}
	return count;
}

/** 8月迭代 pi-0.84 配合 P1①：PowerShell 专有危险命令守卫——pi 0.84.3 新增可选内置 powershell 工具
 *  （Windows），守卫链原全锚定 bash 会对启用该工具的用户整条旁路，本函数补 PS 语法模式。
 *  只拦高置信破坏性形态（本模块是轻护栏不是安全边界，与模块头声明同款取舍：伪命中容忍优先于
 *  漏拦误拦，刻意对抗不在此层防御）；POSIX 侧 assertSafeCommand 对 PS 输入直接复用（rm -rf /、
 *  git push、curl|sh 等跨 shell 同险，PS 中 rm/del/curl 为同义别名）。 */
export function assertPowerShellDanger(command: string, toolName?: string): string | null {
	// ev-20260903-96b827②（实战：macOS 上 find/rm 单文件删除被「PowerShell 通配符批量删除」规则
	// 误拦——bash 的 rm build/* 是 POSIX 正常通配删除而非 PS 语法）：PS 别名/cmdlet 族规则平台分流，
	// 仅 powershell 工具或 win32 平台启用；toolName 缺省=未知调用方，保守沿用启用（纯函数回归语义不变）。
	// 例外：powershell/pwsh -EncodedCommand 自嵌套混淆检测不参与分流——bash 里嵌 PS 混淆执行两边都该拦
	//（-NoExit/-Interactive 交互旗标在 assertPowerShellInteractive，本就不分流）。
	const psSyntaxApplies = toolName === undefined || toolName === "powershell" || process.platform === "win32";
	// 删除系词组：Remove-Item cmdlet + ri/rm/rmdir/rd/del/erase 官方别名（修复轮补 ri）。git/npm/docker
	// 的 rm 子命令是版本库/包/容器操作而非文件系统删除，lookbehind 排除防误拦（git rm --cached *.log 等高频形态）。
	const removeWord = /\b(?<!\b(?:git|npm|docker)\s)(?:remove-item|rmdir|rd|del|erase|rm|ri)(?![\w:])/i;
	// 删除系带 -Recurse/-Force 完整参数（参数缩写如 -r/-fo 不拦——PS 允许前缀缩写，防误伤只认全词）
	if (psSyntaxApplies && new RegExp(removeWord.source + "[^|;&\\n]*\\s-(?:recurse|force)\\b", "i").test(command)) {
		return "[AMAGI 守卫] 已阻止危险命令（PowerShell 递归/强制删除）。";
	}
	// 删除系 + 通配目标（Remove-Item *.log，或通配管道进删除段：Get-ChildItem *.log | Remove-Item）。
	// 修复轮：字面量字符类的 \\n 曾实为「反斜杠+字母 n」而非换行——含 n 的路径/参数（如 *.json、-Name）直接断链，
	// 已统一改为 \n（构造器形态字符串 "\\n" 本就正确，不动）。
	if (psSyntaxApplies && (new RegExp(removeWord.source + "[^|;&\\n]*\\*", "i").test(command) || /\*[^|;&\n]*\|\s*(?:remove-item|rmdir|rd|del|erase|rm|ri)(?![\w:])/i.test(command))) {
		return "[AMAGI 守卫] 已阻止危险命令（PowerShell 通配符批量删除）。";
	}
	if (psSyntaxApplies && /\b(?:format-volume|clear-disk)\b/i.test(command)) return "[AMAGI 守卫] 已阻止危险命令（格式化卷/清空磁盘）。";
	if (psSyntaxApplies && /\bset-executionpolicy\b/i.test(command)) return `${guardRuleTag("powershell.executionPolicy")} 已阻止危险命令（修改 PowerShell 执行策略——该修改可持久影响主机安全配置（scope 取决于参数：CurrentUser/LocalMachine 需注册表变更，Process 仅当前会话）；与本次任务目标无涉。B4·批C：本机无 PowerShell 平台，行为未实测，维持 block 不翻转（规则 ID 与平台未验证口径见 /amagi config explain）；如确需调整请在宿主侧由操作者执行并明确 scope）。`;
	if (psSyntaxApplies && /\breg(?:\.exe)?\b\s+delete\b/i.test(command)) return "[AMAGI 守卫] 已阻止危险命令（删除注册表项）。";
	if (psSyntaxApplies && /\bstop-process\b[^|;&\n]*\s-force\b/i.test(command)) return "[AMAGI 守卫] 已阻止危险命令（强制终止进程）。";
	// Invoke-Expression/iex 执行远程下载内容（下载器 + URL 双条件同时命中才拦，本地脚本 iex 放行；irm=Invoke-RestMethod 别名，修复轮补）
	if (psSyntaxApplies && /\b(?:invoke-expression|iex)\b/i.test(command) && /https?:\/\//i.test(command) && /\b(?:invoke-webrequest|iwr|irm|curl|wget)\b/i.test(command)) {
		return `${guardRuleTag("command.remoteExecution")} 已阻止危险命令（远程下载内容交给 Invoke-Expression 执行）。`;
	}
	// powershell/pwsh 自嵌套 + Base64 混淆执行
	if (/\b(?:powershell|pwsh)(?:\.exe)?\b[^|;&\n]*\s-encodedcommand\b/i.test(command)) {
		return "[AMAGI 守卫] 已阻止危险命令（PowerShell -EncodedCommand 混淆执行）。";
	}
	return null;
}

/** 8月迭代 pi-0.84 配合 P1①：PowerShell 交互旗标守卫——powershell/pwsh 带 -NoExit/-Interactive 在
 *  无 TTY 的 harness 中必然挂起（-NoExit 执行完保持会话等待输入、-Interactive 强制交互提示）。
 *  命令文本任意位置的自嵌套调用同样命中（bash/powershell 两路共用，覆盖嵌套启动场景）。 */
export function assertPowerShellInteractive(command: string): string | null {
	if (/\b(?:powershell|pwsh)(?:\.exe)?\b[^|;&\n]*\s-(?:noexit|interactive)\b/i.test(command)) {
		return `${guardRuleTag("command.interactive")} 已阻止交互式 PowerShell 会话——对照：-NoExit 执行完保持会话、-Interactive 强制交互提示，两者都可能停在等待输入（未逐程序实测无 TTY 行为）；若停在等待，本工具 shell 无 TTY（输入不可达；有 timeout 时至超时收口，无 timeout 需人工中止）；去掉旗标用 -Command 一次性执行。`;
	}
	return null;
}

export function assertNonInteractive(command: string): string | null {
	// P3：heredoc body 内的「交互式命令」是字面文本（引用/未引用定界符均不交互启动）→ 剥除后再分析
	// （ev-20261012 N2 结构性批已落地：splitHeredocs 引号/注释感知识别引入、精确闭合定界行剔除、
	// 反斜杠续行词法层拼接——af9e9a 误拦根治且不产生 G2 三 Major 放行面；验收=G2-review-A +
	// 52 例矩阵 + 形态等价矩阵 + 差分模糊，见 .agent-outputs/evolve/2.19.3/N2-report.md。）
	const { stripped } = splitHeredocs(command);
	// ev-20261108-e73f44③：shellPipelineChains 的段集与 shellSegments 完全一致（同一 tokenizer、
	// 同一组分隔符），仅多保留链内位置——sqlite3 分支据此识别「段经管道接收 stdin」的一次性形态
	//（`echo "select 1" | sqlite3 app.db`）；其余规则不感知链位置，行为不变。
	const segments: Array<{ words: string[]; pipedStdin: boolean }> = [];
	for (const chain of shellPipelineChains(stripped)) chain.forEach((segment, i) => segments.push({ words: executableWords([...segment]), pipedStdin: i > 0 }));
	// e73f44-r3：sqlite3 段位参计数（span 词表带旗标跳值，见 sqlite3SpanPositionals）
	const sqliteSpanPositionals = sqlite3SpanPositionals(stripped);
	for (const { words, pipedStdin } of segments) {
		if (!words.length) continue;
		const exe = path.basename(words[0]).toLowerCase();
		for (const [names, label, hint] of INTERACTIVE_ALWAYS) {
			if (names.has(exe)) return `${guardRuleTag("command.interactive")} 已阻止${label}——对照：${label}需 TTY 交互，本工具 shell 无 TTY（PAGER=cat 等非交互 env 已注入），可能停在等待输入（未逐程序实测无 TTY 行为）；若停在等待，有 timeout 时至超时收口、无 timeout 需人工中止；${hint}。`;
		}
		if (INTERACTIVE_REPL.has(exe) || INTERACTIVE_DBCLI.has(exe)) {
			const rest = words.slice(1);
			// ev-20261108-e73f44③：sqlite3 一次性查询形态不命中交互规则（判定依据见 sqlite3OneShotArgs）；
			// 其余 DBCLI/REPL 维持既有口径（裸启动或 -i 拦，带脚本/-c/-e 放行）。
			if (exe === "sqlite3") {
				if (sqlite3OneShotArgs(rest, pipedStdin, sqliteSpanPositionals)) continue;
				return `${guardRuleTag("command.interactive")} 已阻止交互式 REPL/CLI（sqlite3 裸启动、仅给 db 文件（无 SQL）或 -interactive 进入交互模式，本工具 shell 无 TTY——可能停在等待输入（未逐程序实测），若停在等待则直至超时/人工中止；给第二个位参（SQL/点命令，空串 "" 也算）或有限 stdin（重定向/heredoc/管道）一次性执行——-cmd/-batch 不带 SQL 位参时仍读 stdin）。`;
			}
			const forceInteractive = rest.some((w) => w === "-i" || w === "--interactive");
			// v1.5.216: node -p/--print 同为一次性执行形式（打印即退），并入 eval 集
			const hasScriptOrEval = rest.some((w) => !w.startsWith("-") || /^-([ce]|p)$/i.test(w) || w.startsWith("--eval") || w === "--print");
			// v1.5.216: 版本/帮助是一次性退出形式，放行（实战误拦：node -v / python -V / python --version）。
			// python 系 -v 是 verbose（裸跑仍进 REPL），其版本旗标是 -V；其余 REPL 的 -v/-V 均为 version。
			const hasOneShotExit = rest.some((w) => w === "--version" || w === "-h" || w === "--help" || (/^python/.test(exe) ? w === "-V" : w === "-v" || w === "-V"));
			if (forceInteractive || (!hasScriptOrEval && !hasOneShotExit)) {
				return `${guardRuleTag("command.interactive")} 已阻止交互式 REPL/CLI（${exe} 裸启动或 -i 进入交互模式，本工具 shell 无 TTY——可能停在等待输入（未逐程序实测），若停在等待则直至超时/人工中止；用 -c/-e/脚本文件一次性执行）。`;
			}
			continue;
		}
		if (exe === "ssh" || exe === "telnet" || exe === "ftp" || exe === "sftp") {
			if (exe === "ssh" && words.some((w) => /BatchMode\s*=\s*yes/i.test(w))) continue;
			return `${guardRuleTag("command.interactive")} 已阻止交互式远程会话（${exe} 的密码/密钥确认需交互输入，本工具 shell 无 TTY——询问将挂起直至超时/人工中止；ssh 请加 -o BatchMode=yes 或使用非交互命令通道）。`;
		}
		if (exe === "crontab" && words.includes("-e")) {
			return `${guardRuleTag("command.interactive")} 已阻止 crontab -e（唤起交互式编辑器，本工具 shell 无 TTY——编辑器可能停在等待输入（未逐程序实测），若停在等待则直至超时/人工中止；用 crontab <file> 或管道写入）。`;
		}
	}
	return null;
}

/** B4·批C（D1/D2/D3，ev-20261012-af58eb §8 批C）：命令风险分类扫描——一次扫描收集全部命中，
 *  恒 block 的危险段（hard）与 rule 可控的启发式（wait/opaque）分离；事件链消费 hard 优先，
 *  启发式按 guard-policy 投影分流 block/disclose。发现顺序（first）保持 assertSafeCommand
 *  旧优先序（兼容既有纯函数语义：检测照常，阻断分流在事件链）。
 *  D3 语义变化（Leader 裁定）：parseErrors 不再短路后续扫描——已识别不可逆段（curl|sh、
 *  rm -rf 根、kill 全用户等）不因解析失败放行；不可安全展开的双引号反引号 payload 原文
 *  （view.unsafeBacktickPayloads）一并递归扫描。 */
export interface CommandRiskScan {
	/** 恒 block：红线/remoteExecution/终止进程/递归删除根/eval 远程载荷/不可安全展开段内已识别危险。 */
	hard: string | null;
	/** D2 command.wait：长 sleep/无限循环/read -p/stdin 等待（rule 可控）。 */
	wait: string | null;
	/** D3 command.opaque：解析深度>4/无已知危险的不可安全展开（rule 可控）。未闭合替换修复轮四收回后恒 block（归 hard），不在此列。 */
	opaque: string | null;
	/** 发现顺序首个命中（assertSafeCommand 兼容口径）。 */
	first: string | null;
}

function emptyRiskScan(): CommandRiskScan {
	return { hard: null, wait: null, opaque: null, first: null };
}

function mergeRiskScan(into: CommandRiskScan, from: CommandRiskScan): void {
	into.hard ??= from.hard;
	into.wait ??= from.wait;
	into.opaque ??= from.opaque;
	into.first ??= from.first;
}

export function scanCommandRisk(command: string, depth = 0): CommandRiskScan {	const out = emptyRiskScan();
	const push = (kind: "hard" | "wait" | "opaque", reason: string) => {
		out[kind] ??= reason;
		out.first ??= reason;
	};
	if (depth > 4) {
		push("opaque", `${guardRuleTag("command.opaque")} 检测到无法安全展开的嵌套 shell 命令（解析深度>4 层，超出守卫有界扫描深度）——前 4 层内已识别危险段照常拦截，更深嵌套未逐层展开。`);
		return out;
	}
	// ev-20260922-2d5a76：改用 analyzeExecutableShell 统一语义视图（与 assertCommitSafe/stash 门同源）——
	// P3 heredoc 字面量放行语义保持：quoted delimiter body 只作数据；unquoted body 的 $()/反引号
	// 按 heredoc 展开规则扫描后递归检查（真实危险不漏）。
	// B4·批C（D3）：parseErrors 不再短路——已识别不可逆段不因解析失败放行。B4C 修复轮四：
	// 未闭合（UNCLOSED_*）恒 block（收回，见下方）；不可安全展开（UNSAFE_DOUBLE_QUOTED_
	// BACKTICK：bash 真实执行但守卫无法安全展开）维持 opaque，payload 原文经
	// unsafeBacktickPayloads 递归扫描，已识别危险段仍拒。
	const view = analyzeExecutableShell(command);
	// B4C 修复轮四（Leader 裁定收回）：未闭合替换（UNCLOSED_*）恒 block——该形态真实 bash 报
	// 语法错误零成功执行，block 无能力损失；曾连续四轮被构造出 Critical 凭据底线绕过（终轮复审
	// ③：heredoc 前缀/变量拼接/ANSI-C/数据通道静态不可收敛）。不可安全展开（UNSAFE 双引号
	// 反引号：bash 真实执行但守卫无法安全展开）维持 opaque 分流，payload 原文照常递归扫描。
	const hasUnclosed = view.parseErrors.some((e) => e === "__AMAGI_UNCLOSED_BACKTICK__" || e === "__AMAGI_UNCLOSED_COMMAND_SUBSTITUTION__");
	if (hasUnclosed) {
		push("hard", `${guardRuleTag("command.opaque")} 检测到未闭合的反引号/命令替换（真实 bash 报语法错误不执行——B4C 前置实测）——含解析错误的命令按 fail-safe 保守阻止（B4C 修复轮四 Leader 裁定收回未闭合子翻转）。已识别危险段照常拦截；变通：修正闭合后重试，或用 write 工具把脚本落盘后执行。`);
		return out;
	}
	if (view.parseErrors.length) {
		push("opaque", `${guardRuleTag("command.opaque")} 检测到无法安全展开的反引号命令替换（双引号内含 shell 元字符；payload 已递归扫描，已识别危险段照常拦截）。`);
	}
	for (const payload of [...view.unquotedBodyPayloads, ...view.wrapperPayloads, ...view.substitutionPayloads, ...view.unsafeBacktickPayloads]) {
		const nested = scanCommandRisk(payload, depth + 1);
		mergeRiskScan(out, nested);
	}
	const commandText = view.stripped;

	const tokens = shellTokens(commandText);
	for (let i = 0; i < tokens.length - 2; i++) {
		const sender = path.basename(tokens[i]).toLowerCase();
		if (sender === "curl" || sender === "wget") {
			for (let pipe = i + 1; pipe < tokens.length; pipe++) {
				if (["&&", "||", ";", "\n"].includes(tokens[pipe])) break;
				if (tokens[pipe] !== "|") continue;
				let end = pipe + 1;
				while (end < tokens.length && !CONTROL_OPERATORS.has(tokens[end])) end++;
				const receiver = executableWords(tokens.slice(pipe + 1, end), true);
				if (["sh", "bash", "zsh"].includes(path.basename(receiver[0] || ""))) { push("hard", `${guardRuleTag("command.remoteExecution")} 已阻止危险命令（远程下载管道执行）。`); break; }
			}
		}
	}

	for (const segment of shellSegments(commandText)) {
		const normalized = [...segment];
		if (normalized.length) {
			normalized[0] = normalized[0].replace(/^\(+/, "");
			normalized[normalized.length - 1] = normalized[normalized.length - 1].replace(/\)+$/, "");
		}
		const words = executableWords(normalized);
		if (!words.length) continue;
		const executable = path.basename(words[0]).toLowerCase();
		if (executable === "while" && (words[1]?.toLowerCase() === "true" || words[1] === ":")) { push("wait", `${guardRuleTag("command.wait")} 检测到无限循环（while true）——命令将循环直至退出条件/超时/中止。`); continue; }
		if (/^for\s*\($/i.test(words[0]) || /^for\(;;\)/i.test(words.join(" "))) { push("wait", `${guardRuleTag("command.wait")} 检测到无限循环（for(;;)）——命令将循环直至退出条件/超时/中止。`); continue; }
		if (/^(?:raw_)?input\s*\(/i.test(words[0])) { push("wait", `${guardRuleTag("command.wait")} 检测到等待标准输入（input()）。`); continue; }
		if (executable === "read" && words.slice(1).some((word) => /^-[^-]*[pe]/.test(word))) { push("wait", `${guardRuleTag("command.wait")} 检测到等待标准输入（read -p/-e）。`); continue; }
		if (executable === "sleep" && Number(words[1]) >= 1000) { push("wait", `${guardRuleTag("command.wait")} 检测到超长 sleep（${words[1]}s）——执行将占用前台直至结束/超时/中止。`); continue; }
		if (executable === "pkill" && words.some((word) => /bash/i.test(word))) { push("hard", "[AMAGI 守卫] 已阻止危险命令（终止 bash 进程）。"); continue; }
		if (executable === "kill" && words.includes("-9") && words.includes("-1")) { push("hard", "[AMAGI 守卫] 已阻止危险命令（终止当前用户全部进程）。"); continue; }
		if (executable === "rm" && words.slice(1).some((word) => /^-[^-]*r[^-]*f|^-[^-]*f[^-]*r/.test(word)) && words.includes("/")) { push("hard", "[AMAGI 守卫] 已阻止危险命令（递归删除根目录）。"); continue; }
		if (executable === "eval") {
			const payload = words.slice(1).join(" ");
			const downloaderSubstitution = /(?:\$\([^)]*\b(?:curl|wget)\b|`[^`]*\b(?:curl|wget)\b)/i.test(payload);
			if (downloaderSubstitution || containsDownloader(payload) || substitutionPayloads(payload).some(containsDownloader)) { push("hard", `${guardRuleTag("command.remoteExecution")} 已阻止危险命令（远程下载内容交给 eval 执行）。`); continue; }
		}
		if (/^(?:python|python\d+(?:\.\d+)?)$/.test(executable)) {
			const cIndex = words.indexOf("-c");
			const payload = cIndex >= 0 ? words[cIndex + 1] || "" : "";
			if (/\b(?:raw_)?input\s*\(/i.test(payload) || /\bwhile\s+True\s*:/i.test(payload)) { push("wait", `${guardRuleTag("command.wait")} 检测到 Python 非交互等待/无限循环。`); continue; }
		}
	}
	//（B4C 修复轮四：未闭合形态已在上方 hard 分支提前返回，不再有「零执行折叠 wait」的路径。）
	return out;
}

/** 兼容导出（既有测试/外部消费者）：返回发现顺序首个命中（检测照常）；阻断分流在事件链
 *  （B4·批C 起 wait/opaque 按 guard-policy 投影，hard 恒 block）。 */
export function assertSafeCommand(command: string, depth = 0): string | null {
	return scanCommandRisk(command, depth).first;
}

/** ev-20261004-e023ed②：子代理未传 timeout 的 bash 注入默认上限（纯函数，供测试直接断言；
 *  B4·批C 起自 bash-override.ts 迁入本模块并在此 re-export 保持外部 import 路径——
 *  bashBoundedExecutionInfo 与执行链 effectiveTimeout 同源消费，两套兑底判定不可能分叉）。
 *  根因：steer 送达挂在「下一个模型请求前」，而未传 timeout 的长阻塞 bash（实战 85 分钟 find /
 *  双进程悬挂）使下一个模型请求不可达——默认上限把「模型请求不可达窗口」从无界收敛为有限
 * （缺省 600s）。仅子代理进程（AMAGI_SUBAGENT=1）生效；AMAGI_SUBAGENT_BASH_TIMEOUT 可调，
 *  =0/off 关闭；显式传了合法 timeout（>0 有限数）则不干预。 */
export function resolveSubagentBashDefaultTimeout(
	env: NodeJS.ProcessEnv = process.env,
	timeoutParam: unknown,
): number | undefined {
	if (env.AMAGI_SUBAGENT !== "1") return undefined;
	if (typeof timeoutParam === "number" && Number.isFinite(timeoutParam) && timeoutParam > 0) return undefined;
	const raw = env.AMAGI_SUBAGENT_BASH_TIMEOUT;
	if (raw === "0" || raw?.toLowerCase() === "off") return undefined;
	const v = raw === undefined || raw.trim() === "" ? 600 : Number(raw);
	if (!Number.isFinite(v) || v <= 0) return 600; // 非法值回缺省（不静默关闭）
	return v;
}

/** B4·批C（D1/D2/D3 disclose 前提）：本次 bash/powershell 调用是否有有限执行兑底。
 *  显式 timeout（有效正数秒）→ bounded(timeoutSec)；子代理（AMAGI_SUBAGENT=1）未传 timeout
 *  且默认超时未关闭 → bounded(默认秒数；与执行链 effectiveTimeout 同源 resolveSubagentBashDefault
 *  Timeout，镜像断言不再是必要——同一函数）。powershell 工具通道（仅 Windows）本机无法实测——
 *  恒 unbounded（该通道 disclose 不生效，与 D4 同口径的平台未验证处置）。 */
export interface BashBoundedExecutionInfo {
	bounded: boolean;
	/** 兑底时限（秒；显式参数或子代理默认）。 */
	timeoutSec?: number;
	/** 无界/不可 disclose 的原因（block 文案与披露共用）。 */
	reason?: string;
}

export function bashBoundedExecutionInfo(input: Record<string, unknown> | undefined, toolName: string): BashBoundedExecutionInfo {
	if (toolName !== "bash") return { bounded: false, reason: "powershell 工具通道仅 Windows（本机未验证），不适用 disclose 前提" };
	const timeoutParam = input?.timeout;
	// B4C-R01：非正有限（0/-1/NaN 等）统一按「无兑底」处理——原生执行器对非法值直接报错零执行，
	// 但披露不得声称有有限时限（避免「0.15s」类误导）；不回退子代理默认（显式参数优先，非法即拒）。
	if (timeoutParam !== undefined) {
		if (typeof timeoutParam === "number" && Number.isFinite(timeoutParam) && timeoutParam > 0) return { bounded: true, timeoutSec: timeoutParam };
		return { bounded: false, reason: "timeout 参数非正有限数（原生将拒绝执行），按无兑底处理不 disclose" };
	}
	const defaultSec = resolveSubagentBashDefaultTimeout(process.env, timeoutParam);
	if (defaultSec !== undefined) return { bounded: true, timeoutSec: defaultSec };
	return { bounded: false, reason: "本次调用未传 timeout 且子代理默认超时不可用（非子代理或 AMAGI_SUBAGENT_BASH_TIMEOUT=0/off），无限兑底时挂起需人工中止" };
}

/** 无界时 block 文案的补充说明（有界时为空串）。 */
function boundedBlockSuffix(bounded: BashBoundedExecutionInfo): string {
	return bounded.bounded ? "" : `——本批 disclose 需有有限执行兑底，${bounded.reason ?? "当前调用无有限兑底"}；传 timeout 参数（秒）后重试即可按披露放行。`;
}

// ── ev-20260903-20063d：目录树删除清点守卫（rm -rf 前强制清点目标目录内容）──
// 实战事故：find -type f 已显示目录下两个文件，仅 mv 归位一个就 rm -rf 整树——非本人创建的
// V2.0 副本被毁且从未 git add 无法恢复。落地为「轻护栏·强制感知」：rm 含 -r/-R/--recursive 递归
// 旗标时对每个目录操作数做有界清点（深度≤4、条目≤200、读失败静默放行不拦——宁缺假数据）；
// 非空且（>1 个文件或含子目录）→ block 附内容清单（前 20 条 + 总数），要求先逐一处置；空目录或
// 恰好 1 个文件直接放行（正常清理零摩擦）。根/家目录硬拦由 assertSafeCommand 既有规则承担（接线
// 在其后，不重复）；通配/变量操作数无法可靠解析目标，静默跳过（与 bashWriteTargets 同款取舍）。

const RM_INVENTORY_MAX_DEPTH = 4;
const RM_INVENTORY_MAX_ENTRIES = 200;
const RM_INVENTORY_LIST_LIMIT = 20;

// ── ev-20260916-57c1c7：rm 拦截附可复制「移动保留」替代命令（仅可信非根路径） ──
// 只在既有目录清点拒绝、且已解析到可信非根目录的明确路径时，附 mv 到 mktemp 目录的可复制命令；
// 明确这是移动保留、不是删除，先核对归属再执行。路径不能确认/根/高危系统目录/家目录/临时目录
// 根不给命令；不输出未展开通配符或未转义路径；不改拦截规则。回滚 AMAGI_RM_MOVE_ADVICE=0/false/off。
const RM_MOVE_UNSAFE_ROOTS = new Set(["/", "/bin", "/sbin", "/etc", "/usr", "/lib", "/lib64", "/libx32", "/boot", "/dev", "/proc", "/sys", "/var", "/opt", "/private", "/system", "/library", "/applications"]);

/** shell 单引号安全引用（路径内单引号拆为 '\'' 序列）。 */
function shellSingleQuote(value: string): string {
	return `'${value.replaceAll("'", `'\\''`)}'`;
}

/** rm 清点拦截的可复制「移动保留」替代命令；不可信路径返回 null（纯函数，导出供测试）。 */
export function rmMoveAdvice(targetAbs: string): string | null {
	const v = process.env.AMAGI_RM_MOVE_ADVICE?.trim().toLowerCase();
	if (v === "0" || v === "false" || v === "off") return null;
	if (!targetAbs) return null;
	const resolved = path.resolve(targetAbs);
	if (!path.isAbsolute(resolved) || /[*?]/.test(resolved)) return null; // 未展开通配符绝不输出
	const lower = (resolved.toLowerCase().replace(/\/+$/, "") || "/");
	if (RM_MOVE_UNSAFE_ROOTS.has(lower)) return null;
	if (path.resolve(os.homedir()) === resolved) return null;
	if (path.resolve(process.env.TMPDIR ?? os.tmpdir()) === resolved) return null;
	return `如需保留后处置，可改用移动保留（是移动不是删除，先逐一核对目录归属再执行）：trash=$(mktemp -d "\${TMPDIR:-/tmp}/amagi-trash.XXXXXX") && mv ${shellSingleQuote(resolved)} "$trash/"（移动保留区位于系统临时目录，属可丢弃空间，需要释放空间时可对 "$trash" 直接 rm -rf 清理；超过 7 天会在 amagi 会话启动时自动清理，需长期保留请移出临时目录）`;
}

/** 单段 rm 词组解析：含递归旗标（-r/-R 簇或 --recursive）时返回操作数（-- 之后全取，选项/旗标
 *  排除——rm 无带值选项，扫描即安全），否则返回 null。纯函数零 fs 依赖。 */
function rmSegmentOperands(words: string[]): string[] | null {
	if (path.basename(words[0] || "").toLowerCase() !== "rm") return null;
	let recursive = false;
	let afterDash = false;
	const operands: string[] = [];
	for (const word of words.slice(1)) {
		if (afterDash) { operands.push(word); continue; }
		if (word === "--") { afterDash = true; continue; }
		if (word.startsWith("--")) { if (word === "--recursive") recursive = true; continue; }
		if (word.length > 1 && word.startsWith("-")) { if (/[rR]/.test(word.slice(1))) recursive = true; continue; }
		operands.push(word);
	}
	return recursive ? operands : null;
}

/** 命令内全部 rm 递归删除操作数（纯函数，导出供测试；cd 段自然跳过，相对路径解析在清点时进行）。 */
export function rmRecursiveOperands(command: string): string[] {
	const operands: string[] = [];
	for (const segment of shellSegments(splitHeredocs(command).stripped)) {
		const normalized = [...segment];
		if (normalized.length) {
			normalized[0] = normalized[0].replace(/^\(+/, "");
			normalized[normalized.length - 1] = normalized[normalized.length - 1].replace(/\)+$/, "");
		}
		const collected = rmSegmentOperands(executableWords(normalized, true));
		if (collected) operands.push(...collected);
	}
	return operands;
}

export interface RmTreeEntryStat {
	/** 相对路径（与清单同序）。 */
	rel: string;
	/** 目录条目标记（stat follow 后的物理落点）。 */
	dir: boolean;
	/** 条目物理身份（dev/ino）+ ctimeMs（任何数据/元数据写入都会更新、用户态 utimes 不可回拨——
	 *  同 size 同 mtime 的原地改写也可检出；是变更指示而非字节 hash）；文件条目另含 size/mtimeMs。 */
	dev?: number;
	ino?: number;
	ctimeMs?: number;
	size?: number;
	mtimeMs?: number;
	/** stat 不可用（断链 symlink 等）：仅记相对路径；断链↔可用状态翻转仍可比对。 */
	broken?: boolean;
}

export interface RmTreeInventory {
	/** 清点到的文件数（不含子目录）。 */
	files: number;
	/** 清点到的子目录数。 */
	dirs: number;
	/** 相对条目清单（目录以 / 结尾，已排序），≤RM_INVENTORY_MAX_ENTRIES 条。 */
	entries: string[];
	/** 与 entries 同序的条目物理指纹（D37-02：确认前后树状态比对用）。 */
	stats: RmTreeEntryStat[];
	/** 根目录物理身份（dev/ino）。 */
	rootDev: number;
	rootIno: number;
	/** 是否触及深度/条目上限截断（截断即必然违规，计数为下界）。 */
	truncated: boolean;
}

/** 目录有界清点（深度≤4、条目≤200，清单排序保证 reason 确定性）；任一目录读失败返回 null
 *  （调用方静默放行不拦——读失败≠危险，宁缺假数据不做保守硬拦）。D37-02：同时采集根目录与
 *  每个已清点条目的物理指纹（stat follow；stat 失败记 broken），供确认前后比对。 */
function collectRmInventory(root: string): RmTreeInventory | null {
	const result: RmTreeInventory = { files: 0, dirs: 0, entries: [], stats: [], rootDev: 0, rootIno: 0, truncated: false };
	try {
		const rootStat = fs.statSync(root);
		result.rootDev = rootStat.dev;
		result.rootIno = rootStat.ino;
	} catch { return null; }
	const rows: Array<{ entry: string; stat: RmTreeEntryStat }> = [];
	const pending: Array<{ dir: string; rel: string; depth: number }> = [{ dir: root, rel: "", depth: 0 }];
	while (pending.length) {
		const { dir, rel, depth } = pending.pop()!;
		let dirents: fs.Dirent[];
		try { dirents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
		for (const dirent of dirents) {
			if (rows.length >= RM_INVENTORY_MAX_ENTRIES) { result.truncated = true; break; }
			const relPath = rel ? `${rel}/${dirent.name}` : dirent.name;
			let entryStat: fs.Stats | undefined;
			try { entryStat = fs.statSync(path.join(dir, dirent.name)); } catch { entryStat = undefined; /* lint-exempt:条目 stat 失败记 broken，清点继续 */ }
			const rowStat: RmTreeEntryStat = entryStat
				? { rel: relPath, dir: entryStat.isDirectory(), dev: entryStat.dev, ino: entryStat.ino, ctimeMs: entryStat.ctimeMs, ...(entryStat.isDirectory() ? {} : { size: entryStat.size, mtimeMs: entryStat.mtimeMs }) }
				: { rel: relPath, dir: false, broken: true };
			rows.push({ entry: dirent.isDirectory() ? `${relPath}/` : relPath, stat: rowStat });
			if (dirent.isDirectory()) {
				result.dirs++;
				if (depth + 1 < RM_INVENTORY_MAX_DEPTH) pending.push({ dir: path.join(dir, dirent.name), rel: relPath, depth: depth + 1 });
				else result.truncated = true; // 深度上限外的子目录存在但不再展开
			} else result.files++;
		}
	}
	rows.sort((a, b) => (a.entry < b.entry ? -1 : a.entry > b.entry ? 1 : 0));
	result.entries = rows.map((r) => r.entry);
	result.stats = rows.map((r) => r.stat);
	return result;
}

/** ev-20261105-e4d22a：rm 清点违规目标的结构化描述（披露/确认弹窗/headless 文案共用）。 */
export interface RmTreeTarget {
	/** 原命令中的操作数（原样，供文案对照）。 */
	operand: string;
	/** 解析后的绝对目标路径。 */
	targetAbs: string;
	/** 清点文件数/子目录数/条目总数（截断时 total/files 为下界）。 */
	files: number;
	dirs: number;
	total: number;
	truncated: boolean;
	/** 前 RM_INVENTORY_LIST_LIMIT 条相对清单（已排序）。 */
	listing: string[];
	/** 树状态指纹（D37-02）：根 dev/ino + 有界清点条目集（rel/dir/dev/ino/ctimeMs/文件 size·mtimeMs）；
 *  截断时仅覆盖已清点条目，上限外部分不宣称已核验（确认弹窗与重查同口径披露）。 */
	fingerprint: string;
}

/** ev-20261105-e4d22a：rm 清点分流结果——general（非临时根后代：有 UI 真实确认、无 UI 阻断）
 *  与 temporary（系统临时根后代：披露放行）；两者皆空返回 null。 */
export interface RmTreeInventoryGate {
	general: RmTreeTarget[];
	temporary: RmTreeTarget[];
}

// ── ev-20261105-e4d22a：临时空间降级为披露放行 ──
// 实战卡点（evolution 证据 ev-20261105-e4d22a）：子 Agent 在 /private/tmp 与 $TMPDIR 下自建的实验
// 目录（含 mv 到 amagi-trash.* 的移动保留区）在「用户明确要求清理 + Leader 已清点核验」后仍被硬阻断，
// mv 到移动保留区不释放空间反而累积，最终只能交用户手工执行。根因：守卫只有「放行/硬阻断」两态，
// 缺少按目标来源的降级——系统临时空间（/tmp、/private/tmp、macOS 任务目录等）本就是可丢弃内容，
// 清点披露即可，无需确认；临时根本身不放行（防止删掉整个 TMPDIR）。原守卫防的真实事故
// （ev-20260903-20063d：项目内非本人创建的未跟踪副本被 rm -rf 毁掉）在项目/家目录语境仍由
// general 分支（确认/阻断）完整保留。
// D37-01（审核修复轮）：临时归属只按物理路径判定——目标 realpath 必须是「可信临时根」realpath 的
// 严格后代；字面路径命中但 realpath 落在项目/家目录等非临时区一律不放行（祖先 symlink 指向项目的
// 反例）；$TMPDIR/os.tmpdir() 只有当其 realpath 本身落在固定系统集合（含等于，或 macOS 任务目录
// 模式）内时才纳入，指向项目/家目录的 TMPDIR 不扩大免确认区；realpath 失败 → 不放行（走通用分支）。
// 回滚：AMAGI_RM_TMP_ALLOW=0/false/off（临时目录回到阻断，其余行为不变）。
const RM_TMP_FIXED_ROOTS = ["/tmp", "/private/tmp", "/var/tmp", "/private/var/tmp", "/dev/shm"];
const MACOS_TMP_TASK_DIR_RE = /^\/(?:private\/)?var\/folders\/[^/]+\/[^/]+\/T(?:\/|$)/;

/** AMAGI_RM_TMP_ALLOW 开关（默认开；0/false/off 关闭临时目录披露放行）。 */
export function rmTmpAllowEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const v = env.AMAGI_RM_TMP_ALLOW?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** 可信临时根 realpath 集合（D37-01）：固定系统根的 realpath，加上 realpath 本身落在固定集合（含
 *  等于）或 macOS 任务目录模式内的 $TMPDIR/os.tmpdir()；指向项目/家目录等的 TMPDIR 不纳入。
 *  固定根不存在（如非 Linux 的 /dev/shm）时跳过；每次现场解析不缓存——TMPDIR 可变（测试与运行时
 *  均可改写），正确性优先于几次 realpath 开销。 */
function rmTrustedTmpRoots(): string[] {
	const fixedReal = new Set<string>();
	for (const literal of RM_TMP_FIXED_ROOTS) {
		try { fixedReal.add(path.resolve(fs.realpathSync(path.resolve(literal)))); } catch { /* lint-exempt:不存在的固定根跳过，不入可信集合 */ }
	}
	const roots = new Set(fixedReal);
	for (const envRoot of [process.env.TMPDIR ?? "", os.tmpdir()]) {
		if (!envRoot) continue;
		let real: string;
		try { real = path.resolve(fs.realpathSync(path.resolve(envRoot))); } catch { continue; /* lint-exempt:TMPDIR realpath 失败的候选不纳入，其余根照常判定 */ }
		if (MACOS_TMP_TASK_DIR_RE.test(real) || [...fixedReal].some((f) => real === f || real.startsWith(f + path.sep))) roots.add(real);
	}
	return [...roots];
}

/** 目标是否为可信临时根的严格后代（D37-01：物理判定）。目标先解析为 realpath（解析祖先 symlink
 *  与 /tmp/../项目 形态），必须是固定系统根/macOS 任务目录模式的严格后代；realpath 失败 → false
 *  （不放行，走通用确认/阻断分支）；临时根本身不算后代。 */
export function isRmTemporaryDescendant(targetAbs: string): boolean {
	if (!rmTmpAllowEnabled()) return false;
	let realTarget: string;
	try { realTarget = path.resolve(fs.realpathSync(path.resolve(targetAbs))); } catch { return false; /* lint-exempt:realpath 失败不放行（走通用确认/阻断分支），不阻断降级 */ }
	const taskDir = MACOS_TMP_TASK_DIR_RE.exec(realTarget);
	if (taskDir && realTarget.length > taskDir[0].length) return true;
	for (const root of rmTrustedTmpRoots()) {
		if (realTarget !== root && realTarget.startsWith(root + path.sep)) return true;
	}
	return false;
}

/** 目录树删除清点分流（ev-20260903-20063d 建立，ev-20261105-e4d22a 分流）：跟踪 cd 的分段扫描，
 *  递归操作数指向「非空且（>1 文件或含子目录）」的目录时按临时根后代/其余分流收集（不短路，
 *  确认弹窗需覆盖命令内全部违规目标）；空目录/恰好 1 个文件/非目录/不存在/读失败/通配操作数
 *  → 不收集（放行）。无违规目标返回 null。 */
/** 树状态指纹（D37-02）：根目录物理身份 + 有界清点条目集（相对路径/类型/dev/ino/ctimeMs/文件 size·mtimeMs）
 *  序列化（ctime 覆盖保留 size/mtime 的原地改写；增量复审 R2）——同名替换/内容改写/断链翻转等同计数变化均可检出；截断时仅覆盖已清点条目。 */
function rmTreeFingerprint(inventory: RmTreeInventory): string {
	const parts = inventory.stats.map((s) => s.broken
		? `${s.rel}:broken`
		: s.dir ? `${s.rel}:d:${s.dev}/${s.ino}/${s.ctimeMs}` : `${s.rel}:f:${s.dev}/${s.ino}/${s.ctimeMs}/${s.size}/${s.mtimeMs}`);
	return JSON.stringify({ root: `${inventory.rootDev}/${inventory.rootIno}`, truncated: inventory.truncated, entries: parts });
}

/** 路径中任一段为 . 或 ..（D37-06：词法折叠与内核 symlink 遍历可能分叉）。 */
const DOT_SEGMENT_RE = /(?:^|\/)\.{1,2}(?:\/|$)/u;

export function rmTreeInventoryGate(command: string, cwd: string): RmTreeInventoryGate | null {
	const gate: RmTreeInventoryGate = { general: [], temporary: [] };
	let currentCwd = path.resolve(cwd);
	let cwdLexicalUncertain = false;
	for (const segment of shellSegments(splitHeredocs(command).stripped)) {
		const normalized = [...segment];
		if (normalized.length) {
			normalized[0] = normalized[0].replace(/^\(+/, "");
			normalized[normalized.length - 1] = normalized[normalized.length - 1].replace(/\)+$/, "");
		}
		if (normalized[0] === "cd" && normalized[1]) {
			currentCwd = path.resolve(currentCwd, normalizeGuardPath(normalized[1]));
			// D37-06：cd 参数含 ./.. 段或 -P 等选项时，词法 cwd 与内核物理遍历可能分叉（symlink 祖先
			// 后的 ..）——此后 symlink 叶子豁免不再可信，回到原清点。
			if (normalized.slice(1).some((arg) => arg.startsWith("-") || DOT_SEGMENT_RE.test(arg))) cwdLexicalUncertain = true;
			continue;
		}
		const operands = rmSegmentOperands(executableWords(normalized, true));
		if (!operands) continue;
		for (const operand of operands) {
			// 通配/变量/命令替换形态无法可靠解析目标，静默跳过（轻护栏不做保守硬拦）
			if (!operand || /[*?]/.test(operand) || operand.startsWith("$")) continue;
			const normalizedOperand = normalizeGuardPath(operand);
			const lexicalTarget = path.isAbsolute(normalizedOperand) ? path.normalize(normalizedOperand) : path.resolve(currentCwd, normalizedOperand);
			// D37-06：含 ./.. 段时按内核遍历语义取物理目标（libc realpath 逐段跟随 symlink 后再处理 ..），
			// 清点/确认/临时归属与 rm 实际删除对象一致；解析失败回落词法目标（既有口径）。
			let target = lexicalTarget;
			if (DOT_SEGMENT_RE.test(normalizedOperand)) {
				const raw = path.isAbsolute(normalizedOperand) ? normalizedOperand : `${currentCwd}/${normalizedOperand}`;
				try { target = fs.realpathSync.native(raw); } catch { target = lexicalTarget; /* lint-exempt:物理解析失败回落词法目标 */ }
			}
			// diting 增量复审 §2：rm -rf <symlink>（无尾斜杠）只删链接本身，不清点链接目标——直接
			// 放行；link/、link/.、link/.. 等尾部形态会作用到目标（POSIX 尾斜杠强制目录解释），保持
			// 原清点。尾形态判定用原始操作数（normalizeGuardPath 会剥尾斜杠）。
			const affectsTargetForm = /\/+$/u.test(operand) || /(?:^|\/)\.{1,2}$/u.test(operand);
			// D37-06（diting r3 Critical）：豁免只在「词法路径 = 内核遍历路径」时成立——操作数任一段为
			// . / ..（如 jump/../victim，jump 为 symlink 祖先）时，path.resolve 的词法折叠可能指向另一个
			// 对象（victim 链接），而 rm 实际删除物理遍历到的普通目录树；此类形态不豁免、回到原清点。
			const lexicalTraversalExact = !DOT_SEGMENT_RE.test(operand) && !cwdLexicalUncertain;
			if (!affectsTargetForm && lexicalTraversalExact) {
				try { if (fs.lstatSync(target).isSymbolicLink()) continue; } catch { continue; }
			}
			let stat: fs.Stats | undefined;
			try { stat = fs.statSync(target); } catch { continue; }
			if (!stat.isDirectory()) continue;
			const inventory = collectRmInventory(target);
			if (!inventory) continue;
			if (inventory.entries.length === 0) continue;
			if (inventory.files <= 1 && inventory.dirs === 0) continue;
			const entry: RmTreeTarget = {
				operand,
				targetAbs: target,
				files: inventory.files,
				dirs: inventory.dirs,
				total: inventory.entries.length,
				truncated: inventory.truncated,
				listing: inventory.entries.slice(0, RM_INVENTORY_LIST_LIMIT),
				fingerprint: rmTreeFingerprint(inventory),
			};
			(isRmTemporaryDescendant(target) ? gate.temporary : gate.general).push(entry);
		}
	}
	return gate.general.length || gate.temporary.length ? gate : null;
}

/** 无确认渠道（子代理/RPC/headless）时的可复制手工执行建议：仅对可信绝对路径输出
 *  （未展开通配/含通配字符的字面路径不输出）；复用 shellSingleQuote 单引号转义。 */
export function rmHeadlessManualAdvice(targets: RmTreeTarget[]): string {
	const trusted = targets.map((t) => t.targetAbs).filter((abs) => path.isAbsolute(abs) && !/[*?]/.test(abs));
	if (!trusted.length) return "";
	return `如主上已明确授权删除，可请主上手工执行：rm -rf ${trusted.map(shellSingleQuote).join(" ")}`;
}

/** 临时目录披露放行文案（接线层经 amagi:guard-note 发出，不阻断）。 */
export function rmTemporaryDisclosure(targets: RmTreeTarget[]): string {
	const files = targets.reduce((sum, t) => sum + t.files, 0);
	const dirs = targets.reduce((sum, t) => sum + t.dirs, 0);
	return `[递归删除·临时目录披露] 已放行递归删除 ${targets.length} 个系统临时目录（清点合计 ${files} 文件/${dirs} 子目录）：${targets.map((t) => t.targetAbs).join("、")}——系统临时空间（tmpdir 后代）本就是可丢弃内容；移动保留区（amagi-trash.*）也位于此处，可直接清理（超过 7 天亦会在 amagi 会话启动时自动清理）。`;
}

/** general 目标的阻断文案（保持 ev-20260903-20063d/B4A 既有措辞；ev-20261105-e4d22a 起多目标
 *  时列首个清单 + 其余摘要，并附 headless 手工执行建议与移动保留替代）。 */
export function rmTreeGeneralBlockReason(targets: RmTreeTarget[]): string {
	const first = targets[0];
	const listing = first.listing.join("、");
	const more = first.total > first.listing.length ? ` 等 ${first.total} 项` : "";
	const truncation = first.truncated ? "（清单已截断，实际不少于上述条目）" : "";
	// ev-20260916-57c1c7：可信非根路径附可复制移动保留替代（rmMoveAdvice 内含开关与高危路径过滤）。
	// B4A 措辞修正（对照式披露，不改判定）：清点可见项不等于已获授权；不建议拆成单文件/通配绕过清点。
	const moveAdvice = targets.map((t) => rmMoveAdvice(t.targetAbs)).filter(Boolean).join("\n");
	const others = targets.length > 1
		? `另有 ${targets.length - 1} 个同类待删目标：${targets.slice(1).map((t) => t.targetAbs).join("、")}（内容清单略，处置方式相同）。`
		: "";
	const manual = rmHeadlessManualAdvice(targets);
	return `[AMAGI 守卫] 已阻止递归删除未清点目录（${first.operand} 清点到 ${first.total} 个条目：${first.files} 文件/${first.dirs} 子目录${truncation}）：${listing}${more}。建议处置：先逐一处置（mv 归位/确认归属），确认目录内已无未处置文件后再删。对照：清点可见项不等于授权；改写成单文件/通配形态删除虽不经本门，但不会改变「目录内有未处置文件被删」的事实，按上面的处置方式走一遍就好。${others}${manual ? `\n${manual}` : ""}${moveAdvice ? `\n${moveAdvice}` : ""}`;
}

/** 目录树删除清点守卫（ev-20260903-20063d；ev-20261105-e4d22a 起临时根后代披露放行）：
 *  非 temporary 分流存在时返回 general 阻断文案，否则返回 null（放行；披露由接线层发出）。 */
export function assertRmTreeInventory(command: string, cwd: string): string | null {
	const gate = rmTreeInventoryGate(command, cwd);
	return gate?.general.length ? rmTreeGeneralBlockReason(gate.general) : null;
}

/** ev-20261105-e4d22a（O-01）：rm 清点三通道的入口公共段——分流、临时后代披露发送（经
 *  amagi:guard-note）与确认渠道解析。返回 general 目标与有 UI 时的确认函数；确认时机由调用方
 *  决定（bash 面需等全部同步门后延迟确认，run_bg 段无后续同步门可立即确认）；无确认渠道时
 *  返回 headless 阻断文案（已含预执行原子性说明）。bash 与 run_bg 两入口共用本函数，不复制分流逻辑。 */
interface RmTreeChannelPlan {
	/** 需真实确认/阻断的 general 目标（空 = 无违规或仅临时披露）。 */
	general: RmTreeTarget[];
	/** 有真实 UI 确认渠道且 general 非空时存在。 */
	confirmFn?: (title: string, message: string, opts?: { timeout?: number }) => Promise<boolean>;
	/** 无确认渠道时的阻断文案（general 非空且无 confirmFn；已含 withPreExecAtomicity）。 */
	headlessReason: string | null;
}

function planRmTreeChannels(pi: ExtensionAPI, ctx: any, command: string, cwd: string): RmTreeChannelPlan {
	const plan: RmTreeChannelPlan = { general: [], headlessReason: null };
	const rmGate = rmTreeInventoryGate(command, cwd);
	if (!rmGate) return plan;
	if (rmGate.temporary.length) {
		try { pi.sendMessage({ customType: "amagi:guard-note", content: rmTemporaryDisclosure(rmGate.temporary), display: false }, { deliverAs: "steer" }); } catch { /* lint-exempt:披露发送失败不影响放行 */ }
	}
	if (rmGate.general.length) {
		const rmUi = (ctx as { hasUI?: boolean; ui?: { confirm?: (title: string, message: string, opts?: { timeout?: number }) => Promise<boolean> } } | undefined);
		const confirmFn = ctx?.hasUI && typeof rmUi?.ui?.confirm === "function" ? rmUi.ui.confirm : undefined;
		if (confirmFn) plan.confirmFn = confirmFn;
		else plan.headlessReason = withPreExecAtomicity(rmTreeGeneralBlockReason(rmGate.general));
		plan.general = rmGate.general;
	}
	return plan;
}

/** ev-20261105-e4d22a：general 目标的真实确认（有 UI 时替代硬阻断；默认否/超时 120s/取消即拒）。
 *  确认通过后重查树指纹（D37-02）：根 dev/ino + 有界清点条目集（rel/dir/dev/ino/ctimeMs/文件 size·mtimeMs），
 *  任一不同即取消——同名替换/内容改写等同计数变化也可检出；截断时仅核验已清点条目，上限外
 *  部分不宣称已核验（弹窗与结果同口径披露）；目标消失/变空（无 general）→ 放行（已无可删内容）。 */
async function confirmRmTreeTargets(
	confirmFn: (title: string, message: string, opts?: { timeout?: number }) => Promise<boolean>,
	targets: RmTreeTarget[],
	command: string,
	cwd: string,
): Promise<{ block: true; reason: string } | undefined> {
	const summary = targets.map((t) => `${t.targetAbs}（清点到 ${t.total} 个条目：${t.files} 文件/${t.dirs} 子目录${t.truncated ? "，清单已截断——超出清点上限部分未纳入核验" : ""}）`).join("\n");
	const sample = targets[0].listing.join("、");
	const truncationNote = targets.some((t) => t.truncated) ? `\n注意：上述清单已触及清点上限，超出部分未纳入确认核验（删除仍覆盖整树）。` : "";
	let ok = false;
	try { ok = await confirmFn("[amagi] 递归删除未清点目录确认", `将递归删除以下未清点目录：\n${summary}\n首个目标内容：${sample}${truncationNote}\n删除不可恢复（默认否；超时/取消均视为拒绝）。`, { timeout: 120_000 }); } catch { ok = false; /* lint-exempt:confirm 异常（超时/取消）统一按拒绝处理 */ }
	if (!ok) {
		return { block: true, reason: withPreExecAtomicity(`[amagi 守卫·递归删除确认] 用户未确认删除（确认默认否；超时/取消均视为拒绝）——命令未执行。${rmTreeGeneralBlockReason(targets)}`) };
	}
	const recheck = rmTreeInventoryGate(command, cwd);
	if (recheck?.general.length) {
		const same = recheck.general.length === targets.length && recheck.general.every((t, i) =>
			t.targetAbs === targets[i].targetAbs && t.fingerprint === targets[i].fingerprint);
		if (!same) {
			return { block: true, reason: withPreExecAtomicity("[amagi 守卫·递归删除确认] 确认后检测到目标目录内容已变化（树指纹不一致：根身份或已清点条目的路径/类型/物理身份/内容指纹变化；触及清点上限的部分不在核验范围）——预检授权不能跨状态生效，本次执行已取消；请重新执行命令重新确认。") };
		}
	}
	return undefined;
}

// Git 调用解析共享层（GitInvocation/parseGitInvocations/resolveGitCommand/gitOutput/normalizeGuardPath/
// isReadOnlyCommand 等）已随 ev-20260916-S1 迁入 git-discard-guard.ts（见文件头部 import）。

function hasAllFlag(args: string[]): boolean {
	return args.some((arg) => arg === "--all" || /^-[^-]*a/.test(arg));
}

interface GitPathspecPlan { pathspecs: string[]; all: boolean; uncertain: boolean; }

function readPathspecFile(invocation: GitInvocation, value: string, nul: boolean): string[] | null {
	const workTree = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
	const file = path.resolve(workTree || invocation.cwd, value);
	try {
		const content = fs.readFileSync(file, "utf8");
		return content.split(nul ? "\0" : /\r?\n/).filter(Boolean);
	} catch { return null; }
}

function gitPathspecPlan(invocation: GitInvocation, subcommand: "add" | "commit", args: string[]): GitPathspecPlan {
	const pathspecs: string[] = [];
	let all = false, uncertain = false, afterDash = false, pathspecFile: string | undefined, pathspecNul = false;
	const valueOptions = new Set(subcommand === "commit"
		? ["-m", "--message", "-F", "--file", "--author", "--date", "-C", "--reuse-message", "-c", "--reedit-message", "--fixup", "--squash", "--cleanup", "--trailer"]
		: ["--chmod", "--pathspec-from-file"]);
	for (let i = 0; i < args.length; i++) {
		const arg = args[i];
		if (afterDash) { pathspecs.push(arg); continue; }
		if (arg === "--") { afterDash = true; continue; }
		if (arg === "-A" || arg === "--all" || arg === "-u" || arg === "--update") { if (subcommand === "add") all = true; continue; }
		if (arg === "--pathspec-file-nul") { pathspecNul = true; continue; }
		if (arg.startsWith("--pathspec-from-file=")) { pathspecFile = arg.slice("--pathspec-from-file=".length); continue; }
		if (valueOptions.has(arg)) { if (arg === "--pathspec-from-file") pathspecFile = args[i + 1]; i++; continue; }
		if (arg.startsWith("-")) continue;
		pathspecs.push(arg);
	}
	if (pathspecFile) {
		const fromFile = readPathspecFile(invocation, pathspecFile, pathspecNul);
		if (fromFile) pathspecs.push(...fromFile); else uncertain = true;
	}
	return { pathspecs, all, uncertain };
}

function gitFileSet(invocation: GitInvocation, plan: GitPathspecPlan): Set<string> | null {
	const files = new Set<string>();
	const specs = plan.pathspecs;
	const commands: string[][] = [];
	// ev-20260910-919667：① 路径限定优先——`-am` 这类合并短选项会把 commit message 误当 pathspec，
	// 故 `-A/-u`（plan.all）保留全仓保守判定，不因 pathspec 组合而收窄；
	// ② `git add .` 的 `.` 是无歧义 pathspec（作用域=命令 cwd 子树），旧写法（`plan.all || specs.includes(".")`）
	// 把它放大到整仓，会在子目录 add 时因仓库别处的敏感文件误报「提交包含不该提交的内容」；
	// ③ 全仓形态必须锚到仓库根：git ≥2.0 的 `-A/-u` 与 cwd 无关（暂存整个工作树），而 `ls-files --others`
	// 不带 pathspec 时只列 cwd 子树——子目录里跑 `git add -A` 会漏掉仓库别处的未跟踪敏感文件（假阴性）。
	// `:/` 是 root-anchored magic pathspec；`ls-files --full-name` 修正其 cwd 相对输出（与 diff 的
	// 仓库根相对不一致，会让 sensitiveHits 的 workTree 拼接/大小复核指错文件）。
	if (plan.all) {
		commands.push(["diff", "HEAD", "--name-only", "--no-relative", "--diff-filter=ACMR", "--", ":/"]);
		commands.push(["ls-files", "--others", "--exclude-standard", "--full-name", "--", ":/"]);
	} else if (specs.length) {
		commands.push(["diff", "HEAD", "--name-only", "--no-relative", "--diff-filter=ACMR", "--", ...specs]);
		commands.push(["ls-files", "--others", "--exclude-standard", "--full-name", "--", ...specs]);
	}
	// ev-20260804-5f2938：空仓库（无 HEAD）没有 tracked 修改面——diff HEAD 必失败，但
	// ls-files --others 已是完整写入集；放行首提交的 git add（显式路径/-A）而非保守阻断。
	let hasHead = true;
	try { hasHead = gitOutput(invocation, ["rev-parse", "--verify", "-q", "HEAD"]) !== null; } catch { /* 失败按有 HEAD 处理（保守） */ }
	for (const args of commands) {
		if (args[0] === "diff" && !hasHead) continue;
		const output = gitOutput(invocation, args);
		if (output === null) return null;
		for (const file of output.split(/\r?\n/).map((line) => line.trim()).filter(Boolean)) files.add(file);
	}
	for (const spec of specs) {
		const normalized = spec.replace(/^:\([^)]*\)/, "").replace(/^:\/?/, "");
		if (isSensitiveFile(normalized, COMMIT_GUARD.block_sensitive_files)) files.add(normalized);
	}
	return files;
}

/** 提交内容分类（B4·批B，ev-20261012-af58eb §8 批B）：检测与策略分离——本函数只做单源检测，
 *  rule 值由消费点（inspectCommitPayload 阻断面 / commitGuardDisclosureNote 披露面）读取。
 *  blocking 为 L-不可逆底线（敏感文件/模板复检/.git/ 禁入），不受任何 rule 值影响。 */
interface CommitContentClassification {
	/** 恒拒面：敏感文件（含模板真密钥复检）与 .git/ 禁入路径。 */
	blocking: string[];
	/** D5 检测面：>10MB 文件（路径+字节数；disclose 时披露列大小）。 */
	largeFiles: Array<{ file: string; bytes: number }>;
	/** D6 检测面：node_modules/ 路径（.git/ 恒在 blocking，不在此面）。 */
	generatedPaths: string[];
}

export function classifyCommitContent(files: Iterable<string>, workTree?: string | null): CommitContentClassification {
	const out: CommitContentClassification = { blocking: [], largeFiles: [], generatedPaths: [] };
	for (const file of files) {
		const norm = file.replaceAll("\\", "/");
		const rule = isSensitiveFile(norm, COMMIT_GUARD.block_sensitive_files);
		if (rule) { out.blocking.push(`${file}（${rule}）`); continue; }
		// ev-20260819-ea1b59：模板文件内容复检——占位模板命中真实密钥形态（sk-/AKIA/长密钥赋值）
		// 仍拦（防把真凭证改名为 .env.example 绕过）。
		if (workTree && isEnvTemplateFile(norm)) {
			try {
				const content = fs.readFileSync(path.join(workTree, norm), "utf8");
				if (fileLooksSecretful(content)) { out.blocking.push(`${file}（模板文件含真实密钥形态——占位模板不应有真实凭证，请改占位值）`); continue; }
			} catch { /* 读不到按模板后缀信号放行 */ }
		}
		// .git/ 属不可逆底线（恒拒、不随 generatedPaths 规则调整）；node_modules 归 D6 检测面。
		if (norm.startsWith(".git/") || norm.includes("/.git/")) {
			out.blocking.push(`${file}（禁入路径 .git/——仓库元数据，不可逆底线，不随 commit.generatedPaths 调整）`);
			continue;
		}
		// B4B 修复轮 R05：D5/D6 检测独立累积——node_modules 命中后不短路 stat：D6 放行路径
		// 不等于豁免 D5 大小检测（node_modules 内 11MB 文件须同时入两检测面，D5 受信收紧仍可阻断）。
		if (norm.startsWith("node_modules/") || norm.includes("/node_modules/")) {
			out.generatedPaths.push(file);
		}
		if (workTree) {
			try {
				const bytes = fs.statSync(path.join(workTree, file)).size;
				if (bytes > COMMIT_GUARD.max_file_mb * 1024 * 1024) out.largeFiles.push({ file, bytes });
			} catch { /* lint-exempt:stat 失败按无大小信号跳过（既有口径，检测面不因 IO 失败拒单） */ }
		}
	}
	return out;
}

/** classify + rule 投影 → 提交守卫 hits（阻断面；D5/D6=disclose 时对应检测不计入——披露面
 *  由 commitGuardDisclosureNote 承担，两面同源 classify，不产生第二份检测逻辑）。 */
function sensitiveHits(files: Iterable<string>, workTree: string | null | undefined, cwd: string, trust: boolean | undefined): string[] {
	const cls = classifyCommitContent(files, workTree);
	const hits = [...cls.blocking];
	if (guardRuleOf("commit.largeFile", cwd, trust) === "block") {
		for (const f of cls.largeFiles) hits.push(`${f.file}（>${COMMIT_GUARD.max_file_mb}MB｜guard-rule: commit.largeFile）`);
	}
	if (guardRuleOf("commit.generatedPaths", cwd, trust) === "block") {
		for (const f of cls.generatedPaths) hits.push(`${f}（禁入路径 node_modules｜guard-rule: commit.generatedPaths）`);
	}
	return hits;
}

/** ls-tree -r -l HEAD 输出 → 路径→blob 字节大小映射（B4B 修复轮 R06：披露大小取实际提交
 *  对象，不依赖执行后工作树 stat——提交后删除/缩小工作树文件不改变历史 blob 事实）。 */
function lsTreeBlobSizes(raw: string): Map<string, number> {
	const out = new Map<string, number>();
	for (const line of raw.split("\n")) {
		// 格式：<mode> <type> <object> <size>	<path>（blob 有 size；tree/link 为 "-" 跳过）
		const m = /^(\d+) (\w+) ([0-9a-f]+) (\d+)\t(.+)$/.exec(line.trim());
		if (m && m[2] === "blob") out.set(m[5]!, Number(m[4]!));
	}
	return out;
}

/** B4·批B（D5/D6 disclose）：commit 命令成功后的披露——基于本次真实提交集（diff-tree HEAD）
 *  与提交对象 blob 大小（ls-tree -l；B4B 修复轮 R06：执行后只读探查不触碰工作树）。对象范围
 *  口径：多 commit 链按最终 HEAD（链中最后一个提交对象）；前序提交通常同批文件不重复披露。
 *  列路径与字节数；事实/推测分句（批A 对照式规范）。凭据检查照常已由阻断面执行（敏感文件/
 *  模板复检不因大小放行）；不自动回退 index——撤销由调用方人工裁定。
 *  非 commit 命令/无 workTree/无检测命中/rule=block → null（零噪音）。 */
export function commitGuardDisclosureNote(command: string, cwd: string, trust?: boolean): string | null {
	let hasCommit = false;
	for (const invocation of parseGitInvocations(command, cwd)) {
		const resolved = resolveGitCommand(invocation);
		if (resolved.subcommand !== "commit") continue;
		hasCommit = true;
		const workTree = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
		if (!workTree) continue;
		// 真实提交集（--root 覆盖首提交；--no-commit-id 免消息污染；-r 递归列出文件）
		const committed = gitOutput(invocation, ["diff-tree", "--no-commit-id", "--name-only", "-r", "--root", "HEAD"]);
		if (committed === null || committed.trim() === "") continue;
		const files = committed.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
		// R06：大小面来自提交对象（blob size），与工作树现状解耦；检测面（generated/敏感）单源 classify。
		const blobSizes = lsTreeBlobSizes(gitOutput(invocation, ["ls-tree", "-r", "-l", "HEAD"]) ?? "");
		const cls = classifyCommitContent(files, null);
		for (const file of files) {
			const bytes = blobSizes.get(file);
			if (bytes !== undefined && bytes > COMMIT_GUARD.max_file_mb * 1024 * 1024
				&& !cls.largeFiles.some((f) => f.file === file)) cls.largeFiles.push({ file, bytes });
		}
		const sections: string[] = [];
		if (guardRuleOf("commit.largeFile", cwd, trust) === "disclose" && cls.largeFiles.length > 0) {
			const listed = cls.largeFiles.slice(0, 10).map((f) => `  ${f.file}（${f.bytes} 字节，约 ${(f.bytes / (1024 * 1024)).toFixed(1)}MB）`).join("\n") + (cls.largeFiles.length > 10 ? `\n  …另有 ${cls.largeFiles.length - 10} 个` : "");
			sections.push(`[amagi guard:commit.largeFile｜已放行] 本次提交包含 ${cls.largeFiles.length} 个 >${COMMIT_GUARD.max_file_mb}MB 文件：\n${listed}\n事实：提交已执行、体积已入仓库历史；推测：这可能是有意的资产/数据提交，也可能高估了必要性——仓库会随之增大、clone/fetch 变慢。护栏：敏感内容与凭据检查照常执行（不因大小放行），未回退 index/未撤销提交——如需撤销由你按仓库策略人工裁定（git revert 不改历史，rewrite 需谨慎）。配置：rule 可收紧回 block（来源见 /amagi config explain）。`);
		}
		if (guardRuleOf("commit.generatedPaths", cwd, trust) === "disclose" && cls.generatedPaths.length > 0) {
			const listed = cls.generatedPaths.slice(0, 10).join("、") + (cls.generatedPaths.length > 10 ? ` …另有 ${cls.generatedPaths.length - 10} 个` : "");
			sections.push(`[amagi guard:commit.generatedPaths｜已放行] 本次提交包含 ${cls.generatedPaths.length} 个 node_modules/ 路径：${listed}\n事实：提交已执行；推测：这可能是有意的 vendoring，也可能误把依赖目录入库——噪声与体积随之增大（.gitignore 常规应排除该目录）。护栏：.git/ 与敏感内容不受本开关控制（恒拒面照常）。配置：rule 可收紧回 block（来源见 /amagi config explain）。`);
		}
		if (sections.length > 0) return sections.join("\n\n");
	}
	return hasCommit ? null : null;
}

const COMMIT_GUARD_ADVICE = "变通：① 改用显式文件清单（git add 文件1 文件2 …）后单独 git commit；② 若用了 --pathspec-from-file，先确认文件存在且可读；③ 检查 pathspec 是否有语法错误或仓库是否可定位（git rev-parse --show-toplevel）。";

/** ev-20260910-919667：cwd/仓库定位不确定的专门文案——点明是 cd/-C 目标的问题（而非 pathspec），
 *  并给出「何种写法可确定放行」，不再让用户去猜规则；末尾保留既有三条变通建议。 */
function commitGuardCwdReason(action: "add" | "commit", invocation: GitInvocation): string {
	const target = invocation.uncertainTarget ? `「${invocation.uncertainTarget}」` : "";
	return `[AMAGI 提交守卫] 无法确定 git ${action} 将在哪个仓库/目录执行：命令内 cd/-C/--git-dir/--work-tree 目标${target}不是可定位的真实目录（变量未展开或目录不存在），判定不会基于猜测，故保守阻止命令链。可确定放行的写法：cd/-C 直接用字面路径（cd /abs/path && git add …），或在同一条命令内给变量赋字面值（W=/abs/path; cd $W && git add …）。${COMMIT_GUARD_ADVICE}`;
}

function inspectCommitPayload(command: string, cwd: string, trust: boolean | undefined): string | null {
	const plannedAdds = new Map<string, Set<string>>();
	for (const invocation of parseGitInvocations(command, cwd)) {
		const resolved = resolveGitCommand(invocation);
		const workTree = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
		const repoKey = workTree || `${invocation.cwd}\0${invocation.globalOptions.join("\0")}`;
		if (resolved.subcommand === "add") {
			if (invocation.cwdUncertain) return commitGuardCwdReason("add", invocation);
			const plan = gitPathspecPlan(invocation, "add", resolved.args);
			const files = gitFileSet(invocation, plan);
			if (plan.uncertain || files === null) return `[AMAGI 提交守卫] 无法确定 git add 将写入 index 的文件，已保守阻止命令链。${COMMIT_GUARD_ADVICE}`;
			const pending = plannedAdds.get(repoKey) || new Set<string>();
			for (const file of files) pending.add(file);
			plannedAdds.set(repoKey, pending);
			continue;
		}
		if (resolved.subcommand !== "commit") {
			if (resolved.uncertain && /commit/i.test(command)) return "[AMAGI 提交守卫] 无法安全展开 Git alias，已保守阻止疑似 commit。";
			continue;
		}
		if (invocation.cwdUncertain) return commitGuardCwdReason("commit", invocation);
		const cached = gitOutput(invocation, ["diff", "--cached", "--name-only", "--diff-filter=ACMR"]);
		if (cached === null) return "[AMAGI 提交守卫] 无法确定目标 Git 仓库，已保守阻止 commit。";
		const files = new Set(cached.split(/\r?\n/).map((line) => line.trim()).filter(Boolean));
		for (const file of plannedAdds.get(repoKey) || []) files.add(file);
		const plan = gitPathspecPlan(invocation, "commit", resolved.args);
		if (plan.uncertain) return "[AMAGI 提交守卫] 无法读取 commit pathspec，已保守阻止。";
		if (hasAllFlag(resolved.args)) plan.all = true;
		const selected = gitFileSet(invocation, plan);
		if (selected === null) return "[AMAGI 提交守卫] 无法计算 commit pathspec 的实际文件集，已保守阻止。";
		for (const file of selected) files.add(file);
		const hits = sensitiveHits(files, workTree, cwd, trust);
		if (hits.length) return `[AMAGI 提交守卫] 提交包含不该提交的内容：\n- ${hits.join("\n- ")}`;
	}
	return null;
}

// B4C 修复轮四（终轮复审 ③，Leader 裁定）：收回 D3「未闭合单元 + 零执行 + 披露放行」子翻转——
// 存在解析错误的命令整体恢复 B4C 前旧严格路径（保守阻止，不跳过提交目标/敏感检查）。理由：
// 未闭合形态真实 bash 报语法错误零成功执行，放行收益≈0；而该子翻转连续四轮被构造出
// Critical 凭据底线绕过（heredoc 前缀/变量拼接/ANSI-C $'..'/数据通道 12 形态静态不可收敛），
// 补偿控制面（迹象词/展开 OR/引导词剥除）不可闭合。修复轮一至三轮的迹象词/展开判定
// （COMMIT_INTENT_*/NONLITERAL_EXPANSION_RE，已删）与前缀递归只服务该子翻转，收回后无
// 调用点（死代码删除，B4C 报告修复轮四节写明）；引导词剥除/pathspec 保守/heredoc payload
// 递归对无解析错误路径仍是承重件，全部保留。

export function assertCommitSafe(command: string, cwd: string, depth = 0, trust?: boolean): string | null {
	// B4·批C（D3 配套，设计 §3#4）+ B4C-R02：深度超限不再无条件全局阻断——无 git 提交特征的深层
	// 嵌套归 assertSafeCommand 的 D3 opaque 分流；文本含 git 字样时深层提交目标无法确定，维持保守
	// 阻止（L-不可逆不因深度放行）。
	if (depth > 4) {
		if (/\bgit\b/i.test(command)) return "[AMAGI 提交守卫] shell 包裹深度超过上限，已保守阻止。";
		return null;
	}
	// ev-20260922-2d5a76：与 assertSafeCommand 同源语义视图（analyzeExecutableShell）——此前本入口
	// 没有 heredoc 剥除前置，quoted heredoc body 的奇数反引号被误报 UNCLOSED_BACKTICK 而另一入口
	// 放行（repro4 实证）。quoted delimiter body 只作数据；unquoted body 的 $()/反引号展开、wrapper
	// 与替换 payload 递归提交检查（嵌套命令替换可能执行 git，不能因顶层非 git 跳过）。
	// B4C 修复轮四：存在任何解析错误（未闭合反引号/未闭合 $()/不可安全展开）→ 旧严格路径
	// 保守阻止（收回依据见函数尾注释；不再区分「零执行同单元」与前缀）。
	const view = analyzeExecutableShell(command);
	// B4C 修复轮四：存在任何解析错误（未闭合反引号/未闭合 $()/不可安全展开）→ 旧严格路径
	// 保守阻止（不再区分「零执行同单元」与前缀——收回依据见函数尾注释）。
	if (view.parseErrors.length) {
		return "[AMAGI 提交守卫] 无法安全展开反引号命令替换，已保守阻止。变通：① 用 write 工具把脚本内容落盘为临时文件（如 /tmp/fix.py）后以 `python3 /tmp/fix.py` 执行；② 或把含反引号的命令拆分为不含命令替换的简单命令序列。";
	}
	for (const payload of [...view.wrapperPayloads, ...view.substitutionPayloads, ...view.unquotedBodyPayloads, ...view.unsafeBacktickPayloads]) {
		const nested = assertCommitSafe(payload, cwd, depth + 1, trust);
		if (nested) return nested;
	}
	return inspectCommitPayload(view.stripped, cwd, trust);
}

// ── ev-20260917-77adc5（friction/P1）：git add/commit 排除 pathspec 零匹配防呆（只警示不阻断） ──
// 实战：`git add -A ':!<path>'` 排除 pattern 目录层级笔误时零匹配且全程无提示，主上本地
// 未提交文件被误并入提交。策略：命令携带排除 pathspec 时对照执行前变更文件集（status
// porcelain，含未跟踪）——零匹配且存在相同 basename 的变更文件，或同名主体仅一两个字母
// 之差的近 basename 变更文件（目录层级/文件名/扩展名笔误）→ 疑似笔误软提示并展示最近似
// 路径（top2，整路径编辑距离排序）。只警示不阻断（false positive 成本低，漏报成本高）；
// glob/变量/不可解析 pattern、无变更、cwd 不确定的命令静默跳过（零噪音优先）。

const GIT_EXCLUDE_PREFILTER = /:(?:!|\([^)]*exclude)/;

/** 排除 pathspec（:!path / :(exclude)path / :(icase,exclude)path）→ 剩离 magic 前缀后的
 *  路径体；非排除形态返回 null。纯函数零 git 依赖。 */
function excludePathspecBody(arg: string): string | null {
	if (!arg.startsWith(":")) return null;
	const rest = arg.slice(1);
	if (rest.startsWith("(")) {
		const close = rest.indexOf(")");
		if (close < 0) return null;
		const magic = rest.slice(1, close).split(",").map((s) => s.trim());
		if (!magic.includes("exclude")) return null;
		return rest.slice(close + 1);
	}
	if (rest.startsWith("!")) return rest.slice(1);
	return null;
}

/** status --porcelain（非 -z）行集 → 变更路径集（重命名取新路径；C 引用路径解引）。
 *  gitOutput 对整体输出 trim，首行前导状态空格可能被剥——不可依赖固定 3 字符偏移，
 *  改为逐行剥前导空白后取首个空格后的路径体（正常行 XY + 空格 + path 同样成立）。 */
function porcelainPaths(raw: string): string[] {
	const out: string[] = [];
	for (const line of raw.split("\n")) {
		const stripped = line.replace(/^\s+/, "").replace(/\r$/, "");
		if (!stripped) continue;
		const split = stripped.indexOf(" ");
		let body = split >= 0 ? stripped.slice(split + 1) : stripped;
		if (body.includes(" -> ")) body = body.slice(body.lastIndexOf(" -> ") + 4);
		if (body.startsWith('"') && body.endsWith('"')) {
			try { out.push(JSON.parse(body) as string); continue; } catch { /* 非法转义回退原文 */ }
		}
		if (body) out.push(body);
	}
	return out;
}

/** 整路径编辑距离（建议排序用；同名 basename 并列时路径段差异小者在前）。 */
function pathEditDistance(a: string, b: string): number {
	const m = a.length;
	const n = b.length;
	if (!m) return n;
	if (!n) return m;
	let prev: number[] = Array.from({ length: n + 1 }, (_, i) => i);
	for (let i = 1; i <= m; i++) {
		const curr: number[] = new Array<number>(n + 1);
		curr[0] = i;
		for (let j = 1; j <= n; j++) {
			const substitution = prev[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1);
			curr[j] = Math.min(prev[j]! + 1, curr[j - 1]! + 1, substitution);
		}
		prev = curr;
	}
	return prev[n]!;
}

/** ev-20260917-77adc5：排除 pathspec 零匹配防呆（纯函数，供守卫接线与测试直接断言）。
 *  命中 → 一行 `[amagi 软提示·git 排除模式] …`（含条目原文与最近似变更路径）；未命中/不可判 → null。 */
export function gitExcludePatternTypoHint(command: string, cwd: string): string | null {
	if (!command || !GIT_EXCLUDE_PREFILTER.test(command)) return null;
	for (const text of [command, ...shellWrapperPayloads(command)]) {
		for (const invocation of parseGitInvocations(text, cwd)) {
			if (invocation.cwdUncertain) continue;
			const resolved = resolveGitCommand(invocation);
			if (resolved.subcommand !== "add" && resolved.subcommand !== "commit") continue;
			const excludeArgs: string[] = [];
			for (const arg of resolved.args) if (excludePathspecBody(arg) !== null) excludeArgs.push(arg);
			if (!excludeArgs.length) continue;
			const status = gitOutput(invocation, ["status", "--porcelain", "--untracked-files=all"]);
			if (!status || !status.trim()) continue; // 无变更：排除零匹配属预期，零提示
			const changed = porcelainPaths(status);
			if (!changed.length) continue;
			const hits: string[] = [];
			for (const arg of excludeArgs) {
				const pattern = (excludePathspecBody(arg) ?? "").trim();
				// glob/变量/命令替换形态无法可靠判定匹配面，静默跳过（零噪音优先）
				if (!pattern || /[*?\[\]]/.test(pattern) || /\$\{?[A-Za-z_]|`/.test(pattern)) continue;
				const norm = pattern.replace(/^\.\//, "").replace(/\/+$/, "");
				const matched = changed.some((f) => f === norm || f.startsWith(`${norm}/`));
				if (matched) continue; // 排除实际生效：不是笔误
				const base = norm.split("/").pop() ?? "";
				if (!base) continue;
				const sameBase0 = [...new Set(changed.filter((f) => (f.split("/").pop() ?? "") === base))];
				// 无同名时回退近 basename（同名主体仅 1-2 字母之差：文件名/扩展名笔误，len≥6 容差 2、短名容差 1）
				const sameBase = sameBase0.length ? sameBase0 : [...new Set(changed.filter((f) => {
				const fb = f.split("/").pop() ?? "";
				return fb !== base && pathEditDistance(base, fb) <= (Math.max(base.length, 3) >= 6 ? 2 : 1);
				}))];
				if (!sameBase.length) continue; // 无同名文件：零匹配可能是排除干净目录，零提示
					sameBase.sort((a, b) => pathEditDistance(norm, a) - pathEditDistance(norm, b) || a.localeCompare(b));
				hits.push(`${arg} 零匹配，最近似变更路径：${sameBase.slice(0, 2).join("、")}`);
			}
			if (hits.length) {
				return `[amagi 软提示·git 排除模式] git ${resolved.subcommand} 的排除 pathspec 疑似笔误（路径/目录层级与实际变更不符）：${hits.join("；")}。该排除实际未生效，对应文件会被并入暂存/提交；请核对路径后重试。本提示不阻断。`;
			}
		}
	}
	return null;
}

function isSensitiveFile(file: string, patterns: string[]): string | undefined {
	const basename = path.basename(file).toLowerCase();
	for (const pattern of patterns) {
		if (pattern === ".env" && (basename === ".env" || basename.startsWith(".env."))) {
			// ev-20260819-ea1b59：.env.example/.sample/.template/.defaults 是无密钥占位模板——
			// 放行名称层；内容层复检在 sensitiveHits（模板含真实密钥形态仍拦）。
			if (ENV_TEMPLATE_SUFFIX_RE.test(basename)) continue;
			return pattern;
		}
		const re = new RegExp(`^${pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replaceAll("*", ".*")}$`, "i");
		if (re.test(basename)) return pattern;
	}
	return undefined;
}

export function checkJsonFile(filePath: string, cwd?: string): string | null {
	if (!filePath || !filePath.toLowerCase().endsWith(".json")) return null;
	const resolved = path.isAbsolute(filePath) ? filePath : path.resolve(cwd || process.cwd(), filePath);
	if (!fs.existsSync(resolved)) return null;
	try {
		const stat = fs.statSync(resolved);
		if (stat.size > JSON_MAX_BYTES) return `[AMAGI JSON 守卫] ${resolved} 为 ${stat.size} 字节，超过 ${JSON_MAX_BYTES} 字节预算；未执行语法验证（非阻断警告）。`;
		JSON.parse(fs.readFileSync(resolved, "utf8"));
		return null;
	} catch (error) { return `[AMAGI JSON 守卫] ${resolved} 不是合法 JSON：${(error as Error).message}`; }
}

// v1.5.179: bash 只读判别——实现已随 Git 调用解析共享层迁入 git-discard-guard.ts（re-export 见文件头部）。\n
export function checkHighRiskPath(targetPath: string): { category: string; matched?: string } | null {
	const normalized = targetPath.replaceAll("\\", "/");
	for (const [pattern, category] of HIGH_RISK_PATTERNS) {
		if (!pattern.test(normalized)) continue;
		// ev-20260819-ea1b59：环境变量模板文件（.env.example/.sample/.template/.defaults）是
		// 无密钥占位模板，不应触发哨兵误报（实战：merge commit 被误拦/读模板误报）。
		if (category === "环境变量" && isEnvTemplateFile(normalized)) continue;
		// ev-20260905-4c9d82①：返回命中片段（如 auth.json）作哨兵去重 key 素材——
		// 原 key 用整条命令文本，python heredoc 每次不同 → 同一敏感文件告警反复触发（实战 3 连）。
		const matched = pattern.exec(normalized)?.[0];
		return { category, matched: matched ?? normalized.slice(0, 64) };
	}
	return null;
}

/** Missing read paths get bounded names from their own authorized directory, never file contents. */
// ── ev-20261012-93e1db：候选分层排序 ──
// 旧实现把「stem 前 4 字符前缀匹配」与「仅同扩展名」用 || 合成同一无相关度集合，再按字母序
// slice(0,6)——同扩展名泛候选（a*.ts 等）按字母序挤掉更相关入口（条目夹具：22 项命名下
// task-facets.ts/task-background.ts 被六个 a*.ts 挤掉）。分层收集与排序解耦：tier0=稳定前缀、
// tier1=名称相似（有界 bigram Dice）、tier2=仅同扩展名（后备）；层内按相似度降序 → 名称升序
// （确定性）；总数仍 ≤6；deny/敏感路径/符号链接实目标过滤与「仅建议不自动改路径」不变。
interface RankedPathCandidate {
	name: string;
	tier: number;
	score: number;
}

/** 归一化名称的字符 bigram Dice 相似度（0~1；纯函数 O(len)、无新依赖；顺序无关的近名变体
 *  如 usage-guide ↔ guide-usage 可命中，前缀不同的真近名不被字母序埋没）。 */
function bigramDice(a: string, b: string): number {
	if (a === b) return 1;
	if (a.length < 2 || b.length < 2) return 0;
	const grams = new Map<string, number>();
	for (let i = 0; i + 1 < a.length; i++) {
		const gram = a.slice(i, i + 2);
		grams.set(gram, (grams.get(gram) ?? 0) + 1);
	}
	let hits = 0;
	for (let i = 0; i + 1 < b.length; i++) {
		const gram = b.slice(i, i + 2);
		const count = grams.get(gram) ?? 0;
		if (count > 0) { hits++; grams.set(gram, count - 1); }
	}
	return (2 * hits) / (a.length - 1 + b.length - 1);
}

const PATH_CANDIDATE_SIMILARITY_THRESHOLD = 0.5;

export function missingReadPathDiagnostic(toolName: string, input: Record<string, unknown> | undefined, errorText: string, cwd: string): string | undefined {
	if (!/ENOENT|Path not found|No such file or directory/i.test(errorText)) return undefined;
	let target = ["read", "grep", "find", "ls"].includes(toolName) ? String(input?.path || input?.file_path || "") : "";
	if (toolName === "bash") {
		const command = String(input?.command || "");
		if (/[|;&<>$`\n]/.test(command) || !isReadOnlyCommand(command)) return undefined;
		const words = shellTokens(command);
		if (words.length < 2 || !["cat", "ls", "find", "rg", "grep"].includes(words[0])) return undefined;
		const operand = words[0] === "find" ? words[1] : words.at(-1)!;
		if (operand.startsWith("-") || /[*?{}]/.test(operand)) return undefined;
		target = operand;
	}
	if (!target || target !== target.trim() || cwd !== cwd.trim() || /\0|\n|\r/.test(target)) return undefined;
	const absolute = path.resolve(cwd, target), parent = path.dirname(absolute);
	const sensitive = (p: string) => !!checkHighRiskPath(p) || /(?:^|[\/])(?:\.ssh|\.aws|\.gnupg|credentials|secrets)(?:[\/]|$)/i.test(p);
	if (sensitive(absolute) || sensitive(parent) || fileReadPermissionBlockReason(cwd, absolute) || fileReadPermissionBlockReason(cwd, parent)) return undefined;
	const parentExists = fs.existsSync(parent), targetExists = fs.existsSync(absolute);
	const ranked: RankedPathCandidate[] = []; let scanned = 0;
	if (parentExists && !targetExists) {
		let dir: fs.Dir | undefined;
		try {
			// Resolve aliases before disclosure too (deny and sensitive checks cover their real target).
			const realParent = fs.realpathSync(parent);
			if (sensitive(realParent) || fileReadPermissionBlockReason(cwd, realParent)) return undefined;
			dir = fs.opendirSync(parent);
			const stem = path.basename(target).toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
			let ent: fs.Dirent | null;
			while (scanned < 128 && (ent = dir.readSync()) !== null) {
				scanned++;
				if (ent.name !== ent.name.trim() || /[\x00-\x1f\x7f]/.test(ent.name)) continue;
				const candidate = path.join(parent, ent.name);
				if (sensitive(candidate) || fileReadPermissionBlockReason(cwd, candidate)) continue;
				let realCandidate: string;
				try { realCandidate = fs.realpathSync(candidate); } catch { /* journal:missing-read-candidate-unavailable */ continue; }
				if (sensitive(realCandidate) || fileReadPermissionBlockReason(cwd, realCandidate)) continue;
				const normalized = ent.name.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]/g, "");
				// A stable prefix or same extension is a candidate only, never an automatic correction.
				const similarity = bigramDice(stem, normalized);
				const tier = stem.length >= 4 && normalized.startsWith(stem.slice(0, 4)) ? 0 : similarity >= PATH_CANDIDATE_SIMILARITY_THRESHOLD ? 1 : 2;
				if (tier < 2 || (path.extname(target) && path.extname(ent.name) === path.extname(target))) ranked.push({ name: ent.name, tier, score: similarity });
			}
		} catch { /* lint-exempt:diagnostic is best effort; preserve original failure */ }
		finally { try { dir?.closeSync(); } catch { /* lint-exempt:诊断目录关闭尽力而为，不影响原工具错误 */ } }
	}
	// ev-20261012-93e1db：分层排序选前 6（tier升序 → 相似度降序 → 名称升序；同输入同输出）。
	const names = ranked
		.sort((a, b) => a.tier - b.tier || b.score - a.score || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
		.slice(0, 6)
		.map((candidate) => candidate.name);
	// 枚举达 128 上限且无近似候选：明确建议先查真实目录，不要继续猜名（条目期望②）。
	const capNote = scanned >= 128
		? names.length
			? "（目录枚举已达到128项上限）"
			: "（目录枚举已达到128项上限且未找到近似候选：先用 find/grep 列出该目录真实文件名再重试，不要继续猜名）"
		: "";
	return `[路径诊断] cwd=${cwd}；原目标=${target}；父目录${parentExists ? "存在" : "不存在"}；目标${targetExists ? "存在（核对工具报错目标）" : "不存在"}${names.length ? `；同目录候选（仅名称，须核对后重试）：${names.map(n => JSON.stringify(n)).join("、")}` : "；未找到可披露的同目录候选"}${capNote}。`;
}

// ── ev-20260819-ea1b59：环境变量模板白名单 + 内容级密钥复检 ──
const ENV_TEMPLATE_SUFFIX_RE = /\.(example|sample|template|defaults)$/i;
const SECRET_CONTENT_RE = /\b(?:sk-[A-Za-z0-9_-]{16,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:api[_-]?key|apikey|secret|token|password|passwd)\s*[:=]\s*["']?[A-Za-z0-9_\-+/=]{20,})/i;

/** 环境变量/配置模板文件（无密钥占位约定后缀）。 */
export function isEnvTemplateFile(file: string): boolean {
	try { return ENV_TEMPLATE_SUFFIX_RE.test(path.basename(file)); } catch { return false; }
}

/** 模板内容复检：命中真实密钥形态（占位模板不该有）→ 仍按敏感处理。 */
export function fileLooksSecretful(content: string): boolean {
	return SECRET_CONTENT_RE.test(String(content).slice(0, 64 * 1024));
}

// v1.5.190：敏感内容类别的可行动告警文案——「建议谨慎」不可行动，
// 给出具体替代动作（实战：凭证文件被 cat 全文是真实泄密路径）。
const SENTINEL_SECRET_CATEGORIES = new Set([
	"环境变量", "SSH 密钥", "凭据", "密钥", "认证", "认证凭据", "证书", "密钥文件", "SSH 私钥", "pi 配置",
]);

export function sentinelAdvice(category: string): string {
	return SENTINEL_SECRET_CATEGORIES.has(category)
		? "；含敏感信息——建议仅列键名/结构（如 python 打印 keys），避免全文打印明文"
		: "";
}

// v1.5.216: 语义性非零退出白名单——diff(1)/cmp(2)/grep 系(1)/rg(1) 的非零退出是
// 「有差异/无匹配」的正常语义而非执行错误，对其追加 Bash 诊断纯属噪音。go test/npm test
// 等真失败不在此列（非零=真错误，诊断提示有价值）。
// ev-20260908-23c9e9（P3/ux）：白名单在真实复合命令场景失效——事故命令
//   KB="..."; D3=...; cd "$KB" && git apply --verbose ... 2>&1; echo "exit=$?"; grep -c "d5bd560" f1 f2
// 整条 exit 1 全部来自末段 grep -c 零匹配（echo 印证前段 exit=0），却触发诊断全文追加。
// 根因（复现锁定）：解析层无缺口，缺口在 every 白名单判定策略——①纯赋值段剥离 VAR= 前缀后
// 为空段、空串不在白名单；②cd/echo 等无失败语义辅助段不在白名单；③未利用「shell 退出码=末段
// 归因」与「stderr 真实错误签名」区分零匹配与文件不存在。修复：白名单纳入 which/compgen
//（原沉淀命令族：探测不存在是正常语义），新增中性段与三维判定 shouldSuppressBashDiagnostic。
// ev-20261101-c1c267（P3/ux）：纳入 pgrep——无进程匹配 exit 1 是正常探测语义（实战：pipefail 下
// `pgrep -fl UnrealEditor | wc -l` 输出 0 一切正常，却得通用诊断「原样重试通常还会失败」）；
// pgrep 2=用法错误仍由退出码/签名防线提示，不静默。
const SEMANTIC_EXIT_TOOLS = new Set(["diff", "cmp", "grep", "egrep", "fgrep", "zgrep", "rg", "which", "compgen", "pgrep", "test", "["]);

/** ev-20260908-23c9e9：中性段——赋值/cd/echo/pwd/true/: 无自身失败语义（失败必留 stderr 签名，
 *  由 REAL_ERROR_SIGNATURES 兜底），不参与「语义退出」判定也不破坏降级。 */
const NEUTRAL_SEGMENT_EXES = new Set(["cd", "echo", "pwd", "true", ":"]);

/** 段的主执行程序（剥包裹器与赋值前缀后取 basename，小写）。 */
function segmentExecutable(segment: string[]): string {
	return path.basename(executableWords(segment, true)[0] || "").toLowerCase();
}

/** 中性段判定：纯赋值段（executableWords 剥离后为空）为中性；含命令替换的段非中性
 *  （解析不确定宁可提示，见期望④保守原则）。 */
function isNeutralSegment(segment: string[]): boolean {
	const words = executableWords(segment, true);
	if (!words.length) return true;
	if (commandSubstitutions(segment.join(" ")).length) return false;
	return NEUTRAL_SEGMENT_EXES.has(path.basename(words[0]).toLowerCase());
}

/** 语义性退出码判定：多段命令（&&/||/;/|/换行分段）须全部段命中白名单或为中性段，
 *  且至少一段命中白名单（全中性如裸 echo 无语义退出概念）；空命令一律不降级
 *  （保守：宁可多提示，不漏提示真错误）。 */
// ev-20260916-8c55a2：进程替换边界识别接线——顶层段判定先剥 <(…)/>(…)（内部 svn 等子命令不当
// 并列顶层命令，消除 `diff <(a && b) f` 的误报）；不执行替换内容，子命令真实错误仍由 stderr 签名兜底。
// 回滚：AMAGI_SEMANTIC_EXIT_PROCESS_SUBSTITUTION=0/false/off 回旧识别。
function semanticExitCommandText(command: string): string {
	const v = process.env.AMAGI_SEMANTIC_EXIT_PROCESS_SUBSTITUTION?.trim().toLowerCase();
	if (v === "0" || v === "false" || v === "off") return command;
	return stripProcessSubstitutions(command).stripped;
}

export function isSemanticExitCommand(command: string): boolean {
	const segments = shellSegments(semanticExitCommandText(command));
	if (!segments.length) return false;
	const semantic = segments.some((segment) => SEMANTIC_EXIT_TOOLS.has(segmentExecutable(segment)));
	if (!semantic) return false;
	return segments.every((segment) => SEMANTIC_EXIT_TOOLS.has(segmentExecutable(segment)) || isNeutralSegment(segment));
}

/** ev-20260908-23c9e9：高置信真实错误签名（从宽——误命中只造成提示不漏提示，方向保守）。
 *  覆盖：文件/权限类（No such file、Permission denied、errno 族）、命令缺失类（command not found、
 *  not found）、程序错误类（error:、Traceback、SyntaxError、模块缺失）、参数错误类（Usage:、
 *  invalid、unrecognized、illegal option）、中断类（timeout/abort/信号）。 */
const REAL_ERROR_SIGNATURES = new RegExp(
	[
		"No such file or directory",
		"Permission denied",
		"command not found",
		"not found\\b",
		"no matches found", // zsh glob 失败
		"error:",
		"Traceback",
		"SyntaxError",
		"Cannot find module",
		"Module not found",
		"EACCES|EPERM|ENOENT|EEXIST",
		"command failed",
		"Command timed out",
		"Command aborted",
		"Segmentation fault",
		"Abort trap",
		"\\bKilled\\b",
		"Usage:",
		"\\binvalid\\b",
		"\\bunrecognized\\b",
		"illegal option",
		// ev-20261017-6d2825（diting F3）：透传段 exit-1 真失败签名（cat 目录 / tee 磁盘满 / 打不开文件）
		"Is a directory",
		"No space left",
		"ENOSPC",
		"cannot open",
	].join("|"),
	"i",
);

/** 从 bash 工具失败文本提取退出码（appendStatus 尾注「Command exited with code N」；取最后一次）。 */
function extractExitCode(errorText: string): number | undefined {
	const matches = [...errorText.matchAll(/Command exited with code (\d+)/g)];
	return matches.length ? Number(matches[matches.length - 1][1]) : undefined;
}

/** ev-20260908-23c9e9：bash 诊断降噪三维判定（接线层权威入口，取代裸 isSemanticExitCommand）。
 *  ①退出码：白名单族语义退出码唯一为 1（diff/grep/rg/cmp 的 0/1/2 中 2=真错误；which/compgen
 *    的 1=未命中）；无「exited with code」签名（timeout/abort/截断）保守提示。
 *  ②错误签名：REAL_ERROR_SIGNATURES 命中一律提示——「零匹配 exit 1 静默」与
 *    「文件不存在/权限拒绝提示」由此区分（负路径不回退）。
 *  ③段结构：全段白名单/中性（isSemanticExitCommand），或末段归因（shell 复合命令退出码
 *    由最后一段决定：`cmd; echo exit; grep -c` 验证型模式前段成功由签名兜底）。
 *  保守原则：解析不确定时宁可提示不漏提示。 */
export function shouldSuppressBashDiagnostic(command: string, errorText: string): boolean {
	return semanticExitAttribution(command, errorText) !== null;
}

/** ev-20261017-6d2825：pipefail 下管道退出码=最右非零段——无自身失败语义的透传/过滤段（失败必留
 *  stderr 签名，由 REAL_ERROR_SIGNATURES 兜底）。与管道退出码提示的弱尾族不同：此处只要「成功即 0」的段。 */
const PIPEFAIL_PASSTHROUGH_EXES = new Set(["head", "tail", "wc", "cat", "tac", "nl", "sort", "uniq", "cut", "tr", "tee", "column", "fold", "less", "more"]);

/** ev-20261017-6d2825：exit 1 归因到语义退出命令（返回其可执行名；不可归因 → null）。
 *  在 23c9e9 三维判定上补 shell 退出码语义：
 *  ① errexit（set -e / -o errexit）下任一前段失败即提前退出——末段归因不成立，只认全段白名单/中性；
 *  ② pipefail 下末管道退出码=最右非零段——`grep -v pat log | head` 的 1 来自 grep 无匹配（实战：末段
 *    head 使旧「末段归因」漏判，全仓 go test 实际 exit 0 却被标失败并追加通用诊断）。仅当末管道全部段
 *    都是语义退出命令或透传段时归因（左侧含重命令如 `go test | grep -v ok | head` 时 1 可能来自
 *    go test——不归因，照常提示）。 */
/** ev-20261017-6d2825（diting F4）：按序扫描 `set` 段求最终 errexit/pipefail 状态——`set -euo pipefail`
 *  组合短旗（o 消费下一词为选项名）、`+e`/`+o name` 关闭。只认段首可执行词为 set（echo "set -e" 不命中）。 */
function shellOptionState(segments: readonly string[][]): { errexit: boolean; pipefail: boolean } {
	const state = { errexit: false, pipefail: false };
	const setOpt = (name: string | undefined, on: boolean) => {
		if (name === "errexit") state.errexit = on;
		else if (name === "pipefail") state.pipefail = on;
	};
	for (const seg of segments) {
		if (seg[0] !== "set") continue;
		for (let i = 1; i < seg.length; i++) {
			const tok = seg[i]!;
			if (!/^[-+][a-zA-Z]+$/.test(tok)) continue;
			const on = tok[0] === "-";
			for (const ch of tok.slice(1)) {
				if (ch === "e") state.errexit = on;
				else if (ch === "o") setOpt(seg[++i], on);
			}
		}
	}
	return state;
}

/** ev-20261027-b9953e：grep 族匹配/上下文输出行形状——`-n` 单文件 `123:`（匹配）/`123-`（上下文）、
 *  多文件 `path:123:`、上下文分隔 `--`。无行号前缀的裸正文（rg 管道下默认不带 -n、多文件无 -n
 *  仅 `path:content`）不可证为匹配输出，保守不豁免。rg/grep 自身的 IO/参数错误走 stderr
 * （如 `rg: <path>: No such file or directory`），不呈该形状。 */
const GREP_MATCH_OUTPUT_LINE_RE = /^(?:--$|\d+[:-]|[^\s:][^:\n]*:\d+[:-])/;

/** ev-20261027-b9953e：语义段是否全为 grep 族（rg/grep/egrep/fgrep/zgrep——匹配正文带行号前缀）。
 *  仅在「全段白名单/中性」前提下有意义，不将未知生产者的行号形态输出解释为搜索记录。 */
function grepFamilyOnlySegments(segments: readonly string[][]): boolean {
	return segments.every((seg) => {
		const exe = segmentExecutable(seg);
		return !SEMANTIC_EXIT_TOOLS.has(exe) || ["grep", "egrep", "fgrep", "zgrep", "rg"].includes(exe);
	});
}

/** ev-20261027-b9953e：仅检测不可证为 grep 族匹配/上下文输出行的真实错误签名。
 *  同型机制复现（#831 原命令截断，非完整事故回放）：REAL_ERROR_SIGNATURES 扫整段合并输出，把 rg 匹配出的
 *  源码正文（行号记录里的 'error:'/'not found' 等）误当 rg 执行错误，拒绝把 exit 1 归因为
 *  无匹配，改落 cwd 泛化提示。修复口径：可证为匹配正文的行不作为执行错误证据；不可证
 * （无行号前缀裸正文 / 段内含未知生产者）→ 混合未知不猜，维持整段签名检测，真实错误不静默。 */
function realErrorSignatureBeyondMatchLines(errorText: string): boolean {
	const evidence = errorText.split(/\r?\n/).filter(line => !GREP_MATCH_OUTPUT_LINE_RE.test(line)).join("\n");
	// 执行错误和断言失败使用同一来源判定，不能先扫描合并正文再丢弃搜索来源。
	return REAL_ERROR_SIGNATURES.test(evidence) || isTestFailureText(evidence);
}

export function semanticExitAttribution(command: string, errorText: string): string | null {
	const exitCode = extractExitCode(errorText);
	if (exitCode !== 1) return null;
	const text = semanticExitCommandText(command);
	const segments = shellSegments(text);
	if (!segments.length) return null;
	const firstSemantic = (segs: string[][]): string | null => {
		for (let i = segs.length - 1; i >= 0; i--) {
			const exe = segmentExecutable(segs[i]!);
			if (SEMANTIC_EXIT_TOOLS.has(exe)) return exe;
		}
		return null;
	};
	let attributed: string | null = null;
	const viaFullWhitelist = isSemanticExitCommand(command);
	if (viaFullWhitelist) attributed = firstSemantic(segments);
	else {
		// diting F4：shell 选项按词法层 set 段解析（注释/引号 payload 已剥离；+e/+o 关闭语义生效）
		const opts = shellOptionState(segments);
		if (opts.errexit) return null; // ① errexit：前段失败可提前退出
		// diting F1：末链由 && 引入时前段失败会短路末链——退出码可能来自前段，不归因（|| 引入时 exit 1 末链必已执行）
		const ops = shellChainOperators(text);
		if (ops[ops.length - 1] === "&&") return null;
		const lastExe = segmentExecutable(segments[segments.length - 1]!);
		if (SEMANTIC_EXIT_TOOLS.has(lastExe)) attributed = lastExe;
		else if (opts.pipefail) {
			// ② pipefail：取末管道（按 &&/||/;/换行断链后的最后一条链；与 shellSegments 同一词法器）
			const chains = shellPipelineChains(text);
			const lastChain = chains[chains.length - 1];
			if (!lastChain || lastChain.length < 2) return null;
			const allAttributable = lastChain.every((seg) => {
				const exe = segmentExecutable(seg);
				return SEMANTIC_EXIT_TOOLS.has(exe) || PIPEFAIL_PASSTHROUGH_EXES.has(exe);
			});
			attributed = allAttributable ? firstSemantic(lastChain) : null;
		}
	}
	if (!attributed) return null;
	// ev-20261027-b9953e：错误签名检测移到归因判定之后——全段白名单/中性且语义段全为 grep 族时，
	// 按行形状豁免可证匹配正文（realErrorSignatureBeyondMatchLines）；其余形态（含非语义段
	// 生产者 / 语义段含 diff/which 等）整段检测不变。真实 IO/参数错误（`rg: …` stderr）与
	// exit ≥2 不受影响，不静默、不降为无匹配。
	if (viaFullWhitelist && grepFamilyOnlySegments(segments)
		&& commandSubstitutions(command).length === 0 && stripProcessSubstitutions(command).payloads.length === 0) {
		if (realErrorSignatureBeyondMatchLines(errorText)) return null;
	} else if (REAL_ERROR_SIGNATURES.test(errorText) || isTestFailureText(errorText)) return null;
	return attributed;
}

/** ev-20261017-6d2825：grep 族无匹配的一行正向注记——宿主仍按非零退出标 isError，静默时实战被读成
 *  「命令失败」计入失败统计（grep -c 输出 0 / -v 空输出无法自证）。仅 grep 族：diff/cmp 输出差异本身
 *  自证语义，which/compgen 未命中无歧义，维持静默（23c9e9 降噪口径不回退）。返回 null=不注记。
 *  ev-20261027-b9953e：单条 grep 族无匹配从 P3 静默改一行简短说明（feishu-sync #1051：静默
 *  缺解释被读作未分类失败）——不改退出码/isError 事实、不吞真实错误（真实错误仍走签名/退出码
 *  防线）；复合命令保持完整归因注记（左侧另有工作、归因不自明）。
 *  ev-20261101-c1c267：pgrep 纳入注记族——无匹配时输出为空/仅透传计数（`pgrep|wc -l` 印 0），
 *  与 grep -c 同型缺自证，静默会被读作失败；diff/cmp/which/compgen 维持静默（23c9e9 口径不回退）。 */
const NO_MATCH_NOTE_TOOLS = new Set(["grep", "egrep", "fgrep", "zgrep", "rg", "pgrep"]);
export function semanticExitNote(tool: string, compound: boolean): string | null {
	if (tool === "test" || tool === "[") return `\n\n${BASH_DIAGNOSTIC_PREFIX} 退出码 1 可表示 ${tool} 条件未满足；保持原始退出事实，不据此断言其他命令成功或失败。`;
	if (!NO_MATCH_NOTE_TOOLS.has(tool)) return null;
	if (!compound) {
		return `\n\n${BASH_DIAGNOSTIC_PREFIX} 退出码 1 = ${tool} 无匹配（非执行错误；真实错误为 ≥2 或带错误签名），无需重试。`;
	}
	return `\n\n${BASH_DIAGNOSTIC_PREFIX} 退出码 1 归因于 ${tool} 无匹配（POSIX：1=无匹配，非执行错误；真实错误为 ≥2 或带错误签名）——左侧命令成败以上方输出为准，无需重试；不希望无匹配计为非零时末尾加 \`|| true\`。`;
}

/** ev-20261101-c1c267：exit 1 归因不明（pipefail/errexit 混合链）的中性注记——返回 null=维持原通用诊断。
 *  实战（ev 证据同会话 2 处）：`set -o pipefail; … | grep "Result={Fail}" | head` 无匹配 → exit 1，
 *  末管道混重命令无法唯一归因，落通用诊断「原样重试通常还会失败」，把「无匹配」（0 失败的成功
 *  信号）误说成执行失败。中性解释优先于完整证明成功：只声明来源不唯一、请据真实输出判断。
 *  仅在 exit 1、无真实错误/测试失败证据且词法层确有语义命令时作中性解释；末管道、&& 短路或
 *  errexit 可使来源不唯一（包括宿主隐式 pipefail），不要求模型重写命令声明选项。
 *  普通分号后末命令失败仍走原诊断。不改变退出码/isError 事实、不阻断重试、不加门禁。 */
export function ambiguousSemanticExit1Note(command: string, errorText: string): string | null {
	const exitCode = extractExitCode(errorText);
	if (exitCode !== 1) return null;
	if (REAL_ERROR_SIGNATURES.test(errorText) || isTestFailureText(errorText)) return null;
	const text = semanticExitCommandText(command);
	const segments = shellSegments(text);
	if (!segments.length) return null;
	const hasSemanticSegment = segments.some((segment) => SEMANTIC_EXIT_TOOLS.has(segmentExecutable(segment)));
	if (!hasSemanticSegment) return null;
	if (semanticExitAttribution(command, errorText)) return null; // 可唯一归因走 semanticExitNote 完整注记
	const opts = shellOptionState(segments);
	const chains = shellPipelineChains(text);
	const ops = shellChainOperators(text);
	const hasSemantic = (chain: string[][]) => chain.some(seg => SEMANTIC_EXIT_TOOLS.has(segmentExecutable(seg)));
	let possibleSemanticSource = hasSemantic(chains.at(-1) ?? []);
	// 只沿可传播非零状态的末尾&&链回溯；分号/换行覆盖旧状态，||恢复后旧失败不再决定末状态。
	for (let i = chains.length - 1; i > 0 && ops[i] === "&&"; i--) {
		possibleSemanticSource ||= hasSemantic(chains[i - 1]!);
	}
	// 宿主可能隐式启用 pipefail；末管道含语义段时不要求模型在命令里重复声明。
	// 普通 `grep ...; npm test` 的末链不含语义段且没有提前退出路径，仍按真实末命令诊断。
	if (!opts.errexit && !possibleSemanticSource) return null;
	return `\n\n${BASH_DIAGNOSTIC_PREFIX} 退出码 1 来源不唯一：可能只是 grep/rg/pgrep 等语义段的无匹配或 test 条件未满足（非执行错误），也可能来自其他段的真实失败——请依据上方真实输出判断，不据此断言成功或失败；需要时可调整命令后再执行。本提示不阻断重试。`;
}

// ── ev-20261027-b9953e：agent-browser 失败分类（输出特征驱动，非 cwd 猜测）──
// 实战（feishu-sync 会话 9 次 isError 中 4 次）：wait 超时 / ref 失效 / role-name 定位未命中都有
// 明确输出特征，却被合并进 generic:agent-browser 计数并给「先分类为 cwd/路径」泛化提示——根因在
// UI 状态与元素名（与 cwd 无关），且「本会话第 N 次」跨类别串扰。分类为稳定规则键（各自计次不串类），
// 文案（diagnoseBashFailure）与 repeatNotes 键（diagnosticRuleKey）复用同一匹配结果（单一来源）。
export interface BrowserFailureRule {
	/** 规则键（与 diagnosticRuleKey 同口径：browser-* 稳定短标识，不含命令正文）。 */
	key: string;
	/** 输出特征（取自真实 agent-browser 输出实录，非想象）。 */
	signature: RegExp;
	/** 可行动建议：先 snapshot -i 核对真实 UI 状态，再按真实状态修正（不猜测 cwd）。 */
	advice: string;
}

const BROWSER_FAILURE_RULES: BrowserFailureRule[] = [
	{
		key: "browser-wait-timeout",
		signature: /Wait timed out/i,
		advice: "agent-browser wait 超时：目标文本/状态在超时窗口内未出现（页面可能仍在加载、文案不同或被遮挡）。先 `agent-browser --session <id> snapshot -i` 核对当前页面真实状态，再按真实状态调整等待条件或直接操作元素；原样重试同一 wait 通常继续超时。",
	},
	{
		key: "browser-unknown-ref",
		signature: /Unknown ref:/i,
		advice: "agent-browser 元素引用失效（Unknown ref）：页面 reload/导航/快照更新后旧 @ref 不再有效。先 `agent-browser --session <id> snapshot -i` 重新获取当前快照与元素 ref，再用新 ref 重发操作。",
	},
	{
		key: "browser-element-mismatch",
		signature: /Could not locate element|but none match name/i,
		advice: "agent-browser 按 role/name 定位未命中：元素不存在或可访问名称与预期不同。",
	},
];

/** Only classify when every candidate for the final failure is a browser command.
 * A browser merely present in an unexecuted branch is not the output's provenance. */
export function matchBrowserFailureRule(command: string, errorText: string): BrowserFailureRule | null {
	const executableText = splitHeredocs(command).stripped;
	const chains = shellPipelineChains(executableText);
	const operators = shellChainOperators(executableText);
	// With set options, earlier failure/pipe semantics may determine the result; don't guess.
	if (shellSegments(executableText).some((seg) => segmentExecutable(seg) === "set")) return null;
	let index = chains.length - 1;
	if (index < 0) return null;
	for (;;) {
		if (!chains[index]!.every((seg) => segmentExecutable(seg) === "agent-browser")) return null;
		if (operators[index] !== "&&") break;
		if (--index < 0) return null;
	}
	return BROWSER_FAILURE_RULES.find((rule) => rule.signature.test(errorText)) ?? null;
}

/** ev-20260916-c1a50c：bash 诊断规则键（有界短标识：规则类别 + 可执行名；不记录命令正文/凭据）。 */
export function diagnosticRuleKey(command: string, errorText: string, opts: { platform?: string | (() => string | undefined) } = {}): string {
	const lastSegment = shellSegments(command).at(-1) ?? [];
	const exe = path.basename(executableWords(lastSegment, true)[0] ?? "").toLowerCase() || "unknown";
	if (isBsdXargsError(command, errorText)) return "bsd-xargs";
	// ev-20260922-d9655d：BSD sed/cat 平台规则经 matchBashFailureRule 单源（真实可执行名 + 旗标/
	// script 定位 + 平台注入；未知平台 cat 记 cat-a-unsupported，不再一律记 bsd-cat）。
	const platformRule = matchBashFailureRule(command, errorText, opts);
	if (platformRule) return platformRule.key;
	if (isPrefixToolchainFailure(command, errorText)) return "prefix-toolchain";
	if (isTestFailureText(errorText)) return "test-failure";
	if (isCommandNotFoundFailure(errorText)) return `cmd-not-found:${exe}`;
	// ev-20261027-b9953e：agent-browser 失败按输出特征分类（与 diagnoseBashFailure 同优先级同源匹配，
	// 在 module/enoent/usage 等特征之前——不因输出偶含其它签名被抢 key 造成文案/计次口径分叉），
	// 不再合并进 generic:agent-browser——等待/ref/元素各类别独立计次不串类。
	const browserRule = matchBrowserFailureRule(command, errorText);
	if (browserRule) return browserRule.key;
	if (/MODULE_NOT_FOUND|Cannot find module/i.test(errorText)) return "module-missing";
	if (/No such file or directory/i.test(errorText)) return `enoent:${exe}`;
	if (/Cannot use import statement outside a module|require is not defined/i.test(errorText)) return "esm-conflict";
	if (/Usage:|\binvalid\b|\bunrecognized\b|illegal option/i.test(errorText)) return `usage:${exe}`;
	return `generic:${exe}`;
}

const BASH_DIAGNOSTIC_PREFIX = "[AMAGI Bash 诊断·软提示]";
export const BASH_HISTORY_MAX = 50;
export const GENERIC_BASH_DIAGNOSTIC = `\n\n${BASH_DIAGNOSTIC_PREFIX} 保留并阅读上方原始错误；先分类为 cwd/路径、环境/依赖、命令参数或真实代码失败。原样重试通常还会失败，先定位原因更省时间；按需核对项目说明与入口，修正后再执行。本提示不阻断重试。`;

// ev-20260830-b70efc：command not found 文案签名（bash/zsh：command not found；dash：cmd: not found）。
// 只认 shell 明确文案不认裸退出码 127——可执行文件 ENOENT 同样退出 127，须留给路径候选分支裁决。
export function isCommandNotFoundFailure(errorText: string): boolean {
	if (/command not found/i.test(errorText)) return true;
	return /:\s*\d*:\s*[^\s:]+:\s*not found\b/.test(errorText);
}

export interface BashDiagnosticOptions {
	errorText: string;
	/** 本次命令实际 cwd；错误尾注中的 [cwd] 优先。 */
	cwd?: string;
	/** 用于约束候选路径不得逃出仓库。 */
	repositoryRoot?: string;
	/** 同命令前缀最近记录的成功 cwd。 */
	successfulCwd?: string;
	/** 会话内全部历史成功 cwd（跨仓定位 ENOENT 相对路径用；由调用方注入 rememberSuccessfulBashCwd 的历史值）。 */
	historyCwds?: string[];
	/** 原始 bash 命令行（P2：建议命令改写用；缺省不改写）。 */
	command?: string;
	/** 测试可注入，生产默认 existsSync。 */
	pathExists?: (candidate: string) => boolean;
	/** ev-20260830-b70efc：bash 运行时信息（127 分支用；可传懒探测函数，仅命中分支才求值）。 */
	runtime?: BashRuntimeInfo | (() => BashRuntimeInfo | undefined);
	/** ev-20260922-d9655d：远端 shell 平台（"darwin"/"linux"/…；测试与跨平台注入用）。缺省从
	 *  runtime 探测（uname）推导，绝不回退宿主 process.platform——宿主与 bash 运行时可能分属两个平台。 */
	platform?: string;
	/** ev-20260924-bd1e06：git 顶层坐标信息（{toplevel, prefix}；null=不在仓库/在顶层/探测失败）。
	 *  缺省由本模块同步探测 git rev-parse（仅 ENOENT 分支求值）；测试注入避免真实 git。 */
	gitTop?: { toplevel: string; prefix: string } | null | (() => { toplevel: string; prefix: string } | null | undefined);
}

/** ev-20260924-bd1e06：同步探测 cwd 的 git 顶层坐标（--show-toplevel / --show-prefix）。
 *  非 git 目录 / 探测失败 / cwd 即仓库顶层（prefix 空——无双坐标系问题）→ null。 */
function probeGitTop(cwd: string): { toplevel: string; prefix: string } | null {
	try {
		const out = execFileSync("git", ["rev-parse", "--show-toplevel", "--show-prefix"], { cwd, encoding: "utf8", timeout: 3000, stdio: ["ignore", "pipe", "ignore"] });
		const lines = out.split("\n").map((s) => s.replace(/\/$/, "").trim()).filter(Boolean);
		if (lines.length < 2 || !path.isAbsolute(lines[0])) return null;
		return { toplevel: lines[0], prefix: lines[1] };
	} catch { /* lint-exempt:非 git 目录/探测超时→null（保守：不出坐标诊断） */ return null; }
}

/** 解析 gitTop 注入（值/懒函数；undefined 时内部探测）。 */
function resolveGitTopOption(options: BashDiagnosticOptions, cwd: string | undefined): { toplevel: string; prefix: string } | null {
	const injected = options.gitTop;
	if (injected !== undefined) {
		const v = typeof injected === "function" ? (() => { try { return injected(); } catch { /* lint-exempt:注入探测函数异常→undefined（回退 null） */ return undefined; } })() : injected;
		return v ?? null;
	}
	return cwd ? probeGitTop(cwd) : null;
}

function isWithin(root: string, target: string): boolean {
	const relative = path.relative(path.resolve(root), path.resolve(target));
	return relative === "" || (relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}

function extractMissingModulePath(errorText: string): string | undefined {
	const direct = errorText.match(/Cannot find module\s+['"`]([^'"`\r\n]+)['"`]/i)?.[1];
	if (direct) return direct;
	const signature = errorText.search(/MODULE_NOT_FOUND/i);
	if (signature < 0) return undefined;
	const nearby = errorText.slice(Math.max(0, signature - 240), signature + 240);
	return nearby.match(/['"`]((?:[A-Za-z]:[\\/]|\/)[^'"`\r\n]+)['"`]/)?.[1];
}

/**
 * 从错误绝对路径推导仓库内现存候选。只组合 cwd/其祖先的相对后缀，不递归扫描仓库。
 * 这覆盖 `cd repo && dev & node scripts/x` 把 scripts/x 错解到 repo 父目录的实战路径。
 */
export function findModulePathCandidate(
	missingPath: string,
	cwd: string,
	repositoryRoot: string = cwd,
	pathExists: (candidate: string) => boolean = fs.existsSync,
): string | undefined {
	if (!missingPath || !cwd) return undefined;
	const missing = path.isAbsolute(missingPath) ? path.normalize(missingPath) : path.resolve(cwd, missingPath);
	const candidates: string[] = [];
	const seen = new Set<string>();
	const addRelativeSuffixes = (relative: string) => {
		if (!relative || (relative === ".." || relative.startsWith(`..${path.sep}`)) || path.isAbsolute(relative)) return;
		const parts = relative.split(path.sep).filter(Boolean);
		for (let index = 0; index < parts.length; index++) {
			const candidate = path.resolve(cwd, ...parts.slice(index));
			if (candidate !== missing && !seen.has(candidate) && isWithin(repositoryRoot, candidate)) {
				seen.add(candidate);
				candidates.push(candidate);
			}
		}
	};

	addRelativeSuffixes(path.relative(cwd, missing));
	let ancestor = path.dirname(cwd);
	for (let depth = 0; depth < 6; depth++) {
		addRelativeSuffixes(path.relative(ancestor, missing));
		const parent = path.dirname(ancestor);
		if (parent === ancestor) break;
		ancestor = parent;
	}
	for (const candidate of candidates) {
		try { if (pathExists(candidate)) return candidate; } catch {}
	}
	return undefined;
}

function hasHttp4xx(errorText: string): boolean {
	return /(?:\bHTTP(?:\/[0-9.]+)?\s*|\bstatus(?:Code)?["']?\s*[:=]\s*|\bresponse(?:\s+status)?\s*[:=]?\s*)4\d\d\b|\b4\d\d\s+(?:Bad Request|Unauthorized|Forbidden|Not Found|Conflict|Unprocessable Entity|Too Many Requests)\b/i.test(errorText);
}

function contractPatternRange(errorText: string): { start: number; end: number } | undefined {
	const literal = /\/(?:\\.|[^\/\r\n])+\/[dgimsuvy]*/g;
	for (const match of errorText.matchAll(literal)) {
		const start = match.index ?? 0;
		const nearby = errorText.slice(Math.max(0, start - 100), Math.min(errorText.length, start + match[0].length + 100));
		if (match[0].startsWith("/^") || /\bzod\b|\.regex\s*\(|\bregex\b|["']?pattern["']?\s*[:=]/i.test(nearby)) {
			return { start, end: start + match[0].length };
		}
	}
	const zodCall = /(?:\b[zv]\.)?string\(\)\.regex\s*\(/i.exec(errorText);
	if (zodCall?.index !== undefined) return { start: zodCall.index, end: zodCall.index + zodCall[0].length };
	return undefined;
}

function contractPatternExcerpt(errorText: string): string | undefined {
	if (!hasHttp4xx(errorText)) return undefined;
	const range = contractPatternRange(errorText);
	if (!range) return undefined;
	return errorText.slice(Math.max(0, range.start - 120), Math.min(errorText.length, range.end + 120)).trim();
}

/** [cwd] 尾注由 bash-override.ts 仅在显式 cwd 的失败结果中追加。 */
export function extractBashCwd(errorText: string): string | undefined {
	let cwd: string | undefined;
	for (const match of errorText.matchAll(/^\[cwd\]\s+(.+?)\s*$/gim)) cwd = match[1]?.trim();
	return cwd || undefined;
}

/** 同款命令按“执行程序 + 稳定入口”分组，忽略 node/tsx 诊断脚本后的易变参数。 */
export function bashCommandPrefix(command: string): string {
	const segment = shellSegments(command)[0];
	const words = segment ? executableWords(segment, true) : [];
	if (!words.length) return "";
	const executable = path.basename(words[0]).toLowerCase();
	let length = Math.min(words.length, 2);
	if (["npm", "pnpm", "yarn", "bun"].includes(executable) && words[1] === "run") length = Math.min(words.length, 3);
	return [executable, ...words.slice(1, length)].join(" ");
}

export function rememberSuccessfulBashCwd(history: Map<string, string>, command: string, cwd: string): void {
	const prefix = bashCommandPrefix(command);
	if (!prefix || !cwd) return;
	if (!history.has(prefix) && history.size >= BASH_HISTORY_MAX) {
		const oldest = history.keys().next().value;
		if (oldest !== undefined) history.delete(oldest);
	}
	history.set(prefix, cwd);
}

function diagnosticText(body: string): string {
	return `\n\n${BASH_DIAGNOSTIC_PREFIX} 保留并阅读上方原始错误；${body} 本提示不阻断重试。`;
}

/**
 * ev-20260904 复盘 §5③：测试断言失败特征识别（纯函数，供分流与测试直接断言）。
 * 覆盖 vitest/jest 汇总行（Test Files N failed / Tests N failed / N failed）、node:assert
 * AssertionError、playwright/jest expect(received) 断言栈、测试 UI 失败符号（✕/✖）。
 * 高置信优先：汇总行/断言栈是测试运行器专属输出；非测试命令几乎不会产生这些特征。
 */
export function isTestFailureText(errorText: string): boolean {
	return (
		/Test Files?\s+[^\r\n]*\bfail/i.test(errorText) ||
		/\bTests?\s+\d+\s+failed/i.test(errorText) ||
		/\b\d+\s+failed\b/.test(errorText) ||
		/AssertionError/.test(errorText) ||
		/^(?:--- FAIL:\s|FAIL(?:\s|$))/m.test(errorText) ||
		/expect\(received\)/.test(errorText) ||
		/[✕✖]/u.test(errorText)
	);
}

function cwdDiffText(currentCwd: string | undefined, successfulCwd: string | undefined): string {
	if (!currentCwd || !successfulCwd || path.resolve(currentCwd) === path.resolve(successfulCwd)) return "";
	return ` 低置信线索：同命令前缀此前在 cwd=${successfulCwd} 成功，本次 cwd=${currentCwd}——仅当上方缺失的相对路径本应在前者下解析时，再用 bash cwd 参数对齐；本次 cwd 若正是目标树则忽略本条。`;
}

// ev-20261021-44e416：cwd 归因须有路径解析失败证据。命令前缀（git diff / pnpm --filter / python3 -）
// 极宽泛，「同前缀在别处成功过」本身不是 cwd 故障证据——只有输出明确出现路径解析失败、且缺失路径
// 是相对路径（随 cwd 变化）时，cwd 对齐建议才有因果依据。
const PATH_RESOLUTION_FAILURE_RE = /No such file or directory|ENOENT|ENOTDIR|Cannot find module|not a git repository|cannot access|can't open file|does not exist|No projects matched the filters|ERR_PNPM_NO_IMPORTER_MANIFEST|Could not read package\.json|no such file|找不到/i;

/** 命令内输出重定向目标（排除 /dev/null 与 fd 复制 2>&1）；按 cwd 解析为绝对路径。
 *  diting D-03（含复核残留）：重定向是 shell 词法中的**操作符**，不是 word 起点——在剥离 heredoc
 *  正文（splitHeredocs，含 `<<-` Tab 闭合）后的原文上按引号/转义状态逐字符扫描：只认引号外的 `>`，
 *  覆盖 `>|` 强制覆盖、附着写法（`false>x`、`'2'>x`）、任意位 fd（`10>x`）与 `&>`/`>>`；目标按
 *  shell 拼接规则读取（引号内空格属于目标，`>'my 'log.txt` → `my log.txt`）。注释（引号外 word 起点
 *  的 #）、进程替换 `>(…)`、fd 复制 `>&N`/`>&-` 不计。 */
export function redirectedOutputTargets(command: string, cwd: string | undefined): string[] {
	const out: string[] = [];
	const { stripped: src } = splitHeredocs(command);
	const BREAK = new Set([" ", "\t", "\n", ";", "&", "|", "<", ">", "(", ")"]);
	let quote: "'" | '"' | null = null;
	let atWordStart = true;
	for (let i = 0; i < src.length; i++) {
		const ch = src[i]!;
		if (quote) { if (ch === "\\" && quote === '"') i++; else if (ch === quote) quote = null; continue; }
		if (ch === "\\") { i++; atWordStart = false; continue; }
		if (ch === "'" || ch === '"') { quote = ch; atWordStart = false; continue; }
		if (ch === "#" && atWordStart) { while (i < src.length && src[i] !== "\n") i++; atWordStart = true; continue; }
		if (ch !== ">") { atWordStart = BREAK.has(ch); continue; }
		// 引号外 `>`：重定向操作符（前缀 fd 数字/& 与本判定无关——目标同为文件）
		let j = i + 1;
		if (src[j] === "(") { atWordStart = true; continue; } // 进程替换 >(…)
		if (src[j] === ">" || src[j] === "|") j++;
		if (src[j] === "&") { i = j; atWordStart = true; continue; } // fd 复制 >&2 / 2>&1 / >&-
		while (src[j] === " " || src[j] === "\t") j++;
		let target = "";
		let q: "'" | '"' | null = null;
		for (; j < src.length; j++) {
			const c = src[j]!;
			if (q) { if (c === q) q = null; else if (c === "\\" && q === '"' && j + 1 < src.length) target += src[++j]; else target += c; continue; }
			if (c === "'" || c === '"') { q = c; continue; }
			if (c === "\\" && j + 1 < src.length) { target += src[++j]; continue; }
			if (BREAK.has(c)) break;
			target += c;
		}
		i = j - 1;
		atWordStart = true;
		if (!target || target === "/dev/null") continue;
		out.push(path.isAbsolute(target) || !cwd ? target : path.resolve(cwd, target));
	}
	return [...new Set(out)];
}

/** 剥离 bash 结果的执行尾注后是否几乎无输出（失败详情不在结果里）。 */
function failureOutputIsEmpty(errorText: string): boolean {
	const body = errorText
		.replace(/^\[cwd\].*$/gm, "")
		.replace(/Command exited with code \d+/g, "")
		.replace(/\(no output\)/g, "")
		.replace(/^\[debug [^\]]*\].*$/gm, "");
	return body.trim().length === 0;
}

/** ev-20261021-44e416：脚本内 assert（Python 最终异常为 AssertionError、无 pytest/unittest 汇总）
 *  ——非测试框架用例失败；返回断言帧位置（无则 ""）或 null。
 *  diting D-04：只看**最后一个** Traceback 段（异常链 `raise X from e` / during handling 时，前段是
 *  被链接的原因，最终异常在末段）：末段异常行须为 AssertionError，帧也只取末段的最后一帧。 */
export function scriptAssertionFrame(errorText: string): string | null {
	const header = "Traceback (most recent call last)";
	const at = errorText.lastIndexOf(header);
	if (at < 0) return null;
	if (/short test summary info|=+ FAILURES =+|\b\d+ failed\b|FAILED \(failures=|\bpytest\b/i.test(errorText)) return null;
	const lastBlock = errorText.slice(at + header.length);
	// 末段异常行：帧（缩进行）之后首个非缩进非空行
	const finalLine = lastBlock.split("\n").slice(1).find((l) => l.trim() !== "" && !/^\s/.test(l));
	if (!finalLine || !/^AssertionError\b/.test(finalLine)) return null;
	const frames = [...lastBlock.matchAll(/File "([^"]+)", line (\d+)/g)];
	const last = frames.at(-1);
	return last ? `${last[1]}:${last[2]}` : "";
}

// ── P2（8月迭代第三轮复盘）：bash 诊断升级为「建议命令」改写 ──
// 实战：上下文缺失型失败占全部 bash 失败 37%——只描述原因不动手改写时，模型仍需 1-2 轮
// 自己拼正确命令；机械改写高置信场景（路径替换/BSD sed -i 语法）直接给出可复制的建议命令。

/** 命令内字符串替换（仅当原文作为独立 token/子串出现，避免误改）。 */
function rewriteToken(command: string, from: string, to: string): string | undefined {
	if (!from || !command.includes(from)) return undefined;
	return command.split(from).join(to);
}

// ── ev-20260922-d9655d（B1）：BSD 命令诊断结构化单源 ──
// 根因边界：BSD sed/cat 识别与改写规则此前已部分存在，但①以「命令文本含 sed/cat 字样」判归属
// （echo 参数里的 sed 字样会被误分类）；②rewriteBsdSedRelativeAddr 对整条命令全局正则替换 N,+M
// （echo 参数/文件名里的同形态字面被连带改写）；③BSD cat 归因不区分远端 shell 平台（宿主 ≠ 远端）；
// ④平台分支仍附 cwd 纠偏建议（高置信参数错误与 cwd 无关，[cwd] 尾注只是执行事实）。本批新增纯
// matchBashFailureRule 产出 {key, cause, confidence, suggestion?, showCwdAdvice}（+readHint 等价
// 提示），diagnosticRuleKey/suggestCommandRewrite/diagnoseBashFailure 三处共用同一结果；只整理
// 本条涉及的平台规则（sed/cat），不重写整个诊断库（xargs/prefix/module/enoent 路由保持原样）。

/** BSD sed 错误签名（macOS；GNU sed 对 -i 无需后缀参数，两者语法不兼容）。BSD sed 回显 script
 *  时引号内可含换行（Darwin 25 实测 `sed -n '1~2p'` 报 sed: 1: "1~2p\n": invalid command code ~），
 *  须用 [^"]* 跨行匹配；同行形态保留兼容（历史会话样本均为单行回显）。 */
const BSD_SED_ERROR_SIGNATURE = new RegExp([
	'sed: \\d+: "[^"]*": (?:invalid command code|extra characters at the end of|unterminated substitute|expected context address|unterminated regular expression)',
	"sed: [^\\r\\n]*: (?:invalid command code|extra characters at the end of|unterminated substitute|expected context address|unterminated regular expression)",
	"sed: -i may not be used with stdin",
	"sed: invalid command code",
	"extra characters at the end of [a-z]+ command",
].join("|"), "i");

/** 段内定位可执行名 token 下标（须先经 executableWords 核验段的可执行名确为 name，防「echo 'sed …'
 *  字样」这类 operand 冒充可执行；index 定位只服务 script/旗标参数解析）。 */
function findInvocationTokenIndex(texts: string[], name: string): number {
	for (let i = 0; i < texts.length; i++) {
		if (path.basename(texts[i]).toLowerCase() === name) return i;
	}
	return -1;
}

/** 直接可执行段（span 视图；span 相对原始命令串——改写据此定位）。 */
function directShellInvocations(command: string, name: string): { texts: string[]; exeIndex: number; segment: ShellTokenSpan[] }[] {
	const out: { texts: string[]; exeIndex: number; segment: ShellTokenSpan[] }[] = [];
	for (const segment of segmentShellSpans(tokenizeShellSpans(command))) {
		const texts = segment.map((token) => token.text);
		const exeIndex = findInvocationTokenIndex(texts, name);
		if (exeIndex < 0) continue;
		if (path.basename(executableWords(texts, true)[0] ?? "").toLowerCase() !== name) continue;
		out.push({ texts, exeIndex, segment });
	}
	return out;
}

/** 可执行域真实执行 payload（wrapper/$() 替换/未引用 heredoc body 展开；解析异常返回空）。 */
function safeExecutablePayloads(command: string): string[] {
	try {
		const view = analyzeExecutableShell(command);
		return [...view.wrapperPayloads, ...view.substitutionPayloads, ...view.unquotedBodyPayloads];
	} catch {
		return [];
	}
}

/** 命令是否真实以 <name> 为可执行名调用：直接段 + payload 递归（深度 2）。「echo 参数里的 sed
 *  字样」是数据不是执行，不计入；quoted heredoc body 同理（其 payload 只含 body 内 $()/反引号）。 */
function commandInvokesExecutable(command: string, name: string, depth = 0): boolean {
	if (directShellInvocations(command, name).length) return true;
	if (depth >= 2) return false;
	for (const payload of safeExecutablePayloads(command)) {
		if (payload && commandInvokesExecutable(payload, name, depth + 1)) return true;
	}
	return false;
}

/** sed 参数序列中 script token 的下标集（-e/--expression 取值或首个非旗标 operand；-i 的独立空串
 *  后缀、-f/--file 取值与文件 operand 不算 script）。保守解析：不认识的形态不误标。 */
function sedScriptTokenIndexes(texts: string[], sedIndex: number): number[] {
	const scripts: number[] = [];
	let expectScript = false;
	let sawExplicitScript = false;
	let firstOperand = true;
	let i = sedIndex + 1;
	while (i < texts.length) {
		const token = texts[i];
		if (expectScript) { scripts.push(i); expectScript = false; sawExplicitScript = true; i++; continue; }
		if (token === "--") { if (i + 1 < texts.length && !sawExplicitScript) scripts.push(i + 1); break; }
		if (token.startsWith("--expression=")) { scripts.push(i); sawExplicitScript = true; i++; continue; }
		if (token === "--expression" || token === "-e") { expectScript = true; i++; continue; }
		if (token === "--file" || token === "-f") { i += 2; continue; }
		if (/^-[a-zA-Z]+$/.test(token)) {
			if (token.includes("f")) { i += 2; continue; }        // 组合旗标含 f：下一参是 script 文件
			if (token.includes("e")) { expectScript = true; i++; continue; }
			if (token.includes("i") && texts[i + 1] === "") i++;  // 裸 -i 的独立空串后缀（BSD 形态）
			i++;
			continue;
		}
		if (/^-i\./.test(token) || /^--/.test(token)) { i++; continue; } // -i.bak 附带后缀 / 其余长旗标
		if (firstOperand && !sawExplicitScript) { scripts.push(i); firstOperand = false; }
		i++;
	}
	return scripts;
}

/** GNU 相对行号在命令中的真实使用情况：anyRelative 含 wrapper/替换 payload 递归（判因）；
 *  directParseable 仅看直接段——payload 内的 script 无法映射回原始命令偏移，不作为改写依据。 */
function sedRelativeAddrFacts(command: string, depth = 0): { anyRelative: boolean; directParseable: boolean } {
	let anyRelative = false;
	let directParseable = false;
	for (const invocation of directShellInvocations(command, "sed")) {
		for (const index of sedScriptTokenIndexes(invocation.texts, invocation.exeIndex)) {
			const script = invocation.texts[index];
			if (!/,\+\d/.test(script)) continue;
			anyRelative = true;
			if (/(\d+),\+(\d+)/.test(script)) directParseable = true;
		}
	}
	if (depth < 2) {
		for (const payload of safeExecutablePayloads(command)) {
			if (payload && sedRelativeAddrFacts(payload, depth + 1).anyRelative) anyRelative = true;
		}
	}
	return { anyRelative, directParseable };
}

/** BSD sed 错误签名 + 真实可执行名 sed（结构化判定；echo 参数里的 sed 字样不命中）。 */
function isBsdSedError(command: string, errorText: string): boolean {
	if (!BSD_SED_ERROR_SIGNATURE.test(errorText)) return false;
	return commandInvokesExecutable(command, "sed");
}

/** ev-20260916-3324e4：macOS/BSD xargs 无 -d 选项错误签名（命令须真用了 -d，错误须指向 d）。 */
export function isBsdXargsError(command: string, errorText: string): boolean {
	if (!/\bxargs\b/.test(command)) return false;
	if (!/\s-d(?=[\s'\"=]|$)/.test(command)) return false; // 命令实际使用了 -d 才归属本规则
	return /xargs:\s+(?:illegal|invalid) option\b[^\n]*\bd\b/i.test(errorText);
}

/** 上游已是 NUL 分隔时 `-d '<分隔符>' → -0` 的安全改写（仅替换选项无效，不满足前置不给改写）。 */
function rewriteBsdXargsD(command: string): string | undefined {
	if (!/\b(?:print0|--null|-z)\b/.test(command)) return undefined;
	const rewritten = command.replace(/(\bxargs\b[^\n|;&]*?)\s-d\s+(?:'\\n'|'\\t'|'\\0'|"\\n"|"\\t"|\\n|\\t|'[^']*'|"[^"]*")/g, "$1 -0");
	return rewritten !== command ? rewritten : undefined;
}

/** macOS BSD sed 的 -i 必须跟备份后缀参数：裸 -i 改写为 -i ''（不动 -i.bak/已有 '' 形参）。 */
function rewriteBsdSedI(command: string): string | undefined {
	// 仅改写 sed 调用后的裸 -i（-i 后是空白/行尾，且下一参不是空串后缀 ''/“”）；-i.bak 不匹配
	const rewritten = command.replace(/(\bsed\s+(?:[^\n;|&]*?\s)?)-i(?=\s|$)(?!\s*(?:''|""))/g, "$1-i ''");
	return rewritten !== command ? rewritten : undefined;
}

// ── 8月迭代第四轮（跨仓 webui 复盘）：BSD cat -A / BSD sed 相对行号 / 历史 cwd ENOENT ──

/** macOS BSD cat 错误签名：GNU cat 的 -A（= -vET）在 BSD cat 不存在（实战：cat: illegal option -- A）。 */
const BSD_CAT_A_ERROR_SIGNATURE = /cat: illegal option -- A\b/;

/** 段内 letters-only 短旗标簇（-A/-Ae/-n…；-- 长旗标与带值形态不算簇）。 */
function invocationFlagClusters(texts: string[], exeIndex: number): string[] {
	return texts.slice(exeIndex + 1).filter((token) => /^-[A-Za-z]+$/.test(token));
}

/** 命令中真实 <name> 调用是否带满足谓词的旗标簇（直接段 + payload 递归；grep 的 -A2 不算——
 *  可执行名核验已排除非 cat 段）。 */
function invocationHasFlagCluster(command: string, name: string, predicate: (flag: string) => boolean, depth = 0): boolean {
	for (const invocation of directShellInvocations(command, name)) {
		if (invocationFlagClusters(invocation.texts, invocation.exeIndex).some(predicate)) return true;
	}
	if (depth >= 2) return false;
	for (const payload of safeExecutablePayloads(command)) {
		if (payload && invocationHasFlagCluster(payload, name, predicate, depth + 1)) return true;
	}
	return false;
}

/** BSD cat -A 识别：真实 cat 调用 + -A 旗标簇 + 错误指向 A（三者齐备才命中；平台归因在
 *  matchBashFailureRule 内按注入平台裁决——未知平台不作 BSD 归因）。 */
function isBsdCatError(command: string, errorText: string): boolean {
	if (!BSD_CAT_A_ERROR_SIGNATURE.test(errorText)) return false;
	return invocationHasFlagCluster(command, "cat", (flag) => flag.includes("A"));
}

// ── ev-20261002-de1845（friction/P3）：GNU-only 旗标/地址执行前预警（纯命令文本检测） ──
// 根因：BSD 陷阱防护只有被动两层——静态环境注记（DARWIN_BSD_NOTE 文本清单未含 cat -A）与失败后
// 诊断（错误已发生才触发，matchBashFailureRule）；命令文本层面无「执行前主动预警」，模型注意力在
// 命令构造点而非环境记忆点（实战 sed N,+p 在 AGENTS 环境段已明示仍复发）。本检测为第三层：
// bash 执行时点、绑定命令文本的模式命中（宁可漏报不误报——真实可执行名核验 + heredoc 跳过）。
// 仅做命中检测；平台裁决（darwin 才预警）、文案与计次降频在 bash-override 组装（本层无状态）。

export type GnuOnlyBsdPatternHit =
	| { kind: "cat-A" }
	| { kind: "sed-relative-addr" };

/** GNU-only 形态命中：①真实 cat 调用带 -A 旗标簇（BSD cat 无此选项，必失败）；②真实 sed 调用
 *  script 含 N,+M 相对地址（GNU 扩展，BSD 支持视版本——不可移植，部分环境失败）。
 *  复用失败诊断的同一套词法工具（directShellInvocations/sedScriptTokenIndexes）——检测口径
 *  与事后改写建议严格一致，不会出现「预警命中但诊断不认」的口径漂移。 */
export function gnuOnlyBsdPatternHit(command: string): GnuOnlyBsdPatternHit | null {
	// heredoc body 是数据不作命令检测（与 rewriteBsdSedRelativeAddr 同保守口径：含 heredoc 整体跳过；
	// 定界符可带引号 <<'EOF' / <<"EOF"）
	if (/<<-?\s*['"]?[A-Za-z_(]/.test(command)) return null;
	if (invocationHasFlagCluster(command, "cat", (flag) => flag.includes("A"))) return { kind: "cat-A" };
	for (const invocation of directShellInvocations(command, "sed")) {
		for (const index of sedScriptTokenIndexes(invocation.texts, invocation.exeIndex)) {
			if (/\d+,\+\d+/.test(invocation.texts[index])) return { kind: "sed-relative-addr" };
		}
	}
	return null;
}

/** GNU cat -A → BSD cat -et（-e 显示行尾 $、-t 显示 tab ^I，均隐含 -v）。只改写 cat 调用段内
 *  -A 开头的旗标簇（-A/-Ae/-Aet…，簇内字母去重合并）；其它命令的 -A（如 grep -A2）不动。 */
function rewriteBsdCatA(command: string): string | undefined {
	let result = command;
	let changed = false;
	for (const segment of shellSegments(command)) {
		const exe = path.basename(executableWords(segment, true)[0] || "").toLowerCase();
		if (exe !== "cat") continue;
		for (const flag of segment) {
			if (!/^-[A-Za-z]+$/.test(flag) || !flag.startsWith("-A")) continue;
			const merged: string[] = ["e", "t"];
			for (const ch of flag.slice(2)) if (!merged.includes(ch)) merged.push(ch);
			// 旗标按独立 token 边界替换（前后空白/段界），避免误伤同命令内其它程序的 -A
			const replaced = result.replace(new RegExp(`(^|[\\s;|&])${flag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=$|[\\s;|&])`), `$1-${merged.join("")}`);
			if (replaced !== result) { result = replaced; changed = true; }
		}
	}
	return changed ? result : undefined;
}

/** GNU sed 相对行号地址 addr,+N（BSD sed 不支持）→ 绝对区间 addr,addr+N；N/M 均为可解析数字才改写。
 *  ev-20260922-d9655d：只改写 sed 调用 script token 的原始 span（引号原样保留），不再对整条命令
 *  全局替换——echo 参数、文件名里的 N,+M 字面文本不动；含 heredoc 的命令不机械改写（body 是数据，
 *  span 视图区分不了 body 行与真实段）。token.text 是引号剥离 payload，若因转义在 raw 中找不到
 *  原字面（改写可能错位）则放弃该 token（保守不改写）。 */
function rewriteBsdSedRelativeAddr(command: string): string | undefined {
	if (/<<-?\s*[A-Za-z_(]/.test(command)) return undefined;
	const edits: { start: number; end: number; raw: string }[] = [];
	for (const invocation of directShellInvocations(command, "sed")) {
		for (const index of sedScriptTokenIndexes(invocation.texts, invocation.exeIndex)) {
			const token = invocation.segment[index];
			const matches = [...token.text.matchAll(/(\d+),\+(\d+)/g)];
			if (!matches.length) continue;
			const raw = command.slice(token.start, token.end);
			let rawOut = raw;
			let safe = true;
			for (const match of matches) {
				const from = Number(match[1]);
				const count = Number(match[2]);
				if (!Number.isFinite(from) || !Number.isFinite(count) || from < 1 || count < 1 || !raw.includes(match[0])) { safe = false; break; }
				rawOut = rawOut.split(match[0]).join(`${match[1]},${from + count}`);
			}
			if (safe && rawOut !== raw) edits.push({ start: token.start, end: token.end, raw: rawOut });
		}
	}
	if (!edits.length) return undefined;
	let out = command;
	for (const edit of edits.sort((a, b) => b.start - a.start)) {
		out = out.slice(0, edit.start) + edit.raw + out.slice(edit.end);
	}
	return out !== command ? out : undefined;
}

/** sed 纯区间打印（-n + 单 script 恰为 N,+Mp + 恰一个字面文件 operand）→ read 工具等价提示。
 *  ev-20260922-d9655d：能给 read 等价提示时优先给提示（read 工具原生支持 offset/limit 分页），
 *  不自动执行任何改写。 */
function sedPrintRangeReadHint(command: string): string | undefined {
	if (/<<-?\s*[A-Za-z_(]/.test(command)) return undefined;
	for (const invocation of directShellInvocations(command, "sed")) {
		const { texts, exeIndex, segment } = invocation;
		const scripts = sedScriptTokenIndexes(texts, exeIndex);
		if (scripts.length !== 1) continue;
		const scriptIndex = scripts[0];
		const match = /^(\d+),\+(\d+)p$/.exec(texts[scriptIndex]);
		if (!match) continue;
		const from = Number(match[1]);
		const count = Number(match[2]);
		if (!Number.isFinite(from) || !Number.isFinite(count) || from < 1 || count < 1) continue;
		// -n/--quiet/--silent 关闭自动打印（否则 p 输出叠加全文，与 read 不等价）
		const silent = texts.slice(exeIndex + 1, scriptIndex).some((token) =>
			token === "--quiet" || token === "--silent" || (/^-[a-z]+$/.test(token) && token.includes("n")),
		);
		if (!silent) continue;
		// script 后恰一个字面文件 operand（无 $() 展开/重定向复合词）
		const operands = segment.slice(scriptIndex + 1);
		if (operands.length !== 1 || operands[0].unquotedVar) continue;
		const file = operands[0].text;
		if (!file || file.startsWith("-") || /[<>|&]/.test(file)) continue;
		return `read 工具等价：read(path=${file}, offset=${from}, limit=${count + 1})`;
	}
	return undefined;
}

/** 远端 shell 平台（小写）：从 bash 运行时探测（uname）推导；探测失败/未知 = undefined。
 *  绝不回退宿主 process.platform——宿主与 bash 运行时可能分属两个平台（WSL 实战）。
 *  ev-20261002-de1845：导出（bash-override 执行前 BSD 陷阱预警复用同一平台归因，单源）。 */
export function shellPlatformOf(info: BashRuntimeInfo | undefined): string | undefined {
	if (!info?.probed || !info.uname) return undefined;
	if (/^darwin/i.test(info.uname)) return "darwin";
	if (/^linux/i.test(info.uname)) return "linux";
	return undefined;
}

/** platform 选项求值（string | 懒函数——cat 规则命中分支才求值，避免无谓探测）；异常按未知处理。 */
function resolvePlatformOption(platform?: string | (() => string | undefined)): string | undefined {
	if (typeof platform === "function") {
		try { return platform() || undefined; } catch { return undefined; }
	}
	return platform || undefined;
}

/** ev-20260922-d9655d：BSD 平台规则结构化单源（纯函数）——diagnosticRuleKey/suggestCommandRewrite/
 *  diagnoseBashFailure 共用同一匹配结果。多错误混杂（sed/cat 两种平台错误同时命中）不强推单因：
 *  返回 undefined 退回通用诊断保留原错，不给自动改写。 */
export interface BashFailureRuleMatch {
	/** 规则键（diagnosticRuleKey 同口径：bsd-sed / bsd-cat / cat-a-unsupported）。 */
	key: string;
	/** 原因解释（诊断正文核心句）。 */
	cause: string;
	/** high=高置信参数/平台错误（抑制 cwd 纠偏建议）；低置信不产出匹配（退回通用诊断保留原错）。 */
	confidence: "high" | "low";
	/** 高置信机械改写建议命令（可复制整行；无则 undefined）。 */
	suggestion?: string;
	/** 是否附 cwd 纠偏建议；高置信参数错误为 false（[cwd] 尾注仍由 bash-override 作为执行事实保留）。 */
	showCwdAdvice: boolean;
	/** read 工具等价提示（sed 纯区间打印；优先于建议命令展示，不自动执行）。 */
	readHint?: string;
}

export function matchBashFailureRule(
	command: string,
	errorText: string,
	opts: { platform?: string | (() => string | undefined) } = {},
): BashFailureRuleMatch | undefined {
	if (!command) return undefined;
	const catHit = isBsdCatError(command, errorText);
	const sedHit = isBsdSedError(command, errorText);
	if (catHit && sedHit) return undefined; // 多错误混杂：不强推单因
	if (catHit) {
		const platform = resolvePlatformOption(opts.platform);
		if (platform === "linux") return undefined; // Linux 正常 GNU cat 支持 -A：不给 BSD 结论
		if (platform === "darwin") {
			return {
				key: "bsd-cat",
				cause: "检测到 macOS BSD cat 无 -A 选项（GNU cat 的 -A = -vET；-e 显示行尾 $、-t 显示 tab ^I，均隐含 -v），建议改写为 cat -et。",
				confidence: "high",
				suggestion: rewriteBsdCatA(command),
				showCwdAdvice: false,
			};
		}
		return {
			key: "cat-a-unsupported",
			cause: "当前 shell 的 cat 不支持 -A 旗标（错误签名 cat: illegal option -- A）。未确认 bash 运行时平台，不据此归因到某一具体 cat 实现；等价旗标建议 cat -et（-e 显示行尾 $、-t 显示 tab ^I，均隐含 -v），请先确认远端 cat 实现后选用。",
			confidence: "high",
			suggestion: rewriteBsdCatA(command),
			showCwdAdvice: false,
		};
	}
	if (!sedHit) return undefined;
	if (/invalid command code/i.test(errorText)) {
		const facts = sedRelativeAddrFacts(command);
		if (facts.anyRelative) {
			return {
				key: "bsd-sed",
				cause: facts.directParseable
					? "检测到 macOS BSD sed 不支持 GNU 相对行号地址 addr,+N（实际 script 使用了 N,+M 相对地址）。"
					: "检测到 macOS BSD sed 不支持 GNU 相对行号地址 addr,+N。建议改写为绝对区间 N,(N+M)（M 为追加行数，N+M 即结束行）。",
				confidence: "high",
				suggestion: facts.directParseable ? rewriteBsdSedRelativeAddr(command) : undefined,
				showCwdAdvice: false,
				readHint: sedPrintRangeReadHint(command),
			};
		}
	}
	const iRewrite = rewriteBsdSedI(command);
	if (iRewrite) {
		return {
			key: "bsd-sed",
			cause: "检测到 macOS BSD sed 语法冲突：-i 必须跟备份后缀参数（GNU sed 的裸 -i 在 BSD sed 会被当作脚本串入）。",
			confidence: "high",
			suggestion: iRewrite,
			showCwdAdvice: false,
		};
	}
	return {
		key: "bsd-sed",
		cause: "检测到 macOS BSD sed 与 GNU sed 语法不兼容（BSD 签名：invalid command code / extra characters 等）。请按 BSD sed 语法核对 script 后修正再执行，原样重试仍会失败。",
		confidence: "high",
			showCwdAdvice: false,
		};
}

/** ENOENT 错误文本中的缺失路径（shell 风格 `cmd: path: No such...` / Node 风格 `...open 'path'`）。 */
function enoentMissingPath(errorText: string): string | undefined {
	const enoent = errorText.match(/: ((?:[A-Za-z]:[\\/]|\/)?[^:\r\n]*?): No such file or directory/) || errorText.match(/No such file or directory, open '?([^'\r\n]+)'?/);
	return enoent?.[1]?.trim() || undefined;
}

/** 历史成功 cwd 探测：missing 为相对路径且当前 cwd 下不存在时，逐个历史 cwd resolve 定位（首个命中即返回）。
 *  跨仓会话实战：grep 相对路径在本次 cwd 报 ENOENT，但文件在会话前段成功执行过的仓库 cwd 下真实存在。 */
function probeHistoryCwds(
	missing: string,
	cwd: string,
	historyCwds: string[] | undefined,
	exists: (candidate: string) => boolean,
): { historyCwd: string; candidate: string } | undefined {
	if (!historyCwds?.length || !missing || !cwd || path.isAbsolute(missing)) return undefined;
	try { if (exists(path.resolve(cwd, missing))) return undefined; } catch {}
	for (const historyCwd of historyCwds) {
		if (!historyCwd || path.resolve(historyCwd) === path.resolve(cwd)) continue;
		const candidate = path.resolve(historyCwd, missing);
		try { if (exists(candidate)) return { historyCwd, candidate }; } catch {}
	}
	return undefined;
}

// ── ev-20260910-bcb097（D）：npm/npx --prefix 前端工具链防呆 ──
// 实战：`npx --prefix mobile vue-tsc -b` / `npx --prefix mobile vitest run` 形态看似合理但必败——
// --prefix 只切换包管理器的安装/解析基准，不改变进程 cwd；vue-tsc/vite/vitest 仍按当前 cwd 解析
// tsconfig 与 vite 插件链，故报 TS5083/找不到 tsconfig/Failed to resolve import/插件与 vite 模块缺失。

/** 前端工具链按 cwd 解析失败的典型错误签名（vue-tsc/vite/vitest）。 */
export const PREFIX_TOOLCHAIN_ERROR_RE = /TS5083|(?:找不到|无法找到)[^\r\n]*tsconfig|Failed to resolve import|Install @vitejs\/plugin-|Cannot find module[^\r\n]*vite/i;

/** 触发条件（设计 §D，两者同时）：命令含 --prefix 且失败输出命中前端工具链 cwd 解析特征。 */
export function isPrefixToolchainFailure(command: string, errorText: string): boolean {
	if (!command || !/--prefix\b/.test(command)) return false;
	return PREFIX_TOOLCHAIN_ERROR_RE.test(errorText);
}

/** `npx --prefix mobile vue-tsc -b` → `cd mobile && npx vue-tsc -b`：剥离 --prefix 参值对、
 *  改为 cd 进包目录后执行（`npm --prefix <dir> run <script>` 形态亦可——跑脚本时 npm 会把 cwd 设为包目录）。 */
export function rewritePrefixToolchain(command: string): string | undefined {
	const m = /(?:^|[\s;|&])--prefix(?:=|[ \t]+)([^\s;&|]+)/.exec(command);
	if (!m?.[1]) return undefined;
	const dir = m[1].replace(/^["']|["']$/g, "");
	const rest = `${command.slice(0, m.index)} ${command.slice(m.index + m[0].length)}`.replace(/\s{2,}/g, " ").trim();
	return dir && rest ? `cd ${dir} && ${rest}` : undefined;
}

/** 高置信建议命令改写：返回可直接复制的建议命令，无法高置信改写返回 undefined。 */
export function suggestCommandRewrite(command: string, errorText: string, opts: { cwd?: string; repositoryRoot?: string; pathExists?: (p: string) => boolean; historyCwds?: string[]; platform?: string | (() => string | undefined) } = {}): string | undefined {
	if (!command) return undefined;
	// ⓪/① ev-20260922-d9655d：BSD 平台规则经 matchBashFailureRule 单源（真实可执行名 + 旗标/
	// script 定位 + 平台注入）；优先序保持 cat → xargs → sed 不变（darwin cat 的 -et 改写仍居首）。
	const platformRule = matchBashFailureRule(command, errorText, { platform: opts.platform });
	if (platformRule?.key === "bsd-cat" && platformRule.suggestion) return platformRule.suggestion;
	// ⓪' ev-20260916-3324e4：BSD xargs 无 -d；上游已是 NUL 分隔才给 -d→-0 改写（否则仅诊断不建议）
	if (isBsdXargsError(command, errorText)) return rewriteBsdXargsD(command);
	if (platformRule?.suggestion) return platformRule.suggestion;
	// ①' ev-20260910-bcb097（D）--prefix 前端工具链：命令带 --prefix 且错误特征指向 tsconfig/
	// 插件链按 cwd 解析 → 改写为 cd 进包目录。先于通用模块缺失路由：`Cannot find module…vite`
	// 同属其特征，但根因是 --prefix 不改 cwd，路径替换无济于事。
	if (isPrefixToolchainFailure(command, errorText)) return rewritePrefixToolchain(command);
	// ② 模块路径缺失：错误路径在命令中可定位且仓库内存在候选 → 命令内路径替换为候选绝对路径
	if (/MODULE_NOT_FOUND|Cannot find module/i.test(errorText)) {
		const missing = extractMissingModulePath(errorText);
		const cwd = opts.cwd;
		if (missing && cwd) {
			const candidate = findModulePathCandidate(missing, cwd, opts.repositoryRoot || cwd, opts.pathExists || fs.existsSync);
			if (candidate) {
				// 命令里按原书写形态替换（相对/绝对均可）；原书写形态不在命令里则按 basename 锚定 token
				const byLiteral = rewriteToken(command, missing, candidate);
				if (byLiteral) return byLiteral;
				const base = path.basename(missing);
				const tokenRe = new RegExp(`(?:^|[\\s'"=])((?:[./][^\\s'"]*|[^\\s'"]*)${base.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})(?=$|[\\s'"])`);
				const tm = command.match(tokenRe);
				if (tm?.[1] && !tm[1].includes(" ")) return command.split(tm[1]).join(candidate);
			}
		}
		return undefined;
	}
	// ③ 文件不存在（ENOENT）：shell 风格 `cmd: path: No such file or directory` 且候选存在 → 同样替换
	if (/No such file or directory/i.test(errorText) && !/MODULE_NOT_FOUND|Cannot find module/i.test(errorText)) {
		const cwd = opts.cwd;
		const missing = enoentMissingPath(errorText);
		if (missing && cwd && !/(?:^|[\\/])proc|^\/dev\//.test(missing)) {
			let candidate = findModulePathCandidate(missing, cwd, opts.repositoryRoot || cwd, opts.pathExists || fs.existsSync);
			const exists = opts.pathExists || fs.existsSync;
			// 补充：cwd 错位到子目录时（cat data.json 在 pkg/ 下跑，文件在仓根），从 cwd 祖先按原相对路径定位
			if (!candidate && !path.isAbsolute(missing)) {
				const root = opts.repositoryRoot || cwd;
				let dir = cwd;
				for (let i = 0; i < 6; i++) {
					const tryP = path.resolve(dir, missing);
					if (tryP !== path.resolve(cwd, missing) && isWithin(root, tryP)) {
						try { if (exists(tryP)) { candidate = tryP; break; } } catch {}
					}
					const parent = path.dirname(dir);
					if (parent === dir) break;
					dir = parent;
				}
			}
			// 历史成功 cwd 探测：相对路径在仓库内定位不到时，逐个历史 cwd resolve（跨仓会话实战）
			if (!candidate) candidate = probeHistoryCwds(missing, cwd, opts.historyCwds, exists)?.candidate;
			if (candidate) {
				const byLiteral = rewriteToken(command, missing, candidate);
				if (byLiteral) return byLiteral;
			}
		}
		return undefined;
	}
	return undefined;
}

/** 纯路由主体：0 command not found → 0.5 --prefix 前端工具链 → 1 MODULE_NOT_FOUND → 2 BSD cat/sed 平台差异 → 3 ESM/CJS → 4 HTTP pattern → 5 cwd 尾注 → 6 历史 cwd → 通用提示。 */
export function diagnoseBashFailure(options: BashDiagnosticOptions): string {
	const errorText = options.errorText || "";
	// ev-20260830-b70efc：command not found ——运行时语义错配最常见形态（Windows 工具名缺 .exe /
	// MSYS 路径风格）。软提示直接给 uname 探测命令；已知 WSL 运行时则附针对性修正建议。
	// runtime 可传懒探测函数，仅命中本分支才求值（生产为 memoized probe，零重复 fork）。
	if (isCommandNotFoundFailure(errorText)) {
		const rt = typeof options.runtime === "function" ? (() => { try { return options.runtime!(); } catch { return undefined; } })() : options.runtime;
		const probeCmd = "uname -srm && printf 'WSL_DISTRO_NAME=%s\\n' \"$WSL_DISTRO_NAME\"";
		const wslBits = rt?.probed && rt.wsl
			? ` 本机探测：bash 运行在 WSL${rt.distro ? `（${rt.distro}）` : ""}${rt.windowsExeOnPath === false ? "，PATH 无 Windows 目录" : ""}——Windows 工具需 .exe 全名（powershell.exe/pwsh.exe），无 Windows PATH 时用 /mnt/<盘>/.../xxx.exe 全路径（交互式工具尾部加 </dev/null）；改用 Linux 侧等价工具更稳。`
			: "";
		// ev-20261020-d56baa：工具链在用户级目录（如 pip --user 的 cmake/ctest）不在 PATH——指引项目级声明入口
		// （amagi.json shell.pathPrepend；bash/run_bg/子 Agent/自动基线测试同源注入），免逐命令手动 export。
		const toolchainBits = " 工具链在用户级目录时可在项目 amagi.json 声明 shell.pathPrepend（绝对路径数组；bash/run_bg/子 Agent 与自动基线测试同源注入），免逐命令 export。";
		return diagnosticText(`检测到命令未找到（127）。常见根因：命令拼写/大小写、未安装、或按另一运行时的语义书写（如 Windows 工具名缺 .exe、MSYS/Windows 路径风格）。先用 \`${probeCmd}\` 确认 bash 运行时再修正命令。${toolchainBits}${wslBits}`.trim());
	}
	// ev-20261027-b9953e：agent-browser 失败按输出特征分类（wait 超时/ref 失效/元素未命中）——根因在
	// UI 状态与元素名（与 cwd/路径无关），给「先 snapshot -i 核对真实 UI」的可行动建议，不做 cwd 猜测。
	const browserRule = matchBrowserFailureRule(options.command || "", errorText);
	if (browserRule) {
		if (browserRule.key !== "browser-element-mismatch") return diagnosticText(`检测到 ${browserRule.advice}`);
		// 只采工具原始输出，不能把此前追加的诊断当作候选证据。
		const rawOutput = errorText.split(BASH_DIAGNOSTIC_PREFIX, 1)[0] ?? "";
		const section = /\bNames seen:[ \t]*([^\r\n]*)/i.exec(rawOutput);
		const seen = section?.[1]?.trim() ?? "";
		const empty = /^(?:\[\]|\(none\)|none|""|'')$/i;
		const following = section && !seen ? rawOutput.slice(section.index + section[0].length).split(/\r?\n/).slice(1, 9) : [];
		const end = following.findIndex(line => line.trim() && !/^[ \t]/.test(line));
		const multiline = following.slice(0, end < 0 ? following.length : end).some(line => /^[ \t]+(?:["']([^"']+)["']|[-*][ \t]+\S)/.test(line));
		const candidates = (seen && !empty.test(seen)) || multiline
			? "原输出的 Names seen 段列出了候选。"
			: section && !seen
				? "未能解析 Names seen 候选，请核对原输出。"
				: "当前输出未提供候选。";
		return diagnosticText(`检测到 ${browserRule.advice}${candidates}先 \`agent-browser --session <id> snapshot -i\` 核对元素真实 role 与名称，按快照中的名称重试。`);
	}
	const annotatedCwd = extractBashCwd(errorText);
	const currentCwd = annotatedCwd || options.cwd;
	// ev-20261021-44e416：cwd 归因前提——路径解析失败证据 + 缺失路径非绝对（绝对路径不随 cwd 变化）。
	const missingForCwd = enoentMissingPath(errorText);
	const missingIsAbsolute = !!missingForCwd && path.isAbsolute(missingForCwd);
	const cwdRelevant = PATH_RESOLUTION_FAILURE_RE.test(errorText) && !missingIsAbsolute;
	const successfulCwd = cwdRelevant ? options.successfulCwd : undefined;
	// ev-20260922-d9655d：远端平台懒解析（显式 platform 优先，否则 runtime 探测 uname 推导）。
	// 仅 cat 规则命中才求值（probeBashRuntime 模块级缓存，首次后零开销）；宿主平台不作为远端平台。
	let platformResolved = false;
	let platformValue: string | undefined;
	const platformOf = (): string | undefined => {
		if (platformResolved) return platformValue;
		platformResolved = true;
		if (options.platform) { platformValue = options.platform; return platformValue; }
		const info = typeof options.runtime === "function" ? (() => { try { return options.runtime!(); } catch { return undefined; } })() : options.runtime;
		platformValue = shellPlatformOf(info);
		return platformValue;
	};
	// 历史 cwd 探测注记（ENOENT 相对路径）：文件在会话前段成功过的 cwd 下存在时附「同会话此前在 cwd=X 下成功…」
	const enoentHistoryNote = (() => {
		if (!/No such file or directory/i.test(errorText)) return "";
		const missing = enoentMissingPath(errorText);
		if (!missing || !currentCwd || /(?:^|[\\/])proc|^\/dev\//.test(missing)) return "";
		const hit = probeHistoryCwds(missing, currentCwd, options.historyCwds, options.pathExists || fs.existsSync);
		return hit ? ` 同会话此前在 cwd=${hit.historyCwd} 下成功，本次 cwd=${currentCwd}；文件在 ${hit.historyCwd} 下存在。` : "";
	})();
	const context = `${annotatedCwd ? ` 本次 cwd=${annotatedCwd}。` : ""}${cwdDiffText(currentCwd, successfulCwd)}${enoentHistoryNote}`;
	const missingModule = /MODULE_NOT_FOUND|Cannot find module/i.test(errorText) ? extractMissingModulePath(errorText) : undefined;
	const moduleInNodeModules = missingModule
		? /(?:^|[\\/])node_modules(?:[\\/]|$)/i.test(missingModule)
		: /Cannot find module[^\r\n]*node_modules/i.test(errorText);
	// P2：高置信场景直接给出可复制的建议命令（机械改写，不猜内容；平台口径与平台规则单源一致）
	const rewrite = suggestCommandRewrite(options.command || "", errorText, { cwd: currentCwd, repositoryRoot: options.repositoryRoot, pathExists: options.pathExists, historyCwds: options.historyCwds, platform: platformOf });
	const rewriteLine = rewrite ? ` 建议命令：\n  ${rewrite}` : "";
	// ev-20260910-bcb097（D）：--prefix 前端工具链防呆——先于通用模块路径路由（`Cannot find module…vite`
	// 同属其特征，但根因是 --prefix 不改变 cwd，路径替换/换 cwd 重跑无济于事）。
	if (options.command && isPrefixToolchainFailure(options.command, errorText)) {
		return diagnosticText(`检测到 --prefix 与前端工具链失败特征组合（TS5083/找不到 tsconfig/Failed to resolve import/@vitejs/plugin-/Cannot find module…vite）。--prefix 不改变工作目录——它只切换包管理器的安装/解析基准，vue-tsc/vite/vitest 仍按当前 cwd 解析 tsconfig 与 vite 插件链。改用 cd 进包目录后执行 npx（bash 传 cwd 参数更佳），或 npm --prefix <目录> run <script> 形态跑 package.json 脚本。${rewriteLine}${context}`.trim());
	}
	if (/MODULE_NOT_FOUND|Cannot find module/i.test(errorText) && !moduleInNodeModules) {
		const candidate = missingModule && currentCwd
			? findModulePathCandidate(missingModule, currentCwd, options.repositoryRoot || currentCwd, options.pathExists || fs.existsSync)
			: undefined;
		const suggestion = candidate ? ` 检测到仓库内现存候选，建议将错误路径修正为 ${candidate}。` : "";
		return diagnosticText(`检测到模块路径解析失败。相对路径以进程 cwd 解析；建议 bash 传 cwd 参数显式指定基准（可用 pwd 确认当前 cwd）。${suggestion}${rewriteLine}${context}`.trim());
	}
	// 8月迭代第四轮 + ev-20260922-d9655d（B1）：BSD cat/sed 平台规则经 matchBashFailureRule 结构化
	// 单源（真实可执行名 + 旗标/script 定位 + 平台注入）。高置信参数错误抑制 cwd 纠偏建议
	//（showCwdAdvice=false）——[cwd] 尾注仍由 bash-override 作为执行事实保留，不在此转成因果判断。
	const platformRule = matchBashFailureRule(options.command || "", errorText, { platform: platformOf });
	if (platformRule) {
		const ruleParts = [platformRule.cause];
		if (platformRule.readHint) ruleParts.push(`优先用 ${platformRule.readHint}（等价且免改写；本提示不会自动执行）。`);
		if (platformRule.suggestion) ruleParts.push(`建议命令：\n  ${platformRule.suggestion}`);
		return diagnosticText(`${ruleParts.join(" ")}${platformRule.showCwdAdvice ? context : ""}`.trim());
	}
	// ev-20260916-3324e4：macOS/BSD xargs 无 -d —— -0 建议必须同时要求上游 NUL 分隔，不能仅替换选项
	if (options.command && isBsdXargsError(options.command, errorText)) {
		return diagnosticText(`检测到 macOS/BSD xargs 不支持 -d 选项。改用 -0 时上游必须输出 NUL 分隔（find -print0 / grep -lZ / rg -0 / sort -z / printf '%s\\0'），仅替换选项无效；若上游已是 NUL 分隔，把 -d '<分隔符>' 换成 -0 即可，否则需先改写上游命令再接 -0。${rewriteLine}${context}`.trim());
	}
	if (/Cannot use import statement outside a module|require is not defined(?: in ES module scope)?|top[- ]level await|await is only valid in async functions and the top level bodies of modules/i.test(errorText)) {
		return diagnosticText(`检测到 ESM/CJS 执行冲突。项目 package.json type=module：临时脚本用 .mts 后缀 + 以仓库根为基准的绝对 import；tsx 跑诊断脚本时避免 CJS 顶层 require。${context}`.trim());
	}
	const excerpt = contractPatternExcerpt(errorText);
	if (excerpt) {
		return diagnosticText(`检测到 HTTP 4xx 响应中的契约 pattern，请按原文修正参数：\n${excerpt}${context}`.trim());
	}
	// ev-20260904 复盘 §5③：测试断言失败文案分流——vitest/jest/playwright/node:test 汇总与断言
	// 栈特征先于 cwd/改写类通用路由：这类失败根因在被测代码/用例期望，重跑命令或改 cwd/依赖无济于事，
	// 通用文案「核对项目说明与入口」与场景错配（2026-09-04 实战 4 次注入中 2 次错配）。
	const scriptFrame = scriptAssertionFrame(errorText);
	if (scriptFrame !== null) {
		return diagnosticText(`检测到脚本内 assert 断言失败（Python 最终异常为 AssertionError${scriptFrame ? `，断言位于 ${scriptFrame}` : ""}；无测试框架汇总，非测试框架用例）——多为脚本自写的检查（计数/路径清单/规范化比较等）不成立：先核对断言期望与真实现场是否一致（期望本身可能写错），再决定是否改业务代码；改 cwd 或原样重跑无济于事。`);
	}
	// ev-20261021-44e416：输出被重定向且结果几乎为空 → 失败详情在重定向文件里（退出码本身不指向 cwd）。
	const redirects = options.command ? redirectedOutputTargets(options.command, currentCwd) : [];
	if (redirects.length && failureOutputIsEmpty(errorText)) {
		return diagnosticText(`命令输出已重定向到 ${redirects.join("、")}，失败详情在该文件而非本结果——先读取它判断失败原因（如测试真实首败）；空结果与非零退出码本身不是 cwd/路径问题的证据。`);
	}
	if (isTestFailureText(errorText)) {
		return diagnosticText(`检测到测试断言失败特征（vitest/jest/playwright/node:test 汇总或断言栈）——按真实代码/用例缺陷处理：先读失败用例名与 expected/received 差异，定位被测代码或断言期望；改 cwd、依赖版本或重跑同一命令通常无济于事，请先修正代码或断言期望再重跑。`.trim());
	}
	// ev-20260924-bd1e06（P2）：git 顶层坐标换算——确定性事实判定（文件确实位于顶层坐标下），
	// 先于启发式候选（祖先后缀/历史 cwd）。git diff --name-only / git status --porcelain 输出
	// 仓库顶层相对路径，cwd 在子目录（或 worktree 子目录）时直接复用即 ENOENT。
	if (/No such file or directory/i.test(errorText) && !/MODULE_NOT_FOUND|Cannot find module/i.test(errorText)) {
		const gitTopInfo = resolveGitTopOption(options, currentCwd);
		const missingTop = enoentMissingPath(errorText);
		if (gitTopInfo && missingTop && currentCwd && !path.isAbsolute(missingTop) && !/(?:^|[\\/])proc|^\/dev\//.test(missingTop)) {
			const exists = options.pathExists || fs.existsSync;
			const atTop = path.resolve(gitTopInfo.toplevel, missingTop);
			const atCwd = path.resolve(currentCwd, missingTop);
			let topHas = false, cwdHas = false;
			try { topHas = exists(atTop); cwdHas = exists(atCwd); } catch { /* lint-exempt:存在性探测异常→按无坐标事实处理 */ topHas = false; }
			if (topHas && !cwdHas) {
				return diagnosticText(`路径 \`${missingTop}\` 是仓库顶层坐标（git 输出默认口径：git diff --name-only / git status --porcelain 等输出顶层相对路径）；当前 cwd 位于仓库子目录 \`${gitTopInfo.prefix}\`（顶层 ${gitTopInfo.toplevel}）。改用 \`${atTop}\`，或给 git 命令加 --relative 输出 cwd 相对路径。${context}`.trim());
			}
		}
	}
	if (missingIsAbsolute && PATH_RESOLUTION_FAILURE_RE.test(errorText)) {
		return diagnosticText(`缺失的是绝对路径 \`${missingForCwd}\`（不随 cwd 变化，改 cwd 无济于事）——核对该路径所在的树/目录是否正确（例如目标文件实际位于另一工作树或主树），或先 ls 其父目录确认真实文件名。${rewriteLine}`.trim());
	}
	if (annotatedCwd && cwdRelevant) {
		return diagnosticText(`错误尾注已明确本次 cwd=${annotatedCwd}；相对路径均以该目录解析，请先核对执行基准。${rewriteLine}${cwdDiffText(annotatedCwd, successfulCwd)}`.trim());
	}
	const historyDiff = cwdDiffText(currentCwd, successfulCwd);
	if (historyDiff) return diagnosticText(`${historyDiff.trim()}${rewriteLine}${enoentHistoryNote}`);
	if (rewrite) return diagnosticText(`检测到高置信修复路径：\n  ${rewrite}${enoentHistoryNote}`.trim());
	return GENERIC_BASH_DIAGNOSTIC;
}

function toolResultText(content: unknown): string {
	if (typeof content === "string") return content;
	if (!Array.isArray(content)) return "";
	return content.map((part) => {
		if (typeof part === "string") return part;
		if (part && typeof part === "object" && typeof (part as { text?: unknown }).text === "string") return (part as { text: string }).text;
		return "";
	}).filter(Boolean).join("\n");
}

// ev-20260922-1eea28（B2）：本地 effectiveBashCwd 已迁 git-discard-guard.ts（顶部 import；
// bash-override 执行边界同源解析，保证守卫预检与实际执行同一 cwd 口径）。

/** 8月迭代 F5：目标路径是否命中 AMAGI_PROTECTED_PATHS 硬边界（前缀匹配：目录保护其下全部文件）。命中返回阻断 reason，未命中 undefined。 */
export function assertProtectedPaths(targetRaw: string, cwd: string): string | undefined {
	if (!targetRaw) return undefined;
	const raw = process.env.AMAGI_PROTECTED_PATHS;
	if (!raw) return undefined;
	let list: unknown;
	try { list = JSON.parse(raw); } catch { return undefined; }
	if (!Array.isArray(list)) return undefined;
	const target = path.isAbsolute(targetRaw) ? targetRaw : path.resolve(cwd, targetRaw);
	for (const entry of list) {
		if (typeof entry !== "string" || !entry) continue;
		const bound = path.isAbsolute(entry) ? entry : path.resolve(cwd, entry);
		const rel = path.relative(bound, target);
		if (rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel))) {
			return `[任务边界] 目标在派发方保护路径内（${bound}）——本任务无权修改；如需变更请回报 Leader 由其处理。`;
		}
	}
	return undefined;
}

/** 8月迭代 C3：写入目标是否在 AMAGI_ALLOWED_PATHS 白名单内（前缀匹配：目录含其下全部文件，
 *  与 PROTECTED 同语义反向）。env 存在且目标 ∉ 清单 → 返回阻断 reason；env 不存在或目标在清单内 → undefined。
 *  与 AMAGI_PROTECTED_PATHS 同设时取交集：两个检查独立判定、都放行才放行。
 *  可观测：reason 含目标路径与清单条数（首 3 项预览，不打印全清单防噪）。 */
export function assertAllowedPaths(targetRaw: string, cwd: string): string | undefined {
	if (!targetRaw) return undefined;
	const raw = process.env.AMAGI_ALLOWED_PATHS;
	if (!raw) return undefined;
	let list: unknown;
	try { list = JSON.parse(raw); } catch { return undefined; }
	if (!Array.isArray(list)) return undefined;
	const target = path.isAbsolute(targetRaw) ? targetRaw : path.resolve(cwd, targetRaw);
	const entries = list.filter((e): e is string => typeof e === "string" && e.length > 0);
	// ev-20260914-9084ee：改用共享 matcher（path-match.ts）——plain「目录或精确文件」语义逐字兼容，
	// 新增 glob（如 data/cfg/gds_*.tres）与 prefix:（显式前缀）两种白名单形态，与派发端预检同源。
	if (matchPathAllowed(target, entries, cwd)) return undefined; // 在清单内 → 放行
	const preview = entries.slice(0, 3).join("、");
	return `[任务边界] 写入目标不在任务允许写入清单（allowedPaths）内：${target}（清单共 ${entries.length} 项${preview ? `，如：${preview}` : ""}）；若需写入共享/范围外文件，通过报告说明由 Leader 处理。`;
}

/** ev-20260902-772c7f：硬边界 terminate 升级阈值——同一 run 内前 2 次越界软阻断（子 Agent 可读
 * reason 自纠：改授权目录/内联执行/QUESTIONS 上报），第 3 次起 escalate terminate（防无限重试循环）。
 * 实战依据：两次边界终止均发生在 95% 完成后的验证阶段（stub server 落盘 /tmp、改 vitest 配置），
 * 一击必杀丢失当轮上下文，软阻断优先即可自愈。 */
export const BOUNDARY_ESCALATE_AT = 3;

/** 纯策略（可测）：AMAGI_BOUNDARY_TERMINATE × 累计命中次数 → 是否 terminate。
 *  - "1" = 每次命中立即 terminate（旧行为，严格逃生舱）
 *  - "0" = 永不 terminate（仅 block）
 *  - 未设（新默认）= 软阻断优先，累计第 BOUNDARY_ESCALATE_AT 次起升级 terminate */
export function boundaryTerminateDecision(mode: string | undefined, hits: number): boolean {
	if (mode === "1") return true;
	if (mode === "0") return false;
	return hits >= BOUNDARY_ESCALATE_AT;
}

// ev-20260914-fd863c（friction/P1）：探针类低风险目录特征——tests/、tmp/、沙箱等非源码目录内
// 的新建临时探针文件（实战：tests/_n28_probe.gd）不升级 terminate；修改既有白名单外文件/
// 白名单外新建源码/配置类文件仍维持 terminate 升级链（见 boundaryLowRiskNewFile）。
const PROBE_LIKE_DIR_RE = /(?:^|\/)(?:tests?|__tests__|tmp|temp|e2e|sandbox|scratch|fixtures?|probes?)(?=\/|$)/i;

/** ev-20260914-fd863c：白名单外新建文件的越界风险分级（纯策略，可测）。
 *  低风险 = 目标当前不存在（新建，非改写既有文件）且位于探针类目录（tests/tmp/沙箱等）。
 *  只对白名单（ALLOWED）越界生效；PROTECTED 黑名单命中不分级（保护用户未提交工作优先）。 */
export function boundaryLowRiskNewFile(targetRaw: string, cwd: string): boolean {
	if (!targetRaw) return false;
	const target = path.isAbsolute(targetRaw) ? targetRaw : path.resolve(cwd, targetRaw);
	try { if (fs.existsSync(target)) return false; } catch { return false; } // 既有文件（任何扩展名）→ 高风险
	const rel = path.relative(cwd, target);
	const norm = rel && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel) ? rel : target;
	return PROBE_LIKE_DIR_RE.test(norm.replaceAll("\\", "/"));
}

// ev-20260909-729b99（P3）：amagi-task/ 目录撞名消歧文案（供 session_start 提示与边界拦截 reason 共用）
export function taskTmpNameclashHint(tmpDir?: string, clashDir?: string): string {
	const tmp = tmpDir ?? process.env.AMAGI_TASK_TMP_DIR;
	const clash = clashDir ?? process.env.AMAGI_TASK_TMP_NAMECLASH;
	if (!tmp || !clash) return "";
	return `系统验证产物目录绝对路径是 ${tmp}；工作区内 amagi-task/（${clash}）是历史遗留同名目录、与系统验证目录无关——验收记录/验证脚本一律写前者，勿写入仓库。`;
}

/** 边界拦截 reason 的补充引导：软阻断时给自纠路径（含自动授权的验证产物目录，若有）。 */
export function boundaryBlockHint(terminate: boolean, hits: number, opts: { lowRiskProbe?: boolean } = {}): string {
	const parts: string[] = [];
	if (!terminate) {
		// ev-20260914-fd863c：低风险探针类越界不升级 terminate，引导改为「探针去向」替代指引
		parts.push(opts.lowRiskProbe
			? `（第 ${hits} 次越界拦截：已阻断写入但未终止运行——该目标是白名单外新建临时探针类文件（低风险），持续软阻断、不升级终止；临时探针请写系统 tmp 或任务沙箱 amagi-task/<runId>/（自动在白名单内），最终断言并入白名单内既有测试后重试）`
			: `（第 ${hits} 次越界拦截：已阻断写入但未终止运行——请改走任务白名单内路径或内联执行完成验证，或经 QUESTIONS 请 Leader 放行；累计第 ${BOUNDARY_ESCALATE_AT} 次起将终止运行）`);
	} else {
		parts.push(`（第 ${hits} 次越界：已达升级阈值，本轮终止——请 Leader 复核任务边界后重新派发或 resume）`);
	}
	const tmp = process.env.AMAGI_TASK_TMP_DIR;
	if (tmp) {
		parts.push(`本任务验证产物目录（已自动加入白名单）：${tmp}——stub server/验证脚本/截图等临时产物统一写这里后重试。`);
		// ev-20260909-729b99：撞名消歧追加
		const clash = taskTmpNameclashHint();
		if (clash) parts.push(clash);
	}
	return parts.join("");
}

// ═══ ev-20260905 视觉模型识图直读（主上裁定）：有视觉能力的模型禁止经技能/MCP 外派识图 ═══
// 实战：具备读图能力的模型仍习惯性走 amagi-media-understanding 技能或 zhipu-vision MCP
// 外派识图——绕远、慢、且丢一手视觉证据。与下方 registerGuards 内 ev-20260801-b7755a
//（无视觉模型拦 read 引导外派）互为镜像：model.input 含 "image" 时反向拦截外派通道。
// 边界：识视频（read 不支持视频）与 tiff 等图片格式 read 不支持的场景不受限仍可走技能；
// 逃生舱 env AMAGI_ALLOW_DELEGATED_VISION=1（可回滚）。以下均为纯函数，供守卫与测试直接断言。

/** pi read 工具可直接读取的图片扩展（与 ev-20260801-b7755a read 守卫同一集合；容忍 URL 查询串）。 */
const DIRECT_READ_IMAGE_EXT = /\.(png|jpe?g|gif|webp|bmp)([?#][^\s]*)?$/i;
/** 识图技能脚本支持、但 read 无法读取的视频扩展（识视频不属本守卫管辖）。 */
const DELEGATE_VIDEO_EXT = /\.(mp4|m4v|mov|webm|mkv|avi|mpg|mpeg|[23]gp)([?#][^\s]*)?$/i;
/** 识图/识视频委托技能特征 token（skill 目录与脚本同名；命令文本命中即视为委托调用）。 */
const MEDIA_DELEGATE_TOKEN = "amagi-media-understanding";

export interface MediaDelegateClassification {
	/** 调用意图：--list 优先 > --mode > 输入扩展推断 unknown。 */
	intent: "image" | "video" | "list" | "unknown";
	/** `--` 之后输入里存在 read 可直读的图片文件。 */
	hasDirectImage: boolean;
	/** `--` 之后输入里存在视频文件。 */
	hasVideo: boolean;
}

/** 解析 amagi-media-understanding 委托调用并分类（非委托命令返回 null）。 */
export function classifyMediaDelegateCommand(command: string): MediaDelegateClassification | null {
	if (!command || !command.includes(MEDIA_DELEGATE_TOKEN)) return null;
	const modeMatch = /--mode[= ]["']?(image|video)\b/i.exec(command);
	const dashDash = /\s--\s/.exec(command);
	const inputs = dashDash ? command.slice(dashDash.index + dashDash[0].length).split(/\s+/) : [];
	const stripped = (t: string) => t.replace(/^["']+|["']+$/g, "");
	return {
		intent: /(^|\s)--list\b/.test(command)
			? "list"
			: modeMatch
				? (modeMatch[1].toLowerCase() === "video" ? "video" : "image")
				: "unknown",
		hasDirectImage: inputs.some((t) => DIRECT_READ_IMAGE_EXT.test(stripped(t))),
		hasVideo: inputs.some((t) => DELEGATE_VIDEO_EXT.test(stripped(t))),
	};
}

/**
 * 视觉模型经识图技能识别「read 可直读图片」→ 返回阻断 reason；其余（识视频 / --list /
 * tiff 等特殊格式 / 非委托命令）返回 null 放行（视觉能力判定由调用方负责）。
 */
export function assertNoDelegatedImageRecognition(command: string): string | null {
	const c = classifyMediaDelegateCommand(command);
	if (!c) return null;
	if (c.intent === "list" || c.intent === "video") return null;
	if (c.intent === "unknown" && !(c.hasDirectImage && !c.hasVideo)) return null;
	return `[amagi 守卫] 当前模型具备读图能力（model.input 含 image）——本次调用已拦截，命令未执行。请直接用 read 工具读取图片路径（jpg/png/gif/webp/bmp 均支持附件直读），自行分析后作答；多图对比可多次 read。识视频与 read 不支持的格式（tiff 等）不受此限，仍可走技能；确需强制外派设 AMAGI_ALLOW_DELEGATED_VISION=1。`;
}

/** 已知视觉 MCP 工具（mcp-client VISION_REMOTE_TOOLS 的识图子集；analyze_video 属视频理解，模型无法直读故不拦）。 */
export const DELEGATED_IMAGE_MCP_TOOLS = new Set([
	"analyze_image",
	"ui_to_artifact",
	"ui_diff_check",
	"extract_text_from_screenshot",
	"diagnose_error_screenshot",
	"understand_technical_diagram",
	"analyze_data_visualization",
]);

/** mcp_call 是否为「识图外派」：视频理解放行；生成/检索/处理类图片工具（generate_image 等）不是识图外派，放行。 */
export function isDelegatedImageMcpCall(server: unknown, tool: unknown): boolean {
	const s = typeof server === "string" ? server : "";
	const t = typeof tool === "string" ? tool : "";
	if (!t) return false;
	if (/video/i.test(t)) return false;
	if (/(?:generat|create|draw|paint|render|search|fetch|download|upload|compress|convert|resize|crop|edit)/i.test(t)) return false;
	if (DELEGATED_IMAGE_MCP_TOOLS.has(t)) return true;
	if (/(?:analyz|understand|describ|recogni[sz]|ocr)\S*image|image\S*(?:analyz|understand|describ)|识图|看图|读图/i.test(t)) return true;
	return !!s && /vision/i.test(s);
}

// ═══ B6a（十月迭代 M3，设计 §7.2-5）：原生 MCP 工具与资源工具的 grant 复用检查（纯函数） ═══
// 混合模式下原生 mcp__* 工具经过宿主 tool_call 管线（docs/mcp.md §Permissions：扩展 tool_call
// 处理器含权限门），本节提供复用 amagi grant 的执法判定：逐次重验、拒绝先于 transport。
// 资源工具（list_mcp_resources / list_mcp_resource_templates / read_mcp_resource）单独守卫——
// 无 server 的全局 list 在存在未授权 server 时执行前拒绝（不能先列出再过滤敏感信息）。
// 接线：registerGuards 新增 options.mcpHybrid（B6b 启用混合时由 index.ts 接线注入；
// 缺省 undefined → 零行为变化，B6a 默认关闭语义）。

/** 宿主 MCP 资源工具名（docs/mcp.md §Use resources；资源工具标记只读）。 */
export const NATIVE_MCP_RESOURCE_TOOLS = new Set(["list_mcp_resources", "list_mcp_resource_templates", "read_mcp_resource"]);

/** 是否为原生 MCP 工具名（mcp__ 前缀；server/tool 允许大写——与守卫入口小写化无关，判定用原名）。 */
export function isNativeMcpToolName(toolName: string): boolean {
	return typeof toolName === "string" && toolName.startsWith("mcp__") && toolName.length > "mcp__".length + 2;
}

/** 原生 MCP 执法上下文；grant/路由始终生效，plan 仅补充 mixed 的 owner 分流。 */
export interface NativeMcpGuardContext {
	plan?: McpOwnershipPlan;
	/** 任务/会话冻结的 MCP 权限面（与 mcp_call 同源；undefined=legacy 无执法面，只做 owner 分流）。 */
	permission?: McpPermission;
	/** 宿主实际注册的 server 名（工具名含 hash/歧义分隔时必须提供元数据映射，不能字符串切分猜）。 */
	registeredServerNames?: readonly string[];
	/** 角色/Leader 的 server 路由；与工具授权求交，不替代 grant。 */
	onlyServers?: readonly string[];
	/** ev-20261019-a50ce4：路由拒绝的可行动说明（只读配置，不参与判定）。 */
	routeDenialHint?: (server: string) => string;
	/** 当前注册工具的性质，来自宿主 ToolInfo.annotations。 */
	natureOf?: (server: string, tool: string) => "read-only" | "unknown";
}

export interface NativeMcpGuardDecision {
	block: boolean;
	reason?: string;
}

/** server 级授权（资源面）：任一条目命中该 server（通配 server 或具体名）即视为资源可见主体。 */
function serverGrantedForResources(perm: McpPermission | undefined, server: string): boolean {
	if (!perm) return true; // legacy 无执法面（v1 行为；owner 分流仍生效）
	return perm.allow.some((e) => e.server === "*" || e.server.replace(/-/g, "_") === server.replace(/-/g, "_"));
}

/** 混合计划内 host-owner server 集合（资源全局 list 的未授权判定面）。 */
function hostOwnerServersOfPlan(plan: McpOwnershipPlan): string[] {
	return plan.mode === "mixed" ? plan.servers.filter((s) => s.owner === "host").map((s) => s.name) : [];
}

/**
 * 原生 MCP 工具/资源工具的 grant 复用判定（纯函数；拒绝先于 transport，零副作用）。
 * - mcp__* 工具：解析 server/tool（歧义且无注册表映射 → 拒绝，不猜）；amagi-owner server 的
 *   原生工具名不应存在（owner=amagi 在 native 侧 disabled），出现即拒绝并指引自研通道；
 *   host-owner → checkMcpCallPermission 逐次重验（与 mcp_call 同一执法面）。
 * - 资源工具：read/list 带 server → host-owner + server 级授权；无 server 全局 list →
 *   存在任一未授权 host-owner server 即执行前拒绝（不先列出再过滤）。
 */
export function nativeMcpGuardDecision(rawToolName: string, input: unknown, ctx: NativeMcpGuardContext): NativeMcpGuardDecision {
	const mixed = ctx.plan?.mode === "mixed" ? ctx.plan : undefined;
	if (!mixed && !ctx.permission && !ctx.onlyServers) return { block: false };
	const toolName = typeof rawToolName === "string" ? rawToolName : "";
	const args = (input && typeof input === "object" ? input : {}) as Record<string, unknown>;
	const canonical = (name: string) => name.replace(/-/g, "_");
	const routeAllows = (server: string) => !ctx.onlyServers || ctx.onlyServers.some((name) => name === "*" || canonical(name) === canonical(server));
	const denied = (reason: string): NativeMcpGuardDecision => ({ block: true, reason: `[amagi 守卫] 原生 MCP 权限拒绝：${reason}` });
	if ((isNativeMcpToolName(toolName) || NATIVE_MCP_RESOURCE_TOOLS.has(toolName)) && ctx.permission?.allow.length === 0) {
		return denied("冻结 grant.mcp 为空，调用在 transport 前被阻断。");
	}
	if (isNativeMcpToolName(toolName)) {
		const parts = parseNativeMcpToolName(toolName, { registeredServerNames: ctx.registeredServerNames });
		if (!parts) {
			return { block: true, reason: `[amagi 守卫] 原生 MCP 工具名 "${toolName}" 无法解析出 server/tool（含 hash 后缀或歧义分隔时，需要宿主注册元数据才能确定切分，不能靠字符串猜）——混合模式下按拒绝处理。` };
		}
		if (parts.ambiguous) {
			return { block: true, reason: `[amagi 守卫] 原生 MCP 工具名 "${toolName}" 含多个 __ 分隔段，server/tool 切分不唯一（需要宿主实际注册元数据才能确定）——暂按拒绝处理。` };
		}
		// 还原宿主 -/_ 归一前的 server 名；不把模型工具名当作权限清单的新标识。
		const server = ctx.registeredServerNames?.find((name) => canonical(name) === parts.server) ?? parts.server;
		if (!routeAllows(server)) return denied(`server "${server}" 未在当前角色/会话路由中。${ctx.routeDenialHint ? ctx.routeDenialHint(server) : ""}`);
		const owner = mixed ? ownerOfServerInPlan(mixed, server) : undefined;
		if (owner === "amagi") {
			return { block: true, reason: `[amagi 守卫] server "${parts.server}" 由自研通道拥有（owner=amagi）——原生工具面不应出现该 server 的工具；请改用 mcp_call({server:"${parts.server}", tool:"${parts.tool}", arguments:{…}})。` };
		}
		// grant 与 owner 独立：非 mixed 和计划外工具也必须检查；带 hash 的名称不能猜原名。
		if (ctx.permission && /_[0-9a-f]{8}$/.test(parts.tool)) return denied(`工具 "${toolName}" 含宿主 hash，缺少原始工具映射，不能猜测授权。`);
		const decision = checkMcpCallPermission(ctx.permission, server, parts.tool, ctx.natureOf);
		if (!decision.allowed) return denied(decision.reason ?? `工具 ${toolName} 未授权。`);
		return { block: false };
	}
	if (NATIVE_MCP_RESOURCE_TOOLS.has(toolName)) {
		const serverArg = typeof args.server === "string" && args.server.trim() !== "" ? args.server.trim() : undefined;
		const hostServers = [...new Set([...(ctx.registeredServerNames ?? []), ...(mixed ? hostOwnerServersOfPlan(mixed) : [])])];
		if (serverArg === undefined) {
			// 全局 list：存在未授权 host-owner server → 执行前拒绝（不能先列出再过滤敏感信息）
			if (toolName === "read_mcp_resource") {
				return { block: true, reason: `[amagi 守卫] read_mcp_resource 缺 server 参数——必须指定 server（资源读取逐 server 授权，不支持全局盲读）。` };
			}
			if (ctx.permission && hostServers.length === 0 && !ctx.permission.allow.some((e) => e.server === "*")) return denied("无法确认全局资源列表的 server 集合，请指定已授权的 server。");
			const unauthorized = hostServers.filter((s) => !routeAllows(s) || !serverGrantedForResources(ctx.permission, s));
			if (unauthorized.length > 0) {
				return { block: true, reason: `[amagi 守卫] ${toolName} 全局列举被拒：存在未授权 server（${unauthorized.join(", ")}）——先按 server 维度授权或指定 server 参数（不能先列出再过滤敏感信息）。` };
			}
			return { block: false };
		}
		if (!routeAllows(serverArg)) return denied(`资源 server "${serverArg}" 未在当前角色/会话路由中。${ctx.routeDenialHint ? ctx.routeDenialHint(serverArg) : ""}`);
		const owner = mixed ? ownerOfServerInPlan(mixed, serverArg) : undefined;
		if (owner === "amagi") {
			return { block: true, reason: `[amagi 守卫] 资源工具指定 server "${serverArg}" 由自研通道拥有（owner=amagi）——资源读取经 mcp_call 走该 server 的远端工具；原生资源工具仅覆盖 host-owner server。` };
		}
		if (!serverGrantedForResources(ctx.permission, serverArg)) {
			return { block: true, reason: `[amagi 守卫] 资源工具访问 server "${serverArg}" 未授权（资源面 server 级授权未命中）——先在任务授权名单声明该 server。` };
		}
		return { block: false };
	}
	return { block: false };
}

// ═══ ev-20260916-ead537（P0）：图片读取能力三态守卫 ═══
// 实战缺口：模型元数据 input 缺失时旧逻辑放行 read 图片——pi 上游可能默默剥除附件并在结果里
// 留 "(tool image omitted: …)"，模型未看到像素却可能声称已看图（证据诚信缺口）。三态：
// image-capable（原生 read）/ text-only（执行前阻断，文案补「未读取到像素」）/ unknown（元数据缺失
// 或非法——strict 默认也阻断，说「能力未确认」，不得断言模型一定不支持图片）。工具结果侧的 omitted
// 哨兵后处理见 tool_result 接线（pi 可能在扩展之后才生成该文本，后处理是补充，前置拦截是主修复）。
// 回滚：AMAGI_IMAGE_READ_GUARD=strict|legacy（默认 strict；非法值回 strict）。legacy 恢复「text-only
// 阻断、unknown 放行」旧行为；回滚不撤销「未看到不能声称已看」的文案约束。

export type ImageReadCapability = "image-capable" | "text-only" | "unknown";

/** 模型视觉能力三态判定（input 数组缺失/非数组 → unknown）。 */
export function imageReadCapability(model: unknown): ImageReadCapability {
	const inputs = Array.isArray((model as { input?: unknown } | undefined)?.input)
		? ((model as { input?: unknown[] }).input as unknown[])
		: undefined;
	if (!inputs) return "unknown";
	return inputs.map((v) => String(v)).includes("image") ? "image-capable" : "text-only";
}

/** AMAGI_IMAGE_READ_GUARD 解析：strict（默认）| legacy；非法值回安全默认 strict。 */
export function imageReadGuardPolicy(env: string | undefined = process.env.AMAGI_IMAGE_READ_GUARD): "strict" | "legacy" {
	const v = env?.trim().toLowerCase();
	return v === "legacy" ? "legacy" : "strict";
}

/** read 可直读图片扩展（与 ev-20260801-b7755a read 守卫同一集合）。 */
const READ_IMAGE_EXT_RE = /\.(png|jpe?g|gif|webp|bmp)$/i;

/** pi 上游剥图哨兵（工具结果形态；精确匹配，防普通正文 image/omitted 误判）。 */
const TOOL_IMAGE_OMITTED_SENTINEL = "(tool image omitted: model does not support images)";

/** 识图替代路线指引（text-only / unknown / omitted 后处理共用；不引导嵌套派发）。 */
function imageFallbackGuidance(): string {
	return "识图请按优先级依次尝试，不要跳级（前一级更稳定，先读技能清单确认再往下走）：① 首选 amagi-media-understanding 技能（可用技能清单中应含它——技能由 pi 自动加载供给清单，先读取该技能说明再按其 SKILL.md 指引调用，支持识图/识视频、多模型自动降级）；② 备用 zhipu-vision MCP（mcp_list_tools 查工具清单后经 mcp_call 调用，如 mcp_call({server:\"zhipu-vision\", tool:\"analyze_image\", arguments:{业务字段}})；同类视觉工具 ui_diff_check / extract_text_from_screenshot 等）。都失败时原样上报，不要编造图像内容。";
}

// ev-20260903-c1521b① + ev-20260916-a7eee1：stash 软提示一次性（session 生命周期）。
// a7eee1 修复两组误报：① grep/sed/awk/echo 的字面文本含 "git stash" 不是 stash 操作；② git stash
// list/show 只读不弹提示。真实可执行 git 段经 parseGitInvocations+resolveGitCommand 解析（alias 可达，
// sh -c/bash -c 包裹经 shellWrapperPayloads 展开）；无子命令（新增 stash）与 push/pop/apply/drop/
// clear/store/save/branch/create 保留风险提示，文案沿用。生命周期自「模块进程终生一次」改为
// session_start 重置（长驻会话换任务后仍可再提示）。回滚：AMAGI_STASH_HINT_PARSE=legacy 回旧正则匹配。
// ev-20260917-589972：STASH_RISKY_SUBCOMMANDS/stashRiskOperation 实现已迁 git-discard-guard.ts
//（与子 Agent stash 硬拦截门同模块；本文件头部 re-export 维持外部导入路径不变）。
const stashNoteState = { sent: false };

/** 仅供测试复位 stash 一次性提示标志（生产代码不调用）。 */
export function resetStashNoteForTest(): void {
	stashNoteState.sent = false;
}

// ═══ ev-20260916-cfb0b5：异源暂存弱归因警示（部分做：只做弱归因告警，不做 stage-partial/hunk 封装） ═══
// 共享 index 的多源会话里，commit 可能把「会话开始前就已暂存的他人改动」一并提交。本提示在 commit
// 前计算 currentStaged − sessionTouched（同命令 git add 计划并入 currentStaged，但 add 不是创作归属
// 证据，不能把 add 过的文件全算本会话产物）；baseline staged 中仍存在的路径即使本会话触碰过，也保留
// 「会话前已有暂存内容，须审阅 diff」提示（路径级检查分不清混合 hunk 的作者）。缺少可靠写入登记时
// 一律降级为「来源未确认」——不说「属于别人」；不阻断、不自动 unstage、不修改用户 index。
// 相同 index 指纹去重，index 变化重新提示。回滚：AMAGI_STAGED_ORIGIN_HINT=0/false/off 关闭。

export function stagedOriginHintEnabled(env: string | undefined = process.env.AMAGI_STAGED_ORIGIN_HINT): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

interface StagedOriginState {
	/** repoRoot → 会话首次观测时的 staged 基线（null = 基线探测失败，降级为不可判）。 */
	baselines: Map<string, Set<string> | null>;
	/** 本会话确认成功写入的绝对路径（write/edit 成功 + bash 高置信写目标；FIFO 有界）。 */
	touched: Map<string, true>;
	/** 已提示过的 index 指纹。 */
	notified: Set<string>;
	/** ev-20261005-01c6f2：已警示过的路径（workTree\0relPath）——同路径只警示一次，后续 commit
	 *  只对新增路径发警示；merge/收口流中同批文件反复 add/commit 不再重复轰炸（实战各 4 次）。 */
	warnedPaths: Set<string>;
}

const STAGED_TOUCHED_MAX = 2048;

export function newStagedOriginState(): StagedOriginState {
	return { baselines: new Map(), touched: new Map(), notified: new Set(), warnedPaths: new Set() };
}

function recordSessionTouchedPath(state: StagedOriginState, absPath: string): void {
	if (!absPath) return;
	if (state.touched.has(absPath)) return;
	if (state.touched.size >= STAGED_TOUCHED_MAX) {
		const oldest = state.touched.keys().next().value;
		if (oldest !== undefined) state.touched.delete(oldest);
	}
	state.touched.set(absPath, true);
}

/** ev-20261108-e91768：本会话已派发子任务的写面登记（readTaskWrites，子进程成功写盘即时登记）并入「已知来源」——
 *  Leader 提交已接受子任务的产物时，这些路径不再被报「来源未确认」（它们有回执级写证据）。任务在本仓库
 *  工作树内写入 → 直接取相对路径；任务在独立 worktree（cwd 不在本树内）写入 → 取相对其 cwd 的路径
 *  （合并回主树的同名相对路径同样有来源）。有界：最近 64 个任务、每任务登记 ≤512 行（写入侧既有上限）。
 *  只认真实登记，不把 allowedPaths 声明当写证据；registry 不可用静默降级为空集。
 *  e91768-r2（diting m5）：归因收紧到「与当前 workTree 同一仓库」——①登记绝对路径落在
 *  workTree（含 realpath）内照旧直取；②回退「相对任务 cwd」仅当任务 cwd 与 workTree 同一
 *  仓库（git rev-parse --git-common-dir 两边一致，探测失败不回退），跨仓库任务写的同名相对
 *  路径不再被静默吞掉「来源未确认」警示；③cancelled/error 终态任务（产物未被接受，TaskStatus
 *  枚举无 rejected——验收轴不在 registry）不算「已知来源」。 */
const TASK_REGISTERED_SCAN_MAX = 64;
function taskRegisteredRelativePaths(workTree: string): Set<string> {
	const out = new Set<string>();
	try {
		const roots = new Set([path.resolve(workTree)]);
		try { roots.add(fs.realpathSync(workTree)); } catch { /* lint-exempt:realpath 失败用 resolve */ }
		// e91768-r3（diting m-b）：路径形态归一——登记/任务 cwd 可能是字面形态（/var/...）而 workTree
		// 是 realpath 形态（/private/var/...，git rev-parse --show-toplevel 的返回）；目录被删时 realpath
		// 失败，用父目录 realpath 拼回尾段对齐两种形态（纯路径判断，不受 worktree 已删影响）。
		const pathForms = (p: string): string[] => {
			const forms = new Set([path.resolve(p)]);
			try { forms.add(fs.realpathSync(p)); } catch { /* lint-exempt:目录已删无 realpath，用父目录 realpath 拼回尾段 */
				try { forms.add(path.join(fs.realpathSync(path.dirname(p)), path.basename(p))); } catch { /* lint-exempt:父目录也不存在时仅字面形态 */ }
			}
			return [...forms];
		};
		// m-b②：worktree.ts 约定位置（<workTree>/.amagi-worktrees/<name>）的路径前缀证据——任务 cwd
		// 落在内即视为同仓库（git 探测在 worktree 被删后失败，纯路径判断不受影响）。
		const underWorktreesConvention = (p: string): boolean => {
			for (const pForm of pathForms(p)) {
				for (const base of roots) {
					if (pForm === base || pForm.startsWith(`${base}${path.sep}`)) {
						const relToBase = path.relative(base, pForm);
						if (relToBase === ".amagi-worktrees" || relToBase.startsWith(`.amagi-worktrees${path.sep}`)) return true;
					}
				}
			}
			return false;
		};
		const records = [...taskRegistry.list()].sort((a, b) => (b.startedAt ?? 0) - (a.startedAt ?? 0)).slice(0, TASK_REGISTERED_SCAN_MAX);
		const shareCache = new Map<string, boolean>();
		const toRel = (base: string, abs: string): string | null => {
			const rel = path.relative(base, abs);
			return rel && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel) ? rel.replaceAll("\\", "/") : null;
		};
		for (const rec of records) {
			if (rec.status === "cancelled" || rec.status === "error") continue; // r2：未接受产物不作来源
			const taskCwd = rec.cwd ? path.resolve(rec.cwd) : null;
			for (const w of readTaskWrites(rec.taskId)) {
				const abs = path.resolve(w.file);
				let rel: string | null = null;
				for (const absForm of pathForms(abs)) { for (const base of roots) { rel = toRel(base, absForm); if (rel) break; } if (rel) break; }
				// m-b①：登记绝对路径落在 workTree 内但 rel 以 .amagi-worktrees/ 开头（worktree.ts 约定
				// 位置）——登记其实是任务 worktree 内路径，按任务 cwd 重算（合并回主树的同名相对路径才
				// 有来源；旧逻辑取到 .amagi-worktrees/<name>/src/x.ts 非空 rel 后不回退，豁免从未生效）。
				if (rel && rel !== ".." && rel.startsWith(".amagi-worktrees/") && taskCwd) {
					rel = toRel(taskCwd, abs) ?? rel;
				}
				// m-b②：任务 cwd 不在 workTree 内的回退需同仓库证明——约定位置用路径前缀证据（worktree
				// 被删后 git 探测失败，不再误报），其余仍走 git 探测，探测失败保守不回退（维持警示）。
				if (!rel && taskCwd && (underWorktreesConvention(taskCwd) || taskCwdSharesRepository(taskCwd, workTree, shareCache))) rel = toRel(taskCwd, abs);
				if (rel) out.add(rel);
			}
		}
	} catch { /* lint-exempt:registry/登记读取失败按无登记处理（保守：维持旧警示口径） */ }
	return out;
}

/** e91768-r2（diting m5）：taskCwd 与 workTree 是否同一 git 仓库——各自 `git rev-parse
 *  --git-common-dir` 探测（相对输出按探测 cwd 归一后 realpath；主仓与各 linked worktree 的
 *  common dir 同指主仓 .git，故同仓库 worktree 仍豁免）。有界 gitOutput（execFileSync，10s
 *  超时）；探测失败按不同仓库处理（保守：不回退相对路径，维持警示口径）。按 (taskCwd,
 *  workTree) 缓存，单次扫描内同 cwd 任务不重复探测。 */
function taskCwdSharesRepository(taskCwd: string, workTree: string, cache: Map<string, boolean>): boolean {
	const key = `${taskCwd}\0${workTree}`;
	const cached = cache.get(key);
	if (cached !== undefined) return cached;
	const commonDir = (cwd: string): string | null => {
		const raw = gitOutput({ cwd, globalOptions: [], subcommand: "rev-parse", args: [], segmentIndex: 0 }, ["rev-parse", "--git-common-dir"]);
		if (!raw) return null;
		const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
		try { return fs.realpathSync(abs); } catch { /* lint-exempt:realpath 失败用 resolve 结果比较 */ return abs; }
	};
	const shared = (() => {
		const mine = commonDir(taskCwd);
		return mine !== null && mine === commonDir(workTree);
	})();
	cache.set(key, shared);
	return shared;
}

/** 会话写入绝对路径统一为仓库相对路径，兼容macOS /var与/private/var。 */
function sessionTouchedRelativePaths(state: StagedOriginState, workTree: string): Set<string> {
	const touchedRel = new Set<string>();
	const rootBases = new Set([path.resolve(workTree)]);
	try { rootBases.add(fs.realpathSync(workTree)); } catch { /* realpath失败用resolve */ }
	for (const abs of state.touched.keys()) {
		let absReal = path.resolve(abs);
		try { absReal = fs.realpathSync(abs); } catch { /* 已移动/删除保持resolve */ }
		for (const base of rootBases) {
			const rel = path.relative(base, absReal);
			if (rel && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel)) { touchedRel.add(rel.replaceAll("\\", "/")); break; }
		}
	}
	for (const rel of taskRegisteredRelativePaths(workTree)) touchedRel.add(rel);
	return touchedRel;
}

/** NUL 分隔 name-only 输出 → 路径集合（null = 探测失败）。 */
function stagedPathSet(raw: string | null): Set<string> | null {
	if (raw === null) return null;
	return new Set(raw.split("\0").filter(Boolean));
}

/** diting 审核 Major-1：session_start 时为 cwd 所在仓库采集 staged 基线。
 *  原实现仅在首次 commit 评估时懒采集（stagedOriginWarning 内）——本会话 write + 单独真实
 *  `git add` 的常态工作流会被 baseline 吞掉产生「会话开始前已暂存」误报；提前到 session_start
 *  后，会话内 add 的文件不入基线。探测失败（非 repo/无 git）保持空映射，首次 commit 懒采集
 *  兜底（会话中途 cd 进 repo 的场景，懒采集窗口仍在，主路径已修复）。 */
export function primeStagedOriginBaseline(cwd: string | undefined, state: StagedOriginState): void {
	if (!stagedOriginHintEnabled() || !cwd) return;
	// diting F-10：session_start 复位路径级去重集（换会话后同批文件首警重现——去重是会话内语义）
	state.warnedPaths.clear();
	const probe: GitInvocation = { cwd, globalOptions: [], subcommand: "rev-parse", args: [], segmentIndex: 0 };
	const root = gitOutput(probe, ["rev-parse", "--show-toplevel"]);
	if (!root) return;
	state.baselines.set(root, stagedPathSet(gitOutputRaw({ ...probe, cwd: root }, ["diff", "--cached", "--name-only", "-z"])));
}

/** ev-20260924-ecd3d2：有界展示——≤阈值逐路径列出；超阈值按顶层目录分组（目录（计数）+ 前 3
 *  示例），完整清单指向 git 命令（旧版截前 20 条只是节流，不解决“本不该出现”与长尾藏进「等 N 项」）。 */
const STAGED_FOLD_THRESHOLD = 20;
function foldStagedList(paths: string[], listCmd = "git diff --cached --name-only"): string {
	if (paths.length <= STAGED_FOLD_THRESHOLD) return paths.join("、");
	const byDir = new Map<string, number>();
	for (const p of paths) {
		const slash = p.indexOf("/");
		const dir = slash > 0 ? p.slice(0, slash) : "(顶层)";
		byDir.set(dir, (byDir.get(dir) ?? 0) + 1);
	}
	const groups = [...byDir.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
	const groupText = groups.slice(0, 8).map(([d, n]) => `${d}(${n})`).join("、") + (groups.length > 8 ? " 等" : "");
	return `${paths.length} 项（按顶层目录：${groupText}；示例：${paths.slice(0, 3).join("、")}；完整清单：${listCmd}）`;
}

/** ev-20260924-ecd3d2：进行中的 merge/cherry-pick/revert 归因——读 git dir 下的 HEAD 标记文件
 *  （worktree 下 git dir 不在仓库根，经 rev-parse --git-dir 解析）。实战：merge 137 文件被全量
 *  列为「来源未确认」——它们是该操作引入的，并非来源不明。 */
function inProgressGitOperation(invocation: GitInvocation): "merge" | "cherry-pick" | "revert" | null {
	const gitDir = gitOutput(invocation, ["rev-parse", "--git-dir"]);
	if (!gitDir) return null;
	const abs = path.isAbsolute(gitDir) ? gitDir : path.resolve(invocation.cwd, gitDir);
	try {
		if (fs.existsSync(path.join(abs, "MERGE_HEAD"))) return "merge";
		if (fs.existsSync(path.join(abs, "CHERRY_PICK_HEAD"))) return "cherry-pick";
		if (fs.existsSync(path.join(abs, "REVERT_HEAD"))) return "revert";
	} catch { /* lint-exempt:探测失败按无操作处理（保守：不归因，维持旧口径） */ }
	return null;
}

/** ev-20260924-ecd3d2（diting F1 修复）：操作实际引入的路径集（求交归因用）。
 *  merge = merge-base..MERGE_HEAD 的变更路径（合并真正带进来的内容）；cherry-pick/revert =
 *  被操作提交自身的变更路径（revert 引入的是其逆变更，文件集相同）。探测失败 → null：
 *  归因是「能够证明」的断言，拿不到路径集就不归因（suspicious 照旧警示——来源未确认属实）。 */
function operationIntroducedPaths(invocation: GitInvocation, op: "merge" | "cherry-pick" | "revert"): Set<string> | null {
	try {
		if (op === "merge") {
			const base = gitOutput(invocation, ["merge-base", "HEAD", "MERGE_HEAD"]);
			if (!base) return null;
			return stagedPathSet(gitOutputRaw(invocation, ["diff", "--name-only", "-z", base.trim(), "MERGE_HEAD"]));
		}
		const marker = op === "cherry-pick" ? "CHERRY_PICK_HEAD" : "REVERT_HEAD";
		return stagedPathSet(gitOutputRaw(invocation, ["diff", "--name-only", "-z", `${marker}^`, marker]));
	} catch { /* lint-exempt:路径集不可得→不归因（suspicious 保留警示） */ return null; }
}

/** ev-20261021-5c5f14：异源暂存发现（执行前采集的事实）。措辞与只读审阅命令取决于执行结果——
 *  commit 成功后 index 已清空，`git diff --cached` 不再能审阅该次提交——故发现与渲染分离：
 *  tool_call 采集（commit 前 index 才是真相），tool_result 按 HEAD 是否前移选择时态与命令。 */
export interface StagedOriginFindings {
	workTree: string;
	/** git 命令执行目录（结果期复查 HEAD 用）。 */
	gitCwd: string;
	/** 执行前 HEAD（unborn 仓库为 null）。 */
	headBefore: string | null;
	op: "merge" | "cherry-pick" | "revert" | null;
	opIntroduced: string[];
	suspicious: string[];
	preExisting: string[];
	/** 结果期以实际路径重新关联写入归属；不把add计划当作已提交事实。 */
	provenance?: { touched: string[]; baseline: string[]; operationPaths: string[] };
	gitGlobalOptions?: string[];
	/** ev-20261108-e91768 期望②：触发命令摘要（≤40 字）——警示经结果期/后续轮投递时可能与最新
	 *  HEAD/index 事实错位（实战：add 失败轮的提示延后一轮被当作当前事实），摘要作「针对哪条命令」
	 *  的对照锚点，不断言因果。 */
	triggerCmd?: string;
}

/** 执行结果：committed=执行后 HEAD 已前移（值为新提交 sha）；null=未产生新提交。 */
export interface StagedOriginOutcome {
	committed: string | null;
	/** 有提交时为该真实提交的路径，无提交时为当前index；null/缺席=没有核实路径事实。 */
	paths?: string[] | null;
}

/** ev-20261108-e91768 期望②：触发命令摘要（含括号总长 ≤40 字）——只作「针对哪条命令」的
 *  对照锚点，不参与任何判定。e91768-r2（diting m6）：摘要不再携带任何参数值——原「空白折叠
 *  后截 32 字」会把 `token=…`/`user:pw@`/heredoc 提交信息原文带进 amagi:guard-note（会话持久化/
 *  steer 投递面）；改为只保留结构骨架：每个 git 调用 = git 子命令词（resolveGitCommand 解析，
 *  alias 可达）+ 至多前两个以 - 开头的 flag 名（去掉 =值；-m 之后的值不带；位参/更多 flag/
 *  flag 值一律省略为 …），调用间以链操作符（&&/||/;/管道 |）连接；解析不出 git 调用退化为
 *  「git …」骨架。超长仍截断加 …（截断不产生半截 flag 名以外的新信息）。 */
const TRIGGER_SUMMARY_MAX = 40;
function summarizeGitInvocation(invocation: GitInvocation): string {
	const { subcommand, args } = resolveGitCommand(invocation);
	const flags: string[] = [];
	let omitted = false;
	for (const w of args) {
		if (w === "--") { omitted = true; break; }
		if (!w.startsWith("-") || flags.length >= 2) { omitted = true; continue; }
		// e73f44-r3（diting m-c）：单横线短 flag 只保留前 2 字符（-m/-a）——第 3 字符起可能是粘连值
		//（-mSECRET/-SSECRET/-amV 形态曾把值原样带进摘要）；双横线长 flag 保留 flag 名去 =值（现状）。
		if (w.startsWith("--")) {
			const eq = w.indexOf("=");
			if (eq > 0) { omitted = true; flags.push(w.slice(0, eq)); } else flags.push(w);
			continue;
		}
		if (w.length > 2) omitted = true;
		flags.push(w.slice(0, 2));
	}
	return `git ${subcommand}${flags.length ? ` ${flags.join(" ")}` : ""}${omitted ? " …" : ""}`;
}

function triggerCommandSummary(command: string, cwd: string): string {
	const invocations = parseGitInvocations(command, cwd);
	let inner: string;
	if (!invocations.length) inner = "git …";
	else {
		// 链操作符锚定：shellChainOperators[i] 是第 i 条链的前置操作符（""=首链/空链）；同链相邻
		// git 段以 | 连接。两套切分同一 tokenizer、段集一致（e73f44 注释同款口径）。
		const ops = shellChainOperators(command);
		const chains = shellPipelineChains(command);
		const chainOf = new Map<number, number>();
		let seg = 0;
		chains.forEach((chain, ci) => chain.forEach(() => chainOf.set(seg++, ci)));
		const parts: string[] = [];
		let lastChain = -1;
		for (const invocation of invocations) {
			const ci = chainOf.get(invocation.segmentIndex) ?? -1;
			const op = parts.length && ci >= 0 && ci === lastChain ? "|" : ops[ci] === "&&" || ops[ci] === "||" ? ops[ci] : ";";
			if (parts.length) parts.push(` ${op} `);
			parts.push(summarizeGitInvocation(invocation));
			lastChain = ci;
		}
		inner = parts.join("");
	}
	const cap = TRIGGER_SUMMARY_MAX - "（针对：）".length; // 包装括号在渲染层（renderStagedOriginWarning）
	return inner.length <= cap ? inner : `${inner.slice(0, cap - 1)}…`;
}

/** commit 前采集异源暂存发现；无警示/仓库不可定位/开关关闭返回 null（同时登记去重状态）。 */
export function stagedOriginFindings(command: string, cwd: string, state: StagedOriginState, deferUntilResult = false): StagedOriginFindings | null {
	if (!stagedOriginHintEnabled()) return null;
	const addPlan = new Set<string>(); // 同命令 git add 计划集（add 非归属证据，只并入 currentStaged）
	for (const invocation of parseGitInvocations(command, cwd)) {
		const resolved = resolveGitCommand(invocation);
		if (resolved.subcommand === "add") {
			if (invocation.cwdUncertain) continue;
			const plan = gitPathspecPlan(invocation, "add", resolved.args);
			const files = gitFileSet(invocation, plan);
			if (plan.uncertain || files === null) continue;
			for (const file of files) addPlan.add(file);
			continue;
		}
		if (resolved.subcommand !== "commit") continue;
		if (invocation.cwdUncertain) continue;
		const workTree = gitOutput(invocation, ["rev-parse", "--show-toplevel"]);
		if (!workTree) continue;
		if (!state.baselines.has(workTree)) {
			state.baselines.set(workTree, stagedPathSet(gitOutputRaw(invocation, ["diff", "--cached", "--name-only", "-z"])));
		}
		const currentStaged = stagedPathSet(gitOutputRaw(invocation, ["diff", "--cached", "--name-only", "-z"]));
		if (!currentStaged) continue;
		for (const file of addPlan) currentStaged.add(file);
		const touchedRel = sessionTouchedRelativePaths(state, workTree);
		const baseline = state.baselines.get(workTree) ?? null;
		// ev-20260924-ecd3d2（P2）：分段互斥——preExisting（会话前已暂存）单独成段，suspicious
		// 排除 baseline（旧定义两集合重叠：同一路径在「来源未确认」与「会话前已暂存」各出现一次）。
		let preExisting = baseline ? [...currentStaged].filter((p) => baseline.has(p)).sort() : [];
		let suspicious: string[] = [...currentStaged].filter((p) => !touchedRel.has(p) && !(baseline?.has(p) ?? false)).sort();
		// 操作归因（diting F1 修复：按操作实际引入路径集求交，非在场即全量）：merge/cherry-pick/
		// revert 进行中时，suspicious 中属于该操作引入的路径归因该操作（一行摘要，不再列为可疑）；
		// 交外路径（并行进程 stage / 手动 add 的无关异源文件）保留「来源未确认」警示。
		const op = inProgressGitOperation(invocation);
		let opIntroduced: string[] = [];
		let opPaths: Set<string> | null = null;
		if (op) {
			opPaths = operationIntroducedPaths(invocation, op);
			if (opPaths) {
				const introduced = opPaths;
				opIntroduced = suspicious.filter((p) => introduced.has(p));
				suspicious = suspicious.filter((p) => !introduced.has(p));
			}
		}
		if (deferUntilResult) {
			// 即使执行前没有候选，也保存来源快照：同命令生成/暂存的新文件只在结果期可见。
			return { workTree, gitCwd: invocation.cwd, gitGlobalOptions: invocation.globalOptions,
				headBefore: gitOutput(invocation, ["rev-parse", "--verify", "-q", "HEAD"]) || null,
				op, opIntroduced, suspicious, preExisting, triggerCmd: triggerCommandSummary(command, cwd),
				provenance: { touched: [...touchedRel], baseline: [...(baseline ?? [])], operationPaths: [...(opPaths ?? [])] } };
		}
		if (!suspicious.length && !preExisting.length && !opIntroduced.length) continue;
		// index 指纹（staged 集合 + numstat 内容摘要）去重；index 变化重新提示
		const numstat = gitOutput(invocation, ["diff", "--cached", "--numstat", "-z"]);
		const fingerprint = `${workTree}\0${[...currentStaged].sort().join("\n")}\0${numstat ?? ""}`;
		if (state.notified.has(fingerprint)) continue;
		state.notified.add(fingerprint);
		// ev-20261005-01c6f2：路径级累积去重（保留首建告警）——指纹只对「index 完全未变」去重，
		// merge/commit 收口流中逐批 add 使指纹每次都变，同批路径反复重发（实战 4 次）。改为：
		// 三段均只列「本次新出现」的路径；全部已警示过 → 整体不重发（新异源路径首次出现必警示）。
		const warnedKey = (p: string): string => `${workTree}\0${p}`;
		const freshOf = (paths: string[]): string[] => paths.filter((p) => !state.warnedPaths.has(warnedKey(p)));
		const suspiciousFresh = freshOf(suspicious);
		const preExistingFresh = freshOf(preExisting);
		const opIntroducedFresh = freshOf(opIntroduced);
		if (!suspiciousFresh.length && !preExistingFresh.length && !opIntroducedFresh.length) continue;
		for (const p of [...suspiciousFresh, ...preExistingFresh, ...opIntroducedFresh]) {
			// diting F-10：有界（FIFO 4096——warnedPaths 无增长上限的内存纪律；路径数远小于常规会话规模）
			if (state.warnedPaths.size >= 4096) {
				const first = state.warnedPaths.values().next().value;
				if (first !== undefined) state.warnedPaths.delete(first);
			}
			state.warnedPaths.add(warnedKey(p));
		}
		suspicious = suspiciousFresh;
		preExisting = preExistingFresh;
		opIntroduced = opIntroducedFresh;
		return { workTree, gitCwd: invocation.cwd, headBefore: gitOutput(invocation, ["rev-parse", "--verify", "-q", "HEAD"])?.trim() || null, op, opIntroduced, suspicious, preExisting, triggerCmd: triggerCommandSummary(command, cwd) };
	}
	return null;
}

/** 结果期判定：HEAD 相对执行前前移即视为已提交（与 isError 无关——commit 成功后链上后续段失败仍已提交）。 */
export function resolveStagedOriginOutcome(findings: StagedOriginFindings): StagedOriginOutcome {
	const invocation: GitInvocation = { cwd: findings.gitCwd, globalOptions: findings.gitGlobalOptions ?? [], subcommand: "rev-parse", args: [], segmentIndex: 0 };
	const head = gitOutput(invocation, ["rev-parse", "--verify", "-q", "HEAD"]);
	const committed = head && head !== findings.headBefore ? head : null;
	const firstParent = committed ? gitOutput(invocation, ["rev-parse", "--verify", "-q", `${committed}^1`]) : null;
	// -z保留路径原字节（空格/换行）；root提交和merge首父变更也从真实提交树读取。
	const paths = stagedPathSet(gitOutputRaw(invocation, committed
		? ["diff-tree", "--root", "--no-commit-id", "--name-only", "--no-renames", "-r", "-z", ...(firstParent ? [firstParent, committed] : [committed])]
		: ["diff", "--cached", "--name-only", "-z"]));
	return { committed, paths: paths ? [...paths] : null };
}

/** 执行后从真实路径重建分类，而不是将执行前add候选换个时态就断言已提交。 */
function resultStagedOriginFindings(f: StagedOriginFindings, outcome?: StagedOriginOutcome): StagedOriginFindings {
	if (!Array.isArray(outcome?.paths)) return f;
	const actual = new Set(outcome.paths);
	if (!f.provenance) return { ...f, suspicious: f.suspicious.filter(p => actual.has(p)),
		preExisting: f.preExisting.filter(p => actual.has(p)), opIntroduced: f.opIntroduced.filter(p => actual.has(p)) };
	const baseline = new Set(f.provenance.baseline);
	const touched = new Set(f.provenance.touched);
	const introduced = new Set(f.provenance.operationPaths);
	const unknown = [...actual].filter(p => !baseline.has(p) && !touched.has(p));
	return { ...f, provenance: undefined,
		preExisting: [...actual].filter(p => baseline.has(p)).sort(),
		opIntroduced: unknown.filter(p => introduced.has(p)).sort(),
		suspicious: unknown.filter(p => !introduced.has(p)).sort() };
}

/** 按执行结果渲染警示：outcome 缺席=执行前口径（「将提交」）；committed=已提交口径（审阅该提交）；
 *  否则=未提交口径（暂存仍在，审阅 index）。 */
export function renderStagedOriginWarning(f: StagedOriginFindings, outcome?: StagedOriginOutcome): string {
	f = resultStagedOriginFindings(f, outcome);
	const committed = outcome?.committed ?? null;
	const short = committed ? committed.slice(0, 12) : null;
	const listCmd = short ? `git show --name-only --format= ${short}` : "git diff --cached --name-only";
	const parts: string[] = [];
	if (f.opIntroduced.length) parts.push(`${f.opIntroduced.length} 个路径由${committed ? "" : "进行中的 "}${f.op} 引入（执行前 ${f.op === "merge" ? "MERGE_HEAD" : f.op === "cherry-pick" ? "CHERRY_PICK_HEAD" : "REVERT_HEAD"} 在场）——操作引入非来源不明，未列入可疑（审阅清单：${listCmd}）`);
	if (f.suspicious.length) parts.push(`${f.suspicious.length} 个来源未确认路径（会话开始后未见本会话写入登记）：${foldStagedList(f.suspicious, listCmd)}`);
	if (f.preExisting.length) parts.push(`${f.preExisting.length} 个路径在会话开始前就已处于暂存状态（即使本会话触碰过，路径级检查分不清混入的他人 hunk）：${foldStagedList(f.preExisting, listCmd)}`);
	if (!parts.length) return "";
	const disclaimer = "这只说明「来源未确认」，不代表属于其他任务；git add 不是创作归属证据。关闭本提示可设置 AMAGI_STAGED_ORIGIN_HINT=0。";
	// ev-20261108-e91768 期望②：前缀带触发命令摘要——提示经结果期/后续轮投递时与最新 HEAD/index
	// 事实可能错位，摘要锚定「针对哪条命令」（有界 ≤40 字，见 triggerCommandSummary）。
	const aimed = f.triggerCmd ? `（针对：${f.triggerCmd}）` : "";
	if (outcome && !Array.isArray(outcome.paths)) return `[异源暂存警示·软提示]${aimed} ${short ? `HEAD 已变更为 ${short}；` : ""}执行后实际路径清单未能核对，以下仅为执行前候选，不断言本次提交或暂存包含它们：${parts.join("；")}。${disclaimer}请只读核对：${listCmd}。本提示不阻断、不修改 index。`;
	if (short) return `[异源暂存警示·软提示]${aimed} commit 已提交为 ${short}，其中含${parts.join("；")}。${disclaimer}请只读审阅该提交：git show --stat ${short} -- <路径>（内容：git show ${short} -- <路径>）。本提示不阻断、不回滚、不修改 index。`;
	const verb = outcome ? "commit 未产生新提交（HEAD 未前移），暂存中仍有" : "commit 执行前候选（当前暂存及同命令 add 计划，非已提交事实）：";
	return `[异源暂存警示·软提示]${aimed} ${verb}${parts.join("；")}。${disclaimer}请先只读审阅：git diff --cached -- <路径>。本提示不阻断、不自动 unstage、不修改 index。`;
}

/** 执行前口径的一步式警示文本（兼容入口；宿主无 toolCallId 无法关联结果时使用）。 */
export function stagedOriginWarning(command: string, cwd: string, state: StagedOriginState): string | null {
	const f = stagedOriginFindings(command, cwd, state);
	return f ? renderStagedOriginWarning(f) : null;
}

export function registerGuards(pi: ExtensionAPI, options: { enableSentinel?: boolean; mcpHybrid?: NativeMcpGuardContext; nativeMcp?: () => NativeMcpGuardContext } = {}): void {
	const enableSentinel = options.enableSentinel !== false;
	// 兼容既有 mixed 静态接线；生产 nativeMcp 在调用时读取宿主注册表与冻结授权。
	const mcpHybrid = options.mcpHybrid;
	const sentinelKeys = new Set<string>();
	const categoryCounts = new Map<string, number>();
	const successfulBashCwds = new Map<string, string>();
	let sentinelTotal = 0;
	// 工具由模型按场景选择；这里仅对实际风险提示做会话去重。
	const guardAdvice = newGuardAdviceState();
	// ev-20260902-772c7f：硬边界累计命中计数（软阻断→升级 terminate 的依据；session 重置）。
	let boundaryHits = 0;
	// ev-20260916-c1a50c：bash 诊断会话计次（有界 64；第二次起标注「本会话第 N 次出现」）。
	const repeatNotes = new RepeatNoteTracker();
	// B4·批C（D1/D2/D3 disclose）：披露去重——去重键 rule+命令前 80 字符（设计 §6.1：同会话首次完整、
	// 后续同目标折叠；新目标重新完整披露）。有界（每 rule 至多 16 个目标摘要，FIFO 驱逐）。
	const disclosedGuardTargets = new Map<string, Set<string>>();
	// B4·批C（D1/D2/D3）：disclose 披露发送（设计 §6.1 格式：检测事实；不确定项；本次实际约束；
	// 可能影响；可选替代）。去重：同 rule+同目标（命令前 80 字符）首次完整、后续静默折叠（命令真实
	// 执行可见，重复披露仅噪音；新目标重新完整）。发送失败静默（披露不阻断执行）。
	const sendGuardDisclosure = (ruleId: "command.interactive" | "command.wait" | "command.opaque", fact: string, bounded: BashBoundedExecutionInfo, command: string): void => {
		const targetKey = command.slice(0, 80);
		let seen = disclosedGuardTargets.get(ruleId);
		if (seen === undefined) {
			if (disclosedGuardTargets.size >= 16) disclosedGuardTargets.delete(disclosedGuardTargets.keys().next().value as string);
			seen = new Set();
			disclosedGuardTargets.set(ruleId, seen);
		}
		if (seen.has(targetKey)) return;
		if (seen.size >= 16) seen.delete(seen.values().next().value as string);
		seen.add(targetKey);
		const boundText = bounded.bounded ? `本次执行时限 ${bounded.timeoutSec}s（超时自动收口，可中止）` : "本次无有限兑底（不应到达：无界时保持 block）";
		const alternatives = ruleId === "command.interactive"
			? "可用非交互替代（脚本参数/-c 一次性执行/BatchMode/单次采样）。"
			: ruleId === "command.wait"
				? "长等待建议拆批或改 run_bg 后台；循环命令建议有界退出条件。"
				: "复杂嵌套建议拆分执行或用脚本文件；未闭合替换在真实 bash 中报语法错误不执行。";
		try { pi.sendMessage({ customType: "amagi:guard-note", content: `[amagi guard:${ruleId}｜已放行] ${fact}；${boundText}；若停在等待输入将超时收口（非交互 env 已注入：PAGER=cat/GIT_TERMINAL_PROMPT=0，stdin 无 TTY）。${alternatives}（受信配置可收紧回 block；投影见 /amagi config explain）`, display: false }, { deliverAs: "steer" }); } catch { /* lint-exempt:披露发送失败不阻断执行 */ }
	};
	// ev-20260916-cfb0b5：异源暂存弱归因——会话 staged 基线 / 本会话确认写入 / 已提示 index 指纹。
	const stagedOriginState = newStagedOriginState();
	// ev-20261021-5c5f14：toolCallId → 执行前发现（tool_result 取出按结果渲染；有界 FIFO 64，中断未回结果的条目随淘汰丢弃）。
	const pendingStagedOrigin = new Map<string, StagedOriginFindings>();
	const rememberPendingStagedOrigin = (id: string, f: StagedOriginFindings): void => {
		if (pendingStagedOrigin.size >= 64) {
			const first = pendingStagedOrigin.keys().next().value;
			if (first !== undefined) pendingStagedOrigin.delete(first);
		}
		pendingStagedOrigin.set(id, f);
	};
	const takePendingStagedOrigin = (id: string): StagedOriginFindings | undefined => {
		if (!id) return undefined;
		const f = pendingStagedOrigin.get(id);
		pendingStagedOrigin.delete(id);
		return f;
	};
	const sendStagedOriginNote = (f: StagedOriginFindings, outcome?: StagedOriginOutcome): void => {
		// 无ID宿主只能披露候选；独立去重键不污染以后实际路径的warnedPaths。
		const candidateKey = (p: string) => `candidate\0${f.workTree}\0${p}`;
		let candidatePaths: string[] = [];
		if (!outcome) {
			const fresh = (paths: string[]) => paths.filter(p => !stagedOriginState.notified.has(candidateKey(p)));
			f = { ...f, suspicious: fresh(f.suspicious), preExisting: fresh(f.preExisting), opIntroduced: fresh(f.opIntroduced) };
			candidatePaths = [...f.suspicious, ...f.preExisting, ...f.opIntroduced];
		}
		if (Array.isArray(outcome?.paths)) {
			if (f.provenance) f = { ...f, provenance: { ...f.provenance,
				touched: [...new Set([...f.provenance.touched, ...sessionTouchedRelativePaths(stagedOriginState, f.workTree)])] } };
			f = resultStagedOriginFindings(f, outcome);
			const fresh = (paths: string[]) => paths.filter(p => !stagedOriginState.warnedPaths.has(`${f.workTree}\0${p}`));
			f = { ...f, suspicious: fresh(f.suspicious), preExisting: fresh(f.preExisting), opIntroduced: fresh(f.opIntroduced) };
		}
		const warning = renderStagedOriginWarning(f, outcome);
		if (!warning) return;
		// ev-20261002-f9f167：会话计次；ev-20261031-a25f7a：staged-origin 不并入 compact 折叠——正文是
		// 每轮不同的新路径名单（01c6f2 路径级去重后仅新路径触发提示），折叠会丢新混入路径的披露
		// （收口流实战依赖）；保持 19d1bb 全文+计次标注+升级段。用户「首次全文、第二次起折叠」
		// 口径针对同文重复族（管道退出码/ABI/env 类），不适用每轮新信息的披露型提示。
		const review = outcome?.committed ? `git show --stat ${outcome.committed.slice(0, 12)}` : "git diff --cached";
		const compactOut = withEscalatedNote(warning, repeatNotes.note("staged-origin"),
			`同批 commit 流内异源暂存警示已多次出现（add 改 index 即重新提示属预期）——本轮先只读审阅 ${review}；确认全部暂存属预期后可用 AMAGI_STAGED_ORIGIN_HINT=0 关闭本提示。`);
		try {
			pi.sendMessage({ customType: "amagi:guard-note", content: compactOut, display: false }, { deliverAs: "steer" });
			for (const p of candidatePaths) {
				if (stagedOriginState.notified.size >= 4096) {
					const first = stagedOriginState.notified.values().next().value;
					if (first !== undefined) stagedOriginState.notified.delete(first);
				}
				stagedOriginState.notified.add(candidateKey(p));
			}
			// 成功投递的真实路径才消耗去重，候选/发送失败不会吞掉以后真实提交的提示。
			if (Array.isArray(outcome?.paths)) for (const p of [...f.suspicious, ...f.preExisting, ...f.opIntroduced]) {
				if (stagedOriginState.warnedPaths.size >= 4096) {
					const first = stagedOriginState.warnedPaths.values().next().value;
					if (first !== undefined) stagedOriginState.warnedPaths.delete(first);
				}
				stagedOriginState.warnedPaths.add(`${f.workTree}\0${p}`);
			}
		} catch { /* lint-exempt:软提示发送失败不影响命令结果 */ }
	};
	const resetSessionState = () => {
		sentinelKeys.clear();
		categoryCounts.clear();
		successfulBashCwds.clear();
		sentinelTotal = 0;
		boundaryHits = 0;
		stashNoteState.sent = false; // ev-20260916-a7eee1：stash 提示生命周期改为 session
		repeatNotes.reset();
		disclosedGuardTargets.clear();
		stagedOriginState.baselines.clear();
		stagedOriginState.touched.clear();
		stagedOriginState.notified.clear();
		stagedOriginState.warnedPaths.clear();
		pendingStagedOrigin.clear();
		Object.assign(guardAdvice, newGuardAdviceState());
	};
	pi.on("session_start", (_event: any, ctx: any) => {
		resetSessionState();
		// diting 审核 Major-1：session_start 采集 staged 基线（cwd 所在仓库），消除「本会话单独
		// git add 后 commit」常态工作流的懒采集误报；非 repo/探测失败静默（懒采集兜底）。
		try { primeStagedOriginBaseline(typeof ctx?.cwd === "string" ? ctx.cwd : undefined, stagedOriginState); } catch { /* 采集失败静默 */ }
		// ev-20260902-772c7f：任务书「验证产物落盘位置」前置告知——白名单任务自动附带临时目录
		//（task-run 派发时注入 AMAGI_TASK_TMP_DIR 并已追加进白名单），收尾阶段的 stub server/
		// 验证脚本不再因选错落盘位（如系统 /tmp 根）触发边界拦截。
		const tmp = process.env.AMAGI_TASK_TMP_DIR;
		if (tmp) {
			// ev-20260909-729b99：撞名消歧追加
			const clash = taskTmpNameclashHint();
			const clashSuffix = clash ? `\n【撞名消歧】${clash}` : "";
			try {
				pi.sendMessage({ customType: "amagi:guard-note", content: `[验证产物落盘位置] ${tmp}（本任务自动授权）——运行期验证脚本/stub server/截图等临时产物统一写这里，不要写到系统 /tmp 其它路径或任务范围外目录；该目录 24h 自动回收，无需清理。${clashSuffix}`, display: false }, { deliverAs: "steer" });
			} catch {}
		}
	});
	pi.on("session_shutdown", resetSessionState);

	pi.on("tool_call", (event: any, ctx: any): any => {
		const toolName = String(event.toolName || "").toLowerCase();
		// 8月迭代 F5：任务硬边界——AMAGI_PROTECTED_PATHS（派发方声明，JSON 绝对路径数组）内的
		// edit/write 目标直接阻断（子 Agent 越界写用户未提交工作/共享文件的实战：d4c8ca40 改 fake-runner）。
		if (toolName === "edit" || toolName === "write") {
			// 8月迭代 pi-0.84 配合 P1④ + ev-20260902-772c7f：硬边界 reason 统一加精确前缀「[AMAGI 守卫·硬边界]」
			// （原 reason 文本保留在前缀之后）——task-run.ts 侧以三重结构化判据（isError + result.terminate +
			// 标记文本）识别「边界终止」并抑制自动续跑；软阻断（block 无 terminate）不会误判。
			// terminate 语义升级（ev-20260902-772c7f）：AMAGI_BOUNDARY_TERMINATE="1"=立即终止（旧严格逃生舱）、
			// "0"=永不终止、未设（新默认）=软阻断优先（前 2 次 block 保留上下文供子 Agent 自纠），
			// 累计第 BOUNDARY_ESCALATE_AT 次起升级终止（防无限重试循环）。
			const boundaryCwd = ctx?.cwd || process.cwd();
			const rawTargets = toolName === "edit" && Array.isArray(event.input?.files)
				? event.input.files.filter((f: unknown): f is string => typeof f === "string" && f !== "")
				: [String(event.input?.file_path || event.input?.path || "")].filter(Boolean);
			let targets: string[];
			try { targets = rawTargets.map((f: string) => resolveBuiltinFileTarget(f, boundaryCwd)); }
			catch (e) { return { block: true, reason: `[AMAGI 守卫·硬边界] 无法解析文件目标：${e instanceof Error ? e.message : String(e)}` }; }
			const protectedTarget = targets.find((f) => assertProtectedPaths(f, boundaryCwd));
			const blockedByBoundary = protectedTarget ? assertProtectedPaths(protectedTarget, boundaryCwd) : undefined;
			// 8月迭代 C3：白名单反向语义——写入目标不在 allowedPaths 内即 block（与 PROTECTED 同设取交集：都放行才放行）
			const outsideTarget = blockedByBoundary ? undefined : targets.find((f) => assertAllowedPaths(f, boundaryCwd));
			const blockedByWhitelist = outsideTarget ? assertAllowedPaths(outsideTarget, boundaryCwd) : undefined;
			const boundaryReason = blockedByBoundary ?? blockedByWhitelist;
			if (boundaryReason) {
				boundaryHits++;
				const _boundaryTarget = protectedTarget ?? outsideTarget ?? "";
				const _boundaryCwd = boundaryCwd;
				const _mode = process.env.AMAGI_BOUNDARY_TERMINATE;
				// ev-20260914-fd863c：越界分级——白名单外新建探针类低风险越界保持软阻断不升级 terminate
				//（替代指引见 boundaryBlockHint lowRiskProbe 文案）；修改既有白名单外文件/白名单外源码文件
				// 照旧升级。显式严格模式 "1" 是操作者逃生舱，优先于分级。黑名单（PROTECTED）命中不分级。
				const _lowRiskProbe = !!blockedByWhitelist && boundaryLowRiskNewFile(_boundaryTarget, _boundaryCwd);
				const terminate = boundaryTerminateDecision(_mode, boundaryHits) && !(_lowRiskProbe && _mode !== "1");
				// ev-20260914-9084ee②：首次白名单拦截附「前缀意图诊断」——无语法条目疑似前缀短写
				//（目录不存在但父目录内有同名前缀文件）时给出 glob/prefix: 改写指引，避免反复盲试。
				let _prefixHint = "";
				if (boundaryHits === 1 && blockedByWhitelist && !terminate) {
					try {
						const _rawEntries = JSON.parse(process.env.AMAGI_ALLOWED_PATHS || "[]");
						if (Array.isArray(_rawEntries)) _prefixHint = whitelistPrefixIntentHint(_rawEntries.filter((e): e is string => typeof e === "string"), _boundaryCwd);
					} catch { /* 诊断失败静默，不影响阻断 */ }
				}
				return { block: true, reason: `[AMAGI 守卫·硬边界] ${boundaryReason}${_prefixHint}${boundaryBlockHint(terminate, boundaryHits, { lowRiskProbe: _lowRiskProbe })}`, ...(terminate ? { terminate: true } : {}) };
			}
		}
		// 8月迭代 pi-0.84 配合 P1①：pi 0.84.3 新增可选内置 powershell 工具（Windows）纳入哨兵高风险路径
		// 告警集合（PS 的 Get-Content/管道同样触及 .env 等敏感路径；只读判定与 bash 同用 POSIX 集合）。
		if (enableSentinel && (toolName === "bash" || toolName === "powershell" || toolName === "edit" || toolName === "write")) {
			const rawPath = String(event.input?.file_path || event.input?.path || event.input?.command || "");
			const normalizedPath = rawPath.replaceAll("\\", "/");
			// v1.5.179: bash 只读命令跳过路径告警（edit/write 始终检查）
			const skipReadOnly = (toolName === "bash" || toolName === "powershell") && isReadOnlyCommand(String(event.input?.command || ""));
			const risk = !skipReadOnly && normalizedPath ? checkHighRiskPath(normalizedPath) : null;
			if (risk) {
				// ev-20260905-4c9d82①：key 用「类别:命中片段」（如 认证凭据:auth.json）——
				// 原来用整条命令文本，python heredoc/jq 每次命令不同 → 同一敏感文件反复告警（实战 3 连）。
				const key = `${risk.category}:${(risk.matched ?? normalizedPath).toLowerCase()}`;
				const categoryCount = categoryCounts.get(risk.category) || 0;
				if (!sentinelKeys.has(key) && categoryCount < SENTINEL_MAX_PER_CATEGORY && sentinelTotal < SENTINEL_MAX_PER_SESSION) {
					sentinelKeys.add(key); categoryCounts.set(risk.category, categoryCount + SENTINEL_MAX_PER_KEY); sentinelTotal++;
					// v1.5.244 注入安全：工具钩子内的 sendMessage 若用 {triggerTurn:false}，pi 会把 custom 消息原位
					// push 进 state.messages——恰落在 assistant(tool_calls) 与其 toolResult 之间；convertToLlm 将其原位转成
					// user 消息后，Kimi 等严格 OpenAI 兼容后端 400（tool 消息必须紧跟携带对应 tool_call_id 的 assistant）。
					// 统一改用 { deliverAs: "steer" }（不带 triggerTurn:false）：流式时进 steer 队列在快照末尾（全部
					// toolResult 之后）注入，非流式时原位插到末尾——两种状态都在完整配对之后，永不打断 tool 配对。
					try { pi.sendMessage({ customType: "amagi:sentinel", content: `[哨兵] 高风险路径：${normalizedPath}（${risk.category}），建议谨慎${sentinelAdvice(risk.category)}`, display: false }, { deliverAs: "steer" }); } catch {}
				}
			}
		}

		// ev-20260801-b7755a + ev-20260916-ead537：read 图片三态守卫（image-capable / text-only / unknown）。
		// text-only：阻断附件直送并引导识图通道（文案补「未读取到像素」）；unknown（元数据缺失/非法）：
		// strict 默认也阻断，说「能力未确认」（不得断言模型一定不支持图片）；legacy 回旧放行（防误伤
		// 逃生舱）。v1.5.250：①强调不得因看漏清单而跳级；②经 mcp_call 通道调用。
		// diting-M5-F1（方案 §5.2 read 通道同列）：grep/find 宿主独立工具的搜索根同样经
		// checkRead 逐次校验（ev-20260919 读范围限制退役后仅 deny 禁入护读；path 参数缺省=
		// cwd 本身——必须校验这个实际默认目录，不能把缺省路径当作「无目标」跳过 deny）。
		if (toolName === "grep" || toolName === "find") {
			const searchScopeReason = fileReadPermissionBlockReason(ctx?.cwd || process.cwd(), String(event.input?.path || "."), false);
			if (searchScopeReason) return { block: true, reason: searchScopeReason };
		}
		if (toolName === "read") {
			// P2（§5.2 read 通道）：ev-20260919 读范围限制退役——读不设范围限制，仅 deny 禁入
		// 拒绝（词法或真实落点任一命中 deny 即 block；符号链接 realpath 解析仍用于 deny 锚定）。
			const readScopeReason = fileReadPermissionBlockReason(ctx?.cwd || process.cwd(), String(event.input?.path || event.input?.file_path || ""));
			if (readScopeReason) return { block: true, reason: readScopeReason };
			const readPath = String(event.input?.path || event.input?.file_path || "");
			if (READ_IMAGE_EXT_RE.test(readPath)) {
				const model = (ctx as { model?: { provider?: string; id?: string; input?: string[] } } | undefined)?.model;
				const capability = imageReadCapability(model);
				if (capability === "text-only" && model) {
					return { block: true, reason: `[amagi 守卫] 当前模型 ${model.provider}/${model.id} 不支持图片输入（input 仅 ${(Array.isArray(model.input) ? model.input : []).join(",")}）——read 图片会把附件直送 provider 触发 400 并丢失终稿；即使上游未报错，本次也未读取到像素，请如实说明没有看到图片，不要声称已看图。${imageFallbackGuidance()}read 仅用于文本文件。` };
				}
				if (capability === "unknown" && imageReadGuardPolicy() === "strict") {
					return { block: true, reason: `[amagi 守卫] 图片读取能力未确认（模型元数据 input 声明缺失或非法）——默认阻断：未读取到像素前请不要声称已看图，也不要断言该模型一定不支持图片。${imageFallbackGuidance()}如需原生 read 图片，由具备条件的会话先核实模型 input 元数据后进行；本提示不引导嵌套派发。` };
				}
			}
		}
		// v1.5.265 视觉模型识图直读（ev-20260905，主上裁定）：实战中具备读图能力的模型仍经
		// amagi-media-understanding 技能 / zhipu-vision MCP 外派识图——绕远且丢一手视觉证据。
		// 与上方 ev-20260801-b7755a 互为镜像：model.input 含 "image" 时反向拦截外派通道，识图
		// 必须直接 read；识视频（read 不支持）与特殊格式不受限；元数据缺失不拦（防误伤）。
		// 原生工具/资源调用先于 transport 复核；保留原名的大小写，授权独立于 owner。
		const rawName = String(event.toolName || "");
		if (rawName.startsWith("mcp__") || NATIVE_MCP_RESOURCE_TOOLS.has(rawName) || NATIVE_MCP_RESOURCE_TOOLS.has(toolName)) {
			let nativeMcp: NativeMcpGuardContext | undefined;
			try { nativeMcp = options.nativeMcp?.() ?? mcpHybrid; }
			catch { return { block: true, reason: "[amagi 守卫] 原生 MCP 授权上下文不可用，拒绝执行；请恢复授权注册表后重试。" }; }
			if (nativeMcp !== undefined) {
				const hybridDecision = nativeMcpGuardDecision(rawName, event.input, nativeMcp);
				if (hybridDecision.block) return { block: true, reason: withPreExecAtomicity(hybridDecision.reason ?? "[amagi 守卫] 原生 MCP 调用被拒（混合模式 grant 复用检查）") };
			}
		}
		if (process.env.AMAGI_ALLOW_DELEGATED_VISION !== "1" && (toolName === "bash" || toolName === "powershell" || toolName === "mcp_call")) {
			const model = (ctx as { model?: { provider?: string; id?: string; input?: string[] } } | undefined)?.model;
			const inputs = Array.isArray(model?.input) ? model.input : undefined;
			if (model && inputs && inputs.includes("image")) {
				if (toolName === "mcp_call") {
					if (isDelegatedImageMcpCall(event.input?.server, event.input?.tool)) {
						return { block: true, reason: `[amagi 守卫] 当前模型 ${model.provider}/${model.id} 具备读图能力（model.input 含 image），无需经 MCP 视觉工具 ${String(event.input?.server)}/${String(event.input?.tool)} 外派识图（本次调用已拦截）。请直接用 read 工具读取图片路径后自行分析；识视频（analyze_video 等）不受此限。确需外派可设 AMAGI_ALLOW_DELEGATED_VISION=1。` };
					}
				} else {
					const delegated = assertNoDelegatedImageRecognition(String(event.input?.command || ""));
					if (delegated) return { block: true, reason: withPreExecAtomicity(delegated) };
				}
			}
		}
		// ev-20260922-e44fe9（B0/P0）：stash 串联门同样覆盖 run_bg start——run_bg 直接 spawn 任意
		// shell 命令，不能靠 bash 的 toolName 钩子证明受保护；直接 API 入口（runBgExecute）另有一层
		// 同门（双重接线，工具链与直接调用均验证）。只补串联保护，不重构后台工具权限。
		if (toolName === "run_bg" && String(event.input?.action || "") === "start") {
			const runBgCommand = String(event.input?.command || "");
			const runBgCwd = effectiveBashCwd(event.input as Record<string, unknown> | undefined, ctx?.cwd || process.cwd());
			const runBgChain = decideStashChainGate(runBgCommand, runBgCwd);
			if (runBgChain) return { block: true, reason: withPreExecAtomicity(runBgChain.reason) };
			// ev-20261105-e4d22a（O-01）：run_bg start 直接 spawn 任意 shell 命令——rm 清点三通道
			// 与 bash 同门（同一 planRmTreeChannels 分流：临时后代披露放行/有 UI 真实确认/无 UI
			// 阻断附可复制命令）；stashChain 仍在最前（整单拒绝优先）。本段之后无其他同步门（commit/
			// discard 等门只接 bash/powershell 输入），确认可立即进行并自带指纹重查。直接 API 入口
			// （runBgExecute）只保留 stashChain 同门：与 discard/commit 门同口径只接 tool_call 事件层
			//（rm 确认需 UI 渠道与披露通道，仅在 tool_call 语境可用；取舍详见实现报告）。
			const runBgRmPlan = planRmTreeChannels(pi, ctx, runBgCommand, runBgCwd);
			if (runBgRmPlan.headlessReason) return { block: true, reason: runBgRmPlan.headlessReason };
			if (runBgRmPlan.confirmFn) return confirmRmTreeTargets(runBgRmPlan.confirmFn, runBgRmPlan.general, runBgCommand, runBgCwd);
		}
		// M8（diting 审核轮）：win_exec 破坏性 git 操作同门——适配函数在 win-exec-guard.ts
		//（规范化 program/args 为等价命令串后复用 git-discard-guard 同一判定与 B2 授权票据；
		// 授权票据由 win-exec.ts 执行边界消费）。本分支是最小加法，不改动既有逻辑。
		if (toolName === "win_exec") {
			try {
				const winExecCwd = effectiveBashCwd(event.input as Record<string, unknown> | undefined, ctx?.cwd || process.cwd());
				const winExecGate = winExecGuardDecision(event.input as WinExecGuardInput, {
					cwd: winExecCwd,
					toolCallId: String(event.toolCallId || ""),
					notify: (text) => { pi.sendMessage({ customType: "amagi:guard-note", content: text, display: false }, { deliverAs: "steer" }); },
				});
				if (winExecGate) return { block: true, reason: withPreExecAtomicity(winExecGate.reason) };
			} catch { /* lint-exempt:适配层异常不阻断（工具执行层仍有 M8 兜底门） */ }
		}
		// 8月迭代 pi-0.84 配合 P1①：powershell 并入 bash 同路（复用 event.input.command 字段）——
		// POSIX 危险/交互/提交守卫对 PS 输入直接复用（rm -rf /、git push 等跨 shell 同险）；
		// PS 专有语法走下方 assertPowerShellDanger/assertPowerShellInteractive 补充检查。
		if (toolName === "bash" || toolName === "powershell") {
			const command = String(event.input?.command || "");
			// ev-20260823-c3881f：全部 git 类守卫用 bash 工具的 cwd 参数（含 WSL 形式归一化）而非会话 cwd。
			const bashCwd = effectiveBashCwd(event.input as Record<string, unknown> | undefined, ctx?.cwd || process.cwd());
			// B4·批C（D1/D2/D3，ev-20261012-af58eb §8 批C + Leader 裁定）：危险命令扫描改分类收集——
			// hard（红线/remoteExecution/终止进程/递归删除根/eval 远程载荷）恒 block；wait（D2）与
			// opaque（D3）按 guard-policy 投影分流：block=现状硬阻断，disclose=放行+披露（前置实测证明
			// 有限 timeout/可取消/非交互 env 已生效——B4C 前置探针①②③④；未闭合替换真实 bash 语法
			// 错误零执行——探针⑤）。disclose 前提：本次调用有有限执行兑底（显式 timeout 或子代理默认
			// 超时），无界等待保持 block（Leader 面 bash 未传 timeout 无限兑底）。
			const risk = scanCommandRisk(command);
			const guardTrust = guardProjectTrustedOf(ctx);
			if (risk.hard) return { block: true, reason: withPreExecAtomicity(risk.hard) };
			const bounded = bashBoundedExecutionInfo(event.input as Record<string, unknown> | undefined, toolName);
			if (risk.wait) {
				if (guardRuleOf("command.wait", bashCwd, guardTrust) === "block" || !bounded.bounded) {
					return { block: true, reason: withPreExecAtomicity(risk.wait + boundedBlockSuffix(bounded)) };
				}
				sendGuardDisclosure("command.wait", risk.wait, bounded, command);
			}
			if (risk.opaque) {
				if (guardRuleOf("command.opaque", bashCwd, guardTrust) === "block" || !bounded.bounded) {
					return { block: true, reason: withPreExecAtomicity(risk.opaque + boundedBlockSuffix(bounded)) };
				}
				sendGuardDisclosure("command.opaque", risk.opaque, bounded, command);
			}
			// ev-20260903-20063d：目录树删除清点守卫（仅 bash——PS 侧递归删除由 PS 专有规则管辖；
			// 根/家目录硬拦已由上方 assertSafeCommand 承担，接线在其后不重复）。
			// ev-20261105-e4d22a：两态 → 三通道——①系统临时根后代（os.tmpdir()/$TMPDIR//tmp/
			// /private/tmp 等，realpath 归一）降级为披露放行（临时空间本就是可丢弃内容，mv 移动保留区
			// 也在此处，原硬阻断把「清理实验现场」变成无解）；②其余违规目标有 UI 时经 ui.confirm
			// 真实确认（默认否/超时 120s/取消即拒）——确认放行、拒绝阻断，无确认渠道才保留硬阻断；
			// ③无 UI（子代理/RPC/headless）不伪造授权，阻断文案附可直接复制的手工执行命令。确认是
			// 异步且会提前 return：pendingRmConfirm 先收集，等 commit/worktree/stashChain/discard/
			// subagentStash/interactive/PS 等全部同步门跑完再弹（本门确认不绕过任何同步门）；与丢弃
			// 确认门共存时依次确认（先丢弃后删除，任一拒绝整单阻断，见 confirm 分支内接线）。
			// 回滚：AMAGI_RM_TMP_ALLOW=0/false/off 临时目录回到阻断（isRmTemporaryDescendant 恒 false）。
			let pendingRmConfirm: RmTreeTarget[] | undefined;
			let rmConfirmFn: ((title: string, message: string, opts?: { timeout?: number }) => Promise<boolean>) | undefined;
			if (toolName === "bash") {
				// O-01 起与 run_bg 共用 planRmTreeChannels（分流/披露/确认渠道解析单点）；bash 面确认
				// 时机延后到全部同步门之后（pendingRmConfirm 收集，见下方兑底点与丢弃 confirm 链内接线）。
				const rmPlan = planRmTreeChannels(pi, ctx, command, bashCwd);
				if (rmPlan.headlessReason) return { block: true, reason: rmPlan.headlessReason };
				if (rmPlan.confirmFn) { pendingRmConfirm = rmPlan.general; rmConfirmFn = rmPlan.confirmFn; }
			}
			// ev-20260823-c3881f：commit/add 守卫用 bash 工具的 cwd 参数（含 WSL 形式归一化）而非会话 cwd——
			// 子目录仓库 + 会话 cwd 非仓库时，git 探测必失败导致正常 commit 被误拦。
			const commit = assertCommitSafe(command, bashCwd, 0, guardProjectTrustedOf(ctx));
			if (commit) return { block: true, reason: withPreExecAtomicity(commit) };
			// ev-20260917-77adc5（friction/P1）：git add/commit 排除 pathspec 零匹配防呆——零匹配且
			// 存在同名（basename）变更文件 → 疑似笔误软提示（含最近似路径）；只警示不阻断。
			const excludeHint = gitExcludePatternTypoHint(command, bashCwd);
			if (excludeHint) {
				try { pi.sendMessage({ customType: "amagi:guard-note", content: excludeHint, display: false }, { deliverAs: "steer" }); } catch {}
			}
			// ev-20260916-07e44a（bash 入口）：git worktree remove（含 --force/-f、-C）前置脏树检查——
			// cleanupWorktree 的保护只覆盖 task 工具入口，用户经 Git CLI 强删脏树同样不可逆；
			// S4 的 inspectWorktreeRemoval 就绪后改为调用同一实现（见 git-discard-guard.ts 头注）。
			// 回滚：AMAGI_WORKTREE_DIRTY_REMOVE=legacy（默认 protect）。
			const worktreeGate = decideWorktreeRemoveGate(command, bashCwd);
			if (worktreeGate) return { block: true, reason: withPreExecAtomicity(worktreeGate.reason) };
			// ev-20260922-e44fe9（B0/P0）：stash 串联门——同一工具调用内风险 stash 与其他可执行段串联时
			// 整单拒绝（实战：push 因 untracked 失败、pop 仍运行弹出他人 stash 污染七文件）。接线在丢弃
			// 确认门可能异步返回的 confirm 分支之前（否则 confirm 提前 return 会绕过本门）；不以
			// AMAGI_SUBAGENT 分流、不被 AMAGI_GIT_DISCARD_POLICY=warn/legacy 豁免（安全兼容性变化，见
			// 发布说明）；单步 stash 仍走既有子 Agent 门与主会话软提示。
			const stashChainGate = decideStashChainGate(command, bashCwd);
			if (stashChainGate) return { block: true, reason: withPreExecAtomicity(stashChainGate.reason) };
			// ev-20260916-18f0d5：丢弃改动确认门（checkout 路径还原 / restore / reset --hard）。
			// 回滚：AMAGI_GIT_DISCARD_POLICY=confirm|warn|legacy（默认 confirm；操作者部署配置，文案不教 env 绕过）。
			const discardGate = decideDiscardGate(command, bashCwd);
			if (discardGate) {
				if (discardGate.action === "block") return { block: true, reason: withPreExecAtomicity(discardGate.reason) };
				if (discardGate.action === "warn") {
					// ev-20260922-1eea28（B2）：warn 保留历史行为（列风险不确认），但显式标明未获得
					// backup-and-execute 通道的完整备份保证——不得把 warn 当自动备份别名。
					try { pi.sendMessage({ customType: "amagi:guard-note", content: `[丢弃改动风险·软提示]（warn 策略：只警示不确认，未获得本通道（backup-and-execute）的完整备份保证——stash create 快照只覆盖 tracked 改动） ${discardGate.reason}`, display: false }, { deliverAs: "steer" }); } catch {}
				} else if (discardGate.action === "confirm") {
					// confirm：只有真实确认渠道才弹确认（默认否，超时/取消均拒绝；确认后重查 fingerprint，
				// 状态变化则取消本次执行）。无 UI（子代理/RPC/headless）不伪造授权：阻断并报告 Leader。
					// handler 其余路径保持同步返回，仅本分支返回 Promise——pi 的 tool_call runner 对结果
					// await，两种形态等价（不改变既有同步测试 harness 的行为）。
					const ui = (ctx as { hasUI?: boolean; ui?: { confirm?: (title: string, message: string, opts?: { timeout?: number }) => Promise<boolean> } } | undefined);
					if (ctx?.hasUI && typeof ui?.ui?.confirm === "function") {
						const confirmFn = ui.ui.confirm;
						return (async (): Promise<{ block: true; reason: string } | undefined> => {
							let ok = false;
							try { ok = await confirmFn(discardGate.title, discardGate.message, { timeout: 120_000 }); } catch { ok = false; }
							if (!ok) return { block: true, reason: withPreExecAtomicity("用户未确认丢弃改动（确认默认否；超时/取消均视为拒绝）——命令未执行。可改用 edit 工具做局部修复，或先保全改动后另行处置。") };
								const recheck = inspectDiscard(command, bashCwd);
							if (!recheck || recheck.fingerprint !== discardGate.inspection.fingerprint || recheck.unknownReason) {
								return { block: true, reason: withPreExecAtomicity("确认后检测到工作区/暂存状态已变化（fingerprint 不一致）——预检授权不能跨状态生效，本次执行已取消；请重新执行命令重新确认。") };
							}
							// ev-20261105-e4d22a：丢弃确认通过后依次处理 rm 清点确认（同一 async 链内，不因
							// 本分支提前 return 而漏掉；先丢弃后删除——丢弃是不可恢复面更宽的操作，先确认
							// 高危项。互斥面：rm 段在丢弃段之前时，丢弃门既有前置段检查已同步拦截，不会
							// 到达此处；本接线覆盖「丢弃在前、rm 在后」与前置段检查未来放宽时的纵深防御）。
							if (pendingRmConfirm && rmConfirmFn) {
								const rmOutcome = await confirmRmTreeTargets(rmConfirmFn, pendingRmConfirm, command, bashCwd);
								if (rmOutcome) return rmOutcome;
							}
							return undefined;
						})();
					}
					// ev-20260922-1eea28（B2）：无 UI + 有效预授权（AMAGI_DISCARD_APPROVAL_REF 不透明引用，
					// 宿主受保护记录验真）→ backup-and-execute：验真（命令/内容指纹/归属/有效期/lease）
					// → 备份 → 全量复核 → 原子 claim → 签发一次性放行凭证（绑定 toolCallId/canonicalCommand/
					// cwd，预检后换命令即失效；实际执行与结果记录由 bash-override 承接）。「无人值守」本身
					// 不是授权——仅 bash 通道接入本执行边界；powershell 等非 bash 通道在接入同等边界前保持阻断。
					if (toolName === "bash") {
						const approvalRef = discardApprovalRefFromEnv();
						if (approvalRef) {
							const authorized = authorizeDiscardBackupAndExecute({
								command,
								cwd: bashCwd,
								inspection: discardGate.inspection,
								ref: approvalRef,
								toolCallId: String(event.toolCallId || ""),
							});
							if (authorized.ok) {
								// 放行：命令由 bash-override 凭一次性凭证执行并记录结果（guard-note 含真实 backupId）。
							return undefined;
							}
							return { block: true, reason: withPreExecAtomicity(`[amagi 守卫·丢弃确认·B2 授权通道] 预授权验真/备份未通过，命令未执行：${authorized.reason}${authorized.approvalText ? `（${authorized.approvalText}）` : ""}备份数据不因拒绝丢失（已完成的备份保留）；如需丢弃请重新签发授权后在有效期内执行。`) };
							}
					}
					// 无 UI 无授权 → 仍 blocked；文案附可供有权会话批准的清单（准确对象 + 影响 + 建议批准方式）。
					return { block: true, reason: withPreExecAtomicity(`[amagi 守卫·丢弃确认] 检测到将丢弃未提交改动的 Git 操作（${discardGate.inspection.kindLabel}），当前会话无真实确认渠道（子代理/RPC/headless 不自行授权破坏性 Git 操作）——命令未执行。${discardRiskText(discardGate.inspection)}【可供有权会话批准的清单】准确对象与影响见上方路径清单；建议批准方式：① 在具备确认渠道的会话（TUI ui.confirm）执行同一命令并确认；② 或由 Leader 经任务派发预授权签发一次性丢弃授权（DiscardApproval：10 分钟有效、单次消费、绑定命令与内容指纹）后重派本任务。任务角色不得自行设置 env 或 backup 参数批准丢弃。请报告 Leader；小范围恢复优先用 edit 工具局部修复。`) };
				}
			}
			// ev-20260916-cfb0b5：异源暂存弱归因警示（commit 已过提交守卫；不阻断、不动 index）。
			// 回滚：AMAGI_STAGED_ORIGIN_HINT=0/false/off。
			if (/\bcommit\b/.test(command) && stagedOriginHintEnabled()) {
				const findings = stagedOriginFindings(command, bashCwd, stagedOriginState, true);
				if (findings) {
					// ev-20261021-5c5f14：发现在执行前采集（commit 前 index 才是真相），措辞在执行后按
					// HEAD 是否前移选择——steer 消息本就在工具返回后才送达，执行前措辞「将提交 / 审阅
					// git diff --cached」在提交成功后已失效。宿主未给 toolCallId（无法关联结果）才按执行前口径即发。
					const toolCallId = String(event.toolCallId || "");
					if (toolCallId) rememberPendingStagedOrigin(toolCallId, findings);
					else sendStagedOriginNote(findings);
				}
			}
			// ev-20260917-589972（P2·修③）：子 Agent stash 硬拦截——共享树多进程协作实战：子 Agent 为归因
			// 把主上未提交改动 stash 后恢复（中断即丢）。checkout/restore/reset --hard 已由上方丢弃确认门
			// 在 headless 下等效阻断（confirm 无 UI 即 block）；stash 此前只有软提示，此处补硬拦截。
			// 逃生舱沿用 AMAGI_GIT_DISCARD_POLICY（legacy/warn 不阻断，软提示仍生效）。
			const subagentStashGate = decideSubagentStashGate(command, bashCwd);
			if (subagentStashGate) return { block: true, reason: withPreExecAtomicity(subagentStashGate.reason) };
			// ev-20260803-8777cf：stash 高风险软提示（不阻断）——生产工作树弹 stash 可能污染未提交
			// 工作区（实战：为验证 pre-existing 问题险些弹掉遗留 stash）。
			// ev-20260903-c1521b① + ev-20260916-a7eee1：一次性标志（session 生命周期）+ 子命令解析
			//（list/show 只读豁免；grep/sed 等字面文本不触发；回滚 AMAGI_STASH_HINT_PARSE=legacy 回旧正则）。
			if (!stashNoteState.sent) {
				const stashHit = process.env.AMAGI_STASH_HINT_PARSE === "legacy"
					? /\bgit\b[^;|&]*\bstash\b/.test(command)
					: stashRiskOperation(command, bashCwd);
				if (stashHit) {
					stashNoteState.sent = true;
					try { pi.sendMessage({ customType: "amagi:guard-note", content: `[stash 提示] 检测到 git stash 操作——弹/删 stash 会改动工作区状态：①先 git stash list 确认目标；②验证类任务请用独立 worktree（task 派发传 worktree 参数）而非生产工作树；③仅新增 stash（无子命令）风险低。软提示不阻断。`, display: false }, { deliverAs: "steer" }); } catch {}
				}
			}
			// v1.5.189: 交互式卡死守卫（无 TTY 必挂起的程序级交互命令）
			// B4·批C（D1）：默认 disclose（前置实测⑥：vi 无 TTY 真实挂起但被有限 timeout 3s 收口；
			// read -p/裸 python 无 stdin 立即 EOF 退出）——放行+披露实际时限与非交互替代；无有限兑底
			//（Leader 未传 timeout 且非子代理）保持 block；powershell 工具通道（仅 Windows，本机
			// darwin 无法实测）不 disclose，保持 block（平台未验证，同 D4 口径）。
			const interactive = assertNonInteractive(command);
			if (interactive) {
				const interactiveRule = guardRuleOf("command.interactive", bashCwd, guardTrust);
				if (interactiveRule === "block" || !bounded.bounded) return { block: true, reason: withPreExecAtomicity(interactive + boundedBlockSuffix(bounded)) };
				sendGuardDisclosure("command.interactive", interactive, bounded, command);
			}
			// 8月迭代 pi-0.84 配合 P1①：PowerShell 专有补充——高置信破坏性模式 + 交互旗标（bash 路径
			// 共用：bash 中嵌套 powershell -EncodedCommand/-NoExit 同为混淆执行/挂起场景）。
			// ev-20260903-96b827②：传入 toolName 平台分流——bash 在 darwin/linux 跳过 PS 别名族规则
			//（保留 -EncodedCommand 混淆与下方交互旗标两类自嵌套检测），powershell 工具与 win32 不变。
			const psDanger = assertPowerShellDanger(command, toolName);
			if (psDanger) return { block: true, reason: withPreExecAtomicity(psDanger) };
			// B4·批C（D1 含 PS 交互）：bash 内嵌 powershell -NoExit/-Interactive 的交互旗标检测——
			// bash 通道有有限 timeout 兑底时 disclose（嵌套 PS 进程随 bash timeout 组级收口）；
			// powershell 工具通道（仅 Windows，平台未验证）保持 block。
			const psInteractive = assertPowerShellInteractive(command);
			if (psInteractive) {
				if (toolName !== "bash" || !bounded.bounded || guardRuleOf("command.interactive", bashCwd, guardTrust) === "block") {
					return { block: true, reason: withPreExecAtomicity(psInteractive) };
				}
				sendGuardDisclosure("command.interactive", psInteractive, bounded, command);
			}
			// ev-20261105-e4d22a：rm 清点确认兑底——pendingRmConfirm 自清点门收集至此，全部同步
			// 阻断门（commit/worktree/stashChain/discard/subagentStash/interactive/PS）已跑完：被
			// 同步门拦下的命令不消耗确认，此处才弹真实确认；后续仅剩软提示，确认链提前 return 跳过
			// 它们与丢弃确认门 confirm 分支的既有行为一致。丢弃确认门 confirm 分支的提前 return 场景
			// 已在其 async 链内自行接入本确认，不经过此兑底。
			if (pendingRmConfirm && rmConfirmFn) {
				const rmTargets = pendingRmConfirm, rmFn = rmConfirmFn;
				return confirmRmTreeTargets(rmFn, rmTargets, command, bashCwd);
			}
			// ev-20260831-56f939（8月迭代 pi-0.84 配合 修复轮）：前台派生 pi 子进程无 timeout 软提示
			// （每会话至多一次，不阻断；文案见 piChildSpawnRisk——bash/powershell 共路两栖覆盖）。
			if (!guardAdvice.piSpawnNotified) {
				const piSpawnHint = piChildSpawnRisk(command, (event.input as Record<string, unknown> | undefined)?.timeout);
				if (piSpawnHint) {
					guardAdvice.piSpawnNotified = true;
					try { pi.sendMessage({ customType: "amagi:guard-note", content: piSpawnHint, display: false }, { deliverAs: "steer" }); } catch {}
				}
			}
			// ev-20260923-680943：全盘 find 无超时预算软提示（每会话至多一次，不阻断；文案见 fullScanFindRisk）。
			if (!guardAdvice.findScanNotified) {
				const findScanHint = fullScanFindRisk(command, (event.input as Record<string, unknown> | undefined)?.timeout);
				if (findScanHint) {
					guardAdvice.findScanNotified = true;
					try { pi.sendMessage({ customType: "amagi:guard-note", content: findScanHint, display: false }, { deliverAs: "steer" }); } catch {}
				}
			}
			// ev-20260830-2c709d（剩余缺口）：批量格式化整包重写软提示（go fmt 任意形式 / gofmt -w
			// 无显式单文件列表；文案见 batchFormatRewriteRisk）。挂接在丢弃确认门等全部阻断门之后：
			// 被阻断的命令不消耗提示名额，软提示只在命令真正走向执行时发出；不阻断、不改写命令、不碰 index。
			if (!guardAdvice.batchFormatNotified) {
				const batchFormatHint = batchFormatRewriteRisk(command, bashCwd);
				if (batchFormatHint) {
					guardAdvice.batchFormatNotified = true;
					try { pi.sendMessage({ customType: "amagi:guard-note", content: batchFormatHint, display: false }, { deliverAs: "steer" }); } catch { /* lint-exempt:软提示发送失败静默——警示非关键路径，不阻断命令（ev-20260830-2c709d） */ }
				}
			}
			// ev-20260910-244bbd（ux/P3）：管道吞退出码的假阳性防呆（软提示，不阻断）——
			// `cmd | grep x && echo 通过` 形态下管道退出码只取末段，左侧失败不传播，&& 断言
			// 可能得出假阳性结论回流 Leader。ev-20260926-19d1bb：接入会话计次升级——仍逐次提示
			// （不跟频）；ev-20261031-a25f7a：阈值 3→2（首次全文、第 2 次起折叠接管，用户裁定口径）。
			const pipeHint = pipeExitCodeHint(command);
			if (pipeHint) {
				// ev-20261002-f9f167：可纠正型降频——第 2 次起升级接管（一行计数+修正建议，不再重复全文）
				const pipeHintOut = withCompactEscalatedNote(pipeHint, repeatNotes.note("pipe-exit-code"),
					"管道退出码陷阱已多次命中——本轮就把 `set -o pipefail` 写进命令开头再跑，或改判 `${PIPESTATUS[0]}`，不要继续裸读管道退出码。");
				try { pi.sendMessage({ customType: "amagi:guard-note", content: pipeHintOut, display: false }, { deliverAs: "steer" }); } catch {}
			}
			// 8月迭代 C3：白名单下 bash 写盘目标软提示——第一版不硬拦（重定向目标提取可靠性不足，防误拦）。
			// bashWriteTargets 只提取高置信形态（$VAR/命令替换/通配一律不记）；提取到目标且 ∉ 白名单 → sendMessage 提示，不阻断。
			if (process.env.AMAGI_ALLOWED_PATHS) {
				const bashCwd = effectiveBashCwd(event.input as Record<string, unknown> | undefined, ctx?.cwd || process.cwd());
				const offenders = bashWriteTargets(command).filter((t) => assertAllowedPaths(t, bashCwd));
				if (offenders.length > 0) {
					try { pi.sendMessage({ customType: "amagi:guard-note", content: `[白名单提示] bash 写盘目标疑似不在任务允许写入清单（allowedPaths）内：${offenders.join("、")}——软提示不阻断（目标提取可靠性有限）；若确需写入，通过报告说明由 Leader 处理。`, display: false }, { deliverAs: "steer" }); } catch {}
				}
			}
			if (scanBackticks(command).doubleQuotedLiterals.length) {
				try { pi.sendMessage({ customType: "amagi:guard-note", content: DOUBLE_QUOTED_BACKTICK_ADVICE, display: false }, { deliverAs: "steer" }); } catch {}
			}
		}
		return undefined;
	});

	pi.on("tool_result", (event: any, ctx: any): any => {
		const toolName = String(event.toolName || "").toLowerCase();
		const input = event.input as Record<string, unknown> | undefined;
		const command = String(input?.command || "");
		const sessionCwd = String(ctx?.cwd || process.cwd());
		// ev-20260916-ead537④：read 图片结果被上游剥除（精确哨兵匹配，非普通 image/omitted 文本）
		// → 转明确失败并附同样指引；保留原始内容与路径，不伪造图片内容。pi 可能在扩展之后才生成
		// 该文本，后处理只是补充（主修复是 unknown 前置拦截）；legacy 模式维持旧行为不后处理。
		if (toolName === "read" && !event.isError && imageReadGuardPolicy() === "strict") {
			const readPath = String(input?.path || input?.file_path || "");
			if (READ_IMAGE_EXT_RE.test(readPath) && toolResultText(event.content).includes(TOOL_IMAGE_OMITTED_SENTINEL)) {
				return {
					isError: true,
					content: [...(event.content || []), { type: "text" as const, text: `\n\n[amagi 守卫] 本次 read 图片未读取到像素（上游返回 "${TOOL_IMAGE_OMITTED_SENTINEL}"）——看图失败，请如实说明，不要用文件名/尺寸/上下文推断来冒充已看图。${imageFallbackGuidance()}以上保留原始返回与路径（${readPath}）；请改走识图路线后重试。` }],
				};
			}
		}
		// ev-20260922-1eea28（B2）：授权丢弃执行结果的 guard-note（含真实 backupId）——bash-override
		// 执行边界已把 outcome 落盘（outcome.jsonl 持久事实）；此处仅发送人类可读摘要（成功/失败两态
		// 都发），发送失败不抹掉落盘事实（try/catch 静默，双向独立）。
		if (toolName === "bash" && !event.isError) {
			// 结果已成功，先登记同命令的高置信写目标，再核对提交归属。
			const bashCwd = effectiveBashCwd(input, sessionCwd);
			rememberSuccessfulBashCwd(successfulBashCwds, command, bashCwd);
			for (const target of bashWriteTargets(command)) {
				recordSessionTouchedPath(stagedOriginState, path.isAbsolute(target) ? path.normalize(target) : path.resolve(bashCwd, target));
			}
		}
		if (toolName === "bash") {
			const pendingStaged = takePendingStagedOrigin(String(event.toolCallId || ""));
			if (pendingStaged) sendStagedOriginNote(pendingStaged, resolveStagedOriginOutcome(pendingStaged));
			const discardOutcomeNote = takePendingDiscardOutcomeNote(String(event.toolCallId || ""));
			if (discardOutcomeNote) {
				try { pi.sendMessage({ customType: "amagi:guard-note", content: discardOutcomeNote, display: false }, { deliverAs: "steer" }); } catch {}
			}
		}
		if (event.isError) {
			const pathDiagnostic = missingReadPathDiagnostic(toolName, input, toolResultText(event.content), toolName === "bash" ? effectiveBashCwd(input, sessionCwd) : sessionCwd);
			if (toolName !== "bash") return pathDiagnostic ? { content: [...(event.content || []), { type: "text", text: pathDiagnostic }], isError: true } : undefined;
			// v1.5.216: 语义性非零退出白名单优先于全部特征路由，避免 grep/diff 正常语义产生噪音。
			// ev-20260908-23c9e9: 升级为 shouldSuppressBashDiagnostic 三维判定（退出码+错误签名+段结构），
			// 覆盖真实复合验证命令（赋值/cd/echo 前缀 + 末段 grep 零匹配）且负路径不回退。
			// ev-20261017-6d2825：归因成立时从静默改为一行正向注记（exit 1=无匹配，非失败），不走通用诊断。
			const semanticTool = semanticExitAttribution(command, toolResultText(event.content));
			if (semanticTool) {
				// ev-20261027-b9953e：单条 grep 族无匹配改一行简短说明（feishu-sync #1051 静默缺解释，
				// 被读作未分类失败）；复合命令保持完整归因注记（#831 同型：匹配正文不再误判为执行错误）。
				// diff/cmp/which/compgen 维持静默（23c9e9 降噪口径不回退）；isError 事实不变。
				const compound = shellSegments(semanticExitCommandText(command)).length > 1;
				const note = semanticExitNote(semanticTool, compound);
				return note ? { content: [...(event.content || []), { type: "text" as const, text: note }], isError: true } : undefined;
			}
			// ev-20261101-c1c267：归因不明的 pipefail/errexit 混合链 exit 1 改中性解释——通用诊断开场
			// 「原样重试通常还会失败」把可能的无匹配误说成执行失败（pgrep|wc 无匹配被当失败计数）。
			// 退出码/isError 事实不变；真实错误签名、126/127、exit≥2 与真编译测试失败仍走原诊断。
			const neutralNote = ambiguousSemanticExit1Note(command, toolResultText(event.content));
			if (neutralNote) {
				return { content: [...(event.content || []), { type: "text" as const, text: neutralNote }], isError: true };
			}
			const effectiveCwd = effectiveBashCwd(input, sessionCwd);
			const diagnostic = diagnoseBashFailure({
				errorText: toolResultText(event.content),
				cwd: effectiveCwd,
				repositoryRoot: sessionCwd,
				command,
				successfulCwd: successfulBashCwds.get(bashCommandPrefix(command)),
				historyCwds: [...new Set(successfulBashCwds.values())],
				// ev-20260830-b70efc：懒探测（仅 127 分支求值；probeBashRuntime 模块级缓存，首次后零开销）
				runtime: () => probeBashRuntime(sessionCwd),
			});
			// ev-20260916-c1a50c：同规则第二次起标注「本会话第 N 次出现」（软提示不升级；不记录命令正文）。
			// 回滚：AMAGI_GUARD_REPEAT_NOTE=0/false/off 回旧文案。
			const diagnosticTextOut = guardRepeatNoteEnabled()
				? withRepeatNoteHeader(diagnostic, repeatNotes.note(diagnosticRuleKey(command, toolResultText(event.content), {
					// ev-20260922-d9655d：规则键与诊断同平台口径（懒探测，仅 cat 命中分支才求值）
					platform: () => { try { return shellPlatformOf(probeBashRuntime(sessionCwd)); } catch { return undefined; } },
				})))
				: diagnostic;
			return {
				content: [
					...(event.content || []),
					{ type: "text" as const, text: [diagnosticTextOut, pathDiagnostic].filter(Boolean).join("\n") },
				],
			};
		}
		if (toolName === "write" || toolName === "edit") {
			const filePath = String(event.input?.path || event.input?.file_path || "");
			// ev-20260916-cfb0b5：成功 write/edit 的路径记入会话 touched（异源暂存弱归因数据源）。
			if (!event.isError) recordSessionTouchedPath(stagedOriginState, path.resolve(sessionCwd, filePath));
			const jsonMessage = checkJsonFile(filePath, ctx?.cwd);
			if (jsonMessage) return { content: [...(event.content || []), { type: "text" as const, text: `\n\n${jsonMessage}` }] };
		}
		return undefined;
	});
}

// ═══ C14（十月迭代 M4，设计 §6.4）：base64 图像数据禁入模型 text 通道守卫（纯函数） ═══
// 背景：生图产物（宿主 generateImages image block 的 base64 data）只允许经落盘通道成为文件证据；
// 若 base64 拼进工具结果/回流等 text 通道直送模型，轻则爆上下文，重则模型把「看到 base64」当
// 「看到图」伪造视觉确认——设计 §6.4 明令禁止（「原始 base64 不入日志」，同理不入 text 通道）。
// 检测两形态：① data:image/<subtype>;base64,<payload> 数据 URI；② 裸长 base64 连缕（≥1024 字符，
// 含 MIME 76 列折行形态——检测前剥离换行）。短 base64（sha256 hex、短编码串）不命中——正常文本
// 零误伤。接线（Leader 串行合并，见 C14 报告）：生图工具 execute 返回文本与 tool_result 后处理
// 均过本检测器，命中即整段 redact/block；image-generation.ts 产出摘要已内置同源自检。

/** base64 裸连缕最小长度（≈768B 载荷；正常文本/摘要/sha256 hex 远低于此）。 */
export const IMAGE_BASE64_RUN_MIN = 1024;

const IMAGE_BASE64_DATA_URI_RE = /data:image\/[a-z0-9.+-]+;base64,[A-Za-z0-9+/=]{16,}/i;
const IMAGE_BASE64_LONG_RUN_RE = new RegExp(`[A-Za-z0-9+/]{${IMAGE_BASE64_RUN_MIN},}={0,2}`);
/** redact 专用：全局版 data URI 正则（多 URI 逐一全替换——F17 残留收口：无 g 只剥首段）。 */
const IMAGE_BASE64_DATA_URI_GLOBAL_RE = new RegExp(IMAGE_BASE64_DATA_URI_RE.source, "gi");
/** redact 专用：base64 字符与换行交错的连续块（折行形态原位定位——剥换行后总长达阈值即整块剥除）。
 *  与检测器 fold 口径一致：换行是唯一被折叠的字符，其它非 base64 字符天然断块；
 *  短列（如 32 列）折行单段 < 阈值但整块拼接后命中——本正则按块匹配不受列宽限制。 */
const IMAGE_BASE64_FOLD_BLOCK_RE = /[A-Za-z0-9+/=]+(?:[\r\n]+[A-Za-z0-9+/=]+)*/g;

export interface ImageBase64TextFinding {
	/** data-uri=数据 URI 形态；long-run=裸长连缕（含折行折叠后命中）。 */
	kind: "data-uri" | "long-run";
	/** 命中片段长度（字符）。 */
	matchedLength: number;
	/** 命中片段预览（首 24 字符，截断——预览本身不得携带可复原载荷）。 */
	preview: string;
}

/** 检测文本中的 base64 图像数据（命中返回事实；未命中 null）。纯函数零副作用。 */
export function findImageBase64InText(text: string): ImageBase64TextFinding | null {
	if (typeof text !== "string" || text.length === 0) return null;
	const uri = IMAGE_BASE64_DATA_URI_RE.exec(text);
	if (uri) return { kind: "data-uri", matchedLength: uri[0].length, preview: uri[0].slice(0, 24) };
	// 折行形态：MIME 76 列折行在剥离换行后成为连续 base64——检测口径与单行一致。
	const flattened = text.replace(/[\r\n]/g, "");
	const run = IMAGE_BASE64_LONG_RUN_RE.exec(flattened);
	if (run) return { kind: "long-run", matchedLength: run[0].length, preview: run[0].slice(0, 24) };
	return null;
}

/** 阻断 reason（工具结果/回流拼装处消费；命中即不得把原文送入模型 text 通道）。 */
export function assertNoImageBase64InText(text: string): string | null {
	const hit = findImageBase64InText(text);
	if (!hit) return null;
	return `[amagi 守卫] 检测到 base64 图像数据（${hit.kind}，首 24 字符「${hit.preview}…」，共 ${hit.matchedLength} 字符）禁止进入模型 text 通道——图像产物只允许经落盘通道（artifact 归档/显式路径+digest）成为证据；工具结果改引文件路径与 sha256，视觉确认需 luoshen/人工（机器不得凭 base64 字符串声称已看图）。`;
}

/** 剥除文本中的 base64 图像载荷并保留其余内容（F17：失败 text/error 净化——保留真实错误
 *  关键词/阶段，只剥图像载荷；与整段替换的 sanitize 策略互补）。F17 残留收口（增量复审）：
 *  ① data URI 全局替换（多 URI 全命中）；② 裸长连缀含任意列宽折行（折行拼接后达阈值即整块
 *  剥除——宁多剥不漏放）；③ 输出前强制复核——同源检测器仍命中时 fail-closed 整段净化
 *  （宁可丢失关键词也不放行载荷；审计/返回文本两条路径同强度）。 */
export function redactImageBase64InText(text: string): string {
	if (typeof text !== "string" || text.length === 0) return typeof text === "string" ? text : "";
	let out = text.replace(IMAGE_BASE64_DATA_URI_GLOBAL_RE, (m) => `[redacted: base64 图像数据 ${m.length} 字符]`);
	out = out.replace(IMAGE_BASE64_FOLD_BLOCK_RE, (m) => {
		const unfolded = m.replace(/[\r\n]/g, "");
		return unfolded.length >= IMAGE_BASE64_RUN_MIN ? `[redacted: base64 图像数据 ${m.length} 字符（折行折叠后 ${unfolded.length}）]` : m;
	});
	if (findImageBase64InText(out) !== null) {
		return `[redacted: base64 图像数据检测仍命中——整段 fail-closed 净化（原文 ${out.length} 字符）]`;
	}
	return out;
}
