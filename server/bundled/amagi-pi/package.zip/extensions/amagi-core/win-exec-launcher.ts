/**
 * win-exec-launcher.ts — supervised 模式的 PowerShell 启动脚本（进程树回收，ue-run.sh 的
 * Windows 侧等价物）。
 *
 * v2（diting 审核 M7/m3/m4）：
 *  - 载荷不再经 WSLENV 环境变量——base64 载荷**直接内嵌脚本文本**（`$raw = '<b64>'`；base64
 *    字符集 [A-Za-z0-9+/=] 无单引号，PS 单引号字符串零解释面），后台模式也因此无需把任何
 *    值拼进 shell 命令字符串。
 *  - M7：CreateJobObject/SetInformationJobObject/AssignProcessToJobObject 失败（false/Zero）
 *    必须 Write-Error + exit 91，绝不继续启动目标。
 *  - m4：载荷长度预检由调用方（win-exec.ts）执行；本模块保持纯生成/编解码。
 *
 * 注入安全：目标程序/参数/cwd/env 只存在于 base64(JSON) 内嵌载荷，绝不拼接进 powershell
 * 命令行——恶意参数（引号、$()、反引号、换行、中文）只是 JSON 字符串，无命令行解释面。
 * 参数在脚本内经 ProcessStartInfo.Arguments（Windows 标准引号规则，JS 侧预引号）传递。
 */

/** 启动载荷（JSON 字节面）。 */
export interface WinExecLauncherPayload {
	program: string;
	/** 预引号后的参数命令行（单字符串；由 buildArgumentsLine 生成）。 */
	argsLine: string;
	/** 工作目录（Windows 绝对路径；空串=不设置）。 */
	cwd: string;
	/** 附加环境变量（已过白名单；空对象=不设置）。 */
	env: Record<string, string>;
}

/** base64(UTF-8(JSON))——载荷通道（内嵌脚本）。 */
export function encodeLauncherPayload(payload: WinExecLauncherPayload): string {
	return Buffer.from(JSON.stringify(payload), "utf8").toString("base64");
}

/** 解码（测试与 doctor 往返断言用）。 */
export function decodeLauncherPayload(b64: string): WinExecLauncherPayload {
	return JSON.parse(Buffer.from(String(b64 ?? ""), "base64").toString("utf8")) as WinExecLauncherPayload;
}

/** m4：内嵌载荷上限（脚本行长度与 PS 解析安全边界）。 */
export const WINEXEC_PAYLOAD_MAX_B64 = 24_000;
/** m4：Windows 单命令行长度上限（CreateProcess lpCommandLine 32767 字符）。 */
export const WIN_COMMAND_LINE_MAX = 32_767;

/**
 * Windows 参数引号规则（CommandLineToArgvW 的逆）：空串 → ""；含空白/引号 → 包裹并对内部
 * 引号/尾部反斜杠做标准转义；其余原样。纯函数，充分单测（含空格、内嵌引号、反斜杠、中文）。
 */
export function windowsQuoteArg(arg: string): string {
	const raw = String(arg ?? "");
	if (raw === "") return '""';
	if (!/[\s"]/.test(raw)) return raw;
	let out = '"';
	let backslashes = 0;
	for (const ch of raw) {
		if (ch === "\\") { backslashes++; continue; }
		if (ch === '"') {
			out += "\\".repeat(backslashes * 2 + 1) + '"';
			backslashes = 0;
			continue;
		}
		out += "\\".repeat(backslashes);
		backslashes = 0;
		out += ch;
	}
	out += "\\".repeat(backslashes * 2);
	out += '"';
	return out;
}

/** 多参数 → 单条命令行（逐参数引号后空格连接；空参数表 → 空串）。 */
export function buildArgumentsLine(args: readonly string[]): string {
	return args.map((a) => windowsQuoteArg(a)).join(" ");
}

/**
 * 生成 launcher 脚本文本（.ps1）：内嵌 base64 载荷 → 建 Job(KILL_ON_JOB_CLOSE，失败 exit 91)
 * → 自身入 Job → 设 env/cwd → Process.Start(UseShellExecute=$false) → WaitForExit → 以目标
 * 退出码退出。脚本里不含任何未编码的用户参数字节。
 */
export function buildLauncherScript(payloadB64: string): string {
	const b64 = String(payloadB64 ?? "");
	if (b64 === "" || !/^[A-Za-z0-9+/=]+$/.test(b64)) throw new Error("buildLauncherScript: payload 须为非空 base64");
	return [
		"$ErrorActionPreference = 'Stop'",
		`$raw = '${b64}'`,
		"$payload = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($raw)) | ConvertFrom-Json",
		// Job Object：KILL_ON_JOB_CLOSE——relay（本 powershell）死亡即整树连带回收
		"Add-Type -TypeDefinition @'",
		"using System;",
		"using System.Runtime.InteropServices;",
		"public static class AmagiWinExecJob {",
		"  [DllImport(\"kernel32.dll\", SetLastError=true)] public static extern IntPtr CreateJobObject(IntPtr a, string n);",
		"  [DllImport(\"kernel32.dll\", SetLastError=true)] public static extern bool SetInformationJobObject(IntPtr h, int c, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION i, int cb);",
		"  [DllImport(\"kernel32.dll\", SetLastError=true)] public static extern bool AssignProcessToJobObject(IntPtr h, IntPtr p);",
		"  [DllImport(\"kernel32.dll\", SetLastError=true)] public static extern IntPtr GetCurrentProcess();",
		"  [StructLayout(LayoutKind.Sequential)] public struct JOBOBJECT_BASIC_LIMIT_INFORMATION {",
		"    public long PerProcessUserTimeLimit; public long PerJobUserTimeLimit; public uint LimitFlags;",
		"    public UIntPtr MinimumWorkingSetSize; public UIntPtr MaximumWorkingSetSize; public uint ActiveProcessLimit;",
		"    public UIntPtr Affinity; public uint PriorityClass; public uint SchedulingClass; }",
		"  [StructLayout(LayoutKind.Sequential)] public struct IO_COUNTERS {",
		"    public ulong ReadOperationCount; public ulong WriteOperationCount; public ulong OtherOperationCount;",
		"    public ulong ReadTransferCount; public ulong WriteTransferCount; public ulong OtherTransferCount; }",
		"  [StructLayout(LayoutKind.Sequential)] public struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {",
		"    public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation; public IO_COUNTERS IoInfo;",
		"    public UIntPtr ProcessMemoryLimit; public UIntPtr JobMemoryLimit; public UIntPtr PeakProcessMemoryUsed; public UIntPtr PeakJobMemoryUsed; }",
		"}",
		"'@",
		// M7：三步任一失败 → exit 91，绝不启动目标（半建 Job 的 relay 退出即回收自身，无泄漏面）
		"$job = [AmagiWinExecJob]::CreateJobObject([IntPtr]::Zero, $null)",
		"if ($job -eq [IntPtr]::Zero) { Write-Error 'CreateJobObject failed'; exit 91 }",
		"$info = New-Object AmagiWinExecJob+JOBOBJECT_EXTENDED_LIMIT_INFORMATION",
		"$info.BasicLimitInformation.LimitFlags = 0x2000 # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE",
		"$okSet = [AmagiWinExecJob]::SetInformationJobObject($job, 9, [ref]$info, [System.Runtime.InteropServices.Marshal]::SizeOf($info)) # 9 = JobObjectExtendedLimitInformation",
		"if (-not $okSet) { Write-Error 'SetInformationJobObject failed'; exit 91 }",
		"$okAssign = [AmagiWinExecJob]::AssignProcessToJobObject($job, [AmagiWinExecJob]::GetCurrentProcess())",
		"if (-not $okAssign) { Write-Error 'AssignProcessToJobObject failed'; exit 91 }",
		"if ($payload.env) { foreach ($p in $payload.env.PSObject.Properties) { [Environment]::SetEnvironmentVariable($p.Name, [string]$p.Value) } }",
		"$psi = New-Object System.Diagnostics.ProcessStartInfo",
		"$psi.FileName = [string]$payload.program",
		"$psi.Arguments = [string]$payload.argsLine",
		"if ($payload.cwd) { $psi.WorkingDirectory = [string]$payload.cwd }",
		"$psi.UseShellExecute = $false",
		"$child = [System.Diagnostics.Process]::Start($psi)",
		"$child.WaitForExit()",
		"exit $child.ExitCode",
	].join("\n");
}

/**
 * 恶意参数注入安全自检（纯函数，测试与 doctor 共用）：把任意 args 打包为载荷后，断言
 * ①载荷可无损往返；②脚本/命令行不含未编码的 args 原文（只有 base64 内嵌形态）。
 */
export function launcherPayloadSafetyProbe(args: readonly string[]): {
	ok: boolean;
	roundTrip: boolean;
	leakFree: boolean;
	encodedSample: string;
} {
	const payload: WinExecLauncherPayload = { program: "C:\\target app\\tool.exe", argsLine: buildArgumentsLine(args), cwd: "C:\\work dir", env: { K: "v" } };
	const encoded = encodeLauncherPayload(payload);
	const decoded = decodeLauncherPayload(encoded);
	const roundTrip = JSON.stringify(decoded) === JSON.stringify(payload);
	const script = buildLauncherScript(encoded);
	// 泄漏判定：args 原文（含引号/替换/换行的恶意形态）不得以未编码形态出现在脚本里
	const leakFree = args.every((a) => !a || (!script.includes(a) || script.includes(encoded)));
	return { ok: roundTrip && leakFree, roundTrip, leakFree, encodedSample: encoded };
}
