/**
 * cache-warming.ts — B8 宿主缓存保温策略（设计方案 §5.5，十月迭代 M3）。
 *
 * 定位（设计裁定）：**优先复用宿主默认保温**——pi 1.0.2 在 streaming 相位
 * （发起请求的 agent run 仍活跃，如 task_control wait 阻塞在工具调用内）以 P=1 的
 * continuation probability 自行做经济裁决（expectedSavings ≥ $0.05 才 warm），amagi 不
 * 重复建设这一层。pi 1.5.1 起宿主全局默认 cacheWarming 由 "streaming" 改为 "idle"（1.5.1 前
 * 默认仅 streaming 相位；idle 模式 = streaming 相位保温 + agent run 之间空闲保温至多 30 分钟，
 * CACHE_WARMING_MAX_IDLE_AGE_MS，仍受同一经济裁决约束）——delegate 策略下两者均不干预，
 * 成本面变化见下述「子进程空闲保温」。amagi 的新增价值是「限制无效保温 + 明确待机预算」：
 *
 *   1. 默认 delegate：idleStrategy 缺省 "delegate"，决策器恒返回 undefined（宿主决策原样
 *      生效，含用户 off——mode=off 时宿主根本不启动 warming run，事件不会到达）。
 *   2. 显式 managed（amagi.json cacheWarming 节）后只在 idle 相位干预：
 *      - 「amagi 已知将长等待/长验证」的在窗 lease（task_control wait 未决期 / handle 后台
 *        任务运行期 / finalizer 基线验证期）→ 返回 warm——宿主 idle 相位固定采 P=0.15
 *        （宿主实测口径；pi 1.5.1 起常量迁至 pi-ai cache-warming.ts CACHE_WARMING_IDLE_CONTINUATION_PROBABILITY
 *        =0.15，pi-coding-agent cache-warmer 不再自行导出），对 amagi 已知
 *        续跑将到的窗口过悲观，amagi 以 lease 置信概率重算期望节省后覆盖；
 *      - 无在窗 lease / 预算到期 / 会话切换 → 返回 stop（限制无效保温与待机预算兑底）；
 *      - 事件经济字段不可计算（NaN/负值）或期望节省低于阈值 → undefined（delegate——
 *        「事件字段不足以判断时继续 delegate，不猜测内部字段」）。
 *
 * 宿主 1.0.2 事件语义（docs/extensions.md cache_warming_decision 节 + dist types 核实）：
 *   - 事件在**每次保温刷新前**触发，载荷 {warmCost, missCost, continuationProbability,
 *     action}（无 phase 字段——相位由 ctx.isIdle() 在运行时判别：streaming 相位=agent run
 *     活跃；idle 相位=agent 已 settled 且宿主全局 settings cacheWarming="idle"）；
 *   - handler 返回 {action:"warm"|"stop"} 覆盖宿主决策（**最后一个返回 action 的 handler
 *     获胜**——多扩展组合的覆盖关系是宿主文档明示语义，本模块不试图争抢），返回
 *     undefined=接受宿主决策；
 *   - "stop" 终止本轮 warming（直到下一个真实请求重启）；handler 抛错宿主捕获并回落
 *     自身决策——本模块仍自兜 try/catch（失败→undefined+诊断，不依赖宿主容错）。
 *
 * 与 B9（agent_before_settle 续跑裁决）的非竞态论证（设计 §3 交叉项）：
 *   agent_before_settle 只在 agent run 收尾（settle 之前）触发，此刻宿主 warming run 仍处
 *   streaming 相位（相位迁移发生在 agent_settled 之后的 onAgentSettled）——本决策器在
 *   streaming 相位恒返回 undefined（不干预），即 B9 裁决窗口内保温决策完全归宿主；idle 相位
 *   事件只可能在 agent_settled 之后到达，时序上与 agent_before_settle 严格不重叠。若 B9
 *   裁决 continue:true，新一轮 run 启动 → 相位回 streaming → 本决策器继续不干预。两套
 *   handler 永远不会作用于同一相位的同一 warming run，无竞态面。
 *
 * lease 语义（设计：「lease 以 session generation + 真实工作 ID 关联，finally 清理；并发
 * 任务全部结束才结束等待状态」）：
 *   - lease 键 = 真实工作 ID（taskId / `verify:${taskId}`），值含 kind 与 startedAt；
 *     begin 对已存在键**刷新 startedAt**（每次显式 wait/验证起点 = 新的单次等待窗口）；
 *   - 等待状态 = 在窗 lease 集合非空：task_control wait 超时返回后未决任务的 lease 保留
 *     （后台任务仍在跑=真实 idle 保温窗口），完成通知/取消/resolve-external/budget 到期
 *     收口；多任务 lease 全部收口才进入「无在窗 lease → stop」；
 *   - resetCacheWarmingSession() 在会话启动/关闭/切换时 generation+1 并清空全部 lease
 *     （旧 generation 的 lease 不跨会话存活——接线补丁把该函数挂到 session_start/
 *     session_shutdown）；
 *   - 每个窗口受单次 idle 等待预算约束（idleBudgetMs，默认 10 分钟——设计提议的试点
 *     策略值，非宿主默认），到期后的决策返回 stop 并一次性记录提示诊断。
 *
 * 失败语义：决策器永不抛错（内部异常→undefined+诊断记录）；lease 收口幂等（重复 end 无
 * 副作用）；保温请求本身的成败由宿主 CacheWarmer 管理（warm 请求失败不重试不阻断任务链，
 * 宿主 validateRun 自然收口）。
 *
 * 子进程空闲保温成本面（pi 1.5.1 起宿主默认 idle）：cacheWarming 是宿主全局 settings 项，
 * 派生子进程同样读全局设置。JSON 子进程（--mode json -p）在 agent settle 后由
 * child-settle-exit 自退（缺省 1500ms，见 child-settle-exit.ts）——空闲保温窗口可忽略；
 * RPC 常驻 worker 空闲期（池 idleTimeoutMs 缺省 5 分钟）会按宿主经济裁决做空闲保温（至多
 * 30 分钟与池空闲超时取小）——同一 worker 续跑同会话时保温自付，跨任务换会话时宿主 start()
 * 替换旧 warming run，不叠加。限制空闲保温面用 amagi.json cacheWarming.idleStrategy=managed
 * （无在窗 lease → stop），或在宿主全局 settings 把 cacheWarming 显式设回 "streaming"。
 *
 * 配置（amagi 既有体系增量区：amagi.json `cacheWarming` 节，全局
 * <PI_CODING_AGENT_DIR||~/.pi/agent>/amagi.json 打底、项目 <cwd>/amagi.json 覆盖，mtime
 * 缓存——与 decision 节同模式；**不发明临时环境变量**）：
 *   { "idleStrategy": "delegate" | "managed",   // 缺省 delegate（默认不干预）
 *     "idleBudgetMs": 600000,                    // 单次 idle 等待预算（试点策略值）
 *     "minExpectedSavingsUsd": 0.05,             // 期望节省阈值（对齐宿主 $0.05 口径）
 *     "leaseContinuationProbability": 0.9 }      // lease 在窗时 amagi 采信的续跑概率
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

// ── 类型（宿主事件/上下文的最小结构面——不 import pi dist，保持模块独立可测）────────

/** 宿主保温决策事件的公开载荷字段（cache-warmer.d.ts CacheWarmingDecisionEvent）。 */
export interface CacheWarmingDecisionEventInput {
	readonly warmCost: number;
	readonly missCost: number;
	readonly continuationProbability: number;
	readonly action: "warm" | "stop";
}

/** 决策上下文的最小结构面（ExtensionContext 的 isIdle/cwd 子集）。 */
export interface CacheWarmingDecisionContext {
	isIdle(): boolean;
	readonly cwd?: string;
}

export type CacheWarmingAction = "warm" | "stop";
export type CacheWarmingDecisionResult = { action: CacheWarmingAction } | undefined;

export type CacheWarmingLeaseKind = "wait" | "background" | "verify";

export interface CacheWarmingLeaseView {
	workId: string;
	kind: CacheWarmingLeaseKind;
	startedAt: number;
}

export interface CacheWarmingDiagnostic {
	ts: number;
	/** streaming=事件到达时 agent run 活跃；idle=已 settled。 */
	phase: "streaming" | "idle" | "unknown";
	hostAction: CacheWarmingAction | "unknown";
	/** 决策器返回：warm/stop=覆盖注入；delegate=返回 undefined。 */
	decision: "warm" | "stop" | "delegate";
	leaseCount: number;
	detail?: string;
}

// ── 配置（amagi.json cacheWarming 节；全局打底、项目覆盖、mtime 缓存）────────────

export interface CacheWarmingConfig {
	idleStrategy: "delegate" | "managed";
	idleBudgetMs: number;
	minExpectedSavingsUsd: number;
	leaseContinuationProbability: number;
}

const CACHE_WARMING_DEFAULTS: CacheWarmingConfig = {
	idleStrategy: "delegate",
	idleBudgetMs: 600_000,
	minExpectedSavingsUsd: 0.05,
	leaseContinuationProbability: 0.9,
};

const MAX_DIAGNOSTICS = 32;

function globalAmagiConfigPath(): string {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi.json");
}

const configCache = new Map<string, { mtimeMs: number; cfg: CacheWarmingConfig }>();
let injectedConfig: CacheWarmingConfig | null | undefined;

/** 测试注入：固定配置（null 恢复读盘路径；undefined 复位为未注入）。 */
export function _setCacheWarmingConfigForTest(cfg: CacheWarmingConfig | null | undefined): void {
	configCache.clear();
	injectedConfig = cfg === null ? null : cfg;
}

function mergeCacheWarmingSection(base: CacheWarmingConfig, raw: unknown): CacheWarmingConfig {
	if (!raw || typeof raw !== "object") return base;
	const o = raw as Record<string, unknown>;
	const next: CacheWarmingConfig = { ...base };
	if (o.idleStrategy === "delegate" || o.idleStrategy === "managed") next.idleStrategy = o.idleStrategy;
	if (typeof o.idleBudgetMs === "number" && o.idleBudgetMs >= 1_000) next.idleBudgetMs = Math.floor(o.idleBudgetMs);
	if (typeof o.minExpectedSavingsUsd === "number" && o.minExpectedSavingsUsd >= 0) next.minExpectedSavingsUsd = o.minExpectedSavingsUsd;
	if (typeof o.leaseContinuationProbability === "number" && o.leaseContinuationProbability > 0 && o.leaseContinuationProbability <= 1) {
		next.leaseContinuationProbability = o.leaseContinuationProbability;
	}
	// 宽松解析：未知键忽略（前向兼容，与 decision 节同口径）
	return next;
}

function readCacheWarmingSection(file: string): unknown | null {
	try {
		const json = JSON.parse(fs.readFileSync(file, "utf8")) as unknown;
		return json && typeof json === "object" && "cacheWarming" in json ? (json as Record<string, unknown>).cacheWarming : null;
	} catch { /* lint-exempt:配置节缺失/不可解析=无该节，回退链继续（与 decision 节同口径） */
		return null;
	}
}

export function loadCacheWarmingConfig(cwd?: string): CacheWarmingConfig {
	if (injectedConfig !== undefined && injectedConfig !== null) return injectedConfig;
	if (injectedConfig === null) return CACHE_WARMING_DEFAULTS;
	const files = [globalAmagiConfigPath()];
	if (cwd) files.push(path.join(cwd, "amagi.json"));
	const cacheKey = files.join("|");
	let mtimeMs = 0;
	for (const f of files) {
		try { mtimeMs = Math.max(mtimeMs, Math.floor(fs.statSync(f).mtimeMs)); } catch { /* lint-exempt:文件不存在=mtime 无贡献，缓存链自然失效 */ }
	}
	const cached = configCache.get(cacheKey);
	if (cached && cached.mtimeMs === mtimeMs) return cached.cfg;
	let cfg = CACHE_WARMING_DEFAULTS;
	for (const f of files) {
		const section = readCacheWarmingSection(f);
		if (section !== null) cfg = mergeCacheWarmingSection(cfg, section);
	}
	configCache.set(cacheKey, { mtimeMs, cfg });
	return cfg;
}

// ── lease 登记（session generation + 真实工作 ID；并发全部结束才结束等待状态）────

interface LeaseEntry extends CacheWarmingLeaseView {
	generation: number;
	/** 预算到期提示是否已记录（一次性诊断标记）。 */
	expiryNoted: boolean;
}

let leaseGeneration = 1;
const leases = new Map<string, LeaseEntry>();
const diagnostics: CacheWarmingDiagnostic[] = [];

function recordDiagnostic(d: CacheWarmingDiagnostic): void {
	diagnostics.push(d);
	if (diagnostics.length > MAX_DIAGNOSTICS) diagnostics.splice(0, diagnostics.length - MAX_DIAGNOSTICS);
}

/**
 * 开窗/刷新窗：amagi 已知将长等待（task_control wait / handle 后台任务）或长验证
 * （finalizer 基线验证）时调用。对已存在键刷新 startedAt（每次显式起点 = 新的单次
 * 等待窗口，预算重计）。幂等。
 */
export function beginCacheWarmingLease(workId: string, kind: CacheWarmingLeaseKind = "wait"): void {
	if (typeof workId !== "string" || workId === "") return;
	leases.set(workId, { workId, kind, startedAt: Date.now(), generation: leaseGeneration, expiryNoted: false });
}

/** 收窗（完成通知/取消/resolve-external/验证 finally）。幂等：不存在即无操作。 */
export function endCacheWarmingLease(workId: string): void {
	if (typeof workId !== "string") return;
	leases.delete(workId);
}

/** 会话切换/关闭：generation+1 并清空全部 lease（旧会话窗口不跨代存活）。幂等。 */
export function resetCacheWarmingSession(): void {
	leaseGeneration += 1;
	leases.clear();
}

/** 在窗 lease 只读快照（状态展示/测试观测）。 */
export function cacheWarmingLeaseSnapshot(): readonly CacheWarmingLeaseView[] {
	return [...leases.values()].map(({ workId, kind, startedAt }) => ({ workId, kind, startedAt }));
}

/** 有界诊断环形缓冲只读快照（最新在后）。 */
export function cacheWarmingDiagnostics(): readonly CacheWarmingDiagnostic[] {
	return [...diagnostics];
}

/** 在窗且未超预算的 lease 判定；全部超预算时一次性记录提示诊断。 */
function activeLeaseCount(now: number, budgetMs: number): number {
	let active = 0;
	for (const lease of leases.values()) {
		if (now - lease.startedAt <= budgetMs) {
			active += 1;
		} else if (!lease.expiryNoted) {
			lease.expiryNoted = true;
			recordDiagnostic({
				ts: now, phase: "idle", hostAction: "unknown", decision: "stop", leaseCount: 0,
				detail: `idle 等待预算到期（${lease.workId} 已 ${Math.round((now - lease.startedAt) / 1000)}s > ${Math.round(budgetMs / 1000)}s）——保温窗口收口，回到宿主默认`,
			});
		}
	}
	return active;
}

/** 事件经济字段可计算性（NaN/负值/缺省视为不可计算——不猜测内部字段）。 */
function economicsComputable(event: CacheWarmingDecisionEventInput): boolean {
	return Number.isFinite(event.warmCost) && Number.isFinite(event.missCost)
		&& Number.isFinite(event.continuationProbability)
		&& event.warmCost >= 0 && event.missCost >= 0
		&& event.continuationProbability >= 0 && event.continuationProbability <= 1;
}

/**
 * 核心决策（纯函数面；now 可注入供测试）。永不抛错——内部异常按「失败不阻塞」回落
 * delegate（undefined）并记录诊断。
 *
 * 决策表（§文件头）：streaming→delegate；delegate 策略→delegate；无在窗 lease→stop；
 * 预算耗尽→stop；字段不可计算→delegate；期望节省（lease 置信概率重算）≥ 阈值→warm；
 * 低于阈值→delegate（交宿主自身经济裁决）。
 */
export function decideCacheWarming(
	event: CacheWarmingDecisionEventInput,
	ctx: CacheWarmingDecisionContext,
	now: number = Date.now(),
): CacheWarmingDecisionResult {
	let phase: CacheWarmingDiagnostic["phase"] = "unknown";
	let hostAction: CacheWarmingDiagnostic["hostAction"] = "unknown";
	try {
		hostAction = event.action === "warm" || event.action === "stop" ? event.action : "unknown";
		phase = ctx.isIdle() ? "idle" : "streaming";
		if (phase === "streaming") {
			// 复用宿主默认 streaming 保温（P=1 经济裁决）；B9 settle 边界同窗不竞态（文件头论证）
			recordDiagnostic({ ts: now, phase, hostAction, decision: "delegate", leaseCount: 0, detail: "streaming 相位——宿主默认保温，不干预" });
			return undefined;
		}
		const cfg = loadCacheWarmingConfig(ctx.cwd);
		if (cfg.idleStrategy !== "managed") {
			recordDiagnostic({ ts: now, phase, hostAction, decision: "delegate", leaseCount: leases.size, detail: "idleStrategy=delegate——默认不干预" });
			return undefined;
		}
		const active = activeLeaseCount(now, cfg.idleBudgetMs);
		if (active === 0) {
			recordDiagnostic({ ts: now, phase, hostAction, decision: "stop", leaseCount: 0, detail: leases.size > 0 ? "全部 lease 超预算——待机预算兑底" : "无在窗 lease——限制无效 idle 保温" });
			return { action: "stop" };
		}
		if (!economicsComputable(event)) {
			recordDiagnostic({ ts: now, phase, hostAction, decision: "delegate", leaseCount: active, detail: "事件经济字段不可计算——不猜测内部字段" });
			return undefined;
		}
		const effectiveProbability = Math.max(event.continuationProbability, cfg.leaseContinuationProbability);
		const expectedSavings = effectiveProbability * event.missCost - event.warmCost;
		if (expectedSavings >= cfg.minExpectedSavingsUsd) {
			recordDiagnostic({
				ts: now, phase, hostAction, decision: "warm", leaseCount: active,
				detail: `在窗 lease ${active} 个——期望节省 $${expectedSavings.toFixed(4)} ≥ $${cfg.minExpectedSavingsUsd}（P_eff=${effectiveProbability.toFixed(2)}）`,
			});
			return { action: "warm" };
		}
		recordDiagnostic({ ts: now, phase, hostAction, decision: "delegate", leaseCount: active, detail: `期望节省 $${expectedSavings.toFixed(4)} < $${cfg.minExpectedSavingsUsd}——交宿主经济裁决` });
		return undefined;
	} catch (e) {
		// 失败不阻塞任务链：回落 delegate 并记录诊断（宿主对 handler 抛错同样回落自身决策）
		recordDiagnostic({ ts: now, phase, hostAction, decision: "delegate", leaseCount: 0, detail: `决策器内部异常→delegate：${e instanceof Error ? e.message : String(e)}`.slice(0, 200) });
		return undefined;
	}
}

/**
 * pi.on("cache_warming_decision") handler 适配器（接线补丁消费；探针与测试直接消费）。
 * 返回值类型即宿主 CacheWarmingDecisionEventResult（{action} 覆盖 / undefined 接受）。
 */
export function createCacheWarmingDecisionHandler(): (event: CacheWarmingDecisionEventInput, ctx: CacheWarmingDecisionContext) => CacheWarmingDecisionResult {
	return (event, ctx) => decideCacheWarming(event, ctx);
}

/** 测试隔离复位（lease/诊断/代数/配置注入全部还原）。 */
export function resetCacheWarmingForTest(): void {
	leaseGeneration = 1;
	leases.clear();
	diagnostics.length = 0;
	configCache.clear();
	injectedConfig = undefined;
}
