/**
 * continuation.ts — 压缩成功后、下一轮 system prompt 的保真摘要。
 * dist 证据：session_before_compact 只能候选；session_compact 才代表 entry 已落盘。
 *
 * B9（设计方案 §5.6，pi 1.0.2 迭代）：最终续跑裁决迁 agent_before_settle（真实 1.0.2 子进程
 * 探针证据见 tests/pi-102-b9-boundary-probe.mjs 与报告）：
 *   - turn_end 降级为观测（积累已发生的信号，不发 continue）；
 *   - agent_before_settle 重读当前待续跑条件（压缩存活 pending 为主因），排除用户取消/
 *     shutdown/blocked 待答/已发终态/失效 generation/无新信息重复条件后，经宿主边界返回链
 *     追加 custom_message 条目并 continue:true 恰一次（令牌消费 + 预算双保险）；
 *   - 宿主 <0.87.0 无该事件：维持 legacy 行为（session_compact willRetry steer 注入 +
 *     before_agent_start 消费），不做边界裁决——单一路径，不新旧双订阅。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import type { ExtensionAPI, SessionBoundaryDraft } from "@earendil-works/pi-coding-agent";
import { registry, isTerminalStatus, type TaskRecord } from "./task-registry.ts";
import { amagiDataFile } from "./data-dir.ts";
import { capabilityEnabledByVersion, detectHostPackageVersion } from "./host-capabilities.ts";
import { getLeaderSessionStamp, peekTaskKernel, queryTaskViews } from "./task-service.ts";
import type { TaskView } from "./contracts/task.ts";

interface Candidate {
	sessionKey: string;
	reason: string;
	summary: string;
}

interface Pending {
	sessionKey: string;
	summary: string;
}

export interface ContinuationState {
	stage(sessionKey: string, reason: string, summary: string): void;
	confirm(sessionKey: string, reason: string): string | null;
	consume(sessionKey: string): string | null;
	/** 8月迭代 pi-0.84 配合 P1③：压缩失败时作废已 stage 的候选（防下次 confirm 误匹配陈旧摘要）。 */
	discard(sessionKey: string): void;
	reset(sessionKey?: string): void;
	/** reset 后所有已开始的异步消费失效；可选以兼容仅提供 consume 的旧测试桩。 */
	getEpoch?(): number;
	inspect(): { sessionKey: string | null; hasCandidate: boolean; hasPending: boolean };
}

export function createContinuationState(): ContinuationState {
	let activeSessionKey: string | null = null;
	let candidate: Candidate | null = null;
	let pending: Pending | null = null;
	let epoch = 0;
	return {
		stage(sessionKey, reason, summary) {
			activeSessionKey = sessionKey;
			candidate = { sessionKey, reason, summary };
			pending = null;
		},
		confirm(sessionKey, reason) {
			if (!candidate || candidate.sessionKey !== sessionKey || candidate.reason !== reason) return null;
			pending = { sessionKey, summary: candidate.summary };
			candidate = null;
			return pending.summary;
		},
		consume(sessionKey) {
			if (!pending || pending.sessionKey !== sessionKey) return null;
			const summary = pending.summary;
			pending = null;
			return summary;
		},
		discard(sessionKey) {
			// 8月迭代 pi-0.84 配合 P1③：仅作废同 session 的候选；pending 属于已成功压缩的
			// 待消费摘要（下次 before_compact 的 stage 会先行清理），此处不越权触碰。
			if (candidate && candidate.sessionKey === sessionKey) candidate = null;
		},
		reset(sessionKey) {
			epoch += 1;
			activeSessionKey = sessionKey || null;
			candidate = null;
			pending = null;
		},
		getEpoch() { return epoch; },
		inspect() { return { sessionKey: activeSessionKey, hasCandidate: !!candidate, hasPending: !!pending }; },
	};
}

function sessionKey(ctx: any): string {
	return String(ctx?.sessionManager?.getSessionFile?.() || ctx?.sessionManager?.getSessionId?.() || "unknown-session");
}
function bounded(value: string | undefined, max = 300): string {
	if (!value) return "(未记录)";
	const chars = Array.from(value.replace(/\s+/g, " ").trim());
	return chars.length <= max ? chars.join("") : `${chars.slice(0, max).join("")}…`;
}

// ── B9（设计方案 §5.6）：agent_before_settle 最终续跑裁决 ────────────────────
// 事件证据（真实 pi 1.0.2 子进程探针，tests/pi-102-b9-boundary-probe.mjs）：
//   时序 turn_end#1 → compaction_start/end(threshold, willRetry=false) → agent_before_settle#1
//   → entry_appended（边界草案提交）→ agent_start#2（续跑 run）→ turn_end#2 →
//   agent_before_settle#2 → agent_settled（恰一次，在续跑之后）；退出码 0。
//   载荷 keys={type,entries[],continue,context{canContinue,contextEntries,contextMessages,
//   llmMessages,pendingMessages},outcome}；动作效果：{entries:[...e.entries,draft],continue:true}
//   → 恰一次后续 provider 请求且消息含注入条目文本；宿主将 custom_message 投影为 user 角色
//   （finalRole≠assistant → canContinue 成立，agent.continue() 合法）。注：agent_before_settle
//   是 extension-runner 域事件，不经宿主 _emit 进 json 流（agent_settled 才双发）。

/** 边界续跑验收关键词（设计方案 §5.6 验收：后续请求含 CONTINUATION_ONCE）。 */
export const BOUNDARY_CONTINUE_KEYWORD = "CONTINUATION_ONCE";

/** 每会话 generation 的边界续跑预算（无件循环保险：新压缩才生新令牌，预算另封顶）。 */
export const BOUNDARY_CONTINUE_BUDGET = 3;

/** agent_before_settle 引入版本（0.87.0）权威源已迁 host-capabilities CAPABILITY_FACTS
 * （agentBeforeSettleBoundary，B9 跟进）；本常量为该表 since 的镜像导出，仅供日志/文档引用，
 * 判定一律走 boundaryAdjudicationEnabled（capabilityEnabledByVersion 口径）。 */
export const AGENT_BEFORE_SETTLE_SINCE = "0.87.0";

/** 版本门：宿主 ≥0.87.0 才启用边界裁决（单一路径；旧宿主维持 legacy 行为，不双订阅）。
 * B9 跟进：从硬编码 compareVersions 切到 host-capabilities 版本表口径（capabilityEnabledByVersion
 * 对 version-table 条目即 since 比较——行为等价：null/空版本保守拒绝，未知能力名 false）。 */
export function boundaryAdjudicationEnabled(version: string | null | undefined): boolean {
	return capabilityEnabledByVersion("agentBeforeSettleBoundary", version);
}

/** turn_end 观测信号（已发生事实的积累，不承载裁决）。 */
export interface BoundaryTurnSignal {
	outcome: string;
	turnIndex?: number;
	/** 末轮 assistant 文本尾栈（有界；终态标记检测用）。 */
	lastAssistantTail: string;
}

/** 裁决拒绝原因（日志/测试观测面；不反哺行为）。 */
export type BoundarySkipReason =
	| "no-signal"
	| "outcome-not-completed"
	| "ui-wait-pending"
	| "terminal-marker-seen"
	| "no-pending-summary"
	| "budget-exhausted";

export interface BoundaryDecision {
	/** continue = 经宿主返回链请求恰一次下一次模型调用。 */
	entries: SessionBoundaryDraft[];
	continue: true;
	reason: string;
}

/** 续跑注入条目内容（验收关键词 + 摘要 + 有界行为指引）。 */
export function boundaryContinuationContent(summary: string): string {
	return `[amagi 压缩存活 · ${BOUNDARY_CONTINUE_KEYWORD}]（settle 前一次性续跑注入：压缩后的任务/blocked/artifact 状态见下。如无待续工作，以一行确认收尾，不展开新工作。）\n${summary}`;
}

/** 从 turn_end 事件提取有界观测信号（消息防御读取；旧宿主字段缺失返回 null）。 */
export function extractTurnSignal(event: any): BoundaryTurnSignal | null {
	if (!event || typeof event !== "object") return null;
	const outcome = String(event.outcome || "unknown");
	if (outcome === "unknown" && event.turnIndex === undefined && !event.message) return null;
	const parts: string[] = [];
	const content = event?.message?.content;
	if (Array.isArray(content)) {
		for (const p of content) if (p?.type === "text" && typeof p.text === "string") parts.push(p.text);
	} else if (typeof content === "string") parts.push(content);
	return {
		outcome,
		turnIndex: typeof event.turnIndex === "number" ? event.turnIndex : undefined,
		lastAssistantTail: parts.join("").slice(-2048),
	};
}

/** 子 Agent 终态/阻塞标记（已发终态门：标记在则不再续跑——终稿已交付，续跑只烧预算）。 */
const TERMINAL_MARKERS = [/<!--AMAGI:DONE-->/, /<!--AMAGI:BLOCKED-->/];

export interface BoundaryAdjudicator {
	/** turn_end 观测积累（所有宿主安全：返回 void，不发 continue）。 */
	noteTurnEnd(event: any): void;
	/** ui_prompt_start/end 配对（blocked/待用户回答门）。 */
	noteUiPrompt(start: boolean): void;
	/** 会话代次推进（session_start/shutdown；旧令牌失效 + 预算重置）。 */
	noteGenerationBump(): void;
	/** agent_before_settle 裁决：返回 continue 决策或 undefined（观测面附 skipReason）。 */
	adjudicate(event: any, sessionKeyNow: string): BoundaryDecision | undefined;
	/** 观测（测试/看板）：代次、信号、预算、续跑计数与最近拒绝原因。 */
	inspect(): {
		generation: number;
		budgetLeft: number;
		continuations: number;
		uiWaitPending: boolean;
		lastSkip: BoundarySkipReason | null;
	};
}

export interface BoundaryAdjudicatorDeps {
	/** 裁决日志落盘文件（测试注入；缺省 amagiDataFile("continuation-boundary.log")）。 */
	logFile?: string;
	/** 续跑预算（测试注入；缺省 BOUNDARY_CONTINUE_BUDGET）。 */
	budget?: number;
}

export function createBoundaryAdjudicator(state: ContinuationState, deps: BoundaryAdjudicatorDeps = {}): BoundaryAdjudicator {
	const budget = deps.budget ?? BOUNDARY_CONTINUE_BUDGET;
	let generation = 1;
	let lastTurn: BoundaryTurnSignal | null = null;
	let uiWaitDepth = 0;
	let budgetLeft = budget;
	let continuations = 0;
	let lastSkip: BoundarySkipReason | null = null;

	function appendDecisionLog(line: string): void {
		// 有界决策日志（仅续跑决策落盘；watchdog.ts 同款尾部护栏）
		try {
			const file = deps.logFile ?? amagiDataFile("continuation-boundary.log");
			fs.mkdirSync(path.dirname(file), { recursive: true });
			try {
				const st = fs.statSync(file);
				if (st.size > 256 * 1024) {
					const tail = fs.readFileSync(file, "utf8").slice(-128 * 1024);
					fs.writeFileSync(file, tail, "utf8");
			}
			} catch { /* lint-exempt:文件不存在 */ }
			fs.appendFileSync(file, line + "\n", "utf8");
		} catch { /* lint-exempt:日志失败不阻断裁决 */ }
	}

	return {
		noteTurnEnd(event) { const s = extractTurnSignal(event); if (s) lastTurn = s; },
		noteUiPrompt(start) {
			uiWaitDepth = Math.max(0, uiWaitDepth + (start ? 1 : -1));
			if (uiWaitDepth === 0) lastSkip = null;
		},
		noteGenerationBump() {
			generation += 1;
			lastTurn = null;
			uiWaitDepth = 0;
			budgetLeft = budget;
		},
		adjudicate(event, sessionKeyNow) {
			// 门 1：无已发生信号（本 generation 从未观测 turn）→ 不裁（防止空转续跑）
			if (!lastTurn) { lastSkip = "no-signal"; return undefined; }
			// 门 2：用户取消/错误轮（outcome≠completed）→ 不续跑
			if (lastTurn.outcome !== "completed" || String(event?.outcome || "") !== "completed") {
				lastSkip = "outcome-not-completed";
				return undefined;
			}
			// 门 3：blocked/待用户回答（扩展 UI 提示在等待）→ 不续跑
			if (uiWaitDepth > 0) { lastSkip = "ui-wait-pending"; return undefined; }
			// 门 4：已发终态（终稿含 DONE/BLOCKED 标记）→ 不续跑
			const turn = lastTurn;
			if (TERMINAL_MARKERS.some((re) => re.test(turn.lastAssistantTail))) {
				lastSkip = "terminal-marker-seen";
				return undefined;
			}
			// 门 5：循环预算（同 generation 连续边界续跑封顶；新压缩生新令牌也受总预算约束）——
			// 门序裁定（diting F4）：预算检查先于 consume——耗尽时保真摘要不被作废丢弃（防循环由预算门
			// 自身保证，非靠 consume-and-discard；摘要保留至 generation 重置自然失效）。
			if (budgetLeft <= 0) {
				lastSkip = "budget-exhausted";
				appendDecisionLog(`${new Date().toISOString()} SKIP gen=${generation} reason=budget-exhausted（摘要保留未作废，防循环由预算门保证）`);
				return undefined;
			}
			// 门 6：无待续跑条件（压缩存活 pending 不存在/已消费/跨会话失效——consume 单次消费即令牌）
			const summary = state.consume(sessionKeyNow);
			if (!summary) { lastSkip = "no-pending-summary"; return undefined; }
			budgetLeft -= 1;
			continuations += 1;
			const draft: SessionBoundaryDraft = {
				type: "custom_message",
				customType: "amagi:compact-continuation",
				content: boundaryContinuationContent(summary),
				display: false,
			};
			const reason = `compact-survival gen=${generation} seq=${continuations}`;
			appendDecisionLog(`${new Date().toISOString()} CONTINUE gen=${generation} ${reason} budgetLeft=${budgetLeft}`);
			return { entries: [...(Array.isArray(event?.entries) ? event.entries : []), draft], continue: true, reason };
		},
		inspect() {
			return { generation, budgetLeft, continuations, uiWaitPending: uiWaitDepth > 0, lastSkip };
		},
	};
}
// ── ev-20260904 复盘 §5④：压缩保真块附带工具统计快照 ──
// 实战痛点：全天多段会话的复盘统计只能覆盖压缩后段（155 次 vs 全天），压缩丢掉的正是
// 前段调用分布。工具计数随进程累计（session_start 重置），压缩时落进保真块，复盘数据完整。
// 有界：最多列 8 类工具，溢出显式标注，不影响保真块预算主体。
interface ToolCallCount { calls: number; errors: number; }
const toolCallStats = new Map<string, ToolCallCount>();
const TOOL_STATS_MAX_TOOLS = 8;

/** 工具调用计数（tool_result 事件驱动；isError 按事件标志累计失败数）。 */
export function noteToolCall(toolName: string, isError: boolean): void {
	const key = toolName || "unknown";
	const entry = toolCallStats.get(key) || { calls: 0, errors: 0 };
	entry.calls += 1;
	if (isError) entry.errors += 1;
	toolCallStats.set(key, entry);
}

/** 清零（session_start 重置，与保真状态同生命周期）。 */
export function resetToolCallStats(): void {
	toolCallStats.clear();
}

function toolStatsSummary(): string | null {
	if (!toolCallStats.size) return null;
	const rows = [...toolCallStats.entries()].sort((a, b) => b[1].calls - a[1].calls);
	const total = rows.reduce((sum, [, v]) => sum + v.calls, 0);
	const totalErrors = rows.reduce((sum, [, v]) => sum + v.errors, 0);
	const top = rows.slice(0, TOOL_STATS_MAX_TOOLS)
		.map(([name, v]) => `${name} ${v.calls}${v.errors ? `（错 ${v.errors}）` : ""}`)
		.join(" / ");
	const overflow = rows.length > TOOL_STATS_MAX_TOOLS ? ` … 另 ${rows.length - TOOL_STATS_MAX_TOOLS} 类` : "";
	return `工具统计（本进程累计 ${total} 次${totalErrors ? `，失败 ${totalErrors}` : ""}）：${top}${overflow}`;
}

/** 编排进度终态计数表（与 task-registry TERMINAL 一致；静态查表避免反向依赖）。 */
/** runId 编排进度摘要上限：组数 / 每组节点数（压缩保真预算有界，溢出显式标注）。 */
const MAX_ORCH_GROUPS = 3;
const MAX_ORCH_NODES = 8;
const MAX_CONTINUATION_TASKS = 8;

/** 从 registry 生成四要素：真实目标、活跃任务（running+queued）、blocked 问题、真实 artifact；v2: +runId 编排进度。 */
export function generateContinuationSummary(tasks: readonly Readonly<TaskRecord>[] = registry.list()): string {
	const lines: string[] = ["[amagi 压缩保真]"];
	if (tasks.length === 0) {
		lines.push("（无活跃或近期任务）");
		// ev-20260904 §5④：无任务会话也保留工具统计（复盘数据完整性）
		const idleStats = toolStatsSummary();
		if (idleStats) lines.push(`\n${idleStats}`);
		return lines.join("\n");
	}

	// v2 批次C：queued（准入排队中）纳入在途——排队是真实在途状态，压缩后必须保真。
	const active = tasks.filter((task) => task.status === "running" || task.status === "queued");
	if (active.length) {
		lines.push(`\n进行中子 Agent（${active.length}）：`);
		for (const task of active.slice(0, MAX_CONTINUATION_TASKS)) lines.push(`- ${task.agent}/${task.taskId.slice(0, 8)}${task.status === "queued" ? "（排队中）" : ""} · 目标: ${bounded(task.goal, 120)}`);
		if (active.length > MAX_CONTINUATION_TASKS) lines.push(`- 其余 ${active.length - MAX_CONTINUATION_TASKS} 个在途任务省略：task_query({ view: "summary" }) 分页查询`);
	}

	const blocked = tasks.filter((task) => task.status === "blocked");
	if (blocked.length) {
		// diting 增审 Major-3：两类 blocked 分列——questions 进「待答」（QUESTIONS 逐项答复），
		// needs-handoff 进「待接手」（resume 接手开工，非提问）；已消费 handoff（answered 等终态）
		// 不再出现在任何行动队列（spawn 确认后父记录已迁出 blocked）。
		const questionsBlocked = blocked.filter((t) => t.blockReason !== "needs-handoff");
		const handoffBlocked = blocked.filter((t) => t.blockReason === "needs-handoff");
		if (questionsBlocked.length) {
			lines.push(`\nblocked 待答（${questionsBlocked.length}）：`);
			for (const task of questionsBlocked.slice(0, MAX_CONTINUATION_TASKS)) {
				let questions = task.blockedQuestions;
				if (!questions?.length && typeof task.result === "string") {
					const match = task.result.match(/QUESTIONS:\s*([\s\S]*?)(?:\nPARTIAL:|$)/i);
					questions = match ? match[1].split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 10) : undefined;
				}
				const questionText = questions?.length ? questions.join(" / ") : "(无法提取)";
				lines.push(`- ${task.agent}/${task.taskId.slice(0, 8)} · 目标: ${bounded(task.goal, 120)} · 问题: ${bounded(questionText, 260)}`);
				if (Array.from(questionText).length > 260) lines.push(`  问题共 ${questions?.length ?? 0} 项，摘要省略；task_control({ action: "wait", handles: ["${task.taskId}"], timeoutMs: 1 }) 取待答正文`);
			}
			if (questionsBlocked.length > MAX_CONTINUATION_TASKS) lines.push(`- 其余 ${questionsBlocked.length - MAX_CONTINUATION_TASKS} 个待答任务省略：task_query({ view: "summary" }) 分页查询`);
		}
		if (handoffBlocked.length) {
			lines.push(`\n待接手（NEEDS_HANDOFF，${handoffBlocked.length}）：`);
			for (const task of handoffBlocked.slice(0, MAX_CONTINUATION_TASKS)) {
				lines.push(`- ${task.agent}/${task.taskId.slice(0, 8)} · 目标: ${bounded(task.goal, 120)} · settle 产出窗口收口（零写盘，非提问）——resume 接手开工：task_resume({ handle: "${task.taskId}", message: "先核对已有产物，再继续原任务未完成部分。" })`);
			}
			if (handoffBlocked.length > MAX_CONTINUATION_TASKS) lines.push(`- 其余 ${handoffBlocked.length - MAX_CONTINUATION_TASKS} 个待接手任务省略：task_query({ view: "summary" }) 分页查询`);
		}
	}

	// v2 批次C：按 runId 分组输出编排进度（已知节点状态 + 真实依赖），组按最新活动新到旧；
	// 组数/节点数/行长三重有界，溢出显式标注，无 runId 时整段不出现（行为不变）。
	const groups = new Map<string, Array<Readonly<TaskRecord>>>();
	for (const task of tasks) {
		if (!task.runId) continue;
		const list = groups.get(task.runId);
		if (list) list.push(task); else groups.set(task.runId, [task]);
	}
	if (groups.size > 0) {
		const latestOf = (nodes: Array<Readonly<TaskRecord>>) => Math.max(...nodes.map((n) => n.endedAt || n.blockedAt || n.startedAt));
		const orderedGroups = [...groups.entries()].sort((a, b) => latestOf(b[1]) - latestOf(a[1])).slice(0, MAX_ORCH_GROUPS);
		lines.push(`\n编排进度（${orderedGroups.length} 组，按 runId）：`);
		for (const [runId, nodes] of orderedGroups) {
			const seq = [...nodes].sort((a, b) => a.startedAt - b.startedAt);
			const settledCount = seq.filter((n) => isTerminalStatus(n.status)).length;
			const parts = seq.slice(0, MAX_ORCH_NODES).map((n) =>
				`${n.nodeId || n.taskId.slice(0, 8)}:${n.status}${n.dependsOn?.length ? `(依赖${n.dependsOn.join("/")})` : ""}`);
			const overflow = seq.length > MAX_ORCH_NODES ? ` …另 ${seq.length - MAX_ORCH_NODES} 节点` : "";
			lines.push(`- ${bounded(runId, 40)} ${settledCount}/${seq.length} 节点终态: ${bounded(parts.join(" ") + overflow, 400)}`);
		}
	}

	// 在途/待答优先，其余新→旧；归档只放路径，不将 result/completionAnnotation 重新展开。
	const byRecency = [...tasks].sort((a, b) => (b.endedAt || b.startedAt) - (a.endedAt || a.startedAt));
	const relevant = [...byRecency.filter((t) => !isTerminalStatus(t.status)), ...byRecency.filter((t) => isTerminalStatus(t.status))];
	const allRefs = [...new Set(relevant.flatMap((task) => task.artifactRefs || []))];
	const artifactRefs: string[] = [];
	let refBytes = 0;
	for (const ref of allRefs) {
		const cost = Buffer.byteLength(ref) + 3;
		if (artifactRefs.length >= 20 || refBytes + cost > 4096 || /[\r\n]/.test(ref)) continue;
		artifactRefs.push(ref); refBytes += cost;
	}
	lines.push("\n关键 artifact：");
	if (artifactRefs.length) for (const ref of artifactRefs) lines.push(`- ${ref}`);
	else lines.push("- (未记录)");
	if (allRefs.length > artifactRefs.length) lines.push(`- 其余 ${allRefs.length - artifactRefs.length} 个引用省略：task_query({ handle: "<taskId>", view: "output" }) 按需查询`);

	// ev-20261011-094b9f：原「当前任务目标：goal(500)」行收的是 registry 最近一条子任务的任务书——registry 只登记
	// 子 Agent 任务，字段名宣称了数据不提供的东西，且子任务指令文本被置于系统提示层（实测：被误指为已中止
	// 探针的「不调用任何工具」指令）。改为诚实标注：对账参考的子任务目标摘录，非本会话目标；在途任务目标
	// 已在「进行中子 Agent」/「blocked 待答」节展示（同 bounded 120 口径）。
	const recent = relevant[0];
	if (recent?.goal) {
		const state = isTerminalStatus(recent.status) ? "·已终态" : "";
		lines.push(`\n最近子任务（${recent.agent}/${recent.taskId.slice(0, 8)}${state}）目标摘录（对账参考，非本会话目标）：${bounded(recent.goal, 120)}`);
	}
	// ev-20260904 §5④：工具统计快照附尾（调用数/失败数按工具分布，进程累计口径）
	const stats = toolStatsSummary();
	if (stats) lines.push(`\n${stats}`);
	return lines.join("\n");
}

/** 消费令牌时重取会话三轴；压缩时冻结的文本不能覆盖之后的状态迁移。
 * 查询失败时只报告未知，绝不把旧快照当作当前状态。 */
export async function refreshContinuationSummary(): Promise<string> {
	const session = getLeaderSessionStamp();
	const views = new Map<string, Readonly<TaskView>>();
	let cursor: string | undefined;
	let legacy: readonly { taskId: string; agent: string; status: string }[] = [];
	for (;;) {
		let result: Awaited<ReturnType<typeof queryTaskViews>>;
		try {
			result = await queryTaskViews({ limit: 100, ...(cursor ? { cursor } : {}) });
		} catch (error) {
			return `[amagi 压缩保真]\n任务状态未知（查询异常：${bounded(error instanceof Error ? error.message : String(error), 300)}）；请用 task_query 核对，不得假定已结束。`;
		}
		if (!result.ok) {
			const ids = registry.list().slice(0, MAX_CONTINUATION_TASKS).map((r) => `${r.agent}/${r.taskId.slice(0, 8)}`).join("、");
			return `[amagi 压缩保真]\n任务状态未知（${result.error.code}）：${bounded(result.error.message, 300)}${ids ? `\n待核对: ${ids}` : ""}\n请用 task_query 核对；不得假定已结束。`;
		}
		legacy = result.value.legacy;
		for (const view of result.value.page.items) views.set(view.taskId, view);
		cursor = result.value.page.nextCursor;
		if (!cursor) break;
	}
	if (getLeaderSessionStamp() !== session) return "[amagi 压缩保真]\n会话已切换，任务状态未知；请重新查询。";
	const records = new Map(registry.list().map((r) => [r.taskId, r]));
	const tasks: TaskRecord[] = [];
	const pending: string[] = [];
	for (const [id, listed] of views) {
		// 查询期间内核可能推进；内存权威视图最后重读，避免早一页覆盖新事实。
		const view = peekTaskKernel()?.get(id) ?? listed;
		const projected = records.get(id);
		// registry 元数据只在同 revision 时可与契约合并；旧轮问题/结果不能附到新轮。
		const rec = projected?.revision === view.revision ? projected : undefined;
		const status = view.execution;
		tasks.push({ ...(rec ?? { taskId: id, agent: view.spec.agent, startedAt: view.run.queuedAt }), status, goal: rec?.goal ?? view.spec.assignment, revision: view.revision });
		if (isTerminalStatus(status) && view.acceptance === "unreviewed") pending.push(`${view.spec.agent}/${id.slice(0, 8)}（${view.execution}/${view.settlement}/${view.acceptance}${view.receipt ? "" : "，无回执"}）`);
	}
	// 已确认的 v1 投影可继续作为观察值；没有归属或状态证据的记录单列未知。
	if (session !== undefined) for (const item of legacy) {
		const rec = records.get(item.taskId);
		if (rec) tasks.push({ ...rec });
	}
	const unknown = [...records.values()].filter((r) => !views.has(r.taskId) && !(session !== undefined && legacy.some((l) => l.taskId === r.taskId)));
	let summary = tasks.length === 0 && (unknown.length > 0 || session === undefined)
		? "[amagi 压缩保真]"
		: generateContinuationSummary(tasks);
	if (pending.length) summary += `\n\n已结束待决策（${pending.length}）：\n${pending.slice(0, MAX_CONTINUATION_TASKS).map((s) => `- ${s}`).join("\n")}`;
	if (unknown.length) summary += `\n\n状态未知（${unknown.length}，请查询）：\n${unknown.slice(0, MAX_CONTINUATION_TASKS).map((r) => `- ${r.agent}/${r.taskId.slice(0, 8)}`).join("\n")}`;
	if (session === undefined) summary += "\n\n会话身份未确认：历史任务清单可能不完整，请用 task_query 核对。";
	return summary;
}

export interface RegisterContinuationDeps {
	/** 宿主版本覆写（测试注入；缺省 detectHostPackageVersion()）。 */
	version?: string | null;
	/** 裁决器依赖透传（测试注入 logFile/budget）。 */
	boundary?: BoundaryAdjudicatorDeps;
}

export function registerContinuation(pi: ExtensionAPI, state: ContinuationState, deps: RegisterContinuationDeps = {}): void {
	// B9（设计方案 §5.6）：最终续跑裁决迁 agent_before_settle。版本门选单一路径：
	// 宿主 ≥0.87.0 → 边界裁决（agent_before_settle 唯一 continue 发射点，turn_end 只观测）；
	// 旧宿主/版本未知 → 维持 legacy（willRetry steer 注入 + before_agent_start 消费），不双订阅。
	const hostVersion = deps.version !== undefined ? deps.version : detectHostPackageVersion();
	const boundaryEnabled = boundaryAdjudicationEnabled(hostVersion);
	const adjudicator = createBoundaryAdjudicator(state, deps.boundary);

	pi.on("session_start", (_event: any, ctx: any) => {
		state.reset(sessionKey(ctx));
		// B9：新会话代次——旧令牌失效 + 预算重置
		adjudicator.noteGenerationBump();
		// ev-20260904 §5④：工具统计与保真状态同生命周期（新会话进程重新计数）
		resetToolCallStats();
	});
	pi.on("session_shutdown", () => {
		state.reset();
		// B9：shutdown 观测——代次推进，旧信号作废
		adjudicator.noteGenerationBump();
	});
	// ev-20260904 §5④：工具调用计数（事件名/形状与 guards.ts tool_result 处理器同源；
	// toolName 防御性回退 event.name，与守卫层取值口径一致）
	pi.on("tool_result", (event: any) => {
		noteToolCall(String(event?.toolName || event?.tool?.name || event?.name || "unknown"), event?.isError === true);
	});

	// B9：turn_end 降级为观测（积累已发生信号；不返回任何值 → 0.87+ 可动作语义下也不发 continue）
	pi.on("turn_end", (event: any) => { adjudicator.noteTurnEnd(event); });
	// B9：blocked/待用户回答门（扩展 UI 提示在等待时不得自动续跑）；
	// ui_prompt_start/end 为 0.84+ 事件，旧宿主仅注册不触发（零成本降级，index.ts 先例）
	try { pi.on("ui_prompt_start", () => adjudicator.noteUiPrompt(true)); } catch { /* lint-exempt:事件不可用防御 */ }
	try { pi.on("ui_prompt_end", () => adjudicator.noteUiPrompt(false)); } catch { /* lint-exempt:事件不可用防御 */ }
	if (boundaryEnabled) {
		// 唯一 continue 发射点：压缩存活 pending（无重试压缩后未消费的保真摘要）经宿主
		// 边界返回链追加 custom_message 并 continue:true 恰一次；令牌消费后零重复，
		// 预算封顶防循环。与 willRetry steer / before_agent_start 消费互斥（同一令牌单次消费）。
		pi.on("agent_before_settle", async (event: any, ctx: any): Promise<any> => {
			const generation = adjudicator.inspect().generation;
			const epoch = state.getEpoch?.();
			const decision = adjudicator.adjudicate(event, sessionKey(ctx));
			if (!decision) return undefined;
			const session = getLeaderSessionStamp();
			const summary = await refreshContinuationSummary();
			if (adjudicator.inspect().generation !== generation || state.getEpoch?.() !== epoch || getLeaderSessionStamp() !== session) return undefined;
			const draft = decision.entries[decision.entries.length - 1];
			if (draft?.type === "custom_message") draft.content = boundaryContinuationContent(summary);
			return decision;
		});
	}

	pi.on("session_before_compact", (event: any, ctx: any): any => {
		state.stage(sessionKey(ctx), String(event.reason || "unknown"), generateContinuationSummary());
		return undefined;
	});

	pi.on("session_compact", async (event: any, ctx: any): Promise<any> => {
		const key = sessionKey(ctx);
		const summary = state.confirm(key, String(event.reason || "unknown"));
		if (summary && event.willRetry) {
			// overflow retry 不再触发 before_agent_start；以 steer custom message 注入本次重试上下文。
			// v1.5.244：原 {triggerTurn:false, deliverAs:"steer"} 中 triggerTurn:false 会废掉 steer 分支
			// （sendCustomMessage 的 steer 分支要求 triggerTurn !== false），实际落入原位插入，
			// 流式中可能插进 tool 配对中间；去掉 triggerTurn:false 让 steer 真正生效。
			state.consume(key);
			const session = getLeaderSessionStamp();
			const epoch = state.getEpoch?.();
			const fresh = await refreshContinuationSummary();
			if (state.getEpoch?.() !== epoch || getLeaderSessionStamp() !== session) return undefined;
			try { pi.sendMessage({ customType: "amagi:compact-continuation", content: fresh, display: false }, { deliverAs: "steer" }); } catch {}
		}
	});

	// 8月迭代 pi-0.84 配合 P1③ → H2 typed 化（amagi-pi v2，方案 §8.4-H2/§6.2.8）：0.85.1 官方类型
	// 已将 session_compact_failed 入 SessionEvent 联合（dist/core/extensions/types.d.ts
	// SessionCompactFailedEvent 五字段：reason/errorMessage?/aborted/willRetry/fromExtension，
	// docs/extensions.md:484 契约），去掉 0.83 时代的 unknown 结构化订阅强转——on 重载直接可用，
	// reason/aborted/willRetry/fromExtension 分别记录进告警文案（字段运行时防御读取保留：typed
	// 是编译期契约，宿主观测期不因缺字段抛错）。压缩失败时 before_compact 已 stage 的候选必须
	// 作废，否则下次 compact 成功时 confirm 可能误匹配陈旧摘要。主进程上浮 warning 告警 + 有界
	// steer 注入；子进程只 stderr 一行告警（子进程 steer 语义复杂，不注入消息——task-tool.ts:396
	// 先例）。同 sessionKey 同 reason 30s 窗口去重防 retry 风暴刷屏；不新增 env 开关（订阅零成本）。
	const COMPACT_FAILED_ALERT_DEDUP_MS = 30_000;
	const compactFailedAlerts = new Map<string, number>();
	const handleCompactFailed = (event: { reason?: string; errorMessage?: string; aborted?: boolean; willRetry?: boolean; fromExtension?: boolean }, ctx: any): void => {
		const key = sessionKey(ctx);
		const reason = String(event?.reason || "unknown");
		state.discard(key); // 作废每次都执行（幂等）；去重只作用于告警上浮
		const dedupKey = `${key}::${reason}`;
		const now = Date.now();
		if (now - (compactFailedAlerts.get(dedupKey) ?? 0) < COMPACT_FAILED_ALERT_DEDUP_MS) return;
		compactFailedAlerts.set(dedupKey, now);
		const detail = event?.errorMessage ? `错误: ${bounded(String(event.errorMessage))}` : event?.aborted ? "已被取消/中止" : "(无错误详情)";
		// H2：fromExtension 分别记录——true = 失败压缩内容来自扩展 before_compact 注入（定位方向：
		// 先查本扩展注入的摘要体量/格式，再查 provider）。
		const from = event?.fromExtension === true ? "，fromExtension=true（失败内容来自扩展注入摘要）" : "";
		const advice = event?.willRetry ? "中断轮次将自动重试压缩" : "可等自动重试或手动 /compact 重试";
		const message = `[amagi 压缩存活] session_compact_failed（reason=${reason}，${detail}${from}）——动态上下文候选已作废；${advice}`;
		if (process.env.AMAGI_SUBAGENT) {
			console.error(message);
			return;
		}
		// 告警走 ctx.ui.notify（ExtensionContext 真实 API，watchdog.ts 先例；pi 对象本身无 ui）
		try { ctx?.ui?.notify?.(message, "warning"); } catch { /* 通知失败不阻断 */ }
		// steer 有界注入失败摘要（display:false），sendMessage 失败静默与上文 :160 惯例一致
		try { pi.sendMessage({ customType: "amagi:compact-failed", content: message, display: false }, { deliverAs: "steer" }); } catch {}
	};
	try {
		// 官方 typed 订阅（H2）：事件/ctx 形状由 0.85.1 on("session_compact_failed") 重载推导，
		// 经 handleCompactFailed 结构兼容入参消费；旧宿主（<0.84.3）on 未知事件仅注册不抛错、
		// 事件永不触发，零成本降级。
		pi.on("session_compact_failed", (event, ctx) => handleCompactFailed(event, ctx));
	} catch { /* pi < 0.84.3 无此事件，防御静默 */ }
}
