/**
 * lsp-wire.ts — P6（寄生增强方案 §9 P6 行，pi-0.99.1 批 W3）：lsp 工具结构化输出 wire v1。
 *
 * 纯 schema/投影模块（纪律沿 task-query-wire §4.1，同族先行：mcp-wire / run-bg-wire /
 * handbook-wire）：零 I/O（无 fs/进程/store 写）、零宿主私有依赖（仅 typebox + node:url 纯
 * URI 解码 + task-query-wire 纯导出 redactCredentials——同源复用不复制匹配规则）；不读用户
 * 现场、不 spawn/不 kill/不发 LSP 请求（调用点在 lsp-tool.ts 接线层：同一次请求的源结果
 * 单次读取投影，mapper 不执行副作用、不重发请求——U13：字段不从正文文本反猜）。
 *
 * wire 身份（§4.2 新家族共同字段）：kind="amagi.lsp"、wireVersion=1、schemaVersion=1、
 * action、ok、isError。成功分支带 data（对象封闭、无值字段 null）；失败分支带
 * error:{code,message}（code ∈ shape/permission/unavailable/operation/internal；message 过
 * redactCredentials 同源脱敏——正文 content 文本不脱敏，双载体口径差异见 P6 报告）。
 * action 非法映射 null。URN：urn:amagi:lsp:<分支>:1（十成功分支 + error）。v1 冻结字段
 * 集合；增删字段或改语义先升 schemaVersion。
 *
 * 分支投影（源闭合锚点=lsp-tool.ts 各 action 返回点 + lsp-client.ts 类型；逐字段源形状
 * 闭合表见 P6 报告）：
 *  - status：配置三布尔（enabled/autoDetect/readOnly）+ 检测 servers（name/commandPath/
 *    fileTypes）+ 运行中 instances（lsp-client LspClientStatus 字段子集）+ doctor（项目
 *    命中语言但二进制未装的安装指引——与正文 status doctor 段同一次扫描）。
 *  - capabilities：server 名 + serverCapabilities（开放远端 JSON 槽——服务器自报，只声明
 *    发现不表示本地已验证）。
 *  - diagnostics：LspDiagnostic[]（lsp-client.ts publishDiagnostics 缓存条目）归一——range
 *    摊平、severity 原值、severityLabel 由 1..4 映射（缺席/越界 → null；正文渲染缺省按
 *    ERROR 展示是正文层约定，wire 显式 null 不改语义）、code 字符串化、source/message。
 *  - definition/type_definition/implementation/references：**LSP Location/LocationLink 归一**
 *    ——uri|targetUri → uri、range|targetRange → range、targetSelectionRange →
 *    selectionRange、originSelectionRange → originRange；嵌套 {start:{line,character},
 *    end:{...}} 摊平为 startLine/startCharacter/endLine/endCharacter（0 基 LSP 原生坐标，
 *    正文 1 基展示属渲染层，不改语义）；无 uri/targetUri 的条目过滤（与正文 formatLocations
 *    同口径）；file: URI 解码为 file 路径（非 file:/解码失败 → file null，uri 原样保留）。
 *  - hover：state=present/absent（结果 null=absent）+ body（与正文同源提取，hoverBodyOf
 *    单源——接线层正文与 wire 共用，不做第二套提取）。
 *  - symbols：DocumentSymbol[]/SymbolInformation[] 服务器产物——开放远端 JSON 槽（strict
 *    JSON-safe 整树拷贝 + 递归脱敏；非法树 state=invalid 不做部分拷贝；结果 null → absent）。
 *  - rename：mode=preview/applied、editForm=changes/documentChanges/none、editCount、
 *    targets（file+摊平 range+newText；applied 档 targets 即真实写盘回执的文件集）、
 *    rawWorkspaceEdit（documentChanges 形态原样开放槽，V1 不自动应用）。**rename 权限红线**
 *    （P6 任务书）：本模块只做投影，不新增任何成功捷径——readOnly/能力名单/writeRules/
 *    denyRules/工作区边界/range 校验全部留在 lsp-tool.ts 原路径零变化；wire 成功分支只
 *    覆盖既有 ok() 出口（preview/preview-none/preview-documentChanges/applied），不扩语义。
 *  - error：{code,message} 封闭 envelope（§4.3：普通工具不强转任务契约 ContractError）。
 *
 * 错误分类（code 固定五值）：
 *   shape        调用参数错形（未知 action/缺 file/缺 newName/文件不存在——零副作用可改参重试）
 *   permission   策略拒绝（能力名单/readOnly/工作区边界/deny 禁入/写授权未覆盖——预写盘零副作用）
 *   unavailable  无可用服务器（零检测/文件不路由任何服务器/服务器未声明所需能力）
 *   operation    LSP 操作失败（JSON-RPC error/请求超时——客户端先发 $/cancelRequest 再 reject
 *                ——/进程退出/WorkspaceEdit 结构或 range 校验失败/写盘失败（正文含回滚报告））
 *   internal     兜底异常
 */
import { fileURLToPath } from "node:url";
import { Type, type TSchema } from "typebox";
import { redactCredentials } from "./task-query-wire.ts";

// ── wire 身份常量（固定字面量；接线层与测试共用） ──────────────────────────────

export const LSP_WIRE_KIND = "amagi.lsp";
export const LSP_WIRE_VERSION = 1;
export const LSP_SCHEMA_VERSION = 1;

/** 十一分支 schema 标识（§4.2 URN 格式 urn:amagi:<家族>:<分支>:1）。 */
export const LSP_WIRE_URNS = {
	status: "urn:amagi:lsp:status:1",
	capabilities: "urn:amagi:lsp:capabilities:1",
	diagnostics: "urn:amagi:lsp:diagnostics:1",
	definition: "urn:amagi:lsp:definition:1",
	type_definition: "urn:amagi:lsp:type_definition:1",
	implementation: "urn:amagi:lsp:implementation:1",
	references: "urn:amagi:lsp:references:1",
	hover: "urn:amagi:lsp:hover:1",
	symbols: "urn:amagi:lsp:symbols:1",
	rename: "urn:amagi:lsp:rename:1",
	error: "urn:amagi:lsp:error:1",
} as const;

/** 家族错误码（五值封闭；语义见模块头）。 */
export const LSP_WIRE_ERROR_CODES = ["shape", "permission", "unavailable", "operation", "internal"] as const;
export type LspWireErrorCode = (typeof LSP_WIRE_ERROR_CODES)[number];

/** 工具 action 全集（lsp-tool.ts ACTIONS 同源冻结；error 分支 action 判据）。 */
export const LSP_WIRE_ACTIONS = [
	"status", "capabilities", "diagnostics", "definition", "type_definition",
	"implementation", "references", "hover", "symbols", "rename",
] as const;
export type LspWireAction = (typeof LSP_WIRE_ACTIONS)[number];

/** 定位族 action（definition/type_definition/implementation/references——同 wire 形状）。 */
export type LspLocationAction = Extract<LspWireAction, "definition" | "type_definition" | "implementation" | "references">;

// ── 共享子 schema（additionalProperties:false + 全键 required；分支根才挂 $id） ──

const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });
const NullableString = Type.Union([Type.String(), Type.Null()]);

/** LSP severity 1..4 → 标签（lsp-tool.ts formatDiagnostics 同源——接线层正文与 wire 共用）。 */
export const LSP_SEVERITY_LABELS = ["", "ERROR", "WARN", "INFO", "HINT"] as const;

/** severity → 标签（1..4 内映射；null/越界 → null——正文渲染缺省 ERROR 属正文层，wire 不臆造）。 */
export function lspSeverityLabel(severity: number | null): string | null {
	return severity !== null && severity >= 1 && severity <= 4 ? LSP_SEVERITY_LABELS[severity] : null;
}

const WireCommonProperties = {
	kind: Type.Literal(LSP_WIRE_KIND),
	wireVersion: Type.Literal(LSP_WIRE_VERSION),
	schemaVersion: Type.Literal(LSP_SCHEMA_VERSION),
};

/** LSP range 摊平 wire（嵌套 {start:{line,character},end:{...}} → 四数字字段；0 基原生坐标）。 */
export const LspRangeWireSchema = Type.Object({
	startLine: NonNegativeSafeInt,
	startCharacter: NonNegativeSafeInt,
	endLine: NonNegativeSafeInt,
	endCharacter: NonNegativeSafeInt,
}, { additionalProperties: false, description: "LSP range 归一摊平（0 基；source 嵌套差异归一不改语义）" });
export interface LspRangeWire { startLine: number; startCharacter: number; endLine: number; endCharacter: number }

/** 请求位置 wire（resolvePosition 产物；0 基 LSP 原生）。 */
const LspPositionWireSchema = Type.Object({
	line: NonNegativeSafeInt,
	character: NonNegativeSafeInt,
}, { additionalProperties: false });
export interface LspPositionWire { line: number; character: number }

/** 开放远端 JSON 槽的递归 JSON Schema（$defs 挂分支根——同 mcp-wire 手法）。 */
const JSON_SAFE_DEFS = {
	jsonValue: {
		anyOf: [
			{ type: "null" },
			{ type: "boolean" },
			{ type: "number" },
			{ type: "string" },
			{ type: "array", items: { $ref: "#/$defs/jsonValue" } },
			{ type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
		],
	},
	jsonObject: { type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
};
const JsonValueRef = { $ref: "#/$defs/jsonValue" } as unknown as TSchema;
const JsonObjectRef = { $ref: "#/$defs/jsonObject" } as unknown as TSchema;

const ErrorCodeSchema = Type.Union(
	LSP_WIRE_ERROR_CODES.map((c) => Type.Literal(c)),
	{ description: "shape/permission/unavailable/operation/internal（五值封闭）" },
);

const RangeOrNull = Type.Union([LspRangeWireSchema, Type.Null()]);

/** Location/LocationLink 归一条目（uri/range/targetUri/targetRange/targetSelectionRange/originSelectionRange 统一）。 */
export const LspLocationWireSchema = Type.Object({
	uri: Type.String({ description: "Location.uri 或 LocationLink.targetUri（原样）" }),
	file: Type.Union([Type.String(), Type.Null()], { description: "file: URI 解码路径；非 file:/解码失败 → null（uri 原样保留）" }),
	range: Type.Union([LspRangeWireSchema, Type.Null()], { description: "Location.range 或 LocationLink.targetRange 摊平；缺失/非法 → null" }),
	selectionRange: Type.Union([LspRangeWireSchema, Type.Null()], { description: "LocationLink.targetSelectionRange 摊平（Location 形态 → null）" }),
	originRange: Type.Union([LspRangeWireSchema, Type.Null()], { description: "LocationLink.originSelectionRange 摊平（可选；Location 形态 → null）" }),
}, { additionalProperties: false, description: "LSP Location | LocationLink → 统一 wire 形状" });
export interface LspLocationWire {
	uri: string;
	file: string | null;
	range: LspRangeWire | null;
	selectionRange: LspRangeWire | null;
	originRange: LspRangeWire | null;
}

// ── 分支 schema（§9 P6 行「各 action 成功形状 + Failure」） ────────────────────

/** status 成功分支：urn:amagi:lsp:status:1。 */
export const LspStatusWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("status"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		enabled: Type.Boolean(),
		autoDetect: Type.Boolean(),
		readOnly: Type.Boolean(),
		servers: Type.Array(Type.Object({
			name: Type.String(),
			commandPath: Type.String(),
			fileTypes: Type.Array(Type.String()),
		}, { additionalProperties: false }), { description: "检测结果（正文 status 首段同源）" }),
		instances: Type.Array(Type.Object({
			name: Type.String(),
			pid: Type.Union([NonNegativeSafeInt, Type.Null()], { description: "进程 pid；未运行/未知 → null" }),
			alive: Type.Boolean(),
			initialized: Type.Boolean(),
			openFiles: NonNegativeSafeInt,
			diagnosticFiles: NonNegativeSafeInt,
		}, { additionalProperties: false }), { description: "运行中实例（LspClientStatus 字段子集）" }),
		doctor: Type.Array(Type.Object({
			name: Type.String(),
			rootMarker: NullableString,
			installCommand: NullableString,
		}, { additionalProperties: false }), { description: "命中项目语言但二进制未装的安装指引（与正文 doctor 段同一次扫描）" }),
	}, { additionalProperties: false, description: "status 成功 data" }),
}, { $id: LSP_WIRE_URNS.status, additionalProperties: false, description: "lsp status wire（检测/实例/doctor）" });

/** capabilities 成功分支：urn:amagi:lsp:capabilities:1。 */
export const LspCapabilitiesWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("capabilities"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		server: Type.String(),
		capabilities: Type.Union([JsonObjectRef, Type.Null()], { description: "serverCapabilities 开放远端 JSON 槽（服务器自报；无法整树 JSON-safe 拷贝 → null）" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.capabilities, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "lsp capabilities wire" });

/** diagnostics 成功分支：urn:amagi:lsp:diagnostics:1。 */
export const LspDiagnosticsWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("diagnostics"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		file: Type.String({ description: "请求文件（相对项目根；正文同款口径）" }),
		diagnostics: Type.Array(Type.Object({
			range: RangeOrNull,
			severity: Type.Union([Type.Integer(), Type.Null()], { description: "LSP severity 原值（1..4 常规）；缺席 → null" }),
			severityLabel: NullableString,
			code: NullableString,
			source: NullableString,
			message: Type.String(),
		}, { additionalProperties: false }), { description: "publishDiagnostics 条目归一（正文 formatDiagnostics 同源）" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.diagnostics, additionalProperties: false, description: "lsp diagnostics wire" });

/** 定位族成功分支（definition/type_definition/implementation/references 同形状）。 */
function locationWireSchema(action: LspLocationAction, urn: string) {
	return Type.Object({
		...WireCommonProperties,
		action: Type.Literal(action),
		ok: Type.Literal(true),
		isError: Type.Literal(false),
		data: Type.Object({
			file: Type.String({ description: "请求文件（相对项目根）" }),
			position: LspPositionWireSchema,
			locations: Type.Array(LspLocationWireSchema, { description: "Location/LocationLink 归一（无 uri/targetUri 条目过滤——与正文同口径）" }),
		}, { additionalProperties: false }),
	}, { $id: urn, additionalProperties: false, description: `lsp ${action} wire（Location/LocationLink 归一）` });
}

export const LspDefinitionWireSchema = locationWireSchema("definition", LSP_WIRE_URNS.definition);
export const LspTypeDefinitionWireSchema = locationWireSchema("type_definition", LSP_WIRE_URNS.type_definition);
export const LspImplementationWireSchema = locationWireSchema("implementation", LSP_WIRE_URNS.implementation);
export const LspReferencesWireSchema = locationWireSchema("references", LSP_WIRE_URNS.references);

/** hover 成功分支：urn:amagi:lsp:hover:1。 */
export const LspHoverWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("hover"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		file: Type.String(),
		position: LspPositionWireSchema,
		state: Type.Union([Type.Literal("present"), Type.Literal("absent")], { description: "服务器返回 null → absent（正文「(无 hover 内容)」同判据）" }),
		body: Type.String({ description: "与正文同源提取的 hover 文本（hoverBodyOf 单源）" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.hover, additionalProperties: false, description: "lsp hover wire" });

/** symbols 成功分支：urn:amagi:lsp:symbols:1。 */
export const LspSymbolsWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("symbols"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		file: Type.String(),
		state: Type.Union([Type.Literal("present"), Type.Literal("absent"), Type.Literal("invalid")], { description: "服务器产物整树 JSON-safe 拷贝状态：absent=结果 null；invalid=无法安全拷贝（不做部分拷贝）；present=合法（可含空数组）" }),
		symbols: Type.Union([JsonValueRef, Type.Null()], { description: "DocumentSymbol[]/SymbolInformation[] 开放远端 JSON 槽（递归字符串已脱敏）；absent/invalid → null" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.symbols, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "lsp symbols wire" });

/** rename 成功分支：urn:amagi:lsp:rename:1（preview/applied 共形状；权限拒绝走 error 分支）。 */
export const LspRenameWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Literal("rename"),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: Type.Object({
		file: Type.String({ description: "发起 rename 的请求文件（相对项目根）" }),
		newName: Type.String(),
		mode: Type.Union([Type.Literal("preview"), Type.Literal("applied")], { description: "applied=已真实写盘（targets 即写盘回执文件集）；preview=未写盘" }),
		editForm: Type.Union([Type.Literal("changes"), Type.Literal("documentChanges"), Type.Literal("none")], { description: "WorkspaceEdit 形态：changes=已解析校验；documentChanges=V1 不支持的形态（原样入 rawWorkspaceEdit，未写盘）；none=服务器无可应用编辑" }),
		editCount: NonNegativeSafeInt,
		targets: Type.Array(Type.Object({
			file: Type.String({ description: "编辑目标文件（相对项目根；applied 档=实际写盘文件）" }),
			edits: Type.Array(Type.Object({
				range: LspRangeWireSchema,
				newText: Type.String(),
			}, { additionalProperties: false }), { description: "range 已过 applyTextEdits 校验（边界内/有序/不重叠）" }),
		}, { additionalProperties: false })),
		rawWorkspaceEdit: Type.Union([JsonObjectRef, Type.Null()], { description: "documentChanges 形态 WorkspaceEdit 原样开放槽；其余 → null" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.rename, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "lsp rename wire（preview/applied 严格原授权——成功分支只投影既有 ok() 出口）" });

/** Failure 分支：urn:amagi:lsp:error:1。 */
export const LspErrorWireSchema = Type.Object({
	...WireCommonProperties,
	action: Type.Union([...LSP_WIRE_ACTIONS.map((a) => Type.Literal(a)), Type.Null()], { description: "合法 action 字面或 null（未知/缺席 action → null）" }),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	error: Type.Object({
		code: ErrorCodeSchema,
		message: Type.String({ description: "与正文同文案（自由文本——已过 redactCredentials；正文 content 不脱敏）" }),
	}, { additionalProperties: false }),
}, { $id: LSP_WIRE_URNS.error, additionalProperties: false, description: "lsp 工具内失败 wire（五 code 封闭）" });

/** 十一封闭分支 Union（注册面统一校验器；消费者判据 kind/wireVersion/action/ok/schemaVersion）。 */
export const LspOutputSchema = Type.Union(
	[
		LspStatusWireSchema, LspCapabilitiesWireSchema, LspDiagnosticsWireSchema,
		LspDefinitionWireSchema, LspTypeDefinitionWireSchema, LspImplementationWireSchema,
		LspReferencesWireSchema, LspHoverWireSchema, LspSymbolsWireSchema,
		LspRenameWireSchema, LspErrorWireSchema,
	],
	{ description: "amagi lsp 结构化输出 wire v1（十一封闭分支：十 action 成功形状 + error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；一致性由专项测试 Value.Check+键集对照双断言） ──

export interface LspWireCommon {
	kind: typeof LSP_WIRE_KIND;
	wireVersion: typeof LSP_WIRE_VERSION;
	schemaVersion: typeof LSP_SCHEMA_VERSION;
}

export type JsonSafeValue = null | boolean | number | string | JsonSafeValue[] | { [key: string]: JsonSafeValue };
export type JsonSafeObject = { [key: string]: JsonSafeValue };

export interface LspStatusWire extends LspWireCommon {
	action: "status"; ok: true; isError: false;
	data: {
		enabled: boolean; autoDetect: boolean; readOnly: boolean;
		servers: Array<{ name: string; commandPath: string; fileTypes: string[] }>;
		instances: Array<{ name: string; pid: number | null; alive: boolean; initialized: boolean; openFiles: number; diagnosticFiles: number }>;
		doctor: Array<{ name: string; rootMarker: string | null; installCommand: string | null }>;
	};
}
export interface LspCapabilitiesWire extends LspWireCommon {
	action: "capabilities"; ok: true; isError: false;
	data: { server: string; capabilities: JsonSafeObject | null };
}
export interface LspDiagnosticItemWire {
	range: LspRangeWire | null;
	severity: number | null;
	severityLabel: string | null;
	code: string | null;
	source: string | null;
	message: string;
}
export interface LspDiagnosticsWire extends LspWireCommon {
	action: "diagnostics"; ok: true; isError: false;
	data: { file: string; diagnostics: LspDiagnosticItemWire[] };
}
export interface LspLocationsWire extends LspWireCommon {
	action: LspLocationAction; ok: true; isError: false;
	data: { file: string; position: LspPositionWire; locations: LspLocationWire[] };
}
export interface LspHoverWire extends LspWireCommon {
	action: "hover"; ok: true; isError: false;
	data: { file: string; position: LspPositionWire; state: "present" | "absent"; body: string };
}
export interface LspSymbolsWire extends LspWireCommon {
	action: "symbols"; ok: true; isError: false;
	data: { file: string; state: "present" | "absent" | "invalid"; symbols: JsonSafeValue | null };
}
export interface LspRenameTargetWire {
	file: string;
	edits: Array<{ range: LspRangeWire; newText: string }>;
}
export interface LspRenameWire extends LspWireCommon {
	action: "rename"; ok: true; isError: false;
	data: {
		file: string; newName: string;
		mode: "preview" | "applied";
		editForm: "changes" | "documentChanges" | "none";
		editCount: number;
		targets: LspRenameTargetWire[];
		rawWorkspaceEdit: JsonSafeObject | null;
	};
}
export interface LspErrorWire extends LspWireCommon {
	action: LspWireAction | null; ok: false; isError: true;
	error: { code: LspWireErrorCode; message: string };
}
export type LspWireOutput =
	| LspStatusWire | LspCapabilitiesWire | LspDiagnosticsWire | LspLocationsWire
	| LspHoverWire | LspSymbolsWire | LspRenameWire | LspErrorWire;

// ── 投影源（接线层单次执行内部对象的结构声明——本模块不 import lsp-tool/lsp-client 防耦合；
//    字段闭合锚点=lsp-tool.ts 各返回点 + lsp-client.ts LspDiagnostic/LspClientStatus） ──

/** status 投影源（检测/实例/doctor 与正文 status 三段同一次扫描产物）。 */
export interface LspStatusSource {
	enabled: boolean;
	autoDetect: boolean;
	readOnly: boolean;
	servers: ReadonlyArray<{ name: unknown; commandPath: unknown; fileTypes?: unknown }>;
	instances: ReadonlyArray<{ name: unknown; pid?: unknown; alive?: unknown; initialized?: unknown; openFiles?: unknown; diagnosticFiles?: unknown }>;
	doctor: ReadonlyArray<{ name: unknown; rootMarker?: unknown; installCommand?: unknown }>;
}

/** 定位族请求上下文（file=正文同款相对路径；position=resolvePosition 产物）。 */
export interface LspRequestContext {
	file: string;
	position: { line: number; character: number };
}

/** rename targets 投影源（groups 单次读取直投影——file 已由接线层相对化）。 */
export interface LspRenameTargetSource {
	file: string;
	edits: ReadonlyArray<{ range: unknown; newText: unknown }>;
}

// ── 归一小件（未知/类型不合 → null/缺省；映射纯函数不抛） ──────────────────────

function nonNegativeSafeInt(v: unknown): number | null {
	return typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= Number.MAX_SAFE_INTEGER ? v : null;
}

function nullableStringOf(v: unknown): string | null {
	return typeof v === "string" ? v : null;
}

function boolOr(v: unknown, dflt: boolean): boolean {
	return typeof v === "boolean" ? v : dflt;
}

/** 嵌套 LSP range → 摊平 wire（四坐标均合法非负整数才归一；否则 null——不臆造部分 range）。 */
export function normalizeLspRange(range: unknown): LspRangeWire | null {
	if (typeof range !== "object" || range === null) return null;
	const r = range as { start?: unknown; end?: unknown };
	const pos = (v: unknown): { line?: unknown; character?: unknown } | null =>
		typeof v === "object" && v !== null ? v as { line?: unknown; character?: unknown } : null;
	const s = pos(r.start);
	const t = pos(r.end);
	if (!s || !t) return null;
	const startLine = nonNegativeSafeInt(s.line);
	const startCharacter = nonNegativeSafeInt(s.character);
	const endLine = nonNegativeSafeInt(t.line);
	const endCharacter = nonNegativeSafeInt(t.character);
	if (startLine === null || startCharacter === null || endLine === null || endCharacter === null) return null;
	return { startLine, startCharacter, endLine, endCharacter };
}

/** file: URI → 路径（语义与 lsp-tool.ts uriToPath 同——file 前缀 + fileURLToPath 解码百分号编码；
 *  权限关键路径（rename 目标解析）仍走 lsp-tool 本地实现，本导出只服务 wire file 字段投影）。 */
export function lspFileUriToPath(uri: string): string | null {
	if (!uri.startsWith("file:")) return null;
	try { return fileURLToPath(uri); } catch { /* lint-exempt:非 file URI/解码失败 → null（与 lsp-tool uriToPath 同语义） */ return null; }
}

/** Location | LocationLink → 统一 wire 条目（uri 判据：uri ?? targetUri，与正文 formatLocations 同口径）。 */
function locationOf(item: unknown): LspLocationWire | null {
	if (typeof item !== "object" || item === null) return null;
	const l = item as Record<string, unknown>;
	const uri = typeof l.uri === "string" ? l.uri : typeof l.targetUri === "string" ? l.targetUri : null;
	if (uri === null) return null; // 无 uri/targetUri 条目不入列（正文同口径过滤）
	return {
		uri,
		file: lspFileUriToPath(uri),
		range: normalizeLspRange(l.range ?? l.targetRange),
		selectionRange: normalizeLspRange(l.targetSelectionRange),
		originRange: normalizeLspRange(l.originSelectionRange),
	};
}

/** 定位族结果（null | Location | LocationLink | 数组混排）→ 归一数组。 */
export function normalizeLspLocations(result: unknown): LspLocationWire[] {
	const arr = Array.isArray(result) ? result : result ? [result] : [];
	const out: LspLocationWire[] = [];
	for (const item of arr) {
		const loc = locationOf(item);
		if (loc) out.push(loc);
	}
	return out;
}

/** hover 结果 → {present, body}（正文同源提取：string | contents.value | JSON.stringify；
 *  contents 缺席时旧正文渲染 "undefined"——String(undefined) 逐字节保持，不做第二套提取）。 */
export function hoverBodyOf(hover: unknown): { present: boolean; body: string } {
	if (!hover) return { present: false, body: "" };
	const h = hover as { contents?: unknown };
	const raw = typeof h.contents === "string"
		? h.contents
		: ((h.contents as { value?: string } | null | undefined)?.value ?? JSON.stringify(h.contents));
	return { present: true, body: typeof raw === "string" ? raw : String(raw) };
}

// ── 严格 JSON-safe 整树拷贝 + 递归脱敏（纪律同 mcp-wire strictJsonSafeCopy/redactJsonSafeTexts：
//    整树合法才拷贝，不做部分拷贝；开放槽递归字符串值过 redactCredentials，对象键不脱敏） ──

function isPlainObject(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null) return false;
	const proto = Object.getPrototypeOf(v);
	return proto === Object.prototype || proto === null;
}

function strictJsonSafeCopy(v: unknown, stack: Set<object>): { ok: true; value: JsonSafeValue } | { ok: false } {
	if (v === null) return { ok: true, value: null };
	switch (typeof v) {
		case "string":
		case "boolean":
			return { ok: true, value: v };
		case "number":
			return Number.isFinite(v) ? { ok: true, value: v } : { ok: false };
		case "object": {
			if (stack.has(v as object)) return { ok: false };
			if (Array.isArray(v)) {
				stack.add(v);
				const out: JsonSafeValue[] = [];
				for (const el of v) {
					const r = strictJsonSafeCopy(el, stack);
					if (!r.ok) { stack.delete(v); return { ok: false }; }
					out.push(r.value);
				}
				stack.delete(v);
				return { ok: true, value: out };
			}
			if (!isPlainObject(v)) return { ok: false };
			stack.add(v);
			const out: Record<string, JsonSafeValue> = {};
			for (const [k, val] of Object.entries(v)) {
				if (val === undefined) { stack.delete(v); return { ok: false }; }
				const r = strictJsonSafeCopy(val, stack);
				if (!r.ok) { stack.delete(v); return { ok: false }; }
				out[k] = r.value;
			}
			stack.delete(v);
			return { ok: true, value: out };
		}
		default:
			return { ok: false };
	}
}

function redactJsonSafeTexts(v: JsonSafeValue): JsonSafeValue {
	if (typeof v === "string") return redactCredentials(v);
	if (Array.isArray(v)) return v.map(redactJsonSafeTexts);
	if (v !== null && typeof v === "object") {
		const out: Record<string, JsonSafeValue> = {};
		for (const [k, val] of Object.entries(v)) out[k] = redactJsonSafeTexts(val);
		return out;
	}
	return v;
}

/** 开放对象槽：纯对象且整树 JSON-safe → 递归脱敏副本；否则 null（不做部分拷贝）。 */
function jsonObjectSlotOf(v: unknown): JsonSafeObject | null {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return null;
	let safe: ReturnType<typeof strictJsonSafeCopy>;
	try {
		safe = strictJsonSafeCopy(v, new Set());
	} catch { /* lint-exempt: 超深嵌套栈溢出=无法安全转换——开放槽显式 null，不丢诊断 */
		return null;
	}
	if (!safe.ok || !isPlainObject(safe.value)) return null;
	try {
		return redactJsonSafeTexts(safe.value) as JsonSafeObject;
	} catch { /* lint-exempt: 同上——递归脱敏失败整槽置 null */
		return null;
	}
}

// ── 各分支映射（纯函数、不抛——坏源产 schema-invalid wire 如实暴露，不臆造） ─────

function wireIdentity() {
	return { kind: LSP_WIRE_KIND, wireVersion: LSP_WIRE_VERSION, schemaVersion: LSP_SCHEMA_VERSION } as const;
}

export function toLspStatusWire(src: Readonly<LspStatusSource>): LspStatusWire {
	return {
		...wireIdentity(),
		action: "status",
		ok: true,
		isError: false,
		data: {
			enabled: boolOr(src.enabled, false),
			autoDetect: boolOr(src.autoDetect, false),
			readOnly: boolOr(src.readOnly, false),
			servers: (Array.isArray(src.servers) ? src.servers : []).map((s) => ({
				name: typeof s.name === "string" ? s.name : "",
				commandPath: typeof s.commandPath === "string" ? s.commandPath : "",
				fileTypes: Array.isArray(s.fileTypes) ? s.fileTypes.filter((f: unknown): f is string => typeof f === "string") : [],
			})),
			instances: (Array.isArray(src.instances) ? src.instances : []).map((i) => ({
				name: typeof i.name === "string" ? i.name : "",
				pid: nonNegativeSafeInt(i.pid),
				alive: boolOr(i.alive, false),
				initialized: boolOr(i.initialized, false),
				openFiles: nonNegativeSafeInt(i.openFiles) ?? 0,
				diagnosticFiles: nonNegativeSafeInt(i.diagnosticFiles) ?? 0,
			})),
			doctor: (Array.isArray(src.doctor) ? src.doctor : []).map((d) => ({
				name: typeof d.name === "string" ? d.name : "",
				rootMarker: nullableStringOf(d.rootMarker),
				installCommand: nullableStringOf(d.installCommand),
			})),
		},
	};
}

export function toLspCapabilitiesWire(server: string, capabilities: unknown): LspCapabilitiesWire {
	return {
		...wireIdentity(),
		action: "capabilities",
		ok: true,
		isError: false,
		data: { server: typeof server === "string" ? server : "", capabilities: jsonObjectSlotOf(capabilities) },
	};
}

function diagnosticItemOf(d: unknown): LspDiagnosticItemWire {
	const o = typeof d === "object" && d !== null ? d as Record<string, unknown> : {};
	const severity = typeof o.severity === "number" && Number.isInteger(o.severity) ? o.severity : null;
	const code = o.code;
	return {
		range: normalizeLspRange(o.range),
		severity,
		severityLabel: lspSeverityLabel(severity),
		code: typeof code === "string" ? code : typeof code === "number" && Number.isFinite(code) ? String(code) : null,
		source: nullableStringOf(o.source),
		message: typeof o.message === "string" ? redactCredentials(o.message) : "",
	};
}

export function toLspDiagnosticsWire(file: string, diags: unknown): LspDiagnosticsWire {
	return {
		...wireIdentity(),
		action: "diagnostics",
		ok: true,
		isError: false,
		data: {
			file: typeof file === "string" ? file : "",
			diagnostics: (Array.isArray(diags) ? diags : []).map(diagnosticItemOf),
		},
	};
}

function positionWireOf(p: { line: number; character: number }): LspPositionWire {
	return { line: nonNegativeSafeInt(p.line) ?? 0, character: nonNegativeSafeInt(p.character) ?? 0 };
}

export function toLspLocationsWire(action: LspLocationAction, ctx: Readonly<LspRequestContext>, result: unknown): LspLocationsWire {
	return {
		...wireIdentity(),
		action,
		ok: true,
		isError: false,
		data: {
			file: typeof ctx.file === "string" ? ctx.file : "",
			position: positionWireOf(ctx.position),
			locations: normalizeLspLocations(result),
		},
	};
}

export function toLspHoverWire(ctx: Readonly<LspRequestContext>, hover: unknown): LspHoverWire {
	const { present, body } = hoverBodyOf(hover);
	// diting v2.11.0 全量审核 F-2：hover body 自由文本过 redactCredentials（与 diagnostics.message/rename newText 同族纪律）。
	const redactedBody = typeof body === "string" ? redactCredentials(body) : body;
	return {
		...wireIdentity(),
		action: "hover",
		ok: true,
		isError: false,
		data: {
			file: typeof ctx.file === "string" ? ctx.file : "",
			position: positionWireOf(ctx.position),
			state: present ? "present" : "absent",
			body: redactedBody,
		},
	};
}

export function toLspSymbolsWire(file: string, symbols: unknown): LspSymbolsWire {
	if (symbols === undefined || symbols === null) {
		return { ...wireIdentity(), action: "symbols", ok: true, isError: false, data: { file: typeof file === "string" ? file : "", state: "absent", symbols: null } };
	}
	try {
		const safe = strictJsonSafeCopy(symbols, new Set());
		if (!safe.ok) {
			return { ...wireIdentity(), action: "symbols", ok: true, isError: false, data: { file: typeof file === "string" ? file : "", state: "invalid", symbols: null } };
		}
		return {
			...wireIdentity(), action: "symbols", ok: true, isError: false,
			data: { file: typeof file === "string" ? file : "", state: "present", symbols: redactJsonSafeTexts(safe.value) },
		};
	} catch { /* lint-exempt: 超深嵌套/脱敏递归失败=整树无法安全转换——state=invalid 显式暴露 */
		return { ...wireIdentity(), action: "symbols", ok: true, isError: false, data: { file: typeof file === "string" ? file : "", state: "invalid", symbols: null } };
	}
}

export function toLspRenameWire(
	file: string,
	newName: unknown,
	mode: "preview" | "applied",
	editForm: "changes" | "documentChanges" | "none",
	targets: ReadonlyArray<Readonly<LspRenameTargetSource>>,
	rawWorkspaceEdit: unknown,
): LspRenameWire {
	const targetWires = (Array.isArray(targets) ? targets : []).map((t) => ({
		file: typeof t.file === "string" ? t.file : "",
		edits: (Array.isArray(t.edits) ? t.edits : []).map((e: { range: unknown; newText: unknown }) => ({
			range: normalizeLspRange(e.range), // 上游 applyTextEdits 已校验——坏源 null 产 schema-invalid wire 如实暴露
			newText: typeof e.newText === "string" ? redactCredentials(e.newText) : "",
		})),
	}));
	return {
		...wireIdentity(),
		action: "rename",
		ok: true,
		isError: false,
		data: {
			file: typeof file === "string" ? file : "",
			newName: typeof newName === "string" ? newName : "",
			mode,
			editForm,
			editCount: targetWires.reduce((n, t) => n + t.edits.length, 0),
			targets: targetWires,
			rawWorkspaceEdit: editForm === "documentChanges" ? jsonObjectSlotOf(rawWorkspaceEdit) : null,
		},
	};
}

/** 外层异常 → 五 code 分类（形态锚定 lsp-client.ts 现行错误文案；家族先例 = mcp-wire
 *  classifyMcpWireError——纯模块不 import lsp-client，P6 接线层在外层 catch 传入真实异常）。
 *  请求/诊断超时（客户端先发 $/cancelRequest 再 reject）、JSON-RPC error 应答、进程退出/
 *  未运行/熔断/启动失败 = operation（LSP 操作执行期失败）；其余 internal。 */
export function classifyLspWireError(e: unknown): LspWireErrorCode {
	if (!(e instanceof Error)) return "internal";
	const message = e.message ?? "";
	if (/LSP request timeout|LSP diagnostics timeout/.test(message)) return "operation";
	if (/LSP JSON-RPC error/.test(message)) return "operation";
	if (/已退出|未运行|stdin 不可写|熔断冷却中|启动或 initialize 失败/.test(message)) return "operation";
	return "internal";
}

/** error 分支：action 只认合法十字面（未知/缺席 → null）；message 同源脱敏（正文不脱敏）。
 *  code 语义见模块头五值分类；permission/shape 均为预执行拒绝（零副作用）。 */
export function toLspErrorWire(action: unknown, code: LspWireErrorCode, message: string): LspErrorWire {
	const known = (LSP_WIRE_ACTIONS as readonly unknown[]).includes(action) ? action as LspWireAction : null;
	return {
		...wireIdentity(),
		action: known,
		ok: false,
		isError: true,
		error: { code, message: typeof message === "string" ? redactCredentials(message) : "" },
	};
}
