/**
 * orchestrate.ts — T2-5 编排模式库（fanout/pipeline/tournament/redteam/fork）：纯语法糖，展开为 typed GroupSpec
 * 交 GroupScheduler 执行（P3-C：2026-08-19 插件进化，第二/三批拆分自 task-tool.ts L1897-2138）。
 * 随迁：nodeDeliveryMessage（L1897-1907，OMP 风格异步节点投递；createTaskTool 的 batch onNodeDone 亦消费，task-tool 回 import）。
 * 纯搬家：函数体零改动；签名适配（防 orchestrate→task-tool 循环 import）——
 *   ① sync 主链 runTask 留守 task-tool.ts，改为 orchOpts.runTask 注入（OrchestrateRunTask 结构等价签名）；
 *   ② runResumeTask/resolveSessionWithBackfill 改自 task-resume.ts 导入（原文件内解析）；
 *   ③ nodeDeliveryMessage/orchestrate 补 export 关键字（供 task-tool 回 import）。
 */
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { AgentConfig } from "./agents-loader.ts";
import { findAgentByRequest } from "./agent-aliases.ts";
import type { ModelRegistryLike } from "./model-resolver.ts";
import { runGroup, submitGroup, handoffBlock, type GroupSpec, type GroupNode, type GroupRunDeps, type GroupRunOutcome, type ResultEnvelope } from "./group-scheduler.ts";
import { genTaskId, type RunResult } from "./task-run.ts";
import { resolveSessionWithBackfill, runResumeTask } from "./task-resume.ts";
import { sendTaskCompletion, sendMachineNotice, GROUP_TERMINAL_TYPE } from "./evidence-context.ts";

/** sync 主链 runTask 的结构等价签名（RunTaskOptions 留守 task-tool.ts；编排模块不得反向 import task-tool）。 */
export type OrchestrateRunTask = (agent: AgentConfig, task: string, opts: Record<string, unknown>) => Promise<RunResult>;

/** OMP-style 异步节点投递：正文预览有界，完整结果留在 artifact/query_task，避免 steer 撑爆 Leader 上下文。 */
export function nodeDeliveryMessage(scope: "group 节点完成" | "batch 节点完成", env: ResultEnvelope): string {
	const status = env.error?.code === "blocked" ? "blocked" : env.status;
	const raw = env.display?.output || env.summary || env.error?.message || "(无输出)";
	const refs = env.artifactRefs.filter(Boolean);
	const fullHint = refs.length > 0
		? `完整结果: ${refs.join(", ")}`
		: `完整结果: query_task({ session: "${env.taskId}" })`;
	const body = raw.length <= 4000 ? raw : `${raw.slice(0, 4000)}\n…[预览已截断；${fullHint}]`;
	return `[${scope} ${env.nodeId || "?"}] 状态: ${status}\n${body}${env.display?.completionAnnotation || ""}`;
}

// ── T2-5 编排模式库（fanout/pipeline/tournament/redteam）：纯语法糖，展开为多次 runTask ─
/** 编排单组的结构复杂度上限（AMAGI_ORCH_MAX_BRANCHES，默认 4）。
 *  超上限不再静默 slice/夹紧——整单显式拒绝（零部分启动、零无记录丢失）；
 *  合法组内节点的运行并发由共享 admission FIFO 队列承载。 */
const MAX_ORCH_BRANCHES = (() => {
	const v = Number(process.env.AMAGI_ORCH_MAX_BRANCHES);
	return Number.isFinite(v) && v >= 1 ? Math.floor(v) : 4;
})();

/** 整单显式拒绝（超限/违反模板契约）；在 runTask 之前返回，保证零部分执行。 */
function orchReject(mode: string, reason: string): { content: Array<{ type: "text"; text: string }>; isError: true } {
	return { content: [{ type: "text" as const, text: `[${mode} 整单拒绝] ${reason}。当前单组分支上限 ${MAX_ORCH_BRANCHES}（结构复杂度限制；合法组内节点另由共享 admission FIFO 排队），不做部分执行（零静默丢弃、零部分启动）。请缩小单组规模，或用 AMAGI_ORCH_MAX_BRANCHES 调整上限。` }], isError: true };
}

/**
 * T2-5 编排模式（§9.6）→ v2 批次C typed group template。
 * 五模板（fanout/pipeline/tournament/redteam/fork）展开为 GroupSpec（DAG + unlock 条件），
 * 统一经 GroupScheduler 执行：节点间交接 = ResultEnvelope + artifactRefs（不再用 1500/2000
 * 字符硬截断充当完整交接协议）；依赖满足才解锁（cancelled/stale 一律不解锁，未解锁节点如实
 * 列入 skipped）；并发容量由共享 admission 承载（节点内排队，调度器不做第二份计数）。
 * 返回语义：flag 关（默认）同步等全部节点返回汇总文本（兼容语义不变）；
 * flag 开（AMAGI_GROUP_ASYNC=1 或 asyncGroup:true）submitGroup 异步 handle + 完成自动通知。
 */
export async function orchestrate(
	mode: "fanout" | "pipeline" | "tournament" | "redteam" | "fork",
	spec: any,
	topLevelTask: string,
	agents: AgentConfig[],
	ctx: { cwd: string },
	testOpts: { testCommand?: { command: string; args: string[] }; orchestrateRun?: (agent: AgentConfig, task: string, opts: { cwd: string; model?: string; onStall?: (info: { taskId: string; agent: string; idleMs: number }) => void }) => Promise<RunResult> } | undefined,
	onStall: ((info: { taskId: string; agent: string; idleMs: number }) => void) | undefined,
	orchOpts: { asyncGroup?: boolean; pi?: ExtensionAPI; runTask: OrchestrateRunTask },
): Promise<{ content: Array<{ type: "text"; text: string }>; isError?: boolean }> {
	const orchId = genTaskId().slice(0, 8);
	const runId = `orch-${orchId}`; // v2 批次A：一次 orchestrate 调用一个 runId（trace 可重建 group）
	const findAgent = (name: string) => findAgentByRequest(agents, name);
	const cap = (s: string | undefined, n = 600) => (s || "").slice(0, n);
	// v1.5.188 P1-4⑤：收集各分支派发前熔断警告，汇总首部统一前置（编排旁路天然覆盖）。
	const _fuseSeen = new Set<string>();

	// ── 模板展开（typed group template；校验与批次A一致：超限/违反契约整单显式拒绝，零部分执行） ──
	let groupSpec: GroupSpec;
	let header = "";
	if (mode === "fanout") {
		const branches: any[] = Array.isArray(spec) ? spec : [];
		if (branches.length === 0) return { content: [{ type: "text" as const, text: "[fanout] 至少 1 分支" }], isError: true };
		if (branches.length > MAX_ORCH_BRANCHES) return orchReject("fanout", `请求 ${branches.length} 分支超过上限`);
		header = `[编排 fanout · orch-${orchId} · ${branches.length} 分支并行]`;
		groupSpec = { runId, nodes: branches.map((b, i) => ({ nodeId: `fanout-${i + 1}`, agent: b.agent, task: b.task, model: b.model })) };
	} else if (mode === "pipeline") {
		const branches: any[] = Array.isArray(spec) ? spec : [];
		if (branches.length === 0) return { content: [{ type: "text" as const, text: "[pipeline] 至少 1 节点" }], isError: true };
		header = `[编排 pipeline · orch-${orchId} · ${branches.length} 节点串行]`;
		// v2 批次C：前序交接 = envelope + artifactRefs（read result.md 全文），替换 2000 字符硬截断；
		// unlockOn=completed 保持链暂停语义（上游非 completed 级联跳过，不为并发破坏真实依赖）。
		// K8b 裁量：pipeline 作为旧模板经兼容解释器保留旧条件（unlockOn=completed ⟺ 上游执行成功）——
		// 新契约 requires 边（accepted/ready/settled 消费回执三轴）属新图声明面（task_batch I1 接线）；
		// 直接升级 requires=accepted 会使每次链式推进插入 Leader 显式接受（旧模板变义，K8b 风险项）。
		groupSpec = { runId, nodes: branches.map((b, i) => ({
			nodeId: `pipeline-${i + 1}`, agent: b.agent, model: b.model,
			task: i === 0 ? b.task : undefined,
			buildTask: i === 0 ? undefined : (deps: Record<string, ResultEnvelope>) => `${b.task}\n\n${handoffBlock(`前序节点产出 · pipeline-${i}`, deps[`pipeline-${i}`])}`,
			dependsOn: i > 0 ? [`pipeline-${i}`] : undefined,
			unlockOn: i > 0 ? "completed" as const : undefined,
		})) };
	} else if (mode === "tournament") {
		const { agent, task, n, judge } = spec || {};
		// v2 批次A：n 不再静默夹紧——显式给定时必须合法（2..MAX 整数），否则整单拒绝；缺省 3。
		let N = 3;
		if (n !== undefined) {
			const nNum = Number(n);
			if (!Number.isInteger(nNum) || nNum < 2) return orchReject("tournament", `n=${JSON.stringify(n)} 非法：并行实例数至少 2`);
			if (nNum > MAX_ORCH_BRANCHES) return orchReject("tournament", `请求 n=${nNum} 超过上限`);
			N = nNum;
		}
		const judgeName = judge || "diting";
		header = `[编排 tournament · orch-${orchId} · ${N} 实例并行 + ${judgeName} 择优]`;
		const implNodeIds = Array.from({ length: N }, (_, i) => `tournament-impl-${i + 1}`);
		const implTask = task || topLevelTask;
		// judge 依赖全部 impl 是合理 barrier（首版仍用 all，不加 quorum/first-valid——v2 §7.4）；
		// 交接含各分支 artifact refs 全文引用，替换 1500 字符硬截断。
		// K8b：judge 是审查型下游（diting 择优）——requires=ready 审查边：impl 回执 settlement=ready
		// 即解锁（不等 Leader 接受）；无回执面（mock 注入）走兼容解释回退（envelope completed ⟺ ready）。
		groupSpec = { runId, nodes: [
			...implNodeIds.map((id) => ({ nodeId: id, agent, task: implTask })),
			{ nodeId: "tournament-judge", agent: judgeName, dependsOn: implNodeIds, requires: "ready" as const, buildTask: (deps: Record<string, ResultEnvelope>) => `以下是对同一任务的 ${N} 个并行实现，请择优并说明理由：\n\n${implNodeIds.map((id, i) => handoffBlock(`实现分支 ${i + 1}`, deps[id])).join("\n\n")}\n\n输出格式：优胜分支编号 + 选择理由 + 综合改进建议。` },
		] };
	} else if (mode === "redteam") {
		const branches: any[] = Array.isArray(spec) ? spec : [];
		const impls = branches.filter((b: any) => !b.adversarial);
		const attackers = branches.filter((b: any) => b.adversarial);
		// v2 批次A：输入契约=恰好 1 个实现节点 + 零到多个攻击节点；多实现输入整单拒绝（不再静默只取第一个）。
		if (impls.length === 0) return { content: [{ type: "text" as const, text: "[redteam] 需恰好 1 个非 adversarial 实现分支（当前 0 个）" }], isError: true };
		if (impls.length > 1) return orchReject("redteam", `当前契约恰好 1 个实现节点，收到 ${impls.length} 个非 adversarial 实现分支——多实现输入不被静默忽略`);
		if (attackers.length > MAX_ORCH_BRANCHES) return orchReject("redteam", `请求 ${attackers.length} 攻击分支超过上限`);
		const implBranch = impls[0];
		header = `[编排 redteam · orch-${orchId} · 实现 ${implBranch.agent} + ${attackers.length} 攻击]`;
		// 实现完成后解锁全部攻击节点（攻击之间并行）；交接为 impl artifact refs 全文引用，替换 2000 字符硬截断。
		// K8b：attack 是审查型下游（对抗审查）——requires=ready 审查边：impl 回执 settlement=ready
		// 即解锁（不等 Leader 接受）；无回执面（mock 注入）走兼容解释回退（envelope completed ⟺ ready）。
		groupSpec = { runId, nodes: [
			{ nodeId: "redteam-impl", agent: implBranch.agent, task: implBranch.task || topLevelTask, model: implBranch.model },
			...attackers.map((a, i) => ({ nodeId: `redteam-attack-${i + 1}`, agent: a.agent, model: a.model, dependsOn: ["redteam-impl"], requires: "ready" as const, buildTask: (deps: Record<string, ResultEnvelope>) => `${a.task || "审查以下实现，寻找缺陷/漏洞/边界遗漏（红队对抗视角）"}：\n\n${handoffBlock("被审实现", deps["redteam-impl"])}` })),
		] };
	} else {
		// fork
		const { session, branches } = spec || {};
		const forkBranches: any[] = Array.isArray(branches) ? branches : [];
		if (forkBranches.length === 0) return { content: [{ type: "text" as const, text: "[fork] 至少 1 分叉枝" }], isError: true };
		if (forkBranches.length > MAX_ORCH_BRANCHES) return orchReject("fork", `请求 ${forkBranches.length} 分叉枝超过上限`);
		// v2 批次A：fork 源任务登记为 parentTaskId（运行图父子关系；解析失败不阻断）。
		let parentTaskId: string | undefined;
		// v1.5.222：fork 源解析同样走磁盘回填（Leader 重启后 fork 不断链）；解析失败仍不阻断。
		try { parentTaskId = resolveSessionWithBackfill(String(session))?.taskId; } catch {}
		const nParallel = forkBranches.filter((b) => b?.readOnly === true).length;
		header = `[编排 fork · orch-${orchId} · 从 ${String(session).slice(0, 8)} 分叉 ${forkBranches.length} 枝（各自独立 sessionId/taskId${nParallel > 1 ? `；${nParallel} 枝 readOnly 真并发` : ""}）]`;
		// v2 批次A 并发策略 DAG 化：serial（未声明）枝依赖截至上一枝的全部节点（barrier 全集）；
		// readOnly 枝只依赖最近 serial 段边界——同段 readOnly 枝互不依赖、真实并发（各枝独立
		// sessionFile + 显式无写副作用），未声明枝保持串行不被并发放大。
		const nodes: GroupNode[] = [];
		const prevAll: string[] = [];      // 截至上一枝的全部节点
		let lastSerialDeps: string[] = []; // readOnly 枝的共同依赖（最近 serial 段边界及其之前全部）
		forkBranches.forEach((b, i) => {
			const nodeId = `fork-${i + 1}`;
			if (b?.readOnly === true) {
				nodes.push({ nodeId, agent: b.agent, model: b.model, kind: "fork" as const, task: b.task, dependsOn: lastSerialDeps.length ? [...lastSerialDeps] : undefined, parentTaskId });
			} else {
				nodes.push({ nodeId, agent: b.agent, model: b.model, kind: "fork" as const, task: b.task, dependsOn: prevAll.length ? [...prevAll] : undefined, parentTaskId });
				lastSerialDeps = [...prevAll, nodeId];
			}
			prevAll.push(nodeId);
		});
		groupSpec = { runId, nodes, forkSession: String(session) };
	}

	// ── GroupScheduler 执行（同步兼容 / 异步 handle 两路径） ──
	const deps: GroupRunDeps = {
		cwd: ctx.cwd, modelRegistry: (ctx as { modelRegistry?: ModelRegistryLike }).modelRegistry, command: testOpts?.testCommand, onStall,
		onNodeDone: orchOpts?.asyncGroup ? (env) => {
			// ev-20261101-7fffc6：节点完成投递走 custom 机器通道（amagi:task-completion + details.taskId）。
			sendTaskCompletion(orchOpts.pi, nodeDeliveryMessage("group 节点完成", env), env.taskId);
		} : undefined,
		runTask: orchOpts.runTask, // P3-C：sync 主链 runTask 留守 task-tool.ts，由 createTaskTool 注入（防 orchestrate→task-tool 反向依赖）
		runResume: (ag, p, o) => runResumeTask(ag, p as Parameters<typeof runResumeTask>[1], o as unknown as Parameters<typeof runResumeTask>[2]),
		findAgent,
		testRunNode: testOpts?.orchestrateRun ? (ag, task, o) => testOpts.orchestrateRun!(ag, task, { cwd: o.cwd, model: o.model, onStall }) : undefined,
		trusted: (ctx as { isProjectTrusted?: () => boolean }).isProjectTrusted?.() ?? false,
	};

	// 展示：envelope → 兼容分支行（display sidecar 保留原 output/标注；状态标签与旧汇总一致）
	const labelOf = (env: ResultEnvelope): string => env.display?.status || (env.status === "completed" ? "done" : env.status === "cancelled" ? "cancelled" : env.status === "stale" ? "stale" : env.error?.code === "blocked" ? "blocked" : "error");
	const renderEnvBody = (env: ResultEnvelope, capN = 600, emptyHint = "(无输出)"): string =>
		`${env.error?.code === "blocked" ? "BLOCKED" : cap(env.display?.output ?? env.summary, capN) || env.error?.message || emptyHint}${env.display?.completionAnnotation || ""}${env.display?.modelNote ? `\n  ${env.display.modelNote}` : ""}`;
	const id8 = (env?: ResultEnvelope) => (env?.taskId || "?").slice(0, 8);

	const renderOutcome = (outcome: GroupRunOutcome): string => {
		const lines: string[] = [header];
		// K8b：暂停等待人工接受——待接受明细前置（Leader decide 后 resume 续跑，非终局）
		if (outcome.awaitingAcceptance?.length) {
			for (const a of outcome.awaitingAcceptance) lines.push(`⏸ 等待 Leader 接受: ${a.nodeId} #${a.taskId.slice(0, 8)}（receiptId=${a.receiptId}）——阻塞 ${a.blockedNodes.join("、")}`);
			lines.push(`（显式 decide accept 后组续跑；未启动节点已保留不级联跳过）`);
		}
		const envOf = (nodeId: string) => outcome.envelopes[nodeId];
		if (mode === "fanout") {
			groupSpec.nodes.forEach((n, i) => {
				const env = envOf(n.nodeId);
				if (env) lines.push(`分支${i + 1} ${n.agent}#${id8(env)}: ${labelOf(env)} — ${renderEnvBody(env, 200)}`);
			});
		} else if (mode === "pipeline") {
			groupSpec.nodes.forEach((n, i) => {
				const env = envOf(n.nodeId);
				if (env) lines.push(`节点${i + 1} ${n.agent}#${id8(env)}: ${labelOf(env)} — ${renderEnvBody(env, 200)}`);
			});
			const firstSkipped = outcome.skipped[0];
			if (firstSkipped) {
				const idx = groupSpec.nodes.findIndex((n) => n.nodeId === firstSkipped.nodeId);
				const up = outcome.envelopes[`pipeline-${idx}`];
				const blocked = up?.error?.code === "blocked";
				const why = blocked ? "暂停（blocked）" : up?.status === "cancelled" ? "中止（cancelled）" : up?.status === "stale" ? "中止（stale）" : "中止（error）";
				lines.push(`⚠ 链在节点 ${idx} ${why}：${blocked ? "补足信息后 resume" : "修复后重试"}该节点继续链。`);
			} else {
				lines.push(`✓ 链全部完成（${groupSpec.nodes.length} 节点）`);
			}
		} else if (mode === "tournament") {
			groupSpec.nodes.forEach((n, i) => {
				if (n.nodeId === "tournament-judge") return;
				const env = envOf(n.nodeId);
				if (env) lines.push(`实现${i + 1} ${n.agent}#${id8(env)}: ${labelOf(env)} — ${renderEnvBody(env, 150)}`);
			});
			const jr = envOf("tournament-judge");
			if (jr) {
				lines.push(`\n[择优 ${groupSpec.nodes.find((n) => n.nodeId === "tournament-judge")?.agent || "judge"}#${id8(jr)}: ${labelOf(jr)}]`);
				lines.push(renderEnvBody(jr, 1500, "(择优无输出)"));
			}
		} else if (mode === "redteam") {
			const ir = envOf("redteam-impl");
			if (ir) {
				lines.push(`[实现 ${groupSpec.nodes[0].agent}#${id8(ir)}: ${labelOf(ir)}]`);
				lines.push(renderEnvBody(ir, 800, "(实现无输出)"));
			}
			groupSpec.nodes.forEach((n, i) => {
				if (n.nodeId === "redteam-impl") return;
				const env = envOf(n.nodeId);
				if (env) {
					lines.push(`\n[攻击${i} ${n.agent}#${id8(env)}: ${labelOf(env)}]`);
					lines.push(renderEnvBody(env, 800, "(攻击无输出)"));
				}
			});
		} else {
			groupSpec.nodes.forEach((n, i) => {
				const env = envOf(n.nodeId);
				if (env) lines.push(`分叉${i + 1} ${n.agent}#${id8(env)}: ${labelOf(env)} — ${renderEnvBody(env, 200)}`);
			});
			lines.push(`（真实 --fork 分叉，各枝独立 sessionFile，互不污染）`);
		}
		// 级联跳过如实列出（不静默消失；pipeline 已在暂停行专项呈现）
		if (mode !== "pipeline") {
			for (const s of outcome.skipped) lines.push(`⚠ 节点 ${s.nodeId} 未执行：${s.reason}`);
		}
		return lines.join("\n");
	};

	// v2 批次C flag 开：submitGroup 异步 handle——Leader 不被长 group 隐式 await 占住；
	// 完成经 background completion steer 自动通知（复用既有回流通道），wait/cancel 是显式动作。
	// K8b：requires=accepted 边等待 Leader 接受时组暂停（onPaused 通知待接受明细，不阻塞）。
	if (orchOpts?.asyncGroup) {
		submitGroup(groupSpec, deps, {
			onDone: (outcome) => {
				for (const env of Object.values(outcome.envelopes)) if (env.display?.fuseWarning) _fuseSeen.add(env.display.fuseWarning);
				const text = renderOutcome(outcome);
				// ev-20261101-7fffc6：组终局/暂停走 custom 机器通道（amagi:group-terminal + details.runId/orchId
				// ——组句柄是 runId，不冒充 taskId；节点级 taskId 已在 onNodeDone 逐个投递）。
				sendMachineNotice(orchOpts.pi, GROUP_TERMINAL_TYPE, `${_fuseSeen.size ? [..._fuseSeen].join("") : ""}[group 完成 orch-${orchId}] ${outcome.isError ? "含失败/跳过节点" : "全部完成"}\n${text}`, { runId, orchId });
			},
			onPaused: (outcome) => {
				sendMachineNotice(orchOpts.pi, GROUP_TERMINAL_TYPE, `[group 暂停 orch-${orchId} · 等待 Leader 接受]\n${renderOutcome(outcome)}\ntask_control accept 该节点回执后组自动可续；task({ cancel: "${runId}" }) 级联取消。`, { runId, orchId });
			},
		});
		return { content: [{ type: "text" as const, text: `[submitGroup · orch-${orchId} · ${groupSpec.nodes.length} 节点] 已受理并异步执行（共享准入 FIFO 排队）。\n节点 taskId 陆续出现：task({ wait: { group: "${runId}", mode: "all" } }) 显式等待全部收尾；task({ cancel: "${runId}" }) 级联取消（无孤儿 worker）。\n[异步契约] 完成时自动通知（含各节点状态与 artifact 引用）；通知到达前不要轮询/重复提交，可并行推进不相关工作。` }] };
	}

	// flag 关（默认）：同步等待全部节点，返回汇总文本（兼容语义不变）。
	// K8b 规则 4：组内存在等待 Leader 接受的节点时不阻塞同步等完整图——注册暂停组并立即返回
	// 组句柄（Leader 显式 decide accept 后 resumeGroupAfterAcceptance 续跑；工具面接线属 K8c/I1）。
	const outcome = await runGroup(groupSpec, deps);
	if (outcome.awaitingAcceptance?.length) {
		submitGroup(groupSpec, deps, {
			carry: { envelopes: outcome.envelopes, skipped: outcome.skipped, isError: outcome.isError },
			onDone: (finalOutcome) => {
				sendMachineNotice(orchOpts?.pi, GROUP_TERMINAL_TYPE, `[group 续跑完成 orch-${orchId}] ${finalOutcome.isError ? "含失败/跳过节点" : "全部完成"}\n${renderOutcome(finalOutcome)}`, { runId, orchId });
			},
			onPaused: (pausedOutcome) => {
				sendMachineNotice(orchOpts?.pi, GROUP_TERMINAL_TYPE, `[group 暂停 orch-${orchId} · 等待 Leader 接受]\n${renderOutcome(pausedOutcome)}\ntask_control accept 该节点回执后组自动可续。`, { runId, orchId });
			},
		});
		return { content: [{ type: "text" as const, text: `${renderOutcome(outcome)}\n\n[group 暂停 · ${runId} · 等待 Leader 接受] 已注册组句柄，未启动节点保留（不级联跳过）。Leader task_control accept 后组自动可续；task({ cancel: "${runId}" }) 级联取消；task({ wait: { group: "${runId}", mode: "all" } }) 等待终局。` }] };
	}
	for (const env of Object.values(outcome.envelopes)) if (env.display?.fuseWarning) _fuseSeen.add(env.display.fuseWarning);
	return { content: [{ type: "text" as const, text: (_fuseSeen.size ? [..._fuseSeen].join("") : "") + renderOutcome(outcome) }], isError: outcome.isError };
}
