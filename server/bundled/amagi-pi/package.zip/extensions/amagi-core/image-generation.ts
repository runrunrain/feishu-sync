/**
 * image-generation.ts — C14（十月迭代 M4，设计 §6.4/F6 终局 Delta）：宿主生图与图像产物证据。
 *
 * 分层（适配器 → 宿主解码探测 → 落盘 → 证据 → 审计，守卫横切）：
 *   - 适配器层：ImageGenerationAdapter（generate(spec, ctx) → outcome）。
 *     · MockImageAdapter——确定性 SVG/PNG 字节生成（测试与机制验证；零 IO、零真实模型调用）。
 *     · HostImageAdapter——ctx.modelRegistry.generateImages 适配骨架（API 形状经 pi-ai 1.0.2
 *       dist/types.d.ts 核实：ImagesContext={input:(text|image)[]}、AssistantImages={stopReason,
 *       errorMessage?,output,usage?}，image block 含 base64 data+mimeType）。surface 未注入即
 *       拒绝——默认不可用；能力门+预算授权双门由 runImageGeneration 调用面统一把关。
 *   - 解码探测层（F6 终局）：image-decoder.ts——真实解码 100% 委托公共包根 resizeImage
 *     （一请求一受监督 worker）；amagi 不再有手写格式校验器。严格成功必须取得宿主主栅格
 *     解码 passed 观测；尺寸恒取宿主观测；SVG/WebP 及未知 MIME 明确不支持。amagi 证明落盘
 *     字节身份并记录「指定宿主解码器在指定范围内成功」的限域事实（host-primary-raster-v1）
 *     ——不声明完整格式规范符合性/全部动画帧/元数据正确性（formatConformance 恒 not-assessed）；
 *     落盘只消费 decode 前冻结的字节快照，digest 校验先于任何持久化（B1：失败零磁盘痕迹）；
 *     落盘前另作完整操作预算复核（B2：晚到 passed 不落盘）；首个落盘副作用前再终审一次完整
 *     预算（AC7 收尾：预算门后的只读准备——参考图读取/写点预检——跨截止即零写入零证据）。
 *   - 落盘层：persistGeneratedImage——复用 artifact 协议归档目录（<artifactRoot>/<taskId>/images/，
 *     metadata v2 记录尺寸/digest/解码观测/生成参数摘要）；显式 outputPath 复用同源 deny/写面检查
 *     （file-permission 执法面）+ 真实落点 symlink/父目录复核，不只检查请求字符串；写后回读+sha256。
 *   - 证据面：ImageEvidenceEntry v2（evidence.ts buildImageEvidenceEntry）——路径+digest+限域解码
 *     观测；完整格式符合性与视觉有效性恒 not-assessed（前者属解码器规范裁决，后者需 luoshen/人工）。
 *   - 审计面：有界环形缓冲（64 条）记录 gate 决策与生成结果；prompt 只记 digest，原始 base64
 *     零落日志/零进 text 通道（findImageBase64InText 双向自检）。
 *
 * 预算纪律（设计 §6.4/F6 终局口径）：一次一图；单图编码文件字节上限 20 MiB（base64 还原后——
 * 非像素内存上限）；完整操作 180s 单调时钟预算不因解码重置（probe 子预算=min(剩余,10s)），取消/
 * 超时后迟到结果丢弃不写盘（解码 worker 由父侧 terminate 回收）。真实 generateImages 调用不在
 * 本切片（需主上预算授权）；本模块不注册新工具——缺安全落盘机制即不注册。图像只作参考证据，
 * 不自动满足视觉验收、不写 accepted；SVG 源文档只可作为明确未验证的独立 artifact 交付，不走
 * 严格生图成功分支。
 *
 * 边界：不触碰 rpc-pool、mcp-*、continuation、input-router；零真实 ~/.pi 写入（artifactRoot 可经
 * AMAGI_ARTIFACT_ROOT 测试注入，既有逃生舱）；不引入新 AMAGI_* 开关；不新增图像解码依赖。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import * as zlib from "node:zlib";
import { createHash } from "node:crypto";
import { performance } from "node:perf_hooks";

import { artifactEnabled, artifactRoot, sanitizeId } from "./artifact.ts";
import {
	enforceFileWriteTargets,
	fileReadPermissionBlockReason,
	realpathNearestExisting,
} from "./file-permission.ts";
import { buildImageEvidenceEntry, type ImageEvidenceEntry } from "./evidence.ts";
import {
	defaultHostImageDecoder,
	decodeResultAdmission,
	IMAGE_DECODE_LIMIT_BYTES,
	IMAGE_DECODE_POLICY_VERSION,
	imageDecodeErrorCode,
	imageDecodeFailureText,
	type ImageDecodePassed,
	type ImageDecoderLike,
	type ImageGenerationErrorCode,
} from "./image-decoder.ts";
import { findImageBase64InText, redactImageBase64InText } from "./guards.ts";

export { IMAGE_DECODE_LIMIT_BYTES, IMAGE_DECODE_POLICY_VERSION } from "./image-decoder.ts";

// ── 0. 预算常量（设计 §6.4 试点口径；导出供测试与报告引用） ────────────────────

/** 完整生图操作预算（180s；单调时钟——probe 子预算不重置本预算）。 */
export const IMAGE_OPERATION_TIMEOUT_MS = 180_000;
/** 审计环形缓冲容量。 */
export const IMAGE_AUDIT_CAP = 64;

// ── 1. 适配器层类型 ───────────────────────────────────────────────────────────

/** 生图请求（对齐设计 §6.4 提议接口 {modelRef, prompt, referencePaths?, outputPath}）。 */
export interface ImageGenerationSpec {
	/** 物理/逻辑模型引用（如 "provider/model"；mock 下仅作确定性种子与审计标识）。 */
	modelRef: string;
	prompt: string;
	/** 参考图路径（luoshen 参考图场景；host 侧经 deny 检查后读入为 image input block）。 */
	referencePaths?: readonly string[];
	/** mock 专用输出格式（缺省 png）；host 侧格式由模型/宿主决定。 */
	format?: "png" | "svg";
	/** 产物名主干（归档目录内文件名；sanitize 为 [A-Za-z0-9._-]，缺省 "image"）。 */
	outputName?: string;
	/** 显式输出路径（相对 cwd 或绝对；缺省落 artifact 归档目录）。 */
	outputPath?: string;
	/** 归因 taskId（artifact 目录与证据条目）。 */
	taskId: string;
	/** 归因角色（如 "luoshen"/"leader"）。 */
	agent: string;
}

/** 适配器执行上下文（cwd 由调用面注入——适配器不猜测工作目录）。 */
export interface ImageAdapterRunContext {
	cwd: string;
}

/** 已解码图像载荷（bytes 为解码后字节；base64 只存在于适配器内部，绝不外流）。 */
export interface GeneratedImagePayload {
	mimeType: string;
	bytes: Buffer;
	width?: number;
	height?: number;
}

/** 用量摘要（host 从 AssistantImages.usage 提取；mock 恒 0 且 costKnown=true）。 */
export interface ImageGenerationUsage {
	inputTokens?: number;
	outputTokens?: number;
	totalTokens?: number;
	costUsd?: number;
	/** false = provider 未上报费用（如实 unknown，不伪造 0）。 */
	costKnown: boolean;
}

/** 适配器生成结果。ok=false 时 error 必填（含真实失败关键词，不编造）。 */
export interface ImageGenerationOutcome {
	ok: boolean;
	stopReason: string;
	/** 0..1（设计裁定一次一图；>1 时取首图并在 textNotes 注记）。 */
	images: GeneratedImagePayload[];
	/** 模型 text block（经 base64 自检/redact 后——不作为视觉判断依据）。 */
	textNotes: string[];
	usage?: ImageGenerationUsage;
	error?: string;
	/** 参考图 sha256 列表（实际提交给模型字节的 digest——不可变调用事实，F7：生成后重读不得
	 *  替代输入快照；host 适配器读入时计算并携带，mock 零 IO 不携带）。 */
	referenceDigests?: string[];
}

export interface ImageGenerationAdapter {
	readonly kind: "mock" | "host";
	generate(spec: ImageGenerationSpec, ctx: ImageAdapterRunContext): Promise<ImageGenerationOutcome>;
}

// ── 2. 确定性编码器（mock 字节源；导出供测试独立复核 PNG 结构） ────────────────

const CRC32_TABLE = (() => {
	const t = new Uint32Array(256);
	for (let n = 0; n < 256; n++) {
		let c = n;
		for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
		t[n] = c >>> 0;
	}
	return t;
})();

function crc32(buf: Buffer): number {
	let c = 0xffffffff;
	for (let i = 0; i < buf.length; i++) c = CRC32_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
	return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
	const len = Buffer.alloc(4);
	len.writeUInt32BE(data.length, 0);
	const typeBuf = Buffer.from(type, "ascii");
	const crc = Buffer.alloc(4);
	crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
	return Buffer.concat([len, typeBuf, data, crc]);
}

/** 确定性最小 PNG（8-bit truecolor RGB，无压缩依赖差异——同 seed 同字节流）。 */
export function encodeDeterministicPng(width: number, height: number, seedHex: string): Buffer {
	const seed = Buffer.from(seedHex.slice(0, 16).padEnd(16, "0"), "hex");
	const base = [seed[0], seed[1], seed[2]];
	const ihdr = Buffer.alloc(13);
	ihdr.writeUInt32BE(width, 0);
	ihdr.writeUInt32BE(height, 4);
	ihdr[8] = 8; // bit depth
	ihdr[9] = 2; // color type: truecolor RGB
	const raw = Buffer.alloc(height * (1 + width * 3));
	for (let y = 0; y < height; y++) {
		const row = y * (1 + width * 3);
		raw[row] = 0; // filter: none
		for (let x = 0; x < width; x++) {
			const o = row + 1 + x * 3;
			raw[o] = (base[0] + x * 2) & 0xff;
			raw[o + 1] = (base[1] + y * 2) & 0xff;
			raw[o + 2] = (base[2] + ((x + 1) * (y + 1))) & 0xff;
		}
	}
	const idat = zlib.deflateSync(raw, { level: 9 });
	return Buffer.concat([
		Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
		pngChunk("IHDR", ihdr),
		pngChunk("IDAT", idat),
		pngChunk("IEND", Buffer.alloc(0)),
	]);
}

/** 确定性 SVG（文本字节；内嵌 promptDigest 摘要标签——不含 prompt 原文）。 */
export function renderDeterministicSvg(width: number, height: number, seedHex: string, promptDigest: string): string {
	const c1 = `#${seedHex.slice(0, 6)}`;
	const c2 = `#${seedHex.slice(6, 12)}`;
	const r = 8 + (parseInt(seedHex.slice(12, 14), 16) % Math.max(1, Math.floor(width / 3)));
	const cx = 8 + (parseInt(seedHex.slice(14, 16), 16) % Math.max(1, width - 16));
	const cy = 8 + (parseInt(seedHex.slice(16, 18), 16) % Math.max(1, height - 16));
	return (
		`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">` +
		`<rect width="100%" height="100%" fill="${c1}"/>` +
		`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${c2}" opacity="0.85"/>` +
		`<text x="6" y="${height - 6}" font-family="monospace" font-size="10" fill="#ffffff">amagi-mock ${promptDigest.slice(0, 16)}</text>` +
		`</svg>`
	);
}

// ── 3. MockImageAdapter（确定性；零 IO、零真实模型调用） ───────────────────────

/** mock 确定性种子：对 {modelRef, prompt, 排序后 referencePaths, format} 的 sha256。 */
export function mockSeedHex(spec: ImageGenerationSpec): string {
	const canonical = JSON.stringify({
		modelRef: spec.modelRef,
		prompt: spec.prompt,
		refs: [...(spec.referencePaths ?? [])].sort(),
		format: spec.format ?? "png",
	});
	return createHash("sha256").update(canonical, "utf8").digest("hex");
}

export function promptDigestOf(prompt: string): string {
	return createHash("sha256").update(prompt, "utf8").digest("hex");
}

export function fileDigestOf(bytes: Buffer): string {
	return createHash("sha256").update(bytes).digest("hex");
}

export class MockImageAdapter implements ImageGenerationAdapter {
	readonly kind = "mock" as const;
	async generate(spec: ImageGenerationSpec): Promise<ImageGenerationOutcome> {
		const seed = mockSeedHex(spec);
		const digest = promptDigestOf(spec.prompt);
		const width = 96;
		const height = 64;
		if (spec.format === "svg") {
			const svg = renderDeterministicSvg(width, height, seed, digest);
			return {
				ok: true,
				stopReason: "stop",
				images: [{ mimeType: "image/svg+xml", bytes: Buffer.from(svg, "utf8"), width, height }],
				textNotes: [`[mock] 确定性 SVG 生成（seed=${seed.slice(0, 12)}…，promptDigest=${digest.slice(0, 12)}…）`],
				usage: { totalTokens: 0, costUsd: 0, costKnown: true },
			};
		}
		const png = encodeDeterministicPng(width, height, seed);
		return {
			ok: true,
			stopReason: "stop",
			images: [{ mimeType: "image/png", bytes: png, width, height }],
			textNotes: [`[mock] 确定性 PNG 生成（seed=${seed.slice(0, 12)}…，promptDigest=${digest.slice(0, 12)}…）`],
			usage: { totalTokens: 0, costUsd: 0, costKnown: true },
		};
	}
}

// ── 4. HostImageAdapter（ctx.modelRegistry.generateImages 骨架；默认不可用） ────

/** generateImages 返回的结构投影（pi-ai AssistantImages；防御式解析，不 import pi-ai 类型）。 */
export interface HostImagesCallResult {
	stopReason?: unknown;
	errorMessage?: unknown;
	output?: unknown;
	usage?: { input?: unknown; output?: unknown; totalTokens?: unknown; cost?: { total?: unknown } };
	provider?: unknown;
	model?: unknown;
}

/** 宿主生图面（事件 ctx.modelRegistry 投影；与 host-capabilities 探测同源形状）。 */
export interface HostModelRegistrySurface {
	generateImages(model: unknown, context: unknown, options?: unknown): Promise<HostImagesCallResult>;
}

/** 参考图读取结果。 */
interface ReferenceImageRead {
	ok: boolean;
	error?: string;
	block?: { type: "image"; data: string; mimeType: string };
	digest?: string;
}

const REF_MIME_BY_EXT: Record<string, string> = {
	".png": "image/png",
	".jpg": "image/jpeg",
	".jpeg": "image/jpeg",
	".gif": "image/gif",
	".webp": "image/webp",
	".bmp": "image/bmp",
};

function sniffImageMime(p: string): string | null {
	return REF_MIME_BY_EXT[path.extname(p).toLowerCase()] ?? null;
}

/** base64 合法性（解码前先验字符集——坏 base64 负例在解码前拒绝，不产生半解码产物）。 */
function isPlausibleBase64(s: string): boolean {
	return /^[A-Za-z0-9+/]+={0,2}$/.test(s);
}

/** text 通道自检：命中 base64 图像数据即整段 redact（守卫同款检测器，纵深防御）。 */
function sanitizeTextForChannel(text: string): string {
	const hit = findImageBase64InText(text);
	if (!hit) return text;
	return `[redacted: base64 图像数据不得进入 text 通道（${hit.kind}，${hit.matchedLength} 字符）]`;
}

export class HostImageAdapter implements ImageGenerationAdapter {
	readonly kind = "host" as const;
	private readonly timeoutMs: number;
	private readonly maxDecodeBytes: number;

	constructor(
		private readonly deps: {
			/** ctx.modelRegistry 投影；未提供 → generate 恒拒绝（默认不可用）。 */
			surface?: HostModelRegistrySurface;
			/** 模型对象（从宿主目录选定的已登录可用 image 模型；接线/试验阶段注入）。 */
			model?: unknown;
			timeoutMs?: number;
			maxDecodeBytes?: number;
		} = {},
	) {
		this.timeoutMs = deps.timeoutMs ?? IMAGE_OPERATION_TIMEOUT_MS;
		this.maxDecodeBytes = deps.maxDecodeBytes ?? IMAGE_DECODE_LIMIT_BYTES;
	}

	/** 参考图读入：deny 禁入检查 → 存在性/大小/mime 校验 → base64 化为 image input block。 */
	private readReference(p: string, cwd: string): ReferenceImageRead {
		const deny = fileReadPermissionBlockReason(cwd, p);
		if (deny) return { ok: false, error: `参考图被 deny 拒绝：${p}（${deny}）` };
		const mime = sniffImageMime(p);
		if (!mime) return { ok: false, error: `参考图格式不支持：${p}（支持 png/jpg/jpeg/gif/webp/bmp）` };
		let bytes: Buffer;
		try {
			const abs = path.resolve(cwd, p);
			const st = fs.statSync(abs);
			if (!st.isFile()) return { ok: false, error: `参考图不是常规文件：${p}` };
			if (st.size > this.maxDecodeBytes) {
				return { ok: false, error: `参考图超解码上限（${st.size}B > ${this.maxDecodeBytes}B）：${p}` };
			}
			bytes = fs.readFileSync(abs);
		} catch (e) {
			return { ok: false, error: `参考图不可读：${p}（${e instanceof Error ? e.message : String(e)}）` };
		}
		return {
			ok: true,
			block: { type: "image", data: bytes.toString("base64"), mimeType: mime },
			digest: fileDigestOf(bytes),
		};
	}

	async generate(spec: ImageGenerationSpec, ctx: ImageAdapterRunContext): Promise<ImageGenerationOutcome> {
		const { surface, model } = this.deps;
		if (!surface || typeof surface.generateImages !== "function" || model === undefined) {
			// 默认不可用：surface/model 未注入（能力探测未命中或接线未授权）——诚实拒绝，不降级 mock。
			return { ok: false, stopReason: "error", images: [], textNotes: [], error: "host-surface-unavailable：ctx.modelRegistry.generateImages 或 image 模型未注入（默认不可用；需能力探测命中 + 会话授权接线）" };
		}
		// 参考图：deny 检查 + 读入（失败即拒——不静默丢弃参考输入）；读入时即固化提交字节 digest
		//（F7：不可变调用事实，贯穿 outcome→metadata/evidence——不得用生成后的重读替代）。
		const refBlocks: Array<{ type: "image"; data: string; mimeType: string }> = [];
		const refDigests: string[] = [];
		for (const ref of spec.referencePaths ?? []) {
			const r = this.readReference(ref, ctx.cwd);
			if (!r.ok) return { ok: false, stopReason: "error", images: [], textNotes: [], error: r.error };
			refBlocks.push(r.block!);
			refDigests.push(r.digest!);
		}
		const imagesContext = {
			input: [{ type: "text", text: spec.prompt }, ...refBlocks],
		};
		let raw: HostImagesCallResult;
		try {
			raw = await Promise.race([
				surface.generateImages(model, imagesContext),
				new Promise<never>((_, reject) => {
					setTimeout(() => reject(new Error(`IMAGE_TIMEOUT_${this.timeoutMs}ms`)), this.timeoutMs).unref?.();
				}),
			]);
		} catch (e) {
			const msg = e instanceof Error ? e.message : String(e);
			if (msg.startsWith("IMAGE_TIMEOUT_")) {
				// 超时/取消语义：迟到结果丢弃不写盘（race 已脱离底层 promise；persist 由调用面在其后）。
				return { ok: false, stopReason: "aborted", images: [], textNotes: [], error: `生图操作超时（${this.timeoutMs}ms）——迟到结果丢弃不写盘（设计 §6.4）` };
			}
			return { ok: false, stopReason: "error", images: [], textNotes: [], error: `generateImages 调用失败：${msg}` };
		}
		const stopReason = typeof raw?.stopReason === "string" ? raw.stopReason : "error";
		if (stopReason !== "stop") {
			const errText = typeof raw?.errorMessage === "string" ? raw.errorMessage : "";
			return { ok: false, stopReason, images: [], textNotes: [], error: `生图未成功（stopReason=${stopReason}${errText ? `：${errText}` : ""}）` };
		}
		const output = Array.isArray(raw?.output) ? raw.output : [];
		const images: GeneratedImagePayload[] = [];
		const textNotes: string[] = [];
		let extraImageCount = 0;
		for (const block of output) {
			const b = block as { type?: unknown; text?: unknown; data?: unknown; mimeType?: unknown };
			if (b?.type === "text" && typeof b.text === "string") {
				textNotes.push(sanitizeTextForChannel(b.text));
				continue;
			}
			if (b?.type !== "image") continue;
			if (images.length >= 1) {
				extraImageCount++; // 一次一图：多余图不落盘，只注记计数。
				continue;
			}
			if (typeof b.data !== "string" || !isPlausibleBase64(b.data)) {
				return { ok: false, stopReason, images: [], textNotes: [], error: "image block base64 非法（解码前拒绝，不产生半解码产物）" };
			}
			if (typeof b.mimeType !== "string" || !b.mimeType.startsWith("image/")) {
				return { ok: false, stopReason, images: [], textNotes: [], error: `image block mimeType 非法：${String(b.mimeType)}` };
			}
			const approxBytes = Math.floor((b.data.length * 3) / 4);
			if (approxBytes > this.maxDecodeBytes) {
				return { ok: false, stopReason, images: [], textNotes: [], error: `单图解码超上限（约 ${approxBytes}B > ${this.maxDecodeBytes}B，设计 §6.4 20 MiB 口径）` };
			}
			let bytes: Buffer;
			try {
				bytes = Buffer.from(b.data, "base64");
			} catch (e) {
				return { ok: false, stopReason, images: [], textNotes: [], error: `base64 解码失败：${e instanceof Error ? e.message : String(e)}` };
			}
			if (bytes.length === 0) {
				return { ok: false, stopReason, images: [], textNotes: [], error: "image block 解码后为空字节（拒绝占位空图）" };
			}
			images.push({ mimeType: b.mimeType, bytes });
		}
		if (images.length === 0) {
			// 设计 §6.4 负例语义：只返 text 无图 → 失败，不得创建「成功占位图」。
			return { ok: false, stopReason, images: [], textNotes: [], error: "text-only-no-image：模型只返回 text block 无 image block——不造占位图" };
		}
		if (extraImageCount > 0) textNotes.push(`[host] 返回 ${extraImageCount + 1} 张图，按一次一图取首图（设计 §6.4）`);
		const u = raw?.usage;
		const costTotal = u?.cost?.total;
		// F13：目录价 cost=0（无目录价模型按 0 上报）不得当已知免费——0/非有限恒 unknown
		//（mock 明确零成本另计——其 costKnown=true 保留）。
		const costKnown = typeof costTotal === "number" && Number.isFinite(costTotal) && costTotal > 0;
		const usage: ImageGenerationUsage = {
			inputTokens: typeof u?.input === "number" ? u.input : undefined,
			outputTokens: typeof u?.output === "number" ? u.output : undefined,
			totalTokens: typeof u?.totalTokens === "number" ? u.totalTokens : undefined,
			costUsd: costKnown ? (costTotal as number) : undefined,
			costKnown,
		};
		return {
			ok: true,
			stopReason,
			images,
			textNotes,
			usage,
			...(refDigests.length > 0 ? { referenceDigests: refDigests } : {}),
		};
	}
}

// ── 5. 调用面守卫：能力门 + 预算授权双门（默认 deny） ─────────────────────────

/** 会话级显式授权（仅显式授权会话可用；由接线层从任务契约/主上批准构造，不经 env）。 */
export interface ImageGenerationGrant {
	/** 获准会话标识（审计对账）。 */
	sessionId: string;
	/** 授权场景（如 "luoshen-reference-image" / "leader-explicit"）。 */
	purpose: string;
	grantedAt: number;
	/** 预算上限（美元；累计已花 ≥ 上限即拒绝）。 */
	budgetUsd?: number;
	/** 允许的模型 refs（精确匹配；缺省/空 = 不限名单）。 */
	allowedModels?: readonly string[];
}

export type ImageGenerationDenyGate = "capability-unavailable" | "grant-missing" | "model-not-allowed" | "budget-exceeded";

export interface ImageGenerationGateVerdict {
	allowed: boolean;
	gate?: ImageGenerationDenyGate;
	reason?: string;
}

/** 生图调用门（纯函数）：无授权会话一律拒绝（默认 deny）；能力探测未命中拒绝；
 *  模型名单外拒绝；预算耗尽拒绝。通过次序：能力 → 授权 → 名单 → 预算。 */
export function imageGenerationGate(input: {
	capability: boolean;
	grant: ImageGenerationGrant | undefined;
	spec: { modelRef: string };
	spentUsd?: number;
}): ImageGenerationGateVerdict {
	if (!input.capability) {
		return { allowed: false, gate: "capability-unavailable", reason: "宿主能力缺失：modelRegistryGenerateImages 探测未命中（host-capabilities 运行时探测）——不注册生图调用面" };
	}
	if (!input.grant) {
		return { allowed: false, gate: "grant-missing", reason: "生图调用面默认 deny：会话未获显式生图授权（预算/输入外发授权缺失）——设计 §6.4「仅任务允许的 luoshen/Leader 场景显式启用」" };
	}
	if (
		Array.isArray(input.grant.allowedModels) &&
		input.grant.allowedModels.length > 0 &&
		!input.grant.allowedModels.includes(input.spec.modelRef)
	) {
		return { allowed: false, gate: "model-not-allowed", reason: `模型 ${input.spec.modelRef} 不在授权名单（${input.grant.allowedModels.join(", ")}）内` };
	}
	if (
		typeof input.grant.budgetUsd === "number" &&
		Number.isFinite(input.grant.budgetUsd) &&
		typeof input.spentUsd === "number" &&
		input.spentUsd >= input.grant.budgetUsd
	) {
		return { allowed: false, gate: "budget-exceeded", reason: `生图预算耗尽：已花 $${input.spentUsd.toFixed(4)} ≥ 上限 $${input.grant.budgetUsd.toFixed(4)}（会话 ${input.grant.sessionId}）` };
	}
	return { allowed: true };
}

// ── 6. 落盘层（复用 artifact 协议；显式路径走同源 deny/写面检查 + 真实落点复核） ──

export interface ImagePersistenceRecord {
	/** 落盘绝对路径。 */
	artifactPath: string;
	metadataPath: string;
	mode: "archive" | "explicit";
	bytes: number;
	sha256: string;
	mimeType: string;
	width?: number;
	height?: number;
	/** 归档目录内序号文件名（explicit 模式为 basename）。 */
	fileName: string;
}

export type ImagePersistenceResult =
	| { ok: true; record: ImagePersistenceRecord }
	| { ok: false; error: string; /** 有限失败码（AC7 收尾：副作用前预算终审拒绝时携带；其它落盘失败无码）。 */ errorCode?: ImageGenerationErrorCode };

function extOfMime(mime: string): string {
	switch (mime) {
		case "image/png":
			return "png";
		case "image/svg+xml":
			return "svg";
		case "image/jpeg":
			return "jpg";
		case "image/gif":
			return "gif";
		case "image/webp":
			return "webp";
		case "image/bmp":
			return "bmp";
		default:
			return "img";
	}
}

function sanitizeStem(name: string | undefined): string {
	const s = String(name ?? "image").replace(/[^A-Za-z0-9._-]/g, "-").replace(/^[-.]+/, "").slice(0, 48);
	return s.length > 0 ? s : "image";
}

/** 归档目录内下一个序号（扫描既有 N- 前缀文件，不猜不跳）。 */
function nextSeqIn(dir: string): number {
	let max = 0;
	try {
		for (const f of fs.readdirSync(dir)) {
			const m = /^(\d+)-/.exec(f);
			if (m) max = Math.max(max, Number.parseInt(m[1], 10));
		}
	} catch (e) {
		if ((e as NodeJS.ErrnoException)?.code !== "ENOENT") throw e; /* lint-exempt:非 ENOENT 上抛=fail-closed */
	}
	return max + 1;
}

/** 真实落点复核：物理路径（realpath 最近存在祖先）不落在 base 物理目录内即拒绝——
 *  拦截经 symlink 逃逸的显式路径/归档目录篡改（设计 §6.4：不能只检查请求字符串）。 */
function physicalInside(base: string, target: string): boolean {
	const physBase = realpathNearestExisting(base);
	const physTarget = realpathNearestExisting(target);
	const rel = path.relative(physBase, physTarget);
	return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
}

/** 写盘 + 回读复核（digest 不一致即失败——防半写/编码意外）。 */
function writeAndVerify(abs: string, bytes: Buffer): { ok: true; sha256: string } | { ok: false; error: string } {
	fs.writeFileSync(abs, bytes, { mode: 0o600 });
	const readBack = fs.readFileSync(abs);
	if (readBack.length !== bytes.length || !readBack.equals(bytes)) {
		return { ok: false, error: `落盘回读不一致：${abs}（期望 ${bytes.length}B，实读 ${readBack.length}B）` };
	}
	return { ok: true, sha256: fileDigestOf(readBack) };
}

export function persistGeneratedImage(opts: {
	payload: GeneratedImagePayload;
	spec: ImageGenerationSpec;
	adapterKind: string;
	cwd: string;
	usage?: ImageGenerationUsage;
	promptDigest: string;
	referenceDigests: readonly string[];
	generatedAt: number;
	/** 宿主解码 passed 观测（严格成功路径才落盘——persist 只接已批准字节与解码事实，不接缩略图）。 */
	decode: ImageDecodePassed;
	/** 完整操作绝对截止点（performance.now 口径；AC7 收尾：全部只读预检通过后、首个落盘副作用前
	 *  的最终预算复核。缺省不复核——直连调用面维持既有行为；编排面恒传入）。 */
	deadlineAtMonotonic?: number;
}): ImagePersistenceResult {
	const { payload, spec, cwd } = opts;
	const ext = extOfMime(payload.mimeType);
	let mode: "archive" | "explicit";
	let abs: string;
	let manifestPath: string | undefined;
	if (spec.outputPath !== undefined && spec.outputPath.trim() !== "") {
		mode = "explicit";
		const target = path.resolve(cwd, spec.outputPath);
		if (path.extname(target) === "") abs = `${target}.${ext}`;
		else abs = target;
	} else {
		mode = "archive";
		if (!artifactEnabled()) {
			return { ok: false, error: "artifact 通道关闭（AMAGI_ARTIFACT_OFF）且未提供显式输出路径——图像无落盘通道，拒绝生成占位" };
		}
		const taskDir = path.join(artifactRoot(), sanitizeId(spec.taskId));
		const dir = path.join(taskDir, "images");
		manifestPath = path.join(taskDir, "images.ndjson");
		// 归档根归属复核：任务目录真实落点不得逃逸 artifact 归档根（symlink 篡改防护）。
		if (!physicalInside(artifactRoot(), taskDir)) {
			return { ok: false, error: `artifact 归档目录真实落点异常（symlink 复核失败）：${taskDir}` };
		}
		const seq = nextSeqIn(dir);
		abs = path.join(dir, `${String(seq).padStart(3, "0")}-${sanitizeStem(spec.outputName)}.${ext}`);
	}
	// F5：附属写点（metadata sidecar / 归档 manifest）与主图同源整单预检——先枚举全部写点，
	// 同源 deny/写面检查（与 write 工具同口径）+ 逐点 symlink/物理落点复核；任一不过即失败且
	// 零副作用（预检先于一切目录创建/写盘）。F5 残留收口（增量复审）：archive 模式同样过
	// enforceFileWriteTargets——deny/契约存储/跨根保护不得因「归档落点在合法根内」被绕过
	//（两种模式全部写点统一整单预检；无活动权限上下文时零干预不变）。
	const physicalBase = mode === "explicit" ? cwd : path.dirname(manifestPath!);
	const writePoints: Array<{ kind: string; label: string; path: string }> = [
		{ kind: "主图", label: mode === "explicit" ? "显式输出" : "归档主图", path: abs },
		{ kind: "metadata sidecar", label: mode === "explicit" ? "显式输出" : "归档", path: `${abs}.image.json` },
		...(manifestPath !== undefined ? [{ kind: "归档 manifest", label: "归档", path: manifestPath }] : []),
	];
	try {
		enforceFileWriteTargets(cwd, writePoints.map((w) => w.path));
	} catch (e) {
		return { ok: false, error: `图像写点被写面拒绝（整单预检，零写入）：${e instanceof Error ? e.message : String(e)}` };
	}
	for (const w of writePoints) {
		const escapeHint =
			mode === "explicit"
				? `${w.label}${w.kind}写点真实落点逃逸工作区（symlink 复核失败，零写入）：${w.path} → ${realpathNearestExisting(w.path)}`
				: `${w.label}${w.kind}写点真实落点逃逸归档目录（symlink 复核失败，零写入）：${w.path} → ${realpathNearestExisting(w.path)}`;
		if (!physicalInside(physicalBase, w.path)) {
			return { ok: false, error: escapeHint };
		}
		try {
			const st = fs.lstatSync(w.path);
			if (st.isSymbolicLink()) {
				return { ok: false, error: `图像${w.kind}写点已是 symlink，拒绝写入（零写入）：${w.path}` };
			}
		} catch (e) {
			if ((e as NodeJS.ErrnoException)?.code !== "ENOENT") {
				return { ok: false, error: `图像${w.kind}写点 lstat 失败：${w.path}（${e instanceof Error ? e.message : String(e)}）` };
			}
		}
	}
	// F6 AC7 收尾（B2 剩余路径）：全部只读准备（参考图 digest 收集、写点整单预检、symlink 复核）
	// 完成后的最终完整预算复核——预算门（decode 后）与这里之间的读取/预检耗时跨过截止即拒绝：
	// 零目录创建/主图/sidecar/manifest 写入、零证据，有限 timeout 失败码（与 B2 落盘门同款口径
	// ——decodeResultAdmission 单调时钟事实复核，不依赖 timer 回调；本调用面无取消信号恒 false）。
	if (opts.deadlineAtMonotonic !== undefined) {
		const finalAdmission = decodeResultAdmission({ now: performance.now(), probeDeadlineAt: opts.deadlineAtMonotonic, operationDeadlineAt: opts.deadlineAtMonotonic, aborted: false });
		if (!finalAdmission.consume) {
			const budgetReason = finalAdmission.reason === "cancelled" ? "cancelled" : "timeout";
			const errorCode = imageDecodeErrorCode({ status: "not-assessed", reason: budgetReason })!;
			return { ok: false, errorCode, error: `落盘副作用前完整预算复核拒绝（零写入）：${imageDecodeFailureText({ status: "not-assessed", reason: budgetReason })}` };
		}
	}
	// 预检全过才创建目录与写盘。
	fs.mkdirSync(path.dirname(abs), { recursive: true, mode: mode === "archive" ? 0o700 : 0o755 });
	const written = writeAndVerify(abs, payload.bytes);
	if (!written.ok) return { ok: false, error: written.error };
	const metadata = {
		formatVersion: 2,
		kind: "image-artifact",
		taskId: spec.taskId,
		agent: spec.agent,
		adapter: opts.adapterKind,
		modelRef: spec.modelRef,
		mimeType: payload.mimeType,
		mimeSource: "adapter-declared",
		mimeConsistency: "signature-matched",
		bytes: payload.bytes.length,
		sha256: written.sha256,
		width: payload.width,
		height: payload.height,
		dimensionBasis: "host-oriented-raster",
		decode: opts.decode,
		policyVersion: IMAGE_DECODE_POLICY_VERSION,
		promptDigest: opts.promptDigest,
		referenceDigests: [...opts.referenceDigests],
		generatedAt: opts.generatedAt,
		outputMode: mode,
		usage: opts.usage,
		formatConformance: "not-assessed", // 完整格式符合性不在机器声明面（F6 终局：只记录限域解码事实）
		visualValidity: "not-assessed", // 视觉有效性不在机器面（需 luoshen/人工——见 IMAGE_VISUAL_VALIDITY_NOTE）
	};
	const metadataPath = `${abs}.image.json`;
	try {
		fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2) + "\n", { mode: 0o600 });
	} catch (e) {
		return { ok: false, error: `metadata 写盘失败（产物已写但证据不完整，按失败上报）：${e instanceof Error ? e.message : String(e)}` };
	}
	if (mode === "archive") {
		// 归档任务级清单行（任务目录内 images.ndjson——不污染根 index.ndjson 的任务前缀扫语义）。
		// F6 终局：清单行增量 formatVersion/decodeStatus/policyVersion（digest 关联 sidecar，不复制大日志）。
		try {
			fs.appendFileSync(
				manifestPath!,
				JSON.stringify({ at: opts.generatedAt, taskId: spec.taskId, agent: spec.agent, adapter: opts.adapterKind, modelRef: spec.modelRef, file: path.basename(abs), bytes: payload.bytes.length, sha256: written.sha256, mimeType: payload.mimeType, promptDigest: opts.promptDigest, formatVersion: 2, decodeStatus: opts.decode.status, policyVersion: IMAGE_DECODE_POLICY_VERSION }) + "\n",
				"utf8",
			);
		} catch (e) {
			return { ok: false, error: `images.ndjson 追加失败：${e instanceof Error ? e.message : String(e)}` };
		}
	}
	return {
		ok: true,
		record: {
			artifactPath: abs,
			metadataPath,
			mode,
			bytes: payload.bytes.length,
			sha256: written.sha256,
			mimeType: payload.mimeType,
			width: payload.width,
			height: payload.height,
			fileName: path.basename(abs),
		},
	};
}

// ── 7. 审计（有界环形缓冲；prompt 只记 digest，base64 零落日志） ───────────────

export interface ImageGenerationAuditEntry {
	at: number;
	/** denied=门拒绝；generated=成功落盘；failed=适配器/解码/落盘失败。 */
	event: "denied" | "generated" | "failed";
	adapter?: "mock" | "host";
	gate?: ImageGenerationDenyGate;
	modelRef: string;
	promptDigest: string;
	artifactPath?: string;
	sha256Prefix?: string;
	bytes?: number;
	durationMs?: number;
	/** F6 终局：有限失败码（解码探测阶段；设计 §4.2 失败码表）。 */
	errorCode?: string;
	/** 失败/拒绝原因（截断 200 字符；经 base64 redact）。 */
	error?: string;
}

const imageAudit: ImageGenerationAuditEntry[] = [];

function pushAudit(e: ImageGenerationAuditEntry): void {
	imageAudit.push(e);
	if (imageAudit.length > IMAGE_AUDIT_CAP) imageAudit.splice(0, imageAudit.length - IMAGE_AUDIT_CAP);
}

/** 审计只读快照（导出供诊断/测试）。 */
export function imageGenerationAuditLog(): readonly ImageGenerationAuditEntry[] {
	return [...imageAudit];
}

/** 仅供测试复位审计缓冲。 */
export function resetImageGenerationAuditForTest(): void {
	imageAudit.length = 0;
}

function auditSafeError(err: string | undefined): string | undefined {
	if (err === undefined) return undefined;
	// F17：审计失败原因同样只剥 base64 载荷、保留真实错误关键词（截断 200 字符）。
	return redactImageBase64InText(err).slice(0, 200);
}

// ── 8. 编排：门 → 适配器 → 落盘 → 证据（一次一图全链路） ───────────────────────

export interface ImageGenerationRunInput {
	spec: ImageGenerationSpec;
	adapter: ImageGenerationAdapter;
	/** resolveHostCapabilities().capabilities.modelRegistryGenerateImages（mock 链路传 true——机制验证不消费宿主）。 */
	capability: boolean;
	grant?: ImageGenerationGrant;
	/** 会话累计已花费（美元；预算门输入）。 */
	spentUsd?: number;
	cwd: string;
	/** 解码器注入面（默认真实宿主 HostImageDecoder；测试仅可注入机制夹具——夹具不产生真解码验收证据）。 */
	decoder?: ImageDecoderLike;
}

export interface ImageGenerationRunResult {
	ok: boolean;
	/** 失败阶段（gate/generate/persist；解码探测属 generate 段）。 */
	stage?: "gate" | "generate" | "persist";
	gate?: ImageGenerationDenyGate;
	/** F6 终局：有限失败码（设计 §4.2；解码探测路径必填）。 */
	errorCode?: ImageGenerationErrorCode;
	error?: string;
	/** 模型 text 通道安全摘要（无 base64——经守卫检测器复核；含实际文件名/digest 关键词）。 */
	text: string;
	artifact?: ImagePersistenceRecord;
	evidence?: ImageEvidenceEntry;
}

/** 全链路编排：gate（默认 deny）→ adapter.generate → 宿主真解码探测（严格成功必须 passed；
 *  mock 与 host 同门——无通行特例）→ persist（落盘+回读+metadata v2）→ 证据条目 v2
 *  （formatConformance/visualValidity 恒 not-assessed）。任一环失败即失败，不产占位产物。 */
export async function runImageGeneration(input: ImageGenerationRunInput): Promise<ImageGenerationRunResult> {
	const startedAt = Date.now();
	// 单调时钟预算：180s 完整操作预算不因解码重置；probe 子预算=min(剩余,10s) 由解码器内部计算。
	const deadlineAtMonotonic = performance.now() + IMAGE_OPERATION_TIMEOUT_MS;
	const promptDigest = promptDigestOf(input.spec.prompt);
	const verdict = imageGenerationGate({ capability: input.capability, grant: input.grant, spec: input.spec, spentUsd: input.spentUsd });
	if (!verdict.allowed) {
		pushAudit({ at: startedAt, event: "denied", adapter: input.adapter.kind, gate: verdict.gate, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, error: auditSafeError(verdict.reason) });
		return { ok: false, stage: "gate", gate: verdict.gate, error: verdict.reason, text: `[image-generation] 拒绝（gate=${verdict.gate}）：${verdict.reason}` };
	}
	const outcome = await input.adapter.generate(input.spec, { cwd: input.cwd });
	if (!outcome.ok || outcome.images.length === 0) {
		const err = outcome.error ?? "适配器未返回图像（未知原因）";
		// F17：失败 text/error 统一净化——保留真实错误关键词/阶段，剥除 base64 图像载荷
		//（provider errorMessage/adapter error 可能回显 data URI 或裸长 base64）。
		const safeErr = redactImageBase64InText(err);
		pushAudit({ at: startedAt, event: "failed", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, error: auditSafeError(safeErr) });
		return { ok: false, stage: "generate", error: safeErr, text: `[image-generation] 生成失败（adapter=${input.adapter.kind}，stopReason=${outcome.stopReason}）：${safeErr}` };
	}
	// F6 终局：落盘前真实宿主解码探测（真委托公共 resizeImage——无 normalize/read/convertToPng
	// 快路径替代，无 mock 通行特例）。严格成功必须 decode.status=passed；失败码有限（设计 §4.2）。
	// 尺寸恒取宿主观测（payload 声明尺寸不优先——AC3 伪尺寸被覆盖）；声明 MIME 先过签名快筛。
	// F6.B1：收到适配器输出即冻结字节快照（专属副本——适配器保留原 Buffer 可变也不影响证据链）；
	// probe/持久化/证据全程只消费快照，digest 校验先于任何持久化（失败零磁盘痕迹）。
	const decoder = input.decoder ?? defaultHostImageDecoder;
	const payload = outcome.images[0];
	const frozenBytes = Buffer.from(payload.bytes);
	const frozenDigest = fileDigestOf(frozenBytes);
	const decode = await decoder.probe(frozenBytes, payload.mimeType, { deadlineAtMonotonic });
	if (decode.status !== "passed") {
		const decodeErr = imageDecodeFailureText(decode);
		const errorCode = imageDecodeErrorCode(decode)!;
		pushAudit({ at: startedAt, event: "failed", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, errorCode, error: auditSafeError(decodeErr) });
		return { ok: false, stage: "generate", errorCode, error: decodeErr, text: `[image-generation] 生成失败（adapter=${input.adapter.kind}，解码探测）：${decodeErr}` };
	}
	// F6.B1：持久化前字节绑定复核——passed 观测的 inputSha256 必须等于被探测冻结快照 digest；
	// 不一致即观测未绑定被解码字节（decode 期间原 Buffer 漂移/注入摘要），此时拒绝且
	// 主图/sidecar/manifest 零写入（evidence 构建校验保留为落盘后的第二道防线，不以写后抛错充当零副作用）。
	if (decode.inputSha256 !== frozenDigest) {
		const bindingErr = `IMAGE_DECODE_UNPROVEN：decode.inputSha256（${decode.inputSha256.slice(0, 12)}…）与解码输入冻结快照 digest（${frozenDigest.slice(0, 12)}…）不一致（字节绑定破坏）——探测观测未绑定被解码字节，持久化前拒绝（零写入）`;
		pushAudit({ at: startedAt, event: "failed", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, errorCode: "IMAGE_DECODE_UNPROVEN", error: auditSafeError(bindingErr) });
		return { ok: false, stage: "generate", errorCode: "IMAGE_DECODE_UNPROVEN", error: bindingErr, text: `[image-generation] 生成失败（adapter=${input.adapter.kind}，解码探测）：${bindingErr}` };
	}
	// F6.B2：落盘前完整操作预算复核（第二道门，与解码器消费门同款口径——不依赖 timer 回调；
	// 晚到 passed 不落盘。本调用面无取消信号，aborted 恒 false：取消语义由解码器消费门承担）。
	const persistAdmission = decodeResultAdmission({ now: performance.now(), probeDeadlineAt: deadlineAtMonotonic, operationDeadlineAt: deadlineAtMonotonic, aborted: false });
	if (!persistAdmission.consume) {
		const budgetReason = persistAdmission.reason === "cancelled" ? "cancelled" : "timeout";
		const errorCode = imageDecodeErrorCode({ status: "not-assessed", reason: budgetReason })!;
		const budgetErr = imageDecodeFailureText({ status: "not-assessed", reason: budgetReason });
		pushAudit({ at: startedAt, event: "failed", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, errorCode, error: auditSafeError(budgetErr) });
		return { ok: false, stage: "generate", errorCode, error: budgetErr, text: `[image-generation] 生成失败（adapter=${input.adapter.kind}，落盘前预算复核）：${budgetErr}` };
	}
	payload.width = decode.width;
	payload.height = decode.height;
	// 参考图 digest（证据可追溯——设计 §6.4「引用输入来源可追溯」）；F7：优先用适配器携带的
	// 提交字节 digest（不可变调用事实——生成后重读不得替代输入快照）；零 IO 适配器（mock）
	// 无携带时回退生成后重读，重读失败不掩盖：证据不完整即整体失败不落盘。
	const referenceDigests: string[] = [];
	if (outcome.referenceDigests !== undefined) {
		referenceDigests.push(...outcome.referenceDigests);
	} else {
		for (const ref of input.spec.referencePaths ?? []) {
			try {
				referenceDigests.push(fileDigestOf(fs.readFileSync(path.resolve(input.cwd, ref))));
			} catch { /* journal:image-ref-reread-fail——参考图重读失败即整体失败（证据不完整不落盘） */
				return { ok: false, stage: "persist", error: `参考图重读失败（生成后漂移，证据不完整即失败）：${ref}`, text: `[image-generation] 参考图重读失败：${ref}` };
			}
		}
	}
	const generatedAt = Date.now();
	const persisted = persistGeneratedImage({
		payload: { ...payload, bytes: frozenBytes }, // F6.B1：落盘只消费冻结快照——adapter 原 Buffer 后续漂移不进入磁盘
		spec: input.spec,
		adapterKind: input.adapter.kind,
		cwd: input.cwd,
		usage: outcome.usage,
		promptDigest,
		referenceDigests,
		generatedAt,
		decode,
		deadlineAtMonotonic,
	});
	if (!persisted.ok) {
		// F17：persist 失败路径同样净化（错误文本可能携带外部输入回显）。
		const safePersistErr = redactImageBase64InText(persisted.error);
		// AC7 收尾：副作用前预算终审拒绝携带有限失败码（其它落盘失败无码，语义不变）。
		pushAudit({ at: startedAt, event: "failed", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, durationMs: Date.now() - startedAt, errorCode: persisted.errorCode, error: auditSafeError(safePersistErr) });
		return { ok: false, stage: "persist", errorCode: persisted.errorCode, error: safePersistErr, text: `[image-generation] 落盘失败（adapter=${input.adapter.kind}）：${safePersistErr}` };
	}
	const evidence = buildImageEvidenceEntry({
		taskId: input.spec.taskId,
		agent: input.spec.agent,
		adapter: input.adapter.kind,
		modelRef: input.spec.modelRef,
		promptDigest,
		referenceDigests,
		path: persisted.record.artifactPath,
		bytes: persisted.record.bytes,
		sha256: persisted.record.sha256,
		mimeType: persisted.record.mimeType,
		generatedAt,
		usage: outcome.usage,
		decode,
	});
	const text =
		`[image-generation] 已生成并落盘：${persisted.record.fileName}（${persisted.record.bytes}B，sha256:${persisted.record.sha256.slice(0, 12)}…，${persisted.record.mimeType}，${persisted.record.mode === "archive" ? "artifact 归档" : "显式路径"}）；` +
		`宿主主栅格解码成功（${decode.width}x${decode.height}，${decode.policyVersion}，host ${decode.hostVersion}）／完整格式符合性未评估／视觉有效性未评估——需 luoshen/人工确认` +
		(outcome.textNotes.length > 0 ? `；模型文本：${outcome.textNotes.join(" | ")}` : "");
	// F17：成功/失败文本统一净化——成功摘要走守卫检测器复核（含实际文件名/digest 关键词）。
	const safeText = redactImageBase64InText(text);
	pushAudit({ at: startedAt, event: "generated", adapter: input.adapter.kind, modelRef: input.spec.modelRef, promptDigest, artifactPath: persisted.record.artifactPath, sha256Prefix: persisted.record.sha256.slice(0, 12), bytes: persisted.record.bytes, durationMs: Date.now() - startedAt });
	return { ok: true, text: safeText, artifact: persisted.record, evidence };
}
