/**
 * task-jsonl.ts — 子进程 JSONL stdout 解析域（P3-B：2026-08-19 插件进化，第一批拆分自 task-tool.ts）。
 *
 * 来源行段（拆分前 task-tool.ts，共 3786 行）：
 *   L67/L69-73/L77-82   解析上限常量（MAX_EVENTS、ACTIVITY_NOISE、getMaxMessageBytes）
 *   L207-372            settle 截断豁免预检 + bash 写盘形态分类/目标提取（bashCommandWritesFile 家族）
 *   L503-536            stripCodeBlocks（Markdown fence 剥离）
 *   L717-784            终稿提取（getFinalOutput）、blocked QUESTIONS/artifact refs 解析、UTF-8 安全截断
 *   L792-827            doom-loop 阈值 + ToolExecutionObservation/PendingToolExecution + tool result 文本
 *   L829-1106           JSONL 解析上下文 ParseContext + processLine（P1-1）
 *   L1111-1152          测试证据复用（findReusableTestEvidence）
 *   L1316-1323          usage 提取（extractUsage）
 * 纯搬家纪律（P3-B）：函数体零改动；唯一签名适配 = findReusableTestEvidence 形参
 * Pick<RunResult, "_toolExecutions"> 改写为结构等价内联类型（P3-C 起 RunResult 已随引擎迁往 task-run.ts，本模块避免依赖巨石头部）。
 * task-tool.ts re-export 全部既有导出名 + 回 import 内部消费名，公共面与调用方零变化。
 * K1（amagi-pi v2，方案 §3.1）：bash 写盘形态分类家族（bashCommandWritesFile/bashWriteTargets/
 * scanBashWrites/writeEditTargets/isWriteToolCall 及私有辅助）下沉至 shell-write-observation.ts
 * （纯搬家，函数体零改动，同 guards.ts→shell-lexer.ts 的 P3-A 先例）；本模块 import + re-export
 * 全部既有导出名，外部调用方与既有测试零变化。
 */
import * as path from "node:path";
import { newRuntimeEventAccumulator, observeRuntimeEvent, type RuntimeEventAccumulator } from "./runtime-fingerprint.ts";
import { registry } from "./task-registry.ts";
import { stripModelThinkingSuffix } from "./model-resolver.ts";
import type { CmdResult, DetectedTest } from "./evidence.ts";
// K1：bash 写盘形态分类家族已下沉 shell-write-observation.ts（纯模块，零 pi 依赖）；
// re-export 维持既有外部 import 路径不变（task-tool.ts 继续转发），isWriteToolCall 供 processLine 消费。
import { bashWriteTargets, isWriteToolCall, writeEditTargets } from "./shell-write-observation.ts";
export { bashCommandWritesFile, bashWriteTargets, writeEditTargets } from "./shell-write-observation.ts";

const MAX_EVENTS = 100_000;

// v1.5.182 活动轨迹噪音白名单：流式/生命周期高频事件不记录（挤掉有意义条目的实战修复）
//
// H2（amagi-pi v2，方案 §6.2.2/§8.4-H2）——两套 message_update 语义区分（不混淆）：
//  - wire（子进程 --print --mode json stdout，本解析域唯一输入）：宿主 dist/modes/json-event.js
//    toJsonEvent 把 message_update 投影为 **delta-only**（仅 type/usage/assistantMessageEvent，
//    剥掉整条 message）；message_end 才是权威帧（完整 message 落盘+入缓冲）。
//  - 内部扩展事件（webui/server.ts FORWARDED_EVENTS 转发面）：message_update 携带**累计
//    message 快照** + assistantMessageEvent delta（docs/webui-protocol.md §0.2 冻结契约：
//    前端按 event.message 整块替换渲染）——仅供显示层，不进本 wire 解析域；即便内部形态
//    行意外到达 wire（非 pi 发射器），同样被本白名单忽略，不污染终稿提取。
//  agent_end 亦非终态信号（宿主 agent-session.js 以 willRetry 重发 agent_end，自动重试/
//  压缩/排队续跑仍可能在途；settled 权威信号是 agent_settled）——settle 判定只认下方
//  message_end 白名单帧（isCleanFinal），不消费 agent_end。
export const ACTIVITY_NOISE = new Set([
	"message_start", "message_update", "turn_start", "turn_end", "agent_start", "agent_end",
	"tool_execution_update", "auto_retry_start", "auto_retry_end", "compaction_start", "compaction_end",
]);

// 累计 message 缓冲上限（防内存无界）：默认 32MB，AMAGI_MAX_MESSAGE_BYTES 可调。
// 8MB 旧默认在真实长任务（多文件读写+大段测试输出）下会截断丢终稿（实战事故：luban/diting 完成工作却被误判 error）。
function getMaxMessageBytes(): number {
	const v = Number(process.env.AMAGI_MAX_MESSAGE_BYTES);
	return Number.isFinite(v) && v > 0 ? v : 32 * 1024 * 1024;
}

/** v1.5.218 settle 收口豁免条件预检：终稿帧可信（未截断）才允许按 done 收口。 */
export function truncatedFallbackPeek(ctx: ParseContext): boolean {
	return ctx.stdoutCapped || ctx.messageTruncated || ctx.lineTruncated;
}

// K1（amagi-pi v2）：bash 写盘形态分类家族已下沉 shell-write-observation.ts（纯搬家，函数体零改动）。
// 本模块经顶部 import 回引 isWriteToolCall 供 processLine 消费；既有导出名经 re-export 保持不变。

/**
 * 按行扫描移除 Markdown 代码块 fence（``` 与 ~~~，可变长度，含未闭合、四反引号嵌套、list-item 同行 fence）。
 * 闭合规则（CommonMark）：同字符 + 长度>=开启 + marker 后仅空白。
 * 行首允许可选 list container（- / * / + / 数字. + 空格）后再识别 fence。
 */
export function stripCodeBlocks(text: string): string {
	const lines = text.split("\n");
	const out: string[] = [];
	let inFence = false;
	let fenceChar = "";
	let fenceLen = 0;
	for (const line of lines) {
		// fence 行：前导（0-3空格 或 list marker -/*/+/数字. + 空格）+ 3+ ` 或 ~ + 尾随
		const m = line.match(/^(?: {0,3}|[-*+] +|\d+\. +)(`{3,}|~{3,})(.*)$/);
		if (m) {
			const marker = m[1];
			const trailing = m[2];
			const ch = marker[0];
			const len = marker.length;
			if (!inFence) {
				inFence = true;
				fenceChar = ch;
				fenceLen = len;
			} else if (ch === fenceChar && len >= fenceLen && /^\s*$/.test(trailing)) {
				inFence = false;
				fenceChar = "";
				fenceLen = 0;
			}
			continue;
		}
		if (!inFence) out.push(line);
	}
	return out.join("\n");
}

/**
 * 取最终 assistant 文本输出。
 * v1.5.197：拼接 provider 自动分段终稿——GLM 达单次响应 maxTokens 时 pi-ai 将该消息
 * stopReason 归一为 "length"，续段为后续连续纯文本 assistant 消息；旧实现只取最后一条，
 * 实战表现为长报告回流以"[结果在第 1 条消息达到输出上限，自动分段继续]"截断、前半段
 * ACHIEVEMENT 丢失。
 * 拼接边界（快审 major-2 修复）：仅跨越 stopReason==="length" 的段才拼接——前段以正常
 * "stop"（或缺失 stopReason，保守视同 stop）结束的两条相邻 assistant 文本是**独立回复**，
 * 不拼接（防旧 ACHIEVEMENT 与新 DONE marker 组合误通过完成校验）。
 */
export function getFinalOutput(messages: Array<{ role: string; content: Array<{ type: string; text?: string }>; stopReason?: string }>): string {
	const segments: string[] = [];
	for (let i = messages.length - 1; i >= 0; i--) {
		const msg = messages[i];
		if (msg.role !== "assistant" || !Array.isArray(msg.content)) break;
		if (msg.content.some((p) => p?.type === "toolCall")) break;
		const texts = msg.content.filter((p) => p?.type === "text" && p.text).map((p) => p.text as string);
		if (texts.length === 0) break;
		segments.unshift(texts.join(""));
		// 本段是否为续段，取决于**前一段**是否被输出上限截断（stopReason==="length"）：
		// 是 → 继续向前拼接；否（stop/缺失/非 assistant）→ 本段即完整独立回复起点，停止。
		const prev = messages[i - 1];
		if (!prev || prev.role !== "assistant" || prev.stopReason !== "length") break;
	}
	return segments.join("\n");
}

export function extractBlockedQuestions(output: string): string[] | undefined {
	const match = output.match(/QUESTIONS:\s*([\s\S]*?)(?:\nPARTIAL:|$)/i);
	if (!match) return undefined;
	const questions = match[1].split(/\r?\n/).map((line) => line.trim()).filter(Boolean).slice(0, 10);
	return questions.length ? questions : undefined;
}

export function extractArtifactRefs(text: string): string[] | undefined {
	// v1.5.248：跳过未解析模板变量残片（如 {PROJECT_META_ROOT}/agent-outputs/...）——正则字符类不含 {}，
	// 会把变量剥掉后提取出「/agent-outputs/...」根路径残片；该路径承远不存在，曾致交付物预检永远判缺、
	// 正常落盘的子 Agent 被 deliverableBlocked 强制收口（diting 审核会话实录）。
	// ev-20261005-309cf4：非 ASCII 路径段支持。根因：ASCII 白名单在首个 CJK 字符处截断
	// （agent-outputs/workflow/pi-1.0.2-十月迭代-m1-m4/... → .../pi-1.0.2- 永不存在的路径）→ B1
	// 交付物预检误判缺件假 NEEDS_HANDOFF。diting F-08 修正（段规则）：完整档匹配后按路径段修剪——
	// 段内非 ASCII 字符仅当处于**段首**、紧邻 -/_ 连接符、或延续前一个非 ASCII（连续中文）时合法；
	// ASCII 字符后直接粘连的中文（「R.md已完成」「….md已完成请查收」）在该处截断（叙述尾巴）。
	// agent-outputs 字面前的前缀含非 ASCII 时整体丢弃前缀（「报告agent-outputs/…」的「报告」是叙述）。
	// 模板变量跳过（v1.5.248）与 <节点名> 前缀停止（ev-20260907）行为保持。
	const ASCII_SEG = "[A-Za-z0-9_@.+:~/\\-]";
	const NONASCII_SEG = "[^\\u0000-\\u007f\\s，。；：！？、（）()「」『』【】《》“”‘’…·]";
	const FULL_SEG = `${ASCII_SEG}|${NONASCII_SEG}`;
	const reWin = new RegExp(`^(?:\\.{0,2}\\/|\\/)?(?:${FULL_SEG})*agent-outputs\\/(?:${FULL_SEG})+`);
	const reAsciiSeg = new RegExp(`^${ASCII_SEG}$`);
	const reNonAsciiSeg = new RegExp(`^${NONASCII_SEG}$`);
	const isSegChar = (ch: string): boolean => reAsciiSeg.test(ch) || reNonAsciiSeg.test(ch);
	// ev-20261007-ci-unblock（ReDoS 根因修复，解锁 ev-20260914-ce6bd2 ④ 两用例 CI 阻塞）：
	// 旧实现 reFull 对全文跑 `(?:SEG)*agent-outputs\/(?:SEG)+`（g）的逐起点贪婪+回溯——
	// 无 marker 长文本（resume 反馈：135K 字符 / 320K 字符连续 CJK run）每起点 O(run)
	// 回溯、总 O(n²)（320K 字符连续 run ≈5×10¹⁰ 步实测 25s+ 不完成；135K 字符变体在 node --test
	// 子进程的正则解释执行态下同样分钟级挂死）。修复依据：匹配的每个组成字符（前缀 SEG*、
	// agent-outputs/ 字面、tail SEG+）都在同一字符类内，任一匹配整体落在「包含 anchor 的
	// 连续 SEG 段（SEG-run）」内——先 indexOf 定位每个 anchor（原生线性、无回溯），再仅在
	// SEG-run 窗口上做 ^ 锚定单次匹配（起点唯一=run 左端，单起点一次贪婪回溯 O(window)；
	// 无 anchor 段落零正则成本；「有效 marker 后跟长无 marker 尾段」场景窗口内仍只需单起点
	// 一次匹配，不再逐起点回溯）。提取语义（模板变量跳过 / <节点名> 前缀停止 / 非 ASCII
	// 前缀丢弃 / 段内叙述尾巴截断）逐字保持——由 evolution-cjk-deliverable-path /
	// artifact-template-path / b1-deliverable-precheck 既有回归锁定。
	const ANCHOR = "agent-outputs/";
	const FILE_EXT_RE = /\.[A-Za-z0-9]{1,10}$/;
	const isNonAscii = (ch: string): boolean => ch !== "" && ch.charCodeAt(0) > 0x7f;
	/** 段内叙述尾巴截断：首个「非法非 ASCII 位」（前驱为 ASCII 且非 -/_）处截；返回截后段。 */
	const trimSeg = (seg: string): string => {
		for (let j = 0; j < seg.length; j++) {
			if (!isNonAscii(seg[j])) continue;
			if (j === 0) continue; // 段首非 ASCII：目录/文件名合法形态
			const prev = seg[j - 1];
			if (isNonAscii(prev) || prev === "-" || prev === "_") continue; // 连续中文或连字符/下划线连接
			return seg.slice(0, j); // ASCII 后直粘中文 → 叙述尾巴，截断
		}
		return seg;
	};
	const matches: string[] = [];
	let from = 0;
	while (true) {
		const k = text.indexOf(ANCHOR, from);
		if (k < 0) break;
		// SEG-run 边界：anchor 两侧延伸到首个非 SEG 字符（正则的组成字符全为 SEG，
		// 匹配整体必落在段内；上一段尾与本段首之间的非 SEG 字符保证 runStart 不回退）
		let runStart = k, runEnd = k + ANCHOR.length;
		while (runStart > 0 && isSegChar(text[runStart - 1])) runStart--;
		while (runEnd < text.length && isSegChar(text[runEnd])) runEnd++;
		// ^ 锚定窗口单次匹配：起点唯一=窗口左端（SEG* 贪婪最长前缀，可选 ./ ../ / 前缀组
		// 的字符亦属 SEG 被其覆盖；匹配成功时 m[0] 贪婪吞尽整段，与旧全文 g 循环的最左
		// 匹配等价）
		const m = reWin.exec(text.slice(runStart, runEnd));
		if (m) {
			const idx = runStart;
			const prevChar = idx > 0 ? text[idx - 1] : "";
			const prevIsTemplateVar = prevChar === "}"; // {IDENT} 变量尾部紧贴匹配起点 → 本提及是未解析模板
			// ev-20260907-8abf9a：字符类在 c<节点名>/c{nodeName}/c${nodeName} 前停止，
			// 不能将已匹配前缀 c（甚至目录）登记为交付物并驱动补写。只跳过当前模板引用，保留同段真实路径。
			const suffix = text.slice(idx + m[0].length);
			const endsAtTemplate = /^(?:<[^<>\r\n]+>|\$?\{[^{}\r\n]+\})/.test(suffix);
			if (!prevIsTemplateVar && !endsAtTemplate) {
				// diting F-08：前缀含非 ASCII → 前缀是叙述（路径前缀无中文形态），从 agent-outputs 字面起重写
				const kk = m[0].indexOf("agent-outputs");
				let head = m[0].slice(0, kk);
				if (head.split("").some(isNonAscii)) head = "";
				// ev-20261021-2419d8：叙述尾巴截断只可能发生在路径末段（中段之后路径仍以 / 延续，不是叙述），
				// 且引号/反引号定界的 token 边界由定界符给出（[任务输入] 节以 JSON 字符串渲染冻结 inputs）——
				// 定界内不截断；末段截断后若剩余前缀不成文件名（无扩展名）而整段以扩展名收尾，截断点落在文件名
				// 内部（「53-LeaderR7c预算补正.md」→「53-LeaderR7c」是不存在的伪路径），保留整段。
				const open = runStart > 0 ? text[runStart - 1] : "";
				const delimited = (open === "\"" || open === "'" || open === "`") && text[runEnd] === open;
				const tailSegs = m[0].slice(kk).split("/");
				const last = tailSegs.length - 1;
				if (!delimited && last >= 0) {
					const seg = tailSegs[last]!;
					const cut = trimSeg(seg);
					const cutInsideFileName = cut !== seg && !FILE_EXT_RE.test(cut) && FILE_EXT_RE.test(seg);
					if (!cutInsideFileName) tailSegs[last] = cut;
				}
				matches.push(`${head}${tailSegs.join("/")}`);
			}
		}
		// 旧 g 循环非重叠语义：首个匹配贪婪吞尽整 SEG-run（前缀 SEG* 与 tail SEG+ 均取到段
		// 边界），段内其余 anchor 属同一 match，从段尾继续找下一个 anchor。
		from = runEnd;
	}
	const unique = [...new Set(matches.map((item) => item.replace(/[),.;:），。；：]+$/, "")))].slice(0, 10);
	return unique.length ? unique : undefined;
}

/** E3 路径规范化：相对 cwd 解析为规范绝对路径（绝对路径原样 normalize）；解析失败返回 null。 */
export function resolveArtifactAbs(cwd: string, ref: string): string | null {
	try {
		return path.isAbsolute(ref) ? path.resolve(ref) : path.resolve(cwd, ref);
	} catch { return null; }
}

/** UTF-8 安全截断（不切断多字节字符） */
export function capUtf8(str: string, maxBytes: number): string {
	const buf = Buffer.from(str, "utf8");
	if (buf.length <= maxBytes) return str;
	let cut = maxBytes;
	while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--; // 回退到字符边界
	return `${buf.slice(0, cut).toString("utf8")}\n\n[输出截断：省略 ${buf.length - cut} 字节]`;
}

/** v1.5.186 P3（grok truncate_front_and_back 移植）：头尾双保留截断——报告类长输出的终稿/错误常在尾部，单端截断必丢。头 60% + 尾 40%。 */
export function capUtf8HeadTail(str: string, maxBytes: number): string {
	const buf = Buffer.from(str, "utf8");
	if (buf.length <= maxBytes) return str;
	const headBudget = Math.floor(maxBytes * 0.6);
	const tailBudget = maxBytes - headBudget;
	let headCut = headBudget;
	while (headCut > 0 && (buf[headCut] & 0xc0) === 0x80) headCut--;
	let tailStart = buf.length - tailBudget;
	while (tailStart < buf.length && (buf[tailStart] & 0xc0) === 0x80) tailStart++;
	return `${buf.slice(0, headCut).toString("utf8")}\n\n[输出截断：中间省略 ${tailStart - headCut} 字节（头尾双保留）]\n\n${buf.slice(tailStart).toString("utf8")}`;
}

/** v1.5.186 P2 doom-loop 阈值（默认 4 次连续同签名 toolCall；0=关闭）。 */
export function getDoomLoopThreshold(): number {
	const v = Number(process.env.AMAGI_DOOM_LOOP_THRESHOLD);
	return Number.isFinite(v) ? v : 4;
}

export interface ToolExecutionObservation {
	toolName: string;
	args: Record<string, unknown>;
	resultText: string;
	isError: boolean;
	durationMs: number;
	order: number;
}

export interface PendingToolExecution {
	toolName: string;
	args: Record<string, unknown>;
	startedAt: number;
	order: number;
}

// ── B0-1（Leader 成本效率编排 §3.4 / 附录 B.1）：累计用量计量（纯解析域类型与读取器） ──

/** usage 数值快照（有限值过滤后；字段 undefined = 该项未上报/未观察，不冒充 0）。 */
export interface UsageFigures {
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	/** 宿主 cost.total（不猜单价）；无 cost 字段的通道如实缺失。 */
	cost?: number;
}

/** 末次调用诊断快照（错误尾帧可为 0——保留诊断不覆盖累计；上下文规模取三个输入分项）。 */
export type CallUsage = UsageFigures & { stopReason?: string };

/** 可变累计桶（undefined 键 = 全程未上报，保持未知）。 */
export type UsageTotals = { [K in keyof UsageFigures]: number | undefined };

export function newUsageTotals(): UsageTotals {
	return { input: undefined, output: undefined, cacheRead: undefined, cacheWrite: undefined, cost: undefined };
}

function finiteUsageValue(v: unknown): number | undefined {
	return typeof v === "number" && Number.isFinite(v) ? v : undefined;
}

/** 读宿主 usage 对象（pi-ai Usage 形状：input/output/cacheRead/cacheWrite/cost.total；兼容 cost 标量）。
 *  无任何有限值 → undefined（usage 缺席与全零区分：全零是已上报的 0）。 */
export function readUsageFigures(raw: unknown): UsageFigures | undefined {
	if (!raw || typeof raw !== "object") return undefined;
	const u = raw as { input?: unknown; output?: unknown; cacheRead?: unknown; cacheWrite?: unknown; cost?: unknown };
	const input = finiteUsageValue(u.input);
	const output = finiteUsageValue(u.output);
	const cacheRead = finiteUsageValue(u.cacheRead);
	const cacheWrite = finiteUsageValue(u.cacheWrite);
	const cost = typeof u.cost === "number" ? finiteUsageValue(u.cost) : finiteUsageValue((u.cost as { total?: unknown } | null | undefined)?.total);
	const fig: UsageFigures = {
		...(input !== undefined ? { input } : {}),
		...(output !== undefined ? { output } : {}),
		...(cacheRead !== undefined ? { cacheRead } : {}),
		...(cacheWrite !== undefined ? { cacheWrite } : {}),
		...(cost !== undefined ? { cost } : {}),
	};
	return Object.keys(fig).length > 0 ? fig : undefined;
}

/** 把一份 usage 累加进桶（缺项保持 undefined——不把未上报补成 0）。 */
export function addUsageFigures(totals: UsageTotals, fig: UsageFigures): void {
	for (const key of ["input", "output", "cacheRead", "cacheWrite", "cost"] as const) {
		const v = fig[key];
		if (v !== undefined) totals[key] = (totals[key] ?? 0) + v;
	}
}

/** 桶 → 快照（未观察的字段保持 undefined，不写 0）。 */
export function usageFiguresOf(totals: UsageTotals): UsageFigures {
	return { input: totals.input, output: totals.output, cacheRead: totals.cacheRead, cacheWrite: totals.cacheWrite, cost: totals.cost };
}

/** 一次运行的完整累计口径（附录 B.1 字段表；extractUsageDetail 产出）。 */
export interface CumulativeUsage {
	/** assistant message_end 各项 usage 的和；全 undefined = 未见任何带 usage 的完结帧（未知）。 */
	totals: UsageFigures;
	/** 已观察到的 assistant 完结事件数（可观测模型轮次，非供应商账单请求数）。 */
	assistantCalls: number;
	/** 完结帧缺 usage 的 assistant 事件数（与 assistantCalls 分列，不机械相加）。 */
	usageMissingCalls: number;
	/** 第一条带 usage 的 assistant 调用的 input+cacheRead+cacheWrite；首条缺 usage → undefined（未知，不以第二条冒充）。 */
	firstCallContext?: number;
	/** 最后一条 assistant 的 usage 与 stopReason（错误尾帧可为 0，仅诊断）。 */
	lastCall?: CallUsage;
	/** toolResult.message_end 可选 usage 的和（与 assistant 分开单列）。 */
	nestedUsage?: UsageFigures;
	/** 观察到嵌套 usage 的 toolResult 完结帧数。 */
	nestedCalls: number;
	/** compaction_end.result.usage 的可见和（压缩模型单列）。 */
	compactionUsage?: UsageFigures;
	/** 观察到 usage 的 compaction_end 事件数。 */
	compactionEvents: number;
}

function isTextToolResultPart(part: unknown): part is { type: "text"; text: string } {
	return !!part
		&& typeof part === "object"
		&& "type" in part
		&& part.type === "text"
		&& "text" in part
		&& typeof part.text === "string";
}

export function toolResultText(result: unknown): string {
	if (!result || typeof result !== "object" || !("content" in result) || !Array.isArray(result.content)) return "";
	const text = result.content.filter(isTextToolResultPart).map((part) => part.text).join("\n");
	return capUtf8HeadTail(text, 8 * 1024);
}

// ── JSONL 解析上下文 + processLine（P1-1） ───────────────────────────────────
export interface ParseContext {
	runtimeEvents: RuntimeEventAccumulator;
	pendingAdvisors?: Map<string, number>;
	messages: Array<{ role: string; content: Array<{ type: string; text?: string }> }>;
	/** 与 messages 平行的逐帧字节数（尾部淘汰时精确扣减）。 */
	messageSizes: number[];
	/** 缓冲淘汰计数（>0 = 发生过淘汰；终稿帧始终保留，不因此误判 error）。 */
	evictedMessages: number;
	/** 增量工具统计（按帧入队时累计；淘汰帧不丢计数——终态不再扫描幸存帧）。 */
	toolCalls: number;
	toolNames: Set<string>;
	sessionId?: string;
	model?: string;
	stopReason?: string;
	errorMessage?: string;
	parseErrors: string[];
	messageBytes: number;
	eventCount: number;
	stdoutCapped: boolean;
	/** 单条消息即超缓冲上限——终帧无法完整保留，维持"最终帧不可信" error 判定。 */
	messageTruncated: boolean;
	lineTruncated: boolean; // P1-2: 单行超限被截断→最终帧可能损坏
	spawnError?: string; // P1-3: spawn Error 根因（ENOENT 等）
	stderr: string;
	/** v1.5.184 耗时拆分：模型生成时间（message_start→message_end 累计，含 thinking/文本/工具参数流式）。 */
	thinkMs: number;
	/** v1.5.184 耗时拆分：工具执行时间（tool_execution_start→end 累计）。 */
	toolMs: number;
	msgStartTs?: number;
	toolStartTs?: number;
	/** v1.5.185 provider 重试风暴感知：auto_retry_start 次数与退避等待累计（沉默烧时间的元凶之一）。 */
	retryAttempts: number;
	retryWaitMs: number;
	/** v1.5.186 P2 doom-loop（grok doom_loop 移植）：连续同签名 toolCall 重复检测。 */
	lastToolSig?: string;
	toolSigRepeats: number;
	/** 命中阈值后的签名摘要（data handler 据此杀进程）。 */
	doomLoop?: string;
	/** Bounded tool execution receipts used to reuse a final child-run baseline. */
	toolExecutions: ToolExecutionObservation[];
	pendingToolExecutions: Map<string, PendingToolExecution>;
	toolSequence: number;
	/** v1.5.187 P7：首个 stdout 事件时间戳（startupMs = firstEventTs - startedAt，冷启动延迟感知）。 */
	firstEventTs?: number;
	/** v1.5.218 settle 收口兜底：最后一条 assistant message_end 时间戳（print 模式 turn 完成信号）。 */
	lastAssistantEndTs?: number;
	/** A1（ev-20260815-35219a）写盘证据：本轮**成功**写盘类工具调用计数（write/edit + bash 高置信写形态）。
	 *  A1-R（diting Major-3）：计数改为基于成功的 tool_result——被守卫阻断/执行失败的调用不算
	 *  （pendingWriteCalls 意图登记 → settleWriteCredit 核销）；settle 收口终稿判定与产出窗口判定消费。 */
	writeToolCalls: number;
	/** A1-R：待核销写盘意图（按 toolCall 到达顺序登记；id 可缺——消息级无 id 流按 FIFO 对账）。
	 *  Wave C2：随意图携带写盘目标路径（成功核销时转入 creditedWritePaths）。 */
	pendingWriteCalls: Array<{ id?: string; writeClass: true; paths?: string[] }>;
	/** Wave C2：成功核销的写盘目标缓冲（data handler 每 chunk / finalize 尾帧后 drain 到 registry）。 */
	creditedWritePaths: string[];
	/** v1.5.219 spawn 解析的全形态模型（provider/model:thinking）——运行流裸 modelId 与之合并保留档位。 */
	spawnModel?: string;
	// ── B0-1（附录 B.1）：累计用量累加器（独立于消息环形缓冲——逐出不丢；先于单条超限早退入账） ──
	/** assistant message_end 各项 usage 的累计和（缺项保持 undefined=未上报）。 */
	usageTotals: UsageTotals;
	/** 任一带 usage 的 assistant 完结帧出现过（false=全程未知，序列化不补 0）。 */
	usageObserved: boolean;
	/** 已观察到的 assistant 完结事件数（含零 usage 帧；不含 message_update/turn_end/agent_end 重复帧）。 */
	assistantCalls: number;
	/** 完结帧缺 usage 的 assistant 事件数。 */
	usageMissingCalls: number;
	/** 第一条带 usage 的 assistant 调用的 input+cacheRead+cacheWrite。 */
	firstCallContext?: number;
	/** 末次 assistant 调用诊断快照（错误尾帧可为 0；不覆盖累计）。 */
	lastCallUsage?: CallUsage;
	/** toolResult.message_end 可选 usage 的累计（工具内嵌模型调用，单列）。 */
	nestedUsage?: UsageTotals;
	/** 观察到嵌套 usage 的 toolResult 完结帧数。 */
	nestedCalls: number;
	/** compaction_end.result.usage 的累计（压缩模型单列）。 */
	compactionUsage?: UsageTotals;
	/** 观察到 usage 的 compaction_end 事件数。 */
	compactionEvents: number;
	/** usage 入账消息 id 去重集（同 id 重放的 message_end 不重复入账；有界防膨胀）。 */
	usageSeenIds: Set<string>;
}

export function newParseContext(): ParseContext {
	return {
		runtimeEvents: newRuntimeEventAccumulator(),
		messages: [],
		messageSizes: [],
		evictedMessages: 0,
		toolCalls: 0,
		toolNames: new Set(),
		parseErrors: [],
		messageBytes: 0,
		eventCount: 0,
		stdoutCapped: false,
		messageTruncated: false,
		lineTruncated: false,
		stderr: "",
		thinkMs: 0,
		toolMs: 0,
		retryAttempts: 0,
		retryWaitMs: 0,
		toolExecutions: [],
		pendingToolExecutions: new Map(),
		toolSequence: 0,
		toolSigRepeats: 0,
		writeToolCalls: 0,
		pendingWriteCalls: [],
		creditedWritePaths: [],
		usageTotals: newUsageTotals(),
		usageObserved: false,
		assistantCalls: 0,
		usageMissingCalls: 0,
		nestedCalls: 0,
		compactionEvents: 0,
		usageSeenIds: new Set(),
	};
}

/** A1-R（diting Major-3）写盘证据核销：成功的 tool_result 才计入写盘次数。
 *  id 匹配优先（toolResult 消息帧 / tool_execution_end 双信号幂等核销——先到先销，不双计）；
 *  无 id 的结果帧（合成流/旧格式）按 FIFO 对账最早一笔。被阻断/失败（isError）的调用直接
 *  丢弃意图：不算写盘，也不留待后续误核销。
 *  Wave C2：成功核销同时把该调用的写盘目标路径转入 creditedWritePaths（待 drain 入 registry）。 */
export function settleWriteCredit(ctx: ParseContext, id: string | undefined, isError: boolean): void {
	let idx = -1;
	if (id !== undefined) idx = ctx.pendingWriteCalls.findIndex((e) => e.id === id);
	else if (ctx.pendingWriteCalls.length > 0) idx = 0;
	if (idx === -1) return;
	const entry = ctx.pendingWriteCalls[idx];
	ctx.pendingWriteCalls.splice(idx, 1);
	if (!isError) {
		ctx.writeToolCalls++;
		for (const p of entry.paths || []) if (!ctx.creditedWritePaths.includes(p)) ctx.creditedWritePaths.push(p);
	}
}

/** Wave C2：写盘目标规范化（绝对 → normalize；相对 → 以任务 cwd 解析）。 */
function resolveWriteTarget(p: string, cwd: string | undefined): string {
	try {
		return path.isAbsolute(p) ? path.normalize(p) : path.resolve(cwd || process.cwd(), p);
	} catch { return p; }
}

/** Wave C2：把成功核销的写盘目标刷入 registry（滚动 ≤8 去重队列）。
 *  data handler 每 chunk 与 finalize 尾帧各 drain 一次；空缓冲零开销。
 *  K4 注记：writePath 无内核命令等价物（ExecutionEvent 封闭为 started/session/activity/exited）——
 *  本写点为迁移期残留桥写入点（registry.appendWritePath → 桥 observeLegacy 内存投影，不推进 stateSeq/CAS），
 *  K5a/K8 决定观察模式的记录投影策略后收口；现仅 legacy/观察两模式共用（记录投影，非状态写）。 */
export function drainWritePaths(ctx: ParseContext, taskId: string, cwd: string | undefined): void {
	if (ctx.creditedWritePaths.length === 0) return;
	const pending = ctx.creditedWritePaths;
	ctx.creditedWritePaths = [];
	for (const p of pending) {
		try { registry.appendWritePath(taskId, resolveWriteTarget(p, cwd)); } catch { /* 观测补录不阻断主流程 */ }
	}
}

/** A1-R（diting Major-1）只读终稿文本判定：区分「中途宣告」与「完整陈述性终稿」。
 *  无交付物任务（无 artifactRefs/交付物标记）且零写盘、无 DONE marker 时，settle 兑底收口
 *  是否按 done 结算由本判定把关（旧实现以写盘次数为必要条件，把纯只读调查的合法终稿误判
 *  killed-by-settle error——diting Major-1 回归）。A1-R2（diting 增审 Major-1）词法边界收敛：
 *  ① 代码上下文剔除（fence 块整段移除 + 行内 code 剥离）——代码词 continue/未完成不参与否决；
 *  ② 否决仅限明确第一人称/主语省略的未来动作句（我接下来/我继续/现在开始/稍后/I will…）——
 *    建议性表述（「下一步建议：无需修改」）不否决；
 *  ③ 未完成类句式句子级作用域：仅当紧邻主语为本任务/工作/第一人称时否决——范围外既有
 *    问题的存在性陈述（「tests/foo 尚未完成迁移」）不否决；
 *  ④ 收尾性正证据（调查完成/结论/总结/无需改动…）：准备完成状态帧（「全部上下文已读取…
 *    方案细节已形成」）无收尾证据不放行——宁可保守 error+resume，不可 done 误放（done 误放
 *    是漏交付，error 方向可 resume 恢复）。 */
const REPORT_EVIDENCE_RE = /(?:调查|分析|审查|核查|调研|排查|复核|梳理|阅读|检查|验证)(?:完成|完毕)|结论|总结|汇报|如下|无需(?:改动|修改|变更|调整|处理|进一步)|没有(?:问题|异常|改动|发现)|未发现(?:问题|异常|风险)|(?:^|[^a-z])(?:conclusion|summary|findings?)(?=[^a-z]|$)/i;
const FUTURE_ACTION_RE = /我接下来|接下来我|我将要|我将开始|我会继续|我继续|我现在开始|我准备|让我继续|现在开始|准备开始|开始写|着手写|稍后|待续|待补|(?:^|[^a-z])(?:i\s+will|i'll|we\s+will|we'll|i\s+am\s+going|i'm\s+going|next,\s*i|will\s+now\s+(?:continue|start|begin|write|implement|analyze)|continuing)(?=[^a-z]|$)/i;
const INCOMPLETE_RE = /(尚未|还没|未|还没有)(完成|做完|收尾|补完)/g;
/** 未完成短语紧邻主语为本任务/工作/第一人称 → 指代本任务未完成；路径/对象名等存在性陈述不否决。 */
const INCOMPLETE_SELF_SUBJECT_RE = /(?:我|我们|本任务|本次任务|本轮任务|该任务|此任务|这项工作|这个工作|任务|工作|调查|分析|修复|改造|实施|收尾|剩余部分|剩余工作)$/;
function incompleteRefersToThisTask(sentence: string): boolean {
	for (const m of sentence.matchAll(INCOMPLETE_RE)) {
		const before = sentence.slice(Math.max(0, m.index - 14), m.index);
		if (INCOMPLETE_SELF_SUBJECT_RE.test(before)) return true;
	}
	return false;
}
export function looksLikeFinalReport(text: string): boolean {
	// ① 代码上下文剔除：fence 块整段移除 + 行内 code 剥离——代码词不参与任何判定
	const stripped = stripCodeBlocks(text.replace(/\r\n/g, "\n").replace(/\r/g, "\n")).replace(/`[^`\n]*`/g, " ");
	const trimmed = stripped.trim();
	if (!trimmed) return false;
	// ② 明确未来动作句否决（建议性「下一步建议」不否决）
	if (FUTURE_ACTION_RE.test(trimmed)) return false;
	// ③ 未完成句式：句子级主语作用域——范围外既有问题不否决
	for (const sentence of trimmed.split(/[。！？!？；;\n]+/)) {
		if (incompleteRefersToThisTask(sentence)) return false;
	}
	// ④ 实质内容 + 收尾性正证据（准备状态帧无收尾证据不放行）
	const nonEmptyLines = trimmed.split("\n").filter((l) => l.trim() !== "");
	const substantive = nonEmptyLines.length >= 2 || trimmed.replace(/\s/g, "").length >= 24;
	return substantive && REPORT_EVIDENCE_RE.test(trimmed);
}

export function processLine(line: string, ctx: ParseContext): void {
	if (!line.trim()) return;
	let ev: any;
	try {
		ev = JSON.parse(line);
	} catch {
		ctx.parseErrors.push(line.slice(0, 200));
		return;
	}
	// Direct replay and live parsing share the same bounded runtime/retry projection.
	observeRuntimeEvent(ctx.runtimeEvents, ev);
	// 结算前边界追加的咨询通知以 entry_appended 完结；归一后按 callId 与 message_end 共同去重。
	if (ev.type === "entry_appended" && ev.entry?.type === "custom_message" && ev.entry.customType === "amagi:advisor-result") ev = { type: "message_end", message: { ...ev.entry, role: "custom" } };
	if (ev.type === "turn_start" || ev.type === "agent_start") ctx.lastAssistantEndTs = undefined;
	// B0-1（附录 B.1）：compaction_end 是压缩模型用量的权威完结帧（在 ACTIVITY_NOISE 白名单内——
	// 计量先行于噪音过滤：只读 usage，不入事件计数/消息缓冲，读后等同噪音行早退）。
	// 注：wire 链路上 compaction_end 是 NOISE_LINE_RE 噪音行，processLine 收不到——生产累计在
	// task-run.ts consumeLine 的全行遍历块（同 thinkMs 口径）；本分支服务直接 processLine 调用方
	//（测试/重放），两入口互斥不双计。无 result.usage 的宿主如实缺席（未覆盖，不冒充 0）。
	if (ev?.type === "compaction_end") {
		const fig = readUsageFigures((ev as { result?: { usage?: unknown } }).result?.usage);
		if (fig) {
			if (!ctx.compactionUsage) ctx.compactionUsage = newUsageTotals();
			addUsageFigures(ctx.compactionUsage, fig);
			ctx.compactionEvents++;
		}
		return;
	}
	// v1.5.183: 流式快照噪音（message_update 等）不进事件计数/缓冲——终稿判定只消费
	// session/message_end；快照行体积随消息长度平方增长，计入上限必误伤（实战见 data handler）。
	// H2 复核：wire message_update 为 delta-only（无 message 字段）、内部形态（带累计快照
	// message）意外到达 wire 时同被忽略——终稿唯一权威是 message_end，见文件头语义注记。
	if (ACTIVITY_NOISE.has(String(ev?.type ?? ""))) return;
	if (ctx.eventCount++ > MAX_EVENTS) {
		ctx.stdoutCapped = true;
		return;
	}
	if (ev.type === "session" && ev.id) {
		ctx.sessionId = ev.id;
	}
	if (ev.type === "message_end" && ev.message) {
		// A1-R（diting Major-3）：写盘证据只在成功 tool_result 核销（守卫阻断/执行失败不计入）。
		if ((ev.message as { role?: string }).role === "toolResult") {
			const tr = ev.message as { toolCallId?: unknown; isError?: unknown };
			settleWriteCredit(ctx, typeof tr.toolCallId === "string" ? tr.toolCallId : undefined, tr.isError === true);
		}
		// B0-1（附录 B.1）：usage 只在权威完结事件（message_end）入账一次——message_update/turn_end/
		// agent_end 不重复计；同 id 重放的 message_end 帧去重（宿主 getSessionStats 同口径）。
		// 位置在单条超限早退（sz > cap）之前：超大消息也计入；累加器独立于 ctx.messages——
		// 环形缓冲逐出不丢用量。工具内嵌模型调用（toolResult.usage）单列 nestedUsage，
		// 不混入 assistant 累计；错误尾帧只加自身上报用量，不覆盖已有累计。
		{
			const m = ev.message as { role?: string; usage?: unknown; stopReason?: unknown; id?: unknown; toolName?: string; customType?: string; details?: { handle?: string; status?: string; startedAt?: number; advisor?: { handle?: string; callId?: string; usage?: unknown; accountUsage?: boolean } } };
			const advisor = ((m.role === "custom" && m.customType === "amagi:advisor-result") || (m.role === "toolResult" && m.toolName === "amagi_advisor" && m.details?.advisor?.accountUsage !== false)) ? m.details?.advisor : undefined;
			if (advisor?.handle) { ctx.pendingAdvisors?.delete(advisor.handle); ctx.lastAssistantEndTs = undefined; }
			if (m.role === "toolResult" && m.toolName === "amagi_advisor" && typeof m.details?.handle === "string") {
				if (m.details.status === "cancelled") ctx.pendingAdvisors?.delete(m.details.handle);
				if (m.details.status === "running" && typeof m.details.startedAt === "number" && Number.isFinite(m.details.startedAt)) {
					ctx.pendingAdvisors ??= new Map();
					if (ctx.pendingAdvisors.size < 50) ctx.pendingAdvisors.set(m.details.handle, m.details.startedAt);
				}
			}
			const dupId = advisor?.callId ? `advisor:${advisor.callId}` : typeof m.id === "string" && m.id !== "" ? m.id : undefined;
			const seenBefore = dupId !== undefined && ctx.usageSeenIds.has(dupId);
			if (dupId !== undefined && !seenBefore && ctx.usageSeenIds.size < MAX_EVENTS) ctx.usageSeenIds.add(dupId);
			if (!seenBefore) {
				if (m.role === "assistant") {
					// F1（diting，附录 B.1）：仅首条 assistant 完结事件可赋 firstCallContext——首条缺
					// usage/无输入分项时保持未知，绝不拿第二条冒充起点（旧 `=== undefined` 判空会在
					// 首条未知时波及后续帧）。调用计数先行（isFirst 以本帧为基准判定）。
					const isFirstAssistantCall = ctx.assistantCalls === 0;
					ctx.assistantCalls++;
				const fig = readUsageFigures(m.usage);
				const stopReason = typeof m.stopReason === "string" ? m.stopReason : undefined;
					if (fig) {
						addUsageFigures(ctx.usageTotals, fig);
					ctx.usageObserved = true;
					if (isFirstAssistantCall) {
							const parts = [fig.input, fig.cacheRead, fig.cacheWrite].filter((v): v is number => v !== undefined);
							if (parts.length > 0) ctx.firstCallContext = parts.reduce((a, b) => a + b, 0);
							// 首条 usage 无输入分项 → 保持未知（不得由第二条冒充）
						}
					ctx.lastCallUsage = { ...fig, ...(stopReason !== undefined ? { stopReason } : {}) };
				} else {
					ctx.usageMissingCalls++;
					if (stopReason !== undefined) ctx.lastCallUsage = { stopReason };
				}
			} else if (m.role === "toolResult" || advisor) {
				// 工具执行结束（tool_execution_end）不携带 usage，本帧（工具消息结束）是唯一入账点——不存在双计。
				const fig = readUsageFigures(advisor?.usage ?? m.usage);
				if (fig) {
						if (!ctx.nestedUsage) ctx.nestedUsage = newUsageTotals();
						addUsageFigures(ctx.nestedUsage, fig);
						ctx.nestedCalls++;
				}
			}
			}
		}
		// v1.5.220→v1.5.222 settle 信号终稿帧白名单：仅 stopReason 为 "stop"/缺失、无 toolCall、
		// 无 errorMessage 的帧才计时（此前两轮误杀：toolUse 轮首 token 慢被杀；cbc75699 的 provider
		// error 帧后 SDK 退避重试静默 >25s 被杀且误标 done）。error=重试在飞、length=自动续段在飞、
		// toolUse=工具轮在飞、aborted=异常终止——全都不是 turn 完成信号；挂死由子进程自退/看门狗/总超时接管。
		if ((ev.message as { role?: string }).role === "assistant") {
			const m = ev.message as { stopReason?: string; errorMessage?: string; content?: unknown };
			const hasToolCall = Array.isArray(m.content) && (m.content as Array<{ type?: string }>).some((p) => p?.type === "toolCall");
			const stop = m.stopReason;
			const isCleanFinal = !hasToolCall && !m.errorMessage && (stop === undefined || stop === "stop");
			ctx.lastAssistantEndTs = isCleanFinal ? Date.now() : undefined;
		}
		const sz = Buffer.byteLength(JSON.stringify(ev.message), "utf8");
		const cap = getMaxMessageBytes();
		if (sz > cap) {
			// 单条消息即超上限：终帧无法完整保留，维持不可信判定（error + resume 指引）。
			ctx.messageTruncated = true;
			return;
		}
		// 增量工具统计先行（淘汰帧不丢计数），再入队 + 尾部淘汰最旧帧。
		// 环形保留（ring buffer）：累计超上限时淘汰最早帧而非丢弃新帧——终稿帧永不丢，
		// 根治"缓冲超上限丢终稿 → 误判 error"（实战 luban/diting 单次任务三连命中）。
		const content = (ev.message as { content?: unknown }).content;
		if (Array.isArray(content)) {
			for (const p of content as Array<{ type?: string; name?: unknown }>) {
				if (p?.type === "toolCall") {
					ctx.toolCalls++;
					if (typeof p.name === "string" && p.name) {
						ctx.toolNames.add(p.name);
						// A1-R（diting Major-3）写盘意图登记：仅登记写盘类调用，成功 tool_result 才核销计数
						//（阻断/失败不算——宁保留 handoff 窗口，不把未落盘的调用当完成正证据）。
						// Wave C2：同位捕获写盘目标（write/edit 的 file_path/path；bash 高置信写形态
						// 的重定向/tee/of= 目标粗提取——提取不到则不记，宁缺勿错）。
						const tc = p as { name: string; id?: unknown; args?: unknown; arguments?: unknown; input?: unknown };
						const rawArgs = tc.args ?? tc.arguments ?? tc.input;
						if (isWriteToolCall(p.name, rawArgs)) {
							const paths = p.name === "bash"
								? bashWriteTargets(String((rawArgs as { command?: unknown } | null | undefined)?.command ?? ""))
								: writeEditTargets(rawArgs);
							ctx.pendingWriteCalls.push({ id: typeof tc.id === "string" ? tc.id : undefined, writeClass: true, paths });
						}
					}
				}
			}
		}
		ctx.messages.push(ev.message);
		ctx.messageSizes.push(sz);
		ctx.messageBytes += sz;
		while (ctx.messageBytes > cap && ctx.messages.length > 1) {
			ctx.messages.shift();
			ctx.messageBytes -= ctx.messageSizes.shift() ?? 0;
			ctx.evictedMessages++;
		}
		// v1.5.186 P2 doom-loop 检测（grok doom_loop 移植）：连续同签名 toolCall 超阈值 →
		// 记 doomLoop（data handler 杀进程）；不同签名/无工具帧则复位。max thinking 下死循环
		// 每分钟都在烧 token，此前只能靠任务超时兜底（10min+）。
		if (ev.message.role === "assistant") {
			const toolParts = Array.isArray(content)
				? (content as Array<{ type?: string; name?: string; args?: unknown; arguments?: unknown; input?: unknown }>).filter((p) => p?.type === "toolCall" && typeof p.name === "string")
				: [];
			if (toolParts.length > 0) {
				const sig = toolParts.map((p) => `${p.name}:${JSON.stringify(p.args ?? p.arguments ?? p.input ?? {}).slice(0, 500)}`).join("|");
				if (sig === ctx.lastToolSig) ctx.toolSigRepeats++;
				else { ctx.lastToolSig = sig; ctx.toolSigRepeats = 1; }
				const th = getDoomLoopThreshold();
				if (th > 0 && ctx.toolSigRepeats >= th && !ctx.doomLoop) ctx.doomLoop = sig.slice(0, 200);
			} else if (ctx.toolSigRepeats > 0) { ctx.lastToolSig = undefined; ctx.toolSigRepeats = 0; }
		}
		if (ev.message.model) {
			// v1.5.219 修复：pi 流内 message.model 是裸 modelId（如 glm-5.3，无 provider/思考档），
			// 直接覆盖会把 registry/面板的 "amagi-glm/glm-5.3:max" 降级成 "glm-5.3"——
			// 思考强度显示丢失（实战：面板运行中实况无 :max）。合并策略：流值与 spawnModel
			// 尾名一致时保留 spawn 全形态；不同名（运行中换模型）才接受流值。
			const streamed = String(ev.message.model);
			const spawn = ctx.spawnModel;
			const bare = (x: string) => { const stripped = stripModelThinkingSuffix(x); return stripped.includes("/") ? stripped.split("/").pop()! : stripped; };
			if (spawn && bare(streamed) === bare(spawn)) ctx.model = spawn;
			else ctx.model = streamed;
		}
		// P0-1: 读取 stopReason/errorMessage（provider error 即使 exit 0 也判 error）
		if (ev.message.stopReason) {
			ctx.stopReason = ev.message.stopReason;
			// v1.5.216 修复：瞬时 provider 错误经 auto_retry 成功恢复后，后续帧以非 error
			// stopReason 正常收尾 → 清除早期残留 errorMessage，否则终稿完整交付仍被误判
			// error（实战：S2 重试 2 次成功交付报告，状态却 error）。终态取“最后一帧”语义：
			// 真正终止在最后的错误帧（stopReason 保持 error/aborted）不受影响。
			if (ctx.stopReason !== "error" && ctx.stopReason !== "aborted") ctx.errorMessage = undefined;
		}
		if (ev.message.errorMessage) ctx.errorMessage = ev.message.errorMessage;
	}
}

function normalizedShellTail(command: string): string {
	const tail = command.split(/&&|;/).at(-1) || "";
	return tail.replace(/\s+\d?>&\d\s*$/, "").trim().replace(/\s+/g, " ");
}

/** 基线命令识别（findReusableTestEvidence 与 B0-3 重复全套观测共用；末段命令归一比对，
 *  容忍 --silent 尾缀）。导出供观测计数与测试直接断言同一单源。 */
export function matchesDetectedTest(command: unknown, detected: DetectedTest): boolean {
	if (typeof command !== "string") return false;
	const actual = normalizedShellTail(command);
	const exact = detected.cmd.join(" ");
	const withoutSilent = detected.cmd.at(-1) === "--silent" ? detected.cmd.slice(0, -1).join(" ") : exact;
	return actual === exact || actual === withoutSilent;
}

/** §7.2 V2 提取证据形状：bash 工具执行观测（harness 捕获的进程事实：isError/resultText/duration）
 *  + 可选对象指纹。无指纹 = display-only（只能展示，不得作为结算 ready 判定或跨快照复用依据）。 */
export interface ReusableTestEvidence {
	command: string[];
	result: CmdResult;
	execCwd?: string;
	/** 对象指纹（§7.2 复用「对象完全一致」条件的凭据）：仅 harness 结构化捕获的检查证据才有
	 *  （evidence.ts runStructuredCheck 产出的 CheckResult+对象）；旧任务/子进程裸 bash 观测无指纹 → undefined。 */
	objectFingerprint?: { objectId: string; policyDigest: string };
	/** true = 携带对象指纹且结果通过（exit 0）——可作 ready/结构化复用依据；false = display-only。 */
	reusable: boolean;
}

export interface FindReusableTestEvidenceOpts {
	/** 对象指纹供给（harness 侧注入，V3 接线点）：给定观测执行与其真实 cwd，返回该执行所属验证
	 *  对象的指纹；返回 undefined = 该执行不在任何已捕获对象上（display-only）。 */
	objectFingerprint?: (execution: ToolExecutionObservation, observedCwd: string | undefined) => { objectId: string; policyDigest: string } | undefined;
}

export function findReusableTestEvidence(
	rounds: ReadonlyArray<{ _toolExecutions?: ReadonlyArray<ToolExecutionObservation> }>,
	detected?: DetectedTest,
	/** 调用方已知的默认执行 cwd（子进程 spawn cwd）；缺省 = 观测未知，对子包命中禁止复用。 */
	defaultCwd?: string,
	/** V2 §7.2 对齐：对象指纹供给（缺省无 → 提取结果 display-only）。 */
	opts?: FindReusableTestEvidenceOpts,
): ReusableTestEvidence | undefined {
	if (!detected) return undefined;
	let unsafeExecutionAfter = false;
	for (let roundIndex = rounds.length - 1; roundIndex >= 0; roundIndex--) {
		const executions = [...(rounds[roundIndex]._toolExecutions || [])].sort((a, b) => b.order - a.order);
		for (const execution of executions) {
			if (execution.toolName === "bash" && matchesDetectedTest(execution.args.command, detected) && !unsafeExecutionAfter) {
				// ev-20260906-d9dc13（Leader 反馈修正）：观测 cwd 只取真实 execution.args.cwd（bash 原生
				// cwd 参数），缺省回退调用方已知的默认 cwd；两者皆缺 → 观测未知。绝不用 detected.execCwd
				//（期望值）充当观测值——那会把根目录跑的 npm test 冒充子包测试证据（假归因）。
				const rawCwd = typeof execution.args?.cwd === "string" && execution.args.cwd.trim() !== "" ? execution.args.cwd : defaultCwd;
				const observed = rawCwd && path.isAbsolute(rawCwd) ? path.resolve(rawCwd)
					: rawCwd && defaultCwd && path.isAbsolute(defaultCwd) ? path.resolve(defaultCwd, rawCwd) : undefined;
				// 复合 shell 可以 cd 或改写文件；仅凭末段命令不能证明测试目录或更早证据仍有效。
				if (detected.execCwd && /[;&|\n\r]/.test(String(execution.args.command))) return undefined;
				// 子包级联命中要求观测 cwd 确证 === 子包目录；观测未知/不符 → 本条不可复用（保守：
				// 宁可重跑，不采信无法定位执行目录的基线）；该 bash 也可能有写副作用，不能越过复用旧结果。
				if (detected.execCwd && observed !== path.resolve(detected.execCwd)) return undefined;
				// V2 §7.2 对齐：观测本身是 harness 捕获的进程事实（非模型自报文本），但无对象指纹时
				// 只能 display-only（不作为 ready 判定/跨快照复用依据）；指纹由 harness 侧注入面供给（V3 接线）。
				const fingerprint = opts?.objectFingerprint?.(execution, observed);
				return {
					command: [...detected.cmd],
					// 观测确证的执行 cwd（子包场景已与 detected.execCwd 归一相等）；根命中不携带
					//（缺省 = effCwd，既有 cwd 无关口径零变化）
					execCwd: detected.execCwd ? observed : undefined,
					result: {
						ok: !execution.isError,
						stdout: execution.resultText,
						stderr: "",
						code: execution.isError ? 1 : 0,
						timedOut: false,
						durationMs: execution.durationMs,
					},
					...(fingerprint ? { objectFingerprint: fingerprint } : {}),
					reusable: !!fingerprint && !execution.isError,
				};
			}
			if (execution.toolName === "edit" || execution.toolName === "write" || execution.toolName === "bash") {
				unsafeExecutionAfter = true;
			}
		}
	}
	return undefined;
}

// ── B0-3（Leader 成本效率编排 §3.4 / 附录 B.2）：重复全套观测 ──────────────────

/** 子代理重复全套观测结果（只记录，不改变行为；次数与末次候选拆开，不一个对象冒充计数器）。 */
export interface ChildSuiteObservation {
	/** 已结束、可识别且 cwd 匹配的基线命令执行次数（下界：观测缓冲有界、间接调用不猜测）。 */
	fullSuiteRuns: number;
	/** 命中命令但 cwd 不匹配/不可确证的执行数（异 cwd 不算同一回归，单列不丢弃）。 */
	cwdMismatchRuns: number;
	/** findReusableTestEvidence 是否返回候选——只证明最近命中后无 unsafe 工具，不证明文件状态。 */
	candidate: boolean;
}

/** 从各轮 _toolExecutions 统计基线命令执行（复用 matchesDetectedTest 命令识别 + findReusableTestEvidence
 *  的 cwd 保守条件：复合 shell 且带 execCwd 时不猜测；观测 cwd 只取真实 execution.args.cwd，
 *  缺省回退调用方已知 defaultCwd，两者皆缺 → 不可确证）。 */
export function observeChildSuiteRuns(
	rounds: ReadonlyArray<{ _toolExecutions?: ReadonlyArray<ToolExecutionObservation> }>,
	detected: DetectedTest,
	defaultCwd?: string,
): ChildSuiteObservation {
	let fullSuiteRuns = 0;
	let cwdMismatchRuns = 0;
	for (const round of rounds) {
		const executions = [...(round._toolExecutions || [])].sort((a, b) => a.order - b.order);
		for (const execution of executions) {
			if (execution.toolName !== "bash" || !matchesDetectedTest(execution.args.command, detected)) continue;
			const command = String(execution.args.command);
			const compound = /[;&|\n\r]/.test(command);
			// 复合 shell 可以 cd 或改写文件；仅凭末段命令不能证明测试目录——与 findReusableTestEvidence
			// 同保守口径：不猜测（不计入次数，也不计入异 cwd）。
			if (detected.execCwd && compound) continue;
			const rawCwd = typeof execution.args?.cwd === "string" && execution.args.cwd.trim() !== "" ? execution.args.cwd : defaultCwd;
			const observed = rawCwd && path.isAbsolute(rawCwd) ? path.resolve(rawCwd)
				: rawCwd && defaultCwd && path.isAbsolute(defaultCwd) ? path.resolve(defaultCwd, rawCwd) : undefined;
			if (detected.execCwd) {
				if (observed === path.resolve(detected.execCwd)) fullSuiteRuns++;
				else cwdMismatchRuns++;
			} else {
				// F6（diting 终审）：根级命中同样要能确证 cwd——复合命令（`cd 别处 && npm test` 等）可能
				// 改写工作目录，末段命中不能证明在本根执行：计入 cwd 不匹配/不可确证桶，不进确认次数。
				if (compound) { cwdMismatchRuns++; continue; }
				// 单一命令同样比较观测 cwd 与项目根（defaultCwd 解析）：相等才计入确认次数；
				// args.cwd=/other 等异目录不冒充本项目全套。defaultCwd 缺失/观测不可解析 → 不可确证
				// （保守不计入确认次数，单列 mismatch 桶，同子包口径）。候选 display-only 语义
				//（findReusableTestEvidence）不随本路径变更（遗留观察已裁决保留）。
				if (defaultCwd === undefined || observed === undefined) { cwdMismatchRuns++; continue; }
				if (observed === path.resolve(defaultCwd)) fullSuiteRuns++;
				else cwdMismatchRuns++;
			}
		}
	}
	return { fullSuiteRuns, cwdMismatchRuns, candidate: findReusableTestEvidence(rounds, detected, defaultCwd) !== undefined };
}

/** P1-7: ParseContext usage 提取。B0-1（附录 B.1）起为**累计口径**：返回本次运行可见
 *  message_end 事件的各项 usage 之和（缺项保持 undefined=未上报，不补 0；全程无 usage → 空对象）。
 *  末轮诊断快照经 lastCall 单列（extractUsageDetail）；不再从 ctx.messages 倒扫（旧口径在末帧
 *  缺 usage 时会误吞 toolResult 嵌套 usage——pi-099 §M2 负例锚）。 */
export function extractUsage(ctx: ParseContext): UsageFigures {
	if (!ctx.usageObserved) return {};
	return usageFiguresOf(ctx.usageTotals);
}

/** B0-1（附录 B.1）：一次运行的完整累计口径（totals/调用数/首末上下文/嵌套/压缩分栏）。 */
export function extractUsageDetail(ctx: ParseContext): CumulativeUsage {
	return {
		totals: extractUsage(ctx),
		assistantCalls: ctx.assistantCalls,
		usageMissingCalls: ctx.usageMissingCalls,
		...(ctx.firstCallContext !== undefined ? { firstCallContext: ctx.firstCallContext } : {}),
		...(ctx.lastCallUsage !== undefined ? { lastCall: ctx.lastCallUsage } : {}),
		...(ctx.nestedUsage !== undefined ? { nestedUsage: usageFiguresOf(ctx.nestedUsage) } : {}),
		nestedCalls: ctx.nestedCalls,
		...(ctx.compactionUsage !== undefined ? { compactionUsage: usageFiguresOf(ctx.compactionUsage) } : {}),
		compactionEvents: ctx.compactionEvents,
	};
}

/** B0-1：usageCoverage —— 可见事件的缺 usage/截断/异常中断标注（"complete" 或 "|" 连接的 flags；
 *  完整仅指可见协议事件齐备，不能宣称等于供应商账单完整）。flags：missing-usage（有完结帧缺
 *  usage）、output-truncated（stdout 总量/单条/单行截断）、abnormal-exit（error/truncated 终态）。 */
export function usageCoverageOf(ctx: ParseContext, status: string | undefined): string {
	const flags: string[] = [];
	if (ctx.usageMissingCalls > 0) flags.push("missing-usage");
	if (ctx.stdoutCapped || ctx.messageTruncated || ctx.lineTruncated) flags.push("output-truncated");
	if (status === "error" || status === "truncated") flags.push("abnormal-exit");
	return flags.length > 0 ? flags.join("|") : "complete";
}

/** 仅冻结能力已授权的有界在途咨询可豁免终稿兜底，不延长任务总时限。 */
export function advisorConsultationPending(ctx: ParseContext, timeoutMs: number | undefined, now = Date.now()): boolean {
	if (!timeoutMs || timeoutMs <= 0 || timeoutMs > 300000) return false;
	return [...(ctx.pendingAdvisors?.values() ?? [])].some(started => now >= started && now - started < timeoutMs + 1000);
}
