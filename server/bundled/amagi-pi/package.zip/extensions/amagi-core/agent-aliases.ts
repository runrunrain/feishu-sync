/**
 * agent-aliases.ts — v2 子 Agent 体系角色别名归一与代码基线策略（无 I/O 纯模块）。
 *
 * 体系 13→5 切换（2026-09-19 定案 v4.2）：五 canonical 角色 baize/luban/luoshen/diting/fuxi；
 * 八个旧岗位 stem 收敛为别名（wenqu→baize；taibai/laojun/wukong/cangjie→luban；
 * diting-quick→diting+quick；hongjun→fuxi+attack；puti→fuxi+reflect）。别名兼容只保留一个发布
 * 版本，之后移除入口兼容；不改写历史 artifact、审核注释或手册。
 *
 * 归一七步（设计方案 §7.2）：
 *  1. 保留请求标识 requestedAgent；只对被解析成 Agent token 的完整标识精确查表——不对自然语言、
 *     文件名或 artifact 文本做替换（普通任务正文提到别名不算显式触发）。
 *  2. 查表得 canonical id 与兼容模式；canonical 名幂等；未知名称沿用调用方既有「不存在角色」
 *     错误，不猜近似名（本模块 known=false 透传，由调用方报错）。
 *  3. 模式优先级：明确任务模式 > 别名默认 > 角色默认（diting→full；fuxi→design）。
 *     跨角色非法模式（如 luban 带 reviewMode）返回参数错误，不静默忽略。
 *  4. #hongjun/#puti 或显式 agent 字段使用别名 = 用户/Leader 显式选择对应态。
 *  5. canonical id 用于角色文件查找、权限、预算、模型/MCP 选择与证据分类；requestedAgent 仅作
 *     回执兼容说明，不另建遥测链。
 *  6. 解析模式 ≠ 角色默认时产出任务契约固定首部（modeHeader），由派发层注入任务正文首部；
 *     注入幂等（withModeHeader 检测既有首部不重复附加）。
 *  7. 本版本不存在旧角色文件的二次 fallback：别名归一后找不到新角色文件由调用方明确失败。
 *
 * 代码基线策略（设计方案 §7.1 A/B，两调用点 task-tool AUTO_VERIFY 与 evidence DEFAULT_CODE_AGENTS
 * 消费同一判定）：候选集合 CODE_PRODUCT_AGENTS={luban,luoshen,fuxi} 不是无条件执行集合——
 * 「可能交付项目代码、需按代码产物验收的角色」；实际触发 = shouldRunCodeBaseline(ctx)（候选 &&
 * producesProjectCode && (非 fuxi || fuxiState==="attack")）。D1 裁决（2026-09-19）：fuxi 只给指导性
 * 方案不落地实现（artifact-only），producesProjectCode 恒 false 永不触发；机制保留为未来授权留口。
 */

// ── 类型与别名表 ─────────────────────────────────────────────────────────────

export type CanonicalAgentId = "baize" | "luban" | "luoshen" | "diting" | "fuxi";
export type DitingReviewMode = "quick" | "full";
export type FuxiState = "design" | "attack" | "reflect";

/** 别名归一目标：canonical 角色 + 兼容模式（缺省由角色默认补齐）。 */
export interface AliasTarget {
	agent: CanonicalAgentId;
	reviewMode?: DitingReviewMode;
	fuxiState?: FuxiState;
}

/** 八个退役岗位 stem → canonical 目标（§7.2 全表；键一律小写）。 */
export const AGENT_ALIASES: Readonly<Record<string, AliasTarget>> = {
	wenqu: { agent: "baize" },
	taibai: { agent: "luban" },
	laojun: { agent: "luban" },
	wukong: { agent: "luban" },
	cangjie: { agent: "luban" },
	"diting-quick": { agent: "diting", reviewMode: "quick" },
	hongjun: { agent: "fuxi", fuxiState: "attack" },
	puti: { agent: "fuxi", fuxiState: "reflect" },
};

/** 五 canonical id（AGENTS.md 名册口径；agents/*.md 文件 stem 单源，此处仅策略模块内部枚举）。 */
export const CANONICAL_AGENT_IDS: readonly CanonicalAgentId[] = ["baize", "luban", "luoshen", "diting", "fuxi"];

/** 角色默认模式（§7.2 步骤 3 最低档）：diting 未指定按 full；fuxi 未指定按 design。 */
const ROLE_DEFAULT_MODE: Readonly<Record<"diting" | "fuxi", { reviewMode?: DitingReviewMode; fuxiState?: FuxiState }>> = {
	diting: { reviewMode: "full" },
	fuxi: { fuxiState: "design" },
};

/** 模式归属角色（跨角色非法模式报错的判定依据）。 */
const REVIEW_MODE_OWNER: Readonly<Record<DitingReviewMode, CanonicalAgentId>> = { quick: "diting", full: "diting" };
const FUXI_STATE_OWNER: Readonly<Record<FuxiState, CanonicalAgentId>> = { design: "fuxi", attack: "fuxi", reflect: "fuxi" };

// ── 归一解析（七步；纯函数） ────────────────────────────────────────────────

/** 显式任务模式入口（§7.2 步骤 3 最高档）：由派发入口的结构化请求携带（如 #qreview 的 quick）。 */
export interface ExplicitAgentMode {
	reviewMode?: DitingReviewMode;
	fuxiState?: FuxiState;
}

export interface AgentRequestResolution {
	/** 步骤 1：用户/Leader 原始请求标识（保留大小写原样；回执兼容说明用）。 */
	requestedAgent: string;
	/** 步骤 2/5：canonical id；未知名原样透传（known=false，由调用方沿用既有未知角色错误）。 */
	agent: string;
	/** 命中 canonical 或别名表。 */
	known: boolean;
	/** 步骤 3 解析出的最终模式（仅归属角色产生；角色默认档也回填，供调用方一致性校验）。 */
	reviewMode?: DitingReviewMode;
	fuxiState?: FuxiState;
	/** 步骤 6：任务契约固定首部（解析模式 ≠ 角色默认时非空）。 */
	modeHeader?: string;
}

/** 跨角色非法模式错误（§7.2 步骤 3：报参数错误，不静默忽略）。 */
export interface AgentRequestError {
	error: string;
}

function modeHeaderOf(agent: string, reviewMode?: DitingReviewMode, fuxiState?: FuxiState): string | undefined {
	if (reviewMode === "quick") return "审核档: quick";
	if (fuxiState === "attack") return "任务态: attack";
	if (fuxiState === "reflect") return "任务态: reflect";
	// full/design 为角色默认档：不注入首部（默认不注噪音；§7.2 步骤 6）。
	return undefined;
}

/**
 * 统一解析入口（§7.2 全规格）。输入为完整 Agent token（#点名 role、task.agent、batch 节点、
 * resume 的 record.agent）；返回 canonical id + 最终模式 + 固定首部。未知名不报错——known=false
 * 透传，由调用方沿用既有「不存在角色」错误（本模块不重复实现各入口的错误文案）。
 */
export function resolveAgentRequest(requestedAgent: string, explicitMode?: ExplicitAgentMode): AgentRequestResolution | AgentRequestError {
	const requested = requestedAgent.trim();
	const key = requested.toLowerCase();
	// 步骤 2：canonical 幂等 / 别名查表 / 未知名透传。
	let agent: string;
	let alias: AliasTarget | undefined;
	if ((CANONICAL_AGENT_IDS as readonly string[]).includes(key)) {
		agent = key;
	} else {
		alias = AGENT_ALIASES[key];
		agent = alias ? alias.agent : requested;
	}
	if (!alias && !(CANONICAL_AGENT_IDS as readonly string[]).includes(key)) {
		// 未知名称：不猜近似名（步骤 2）。
		return { requestedAgent: requested, agent: requested, known: false };
	}
	// 步骤 3：明确任务模式 > 别名默认 > 角色默认；跨角色非法模式报参数错误。
	if (explicitMode?.reviewMode !== undefined && REVIEW_MODE_OWNER[explicitMode.reviewMode] !== agent) {
		return { error: `reviewMode "${explicitMode.reviewMode}" 不适用于角色 "${agent}"（审核档仅 diting；跨角色非法模式）` };
	}
	if (explicitMode?.fuxiState !== undefined && FUXI_STATE_OWNER[explicitMode.fuxiState] !== agent) {
		return { error: `fuxiState "${explicitMode.fuxiState}" 不适用于角色 "${agent}"（任务态仅 fuxi；跨角色非法模式）` };
	}
	const roleDefault = agent === "diting" || agent === "fuxi" ? ROLE_DEFAULT_MODE[agent] : {};
	const reviewMode = explicitMode?.reviewMode ?? alias?.reviewMode ?? roleDefault.reviewMode;
	const fuxiState = explicitMode?.fuxiState ?? alias?.fuxiState ?? roleDefault.fuxiState;
	return {
		requestedAgent: requested,
		agent,
		known: true,
		...(reviewMode !== undefined ? { reviewMode } : {}),
		...(fuxiState !== undefined ? { fuxiState } : {}),
		...(modeHeaderOf(agent, reviewMode, fuxiState) !== undefined ? { modeHeader: modeHeaderOf(agent, reviewMode, fuxiState) } : {}),
	};
}

/** 名字归一（幂等；未知名原样返回）——各派发入口的角色查找统一经此，不各自猜文本。 */
export function canonicalAgentId(requestedAgent: string): string {
	const key = requestedAgent.trim().toLowerCase();
	if ((CANONICAL_AGENT_IDS as readonly string[]).includes(key)) return key;
	return AGENT_ALIASES[key]?.agent ?? requestedAgent.trim();
}

/** 兼容名册（canonical + 别名键，排序稳定）：工具 schema 枚举与错误提示共用。 */
export function dispatchAcceptableAgentIds(canonical: readonly string[]): string[] {
	return [...canonical, ...Object.keys(AGENT_ALIASES).filter((k) => !canonical.includes(k))];
}

/**
 * 按请求标识查找角色配置（全部派发入口的统一查找口：#点名、task 单任务、batch 节点、resume
 * 的 record.agent、编排节点、answer-queue、webui 恢复等）。别名先归一到 canonical 再按
 * name/frontmatterName 精确匹配——I5「别名集中归一所有入口」的实现锚点。
 */
export function findAgentByRequest<T extends { name: string; frontmatterName?: string }>(agents: readonly T[], requestedAgent: string): T | undefined {
	const key = canonicalAgentId(requestedAgent);
	return agents.find((a) => a.name === key || a.frontmatterName === key) ?? agents.find((a) => a.name === requestedAgent.trim() || a.frontmatterName === requestedAgent.trim());
}

/**
 * 任务正文首部注入（§7.2 步骤 6）：modeHeader 存在时前置为固定首部；幂等——正文已带同款
 * 首部（或 canonical 归一重复调用）不重复附加。
 */
export function withModeHeader(header: string | undefined, task: string): string {
	const body = task;
	if (!header) return body;
	const lines = body.split("\n");
	if (lines[0]?.trim() === header) return body; // 幂等：canonical 名再归一不重复附加模式首部
	return `${header}\n${body}`;
}

// ── 代码基线策略（§7.1 A/B；两调用点消费同一判定） ──────────────────────────

/**
 * 代码产物候选角色（设计方案 §7.1）：“可能交付项目代码、需按代码产物验收的角色”。
 * 候选集合不是无条件执行集合——实际触发见 shouldRunCodeBaseline。
 * task-tool AUTO_VERIFY 与 evidence DEFAULT_CODE_AGENTS 共用这一定义，不能各维护一份。
 */
export const CODE_PRODUCT_AGENTS: ReadonlySet<string> = new Set(["luban", "luoshen", "fuxi"]);

export type FuxiStateOf = FuxiState;

/** 代码基线判定上下文（字段由任务归一层产生；不直接增设公网/工具 schema）。 */
export interface CodeProductContext {
	/** 已归一 canonical id。 */
	agent: string;
	/** 任务是否产出项目代码（fresh 变更路径含代码文件；fuxi 按裁决恒 false）。 */
	producesProjectCode: boolean;
	/** fuxi 三态（当前派发层不结构化携带；机制保留为未来授权留口）。 */
	fuxiState?: FuxiState;
}

/**
 * 统一代码基线判定（§7.1）：候选角色 && producesProjectCode && (非 fuxi || fuxiState==="attack")。
 * D1 裁决下 fuxi producesProjectCode=false 永不触发；未来裁定授权项目写码后由归一层置
 * producesProjectCode=true 且携带 fuxiState="attack" 才触发（本行不构成权限授权）。
 */
export function shouldRunCodeBaseline(ctx: CodeProductContext): boolean {
	if (!CODE_PRODUCT_AGENTS.has(ctx.agent)) return false;
	if (!ctx.producesProjectCode) return false;
	if (ctx.agent === "fuxi") return ctx.fuxiState === "attack";
	return true;
}

/**
 * 代码文件判定（保守白名单扩展名；无扩展名路径按非代码处理）。用于 fresh 变更路径分类：
 * 含任一代码/结构化项目文件 → producesProjectCode=true；纯文档（md/txt）、图像与二进制资产
 * 变更 → false。json/yaml/toml 等结构化项目文件（package.json 等）计入——它们承载脚本/配置/
 * 契约，不是「文档/Git 收尾」场景（§7.1 表第 3 行不触发面）。
 */
const CODE_FILE_RE = /\.(?:[cm]?ts|tsx|[cm]?js|jsx|py|rb|go|rs|java|kt|kts|swift|c|h|cc|cpp|cxx|hpp|cs|php|vue|svelte|scala|sh|bash|zsh|sql|graphql|gql|proto|zig|dart|lua|json5?|ya?ml|toml|ini|env|lock)$/i;

/** fresh 变更路径 → 是否产出项目代码。paths 为 null（无法判定：非 git 仓库/探测失败）时保守
 *  返回 true——取值规则「不能因任务声称文档跳过代码验收」：未知不跳过，沿用旧候选必跑口径。 */
export function producesProjectCodeFromPaths(paths: readonly string[] | null): boolean {
	if (paths === null) return true;
	return paths.some((p) => CODE_FILE_RE.test(p));
}

/**
 * 调用点便捷构造：D1 裁决下 fuxi（artifact-only）producesProjectCode 恒 false；其余角色按
 * fresh 路径分类（null=无法判定保守 true）；非候选角色直接 false。
 */
export function codeProductContextOf(agentName: string, producesProjectCode: boolean): CodeProductContext {
	if (agentName === "fuxi") return { agent: agentName, producesProjectCode: false };
	return { agent: agentName, producesProjectCode };
}

/**
 * 自动验证门（设计方案 §7.1 AUTO_VERIFY 面）：trusted + 编码基线判定 + AMAGI_AUTO_VERIFY_OFF 逃生舱。
 * ev-20261013（设计 §5.3/§9.3）：自 task-tool.ts 迁入——background 派发需同一公式计算预检
 * autoVerify，但 depcruise 禁止 task-background 反向 import task-tool；迁到本纯模块保单一来源，
 * 防 sync/background 公式漂移。消费点：task-tool（预检行 + sync auto-verifier shouldAutoVerify）、
 * task-background（预检行）。
 */
export function automaticVerificationEnabled(agentName: string, trusted?: boolean, producesProjectCode: boolean = true): boolean {
	return trusted === true && shouldRunCodeBaseline(codeProductContextOf(agentName, producesProjectCode)) && process.env.AMAGI_AUTO_VERIFY_OFF !== "1";
}
