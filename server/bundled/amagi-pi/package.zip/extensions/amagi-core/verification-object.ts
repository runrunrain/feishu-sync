/**
 * verification-object.ts — amagi-pi v2 V1：验证对象与安全捕获（方案 §7.1 / §8.5-V1 / §9.1「验证对象」行）。
 *
 * 职责：把「检查运行所处的冻结内容与环境」建立为可校验的 VerificationObject（K1 契约形状，
 * contracts/evidence.ts 消费端校验器）：
 *   1. 对象清单全量捕获（§7.1.2）：未提交改动/未跟踪文件/删除项/执行位变化/嵌套 cwd（子目录基线
 *      或子模块条目）都进清单——不只检 HEAD。hash 为**工作树文件字节** SHA-256（非 git 对象）。
 *   2. 专用临时捕获目录（§7.1.3）：worktree.ts 的窄接口 captureSnapshot 提供 mkdtemp 捕获槽 +
 *      linked worktree 归属保护（活跃租约如实上报）；捕获全程不改用户索引、不 stash、不更新用户分支。
 *   3. 复制前后 hash 核对（§7.1.3/§7.1.6 前半）：清单 digest（复制前源内容）与复制后源/副本
 *      双对照，任一变化 → object-changed，不产出对象（不继续验证——V2 据此停止检查）。
 *   4. 不可复制输入诚实 unavailable（§7.1.4）：凭据、外部依赖（node_modules）、越界 symlink、
 *      复制失败、子模块内容 → limitations 记录（不静默缺失）；V2 将相关检查判 unavailable。
 *   5. 快照模式判定面（§7.1.7）：objectMode snapshot|shared-tree（VerificationPolicy 已有）；
 *      快照关闭（snapshotEnabled=false / AMAGI_VERIFICATION_SNAPSHOT=0）后仅显式声明的
 *      shared-tree 或 allowSharedFallback=true 回落可用，否则判定不可建立（V2 → 检查 incomplete）。
 *   6. environmentDigest（§7.1.5）：node 版本/平台/架构/git HEAD/cwd 的规范化 hash——不含
 *      时间戳/捕获目录路径，同环境两次捕获同值。
 *
 * 边界（本片冻结）：不执行检查（V2 evidence.ts）、不结算（V3 finalizer）、不管理快照保留清理
 * 策略（成功对象保留供复核 §7.1.5，调用方决定何时 releaseCaptureDir）；依赖安装不自动执行
 * （dependencies-not-captured 只记录，安装须策略明确且授权 §7.1.4）。
 */

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { captureSnapshot, releaseCaptureDir } from "./worktree.ts";
import { validateVerificationObject, type VerificationMode, type VerificationObject } from "./contracts/evidence.ts";
import type { Ref } from "./contracts/view.ts";
import { captureLocalDependencies, verifyDependencyManifest, type DependencyCaptureLimits, type DependencyCaptureProgress, type DependencyManifest } from "./verification-dependencies.ts";

// ─────────────────────────────────────────────────────────────────────────────
// git 包装（本模块私有；30s 超时沿用 worktree.ts 约定）
// ─────────────────────────────────────────────────────────────────────────────

const GIT_TIMEOUT_MS = 30_000;

function gitRaw(args: string[], cwd: string): string {
	return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], timeout: GIT_TIMEOUT_MS });
}

// ─────────────────────────────────────────────────────────────────────────────
// 公共类型：清单 / 排除项 / 环境摘要 / 捕获结果
// ─────────────────────────────────────────────────────────────────────────────

/** 清单条目状态（由 git status XY 与 index 推导；非 git 源全为 untracked）。 */
export type ManifestEntryStatus =
	| "clean" | "modified" | "added" | "renamed" | "typechange"
	| "mode-change" | "untracked" | "deleted" | "submodule";

export interface ObjectManifestEntry {
	/** 相对 sourceCwd 的路径（POSIX 分隔；清单内路径一律相对，快照随捕获根整体迁移）。 */
	path: string;
	/** tracked（git index 内）/ untracked（工作区新增）。 */
	kind: "tracked" | "untracked";
	status: ManifestEntryStatus;
	/** 工作树字节 SHA-256（deleted 无内容 → null；submodule 为其 commit hash）。 */
	digest: string | null;
	bytes: number;
	/** 当前工作树执行位（lstat mode & 0o111）。 */
	executable: boolean;
	/** git index 模式（100644/100755/120000/160000；非 git 源无）。 */
	indexMode?: string;
	/** 执行位相对已知基线（index 模式）发生变化（§7.1.2 执行位记录；干净内容+执行位变化 → status 覆盖为 mode-change）。 */
	executableChanged?: boolean;
	/** 是否已复制进捕获目录（snapshot 模式成功后 true；shared-tree 模式恒 false；deleted false）。 */
	copied: boolean;
}

/** 被排除的输入（诚实 unavailable 面：不静默缺失，全部进 limitations）。 */
export interface ExcludedInput {
	path: string;
	reason: "credential" | "external-dependency" | "symlink-escape" | "copy-error" | "submodule";
	detail?: string;
	/** 是否必要输入（保守 true：被排除即可能导致相关检查 unavailable——V2 消费）。 */
	required: boolean;
}

/** 环境摘要事实（environmentDigest 的输入；全部字段值稳定——不含时间戳/捕获路径）。 */
export interface EnvironmentFacts {
	nodeVersion: string;
	platform: string;
	arch: string;
	/** git HEAD commit（非 git 源/空仓缺省）。 */
	gitCommit?: string;
	/** 规范化源 cwd（realpath 优先）。 */
	cwd: string;
	/** C2-a（方案 §2.8）：冻结依赖清单摘要（dependencyMode=copy-local 且完整校验通过才有）——
	 *  依赖内容变化 → digest 变化 → environmentDigest/objectId 变化 → 复用拒绝/重验。 */
	dependencies?: { digest: string; entries: number; bytes: number };
}

/** 对象清单：全部输入路径/类型/hash/删除项/依赖锁文件（§7.1.5）。 */
export interface VerificationManifest {
	sourceCwd: string;
	/** git 仓库根（非 git 源缺省 → limitations 记 no-git-baseline）。 */
	repoRoot?: string;
	/** 嵌套 cwd：sourceCwd 相对仓库根路径（子目录基线；源即仓库根 → \"\"）。 */
	cwdRelRepo?: string;
	/** 基线 commit 锚点。 */
	headCommit?: string;
	entries: readonly ObjectManifestEntry[];
	/** 删除项（index/基线有而工作树无；rename 另含原路径）。 */
	deletedPaths: readonly string[];
	/** sourceCwd 首层存在的依赖锁文件（外部依赖未随快照捕获的判定依据）。 */
	lockFiles: readonly string[];
	excluded: readonly ExcludedInput[];
}

export interface CaptureOptions {
	/** 验证策略（VerificationPolicy 已有字段；缺省 = { objectMode: \"snapshot\", allowSharedFallback: false }）。
	 *  C2-a：dependencyMode=copy-local 时捕获冻结依赖对象（root + 声明 workspace 子包
	 *  node_modules 私有副本；旧策略缺字段 = none，行为零变化）。 */
	policy?: { objectMode: VerificationMode; allowSharedFallback: boolean; dependencyMode?: "none" | "copy-local" };
	/** 快照开关（缺省按 env 解析：AMAGI_VERIFICATION_SNAPSHOT=0|false 关闭）。 */
	snapshotEnabled?: boolean;
	/** mkdtemp 根目录（测试隔离用；缺省 os.tmpdir()）。 */
	tmpDir?: string;
	/** 测试/上层钩子：清单建立后、复制前调用（§9.1「检查期间文件改变不能 passed」的捕获中途 mutate 夹具点）。 */
	afterManifest?: () => void;
	/** 测试/上层钩子：依赖清单建立后、依赖复制前调用（C2 依赖漂移夹具点）。 */
	afterDependencyManifest?: () => void;
	/** 依赖捕获上限覆盖（测试用；缺省 DEFAULT_DEPENDENCY_LIMITS：1 GiB / 100k 条 / 120s）。 */
	dependencyLimits?: Partial<DependencyCaptureLimits>;
	/** 依赖捕获进度回调（每 1,000 条或 5 秒；生产缺省不接，成本实测见 C2 报告）。 */
	onDependencyProgress?: (p: DependencyCaptureProgress) => void;
	/** 检查的相对 cwd/bin 计划，驱动同源依赖捕获。 */
	executionPlan?: { execCwd: string; binDirsRel: readonly string[] };
}

export type CaptureOutcome =
	| {
			ok: true;
			/** K1 契约形状的验证对象（已过 validateVerificationObject 自检）。 */
			object: VerificationObject;
			manifest: VerificationManifest;
			manifestRef: Ref;
			/** 捕获根（manifest.json 落盘处；snapshot 模式另含内容镜像）。成功后保留供复核（§7.1.5）。 */
			captureRoot: string;
			/** 生效模式（shared-tree 经 allowSharedFallback 回落时 mode=\"shared-tree\"、fallback=true）。 */
			mode: VerificationMode;
			fallback: boolean;
			environment: EnvironmentFacts;
			/** C2-a：依赖捕获事实（dependencyMode=copy-local 时有；none 缺席）。失败不阻断对象产出
			 *  ——调用方（evidence.ts/unavailableReason）据此将依赖型检查判 unavailable。 */
			dependencyCapture?: DependencyCaptureSummary;
			/** C2-a：完整依赖清单（检查结束后 verifyCapturedObject 复核输入；失败/none 缺席）。 */
			dependencyManifest?: DependencyManifest;
	  }
	| {
			ok: false;
			/** mode-unavailable=快照关闭且未显式允许 shared（V2 → 检查 incomplete）；object-changed=复制期间源内容变化（不产出对象、不继续验证）；capture-error=捕获槽/git 探测失败。 */
			code: "mode-unavailable" | "object-changed" | "capture-error";
			message: string;
			/** object-changed 时变化的相对路径清单。 */
			changedPaths?: string[];
			captureRoot?: string;
	  };

/** C2-a：依赖捕获结果摘要（成功事实进 environmentDigest；失败保留真实原因）。 */
export type DependencyCaptureSummary =
	| {
			mode: "copy-local";
			ok: true;
			digest: string;
			manifestRef: Ref;
			roots: number;
			files: number;
			symlinks: number;
			bytes: number;
			durationMs: number;
	  }
	| {
			mode: "copy-local";
			ok: false;
			code: string;
			reason: string;
			partialEntries: number;
			partialBytes: number;
	  };

// ─────────────────────────────────────────────────────────────────────────────
// 模式判定面（§7.1.7；V2 消费：decision.ok=false → 相关检查不可建立 → 结算 incomplete）
// ─────────────────────────────────────────────────────────────────────────────

export interface ObjectModeDecision {
	ok: boolean;
	mode: VerificationMode;
	/** true = 经 allowSharedFallback 从 snapshot 回落到 shared-tree。 */
	fallback: boolean;
	/** 拒绝原因（ok=false 时有）。 */
	reason?: "snapshot-disabled";
	message?: string;
}

/** 快照捕获开关（env 解析；AMAGI_VERIFICATION_SNAPSHOT=0|false 关闭——部署级，缺省开启）。 */
export function snapshotCaptureEnabled(env: Record<string, string | undefined> = process.env): boolean {
	const v = env.AMAGI_VERIFICATION_SNAPSHOT;
	return !(v === "0" || v === "false");
}

/**
 * 对象模式判定（纯函数）：快照可用 → 按策略 objectMode；快照关闭 → 仅①策略显式声明 shared-tree
 * 或②snapshot + allowSharedFallback=true 回落可用，否则不可建立（§7.1.7「否则 incomplete，不强行绿灯」
 * ——本片建立判定面，incomplete 结算由 V3 消费）。
 */
export function resolveObjectMode(
	policy: { objectMode: VerificationMode; allowSharedFallback: boolean },
	opts?: { snapshotEnabled?: boolean },
): ObjectModeDecision {
	const enabled = opts?.snapshotEnabled ?? snapshotCaptureEnabled();
	if (enabled) return { ok: true, mode: policy.objectMode, fallback: false };
	if (policy.objectMode === "shared-tree") {
		return { ok: true, mode: "shared-tree", fallback: false };
	}
	if (policy.allowSharedFallback) {
		return { ok: true, mode: "shared-tree", fallback: true };
	}
	return {
		ok: false,
		mode: policy.objectMode,
		fallback: false,
		reason: "snapshot-disabled",
		message: "快照捕获已关闭（snapshotEnabled=false / AMAGI_VERIFICATION_SNAPSHOT=0）且策略未显式允许 shared-tree（objectMode=snapshot、allowSharedFallback=false）——验证对象不可建立，相关检查将 incomplete（§7.1.7）",
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// 环境摘要（§7.1.5）：规范化 hash，同环境同值
// ─────────────────────────────────────────────────────────────────────────────

/** 规范化 JSON（键排序，稳定序列化——digest 输入与 manifest 落盘共用）。 */
function canonicalJson(v: unknown): string {
	const walk = (x: unknown): unknown => {
		if (Array.isArray(x)) return x.map(walk);
		if (x && typeof x === "object") {
			const rec: Record<string, unknown> = {};
			for (const k of Object.keys(x as Record<string, unknown>).sort()) rec[k] = walk((x as Record<string, unknown>)[k]);
			return rec;
		}
		return x;
	};
	return JSON.stringify(walk(v));
}

export function digestEnvironment(facts: EnvironmentFacts): string {
	return createHash("sha256").update(canonicalJson(facts)).digest("hex");
}

function normalizeCwd(cwd: string): string {
	try { return fs.realpathSync(cwd); } catch { return path.resolve(cwd); }
}

function gatherEnvironmentFacts(sourceCwd: string, slot: { headCommit?: string }): EnvironmentFacts {
	const facts: EnvironmentFacts = {
		nodeVersion: process.version,
		platform: process.platform,
		arch: process.arch,
		cwd: normalizeCwd(sourceCwd),
	};
	if (slot.headCommit) facts.gitCommit = slot.headCommit;
	return facts;
}

// ─────────────────────────────────────────────────────────────────────────────
// 排除规则（§7.1.4：不复制凭据和无关个人文件；§7.1.5：不跟随越界 symlink）
// ─────────────────────────────────────────────────────────────────────────────

/** 凭据类文件名/后缀（不复制、不读内容——连摘要也不产，凭据文件根本不出现在 entries）。 */
const CREDENTIAL_BASENAMES = new Set([
	".env", ".npmrc", ".netrc", ".awsrc", "credentials.json",
	"id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
]);
const CREDENTIAL_SUFFIXES = [".pem", ".key", ".p12", ".pfx"];

function isCredentialPath(rel: string): boolean {
	const base = path.posix.basename(rel);
	if (CREDENTIAL_BASENAMES.has(base)) return true;
	if (/^\.env\.[^.]+$/.test(base) && !/\.example$/.test(base)) return true;
	return CREDENTIAL_SUFFIXES.some((s) => base.endsWith(s));
}

/** 外部依赖目录（不复制：依赖安装须策略明确且授权 §7.1.4；limitation 如实记录）。 */
function isExternalDependencyDir(base: string): boolean {
	return base === "node_modules" || base === "vendor" || base === ".venv" || base === "venv";
}

/** 依赖锁文件（sourceCwd 首层；存在即记录 dependencies-not-captured limitation）。 */
const LOCK_FILE_NAMES = [
	"package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb",
	"Cargo.lock", "go.sum", "poetry.lock", "composer.lock", "Gemfile.lock",
] as const;

// ─────────────────────────────────────────────────────────────────────────────
// 清单建立（§7.1.2：已知基线 + 实际交付内容；不只检 HEAD）
// ─────────────────────────────────────────────────────────────────────────────

interface IndexEntry { mode: string; hash: string; rel: string }
interface StatusEntry { xy: string; rel: string; origRel?: string }

/** `git ls-files -s -z -- .`（cwd 内运行 → 只列 cwd 子树，路径相对 cwd）。 */
function gitIndexEntries(cwd: string): IndexEntry[] | undefined {
	let out: string;
	try { out = gitRaw(["ls-files", "-s", "-z", "--"], cwd); } catch { return undefined; }
	const entries: IndexEntry[] = [];
	for (const rec of out.split("\0")) {
		if (!rec) continue;
		const tab = rec.indexOf("\t");
		if (tab < 0) continue;
		const meta = rec.slice(0, tab).split(" ");
		if (meta.length < 2) continue;
		entries.push({ mode: meta[0], hash: meta[1], rel: rec.slice(tab + 1) });
	}
	return entries;
}

/** `git status --porcelain -z --untracked-files=all -- .`（cwd 内运行）。porcelain 路径相对**仓库根**
 *  （与 ls-files 相对 cwd 不同，实测 git 2.50）——按 cwdRelRepo 剥前缀归一到相对 cwd；
 *  子树外条目忽略（捕获范围 = cwd 子树）。rename 追加原路径记录。 */
function gitStatusEntries(cwd: string, cwdRelRepo: string | undefined): StatusEntry[] | undefined {
	let out: string;
	try { out = gitRaw(["status", "--porcelain", "-z", "--untracked-files=all", "--"], cwd); } catch { return undefined; }
	const prefix = cwdRelRepo ? cwdRelRepo.replace(/\/+$/, "") + "/" : "";
	const recs = out.split("\0");
	const entries: StatusEntry[] = [];
	for (let i = 0; i < recs.length; i++) {
		const rec = recs[i];
		if (rec.length < 4 || rec[2] !== " ") continue;
		const xy = rec.slice(0, 2);
		let rel = rec.slice(3);
		if (prefix) {
			if (!rel.startsWith(prefix)) continue; // cwd 子树外（含根级未跟踪）——不在捕获范围
			rel = rel.slice(prefix.length);
			if (!rel) continue;
		}
		let origRel: string | undefined;
		if (rec[0] === "R" || rec[0] === "C") {
			const orig = recs[++i];
			if (!prefix || (orig.startsWith(prefix) && orig.slice(prefix.length))) origRel = prefix ? orig.slice(prefix.length) : orig;
		}
		entries.push({ xy, rel, origRel });
	}
	return entries;
}

function sha256File(p: string): string {
	return createHash("sha256").update(fs.readFileSync(p)).digest("hex");
}

/** status XY → 条目状态（跟踪文件；untracked 单独由 ?? 判定）。 */
function statusOfIndexEntry(xy: string | undefined): ManifestEntryStatus {
	if (!xy || xy === "  ") return "clean";
	if (xy[0] === "A") return "added";
	if (xy[0] === "R") return "renamed";
	if (xy[1] === "T" || xy[0] === "T") return "typechange";
	return "modified";
}

/** 非 git 源的纯目录遍历（全 untracked；跳过 .git/外部依赖/凭据；越界 symlink 排除）。 */
function walkPlainDir(
	sourceCwd: string,
	entries: ObjectManifestEntry[],
	excluded: ExcludedInput[],
): void {
	const walk = (relDir: string): void => {
		const absDir = relDir ? path.join(sourceCwd, relDir) : sourceCwd;
		let ents: fs.Dirent[];
		try { ents = fs.readdirSync(absDir, { withFileTypes: true }); } catch { return; }
		for (const ent of ents.sort((a, b) => a.name.localeCompare(b.name))) {
			const rel = relDir ? `${relDir}/${ent.name}` : ent.name;
			const abs = path.join(sourceCwd, rel);
			if (ent.isDirectory()) {
				if (ent.name === ".git") continue;
				if (isExternalDependencyDir(ent.name)) { excluded.push({ path: rel, reason: "external-dependency", detail: "外部依赖目录未随快照捕获", required: true }); continue; }
				walk(rel);
				continue;
			}
			if (ent.isSymbolicLink()) {
				let target: string | undefined;
				try { target = fs.realpathSync(abs); } catch { /* 断链 */ }
				const inside = target !== undefined && (target === sourceCwd || target.startsWith(sourceCwd + path.sep));
				if (!inside) { excluded.push({ path: rel, reason: "symlink-escape", detail: target ? `指向捕获范围外: ${target}` : "断链 symlink", required: true }); continue; }
			}
			if (!ent.isFile()) continue;
			if (isCredentialPath(rel)) { excluded.push({ path: rel, reason: "credential", required: true }); continue; }
			const st = fs.lstatSync(abs);
			entries.push({ path: rel, kind: "untracked", status: "untracked", digest: sha256File(abs), bytes: st.size, executable: (st.mode & 0o111) !== 0, copied: false });
		}
	};
	walk("");
}

interface ManifestBuild {
	manifest: VerificationManifest;
	/** 可变引用（与 manifest.excluded 同数组）：复制阶段补充 copy-error 条目用。 */
	excluded: ExcludedInput[];
}

function buildManifest(sourceCwd: string, slot: { repoRoot?: string; cwdRelRepo?: string; headCommit?: string }): ManifestBuild {
	const entries: ObjectManifestEntry[] = [];
	const excluded: ExcludedInput[] = [];
	const deletedPaths: string[] = [];
	const resolvedCwd = normalizeCwd(sourceCwd);

	const index = slot.repoRoot !== undefined ? gitIndexEntries(sourceCwd) : undefined;
	const status = slot.repoRoot !== undefined ? gitStatusEntries(sourceCwd, slot.cwdRelRepo) : undefined;
	const statusByRel = new Map<string, StatusEntry>();
	if (status) for (const s of status) statusByRel.set(s.rel, s);

	if (index) {
		for (const ix of index) {
			// 子模块条目（mode 160000）：进清单但不复制内容（子模块有自己的基线；如实记录 limitation）
			if (ix.mode === "160000") {
				entries.push({ path: ix.rel, kind: "tracked", status: "submodule", digest: ix.hash, bytes: 0, executable: false, indexMode: ix.mode, copied: false });
				excluded.push({ path: ix.rel, reason: "submodule", detail: `子模块内容未随快照捕获（commit ${ix.hash.slice(0, 12)}）`, required: true });
				continue;
			}
			const abs = path.join(sourceCwd, ix.rel);
			let st: fs.Stats | undefined;
			try { st = fs.lstatSync(abs); } catch { /* 工作树缺失 = 删除项 */ }
			if (!st) {
				entries.push({ path: ix.rel, kind: "tracked", status: "deleted", digest: null, bytes: 0, executable: false, indexMode: ix.mode, copied: false });
				deletedPaths.push(ix.rel);
				continue;
			}
			// symlink（跟踪的 120000 或工作区改动产生的链接）：越界不跟随（§7.1.5）
			if (st.isSymbolicLink()) {
				let target: string | undefined;
				try { target = fs.realpathSync(abs); } catch { /* 断链 */ }
				const inside = target !== undefined && (target === resolvedCwd || target.startsWith(resolvedCwd + path.sep));
				if (!inside) {
					excluded.push({ path: ix.rel, reason: "symlink-escape", detail: target ? `指向捕获范围外: ${target}` : "断链 symlink", required: true });
					continue;
				}
			} else if (!st.isFile()) {
				excluded.push({ path: ix.rel, reason: "copy-error", detail: "非普通文件（fifo/socket 等）", required: true });
				continue;
			}
			if (isCredentialPath(ix.rel)) { excluded.push({ path: ix.rel, reason: "credential", required: true }); continue; }
			const executable = (st.mode & 0o111) !== 0;
			const executableChanged = (ix.mode === "100755") !== executable;
			const stat = statusByRel.get(ix.rel);
			const entryStatus: ManifestEntryStatus = executableChanged
				? "mode-change"
				: stat ? statusOfIndexEntry(stat.xy) : "clean";
			entries.push({
				path: ix.rel, kind: "tracked", status: entryStatus,
				digest: sha256File(abs), bytes: st.size,
				executable, indexMode: ix.mode, executableChanged, copied: false,
			});
		}
		// rename 原路径（仓库根相对 → 同样剥前缀；工作树已无 → 删除项；index 内已判的除外）
		if (status) for (const s of status) {
			if (!s.origRel || deletedPaths.includes(s.origRel)) continue;
			if (!fs.existsSync(path.join(sourceCwd, s.origRel))) deletedPaths.push(s.origRel);
		}
		// 未跟踪（?? 条目；含展开目录内文件）
		for (const s of statusByRel.values()) {
			if (s.xy !== "??") continue;
			const abs = path.join(sourceCwd, s.rel);
			let st: fs.Stats;
			try { st = fs.lstatSync(abs); } catch { continue; }
			if (st.isSymbolicLink()) {
				let target: string | undefined;
				try { target = fs.realpathSync(abs); } catch { /* 断链 */ }
				const inside = target !== undefined && (target === resolvedCwd || target.startsWith(resolvedCwd + path.sep));
				if (!inside) { excluded.push({ path: s.rel, reason: "symlink-escape", detail: target ? `指向捕获范围外: ${target}` : "断链 symlink", required: true }); continue; }
			} else if (!st.isFile()) continue;
			if (isCredentialPath(s.rel)) { excluded.push({ path: s.rel, reason: "credential", required: true }); continue; }
			entries.push({ path: s.rel, kind: "untracked", status: "untracked", digest: sha256File(abs), bytes: st.size, executable: (st.mode & 0o111) !== 0, copied: false });
		}
	} else {
		// 非 git 源：纯目录捕获（no-git-baseline limitation 由 limitationsOf 记录）
		walkPlainDir(resolvedCwd, entries, excluded);
	}

	// 依赖锁文件（sourceCwd 首层）：dependencies-not-captured 判定依据
	const lockFiles = LOCK_FILE_NAMES.filter((n) => fs.existsSync(path.join(sourceCwd, n)));

	const manifest: VerificationManifest = {
		sourceCwd: resolvedCwd,
		repoRoot: slot.repoRoot,
		cwdRelRepo: slot.cwdRelRepo,
		headCommit: slot.headCommit,
		entries,
		deletedPaths,
		lockFiles,
		excluded,
	};
	return { manifest, excluded };
}

// ─────────────────────────────────────────────────────────────────────────────
// limitations 语义（§7.1.4/§7.1.5/§7.1.7：被排除的必要输入 → 相关检查 unavailable（V2 接））
// ─────────────────────────────────────────────────────────────────────────────

const EXCLUSION_LIMITATION_KEY: Record<ExcludedInput["reason"], string> = {
	credential: "credential-excluded",
	"external-dependency": "external-dependency",
	"symlink-escape": "symlink-escape",
	"copy-error": "copy-error",
	submodule: "submodule-not-captured",
};

function limitationsOf(manifest: VerificationManifest, mode: VerificationMode, extra: readonly string[], deps?: DependencyCaptureSummary): string[] {
	const out: string[] = [];
	for (const ex of manifest.excluded) {
		out.push(`${EXCLUSION_LIMITATION_KEY[ex.reason]}:${ex.path}${ex.detail ? `（${ex.detail}）` : ""}——必要输入被排除，相关检查将 unavailable`);
	}
	if (manifest.lockFiles.length) {
		// C2-a（方案 §2.8）：copy-local 完整校验通过 → 依赖已随对象冻结（不再记未捕获缺口；
		// 锁文件仍入清单——它是事实之一，不是代用判断）；失败/none 保持旧 limitation 口径。
		if (deps?.ok) {
			out.push(`dependencies-frozen:${manifest.lockFiles.join(",")}（copy-local 私有副本 ${deps.files} 文件/${deps.symlinks} 链接，digest ${deps.digest.slice(0, 12)}…）——依赖随验证对象冻结，可复核`);
		} else if (deps && !deps.ok) {
			out.push(`dependencies-capture-failed:${deps.code}（${deps.reason}）——copy-local 捕获未完成，相关检查将 unavailable`);
		} else {
			// ev-20261017-ece384 续：go.sum 的依赖缺口有只读离线路径（本机 GOMODCACHE 预检完备即执行
			// ——判定在 evidence.ts ②，此处仅披露口径；其余锁文件/npm 类仍须 copy-local 或授权安装）。
			out.push(`dependencies-not-captured:${manifest.lockFiles.join(",")}——快照不含依赖安装产物；依赖安装须策略明确且已有授权（§7.1.4）${manifest.lockFiles.includes("go.sum") ? "；go.sum（Go）：可经本机 GOMODCACHE 只读离线预检路径执行（ev-20261017-ece384 续，evidence.ts 判定）" : ""}`);
		}
	}
	if (!manifest.repoRoot) {
		out.push("no-git-baseline:源目录不在 git 仓库内（无删除项/执行位基线/HEAD 锚点语义）");
	}
	if (mode === "shared-tree") {
		out.push("shared-tree-unisolated:检查直接运行于共享树（未隔离）——须记录验证前后对象指纹（§7.1.7）");
	}
	out.push(...extra);
	return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// 复制 + 复制前后 hash 核对（§7.1.3：变化 → object-changed，不继续验证）
// ─────────────────────────────────────────────────────────────────────────────

/** snapshot 模式：复制内容镜像到捕获根；复制后对源与副本双重核对清单 digest。
 *  返回变化/失败路径（空 = 一致）。复制失败条目不静默缺失 → 计入 changed（copy 失败即无法证明内容冻结）。 */
function copyAndVerify(
	sourceCwd: string,
	captureRoot: string,
	manifest: VerificationManifest,
	excluded: ExcludedInput[],
): string[] {
	const changed: string[] = [];
	for (const entry of manifest.entries) {
		if (entry.status === "deleted" || entry.status === "submodule" || entry.digest === null) continue;
		const src = path.join(sourceCwd, entry.path);
		const dst = path.join(captureRoot, entry.path);
		try {
			fs.mkdirSync(path.dirname(dst), { recursive: true });
			const st = fs.lstatSync(src);
			fs.copyFileSync(src, dst);
			fs.chmodSync(dst, st.mode & 0o7777);
			// 复制后核对：源重读（捕获期间被改？）+ 副本重读（复制完整性）——与清单 digest（复制前源内容）对照
			if (sha256File(src) !== entry.digest) changed.push(entry.path);
			else if (sha256File(dst) !== entry.digest) changed.push(entry.path);
			else entry.copied = true;
		} catch (e: any) {
			changed.push(entry.path);
			excluded.push({ path: entry.path, reason: "copy-error", detail: String(e?.message || e).slice(0, 120), required: true });
		}
	}
	return changed;
}

/**
 * 源与清单对照（V2 检查前/后指纹复核入口，§7.1.6/§7.1.7）：返回与清单 digest 不一致的相对路径。
 * snapshot 对象在检查后对快照副本核对（快照不再动）；shared-tree 对象对源树前后各核一次。
 */
export function compareSourceToManifest(manifest: VerificationManifest, sourceCwd?: string): { changed: string[]; missing: string[] } {
	const root = sourceCwd ?? manifest.sourceCwd;
	const changed: string[] = [];
	const missing: string[] = [];
	for (const entry of manifest.entries) {
		if (entry.digest === null) continue;
		try {
			if (sha256File(path.join(root, entry.path)) !== entry.digest) changed.push(entry.path);
		} catch {
			missing.push(entry.path);
		}
	}
	return { changed, missing };
}

// ─────────────────────────────────────────────────────────────────────────────
// 捕获入口（§7.1 全流程：开槽 → 清单 → （snapshot）复制+核对 → manifest 落盘 → 对象）
// ─────────────────────────────────────────────────────────────────────────────

const MANIFEST_FILE = "manifest.json";

/**
 * 捕获验证对象。
 * - snapshot 模式：内容镜像到专用临时目录（捕获根），复制前后源/副本 hash 双核对；检查将运行于快照副本（object.cwd = captureRoot）。
 * - shared-tree 模式：不复制内容（检查直接运行于共享树），object.cwd = sourceCwd；manifest 仍落盘捕获根并记录未隔离 limitation。
 * - 失败语义（fail-closed）：mode-unavailable / object-changed / capture-error 均不产出对象——V2 不得在无对象上跑检查。
 */
export function captureVerificationObject(sourceCwd: string, opts: CaptureOptions = {}): CaptureOutcome {
	const policy = opts.policy ?? { objectMode: "snapshot" as const, allowSharedFallback: false };
	const decision = resolveObjectMode(policy, { snapshotEnabled: opts.snapshotEnabled });
	if (!decision.ok) {
		return { ok: false, code: "mode-unavailable", message: decision.message ?? "验证对象模式不可建立" };
	}
	const mode = decision.mode;

	// 开捕获槽（mkdtemp 专用目录 + git 基线 + worktree 归属保护探测）
	const slot = captureSnapshot(sourceCwd, { tmpDir: opts.tmpDir });
	if (!slot.ok || !slot.captureRoot) {
		return { ok: false, code: "capture-error", message: slot.message ?? "捕获槽不可用" };
	}
	const captureRoot = slot.captureRoot;

	// 清单：已知基线 + 实际交付内容（未提交/未跟踪/删除/执行位/嵌套 cwd 全量）
	const built = buildManifest(sourceCwd, slot);

	// 测试/上层钩子（清单后、复制前——捕获中途 mutate 夹具点）
	opts.afterManifest?.();

	const extraLimitations: string[] = [];
	if (slot.activeWriter) {
		extraLimitations.push(`active-writer:${slot.activeWriter.leaseId}${slot.activeWriter.taskId ? `（任务 ${slot.activeWriter.taskId}）` : ""}——捕获时源 worktree 存在活跃租约，内容可能仍在被写；复制前后 hash 核对兜底撕裂`);
	}

	if (mode === "snapshot") {
		const changed = copyAndVerify(sourceCwd, captureRoot, built.manifest, built.excluded);
		if (changed.length) {
			releaseCaptureDir(captureRoot);
			return {
				ok: false,
				code: "object-changed",
				message: `捕获期间源内容发生变化（或复制失败），验证对象不成立、不继续验证: ${changed.slice(0, 10).join(", ")}${changed.length > 10 ? " …" : ""}`,
				changedPaths: changed,
			};
		}
	}

	// manifest.json 落盘（canonical JSON——稳定序列化，供对象指纹与跨机复核）
	const manifestJson = canonicalJson(built.manifest);
	const manifestAbs = path.join(captureRoot, MANIFEST_FILE);
	try {
		fs.writeFileSync(manifestAbs, manifestJson, "utf8");
	} catch (e: any) {
		releaseCaptureDir(captureRoot);
		return { ok: false, code: "capture-error", message: `manifest 落盘失败: ${String(e?.message || e).slice(0, 160)}` };
	}
	const manifestRef: Ref = {
		path: manifestAbs,
		digest: createHash("sha256").update(manifestJson, "utf8").digest("hex"),
		bytes: Buffer.byteLength(manifestJson, "utf8"),
	};

	// C2-a（方案 §2.8）：copy-local 依赖捕获——root + 声明 workspace 子包 node_modules 私有
	// 副本（pnpm .pnpm 与内部链接保持对象内；跨授权根链接/缺文件/超限如实失败，不降格）。
	// 失败不阻断对象产出（源码镜像与 manifest 已成立）——依赖型检查由消费侧 unavailable；
	// 成功时 digest 纳入 environmentDigest（依赖漂移 → objectId 变化 → 复用拒绝）。
	let dependencyCapture: DependencyCaptureSummary | undefined;
	let dependencyManifest: DependencyManifest | undefined;
	if (mode === "snapshot" && policy.dependencyMode === "copy-local") {
		// ev-20261019-9321ad：别名检查只作用于对象清单在场的路径（git ignore 的别名不进对象、
		// 不进依赖捕获，不再阻断捕获/自动基线）；清单缺席路径的别名由 participatingPaths 语义跳过。
		const deps = captureLocalDependencies(sourceCwd, captureRoot, {
			...(opts.executionPlan ? { executionPlan: opts.executionPlan } : {}),
			participatingPaths: new Set(built.manifest.entries.map((e) => e.path)),
			...(opts.dependencyLimits ? { limits: opts.dependencyLimits } : {}),
			...(opts.onDependencyProgress ? { onProgress: opts.onDependencyProgress } : {}),
			...(opts.afterDependencyManifest ? { afterManifest: opts.afterDependencyManifest } : {}),
		});
		if (deps.ok) {
			dependencyCapture = {
				mode: "copy-local", ok: true, digest: deps.digest, manifestRef: deps.manifestRef,
				roots: deps.stats.roots, files: deps.stats.files, symlinks: deps.stats.symlinks,
				bytes: deps.stats.bytes, durationMs: deps.stats.durationMs,
			};
			dependencyManifest = deps.manifest;
			extraLimitations.push(`dependency-capture:${deps.stats.roots} 根依赖树 ${deps.stats.files} 文件/${deps.stats.symlinks} 链接/${(deps.stats.bytes / 1024 / 1024).toFixed(1)}MiB/${deps.stats.durationMs}ms（copy-local；上限 1GiB/100k/120s）`);
		} else {
			dependencyCapture = {
				mode: "copy-local", ok: false, code: deps.code, reason: deps.reason,
				partialEntries: deps.partialEntries, partialBytes: deps.partialBytes,
			};
			extraLimitations.push(`dependency-capture-failed:${deps.code}（${deps.reason}）——依赖对象捕获未完成（部分 ${deps.partialEntries} 条/${deps.partialBytes}B）`);
		}
	}

	// environmentDigest + 对象 id（内容寻址：清单 + 环境 → 同内容同环境两次捕获同 id，可复用面）
	const environment = gatherEnvironmentFacts(sourceCwd, slot);
	if (dependencyCapture?.ok) {
		// 依赖清单摘要进 environmentDigest（稳定无时间戳）：依赖内容变化 → digest/objectId 变化。
		if (dependencyManifest) {
			environment.dependencies = { digest: dependencyCapture.digest, entries: dependencyManifest.entries.length, bytes: dependencyCapture.bytes };
		}
	}
	const environmentDigest = digestEnvironment(environment);
	const objectId = `vo-${createHash("sha256").update(manifestJson + "\n" + environmentDigest).digest("hex").slice(0, 16)}`;

	const limitations = limitationsOf(built.manifest, mode, extraLimitations, dependencyCapture);
	const object: VerificationObject = {
		id: objectId,
		manifest: manifestRef,
		mode,
		cwd: mode === "snapshot" ? captureRoot : built.manifest.sourceCwd,
		sourceCwd: built.manifest.sourceCwd,
		capturedAt: Date.now(),
		environmentDigest,
		limitations,
	};

	// K1 校验器自检（不变量：产出对象必须能被消费端校验通过；失败属实现 bug，fail-closed 报 capture-error）
	const check = validateVerificationObject(object);
	if (!check.ok) {
		releaseCaptureDir(captureRoot);
		return { ok: false, code: "capture-error", message: `产出对象未过契约校验（实现 bug）: ${check.error.message}` };
	}

	return { ok: true, object, manifest: built.manifest, manifestRef, captureRoot, mode, fallback: decision.fallback, environment, ...(dependencyCapture ? { dependencyCapture } : {}), ...(dependencyManifest ? { dependencyManifest } : {}) };
}

// ─────────────────────────────────────────────────────────────────────────────
// C2-a：检查后对象完整性复核（源码区 + 依赖区 + 清单外新路径——写后事实单口径）
// ─────────────────────────────────────────────────────────────────────────────

/** 对象内保留文件/目录（非被验证内容：源清单、依赖清单、检查日志目录）。 */
const RESERVED_OBJECT_PATHS = new Set(["manifest.json", "dependency-manifest.json", "checks"]);

/** 检查结束后复核整个冻结对象（snapshot 副本专用；§7.1.6 + C2 方案 §2.8）：
 *  ① 源码区：清单条目字节对照（compareSourceToManifest 同口径）；
 *  ② 依赖区：字节/执行位/链接文本对照（verifyDependencyManifest）；
 *  ③ 清单外新路径：对象内出现未登记 file/symlink（测试写产物、runner 缓存写入 node_modules/.vite
 *     等）→ unexpected——不全局忽略任何目录换绿，如实 object-changed。 */
// ── ev-20260930-91f621：良性 runner 产物形态白名单（检查后复核的误报收敛） ──
// 根因：C2 口径「检查期间写入的测试产物/runner 缓存全部入 unexpected，不全局忽略任何目录换绿」
// ——良性 runner 副产物（缓存/coverage/增量状态文件）与危险换绿（新增测试/源文件）同为 unexpected，
// exit 0 全绿的检查被误判 object-changed ✗，每次 accept 都需 Leader 手动 waive（R4a 实战：
// exitCode=0、fail 0 仍 ✗）。收敛：按**文件形态白名单**分流——这些形态不可能构成测试集声明或
// 被测源（非可执行源码/非测试文件），属可再生 runner 状态；**不是目录级全局忽略**：逐文件分流、
// 逐文件透出（benignArtifacts 清单进 notes/日志），源码区 changed/missing 与其余 unexpected
// （新增 .ts/.mjs 等）仍保持 object-changed ✗（§7.1.6 换绿防线不动）。
const BENIGN_ARTIFACT_RULES: ReadonlyArray<{ re: RegExp; label: string }> = [
	{ re: /^node_modules\x2F\.cache\x2F/, label: "runner 缓存（node_modules/.cache）" },
	{ re: /^\.vitest\x2F/, label: "vitest 缓存（.vitest）" },
	{ re: /^(coverage|\.nyc_output)\x2F/, label: "coverage 产物" },
	{ re: /\.tsbuildinfo$/, label: "tsc 增量状态（*.tsbuildinfo）" },
	{ re: /\.eslintcache$/, label: "eslint 缓存（.eslintcache）" },
	{ re: /^(\.turbo|\.parcel-cache)\x2F/, label: "build 缓存" },
];

/** 良性产物判定：命中白名单形态返回形态标签，否则 null（保持 unexpected 严格口径）。 */
export function benignArtifactLabelOf(rel: string): string | null {
	const norm = rel.split(path.sep).join("/");
	for (const rule of BENIGN_ARTIFACT_RULES) if (rule.re.test(norm)) return rule.label;
	return null;
}

/** unexpected 分流：良性产物（带形态标签）与剩余严格项。纯函数。 */
export function splitBenignArtifacts(unexpected: readonly string[]): { unexpected: string[]; benignArtifacts: Array<{ path: string; label: string }> } {
	const rest: string[] = [];
	const benign: Array<{ path: string; label: string }> = [];
	for (const p of unexpected) {
		const label = benignArtifactLabelOf(p);
		if (label !== null) benign.push({ path: p, label });
		else rest.push(p);
	}
	return { unexpected: rest, benignArtifacts: benign };
}

export function verifyCapturedObject(
	captureRoot: string,
	manifest: VerificationManifest,
	dependencyManifest?: DependencyManifest | null,
): { changed: string[]; missing: string[]; unexpected: string[]; benignArtifacts: Array<{ path: string; label: string }>; runnerOutputs: Array<{ path: string; label: string }> } {
	const root = path.resolve(captureRoot);
	const src = compareSourceToManifest(manifest, root);
	const depRoots = new Set((dependencyManifest?.roots ?? []).map((r) => r.split("/").join(path.sep)));
	let depChanged: string[] = [];
	let depMissing: string[] = [];
	let depUnexpected: string[] = [];
	let runnerOutputs: Array<{ path: string; label: string }> = [];
	if (dependencyManifest) {
		const dep = verifyDependencyManifest(root, dependencyManifest);
		depChanged = dep.changed;
		depMissing = dep.missing;
		depUnexpected = dep.unexpected;
		runnerOutputs = dep.runnerOutputs;
	}
	// 源码区新路径扫描（依赖树内的新路径已由 depUnexpected 覆盖，跳过避免重复）
	const manifestPaths = new Set(manifest.entries.map((e) => e.path));
	const unexpected: string[] = [];
	const walk = (relDir: string): void => {
		const absDir = relDir ? path.join(root, relDir) : root;
		let ents: fs.Dirent[];
		try { ents = fs.readdirSync(absDir, { withFileTypes: true }); } catch { return; }
		for (const ent of ents) {
			const rel = relDir ? `${relDir}/${ent.name}` : ent.name;
			if (relDir === "" && RESERVED_OBJECT_PATHS.has(ent.name)) continue;
			if (ent.isDirectory()) {
				// 依赖树根（node_modules 等）整树跳过——其内部新路径由 depUnexpected 口径覆盖
				if (depRoots.has(rel)) continue;
				walk(rel);
				continue;
			}
			if (depRoots.has(relDir.split("/")[0] ?? "")) continue; // 依赖树内 file（树根被跳过时不会到达；防御）
			if (!manifestPaths.has(rel)) unexpected.push(rel);
		}
	};
	walk("");
	// ev-20260930-91f621（diting F-01 修正）：unexpected 保持全量（良性产物不豁免 ✗——目录前缀
	// 无法证明文件不可被 runner 加载换绿，如 coverage/ 下生成 .cjs 再 require）；benignArtifacts 仅作
	// 信息性分类（evidence 侧分组展示供 Leader 据实裁决），不改变判定。
	const benign = unexpected
		.map((p) => { const label = benignArtifactLabelOf(p); return label !== null ? { path: p, label } : undefined; })
		.filter((x): x is { path: string; label: string } => x !== undefined);
	return {
		changed: [...src.changed, ...depChanged],
		missing: [...src.missing, ...depMissing],
		unexpected: [...unexpected, ...depUnexpected],
		benignArtifacts: benign,
		runnerOutputs,
	};
}
