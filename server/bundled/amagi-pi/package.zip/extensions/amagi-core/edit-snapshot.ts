/** Session-local, bounded references to bytes actually shown by a tool. No semantic matching. */
import { createHash, randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { EditFailure, type EditFailureCode } from "./edit-recovery.ts";

export interface EditSelection { snapshotId: string; startLine: number; endLine: number }
export interface EditSnapshotScope { sessionId: string; cwd: string; authorization?: object }
export interface EditSnapshot {
	id: string;
	canonicalPath: string;
	scope: EditSnapshotScope;
	bytes: Buffer;
	digest: string;
	startLine: number;
	endLine: number;
	createdAt: number;
}
export interface SnapshotText { body: string; bom: string; ending: "\n" | "\r\n"; lines: string[] }

export function snapshotScope(cwd: string, ctx?: unknown, authorization?: object): EditSnapshotScope {
	const manager = (ctx as { sessionManager?: { getSessionId?(): string } } | undefined)?.sessionManager;
	return { sessionId: manager?.getSessionId?.() ?? "local", cwd: path.resolve(cwd), authorization };
}

export function snapshotText(bytes: Buffer): SnapshotText {
	let text: string;
	try { text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes); }
	catch { /* lint-exempt:解码失败转换为明确拒绝，不签发范围引用 */ throw new EditFailure("unsupported-content", "范围引用仅支持有效 UTF-8 文本；请使用原有编辑方式。"); }
	if (text.includes("\0") || /\r(?!\n)/.test(text) || (/\r\n/.test(text) && /(?<!\r)\n/.test(text))) {
		throw new EditFailure("unsupported-content", "范围引用不支持二进制、裸 CR 或混合行尾；未转换文件。");
	}
	const bom = text.startsWith("\uFEFF") ? "\uFEFF" : "";
	const body = text.slice(bom.length);
	const ending = body.includes("\r\n") ? "\r\n" : "\n";
	const lines = body.match(/[^\n]*\n|[^\n]+/g) ?? [];
	return { body, bom, ending, lines };
}

export function normalizeSelectionOptions(input: Record<string, unknown>): void {
	for (const key of ["selection", "newText"]) if (input[key] === null) delete input[key];
	if (input.selection !== undefined) for (const key of ["edits", "patch", "files"]) if (input[key] === null) delete input[key];
}

export function validateSelectionInput(input: Record<string, unknown>): EditSelection {
	const selection = input.selection as Partial<EditSelection> | undefined;
	if (typeof input.path !== "string" || !input.path.trim() || typeof input.newText !== "string"
		|| ["edits", "patch", "files", "file_path", "regex"].some(key => input[key] !== undefined)
		|| !selection || typeof selection !== "object" || Array.isArray(selection)
		|| typeof selection.snapshotId !== "string" || !/^s_[a-f0-9-]{36}$/.test(selection.snapshotId)
		|| !Number.isSafeInteger(selection.startLine) || !Number.isSafeInteger(selection.endLine)
		|| selection.startLine! < 1 || selection.endLine! < selection.startLine!
		|| Object.keys(selection).some(key => !["snapshotId", "startLine", "endLine"].includes(key))) {
		throw new EditFailure("invalid-input", "仅支持 {path, selection:{snapshotId,startLine,endLine}, newText}；范围为已展示快照中的一基整行，不能混用其他编辑分面。");
	}
	return selection as EditSelection;
}

export function snapshotNotice(snapshot: EditSnapshot): string {
	return `[edit snapshot: ${snapshot.id}; covered lines: ${snapshot.startLine}-${snapshot.endLine}; version: ${snapshot.digest.slice(0, 12)}; complete: true] 使用 edit({path, selection:{snapshotId:"${snapshot.id}",startLine:${snapshot.startLine},endLine:${snapshot.endLine}},newText:...}) 替换已展示的整行，无需重写 oldText。`;
}

export class EditSnapshotStore {
	private readonly snapshots = new Map<string, EditSnapshot>();
	private readonly failures = new Map<EditFailureCode, number>();
	private issued = 0;
	private readonly options: { now?: () => number; maxBytes?: number; maxCount?: number; ttlMs?: number };
	constructor(options: { now?: () => number; maxBytes?: number; maxCount?: number; ttlMs?: number } = {}) { this.options = options; }
	private now(): number { return this.options.now?.() ?? Date.now(); }
	clear(): void { this.snapshots.clear(); this.failures.clear(); this.issued = 0; }
	recordFailure(code: EditFailureCode): void { this.failures.set(code, (this.failures.get(code) ?? 0) + 1); }
	statistics(): { issued: number; cached: number; failures: Record<string, number> } {
		return { issued: this.issued, cached: this.snapshots.size, failures: Object.fromEntries(this.failures) };
	}
	issue(file: string, bytes: Buffer, scope: EditSnapshotScope, startLine: number, endLine: number): EditSnapshot {
		const parsed = snapshotText(bytes);
		if (!Number.isSafeInteger(startLine) || !Number.isSafeInteger(endLine) || startLine < 1 || endLine < startLine || endLine > parsed.lines.length) {
			throw new EditFailure("unobserved-range", "只能签发完整展示的真实行范围；空文件请使用 write。");
		}
		const maxBytes = this.options.maxBytes ?? 8 * 1024 * 1024;
		if (bytes.length > maxBytes) throw new EditFailure("unsupported-content", "完整文件超过快照缓存上限；原有 edits/patch 仍可用。");
		for (const [id, item] of this.snapshots) if (this.now() - item.createdAt >= (this.options.ttlMs ?? 600_000)) this.snapshots.delete(id);
		let size = [...this.snapshots.values()].reduce((sum, item) => sum + item.bytes.length, 0);
		while (this.snapshots.size && (this.snapshots.size >= (this.options.maxCount ?? 8) || size + bytes.length > maxBytes)) {
			const first = this.snapshots.values().next().value!;
			size -= first.bytes.length; this.snapshots.delete(first.id);
		}
		const snapshot: EditSnapshot = { id: `s_${randomUUID()}`, canonicalPath: fs.realpathSync.native(file), scope: { ...scope },
			bytes: Buffer.from(bytes), digest: createHash("sha256").update(bytes).digest("hex"), startLine, endLine, createdAt: this.now() };
		this.snapshots.set(snapshot.id, snapshot); this.issued++;
		return snapshot;
	}
	resolve(file: string, selection: EditSelection, scope: EditSnapshotScope): EditSnapshot {
		const snapshot = this.snapshots.get(selection.snapshotId);
		if (!snapshot || this.now() - snapshot.createdAt >= (this.options.ttlMs ?? 600_000)) {
			this.snapshots.delete(selection.snapshotId);
			throw new EditFailure("snapshot-expired", "范围引用已过期或不可用；请用 read({path,offset,limit,editReference:true}) 重新读取。");
		}
		if (snapshot.scope.sessionId !== scope.sessionId || snapshot.scope.cwd !== scope.cwd || snapshot.scope.authorization !== scope.authorization) {
			throw new EditFailure("scope-mismatch", "引用属于其他会话、工作目录或授权上下文；请重新读取。");
		}
		if (fs.realpathSync.native(file) !== snapshot.canonicalPath) throw new EditFailure("path-mismatch", "引用与实际目标路径不符；未写入。");
		if (selection.startLine < snapshot.startLine || selection.endLine > snapshot.endLine) throw new EditFailure("unobserved-range", "选区超出了工具完整展示的范围；请定向读取后重试。");
		return snapshot;
	}
	verify(snapshot: EditSnapshot, file: string, bytes: Buffer, scope: EditSnapshotScope): void {
		this.resolve(file, { snapshotId: snapshot.id, startLine: snapshot.startLine, endLine: snapshot.endLine }, scope);
		if (!bytes.equals(snapshot.bytes)) throw new EditFailure("stale-snapshot", "文件在观察后发生变化（包含选区内部或其他位置）；请重新读取，不能沿用旧行号。");
	}
}

export function composeSelection(snapshot: EditSnapshot, selection: EditSelection, newText: string): { oldText: string; newText: string; expectedBytes: Buffer; selectedOldText: string } {
	const { body, bom, ending, lines } = snapshotText(snapshot.bytes);
	const replacement = newText.replace(/\r\n/g, "\n");
	if (/\r/.test(replacement) || replacement.includes("\0") || /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(replacement)) {
		throw new EditFailure("unsupported-content", "新内容包含不支持的裸 CR、NUL 或不完整 Unicode 字符。");
	}
	if (selection.endLine < lines.length && replacement && !replacement.endsWith("\n")) {
		throw new EditFailure("invalid-input", "非 EOF 整行替换的新内容必须以换行结尾；空串表示删除选区。");
	}
	const before = lines.slice(0, selection.startLine - 1).join("");
	const after = lines.slice(selection.endLine).join("");
	const result = before + replacement.replace(/\n/g, ending) + after;
	return { oldText: body, newText: result, expectedBytes: Buffer.from(bom + result), selectedOldText: lines.slice(selection.startLine - 1, selection.endLine).join("") };
}

export const defaultEditSnapshots = new EditSnapshotStore();

const editingRegistrations = new WeakMap<object, { read?: boolean; edit?: boolean; snapshots: EditSnapshotStore }>();
export function recordEditingRegistration(host: object, tool: "read" | "edit", snapshots: EditSnapshotStore): void {
	const registration = editingRegistrations.get(host) ?? { snapshots };
	registration[tool] = true; registration.snapshots = snapshots; editingRegistrations.set(host, registration);
}
export function editingCapabilityStatus(host: unknown): string {
	const state = host && typeof host === "object" ? editingRegistrations.get(host) : undefined;
	if (!state) return "编辑：增强工具注册未确认；不能据安装文件推定当前会话能力。";
	const stats = state.snapshots.statistics();
	return `编辑：edit ${state.edit ? "已注册（patch / selection）" : "未确认"}；read 范围引用 ${state.read ? "已注册" : "未确认"}；快照签发 ${stats.issued}、缓存 ${stats.cached}；原生失败 ${JSON.stringify(stats.failures)}。`;
}
