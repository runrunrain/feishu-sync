import { stripAdvisorEnv } from "./advisor-config.ts";
/** 工具命令的进程局部环境：保留宿主交互环境，MCP 专用凭据不进入模型 shell。 */
import { stripChildMcpEnv } from "./mcp-config.ts";
import { stripCompactionEnv } from "./compaction-config.ts";

export function nonInteractiveToolEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
	return {
		...env,
		GIT_EDITOR: env.GIT_EDITOR ?? "true",
		GIT_SEQUENCE_EDITOR: env.GIT_SEQUENCE_EDITOR ?? "true",
		EDITOR: env.EDITOR ?? "true",
		VISUAL: env.VISUAL ?? env.EDITOR ?? "true",
		GIT_PAGER: env.GIT_PAGER ?? "cat",
		PAGER: env.PAGER ?? "cat",
		GIT_TERMINAL_PROMPT: env.GIT_TERMINAL_PROMPT ?? "0",
		GCM_INTERACTIVE: env.GCM_INTERACTIVE ?? "never",
	};
}

/** B5B（ev-20261012-7517d8 批B §6.2/§9）：codemode 控制包与准入上下文剥离——普通 bash/后台进程
 *  不携带可复制的准入上下文（grant 原文 + digest + cwd 三件套可重建子进程授权面；账户 env 可直写
 *  持久账本目录——设计红线「普通 bash 不应拿到可复制的准入上下文」）。工具 spawn 剥离不影响：
 *  - 子进程 pi 自身的 file-permission（进程内读 process.env，不经工具 spawn 面）；
 *  - AMAGI_CODEMODE_DISABLE（kill 方向保留透传——=1 只收紧不放宽）；
 *  - C11 试点会话的 Leader 判定（trial env 在试点 pi 进程内消费，不在其 bash 子进程）。
 *  TRIAL 控制变量一并剥离：bash 内嵌 pi 重启不得凭继承变量自称隔离试点会话。 */
export function stripCodemodeControlEnv<T extends Record<string, string | undefined>>(env: T): T {
	const out = { ...env };
	delete out.AMAGI_PERMISSION_GRANT;
	delete out.AMAGI_PERMISSION_DIGEST;
	delete out.AMAGI_PERMISSION_CWD;
	delete out.AMAGI_CODEMODE_ACCOUNT;
	delete out.AMAGI_CODEMODE_TRIAL;
	delete out.AMAGI_CODEMODE_TRIAL_TOOLS;
	delete out.AMAGI_CODEMODE_TRIAL_MAX_SCRIPTS;
	delete out.AMAGI_CODEMODE_TRIAL_MAX_OUTPUT_TOKENS;
	delete out.AMAGI_CODEMODE_TRIAL_TIMEOUT_MS;
	return out;
}

export function toolProcessEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
	return nonInteractiveToolEnv(stripCodemodeControlEnv(stripAdvisorEnv(stripCompactionEnv(stripChildMcpEnv(env)))));
}
