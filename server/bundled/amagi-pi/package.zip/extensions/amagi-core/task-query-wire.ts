/**
 * task-query-wire.ts — O3a（机会方案 §4.2，pi-0.99.1 批）：task_query 结构化输出 wire。
 *
 * 本模块是**纯 schema/投影模块**：只定义四个封闭 wire 分支的 TypeBox schema（Type.Union 为
 * TaskQueryOutputSchema）与从调用方提供的查询页/已读归档/恢复说明到 wire 形状的 JSON-safe 投影。
 * 纪律（§4.1）：零 I/O（无 fs/进程/store 写）、零宿主私有依赖（仅 typebox + contracts 纯类型）、
 * 不接生产——task-facets/tool-result-adapter/index 均**不 import 本模块**（O3-connect 才接线）；
 * 脱敏（§4.5）调用点也在 O3-connect（双载体同源脱敏），本模块不读用户现场。
 * U5（pi-099 D 片，diting F3 实施）：凭据模式脱敏**函数**（redactCredentials/redactContractError）
 * 落位于本模块（纯字符串/纯投影变换，零 I/O——与「本模块不读用户现场」纪律相容）；调用点仍在
 * task-facets 接线层，只作用于 wire 自由文本载体（error.message/repairExamples 递归字符串值/
 * recoveryAdvice），正文 content 契约字节不变（正文载体脱敏需另立契约变更，显式登记不在 D 片）。
 *
 * wire 身份（§4.2，判据 = kind + wireVersion + view/ok + schemaVersion，与
 * surfaceVersion/viewVersion/receiptSeq 不混用）：kind="amagi.task-query"、wireVersion=1、
 * schemaVersion=1、surfaceVersion=2（固定字面量；surfaceVersion 沿当前工具面 2）。
 * 四 URN 分支：urn:amagi:task-query:summary:1 / :receipt:1 / :output:1 / error:1。
 * v1 冻结字段集合；增删字段或改语义先升 schemaVersion。
 *
 * 投影纪律：
 *  - 三轴/effects 用 string 是有意的投影选择（§4.2）：合法值由现有契约单源定义与验证
 *    （contracts/task.ts EXECUTION_STATES 等），本模块不另造枚举；映射不生成新状态，
 *    未知状态原字面透传（消费者解释不了时展示原字面并停止自动操作，不折叠为 done/accepted）。
 *  - cursor/id/digest 保留全字面——绝不用正文的 8 位 id/16 位 digest 短形作机器值。
 *  - page.nextCursor 缺省映射 null、page.truncated 缺省映射 false（沿当前正文布尔判断）；
 *    cursor 始终不透明不重新编码；legacy.total 为查询服务返回集合长度（非全磁盘历史总数）。
 *  - 三轴投影源不扩散 spec.assignment/scope/env/inputs 等（结构化白名单是第一道边界，§4.5）；
 *    checks 不输出 command/cwd/stdout/stderr，outputs 不输出文件正文。
 *  - usage：§4.2 规格块未列 usage 字段，wire 不携带、不夹带（O2 实证宿主 combineUsage 需完整
 *    Usage 形状——cost 四项 + cacheRead/cacheWrite；若未来加 usage 必须全形状，见报告决策节）。
 *
 * 归档 collection 缺口语径（§4.3，由调用方注入的已读归档推导，本模块不读盘）：
 *  - 未发布回执：receipt=null、archive=null；三轴按权威视图返回。
 *  - 有回执无 ref：archive.state="unreferenced"、ref=null，对应 collection.state="unreferenced"。
 *  - 归档读取失败（read=null）：archive.state="unreadable"、保留 ref；collection
 *    total=null/items=[]/truncated=false（表示未作列表裁剪，不表示没有检查/产物）。
 *  - 已读 object 中字段缺席 → collection.state="absent"（total=null）；字段存在但不是数组 →
 *    "invalid"（total=null）；可用数组（含空数组）才是 "available"/total=数组长度。
 *  - available 时 items 为前 N（N=8）个白名单投影、truncated=total>N；receipt.missing 不随截断。
 *  - 条目字段缺失或类型不合映射 null（消费者不得拿 null id/path 作决策）；exitCode 可负、
 *    需安全整数；bytes 非负安全整数。
 */
import { Type, type TSchema } from "typebox";
import type { ContractError, Ref, TaskViewLevel } from "./contracts/view.ts";
import type { ReceiptSummary, TaskPage, TaskView } from "./contracts/task.ts";

// ── wire 身份常量（§4.2 固定字面量；O3-connect 与测试共用） ──────────────────

export const TASK_QUERY_WIRE_KIND = "amagi.task-query";
export const TASK_QUERY_WIRE_VERSION = 1;
export const TASK_QUERY_SCHEMA_VERSION = 1;
/** 沿当前分面工具面版本（task-facets TASK_FACET_SURFACE_VERSION=2；wire 不另设工具面版本）。 */
export const TASK_QUERY_SURFACE_VERSION = 2;

/** 四分支 schema 标识（§4.2「三档各有独立 schema 标识」+ error 分支）。 */
export const TASK_QUERY_WIRE_URNS = {
	summary: "urn:amagi:task-query:summary:1",
	receipt: "urn:amagi:task-query:receipt:1",
	output: "urn:amagi:task-query:output:1",
	error: "urn:amagi:task-query:error:1",
} as const;

/** 数量边界（§4.2：items 每页 500、legacy.items 5、checks/outputs.items 8）。 */
export const TASK_QUERY_WIRE_LIMITS = {
	pageMaxItems: 500,
	legacyMaxItems: 5,
	collectionMaxItems: 8,
} as const;

// ── 共享子 schema（全部 additionalProperties:false + 全键 required；无 $id——分支根才有） ──

/** n：非负安全整数（§4.2：integer 上界 Number.MAX_SAFE_INTEGER、n 下界 0）。 */
const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });
/** exitCode：可负的安全整数（§4.2：integer 需安全整数，允许负值）。 */
const SignedSafeInt = Type.Integer({ minimum: -Number.MAX_SAFE_INTEGER, maximum: Number.MAX_SAFE_INTEGER });
const NullableString = Type.Union([Type.String(), Type.Null()]);
const NullableBoolean = Type.Union([Type.Boolean(), Type.Null()]);

/** Common 字面量组（kind/wireVersion/schemaVersion/surfaceVersion——版本判据的机器面）。 */
const WireCommonProperties = {
	kind: Type.Literal(TASK_QUERY_WIRE_KIND),
	wireVersion: Type.Literal(TASK_QUERY_WIRE_VERSION),
	schemaVersion: Type.Literal(TASK_QUERY_SCHEMA_VERSION),
	surfaceVersion: Type.Literal(TASK_QUERY_SURFACE_VERSION),
};

/** BaseItem（§4.2）：三轴投影的最小条目；execution/settlement/acceptance 用 string（投影选择，
 *  合法值由 contracts/task.ts 单源定义，本 schema 不枚举）。 */
const BaseItemProperties = {
	taskId: Type.String({ description: "任务 ID（全字面——非正文 8 位短形）" }),
	agent: Type.String({ description: "角色名（spec.agent 投影）" }),
	stateSeq: NonNegativeSafeInt,
	revision: Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER, description: "失效栅栏 revision" }),
	execution: Type.String({ description: "执行轴（合法值由契约单源定义；未知值原字面透传）" }),
	settlement: Type.String({ description: "结算轴（同上）" }),
	acceptance: Type.String({ description: "接受轴（同上）" }),
	degraded: Type.Array(Type.String(), { description: "内核结算降级事实标签" }),
	recoveryAdvice: Type.Union([Type.String(), Type.Null()], { description: "恢复指引（仅 execution=error 且 renderer 有产出时非 null）" }),
};

const LegacyItemSchema = Type.Object({
	taskId: Type.String(),
	agent: Type.String(),
	status: Type.String(),
}, { additionalProperties: false, description: "v1 遗留记录（无内核契约视图，无三轴）" });

const ReceiptMetaSchema = Type.Object({
	receiptId: Type.String({ description: "回执 ID（全字面）" }),
	receiptSeq: NonNegativeSafeInt,
	settlement: Type.String(),
	acceptance: Type.String(),
	missing: Type.Array(Type.String(), { description: "机器检查缺口 id 原字面完整保留（含旧 id:status 形态；decide 引用原字面，不剥后缀）" }),
}, { additionalProperties: false });

const ArchiveRefSchema = Type.Object({
	path: Type.String({ description: "回执归档路径（全字面）" }),
	bytes: NonNegativeSafeInt,
	digest: Type.String({ description: "SHA-256 hex（全字面——非正文 16 位短形）" }),
}, { additionalProperties: false });

const CheckItemSchema = Type.Object({
	id: NullableString,
	status: NullableString,
	required: NullableBoolean,
	exitCode: Type.Union([SignedSafeInt, Type.Null()], { description: "退出码（可负，安全整数；字段缺失/类型不合为 null）" }),
}, { additionalProperties: false, description: "归档机器检查白名单投影（不含 command/cwd/stdout/stderr）" });

const OutputItemSchema = Type.Object({
	path: NullableString,
	bytes: Type.Union([NonNegativeSafeInt, Type.Null()]),
	digest: NullableString,
	sourcePath: NullableString,
}, { additionalProperties: false, description: "产物引用白名单投影（不含文件正文）" });

/** Collection<T>（§4.2）：归档数组的三态缺口口径（available/absent/invalid/unreadable/unreferenced）。 */
const CollectionStateSchema = Type.Union([
	Type.Literal("available"), Type.Literal("absent"), Type.Literal("invalid"),
	Type.Literal("unreadable"), Type.Literal("unreferenced"),
]);

function collectionSchemaOf<T extends TSchema>(item: T, description: string) {
	return Type.Object({
		state: CollectionStateSchema,
		total: Type.Union([NonNegativeSafeInt, Type.Null()], { description: "原数组长度；null=未作列表统计（unreadable/invalid/absent/unreferenced）" }),
		items: Type.Array(item, { maxItems: TASK_QUERY_WIRE_LIMITS.collectionMaxItems, description: "前 8 个白名单投影" }),
		truncated: Type.Boolean({ description: "total>8（仅 available 有意义；其余恒 false）" }),
	}, { additionalProperties: false, description });
}

const ChecksCollectionSchema = collectionSchemaOf(CheckItemSchema, "机器检查集合（缺口口径见 §4.3）");
const OutputsCollectionSchema = collectionSchemaOf(OutputItemSchema, "产物引用集合（缺口口径见 §4.3）");

/** 归档读取态（§4.2）：read/unreadable/unreferenced。 */
const ArchiveStateSchema = Type.Union([Type.Literal("read"), Type.Literal("unreadable"), Type.Literal("unreferenced")]);

/** receipt 档归档块：checks + outputs 两个 collection。 */
const ReceiptArchiveSchema = Type.Object({
	state: ArchiveStateSchema,
	ref: Type.Union([ArchiveRefSchema, Type.Null()]),
	checks: ChecksCollectionSchema,
	outputs: OutputsCollectionSchema,
}, { additionalProperties: false });

/** output 档归档块：只有 outputs collection（无检查列表、无产物全文、无新路径扫描，§4.3）。 */
const OutputArchiveSchema = Type.Object({
	state: ArchiveStateSchema,
	ref: Type.Union([ArchiveRefSchema, Type.Null()]),
	outputs: OutputsCollectionSchema,
}, { additionalProperties: false });

/** Success<V,I> 的 data：page（nextCursor 缺省 null、truncated 缺省 false）+ legacy（total=返回集合长度、items 前 5）。 */
function successDataSchemaOf<T extends TSchema>(item: T) {
	return Type.Object({
		page: Type.Object({
			items: Type.Array(item, { maxItems: TASK_QUERY_WIRE_LIMITS.pageMaxItems, description: "当前页条目（服务面 limit ≤500；本映射不静默截断页条目）" }),
			snapshotSeq: NonNegativeSafeInt,
			nextCursor: NullableString,
			truncated: Type.Boolean(),
		}, { additionalProperties: false }),
		legacy: Type.Object({
			total: NonNegativeSafeInt,
			items: Type.Array(LegacyItemSchema, { maxItems: TASK_QUERY_WIRE_LIMITS.legacyMaxItems, description: "前 5 条（truncated 表示只展示前 5 条）" }),
			truncated: Type.Boolean(),
		}, { additionalProperties: false }),
	}, { additionalProperties: false });
}

// ── 四封闭分支（§4.2 规格块逐字段；$id=各 URN） ─────────────────────────────

/** summary 档：Success<"summary", SummaryItem>——只从页面 TaskView 显式取 BaseItem 字段。 */
export const TaskQuerySummaryWireSchema = Type.Object({
	...WireCommonProperties,
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	view: Type.Literal("summary"),
	data: successDataSchemaOf(Type.Object(BaseItemProperties, { additionalProperties: false })),
}, { $id: TASK_QUERY_WIRE_URNS.summary, additionalProperties: false, description: "task_query summary 档 wire（§4.2）" });

/** receipt 档：Success<"receipt", ReceiptItem>——BaseItem + ReceiptMeta + 归档（checks+outputs）。 */
export const TaskQueryReceiptWireSchema = Type.Object({
	...WireCommonProperties,
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	view: Type.Literal("receipt"),
	data: successDataSchemaOf(Type.Object({
		...BaseItemProperties,
		receipt: Type.Union([ReceiptMetaSchema, Type.Null()], { description: "null=未发布回执（settlement=pending）" }),
		archive: Type.Union([ReceiptArchiveSchema, Type.Null()], { description: "null=未发布回执；unreferenced=有回执无归档引用；unreadable=引用在但读取失败" }),
	}, { additionalProperties: false })),
}, { $id: TASK_QUERY_WIRE_URNS.receipt, additionalProperties: false, description: "task_query receipt 档 wire（§4.2）" });

/** output 档：Success<"output", OutputViewItem>——BaseItem + ReceiptMeta + 归档（仅 outputs）。 */
export const TaskQueryOutputViewWireSchema = Type.Object({
	...WireCommonProperties,
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	view: Type.Literal("output"),
	data: successDataSchemaOf(Type.Object({
		...BaseItemProperties,
		receipt: Type.Union([ReceiptMetaSchema, Type.Null()]),
		archive: Type.Union([OutputArchiveSchema, Type.Null()]),
	}, { additionalProperties: false })),
}, { $id: TASK_QUERY_WIRE_URNS.output, additionalProperties: false, description: "task_query output 档 wire（§4.2）" });

/**
 * error 分支：Failure（§4.2/§4.4）。repairExamples 是唯一允许动态属性的对象数组——
 * 值为递归 JSON Schema（$defs：null/boolean/finite number/string/array/object；不接受
 * any/undefined/NaN/类实例）。view 只取合法三档字面或 null（缺省 summary、显式非法值映射
 * null——由调用方按 §4.4 决定后传入，本映射不 echo 任意原参数）。
 */
export const TaskQueryErrorWireSchema = Type.Object({
	...WireCommonProperties,
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	view: Type.Union([Type.Literal("summary"), Type.Literal("receipt"), Type.Literal("output"), Type.Null()]),
	error: Type.Object({
		code: Type.String(),
		message: Type.String(),
		fields: Type.Array(Type.String()),
		effects: Type.String({ description: "none/started/unknown（合法值由 ContractError 单源定义；wire 不枚举）" }),
		repairExamples: Type.Array(
			{ $ref: "#/$defs/jsonObject" } as unknown as TSchema,
			{ description: "最小合法调用样例（JSON-safe 对象数组；动态属性递归 JSON Schema）" },
		),
	}, { additionalProperties: false }),
}, {
	$id: TASK_QUERY_WIRE_URNS.error,
	$defs: {
		jsonValue: {
			anyOf: [
				{ type: "null" },
				{ type: "boolean" },
				{ type: "number" },
				{ type: "string" },
				{ type: "array", items: { $ref: "#/$defs/jsonValue" } },
				{ type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
			],
		},
		jsonObject: { type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
	},
	additionalProperties: false,
	description: "task_query 工具内失败 wire（§4.2 Failure 分支）",
});

/** TaskQueryOutputSchema（§4.2）：四分支 Type.Union（error 分支含在内——宿主 outputSchema 文义
 *  仅要求成功结果，但注册面为统一校验器；消费者判据为 kind/wireVersion/view/ok/schemaVersion）。 */
export const TaskQueryOutputSchema = Type.Union(
	[TaskQuerySummaryWireSchema, TaskQueryReceiptWireSchema, TaskQueryOutputViewWireSchema, TaskQueryErrorWireSchema],
	{ description: "amagi task_query 结构化输出 wire v1（四封闭分支：summary/receipt/output/error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；schema 与类型的一致性由 tests/task-query-wire.test.mjs
//    以 Value.Check（映射产物过 schema）+ 属性键静态对照双重断言） ────────────────────

export interface WireCommonFields {
	kind: typeof TASK_QUERY_WIRE_KIND;
	wireVersion: typeof TASK_QUERY_WIRE_VERSION;
	schemaVersion: typeof TASK_QUERY_SCHEMA_VERSION;
	surfaceVersion: typeof TASK_QUERY_SURFACE_VERSION;
}

export interface BaseItemWire {
	taskId: string;
	agent: string;
	stateSeq: number;
	revision: number;
	execution: string;
	settlement: string;
	acceptance: string;
	degraded: string[];
	recoveryAdvice: string | null;
}

export interface LegacyItemWire { taskId: string; agent: string; status: string }
export interface ReceiptMetaWire {
	receiptId: string;
	receiptSeq: number;
	settlement: string;
	acceptance: string;
	missing: string[];
}
export interface ArchiveRefWire { path: string; bytes: number; digest: string }
export type CollectionStateWire = "available" | "absent" | "invalid" | "unreadable" | "unreferenced";
export interface CollectionWire<T> { state: CollectionStateWire; total: number | null; items: T[]; truncated: boolean }
export interface CheckItemWire { id: string | null; status: string | null; required: boolean | null; exitCode: number | null }
export interface OutputItemWire { path: string | null; bytes: number | null; digest: string | null; sourcePath: string | null }
export interface ReceiptArchiveWire {
	state: "read" | "unreadable" | "unreferenced";
	ref: ArchiveRefWire | null;
	checks: CollectionWire<CheckItemWire>;
	outputs: CollectionWire<OutputItemWire>;
}
export interface OutputArchiveWire {
	state: "read" | "unreadable" | "unreferenced";
	ref: ArchiveRefWire | null;
	outputs: CollectionWire<OutputItemWire>;
}
export interface TaskQueryDataWire<I> {
	page: { items: I[]; snapshotSeq: number; nextCursor: string | null; truncated: boolean };
	legacy: { total: number; items: LegacyItemWire[]; truncated: boolean };
}
export interface TaskQuerySummaryWire extends WireCommonFields { ok: true; isError: false; view: "summary"; data: TaskQueryDataWire<BaseItemWire> }
export type ReceiptItemWire = BaseItemWire & { receipt: ReceiptMetaWire | null; archive: ReceiptArchiveWire | null };
export type OutputViewItemWire = BaseItemWire & { receipt: ReceiptMetaWire | null; archive: OutputArchiveWire | null };
export interface TaskQueryReceiptWire extends WireCommonFields { ok: true; isError: false; view: "receipt"; data: TaskQueryDataWire<ReceiptItemWire> }
export interface TaskQueryOutputViewWire extends WireCommonFields { ok: true; isError: false; view: "output"; data: TaskQueryDataWire<OutputViewItemWire> }
export interface TaskQueryFailureWire extends WireCommonFields {
	ok: false;
	isError: true;
	view: TaskViewLevel | null;
	error: { code: string; message: string; fields: string[]; effects: string; repairExamples: object[] };
}
export type TaskQueryWireOutput = TaskQuerySummaryWire | TaskQueryReceiptWire | TaskQueryOutputViewWire | TaskQueryFailureWire;

// ── 投影源（调用方提供页面/已读归档/恢复说明——本模块零 I/O；§4.1） ─────────────

/** 已读归档（调用方已读取的回执归档 JSON；read=null 表示读取失败或非对象——与 readReceiptArchive
 *  同语义的「已读结果」，本模块不重复读盘，也不修复归档）。 */
export interface ArchiveRead {
	read: Readonly<Record<string, unknown>> | null;
}

/** wire 投影源：queryTaskViews 返回形状（QueryViewsResult 的只读子集）+ 注入面。 */
export interface TaskQueryWireSource {
	/** 查询页（TaskPage DTO：items/snapshotSeq/nextCursor?/truncated）。 */
	page: Readonly<TaskPage>;
	/** registry 投影中无内核视图的 v1 遗留记录（查询服务原样返回的集合）。 */
	legacy: ReadonlyArray<{ taskId: string; agent: string; status: string }>;
	/** 已读归档供给（receipt/output 档；按 taskId 取）。无供给或无条目 → unreadable 如实标注。 */
	archiveOf?: (taskId: string) => ArchiveRead | undefined;
	/** 恢复指引供给（§4.3：仅 v.execution="error" 且 registry 有记录、既有 renderer 产出说明时
	 *  由调用方返回当前查询的同一说明；本模块不通过查询恢复/补种状态）。 */
	recoveryAdviceOf?: (view: Readonly<TaskView>) => string | null;
}

// ── JSON-safe 小件（repairExamples 深拷贝：不接受 undefined/NaN/类实例，§4.2） ──

function isPlainObject(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null) return false;
	const proto = Object.getPrototypeOf(v);
	return proto === Object.prototype || proto === null;
}

/** JSON-safe 深拷贝（与 JSON.stringify 同语义的取舍）：string/boolean/null 保留；number 仅有限值
 *  保留（NaN/Infinity→undefined）；对象键值为 undefined/非有限数/类实例/函数/symbol/bigint 时该键
 *  删除；数组坏元素置 null（保形状）。类实例（Date/Map/宿主对象）不入 wire（§4.2「不接受类实例」）。 */
function toJsonSafe(v: unknown): unknown {
	if (v === null) return null;
	switch (typeof v) {
		case "string":
		case "boolean":
			return v;
		case "number":
			return Number.isFinite(v) ? v : undefined;
		case "object": {
			if (Array.isArray(v)) {
				const out: unknown[] = [];
				for (const el of v) {
					const safe = toJsonSafe(el);
					out.push(safe === undefined ? null : safe);
				}
				return out;
			}
			if (!isPlainObject(v)) return undefined;
			const out: Record<string, unknown> = {};
			for (const [k, val] of Object.entries(v)) {
				const safe = toJsonSafe(val);
				if (safe !== undefined) out[k] = safe;
			}
			return out;
		}
		default:
			return undefined;
	}
}

// ── 条目/集合投影（§4.3 缺口语径；各项字段缺失或类型不合映射 null） ────────────

function baseItemOf(v: Readonly<TaskView>, advice: string | null): BaseItemWire {
	return {
		taskId: v.taskId,
		agent: v.spec.agent,
		stateSeq: v.stateSeq,
		revision: v.revision,
		execution: v.execution,
		settlement: v.settlement,
		acceptance: v.acceptance,
		degraded: [...v.degraded],
		recoveryAdvice: advice,
	};
}

/** 恢复指引：仅 execution="error" 时向调用方供给取当前查询同一说明，其余 null（§4.3）。 */
function adviceOf(src: Readonly<TaskQueryWireSource>, v: Readonly<TaskView>): string | null {
	if (v.execution !== "error") return null;
	const got = src.recoveryAdviceOf?.(v) ?? null;
	return typeof got === "string" && got.length > 0 ? got : null;
}

function receiptMetaOf(r: Readonly<ReceiptSummary>): ReceiptMetaWire {
	return {
		receiptId: r.receiptId,
		receiptSeq: r.receiptSeq,
		settlement: r.settlement,
		acceptance: r.acceptance,
		missing: [...r.missing],
	};
}

function archiveRefOf(ref: Readonly<Ref>): ArchiveRefWire {
	return { path: ref.path, bytes: ref.bytes, digest: ref.digest };
}

function emptyCollection(state: Exclude<CollectionStateWire, "available">): { state: CollectionStateWire; total: null; items: never[]; truncated: boolean } {
	return { state, total: null, items: [], truncated: false };
}
function availableCollection<T>(raw: readonly unknown[], project: (entry: unknown) => T): CollectionWire<T> {
	const items = raw.slice(0, TASK_QUERY_WIRE_LIMITS.collectionMaxItems).map(project);
	return { state: "available", total: raw.length, items, truncated: raw.length > TASK_QUERY_WIRE_LIMITS.collectionMaxItems };
}

function checkItemOf(entry: unknown): CheckItemWire {
	if (typeof entry !== "object" || entry === null) return { id: null, status: null, required: null, exitCode: null };
	const c = entry as { id?: unknown; status?: unknown; required?: unknown; exitCode?: unknown };
	const exit = typeof c.exitCode === "number" && Number.isInteger(c.exitCode) && Math.abs(c.exitCode) <= Number.MAX_SAFE_INTEGER
		? c.exitCode
		: null;
	return {
		id: typeof c.id === "string" ? c.id : null,
		status: typeof c.status === "string" ? c.status : null,
		required: typeof c.required === "boolean" ? c.required : null,
		exitCode: exit,
	};
}

function outputItemOf(entry: unknown): OutputItemWire {
	if (typeof entry !== "object" || entry === null) return { path: null, bytes: null, digest: null, sourcePath: null };
	const o = entry as { path?: unknown; bytes?: unknown; digest?: unknown; sourcePath?: unknown };
	const bytes = typeof o.bytes === "number" && Number.isInteger(o.bytes) && o.bytes >= 0 && o.bytes <= Number.MAX_SAFE_INTEGER
		? o.bytes
		: null;
	return {
		path: typeof o.path === "string" ? o.path : null,
		bytes,
		digest: typeof o.digest === "string" ? o.digest : null,
		sourcePath: typeof o.sourcePath === "string" ? o.sourcePath : null,
	};
}

/** 已读归档数组字段 → Collection（§4.3）：缺席=absent、非数组=invalid（均 total=null）、
 *  数组=available（total=原长度、items=前 8 投影、truncated=total>8；空数组也是 available/0）。 */
function collectionFromField<T>(raw: unknown, project: (entry: unknown) => T): CollectionWire<T> {
	if (raw === undefined) return emptyCollection("absent");
	if (!Array.isArray(raw)) return emptyCollection("invalid");
	return availableCollection(raw, project);
}

// ── 三档 + Failure 映射（§4.2/§4.3/§4.4） ─────────────────────────────────────

function successEnvelope<V extends "summary" | "receipt" | "output", I>(
	view: V,
	items: I[],
	src: Readonly<TaskQueryWireSource>,
): WireCommonFields & { ok: true; isError: false; view: V; data: TaskQueryDataWire<I> } {
	return {
		kind: TASK_QUERY_WIRE_KIND,
		wireVersion: TASK_QUERY_WIRE_VERSION,
		schemaVersion: TASK_QUERY_SCHEMA_VERSION,
		surfaceVersion: TASK_QUERY_SURFACE_VERSION,
		ok: true,
		isError: false,
		view,
		data: {
			page: {
				items,
				snapshotSeq: src.page.snapshotSeq,
				nextCursor: src.page.nextCursor ?? null, // 缺省映射 null（cursor 全字面不透明，不重新编码）
				truncated: src.page.truncated === true,
			},
			legacy: {
				total: src.legacy.length, // 查询服务返回集合长度（非全磁盘历史总数）
				items: src.legacy.slice(0, TASK_QUERY_WIRE_LIMITS.legacyMaxItems).map((l) => ({ taskId: l.taskId, agent: l.agent, status: l.status })),
				truncated: src.legacy.length > TASK_QUERY_WIRE_LIMITS.legacyMaxItems,
			},
		},
	};
}

/** summary 档映射：只从页面 TaskView 显式取 BaseItem 字段（不扩散 spec.assignment/scope/env/inputs）。 */
export function toSummaryWire(src: Readonly<TaskQueryWireSource>): TaskQuerySummaryWire {
	return successEnvelope("summary", src.page.items.map((v) => baseItemOf(v, adviceOf(src, v))), src);
}

/** receipt 档映射：BaseItem + ReceiptMeta + 归档（checks/outputs 两 collection，§4.3 缺口语径）。 */
export function toReceiptWire(src: Readonly<TaskQueryWireSource>): TaskQueryReceiptWire {
	const items = src.page.items.map((v): ReceiptItemWire => {
		const base = baseItemOf(v, adviceOf(src, v));
		if (!v.receipt) return { ...base, receipt: null, archive: null }; // 未发布回执（settlement=pending——执行结束但结算未落）
		const meta = receiptMetaOf(v.receipt);
		const ref = v.receipt.ref ?? null;
		if (!ref) {
			return { ...base, receipt: meta, archive: { state: "unreferenced", ref: null, checks: emptyCollection("unreferenced"), outputs: emptyCollection("unreferenced") } };
		}
		const read = src.archiveOf?.(v.taskId)?.read ?? null;
		if (read === null) {
			return { ...base, receipt: meta, archive: { state: "unreadable", ref: archiveRefOf(ref), checks: emptyCollection("unreadable"), outputs: emptyCollection("unreadable") } };
		}
		return {
			...base,
			receipt: meta,
			archive: {
				state: "read",
				ref: archiveRefOf(ref),
				checks: collectionFromField("checks" in read ? read.checks : undefined, checkItemOf),
				outputs: collectionFromField("outputs" in read ? read.outputs : undefined, outputItemOf),
			},
		};
	});
	return successEnvelope("receipt", items, src);
}

/** output 档映射：BaseItem + ReceiptMeta + 归档（仅 outputs collection——无检查列表/产物全文/新路径扫描）。 */
export function toOutputWire(src: Readonly<TaskQueryWireSource>): TaskQueryOutputViewWire {
	const items = src.page.items.map((v): OutputViewItemWire => {
		const base = baseItemOf(v, adviceOf(src, v));
		if (!v.receipt) return { ...base, receipt: null, archive: null };
		const meta = receiptMetaOf(v.receipt);
		const ref = v.receipt.ref ?? null;
		if (!ref) {
			return { ...base, receipt: meta, archive: { state: "unreferenced", ref: null, outputs: emptyCollection("unreferenced") } };
		}
		const read = src.archiveOf?.(v.taskId)?.read ?? null;
		if (read === null) {
			return { ...base, receipt: meta, archive: { state: "unreadable", ref: archiveRefOf(ref), outputs: emptyCollection("unreadable") } };
		}
		return {
			...base,
			receipt: meta,
			archive: {
				state: "read",
				ref: archiveRefOf(ref),
				outputs: collectionFromField("outputs" in read ? read.outputs : undefined, outputItemOf),
			},
		};
	});
	return successEnvelope("output", items, src);
}

/**
 * Failure 映射（§4.4）：ContractError → Failure 分支。code/message/fields/effects 原语义完整保留；
 * repairExamples 深拷贝为 JSON-safe 对象数组（缺省映射 []，不为新增载体改正文）；effects 为 string
 * 投影（合法值由 ContractError 单源定义）。view 只接受合法三档字面或 null——调用方按 §4.4 裁定
 * （缺省 summary、显式非法值 null），本映射不 echo 任意原参数。
 */
export function toFailureWire(e: Readonly<ContractError>, view: TaskViewLevel | null): TaskQueryFailureWire {
	const repairExamples: object[] = [];
	for (const ex of e.repairExamples) {
		const safe = toJsonSafe(ex);
		if (isPlainObject(safe)) repairExamples.push(safe);
	}
	return {
		kind: TASK_QUERY_WIRE_KIND,
		wireVersion: TASK_QUERY_WIRE_VERSION,
		schemaVersion: TASK_QUERY_SCHEMA_VERSION,
		surfaceVersion: TASK_QUERY_SURFACE_VERSION,
		ok: false,
		isError: true,
		view,
		error: {
			code: e.code,
			message: e.message,
			fields: [...e.fields],
			effects: e.effects,
			repairExamples,
		},
	};
}

// ── U5（pi-099 D 片，diting F3 实施）：凭据模式脱敏（wire 自由文本专用） ─────────
//
// 边界（任务书 D 片裁定）：只作用于 wire 载体的自由文本字段（Failure 的 error.message 与
// repairExamples 递归字符串值、成功三档的 recoveryAdvice）及 details.error（第三载体，O3c
// §二-4 实测发现）——不动结构字段（taskId/digest/path/枚举）；正文 content 契约字节不变
//（v2.8.9 正文未脱敏是显式登记的存量边界，闭合需另立契约变更）。
// 模式纪律：**只匹配明确凭据 token 形态**——Bearer 值（≥20 字符 token 形，避免「Bearer
// authentication scheme」文档词误伤）、api[-_]?key 赋值（键名+[:=] 强指征，值 ≥8 token 形）、
// sk- 式长串（≥16，OpenAI 风格 secret key 前缀强指征）、password 赋值（值 ≥6 ASCII 凭据 token
// 形态——排除中文/任意文本，误伤优先于漏脱的保守取舍）。普通路径、普通错误消息、枚举、digest/taskId 字面零匹配（pi-099-d 测试零误伤配对）。
// 幂等：[REDACTED:<kind>] 标记不含任何可再匹配形态，重复脱敏结果稳定。

/** 凭据模式清单（kind 进 [REDACTED:<kind>] 标记；prefix 组保留键名/方案词——值被替换）。 */
const CREDENTIAL_REDACTION_PATTERNS: readonly { kind: string; re: RegExp; keepPrefix: boolean }[] = [
	{ kind: "bearer-token", re: /\b(Bearer\s+)([A-Za-z0-9\-_.~+/=_]{20,})/gi, keepPrefix: true },
	{ kind: "api-key", re: /\b(api[-_]?key\b["']?\s*[:=]\s*["']?)([A-Za-z0-9\-_.~+/=_]{8,})/gi, keepPrefix: true },
	{ kind: "secret-key", re: /\bsk-[A-Za-z0-9_-]{16,}/g, keepPrefix: false },
	{ kind: "password", re: /\b(password\b["']?\s*[:=]\s*["']?)([A-Za-z0-9\-_.~+/=!@#$%^&*]{6,})/gi, keepPrefix: true },
];

/** 自由文本凭据模式脱敏：只替换明确凭据 token 形态，标记形如 [REDACTED:<kind>]；
 *  键名/方案词前缀（Bearer / api_key= / password": " 等）保留（文本可读、引号闭合不破坏）。
 *  非字符串输入原样抛由调用方——本函数只做纯字符串变换。 */
export function redactCredentials(text: string): string {
	let out = text;
	for (const { kind, re, keepPrefix } of CREDENTIAL_REDACTION_PATTERNS) {
		out = out.replace(re, keepPrefix ? `$1[REDACTED:${kind}]` : `[REDACTED:${kind}]`);
	}
	return out;
}

/** 进程展示面脱敏策略（ev-20261012-2ca6a7 B7 修复轮 F01，diting 终裁）：与 wire 级
 *  redactCredentials 的有限 token 模式（含误伤兼容取舍）不同，本策略面向 ps/argv 等不可控
 *  输入——凡键名含 KEY/TOKEN/SECRET/PASSWORD/PASSWD/AUTH/CREDENTIAL 的赋值（NAME=value /
 *  NAME: value / NAME": "v"，值任意长度、unicode、混合、引号包裹）整体遮蔽为 NAME=[REDACTED]；
 *  另遮蔽 Bearer 值与 sk- 长串。不做 wire 的误伤兼容取舍（进程展示宁过勿漏）；调用方须在
 *  完整遮蔽后再做长度截断，防止截断把值切成明文前缀外露。不改变 redactCredentials 既有约定。 */
const PROCESS_DISPLAY_ASSIGNMENT_RE = /([A-Za-z0-9_]*(?:KEY|TOKEN|SECRET|PASSWORD|PASSWD|AUTH|CREDENTIAL)[A-Za-z0-9_]*["']?\s*[:=]\s*)("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[^\s]+)/gi;
const PROCESS_DISPLAY_BEARER_RE = /\b(Bearer\s+)[A-Za-z0-9\-_.~+/=_]{20,}/gi;
const PROCESS_DISPLAY_SK_RE = /\bsk-[A-Za-z0-9_-]{16,}/g;

/** 进程展示脱敏：KEY/TOKEN/SECRET 类赋值整体遮蔽（任意长度/unicode/引号/多赋值/混合值）；
 *  Bearer/sk- 先行遮蔽（防后续赋值遮蔽吃掉 Bearer 前缀词留下裸 token）。纯字符串变换。 */
export function redactProcessDisplayText(text: string): string {
	// 引号分支转义感知（F01-R1）："(?:[^"\\]|\\.)*" 把 \" 当内容而非闭合——否则 JSON 转义值
	// （{"TOKEN":"head\" tail"}）只遮蔽前半段泄露尾部；不闭合引号回退 [^\s]+ 保守遮蔽到空白。
	let out = text.replace(PROCESS_DISPLAY_BEARER_RE, "$1[REDACTED]");
	out = out.replace(PROCESS_DISPLAY_SK_RE, "[REDACTED]");
	out = out.replace(PROCESS_DISPLAY_ASSIGNMENT_RE, "$1[REDACTED]");
	return out;
}

/** JSON 值递归脱敏：仅字符串值过 redactCredentials（对象键=参数名非自由文本，不脱敏；
 *  非纯对象/数组元素原样——剥除交给 toFailureWire 的 toJsonSafe，职责不混）。 */
function redactJsonTexts(v: unknown): unknown {
	if (typeof v === "string") return redactCredentials(v);
	if (Array.isArray(v)) return v.map(redactJsonTexts);
	if (isPlainObject(v)) {
		const out: Record<string, unknown> = {};
		for (const [k, val] of Object.entries(v)) out[k] = redactJsonTexts(val);
		return out;
	}
	return v;
}

/** ContractError 自由文本脱敏（wire 载体专用）：message 与 repairExamples 递归字符串值脱敏；
 *  code/fields/effects 原样（枚举/字段名结构面，不含凭据形态）。调用点在 task-facets 接线层
 *  （failWire：同一产物喂 structuredContent 与 details.error——两载体同源同脱敏，O3c §4.5）。 */
export function redactContractError(e: Readonly<ContractError>): ContractError {
	return {
		code: e.code,
		message: redactCredentials(e.message),
		fields: [...e.fields],
		effects: e.effects,
		repairExamples: e.repairExamples.map((ex) => redactJsonTexts(ex)) as object[],
	};
}
