/**
 * task-resume.ts — resume 链（P3-C：2026-08-19 插件进化，第二/三批拆分自 task-tool.ts L1662-1839）。
 * 含 v1.5.222 resume 磁盘回填（resolveSessionWithBackfill：Leader 重启后 registry 清空，会话真相在磁盘）
 * + runResumeTask（lease/准入排队/父任务 blocked→answering→answered 状态机）。
 *
 * K5b（方案 §3.4-N5/N6/§8.1-K5b）：resume 链接入统一 submit 面与内核命令——
 *  - 续接子任务经 submitTaskKernel register（冻结真实 TaskSpec + saveSpec/current 清单落盘成功才继续；
 *    relation.parentTaskId 记父链，allowedPaths 继承原任务快照——权限不超父任务，不因旧会话缺字段提升保证）；
 *  - 父任务 blocked→answering = 内核 begin-resume（session lease 防并发续接，只启动一个；N6），
 *    answering→answered/blocked = 内核 finish-resume（answered 携 successorTaskId 父链）；
 *  - 排队晋级 = 内核 grant-start（launchIntent 持久化先于 spawn，K5a 同语义）；
 *  - lease 被占 → 本次续接封闭（不 spawn、未启动的排队子记录显式取消收口、槽位/lease 归还）；
 *  - 内核未持有父任务（v2 前遗留会话）→ registry.patch legacy 兼容入口（桥种子收编后同命令语义）。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import type { TaskSpec, WorkspaceSpec } from "./contracts/task.ts";
import { ok, type Result } from "./contracts/view.ts";
import { randomUUID } from "node:crypto";
import type { AgentConfig } from "./agents-loader.ts";
import { registry, registryErrorEcho, type TaskRecord } from "./task-registry.ts";
import { backfillSessionRecord } from "./session-backfill.ts";
import { taskContextArtifactRefs, uniqueArtifactRefs } from "./artifact.ts";
// ev-20261005-055864：resume 契约候选的即时对账入口（状态判定单源内核，不旁路）；
// diting F-03：owner/machineId 与生产 applyTaskRecovery 同源
import { reconcileRestartTask } from "./task-recovery.ts";
import { getTaskKernel, resolveLeaderOwnerId, getLeaderMachineStamp } from "./task-service.ts";
import { resolveModelWithSource, effectiveModelNote, normalizeModelSpec, collectQuotaRecoveryCandidates, type QuotaCandidateRegistry, type QuotaRecoveryCandidate } from "./model-resolver.ts";
import { resumeBudgetReject, contextBudgetReject, contextWindowOf, persistResumeRelayPack } from "./context-budget.ts";
import { isProviderBreakerEnabled, providerBreakerCheck, recoveryActionOf, isContentPolicyRejection, isAccountQuotaError, isTransientProviderError, type RecoveryAction } from "./reliability.ts";
import { readTaskWrites } from "./task-write-log.ts";
import { tryOccupy, waitForGrant, release as releaseAdmission, cancelQueued } from "./admission.ts";
import { journalDispatch } from "./journal.ts";
// ev-20260909-c00fcb②：白名单 resume 续轮同样注入越界处置契约（与首派同语义）
import { whitelistOverflowContractBlock, anchoredResourceDisciplineBlock } from "./group-scheduler.ts";
import { beginSyncWait, endSyncWait } from "./sync-wait.ts";
import { extractArtifactRefs } from "./task-jsonl.ts";
// ev-20261031-561b9d：续轮并行写入者刷新——与 fresh 派发同入口同语义（排除自身与父任务）
import { collectSiblingWriterLabels, resumeParallelWritersNote } from "./workspace-preflight.ts";
import { collectCrossSessionWriterLabels } from "./cross-session-writers.ts";
// v2.15.0 大发射守卫 prompt 层：子进程 --append-system-prompt 末尾纪律分节（provider 命中才注入）
import { largeEmissionDisciplineLine } from "./large-emission-guard.ts";
import {
	genTaskId, writePromptTmp, providerOfSpec, classifyTask, fuseWarningFor, resolveAgentTools,
	makeErrorResult, finalizeLaunchFailure, runPiTask, DONE_CONTRACT_REMINDER, SHARED_TREE_DISCIPLINE,
	planTaskPrompt, applyTaskPromptOffload, appendDeclaredOutputsSection,
	type RunResult, type BackgroundStart, type BackgroundOpts,
} from "./task-run.ts";
import { submitTaskKernel, grantStartTask, peekTaskKernel, cancelTask, getFrozenPermissionGrant, loadResumeParentSpec, isEnforceablePermissionGrant } from "./task-service.ts";
import { releaseWorktreeLease } from "./worktree.ts";

/** F8：workspace、授权与 outputs 从同一来源读取，store 错误原样透传。null 仅指
 *  store 明确无记录且内核无父任务；有内核占位但无法恢复完整冻结契约必须拒绝。 */
export const loadResumeParentContract = loadResumeParentSpec;
export async function loadResumeParentWorkspace(taskId: string): Promise<Result<WorkspaceSpec | null>> {
	const parent = await loadResumeParentContract(taskId);
	return parent.ok ? ok(parent.value?.workspace ?? null) : parent;
}

// ── v1.5.222 resume 磁盘回填：Leader 重启后 registry 清空，会话真相在磁盘（artifact metadata + pi sessions 目录）。
// 内存未命中 → 回填收编后再解析；resume 不再依赖原 Leader 进程存活（实战：cbc75699 被误杀后
// 重启 Leader，resume "未找到会话"，而会话文件与 artifact 完好、任务本可续接）。 ──
export function resolveSessionWithBackfill(query: string): { taskId: string; record: Readonly<TaskRecord>; backfillNote?: string } | undefined {
	// ev-20260914-4150dd：前缀命中多条时 resolveSession 抛带候选清单的歧义 RegistryError——本函数
	// 不吞不截（保持整段透传：调用方或经 pi 工具层 throw→isError 契约上浮，或如 runResumeTask 转 rejected 结果）。
	const direct = registry.resolveSession(query);
	if (direct) return direct;
	let bf: ReturnType<typeof backfillSessionRecord>;
	try { bf = backfillSessionRecord(query); } catch { return undefined; }
	if (!bf.ok) return undefined;
	const adopted = registry.adoptExternal(bf.record);
	const again = registry.resolveSession(adopted?.taskId ?? query);
	if (!again) return undefined;
	return { ...again, backfillNote: `[resume 磁盘回填] registry 无记录（Leader 已重启），${bf.note}；续接旧会话上下文` };
}

/** ev-20261005-055864（diting F-02）：契约任务收编——内核权威投影，绝不经 adoptExternal 桥。
 *  根因：adoptExternal → kernelBridge.ensureAdopted 在 record.status ≠ 内核 execution 时以 bridgeSpec
 *  （合成 assignment、grant=none）重种子内核并 CAS 写回 store——契约权威（真实 spec/run/授权/产物声明）
 *  被降格覆盖；权限继承（frozenPermissionOf）与产物继承（frozenOutputsOf）随之丢失。
 *  本投影只读内核视图（TaskView：execution/revision/sessionId/spec summary）+ 磁盘回填补充
 *  （cwd/model——非高危面）构造 TaskRecord 直 upsert 进 registry 投影层（不经桥、不 seed、不写 store）。
 *  内核无视图（reconcile 未完成/已被清理）→ undefined 不猜（调用方如实报错）。 */
async function adoptContractProjection(rec: { taskId: string; sessionId?: string; cwd?: string; model?: string }): Promise<{ taskId: string; record: Readonly<TaskRecord> } | undefined> {
	const kernel = peekTaskKernel() ?? getTaskKernel();
	// 干净终态路径未经 reconcile（applyQuiet seed）——内核无视图时先 store 回退种子（零命令/零投影）
	try { await kernel.seedFromStoreIfAbsent(rec.taskId); } catch { /* lint-exempt:种子失败→视图缺失→不收编 */ }
	let view: ReturnType<typeof kernel.get> | undefined;
	try { view = kernel.get(rec.taskId); } catch { /* lint-exempt:内核视图异常不猜→不收编 */ return undefined; }
	if (!view) return undefined;
	registry.projectFromKernel({
		taskId: view.taskId,
		agent: view.spec.agent,
		status: view.run.execution, // 执行态原值：running/resolved-external 由 resume 准入如实拒绝（diting F-05）
		goal: view.spec.assignment,
		cwd: rec.cwd,
		startedAt: view.run.queuedAt,
		backend: view.run.backend,
		revision: view.revision,
		queuedAt: view.run.queuedAt,
		...(view.run.sessionId !== undefined ? { sessionId: view.run.sessionId } : rec.sessionId !== undefined ? { sessionId: rec.sessionId } : {}),
		...(rec.model !== undefined ? { model: rec.model } : {}),
	});
	return registry.resolveSession(view.taskId) ?? undefined;
}

/** ev-20261005-055864（bug/P2）：resume 专用解析——契约候选自动经统一对账入口处置后回填。
 *  根因：K8a 候选门对一切契约任务拒收编，而「对账采纳」在重启后从不自动发生（恢复对账只在
 *  唤起原会话且 sessionKey 匹配时应用）→ resume 死锁：报「磁盘回退亦未命中」实为候选门拒绝被
 *  吞（resolveSessionWithBackfill 的 if(!bf.ok) return undefined），只能全新重派，scope/模型/cwd
 *  继承语义丢失（实战 f442daab/5b58d532 各一次）。桥接（diting F-02/F-03 修正后形态）：
 *  ①gate 放行（干净终态/已对账处置）→ 内核权威投影收编（adoptContractProjection）；
 *  ②gate 拒且 needsReconcile → reconcileRestartTask（owner/machineId 与生产同源；applyQuiet 先从
 *    store seed 权威再标记）成功后重试回填；
 *  ③磁盘真无记录/corrupt（不可经对账解除，diting F-04）/对账后仍未命中 → 如实 undefined。 */
export async function resolveSessionForResume(query: string): Promise<{ taskId: string; record: Readonly<TaskRecord>; backfillNote?: string } | undefined> {
	const direct = registry.resolveSession(query);
	if (direct) return direct;
	let bf: ReturnType<typeof backfillSessionRecord>;
	try { bf = backfillSessionRecord(query); } catch { /* lint-exempt:回填链异常视同未命中（不猜，语义同旧链） */ return undefined; }
	if (bf.ok && !bf.contractProjection) {
		// legacy 遗留任务（无契约记录）：原 adoptExternal 语义安全保持（无内核冲突可重种子）
		const adopted = registry.adoptExternal(bf.record);
		const again = registry.resolveSession(adopted?.taskId ?? query);
		if (!again) return undefined;
		return { ...again, backfillNote: `[resume 磁盘回填] registry 无记录（Leader 已重启），${bf.note}；续接旧会话上下文` };
	}
	if (bf.ok && bf.contractProjection) {
		const projected = await adoptContractProjection(bf.record);
		if (!projected) return undefined;
		return { ...projected, backfillNote: `[resume 磁盘回填] registry 无记录（Leader 已重启），${bf.note}；契约任务经内核权威投影收编（执行态=${projected.record.status}）；续接旧会话上下文` };
	}
	// 穷尽 ok:true 两分支后剩 ok:false（显式收口使 narrowing 成立；防御性不可达）
	if (bf.ok) return undefined;
	const candidate = bf.contractCandidate;
	if (!candidate || !candidate.taskId) return undefined;
	// 契约候选：单任务即时对账（统一入口；owner/machineId 与生产 applyTaskRecovery 同源——diting F-03；
	// 幂等——重复应用保持标记不重复迁移）后重试回填
	let reconcileNote = "";
	try {
		// 先确保内核单例已建（owner 固定）——reconcile fence 的 key.ownerId 必须与内核同源
		// （生产 index 建内核时已同源；测试/重建场景 peek 缺失时 getTaskKernel 先建）。diting F-03。
		const kernelForReconcile = peekTaskKernel() ?? getTaskKernel();
		const item = await reconcileRestartTask(candidate.taskId, { ownerId: kernelForReconcile.ownerId, machineId: getLeaderMachineStamp() });
		reconcileNote = `单任务对账完成（${item.taskId.slice(0, 8)}：execution=${item.execution ?? "-"}，建议动作=${item.action}${item.applied?.ok ? "，已应用" : ""}）`;
	} catch (e) {
		reconcileNote = `单任务对账失败（${e instanceof Error ? e.message : String(e)}）——候选仍未采纳`;
	}
	let bf2: ReturnType<typeof backfillSessionRecord>;
	try { bf2 = backfillSessionRecord(query); } catch { /* lint-exempt:对账后重试回填异常视同未命中（不猜） */ return undefined; }
	if (bf2.ok && bf2.contractProjection) {
		const projected = await adoptContractProjection(bf2.record);
		if (!projected) return undefined;
		return { ...projected, backfillNote: `[resume 磁盘回填] registry 无记录（Leader 已重启），${bf2.note}；${reconcileNote}；契约任务经内核权威投影收编（执行态=${projected.record.status}）；续接旧会话上下文` };
	}
	return undefined;
}

// ── D2（ev-20260922-727096）：resume 准入判定单源 + 记录→恢复动作装配 ──────────
// 建议面（恢复指引：task-facets/task-query/task-tool 通知）与执行面（runResumeTask）共用同一
// 判断；建议不是准入授权——执行时仍重查 lease/模型/预算（skipLease 只反映 fork 语义，不放宽建议面）。 ──

/** resume 准入阻塞码（顺序即判定顺序：running → resolved-external → answering-lease → no-session）。 */
export type ResumeAdmissionCode = "running" | "resolved-external" | "answering-lease" | "no-session";

/** resume 准入判定（纯判断，单源）：返回首个阻塞码；undefined=可续接（执行面仍会重查
 *  lease 占用/模型归一/预算/熔断——本函数只覆盖状态机级阻塞，供恢复建议与执行面共用）。 */
export function resumeAdmissionCodeOf(prev: { status: string; sessionId?: string }, opts?: { skipLease?: boolean }): ResumeAdmissionCode | undefined {
	if (prev.status === "running") return "running";
	if (prev.status === "resolved-external") return "resolved-external";
	if (prev.status === "answering" && !opts?.skipLease) return "answering-lease";
	if (!prev.sessionId) return "no-session";
	return undefined;
}

/** registry 记录（或同形事实对象）→ 恢复动作（recoveryActionOf 输入装配单源——task-facets/
 *  task-query/task-tool 消费；渲染面由调用方按会话 surfaceVersion 选择）。终态记录按定义已确认
 *  进程退出（迟到事件由 finalizer 幂等/stale 防护拦下，不进入建议面）。ev-20261012-21074e②：
 *  policy 拦截时从任务写面登记装配已写入文件清单（≤512 行有界；去重按末次写入时间降序，
 *  渲染侧再限 8 项——error 终态可能已有部分产物，先核对再续接/重派）。
 *  ev-20261031-7110a8：quota/transient 类 error 额外装配换模事实——quota 附父链连续 quota 失败数
 *  （沿 parentTaskId 链向上数连续 error+quota 且实际失败 provider 相同的记录，含当前；steer 2-②：
 *  换 provider 后的失败不计入同 provider 连续；registry 异常/链断时诚实按 1 兜底）与配置枚举候选
 *  （collectQuotaRecoveryCandidates 只读；modelRegistry 由调用方透传，缺席时候选标注未探测）；
 *  transient（含裸 429/瞬时限流，steer 2-①：原始场景同样能看到临时换模入口）只附候选，不附链计数
 *  ——分类与默认重试语义不变。任一装配失败只降级该字段，不影响既有恢复建议。 */
export function recoveryActionOfRecord(rec: Readonly<{
	taskId: string; status: string; sessionId?: string; errorMessage?: string; stopReason?: string;
	timedOut?: boolean; aborted?: boolean; lastErrorKind?: "policy" | "transient" | "quota" | "other"; cwd?: string; model?: string;
}>, extra?: { spawnError?: string; cwdAvailable?: boolean; modelRegistry?: unknown }): RecoveryAction | undefined {
	// policy 判定：errorMessage 现场分类或 registry lastErrorKind 快照（v2.21.6 ev-20261017-88cb27：
	// 安全拦截可区分标签落库后，即使错误原文被包装/截断，恢复建议仍走 policy-reject 不回退到确定性兑底）。
	const _policy = rec.lastErrorKind === "policy" || isContentPolicyRejection(rec.errorMessage) || isContentPolicyRejection(extra?.spawnError);
	// ev-20261031-7110a8：quota/transient 类 error（快照优先，错误文案兑底）装配换模事实；
	// steer 2-①：transient（含裸 429/瞬时限流）同样附候选（非强制），不因仅硬 quota 文案才让当事场景受益。
	const _quota = rec.status === "error" && (rec.lastErrorKind === "quota" || isAccountQuotaError(rec.errorMessage) || isAccountQuotaError(extra?.spawnError));
	const _transient = rec.status === "error" && !_quota && !_policy
		&& (rec.lastErrorKind === "transient" || (!rec.lastErrorKind && (isTransientProviderError(rec.errorMessage) || isTransientProviderError(extra?.spawnError))));
	return recoveryActionOf({
		taskId: rec.taskId,
		status: rec.status,
		errorKind: rec.lastErrorKind,
		errorMessage: rec.errorMessage,
		spawnError: extra?.spawnError,
		stopReason: rec.stopReason,
		userAborted: rec.aborted === true,
		timedOut: rec.timedOut === true,
		processExited: true,
		sessionId: rec.sessionId,
		cwdAvailable: extra?.cwdAvailable ?? (rec.cwd ? fs.existsSync(rec.cwd) : true),
		admissionBlockedCode: resumeAdmissionCodeOf(rec),
		model: rec.model,
		...(_policy ? { writtenFiles: policyWrittenFilesOf(rec.taskId, rec.cwd) } : {}),
		...((_quota || _transient) ? quotaRecoveryFactsOf(rec, extra?.modelRegistry as QuotaCandidateRegistry | undefined, { includeChain: _quota }) : {}),
	});
}

/** 记录的 provider 段（无 / 或空 → 空串；链分段用）。 */
function recordProviderOf(model?: string): string {
	if (!model) return "";
	const i = model.indexOf("/");
	return i > 0 ? model.slice(0, i) : "";
}

/** quota/transient 换模事实装配（配置候选 + quota 父链连续计数[按实际失败 provider 分段]；全程只读，异常降级不拖垮建议面）。 */
function quotaRecoveryFactsOf(rec: Readonly<{ taskId: string; cwd?: string; model?: string }>, modelRegistry: QuotaCandidateRegistry | undefined, opts?: { includeChain?: boolean }): { quotaChainFailures?: number; switchCandidates?: QuotaRecoveryCandidate[] } {
	let quotaChainFailures: number | undefined;
	if (opts?.includeChain) {
		try {
			// steer 2-②：按实际失败 provider 分段——只数与本轮失败同 provider 的连续 quota 失败；
			// 换 provider 后的失败（A 失败→换 B 再失败）不计入同 provider 连续，不得写成「连续 2 次」。
			const curProvider = recordProviderOf(rec.model);
		let chain = 1; // 当前记录已由调用方判定为 quota 类 error
		let cur = registry.get(rec.taskId);
		const seen = new Set<string>();
		while (cur && cur.parentTaskId && !seen.has(cur.taskId)) {
			seen.add(cur.taskId);
			const parent = registry.get(cur.parentTaskId);
			if (!parent || parent.status !== "error") break;
				if (!(parent.lastErrorKind === "quota" || isAccountQuotaError(parent.errorMessage))) break;
				if (!curProvider || recordProviderOf(parent.model) !== curProvider) break;
				chain++;
				cur = parent;
			}
			quotaChainFailures = chain;
		} catch { /* lint-exempt:链计数异常→缺省（渲染层按未提供处理） */ }
	}
	let switchCandidates: QuotaRecoveryCandidate[] | undefined;
	try {
		switchCandidates = collectQuotaRecoveryCandidates({ failedSpec: rec.model, cwd: rec.cwd, registry: modelRegistry }).cross;
	} catch { /* lint-exempt:候选枚举失败→缺省（渲染层给无候选出口，不假称） */ }
	return { ...(quotaChainFailures !== undefined ? { quotaChainFailures } : {}), ...(switchCandidates !== undefined ? { switchCandidates } : {}) };
}

/** policy 恢复建议的已写入文件清单（任务写面登记去重，末次写入降序；cwd 内相对化展示）。 */
function policyWrittenFilesOf(taskId: string, cwd?: string): string[] {
	const last = new Map<string, number>();
	for (const w of readTaskWrites(taskId)) {
		const prev = last.get(w.file);
		if (prev === undefined || w.at >= prev) last.set(w.file, w.at);
	}
	return [...last.entries()]
		.sort((a, b) => b[1] - a[1])
		.map(([file]) => {
			if (!cwd) return file;
			const rel = relUnder(cwd, file);
			return rel !== undefined ? rel : file;
		});
}

/** path 相对 base 的仓库内表示（不在 base 下 → undefined；macOS /var→/private/var 符号链接
 *  前缀错位经 realpath 双侧归一消除——登记方与 cwd 可能持不同链接形态）。 */
function relUnder(base: string, p: string): string | undefined {
	try {
		const realBase = fs.realpathSync(base);
		const rel = path.relative(realBase, p);
		if (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel)) return rel;
		// 登记路径可能持符号链接前缀（/var vs /private/var）：realpath 后重试
		try {
			const relReal = path.relative(realBase, fs.realpathSync(p));
			if (relReal !== ".." && !relReal.startsWith(`..${path.sep}`) && !path.isAbsolute(relReal)) return relReal;
		} catch { /* lint-exempt:目标已删 realpath 不可达——保持原判定（绝对路径展示仍可用） */ }
		return undefined;
	} catch {
		/* lint-exempt:cwd 不可 realpath（已删/权限）——退绝对路径展示，不阻断恢复建议装配 */
		return undefined;
	}
}

// ── resume runResumeTask（调用 runPiTask，sync 或 background） ──
export async function runResumeTask(agent: AgentConfig, params: { session: string; task: string; model?: string; background?: boolean; useFork?: boolean }, opts: BackgroundOpts & { signal?: AbortSignal; skipLease?: boolean; budgetScope?: "resume" | "fresh-fallback"; downgradeFromModel?: string; resumeParentSpec?: Readonly<TaskSpec> | null }): Promise<RunResult | BackgroundStart> {
	// ev-20260914-4150dd：歧义（前缀命中多条）→ resolveSession 抛带候选清单的 RegistryError，
	// 此处整段透传为 rejected 结果（不截断；orchestrate fork / fresh-fallback 注入路径同样可读）。
	let resolved: ReturnType<typeof resolveSessionWithBackfill>;
	try {
		resolved = resolveSessionWithBackfill(params.session);
	} catch (e) {
		const msg = registryErrorEcho(e);
		return { ...makeErrorResult("no-session", agent, "", msg, "resume", msg), rejected: true };
	}
	if (!resolved) {
		// 磁盘回退也失败时给出可读原因（resume 指引而非裸"不存在"）
		let _why = "";
		try { const b = backfillSessionRecord(params.session); _why = b.ok ? "（回填收编失败）" : `（磁盘回退亦未命中：${b.error}）`; } catch { _why = ""; }
		return { ...makeErrorResult("no-session", agent, "", `未找到会话 "${params.session}"${_why}`, "resume", `未找到会话 "${params.session}"${_why}`), rejected: true };
	}
	const prev = resolved.record;
	// ev-20260822-872c59：以下均为准入前拒绝（未 spawn、未建新记录）——统一标 rejected，
	// 消费者直接透出根因，不得拿 prev.taskId 进统一收尾链（旧任务幂等缓存会回放旧终稿）。
	const rejectedResume = (stderr: string, errorMessage?: string): RunResult =>
		({ ...makeErrorResult(prev.taskId, agent, "", stderr, "resume", errorMessage), rejected: true });
	// D2（ev-20260922-727096）：状态机级准入判定改经单源 resumeAdmissionCodeOf（与恢复建议面共用
	// 同一判断）；拒绝文案与既有语义逐字保持不变（行为零变化——只收敛判断源）。
	const _admCode = resumeAdmissionCodeOf(prev, { skipLease: opts.skipLease });
	if (_admCode === "running") return rejectedResume(`任务 ${prev.taskId} 运行中`, `运行中`);
	// ev-20260908-f189e7：外部处置终态不可 resume——产物已在外部采用（会话无需再跑）；
	// 如确需重跑请新派任务（保留原 session 历史仅作参考，不作为执行载体）。
	if (_admCode === "resolved-external") return rejectedResume(`任务 ${prev.taskId} 已外部处置收口（resolved-external 终态，不再可 resume）——${prev.resolveNote || "产物已在外部采用"}；如需重跑请重新派发新任务`, `已外部处置`);
	// K5b（N6 接入侧消费）：answering = 续接进行中（session lease 已被并发 resume 持有，或上一轮
	// begin 后未收敛）——二次续接拒绝（只启动一个）。fork（skipLease：各枝独立 sessionFile，
	// 无共享续接风险）不参与竞争，保持放行（多枝并发对同一父任务 begin 幂等 no-op）。
	if (_admCode === "answering-lease") return rejectedResume(`任务 ${prev.taskId} 续接进行中（answering——N6 lease 防并发续接，只启动一个）；若为历史残留请 task({ cancel: "${prev.taskId}" }) 收口后重派`, `续接进行中`);
	if (_admCode === "no-session" || !prev.sessionId) return rejectedResume(`无 sessionId`, `无 sessionId`);
	// stable 入口已复核 store 并携同源 spec；底层 legacy/fork 已有内核态保留同步建档前缀。
	// 只在 registry-only 或 stable 发现 bridge 占位时 await 恢复，不能用占位默认授权继续。
	let parentSpec = opts.resumeParentSpec;
	if (parentSpec === undefined && !peekTaskKernel()?.get(prev.taskId)) {
		const parent = await loadResumeParentContract(prev.taskId);
		if (!parent.ok) return rejectedResume(`父冻结契约不可读（不降级 legacy）：${parent.error.code}: ${parent.error.message}`, parent.error.message);
		parentSpec = parent.value;
	}
	if (parentSpec) {
		if (!isEnforceablePermissionGrant(parentSpec.permission)) return rejectedResume("冻结授权/outputs 无法恢复，不降级 legacy", "冻结授权/outputs 无法恢复");
		if (peekTaskKernel()?.get(prev.taskId)?.spec.specDigest !== parentSpec.specDigest) {
			try {
				const restored = await getTaskKernel().restoreResumeParentFromStore(prev.taskId);
				if (!restored.ok) return rejectedResume(`${restored.error.code}: ${restored.error.message}`, restored.error.message);
				if (restored.value.specDigest !== parentSpec.specDigest) return rejectedResume("父契约恢复期间冻结版本改变，不猜测授权/outputs", "父冻结版本改变");
			} catch (e) { return rejectedResume(`父契约恢复失败：${String(e)}`, `父契约恢复失败：${String(e)}`); }
		}
	}
	const leaseSid = prev.sessionId;
	if (!opts.skipLease && !registry.acquireLease(leaseSid)) return rejectedResume(`会话 ${leaseSid.slice(0,8)} lease 占用`, `lease`);
	const newTaskId = genTaskId();
	const resolution = resolveModelWithSource(agent, { paramModel: params.model, fallbackModel: prev.model || opts.fallbackModel, cwd: opts.cwd });
	const model = resolution.spec;
	const sessionName = `${agent.name}-${newTaskId.slice(0, 8)}`;
	// v1.5.176: resume 派发前归一/校验（prev.model 继承路径同样过检；失败不启动、不动父任务状态）
	const _nm = normalizeModelSpec(model, opts.modelRegistry);
	if (!_nm.ok) {
		if (!opts.skipLease) registry.releaseLease(leaseSid);
		return rejectedResume(_nm.error || "模型校验失败", "模型校验失败");
	}
	const effModel = _nm.spec;
	const modelNote = [effectiveModelNote(effModel, resolution.source, resolution.amagiOrigin), _nm.note,
		prev.model && prev.model !== effModel ? `[model] 父轮：${prev.model} → 本轮：${effModel}` : undefined].filter(Boolean).join("\n") || undefined;
	// 显式启用 AMAGI_CTX_BUDGET_RATIO 才按原生投影体积做粗略准入检查。
	// 默认不以历史字节数拒绝续接，让 pi 在请求前执行原生上下文检查/自动压缩。
	// opt-in 拒单时给换模型/artifact 接力路径；lease 已占用需释放后再返回。
	// ev-20260905-fdbb89 双口径：budgetScope="fresh-fallback"（sync 失败自动降档重派）表示原派发
	// 是 fresh、失败会话仅含任务书+少量轮次——预算按任务书口径（contextBudgetReject）检查，
	// fresh-fallback 同窗降档仍按任务书预算；显式 resume 使用原生当前分支有效上下文预算。
	// diting 增审 Major-2（ev20260905 阶段审核）：fresh-fallback 的降档 resume 同样以 --session
	// 续接——跨 provider 或上下文窗口收缩时追加有效上下文校验（resumeBudgetReject），防长会话
	// 降档到小窗模型的运行时上下文超限死派发；同窗 tier 降档（kimi-k3:high→:medium）维持任务书口径
	// （不朽宗门事故正是该形态，不能回退）。
	{
		const relaySpec = parentSpec ?? peekTaskKernel()?.frozenSpecOf(prev.taskId);
		const _fbScope = opts.budgetScope === "fresh-fallback";
		let _rbReject: string | null = null;
		if (_fbScope) {
			const _from = opts.downgradeFromModel;
			const _shrink = _from && (providerOfSpec(effModel) !== providerOfSpec(_from)
				|| ((contextWindowOf(opts.modelRegistry, effModel) ?? Number.POSITIVE_INFINITY) < (contextWindowOf(opts.modelRegistry, _from) ?? Number.POSITIVE_INFINITY)));
			_rbReject = (_shrink ? resumeBudgetReject(prev.sessionId, effModel, opts.modelRegistry, opts.cwd, prev, relaySpec) : null)
				?? contextBudgetReject(params.task, effModel, opts.modelRegistry);
		} else {
			// ev-20260910-2899d3：携带 prev → 拒单文案后接自动接力包（四要素盘点 + 可复制 fresh 任务书）
			_rbReject = resumeBudgetReject(prev.sessionId, effModel, opts.modelRegistry, opts.cwd, prev, relaySpec);
		}
		if (_rbReject) {
			if (!opts.skipLease) registry.releaseLease(leaseSid);
			// ev-20261002-c2b7ad：接力包产物化——拒单消息是一过性错误文本，写盘 agent-outs 可回溯
			// （同任务幂等覆盖；失败降级为仅消息展示，零故障放大防线）。
			let _relayPath: string | null = null;
			try { _relayPath = persistResumeRelayPack(prev, _rbReject); } catch { _relayPath = null; /* lint-exempt:产物化内部已降级，外层再兑一层防御——拒单零故障放大 */ }
			const _relaySuffix = _relayPath ? `\n[接力包已产物化] ${_relayPath}（拒单消息沉入历史后仍可回读；task_submit 草稿见上）` : "";
			return rejectedResume(_rbReject + _relaySuffix, _rbReject);
		}
	}
	if (isProviderBreakerEnabled()) {
		const _cbProvider = providerOfSpec(effModel);
		const _cb = providerBreakerCheck(_cbProvider);
		if (_cb.open && !_cb.probe) {
			if (!opts.skipLease) registry.releaseLease(leaseSid);
			return rejectedResume("", `[熔断] provider "${_cbProvider}" 连续 ${_cb.consecutiveFailures} 次瞬时故障，断路器 Open（约 ${Math.ceil((_cb.retryAfterMs ?? 0) / 1000)}s 后半窗探针自动恢复）。稍候重试 resume / 换模型 / AMAGI_CB_ENABLED=0 关闭`);
		}
	}
	registry.appendRound(prev.taskId, { task: params.task, at: Date.now(), model: effModel });
	// A4: resume 发起时把原 blocked 记录迁移状态（防待答队列重复显示已作答项）
	const prevTaskId = prev.taskId;
	// ── K5b（方案 §3.4-N6/§8.1-K5b）：resume 链父任务状态迁移走内核真实命令 ──────
	// blocked→answering = begin-resume（session lease 防并发续接，只启动一个）；
	// answering→answered/-blocked = finish-resume（answered 携 successorTaskId 记父链）。
	// 内核未持有父任务（v2 前遗留会话）→ registry.patch legacy 兼容入口（桥种子收编后仍转译为
	// 同款内核命令；未安装桥的纯 v1 环境保持直写——降级语义见 K5b 报告）。
	// v2 批次B 语义保留：迁移延后到准入晋级后——排队期间父任务保持 blocked 待答语义，
	// 看板/待答队列不丢项；排队取消时无需恢复（从未离开 blocked）。
	const parentWasBlocked = prev.status === "blocked";
	// lease nonce：普通 resume 每次调用唯一（N6 并发续接竞争；同 holder+nonce 重复 begin 幂等）；
	// fork（skipLease）按父任务稳定——多枝并发 begin 同 lease 幂等 no-op（各枝独立 sessionFile，
	// 无共享续接风险，不参与 lease 竞争，与旧桥固定 nonce 语义对齐）。
	const resumeLeaseNonce = opts.skipLease ? `fork-${prevTaskId}` : `resume-${randomUUID()}`;
	const parentKernelView = () => {
		const kernel = peekTaskKernel();
		const view = kernel?.get(prevTaskId);
		return kernel && view ? { kernel, view } : undefined;
	};
	/** blocked→answering（内核 begin-resume；N6 lease 防并发续接）。lease 被占（父任务已在
	 *  answering/异 nonce 租约竞争胜者）→ 拒绝本次续接（只启动一个）；父任务已离开 blocked
	 *  （被取消/外部处置等）→ 容忍放行（子任务独立生命周期，取消父记录不冒充取消子记录——
	 *  旧 _markParentAnswering 吞错语义保持）。 */
	const beginParentAnswering = async (): Promise<{ ok: boolean; message: string }> => {
		if (!parentWasBlocked) return { ok: true, message: "" };
		const pk = parentKernelView();
		if (pk) {
			if (pk.view.execution === "answering") {
				return { ok: false, message: `resume session lease 被占用（父任务已在 answering——N6 并发续接拒绝，只启动一个）` };
			}
			const r = await pk.kernel.apply({
				type: "begin-resume",
				key: { ownerId: pk.view.ownerId, taskId: prevTaskId, revision: pk.view.revision },
				lease: { holder: "amagi-resume", nonce: resumeLeaseNonce, at: Date.now() },
			});
			if (r.ok) return { ok: true, message: "" };
			if (/lease/i.test(r.error.message)) return { ok: false, message: `resume session lease 被占用（N6 并发续接拒绝）：${r.error.message}` };
			// 非 lease 拒绝（取消/外部处置竞态——父任务已离开 blocked）：子任务独立生命周期，放行并留痕
			console.error(`[amagi-resume] begin-resume 未采纳（${prevTaskId.slice(0, 8)}，父任务 ${pk.view.execution}）：${r.error.message}`);
			return { ok: true, message: "" };
		}
		// legacy 兼容：内核未持有父任务（v2 前会话）——registry.patch（桥已安装时种子收编后同命令语义）
		const cur0 = registry.get(prevTaskId);
		if (cur0 && cur0.status === "answering") {
			return { ok: false, message: `resume session lease 被占用（父任务已在 answering——N6 并发续接拒绝，只启动一个）` };
		}
		try {
			registry.patch(prevTaskId, { status: "answering" });
			return { ok: true, message: "" };
		} catch (e) {
			const after = registry.get(prevTaskId)?.status;
			if (after && after !== "blocked" && after !== "answering") {
				// 已离开 blocked（终态/迁移中）：容忍放行（同内核分支语义）
				console.error(`[amagi-resume] 父任务迁移 answering 未采纳（${prevTaskId.slice(0, 8)}，状态 ${after}）：${registryErrorEcho(e)}`);
			return { ok: true, message: "" };
			}
			return { ok: false, message: registryErrorEcho(e) };
		}
	};
	/** answering→answered（spawn 确认；successorTaskId=续接子任务父链）/ answering→blocked（启动失败
	 *  恢复待答）。父任务不在 answering（未迁移/已被取消等）→ no-op false（与旧 patch 失败吞错语义一致）。 */
	const finishParentResume = (outcome: "answered" | "blocked", reason: string): boolean => {
		if (!parentWasBlocked) return true;
		const pk = parentKernelView();
		if (pk) {
			if (pk.view.execution !== "answering") return false;
			// apply 的同步提交段（内存权威 + registry 投影）在调用内同步生效，存储 CAS 异步收尾
			//（失败经内核 degraded 视图可见，K8a 对账收敛）——保持 onSpawn/终局回调同步签名。
			const p = pk.kernel.apply({
				type: "finish-resume",
				key: { ownerId: pk.view.ownerId, taskId: prevTaskId, revision: pk.view.revision },
				outcome,
				reason,
				...(outcome === "answered" ? { successorTaskId: newTaskId } : {}),
			});
			void p.then((r) => {
				if (!r.ok) console.error(`[amagi-resume] finish-resume(${outcome}) 未采纳（${prevTaskId.slice(0, 8)}）：${r.error.message}`);
			}, () => {});
			return pk.kernel.get(prevTaskId)?.execution === outcome;
		}
		try {
			const r = registry.patch(prevTaskId, { status: outcome });
			return r?.status === outcome;
		} catch {
			return false;
		}
	};
	let tmpDir: string | null = null, tmpFile: string | null = null;
	let cleaned = false;
	let spawnConfirmed = false;
	// diting 增审 Major-3：handoff 的 resume 同样消费父待处理态——真实 spawn 确认后走与
	// questions 相同的 answering→answered 迁移（answered=待处理态已被 resume 消费的归档语义，
	// blockReason 保留供 UI 中性展示「待接手」）。否则父记录永久 blocked：continuation 永久重复
	// resume 指令、task wait 永久 blocked、重启 snapshot 保留待处理态。spawn 前失败仍由
	// restoreParentBlocked 恢复 blocked 等待（answering→blocked 合法转换）。
	// C3-R4-A: 仅真实 child `spawn` 事件确认后消费父任务答案。
	const confirmParentAnswered = () => {
		if (!parentWasBlocked) { spawnConfirmed = true; return; }
		// K5b：answering→answered 走内核 finish-resume（successorTaskId 记父链）；未采纳时保持
		// 未确认，finalize 将保守恢复 blocked。
		spawnConfirmed = finishParentResume("answered", `resume spawn 确认（successor=${newTaskId.slice(0, 8)}）`);
	};
	const wrappedFinalize = (r: any) => {
		if (cleaned) return;
		cleaned = true;
		if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, `resume ${r.status}`, newTaskId);
		releaseAdmission(newTaskId); // v2 批次B：终局归还准入槽位（once 守卫配平，恰好一次）
		if (!opts.skipLease) registry.releaseLease(leaseSid);
		// C3-R4-A: spawn 前的异步 error 也会走 finalize；此时必须恢复待答，
		// 不得在终态回调中无条件迁移 answered。
		if (parentWasBlocked && !spawnConfirmed) restoreParentBlocked();
		// diting n-3：background resume 的完成回调 payload 由 task-run finalize 构造（无 modelNote 字段），
		// 而归一注记在 spawn 时只挂到 BackgroundStart（_launch 的 _rr）——完成通知要回显同一注记，需在此补齐；
		// sync 路径的返回值对象另行挂载（下方 _rr.modelNote），此处 !r.modelNote 守卫避免覆盖既有值。
		if (r && typeof r === "object" && !r.modelNote && modelNote) r.modelNote = modelNote;
		try { opts.onComplete?.(r); } catch {}
		if (tmpFile) try { fs.unlinkSync(tmpFile); } catch {}
		if (tmpDir) try { fs.rmdirSync(tmpDir); } catch {}
	};
	// C3-R: 启动失败恢复父任务 blocked（保留问题/答案在队列）——K5b：内核 finish-resume outcome=blocked
	//（父任务不在 answering 时为 no-op，与旧 patch 失败吞错语义一致）。
	const restoreParentBlocked = () => {
		finishParentResume("blocked", "resume 启动失败恢复待答（finish-resume outcome=blocked）");
	};
	// ── K5b：续接子任务走 K5a 统一 submit 面（submitTaskKernel：归一化 → 冻结真实 TaskSpec →
	// 内核 register，saveSpec+current 清单落盘成功才继续；清单失败封闭：不占槽、不 spawn）。
	// relation.parentTaskId 记父链（编排已显式指定 DAG 父时保留，否则缺省续接会话原任务）；
	// allowedPaths 继承原任务派发时快照（ev-20260909-1af2ca）——权限不超父任务，不因旧会话缺字段提升保证。
	let dispatchRevision = 0;
	// 现代父任务从已复核的同源 spec 继承授权与 outputs（包括明确空声明）；真正历史/底层
	// legacy/fork 保留内核同步读取，不新增建档前 await。注入幂等（标记锚点）。
	const parentGrant = parentSpec && isEnforceablePermissionGrant(parentSpec.permission) ? parentSpec.permission
		: peekTaskKernel()?.frozenPermissionOf(prevTaskId)
			?? (registry.get(prevTaskId) === undefined ? await getFrozenPermissionGrant(prevTaskId) : undefined);
	const parentOutputs = parentSpec?.outputs ?? peekTaskKernel()?.frozenOutputsOf(prevTaskId);
	const resumeTask = parentOutputs !== undefined ? appendDeclaredOutputsSection(params.task, parentOutputs, { cwd: opts.cwd || process.cwd() }) : params.task;
	const resumeCwd = opts.cwd || prev.cwd || process.cwd();
	const messageRefs = extractArtifactRefs(params.task) || [];
	// 展示/交接只继承直接父任务；错误产物判定仍排除完整旧基线，不能冒认历史文件为本轮产物。
	const resumeRefs = uniqueArtifactRefs([...messageRefs, ...taskContextArtifactRefs(prevTaskId, prev.artifactRefs || [], prev.upstreamArtifactRefs || [], resumeCwd)], resumeCwd);
	const baselineRefs = uniqueArtifactRefs([...(prev.artifactRefs || []), ...messageRefs], resumeCwd);
	// ev-20261031-561b9d：并行写入者扫描 cwd 与 submitTaskKernel 同源（opts.cwd || process.cwd()）——
	// 不沿用 resumeCwd 的 prev.cwd 回退（那是 artifact 归一口径），保证「同 cwd」判定与实际 spawn cwd 一致。
	const _scanCwd = opts.cwd || process.cwd();
	try {
		const _subP = submitTaskKernel({
			taskId: newTaskId,
			agent: agent.name,
			assignment: resumeTask,
			contextMode: parentSpec?.contextMode ?? peekTaskKernel()?.get(prevTaskId)?.spec.contextMode ?? "isolated",
			goal: params.task,
			cwd: opts.cwd || process.cwd(),
			model: effModel,
			mode: params.background ? "background" : "sync",
			relation: { ...opts.relation, parentTaskId: opts.relation?.parentTaskId ?? prevTaskId },
			allowedPaths: prev.allowedPaths,
			artifactRefs: resumeRefs,
			upstreamArtifactRefs: resumeRefs,
			...(parentGrant !== undefined ? { permission: parentGrant } : {}),
			...(parentOutputs !== undefined ? { outputs: parentOutputs } : {}),
			...(opts.worktreeDispatch !== undefined ? { worktreeDispatch: opts.worktreeDispatch } : {}),
		});
		// 内核 register 同步前缀已建档（内存态+投影）——与 K5a 同语义，在 await 前同步定格登记时刻
		// revision 作为 dispatch stale 基线（store 提交等待窗口内的取消会 bump revision，但不得改写本值）。
		dispatchRevision = registry.get(newTaskId)?.revision ?? 0;
		const _sub = await _subP;
		if (!_sub.ok) throw new Error(_sub.message);
		// T2-3c: newTaskId 记本次 resume 轮次（patch rounds 受 PATCHABLE 白名单限制，用 appendRound 专用方法；
		// 使 trace 的 resumeRounds/mode 与回流升档判定能感知"resume 过"）
		try { registry.appendRound(newTaskId, { task: params.task, at: Date.now(), model: effModel }); } catch {}
		// P0.5：resume 轮次同样 journal 留痕（中断后有迹可循；中断恢复时 resume 任务也是"在途"）
		journalDispatch({ taskId: newTaskId, agent: agent.name, name: prev.name, goal: params.task, cwd: opts.cwd || process.cwd(), mode: params.background ? "background" : "sync", model: effModel, ...opts.relation });
	} catch (e) {
		if (!opts.skipLease) registry.releaseLease(leaseSid);
		restoreParentBlocked();
		return makeErrorResult(newTaskId, agent, "", `resume 启动失败: ${String(e)}`, sessionName, `resume 启动失败: ${String(e)}`);
	}
	// v2 批次B 共享准入（K5b 对齐 K5a：清单落盘成功后才占槽——按 resume 实际 effModel 的 provider/model 分池）；
	// queued 时排队等待，父任务 answering 迁移与 spawn 都延后到晋级之后（排队期间父任务保持 blocked）。
	const _occ = tryOccupy(newTaskId, { modelSpec: effModel, cwd: opts.cwd });
	// 启动闭包：args/prompt tmp 在晋级时刻构建（排队期间不落盘临时文件）。
	const _launch = async (): Promise<RunResult | BackgroundStart> => {
		// 构造 --session args
		// C1: useFork 时用 --fork（真实分叉，各枝独立 sessionFile）；否则 --session（续接）
		const sessionFlag = params.useFork ? "--fork" : "--session";
		const args = [sessionFlag, prev.sessionId!, "--mode", "json", "-p", "--name", sessionName];
		try {
			// v2.15.0 大发射守卫 · prompt 层（与 fresh 派发同款）：resume 续轮新起 pi 进程——effModel
			// provider 命中 riskyProviders 时同样追加大发射纪律分节（不命中零注入零字节）。
			const _emissionLine = largeEmissionDisciplineLine(providerOfSpec(effModel), opts.cwd);
			const _systemPrompt = _emissionLine ? `${agent.systemPrompt}\n\n## 大发射纪律（通道适配）\n${_emissionLine}` : agent.systemPrompt;
			if (_systemPrompt.trim()) { const tmp = await writePromptTmp(agent.name, _systemPrompt); tmpDir = tmp.dir; tmpFile = tmp.file; args.push("--append-system-prompt", tmpFile); }
			args.push("--tools", resolveAgentTools(agent, opts.cwd).join(","));
			if (effModel) args.push("--model", effModel);
			// ev-20260914-ce6bd2：resume 续轮同款 argv 降级——反馈任务书拼装后 >128KB 全文落盘
			// <cwd>/amagi-task/<newTaskId>/goal-full.md，>900KB 硬上限拒单（E2BIG 防线）。
			// ev-20260920-61839b：续接轮同样携带产物落位注入段（resumeTask = params.task + 继承契约段）
			// ev-20261031-561b9d：续轮并行写入者刷新——resume 原只带派发时刻快照（或无），同 cwd 兄弟
			// 列表可能已失真。晋级/spawn 时刻用现有入口重算（与 fresh 派发同语义同上限；排除自身与
			// 父任务——父任务此刻 answering 属活跃态但不是新写入者），无并行写入者时零注入。
			const _regRecs = registry.list();
			const _parallelNote = resumeParallelWritersNote(
				collectSiblingWriterLabels(_scanCwd, newTaskId, _regRecs.filter((r) => r.taskId !== prevTaskId)),
				collectCrossSessionWriterLabels(_scanCwd, [newTaskId, prevTaskId, ..._regRecs.map((r) => r.taskId)]),
			);
			const _finalPrompt = `反馈：${resumeTask}${(prev.allowedPaths && prev.allowedPaths.length > 0) ? whitelistOverflowContractBlock() + anchoredResourceDisciplineBlock(prev.allowedPaths) : ""}${_parallelNote ? `\n\n${_parallelNote}` : ""}${SHARED_TREE_DISCIPLINE}${DONE_CONTRACT_REMINDER}`;
			const _pp = planTaskPrompt(_finalPrompt, opts.cwd, newTaskId);
			if (_pp.action === "reject") {
				restoreParentBlocked();
				return finalizeLaunchFailure(newTaskId, agent, sessionName, _pp.reason ?? "任务书超硬上限", wrappedFinalize);
			}
			if (_pp.action === "offload") {
				try { applyTaskPromptOffload(_pp, _finalPrompt); } catch (e) {
					restoreParentBlocked();
					return finalizeLaunchFailure(newTaskId, agent, sessionName, `任务书落盘降级失败: ${String(e)}`, wrappedFinalize);
				}
				args.push(_pp.prompt);
			} else {
				args.push(_finalPrompt);
			}
		} catch (e) {
			restoreParentBlocked();
			return finalizeLaunchFailure(newTaskId, agent, sessionName, `prompt tmp 失败: ${String(e)}`, wrappedFinalize);
		}
		// 调用统一管线
		try {
			// ev-20260909-1af2ca：调 runPiTask 传入 allowedPaths: prev.allowedPaths（继承边界；原任务无白名单为 undefined 保持无边界）
			const _rr = await runPiTask(agent, args, { cwd: opts.cwd, model: effModel, signal: opts.signal, timeoutMs: opts.timeoutMs, command: opts.command, background: params.background, onStall: opts.onStall, onSpawn: confirmParentAnswered, onFinalize: wrappedFinalize, dispatchTime: Date.now(), dispatchRevision, taskCategory: classifyTask(params.task), baselineArtifactRefs: baselineRefs, fuseWarn: fuseWarningFor(agent.name, effModel, classifyTask(params.task)), allowedPaths: prev.allowedPaths, ...(parentOutputs && parentOutputs.length > 0 ? { declaredOutputPaths: parentOutputs.map((o) => o.path) } : {}) }, newTaskId, sessionName);
			if (modelNote && _rr && typeof _rr === "object") (_rr as RunResult).modelNote = modelNote;
			return _rr;
		} catch (e) {
			restoreParentBlocked();
			return finalizeLaunchFailure(newTaskId, agent, sessionName, `resume 异常: ${String(e)}`, wrappedFinalize);
		}
	};
	if (_occ === "queued") {
		// K5a 同型窗口防护（Leader 补齐）：清单落盘（异步 store 提交）与占槽之间被取消——记录已 cancelled
		// 时不入队等待/不 spawn，出队 + 归还槽位后按取消收口（否则 waiter 永不被 resolve：cancelTask 已
		// 先于 tryOccupy 执行，无人再 cancelQueued）。
		if (registry.get(newTaskId)?.status === "cancelled") {
			if (_occ === "queued") cancelQueued(newTaskId);
			releaseAdmission(newTaskId);
			if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, "resume cancelled before admission", newTaskId);
			restoreParentBlocked();
			try { if (!opts.skipLease) registry.releaseLease(leaseSid); } catch { /* lease 归还尽力 */ }
			return { taskId: newTaskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, errorMessage: "任务在排队等待执行槽位时被取消", completionAnnotation: "", dispatchRevision };
		}
		// 晋级后统一收口：cancelled → wrappedFinalize（lease/槽位归还 + background onComplete 通知）；
		// running → 父任务 begin-resume（answering）+ 内核 grant-start + 启动。父任务排队全程保持 blocked。
		const _afterGrant = async (): Promise<RunResult | BackgroundStart | null> => {
			const grant = await waitForGrant(newTaskId);
			const rec = registry.get(newTaskId);
			if (grant !== "running" || !rec || rec.status === "cancelled") {
				releaseAdmission(newTaskId); // 已晋级但 record 被取消：回收槽位（与 wrappedFinalize 的 release 幂等）
				wrappedFinalize({ taskId: newTaskId, agent: agent.name, status: "cancelled", output: "", blocked: false, errorMessage: "任务在排队等待执行槽位时被取消", completionAnnotation: "", dispatchRevision });
				return null;
			}
			// K5b：父任务 blocked→answering 走内核 begin-resume（N6 lease）；被占 → 本次续接封闭
			//（不 spawn、未启动的排队子记录显式取消收口、槽位/lease 归还——只启动一个）。
			const _ba = await beginParentAnswering();
			if (!_ba.ok) {
				try { cancelTask(newTaskId, `resume 续接被拒：${_ba.message}`); } catch {}
				return finalizeLaunchFailure(newTaskId, agent, sessionName, `resume 续接被拒（未 spawn）：${_ba.message}`, wrappedFinalize);
			}
			// K5b：晋级 = 内核 grant-start 命令（launchIntent 持久化先于 spawn，K5a 同语义）；失败封闭不 spawn。
			const _gs = await grantStartTask(newTaskId);
			if (!_gs.ok) {
				restoreParentBlocked();
				return finalizeLaunchFailure(newTaskId, agent, sessionName, `resume 晋级启动失败（未 spawn）：${_gs.message}`, wrappedFinalize);
			}
			try { registry.patch(newTaskId, { queueMs: Date.now() - (rec.queuedAt || Date.now()) }); } catch {}
			return _launch();
		};
		if (params.background) {
			void _afterGrant().catch((e) => {
				if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, "resume queued launch exception", newTaskId);
				restoreParentBlocked();
				finalizeLaunchFailure(newTaskId, agent, sessionName, `续接排队后启动异常: ${String(e)}`, wrappedFinalize);
			});
			return { taskId: newTaskId, agent: agent.name, status: "queued", sessionName, modelNote, fuseWarning: fuseWarningFor(agent.name, effModel, classifyTask(params.task)) };
		}
		// sync resume 排队：登记 sync-wait 等待晋级（防主进程活性看门狗误杀），晋级后同 sync 流程。
		beginSyncWait();
		try {
			const r = await _afterGrant();
			if (r) return r;
			return { taskId: newTaskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, errorMessage: "任务在排队等待执行槽位时被取消", completionAnnotation: "", dispatchRevision };
		} finally { endSyncWait(); }
	}
	// 立即占槽：父任务 begin-resume（N6 lease）→ 内核 grant-start（launchIntent 先于 spawn）→ 启动。
	const _ba = await beginParentAnswering();
	if (!_ba.ok) {
		try { cancelTask(newTaskId, `resume 续接被拒：${_ba.message}`); } catch {}
		return finalizeLaunchFailure(newTaskId, agent, sessionName, `resume 续接被拒（未 spawn）：${_ba.message}`, wrappedFinalize);
	}
	const _gs = await grantStartTask(newTaskId);
	if (!_gs.ok) {
		restoreParentBlocked();
		return finalizeLaunchFailure(newTaskId, agent, sessionName, `resume 启动意图持久化失败（未 spawn）：${_gs.message}`, wrappedFinalize);
	}
	{ const _q = registry.get(newTaskId); if (_q?.queuedAt) { try { registry.patch(newTaskId, { queueMs: Date.now() - _q.queuedAt }); } catch {} } }
	return _launch();
}
