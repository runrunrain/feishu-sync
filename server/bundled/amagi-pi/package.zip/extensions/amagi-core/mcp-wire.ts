/**
 * mcp-wire.ts — P1（寄生增强方案 §3.2，pi-0.99.1 批 W2 首片）：MCP wire 家族结构契约。
 *
 * 本模块是**纯 schema/投影模块**（沿 task-query-wire.ts 同族纪律）：只定义 mcp_call /
 * mcp_list_tools 两工具四个封闭 wire 分支的 TypeBox schema，与从「调用方提供的远端结果 /
 * 发现数据 / 错误」到 wire 形状的 JSON-safe 投影。transport 接线由 mcp-client 承担；
 * 本模块不 import mcp-client（零 transport/权限副作用）——投影源用本地结构化接口，
 * 与 mcp-client 真实形状锚定（McpCallResult :347-351、McpDiscoveredTool :355-360）。
 * 纪律（§3.2/§3.3）：零 I/O（无 fs/进程/store 写）、零宿主私有依赖（仅 typebox +
 * task-query-wire 纯导出）；自由文本脱敏**复用** task-query-wire 的 redactCredentials
 * （同源不复制实现，§3.3「复用 task-query-wire.ts:622–654 的 redactCredentials 规则」）。
 *
 * wire 身份（§3.2 判据 = kind + wireVersion + ok + schemaVersion；**与工具面 surfaceVersion
 * 无关——本家族不携带 surfaceVersion 字段**）：kind="amagi.mcp-call" / "amagi.mcp-list"
 * （独立 wire 家族，共用构造/脱敏方法，不复用 task_query 的 URN 或版本字段语义）、
 * call wireVersion=2、schemaVersion=2；list 保持 1。四 URN 分支：
 *   urn:amagi:mcp-call:result:2 / urn:amagi:mcp-call:error:2
 *   urn:amagi:mcp-list:result:1 / urn:amagi:mcp-list:error:1
 * v1 冻结字段集合；增删字段或改语义先升 schemaVersion。
 *
 * input/output schema 区分（§2.2 纠偏 + §3.2）：远端工具 inputSchema 只是调用参数说明缓存
 * （mcp-client.ts:355-360 McpDiscoveredTool 现有字段，list 分支以开放槽原样投影）；远端
 * outputSchema（若 server 提供）**单独采集**——list 分支每工具独立 outputSchema 槽（JSON
 * object 或 null，不可信 schema 数据——只声明发现，不动态替换宿主 mcp_call 定义）；call 分支
 * 只携带 schemaSource=remote-output/none（是否发现远端输出声明，**不表示本地已验证符合声明**）。
 *
 * 封闭与开放槽：amagi 定义的结构字段全封闭（additionalProperties:false + 全键 required）；
 * 远端返回内容（structuredContent 副本、input/outputSchema 对象、repairExamples 条目）是
 * **开放远端 JSON 槽**——严格 JSON-safe（不接受 undefined/NaN/Infinity/函数/symbol/bigint/
 * 类实例/循环引用）。纪律差异（有意）：structuredContent **整树**无法安全转换则
 * payloadState=invalid、不做部分拷贝（§3.2「合法结构保持完整……不能切坏 JSON」）；repairExamples
 * 按条目整取整弃（非 JSON-safe 条目剥除——缺样例比残缺样例诚实，沿 task-query-wire
 * toFailureWire 的条目级剥除）。开放槽递归字符串值过 redactCredentials（§3.3「凭据 sentinel
 * 必须覆盖嵌套字符串与错误」）；结构字段（name/枚举/字节数/dumpPath 等字面身份）不脱敏。
 * payloadBytes 对**wire 内已脱敏副本**计数（可复核不变式：payloadBytes =
 * Buffer.byteLength(JSON.stringify(remoteStructured))；无法编码或无 payload 时 null）。
 *
 * 错误分类（§3.2 code 固定五值）：
 *   shape      调用参数错形（预 transport，零副作用）
 *   permission 权限拒绝（checkMcpCallPermission 语义——预 transport，零副作用）
 *   remote     远端已应答的错误（McpRpcError / McpGatewayError / McpBusinessAuthError 语义：
 *              JSON-RPC error、result.isError 业务错、网关非 JSON-RPC 业务体）
 *   transport  未获远端协议应答的通道失败（超时/abort/会话认证/HTTP 状态/stdio 退出）
 *   internal   兜底异常
 * classifyMcpWireError 按 Error.name/消息形态识别——纯模块不 import mcp-client 类；name 字段
 * 在 Error 子类实例上稳定存在（锚点 mcp-client.ts:88-110），超时/stdio 文案与 mcp-client
 * 现行实现锚定；P2 接线时可直接传入真实异常实例。
 */
import { Type, type TSchema } from "typebox";
import { redactCredentials } from "./task-query-wire.ts";

// ── wire 身份常量（§3.2 固定字面量；P2 接线与测试共用） ──────────────────────────

export const MCP_WIRE_CALL_KIND = "amagi.mcp-call";
export const MCP_WIRE_LIST_KIND = "amagi.mcp-list";
export const MCP_WIRE_VERSION = 1;
export const MCP_SCHEMA_VERSION = 1;
/** call v2 增加原生 image blocks；list 与历史会话继续保持 v1。 */
export const MCP_CALL_WIRE_VERSION = 2;
export const MCP_CALL_SCHEMA_VERSION = 2;

/** 四分支 schema 标识（§3.2：call/list 各 result/error 两分支）。 */
export const MCP_WIRE_URNS = {
	callResult: "urn:amagi:mcp-call:result:2",
	callError: "urn:amagi:mcp-call:error:2",
	listResult: "urn:amagi:mcp-list:result:1",
	listError: "urn:amagi:mcp-list:error:1",
} as const;

/** 错误 code 封闭枚举（§3.2「code 固定为 shape/permission/remote/transport/internal」）。 */
export const MCP_WIRE_ERROR_CODES = ["shape", "permission", "remote", "transport", "internal"] as const;
export type McpWireErrorCode = (typeof MCP_WIRE_ERROR_CODES)[number];

/** structuredContent 三态（§3.2：absent / available / invalid；available 可以是合法 JSON null——以状态消歧）。 */
export const MCP_PAYLOAD_STATES = ["absent", "available", "invalid"] as const;
export type McpPayloadState = (typeof MCP_PAYLOAD_STATES)[number];

/** 远端输出声明来源（§3.2：remote-output / none——只表示是否发现远端输出声明）。 */
export const MCP_SCHEMA_SOURCES = ["remote-output", "none"] as const;
export type McpSchemaSource = (typeof MCP_SCHEMA_SOURCES)[number];

/** list 分支 server 发现状态（§3.2：cached / live / error）。 */
export const MCP_SERVER_STATUSES = ["cached", "live", "error"] as const;
export type McpServerDiscoveryStatus = (typeof MCP_SERVER_STATUSES)[number];

// ── 共享子 schema（全部 additionalProperties:false + 全键 required；无 $id——分支根才有） ──

/** n：非负安全整数。 */
const NonNegativeSafeInt = Type.Integer({ minimum: 0, maximum: Number.MAX_SAFE_INTEGER });

/** string | null（带字段说明）。 */
function nullableString(description: string) {
	return Type.Union([Type.String(), Type.Null()], { description });
}

/** 开放远端 JSON 槽的递归 JSON Schema（$defs 挂分支根——同 task-query-wire error 分支手法）。 */
const JSON_SAFE_DEFS = {
	jsonValue: {
		anyOf: [
			{ type: "null" },
			{ type: "boolean" },
			{ type: "number" },
			{ type: "string" },
			{ type: "array", items: { $ref: "#/$defs/jsonValue" } },
			{ type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
		],
	},
	jsonObject: { type: "object", additionalProperties: { $ref: "#/$defs/jsonValue" } },
};
const JsonValueRef = { $ref: "#/$defs/jsonValue" } as unknown as TSchema;
const JsonObjectRef = { $ref: "#/$defs/jsonObject" } as unknown as TSchema;

const McpWireErrorCodeSchema = Type.Union(
	MCP_WIRE_ERROR_CODES.map((c) => Type.Literal(c)),
	{ description: "shape/permission/remote/transport/internal（§3.2 固定五值）" },
);

/** call 分支 data：v1 文本/结构字段与 v2 原生 images。 */
export const McpCallDataSchema = Type.Object({
	text: Type.String({ description: "同次内容转换/截断后的结果文本（自由文本——已过 redactCredentials）" }),
	images: Type.Array(Type.Object({
		type: Type.Literal("image"),
		data: Type.String(),
		mimeType: Type.String(),
	}, { additionalProperties: false }), { description: "已通过当前模型能力与图片处理检查的原生 image blocks；codemode 用 image(data.images[i]) 转交，勿 text/日志打印图片数据" }),
	textTruncated: Type.Boolean({ description: "text 是否经现行 MCP 截断（truncateMcpText 同次口径）" }),
	textDumpPath: nullableString("截断落盘路径；null=未落盘（不自动另写结构文件）"),
	remoteStructured: Type.Union([JsonObjectRef, Type.Null()], { description: "远端 structuredContent 的 JSON-safe 副本（开放远端 JSON 槽）或 null（absent/invalid；available-null 以 payloadState 消歧）" }),
	payloadState: Type.Union(MCP_PAYLOAD_STATES.map((s) => Type.Literal(s)), { description: "absent=远端无 structuredContent；available=合法载荷（可以是合法 JSON null）；invalid=无法安全转换（不做部分拷贝）" }),
	payloadBytes: Type.Union([NonNegativeSafeInt, Type.Null()], { description: "成功 JSON 编码的 UTF-8 字节数（对 wire 内已脱敏副本计数）；无法编码或没有 payload 时 null" }),
	schemaSource: Type.Union(MCP_SCHEMA_SOURCES.map((s) => Type.Literal(s)), { description: "是否发现远端输出声明——不表示本地已验证符合声明" }),
}, { additionalProperties: false, description: "mcp_call 成功分支 data（§3.2 固定返回字段草案）" });

/** annotations 四布尔 hint（§3.2 list data 行：缺省 null——不臆造）。 */
export const McpAnnotationsHintsSchema = Type.Object({
	readOnlyHint: Type.Union([Type.Boolean(), Type.Null()]),
	destructiveHint: Type.Union([Type.Boolean(), Type.Null()]),
	idempotentHint: Type.Union([Type.Boolean(), Type.Null()]),
	openWorldHint: Type.Union([Type.Boolean(), Type.Null()]),
}, { additionalProperties: false, description: "MCP 协议工具注解四布尔 hint（readOnlyHint 是只读执法的唯一性质证据来源）" });

/** list 分支工具条目（§3.2：name/description/inputSchema/outputSchema/annotations 四 hint）。 */
export const McpListToolSchema = Type.Object({
	name: Type.String({ description: "远端工具名（mcp_call 的 tool 合法值）" }),
	description: nullableString("远端描述（自由文本——已过 redactCredentials）；无/非字符串为 null"),
	inputSchema: Type.Union([JsonObjectRef, Type.Null()], { description: "远端输入 schema——仅调用参数说明缓存（开放槽，非封闭业务 schema）" }),
	outputSchema: Type.Union([JsonObjectRef, Type.Null()], { description: "远端输出 schema——单独采集的不可信 schema 数据（开放槽；旧发现缓存缺该字段合法 → null）" }),
	annotations: McpAnnotationsHintsSchema,
}, { additionalProperties: false, description: "发现面工具条目（仅权限过滤后的可见集，§3.2）" });

/** list 分支 server 条目（§3.2：name/状态 cached-live-error/observedAt/tools/error）。 */
export const McpListServerEntrySchema = Type.Object({
	name: Type.String(),
	status: Type.Union(MCP_SERVER_STATUSES.map((s) => Type.Literal(s)), { description: "发现状态：cached=缓存 / live=实时发现 / error=发现失败" }),
	observedAt: Type.Union([NonNegativeSafeInt, Type.Null()], { description: "发现/缓存时间（epoch ms）；未知 null——不编造刷新时间" }),
	tools: Type.Array(McpListToolSchema, { description: "权限过滤后的可见工具集（过滤掉哪些工具不进 wire——不是另一能力发现面）" }),
	error: nullableString("该 server 发现失败原因（自由文本——已过 redactCredentials）；无错误 null"),
}, { additionalProperties: false, description: "list 分支 server 条目" });

export const McpListDataSchema = Type.Object({
	servers: Type.Array(McpListServerEntrySchema, { description: "逐 server 发现数据（不新增 tool_search、不另造分页协议）" }),
}, { additionalProperties: false, description: "mcp_list_tools 成功分支 data" });

/** Failure 公共形状（code/message/effects/repairExamples + 按分支定型的 remoteResult）。 */
function failureSchemaOf(remoteResult: TSchema) {
	return Type.Object({
		code: McpWireErrorCodeSchema,
		message: Type.String({ description: "错误消息（自由文本——已过 redactCredentials）" }),
		effects: Type.String({ description: "失败副作用口径：none=预 transport 拒绝（shape/permission）；unknown=可能已执行（remote/transport/internal）。合法值由映射单源给出，schema 不枚举" }),
		repairExamples: Type.Array(JsonObjectRef, { description: "最小合法调用样例（JSON-safe 对象数组；非 JSON-safe 条目整条剥除，递归字符串已脱敏）" }),
		remoteResult,
	}, { additionalProperties: false, description: "失败分支 error（§3.2 error 行 + task-query-wire Failure 家族纪律）" });
}

// ── 四封闭分支（§3.2 逐字段；$id=各 URN；$defs 供开放槽 $ref 解析） ───────────────

/** mcp_call 成功分支：urn:amagi:mcp-call:result:2。 */
export const McpCallResultWireSchema = Type.Object({
	kind: Type.Literal(MCP_WIRE_CALL_KIND),
	wireVersion: Type.Literal(MCP_CALL_WIRE_VERSION),
	schemaVersion: Type.Literal(MCP_CALL_SCHEMA_VERSION),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	server: nullableString("已解析的 server 名或 null（输入非法不原样回显，§3.2）"),
	tool: nullableString("已解析的远端工具名或 null"),
	data: McpCallDataSchema,
}, { $id: MCP_WIRE_URNS.callResult, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "mcp_call 成功 wire（§3.2 call result 分支）" });

/** mcp_call 失败分支：urn:amagi:mcp-call:error:2。 */
export const McpCallErrorWireSchema = Type.Object({
	kind: Type.Literal(MCP_WIRE_CALL_KIND),
	wireVersion: Type.Literal(MCP_CALL_WIRE_VERSION),
	schemaVersion: Type.Literal(MCP_CALL_SCHEMA_VERSION),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	server: nullableString("已解析的 server 名或 null"),
	tool: nullableString("已解析的远端工具名或 null"),
	error: failureSchemaOf(Type.Union([McpCallDataSchema, Type.Null()], { description: "远端业务错时捕获的远端结果（与 data 同型）或 null" })),
}, { $id: MCP_WIRE_URNS.callError, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "mcp_call 工具内失败 wire（§3.2 call error 分支）" });

/** mcp_list_tools 成功分支：urn:amagi:mcp-list:result:1。 */
export const McpListResultWireSchema = Type.Object({
	kind: Type.Literal(MCP_WIRE_LIST_KIND),
	wireVersion: Type.Literal(MCP_WIRE_VERSION),
	schemaVersion: Type.Literal(MCP_SCHEMA_VERSION),
	ok: Type.Literal(true),
	isError: Type.Literal(false),
	data: McpListDataSchema,
}, { $id: MCP_WIRE_URNS.listResult, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "mcp_list_tools 成功 wire（§3.2 list result 分支）" });

/** mcp_list_tools 失败分支：urn:amagi:mcp-list:error:1。 */
export const McpListErrorWireSchema = Type.Object({
	kind: Type.Literal(MCP_WIRE_LIST_KIND),
	wireVersion: Type.Literal(MCP_WIRE_VERSION),
	schemaVersion: Type.Literal(MCP_SCHEMA_VERSION),
	ok: Type.Literal(false),
	isError: Type.Literal(true),
	error: failureSchemaOf(Type.Union([McpListDataSchema, Type.Null()], { description: "按 data 同型（list 失败通常无捕获载荷——null）" })),
}, { $id: MCP_WIRE_URNS.listError, $defs: JSON_SAFE_DEFS, additionalProperties: false, description: "mcp_list_tools 工具内失败 wire（§3.2 list error 分支）" });

/** 各工具注册面统一校验器（分支 Union；P2 接线挂 outputSchema，P1 只导出）。 */
export const McpCallOutputSchema = Type.Union(
	[McpCallResultWireSchema, McpCallErrorWireSchema],
	{ description: "amagi mcp_call 结构化输出 wire v2（两封闭分支：result/error；原生图片）" },
);
export const McpListOutputSchema = Type.Union(
	[McpListResultWireSchema, McpListErrorWireSchema],
	{ description: "amagi mcp_list_tools 结构化输出 wire v1（两封闭分支：result/error）" },
);

// ── wire 类型（与 schema 同形状的显式接口；一致性由 tests/mcp-wire.test.mjs 以
//    Value.Check（映射产物过 schema）+ 属性键静态对照双重断言） ────────────────────

export type JsonSafeValue = null | boolean | number | string | JsonSafeValue[] | { [key: string]: JsonSafeValue };
export type JsonSafeObject = { [key: string]: JsonSafeValue };

export interface McpCallDataWire {
	text: string;
	images: { type: "image"; data: string; mimeType: string }[];
	textTruncated: boolean;
	textDumpPath: string | null;
	remoteStructured: JsonSafeObject | null;
	payloadState: McpPayloadState;
	payloadBytes: number | null;
	schemaSource: McpSchemaSource;
}
export interface McpCallResultWire {
	kind: typeof MCP_WIRE_CALL_KIND;
	wireVersion: typeof MCP_CALL_WIRE_VERSION;
	schemaVersion: typeof MCP_CALL_SCHEMA_VERSION;
	ok: true;
	isError: false;
	server: string | null;
	tool: string | null;
	data: McpCallDataWire;
}
export interface McpWireFailureWire {
	code: McpWireErrorCode;
	message: string;
	effects: string;
	repairExamples: object[];
}
export interface McpCallErrorWire {
	kind: typeof MCP_WIRE_CALL_KIND;
	wireVersion: typeof MCP_CALL_WIRE_VERSION;
	schemaVersion: typeof MCP_CALL_SCHEMA_VERSION;
	ok: false;
	isError: true;
	server: string | null;
	tool: string | null;
	error: McpWireFailureWire & { remoteResult: McpCallDataWire | null };
}
export interface McpAnnotationsHintsWire {
	readOnlyHint: boolean | null;
	destructiveHint: boolean | null;
	idempotentHint: boolean | null;
	openWorldHint: boolean | null;
}
export interface McpListToolWire {
	name: string;
	description: string | null;
	inputSchema: JsonSafeObject | null;
	outputSchema: JsonSafeObject | null;
	annotations: McpAnnotationsHintsWire;
}
export interface McpListServerEntryWire {
	name: string;
	status: McpServerDiscoveryStatus;
	observedAt: number | null;
	tools: McpListToolWire[];
	error: string | null;
}
export interface McpListResultWire {
	kind: typeof MCP_WIRE_LIST_KIND;
	wireVersion: typeof MCP_WIRE_VERSION;
	schemaVersion: typeof MCP_SCHEMA_VERSION;
	ok: true;
	isError: false;
	data: { servers: McpListServerEntryWire[] };
}
export interface McpListErrorWire {
	kind: typeof MCP_WIRE_LIST_KIND;
	wireVersion: typeof MCP_WIRE_VERSION;
	schemaVersion: typeof MCP_SCHEMA_VERSION;
	ok: false;
	isError: true;
	error: McpWireFailureWire & { remoteResult: { servers: McpListServerEntryWire[] } | null };
}
export type McpCallWireOutput = McpCallResultWire | McpCallErrorWire;
export type McpListWireOutput = McpListResultWire | McpListErrorWire;

// ── 投影源（调用方提供的远端结果/发现数据/错误——本模块零 I/O，不读盘不碰 transport） ──

/** call 分支载荷字段（成功 data 与失败分支 remoteResult 共用同型投影）。 */
export interface McpCallPayloadFields {
	/** 同次内容转换文本（mcpResultText/contentToText 同次结果；非字符串映射 ""——映射不抛）。 */
	text: string;
	/** 调用层已准入的原生图片；此纯投影只复制协议字段，不重复解码。 */
	images?: readonly { type: "image"; data: string; mimeType: string }[];
	/** 同次截断事实（truncateMcpText 返回 truncated）；缺省 false。 */
	textTruncated?: boolean;
	/** 同次截断落盘路径；缺省 null（不自动另写结构文件）。 */
	textDumpPath?: string | null;
	/** 远端 structuredContent：属性缺席=absent；null=合法 JSON null（available——以状态消歧）；
	 *  对象经严格 JSON-safe 校验（非法整树 → invalid，不做部分拷贝）。 */
	structuredContent?: unknown;
	/** 是否发现该工具的远端输出声明（发现缓存 outputSchema 存在时 true；P2 经 McpDiscoveredTool
	 *  增量字段取得）。缺省 false → schemaSource=none。 */
	remoteOutputSchema?: boolean;
}

/** mcp_call 成功分支投影源（server/tool 只放已解析值——非法原值不回显，由调用方裁定后传入）。 */
export interface McpCallResultSource extends McpCallPayloadFields {
	server: string | null;
	tool: string | null;
}

/** 失败描述（两工具共用）。 */
export interface McpWireErrorSource {
	code: McpWireErrorCode;
	/** 原始消息（映射内脱敏；非字符串映射 ""——映射不抛）。 */
	message: string;
	/** 失败副作用口径：缺省按 code 推导（shape/permission→none；remote/transport/internal→unknown）。 */
	effects?: string;
	/** 最小合法调用样例；非 JSON-safe/非对象条目整条剥除（条目级纪律，见模块头）。 */
	repairExamples?: object[];
}

/** mcp_call 失败分支投影源（remoteResult=远端业务错时捕获的远端载荷，无则 null）。 */
export interface McpCallErrorSource {
	server: string | null;
	tool: string | null;
	error: McpWireErrorSource;
	remoteResult?: Readonly<McpCallPayloadFields> | null;
}

/** list 分支工具条目投影源（形状锚定 mcp-client.ts:355-360 McpDiscoveredTool；outputSchema 为
 *  §3.1 P2 计划增量——旧缓存缺该字段合法 → null）。 */
export interface McpListToolSource {
	name: string;
	description?: unknown;
	inputSchema?: unknown;
	outputSchema?: unknown;
	/** MCP 协议注解对象；四布尔 hint 各自独立投影（缺失/非布尔 → null，不臆造）。 */
	annotations?: unknown;
}

/** list 分支 server 条目投影源（tools 必须是权限过滤后的可见集——§3.2：不泄漏未授权能力）。 */
export interface McpListServerSource {
	name: string;
	status: McpServerDiscoveryStatus;
	/** 发现/缓存时间（epoch ms）；缺失/非法 → null（不编造刷新时间）。 */
	observedAt?: unknown;
	/** 缺失/非数组 → []。 */
	tools?: ReadonlyArray<Readonly<McpListToolSource>>;
	/** 发现失败原因；非字符串 → null。 */
	error?: unknown;
}

export interface McpListResultSource {
	servers: ReadonlyArray<Readonly<McpListServerSource>>;
}

/** mcp_list_tools 失败分支投影源（remoteResult 按 data 同型；list 失败通常 null）。 */
export interface McpListErrorSource {
	error: McpWireErrorSource;
	remoteResult?: Readonly<McpListResultSource> | null;
}

// ── JSON-safe 小件（严格整树纪律 + 递归脱敏投影） ─────────────────────────────

function isPlainObject(v: unknown): v is Record<string, unknown> {
	if (typeof v !== "object" || v === null) return false;
	const proto = Object.getPrototypeOf(v);
	return proto === Object.prototype || proto === null;
}

/** 严格 JSON-safe 深拷贝：**整树**合法才返回副本（远端载荷纪律——与 task-query-wire
 *  toJsonSafe 的剥除纪律不同：不做部分拷贝，无法安全转换即判 invalid）。不接受
 *  undefined/NaN/Infinity/函数/symbol/bigint/类实例；循环引用经路径栈检测（栈上重复即拒；
 *  DAG 共享——兄弟分支重复引用同一对象——放行，与 JSON.stringify 语义一致）。 */
function strictJsonSafeCopy(v: unknown, stack: Set<object>): { ok: true; value: JsonSafeValue } | { ok: false } {
	if (v === null) return { ok: true, value: null };
	switch (typeof v) {
		case "string":
		case "boolean":
			return { ok: true, value: v };
		case "number":
			return Number.isFinite(v) ? { ok: true, value: v } : { ok: false };
		case "object": {
			if (stack.has(v as object)) return { ok: false }; // 循环引用
			if (Array.isArray(v)) {
				stack.add(v);
				const out: JsonSafeValue[] = [];
				for (const el of v) {
					const r = strictJsonSafeCopy(el, stack);
					if (!r.ok) { stack.delete(v); return { ok: false }; }
					out.push(r.value);
				}
				stack.delete(v);
				return { ok: true, value: out };
			}
			if (!isPlainObject(v)) return { ok: false }; // 类实例（Date/Map/宿主对象）不入 wire
			stack.add(v);
			const out: Record<string, JsonSafeValue> = {};
			for (const [k, val] of Object.entries(v)) {
				if (val === undefined) { stack.delete(v); return { ok: false }; } // 键值 undefined 非法（严格于 JSON.stringify 的丢键）
				const r = strictJsonSafeCopy(val, stack);
				if (!r.ok) { stack.delete(v); return { ok: false }; }
				out[k] = r.value;
			}
			stack.delete(v);
			return { ok: true, value: out };
		}
		default:
			return { ok: false }; // function/symbol/bigint/undefined（顶层）
	}
}

/** JSON-safe 值递归脱敏：仅字符串值过 redactCredentials（对象键=参数名非自由文本，不脱敏）。
 *  redactCredentials 复用自 task-query-wire（同源不复制，§3.3）。 */
function redactJsonSafeTexts(v: JsonSafeValue): JsonSafeValue {
	if (typeof v === "string") return redactCredentials(v);
	if (Array.isArray(v)) return v.map(redactJsonSafeTexts);
	if (v !== null && typeof v === "object") {
		const out: Record<string, JsonSafeValue> = {};
		for (const [k, val] of Object.entries(v)) out[k] = redactJsonSafeTexts(val);
		return out;
	}
	return v;
}

/** 成功 JSON 编码的 UTF-8 字节数（§3.2 payloadBytes）；编码失败（如超深嵌套栈溢出）→ null
 *  （「无法编码……时 null」）。输入必须是已 JSON-safe 值。 */
function utf8JsonBytes(v: JsonSafeValue): number | null {
	try {
		const n = Buffer.byteLength(JSON.stringify(v), "utf8");
		return Number.isSafeInteger(n) ? n : null;
	} catch { /* lint-exempt: payloadBytes 计算兜底——非安全整数/序列化失败显式返回 null 进 wire（payloadBytes: null），不丢诊断 */
		return null;
	}
}

function nullableStringValue(v: unknown): string | null {
	return typeof v === "string" ? v : null;
}

function nullableNonNegativeSafeInt(v: unknown): number | null {
	return typeof v === "number" && Number.isInteger(v) && v >= 0 && v <= Number.MAX_SAFE_INTEGER ? v : null;
}

// ── 错误分类（§3.2 五 code；P2 把 transport 层异常交给本函数） ─────────────────

/**
 * 按 Error.name/消息形态把 transport 层异常归入五 code（形态锚定 mcp-client 现行实现：
 * McpGatewayError/McpRpcError/McpBusinessAuthError :88-110、超时文案 rpcRequest/StdioMcpServer、
 * 会话文案 isSessionError/AUTH_SESSION_TEXT :246-262）。分类线：**远端已产生协议/业务应答** =
 * remote（JSON-RPC error、result.isError 业务错、网关非 JSON-RPC 业务体）；**未获远端协议应答** =
 * transport（超时/abort/会话认证/HTTP 状态/stdio 退出）；其余 internal。shape/permission 不是
 * 异常形态——由调用方在预 transport 校验点直接构造。
 */
export function classifyMcpWireError(e: unknown): McpWireErrorCode {
	if (!(e instanceof Error)) return "internal";
	switch (e.name) {
		case "McpGatewayError": // 网关业务错误（HTTP 200 + 非 JSON-RPC 业务体，mcp-client.ts:96）
		case "McpRpcError": // JSON-RPC error（mcp-client.ts:81）
		case "McpBusinessAuthError": // 远端业务 isError 文本中的 auth 失败（mcp-client.ts:241）
			return "remote";
		case "TimeoutError":
		case "AbortError":
		case "McpHttpError": // HTTP 状态层（无协议应答）
			return "transport";
	}
	const message = e.message ?? "";
	if (message === "aborted") return "transport";
	if (/MCP 请求超时|超时（\d+ms）|discovery 超时|^MCP stdio |MCP stdio .* 退出/.test(message)) return "transport";
	// 会话/认证类（isSessionError 同源文案——含中文网关文案）：连接层失败，无远端业务应答
	if (/api key not found|invalid api key|unauthorized|not authenticated|session|身份验证|鉴权失败|鉴权异常|未授权|密钥无效|令牌无效/i.test(message)) return "transport";
	return "internal";
}

// ── 映射（四分支投影；全部纯函数、不抛——非字符串 text/message 映射 ""，结构 name 直接投影
//    产 schema-invalid wire 如实暴露坏源，不臆造） ────────────────────────────────

/** structuredContent → {remoteStructured, payloadState, payloadBytes}（§3.2 消歧纪律：
 *  属性缺席=absent；null=available 的合法 JSON null；纯对象经严格 JSON-safe 校验+脱敏；
 *  标量/数组/非法树=invalid——不做部分拷贝）。 */
function projectPayload(v: unknown): Pick<McpCallDataWire, "remoteStructured" | "payloadState" | "payloadBytes"> {
	if (v === undefined) return { remoteStructured: null, payloadState: "absent", payloadBytes: null };
	if (v === null) return { remoteStructured: null, payloadState: "available", payloadBytes: utf8JsonBytes(null) };
	let safe: ReturnType<typeof strictJsonSafeCopy>;
	try {
		safe = strictJsonSafeCopy(v, new Set());
	} catch { /* lint-exempt: 超深嵌套栈溢出=无法安全转换——显式置 payloadState:"invalid" 进 wire，不丢诊断 */
		return { remoteStructured: null, payloadState: "invalid", payloadBytes: null }; // 超深嵌套栈溢出=无法安全转换
	}
	if (!safe.ok || !isPlainObject(safe.value)) return { remoteStructured: null, payloadState: "invalid", payloadBytes: null };
	const copy = redactJsonSafeTexts(safe.value) as JsonSafeObject;
	return { remoteStructured: copy, payloadState: "available", payloadBytes: utf8JsonBytes(copy) };
}

function projectCallData(f: Readonly<McpCallPayloadFields>): McpCallDataWire {
	const payload = projectPayload(f.structuredContent);
	return {
		text: typeof f.text === "string" ? redactCredentials(f.text) : "",
		images: Array.isArray(f.images) ? f.images
			.filter((b) => b?.type === "image" && typeof b.data === "string" && typeof b.mimeType === "string")
			.map(({ type, data, mimeType }) => ({ type, data, mimeType })) : [],
		textTruncated: f.textTruncated === true,
		textDumpPath: nullableStringValue(f.textDumpPath),
		remoteStructured: payload.remoteStructured,
		payloadState: payload.payloadState,
		payloadBytes: payload.payloadBytes,
		schemaSource: f.remoteOutputSchema === true ? "remote-output" : "none",
	};
}

/** 失败副作用口径缺省：shape/permission=预 transport 拒绝（none）；其余可能已执行（unknown）。 */
function defaultEffectsOf(code: McpWireErrorCode): string {
	return code === "shape" || code === "permission" ? "none" : "unknown";
}

/** repairExamples 条目级投影：JSON-safe 纯对象条目保留（递归字符串脱敏）；其余整条剥除。 */
function repairExamplesOf(examples: ReadonlyArray<object> | undefined): object[] {
	const out: object[] = [];
	if (!Array.isArray(examples)) return out;
	for (const ex of examples) {
		let safe: ReturnType<typeof strictJsonSafeCopy>;
		try {
			safe = strictJsonSafeCopy(ex, new Set());
		} catch { /* lint-exempt: repairExamples 单条非 JSON-safe 跳过——其余条目保留，被跳过条目不进 wire（封闭纪律） */
			continue;
		}
		if (safe.ok && isPlainObject(safe.value)) out.push(redactJsonSafeTexts(safe.value) as JsonSafeObject);
	}
	return out;
}

function projectFailure(src: Readonly<McpWireErrorSource>): McpWireFailureWire {
	return {
		code: src.code,
		message: typeof src.message === "string" ? redactCredentials(src.message) : "",
		effects: typeof src.effects === "string" ? src.effects : defaultEffectsOf(src.code),
		repairExamples: repairExamplesOf(src.repairExamples),
	};
}

/** mcp_call 成功分支映射（§3.2 call 固定返回字段草案）。 */
export function toMcpCallResultWire(src: Readonly<McpCallResultSource>): McpCallResultWire {
	return {
		kind: MCP_WIRE_CALL_KIND,
		wireVersion: MCP_CALL_WIRE_VERSION,
		schemaVersion: MCP_CALL_SCHEMA_VERSION,
		ok: true,
		isError: false,
		server: nullableStringValue(src.server),
		tool: nullableStringValue(src.tool),
		data: projectCallData(src),
	};
}

/** mcp_call 失败分支映射（remoteResult 与 data 同型——远端业务错时捕获的远端载荷）。 */
export function toMcpCallErrorWire(src: Readonly<McpCallErrorSource>): McpCallErrorWire {
	return {
		kind: MCP_WIRE_CALL_KIND,
		wireVersion: MCP_CALL_WIRE_VERSION,
		schemaVersion: MCP_CALL_SCHEMA_VERSION,
		ok: false,
		isError: true,
		server: nullableStringValue(src.server),
		tool: nullableStringValue(src.tool),
		error: {
			...projectFailure(src.error),
			remoteResult: src.remoteResult ? projectCallData(src.remoteResult) : null,
		},
	};
}

/** 开放 schema 槽：纯对象且严格 JSON-safe → 脱敏副本；缺席/null/非对象（数组）/非法树 → null。 */
function jsonObjectSlotOf(v: unknown): JsonSafeObject | null {
	if (typeof v !== "object" || v === null || Array.isArray(v)) return null;
	let safe: ReturnType<typeof strictJsonSafeCopy>;
	try {
		safe = strictJsonSafeCopy(v, new Set());
	} catch { /* lint-exempt: 单值 JSON-safe 转换失败返回 null——开放槽安全纪律，失败显式为 null 非静默 */
		return null;
	}
	if (!safe.ok || !isPlainObject(safe.value)) return null;
	return redactJsonSafeTexts(safe.value) as JsonSafeObject;
}

/** 四布尔 hint：各自独立投影（缺失/非布尔 → null；annotations 非对象 → 全 null）。 */
function hintsOf(a: unknown): McpAnnotationsHintsWire {
	const o = isPlainObject(a) ? a : {};
	const boolOrNull = (v: unknown): boolean | null => (typeof v === "boolean" ? v : null);
	return {
		readOnlyHint: boolOrNull(o.readOnlyHint),
		destructiveHint: boolOrNull(o.destructiveHint),
		idempotentHint: boolOrNull(o.idempotentHint),
		openWorldHint: boolOrNull(o.openWorldHint),
	};
}

function listToolOf(t: Readonly<McpListToolSource>): McpListToolWire {
	return {
		name: t.name, // 直接投影：非 string 坏源产 schema-invalid wire（Value.Check 拒绝），不臆造
		description: typeof t.description === "string" ? redactCredentials(t.description) : null,
		inputSchema: jsonObjectSlotOf(t.inputSchema),
		outputSchema: jsonObjectSlotOf(t.outputSchema),
		annotations: hintsOf(t.annotations),
	};
}

function listServerEntryOf(s: Readonly<McpListServerSource>): McpListServerEntryWire {
	return {
		name: s.name, // 直接投影（同 listToolOf——坏源产 schema-invalid wire）
		status: s.status,
		observedAt: nullableNonNegativeSafeInt(s.observedAt),
		tools: (Array.isArray(s.tools) ? s.tools : []).map(listToolOf),
		error: typeof s.error === "string" ? redactCredentials(s.error) : null,
	};
}

/** mcp_list_tools 成功分支映射（§3.2 list data：servers 数组）。 */
export function toMcpListResultWire(src: Readonly<McpListResultSource>): McpListResultWire {
	return {
		kind: MCP_WIRE_LIST_KIND,
		wireVersion: MCP_WIRE_VERSION,
		schemaVersion: MCP_SCHEMA_VERSION,
		ok: true,
		isError: false,
		data: { servers: src.servers.map(listServerEntryOf) },
	};
}

/** mcp_list_tools 失败分支映射（remoteResult 按 data 同型；通常 null）。 */
export function toMcpListErrorWire(src: Readonly<McpListErrorSource>): McpListErrorWire {
	return {
		kind: MCP_WIRE_LIST_KIND,
		wireVersion: MCP_WIRE_VERSION,
		schemaVersion: MCP_SCHEMA_VERSION,
		ok: false,
		isError: true,
		error: {
			...projectFailure(src.error),
			remoteResult: src.remoteResult ? { servers: src.remoteResult.servers.map(listServerEntryOf) } : null,
		},
	};
}
