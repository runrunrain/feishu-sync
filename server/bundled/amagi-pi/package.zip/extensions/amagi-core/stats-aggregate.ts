/**
 * stats-aggregate.ts — E9：trace → 成本/质量仪表盘（迭代期望 §四-3）。
 *
 * traces.ndjson 已有 taskId/agent/model/status/时长/token/成本字段（T2-8），
 * 本模块只做**只读聚合**：按日/角色/模型聚合任务数、成功率、blocked 率、成本，
 * 供 query_task({ stats:true }) 出口——让"这套编排到底省不省"有数据答案，而非体感。
 *
 * 边界：纯函数聚合 + 文本渲染；不读 agent-stats（token 口径与 trace 重复，trace 为准）；
 * 时间窗按 entry.at（任务终态时间）过滤，days 省略 = 全量。
 * B0-2（Leader 成本效率编排 §3.4/附录 B.1）：usage 只取累计口径行（usageScope=cumulative /
 * trace v3+）；旧格式行（末轮口径）单独小计不混加；末尾新增本会话用量视图（分支可见口径）。
 */

import { readTraces, tracesFile, errorKindOfEntry, type ErrorKind, type TraceEntry, readObservations, type ObservationEntry, type ChildSuiteObservationEntry } from "./trace.ts";

export interface StatsRow {
	key: string;
	tasks: number;
	done: number;
	blocked: number;
	error: number;
	cost: number;
	input: number;
	output: number;
	/** v1.5.226 P0-2：prompt cache 命中/写入 token 累计（trace cacheRead/cacheWrite）。 */
	cacheRead: number;
	cacheWrite: number;
	/** B0-2：assistant 完结事件数累计（仅累计口径行携带；旧行无此字段不计）。 */
	calls: number;
}

export interface StatsModel {
	nestedUsage?: StatsRow;
	nestedCostKnown?: boolean;
	/** 时间窗天数；undefined = 全量。 */
	windowDays?: number;
	/** 窗口内 trace 总条数（聚合前）。 */
	entries: number;
	total: StatsRow;
	byDay: StatsRow[];
	byAgent: StatsRow[];
	byModel: StatsRow[];
	/** P2-A：error 行错误分类直方图（仅 status=error；旧 v1 行无 errorKind 归一为 unknown「未知」，不误报 other）。 */
	errorKinds: Partial<Record<ErrorKind | "unknown", number>>;
	/** B0-2（附录 B.1）：累计口径行数（usageScope=cumulative / trace v3+）。 */
	cumulativeRows: number;
	/** B0-2：旧格式行数（仅末轮口径 usage——单独小计，不与累计行混加）。 */
	legacyRows: number;
	/** B0-2：旧格式行 usage 单独小计（任务数/成功率仍进 total/byAgent/byModel 分母——末轮口径只影响 token/cost/calls 列）。 */
	legacyUsage: { input: number; output: number; cacheRead: number; cacheWrite: number; cost: number };
}

/** B0-2：累计口径行判定（新行 usageScope="cumulative"；trace formatVersion≥3 同义；旧行按 last-call 单独统计）。 */
export function isCumulativeEntry(e: { usageScope?: string; formatVersion?: number }): boolean {
	return e.usageScope === "cumulative" || (typeof e.formatVersion === "number" && e.formatVersion >= 3);
}

function emptyRow(key: string): StatsRow {
	return { key, tasks: 0, done: 0, blocked: 0, error: 0, cost: 0, input: 0, output: 0, cacheRead: 0, cacheWrite: 0, calls: 0 };
}

function add(row: StatsRow, e: TraceEntry): void {
	// v2 批次B：cancelled 不计入成功率统计（取消非 agent 成败信号；trace 仍留痕可查）。
	if (e.status === "cancelled") return;
	addOutcome(row, e);
	// B0-2（附录 B.1）：任务数/成功率对所有行计（未成功任务进分母）；token/cost/calls 只取
	// 累计口径行——旧格式行（末轮口径）不与新行混加，由 StatsModel.legacyUsage 单独小计。
	if (!isCumulativeEntry(e)) return;
	addUsageFiguresToRow(row, e);
}

/** F2（diting，附录 B.1）：任务数/成功率入桶（cancelled 不计）。 */
function addOutcome(row: StatsRow, e: TraceEntry): void {
	row.tasks += 1;
	if (e.status === "done") row.done += 1;
	else if (e.status === "blocked") row.blocked += 1;
	else if (e.status === "truncated") row.error += 1; // P1：truncated 保守计入失败桶（终稿帧丢失；升级 done 的以最终 done 落 trace）
	else row.error += 1;
}

/** F2（diting，附录 B.1）：usage 入桶（非有限分项剔除；同一形状供顶层行与分模型小计行共用）。 */
function addUsageFiguresToRow(row: StatsRow, u: { cost?: unknown; input?: unknown; output?: unknown; cacheRead?: unknown; cacheWrite?: unknown; assistantCalls?: unknown }): void {
	if (typeof u.cost === "number" && Number.isFinite(u.cost)) row.cost += u.cost;
	if (typeof u.input === "number" && Number.isFinite(u.input)) row.input += u.input;
	if (typeof u.output === "number" && Number.isFinite(u.output)) row.output += u.output;
	if (typeof u.cacheRead === "number" && Number.isFinite(u.cacheRead)) row.cacheRead += u.cacheRead;
	if (typeof u.cacheWrite === "number" && Number.isFinite(u.cacheWrite)) row.cacheWrite += u.cacheWrite;
	if (typeof u.assistantCalls === "number" && Number.isFinite(u.assistantCalls)) row.calls += u.assistantCalls;
}

/** F2（diting，附录 B.1）：跨模型聚合行携带的有效分模型小计（≥1 桶且各桶至少有任一已观察
 *  分项；否则 undefined——退回顶层单一模型行）。 */
function validModelSubtotals(e: TraceEntry): ReadonlyArray<NonNullable<TraceEntry["modelSubtotals"]>[number]> | undefined {
	if (!isCumulativeEntry(e) || !Array.isArray(e.modelSubtotals) || e.modelSubtotals.length === 0) return undefined;
	return e.modelSubtotals.every((st) => st !== null && typeof st === "object" && typeof st.model === "string" && st.model !== "") ? e.modelSubtotals : undefined;
}

function dayKey(at: number): string {
	try {
		return new Date(at).toISOString().slice(0, 10);
	} catch {
		return "????-??-??";
	}
}

/** 聚合 traces → StatsModel。纯函数（readTraces 取数注入 tracesPath 便于测试）。 */
export function aggregateStats(opts?: { days?: number; tracesPath?: string; now?: number }): StatsModel {
	const now = opts?.now ?? Date.now();
	const days = opts?.days && Number.isFinite(opts.days) && opts.days > 0 ? Math.floor(opts.days) : undefined;
	const cutoff = days ? now - days * 24 * 3600 * 1000 : undefined;
	const entries = readTraces(opts?.tracesPath).filter((e) => typeof e.at === "number" && (cutoff === undefined || e.at >= cutoff));

	const total = emptyRow("total");
	const byDay = new Map<string, StatsRow>();
	const byAgent = new Map<string, StatsRow>();
	const byModel = new Map<string, StatsRow>();
	// B0-2：累计/旧格式分版计数与旧格式 usage 单独小计（任务数仍进全部分母）。
	let cumulativeRows = 0;
	let legacyRows = 0;
	const legacyUsage = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, cost: 0 };
	// P2-A：错误分类直方图——读侧经 errorKindOfEntry 归一（旧行/无分类 → unknown），
	// 仅统计 status=error 行（truncated 无 errorKind 落盘，混入只会稀释信号）。
	const errorKinds: Partial<Record<ErrorKind | "unknown", number>> = {};
	for (const e of entries) {
		if (e.status === "error") {
			const k = errorKindOfEntry(e) ?? "unknown";
			errorKinds[k] = (errorKinds[k] || 0) + 1;
		}
	}
	for (const e of entries) {
		if (isCumulativeEntry(e)) cumulativeRows++;
		else {
			legacyRows++;
			if (e.status !== "cancelled") {
				if (typeof e.input === "number" && Number.isFinite(e.input)) legacyUsage.input += e.input;
				if (typeof e.output === "number" && Number.isFinite(e.output)) legacyUsage.output += e.output;
				if (typeof e.cacheRead === "number" && Number.isFinite(e.cacheRead)) legacyUsage.cacheRead += e.cacheRead;
				if (typeof e.cacheWrite === "number" && Number.isFinite(e.cacheWrite)) legacyUsage.cacheWrite += e.cacheWrite;
				if (typeof e.cost === "number" && Number.isFinite(e.cost)) legacyUsage.cost += e.cost;
			}
		}
		add(total, e);
		const dk = dayKey(e.at);
		if (!byDay.has(dk)) byDay.set(dk, emptyRow(dk));
		add(byDay.get(dk)!, e);
		const ak = e.agent || "?";
		if (!byAgent.has(ak)) byAgent.set(ak, emptyRow(ak));
		add(byAgent.get(ak)!, e);
		// F2（diting，附录 B.1）：模型维度不把跨模型聚合行的顶层总额填到最后轮模型下——携带
		// 分模型小计时按各桶实际模型入账（任务在每个实际使用的模型行各计一次，跨模型任务的
			// 任务数跨行不叠加口径已在渲染层说明；cancelled 仍不计）。
		if (e.status === "cancelled") continue;
		const subtotals = validModelSubtotals(e);
		if (subtotals) {
			for (const st of subtotals) {
				const mk = st.model || "(未知)";
				if (!byModel.has(mk)) byModel.set(mk, emptyRow(mk));
				const row = byModel.get(mk)!;
				addOutcome(row, e);
				addUsageFiguresToRow(row, st);
			}
		} else {
			const mk = e.model || "(未知)";
			if (!byModel.has(mk)) byModel.set(mk, emptyRow(mk));
			add(byModel.get(mk)!, e);
		}
	}
	const nested = entries.filter(e => isCumulativeEntry(e) && e.nestedUsage);
	const nestedUsage = emptyRow("tools");
	for (const e of nested) addUsageFiguresToRow(nestedUsage, e.nestedUsage!);
	return {
		...(nested.length ? { nestedUsage, nestedCostKnown: nested.every(e => typeof e.nestedUsage?.cost === "number" && Number.isFinite(e.nestedUsage.cost)) } : {}),
		windowDays: days,
		entries: entries.length,
		total,
		byDay: [...byDay.values()].sort((a, b) => b.key.localeCompare(a.key)), // 新日期在前
		byAgent: [...byAgent.values()].sort((a, b) => b.tasks - a.tasks),
		byModel: [...byModel.values()].sort((a, b) => b.cost - a.cost),
		errorKinds,
		cumulativeRows,
		legacyRows,
		legacyUsage,
	};
}

// ── 渲染 ─────────────────────────────────────────────────────────────────────

function pct(n: number, d: number): string {
	return d > 0 ? `${Math.round((n / d) * 100)}%` : "-";
}
function usd(c: number): string {
	return c > 0 ? `$${c.toFixed(4)}` : "-";
}
function tok(n: number): string {
	return n > 0 ? (n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(Math.round(n))) : "-";
}

function renderRows(title: string, rows: StatsRow[], lines: string[]): void {
	if (!rows.length) return;
	lines.push(`\n${title}`);
	lines.push("  键 | 任务 | 成功率 | blocked | 成本 | token(入/出) | 缓存命中 | 调用");
	for (const r of rows) {
		lines.push(`  ${r.key} | ${r.tasks} | ${pct(r.done, r.tasks)} | ${pct(r.blocked, r.tasks)} | ${usd(r.cost)} | ${tok(r.input)}/${tok(r.output)} | ${hitRate(r)} | ${r.calls > 0 ? String(r.calls) : "-"}`);
	}
}

/** 缓存命中率：cacheRead / 总输入（input+cacheRead+cacheWrite；pi-ai 归一化口径：input 为未命中输入）。无数据 → "-"。 */
function hitRate(r: Pick<StatsRow, "input" | "cacheRead" | "cacheWrite">): string {
	const totalIn = r.input + r.cacheRead + r.cacheWrite;
	if (totalIn <= 0) return "-";
	return `${Math.round((r.cacheRead / totalIn) * 100)}%(${tok(r.cacheRead)})`;
}

/** StatsModel → 紧凑文本（query_task 回流口径；B0-2 起 /amagi stats 同源）。 */
export function renderStatsText(m: StatsModel): string {
	const t = m.total;
	const lines: string[] = [];
	const win = m.windowDays ? `近 ${m.windowDays} 天` : "全量";
	lines.push(`[amagi stats] ${win} · ${m.entries} 条任务轨迹`);
	if (m.entries === 0) {
		lines.push("（无 trace 数据——完成若干 SubAgent 任务后再看）");
		return lines.join("\n");
	}
	// B0-2：口径披露——累计行与旧格式行分版计数；旧格式（仅末轮口径）单独小计，不与累计混加。
	lines.push(`口径: 累计 ${m.cumulativeRows} 行${m.legacyRows > 0 ? ` · 旧格式末轮 ${m.legacyRows} 行（单独小计，不与上方累计混加）` : ""}`);
	lines.push(`总计: ${t.tasks} 任务 · 成功率 ${pct(t.done, t.tasks)} · blocked ${pct(t.blocked, t.tasks)} · error ${pct(t.error, t.tasks)} · 成本 ${usd(t.cost)} · token ${tok(t.input)}/${tok(t.output)} · 缓存命中 ${hitRate(t)} · 调用 ${t.calls > 0 ? String(t.calls) : "-"}`);
	// B0-2：无单价显式提示（token 有量而 cost 恒缺/0——通道未上报价格，不解释为免费）。
	if (t.cost === 0 && (t.input > 0 || t.output > 0 || t.cacheRead > 0)) {
		lines.push("单价: 无（当前通道未上报 cost——不是免费，token 与调用数为可用口径）");
	}
	if (m.legacyRows > 0) {
		const lu = m.legacyUsage;
		lines.push(`旧格式末轮口径小计: ${m.legacyRows} 行 · token ${tok(lu.input)}/${tok(lu.output)} · 缓存命中 ${tok(lu.cacheRead)} · 成本 ${usd(lu.cost)}（末轮口径，不回填伪累计）`);
	}
	// P2-A：错误分类（仅 status=error 行；unknown 渲染为「未知」——含旧 formatVersion 行，非 other 误报）
	const kindEntries = Object.entries(m.errorKinds).filter(([, n]) => n > 0);
	if (kindEntries.length > 0) {
		const parts = kindEntries.sort((a, b) => b[1] - a[1]).map(([k, n]) => `${k === "unknown" ? "未知" : k} ${n}`);
		lines.push(`错误分类: ${parts.join(" · ")}`);
	}
	renderRows("按日:", m.byDay, lines);
	renderRows("按角色:", m.byAgent, lines);
	renderRows("按模型:", m.byModel, lines);
	// F2：跨模型任务（多轮聚合行）按分模型小计入桶——任务数跨模型行不叠加口径在此说明。
	lines.push("  （模型维度：跨模型任务按各实际使用模型拆桶入账，任务数在多个模型行各计一次，跨行不做去重叠加）");
	if (m.nestedUsage) lines.push(`\n工具内嵌模型（含 Advisor，独立于执行者用量）: token ${tok(m.nestedUsage.input)}/${tok(m.nestedUsage.output)} · 缓存 ${tok(m.nestedUsage.cacheRead)}/${tok(m.nestedUsage.cacheWrite)} · 成本 ${m.nestedCostKnown === false ? "未知或部分可见" : usd(m.nestedUsage.cost)}`);
	return lines.join("\n");
}

// ── B0-2（§3.4 / 附录 B.1 末段）：本会话用量视图（/amagi stats 附段） ────────────
//
// 口径边界（CLI 视图必须明确）：Leader 侧取 ctx.sessionManager.getBranch() 当前分支可见的
// assistant usage 求和——与 pi 原生全会话口径可能不同（分支切换/压缩后历史不完全可见）。
// 子任务侧按 trace 行 leaderSession 盖章精确匹配当前会话；无盖章/异会话行进「未归属」桶，
// 不静默丢弃。总计只在来源互斥时才可相加；Leader 工具结果未来如附子任务 usage，不得再与
// 对应 trace 相加（同一批消耗双计）。

/** 用量小计（四项 token + 调用数；无数据=0/调用 0）。 */
export interface UsageSubtotal {
	calls: number;
	input: number;
	output: number;
	cacheRead: number;
	cacheWrite: number;
}

export interface SessionUsageView {
	nestedUsage?: UsageSubtotal;
	/** Leader 当前分支可见 assistant 用量（getBranch 投影求和）。 */
	leader: UsageSubtotal;
	/** 本会话子任务（trace 行 leaderSession 精确匹配；仅累计口径行）。 */
	childThisSession: UsageSubtotal & { tasks: number };
	/** 未归属行数（无盖章/异会话——跨会话/后台，不计入上两项也不静默丢弃）。 */
	unattributed: number;
}

function emptySubtotal(): UsageSubtotal {
	return { calls: 0, input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
}

function addAssistantUsage(sub: UsageSubtotal, usage: unknown): void {
	if (!usage || typeof usage !== "object") return;
	const u = usage as { input?: unknown; output?: unknown; cacheRead?: unknown; cacheWrite?: unknown };
	const addNum = (k: "input" | "output" | "cacheRead" | "cacheWrite"): void => {
		const v = u[k];
		if (typeof v === "number" && Number.isFinite(v)) sub[k] += v;
	};
	const before = sub.input + sub.output + sub.cacheRead + sub.cacheWrite;
	addNum("input"); addNum("output"); addNum("cacheRead"); addNum("cacheWrite");
	if (sub.input + sub.output + sub.cacheRead + sub.cacheWrite !== before) sub.calls++;
}

/**
 * 本会话用量聚合（纯函数）。branchEntries：sessionManager.getBranch() 投影（容忍任意形态——
 * 只读 type==="message" 且 message.role==="assistant" 的 usage）；traces：全量 trace 行；
 * leaderSession：当前会话盖章（task-service；undefined=未盖章——子任务全部进未归属）。
 */
export function aggregateSessionUsage(branchEntries: readonly unknown[], traces: readonly TraceEntry[], leaderSession: string | undefined): SessionUsageView {
	const leader = emptySubtotal();
	for (const entry of branchEntries) {
		const e = entry as { type?: unknown; message?: { role?: unknown; usage?: unknown } };
		if (!e || e.type !== "message" || !e.message || e.message.role !== "assistant") continue;
		addAssistantUsage(leader, e.message.usage);
	}
	const childThisSession = { ...emptySubtotal(), tasks: 0 };
	let unattributed = 0;
	for (const t of traces) {
		if (!isCumulativeEntry(t)) continue; // 旧行无会话盖章——不进本会话桶（未归属语义由 legacy 小计承担）
		if (t.leaderSession !== undefined && leaderSession !== undefined && t.leaderSession === leaderSession) {
			childThisSession.tasks++;
			if (typeof t.input === "number" && Number.isFinite(t.input)) childThisSession.input += t.input;
			if (typeof t.output === "number" && Number.isFinite(t.output)) childThisSession.output += t.output;
			if (typeof t.cacheRead === "number" && Number.isFinite(t.cacheRead)) childThisSession.cacheRead += t.cacheRead;
			if (typeof t.cacheWrite === "number" && Number.isFinite(t.cacheWrite)) childThisSession.cacheWrite += t.cacheWrite;
			if (typeof t.assistantCalls === "number" && Number.isFinite(t.assistantCalls)) childThisSession.calls += t.assistantCalls;
		} else {
			unattributed++;
		}
	}
	const nestedUsage = emptySubtotal();
	let observed = false;
	for (const entry of branchEntries) {
		const e = entry as { type?: string; customType?: string; details?: { advisor?: { usage?: unknown } }; message?: { role?: string; toolName?: string; usage?: unknown; customType?: string; details?: { advisor?: { usage?: unknown; accountUsage?: boolean } } } };
		if (e?.type === "custom_message" && e.customType === "amagi:advisor-result" && e.details?.advisor?.usage) { addAssistantUsage(nestedUsage, e.details.advisor.usage); observed = true; continue; }
		if (e?.type !== "message") continue;
		const u = e.message?.role === "toolResult" ? e.message.usage ?? (e.message.toolName === "amagi_advisor" && e.message.details?.advisor?.accountUsage !== false ? e.message.details?.advisor?.usage : undefined) : e.message?.role === "custom" && e.message.customType === "amagi:advisor-result" ? e.message.details?.advisor?.usage : undefined;
		if (u) { addAssistantUsage(nestedUsage, u); observed = true; }
	}
	for (const t of traces) if (isCumulativeEntry(t) && leaderSession && t.leaderSession === leaderSession && t.nestedUsage) { addAssistantUsage(nestedUsage, t.nestedUsage); observed = true; }
	return { leader, childThisSession, unattributed, ...(observed ? { nestedUsage } : {}) };
}

/** 本会话用量视图渲染（口径声明必须随行——分支可见 ≠ 全会话账单）。 */
export function renderSessionUsageText(view: SessionUsageView): string {
	const fmt = (s: UsageSubtotal): string => `调用 ${s.calls} · token ${tok(s.input)}/${tok(s.output)} · 缓存读 ${tok(s.cacheRead)} · 缓存写 ${tok(s.cacheWrite)}`;
	const c = view.childThisSession;
	const lines = [
		"本会话用量（口径：Leader 当前分支可见用量——与 pi 原生全会话口径可能不同；分支切换/压缩后历史不完全可见）",
		`  Leader: ${fmt(view.leader)}`,
		`  本会话子任务: ${c.tasks} 任务（按 leaderSession 匹配）· ${fmt(c)}`,
		`  未归属: ${view.unattributed} 行（无会话盖章/跨会话——单独计数，不并入上两项，不静默丢弃）`,
		"说明: 以上来源互斥才可相加；工具内嵌/压缩用量单列于 trace 分栏（nestedUsage/compactionUsage），未计入上两项。",
	];
	if (view.nestedUsage) lines.push(`  工具内嵌模型（含 Advisor；独立计量）: ${fmt(view.nestedUsage)}`);
	return lines.join("\n");
}

// ── F4（diting，附录 B.2）：重复全套观测视图（/amagi stats 附段） ───────────────
//
// 口径边界：observations.ndjson 是结算后追加的旁路观测（不进内核状态）；unknown 与 0 严格
// 分开呈现——未关联/写入缺失不得冒充零次。纯函数（entries/traces 注入），读侧文件缺失由空数组→
// 显式文案（不等于零次）。F4 终审：提供窗口内 traces 时按 taskId/runKey 关联——每个有 trace 的
// 逻辑任务逐行披露观测关联状态；无观测行=显式缺失（单任务写失败可见），全局汇总行保留。
export function renderObservationsText(entries: ReadonlyArray<ObservationEntry>, traces?: ReadonlyArray<TraceEntry>, window?: { days?: number; now?: number }): string {
	if (!Array.isArray(entries) || entries.length === 0) {
		return "重复全套/大发射观测: 无观测行（尚未到达观察点或观测写入失败——不等于零次重复）";
	}
	const lines: string[] = ["重复全套/大发射观测（observations.ndjson）:"];
	let suiteRows = 0, suiteRuns = 0, suiteRunsUnknown = 0, mismatch = 0, mismatchUnknown = 0;
	let candidate = 0, candidateUnknown = 0, harnessRan = 0, harnessUnknown = 0, runKeyUnknown = 0;
	const blocks = new Map<string, number>();
	for (const e of entries) {
		if (e?.kind === "child-full-suite") {
			suiteRows++;
			if (e.childFullSuiteRuns === "unknown") suiteRunsUnknown++; else if (typeof e.childFullSuiteRuns === "number") suiteRuns += e.childFullSuiteRuns;
			if (e.childCwdMismatchRuns === "unknown") mismatchUnknown++; else if (typeof e.childCwdMismatchRuns === "number") mismatch += e.childCwdMismatchRuns;
			if (e.childSuiteCandidate === "unknown") candidateUnknown++; else if (e.childSuiteCandidate === true) candidate++;
			if (e.harnessBaselineRan === "unknown") harnessUnknown++; else if (e.harnessBaselineRan === true) harnessRan++;
			if (e.runKey === "unknown") runKeyUnknown++;
		} else if (e?.kind === "large-emission-block") {
			const p = typeof e.provider === "string" && e.provider !== "" ? e.provider : "(未知)";
			blocks.set(p, (blocks.get(p) ?? 0) + 1);
		}
	}
	if (suiteRows > 0) {
		lines.push(`  子代理全套: ${suiteRows} 行 · 命中合计 ${suiteRuns} 次 · cwd 不匹配/不可确证 ${mismatch} · 候选存在 ${candidate} · harness 基线跑过 ${harnessRan}`);
		const unknownParts: string[] = [];
		if (suiteRunsUnknown > 0) unknownParts.push(`命中数 unknown ${suiteRunsUnknown}`);
		if (runKeyUnknown > 0) unknownParts.push(`runKey 未关联 ${runKeyUnknown}`);
		if (mismatchUnknown > 0) unknownParts.push(`cwd 不可确证 unknown ${mismatchUnknown}`);
		if (candidateUnknown > 0) unknownParts.push(`候选 unknown ${candidateUnknown}`);
		if (harnessUnknown > 0) unknownParts.push(`harness 基线状态 unknown ${harnessUnknown}`);
		if (unknownParts.length > 0) lines.push(`  未关联（unknown——未按零计）: ${unknownParts.join(" · ")}`);
	}
	if (blocks.size > 0) {
		const total = [...blocks.values()].reduce((a, b) => a + b, 0);
		const parts = [...blocks.entries()].sort((a, b) => b[1] - a[1]).map(([p, n]) => `${p} ${n}`).join(" · ");
		lines.push(`  大发射硬阻断: ${total} 次（${parts}）`);
	}
	// F4 终审：任务级关联披露——窗口内有 trace 的逻辑任务逐行展示观测关联状态；无行=显式缺失
	// （写失败/未到观察点≠零次）。观测行先按 taskId 匹配，缺席时退回 runKey 集匹配（trace 行
	// runKey + runs[] 分轮身份）；两者都无法关联的观测行留在全局汇总，不虚构任务归属。
	if (traces !== undefined) {
		const now = window?.now ?? Date.now();
		const days = window?.days && Number.isFinite(window.days) && window.days > 0 ? Math.floor(window.days) : undefined;
		const cutoff = days ? now - days * 24 * 3600 * 1000 : undefined;
		const windowed = traces.filter((t) => t && typeof t.at === "number" && (cutoff === undefined || t.at >= cutoff));
		const tasks = new Map<string, { agent: string; runKeys: Set<string> }>();
		for (const t of windowed) {
			const key = typeof t.taskId === "string" && t.taskId !== "" ? t.taskId : `run:${typeof t.runKey === "string" ? t.runKey : "?"}`;
			const cur = tasks.get(key) ?? { agent: typeof t.agent === "string" && t.agent !== "" ? t.agent : "?", runKeys: new Set<string>() };
			if (typeof t.runKey === "string" && t.runKey !== "") cur.runKeys.add(t.runKey);
			if (Array.isArray(t.runs)) for (const r of t.runs) if (r && typeof r.runKey === "string" && r.runKey !== "") cur.runKeys.add(r.runKey);
			tasks.set(key, cur);
		}
		const matched = new Map<string, ChildSuiteObservationEntry[]>();
		for (const e of entries) {
			if (e?.kind !== "child-full-suite") continue;
			const row: ChildSuiteObservationEntry = e;
			let key = tasks.has(e.taskId) ? e.taskId : undefined;
			if (key === undefined && typeof e.runKey === "string" && e.runKey !== "unknown") {
				for (const [k, v] of tasks) if (v.runKeys.has(e.runKey)) { key = k; break; }
			}
			if (key === undefined) continue;
			const arr = matched.get(key) ?? [];
			arr.push(row);
			matched.set(key, arr);
		}
		const taskLines: string[] = [];
		const CAP = 40;
		let shown = 0;
		for (const [taskId, info] of tasks) {
			if (shown >= CAP) { taskLines.push(`  … 其余 ${tasks.size - CAP} 任务省略（观测关联同口径）`); break; }
			shown++;
			const rows = matched.get(taskId) ?? [];
			if (rows.length === 0) {
				taskLines.push(`  ${taskId}(${info.agent}): 无观测行——不等于零次重复（观测写失败或未到观察点）`);
				continue;
			}
			let runs = 0, runsUnknown = 0, mismatch = 0, candidateYes = 0, harnessYes = 0, harnessUnknown = 0;
			for (const r of rows) {
				if (r.childFullSuiteRuns === "unknown") runsUnknown++; else if (typeof r.childFullSuiteRuns === "number") runs += r.childFullSuiteRuns;
				if (typeof r.childCwdMismatchRuns === "number") mismatch += r.childCwdMismatchRuns;
				if (r.childSuiteCandidate === true) candidateYes++;
				if (r.harnessBaselineRan === true) harnessYes++;
				else if (r.harnessBaselineRan === "unknown") harnessUnknown++;
			}
			const parts = [`全套命中 ${runs}${runsUnknown > 0 ? `（另有 ${runsUnknown} 行 unknown）` : ""}`, `cwd 不匹配/不可确证 ${mismatch}`];
			if (candidateYes > 0) parts.push("候选在");
			parts.push(`harness 基线 ${harnessYes > 0 ? "跑过" : harnessUnknown > 0 ? "unknown" : "未跑过"}`);
			taskLines.push(`  ${taskId}(${info.agent}): ${parts.join(" · ")}`);
		}
		if (taskLines.length > 0) {
			lines.push("任务级观测关联（窗口内 trace 任务；无行=显式缺失，不等于零次）:");
			lines.push(...taskLines);
		}
	}
	return lines.join("\n");
}
