/**
 * evolution-tool.ts — amagi_evolution 工具：插件自进化的沉淀/查询/解决入口（v1.5.174 + B9）。
 *
 * 用法契约：
 * - 触发沉淀：任务执行中发现的阻断点/摩擦点/期望改进 → { action:"log", title, category,
 *   severity, phenomenon, expected, source, evidence }（全局归档，不污染项目目录）。evidence 为
 *   可选证据留存（B9/ev-20261012-04b7b9）：≤3 个普通文件、每个 ≤64KB，相对路径按当前 cwd 解析；
 *   内容经凭据脱敏后复制到 <evolutionRoot>/evidence/<id>/，随条目迁移可核验；敏感/越权路径拒收，
 *   单项缺失/超限不阻断沉淀并在回执披露『未留存：原因』。不要粘贴凭据——留存副本非通用 DLP。
 * - 升级迭代：主上显式要求升级插件 → { action:"list", status:"open" } 取未解决项
 *   （自动带当前版本执行自愈位置调整）；逐条改进后 { action:"resolve", id, fixVersion, note, evidence }
 *   （首次 resolve 可携 resolve 阶段附件；note 引 evidence key 便于审核锚定）。
 * - { action:"show", id } 查看单条全文 + 留存证据清单与健康校验。
 * - { action:"export", id, dir } 导出自包含包（md + 同名 .evidence/ 证据目录）。
 *   dir 仅用于 export——log/resolve 传 dir 为 invalid-input。
 *
 * P5（寄生增强方案 §9 P5 行 + §4.2，pi-0.99.1 批）：outputSchema + structuredContent 双载体。
 * 正文 content 为 O3b 展开加键（B9 有意增量：证据披露行/留存章节）；副作用流程零变化——
 * log/resolve/export 照旧真实写盘/迁移/导出，list 的版本自愈迁移只由其原有单次调用发生。
 */

import { StringEnum } from "@earendil-works/pi-ai";
import { Type } from "typebox";
import * as fs from "node:fs";
import * as path from "node:path";
import {
	logItem, listItems, resolveItem, renderItemsText, serializeItem, evolutionRoot, redactItemForOutput,
	type EvolutionCategory, type EvolutionItem, type EvolutionSeverity, type EvolutionSessionRef, type EvolutionStatus,
} from "./evolution-log.ts";
import {
	type EvidenceInput, type EvidenceResult, type EvidenceState,
	validateEvidenceInputs, resolveManagedEvolutionRoot, prepareExportDir, ensureExportDir,
	planExportEvidencePackage, publishExportEvidencePackage, preflightExportPackageTargets,
	verifyEvidenceAt, renderEvidenceSection, globalEvidencePathFor, containsPrivateKeyBlock,
	LEGACY_EVIDENCE_NOTE, INVALID_MANIFEST_NOTE, EvidenceSecurityError, safeWriteRegularFile, enforceWriteTarget,
} from "./evolution-evidence.ts";
// P5：结构化输出 wire——纯 schema/投影模块（mapper 零 I/O/零副作用），接线层在此。
import {
	EvolutionOutputSchema, toLogWire, toListWire, toResolveWire, toShowWire, toExportWire, toEvolutionErrorWire,
} from "./evolution-wire.ts";

/** 从 package.json 读当前插件版本（自愈迁移基准）；失败返回 undefined（禁用自愈）。 */
function currentPluginVersion(packageRoot?: string): string | undefined {
	if (!packageRoot) return undefined;
	try {
		const pkg = JSON.parse(fs.readFileSync(path.join(packageRoot, "package.json"), "utf8"));
		return typeof pkg.version === "string" ? pkg.version : undefined;
	} catch { return undefined; }
}

/** pi 当前会话现场：两个值都可靠可得时才附加；缺任一项即无副作用降级。 */
export function evolutionSessionRef(env: NodeJS.ProcessEnv = process.env): EvolutionSessionRef | undefined {
	const sessionId = (env.PI_SESSION_ID || "").trim();
	const jsonlPath = (env.PI_SESSION_PATH || env.PI_SESSION_FILE || "").trim();
	return sessionId && jsonlPath ? { sessionId, jsonlPath } : undefined;
}

/** 写动作意外异常的 error 码（§4.2 语义）：写动作（log/resolve/export）抛错 → operation（操作失败）；
 *  读动作（list/show）→ internal。与 P4 全 internal 的差异见 P5 报告裁定项。 */
function unexpectedErrorCode(action: unknown): "operation" | "internal" {
	return action === "log" || action === "resolve" || action === "export" ? "operation" : "internal";
}

/** 回执披露：未留存逐项（不阻断沉淀的诚实缺口）+ 警告行。 */
function evidenceDisclosure(results?: readonly EvidenceResult[], warnings?: readonly string[]): string {
	const lines: string[] = [];
	for (const r of results ?? []) {
		if (r.record.state === "omitted") lines.push(`未留存: ${r.record.key}（原因: ${r.record.reason}）`);
	}
	for (const w of warnings ?? []) lines.push(`注意: ${w}`);
	return lines.length > 0 ? `\n${lines.join("\n")}` : "";
}

/** 新条目/备注输入的私钥块窄拒收（整次 invalid-input——须在任何截断前检查完整输入）。 */
function rejectPrivateKeyInputs(fields: readonly (string | undefined)[]): string | null {
	for (const f of fields) {
		if (f !== undefined && containsPrivateKeyBlock(f)) {
			return "输入含私钥块（-----BEGIN ... PRIVATE KEY-----）：移除后重试；已泄露凭据须轮换，本工具不承诺通用秘密检测";
		}
	}
	return null;
}

/** show 的证据呈现（只读校验——不更新 digest、不落缓存、不触发自愈）。 */
function showEvidenceOf(root: string, item: EvolutionItem): { section: string; results: EvidenceResult[]; state: EvidenceState; warnings: string[] } {
	if (item.evidenceInvalid) {
		return { section: `\n## 留存证据\n\n${INVALID_MANIFEST_NOTE}\n`, results: [], state: "invalid", warnings: [] };
	}
	if (item.evidence === undefined) {
		return { section: `\n## 留存证据\n\n${LEGACY_EVIDENCE_NOTE}\n`, results: [], state: "legacy", warnings: [] };
	}
	const mdDir = path.join(root, item.status === "open" ? "open" : "resolved");
	const v = verifyEvidenceAt(mdDir, item.evidence, (hex) => globalEvidencePathFor(item.id, hex));
	return { section: renderEvidenceSection(v.results), results: v.results, state: "recorded", warnings: v.warnings };
}

export function createEvolutionTool(deps?: { packageRoot?: string; env?: NodeJS.ProcessEnv }) {
	type EvidenceParam = { path: string; summary?: string; lines?: { start: number; end: number } };
	type ActionParams = {
		action: "log" | "list" | "resolve" | "show" | "export";
		title?: string; category?: EvolutionCategory; severity?: EvolutionSeverity;
		phenomenon?: string; expected?: string; source?: string;
		status?: EvolutionStatus | "all"; id?: string; fixVersion?: string; note?: string;
		/** export：外部知识库目录（或 AMAGI_EVOLUTION_EXPORT_DIR）。log/resolve 传 dir → invalid-input。 */
		dir?: string;
		/** log/首次 resolve：留存证据文件（≤3；结构校验后转 EvidenceInput[]）。 */
		evidence?: EvidenceParam[];
	};
	/** 单 action 执行主体（P5 拆出）：返回旧契约形状（content[/isError]）+ structuredContent 新键。 */
	const executeAction = (params: ActionParams) => {
		if (params.action === "log") {
			if (!params.title || !params.phenomenon || !params.expected) {
				const text = "log 需要 title + phenomenon + expected（category/severity/source 可选）";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("log", "invalid-input", text) };
			}
			if (params.dir) {
				const text = "log 不接受 dir（dir 仅用于 export；log 的真实写面只有配置的 evolution 根）——省略 dir 重发即可";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("log", "invalid-input", text) };
			}
			const pem = rejectPrivateKeyInputs([params.title, params.phenomenon, params.expected, params.source]);
			if (pem) return { content: [{ type: "text" as const, text: pem }], isError: true, structuredContent: toEvolutionErrorWire("log", "invalid-input", pem) };
			let evidence: EvidenceInput[] | undefined;
			if (params.evidence !== undefined) {
				const v = validateEvidenceInputs(params.evidence);
				if (!v.ok) return { content: [{ type: "text" as const, text: v.error }], isError: true, structuredContent: toEvolutionErrorWire("log", "invalid-input", v.error) };
				evidence = v.value;
			}
			const r = logItem({ title: params.title, category: params.category, severity: params.severity, phenomenon: params.phenomenon, expected: params.expected, source: params.source, sessionRef: evolutionSessionRef(deps?.env), evidence });
			return {
				content: [{ type: "text" as const, text: `[evolution log] ${r.id} 已沉淀\n路径: ${r.path}${evidenceDisclosure(r.evidenceResults, r.warnings)}` }],
				structuredContent: toLogWire(r.id, r.path, r.evidenceResults, r.warnings),
			};
		}
		if (params.action === "list") {
			// 单次 listItems（含其自身的版本自愈迁移副作用）——正文与 wire 同源投影，不追加第二次读取（§9 P5）
			const root = evolutionRoot();
			const warnings: string[] = [];
			const items = listItems({ status: params.status ?? "open", currentVersion: currentPluginVersion(deps?.packageRoot) }, root, warnings);
			const label = params.status === "resolved" ? "已解决" : params.status === "all" ? "全部" : "未解决（open）";
			return { content: [{ type: "text" as const, text: renderItemsText(items, `[evolution] ${label}改进项`) }], structuredContent: toListWire({ root, items, warnings }) };
		}
		if (params.action === "resolve") {
			if (!params.id) {
				const text = "resolve 需要 id（或前缀）";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("resolve", "invalid-input", text) };
			}
			if (params.dir) {
				const text = "resolve 不接受 dir（dir 仅用于 export；resolve 的真实写面只有配置的 evolution 根）——省略 dir 重发即可";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("resolve", "invalid-input", text) };
			}
			const pem = rejectPrivateKeyInputs([params.note, params.fixVersion]);
			if (pem) return { content: [{ type: "text" as const, text: pem }], isError: true, structuredContent: toEvolutionErrorWire("resolve", "invalid-input", pem) };
			let evidence: EvidenceInput[] | undefined;
			if (params.evidence !== undefined) {
				const v = validateEvidenceInputs(params.evidence);
				if (!v.ok) return { content: [{ type: "text" as const, text: v.error }], isError: true, structuredContent: toEvolutionErrorWire("resolve", "invalid-input", v.error) };
				evidence = v.value;
			}
			const r = resolveItem(params.id, { fixVersion: params.fixVersion ?? currentPluginVersion(deps?.packageRoot), note: params.note, evidence });
			if (!r.ok) {
				const code = r.errorCode === "operation" || r.errorCode === "invalid-input" ? r.errorCode : "not-found";
				return { content: [{ type: "text" as const, text: r.error || "resolve 失败" }], isError: true, structuredContent: toEvolutionErrorWire("resolve", code, r.error || "resolve 失败") };
			}
			return {
				content: [{ type: "text" as const, text: `[evolution resolve] ${r.id} 已标记解决并迁移 → ${r.path}${evidenceDisclosure(r.evidenceResults, r.warnings)}` }],
				structuredContent: toResolveWire({ id: r.id!, path: r.path!, fixVersion: r.fixVersion, evidence: r.evidenceResults, warnings: r.warnings }),
			};
		}
		// show / export：单条定位（纯读——不携 currentVersion，不触发自愈迁移）
		if (!params.id) {
			const text = `${params.action} 需要 id（或前缀）`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire(params.action, "invalid-input", text) };
		}
		const root = evolutionRoot();
		const all = listItems({ status: "all" }, root);
		const hits = all.filter((i) => i.id === params.id || i.id.startsWith(params.id!));
		if (hits.length !== 1) {
			const text = hits.length === 0 ? `未找到: ${params.id}` : `前缀歧义: ${params.id} 匹配 ${hits.length} 条`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire(params.action, hits.length === 0 ? "not-found" : "invalid-input", text) };
		}
		const item = hits[0];
		if (params.action === "show") {
			const evi = showEvidenceOf(root, item);
			// B9 修复轮 F02：正文出口净化（历史未脱敏正文与 wire 同源；不改磁盘源文件）
			const body = serializeItem(redactItemForOutput(item)) + evi.section;
			if (containsPrivateKeyBlock(body)) {
				const text = "条目正文含私钥块，拒绝输出（不原样扩散、不自动擦除历史）——需人工脱敏摘录后另存";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("show", "operation", text) };
			}
			return { content: [{ type: "text" as const, text: body }], structuredContent: toShowWire({ root, item, evidence: evi.results, evidenceState: evi.state, warnings: evi.warnings }) };
		}
		// export（v1.5.193 + B9）：自包含包——md 为提交点，同名 <id>.evidence/ 携脱敏副本
		const dir = (params.dir || process.env.AMAGI_EVOLUTION_EXPORT_DIR || "").trim();
		if (!dir) {
			const text = "export 需要 dir（或设 AMAGI_EVOLUTION_EXPORT_DIR）";
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("export", "invalid-input", text) };
		}
		if (item.evidenceInvalid) {
			const text = `条目 ${item.id} 证据清单损坏（invalid-manifest）——拒绝导出，须人工核对 evidence 字段`;
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("export", "operation", text) };
		}
		try {
			const managed = resolveManagedEvolutionRoot(root);
			const ex = prepareExportDir(dir, item.id);
			// F01 终裁确认：先规划（零写入）→ 全部目标点预检 → 再实体化/发布
			const plan = planExportEvidencePackage(managed.canonical, ex.root, item.id, item.evidence);
			// 导出 md 省略 sourceContext/sessionRef（去除自动记录的本机绝对根——有意收紧，发布说明口径）
			// B9 修复轮 F02：导出 md 与 wire/磁盘同口径净化（历史未脱敏正文不随包扩散）
			const exportItem: EvolutionItem = {
				...redactItemForOutput(item),
				sessionRef: undefined,
				sourceContext: undefined,
				evidenceVersion: plan.records.length > 0 ? 1 : item.evidenceVersion,
				evidence: plan.records.length > 0 ? plan.records : (item.evidence !== undefined ? [] : undefined),
			};
			const section = plan.records.length > 0
				? renderEvidenceSection(plan.results)
				: (item.evidence !== undefined ? renderEvidenceSection([]) : `\n## 留存证据\n\n${LEGACY_EVIDENCE_NOTE}\n`);
			const md = serializeItem(exportItem) + section;
			if (containsPrivateKeyBlock(md)) {
				const text = "导出内容含私钥块，拒绝写盘（不原样扩散）——需人工脱敏摘录后另存";
				return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("export", "operation", text) };
			}
			const out = path.join(ex.root, `${item.id}.md`);
			const tmp = `${out}.tmp-${process.pid}`;
			enforceWriteTarget(out, { full: true }); // F01 终裁：导出 md 目标点预检（含围栏）
			enforceWriteTarget(tmp, { full: true });
			preflightExportPackageTargets(plan); // F01 终裁二轮：包内目标预检先于任何 mkdir（拒绝时零目录创建）
			ensureExportDir(ex, item.id); // 预检全过后才实体化目录 + 子对象链接/类型检查
			const published = publishExportEvidencePackage(plan); // 包内目标纵深复检（full）→ mkdir/写/链接
			safeWriteRegularFile(tmp, md); // F04：预存链接拒绝重写 + O_NOFOLLOW
			fs.renameSync(tmp, out);
			const bytes = Buffer.byteLength(md, "utf8");
			const retainedCount = published.records.filter((r) => r.state === "retained").length;
			const evLine = retainedCount > 0 ? `\n证据: ${retainedCount} 份 → ${path.join(dir, `${item.id}.evidence`)}` : "";
			return {
				content: [{ type: "text" as const, text: `[evolution export] ${item.id} → ${out}${evLine}${evidenceDisclosure(published.results, published.warnings)}` }],
				structuredContent: toExportWire(item.id, out, bytes, { evidence: published.results, evidenceState: published.evidenceState, evidenceBytes: published.evidenceBytes, evidenceComplete: published.evidenceComplete, warnings: published.warnings }),
			};
		} catch (e) {
			const text = e instanceof EvidenceSecurityError ? e.message : `export 写失败: ${(e as Error).message}`;
			const code = e instanceof EvidenceSecurityError ? "permission" : "operation";
			return { content: [{ type: "text" as const, text }], isError: true, structuredContent: toEvolutionErrorWire("export", code, text) };
		}
	};
	return {
		name: "amagi_evolution",
		label: "Amagi Evolution Log",
		description:
			"插件自进化日志：沉淀任务执行中的阻断点/摩擦点/期望改进到全局路径（log，可携 evidence 证据文件：≤3 个普通文件、每个 ≤64KB、内容凭据脱敏后留存于 evolution 根并随条目迁移），" +
			"查询未解决改进项（list，自动按版本自愈迁移已解决项），标记解决并迁移归档（resolve，可携 resolve 阶段证据与 note），查看单条全文与留存证据清单（show），导出自包含包（export）。",
		promptSnippet:
			`amagi_evolution({ action:"log", title, category, severity, phenomenon, expected, source, evidence }) — 沉淀摩擦点/期望改进（evidence=[{path,summary?}] 留存复现夹具，≤3 个 ≤64KB，脱敏后随条目可核验）；` +
			`amagi_evolution({ action:"list", status:"open" }) — 未解决改进项；` +
			`amagi_evolution({ action:"resolve", id, fixVersion, note, evidence }) — 标记解决（自动迁移归档）；` +
			`amagi_evolution({ action:"show", id }) — 全文+留存证据清单`,
		parameters: Type.Object({
			action: StringEnum(["log", "list", "resolve", "show", "export"], { description: "log=沉淀 / list=查询 / resolve=标记解决 / show=单条全文+证据清单 / export=导出自包含包（md+证据目录）到外部知识库" }),
			title: Type.Optional(Type.String({ description: "log: 条目标题（≤120字）" })),
			category: Type.Optional(StringEnum(["bug", "friction", "ux", "capability"], { description: "log: 归类（bug/摩擦/交互/能力）" })),
			severity: Type.Optional(StringEnum(["P0", "P1", "P2", "P3"], { description: "log: 严重度（P0-P3，缺省 P2）" })),
			phenomenon: Type.Optional(Type.String({ description: "log: 现象（含证据：任务/会话/报错）" })),
			expected: Type.Optional(Type.String({ description: "log: 期望改进" })),
			source: Type.Optional(Type.String({ description: "log: 来源（会话/任务标识，≤300字；解析基准 cwd/gitRoot 另以结构化字段留存）" })),
			evidence: Type.Optional(Type.Array(Type.Object({
				path: Type.String({ description: "证据文件路径（相对当前 cwd 解析；普通文件 ≤64KB；敏感/凭据路径拒收；符号链接拒收）" }),
				summary: Type.Optional(Type.String({ description: "用途说明（脱敏后 ≤240 字）" })),
				lines: Type.Optional(Type.Object({
					start: Type.Integer({ minimum: 1, description: "起始行（1-based 闭区间，指向脱敏后副本）" }),
					end: Type.Integer({ minimum: 1, description: "结束行（≥start；越界自动清除并告警）" }),
				}, { description: "行锚（可选）" })),
			}), { maxItems: 3, description: "log/首次 resolve: 留存证据文件（≤3 个；内容经凭据脱敏后复制到 evolution 根；单项缺失/超限不阻断沉淀，回执披露未留存原因；不要粘贴凭据）" })),
			status: Type.Optional(StringEnum(["open", "resolved", "all"], { description: "list: 状态过滤（缺省 open）" })),
			id: Type.Optional(Type.String({ description: "resolve/show/export: 条目 id 或前缀" })),
			fixVersion: Type.Optional(Type.String({ description: "resolve: 修复发布版本（如 1.5.174）" })),
			note: Type.Optional(Type.String({ description: "resolve: 备注（首次有效 resolve 持久化并随 show/export 呈现；推荐引 evidence key）" })),
			dir: Type.Optional(Type.String({ description: "export: 目标目录（缺省读 AMAGI_EVOLUTION_EXPORT_DIR；log/resolve 传 dir 拒绝）" })),
		}),
		/** P5（寄生增强方案 §4.2）：结构化输出 schema（宿主 0.99+ ToolDefinition.outputSchema：TSchema）。
		 *  声明后 execute 成功/失败均携 structuredContent（六封闭分支 Union：log/list/resolve/show/
		 *  export/error；消费者判据 kind/wireVersion/action/ok/schemaVersion）。 */
		outputSchema: EvolutionOutputSchema,
		async execute(_id: string, params: ActionParams) {
			// P5 双载体：正常分支正文/错误文案零改动（executeAction 内逐分支同文案）；
			// 意外异常兜底 error wire——正文复刻宿主对抛错的归一形状
			//（pi 0.99.1 executePreparedToolCall catch → createErrorToolResult：content=message、
			// details={}、isError），只加 structuredContent 新键（旧消费者面零变化）。
			try {
				return executeAction(params);
			} catch (e) {
				const message = e instanceof Error ? e.message : String(e);
				// B9 修复轮 F01：安全拒斥（deny 禁入/敏感路径/围栏）语义上是 permission，不混同 operation
				const code = e instanceof EvidenceSecurityError ? "permission" : unexpectedErrorCode(params?.action);
				return {
					content: [{ type: "text" as const, text: message }],
					details: {},
					isError: true,
					structuredContent: toEvolutionErrorWire(params?.action, code, message),
				};
			}
		},
	};
}
