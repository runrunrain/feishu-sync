/**
 * write-override.ts — P1-D（插件进化8.19）：同名覆盖内置 write，成功写盘后附加 LSP 推送式诊断；
 * ev-20260830-e115cb：回执回显实际落盘路径 + POSIX 绝对路径 × WSL bash 的跨运行时告警。
 *
 * 机制与 bash-override/edit-override 同构（pi extensions.md「Overriding Built-in Tools」官方模式，
 * 内置 write 可被同名扩展覆盖且渲染按槽继承）：全参数原样委托 createWriteToolDefinition(cwd).execute
 * （mkdir/writeFile/withFileMutationQueue/abort 语义全走原生路径，成功与失败行为与原生一致——原生
 * 失败以 throw 表达，本覆盖不捕获不改写）；成功返回后：
 *  - ev-20260830-e115cb：回执追加 [amagi write] 注记——回显实际落盘绝对路径（原生回执只回显
 *    书写形态）；win32 宿主收到 POSIX 绝对路径（/tmp/x.py 等）时附跨运行时告警：write 在 Windows
 *    侧按当前盘根解析，而 bash（WSL）的 / 属另一文件系统——实战：write /tmp/x.py 回执成功但
 *    bash python3 /tmp/x.py 找不到（相对 cwd 路径两侧互通）。运行时信息经 runtime-env 模块级
 *    缓存懒探测（仅 POSIX 绝对路径触发，常规写入零探测）；探测失败仍给通用告警，绝不阻断写入。
 *  - ev-20260925-287e93（双宿主根治 §2.2，复盘 P2）：POSIX 绝对路径自动重定向——win32 宿主 +
 *    bash 跑在 WSL（distro 已知）时，path 改写为 \\wsl.localhost\<distro><posix>（9P 落盘进
 *    WSL 文件系统，bash 侧路径即原 POSIX 路径），回执改发重定向注记（双侧路径）；/mnt/<盘>/
 *    形态确定性映射到 <盘>:\。distro 未知（探测失败）不重定向，维持原语义 + 通用告警。
 *  - 把被写文件交给 EditDiagnostics.attach 追加 `[LSP 诊断]` 段（不可用/超时/开关关闭 → 原样返回）。
 * 提示、参数和渲染元数据继承原生定义；execute 增补权限、路径与诊断能力。
 * 注册范围由 index.ts 的宿主平台、权限上下文与路径防线开关决定。
 */

import { createWriteToolDefinition } from "@earendil-works/pi-coding-agent";
import { builtinFileCwd, resolveBuiltinFileTarget } from "./builtin-file-target.ts";
import type { EditDiagnostics } from "./edit-diagnostics.ts";
import { resolveBuiltinConstrainedSampling } from "./host-capabilities.ts";
import { enforceFileWriteTargets, failStrictTaskStartup, strictEnforcementActive } from "./file-permission.ts";
import { enforceLargeWriteEmission } from "./large-emission-guard.ts";
import { isPosixStyleAbsolutePath, posixToWindowsVisible, probeBashRuntime, writePathAdvisoryNote, type BashRuntimeInfo } from "./runtime-env.ts";
import { recordTaskWrite } from "./task-write-log.ts";

export interface WriteOverrideDeps {
	/** 诊断注入器；缺省无注入（纯透传，行为与原生 write 一致）。 */
	editDiagnostics?: Pick<EditDiagnostics, "attach">;
	/** ev-20260830-e115cb：bash 运行时信息（缺省懒探测缓存；测试注入固定值）。 */
	bashRuntime?: () => BashRuntimeInfo;
	/** 宿主平台（测试注入；缺省 process.platform）。 */
	hostPlatform?: string;
}

/** 结果尾部追加注记：浅克隆并仅在首个 text 条目后换行追加，其余字段原样保留；形态异常原样返回。 */
import { writeDriftNote } from "./path-drift.ts";

/** diting 审核 M1（ev-20260929-3c5db4 后续）：失败回执不附「写入已生效」类注记——原生 write
 *  以 throw 表达失败（本覆盖不捕获），但结果体形态（isError:true）一旦出现，drift 注记的
 *  「写入已生效」断言即为错误陈述。pathNote（落盘路径回显/跨运行时告警）是路径映射信息，
 *  与写入成败无关，失败时保留。纯函数供测试直接断言。 */
export function notesForWriteResult(pathNoteText: string | null, driftNoteText: string | null, failed: boolean): string | null {
	const parts = [pathNoteText, failed ? null : driftNoteText].filter((x): x is string => x !== null && x !== "");
	return parts.length > 0 ? parts.join("\n") : null;
}

function appendAdvisory(result: unknown, note: string | null): unknown {
	if (!note || !result || typeof result !== "object") return result;
	const r = result as { content?: unknown };
	if (!Array.isArray(r.content) || r.content.length === 0) return result;
	const first = r.content[0] as { text?: unknown } | undefined;
	if (!first || typeof first !== "object" || typeof first.text !== "string") return result;
	const content = r.content.slice();
	content[0] = { ...(first as object), text: `${first.text}\n${note}` };
	return { ...(r as object), content };
}

/** 创建覆盖内置 write 的同名工具：委托原生 + 成功写盘后路径注记与诊断注入（均静默降级）。 */
export function createWriteOverrideTool(baseCwd: string = process.cwd(), deps: WriteOverrideDeps = {}) {
	const baseDef = createWriteToolDefinition(baseCwd);
	const attach = async (result: unknown, file: unknown): Promise<unknown> => {
		if (!deps.editDiagnostics || typeof file !== "string" || file === "") return result;
		try { return await deps.editDiagnostics.attach(result, [file]); } catch { return result; }
	};
	/** ev-20260830-e115cb：路径注记——常规写入只回显落盘路径；win32+POSIX 绝对路径才求值运行时探测。
	 *  ev-20260925-287e93：redirected=true（已重定向到 WSL 侧路径）时发双侧路径重定向回执。 */
	const pathNote = (rawPath: string, actualPath: string, cwd: string, redirected = false): string | null => {
		const raw = rawPath;
		if (!raw) return null;
		const host = deps.hostPlatform ?? process.platform;
		if (redirected) {
			return writePathAdvisoryNote(raw, actualPath, { probed: false, wsl: false }, { hostPlatform: host, redirected: true });
		}
		const resolved = actualPath;
		if (host === "win32" && /^\//.test(raw)) {
			let info: BashRuntimeInfo = { probed: false, wsl: false };
			try { info = deps.bashRuntime ? deps.bashRuntime() : probeBashRuntime(cwd); } catch { /* 通用告警 */ }
			return writePathAdvisoryNote(raw, resolved, info, { hostPlatform: host });
		}
		return writePathAdvisoryNote(raw, resolved, { probed: false, wsl: false }, { hostPlatform: host });
	};
	return {
		...baseDef,
		name: "write" as const,
		label: "write",
		description: baseDef.description,
		parameters: baseDef.parameters,
		prepareArguments: baseDef.prepareArguments,
		// pi 0.86.0 配合：对齐内置 write 默认 strict:prefer（AMAGI_BUILTIN_CONSTRAINED=0 逃生舱），见 host-capabilities.resolveBuiltinConstrainedSampling
		constrainedSampling: resolveBuiltinConstrainedSampling(),
		async execute(
			toolCallId: string,
			args: { path: string; content: string },
			signal: AbortSignal | undefined,
			onUpdate: ((partial: unknown) => void) | undefined,
			ctx: unknown,
		) {
			// ev-20260925-287e93（双宿主根治 §2.2）：win32 宿主 + bash 跑在 WSL 时，POSIX 绝对路径会被
			// 原生 write 按当前盘根解析落盘（X:\tmp\x.py）——bash（WSL）看不到，跨工具文件不可见。
			// 此处把 path 重定向到 WSL 侧可见路径：/mnt/<盘>/P → <盘>:\P（drvfs 同一文件系统，零探测）；
			// WSL 内部路径（/home、/tmp 等）→ \\wsl.localhost\<distro><P>（需 distro 已知，失败不重定向）。
			// 权限校验/登记/诊断均以重定向后的实际落盘目标为准（回执注记回显双侧路径）。
			const cwd = builtinFileCwd(baseCwd, ctx);
			const rawOriginal = typeof args?.path === "string" ? args.path : "";
			let redirected = false;
			if (rawOriginal !== "" && isPosixStyleAbsolutePath(rawOriginal) && (deps.hostPlatform ?? process.platform) === "win32") {
				let target = posixToWindowsVisible(rawOriginal, { probed: false, wsl: false });
				if (target === null) {
					let info: BashRuntimeInfo = { probed: false, wsl: false };
					try { info = deps.bashRuntime ? deps.bashRuntime() : probeBashRuntime(cwd); } catch { /* lint-exempt:探测失败不重定向，维持原语义（writePathAdvisoryNote 通用告警路径） */ }
					target = posixToWindowsVisible(rawOriginal, info);
				}
				if (target !== null) {
					redirected = true;
					args = { ...args, path: target };
				}
			}
			// P2（方案 §5.2 write 通道执行点）：原生 mkdir/writeFile 之前逐次权限校验（新目录最近存在
			// 父目录解析、符号链接 realpath、v2-store 重叠、deny 恒优先——越界 throw 即零写入；
			// 无活动权限上下文时零干预）。权限只校验目标，不改写内容与回执语义。
			const writeTarget = typeof args?.path === "string" ? args.path : "";
			const actualTarget = writeTarget !== "" ? resolveBuiltinFileTarget(writeTarget, cwd) : "";
			if (actualTarget !== "") enforceFileWriteTargets(cwd, [actualTarget]);
			// v2.15.0 大发射守卫（工具层硬闸）：riskyProviders 命中通道的单次 write 发射内容超 maxBytes
			// 时 throw（与上行越界 throw 同语义——覆盖层不捕获；enabled/env/provider/skipPatterns 不命中
			// 时零干预，守卫自身异常静默放行不阻断正常写入；prompt 层事前引导见 task-tool/leader-prompt）。
			if (actualTarget !== "") enforceLargeWriteEmission(actualTarget, args?.content, cwd);
			// ev-20260929-3c5db4（P0 漏层防线·写盘点）：原生 mkdir 发生在 execute 内——写盘前求值
			// 「本次需新建的中间层 + 项目内同名目录」；成功后回执追加疑似漏层 advisory（不阻断不回滚，
			// 本会话即时可核）。父目录存在的常规写入零扫描零成本；探测异常一律吞掉不影响写盘。
			const driftNote = writeDriftNote(cwd, actualTarget);
			const result = await baseDef.execute(toolCallId, args, signal, onUpdate as never, ctx as never);
			// ev-20260903-64641c（P0）：原生成功（无 throw）= 已写盘——登记绝对路径供结算三档归因
			//（命中=本任务写入；未设 AMAGI_TASK_ID 时 no-op，登记失败静默不影响回执）。
			if (actualTarget) recordTaskWrite(actualTarget, "write");
			const failed = (result as { isError?: boolean } | null | undefined)?.isError === true;
			return appendAdvisory(await attach(result, actualTarget), notesForWriteResult(pathNote(rawOriginal, actualTarget, cwd, redirected), driftNote, failed));
		},
	};
}

/** ev-20260929-3c5db4（P0 漏层防线）：类 Unix 无活动权限上下文场景的 write 覆盖注册开关（默认开
 *  ——深层路径漏层后 write 自动 mkdir 零告警是全场景风险，不只执法上下文；AMAGI_WRITE_OVERRIDE=
 *  0/false/off 恢复旧行为：该场景不注册，win32/活动权限上下文恒注册不受影响）。 */
export function writeOverrideDriftEnabled(env: string | undefined = process.env.AMAGI_WRITE_OVERRIDE): boolean {
	const v = env?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

// ── 注册器（P4 接线：index.ts 改用本入口，严格任务注册失败即拒启动） ──────────

export interface WriteOverridePi {
	registerTool(tool: unknown): void;
}

export interface WriteOverrideRegisterDeps extends WriteOverrideDeps {
	/** 工作目录（缺省 process.cwd()）。 */
		cwd?: string;
}

/**
 * 注册 write 覆盖版（P2 新增接缝，供 index.ts/P4 接线）：注册失败时——
 * legacy 静默降级（原生 write 不受影响）；严格任务（tool-enforced 活动权限上下文）例外：
 * failStrictTaskStartup（exit 1）——override 是 write 通道逐次权限校验的执法点，
 * 静默降级为原生 write = 校验旁路，任务启动即拒（不静默降级为无包装器原生工具）。
 */
export function registerWriteOverrideTool(pi: WriteOverridePi, deps: WriteOverrideRegisterDeps = {}): void {
	try {
		pi.registerTool(createWriteOverrideTool(deps.cwd ?? process.cwd(), deps));
	} catch (e) {
		const cause = e instanceof Error ? e.message : String(e);
		if (strictEnforcementActive()) {
			failStrictTaskStartup(`write override 注册失败（${cause}）——tool-enforced 任务的 write 通道逐次权限校验依赖同名 override，禁止静默降级为无包装器原生 write。`);
		}
		throw e; // legacy：调用方静默降级（原生 write 不受影响）
	}
}
