/** Startup summary of old unreviewed receipts. Read-only; decisions stay explicit. */
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { contractStoreRoot } from "./artifact.ts";
import { loadStoredTaskSnapshot } from "./task-service.ts";

const TERMINAL = new Set(["done", "error", "answered", "cancelled", "truncated", "resolved-external"]);
const DAY_MS = 24 * 60 * 60 * 1000;
export interface PendingAcceptanceSummary {
	count: number;
	oldest: number;
	roles: Record<string, number>;
	batchIds: string[];
	reviewIds: string[];
	unreadable: number;
	signature: string;
}

export async function scanPendingAcceptance(opts: { ownerId: string; machineId?: string; root?: string; now?: number }): Promise<PendingAcceptanceSummary> {
	const root = opts.root ?? contractStoreRoot();
	const summary: PendingAcceptanceSummary = { count: 0, oldest: Infinity, roles: {}, batchIds: [], reviewIds: [], unreadable: 0, signature: "" };
	let entries;
	try { entries = await fs.readdir(root, { withFileTypes: true }); }
	catch (e) { /* lint-exempt:没有历史目录时返回空；其它读取失败保留错误，不冒充空库 */
		if ((e as NodeJS.ErrnoException).code === "ENOENT") return summary;
		throw e;
	}
	const pending: Array<{ id: string; at: number; revision: number; receiptId: string; agent: string; batch: boolean }> = [];
	for (const entry of entries) {
		if (!entry.isDirectory() || !/^[\w-]+$/.test(entry.name)) continue;
		try {
			// Cheap prefilter only. Every included record still passes the store's complete digest/chain validation.
			const raw = JSON.parse(await fs.readFile(path.join(root, entry.name, "current.json"), "utf8"));
			if (!TERMINAL.has(raw.execution) || raw.acceptance !== "unreviewed" || !raw.currentReceipt) continue;
			const loaded = await loadStoredTaskSnapshot(entry.name, root);
			if (!loaded.ok) { summary.unreadable++; continue; }
			const { run, spec, receipt } = loaded.value;
			// A decision may land between the prefilter read and this validated load.
			if (!TERMINAL.has(run.execution) || run.acceptance !== "unreviewed") continue;
			const local = spec.machineId !== undefined ? spec.machineId === opts.machineId : run.ownerId === opts.ownerId;
			if (!local || !receipt) continue;
			const at = run.exitedAt ?? receipt.createdAt;
			if ((opts.now ?? Date.now()) - at <= DAY_MS) continue;
			pending.push({ id: run.taskId, at, revision: run.revision, receiptId: receipt.receiptId, agent: spec.agent,
				// The frozen task's declared write surface, not today's mutable role configuration.
				batch: spec.permission.write.length === 0 && receipt.settlement === "ready" && receipt.missing.length === 0 });
		} catch { /* lint-exempt:单条坏记录不阻断启动汇总，披露跳过数量 */ summary.unreadable++; }
	}
	pending.sort((a, b) => a.at - b.at || a.id.localeCompare(b.id));
	for (const p of pending) {
		summary.count++;
		summary.oldest = Math.min(summary.oldest, p.at);
		summary.roles[p.agent] = (summary.roles[p.agent] ?? 0) + 1;
		(p.batch ? summary.batchIds : summary.reviewIds).push(p.id);
	}
	summary.signature = createHash("sha256").update(JSON.stringify(pending)).digest("hex");
	return summary;
}

export function renderPendingAcceptance(summary: PendingAcceptanceSummary): string {
	if (!summary.count) return "";
	const roles = Object.entries(summary.roles).sort(([a], [b]) => a.localeCompare(b)).map(([role, count]) => `${role} ${count}`).join("、");
	const lines = [`[待验收汇总] 本机 ${summary.count} 个终态任务超过 24 小时未验收；最早 ${new Date(summary.oldest).toISOString().slice(0, 10)}（UTC）；角色：${roles}。`];
	if (summary.batchIds.length) {
		const ids = summary.batchIds.slice(0, 20);
		lines.push(`写面为空且已结算的候选 ${summary.batchIds.length} 个。核对其只读/报告产物后，可批量接受${ids.length < summary.batchIds.length ? `（本次列最早 ${ids.length} 个）` : ""}：`,
			`task_control(${JSON.stringify({ action: "accept", handles: ids, reason: "<填入产物核验依据>" })})`);
	}
	if (summary.reviewIds.length) lines.push(`另有 ${summary.reviewIds.length} 个写任务或存在结算缺口，逐个查看后决定；从 task_query(${JSON.stringify({ handle: summary.reviewIds[0], view: "receipt" })}) 开始。`);
	if (summary.unreadable) lines.push(`另跳过 ${summary.unreadable} 条不可读取记录；上述数量不包含它们。`);
	return lines.join("\n");
}

export function pendingAcceptanceNoticeAlreadyDelivered(entries: readonly any[], signature: string): boolean {
	return entries.some(entry => {
		const message = entry?.message ?? entry;
		return message?.customType === "amagi:pending-acceptance" && message?.details?.signature === signature;
	});
}
