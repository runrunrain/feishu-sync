/**
 * runtime-env.ts — ev-20260830-b70efc / ev-20260830-e115cb：bash 运行时环境自描述（低频缓存探测）。
 *
 * 痛点（两条 evolution 的共同根因）：pi 宿主进程与 bash 工具可能分属两个运行时（本机实证：
 * 宿主 Node 在 Windows（X:\... 路径语义），bash 工具经 pi getShellConfig 解析到
 * C:\Windows\System32\bash.exe 实际跑在 WSL2）。系统提示无任何环境自描述 → Agent 开局按
 * Windows shell 语义书写命令连败（pwsh 缺 .exe / MSYS 路径风格 / 2>nul 副作用）；
 * write 工具（Windows 侧解析）落 POSIX 绝对路径 /tmp/x.py 回执成功，bash（WSL 侧）却看不到
 * ——两个 /tmp 属不同文件系统（相对 cwd 路径两侧经会话目录互通）。
 *
 * 实现口径：
 *  - 探测与 pi bash 工具用同一 getShellConfig() 解析（含 legacy WSL bash.exe 的 stdin 传输
 *    形态），probe 命令一次拿全：uname -srm / $WSL_DISTRO_NAME / wslpath 换算会话目录 /
 *    command -v powershell.exe（PATH 是否可达 Windows exe）。
 *  - spawnSync + 2.5s 超时 + 模块级一次缓存：会话内零重复 fork；失败/无 shell → probed:false，
 *    全部消费方（leader-prompt 注入 / guards 127 诊断 / write 回执告警）静默降级，绝不阻断。
 *  - 纯格式化函数（formatBashRuntimeNote / writePathAdvisoryNote）与探测分离，hostPlatform
 *    可注入——测试在任意平台可覆盖 win32 宿主分支。
 *  - ev-3324e4（S3）：非 WSL 的 darwin 注入 BSD 工具差异短注记（常量文本，探测失败回退宿主平台判定，
 *    Linux 零注入）；AMAGI_PLATFORM_NOTE=0 仅关闭该段，不影响 WSL 说明。
 */

import { spawnSync } from "node:child_process";
import { getShellConfig } from "@earendil-works/pi-coding-agent";

export interface BashRuntimeInfo {
	/** 探测成功拿到 shell 自述（失败/超时/无 bash → false，消费方一律静默降级）。 */
	probed: boolean;
	/** bash 运行在 WSL（uname 含 microsoft 或 $WSL_DISTRO_NAME 非空）。 */
	wsl: boolean;
	/** $WSL_DISTRO_NAME（WSL 内非空）。 */
	distro?: string;
	/** uname -srm 单行摘要。 */
	uname?: string;
	/** 会话/工作目录在 bash 侧的真实路径（win32 宿主 + WSL bash 时经 wslpath 换算，如 /mnt/x/...）。 */
	bashCwd?: string;
	/** WSL 内 PATH 是否能直呼 Windows exe（command -v powershell.exe）；false = appendWindowsPath 已清。 */
	windowsExeOnPath?: boolean;
	/** 探测所用 shell 路径。 */
	shellPath?: string;
}

const NOT_PROBED: BashRuntimeInfo = { probed: false, wsl: false };

/** 探测超时（ms）：WSL bash.exe 冷启动上限量级；探测本身绝不长期阻塞宿主。 */
const PROBE_TIMEOUT_MS = 2_500;

let cached: BashRuntimeInfo | undefined;

/** 重置缓存（测试用；生产会话内只探测一次）。 */
export function resetBashRuntimeCache(): void {
	cached = undefined;
}

/** bash 单引号字面量（Windows 路径反斜杠在单引号内原样保留）。 */
function shellSingleQuote(s: string): string {
	return `'${s.replaceAll("'", `'\\''`)}'`;
}

/** 探测命令（一条 shell 语句拿全部字段；wslpath/command -v 失败输出空值不报错）。
 *  wslpath 只接受 Windows 路径——非盘符形态（类 Unix 宿主）直接输出空，防伪换算值。 */
export function buildProbeCommand(cwd: string): string {
	const wslpathProbe = /^[A-Za-z]:[\\/]/.test(cwd)
		? `printf 'AMAGI_WSLPATH=%s\\n' "$(wslpath ${shellSingleQuote(cwd)} 2>/dev/null || true)"`
		: `printf 'AMAGI_WSLPATH=%s\\n' ""`;
	return [
		"uname -srm",
		`printf 'AMAGI_DISTRO=%s\\n' "\${WSL_DISTRO_NAME:-}"`,
		wslpathProbe,
		`printf 'AMAGI_WINEXE=%s\\n' "$(command -v powershell.exe >/dev/null 2>&1 && echo yes || echo no)"`,
	].join("; ");
}

/** 解析探测输出（纯函数）：首行 uname + AMAGI_* 标记行。 */
export function parseProbeOutput(out: string, shellPath?: string): BashRuntimeInfo {
	const text = String(out ?? "");
	const uname = (text.split(/\r?\n/, 1)[0] || "").trim() || undefined;
	const distroRaw = text.match(/^AMAGI_DISTRO=(.*)$/m)?.[1]?.trim();
	const distro = distroRaw ? distroRaw : undefined;
	const bashCwdRaw = text.match(/^AMAGI_WSLPATH=(.*)$/m)?.[1]?.trim();
	const bashCwd = bashCwdRaw && /^\/.+/.test(bashCwdRaw) ? bashCwdRaw : undefined;
	const winExe = text.match(/^AMAGI_WINEXE=(yes|no)$/m)?.[1];
	return {
		probed: true,
		wsl: /microsoft/i.test(uname || "") || distro !== undefined,
		distro,
		uname,
		bashCwd,
		windowsExeOnPath: winExe === "yes" ? true : winExe === "no" ? false : undefined,
		shellPath,
	};
}

/** 供测试注入的探测执行器：返回 stdout（失败 undefined）。 */
export type ProbeRunner = (shellPath: string, args: string[], input: string | undefined) => string | undefined;

const defaultProbeRunner: ProbeRunner = (shellPath, args, input) => {
	const res = spawnSync(shellPath, args, { input, encoding: "utf8", timeout: PROBE_TIMEOUT_MS, windowsHide: true });
	if (res.error || res.status !== 0 || typeof res.stdout !== "string") return undefined;
	return res.stdout;
};

/**
 * 探测 bash 工具实际运行时（模块级一次缓存；cwd 只参与首次换算，之后原样返回缓存）。
 * 与 pi bash 工具同源解析 shell（getShellConfig），含 legacy WSL bash.exe 的 stdin 传输形态；
 * 任何失败返回 { probed:false, wsl:false }，绝不抛出。
 */
export function probeBashRuntime(cwd: string = process.cwd(), opts: { runProbe?: ProbeRunner } = {}): BashRuntimeInfo {
	if (cached) return cached;
	const run = opts.runProbe ?? defaultProbeRunner;
	try {
		const cfg = getShellConfig() as { shell: string; args: string[]; commandTransport?: string };
		const command = buildProbeCommand(cwd);
		const stdinTransport = cfg.commandTransport === "stdin";
		const out = run(cfg.shell, stdinTransport ? cfg.args : [...cfg.args, command], stdinTransport ? `${command}\n` : undefined);
		cached = out === undefined ? NOT_PROBED : parseProbeOutput(out, cfg.shell);
	} catch {
		cached = NOT_PROBED;
	}
	return cached;
}

/** POSIX 风格绝对路径（以 / 开头；win32 宿主上会被按当前盘根解析成另一文件）。 */
export function isPosixStyleAbsolutePath(p: string): boolean {
	const raw = String(p ?? "");
	return raw.startsWith("/") && !raw.startsWith("//");
}

/**
 * ev-20260925-287e93（双宿主根治 §2.1/§2.2）：POSIX 绝对路径 → Windows 侧可达路径（纯函数）。
 * 仅在 win32 宿主 + bash 跑在 WSL 的双宿主形态有意义：
 *  - /mnt/<盘>/P → <盘>:\P（drvfs 同一文件系统，确定性映射，不经 9P；盘符大写）；
 *  - 其余（WSL 内部文件系统，如 /home、/tmp）→ \\wsl.localhost\<distro>\P（9P UNC；bash 侧仍为 P）。
 * 返回 null = 不可映射（非 POSIX 绝对路径，或 WSL 内部路径但 distro 未知）——调用方按原语义回退。
 */
export function posixToWindowsVisible(posixPath: string, info: BashRuntimeInfo = WSL_EMPTY): string | null {
	const p = String(posixPath ?? "");
	if (!isPosixStyleAbsolutePath(p)) return null;
	const mnt = /^\/mnt\/([a-z])\/(.*)$/i.exec(p);
	if (mnt) {
		const rest = mnt[2].replace(/\//g, "\\");
		return rest === "" ? `${mnt[1].toUpperCase()}:\\` : `${mnt[1].toUpperCase()}:\\${rest}`;
	}
	if (!info.probed || !info.wsl || !info.distro) return null;
	return `\\\\wsl.localhost\\${info.distro}${p}`.replaceAll("/", "\\");
}

/**
 * ev-20260925-287e93：Windows 盘符绝对路径 → bash 侧 POSIX 路径（纯函数，用于回执/注记展示）：
 * X:\P 或 X:/P → /mnt/x/P；非盘符绝对路径（UNC 等）返回 null（无确定性映射）。
 */
export function windowsToPosixBashPath(winPath: string): string | null {
	const m = /^([A-Za-z]):[\\/](.*)$/.exec(String(winPath ?? ""));
	if (!m) return null;
	return `/mnt/${m[1].toLowerCase()}/${m[2].replace(/\\/g, "/")}`;
}

/** 格式化选项（hostPlatform 注入供测试在任意平台覆盖 win32 宿主分支；env 注入供测试覆盖开关解析）。 */
export interface RuntimeNoteOpts {
	hostPlatform?: string;
	env?: NodeJS.ProcessEnv;
}

const WSL_EMPTY: BashRuntimeInfo = { probed: false, wsl: false };

/**
 * ev-3324e4（S3，2026-09-16 优化方案 §5.2）：macOS 默认工具链 BSD 差异短注记（常量文本，
 * 不每轮探测/uname，重复构造输出字节稳定）。AMAGI_PLATFORM_NOTE=0 仅关闭本段，不影响 WSL 说明。
 */
const DARWIN_BSD_NOTE =
	"[amagi 运行环境] 当前为 macOS，默认工具可能是 BSD：xargs 通常无 -d，使用 NUL 输入配 -0；sed 使用明确起止行号，不用 GNU 的 N,+p 地址；cat 无 -A（GNU -A = -vET），查看不可见字符用 cat -et 或 od -c；readlink -f 跨版本不可靠，先确认能力或用已有 Node 路径解析。若 PATH 已切换 GNU 工具，以实际版本为准。";

/** ev-3324e4：AMAGI_PLATFORM_NOTE=0 关闭新增 darwin/BSD 平台短段（仅此一段，WSL 逻辑不受影响）。 */
export function platformNoteEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return String(env.AMAGI_PLATFORM_NOTE ?? "").trim() !== "0";
}

/**
 * ev-20260830-b70efc：bash 运行时环境自描述文本（注入 Leader 系统提示）。
 * win32 宿主 + WSL bash 时含完整错配信息（bash 侧 cwd / .exe 全名 / 跨工具相对路径纪律）——WSL 优先；
 * 类 Unix 宿主跑在 WSL 内时只保留 Windows 互操作提示（工具路径解析同侧，无割裂）。
 * ev-3324e4：非 WSL 的 darwin（探测成功以 uname 为准；探测失败回退宿主平台判定）注入 BSD 工具差异
 * 短段（Linux 零注入，不塞 macOS 禁令）；非 darwin 非 WSL → null 零噪音。
 */
export function formatBashRuntimeNote(info: BashRuntimeInfo, opts: RuntimeNoteOpts = {}): string | null {
	const host = opts.hostPlatform ?? process.platform;
	if (!info.probed || !info.wsl) {
		// ev-3324e4：darwin/BSD 短注记（WSL 优先探测逻辑保持在前；开关仅作用于本段）
		const isDarwinBash = info.probed ? /^Darwin\b/i.test(info.uname || "") : host === "darwin";
		return isDarwinBash && platformNoteEnabled(opts.env) ? DARWIN_BSD_NOTE : null;
	}
	const lines: string[] = ["[amagi 运行环境] bash 工具实际运行时（与文件工具的路径解析宿主可能不同）："];
	lines.push(`- uname：${info.uname || "(未知)"}${info.distro ? `；WSL 发行版：${info.distro}` : ""}`);
	if (host === "win32") {
		if (info.bashCwd) lines.push(`- 会话目录 bash 侧路径：${info.bashCwd}（Windows 盘挂载于 /mnt/<盘符>）`);
		lines.push(`- bash 命令一律按 Linux/POSIX 语义书写：Windows 工具需 .exe 全名（powershell.exe/pwsh.exe）${info.windowsExeOnPath === false ? "；当前 WSL PATH 无 Windows 目录（appendWindowsPath=false），须用 /mnt/<盘>/.../xxx.exe 全路径调用（powershell 全路径：/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe；tasklist/taskkill：/mnt/c/Windows/System32/），交互式工具尾部加 </dev/null" : "；PATH 未含 Windows 目录时用 /mnt/<盘>/.../xxx.exe 全路径"}；禁用 2>nul、C:\\ 反斜杠路径等 Windows shell 语法`);
		lines.push("- Windows 控制台工具输出编码：tasklist.exe 等中文消息为 GBK（乱码勿直读，用 grep -c 计数判定）；wsl.exe 输出为 UTF-16（grep 前先 tr -d '\\0'）");
		lines.push("- docker 双二进制路径语义：发行版内 /usr/bin/docker（Linux 二进制）必须传 POSIX 路径（/mnt/x/...）；Windows 侧 docker.exe（npipe 通道）才接受 X:/...——误传会把 X:/ 拼成 /mnt/x/.../X:/ 报 no such file");
		lines.push("- WSL interop 包装层退出码可能失真：Start-Process 等分离的 Windows 子进程长驻时，包装层等到超时（rc=124）但子进程本身正常——涉及 Windows 子进程的命令以输出内容+后续进程/端口实证为判据，勿单凭退出码");
		lines.push("- Docker Desktop 冷启动引擎就绪可达 3-4 分钟（轮询预算 ≥300s、5s 间隔）；`wsl --terminate docker-desktop`（仅工具发行版）后重启 ≈5s 就绪；/mnt/wsl/docker-desktop/docker-desktop-user-distro 挂成 0 字节即集成挂坏，自愈序列=全退 Desktop→terminate 工具发行版→重启 Desktop");
		lines.push("- write/edit 工具在 Windows 侧解析路径：POSIX 绝对路径在 WSL bash 已知时会自动重定向到 WSL 文件系统（回执标注 bash 侧路径）；read 无重定向——跨工具传文件仍一律用相对 cwd 路径最稳");
	} else {
		lines.push("- Windows 工具互操作需 .exe 全名（powershell.exe/pwsh.exe）；PATH 未含 Windows 目录时用 /mnt/<盘>/.../xxx.exe 全路径，交互式工具尾部加 </dev/null");
	}
	return lines.join("\n");
}

/**
 * ev-20260830-e115cb：write 回执路径注记（纯函数）——回显实际落盘路径；win32 宿主收到
 * POSIX 绝对路径时附跨运行时告警（info 已知 WSL 给出针对性文案，未知给通用文案）。
 * ev-20260925-287e93：opts.redirected=true（write-override 已把 POSIX 绝对路径重定向到
 * \\wsl.localhost UNC 落盘）时改发重定向回执——文件已实际落入 WSL 文件系统（bash 可见），
 * 回显双侧路径供核对，不再告警（陷阱已根治）。
 */
export function writePathAdvisoryNote(
	rawPath: string,
	resolvedPath: string,
	info: BashRuntimeInfo = WSL_EMPTY,
	opts: RuntimeNoteOpts & { redirected?: boolean } = {},
): string | null {
	const raw = typeof rawPath === "string" ? rawPath : "";
	if (!raw) return null;
	const host = opts.hostPlatform ?? process.platform;
	if (opts.redirected) {
		return `[amagi write] 跨运行时重定向：POSIX 绝对路径 ${raw} 已改写为 WSL 侧 ${resolvedPath} 落盘——文件实际位于 WSL 文件系统，bash 侧路径即 ${raw}（可直接读写）；跨工具回读（read 等 Windows 侧解析的工具）需用 ${resolvedPath}。`;
	}
	const lines = [`[amagi write] 实际落盘路径（${host === "win32" ? "Windows" : "本机"} 侧解析）：${resolvedPath}`];
	if (host === "win32" && isPosixStyleAbsolutePath(raw)) {
		lines.push(
			info.probed && info.wsl
				? `[amagi write] 跨运行时告警：POSIX 绝对路径 ${raw} 已落在 Windows 侧（${resolvedPath}），而 bash 运行在 WSL${info.distro ? `（${info.distro}）` : ""}——两侧 / 与 /tmp 属不同文件系统，bash 看不到该文件。跨 write/bash 工具传文件请改用相对 cwd 路径（两侧经会话目录互通）；bash 侧确需绝对路径时用其自身文件系统内的路径重写。`
				: `[amagi write] 跨运行时告警：POSIX 绝对路径 ${raw} 被宿主按当前盘根解析为 ${resolvedPath}；bash（另一运行时）的同类路径属不同文件系统，可能看不到该文件。跨 write/bash 工具传文件请改用相对 cwd 路径。`,
		);
	}
	return lines.join("\n");
}
