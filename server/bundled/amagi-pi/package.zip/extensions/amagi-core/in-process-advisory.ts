/**
 * in-process-advisory.ts — C15 进程内模型辅助解释通道（十月迭代 M4；设计 §6.5）。
 *
 * 目标：减少轻量、无工具、无独立角色要求的模型辅助调用开销——把「机器检查结果的解释/
 * advisory」从派生子 Agent（或独立 HTTP 决策端点）改为 Leader 进程内经宿主
 * `ctx.modelRegistry.streamSimple()` 的 provider 中立嵌套调用（凭据/模型目录已由宿主解析，
 * pi 1.0.2+）。**范围裁定（设计 §6.5，不可越）**：finalizer 的真实命令执行、冻结验证对象和
 * 结果归档继续原机制；本通道只做解释，不取得结算权，不代替角色执行。
 *
 * 纪律红线（设计 §6.5「接口与生命周期」）：
 *   1. 输入契约：脱敏机器事实摘要 + 固定提示版本 + 输入 digest + 显式物理模型名
 *      （provider/model）；禁止 tools、MCP、fs 权能，禁止把宿主 ctx 整体交给模型——
 *      构造的 Context 恒为 { systemPrompt, messages:[user] }，类型面即契约（tools?: never）。
 *   2. 单次调用强制 signal/超时/token 预算：外部 signal + 内部超时合并为单一 AbortSignal 传宿主
 *      （maxTokens 输出预算随请求）；另设独立超时墙兜底宿主不尊重 signal 的卡流——到墙必退。
 *   3. 取消/异常标 unavailable（stopReason 如实分档），主验证照常按机器结果结算；失败说明
 *      只携带真实机器错误关键词（error.message/宿主 stopReason/errorMessage 原文），无错误不编造。
 *   4. 调用事实按设计字段落 journal 增量通道（{kind:"in-process-advisory", …}）——不伪造
 *      taskId 派发/WAL 行；结果在 execution/settlement/acceptance 三轴之外的 advisory 域
 *      （展示注记由 evidence.renderAdvisoryEvidenceNote 明示「非机器验证结论」）。
 *   5. 默认关闭（amagi.json `inProcessAdvisory.enabled`；AMAGI_INPROCESS_ADVISORY_ENABLED
 *      逃生舱）；关闭时零调用零构造开销。
 *   6. 无重试——一次失败不自动双跑造成重复计费；后续调用才可再触发。
 *
 * usage 记账（设计 §6.5）：本切片场景为 finalizer 收尾链内调用（非工具执行）——宿主不自动
 * 计入会话成本，故单列费用：journal 行携带 usage 数值 + 模块级有界累计器
 * （readInProcessAdvisoryUsageTotals）供展示/报告消费；并入 webui UsageSnapshot 的接线提案
 * 见切片报告（usage-store 只读不改）。作为工具执行的接线（宿主 usage 自动记账、不重复加
 * nested usage）同样只留提案。
 *
 * 可插拔调用层：AdvisoryModelCaller 是 provider 中立窄接口——MockAdvisoryModel（确定性，
 * 供测试）与 HostStreamAdapter（包装 ctx.modelRegistry.streamSimple 的骨架；未注入
 * modelRegistry 时恒 unavailable）实现同一契约。model-resolver 的角色分层链不参与：advisory
 * 无角色语义，modelRef 由配置显式给出物理模型名，经 modelRegistry.find 做目录解析。
 */

import { createHash, randomUUID } from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { journalAdvisory } from "./journal.ts";

// ── 提示版本与固定提示词（promptVersion 进调用事实；改提示必须升版本）──

export const IN_PROCESS_ADVISORY_PROMPT_VERSION = "machine-check-advisory-v1";

/** 固定 system prompt：无工具权能 + advisory 语义 + 禁编造（红线 1/3）。 */
const ADVISORY_SYSTEM_PROMPT = [
	"You are an advisory explainer inside a coding-agent harness.",
	"You receive sanitized machine facts about a finished task's automated checks (structured check ids, statuses, exit codes) and the derived settlement face.",
	"Explain concisely in Chinese: (1) what the machine checks establish and what they do NOT establish; (2) what a human reviewer should verify manually before accepting the task.",
	"You have NO tools, NO filesystem access, NO MCP. Your output is advisory text only — it never gates settlement or acceptance.",
	"Do not invent check results, error messages or failures that are not present in the facts. If the facts are insufficient, say exactly that.",
].join(" ");

/** 事实摘要装配上限（字符）——超限裁剪尾部并标注，输入面有界。 */
export const ADVISORY_FACTS_MAX_CHARS = 4000;
/** 默认单次调用预算（毫秒 / 输出 token 上限）。 */
export const ADVISORY_DEFAULT_TIMEOUT_MS = 15000;
export const ADVISORY_DEFAULT_MAX_OUTPUT_TOKENS = 512;
/** 超时墙宽限：超时触发后给宿主流收尾的额外余量，到墙必退。 */
const ADVISORY_TIMEOUT_WALL_GRACE_MS = 2000;
/** 超时墙/异常路径等待底层调用自然收尾的上限（迟到结果丢弃，不消费）。 */
const ADVISORY_SWALLOW_WAIT_MS = 250;

// ── 配置（amagi.json `inProcessAdvisory` 节；全局打底、项目覆盖；mtime 缓存 + env 逃生舱）──

export interface InProcessAdvisoryConfig {
	enabled: boolean;
	/** 显式物理模型名（provider/model）。空 = 未配置 → 不调用（不猜默认模型）。 */
	model: string;
	timeoutMs: number;
	maxOutputTokens: number;
}

const ADVISORY_CFG_DEFAULTS: InProcessAdvisoryConfig = {
	enabled: false,
	model: "",
	timeoutMs: ADVISORY_DEFAULT_TIMEOUT_MS,
	maxOutputTokens: ADVISORY_DEFAULT_MAX_OUTPUT_TOKENS,
};

function globalAmagiConfigPath(): string {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi.json");
}

const cfgCache = new Map<string, { versions: string; cfg: InProcessAdvisoryConfig }>();
let injectedCfg: InProcessAdvisoryConfig | null = null;

/** 测试注入：绕过读盘固定配置（null 恢复读盘路径）。 */
export function _setInProcessAdvisoryConfigForTest(cfg: InProcessAdvisoryConfig | null): void {
	cfgCache.clear();
	injectedCfg = cfg;
}

/** 每文件独立版本元组（存在性 + mtime + size 复合判据——F11：两文件 max(mtime) 无法感知较旧
 *  文件的更新/删除（保时间戳部署/快照恢复/时钟偏移），逐文件元组任一变化即失效）。 */
function configVersionsOf(files: readonly string[]): string {
	const parts: string[] = [];
	for (const f of files) {
		try {
			const st = fs.statSync(f);
			parts.push(`${f}:${Math.floor(st.mtimeMs)}:${st.size}`);
		} catch {
			parts.push(`${f}:absent`); /* lint-exempt:配置缺省回退——无该文件记 absent，删除/新建均改变元组 */
		}
	}
	return parts.join("|");
}

function mergeAdvisorySection(base: InProcessAdvisoryConfig, raw: unknown): InProcessAdvisoryConfig {
	if (!raw || typeof raw !== "object") return base;
	const o = raw as Record<string, unknown>;
	const next: InProcessAdvisoryConfig = { ...base };
	if (typeof o.enabled === "boolean") next.enabled = o.enabled;
	if (typeof o.model === "string" && o.model.trim() !== "") next.model = o.model.trim();
	if (typeof o.timeoutMs === "number" && o.timeoutMs >= 500 && o.timeoutMs <= 120000) next.timeoutMs = Math.floor(o.timeoutMs);
	if (typeof o.maxOutputTokens === "number" && o.maxOutputTokens >= 16 && o.maxOutputTokens <= 8192) next.maxOutputTokens = Math.floor(o.maxOutputTokens);
	return next;
}

function readAdvisorySection(file: string): unknown | null {
	try {
		const json = JSON.parse(fs.readFileSync(file, "utf8"));
		return json && typeof json === "object" && "inProcessAdvisory" in json ? (json as Record<string, unknown>).inProcessAdvisory : null;
	} catch {
		/* lint-exempt:配置面回退——无该节/解析失败按未配置处理（默认关闭，fail-safe） */
		return null;
	}
}

function applyEnvFlip(cfg: InProcessAdvisoryConfig, raw: string | undefined): InProcessAdvisoryConfig {
	const v = (raw || "").trim().toLowerCase();
	if (v === "1" || v === "true" || v === "on") return { ...cfg, enabled: true };
	if (v === "0" || v === "false" || v === "off") return { ...cfg, enabled: false };
	return cfg;
}

/** 读取 advisory 配置（全局 ~/.pi/agent/amagi.json 打底、项目 cwd/amagi.json 覆盖）。 */
export function loadInProcessAdvisoryConfig(cwd?: string): InProcessAdvisoryConfig {
	if (injectedCfg) {
		const flip = process.env.AMAGI_INPROCESS_ADVISORY_ENABLED;
		return flip === undefined ? injectedCfg : applyEnvFlip(injectedCfg, flip);
	}
	const envFlip = process.env.AMAGI_INPROCESS_ADVISORY_ENABLED;
	const files = [globalAmagiConfigPath()];
	if (cwd) files.push(path.join(cwd, "amagi.json"));
	const cacheKey = files.join("|");
	const versions = configVersionsOf(files);
	const cached = cfgCache.get(cacheKey);
	if (cached && cached.versions === versions) return envFlip === undefined ? cached.cfg : applyEnvFlip(cached.cfg, envFlip);
	let cfg = ADVISORY_CFG_DEFAULTS;
	for (let i = 0; i < files.length; i++) {
		const section = readAdvisorySection(files[i]);
		if (section !== null) cfg = mergeAdvisorySection(cfg, section);
	}
	cfgCache.set(cacheKey, { versions, cfg });
	return envFlip === undefined ? cfg : applyEnvFlip(cfg, envFlip);
}

// ── 调用层：provider 中立窄接口 + Mock + HostStreamAdapter ─────────────────────

/**
 * 宿主 modelRegistry 窄投影（生产 = ctx.modelRegistry: ModelRegistry；测试注入结构兼容对象）。
 * 只暴露 advisory 需要的两个操作——绝不把整个 ctx 交模型（红线 1），扩展拿不到别的面。
 */
export interface AdvisoryModelRegistryLike {
	find(provider: string, modelId: string): unknown;
	streamSimple(model: unknown, context: AdvisoryStreamContext, options?: AdvisoryStreamOptions): AdvisoryMessageStreamLike;
}

/** advisory 通道构造的请求 Context：类型面禁 tools/MCP/fs 权能（tools?: never 即契约）。 */
export interface AdvisoryStreamContext {
	systemPrompt?: string;
	messages: { role: "user"; content: string; timestamp: number }[];
	tools?: never;
}

export interface AdvisoryStreamOptions {
	signal?: AbortSignal;
	maxTokens?: number;
}

export interface AdvisoryMessageStreamLike {
	result(): Promise<AdvisoryMessageLike>;
}

/** 宿主 AssistantMessage 的窄投影（content/stopReason/usage/errorMessage）。 */
export interface AdvisoryMessageLike {
	content: readonly { type: string; text?: string }[];
	stopReason: string;
	usage?: { input?: number; output?: number; cacheRead?: number; cacheWrite?: number };
	errorMessage?: string;
}

export interface AdvisoryCallInput {
	systemPrompt: string;
	userContent: string;
	modelRef: string;
	timeoutMs: number;
	maxOutputTokens: number;
	signal: AbortSignal;
}

export type AdvisoryCallResult =
	| { ok: true; text: string; stopReason: string; usage?: AdvisoryUsage }
	| { ok: false; errorKeyword: string; /** 失败仍可携带真实已上报 usage（F9：解释失败≠调用未记账）。 */ usage?: AdvisoryUsage };

export interface AdvisoryUsage {
	input: number;
	output: number;
	cacheRead: number;
	cacheWrite: number;
}

export interface AdvisoryModelCaller {
	/** 实现标识（mock-advisory/host-stream；进展示注记与审计）。 */
	id: string;
	call(input: AdvisoryCallInput): Promise<AdvisoryCallResult>;
}

/** 真实错误关键词提取：只取原文（截断有界），无错误返回 null——不编造（红线 3）。 */
function errorKeywordOf(err: unknown): string | null {
	const msg = err instanceof Error ? err.message : typeof err === "string" ? err : "";
	const t = msg.trim();
	if (!t) return null;
	return t.length > 200 ? `${t.slice(0, 200)}…` : t;
}

function usageOfNumbers(u: { input?: number; output?: number; cacheRead?: number; cacheWrite?: number } | undefined): AdvisoryUsage | undefined {
	if (!u) return undefined;
	const pick = (v: number | undefined): number => (typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : 0);
	return { input: pick(u.input), output: pick(u.output), cacheRead: pick(u.cacheRead), cacheWrite: pick(u.cacheWrite) };
}

/**
 * MockAdvisoryModel——确定性实现（供测试与无宿主环境演示）：同输入恒同输出（sha256 前 8 位
 * 锚定），不联网。可选 delayMs（模拟延迟/超时）、failWith（模拟真实异常传播）、signal 感知
 * （delay 中外部 abort → 以 AbortError 拒绝，模拟宿主流行为）。
 */
export function createMockAdvisoryModel(opts?: { delayMs?: number; failWith?: Error }): AdvisoryModelCaller {
	return {
		id: "mock-advisory",
		async call(input) {
			if (opts?.failWith) throw opts.failWith;
			if ((opts?.delayMs ?? 0) > 0) {
				await new Promise<void>((resolve, reject) => {
					const timer = setTimeout(resolve, opts!.delayMs);
					const onAbort = () => {
						clearTimeout(timer);
						reject(new Error(`AbortError: signal aborted (${String(input.signal.reason ?? "external")})`));
					};
					if (input.signal.aborted) onAbort();
					else input.signal.addEventListener("abort", onAbort, { once: true });
				});
			}
			const digest = createHash("sha256").update(input.userContent).digest("hex").slice(0, 8);
			return {
				ok: true,
				text: `advisory-mock:${digest} — 机器检查解释（确定性 mock）：输入 ${input.userContent.length} 字符已解释；结论仅供参考，非机器验证结论。`,
				stopReason: "stop",
				usage: { input: 128, output: 64, cacheRead: 0, cacheWrite: 0 },
			};
		},
	};
}

/**
 * HostStreamAdapter——ctx.modelRegistry.streamSimple 适配骨架（设计 §6.5 调用层）。
 * 未注入 modelRegistry / 模型目录未找到 → 恒 unavailable（不猜替代模型）；宿主 stopReason
 * 非 "stop"（length/error/…）→ 失败并携带真实 stopReason/errorMessage 关键词。
 * 流式消费结束后验证结构及 stopReason（红线 2 尾段）；取消后不消费迟到结果。
 */
export function createHostStreamAdapter(modelRegistry: AdvisoryModelRegistryLike | undefined): AdvisoryModelCaller {
	return {
		id: "host-stream",
		async call(input) {
			if (!modelRegistry || typeof modelRegistry.streamSimple !== "function" || typeof modelRegistry.find !== "function") {
				return { ok: false, errorKeyword: "host-model-registry-unavailable" };
			}
			const slash = input.modelRef.indexOf("/");
			if (slash <= 0 || slash >= input.modelRef.length - 1) {
				return { ok: false, errorKeyword: `model-ref-invalid:${input.modelRef}` };
			}
			const provider = input.modelRef.slice(0, slash);
			const modelId = input.modelRef.slice(slash + 1);
			let model: unknown;
			try {
				model = modelRegistry.find(provider, modelId);
			} catch (err) {
				return { ok: false, errorKeyword: `model-lookup-error:${errorKeywordOf(err) ?? "unknown"}` };
			}
			if (!model) return { ok: false, errorKeyword: `model-not-found:${input.modelRef}` };
			// 红线 1：恒不携带 tools 字段——构造面只有 systemPrompt + 单条 user 消息。
			const context: AdvisoryStreamContext = {
				systemPrompt: input.systemPrompt,
				messages: [{ role: "user", content: input.userContent, timestamp: Date.now() }],
			};
			let stream: AdvisoryMessageStreamLike;
			try {
				stream = modelRegistry.streamSimple(model, context, { signal: input.signal, maxTokens: input.maxOutputTokens });
			} catch (err) {
				return { ok: false, errorKeyword: errorKeywordOf(err) ?? "stream-simple-threw" };
			}
			let msg: AdvisoryMessageLike;
			try {
				msg = await stream.result();
			} catch (err) {
				return { ok: false, errorKeyword: errorKeywordOf(err) ?? "stream-result-rejected" };
			}
			if (input.signal.aborted) {
				// 取消后不消费迟到结果（与 C14「取消后不写迟到结果」同语义）；正文弃权但已上报的
				// usage 仍按事实携带（F9：调用是否记账独立于正文可消费性）。
				return { ok: false, errorKeyword: `aborted-before-consume:${String(input.signal.reason ?? "external")}`, ...(msg.usage ? { usage: usageOfNumbers(msg.usage) } : {}) };
			}
			if (msg.stopReason !== "stop") {
				const bits = [`host-stop-reason:${msg.stopReason}`];
				if (msg.errorMessage) bits.push(String(msg.errorMessage).slice(0, 160));
				// F9：length/error 等解释失败时宿主可能已真实消耗 token——usage 不丢弃。
				return { ok: false, errorKeyword: bits.join(" "), ...(msg.usage ? { usage: usageOfNumbers(msg.usage) } : {}) };
			}
			const text = msg.content.filter((c) => c.type === "text" && typeof c.text === "string").map((c) => c.text as string).join("\n").trim();
			if (!text) {
				// F9：空文本响应也可能携带真实 usage——同样不丢。
				return { ok: false, errorKeyword: "host-empty-text-response", ...(msg.usage ? { usage: usageOfNumbers(msg.usage) } : {}) };
			}
			return { ok: true, text, stopReason: msg.stopReason, usage: usageOfNumbers(msg.usage) };
		},
	};
}

// ── 脱敏机器事实摘要（finalizer 侧装配；纯函数）───────────────────────────────

/** 进摘要的机器检查事实行——不含 argv/cwd/文件内容（天然脱敏：id/status/required/exitCode）。 */
export interface AdvisoryCheckFactLine {
	id: string;
	status: string;
	required: boolean;
	exitCode?: number;
}

export interface AdvisoryFactsInput {
	parentTaskId: string;
	agent: string;
	/** 执行终态（done/error/truncated）。 */
	execution: string;
	/** 候选回执结算面（ready/failed/incomplete/pending…；无回执缺省）。 */
	settlement?: string;
	checks: readonly AdvisoryCheckFactLine[];
	missing?: readonly string[];
}

/**
 * 构造脱敏机器事实摘要：只有结构化检查 id/状态/退出码 + 结算面投影 + 缺口清单——无 cwd、无
 * 路径、无产物正文、无环境变量。超 ADVISORY_FACTS_MAX_CHARS 裁剪并标注。
 */
export function buildCheckFactsSummary(input: AdvisoryFactsInput): string {
	const lines: string[] = [
		`task ${input.parentTaskId} (agent ${input.agent}) execution=${input.execution} settlement=${input.settlement ?? "unpublished"}`,
		input.checks.length === 0 ? "checks: (none)" : "checks:",
	];
	for (const c of input.checks) {
		lines.push(`- ${c.id}: ${c.status}${c.required ? " required" : ""}${c.exitCode !== undefined ? ` exit=${c.exitCode}` : ""}`);
	}
	if (input.missing && input.missing.length > 0) lines.push(`missing: ${input.missing.join(", ")}`);
	const text = lines.join("\n");
	if (text.length <= ADVISORY_FACTS_MAX_CHARS) return text;
	return `${text.slice(0, ADVISORY_FACTS_MAX_CHARS)}\n…[facts-clipped at ${ADVISORY_FACTS_MAX_CHARS}]`;
}

// ── usage 单列费用（进程内有界累计；usage-store 只读不改——并入提案见报告）────

export interface AdvisoryUsageTotals {
	/** key = modelRef；值 = 累计 token（四项）+ 调用次数。 */
	models: Record<string, AdvisoryUsage & { calls: number }>;
}

const usageTotals = new Map<string, AdvisoryUsage & { calls: number }>();

function recordUsageTotals(modelRef: string, usage: AdvisoryUsage | undefined): void {
	if (!usage) return;
	const row = usageTotals.get(modelRef) ?? { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, calls: 0 };
	row.input += usage.input; row.output += usage.output; row.cacheRead += usage.cacheRead; row.cacheWrite += usage.cacheWrite;
	row.calls += 1;
	usageTotals.set(modelRef, row);
}

/** 读取 advisory 单列费用累计（冻结快照）。 */
export function readInProcessAdvisoryUsageTotals(): AdvisoryUsageTotals {
	const models: AdvisoryUsageTotals["models"] = {};
	for (const [k, v] of usageTotals) models[k] = Object.freeze({ ...v });
	return Object.freeze({ models: Object.freeze(models) });
}

// ── 执行入口：预算强制 + 事实记录（journal 增量通道）──────────────────────────

export interface InProcessAdvisoryFacts {
	parentTaskId: string;
	/** 脱敏机器事实摘要（buildCheckFactsSummary 产出或等价形态）。 */
	factsSummary: string;
}

export interface InProcessAdvisoryOutcome {
	/** "ok" = 解释成功；"unavailable" = 取消/超时/异常/违约（主验证照常结算，不受影响）。 */
	status: "ok" | "unavailable";
	/** 解释正文（仅 ok；unavailable 恒 null——不编造成功文本）。 */
	text: string | null;
	parentTaskId: string;
	invocationId: string;
	modelRef: string;
	inputDigest: string;
	promptVersion: string;
	startedAt: number;
	endedAt: number;
	/** ok | timeout | aborted | error | model-reject | host-unavailable | rejected-input。 */
	stopReason: string;
	usageStatus: "reported" | "unknown";
	usage?: AdvisoryUsage;
	/** 失败说明：只携带真实机器错误关键词；无错误不携带（不编造）。 */
	detail?: string;
	/** journal advisory 行是否真实落盘（journalAdvisory 返回值；测试守卫拒绝=如实 false）。 */
	journalRecorded: boolean;
}

/** journal 行写入注入（缺省 journalAdvisory；返回是否真实落盘）。 */
export type AdvisoryJournalSink = (entry: {
	parentTaskId: string; invocationId: string; modelRef: string; inputDigest: string; promptVersion: string;
	startedAt: number; endedAt: number; stopReason: string; usageStatus: "reported" | "unknown";
	usage?: AdvisoryUsage; detail?: string;
}) => boolean;

export interface RunInProcessAdvisoryOpts {
	caller: AdvisoryModelCaller;
	config: InProcessAdvisoryConfig;
	/** 外部取消信号（如任务取消级联）。 */
	signal?: AbortSignal;
	/** journal 写入注入（缺省 journalAdvisory）。 */
	journalSink?: AdvisoryJournalSink;
}

/** 落账：构造 outcome 并写 journal 事实行（同步；永不抛）。 */
function commitOutcome(args: {
	parentTaskId: string; invocationId: string; modelRef: string; inputDigest: string; promptVersion: string;
	startedAt: number; endedAt: number; status: "ok" | "unavailable"; stopReason: string; text: string | null;
	usageStatus: "reported" | "unknown"; usage?: AdvisoryUsage; detail?: string; journalSink?: AdvisoryJournalSink;
}): InProcessAdvisoryOutcome {
	const sink = args.journalSink ?? ((e) => journalAdvisory(e));
	let journalRecorded = false;
	try {
		journalRecorded = sink({
			parentTaskId: args.parentTaskId, invocationId: args.invocationId, modelRef: args.modelRef,
			inputDigest: args.inputDigest, promptVersion: args.promptVersion, startedAt: args.startedAt,
			endedAt: args.endedAt, stopReason: args.stopReason, usageStatus: args.usageStatus,
			...(args.usage ? { usage: args.usage } : {}), ...(args.detail ? { detail: args.detail } : {}),
		});
	} catch {
		/* lint-exempt:journal 写入失败如实归 false——advisory 事实行非正确性依赖，不阻断收尾链 */
		journalRecorded = false;
	}
	return {
		status: args.status, text: args.text, parentTaskId: args.parentTaskId, invocationId: args.invocationId,
		modelRef: args.modelRef, inputDigest: args.inputDigest, promptVersion: args.promptVersion,
		startedAt: args.startedAt, endedAt: args.endedAt, stopReason: args.stopReason, usageStatus: args.usageStatus,
		...(args.usage ? { usage: args.usage } : {}), ...(args.detail ? { detail: args.detail } : {}),
		journalRecorded,
	};
}

/** 失败关键词 → stopReason 分档（按真实关键词归类；缺省 error）。 */
function classifyKeyword(keyword: string, abortCause: "timeout" | "aborted" | null): string {
	if (abortCause === "timeout") return "timeout";
	if (abortCause === "aborted") return "aborted";
	if (/host-model-registry-unavailable|model-not-found|model-ref-invalid|model-lookup-error/.test(keyword)) return "host-unavailable";
	if (/host-stop-reason:/.test(keyword)) return "model-reject";
	return "error";
}

/**
 * 执行一次进程内 advisory 调用（唯一入口；finalizer 消费）。
 * 契约：输入违约/未配置模型 → rejected-input 不调用；signal+超时+token 预算强制；取消/异常
 * → unavailable；调用事实（含失败）恒按设计字段走 journal 增量通道——不伪造 dispatch 行。
 * 永不抛错（finalizer 收尾链不阻断）；无重试（一次失败不自动双跑，防重复计费）。
 */
export async function runInProcessAdvisory(
	facts: InProcessAdvisoryFacts,
	opts: RunInProcessAdvisoryOpts,
): Promise<InProcessAdvisoryOutcome> {
	const startedAt = Date.now();
	const invocationId = `adv-${randomUUID()}`;
	const summary = (facts.factsSummary ?? "").trim();
	const modelRef = opts.config.model.trim();
	const inputDigest = createHash("sha256").update(summary).digest("hex");
	const meta = { parentTaskId: facts.parentTaskId, invocationId, modelRef, inputDigest, promptVersion: IN_PROCESS_ADVISORY_PROMPT_VERSION, startedAt };
	// 输入契约校验（fail-closed：不调用、不构造提示）
	if (summary === "" || modelRef === "") {
		return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable", stopReason: "rejected-input", text: null,
			usageStatus: "unknown", detail: summary === "" ? "facts-summary-empty" : "model-ref-empty", journalSink: opts.journalSink });
	}
	// 预算强制：外部 signal + 超时合并为单一 AbortSignal 传宿主；独立超时墙兜底卡流。
	const ctrl = new AbortController();
	let abortCause: "timeout" | "aborted" | null = null;
	const onExternalAbort = () => { abortCause = "aborted"; ctrl.abort(`external:${String(opts.signal?.reason ?? "aborted")}`); };
	if (opts.signal) {
		if (opts.signal.aborted) onExternalAbort();
		else opts.signal.addEventListener("abort", onExternalAbort, { once: true });
	}
	const timeoutTimer = setTimeout(() => { abortCause = "timeout"; ctrl.abort("timeout"); }, opts.config.timeoutMs);
	// F10 时序门（预取消）：合并 signal 已取消（外部预取消/同步 abort）→ 不发起调用（零调用）。
	if (ctrl.signal.aborted) {
		clearTimeout(timeoutTimer);
		if (opts.signal) opts.signal.removeEventListener("abort", onExternalAbort);
		return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable",
			stopReason: abortCause === "timeout" ? "timeout" : "aborted", text: null, usageStatus: "unknown",
			detail: `pre-aborted:${abortCause === "timeout" ? "timeout" : "external"}:${String(opts.signal?.reason ?? "aborted")}`, journalSink: opts.journalSink });
	}
	const wallMs = opts.config.timeoutMs + ADVISORY_TIMEOUT_WALL_GRACE_MS;
	let wallTimer: ReturnType<typeof setTimeout> | undefined;
	const wall = new Promise<never>((_, reject) => {
		wallTimer = setTimeout(() => reject(new Error(`advisory-timeout-wall:${wallMs}ms`)), wallMs);
	});
	try {
		const callP = opts.caller.call({
			systemPrompt: ADVISORY_SYSTEM_PROMPT,
			userContent: `${summary}\n\n[advisory input ${IN_PROCESS_ADVISORY_PROMPT_VERSION} digest=${inputDigest.slice(0, 16)}]`,
			modelRef,
			timeoutMs: opts.config.timeoutMs,
			maxOutputTokens: opts.config.maxOutputTokens,
			signal: ctrl.signal,
		});
		let result: AdvisoryCallResult | null = null;
		let wallKeyword: string | null = null;
		try {
			result = await Promise.race([callP, wall]);
		} catch (err) {
			wallKeyword = errorKeywordOf(err);
		}
		if (result === null) {
			// 超时墙/调用异常：有界等待底层调用收尾（迟到结果丢弃，不消费、不计 usage）
			try { await Promise.race([callP.then(() => undefined, () => undefined), new Promise((r) => setTimeout(r, ADVISORY_SWALLOW_WAIT_MS))]); } catch { /* lint-exempt:迟到结果丢弃——异常仅观察，不再消费不计 usage */ }
			const kw = wallKeyword ?? (abortCause === "timeout" ? "timeout" : abortCause === "aborted" ? "aborted" : null);
			return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable",
				stopReason: abortCause === "timeout" ? "timeout" : abortCause === "aborted" ? "aborted" : "error",
				text: null, usageStatus: "unknown", ...(kw ? { detail: kw } : {}), journalSink: opts.journalSink });
		}
		if (!result.ok) {
			// F9：失败路径不丢弃已上报 usage——解释失败与调用记账独立；逐次只记一次（本次调用首次落账）。
			const failUsage = result.usage;
			recordUsageTotals(modelRef, failUsage);
			return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable",
				stopReason: classifyKeyword(result.errorKeyword, abortCause), text: null,
				usageStatus: failUsage ? "reported" : "unknown", ...(failUsage ? { usage: failUsage } : {}),
				detail: result.errorKeyword, journalSink: opts.journalSink });
		}
		if (ctrl.signal.aborted) {
			// F10 消费前时序门：超时/外部取消后到达的成功结果不消费（正文弃权、不记 ok）；迟到调用
			// 仍是真实调用——已上报 usage 按事实记账（F9 独立性）；时间墙只作回收兜底，不作成功预算延长。
			const lateStop = abortCause === "timeout" ? "timeout" : "aborted";
			const lateUsage = result.usage;
			recordUsageTotals(modelRef, lateUsage);
			return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable", stopReason: lateStop, text: null,
				usageStatus: lateUsage ? "reported" : "unknown", ...(lateUsage ? { usage: lateUsage } : {}),
				detail: `late-success-discarded:${lateStop}`, journalSink: opts.journalSink });
		}
		// F10 残留收口（增量复审）：消费门独立校验截止时间**事实**——timer 饥饿（同步占线使
		// timeout 回调未及执行）下 signal 仍可未 aborted；成功结果到达时 elapsed ≥ timeoutMs 即
		// unavailable 弃权，不依赖定时器回调是否发生；usage 仍按事实上报（F9 语义不回退）。
		const elapsedMs = Date.now() - startedAt;
		if (elapsedMs >= opts.config.timeoutMs) {
			const lateUsage = result.usage;
			recordUsageTotals(modelRef, lateUsage);
			return commitOutcome({ ...meta, endedAt: Date.now(), status: "unavailable", stopReason: "timeout", text: null,
				usageStatus: lateUsage ? "reported" : "unknown", ...(lateUsage ? { usage: lateUsage } : {}),
				detail: `late-success-discarded:timeout`, journalSink: opts.journalSink });
		}
		const usage = result.usage;
		recordUsageTotals(modelRef, usage);
		return commitOutcome({ ...meta, endedAt: Date.now(), status: "ok", stopReason: "ok", text: result.text,
			usageStatus: usage ? "reported" : "unknown", ...(usage ? { usage } : {}), journalSink: opts.journalSink });
	} finally {
		clearTimeout(timeoutTimer);
		if (wallTimer !== undefined) clearTimeout(wallTimer);
		if (opts.signal) opts.signal.removeEventListener("abort", onExternalAbort);
	}
}

/** 测试复位（usage 累计与配置缓存；journal 走自身 _setJournalPathForTest）。 */
export function _resetInProcessAdvisoryForTest(): void {
	usageTotals.clear();
	cfgCache.clear();
	injectedCfg = null;
}
