/**
 * panel-model.ts — 常驻面板数据派生（面板与交互优化 M2-01；交互设计 §7）。
 *
 * 纯函数层：TaskRecord[] + Leader 模型面 → PanelModel 四块（概要条/角色矩阵/任务流/结算）。
 * 单向数据流（P5 原则）：全部派生自 registry 快照 + 调用方注入的 now/leader 信息，无第二状态源。
 * 角色矩阵只显示有活动角色（视觉风格 §4 R-Grid：空闲角色折叠为计数，不占行）。
 * 最近结算沿用 settledTtlMs 语义（默认 15s，与 v1.5.182 status-ui 一致）。
 */

import type { TaskRecord } from "./task-registry.ts";
import { formatDurationOf } from "./ui-shared.ts";

export interface SummaryBar {
	/** `⬤ amagi 2▶ 1⏸` 或 `⬤ amagi 就绪`。 */
	text: string;
	/** leader 模型面 `glm-5.2:max`（R8）；无模型为 undefined。 */
	leaderSeg?: string;
	queued?: number;
}

export interface AgentCell {
	name: string;
	running: number;
	queued: number;
	blocked: number;
}

export interface TaskRow {
	taskId: string;
	agent: string;
	status: "running" | "queued" | "blocked";
	summary: string;
	/** 运行时长（running）或等待时长（blocked）。 */
	dur: string;
}

export interface SettledRow {
	taskId: string;
	agent: string;
	status: "done" | "error" | "cancelled" | "answered" | "resolved-external";
	summary: string;
	/** K8c 三轴标签（执行结束≠已验收）：axisOf 供给可用且任务已结束时携带（如「执行结束，待接受」）；
	 *  兼容字段 status 保留（执行轴），标签是验收轴的明确标注。
	 *  V3 兼容显示：终态但无标签（legacy 无回执）时携 compatNote 明确注记——不补 ready/accepted。 */
	axisLabel?: string;
	compatNote?: string;
}

export interface PanelModel {
	summary: SummaryBar;
	agents: AgentCell[];
	running: TaskRow[];
	blocked: TaskRow[];
	settled: SettledRow[];
	hiddenCounts: { agents: number; running: number; blocked: number; settled: number };
}

/** 任务摘要：goal > name > taskId 前 12 位（与 status-ui taskSummary 同序）。 */
function summaryOf(rec: Readonly<TaskRecord>): string {
	return rec.goal || rec.name || rec.taskId.slice(0, 12);
}

export interface LeaderInfo {
	provider?: string;
	model?: string;
	thinking?: string;
}

// ── K8c：三轴状态供给（可注入的只读 TaskView 面；默认接 registry 投影=无验收轴信息，组合根可换内核视图） ──

/** 任务三轴快照（执行/结算/验收；来自内核 TaskView 只读投影）。 */
export interface TaskAxes {
	execution: string;
	settlement: string;
	acceptance: string;
}
/** 只读三轴供给（DI 点）：默认接 registry 投影（无验收轴→ undefined）；组合根接内核视图。 */
export type TaskAxisOf = (taskId: string) => Readonly<TaskAxes> | undefined;

/** 三轴标签（K8c：老 UI 把「执行结束」显示为完成的隐患——展示层统一带验收轴标注）。
 *  未结束（queued/running/blocked 等）无歧义，返回 undefined；结束后按验收/结算轴标注。
 *  v2.3（ev-20260918-0784ed）：execution=error+accepted 给可区分呈现——接受的是「产物已被
 *  外部核采用」的事实（带 error-execution-coverage 豁免），不与常规「已接受」混淆。 */
export function axisLabelOf(axes: Readonly<TaskAxes> | undefined): string | undefined {
	if (!axes) return undefined;
	if (axes.execution !== "done" && axes.execution !== "truncated" && axes.execution !== "error") return undefined;
	if (axes.acceptance === "accepted") return axes.execution === "error" ? "执行失败，已显式采纳（带豁免）" : "已接受";
	if (axes.acceptance === "rejected") return "已拒绝";
	if (axes.settlement === "ready") return "执行结束，待接受";
	if (axes.settlement === "failed") return "检查失败，须拒绝重派（不可接受）";
	if (axes.settlement === "incomplete") return "回执不完整，须 waive 接受或拒绝重派";
	return "执行结束，待结算";
}

/** V3（§8.5）：终态但无验收轴供给（legacy 无回执/供给未接线）的明确注记——不补 ready/accepted。 */
export const NO_RECEIPT_NOTE = "无回执（未进入验证闭环——不补 ready/accepted）";

/** V3（§8.5 UI 关闭不影响结算/控制）：三轴供给断连容错——单任务供给抛错降级为无标签，
 *  不炸整张快照（供给是只读投影，失败不反噬 finalize/control）。 */
export function safeAxisOf(axisOf: TaskAxisOf | undefined, taskId: string): Readonly<TaskAxes> | undefined {
	if (!axisOf) return undefined;
	try { return axisOf(taskId); } catch { return undefined; }
}

/** R8：Leader 模型面段落 `provider/model:thinking`；无 model 返回 undefined。 */
export function leaderSegOf(info?: LeaderInfo): string | undefined {
	if (!info || !info.model) return undefined;
	const pm = info.provider ? `${info.provider}/${info.model}` : info.model;
	return info.thinking ? `${pm}:${info.thinking}` : pm;
}

/** 空态模型：无任务 + 无结算 → 概要条收敛为就绪行。 */
export function buildPanelModel(
	records: Readonly<TaskRecord>[],
	now: number,
	opts: { leader?: LeaderInfo; settledTtlMs?: number; axisOf?: TaskAxisOf } = {},
): PanelModel {
	const settledTtlMs = opts.settledTtlMs ?? 15_000;

	const running = records
		.filter((r) => r.status === "running" || r.status === "queued" || r.status === "answering")
		.sort((a, b) => a.startedAt - b.startedAt);
	const blocked = records
		.filter((r) => r.status === "blocked")
		.sort((a, b) => (b.blockedAt || b.startedAt) - (a.blockedAt || a.startedAt));
	const settled = records
		.filter((r) => ["done", "error", "cancelled", "answered", "truncated", "resolved-external"].includes(r.status) && r.endedAt && now - r.endedAt <= settledTtlMs)
		.sort((a, b) => (b.endedAt || 0) - (a.endedAt || 0));

	// 角色矩阵：有活动（running/queued/blocked）角色按活动数排序，其余折叠
	const agentMap = new Map<string, AgentCell>();
	for (const r of [...running, ...blocked]) {
		const cell = agentMap.get(r.agent) ?? { name: r.agent, running: 0, queued: 0, blocked: 0 };
		if (r.status === "blocked") cell.blocked += 1;
		else if (r.status === "queued") cell.queued += 1;
		else cell.running += 1;
		agentMap.set(r.agent, cell);
	}
	const agents = [...agentMap.values()].sort((a, b) => (b.running + b.blocked) - (a.running + a.blocked) || a.name.localeCompare(b.name));
	const idleAgents = new Set(records.filter((r) => !["running", "queued", "answering", "blocked"].includes(r.status)).map((r) => r.agent)).size;

	const queued = running.filter((r) => r.status === "queued").length;
	// v1.5.218-f4：空闲态概要条完全收敛（pi footer 已含模型/推理强度，重复无意义——主上验收裁定）。
	// leader 模型面仅在活动态与任务计数并列显示。
	const idle = running.length === 0 && blocked.length === 0 && settled.length === 0;
	const summary: SummaryBar = idle
		? { text: "" }
		: {
			text: `⬤ amagi ${running.length}▶${blocked.length > 0 ? ` ${blocked.length}⏸` : ""}`,
			leaderSeg: leaderSegOf(opts.leader),
			queued: queued > 0 ? queued : undefined,
		};

	return {
		summary,
		agents,
		running: running.map((r) => ({
			taskId: r.taskId,
			agent: r.agent,
			status: r.status === "queued" ? "queued" : r.status === "answering" ? "running" : "running",
			summary: summaryOf(r),
			dur: formatDurationOf(now - r.startedAt),
		})),
		blocked: blocked.map((r) => ({
			taskId: r.taskId,
			agent: r.agent,
			status: "blocked" as const,
			summary: summaryOf(r),
			dur: formatDurationOf(now - (r.blockedAt || r.startedAt)),
		})),
		settled: settled.map((r) => {
			const label = axisLabelOf(safeAxisOf(opts.axisOf, r.taskId));
			return {
				taskId: r.taskId,
				agent: r.agent,
				status: r.status as SettledRow["status"],
				summary: summaryOf(r),
				...(label !== undefined ? { axisLabel: label } : { compatNote: NO_RECEIPT_NOTE }),
			};
		}),
		hiddenCounts: { agents: idleAgents, running: 0, blocked: 0, settled: 0 },
	};
}
