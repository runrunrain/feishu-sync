/**
 * boot-identity.ts — ev-20261026-165da9：可靠系统启动（boot）身份探测。
 *
 * 事故（现场：子任务 10:46 启动，设备 11:46 重启）：恢复对账的疑似逃逸后代扫描以首 run 时刻为界，
 * 把重启后本次 boot 的 509 个系统进程全部判为「启动于任务运行之后」的疑似后代，要求人工
 * confirm-exited。缺失的关键证据是**系统启动身份**：若能证明锚定 run 全部发生在本次系统启动之前，
 * 则该 run 的根进程、进程组与全部后代（含逃逸后代）已随重启退出，且本次启动后的任何进程都不可能
 * 是其后代——PID/PGID 复用不再构成阻断。
 *
 * 证据分级（严→宽，全部 fail-closed）：
 *   1. boot id（Linux /proc/sys/kernel/random/boot_id；macOS sysctl kern.bootsessionuuid）：每次
 *      启动重新生成的 UUID，与时间无关。锚点记录的 boot id ≠ 当前 boot id ⇒ 精确跨 boot 证据。
 *   2. Linux 出生令牌内嵌 boot id（process-audit `linux:<boot_id>:<starttime>`）：legacy 锚点
 *      （无 boot 字段）在 Linux 上仍有精确 boot 身份可比对。
 *   系统权威 boot 时刻及当前时钟健康仅作诊断，不用于推断 legacy run 的 boot 身份：历史校时
 *   已恢复时，当前时钟健康也不能证明历史 run.at 可靠。缺 boot 身份保持既有 fail-closed 证明。
 *
 * 边界（如实）：
 *   - 平台不支持/探测失败/格式异常 ⇒ 返回 undefined（诚实 unknown，不猜）；
 *   - bootTime 晚于当前时刻、或 now-bootTime 与 os.uptime() 偏差超容忍窗（校时回拨/前拨痕迹）⇒
 *     timeTrusted=false——boot id 仍可用（与时间无关），时间判定不可用（fail-closed）；
 *   - 不用 Date.now()-os.uptime() *估算* boot 时刻替代权威来源；权威 btime/boottime 才是判定输入。
 */

import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";

/** 日历时钟自 boot 以来的跨度与单调运行时长（os.uptime）的交叉核验容忍窗（毫秒）。 */
const CLOCK_CROSS_TOLERANCE_MS = 600_000;

/** 当前时刻略超前的容忍（SMP 时钟读取竞态级别）。 */
const FUTURE_TOLERANCE_MS = 5_000;

/** Linux boot_id 与 macOS bootsessionuuid 同为 UUID 形态。 */
export const BOOT_ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export interface BootIdentity {
	/** 本次系统启动的稳定标识（跨重启必变；探测失败则整个探测失败）。 */
	bootId: string;
	/** 系统权威记录的本次启动时刻（epoch 毫秒；来源见 source）。 */
	bootTimeMs: number;
	/** 当前时钟是否经交叉核验一致（仅诊断，不授予历史退出证明）。 */
	timeTrusted: boolean;
	/** 证据来源（如 "linux:/proc/sys/kernel/random/boot_id + /proc/stat btime"）。 */
	source: string;
	probedAt: number;
}

export interface BootProbeDeps {
	platform?: NodeJS.Platform;
	now?: () => number;
	/** 单调运行时长毫秒（缺省 os.uptime()*1000）。 */
	uptimeMs?: () => number;
	/** 文件读取（Linux /proc 探测注入点）。 */
	readFile?: (p: string) => string;
	/** 命令执行（macOS sysctl 探测注入点）。 */
	execCmd?: (file: string, args: readonly string[]) => string;
}

/** 解析 /proc/stat 的 btime（秒）行；缺失/非法 → undefined。 */
export function parseLinuxBtime(statText: string): number | undefined {
	for (const line of String(statText ?? "").split("\n")) {
		const m = line.trim().match(/^btime\s+(\d+)$/);
		if (m) {
			const v = Number(m[1]);
			if (Number.isSafeInteger(v) && v > 0) return v;
		}
	}
	return undefined;
}

/** 解析 sysctl kern.boottime 输出（`{ sec = 1793040384, usec = 327850 } Mon Oct 26 …`）；
 *  非法（sec/usec 越界、usec ≥ 1e6、溢出）→ undefined（fail-closed，不容错为 0）。 */
export function parseDarwinBoottime(text: string): number | undefined {
	const m = String(text ?? "").match(/\{\s*sec\s*=\s*(\d+)\s*,\s*usec\s*=\s*(\d+)\s*\}/);
	if (!m) return undefined;
	const sec = Number(m[1]);
	if (!Number.isSafeInteger(sec) || sec <= 0) return undefined;
	const usec = Number(m[2]);
	if (!Number.isSafeInteger(usec) || usec < 0 || usec >= 1_000_000) return undefined;
	const ms = sec * 1000 + Math.floor(usec / 1000);
	return Number.isSafeInteger(ms) ? ms : undefined;
}

/** Linux 出生令牌（process-audit `linux:<boot_id>:<starttime>`）内嵌的 boot id；非该形态 → undefined。 */
export function bootIdFromIdentityToken(token: string | undefined): string | undefined {
	if (typeof token !== "string" || !token.startsWith("linux:")) return undefined;
	const rest = token.slice("linux:".length);
	const idx = rest.lastIndexOf(":");
	if (idx <= 0) return undefined;
	const id = rest.slice(0, idx);
	return BOOT_ID_RE.test(id) && /^\d+$/.test(rest.slice(idx + 1)) ? id.toLowerCase() : undefined;
}
/** 原始探测事实（boot 会话内不变——仅这些可缓存；时间健全性每次现评，见 evaluateTimeTrusted）。 */
interface RawBootFacts {
	bootId: string;
	bootTimeMs: number;
	source: string;
}

/** 时钟健全性（每次现评，不缓存）：boot 时刻不得晚于当前时刻（容忍毫秒级读取竞态）；
 *  日历跨度 vs 单调运行时长交叉核验（偏差超窗 = 校时回拨/前拨痕迹 → 时间判定不可信）。
 *  返回 undefined = 当前时刻/运行时长不可用（诚实无证据）；false = 异常；true = 可信。 */
function evaluateTimeTrusted(bootTimeMs: number, now: number, uptimeMs: () => number): boolean | undefined {
	if (bootTimeMs > now + FUTURE_TOLERANCE_MS) return false;
	let up: number;
	try { up = uptimeMs(); } catch { /* lint-exempt:时钟探测失败不作证据 */ return undefined; }
	if (!Number.isFinite(up) || up < 0) return undefined;
	return Math.abs((now - bootTimeMs) - up) <= CLOCK_CROSS_TOLERANCE_MS;
}

function probeFacts(deps: BootProbeDeps): RawBootFacts | undefined {
	const platform = deps.platform ?? process.platform;
	try {
		if (platform === "linux") {
			const read = deps.readFile ?? ((p: string) => fs.readFileSync(p, "utf8"));
			const id = read("/proc/sys/kernel/random/boot_id").trim().toLowerCase();
			const btimeSec = parseLinuxBtime(read("/proc/stat"));
			if (!BOOT_ID_RE.test(id) || btimeSec === undefined || !Number.isSafeInteger(btimeSec * 1000)) return undefined;
			return { bootId: id, bootTimeMs: btimeSec * 1000, source: "linux:/proc/sys/kernel/random/boot_id + /proc/stat btime" };
		}
		if (platform === "darwin") {
			const exec = deps.execCmd ?? ((file: string, args: readonly string[]) => execFileSync(file, [...args], { encoding: "utf8", timeout: 2000 }) as string);
			const id = exec("sysctl", ["-n", "kern.bootsessionuuid"]).trim().toLowerCase();
			const bt = parseDarwinBoottime(exec("sysctl", ["-n", "kern.boottime"]));
			if (!BOOT_ID_RE.test(id) || bt === undefined) return undefined;
			return { bootId: id, bootTimeMs: bt, source: "darwin:sysctl kern.bootsessionuuid + kern.boottime" };
		}
		return undefined; // 未知平台：诚实 unknown（不猜）
	} catch { /* lint-exempt:系统探测失败返回无证据，保持 fail-closed */
		return undefined; // 探测失败（权限/超时/输出异常）→ 无 boot 证据
	}
}

function probeUncached(deps: BootProbeDeps): BootIdentity | undefined {
	const facts = probeFacts(deps);
	if (facts === undefined) return undefined;
	const now = (deps.now ?? Date.now)();
	const timeTrusted = evaluateTimeTrusted(facts.bootTimeMs, now, deps.uptimeMs ?? (() => os.uptime() * 1000));
	if (timeTrusted === undefined) return undefined;
	return { bootId: facts.bootId, bootTimeMs: facts.bootTimeMs, timeTrusted, source: facts.source, probedAt: now };
}

/** 进程内缓存：仅成功的**原始事实**（bootId/bootTimeMs/source——boot 会话内不变）。
 *  timeTrusted/probedAt 每次现评（后续校时/探测时钟恢复不被首评永久定格）；探测失败不缓存
 *  （下次调用重试，不永久无能力）。 */
let cachedFacts: RawBootFacts | undefined;

/** 探测当前系统启动身份（默认依赖进程内记忆化原始事实 + 现评时间健全性；注入 deps 时绕过缓存）。 */
export function probeBootIdentity(deps: BootProbeDeps = {}): BootIdentity | undefined {
	const injected = deps.platform !== undefined || deps.now !== undefined || deps.uptimeMs !== undefined || deps.readFile !== undefined || deps.execCmd !== undefined;
	if (!injected && cachedFacts !== undefined) {
		const timeTrusted = evaluateTimeTrusted(cachedFacts.bootTimeMs, Date.now(), () => os.uptime() * 1000);
		return timeTrusted === undefined ? undefined : { bootId: cachedFacts.bootId, bootTimeMs: cachedFacts.bootTimeMs, timeTrusted, source: cachedFacts.source, probedAt: Date.now() };
	}
	const v = probeUncached(deps);
	if (!injected && v !== undefined) cachedFacts = { bootId: v.bootId, bootTimeMs: v.bootTimeMs, source: v.source };
	return v;
}

/** 测试复位：清空进程内默认探测缓存（生产不调用）。 */
export function resetBootIdentityCacheForTest(): void {
	cachedFacts = undefined;
}
