/**
 * task-query.ts — query_task 只读观察工具（P3-C：2026-08-19 插件进化，第二/三批拆分自 task-tool.ts L2738-2984）。
 * 含会话 JSONL 定位/摘要/终稿兜底（findSessionFile/summarizeSessionEntry/readSessionSummary/readSessionFinalText）
 * + createQueryTaskTool（board 快照 / stats 仪表盘 / 任务轨迹查询）。纯搬家：函数体零改动（ev-20260901-cd4173 B
 * 后例外：readSessionSummary 返回 { text, truncated }，截断时 full 查询追加完整落盘报告路径指引）。
 * P15-4 stats（writeStats/setStatsListener）按任务约束#2 的消费方分析驻 task-run.ts（引擎终态链唯一直接消费方；
 * 若驻本模块将成环 task-run→task-query→task-resume→task-run），task-tool.ts re-export 兜底公共面不变。
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { createHash } from "node:crypto";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
// B7（自建面处置设计 §B7）：session 记录 JSON 解析退役 node:readline 自建，换宿主公共
// parseSessionEntries（包根公开导出，非 deep import）；流式行帧走 B3 共享模块（jsonl-framing.ts）。
import { parseSessionEntries } from "@earendil-works/pi-coding-agent";
import { createLfFramer } from "./jsonl-framing.ts";
import type { AgentConfig } from "./agents-loader.ts";
import { registry } from "./task-registry.ts";
import { buildBoardModel, renderBoardLines } from "./workflow-board.ts";
import { journalInflight } from "./journal.ts";
import { aggregateStats, renderStatsText } from "./stats-aggregate.ts";
import { capUtf8 } from "./task-jsonl.ts";
import { artifactEnabled, artifactRoot, archivedTaskContextRefs, contractRefBaseHint, contractRefInlineNote, contractStoreRoot, sanitizeId, findArtifact, readEvidenceClassification } from "./artifact.ts";
import { resolveSessionWithBackfill, recoveryActionOfRecord } from "./task-resume.ts";
// D2（ev-20260922-727096）：error 终态恢复指引单源（与 task-facets 同源；query_task 为 legacy 面 → legacy 调用形态）。
import { renderRecoveryAdvice } from "./reliability.ts";
// D1（ev-20260922-c896f8）：旧回执 id:status 拼接形态的展示适配（拆出的 id 须精确匹配本回执 checks id）。
import { splitLegacyCheckGapId, type CheckStatus } from "./contracts/evidence.ts";
import { collectResidue, residueNote } from "./residue.ts";
import { formatAmagiClock } from "./task-run.ts";
import { parseEvidenceClassificationSnapshot, renderClassificationFull } from "./evidence.ts";
import { peekTaskKernel, queryTaskViews } from "./task-service.ts";
import { axisLabelOf } from "./panel-model.ts";

// ── P15-3: query_task 工具 ───────────────────────────────────────────────────
// v2 批次B：persistArtifact 已唯一化进 finalizer.ts（finalizeTerminal：幂等 + stale 防护 + 固定链序），
// execute/orchestrate/input-router 全部走统一收尾链，本文件不再保留手工装配副本。
function findSessionFile(sessionId: string): string | null {
	const sessionsDir = path.join(os.homedir(), ".pi", "agent", "sessions");
	if (!fs.existsSync(sessionsDir)) return null;
	const matches: string[] = [];
	for (const dir of fs.readdirSync(sessionsDir)) {
		const full = path.join(sessionsDir, dir);
		try { if (!fs.statSync(full).isDirectory()) continue; } catch { continue; }
		for (const f of fs.readdirSync(full)) {
			if (!f.endsWith(".jsonl")) continue;
			// P1-3: UUID 精确/唯一前缀匹配（不模糊 includes）
			const uuid = f.replace(/^[^_]+_/, "").replace(/\.jsonl$/, "");
			if (uuid === sessionId || uuid.startsWith(sessionId)) matches.push(path.join(full, f));
		}
	}
	return matches.length === 1 ? matches[0] : null; // 0 或歧义返回 null
}

/** P2-2: 安全时间格式化（坏时间戳不抛异常；ev-20260916-804ea3：统一带日期与时区标注的
 *  `YYYY-MM-DD HH:mm:ss UTC`——旧态与停滞告警/进程实况的本地时基混用不可辨；
 *  AMAGI_QUERY_TIME_FORMAT=legacy 回旧 ISO 时分秒文本，机器时间数据不受影响）。 */
function safeTime(ts: any): string {
	try {
		if (typeof ts === "string") { const d = new Date(ts); return isNaN(d.getTime()) ? "??:??:??" : formatAmagiClock(d.getTime(), "query"); }
		if (typeof ts === "number" && Number.isFinite(ts) && ts > 0) return formatAmagiClock(ts, "query");
	} catch {}
	return "??:??:??";
}

/**
 * 单条已解析 entry → 一行摘要（角色/工具/首 80 UTF-16 单位/时间）；P2-2: 时间防御。
 * B7（设计 §B7）：JSON 解析委托宿主公共 parseSessionEntries，本函数不再 JSON.parse；
 * 窄守卫只作用于摘要实际访问的字段——非对象 entry（null/标量）与无法投影的 content 元素跳过、
 * 不可用字段不再触发类型异常（设计 §B7 允许改变项：旧实现对 null 行 / content null 元素 /
 * message_end 标量 content 抛 TypeError，使整次查询失败）。
 */
function summarizeSessionEntry(e: unknown): string | null {
	if (!e || typeof e !== "object") return null;
	const o = e as any;
	const ts = safeTime(o.timestamp);
	if (o.type === "message" && o.message) {
		const role = o.message.role;
		const content = o.message.content;
		if (typeof content === "string") return `[${role}] ${ts} ${content.slice(0, 80)}`;
		if (Array.isArray(content)) {
			const texts = content.filter((p: any) => p && p.type === "text").map((p: any) => p.text).join("");
			if (texts) return `[${role}] ${ts} ${texts.slice(0, 80)}`;
			const toolCalls = content.filter((p: any) => p && p.type === "toolCall");
			if (toolCalls.length) return `[${role}:tool] ${ts} ${toolCalls.map((tc: any) => tc.name).join(",")}`;
			// 2026-08-19 修正：无 text 且无 toolCall ≠ 多模态——推理吃光输出上限时 GLM 只回
			// thinking 块（stopReason=length），此前误标「多模态」把排障引向模型损坏/降级。
			if (content.some((p: any) => p && p.type === "thinking")) return `[${role}] ${ts} (仅思考块·无正文)`;
			if (content.some((p: any) => p && (p.type === "image" || p.type === "audio"))) return `[${role}] ${ts} (多模态)`;
			return `[${role}] ${ts} (无文本内容)`;
		}
		return `[${role}] ${ts}`;
	}
	if (o.type === "message_end" && o.message) {
		const role = o.message.role || "?";
		const stop = o.message.stopReason ? `(${o.message.stopReason})` : "";
		const txt = (Array.isArray(o.message.content) ? o.message.content : []).filter((p: any) => p && p.type === "text").map((p: any) => p.text).join("");
		return `[${role}] ${ts} ${stop} ${txt.slice(0, 80)}`.trim();
	}
	if (o.type === "session") return `[session] ${ts} ${String(o.id || "").slice(0, 12)}`;
	if (o.type === "tool_execution_start" || o.type === "tool_execution_end") {
		const name = o.toolName || o.name || "?";
		return `[tool:${name}] ${ts}`;
	}
	if (o.customType) return `[${o.customType}] ${ts}`;
	if (o.type) return `[${o.type}] ${ts}`;
	return null;
}

/**
 * 流式逐行读 JSONL，逐 entry 产出一行摘要。
 * 全轨迹覆盖（不限尾部 N 行）；总输出 50KB cap，超出从旧端截断并标注。
 * ev-20260901-cd4173 B：返回 { text, truncated }，截断时调用方追加完整落盘报告路径指引。
 * ev-20260904 复盘（截断不可达）：返回体新增 sessionFile/totalEntries/keptEntries——截断时
 * 调用方附原始会话文件路径（read/grep 直达中间细节）与全量摘要落盘路径；dumpPath 给定
 * 且实际截断时，把无 cap 的全量摘要（每条 80 字口径不变，条数不限）写盘供 read offset/limit
 * 续读（写盘失败静默，如实不返回 dump 路径）。摘要数组全量驻内存：每条 ≤~120B，万条级
 * 会话也仅 MB 级，可接受。
 */
export async function readSessionSummary(
	sessionId: string,
	maxBytes = 50 * 1024,
	dumpPath?: string,
): Promise<{ text: string; truncated: boolean; sessionFile?: string; totalEntries?: number; keptEntries?: number; dumpedPath?: string }> {
	const file = findSessionFile(sessionId);
	if (!file) return { text: "(会话文件未找到；可能仍在运行且未 flush)", truncated: false };
	const all: string[] = [];
	// B7（设计 §B7）：读取形态保持流式（不整文件读入、不建全量原始 entries 数组）——原始 Buffer
	// 交 B3 行帧器增量解码，逐帧委托宿主公共 parseSessionEntries（空行/语法坏行由宿主跳过）。
	// 记录边界＝LF（CRLF 兼容，每帧剥一个尾 CR）；裸 CR/U+2028/U+2029 不是记录分隔符（显式接受集，
	// 旧 readline 会把裸 CR 与 U+2028/U+2029 当行终止符——对照见 P0-B3-B7 实施报告）。
	const stream = fs.createReadStream(file);
	const framer = createLfFramer((line) => {
		for (const entry of parseSessionEntries(line)) {
			const s = summarizeSessionEntry(entry);
			if (s) all.push(s);
		}
	});
	try {
		for await (const chunk of stream) framer.push(chunk as Buffer);
		// 正常 EOF：发一次未换行尾帧（合法 JSON 可解析；截断坏尾由宿主跳过，不编造未完成记录）。
		// IO／投影异常随 async 函数 reject（不抛进无人处理的流回调）；finally 释放 framer 与 stream。
		framer.finish("emit");
	} finally {
		framer.dispose();
		stream.destroy();
	}
	let totalBytes = 0;
	for (const s of all) totalBytes += Buffer.byteLength(s, "utf8") + 1;
	const summaries = [...all]; // 拷贝：窗口裁剪不得动 all（全量落盘与总条数都依赖它）
	let truncated = false;
	while (totalBytes > maxBytes && summaries.length > 1) {
		const dropped = summaries.shift()!;
		totalBytes -= Buffer.byteLength(dropped, "utf8") + 1;
		truncated = true;
	}
	let result = summaries.join("\n");
	if (truncated) {
		// ev-20260904：截断标注带总量（「共 N 条」）——被丢掉的规模可感知
		const note = `[...早期轨迹已截断，共 ${all.length} 条，仅保留最近 ${summaries.length} 条...]`;
		// P2-1: 截断标注计入预算；超限时进一步裁剪 summaries
		const noteBytes = Buffer.byteLength(note + "\n", "utf8");
		while (totalBytes + noteBytes > maxBytes && summaries.length > 1) {
			const dropped = summaries.shift()!;
			totalBytes -= Buffer.byteLength(dropped, "utf8") + 1;
		}
		result = `${note}\n${summaries.join("\n")}`;
	}
	// ev-20260904：截断时全量摘要落盘（无 50KB cap），供 read offset/limit 续读
	let dumpedPath: string | undefined;
	if (truncated && dumpPath) {
		try {
			fs.mkdirSync(path.dirname(dumpPath), { recursive: true });
			fs.writeFileSync(dumpPath, `# 会话轨迹全量摘要（${all.length} 条，无截断）\n# 源会话：${file}\n\n${all.join("\n")}\n`, "utf8");
			dumpedPath = dumpPath;
		} catch { /* 写盘失败如实不返回 dump 路径 */ }
	}
	return { text: result, truncated, sessionFile: file, totalEntries: all.length, keptEntries: summaries.length, dumpedPath };
}

/** ev-20260901-cd4173 B：完整落盘报告路径（<artifactRoot>/<taskId>/result.md）；
 *  artifact 关闭/解析失败 → null（拿不到真实路径时不给路径，不追加指引行）。 */
function fullReportArtifactPath(taskId: string): string | null {
	try {
		if (!artifactEnabled()) return null;
		return path.join(artifactRoot(), sanitizeId(taskId), "result.md");
	} catch {
		return null;
	}
}

/**
 * 复盘 2026-09-03 §5#5：artifact 目录级指引行。<artifactRoot>/<sanitizeId(taskId)> 目录真实
 * 存在时才输出（目录不存在 → null 不追加，失败静默）：result.md 绝对路径只点名终稿，
 * 目录级指引同时点名 metadata.json（会话/耗时等元数据）并确认目录存在——截断的 full
 * 查询不用再花 1 轮翻 artifacts 目录。使用真实完整绝对路径，免得八位缩略目录被当成 read 目标。 */
function artifactDirHint(taskId: string): string | null {
	try {
		if (!artifactEnabled()) return null;
		const root = artifactRoot();
		if (!fs.existsSync(path.join(root, sanitizeId(taskId)))) return null;
		const display = path.join(root, sanitizeId(taskId));
		const evidenceNote = fs.existsSync(path.join(root, sanitizeId(taskId), "evidence.md")) ? " + evidence.md 自动采集详情" : "";
		return `artifact 目录：${display}/（result.md 完整终稿 + metadata.json${evidenceNote}），可直接 read`;
	} catch {
		return null;
	}
}

/**
 * 会话终稿兜底（导出供测试）：从会话 JSONL 尾部反向扫描最后一个含文本的 assistant 消息。
 * 用于 error/截断任务的 query_task——registry.result 只有残片时，会话文件里终稿常在
 * （实战：缓冲超限误判 error 的任务，resume 前只能靠它看到终稿）。
 * 只读尾部 tailBytes（默认 1MB），不整文件读入；解析失败/无文本 → null。
 */
export async function readSessionFinalText(sessionId: string, tailBytes = 1024 * 1024, capChars = 2000): Promise<string | null> {
	const file = findSessionFile(sessionId);
	if (!file) return null;
	try {
		const st = fs.statSync(file);
		const start = Math.max(0, st.size - tailBytes);
		const fh = await fs.promises.open(file, "r");
		let buf: Buffer;
		try {
			buf = Buffer.alloc(Math.max(0, st.size - start));
			if (buf.length > 0) await fh.read(buf, 0, buf.length, start);
		} finally {
			await fh.close();
		}
		const lines = buf.toString("utf8").split("\n");
		for (let i = lines.length - 1; i >= 0; i--) {
			const line = lines[i];
			if (!line.trim() || !line.includes('"assistant"')) continue;
			let e: any;
			try { e = JSON.parse(line); } catch { continue; } // 首行可能是截断残行，跳过
			const msg = (e.type === "message_end" || e.type === "message") ? e.message : null;
			if (!msg || msg.role !== "assistant") continue;
			const text = (Array.isArray(msg.content) ? msg.content : [])
				.filter((p: any) => p?.type === "text")
				.map((p: any) => String(p.text ?? ""))
				.join("")
				.trim();
			if (text) return text.length > capChars ? `…${text.slice(-capChars)}` : text;
		}
	} catch {}
	return null;
}

// ── K8c：三轴只读查询（§3.3 TaskQuery/TaskPage：handle/view/cursor/limit；查询不 spawn、不续接、不修复磁盘） ──

/** 启动对账报告供给（组合根注入）：缓存文本 + 扫描时刻；未接线/未完成 → undefined。 */
export interface StartupRecoverySupply {
	scannedAt: number;
	text: string;
}

/** 回执文件只读展开（receipt 档：checks/outputs 来自归档回执 JSON，读失败如实标注）；
 *  ref.path 为契约存储相对路径（K2 store 语义），解析到 contractStoreRoot。 */
function readReceiptFile(refPath: string): { checks?: unknown[]; outputs?: unknown[] } | null {
	try {
		const abs = path.isAbsolute(refPath) ? refPath : path.join(contractStoreRoot(), refPath);
		const raw = JSON.parse(fs.readFileSync(abs, "utf8"));
		return raw && typeof raw === "object" ? raw as { checks?: unknown[]; outputs?: unknown[] } : null;
	} catch {
		return null;
	}
}

/** V3（§3.2 尾段）：归档产物当前内容与回执记录 digest 比对（展示级，不重写事实——接受指向归档版本；
 *  当前文件已变时提示消费方不能把旧 accepted 贴到新文件内容）。digest/path 缺失 → null 不臆造。 */
function archiveHashNote(o: { path?: unknown; digest?: unknown }, accepted: boolean): string | null {
	if (typeof o.path !== "string" || typeof o.digest !== "string") return null;
	try {
		const cur = createHash("sha256").update(fs.readFileSync(o.path)).digest("hex");
		if (cur === o.digest) return `    归档比对: 一致（sha256:${cur.slice(0, 16)}）——归档版本未漂移${accepted ? "，已接受指向此版本" : ""}`;
		return `    归档比对: ⚠ 不一致——当前文件 sha256:${cur.slice(0, 16)} ≠ 回执归档 sha256:${o.digest.slice(0, 16)}；回执仍证归档版本，不能把旧 accepted 贴到新文件内容（§3.2）`;
	} catch {
		return `    归档比对: 归档文件不可读（${o.path}）——回执仍证归档版本${accepted ? "（已接受指向归档版本）" : ""}`;
	}
}

/** 输出引用渲染（output 档：归档产物引用不全文；V3 附当前文件 hash 与归档 digest 比对提示面）。 */
function renderOutputRefs(outputs: readonly unknown[] | undefined, opts?: { accepted?: boolean }): string[] {
	const lines: string[] = [];
	if (!outputs || outputs.length === 0) { lines.push("    回执产物: （无 OutputRef——非编码/无产物任务）"); return lines; }
	for (const o of outputs.slice(0, 8)) {
		const r = o as { path?: unknown; digest?: unknown; bytes?: unknown; sourcePath?: unknown };
		lines.push(`    回执产物: ${typeof r.path === "string" ? r.path : "?"}（${typeof r.bytes === "number" ? `${r.bytes}B` : "?"}，sha256:${typeof r.digest === "string" ? r.digest.slice(0, 16) : "?"}${typeof r.sourcePath === "string" ? `，源=${r.sourcePath}` : ""}）`);
		const note = archiveHashNote(r, opts?.accepted === true);
		if (note) lines.push(note);
	}
	return lines;
}

/** K8c 三轴视图行的最小只读形状（与 contracts/task.ts TaskView 同构；行内渲染只读字段）。 */
interface ViewLineShape {
	taskId: string; ownerId: string; revision: number; stateSeq: number;
	execution: string; settlement: string; acceptance: string;
	/** diting-M3-A4：承诺等级（TaskView 携带；旧视图/未携带时缺省不展示）。 */
	assurance?: string;
	spec: { agent: string };
	receipt?: { receiptId: string; receiptSeq: number; settlement: string; acceptance: string; missing: readonly string[]; ref?: { path: string; digest: string; bytes: number } };
}

/** 三轴视图行（K8c：执行结束≠已验收——summary 档必带验收轴标签）。pageState 供分页调用方
 *  控制基准提示每页至多一次（ev-20261012-4afdc8：相对归档引用标存储基准，多任务页不刷屏）。 */
function renderViewLine(v: ViewLineShape, view: "summary" | "receipt" | "output", pageState?: { contractBaseShown: boolean }): string[] {
	const label = axisLabelOf({ execution: v.execution, settlement: v.settlement, acceptance: v.acceptance })
		?? (v.execution === "queued" || v.execution === "running" || v.execution === "blocked" || v.execution === "answering" ? "执行中/待处理（未结束，无验收轴歧义）" : "-");
	const lines = [
		`  ${v.taskId.slice(0, 8)} ${v.spec.agent} · ${label} · execution=${v.execution} settlement=${v.settlement} acceptance=${v.acceptance} · stateSeq=${v.stateSeq} revision=${v.revision} owner=${v.ownerId}${v.assurance ? ` 承诺=${v.assurance}` : ""}`,
	];
	// D2（ev-20260922-727096）：查询面同源展示恢复指引（renderViewLine 仅由 legacy query_task 消费 →
	// legacy 调用形态；事实取 registry 当前记录，无记录不臆造）。
	if (v.execution === "error") {
		const rec = registry.get(v.taskId);
		const note = rec ? renderRecoveryAdvice(recoveryActionOfRecord(rec), { surfaceVersion: 1 }) : undefined;
		if (note) for (const l of note.split("\n")) lines.push(`    ${l}`);
	}
	if (view === "summary") return lines;
	// diting-M3-A4：guarded 回执局限声明（§5.1：壳承诺非对抗隔离，hash 仅证一致性不证可信来源）
	if (v.assurance === "guarded" && view === "receipt") lines.push("    承诺说明: guarded 壳承诺（非对抗隔离）——回执 hash 证明产物一致性，不证明可信来源；对抗隔离需 tool-enforced 任务");
	if (!v.receipt) {
		lines.push("    回执: 未发布（settlement=pending——执行结束但结算未落，需对账或 finalizer 收尾）");
	} else {
		// D1：归档可读时先取 checks id 集（旧 id:status 形态按当前 check 精确 id 识别——不猜 hash/截字符串）。
		const ref = v.receipt.ref;
		const full = ref ? readReceiptFile(ref.path) : null;
		const checkIds = full && Array.isArray(full.checks)
			? full.checks.map((c) => ((c as { id?: unknown }).id ?? "")).filter((id): id is string => typeof id === "string")
			: [];
		const missingRendered = v.receipt.missing.map((g) => {
			const legacy = checkIds.length > 0 ? splitLegacyCheckGapId(g, checkIds) : null;
			return legacy
				? `${g}（旧版 id:status 形态——id=${legacy.checkId} status=${legacy.status}；decide 引用原字面 ${JSON.stringify(g)}，不剥离后缀）`
				: g;
		});
		lines.push(`    回执: receiptId=${v.receipt.receiptId} seq=${v.receipt.receiptSeq} settlement=${v.receipt.settlement} acceptance=${v.receipt.acceptance}${missingRendered.length > 0 ? ` missing=[${missingRendered.join(",")}]` : ""}`);
		if (ref) {
			// ev-20261012-4afdc8：相对归档引用标注存储基准（解析面同源 contractStoreRoot）；
			// 分页多任务时基准行每页至多一次，绝对路径引用不标注、不二次拼接。
			if (!path.isAbsolute(ref.path) && !pageState?.contractBaseShown) {
				lines.push(contractRefBaseHint());
				if (pageState) pageState.contractBaseShown = true;
			}
			lines.push(`    回执归档: ${ref.path}（${ref.bytes}B，sha256:${ref.digest.slice(0, 16)}）${contractRefInlineNote(ref.path)}`);
			if (view === "receipt") {
				if (!full) lines.push(`    检查: 回执文件不可读（${ref.path}）——归档引用如实展示，不臆造内容`);
				else {
					const checks = Array.isArray(full.checks) ? full.checks : [];
					if (checks.length === 0) lines.push("    检查: （无机器检查——非编码/手动验收任务）");
					for (const c of checks.slice(0, 8)) {
						const cc = c as { id?: unknown; status?: unknown; required?: unknown; exitCode?: unknown; exemption?: { kind?: unknown; detail?: unknown } };
						// D1：id/status 分列展示（可照抄引用的纯 id 与状态分开，不拼接成 id:status）。
						// B10（ev-20261008-eb1e27）：豁免检查状态保持真实，exemption 标注显式披露（依据全文在
						// 检查日志 notes 与证据正文；此处单行不展开——防 receipt 视图噪音）。
						const exempt = cc.exemption?.kind === "sibling-interference" && typeof cc.exemption.detail === "string" && cc.exemption.detail !== "";
						lines.push(`    检查: id=${typeof cc.id === "string" ? cc.id : "?"} status=${typeof cc.status === "string" ? (cc.status as CheckStatus) : "?"}${cc.required === true ? "（required）" : ""}${typeof cc.exitCode === "number" ? ` exit=${cc.exitCode}` : ""}${exempt ? " exemption=sibling-interference（漂移/失败文件均不在本任务写面；依据见检查日志）" : ""}`);
					}
				lines.push(...renderOutputRefs(full.outputs, { accepted: v.acceptance === "accepted" }));
			}
			}
			if (view === "output") {
				lines.push(...renderOutputRefs(full?.outputs, { accepted: v.acceptance === "accepted" }));
			}
		}
	}
	if (view === "output") {
		const resultPath = fullReportArtifactPath(v.taskId);
		if (resultPath && fs.existsSync(resultPath)) lines.push(`    归档终稿: ${resultPath}（可直接 read；此处不展开全文）`);
		else lines.push("    归档终稿: （无 result.md 归档——artifact 关闭或未归档，如实不臆造路径）");
		for (const file of archivedTaskContextRefs(v.taskId).filter((p) => path.basename(p) === "evidence.md")) lines.push(`    采集归档: ${file}（按需 read；此处不展开全文）`);
		lines.push("    （output 档只给归档引用不全文；完整轨迹 query_task({ session: \"<taskId 前 8 位>\", full: true })）");
	}
	return lines;
}

export function createQueryTaskTool(deps?: { agents?: AgentConfig[]; startupRecovery?: () => StartupRecoverySupply | undefined | Promise<StartupRecoverySupply | undefined> }) {
	return {
		name: "query_task",
		label: "Amagi Query Task",
		description: "查询 SubAgent 任务状态与活动轨迹（session 支持 taskId/sessionId 前缀、稳定 name、精确 runId/name；tail=滚动窗口；full=完整会话轨迹摘要，每 entry 一行，50KB cap，截断时附原始会话文件与全量摘要落盘路径）；view=summary/receipt/output 三轴只读查询（K8c：执行/结算/验收三轴，summary 含「执行结束，待接受」验收轴标注，receipt 展开回执/检查/产物引用，output 只给归档引用不全文；handle+cursor/limit 分页，零副作用不回填磁盘）；recovery=true 查启动对账报告；board=true 返回看板 headless 快照；零参缺省返回看板快照（含 journal 中断残留分区）。",
		promptSnippet: `query_task({ session }) — 按 taskId/name/runId/name 查询状态/活动/完整轨迹；query_task({ handle, view: "summary"|"receipt"|"output" }) — 三轴只读查询（待接受≠已完成）；query_task({ recovery: true }) — 启动对账报告；query_task({ board:true }) 或零参 — 看板快照；query_task({ stats:true, days:7 }) — 成本仪表盘`,
		parameters: Type.Object({
			session: Type.Optional(Type.String({ description: "taskId/sessionId 前缀、稳定 name，或精确 runId/name" })),
			view: Type.Optional(StringEnum(["summary", "receipt", "output"], { description: "K8c 三轴查询档位（与 session/handle 搭配单任务，缺省 handle 时全量分页）：summary=三轴标签+视图序号；receipt=展开回执/检查/产物引用；output=只给归档产物引用不全文" })),
			handle: Type.Optional(Type.String({ description: "三轴查询的会话内任务句柄；历史契约可用完整 taskId 或至少 8 位唯一前缀（只读，不收编旧会话）" })),
			cursor: Type.Optional(Type.String({ description: "三轴查询分页游标（不透明；首页缺省，翻页传上页 nextCursor）" })),
			limit: Type.Optional(Type.Number({ description: "三轴查询每页条数（1..500，缺省 20）" })),
			recovery: Type.Optional(Type.Boolean({ description: "true=启动恢复对账报告（K8a 组合根接线：崩溃现场/待对账清单/建议动作；只读）" })),
			tail: Type.Optional(Type.Number({ description: "返回最近 N 条活动（默认 10）" })),
			full: Type.Optional(Type.Boolean({ description: "true=读完整会话 JSONL 轨迹摘要" })),
			evidenceDetail: Type.Optional(StringEnum(["compact", "full"], { description: "证据归因呈现：compact=终态正文已是低噪音聚焦呈现（缺省）；full=展开结束时保存的结构化分类快照（classification.json）——结束后工作树改动不改变旧详情；旧任务/未保存快照（无基线、非 git、artifact 关闭或 blocked）则明确不可用，不臆造" })),
			board: Type.Optional(Type.Boolean({ description: "true=看板 headless 快照（角色×任务矩阵+blocked 队列），无需 session" })),
			json: Type.Optional(Type.Boolean({ description: "board=true 时输出结构化 JSON 而非文本渲染" })),
			stats: Type.Optional(Type.Boolean({ description: "true=成本/质量仪表盘（按日/角色/模型聚合任务数、成功率、blocked 率、成本，E9），无需 session" })),
			days: Type.Optional(Type.Number({ description: "stats=true 时的时间窗天数（缺省全量）" })),
		}),
		async execute(
			_id: string,
			params: { session?: string; view?: "summary" | "receipt" | "output"; handle?: string; cursor?: string; limit?: number; recovery?: boolean; tail?: number; full?: boolean; evidenceDetail?: "compact" | "full"; board?: boolean; json?: boolean; stats?: boolean; days?: number },
			_signal: AbortSignal | undefined,
			_onUpdate: ((partial: any) => void) | undefined,
			_ctx: { cwd: string },
		) {
			// K8c：启动对账报告（只读；组合根注入的供给——resume 会话预热缓存，其余会话懒扫描只读零应用）
			if (params.recovery) {
				const cached = await (deps?.startupRecovery?.() ?? undefined);
				const text = cached
					? `${cached.text}\n（扫描时刻 ${safeTime(cached.scannedAt)}；对账动作仅在唤起原会话（resume）时执行，本查询零副作用）`
					: "[query_task] 启动对账报告不可用（组合根未接线或扫描失败；resume 原会话时自动执行 applyTaskRecovery 并缓存）";
				return { content: [{ type: "text" as const, text }] };
			}
			// K8c：三轴只读查询（view 档位，缺省 summary；handle 缺省=全量分页；零副作用——不回填磁盘/不创建内核）
			if (params.view !== undefined || params.handle !== undefined) {
				const level = params.view ?? "summary";
				const r = await queryTaskViews({
					handle: params.handle ?? params.session,
					...(params.view !== undefined ? { view: params.view } : {}),
					...(params.cursor !== undefined ? { cursor: params.cursor } : {}),
					...(params.limit !== undefined ? { limit: params.limit } : {}),
				});
				if (!r.ok) {
					return { content: [{ type: "text" as const, text: `[query_task] 三轴查询失败（${r.error.code}）: ${r.error.message}` }], isError: true };
				}
				const { page, legacy } = r.value;
				const lines: string[] = [`[query_task 三轴 ${level}] 契约任务 ${page.items.length} 条`];
				const pageState = { contractBaseShown: false }; // ev-20261012-4afdc8：基准提示页级单次
				for (const v of page.items) lines.push(...renderViewLine(v, level, pageState));
				if (page.items.length === 0 && params.handle === undefined && params.session === undefined) {
					lines.push("  （无契约任务——内核尚未持有任何任务；重启后等启动对账或先派发）");
				}
					lines.push(`[页] snapshotSeq=${page.snapshotSeq}${page.nextCursor !== undefined ? ` · nextCursor=${page.nextCursor}（翻页 query_task({ view, cursor })）` : ""}${page.truncated ? " · truncated" : ""}`);
				if (legacy.length > 0) {
					lines.push(`[遗留记录] ${legacy.length} 条无内核契约视图（v1 记录，无三轴）：${legacy.slice(0, 5).map((l: { taskId: string; agent: string; status: string }) => `${l.taskId.slice(0, 8)}(${l.agent}/${l.status})`).join(" ")}${legacy.length > 5 ? ` …另有 ${legacy.length - 5} 条` : ""}——详情 query_task({ session })`);
				}
				return { content: [{ type: "text" as const, text: lines.join("\n") }] };
			}
			// E6: 看板 headless 快照——TUI 看板（workflow-board）只是它的一个渲染器；
			// rpc/headless 场景下 Leader 可程序化读取 角色×任务矩阵 + blocked 队列。
			// P0.5：尾部附 journal 中断残留（跨进程在途，registry 内存态看不到）；
			// P3：无任何参数时缺省返回 board 快照（不再报错——实战高频误用零参调用）。
			if (params.board || (!params.session && !params.stats && !params.full && !params.evidenceDetail)) {
				const model = buildBoardModel(deps?.agents || [], registry.list());
				let text = params.json
					? JSON.stringify(model, null, 2)
					: renderBoardLines(model, 100).join("\n");
				try {
					// ev-20260920-6e687c：board 拉取面保留全部残留（含已通知）——主动弹窗一次性，但观察面永不丢信息。
					const inflight = journalInflight(undefined, { cwd: process.cwd(), includeNotified: true });
					if (inflight.length > 0) {
						const jlines = inflight.slice(-8).map((d) => `  ${d.taskId.slice(0, 8)} ${d.agent}${d.mode === "background" ? "(bg)" : ""} · cwd=${d.cwd} · ${formatAmagiClock(d.at, "local")}${d.notifiedAt !== undefined ? " ·已通知（启动弹窗不再重复）" : ""} · ${(d.goal || "").slice(0, 60).replace(/\s+/g, " ")}`);
						text += `\n[journal 中断残留] ${inflight.length} 个跨会话在途任务（派发后未结算——含上次终端/会话被杀时在途；query_task({ session: "<前缀>" }) 查轨迹，或 resume 续接）：\n${jlines.join("\n")}${inflight.length > 8 ? `\n  …另有 ${inflight.length - 8} 条` : ""}`;
					}
				} catch { /* journal 只读失败静默 */ }
				if (!params.board) text = `[query_task] 未提供参数——缺省返回看板快照（指定 session 查任务、stats 查仪表盘）\n\n${text}`;
				return { content: [{ type: "text" as const, text }] };
			}
			// E9: trace → 成本/质量仪表盘（只读聚合 traces.ndjson）
			if (params.stats) {
				const model = aggregateStats({ days: params.days });
				return { content: [{ type: "text" as const, text: renderStatsText(model) }] };
			}
			if (!params.session) {
				return { content: [{ type: "text" as const, text: `[query_task] 需要 session（taskId/sessionId 前缀、稳定 name 或精确 runId/name），或用 board:true 取看板快照` }], isError: true };
			}
			// v1.5.222：查询也走磁盘回填——Leader 重启后 registry 清空，但不该因此查不到
			// 历史任务（artifact/会话文件都在磁盘）；回填为只读收编，不产生副作用。
			const resolved = resolveSessionWithBackfill(params.session);
			if (!resolved) {
				return { content: [{ type: "text" as const, text: `[query_task] 未找到任务: "${params.session}"（registry 无记录；磁盘回退亦未命中——artifact 不存在或 sessionId 不可恢复）` }], isError: true };
			}
			const rec = resolved.record;
			const tail = Math.max(1, Math.min(50, params.tail ?? 10)); // P2-2: clamp 1-50
			const taskId = typeof rec.taskId === "string" ? rec.taskId : "?";
			const agent = typeof rec.agent === "string" ? rec.agent : "?";
			let text = `[query_task ${taskId.slice(0, 8)} ${agent}]\n状态: ${rec.status}${rec.mode ? ` (${rec.mode})` : ""}\n`;
			// K8c：三轴标注（执行结束≠已验收——老 UI 把待接受显示完成的修正；只读 peek，不因读创建内核）。
			// V3（§8.5 兼容显示）：终态而无内核视图（legacy v1 记录，无回执）——明确兼容标签，不补 ready/accepted。
			try {
				const kv = peekTaskKernel()?.get(taskId);
				if (kv) {
					const label = axisLabelOf({ execution: kv.execution, settlement: kv.settlement, acceptance: kv.acceptance });
					text += `三轴: ${label ?? `未结束（${kv.execution}/${kv.settlement}/${kv.acceptance}）`}（execution=${kv.execution} settlement=${kv.settlement} acceptance=${kv.acceptance}；stateSeq=${kv.stateSeq} revision=${kv.revision}）\n`;
				} else if (["done", "error", "cancelled", "answered", "truncated", "resolved-external"].includes(rec.status)) {
					text += `三轴: 无回执（legacy v1 记录——仅执行轴 ${rec.status}，未进入验证闭环；不补 ready/accepted）\n`;
				}
			} catch { /* 只读探测失败静默 */ }
			// ev-20260908-f189e7：外部处置终态展示收口注记（与 cancelled 区分——非放弃，产物已在外部采用）
			if (rec.status === "resolved-external") {
				text += `收口注记: ${rec.resolveNote || "产物已在外部采用，会话无需再跑"}（resolve(external) 轻量收口，终态不再可 resume；如需重跑请新派任务）\n`;
			}
			if (typeof rec.sessionId === "string" && rec.sessionId) text += `会话: ${rec.sessionId.slice(0, 12)}\n`;
			if (typeof rec.model === "string" && rec.model) text += `模型: ${rec.model}\n`;
			if (rec.rounds?.length) text += `resume 轮次: ${rec.rounds.length}\n`;
			// v1.5.184 耗时拆分：回答"时间花在思考还是工具"（实战：baize 侦察 think:tool ≈ 10:1~60:1）。
			if (typeof rec.thinkMs === "number" || typeof rec.toolMs === "number" || typeof rec.startupMs === "number") {
				const th = Math.round((rec.thinkMs ?? 0) / 1000), to = Math.round((rec.toolMs ?? 0) / 1000);
				const su = typeof rec.startupMs === "number" ? ` · 启动 ${Math.round(rec.startupMs / 1000)}s` : "";
				const wall = rec.startedAt && rec.endedAt ? Math.round((rec.endedAt - rec.startedAt) / 1000) : null;
				text += `耗时拆分: 模型生成 ${th}s · 工具执行 ${to}s${su}${wall !== null ? ` · 总 ${wall}s（其余 ${Math.max(0, wall - th - to)}s = 启动/IO/等待）` : ""}\n`;
			}
			if (typeof rec.retryAttempts === "number" && rec.retryAttempts > 0) {
				text += `provider 重试: ${rec.retryAttempts} 次（退避等待 ${Math.round((rec.retryWaitMs ?? 0) / 1000)}s）——provider 不稳定在沉默烧时间\n`;
			}
			// Wave C2 写入路径可观测：running 态展示最近写盘文件（Leader 判断与子任务的并行分工边界；空则省略）
			if (rec.status === "running" && rec.lastWritePaths?.length) {
				text += `最近写入: ${rec.lastWritePaths.map((p) => path.basename(p)).join(", ")}\n`;
			}
			if (rec.startedAt) text += `启动: ${safeTime(rec.startedAt)}\n`;
			if (rec.endedAt) text += `结束: ${safeTime(rec.endedAt)}\n`;
			if (rec.activityWindow?.length) {
				const events = rec.activityWindow.slice(-tail);
				text += `\n最近 ${events.length} 条活动:\n`;
				for (const e of events) {
					const eventType = typeof e?.type === "string" ? e.type : "?";
					const summary = typeof e?.summary === "string" ? e.summary.slice(0, 80) : "";
					text += `  ${safeTime(e?.ts)} ${eventType}: ${summary}\n`;
				}
			}
			if (params.full && typeof rec.sessionId === "string" && rec.sessionId) {
				// ev-20260904（截断不可达）：artifact 可用时预给全量摘要落盘路径（仅实际截断才写盘）
				const traceDump = (() => {
					try { return artifactEnabled() ? path.join(artifactRoot(), `${sanitizeId(taskId)}-trace.md`) : undefined; } catch { return undefined; }
				})();
				const summary = await readSessionSummary(rec.sessionId, 50 * 1024, traceDump);
				text += `\n--- 完整会话轨迹摘要（50KB cap）---\n${summary.text}`;
				if (summary.truncated) {
					// ev-20260901-cd4173 B：截断时直接给出完整落盘报告真实路径（免手动翻 artifacts 目录）
					const resultPath = fullReportArtifactPath(taskId);
					if (resultPath) text += `\n完整落盘报告：${resultPath}`;
					// ev-20260904（截断不可达根治）：原始会话文件 + 全量摘要落盘双通道——报告中间细节
					// （链路/步骤类内容）在早期条目里，旧端截断后 result.md（仅终稿）不可达，这两行补齐
					if (summary.sessionFile) text += `\n原始会话文件：${summary.sessionFile}（JSONL；read 分段/grep 关键词直达中间细节）`;
					if (summary.dumpedPath) text += `\n全量轨迹摘要（共 ${summary.totalEntries} 条，无截断）：${summary.dumpedPath}（read offset/limit 续读全部条目）`;
					// 复盘 2026-09-03 §5#5：目录真实存在时再补目录级指引（result.md + metadata.json）
					const dirHint = artifactDirHint(taskId);
					if (dirHint) text += `\n${dirHint}`;
				}
			}
			if (typeof rec.result === "string" && rec.result) {
				const resultPreview = capUtf8(rec.result, 2000);
				text += `\n--- 结果 ---\n${resultPreview}`;
				// ev-20260904（截断不可达）：结果预览被截时附完整终稿真实路径（存在才给）
				if (Buffer.byteLength(rec.result, "utf8") > 2000) {
					const fullResult = fullReportArtifactPath(taskId);
					if (fullResult && fs.existsSync(fullResult)) text += `\n完整终稿：${fullResult}`;
				}
			}
			// ev-20260916-01ef8c（S5 集成）：evidenceDetail=full 展开结束时的结构化分类快照
			// （classification.json——结束后工作树改动不改变旧详情，不重扫工作树）；旧任务/无快照
			// （无派发基线、非 git、artifact 关闭、blocked）明确不可用，不臆造。
			if (params.evidenceDetail === "full") {
				const _evCwd = typeof rec.cwd === "string" && rec.cwd ? rec.cwd : _ctx.cwd;
				let _fullEvText: string | null = null;
				try {
					const _art = findArtifact(_evCwd, taskId);
					const _raw = _art ? readEvidenceClassification(_art.relDir) : null;
					const _snap = parseEvidenceClassificationSnapshot(_raw);
					_fullEvText = _snap ? renderClassificationFull(_snap) : null;
				} catch { /* 读取失败按不可用呈现 */ }
				text += _fullEvText
					? `\n--- 证据分类详情（结束时快照）---\n${_fullEvText}`
					: `\n--- 证据分类详情（结束时快照）---\n未保存分类详情（旧任务、无派发基线、非 git 仓库、artifact 关闭或 blocked）——full 不可用，不臆造；当前工作树状态以终态正文证据块为准。`;
			}
			// ev-20260905-f51a49：失败任务附残留摘要行（可查询语义——重派前核验半成品；error 任务的写入
			// 登记已被收尾链消费清理，此处为 mtime 疑似档扫描 + cancelled 任务的登记档；N=0 不追加）。
			if (rec.status === "error" || rec.status === "cancelled") {
				try {
					const _qNote = residueNote(collectResidue(taskId, { cwd: typeof rec.cwd === "string" ? rec.cwd : undefined, startedAt: rec.startedAt }));
					if (_qNote) text += `\n\n${_qNote}`;
				} catch { /* 残留扫描失败静默 */ }
			}
			// 终稿兜底：error 任务的 registry.result 可能只是残片（如旧版缓冲截断），
			// 会话 JSONL 里终稿常在——直接捞出来，并给 resume 指引（实战：误判 error 三连 resume 轮回）。
			if (rec.status === "error") {
				if (rec.sessionId) {
					const finalText = await readSessionFinalText(rec.sessionId);
					if (finalText && finalText !== rec.result?.trim() && capUtf8(finalText, 2000) !== capUtf8(rec.result ?? "", 2000)) text += `\n\n--- 会话终稿兜底（会话文件最后 assistant 文本，截 2000 字）---\n${finalText}`;
				}
				// D2（ev-20260922-727096）：error 续接指引单源（recoveryActionOfRecord + renderRecoveryAdvice，
				// legacy 面渲染）——不再维护第二份 task({session}) 文案；句柄用完整 taskId（不用八位前缀）。
				const _recovery = renderRecoveryAdvice(recoveryActionOfRecord(rec), { surfaceVersion: 1 });
				text += `\n（完整轨迹: query_task({ session, full: true })）${_recovery ? `\n${_recovery}` : ""}`;
			}
			for (const file of archivedTaskContextRefs(taskId).filter((p) => path.basename(p) === "evidence.md")) text += `\n采集归档：${file}（按需 read；此处不展开全文）`;
			return { content: [{ type: "text" as const, text }] };
		},
	};
}
