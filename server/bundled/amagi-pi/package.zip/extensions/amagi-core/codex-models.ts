/**
 * codex-models.ts — openai-codex 前线模型抢先适配（v1.5.263）。
 *
 * 场景：OpenAI 后端已可用新模型（如 gpt-6-astra），但 pi.dev 官方目录 feed 尚未收录，
 * pi 内置模型目录（pi-ai providers/data + models-store.json 缓存）里没有它。
 *
 * 机制（基于 pi 0.84.4 provider-composer.js 源码验证，2026-09 实测）：
 *   1. registerProvider("openai-codex", { refreshModels }) 不带静态 models——
 *      applyExtension 无 models 字段时原样保留下层列表（内置 + pi.dev 远程目录），
 *      注册初始零遮蔽；扩展注册的 models 是替换语义，绝不能只写新模型。
 *   2. composer 保证 refreshModels 时序：base.refreshModels（pi.dev → models-store.json
 *      持久化）先跑，extension.refreshModels 后跑——我们读到的 store 一定最新。
 *   3. 我们的 refreshModels 返回全量列表 = store 的 openai-codex 条目 + 候选新模型；
 *      refreshedExtensionModels 替换生效后 getModels 即含新模型。框架对 extension
 *      返回值只 publish({update}) 不 persist——不污染 models-store.json。
 *   4. 候选模型只需 id + 元数据差异：applyExtension 的 defaults 继承链
 *      （api/baseUrl 从同 id 内置模型或列表首项继承），无需重复 baseUrl。
 *   5. 官方目录收录候选后：store 条目已含该 id → 候选自动跳过（不重复、元数据以
 *      官方为准），届时从候选清单删除即可，无残留。
 *
 * 兜底：store 文件读取失败且 context 目录快照缺位 → 返回 undefined（本轮跳过，
 * getModels 保持无遮蔽默认）。绝不返回空数组（truthy 会替换成空列表，清空 provider）。
 *
 * 主进程与子进程（AMAGI_SUBAGENT=1）都注册：子 Agent 派发同样需要模型目录。
 * 全程 best-effort：任何异常吞掉并 stderr 单行提示，绝不阻断扩展加载。
 * 环境开关：AMAGI_CODEX_FRONTLINE=0 整体关闭。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { amagiDataFile } from "./data-dir.ts";
import { discoverAgents } from "./agents-loader.ts";

/** pi agent 目录（尊重 PI_CODING_AGENT_DIR，与 model-resolver.ts 同规）。 */
function agentDir(): string {
	const override = process.env.PI_CODING_AGENT_DIR;
	return override && override.trim() ? override : path.join(os.homedir(), ".pi", "agent");
}

/** models-store.json 条目里单模型的宽松形状（store 存完整 Model 定义，原样回传）。 */
interface StoreModel {
	id: string;
	[name: string]: unknown;
}

/**
 * 前线候选模型清单。只列「后端已可用、官方目录未收录」的模型。
 * 官方收录后（pi.dev feed 推送，models-store.json 出现同 id）自动退位。
 * 元数据对齐 gpt-5.6 系列（2026-09 后端实测可用的最近代系）；cost 未知置 0，
 * 只影响成本统计不影响调用；contextWindow/maxTokens 影响压缩阈值，官方收录后以官方为准。
 */
/**
 * 实测后端支持的 effort 值集（2026-09-05 gpt-6-astra 400 错误信息直列）：
 * low/medium/high/xhigh；minimal 不被后端接受（pi 内置目录用 minimal→low 别名）。
 * 思考档全档映射（对齐 pi EXTENDED_THINKING_LEVELS，off 除外）：
 *   off 不写入 map——pi 语义默认支持（不发 reasoning），写 off:"none" 反而可能触发
 *   后端不接受的 effort="none" 发送路径（openai-codex-responses.js L418 特判）；
 *   minimal→low 后端别名；max→xhigh 向上钔制别名（后端无 max）。
 * 显式全档的好处：目录即事实，展示方无需复刻 pi 隐式默认规则。
 */
const FULL_THINKING_LEVEL_MAP: Record<string, string> = {
	minimal: "low",
	low: "low",
	medium: "medium",
	high: "high",
	xhigh: "xhigh",
	max: "xhigh",
};

const FRONTLINE_MODELS: StoreModel[] = [
	{
		id: "gpt-6-astra",
		name: "GPT-6 Astra",
		reasoning: true,
		input: ["text", "image"],
		cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
		contextWindow: 272000,
		maxTokens: 128000,
		thinkingLevelMap: { ...FULL_THINKING_LEVEL_MAP },
	},
];

/**
 * 基础模型档位补全（gpt-5.6 系列等）：官方目录 map 只显式标了 xhigh/minimal 两键，
 * pi 运行时靠「标准档默认支持」隐式规则补齐六档，但 max 无键仍不可选，展示方只取
 * map 键的（如 amagi-codebox）更是只看到两档。补全策略（保守，仅补缺不覆盖）：
 *   - map 存在且缺标准档键（off/minimal/low/medium/high）→ 按 pi 默认语义显式化
 *   - 缺 max 键 → 补 max→xhigh 向上钔制别名
 * 返回原对象引用（未命中条件）或补全后的新对象；补全记录进 patches（供契约文件下发）。
 */
function patchThinkingLevels(model: StoreModel, patches: Record<string, Record<string, unknown>>): StoreModel {
	if (model.reasoning !== true) return model;
	const map = model.thinkingLevelMap;
	if (!map || typeof map !== "object") return model;
	const missing = ["minimal", "low", "medium", "high", "xhigh", "max"].filter((k) => !(k in map));
	if (missing.length === 0) return model;
	const next: Record<string, string | null> = { ...map };
	for (const k of missing) {
		next[k] = FULL_THINKING_LEVEL_MAP[k];
	}
	model.thinkingLevelMap = next;
	patches[model.id] = { thinkingLevelMap: next };
	return model;
}

/** 读 models-store.json 的 openai-codex 条目模型列表；失败返回 null（调用方降级）。 */
function readStoreCodexModels(): StoreModel[] | null {
	const storePath = path.join(agentDir(), "models-store.json");
	try {
		const raw = fs.readFileSync(storePath, "utf8");
		const data = JSON.parse(raw.replace(/^\uFEFF/, "")) as Record<string, unknown>;
		const entry = data["openai-codex"];
		const models = (entry as { models?: unknown } | undefined)?.models;
		return Array.isArray(models) ? (models as StoreModel[]) : null;
	} catch {
		return null;
	}
}

/** 无持久目录时由宿主公开 ModelRuntime 读取本机内置与 models.json 目录；不刷新网络或认证。 */
async function localCodexModels(): Promise<StoreModel[] | null> {
	try {
		const host = await import("@earendil-works/pi-coding-agent");
		if (!host.ModelRuntime?.create) return null;
		const runtime = await host.ModelRuntime.create({ refreshOnCreate: false });
		const models = runtime.getAllModels("openai-codex");
		return models.length ? models.map((model) => ({ ...model })) : null;
	} catch { return null; }
}

// ── v2.21.24：配置引用自动合成（目录滞后不再阻断派发）──
// 实战（2026-10-29 两次派发中断）：openai-codex/gpt-6.1-terra 服务商已上线，pi.dev 官方
// 目录只收录到 gpt-6.1-sol——任务派发在 model-resolver 注册表校验处硬失败，而唯一逃生阀
// （上方硬编码 FRONTLINE_MODELS）每出一个新模型都要改代码等发版。修复：amagi 配置面
// （全局/项目 amagi.json 的 agents.*.model、profiles、角色卡 frontmatter）引用的
// openai-codex 模型若不在目录中，优先按同族继承；无同族时使用现有 Codex 协议模板。
// 模型 ID、能力、价格及窗口未经验证，拼写错误或不兼容参数交由供应商如实拒绝。

/** 从 model spec 提取 openai-codex 模型 id（去 thinking 后缀）；非本 provider/形态异常 → null。 */
export function codexModelIdFromSpec(spec: string): string | null {
	if (typeof spec !== "string" || !spec.trim()) return null;
	const noThinking = spec.includes("/") ? spec.replace(/:(?:off|minimal|low|medium|high|xhigh|max)$/, "") : spec;
	const slash = noThinking.indexOf("/");
	if (slash <= 0 || noThinking.includes("/", slash + 1)) return null;
	if (noThinking.slice(0, slash) !== "openai-codex") return null;
	const id = noThinking.slice(slash + 1).trim();
	return /^[A-Za-z0-9._-]+$/.test(id) ? id : null;
}

/** 测试注入面（null=恢复真实路径；对齐 model-resolver._setConfigPathForTest 模式）：
 *  refreshModels 内部扫描用真实全局/项目/profiles/agents 路径，测试经此隔离，
 *  免受真仓仓库配置面污染（实战：tiered.json 引用 gpt-5.6-sol 波及旧隔离测试）。 */
let frontlineScanOverrides: { agentDir?: string; cwd?: string; profilesDir?: string; agentsDir?: string } | null = null;
export function _setFrontlineScanForTest(overrides: { agentDir?: string; cwd?: string; profilesDir?: string; agentsDir?: string } | null): void {
	frontlineScanOverrides = overrides;
}

/** 收集 amagi 配置面引用的 openai-codex 模型 id（去重，字典序稳定）。best-effort：
 *  任一源读不到/坏 JSON → 该源贡献空集，绝不抛出阻断扩展加载。测试可注入各目录。 */
export function collectCodexFrontlineReferences(opts?: {
	agentDir?: string;
	cwd?: string;
	profilesDir?: string;
	agentsDir?: string;
}): string[] {
	const dirs = {
		agentDir: opts?.agentDir ?? frontlineScanOverrides?.agentDir ?? agentDir(),
		cwd: opts?.cwd ?? frontlineScanOverrides?.cwd ?? process.cwd(),
		profilesDir: opts?.profilesDir ?? frontlineScanOverrides?.profilesDir ?? path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "profiles"),
		agentsDir: opts?.agentsDir ?? frontlineScanOverrides?.agentsDir ?? path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "agents"),
	};
	const ids = new Set<string>();
	const add = (spec: unknown): void => {
		if (typeof spec !== "string") return;
		const id = codexModelIdFromSpec(spec);
		if (id) ids.add(id);
	};
	const readJson = (file: string): Record<string, unknown> | null => {
		try {
			const parsed = JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
			return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? (parsed as Record<string, unknown>) : null;
		} catch { return null; }
	};
	// ① 全局/项目 amagi.json：agents.<role>.model
	for (const file of [path.join(dirs.agentDir, "amagi.json"), path.join(dirs.cwd, "amagi.json")]) {
		const root = readJson(file);
		const agents = root?.agents;
		if (agents && typeof agents === "object" && !Array.isArray(agents)) {
			for (const entry of Object.values(agents as Record<string, unknown>)) {
				if (entry && typeof entry === "object" && !Array.isArray(entry)) add((entry as { model?: unknown }).model);
			}
		}
	}
	// ② profiles/*.json：leader/fast/work/expert + agentOverrides 值
	try {
		for (const name of fs.readdirSync(dirs.profilesDir).filter((n) => n.endsWith(".json")).sort()) {
			const profile = readJson(path.join(dirs.profilesDir, name));
			if (!profile) continue;
			for (const key of ["leader", "fast", "work", "expert"]) add(profile[key]);
			const overrides = profile.agentOverrides;
			if (overrides && typeof overrides === "object" && !Array.isArray(overrides)) {
				for (const value of Object.values(overrides as Record<string, unknown>)) add(value);
			}
		}
	} catch { /* 目录缺失/读取失败：该源贡献空集 */ }
	// ③ 角色卡 frontmatter model（discoverAgents 已做 frontmatter 解析与安全校验）
	try {
		for (const agent of discoverAgents(dirs.agentsDir).agents) add(agent.model);
	} catch { /* agents 目录异常：该源贡献空集（discoverAgents 自身不抛，双保险） */ }
	return [...ids].sort();
}

/** 优先取同前缀 contextWindow 最大者，否则取已知 Codex 协议模板；无模板返回 null。 */
export function synthesizeFrontlineModel(id: string, base: StoreModel[]): StoreModel | null {
	const lastDash = id.lastIndexOf("-");
	const prefix = lastDash > 0 ? id.slice(0, lastDash + 1) : null;
	let template: StoreModel | null = null;
	for (const model of base) {
		if (!prefix || typeof model?.id !== "string" || model.id === id || !model.id.startsWith(prefix) || (model.type !== undefined && model.type !== "chat") || (model.api !== undefined && model.api !== "openai-codex-responses")) continue;
		if (!template || Number(model.contextWindow ?? 0) > Number(template.contextWindow ?? 0)) template = model;
	}
	// 无同族时仅复用已知 Codex 协议的目录模型，不根据版本号猜测支持情况。
	// 克隆的能力、窗口与价格只是模板值，远端仍可能拒绝模型或参数。
	if (!template) template = base.find((m) => m?.id !== id && m?.api === "openai-codex-responses" && (m.type === undefined || m.type === "chat")) ?? null;
	if (!template) return null;
	return { ...template, id, name: id };
}

/**
 * 前线清单对外契约文件（amagi-codebox provider center 下拉等展示方消费）：
 * refreshModels 生效时落盘当前追加清单 + 基础模型档位补丁，官方全收录（退位）时删除。
 * 展示辅助而非正确性依赖：写/删失败一律静默。
 */
const FRONTLINE_CONTRACT_FILE = "codex-frontline.json";

function writeFrontlineContract(additions: StoreModel[], patches: Record<string, Record<string, unknown>>): void {
	try {
		if (additions.length === 0 && Object.keys(patches).length === 0) {
			fs.rmSync(amagiDataFile(FRONTLINE_CONTRACT_FILE), { force: true });
			return;
		}
		const payload: Record<string, unknown> = {
			provider: "openai-codex",
			updatedAt: new Date().toISOString(),
		};
		if (additions.length > 0) payload.models = additions;
		if (Object.keys(patches).length > 0) payload.modelPatches = patches;
		const file = amagiDataFile(FRONTLINE_CONTRACT_FILE);
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.writeFileSync(file, JSON.stringify(payload, null, "\t") + "\n");
	} catch {
		/* 展示辅助：失败静默 */ }
}

export function registerCodexFrontlineModels(pi: ExtensionAPI): void {
	if (process.env.AMAGI_CODEX_FRONTLINE === "0") return;
	const dispatchedId = process.env.AMAGI_SUBAGENT === "1" ? codexModelIdFromSpec(process.env.AMAGI_DISPATCH_MODEL ?? "") : null;
	// CLI 可在 --model 未匹配时回退。子进程选模后核实身份，绝不向错误模型发送任务。
	if (dispatchedId && typeof pi.on === "function") pi.on("session_start", async (_event, ctx) => {
		if (ctx.model?.provider !== "openai-codex" || ctx.model.id !== dispatchedId) {
			console.error(`[amagi-core] 子进程模型选择失败：期望 openai-codex/${dispatchedId}，实际 ${ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : "无模型"}；未发送任务`);
			process.exit(1);
		}
	});
	let announced = false;
	let localModels: Promise<StoreModel[] | null> | undefined;
	try {
		// 类型注：pi 内嵌 pi-ai 0.84 的 RefreshModelsContext 字段为 stored（0.83 叫 store），
		// 且运行时对 falsy 返回值取「不替换」语义（composer: if (refreshed)）——
		// 0.83 类型签名不认可 undefined 返回，因此函数体返回 unknown、注册处整体 cast。
		const refreshModels = async (context: unknown): Promise<unknown> => {
			// 全量基础：store 文件（base.refreshModels 刚持久化，最新）；
			// 读取失败降级 context 目录快照（0.84=stored / 0.83=store，可能滞后一轮）。
			const ctx = context as { stored?: { models?: unknown }; store?: { models?: unknown } };
			const snapshot = ctx.stored ?? ctx.store;
			const snapshotModels = Array.isArray(snapshot?.models)
				? (snapshot as { models: StoreModel[] }).models
				: null;
			const storedModels = readStoreCodexModels();
			const base = (storedModels?.length ? storedModels : null)
				?? (snapshotModels?.length ? snapshotModels : null)
				?? (dispatchedId ? await (localModels ??= localCodexModels()) : null);
			if (!base || base.length === 0) {
				// 基础不可得：跳过本轮（undefined 不替换，getModels 保持内置无遮蔽）。
				// 全新环境首次网络 refresh 写入 store 后自动恢复。
				return undefined;
			}
			const seen = new Set(base.map((m) => m.id));
			// 基础模型档位补全（gpt-5.6 系列 max 档等）：只补缺不覆盖，记录进 patches。
			const patches: Record<string, Record<string, unknown>> = {};
			const patchedBase = base.map((m) => patchThinkingLevels(m, patches));
			const additions = [...FRONTLINE_MODELS.filter((m) => !seen.has(m.id))];
			// v2.21.24：配置引用自动合成——amagi 配置面（amagi.json/profiles/角色卡）引用而
			// 目录未收录的模型按模板继承元数据抢先注册；官方收录后随 seen 自然退位。
			const synthesized: StoreModel[] = [];
			// 每个子进程只接收本次冻结的模型，不写共享配置或泄漏到其他任务。
			const configuredIds = collectCodexFrontlineReferences();
			for (const id of [...configuredIds, ...(dispatchedId ? [dispatchedId] : [])]) {
				if (seen.has(id) || additions.some((m) => m.id === id) || synthesized.some((m) => m.id === id)) continue;
				const candidate = synthesizeFrontlineModel(id, patchedBase);
				if (candidate) synthesized.push(candidate);
			}
			const allAdditions = [...additions, ...synthesized];
			if (allAdditions.length === 0 && Object.keys(patches).length === 0) {
				writeFrontlineContract([], {}); // 官方全收录且档位已全：删契约文件，展示方自动退位
				return undefined; // 无需接管
			}
			const merged = [...patchedBase, ...allAdditions];
			// 临时派发的模型不写入共享展示契约（不影响配置引用与固定前线项）。
			writeFrontlineContract([...additions, ...synthesized.filter((m) => configuredIds.includes(m.id))], patches);
			// 多轮 refresh（注册/启动/周期各一轮）只提示一次，防 stderr 刷屏。
			if (!announced) {
				announced = true;
				if (!process.env.AMAGI_SUBAGENT && process.env.AMAGI_CODEX_FRONTLINE !== "quiet") {
					console.error(
						// v2.8.6 修复：additions 为空（官方已收录前线条目）而仅剩档位补丁时，
						// 原文案会输出「+（pi.dev 目录未收录…）」空列表误导行——按实际生效面区分。
						allAdditions.length > 0
							? `[amagi-core] codex 前线模型生效：+${allAdditions.map((m) => m.id).join(", ")}（pi.dev 目录未收录，amagi 抢先适配；官方收录后自动退位）${synthesized.length > 0 ? `；其中配置引用自动合成：${synthesized.map((m) => m.id).join(", ")}` : ""}`
							: `[amagi-core] codex 前线档位补丁生效：${Object.keys(patches).join(", ")}（官方目录已收录前线条目，仅补全 thinkingLevelMap 缺档）`,
					);
				}
			}
			return merged; // ProviderModelConfig[]：store 条目即完整 Model，字段超集无害
		};
		pi.registerProvider("openai-codex", { refreshModels: refreshModels as never });
	} catch (e) {
		console.error(`[amagi-core] codex 前线模型注册失败（不影响其他功能）: ${e instanceof Error ? e.message : String(e)}`);
	}
}
