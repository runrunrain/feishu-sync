/**
 * 同文件写入串行（主上批准改进：插件为模型服务，能由工具自动处理的就不让模型记规则）。
 *
 * 场景：模型在同一条 assistant 消息里并行发出「Write 任务书文件」与「task_submit/task_batch
 * 引用该 taskFile」。pi 同批工具调用默认并行执行，原生 write/edit 只在彼此之间按 realpath 串行
 * （withFileMutationQueue），读取方不在队列内——taskFile 读取可能先于写入完成，读到旧内容或空文件。
 *
 * 机制：pi 对同批工具调用先逐个 await 发出 tool_execution_start（扩展监听器在任何 execute 之前
 * 全部跑完），再并发执行；每个调用结束发 tool_execution_end。本模块在 start 时登记 write/edit 的
 * 目标路径（规范化真实路径），end 时退场并唤醒等待者；失败事实按 sessionId 保留到 turn_end，
 * 在 turn_start 也清理旧事实。宿主预检失败可能在任何 execute 前立即 end，不能随 pending 一起遗忘。
 * taskFile 读取前 awaitPendingFileMutations 核验同轮失败并等待同文件在途写入完成，
 * 超时（默认 30s，AMAGI_TASKFILE_WRITE_WAIT_MS 可调）报清晰错误。
 * 纯观测登记，不改变工具执行顺序、参数或结果。
 * 边界：只等待读取快照前已登记的调用；不是对未来写入、外部进程或 bash/MCP 写文件的锁。
 * pi 1.3.0 的批内 start→execute 屏障已有真实 Agent loop 回归（1.4.0 源码亦已核对）；旧宿主或嵌套调用若没有该屏障，
 * 且写入在读取快照之后才开始登记，无法预测或等待，不承诺冻结其未来版本。
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

interface PendingMutation {
	sessionId: string;
	toolCallId: string;
	toolName: string;
	keys: string[];
	startedAt: number;
	done: Promise<void>;
	resolve: () => void;
	failed?: boolean;
}

const pending = new Map<string, PendingMutation>();
// 只保留当前轮的已结束失败：宿主可能在准备阶段立即发 end，读取工具尚未进入 execute。
const completedFailures = new Map<string, PendingMutation>();
const mutationKey = (sessionId: string, toolCallId: string): string => JSON.stringify([sessionId, toolCallId]);

/** 生产接线始终传会话身份；无 sessionManager 的直调/测试按 cwd 隔离。 */
export function fileMutationSessionId(ctx: unknown, cwd: string): string {
	const manager = (ctx as { sessionManager?: { getSessionId?: () => string } } | undefined)?.sessionManager;
	return manager?.getSessionId?.() ?? path.resolve(cwd);
}

/** 当前轮开始/结束清理已结束失败，不能把历史失败永久施加到后续任务。 */
export function clearCompletedFileMutations(sessionId: string): void {
	for (const [key, entry] of completedFailures) if (entry.sessionId === sessionId) completedFailures.delete(key);
}

/** 写入类工具名（大小写不敏感；amagi override 与原生同名）。 */
const MUTATION_TOOLS = new Set(["write", "edit"]);

export const DEFAULT_FILE_MUTATION_WAIT_MS = 30_000;

/** 等待上限：AMAGI_TASKFILE_WRITE_WAIT_MS 正整数毫秒；缺省/非法回落默认值。 */
export function fileMutationWaitMs(env: NodeJS.ProcessEnv = process.env): number {
	const raw = env.AMAGI_TASKFILE_WRITE_WAIT_MS;
	const v = raw === undefined || raw === "" ? NaN : Number(raw);
	return Number.isFinite(v) && v > 0 ? Math.max(1, Math.floor(v)) : DEFAULT_FILE_MUTATION_WAIT_MS;
}

/** 路径规范化候选键集（与 pi 写工具同口径：@ 前缀剥离、~ 展开、相对 cwd 解析）：
 *  ① 父目录 realpath + 文件名（文件尚未创建时仍可比对，吸收 /var→/private/var 等目录软链）；
 *  ② 文件存在时其完整 realpath（吸收文件级软链）。任一键相交即视为同一文件。 */
export function fileMutationKeys(filePath: string, cwd: string): string[] {
	let p = filePath;
	if (p.startsWith("@")) p = p.slice(1);
	if (p === "~") p = os.homedir();
	else if (p.startsWith("~/")) p = path.join(os.homedir(), p.slice(2));
	const abs = path.resolve(cwd, p);
	const keys = new Set<string>([abs]);
	// 新文件的多层父目录也可能尚未创建：向上找到第一个存在的祖先，再拼回余下路径。
	for (let dir = path.dirname(abs); ; dir = path.dirname(dir)) {
		try { keys.add(path.resolve(fs.realpathSync(dir), path.relative(dir, abs))); break; } catch { /* lint-exempt:祖先不存在时继续向上 */ }
		if (path.dirname(dir) === dir) break;
	}
	try { keys.add(fs.realpathSync(abs)); } catch { /* lint-exempt:文件尚未创建时无完整 realpath 键 */ }
	return [...keys];
}

function mutationTargets(args: unknown): string[] {
	if (!args || typeof args !== "object") return [];
	const a = args as { path?: unknown; files?: unknown };
	const out: string[] = [];
	if (typeof a.path === "string" && a.path.trim()) out.push(a.path);
	if (Array.isArray(a.files)) for (const f of a.files) if (typeof f === "string" && f.trim()) out.push(f);
	return out;
}

/** tool_execution_start 钩子：登记 write/edit 在途目标（非写入工具/无路径参数忽略）。 */
export function noteFileMutationStart(event: { toolCallId?: unknown; toolName?: unknown; args?: unknown }, cwd: string, sessionId = path.resolve(cwd)): void {
	const toolName = typeof event.toolName === "string" ? event.toolName : "";
	if (!MUTATION_TOOLS.has(toolName.toLowerCase()) || typeof event.toolCallId !== "string") return;
	const keys = mutationTargets(event.args).flatMap((t) => fileMutationKeys(t, cwd));
	if (keys.length === 0) return;
	let resolve!: () => void;
	const done = new Promise<void>((r) => { resolve = r; });
	const key = mutationKey(sessionId, event.toolCallId);
	pending.get(key)?.resolve();
	pending.set(key, { sessionId, toolCallId: event.toolCallId, toolName, keys, startedAt: Date.now(), done, resolve });
}

/** end：成功退场，失败保留到当前轮边界，二者都唤醒等待者。 */
export function noteFileMutationEnd(event: { toolCallId?: unknown; isError?: unknown }, sessionId?: string): void {
	if (typeof event.toolCallId !== "string") return;
	// 兼容直接 helper 调用；生产总有 sessionId。无身份且存在同名并发调用时不猜所属会话。
	const matches = sessionId === undefined ? [...pending.values()].filter((m) => m.toolCallId === event.toolCallId) : [];
	const entry = sessionId === undefined ? (matches.length === 1 ? matches[0] : undefined) : pending.get(mutationKey(sessionId, event.toolCallId));
	if (!entry) return;
	entry.failed = event.isError === true;
	const key = mutationKey(entry.sessionId, entry.toolCallId);
	pending.delete(key);
	if (entry.failed) completedFailures.set(key, entry);
	entry.resolve();
}

export interface FileMutationWaitResult {
	ok: boolean;
	/** 实际等待过的在途写入数（0=无需等待）。 */
	waited: number;
	waitedMs: number;
	error?: string;
}

/** 读取前等待同文件在途 write/edit 完成；超时或中止返回 ok:false + 可读错误（不抛出）。 */
export async function awaitPendingFileMutations(
	filePath: string, cwd: string,
	opts: { timeoutMs?: number; signal?: AbortSignal; sessionId?: string } = {},
): Promise<FileMutationWaitResult> {
	const startedAt = Date.now();
	const timeoutMs = opts.timeoutMs ?? fileMutationWaitMs();
	// 同一 JS 调用栈中 Promise.all 的另一调用可能尚未进入 start 钩子；让它先登记再做快照。
	// 只让出一个微任务，不以轮询/任意延迟假装能预测未来尚未启动的调用。
	await Promise.resolve();
	const sessionId = opts.sessionId ?? path.resolve(cwd);
	const keys = new Set(fileMutationKeys(filePath, cwd));
	const sameFile = (m: PendingMutation): boolean => m.sessionId === sessionId && m.keys.some((k) => keys.has(k));
	const matching = () => [...pending.values()].filter(sameFile);
	let waited = 0;
	const completedFailure = (): FileMutationWaitResult | undefined => {
		const failed = [...completedFailures.values()].filter(sameFile);
		if (!failed.length) return undefined;
		return { ok: false, waited, waitedMs: Date.now() - startedAt, error: `同文件写入失败（${failed.map((m) => `${m.toolName}#${m.toolCallId}`).join("、")}）: ${path.resolve(cwd, filePath)}——任务未提交，避免冻结旧正文；确认写入成功后重新提交` };
	};
	const alreadyFailed = completedFailure();
	if (alreadyFailed) return alreadyFailed;
	for (let current = matching(); current.length > 0; current = matching()) {
		waited += current.length;
		const remaining = timeoutMs - (Date.now() - startedAt);
		let timer: ReturnType<typeof setTimeout> | undefined;
		let onAbort: (() => void) | undefined;
		const outcome = await Promise.race([
			Promise.all(current.map((m) => m.done)).then(() => "done" as const),
			new Promise<"timeout">((r) => { timer = setTimeout(() => r("timeout"), Math.max(0, remaining)); }),
			new Promise<"aborted">((r) => {
				if (!opts.signal) return;
				if (opts.signal.aborted) { r("aborted"); return; }
				onAbort = () => r("aborted");
				opts.signal.addEventListener("abort", onAbort, { once: true });
			}),
		]);
		if (timer) clearTimeout(timer);
		if (onAbort) opts.signal?.removeEventListener("abort", onAbort);
		const waitedMs = Date.now() - startedAt;
		if (outcome === "aborted") return { ok: false, waited, waitedMs, error: `等待同文件写入时调用被中止: ${path.resolve(cwd, filePath)}` };
		if (outcome === "done" && current.some((m) => m.failed)) {
			return { ok: false, waited, waitedMs, error: `同文件写入失败（${current.filter((m) => m.failed).map((m) => `${m.toolName}#${m.toolCallId}`).join("、")}）: ${path.resolve(cwd, filePath)}——任务未提交，避免冻结旧正文；确认写入成功后重新提交` };
		}
		if (outcome === "timeout") {
			const who = matching().map((m) => `${m.toolName}#${m.toolCallId}`).join("、") || "（已结束）";
			return { ok: false, waited, waitedMs, error: `任务书文件仍在被写入（${who}），等待 ${timeoutMs}ms 超时未完成: ${path.resolve(cwd, filePath)}——命令未提交；确认写入成功后重新提交，或改用 task 直接传正文（AMAGI_TASKFILE_WRITE_WAIT_MS 可调等待上限）` };
		}
	}
	return completedFailure() ?? { ok: true, waited, waitedMs: Date.now() - startedAt };
}

/** 测试辅助：清空在途登记（唤醒全部等待者）。 */
export function resetFileMutationTrackerForTests(): void {
	cancelPendingFileMutations();
}

/** session_shutdown：不让过期登记污染下一会话；等待者按写入失败拒绝，不读取半成品。 */
export function cancelPendingFileMutations(sessionId?: string): void {
	for (const [key, m] of pending) if (sessionId === undefined || m.sessionId === sessionId) {
		m.failed = true; m.resolve(); pending.delete(key);
	}
	if (sessionId === undefined) completedFailures.clear();
	else clearCompletedFileMutations(sessionId);
}
