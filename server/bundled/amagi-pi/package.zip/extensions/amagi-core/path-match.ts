/**
 * path-match.ts — allowedPaths 白名单共享 matcher（ev-20260914-9084ee，friction/P1）。
 *
 * 背景：派发者写 "data/cfg/gds_" 想前缀匹配一组文件，守卫按「目录或精确文件」语义判定
 * 目录不存在 → 节点写入被反复拦截（多次达终止阈值，R2 blocked+resume 才收口）。
 * 根因是派发端预检与写守卫端各自实现「条目→可写集」判定，且都不支持前缀意图的表达。
 *
 * 本模块是唯一的条目语义源（单一实现，派发端预检 / 写守卫端 / reportPath 互锁共用）：
 *  - plain（无语法条目）：目录或精确文件（path.relative 前缀包含语义，向后兼容）；
 *  - glob（含 * 或 ? 的条目，如 "data/cfg/gds_*.tres"）：通配匹配（* 不跨 /，** 跨 /）；
 *  - prefix（"prefix:" 前缀语法，如 "prefix:data/cfg/gds_"）：显式字符串前缀（文件/目录均可）。
 *
 * 配套能力（同模块纯函数，避免语义第二源）：
 *  - resolveAllowedPathEntry：scheme 保留解析（prefix:xxx → "prefix:"+绝对路径；通配符原样透传）；
 *  - expandGlobPaths：glob 展开为现存文件集合（派发期存在性预检复用）；
 *  - globStaticBaseDir：glob 静态基目录（零命中时校验目录在工作区子树内）；
 *  - whitelistPrefixIntentHint：首拦诊断——无语法条目疑似前缀短写时给出 glob/prefix 改写指引。
 */
import * as fs from "node:fs";
import * as path from "node:path";

/** 显式前缀语法 scheme。 */
export const ALLOWED_PREFIX_SCHEME = "prefix:";

export type AllowedPathKind = "plain" | "glob" | "prefix";

export interface ParsedAllowedPathEntry {
	kind: AllowedPathKind;
	/** scheme 剥离后的路径部分（glob 条目含通配符；prefix 条目为纯路径）。 */
	value: string;
	/** 语法无效时的原因（如 prefix: 后缺路径 / prefix 与通配符混用）。 */
	invalid?: string;
}

/** 条目是否含 glob 通配符（* 或 ?）。 */
export function isGlobPattern(s: string): boolean {
	return /[*?]/.test(s);
}

/** 解析白名单条目形态（纯函数；invalid 非空表示语法无效，调用方应拒单/诊断）。 */
export function parseAllowedPathEntry(entry: string): ParsedAllowedPathEntry {
	const t = entry.trim();
	if (!t) return { kind: "plain", value: t, invalid: "空白条目" };
	if (t.startsWith(ALLOWED_PREFIX_SCHEME)) {
		const rest = t.slice(ALLOWED_PREFIX_SCHEME.length).trim();
		if (!rest) return { kind: "prefix", value: "", invalid: `${ALLOWED_PREFIX_SCHEME} 后缺少路径（如 prefix:data/cfg/gds_）` };
		if (isGlobPattern(rest)) return { kind: "prefix", value: rest, invalid: `${ALLOWED_PREFIX_SCHEME} 显式前缀语义与通配符（*/?）互斥——前缀直接写全（如 prefix:data/cfg/gds_），通配需求用 glob 形态（如 data/cfg/gds_*.tres）` };
		return { kind: "prefix", value: rest };
	}
	if (isGlobPattern(t)) return { kind: "glob", value: t };
	return { kind: "plain", value: t };
}

/** scheme 保留解析：相对路径按 cwd 解析为绝对，prefix: 前缀重挂；glob 通配符原样透传（path.resolve 视为普通字符）。 */
export function resolveAllowedPathEntry(entry: string, cwd: string): string {
	const t = entry.trim();
	if (t.startsWith(ALLOWED_PREFIX_SCHEME)) {
		const rest = t.slice(ALLOWED_PREFIX_SCHEME.length).trim();
		if (!rest) return t;
		return ALLOWED_PREFIX_SCHEME + (path.isAbsolute(rest) ? rest : path.resolve(cwd, rest));
	}
	return path.isAbsolute(t) ? t : path.resolve(cwd, t);
}

/** glob → RegExp（* 单段内匹配、不跨 /；** 跨目录；? 单字符）。 */
export function globToRegExp(pattern: string): RegExp {
	let src = "";
	for (let i = 0; i < pattern.length; i++) {
		const ch = pattern[i]!;
		if (ch === "*") {
			if (pattern[i + 1] === "*") {
				while (pattern[i + 1] === "*") i++;
				src += ".*";
			} else {
				src += "[^/]*";
			}
		} else if (ch === "?") {
			src += "[^/]";
		} else {
			src += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
	}
	return new RegExp(`^${src}$`);
}

/** 单段 glob 源串（段内无 /，* 等价 .*、? 等价 .）。 */
function globSegmentSource(seg: string): string {
	let src = "";
	for (const ch of seg) {
		if (ch === "*") src += ".*";
		else if (ch === "?") src += ".";
		else src += ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	}
	return src;
}

/** 共享 matcher：写入目标（绝对）是否命中白名单任一条目。
 *  plain=path.relative 前缀包含（目录含其下全部文件，与既有守卫语义逐字兼容）；
 *  glob=通配匹配；prefix:=字符串前缀（目标等于或以声明前缀开头）。
 *  diting M-1（ev-20260914-9084ee 安全回归修复）：targetAbs 与各 bound 统一 path.normalize
 *  后再比对——攻击形态 `/repo/data/cfg/gds_x/../../evil.sh` 词法上以白名单前缀开头
 *  （startsWith / glob-`**` 正则均放行）而实际写点在范围外。词法归一不解析 symlink；
 *  plain 分支 path.relative 本就解析 `..` 故行为不变。 */
export function matchPathAllowed(targetAbs: string, entries: ReadonlyArray<string>, cwd: string): boolean {
	const target = path.normalize(targetAbs);
	for (const entry of entries) {
		if (typeof entry !== "string" || !entry.trim()) continue;
		const parsed = parseAllowedPathEntry(entry);
		if (parsed.invalid) continue; // 非法条目不参与放行（派发端已拒单；守卫端保守跳过）
		const bound = path.normalize(path.isAbsolute(parsed.value) ? parsed.value : path.resolve(cwd, parsed.value));
		if (parsed.kind === "prefix") {
			if (target === bound || target.startsWith(bound)) return true;
		} else if (parsed.kind === "glob") {
			if (globToRegExp(bound).test(target)) return true;
		} else {
			const rel = path.relative(bound, target);
			if (rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel))) return true;
		}
	}
	return false;
}

/** glob 展开为现存路径集合（派发期存在性预检复用 ev-20260908-8d5d8f 逻辑）。
 *  只返回真实存在的路径；cap 封顶防失控展开（超限截断，调用方按「有命中」语义消费）。 */
export function expandGlobPaths(pattern: string, cwd: string, cap = 512): string[] {
	const abs = path.isAbsolute(pattern) ? pattern : path.resolve(cwd, pattern);
	const parts = abs.split(path.sep).join("/").split("/");
	const out: string[] = [];
	const walk = (dirPrefix: string, idx: number): void => {
		if (out.length >= cap) return;
		if (idx >= parts.length) {
			try { if (fs.existsSync(dirPrefix)) out.push(dirPrefix); } catch { /* 不可判存在 → 不计入 */ }
			return;
		}
		const seg = parts[idx]!;
		if (seg === "") { // 根目录（绝对路径首段）或重复分隔符
			walk(idx === 0 ? "/" : dirPrefix, idx + 1);
			return;
		}
		if (!isGlobPattern(seg)) {
			walk(dirPrefix.endsWith("/") ? dirPrefix + seg : dirPrefix + "/" + seg, idx + 1);
			return;
		}
		let names: string[];
		try { names = fs.readdirSync(dirPrefix || "/"); } catch { return; }
		const segRe = new RegExp(`^${globSegmentSource(seg)}$`);
		for (const n of names) {
			if (out.length >= cap) return;
			if (segRe.test(n)) walk(dirPrefix.endsWith("/") ? dirPrefix + n : dirPrefix + "/" + n, idx + 1);
		}
	};
	walk("/", 0);
	return out;
}

/** glob 静态基目录：首个含通配符段之前的字面目录（"data/cfg/gds_*.tres" → <cwd>/data/cfg）。
 *  用于 glob 零命中时校验「任务将创建的匹配文件」的落点目录在工作区子树内。 */
export function globStaticBaseDir(pattern: string, cwd: string): string {
	const abs = path.isAbsolute(pattern) ? pattern : path.resolve(cwd, pattern);
	const parts = abs.split(path.sep).join("/").split("/");
	let cut = parts.length;
	for (let i = 0; i < parts.length; i++) {
		if (isGlobPattern(parts[i]!)) { cut = i; break; }
	}
	if (cut === 0) return "/";
	const joined = parts.slice(0, cut).join("/");
	return joined || "/";
}

/** ev-20260914-9084ee②：首拦前缀意图诊断——白名单里的无语法（plain）条目「疑似前缀短写」探测。
 *  判据：条目解析后不存在（按目录/精确文件语义不可写），但父目录存在且满足任一：
 *  ①有以条目 basename 开头的现存文件；②（ev-20260918-a7bb5b）basename 以连字符/下划线结尾——
 *  「待创建文件」的前缀短写特征（如 tests/rpc- 意图 tests/rpc-*.test.mjs：目标尚不存在，
 *  现存文件判据永远漏检，只能在首拦时靠形态启发式提示）。返回诊断文案（无嫌疑返回空串）。 */
export function whitelistPrefixIntentHint(entries: ReadonlyArray<string>, cwd: string): string {
	const suspects: string[] = [];
	for (const entry of entries) {
		if (typeof entry !== "string" || !entry.trim()) continue;
		const parsed = parseAllowedPathEntry(entry);
		if (parsed.kind !== "plain" || parsed.invalid) continue; // 只诊断无语法条目（glob/prefix 已有显式语义）
		const bound = path.isAbsolute(parsed.value) ? parsed.value : path.resolve(cwd, parsed.value);
		try { if (fs.existsSync(bound)) continue; } catch { continue; }
		const parent = path.dirname(bound);
		const base = path.basename(bound);
		if (!base) continue;
		try {
			if (!fs.statSync(parent).isDirectory()) continue;
			const names = fs.readdirSync(parent);
			if (names.some((n) => n.startsWith(base)) || /[-_]$/.test(base)) suspects.push(entry.trim());
		} catch { continue; }
		if (suspects.length >= 3) break;
	}
	if (suspects.length === 0) return "";
	const first = suspects[0]!;
	return `【前缀意图诊断】白名单条目 ${suspects.map((s) => JSON.stringify(s)).join("、")} 疑似想前缀匹配一组文件，但按「目录或精确文件」默认语义该路径不存在、写入会被持续拦截——请经报告/QUESTIONS 请 Leader 改用 glob 语法（如 ${JSON.stringify(`${first}*`)}）或显式前缀语法（如 prefix:${first}）重写白名单后 resume，不要反复重试同一目标。`;
}
