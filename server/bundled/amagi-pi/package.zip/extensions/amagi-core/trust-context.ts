/**
 * trust-context.ts — B4B 修复轮 R02（ev-20261012-af58eb §8 批B diting 审核）：统一会话项目信任源。
 *
 * 单一状态源：trustFallback 回调由 index.ts 于 session_start 捕获会话信任态注入
 * （宿主契约 isProjectTrusted 只在事件 ctx 提供，工具 execute ctx 不携带——
 * ev-20260918-2fe431 后续的既有事实）。解析优先级：ctx 直给布尔 > 会话回退 > false
 * （未捕获会话时保持旧 fail-closed 语义，不猜）。
 *
 * 本模块从 task-tool.ts 原位抽出（该处保留 re-export，既有 import 路径不变）——
 * B4·批B 修复轮起 guard-policy 判定消费（guardProjectTrustedOf）复用同一回退链，
 * 不为 guards 家族另造第二套信任判定（diting B4B-R02）。
 */

/** 会话级信任回退注入（index.ts 于 session_start 调用；传 undefined 复位，测试隔离用）。 */
let trustFallback: (() => boolean | undefined) | undefined;

export function setTrustFallback(fn: (() => boolean | undefined) | undefined): void {
	trustFallback = fn;
}

/** 工具路径统一信任解析：ctx 直给布尔优先，缺失时回退会话捕获值，均无则 false（不猜）。 */
export function resolveProjectTrusted(ctx: { isProjectTrusted?: () => boolean } | undefined): boolean {
	const direct = ctx?.isProjectTrusted?.();
	if (typeof direct === "boolean") return direct;
	return trustFallback?.() === true;
}
