/**
 * task-store.ts — amagi-pi v2 K2：TaskStore 端口的文件持久化实现 + owner 生命周期 lease。
 *
 * 存储布局（任务目录 = <root>/<sanitizeId(taskId)>；目录 0o700 / 文件 0o600）：
 *   spec-<specId>.json        不可变（tmp+fsync+link 原子建链：link 已存在即失败，杜绝覆盖竞态）
 *   receipt-<receiptId>.json  不可变（同上；同内容幂等返回同 Ref；同 ID 不同内容报错）
 *   current.json              CAS 原子替换（tmp+fsync+rename；rename 前崩溃只留 tmp、不留半成品）
 *   owner-lease.json          owner 生命周期文件锁（O_EXCL 创建，含 nonce+expiry；过期/同 owner 可抢占）
 *
 * 语义要点（方案 §3.2/§3.3/§3.5/§8.1-K2）：
 *   - saveSpec/saveReceipt/replaceCurrent 写失败抛 TaskStoreError（携带 ContractError），绝不
 *     “文件未写但返回成功”；load 一切失败以 Result 返回明确 ContractError——缺文件/坏 JSON/
 *     未知必要版本/digest 复核失败都不是伪成功（undefined 伪成功被禁止）。
 *   - replaceCurrent 的 CAS = 读 current.stateSeq 与 expectedSeq 比对 + 新 stateSeq 必须连续
 *     （= 旧值 + 1；首建必须 0）。磁盘序号 CAS 仅在单 owner 提交串行化前提下成立：本实现按
 *     taskId 进程内串行锁；跨进程 CAS 不由普通 rename 承诺（owner lease + K3 内核串行器负责，
 *     方案 §3.5 明言“不宣称普通 rename 能实现跨进程 CAS”）。
 *   - 旧 owner 的 lease 过期被抢占后，其写请求由 CAS/stateSeq（及 TaskKey.revision）栅栏拒绝；
 *     lease 本身不拦截写路径——它是 owner 生命周期声明，不是写令牌。
 *   - load 回读校验：current → validateTaskRun（版本/封闭形状/三轴）；spec → validateTaskSpec
 *     （含 specDigest 重算复核）；currentReceipt → 文件字节 sha256/bytes 复核 + validateTaskReceipt
 *     + 一致提交链（receipt.taskId/ownerId/specDigest/settlement/acceptance 与 run/spec 一致，
 *     §3.2「有 currentReceipt 时 TaskRun.acceptance/settlement 必须与其一致并一起提交」）。
 *   - Ref.path 为 root 相对路径（“/” 分隔）；Ref.digest = 文件字节（canonical JSON）的 SHA-256。
 *   - saveSpec 的 taskId 参数：TaskSpec 契约本身不携带 taskId（K1 冻结），而目录布局需要它——
 *     内核（K3）持有 taskId，调用 saveSpec(spec, taskId)；省略时显式报错而不是错放目录
 *     （load(taskId) 只认任务目录，静默错放 = 伪成功温床）。
 *   - 崩溃窗口：tmp 以 “.<base>.tmp-” 前缀隐藏命名，load 永不读取；下一次写入在任务锁内清扫
 *     同前缀残留（同任务多进程写本就被单 owner 纪律禁止，锁内清扫不误删并发写者）。
 *   - 平台：link/rename/fsync/openSync("wx") 为真实 POSIX 原语；文件 fsync 与父目录 fsync
 *     尽力而为（不支持的平台静默容忍）。跨平台 rename 原子性差异见 K2 报告“未覆盖项”。
 */

import { createHash, randomBytes } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { contractStoreRoot, sanitizeId } from "./artifact.ts";
import {
	canonicalJson,
	validateTaskReceipt,
	validateTaskRun,
	validateTaskSpec,
	type TaskReceipt,
	type TaskRun,
	type TaskSpec,
} from "./contracts/task.ts";
import {
	CONTRACT_ERROR_CODES,
	err,
	isNonEmptyString,
	isNonNegativeInt,
	isRecord,
	ok,
	type ContractError,
	type Ref,
	type Result,
} from "./contracts/view.ts";
import type { TaskStore } from "./contracts/command.ts";

/** 存储层错误码（与 contracts/view.ts 的 CONTRACT_ERROR_CODES 分属两个命名空间：契约校验错误
 *  由校验器原样透传；存储语义错误用 store-、cas-conflict、lease- 前缀）。 */
export const STORE_ERROR_CODES = {
	IO: "store-io-error",
	NOT_FOUND: "store-not-found",
	CORRUPT: "store-corrupt",
	IMMUTABLE_CONFLICT: "store-immutable-conflict",
	CAS_CONFLICT: "cas-conflict",
	REF_MISMATCH: "store-ref-mismatch",
	LEASE_HELD: "lease-held",
	LEASE_NOT_HELD: "lease-not-held",
} as const;

/** saveSpec/saveReceipt/replaceCurrent 的失败通道：抛出（端口签名不返回 Result），错误载荷是 ContractError。 */
export class TaskStoreError extends Error {
	readonly error: ContractError;
	constructor(error: ContractError) {
		super(error.message);
		this.name = "TaskStoreError";
		this.error = error;
	}
}

/** ev-20261019-06c169：完整 load 校验后的持久契约记录（listByLeaderSession 返回元素；与 load 值同形）。 */
export type StoredContract = { spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt };

// ── owner 生命周期 lease ─────────────────────────────────────────────────────

/** 已获取的 lease 凭据：nonce 是本次运行时随机身份（同 ownerId 重载后旧 nonce 立即失效）。 */
export interface OwnerLease {
	ownerId: string;
	taskId: string;
	nonce: string;
	acquiredAt: number;
	expiresAt: number;
}

/** recovery adopt 的只读 sidecar；缺失/损坏不授予采纳身份。 */
export interface TaskAdoption {
	originalOwnerId: string;
	adoptedByOwner: string;
	adoptedAt: number;
}

export function readTaskAdoption(dirAbs: string, taskId: string): TaskAdoption | undefined {
	try {
		const v: unknown = JSON.parse(fs.readFileSync(path.join(dirAbs, "adopted.json"), "utf8"));
		if (!isRecord(v) || v.formatVersion !== 1 || v.taskId !== taskId) return undefined;
		if (!isNonEmptyString(v.originalOwnerId) || !isNonEmptyString(v.adoptedByOwner) || !isNonNegativeInt(v.adoptedAt)) return undefined;
		return { originalOwnerId: v.originalOwnerId, adoptedByOwner: v.adoptedByOwner, adoptedAt: v.adoptedAt };
	} catch { return undefined; }
}

const CURRENT_FILE = "current.json";
const LEASE_FILE = "owner-lease.json";
const TMP_INFIX = ".tmp-";
const DIR_MODE = 0o700;
const FILE_MODE = 0o600;

function sha256Hex(content: string): string {
	return createHash("sha256").update(content, "utf8").digest("hex");
}

function storeError(
	code: string,
	message: string,
	fields: readonly string[] = [],
	effects: ContractError["effects"] = "none",
	repairExamples: readonly object[] = [],
): TaskStoreError {
	return new TaskStoreError({ code, message, fields, effects, repairExamples });
}

function invalidFieldError(field: string, message: string): TaskStoreError {
	return new TaskStoreError({ code: CONTRACT_ERROR_CODES.INVALID_FIELD, message, fields: [field], effects: "none", repairExamples: [] });
}

// ── FileTaskStore ────────────────────────────────────────────────────────────

export interface TaskStoreOptions {
	/** 契约存储根（测试/运维注入）；缺省 artifact.ts::contractStoreRoot()。 */
	root?: string;
}

/**
 * TaskStore 端口的文件实现（方案 §3.3 端口签名 / §3.5 磁盘纪律）。
 * saveSpec/saveReceipt/replaceCurrent 失败抛 TaskStoreError；load 返回 Result。
 */
export class FileTaskStore implements TaskStore {
	private readonly rootDir: string;
	private readonly locks = new Map<string, Promise<unknown>>();
	private rootRealCache: string | null = null;

	constructor(root?: string) {
		this.rootDir = path.resolve(root ?? contractStoreRoot());
	}

	/** 契约存储根（绝对路径；测试断言/诊断用）。 */
	get root(): string {
		return this.rootDir;
	}

	// ── TaskStore 端口：不可变写入 ────────────────────────────────────────────

	/**
	 * 保存 spec（不可变追加）。同 specId 同内容幂等返回同 Ref；同 specId 不同内容报
	 * store-immutable-conflict。taskId 为目录键（TaskSpec 契约不含 taskId，见模块头）。
	 */
	async saveSpec(spec: Readonly<TaskSpec>, taskId?: string): Promise<Ref> {
		const validated = validateTaskSpec(spec);
		if (!validated.ok) throw new TaskStoreError(validated.error);
		if (!isNonEmptyString(taskId)) {
			throw invalidFieldError(
				"taskId",
				"saveSpec 需要 taskId 定位任务目录 <root>/<taskId>/spec-<specId>.json（TaskSpec 契约不携带 taskId；省略时无法被 load(taskId) 命中，拒绝静默错放）",
			);
		}
		const dirKey = sanitizeId(taskId);
		const rel = path.join(dirKey, `spec-${sanitizeId(spec.specId)}.json`);
		return this.withLock(dirKey, () => this.writeImmutable(rel, canonicalJson(spec)));
	}

	/** 保存回执（不可变追加；TaskReceipt 自带 taskId）。同 receiptId 语义同 saveSpec。 */
	async saveReceipt(receipt: Readonly<TaskReceipt>): Promise<Ref> {
		const validated = validateTaskReceipt(receipt);
		if (!validated.ok) throw new TaskStoreError(validated.error);
		const dirKey = sanitizeId(receipt.taskId);
		const rel = path.join(dirKey, `receipt-${sanitizeId(receipt.receiptId)}.json`);
		return this.withLock(dirKey, () => this.writeImmutable(rel, canonicalJson(receipt)));
	}

	// ── TaskStore 端口：current 的 CAS 原子替换 ──────────────────────────────

	/**
	 * 原子替换 current.json。
	 * CAS：expectedSeq=null 仅限首建（run.stateSeq 必须 0）；否则 expectedSeq 必须等于磁盘
	 * current.stateSeq 且新 run.stateSeq = expectedSeq + 1（stateSeq 连续，N2）。不匹配抛
	 * cas-conflict（fields 含 "stateSeq"），current 不被改动。
	 */
	async replaceCurrent(expectedSeq: number | null, run: Readonly<TaskRun>): Promise<void> {
		const validated = validateTaskRun(run);
		if (!validated.ok) throw new TaskStoreError(validated.error);
		if (expectedSeq !== null && !isNonNegativeInt(expectedSeq)) {
			throw invalidFieldError("expectedSeq", `expectedSeq 必须是非负整数或 null（首建），收到 ${JSON.stringify(expectedSeq)}`);
		}
		const dirKey = sanitizeId(run.taskId);
		return this.withLock(dirKey, () => {
			const dir = this.taskDirOf(dirKey);
			const currentPath = path.join(dir, CURRENT_FILE);
			this.ensureDir(dir);
			const existing = this.readIfPresent(currentPath);
			let actualSeq: number | null = null;
			if (existing !== null) {
				const parsed = this.parseJsonOrThrow(existing, currentPath);
				if (!isRecord(parsed) || !isNonNegativeInt(parsed.stateSeq)) {
					throw storeError(
						STORE_ERROR_CODES.CORRUPT,
						`current.json 缺有效 stateSeq（${currentPath}）——按待对账处理，不伪成功`,
						[CURRENT_FILE, "stateSeq"],
						"none",
						[{ hint: "恢复路径走 K8 对账：校验/修复或人工接管后重建 current，不回退猜测旧值" }],
					);
				}
				actualSeq = parsed.stateSeq;
			}
			if (expectedSeq === null && existing !== null) {
				throw this.casError(null, actualSeq, "current 已存在，首建 CAS（expectedSeq=null）与现状冲突");
			}
			if (expectedSeq !== null && existing === null) {
				throw this.casError(expectedSeq, null, "current 不存在，首建须传 expectedSeq=null");
			}
			if (expectedSeq !== null && actualSeq !== expectedSeq) {
				throw this.casError(expectedSeq, actualSeq, "expectedSeq 与磁盘 current.stateSeq 不匹配");
			}
			const requiredSeq = (actualSeq ?? -1) + 1;
			if (run.stateSeq !== requiredSeq) {
				throw this.casError(expectedSeq, actualSeq, `run.stateSeq=${run.stateSeq} 不连续（须为 current.stateSeq+1=${requiredSeq}）`);
			}
			this.writeAtomicReplace(currentPath, canonicalJson(run));
		});
	}

	// ── TaskStore 端口：回读校验 ─────────────────────────────────────────────

	/** 回读 {spec, run, receipt?}：digest 复核、版本校验（未知必要版本拒绝）、坏 JSON/缺文件
	 *  → 明确 ContractError；有 currentReceipt 时校验一致提交链（§3.2）。 */
	async load(taskId: string): Promise<Result<{ spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt }>> {
		return this.attempt(() => {
			if (!isNonEmptyString(taskId)) throw invalidFieldError("taskId", "load 需要 taskId（非空字符串）");
			const dirKey = sanitizeId(taskId);
			const dir = this.taskDirOf(dirKey);
			const currentPath = path.join(dir, CURRENT_FILE);
			const currentRaw = this.readRequired(currentPath);
			const runValidated = validateTaskRun(this.parseJsonOrThrow(currentRaw, currentPath));
			if (!runValidated.ok) throw new TaskStoreError(runValidated.error);
			const run = runValidated.value;
			if (run.taskId !== taskId) {
				throw storeError(
					STORE_ERROR_CODES.CORRUPT,
					`目录 ${dirKey}/current.json 指向 taskId=${run.taskId}，与请求 ${taskId} 不一致（sanitizeId 碰撞或目录被外部改动）`,
					[CURRENT_FILE, "taskId"],
				);
			}
			const specPath = path.join(dir, `spec-${sanitizeId(run.specId)}.json`);
			const specValidated = validateTaskSpec(this.parseJsonOrThrow(this.readRequired(specPath), specPath));
			if (!specValidated.ok) throw new TaskStoreError(specValidated.error);
			const spec = specValidated.value;
			let receipt: TaskReceipt | undefined;
			if (run.currentReceipt) {
				const ref = run.currentReceipt;
				const abs = this.resolveConfined(ref.path);
				const receiptRaw = this.readRequired(abs);
				if (sha256Hex(receiptRaw) !== ref.digest || Buffer.byteLength(receiptRaw, "utf8") !== ref.bytes) {
					throw storeError(
						STORE_ERROR_CODES.REF_MISMATCH,
						`回执文件内容与 currentReceipt Ref 不一致（digest/bytes 复核失败）：${ref.path}`,
						["run.currentReceipt.digest", "run.currentReceipt.bytes"],
						"none",
						[{ hint: "current 引用的回执被外部篡改或错配；走对账确认后再决定是否重建指针" }],
					);
				}
				const receiptValidated = validateTaskReceipt(this.parseJsonOrThrow(receiptRaw, abs));
				if (!receiptValidated.ok) throw new TaskStoreError(receiptValidated.error);
				receipt = receiptValidated.value;
				if (receipt.taskId !== run.taskId || receipt.ownerId !== run.ownerId) {
					throw storeError(
						STORE_ERROR_CODES.REF_MISMATCH,
						"回执 TaskKey 与 run 不一致（taskId/ownerId 错配）",
						["run.currentReceipt", "taskId", "ownerId"],
					);
				}
				if (receipt.specDigest !== spec.specDigest) {
					throw storeError(
						STORE_ERROR_CODES.REF_MISMATCH,
						"回执 specDigest 与 spec.specDigest 不一致（交付版本链断裂）",
						["run.currentReceipt", "spec.specDigest"],
					);
				}
				if (receipt.settlement !== run.settlement || receipt.acceptance !== run.acceptance) {
					throw storeError(
						STORE_ERROR_CODES.REF_MISMATCH,
						`run.settlement/acceptance(${run.settlement}/${run.acceptance}) 与回执(${receipt.settlement}/${receipt.acceptance}) 不一致——有 currentReceipt 时必须一致并一起提交`,
						["run.settlement", "run.acceptance", "run.currentReceipt"],
						"none",
						[{ hint: "重读 current 与回执后以内核命令重试提交，勿单独改写一侧" }],
					);
				}
			}
			return { spec, run, ...(receipt ? { receipt } : {}) };
		});
	}

	/** 只在 load 明确 not-found 且任务目录确实无记录时返回 null。缺必要文件、失效链接、
	 *  IO/校验错误仍原样返回；调用方不能用 undefined/existsSync 猜测历史来源。 */
	async loadIfPresent(taskId: string): Promise<Result<{ spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt } | null>> {
		const loaded = await this.load(taskId);
		if (loaded.ok || loaded.error.code !== STORE_ERROR_CODES.NOT_FOUND) return loaded;
		return this.attempt(() => {
			try {
				fs.lstatSync(this.taskDirOf(taskId));
			} catch (e) {
				if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
				// 失效根链接不能冒充任务缺席；权限/非目录等异常也必须透出。
				let root: fs.Stats;
				try { root = fs.lstatSync(this.rootDir); }
				catch (rootError) {
					if ((rootError as NodeJS.ErrnoException).code === "ENOENT") return null;
					throw rootError;
				}
				if (root.isSymbolicLink()) fs.statSync(this.rootDir); // ENOENT 此时是根损坏，由 attempt 报 IO 错误。
				return null;
			}
			throw new TaskStoreError(loaded.error); // 目录仍在：缺 current/spec 不等于无记录。
		});
	}

	/** 明确 ID 的短前缀回退：只枚举任务目录，不把 session/name/路径当持久身份。 */
	findTaskIdsByPrefix(prefix: string): Result<readonly string[]> {
		return this.attempt(() => {
			if (!/^[A-Za-z0-9_-]{8,64}$/.test(prefix)) return [];
			try {
				return fs.readdirSync(this.rootDir, { withFileTypes: true })
					.filter((d) => d.isDirectory() && d.name.startsWith(prefix))
					.map((d) => d.name).sort();
			} catch (e) {
				if ((e as NodeJS.ErrnoException).code === "ENOENT") return [];
				throw e;
			}
		});
	}

	// ── ev-20261019-06c169：只读会话契约枚举（task_query 列表真实恢复） ───────────

	/** 枚举当前会话盖章（spec.leaderSession === sessionKey）的持久契约并完整 load（复用全部回读校验：
	 *  digest 复核/版本/一致提交链——不绕过）。只读：不写任何文件、不修复磁盘。
	 *  错误策略（保守）：目录枚举失败（非 ENOENT 空根）、无法确定会话归属的坏 spec/current、
	 *  本会话匹配记录完整 load 失败 → Result 错误（调用方不得伪装成空列表）；明确他会话盖章的
	 *  可读记录跳过（其坏 current 不阻断本会话列表）。 */
	async listByLeaderSession(sessionKey: string): Promise<Result<readonly StoredContract[]>> {
		const probe = this.attempt(() => {
			if (!isNonEmptyString(sessionKey)) throw invalidFieldError("sessionKey", "listByLeaderSession 需要非空会话键（派发时盖章；不扫描全库猜当前会话）");
			let entries: fs.Dirent[];
			try {
				entries = fs.readdirSync(this.rootDir, { withFileTypes: true });
			} catch (e) {
				if ((e as NodeJS.ErrnoException).code === "ENOENT") return null; // 存储根确实不存在 → 空集合（失效 symlink/权限错误照实抛）
				throw e;
			}
			const candidates: string[] = [];
			for (const ent of entries) {
				if (!ent.isDirectory() || ent.isSymbolicLink()) continue;
				const dir = path.join(this.rootDir, ent.name);
				// 归属判定：current.json 的 specId 定位 spec；缺 current/坏 current 时回退目录内唯一 spec-*.json
				let specPath: string | undefined;
				const currentRaw = this.readIfPresent(path.join(dir, CURRENT_FILE));
				if (currentRaw !== null) {
					let parsed: unknown;
					try { parsed = JSON.parse(currentRaw); } catch { /* lint-exempt:坏 current 归属判定回退目录内 spec 文件定位（保守） */ parsed = null; }
					const specId = (parsed as { specId?: unknown } | null)?.specId;
					if (isNonEmptyString(specId)) specPath = path.join(dir, `spec-${sanitizeId(specId)}.json`);
				}
				if (specPath === undefined) {
					const specFiles = fs.readdirSync(dir).filter((f) => f.startsWith("spec-") && f.endsWith(".json"));
					if (specFiles.length === 0) continue; // 无任何契约文件：空目录/残留 tmp——非记录
					if (specFiles.length > 1) {
						throw storeError(STORE_ERROR_CODES.CORRUPT, `任务目录 ${ent.name} 有多个 spec 文件且无法从 current.json 定位——会话归属不明，按待对账处理不猜`, [ent.name]);
					}
					specPath = path.join(dir, specFiles[0]!);
				}
				const specRaw = this.readIfPresent(specPath);
				if (specRaw === null) {
					throw storeError(STORE_ERROR_CODES.NOT_FOUND, `任务目录 ${ent.name} 的 spec 不可读（${path.basename(specPath)}）——会话归属不明，不能并入本会话列表也不能当空集`, [ent.name]);
				}
				const specValidated = validateTaskSpec(this.parseJsonOrThrow(specRaw, specPath));
				if (!specValidated.ok) throw new TaskStoreError(specValidated.error);
				if (specValidated.value.leaderSession !== sessionKey) continue; // 明确他会话/无盖章：不列入（坏 current 不阻断本会话列表）
				candidates.push(ent.name);
			}
			return candidates;
		});
		if (!probe.ok) return probe;
		if (probe.value === null) return ok([]);
		const out: StoredContract[] = [];
		for (const taskId of probe.value) {
			const loaded = await this.load(taskId); // 本会话匹配记录：完整 load 失败照实返回（不伪装空列表）
			if (!loaded.ok) return loaded;
			out.push(loaded.value);
		}
		return ok(out);
	}

	hasOwnerAdoption(taskId: string, originalOwnerId: string, ownerId: string): boolean {
		const note = readTaskAdoption(this.taskDirOf(taskId), taskId);
		return note?.originalOwnerId === originalOwnerId && note.adoptedByOwner === ownerId;
	}

	// ── owner 生命周期 lease（同步 fs 原语；Result 返回） ────────────────────

	/**
	 * 获取 owner lease（文件锁）：O_EXCL 原子创建；已存在时——过期（now >= expiresAt）、
	 * 同 ownerId（运行时重载换新 nonce）或文件损坏（crash 残留）可抢占；未过期的他 owner
	 * 持有则拒绝（lease-held）。lease 不拦截写路径；旧 owner 的写由 CAS/stateSeq 栅栏拒绝。
	 */
	acquireOwnerLease(ownerId: string, taskId: string, ttlMs: number): Result<OwnerLease> {
		return this.attempt(() => {
			this.validateLeaseArgs(ownerId, taskId, ttlMs);
			const dir = this.taskDirOf(taskId);
			const leasePath = path.join(dir, LEASE_FILE);
			this.ensureDir(dir);
			const now = Date.now();
			const lease: OwnerLease = { ownerId, taskId, nonce: randomBytes(16).toString("hex"), acquiredAt: now, expiresAt: now + ttlMs };
			try {
				this.writeExclusive(leasePath, canonicalJson(lease) + "\n");
				return lease;
			} catch (e) {
				if ((e as NodeJS.ErrnoException).code !== "EEXIST") throw e;
			}
			const current = this.readLeaseState(leasePath);
			if (current.kind === "held" && current.ownerId !== ownerId && Date.now() < current.expiresAt) {
				throw storeError(
					STORE_ERROR_CODES.LEASE_HELD,
					`owner lease 被 ${current.ownerId} 持有且未过期（${new Date(current.expiresAt).toISOString()} 到期）；TTL 过期或同 ownerId 才可抢占`,
					["ownerId", taskId],
					"none",
					[{ hint: "等待到期、或确认旧 owner 已退出/人工交接后重试抢占" }],
				);
			}
			// 过期 / 同 owner 重载 / crash 残留：原子替换抢占（旧 nonce 立即失效）
			this.writeAtomicReplace(leasePath, canonicalJson(lease) + "\n");
			return lease;
		});
	}

	/** 续租：仅持有者（ownerId+nonce 匹配且未过期）可续；返回新 expiresAt 的 lease。 */
	renewOwnerLease(lease: OwnerLease, ttlMs: number): Result<OwnerLease> {
		return this.attempt(() => {
			this.validateLeaseArgs(lease.ownerId, lease.taskId, ttlMs);
			const leasePath = path.join(this.taskDirOf(lease.taskId), LEASE_FILE);
			const current = this.readLeaseState(leasePath);
			if (current.kind === "missing") {
				throw storeError(STORE_ERROR_CODES.LEASE_NOT_HELD, "lease 不存在（已释放或从未获取），无法续租", ["lease"], "none", [{ hint: "重新 acquireOwnerLease" }]);
			}
			if (current.kind === "stale") {
				throw storeError(STORE_ERROR_CODES.LEASE_NOT_HELD, "lease 文件损坏（crash 残留），无法续租——重新抢占", ["lease"], "none", [{ hint: "acquireOwnerLease 可抢占 stale lease" }]);
			}
			if (current.ownerId !== lease.ownerId || current.nonce !== lease.nonce) {
				throw storeError(STORE_ERROR_CODES.LEASE_NOT_HELD, "lease 已被抢占或 nonce 失效（ownerId/nonce 不匹配），无法续租", ["lease.nonce"], "none", [{ hint: "同 owner 重载会换新 nonce；用最新 lease 凭据重试" }]);
			}
			if (Date.now() >= current.expiresAt) {
				throw storeError(STORE_ERROR_CODES.LEASE_NOT_HELD, `lease 已过期（${new Date(current.expiresAt).toISOString()}），无法续租——重新抢占`, ["lease.expiresAt"]);
			}
			const renewed: OwnerLease = { ...lease, expiresAt: Date.now() + ttlMs };
			this.writeAtomicReplace(leasePath, canonicalJson(renewed) + "\n");
			return renewed;
		});
	}

	/** 释放：持有者删除 lease 文件；文件已不存在时幂等成功；他人持有（nonce 不匹配）拒绝。 */
	releaseOwnerLease(lease: OwnerLease): Result<true> {
		return this.attempt(() => {
			const leasePath = path.join(this.taskDirOf(lease.taskId), LEASE_FILE);
			const current = this.readLeaseState(leasePath);
			if (current.kind === "missing") return true; // 幂等：已释放/从未获取
			if (current.kind === "held" && (current.ownerId !== lease.ownerId || current.nonce !== lease.nonce)) {
				throw storeError(
					STORE_ERROR_CODES.LEASE_NOT_HELD,
					"lease 由其他运行时持有（ownerId/nonce 不匹配），拒绝释放他人 lease",
					["lease.nonce"],
				);
			}
			try {
				fs.rmSync(leasePath, { force: true });
			} catch (e) {
				throw this.ioError(`释放 lease 失败（${leasePath}）`, [LEASE_FILE], e);
			}
			return true;
		});
	}

	// ── 内部：写入原语 ───────────────────────────────────────────────────────

	private taskDirOf(taskId: string): string {
		return path.join(this.rootDir, sanitizeId(taskId));
	}

	/** 进程内按 taskId 串行写（K3 内核串行器之前的模块级保障；跨进程由 owner 纪律约束）。 */
	private withLock<T>(key: string, fn: () => T): Promise<T> {
		const previous = this.locks.get(key) ?? Promise.resolve();
		const next = previous.then(fn, fn);
		this.locks.set(key, next.then(() => undefined, () => undefined));
		return next;
	}

	private ensureDir(dir: string): void {
		try {
			fs.mkdirSync(dir, { recursive: true, mode: DIR_MODE });
		} catch (e) {
			throw this.ioError(`创建目录失败（${dir}）`, [dir], e);
		}
	}

	/** 同目录 tmp（隐藏名）写入 + fsync；返回 tmp 绝对路径。失败时 tmp 由调用方清理。
	 *  fs 错误统一包装为 store-io-error（效果未知）——原始 EACCES/ENOSPC 等绝不裸抛伪成功。 */
	private writeTmp(dir: string, base: string, content: string): string {
		const tmp = path.join(dir, `.${base}${TMP_INFIX}${process.pid}-${randomBytes(6).toString("hex")}`);
		let fd: number | undefined;
		try {
			fd = fs.openSync(tmp, "wx", FILE_MODE);
			fs.writeFileSync(fd, content, "utf8");
			try {
				fs.fsyncSync(fd);
			} catch { /* 平台差异：fsync 不可用容忍（rename 原子性仍成立） */ }
		} catch (e) {
			if (fd !== undefined) {
				try { fs.closeSync(fd); } catch { /* 关闭失败不掩盖写失败 */ }
			}
			try { fs.rmSync(tmp, { force: true }); } catch { /* best-effort */ }
			throw this.ioError(`临时文件写入失败（${tmp}）`, [tmp], e);
		}
		try { fs.closeSync(fd); } catch { /* 关闭失败不掩盖写失败 */ }
		return tmp;
	}

	/** 原子替换（current/lease 抢占）：tmp+fsync+rename——rename 前崩溃只留 tmp，目标文件保持旧值。 */
	private writeAtomicReplace(abs: string, content: string): void {
		const dir = path.dirname(abs);
		const base = path.basename(abs);
		this.sweepStaleTemps(dir, base);
		const tmp = this.writeTmp(dir, base, content);
		try {
			fs.renameSync(tmp, abs);
		} catch (e) {
			throw this.ioError(`原子替换失败（${abs}，目标文件未被改动）`, [abs], e);
		} finally {
			try { fs.rmSync(tmp, { force: true }); } catch { /* best-effort */ }
		}
		this.fsyncDir(dir);
	}

	/** 不可变建链：tmp+fsync+link（已存在即 EEXIST，杜绝 rename 覆盖竞态）；同内容幂等同 Ref。 */
	private writeImmutable(rel: string, canonical: string): Ref {
		const abs = path.join(this.rootDir, rel);
		const dir = path.dirname(abs);
		const base = path.basename(abs);
		this.ensureDir(dir);
		const existing = this.readIfPresent(abs);
		if (existing !== null) {
			if (this.sameCanonicalContent(existing, canonical)) return this.refFor(rel, canonical);
			throw storeError(
				STORE_ERROR_CODES.IMMUTABLE_CONFLICT,
				`${rel} 已存在且内容不同——不可变文件禁止改写（spec/receipt 每版只写一次）`,
				[rel],
				"none",
				[{ hint: "新内容使用新 specId/receiptId 写新版本；勿复用旧 ID 改写" }],
			);
		}
		this.sweepStaleTemps(dir, base);
		const tmp = this.writeTmp(dir, base, canonical);
		try {
			fs.linkSync(tmp, abs); // 原子 create-or-fail：目标存在即 EEXIST，绝不覆盖
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "EEXIST") {
				const raced = this.readIfPresent(abs);
				if (raced !== null && this.sameCanonicalContent(raced, canonical)) return this.refFor(rel, canonical);
				throw storeError(
					STORE_ERROR_CODES.IMMUTABLE_CONFLICT,
					`${rel} 已被并发创建且内容不同（不可变冲突）`,
					[rel],
					"none",
					[{ hint: "重读现有文件确认版本链后用新 ID 写入" }],
				);
			}
			throw this.ioError(`不可变写入失败（${rel}，目标文件未被创建）`, [rel], e);
		} finally {
			try { fs.rmSync(tmp, { force: true }); } catch { /* best-effort */ }
		}
		this.fsyncDir(dir);
		return this.refFor(rel, canonical);
	}

	/** O_EXCL 创建（lease 首获）：存在即 EEXIST；crash 在创建与写之间会留损坏文件（可抢占）。 */
	private writeExclusive(abs: string, content: string): void {
		let fd: number | undefined;
		try {
			fd = fs.openSync(abs, "wx", FILE_MODE);
			fs.writeFileSync(fd, content, "utf8");
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "EEXIST") throw e; // EEXIST 由抢占判定消费
			throw this.ioError(`独占创建失败（${abs}）`, [abs], e);
		} finally {
			if (fd !== undefined) {
				try { fs.closeSync(fd); } catch { /* 关闭失败不掩盖写失败 */ }
			}
		}
	}

	private refFor(rel: string, content: string): Ref {
		return { path: rel.split(path.sep).join("/"), digest: sha256Hex(content), bytes: Buffer.byteLength(content, "utf8") };
	}

	/** 内容等价判定：按 canonical JSON 比对（键序漂移的同语义文件视为同内容）。 */
	private sameCanonicalContent(existing: string, canonical: string): boolean {
		try {
			return canonicalJson(JSON.parse(existing)) === canonical;
		} catch {
			return false;
		}
	}

	private sweepStaleTemps(dir: string, base: string): void {
		const prefix = `.${base}${TMP_INFIX}`;
		try {
			for (const name of fs.readdirSync(dir)) {
				if (!name.startsWith(prefix)) continue;
				try { fs.rmSync(path.join(dir, name), { force: true }); } catch { /* best-effort */ }
			}
		} catch { /* 目录不可读时由后续写入/读取错误显式暴露 */ }
	}

	private fsyncDir(dir: string): void {
		try {
			const fd = fs.openSync(dir, "r");
			try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
		} catch { /* 平台不支持目录 fsync（如 Windows）容忍 */ }
	}

	// ── 内部：读取与校验 ─────────────────────────────────────────────────────

	private readIfPresent(abs: string): string | null {
		try {
			return fs.readFileSync(abs, "utf8");
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "ENOENT") return null;
			throw this.ioError(`读取失败（${abs}）`, [abs], e);
		}
	}

	private readRequired(abs: string): string {
		try {
			return fs.readFileSync(abs, "utf8");
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "ENOENT") {
				throw storeError(
					STORE_ERROR_CODES.NOT_FOUND,
					`必要文件缺失：${abs}`,
					[this.relOf(abs)],
					"none",
					[{ hint: "任务未注册或存储被外部改动；恢复走 K8 对账，不回退猜测旧值" }],
				);
			}
			throw this.ioError(`读取失败（${abs}）`, [abs], e);
		}
	}

	private parseJsonOrThrow(raw: string, abs: string): unknown {
		try {
			return JSON.parse(raw);
		} catch (e) {
			throw storeError(
				STORE_ERROR_CODES.CORRUPT,
				`文件不是合法 JSON：${abs}`,
				[this.relOf(abs)],
				"none",
				[{ hint: "半成品/被篡改文件按待对账处理，不伪成功" }],
			);
		}
	}

	/** Ref.path 解析并圈禁在契约根内（防目录穿越；Ref 来自磁盘，不可信）。
	 *  macOS /var → /private/var 等 symlink 前缀差异：词法路径重定向到 realpath 根下再比对。 */
	private resolveConfined(relPath: string): string {
		const lexical = path.resolve(this.rootDir, relPath);
		const rootAbs = this.rootRealPath();
		const abs = path.resolve(rootAbs, path.relative(this.rootDir, lexical));
		if (abs !== rootAbs && !abs.startsWith(rootAbs + path.sep)) {
			throw storeError(
				STORE_ERROR_CODES.REF_MISMATCH,
				`Ref 路径越出契约存储根：${relPath}`,
				["run.currentReceipt.path"],
				"none",
				[{ hint: "current 被外部篡改；走对账修复指针" }],
			);
		}
		return abs;
	}

	private rootRealPath(): string {
		if (this.rootRealCache === null) {
			try {
				this.rootRealCache = fs.realpathSync(this.rootDir);
			} catch {
				this.rootRealCache = this.rootDir; // 根尚未创建时退化为词法路径
			}
		}
		return this.rootRealCache;
	}

	private relOf(abs: string): string {
		return path.relative(this.rootDir, abs) || path.basename(abs);
	}

	private casError(expected: number | null, actual: number | null, detail: string): TaskStoreError {
		return storeError(
			STORE_ERROR_CODES.CAS_CONFLICT,
			`CAS 拒绝：${detail}（expectedSeq=${JSON.stringify(expected)}，current.stateSeq=${JSON.stringify(actual)}）`,
			["stateSeq"],
			"none",
			[{ hint: "load(taskId) 重读 current 后按最新 stateSeq 重试；新 stateSeq 必须连续（= 旧值+1，首建为 0）" }],
		);
	}

	private ioError(message: string, fields: readonly string[], cause: unknown): TaskStoreError {
		const code = (cause as NodeJS.ErrnoException)?.code;
		return storeError(
			STORE_ERROR_CODES.IO,
			`${message}${code ? `（${code}）` : `：${String(cause)}`}`,
			fields,
			"unknown", // 写路径 IO 失败：副作用状态不可确认（tmp 可能残留，目标文件未被原子替换）
			[{ hint: "检查磁盘/权限后重试；绝不能把未写当成已写" }],
		);
	}

	// ── 内部：lease 辅助 ─────────────────────────────────────────────────────

	private validateLeaseArgs(ownerId: string, taskId: string, ttlMs: number): void {
		if (!isNonEmptyString(ownerId)) throw invalidFieldError("ownerId", "ownerId 必须是非空字符串（稳定 Leader 逻辑身份）");
		if (!isNonEmptyString(taskId)) throw invalidFieldError("taskId", "taskId 必须是非空字符串");
		if (!isNonNegativeInt(ttlMs)) throw invalidFieldError("ttlMs", `ttlMs 必须是非负整数毫秒，收到 ${JSON.stringify(ttlMs)}`);
	}

	private readLeaseState(leasePath: string):
		| { kind: "missing" }
		| { kind: "stale" }
		| { kind: "held"; ownerId: string; nonce: string; expiresAt: number } {
		const raw = this.readIfPresent(leasePath);
		if (raw === null) return { kind: "missing" };
		try {
			const parsed = JSON.parse(raw) as Record<string, unknown>;
			if (!isNonEmptyString(parsed.ownerId) || !isNonEmptyString(parsed.nonce) || !isNonNegativeInt(parsed.expiresAt)) {
				return { kind: "stale" }; // 形状损坏（crash 半写）→ 可抢占，不阻塞新 owner
			}
			return { kind: "held", ownerId: parsed.ownerId, nonce: parsed.nonce, expiresAt: parsed.expiresAt };
		} catch {
			return { kind: "stale" };
		}
	}

	/** 同步函数 → Result（TaskStoreError 透传其 ContractError；未知异常归一为 store-io-error）。 */
	private attempt<T>(fn: () => T): Result<T> {
		try {
			return ok(fn());
		} catch (e) {
			if (e instanceof TaskStoreError) return err(e.error.code, e.error.message, e.error.fields, e.error.effects, e.error.repairExamples);
			const wrapped = this.ioError("存储操作意外失败", [], e);
			return err(wrapped.error.code, wrapped.error.message, wrapped.error.fields, wrapped.error.effects, wrapped.error.repairExamples);
		}
	}
}

/** 创建 TaskStore 文件实现；root 缺省 artifact.ts::contractStoreRoot()（AMAGI_CONTRACT_ROOT 注入）。 */
export function createTaskStore(opts?: TaskStoreOptions): FileTaskStore {
	return new FileTaskStore(opts?.root);
}
