/**
 * ui-shared.ts — TUI 共享工具层（面板与交互优化 M1-01）。
 *
 * 职责（全部纯函数，零 pi 依赖，可独立测试）：
 *   - fmtKey：KeyId → mac 按键符号（视觉风格 §6 冻结契约：⌥W / ⌃R / ⇧⌃W / ⏎ / Esc；⌘ 不用于终端键位）
 *   - KEY_HINTS：面板/看板/review 三入口的标准提示行（消费 fmtKey，禁止散落手写按键字符串）
 *   - boxBlock：带边框分块渲染（─ 标题 ─ 风格；borderMuted 线 + toolTitle 标题，视觉风格 §4 R-Width）
 *   - budget：行预算分配算法（视觉风格 §4 R-Density / R-Overflow）
 *   - trimDisplay/cellWidth/formatDuration：终端显示单元工具（自 status-ui v1.5.182 迁出共享；
 *     CJK 全角=2 格、ANSI SGR 不占格不切断，截断自动补 reset——保持原实现语义，status-ui re-export 兼容）
 *
 * 上游：视觉交互/面板与交互优化-视觉风格.md@v1.0 §4-§6
 */

/** 终态/在途符号与语义色（视觉风格 §5、§7；与 workflow-board SETTLED_STYLE 对齐）。 */
export const STATUS_STYLE: Record<string, { label: string; color: string; symbol: string }> = {
	running: { label: "running", color: "accent", symbol: "▶" },
	queued: { label: "queued", color: "muted", symbol: "…" },
	answering: { label: "answering", color: "accent", symbol: "▶" },
	done: { label: "done", color: "success", symbol: "✓" },
	answered: { label: "answered", color: "success", symbol: "✓" },
	error: { label: "error", color: "error", symbol: "✗" },
	cancelled: { label: "cancelled", color: "muted", symbol: "⊘" },
	blocked: { label: "blocked", color: "warning", symbol: "⏸" },
	// ev-20260908-f189e7：外部处置终态（与 cancelled 的 ⊘ 区分——非放弃，产物已在外部采用）
	"resolved-external": { label: "外部处置", color: "success", symbol: "✅" },
};

/** 主题面（结构子集）：fg(color, text) 返回着色文本。 */
export type ThemeLike = { fg?(color: string, text: string): string } | undefined;

/** paint：theme 可选着色（缺省纯文本；失败回退原文——渲染路径绝不抛错）。 */
export function paint(theme: ThemeLike, color: string, text: string): string {
	try { return theme?.fg ? theme.fg(color, text) : text; } catch { return text; }
}

// ── mac 按键符号（视觉风格 §6 冻结表） ─────────────────────────────────────

/**
 * fmtKey：pi KeyId → mac 显示符号。
 *   "alt+w"→"⌥W"；"ctrl+shift+w"→"⇧⌃W"（shift 前置）；"enter"/"return"→"⏎"；
 *   "escape"/"esc"→"Esc"；"up/down/left/right"→"↑↓←→"；字母键大写；其余原样小写。
 * 未知组合保守回退：按 "+" 拆分逐段映射拼接。
 */
export function fmtKey(keyId: string): string {
	const id = String(keyId).trim().toLowerCase();
	if (!id) return "";
	const MOD_SYMBOL: Record<string, string> = { shift: "⇧", ctrl: "⌃", alt: "⌥", super: "⌘" };
	const SPECIAL: Record<string, string> = { enter: "⏎", return: "⏎", escape: "Esc", esc: "Esc", tab: "⇥", space: "Space", backspace: "⌫", delete: "Del", up: "↑", down: "↓", left: "←", right: "→", pageup: "PgUp", pagedown: "PgDn", home: "Home", end: "End" };
	const parts = id.split("+");
	if (parts.length === 1) {
		const k = parts[0];
		if (SPECIAL[k]) return SPECIAL[k];
		if (/^[a-z]$/.test(k)) return k.toUpperCase();
		return k;
	}
	let out = "";
	let base = "";
	for (const p of parts) {
		if (MOD_SYMBOL[p]) out += MOD_SYMBOL[p];
		else base = p;
	}
	// mac 惯例修饰符顺序：⇧ 最前、⌃⍥、⌘ 最后（视觉风格 §6 冻结）
	out = ["⇧", "⌃", "⌥", "⌘"].filter((s) => out.includes(s)).join("");
	if (!base) return out;
	if (SPECIAL[base]) return out + SPECIAL[base];
	if (/^[a-z]$/.test(base)) return out + base.toUpperCase();
	return out + base;
}

/** 入口动作名 → 默认键（与 shortcuts.ts DEFAULTS 单一事实同步由 shortcuts 消费方维护）。 */
export type UiEntry = "board" | "tasks" | "review";

/** 标准提示行片段（常驻面板/看板底栏共用；boardCommand 提供文本命令等价物，R4 契约）。 */
export function entryHint(entry: UiEntry, keyIds: string[]): string {
	const keys = keyIds.map(fmtKey).join("/");
	const CMD: Record<UiEntry, string> = { board: "/amagi board", tasks: "/amagi tasks", review: "/amagi review" };
	// v1.5.218-f3：board 入口名 "编排实况"（主上反馈："看板"两字看不出功能）
	const NAME: Record<UiEntry, string> = { board: "实况", tasks: "任务", review: "审 diff" };
	return keys ? `${keys} ${NAME[entry]}（或 ${CMD[entry]}）` : `${NAME[entry]}：${CMD[entry]}`;
}

// ── 分块渲染（视觉风格 §4） ────────────────────────────────────────────────

/** boxBlock：带边框标题的分块。lines 需已按 width 截断；title 空则渲染纯分隔线行。 */
export function boxBlock(opts: { title: string; width: number; lines: string[]; theme?: ThemeLike }): string[] {
	const { title, width, lines, theme } = opts;
	const w = Math.max(4, Math.floor(width));
	const top = (() => {
		const t = title ? `─ ${title} ` : "─";
		const fill = Math.max(0, w - 2 - cellWidthOf(t));
		return paint(theme, "borderMuted", "┌" + t + "─".repeat(fill) + "┐");
	})();
	const body = lines.map((ln) => paint(theme, "borderMuted", "│") + ln + padOrNone(ln, w - 2) + paint(theme, "borderMuted", "│"));
	const bottom = paint(theme, "borderMuted", "└" + "─".repeat(Math.max(0, w - 2)) + "┘");
	return [top, ...body, bottom];

	function padOrNone(ln: string, inner: number): string {
		const used = cellWidthOf(ln);
		return used >= inner ? "" : " ".repeat(inner - used);
	}
}

/** 无边框分隔行（轻量分节）：─ 标题 ─… */
export function sectionLine(title: string, width: number, theme?: ThemeLike): string {
	const t = title ? `─ ${title} ` : "─";
	const fill = Math.max(0, Math.floor(width) - cellWidthOf(t));
	return paint(theme, "borderMuted", t + "─".repeat(fill));
}

// ── 行预算（视觉风格 §4 R-Density / R-Overflow） ───────────────────────────

export interface BudgetSection {
	/** 本块期望行数（内容行，不含框行）。 */
	lines: string[];
	/** 权重（小者先保）；同权重按顺序。 */
	weight: number;
	/** 硬上限。 */
	max: number;
}

/**
 * budget：总行预算内按 weight 升序分配（weight 小优先保住期望行数，剩余行给后续块）。
 * 返回各块实际行数；被截断块由调用方追加 "…还有 k 项" 提示行（计入该块行数）。
 */
export function budget(sections: BudgetSection[], total: number): number[] {
	const n = sections.length;
	const caps = sections.map((s) => Math.max(0, Math.min(s.max, s.lines.length)));
	const want = sections.map((s) => Math.max(0, Math.min(s.max, s.lines.length)));
	const alloc = new Array<number>(n).fill(0);
	let rest = Math.max(0, Math.floor(total));
	// 第一轮：按 weight 升序尽量满足 want
	const order = sections.map((s, i) => i).sort((a, b) => sections[a].weight - sections[b].weight || a - b);
	for (const i of order) {
		const give = Math.min(rest, want[i]);
		alloc[i] = give; rest -= give;
	}
	// 第二轮：仍有余量时按同序填到 cap
	if (rest > 0) {
		for (const i of order) {
			const give = Math.min(rest, caps[i] - alloc[i]);
			alloc[i] += give; rest -= give;
			if (rest <= 0) break;
		}
	}
	return alloc;
}

// ── 终端显示单元工具（自 status-ui v1.5.182 迁出；语义不变） ─────────────────

const ANSI_SGR_RE = /\x1b\[[0-9;]*m/;

/** 单码点显示格数（CJK/谚文/全角/Emoji/大字面 = 2）。 */
function cpCells(cp: number): number {
	if (cp < 0x1100) return 1;
	return (cp <= 0x115f || (cp >= 0x2e80 && cp <= 0x9fff) || (cp >= 0xa960 && cp <= 0xa97f)
		|| (cp >= 0xac00 && cp <= 0xd7a3) || (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe30 && cp <= 0xfe6f)
		|| (cp >= 0xff00 && cp <= 0xff60) || (cp >= 0xffe0 && cp <= 0xffe6)
		|| (cp >= 0x1f300 && cp <= 0x1faff) || (cp >= 0x20000 && cp <= 0x3fffd)) ? 2 : 1;
}

/** 字符串终端显示格数（ANSI 序列不计）。 */
export function cellWidthOf(value: string): number {
	let w = 0;
	for (const seg of String(value).split(new RegExp(`${ANSI_SGR_RE.source}`, "g"))) {
		for (const ch of seg) w += cpCells(ch.codePointAt(0)!);
	}
	return w;
}

/** 终端显示单元截断：maxChars 按终端格计；ANSI 转义不占格不被切断；截断补 "…" 与 reset。 */
export function trimDisplayOf(value: string, maxChars: number): string {
	if (cellWidthOf(value) <= maxChars) return value;
	const b = Math.max(0, maxChars - 1);
	let w = 0, out = "", i = 0;
	const s = String(value);
	while (i < s.length) {
		const m = s.slice(i).match(new RegExp(`^${ANSI_SGR_RE.source}`));
		if (m) { out += m[0]; i += m[0].length; continue; }
		const cp = s.codePointAt(i)!;
		const ch = String.fromCodePoint(cp);
		const cw = cpCells(cp);
		if (w + cw > b) break;
		out += ch; w += cw; i += ch.length;
	}
	if (ANSI_SGR_RE.test(out)) out += "\x1b[0m";
	return out + "…";
}

/** 时长格式化：<60s→"42s"；<60m→"3m12s"；否则 "1h05m"。 */
export function formatDurationOf(ms: number): string {
	const s = Math.max(0, Math.floor(ms / 1000));
	if (s < 60) return `${s}s`;
	const m = Math.floor(s / 60);
	if (m < 60) return `${m}m${String(s % 60).padStart(2, "0")}s`;
	const h = Math.floor(m / 60);
	return `${h}h${String(m % 60).padStart(2, "0")}m`;
}
