/**
 * routing-stats.ts — T2-3a/c：路由记忆聚合 + 自适应分派建议（§9.1 分派决策循环）。
 *
 * a) 增量聚合：每次任务完成从 trace 更新 data/routing-stats.json（角色×成功率/blocked率/avg时长/avg成本）。
 * b) 注入证据：formatRoutingHint() 生成"只给证据不做决策"的历史摘要，经 leader-prompt before_agent_start 注入。
 * c) blocked×2 升档提示：escalationHint() 供 task-tool 回流在第二次 blocked 时附加。
 *
 * 设计哲学（§9.1）：不强制路由，只给证据——"同类任务 luban 近 N 次一次通过率 X%"，分派权在 Leader。
 *
 * 路径：AMAGI_ROUTING_PATH（测试隔离）|| <amagiDataDir>/routing-stats.json（E2 起迁出包目录，见 data-dir.ts）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataFile } from "./data-dir.ts";
import { readTraces, tracesFile, type ErrorKind, type TraceEntry } from "./trace.ts";

export interface AgentStat {
	total: number;
	done: number;
	blocked: number;
	error: number;
	totalDurationMs: number;
	totalCost: number;
	totalToolCalls: number;
	totalInput: number;
	totalOutput: number;
}

export interface RoutingStats {
	agents: Record<string, AgentStat>; // 向后兼容（旧数据）
	/** C7: 多维聚合 key = `${category}/${agent}/${resolvedModel}` */
	dimensions?: Record<string, AgentStat>;
	updatedAt: number;
}

export function routingFile(): string {
	return process.env.AMAGI_ROUTING_PATH || amagiDataFile("routing-stats.json");
}

export function emptyStats(): RoutingStats {
	return { agents: {}, updatedAt: 0 };
}

export function readRoutingStats(file?: string): RoutingStats {
	try {
		const parsed = JSON.parse(fs.readFileSync(file || routingFile(), "utf8"));
		if (parsed && typeof parsed === "object" && parsed.agents) return parsed as RoutingStats;
		return emptyStats();
	} catch {
		return emptyStats();
	}
}

/** 原子写（tmp + rename）。容错。 */
export function writeRoutingStats(stats: RoutingStats, file?: string): void {
	try {
		const f = file || routingFile();
		fs.mkdirSync(path.dirname(f), { recursive: true });
		const tmp = f + ".tmp";
		fs.writeFileSync(tmp, JSON.stringify(stats), { encoding: "utf8", mode: 0o600 });
		fs.renameSync(tmp, f);
	} catch {
		// 容错：聚合写失败不影响主流程
	}
}

/** 增量更新：根据单条任务终态更新多维聚合（C7: category×agent×resolvedModel）。 */
/** ev-20261011-c77487：基础设施类失败判定——非能力信号，不进成功率分母/分子。
 *  - quota（配额/计费）、transient-400（provider 过载误拒）、model（容量/5xx/凭据/网络）：provider 侧故障；
 *  - timeout 且零工具调用：启动/连接期超时，能力未及参与（实战：3 次 57s 启动超时全在网络中断期）。
 *  能力信号照计：context-limit（任务超限）、doom-loop、stall、带工具调用的 timeout（真跑超预算）、
 *  other（兑底不可判——宁可计入不羹报）。 */
function isInfraFailure(entry: { errorKind?: ErrorKind; toolCalls?: number }): boolean {
	if (entry.errorKind === "quota" || entry.errorKind === "transient-400" || entry.errorKind === "model") return true;
	if (entry.errorKind === "timeout" && (entry.toolCalls || 0) === 0) return true;
	return false;
}
export function updateRoutingStats(entry: {
	agent: string;
	status: string;
	blocked: boolean;
	durationMs?: number;
	cost?: number;
	toolCalls?: number;
	input?: number;
	output?: number;
	taskCategory?: string;
	model?: string;
	/** ev-20261011-c77487：调用方传 TraceEntry 形对象时自带（classifyErrorKind 分类）；旧调用面缺省=能力信号照计。 */
	errorKind?: ErrorKind;
}): void {
	// v2 批次B：cancelled 非能力信号（用户/系统主动取消，非 agent 成败证据）——
	// trace 仍落盘（运行图观测），但不入路由记忆聚合，避免污染成功率与熔断 streak。
	if (entry.status === "cancelled") return;
	// ev-20261011-c77487：用户/控制面主动中止（abort 信号）同理 cancelled——非能力、非 provider 健康信号，
	// 实战：主上中止探针任务被记 status=error/errorKind=other，计入 fuxi「成功0%」误导路由。
	if (entry.status === "error" && entry.errorKind === "aborted") return;
	// ev-20261011-c77487：基础设施类失败——不计入能力聚合（成功率语义），但仍喂 provider 熔断（健康信号）。
	// 实战：fuxi 8 次记录 7 次 infra（3 启动超时/他人会话 401/连接错误/429 限流/用户中止）→ 注入「成功0%」。
	if (entry.status === "error" && isInfraFailure(entry)) { recordFuseEvent(entry); return; }
	const stats = readRoutingStats();
	if (!stats.agents) stats.agents = {};
	if (!stats.dimensions) stats.dimensions = {};
	// C7: 多维 key
	const dimKey = `${entry.taskCategory || "unknown"}/${entry.agent}/${entry.model || "default"}`;
	const a: AgentStat = stats.dimensions[dimKey] || {
		total: 0, done: 0, blocked: 0, error: 0,
		totalDurationMs: 0, totalCost: 0, totalToolCalls: 0, totalInput: 0, totalOutput: 0,
	};
	a.total++;
	if (entry.status === "done") a.done++;
	else if (entry.blocked) a.blocked++;
	else a.error++;
	// v1.5.190 止毒：负值/NaN 时长与成本（时钟回拨/坏 trace 产生的腐败行，
	// 实战证据：路由记忆展示 avg-29757114.3m）不入聚合，钳为 0。
	const safeDuration = Number.isFinite(entry.durationMs) && (entry.durationMs as number) > 0 ? (entry.durationMs as number) : 0;
	const safeCost = Number.isFinite(entry.cost) && (entry.cost as number) > 0 ? (entry.cost as number) : 0;
	a.totalDurationMs += safeDuration;
	a.totalCost += safeCost;
	a.totalToolCalls += entry.toolCalls || 0;
	a.totalInput += entry.input || 0;
	a.totalOutput += entry.output || 0;
	stats.dimensions[dimKey] = a;
	// 向后兼容：同时更新 agent-only 聚合
	const aSimple: AgentStat = stats.agents[entry.agent] || { total: 0, done: 0, blocked: 0, error: 0, totalDurationMs: 0, totalCost: 0, totalToolCalls: 0, totalInput: 0, totalOutput: 0 };
	aSimple.total++; if (entry.status === "done") aSimple.done++; else if (entry.blocked) aSimple.blocked++; else aSimple.error++;
	aSimple.totalDurationMs += safeDuration; aSimple.totalCost += safeCost; aSimple.totalToolCalls += entry.toolCalls || 0; aSimple.totalInput += entry.input || 0; aSimple.totalOutput += entry.output || 0;
	stats.agents[entry.agent] = aSimple;
	stats.updatedAt = Date.now();
	writeRoutingStats(stats);
	// R3（Major-3）：写时增量维护 per-key 熔断 streak（sidecar，O(1) 查询；不经 trace 扫描）
	recordFuseEvent(entry);
}

/** 派生指标（成功率/avg时长/avg成本），供注入文本与测试断言。 */
export function deriveAgentMetric(a: AgentStat): {
	total: number;
	successRate: number;
	blockedRate: number;
	avgDurationMs: number;
	avgCost: number;
} {
	const total = a.total || 1;
	return {
		total: a.total,
		successRate: a.total ? a.done / a.total : 0,
		blockedRate: a.total ? a.blocked / a.total : 0,
		avgDurationMs: a.totalDurationMs / total,
		avgCost: a.totalCost / total,
	};
}

/**
 * 格式化路由记忆提示（注入 leader-prompt）。只给证据不做决策。
 * C7: 优先展示多维聚合（category×agent×model），降级到 agent-only。
 */

// ── E4（ev-8cbe23）：路由熔断判定（advisory，不阻断派发；从既有 trace 推导，不新增持久化） ──
/** 瞬时失败定义（复用 v1.5.179 poison 语义）：status=error 且零工具调用且时长<5s。此类失败疑似规格/配置问题，非能力信号。 */
export function isInstantFail(e: { status?: string; toolCalls?: number; durationMs?: number }): boolean {
	return e.status === "error" && (e.toolCalls || 0) === 0 && (e.durationMs ?? 0) < 5000;
}

/** ev-20261011-c77487 F-03：中止不参与熔断序列——增量/懒回填/显式窗口/键集四条路径统一谓词。
 *  透明跳过（既不递增也不复位）：用户/控制面中止与 provider 健康、能力成败均无关；
 *  若映射为非瞬时失败（isInstantFail=false）会错误复位真实 streak，故必须整行跳过。 */
function participatesInFuse(e: { status?: string; errorKind?: ErrorKind }): boolean {
	return !(e.status === "error" && e.errorKind === "aborted");
}

/** dimKey 拼装（与 updateRoutingStats 多维 key 一致：category/agent/model，缺省 unknown/?/default）。 */
export function routingDimKey(category?: string, agent?: string, model?: string): string {
	return `${category || "unknown"}/${agent || "?"}/${model || "default"}`;
}

/** 熔断阈值：某 category/agent/model 键尾段连续瞬时失败次数 ≥ 此值 → fused。 */
export const FUSE_THRESHOLD = 5;

/** v1.5.190 熔断自愈（decay）：streak 最近一次失败后超过该窗口未再失败，视为已恢复
 * （实战痛点：配置问题修复后熔断标志尸体化，长期占据路由记忆且无解）。
 * 默认 24h；AMAGI_FUSE_DECAY_MS 覆盖；<=0 关闭自愈（永久熔断直到成功复位）。 */
function fuseDecayMs(): number {
	const v = Number(process.env.AMAGI_FUSE_DECAY_MS);
	if (Number.isFinite(v)) return v;
	return 24 * 60 * 60 * 1000;
}

/** decay 生效判定：streak 有效（未 decay）时返回原值，否则 0。 */
function applyFuseDecay(streak: number, at: number | undefined, now = Date.now()): number {
	if (streak <= 0) return 0;
	const decay = fuseDecayMs();
	if (decay <= 0) return streak; // 自愈关闭
	if (!at || now - at > decay) return 0;
	return streak;
}

/** P1-5：streak 近窗——只取目标 key 最近 N 条参与尾段连续计数（streak≥FUSE_THRESHOLD 即熔断，50 足够）。 */
export const FUSE_STREAK_WINDOW = 50;

// ── R3（Major-3）：per-key 熔断状态 sidecar——写时增量维护，替代尾扫/缓存方案 ──
// 设计：每次任务终态（updateRoutingStats 统一入口）增量更新目标 key 的尾段连续瞬时
// 失败计数（streak = 瞬时失败 ? streak+1 : 0，精确 per-key 语义，无需窗口/全量扫描）；
// 查询只读小型 sidecar JSON（O(keys)），不再每次派发扫描无界 trace 文件。
// 迁移：sidecar 文件不存在（或目标 key 未见）时，一次性全量扫描 trace 回填后持续增量。
interface FuseStateEntry { streak: number; at: number; }
interface FuseState { version: 1; keys: Record<string, FuseStateEntry>; }

/** 熔断状态 sidecar 路径（AMAGI_FUSE_STATE_PATH 测试隔离）。 */
export function fuseStateFile(): string {
	return process.env.AMAGI_FUSE_STATE_PATH || amagiDataFile("fuse-state.json");
}

function loadFuseState(): FuseState {
	try {
		const raw = fs.readFileSync(fuseStateFile(), "utf8");
		const s = JSON.parse(raw) as FuseState;
		if (s && s.version === 1 && s.keys) return s;
	} catch { /* 缺失/损坏 → 重建 */ }
	return { version: 1, keys: {} };
}

function saveFuseState(s: FuseState): void {
	try {
		const f = fuseStateFile();
		fs.mkdirSync(path.dirname(f), { recursive: true });
		const tmp = f + ".tmp";
		fs.writeFileSync(tmp, JSON.stringify(s), { encoding: "utf8", mode: 0o600 });
		fs.renameSync(tmp, f);
	} catch { /* 容错：sidecar 写失败不影响主流程 */ }
}

/** 测试钩子：删除 sidecar 强制下次查询全量回填（isolate-env 每进程独立数据目录）。 */
export function _resetFuseCache(): void {
	try { fs.unlinkSync(fuseStateFile()); } catch {}
}

/**
 * 写时增量：单条任务终态更新目标 key 的尾段连续瞬时失败计数。
 * 由 updateRoutingStats 统一调用（所有生产终态路径必经），不读 trace 文件。
 */
export function recordFuseEvent(entry: { status?: string; toolCalls?: number; durationMs?: number; taskCategory?: string; agent?: string; model?: string; at?: number; errorKind?: ErrorKind }): void {
	if (!participatesInFuse(entry)) return; // ev-20261011-c77487 F-03：中止零熔断（增量路径防御，正常流程已在 updateRoutingStats 早退）
	try {
		const key = routingDimKey(entry.taskCategory, entry.agent, entry.model);
		const st = loadFuseState();
		const cur = st.keys[key]?.streak || 0;
		st.keys[key] = { streak: isInstantFail(entry) ? cur + 1 : 0, at: entry.at || Date.now() };
		saveFuseState(st);
	} catch { /* 容错 */ }
}

/**
 * 一次性全量回填：sidecar 不存在（targetKey 未指定）或目标 key 未记录时，
 * 全量扫描 trace 重建 per-key streak 并持久化；此后只靠 recordFuseEvent 增量。
 */
function backfillFuseState(targetKey?: string, readFn: (file: string) => TraceEntry[] = readTraces): FuseState {
	const st = loadFuseState();
	let all: TraceEntry[] = [];
	try { all = readFn(tracesFile()); } catch { all = []; }
	all = all.slice().sort((a, b) => (a.at || 0) - (b.at || 0));
	const streaks = new Map<string, number>();
	const ats = new Map<string, number>();
	for (const e of all) {
		const k = routingDimKey(e.taskCategory, e.agent, e.model);
		if (targetKey && k !== targetKey) continue;
		if (!participatesInFuse(e)) continue; // ev-20261011-c77487 F-03：回填与增量同谓词——中止透明跳过，不递增不复位
		streaks.set(k, isInstantFail(e) ? (streaks.get(k) || 0) + 1 : 0);
		ats.set(k, e.at || 0);
	}
	if (!targetKey) st.keys = {}; // 全量重建（sidecar 缺失场景）
	for (const [k, streak] of streaks) st.keys[k] = { streak, at: ats.get(k) || 0 };
	saveFuseState(st);
	return st;
}

export interface FuseStatus { fused: boolean; streak: number; }

/**
 * P1-5/R3：查询某 category/agent/model 的熔断状态与尾段连续瞬时失败次数。
 * - 注入 traces（测试）时按注入序列窗口语义计算；
 * - 生产路径读 per-key sidecar（写时增量，O(1)）；key 未见时一次性全量回填（兼容直写 trace 的旧数据/fixture）。
 */
export function fuseStatus(category: string | undefined, agent: string | undefined, model: string | undefined, traces?: TraceEntry[], opts?: { readFn?: (file: string) => TraceEntry[] }): FuseStatus {
	const key = routingDimKey(category, agent, model);
	if (traces) {
		const own: TraceEntry[] = [];
		for (const e of traces) {
			if (!participatesInFuse(e)) continue; // ev-20261011-c77487 F-03：显式窗口同样跳过中止
			if (routingDimKey(e.taskCategory, e.agent, e.model) === key) own.push(e);
		}
		if (own.length === 0) return { fused: false, streak: 0 };
		own.sort((a, b) => (a.at || 0) - (b.at || 0));
		const win = own.length > FUSE_STREAK_WINDOW ? own.slice(own.length - FUSE_STREAK_WINDOW) : own;
		let streak = 0;
		for (let i = win.length - 1; i >= 0; i--) {
			if (isInstantFail(win[i])) streak++;
			else break;
		}
		return { fused: streak >= FUSE_THRESHOLD, streak };
	}
	let st = loadFuseState();
	if (!(key in st.keys)) st = backfillFuseState(key, opts?.readFn);
	const e = st.keys[key];
	// v1.5.190：decay 自愈——最后一次失败超过窗口未再复发视为已恢复
	const streak = applyFuseDecay(e?.streak || 0, e?.at);
	return { fused: streak >= FUSE_THRESHOLD, streak };
}

/**
 * 计算每个 dimKey 的尾段连续瞬时失败次数（注入 traces 的测试路径）：trace 按 at 升序，
 * 从末尾向前数连续瞬时失败，遇首个非瞬时失败即停；每 key 只看最近 FUSE_STREAK_WINDOW 条。
 */
function computeFuseStreaks(traces: TraceEntry[]): Map<string, number> {
	const list = traces.slice().sort((a, b) => (a.at || 0) - (b.at || 0));
	const byKey = new Map<string, TraceEntry[]>();
	for (const e of list) {
		if (!participatesInFuse(e)) continue; // ev-20261011-c77487 F-03：键集计算同样跳过中止
		const k = routingDimKey(e.taskCategory, e.agent, e.model);
		let arr = byKey.get(k);
		if (!arr) { arr = []; byKey.set(k, arr); }
		arr.push(e);
	}
	const streaks = new Map<string, number>();
	for (const [k, arr] of byKey) {
		const start = arr.length > FUSE_STREAK_WINDOW ? arr.length - FUSE_STREAK_WINDOW : 0;
		let streak = 0;
		for (let i = arr.length - 1; i >= start; i--) {
			if (isInstantFail(arr[i])) streak++;
			else break;
		}
		streaks.set(k, streak);
	}
	return streaks;
}

/** 返回当前已熔断的 dimKey 列表（尾段连续瞬时失败 ≥ FUSE_THRESHOLD）；生产路径读 sidecar，测试可注入 traces。 */
export function fusedKeys(traces?: TraceEntry[]): string[] {
	if (traces) {
		const streaks = computeFuseStreaks(traces);
		const out: string[] = [];
		for (const [k, n] of streaks) if (n >= FUSE_THRESHOLD) out.push(k);
		return out;
	}
	// sidecar 文件不存在 → 先全量回填（兼容旧数据），否则直接用增量状态
	let st = loadFuseState();
	if (!fs.existsSync(fuseStateFile())) st = backfillFuseState();
	return Object.entries(st.keys).filter(([, e]) => applyFuseDecay(e.streak, e.at) >= FUSE_THRESHOLD).map(([k]) => k);
}

/** 查询某 category/agent/model 路由是否已熔断（P1-5：薄封装 fuseStatus 单趟）。 */
export function isFused(category: string | undefined, agent: string | undefined, model: string | undefined, traces?: TraceEntry[]): boolean {
	return fuseStatus(category, agent, model, traces).fused;
}

/** 查询某 category/agent/model 路由的尾段连续瞬时失败次数（P1-5：薄封装 fuseStatus 单趟）。 */
export function fuseStreak(category: string | undefined, agent: string | undefined, model: string | undefined, traces?: TraceEntry[]): number {
	return fuseStatus(category, agent, model, traces).streak;
}

/**
 * 格式化路由记忆提示（注入 leader-prompt）。只给证据不做决策。
 * C7: 优先展示多维聚合（category×agent×model），降级到 agent-only。
 * E4：熔断键（尾段连续瞬时失败≥FUSE_THRESHOLD）标注 ⛔熔断；traces 显式注入供测试。
 */
/** v1.5.192 路由记忆限界：默认只展示 TopK（按 total 降序），其余折叠为一行汇总；
 * 熔断键（安全信号）永远置顶展示不占 TopK 名额。AMAGI_ROUTING_HINT_TOPK 覆盖。 */
function routingHintTopK(): number {
	const v = Number(process.env.AMAGI_ROUTING_HINT_TOPK);
	return Number.isFinite(v) && v > 0 ? Math.floor(v) : 12;
}

/** v1.5.190 展示消毒：负值/零值均值（历史腐败聚合或零时长）显示 `-`，
 * 不再渲染 avg-29757114.3m 类反物理文本。 */
function formatAvgMin(avgDurationMs: number): string {
	return avgDurationMs > 0 ? `avg${(avgDurationMs / 60000).toFixed(1)}m` : "avg-";
}

/** 熔断标注文案（含复位路径说明；decay 关闭时不承诺自动解除）。 */
function fusedMarkText(): string {
	const decay = fuseDecayMs();
	const reset = decay > 0
		? `修复后成功一次自动复位，${Math.round(decay / 3600000)}h 无复发自动解除`
		: "修复后成功一次自动复位";
	return ` ⛔熔断（近${FUSE_THRESHOLD}+次连续瞬时失败，疑规格/配置问题；${reset}）`;
}

/**
 * v1.5.216 防误导：维度键 category/agent/model 的 model 段必须携带 provider 前缀
 * （provider/model[:level]，即 model 段含且仅含 1 个 /）。normalizeModelSpec 之前的遗留
 * 裸名键（glm-5.2 / k3-256k 等）无法安全解析到唯一 provider，渲染时滤除防 Leader 误复制。
 */
export function isQualifiedDimKey(key: string): boolean {
	const parts = key.split("/");
	if (parts.length < 3) return false;
	const model = parts.slice(2).join("/");
	return model.split("/").length === 2;
}

export function formatRoutingHint(stats?: RoutingStats, traces?: TraceEntry[]): string {
	const s = stats || readRoutingStats();
	// E4：熔断键集合（trace 时间序尾段连续瞬时失败≥阈值）
	const fusedSet = new Set(fusedKeys(traces));
	// ev-20261011-c77487 F-02：sidecar-only 熔断键（纯基础设施失败不进能力聚合）——provider 健康警示
	// 不得从任何提示出口消失（含空 stats、过滤后无有效维度、agent-only 降级）；不虚构成功率分母。
	const renderOrphans = (exclude: ReadonlySet<string>): string[] =>
		[...fusedSet].filter((k) => !exclude.has(k))
			.map((k) => `${k}: 0次能力样本 ${fusedMarkText()}（基础设施类瞬时失败达阈值——provider 健康信号，未计入成功率）`);
	// C7: 优先展示多维聚合
	if (s.dimensions && Object.keys(s.dimensions).length > 0) {
		// v1.5.216 防误导：normalizeModelSpec 之前的遗留键无 provider 前缀（如 bug-fix/luban/glm-5.2），
		// Leader 可能直接把裸模型名复制进派发 model 覆盖 → 多 provider 歧义（实战：glm-5.2 同时存在
		// opencode-go 与 zhipuai 两个 provider，裸名被整单拒收或解析到错误 provider）。
		// 渲染端直接滤除：不带 provider 的模型键对分派无安全可用价值，仅在 query_task({stats}) 全量可查。
		const entries = Object.entries(s.dimensions).filter(([k, a]) => a && a.total > 0 && isQualifiedDimKey(k));
		if (entries.length > 0) {
			// v1.5.192 限界（防上下文腐烂）：TopK 展示 + 其余折叠为一行；
			// 熔断键是安全信号，永远置顶展示不占 TopK 名额。
			const topK = routingHintTopK();
			const sorted = entries.sort((a, b) => b[1].total - a[1].total);
			const pinned = sorted.filter(([k]) => fusedSet.has(k));
			const rest = sorted.filter(([k]) => !fusedSet.has(k));
			const shown = [...pinned, ...rest.slice(0, Math.max(0, topK - pinned.length))];
			const folded = rest.slice(Math.max(0, topK - pinned.length));
			const lines = shown
				.map(([key, a]) => {
					const m = deriveAgentMetric(a);
					const rate = Math.round(m.successRate * 100);
					// v1.5.179: 全量瞬时失败标注（error 全零工具调用且均时<5s → 疑似规格/配置问题，非能力信号，防误导分派）
					// E4（ev-8cbe23）：达熔断阈值（尾段连续瞬时失败≥FUSE_THRESHOLD）升级 ⛔熔断，未达阈值保留 ⚠
					const poison = a.total >= 3 && a.done === 0 && (a.totalToolCalls || 0) === 0 && m.avgDurationMs < 5000;
					const fusedMark = fusedSet.has(key)
						? fusedMarkText()
						: poison ? " ⚠全部瞬时失败（疑规格/配置问题）" : "";
					return `${key}: ${m.total}次 成功${rate}% ${formatAvgMin(m.avgDurationMs)}${fusedMark}`;
				});
			lines.push(...renderOrphans(new Set(shown.map(([k]) => k))));
			let tail = "";
			if (folded.length > 0) {
				const foldedTotal = folded.reduce((n, [, a]) => n + (a.total || 0), 0);
				// G23（十月迭代 §8.3）：legacy query_task({stats:true}) 在 v2 会话不注册——指引改指
				// /amagi stats（用户命令，主上界面直达）；注入快照机制不变（leader-prompt 内容变化才注入）。
				tail = `\n其余 ${folded.length} 键（合计 ${foldedTotal} 次，低样本/一次性行已折叠；完整见 /amagi stats）`;
			}
			return `--- 路由记忆（category/agent/model 维度，仅供分派参考；Top${Math.min(topK, entries.length)}/${entries.length}键；模型键勿复制为 model 覆盖参数，派发缺省用角色配置模型）---\n` + lines.join("\n") + tail;
		}
	}
	// 降级：agent-only
	const entries = Object.entries(s.agents).filter(([, a]) => a && a.total > 0);
	if (entries.length === 0) {
		// ev-20261011-c77487 F-02：空能力样本也不得先于健康警示返回空串
		const orphanOnly = renderOrphans(new Set());
		return orphanOnly.length ? `--- 路由记忆（仅 provider 健康警示，无能力样本）---\n${orphanOnly.join("\n")}` : "";
	}
	const lines = entries
		.sort((a, b) => b[1].total - a[1].total)
		.map(([name, a]) => {
			const m = deriveAgentMetric(a);
			const rate = Math.round(m.successRate * 100);
			const avgCost = m.avgCost > 0 ? `$${m.avgCost.toFixed(3)}` : "$-";
			return `${name}: ${m.total}次 成功${rate}% ${formatAvgMin(m.avgDurationMs)} ${avgCost}`;
		});
	lines.push(...renderOrphans(new Set(entries.map(([name]) => name))));
	return "--- 路由记忆（历史统计，仅供分派参考，不强制路由）---\n" + lines.join("\n");
}

/**
 * T2-3c：blocked×2 升档 resume 提示。
 * 同一任务（taskId）第二次 blocked（registry.rounds.length >= 1，即 resume 过至少一次后仍 blocked）时附加。
 */
export function escalationHint(resumeRounds: number, blocked: boolean): string {
	if (!blocked || resumeRounds < 1) return "";
	return "\n\n💡 已连续 blocked（含至少一次 resume 仍 blocked），考虑 resume 时指定更高 tier 模型（如 expert 档）以提升一次通过率。";
}
