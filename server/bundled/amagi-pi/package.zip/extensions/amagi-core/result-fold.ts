/**
 * result-fold.ts — E8 大输出折叠落盘。
 *
 * 来源：《调查报告-超时不可见与终端崩溃.md》「插件侧可做的进一步缓解」：
 *   sync/编排回流超过阈值时，全文落 agent-outputs/<taskId>-result.md，
 *   回流只给头部 + 落盘路径。收益：
 *   a) 减少 Terminal.app 数据检测器（CoreNLP/DataDetectorsCore）触发素材——
 *      三次终端段错误均发生在大段高速文本输出时段；
 *   b) 省 Leader 上下文——回流全文动辄数十 KB，多数只需头部+路径即可决定是否深读。
 *
 * 设计边界：
 *   - 折叠是**呈现层**行为：registry/trace/stats 仍记录 cappedOutput 全文口径，不变。
 *   - 写盘失败如实回退原文（宁多不丢，禁假数据底线：不静默截断且无落盘）。
 *   - blocked 输出由调用方决定是否折叠（本模块不感知状态）；QUESTIONS 需 Leader 直接答复，
 *     调用方（task-tool）对 blocked 跳过折叠。
 *   - 落盘路径含 agent-outputs/ 前缀，extractArtifactRefs 会自动收编为 artifactRefs。
 *   - ev-20260903-265a06 验收节保真：折叠时提取尾部「验收关键节」（ACHIEVEMENT/验收/交付清单/
 *     契约，标题行+≤12 行/UTF-8 ≤1.5KB）附在折叠说明后——子 Agent 终稿尾部验收表被折后
 *     Leader 被迫补查产物文件；保留头部已含完整节时不重复附加（零噪音，行为与旧版一致）。
 *   - ev-20260914 未覆盖/风险节保真：「未覆盖/剩余风险/注意事项」类尾部节与验收节同等保真——
 *     实战样本中这两类恰在尾部且是 Leader 验收/排障决策最需要的信息，此前只有验收节带回。
 *
 * ev-20260914 marker 豁免收窄（双条件）：DONE_CONTRACT_REMINDER 对编码类必注入 marker，
 * F6d 的无条件豁免使折叠对全部合规终稿失效（实测 fast 型调研终稿 4.8KB 全文回流）。
 * 豁免仅当：① contractApplies（编码类 work/expert；fast 型不校验 marker 不应享受豁免）；
 * ② bytes ≤ MARKER_EXEMPT_MAX_BYTES（8KB 覆盖 F6d 痛点的 6.5KB 审核报告；超长终稿仍折叠，
 * 验收/风险节保真 + 全文路径兜底）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { artifactRoot } from "./artifact.ts";

/** 折叠阈值（UTF-8 字节）。默认 4096；<=0 关闭折叠。 */
export function getFoldThreshold(): number {
	const v = Number(process.env.AMAGI_RESULT_FOLD_BYTES);
	return Number.isFinite(v) ? v : 4096;
}

/** 折叠后保留的头部字节数。P3-D 冻结自 AMAGI_RESULT_FOLD_HEAD_BYTES（默认 2048），如需恢复 env 读取请回看 git 历史。 */
const FOLD_HEAD_BYTES = 2048;

/** marker 豁免上限（UTF-8 字节）：带完成契约的终稿仅在此规模内免折叠（ev-20260914 收窄）。 */
const MARKER_EXEMPT_MAX_BYTES = 8192;

export function getFoldHeadBytes(): number {
	return FOLD_HEAD_BYTES;
}

/** UTF-8 安全截断（不切断多字节字符；无后缀标注，由调用方拼折叠说明）。 */
function headUtf8(str: string, maxBytes: number): string {
	const buf = Buffer.from(str, "utf8");
	if (buf.length <= maxBytes) return str;
	let cut = maxBytes;
	while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--; // 回退到字符边界
	return buf.slice(0, cut).toString("utf8");
}

// ── ev-20260903-265a06：验收节保真 ──────────────────────────────────────────
// 实战：多个子 Agent 返回体尾部「[裁剪：省略 NNNN 字节]」，ACHIEVEMENT 验收表不完整，
// Leader 验收需另行补查产物文件。折叠只保留头部 2048B 时尾部整段丢失，故折叠时把
// 「验收关键节」节选原样带回回流。AMAGI:DONE 免折叠（F6d）只覆盖带 marker 的终稿，
// 本节选兜底无 marker 的报告；找不到验收节不附任何内容（零噪音）。
// ev-20260914：未覆盖/风险节（RISK_HEADING_RE）与验收节同等保真——实战样本中
// 「未覆盖：…」「**剩余风险**：…」恰在尾部，是 Leader 验收/排障最需要的信息，此前被折丢。

/** 验收关键节标题行：ACHIEVEMENT/验收/交付清单/契约 开头的 0-3 级标题（无 # 伪标题也算）。 */
const ACHIEVEMENT_HEADING_RE = /^#{0,3}[ \t]*(?:ACHIEVEMENT|验收|交付清单|契约)/i;
/** 未覆盖/风险关键节标题行（ev-20260914）：无 # 伪标题与 **加粗** 标题都算（实战形态：「未覆盖：…」「**剩余风险**：…」）。 */
const RISK_HEADING_RE = /^(?:#{0,3}[ \t]*|\*\*)[ \t]*(?:未覆盖|未验证|剩余风险|风险提示|风险|注意事项|局限)/;
/** 节选上限：标题行 + 后续 ≤12 行、UTF-8 ≤1.5KB（防节选反噬折叠省下的回流预算）。 */
const ACHIEVEMENT_MAX_TAIL_LINES = 12;
const ACHIEVEMENT_MAX_BYTES = 1536;

/**
 * 提取最后一次出现的「验收关键节」：从标题行到下一「同级或更高级」# 标题或节尾。
 * 纯函数；找不到返回 null。上限：标题行 + 12 行 / UTF-8 1.5KB（整行取舍，不切半行）。
 */
export function extractAchievementSection(text: string): string | null {
	return extractTitledSection(text, ACHIEVEMENT_HEADING_RE);
}

/** ev-20260914：提取最后一次出现的「未覆盖/风险关键节」（与验收节同提取规则，仅正则不同）。 */
export function extractRiskSection(text: string): string | null {
	return extractTitledSection(text, RISK_HEADING_RE);
}

/** 通用尾部关键节提取（验收/风险共用）：最后一次命中标题行 → 同级或更高级 # 标题或节尾；整行取舍。 */
function extractTitledSection(text: string, headingRe: RegExp): string | null {
	if (!text) return null;
	const lines = text.split("\n");
	let start = -1;
	for (let i = 0; i < lines.length; i++) if (headingRe.test(lines[i])) start = i; // 取最后出现（终稿关键节在尾部）
	if (start === -1) return null;
	// 节边界：无 # 伪标题（如「验收：」行）视作被 1-3 级 # 标题终结
	const hashes = lines[start].startsWith("#") ? lines[start].match(/^#+/)![0].length : 0;
	const boundary = hashes >= 1 ? hashes : 3;
	let section = Buffer.byteLength(lines[start], "utf8") <= ACHIEVEMENT_MAX_BYTES ? lines[start] : headUtf8(lines[start], ACHIEVEMENT_MAX_BYTES);
	for (let i = start + 1; i < lines.length && i - start <= ACHIEVEMENT_MAX_TAIL_LINES; i++) {
		const heading = /^(#{1,6})[ \t]/.exec(lines[i]);
		if (heading && heading[1].length <= boundary) break; // 下一同级（或更高级）标题 → 节尾
		const next = `${section}\n${lines[i]}`;
		if (Buffer.byteLength(next, "utf8") > ACHIEVEMENT_MAX_BYTES) break; // 超字节预算 → 整行舍弃
		section = next;
	}
	return section;
}

export interface FoldOpts {
	taskId: string;
	/** 任务/会话 cwd（仅作上下文信息；落盘已迁至全局 artifact 目录，不再写项目内）。 */
	cwd: string;
	/** E10：artifact 已落盘时的 result.md 路径——直接引用，不重复写盘。 */
	fullRel?: string;
	/** ev-20260914：完成契约是否适用于该角色（编码类 work/expert = true，fast = false）。
	 *  marker 豁免仅此档生效——fast 型不校验 marker，不应因文本含 marker 字符串逃过折叠。
	 *  缺省 true：纯函数保守兼容（未标注视为适用，保留旧调用方行为）。 */
	contractApplies?: boolean;
}

/**
 * 超过阈值 → 全文落盘（E10 artifact 已落盘则直接引用），返回 头部+折叠说明+路径；
 * 未超阈值 / 已关闭 / 写盘失败 → 原样返回。纯同步、无副作用失败抛错。
 */
export function foldResultText(text: string, opts: FoldOpts): string {
	if (!text) return text;
	const threshold = getFoldThreshold();
	if (threshold <= 0) return text;
	const bytes = Buffer.byteLength(text, "utf8");
	// 8月迭代 F6d：含完成契约 marker 的终稿不折叠——审核/交付报告正是 Leader 必读内容
	// （实战：diting 审核 6.5KB 报告被折，报告核心被落盘，验收读流受挫）。
	// ev-20260914 豁免收窄（双条件）：DONE_CONTRACT_REMINDER 对编码类必注入 marker，无条件
	// 豁免使折叠对全部合规终稿失效（实测 fast 型调研终稿 4.8KB 全文回流）。仅当 ①契约适用
	// 角色（编码类 work/expert；fast 不校验 marker 不应享受豁免）② bytes ≤ 8KB（覆盖 F6d
	// 痛点的 6.5KB 审核报告）才免折；超长终稿仍折叠，验收/风险节保真 + 全文路径兜底。
	if (opts.contractApplies !== false && text.includes("AMAGI:DONE") && bytes <= MARKER_EXEMPT_MAX_BYTES) return text;
	if (bytes <= threshold) return text;
	const head = headUtf8(text, Math.min(getFoldHeadBytes(), threshold));
	// ev-20260903-265a06：验收节保真——尾部验收关键节节选附在折叠说明之后；保留头部
	// 已含完整节时不重复附加（零噪音，不改变无节时的旧行为）。
	const achieve = extractAchievementSection(text);
	const achieveTail = achieve && !head.includes(achieve)
		? `\n\n[验收节保真]（验收关键节节选；完整内容见落盘文件）\n${achieve}`
		: "";
	// ev-20260914：未覆盖/风险节同等保真（尾部信息 Leader 验收/排障最需要）；与验收节分别
	// 提取（两节位置不定，合并取「最后出现」会互相顶掉）；头部已含完整节不重复附加。
	const risk = extractRiskSection(text);
	const riskTail = risk && !head.includes(risk) && risk !== achieve
		? `\n\n[未覆盖/风险节保真]（尾部关键节节选；完整内容见落盘文件）\n${risk}`
		: "";
	if (opts.fullRel) {
		// E10 artifact 已写 result.md → 引用契约路径（单一日志源）
		return `${head}\n\n[输出折叠] 完整回流共 ${bytes}B，已落盘: ${opts.fullRel}\n（read 该文件查看全文；AMAGI_RESULT_FOLD_BYTES 调阈值，<=0 关闭折叠）${achieveTail}${riskTail}`;
	}
	const safeId = String(opts.taskId || "unknown").replace(/[^A-Za-z0-9_-]/g, "_").slice(0, 64) || "unknown";
	// 兑底落盘走全局 artifact 根（不落项目目录，防 SubAgent 产出污染工作区）
	const abs = path.join(artifactRoot(), `${safeId}-result.md`);
	try {
		fs.mkdirSync(path.dirname(abs), { recursive: true });
		fs.writeFileSync(abs, text, "utf8");
	} catch {
		return text; // 写盘失败如实回退全文（不静默截断）
	}
	return `${head}\n\n[输出折叠] 完整回流共 ${bytes}B，已落盘: ${abs}\n（read 该文件查看全文；AMAGI_RESULT_FOLD_BYTES 调阈值，<=0 关闭折叠）${achieveTail}${riskTail}`;
}
