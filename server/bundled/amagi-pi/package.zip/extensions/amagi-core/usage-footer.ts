/**
 * usage-footer.ts — Batch 3（设计方案 §9.5「成本进入 footer」，2026-10 主上裁决 Q4：统一按 token 计量）。
 *
 * 职责：任务终态用量 footer 的**只读登记与渲染**——不改变任何计量写入逻辑（Batch 0 域只读消费）。
 *
 * 取数契约（先验证后实现，2026-10-14 核验结论）：
 * - writeStats（task-run.ts）是子任务 usage 落盘唯一漏斗：sync 路径每逻辑任务恰一行
 *  （task-tool.ts 聚合点 writeStats(_deferredMerge?.stats ?? rr._statsPayload)——deferStats 多轮
 *  经 mergeDeferredUsage 聚合恰一次）；background/resume 每轮各一行（各自 runKey）。
 * - 本模块在 writeStats 漏斗处捕获**已落盘/已聚合的终值**（runKey 对账一次——同 runKey 重放不入账），
 *   装配点（sync 返回/完成通知/wait/query）只做纯读渲染，不重算累计——重复 wait/task_query
 *   返回逐字相同（幂等）。
 * - 多轮任务（resume 续接链 / background 400 修复 / 冷却重派同 taskId）显示「本轮 + 逻辑任务合计」
 *  两截：合计 = 本任务各行之和 ∪ 续接父链（同会话续接才并入；fork/编排分叉各枝独立记账）。
 *   父链账本跨进程缺失（Leader 重启后 resume）→ 合计显式「未知（跨进程历史不可得）」，不静默少报。
 * - 展示只用 token/调用数：缺项显示「未知」不补 0；无单价通道不出现金额（footer 恒不渲染 cost）。
 * - 中断/缺帧（usageCoverage 非 complete）如实标注「部分可见」。
 *
 * 内存面有界（≤1024 任务条目，近似 LRU 逐出）；登记失败静默（观测面绝不反噬任务主流程）。
 */
import { registry } from "./task-registry.ts";

/** footer 数值（token 四项 + 调用数；undefined=未知，不补 0）。 */
export interface UsageFooterFigures {
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	calls?: number;
}

/** 单任务终态登记条目（usageFooterOf 供测试与只读消费）。 */
export interface UsageFooterEntry {
	nested?: UsageFooterFigures;
	/** 本 taskId 已计入的 stats 行数（每 runKey 恰一次）。 */
	runs: number;
	/** 各行 rounds 字段之和（sync deferStats 聚合行内部轮数）。 */
	internalRounds: number;
	/** 本 taskId 各行合计。 */
	own: UsageFooterFigures;
	/** 最近一行数值（「本轮」段）。 */
	last: UsageFooterFigures;
	/** 逻辑任务链合计（own ∪ 续接父链）。 */
	chain: UsageFooterFigures;
	/** 链上 stats 行数（合计段轮数标注）。 */
	chainRuns: number;
	/** 续接父链账本跨进程缺失 → 合计未知（渲染显式标注，不静默少报）。 */
	chainKnown: boolean;
	/** 任一计入行 usageCoverage 非 complete → footer 标「部分可见」。 */
	partialCoverage: boolean;
	/** 已对账 runKey（每行恰一次；含未带 runKey 的兜底键）。 */
	runKeys: ReadonlySet<string>;
}

interface MutableEntry extends Omit<UsageFooterEntry, "runKeys"> {
	runKeys: Set<string>;
}

const MAX_ENTRIES = 1024;
const entries = new Map<string, MutableEntry>();
let anonSeq = 0;

function safeRecord(taskId: string): { parentTaskId?: string; sessionId?: string; status?: string } | undefined {
	try { return registry.get(taskId) as { parentTaskId?: string; sessionId?: string; status?: string } | undefined; } catch { return undefined; /* lint-exempt:registry 只读回退（footer 判据缺失时退独立记账，不反噬） */ }
}

function finiteOf(v: unknown): number | undefined {
	return typeof v === "number" && Number.isFinite(v) ? v : undefined;
}

/** 定义值求和：全程未定义保持 undefined（未知，不补 0）。 */
function addFiguresInto(dst: UsageFooterFigures, src: UsageFooterFigures): void {
	if (src.input !== undefined) dst.input = (dst.input ?? 0) + src.input;
	if (src.output !== undefined) dst.output = (dst.output ?? 0) + src.output;
	if (src.cacheRead !== undefined) dst.cacheRead = (dst.cacheRead ?? 0) + src.cacheRead;
	if (src.cacheWrite !== undefined) dst.cacheWrite = (dst.cacheWrite ?? 0) + src.cacheWrite;
	if (src.calls !== undefined) dst.calls = (dst.calls ?? 0) + src.calls;
}

function newEntry(): MutableEntry {
	return {
		runs: 0, internalRounds: 0,
		own: {}, last: {}, chain: {},
		chainRuns: 0, chainKnown: true, partialCoverage: false,
		runKeys: new Set<string>(),
	};
}

/**
 * writeStats 漏斗唯一写方（每行恰调用一次；同 runKey 重放跳过——runKey 对账一次）。
 * 行参数取 writeStats 已有界化的落盘形状（bounded）——footer 数值与磁盘终值同源。
 */
export function recordUsageFooterRow(row: { taskId: string; runKey?: string; input?: number; output?: number; cacheRead?: number; cacheWrite?: number; assistantCalls?: number; rounds?: number; usageCoverage?: string; nestedUsage?: UsageFooterFigures }): void {
	try {
		if (typeof row?.taskId !== "string" || row.taskId === "") return;
		const runKey = typeof row.runKey === "string" && row.runKey !== "" ? row.runKey : `anon#${++anonSeq}`;
		// 近似 LRU：已存在先删后插（最近更新在尾），超上限逐出最早条目。
		const existing = entries.get(row.taskId);
		if (existing && existing.runKeys.has(runKey)) return; // runKey 已对账——重放不入账
		const e = existing ?? newEntry();
		entries.delete(row.taskId);
		entries.set(row.taskId, e);
		if (entries.size > MAX_ENTRIES) {
			const oldest = entries.keys().next().value;
			if (typeof oldest === "string") entries.delete(oldest);
		}
		const figs: UsageFooterFigures = {
			input: finiteOf(row.input), output: finiteOf(row.output),
			cacheRead: finiteOf(row.cacheRead), cacheWrite: finiteOf(row.cacheWrite),
			calls: finiteOf(row.assistantCalls),
		};
		e.runKeys.add(runKey);
		e.runs += 1;
		e.internalRounds += finiteOf(row.rounds) ?? 1;
		if (row.usageCoverage !== undefined && String(row.usageCoverage) !== "complete") e.partialCoverage = true;
		addFiguresInto(e.own, figs);
		e.last = figs;
		if (row.nestedUsage) { e.nested ??= {}; addFiguresInto(e.nested, row.nestedUsage); }
		// ── 续接链合计（写入时一次，O(1)：取父条目已定格的 chain，不递归回溯）──
		const rec = safeRecord(row.taskId);
		const parentId = rec?.parentTaskId;
		const parentRec = parentId !== undefined ? safeRecord(parentId) : undefined;
		// 同会话续接判据：父记录存在且双方 sessionId 一致非空——resume/降档续接同会话；
		// fork/编排 DAG 子节点是新会话（各枝独立逻辑任务），不并入父链（防并行分叉双计）。
		const isContinuation = !!(parentId && parentRec?.sessionId && rec?.sessionId && parentRec.sessionId === rec.sessionId);
		const parentEntry = isContinuation && parentId !== undefined ? entries.get(parentId) : undefined;
		if (isContinuation && parentId !== undefined && !parentEntry) {
			// 父行在本进程 writeStats 之前（Leader 重启后 resume）——链账本缺失，显式未知
			e.chain = { ...e.own };
			e.chainRuns = e.runs;
			e.chainKnown = false;
		} else {
			e.chain = { ...e.own };
			e.chainRuns = e.runs;
			e.chainKnown = true;
			if (parentEntry) {
				addFiguresInto(e.chain, parentEntry.chain);
				e.chainRuns += parentEntry.chainRuns;
				e.chainKnown = parentEntry.chainKnown;
			}
		}
	} catch { /* lint-exempt:观测面绝不反噬 writeStats（登记失败只丢 footer，不丢计量行） */ }
}

/** 只读查询（测试与诊断用；渲染请走 renderUsageFooter）。 */
export function usageFooterOf(taskId: string): Readonly<UsageFooterEntry> | undefined {
	return entries.get(taskId);
}

/** token 数格式：与 /amagi stats tok() 同口径（k 单位）；undefined → 「未知」（不补 0）。 */
function fmtTok(n: number | undefined): string {
	if (typeof n !== "number" || !Number.isFinite(n)) return "未知";
	return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(Math.round(n));
}

function fmtCalls(n: number | undefined): string {
	return typeof n === "number" && Number.isFinite(n) ? String(n) : "未知";
}

function figuresSegment(f: UsageFooterFigures): string {
	return `入 ${fmtTok(f.input)} 出 ${fmtTok(f.output)} 缓存读 ${fmtTok(f.cacheRead)} 缓存写 ${fmtTok(f.cacheWrite)} 调用 ${fmtCalls(f.calls)}`;
}

const RUNNING_LIKE = new Set(["running", "queued", "answering"]);

/**
 * 渲染 footer 一行。无已聚合终值时：终态任务显式「用量未知」（跨进程历史/未 spawn 早拒），
 * 运行中/未知任务返回空串（无账可示，不加噪音）。inline=true 供 wait/query 列表行（无前导换行）。
 */
export function renderUsageFooter(taskId: string, opts: { inline?: boolean } = {}): string {
	const lead = opts.inline ? "" : "\n";
	const e = entries.get(taskId);
	if (!e) {
		const rec = safeRecord(taskId);
		if (!rec || RUNNING_LIKE.has(String(rec.status))) return "";
		return `${lead}[子任务用量] 用量未知（本会话无该任务已聚合终值——跨进程历史或未 spawn 早拒路径）`;
	}
	const partialNote = (e.partialCoverage ? "；部分可见" : "") + (e.nested ? `；工具内嵌模型另计 ${figuresSegment(e.nested)}` : "");
	// 跨进程父链缺失优先呈现（合计不可信时不因 chainRuns=1 静默吞掉未知标注）
	if (!e.chainKnown) {
		return `${lead}[子任务用量] 本轮 ${figuresSegment(e.last)} ｜合计 未知（续接链跨进程历史不可得）${partialNote}`;
	}
	if (e.chainRuns > 1) {
		return `${lead}[子任务用量] 本轮 ${figuresSegment(e.last)} ｜合计(${e.chainRuns} 轮) ${figuresSegment(e.chain)}${partialNote}`;
	}
	const innerNote = e.internalRounds > 1 ? `（含自动续跑/修复 ${e.internalRounds} 轮，聚合恰一次）` : "";
	return `${lead}[子任务用量] ${figuresSegment(e.own)}${innerNote}${partialNote}`;
}

/** 测试隔离：清空登记（生产零调用）。 */
export function resetUsageFooterForTest(): void {
	entries.clear();
	anonSeq = 0;
}
