import { materializeSelectedEvidence } from "./dispatch-handoff.ts";
/**
 * task-background.ts — background 派发链（P3-C：2026-08-19 插件进化，第二/三批拆分自 task-tool.ts L1520-1661）。
 * 含 shouldAutoContinue 自动续跑门控 + runBackgroundTask（K5a 统一 submit 路径：冻结真实 TaskSpec → 内核
 * register（清单落盘成功）→ 共享准入 → grant-start（launchIntent 先于 spawn）→ 引擎启动；400 消息序自愈
 * 重派一轮、熔断/context 预算拒单）。引擎与共享助手来自 task-run.ts（单向依赖，禁止反向 import task-tool）。
 */
import * as fs from "node:fs";
import type { AgentConfig } from "./agents-loader.ts";
import { registry, type TaskStatus } from "./task-registry.ts";
import { resolveModel, normalizeModelSpec } from "./model-resolver.ts";
import { isProviderBreakerEnabled, providerBreakerCheck } from "./reliability.ts";
import { contextBudgetReject } from "./context-budget.ts";
import { tryOccupy, waitForGrant, release as releaseAdmission, cancelQueued } from "./admission.ts";
import { submitTaskKernel, grantStartTask } from "./task-service.ts";
import { releaseWorktreeLease } from "./worktree.ts";
import { authPreflight } from "./auth-preflight.ts";
import { journalDispatch } from "./journal.ts";
import { extractArtifactRefs, type ToolExecutionObservation } from "./task-jsonl.ts";
import { collectWorkspacePreflight, collectSiblingWriterLabels } from "./workspace-preflight.ts";
import { automaticVerificationEnabled } from "./agent-aliases.ts";
import { collectCrossSessionWriterLabels } from "./cross-session-writers.ts";
import { sessionRepairEnabled, isToolOrder400, repairSessionById, repairAction, transientRepairSummary, repairSummary, transientRetryDelayMs, TRANSIENT_400_NUDGE } from "./session-repair.ts";
// v2.15.0 大发射守卫 prompt 层：子进程 --append-system-prompt 末尾纪律分节（provider 命中才注入）
import { largeEmissionDisciplineLine } from "./large-emission-guard.ts";
import {
	genTaskId, writePromptTmp, providerOfSpec, resolveAgentTools, taskCategoryFor, fuseWarningFor,
	finalizeLaunchFailure, runPiTask, snapshotForPersist, hasDoneMarker,
	diagnoseCompletionContract, completionContractRepairNudge,
	planTaskPrompt, applyTaskPromptOffload, currentAssignmentBody, SHARED_TREE_DISCIPLINE,
	AMAGI_DONE_MARKER, EXECUTION_DISCIPLINE_REMINDER, DONE_CONTRACT_REMINDER,
	type RunResult, type BackgroundStart, type BackgroundOpts,
} from "./task-run.ts";

// ── background runBackgroundTask（调用 runPiTask background=true） ──

/** be7271（ev-20261020）：声明产物路径投影（outputs[].path）——终稿缺 ACHIEVEMENT 标题时
 *  告警定位声明报告中的合规段（与 sync 路径 deliverablePaths 同语义）。 */
function declaredOutputPathsOf(opts: { outputs?: ReadonlyArray<{ path: string }> }): readonly string[] | undefined {
	return opts.outputs && opts.outputs.length > 0 ? opts.outputs.map((o) => o.path) : undefined;
}

/**
 * v1.5.188 自动续跑门控：done 且未按完成契约结束的 work/expert 任务应续跑。
 * blocked/error/fast 型不续跑（blocked 由 Leader 回答；fast 型无契约要求）。
 */
export function shouldAutoContinue(agent: AgentConfig, rr: RunResult, opts?: { zeroOutputStreak?: number }): boolean {
	if (rr.status !== "done" || rr.blocked) return false;
	if (agent.type !== "work" && agent.type !== "expert") return false;
	// 8月迭代 F6c：doom-loop 终止不自动续跑——同 nudge 续跑大概率再 doom（纯烧 token）；
	// 终止注记已建议换模型/调任务，交回 Leader 决策。
	// 8月迭代 pi-0.84 配合 P1④：泛化为「任何 terminatedBy 终止轮都不自动续跑」——doom-loop
	// 之外，boundary-guard（硬边界终止：直接 resume 大概率再次触界）、settle-fallback（收口
	// 兕底：nudge 救不了句柄泄漏）、timeout/abort/cancel 同理：终止已是引擎层的明确裁决，
	// nudge 续跑只会重复烧 token，应交回 Leader 调整边界/任务书/模型后重新决策。
	if (rr.terminatedBy) return false;
	// 8月迭代 C2：续跑退避——上一续跑轮仍零产出（trim 后 <8 字符）时不再续（环境/模型侧问题非 nudge 可救）；
	// 非空宣告文本（如 early-stop 18 字符）不触发——那是模型早停，nudge 仍可能救回。
	if ((opts?.zeroOutputStreak ?? 0) >= 1) return false;
	return !hasDoneMarker(rr.output);
}
/**
 * ev-20261021-e476e9：后台路径交付前格式补正门控（纯函数）。根因：sync runTask 有完成契约续跑，
 * 后台（task_submit 主路径）只在事后挂告警——终稿结构缺陷（标题拼错/缺标题/空清单/marker 错位）
 * 全部落到 Leader 人工补判。这里复用同一诊断器给出定向补正指令；仅 work/expert、done 非 blocked、
 * 无引擎终止裁决/中止、有会话可续、终稿非零产出、末行契约已出现过（marker 缺失=早停，不归格式补正）。
 * 返回 null = 不补正。补正有界一次（调用方单次标志），AMAGI_AUTO_CONTINUE_ROUNDS=0 同步关闭。
 */
export function completionFormatRepairPlan(agentType: string | undefined, r: { status: TaskStatus; blocked: boolean; output: string; sessionId?: string; aborted?: boolean; terminatedBy?: string }): { cause: string; nudge: string } | null {
	if (r.status !== "done" || r.blocked || r.aborted || r.terminatedBy || !r.sessionId) return null;
	if (agentType !== "work" && agentType !== "expert") return null;
	if (Math.max(0, parseInt(process.env.AMAGI_AUTO_CONTINUE_ROUNDS ?? "2", 10) || 0) === 0) return null;
	if ((r.output || "").trim().length < 8 || hasDoneMarker(r.output)) return null;
	const diag = diagnoseCompletionContract(r.output);
	const nudge = completionContractRepairNudge(diag);
	return nudge && diag.cause ? { cause: diag.cause, nudge } : null;
}

/**
 * ev-20261021-e476e9（diting D-02）：格式补正轮结果裁决（纯函数）。补正轮只改结构，原终稿已 done；
 * 补正轮以 error 结束（含子进程启动失败——spawn 错误经 finalize 回调交回而非 reject）时不得把原
 * done 降级为 error、覆盖原终稿与原告警：按原终稿收口并追加补正失败注记。取消/中止/blocked 与
 * done 是补正轮的真实新事实，照常交付补正轮结果（不把取消误恢复为 done）。
 */
export function formatRepairRoundFailed(repair: { status: TaskStatus; aborted?: boolean; terminatedBy?: string }): boolean {
	return repair.status === "error" && !repair.aborted && repair.terminatedBy !== "cancel";
}

export function formatRepairOutcome<T extends { status: TaskStatus; output: string; sessionId?: string; errorMessage?: string; completionAnnotation?: string; aborted?: boolean; terminatedBy?: string }>(original: T, repair: T, fmtAnnotation: string): T {
	if (formatRepairRoundFailed(repair)) {
		const why = (repair.errorMessage || "未知错误").replace(/\s+/g, " ").slice(0, 200);
		return { ...original, completionAnnotation: `${original.completionAnnotation ? `${original.completionAnnotation}\n` : ""}[格式补正] 补正轮失败（${why}），按原终稿收口——原终态、原终稿与原告警保留` };
	}
	return { ...repair, sessionId: repair.sessionId ?? original.sessionId, completionAnnotation: `${fmtAnnotation}${repair.completionAnnotation ? `\n${repair.completionAnnotation}` : ""}` };
}

export async function runBackgroundTask(agent: AgentConfig, task: string, opts: BackgroundOpts): Promise<BackgroundStart | RunResult> {
	// ev-20260916-101d8a：链尽冷却重派复用冷却开始时建的占位记录（queued/cooldown）。
	const taskId = opts.preCreatedTaskId ?? genTaskId();
	const model = resolveModel(agent, { paramModel: opts.model, fallbackModel: opts.fallbackModel, cwd: opts.cwd });
	const sessionName = `${agent.name}-${taskId.slice(0, 8)}`;
	// v1.5.176: 派发前归一/校验（幂等；失败不建记录）
	const _nm = normalizeModelSpec(model, opts.modelRegistry);
	if (!_nm.ok) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model, errorMessage: _nm.error };
	const effModel = _nm.spec;
	if (isProviderBreakerEnabled()) {
		const _cbProvider = providerOfSpec(effModel);
		const _cb = providerBreakerCheck(_cbProvider);
		if (_cb.open && !_cb.probe) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: `[熔断] provider "${_cbProvider}" 连续 ${_cb.consecutiveFailures} 次瞬时故障，断路器 Open（约 ${Math.ceil((_cb.retryAfterMs ?? 0) / 1000)}s 后半窗探针自动恢复）。故障期盲派只会重复烧退避时间。建议：稍候重试 / 换其他 provider 模型 / AMAGI_CB_ENABLED=0 关闭熔断` };
	}
	// 2026-08-16 复盘 P0-2：background 派发前 context 预算预估（排队前拒单，不占槽不 spawn）。
	const _ctxReject = contextBudgetReject(task, effModel, opts.modelRegistry);
	if (_ctxReject) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _ctxReject };
	// 8月迭代 pi-0.84 配合 修复轮（Major-4）：auth 预检上移至准入占位/建档之前——fail-fast 失败
	// 不占并发槽、不留 error 记录（与上方 _ctxReject 同款「无建档无占槽」返回路径）。resume 由
	// task-resume 走 runPiTask 直连（不预检：会话模型首派发已验证）。opts.command（测试 fake
	// runner 注入）跳过：注入的 command 是脚本路径不是 pi。
	if (!opts.command) {
		try {
			await authPreflight(effModel);
		} catch (e) {
			const _authReject = e instanceof Error ? e.message : String(e);
			return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _authReject };
		}
	}
	// ── K5a 统一 submit 路径（方案 §3.5/§8.1-K5a；与 sync 共用——delivery 不分状态机，只影响 Leader 等待方式）──
	// 归一化输入 → 冻结真实 TaskSpec → 内核 register（saveSpec+current 清单落盘成功才继续）→ 共享准入
	// → grant-start（launchIntent 持久化先于 spawn）→ 引擎启动。清单失败封闭：明确错误返回，不占槽、不 spawn。
	const _subP = submitTaskKernel({
		taskId, agent: agent.name, assignment: task, goal: opts.description || opts.journalGoal || currentAssignmentBody(task), cwd: opts.cwd, model: effModel, mode: "background",
		name: opts.name, relation: opts.relation, allowedPaths: opts.allowedPaths,
		artifactRefs: extractArtifactRefs(currentAssignmentBody(task)), upstreamArtifactRefs: extractArtifactRefs(currentAssignmentBody(task)) || [],
		...(opts.contextMode !== undefined ? { contextMode: opts.contextMode } : {}),
		...(opts.outputs !== undefined ? { outputs: opts.outputs } : {}),
		...(opts.permission !== undefined ? { permission: opts.permission } : {}),
		...(opts.worktreeDispatch !== undefined ? { worktreeDispatch: opts.worktreeDispatch } : {}),
		...(opts.preCreatedTaskId === taskId ? { reuseQueued: true } : {}),
	});
	// 内核 register 同步前缀已建档——定格登记时刻 revision 作 dispatch stale 基线（store 提交等待窗口内的
	// 取消会 bump revision，但不得改写本值；与旧「create 后即捕获」语义一致）。
	const dispatchRevision = registry.get(taskId)?.revision ?? 0;
	const _sub = await _subP;
	if (!_sub.ok) {
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _sub.message };
	}
	// P0.5：派发 journal 落盘（background 同样留痕；goal 用原始任务书——见 BackgroundOpts.journalGoal）。
	// ev-20260916-101d8a：冷却占位重派（preCreatedTaskId）在占位建档时已留痕，不重复 journal。
	if (opts.preCreatedTaskId !== taskId) {
		journalDispatch({ taskId, agent: agent.name, name: opts.name, goal: opts.journalGoal ?? task, cwd: opts.cwd || process.cwd(), mode: "background", model: effModel, ...opts.relation });
	}
	const complete = opts.onFinalize ?? opts.onComplete;
	const deliverComplete: NonNullable<BackgroundOpts["onComplete"]> = (r) => {
		// 逻辑终态先释放，再进入任何消费者收尾（不在 auto-repair 中间轮释放）。
		if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, `background ${r.status}`, taskId);
		complete?.(r);
	};
	// v2 批次B 共享准入（K5a：清单落盘成功后才占槽——按 effModel 的 provider/model 分池）；
	// queued → 立即返回排队 handle + 异步等晋级后启动；任务全程（含自动续跑各轮）只占一槽。
	const _occ = tryOccupy(taskId, { modelSpec: effModel, cwd: opts.cwd });
	// K5a 窗口防护：清单落盘（异步 store 提交）与占位之间被取消——记录已 cancelled 时不入队等待/不 spawn，
	// 出队 + 归还槽位 + 交付 cancelled（文案与旧同步路径两分支一致：排队中/启动前）。
	if (registry.get(taskId)?.status === "cancelled") {
		const _cancelMsg = _occ === "queued" ? "任务在排队等待执行槽位时被取消" : "任务在启动前被取消";
		if (_occ === "queued") cancelQueued(taskId);
		releaseAdmission(taskId);
		deliverComplete?.({ taskId, agent: agent.name, status: "cancelled", output: "", blocked: false, errorMessage: _cancelMsg, completionAnnotation: "", dispatchRevision });
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _cancelMsg, completionAnnotation: "", dispatchRevision };
	}
	const _cat = taskCategoryFor(opts.description, currentAssignmentBody(task));
	const _fuse = fuseWarningFor(agent.name, effModel, _cat);
	const _baselineRefs = extractArtifactRefs(currentAssignmentBody(task)) || [];
	// 启动闭包：args/prompt tmp 在晋级时刻构建（排队期间不落盘临时文件、不占用资源）。
	// F5（diting，附录 B.1）：preflight 字节数提升到闭包层（runPiTask opts 在 try 外消费；
	// 启动失败时为 0——不虚假归因未发生的注入）。
	let _preflightBytes = 0;
	const _launch = async (): Promise<BackgroundStart | RunResult> => {
		const tools = resolveAgentTools(agent, opts.cwd);
		const args = ["--mode", "json", "-p", "--name", sessionName];
		if (effModel) args.push("--model", effModel);
		args.push("--tools", tools.join(","));
		let tmpDir: string | null = null, tmpFile: string | null = null;
		try {
			// v2.15.0 大发射守卫 · prompt 层（与 sync runTask 同款）：effModel 的 provider 命中
			// riskyProviders 时在子进程 system prompt 末尾追加大发射纪律分节（maxBytes 动态渲染）；
			// 不命中零注入零字节。工具层硬闸在 write/edit-override（子进程内生效）。
			const _emissionLine = largeEmissionDisciplineLine(providerOfSpec(effModel), opts.cwd);
			const _systemPrompt = _emissionLine ? `${agent.systemPrompt}\n\n## 大发射纪律（通道适配）\n${_emissionLine}` : agent.systemPrompt;
			if (_systemPrompt.trim()) { const tmp = await writePromptTmp(agent.name, _systemPrompt); tmpDir = tmp.dir; tmpFile = tmp.file; args.push("--append-system-prompt", tmpFile); }
			// ev-20261001-4f2a9c：同 cwd 并行归因补齐（与 sync runTask 同款）——会话内兄弟 + 跨会话任务。
			const _regRecs = registry.list();
			// ev-20261013（设计 §5.3/§9.3）：background 补自动收尾行——autoVerify 按 sync 同一公式
			//（task-tool.ts autoVerify 计算处；BackgroundOpts 无 verification 测试注入面，归约为 !opts.command）。
			// 门控核对（§11.3 真值表）：background 编码任务结算时经 finalizer autoDetect
			//（shouldGatherEvidence + trusted + detectTestCommand，与 sync 同一代码路径）真实安排基线；
			// 无自动修复轮（sync 独有的 runBaselineVerification 预跑+修复循环不在 background 链）——文案如实投影。
			const preflight = collectWorkspacePreflight(opts.cwd, currentAssignmentBody(task), {
				trusted: !opts.command && opts.trusted,
				autoVerify: !opts.command && automaticVerificationEnabled(agent.name, opts.trusted),
				delivery: "background",
				siblingWriters: collectSiblingWriterLabels(opts.cwd, taskId, _regRecs),
				foreignWriters: collectCrossSessionWriterLabels(opts.cwd, [taskId, ..._regRecs.map((r) => r.taskId)]),
			});
			_preflightBytes = preflight.text ? Buffer.byteLength(preflight.text, "utf8") : 0;
			// ev-20260914-ce6bd2：background 同款超长任务书 argv 降级 + E2BIG 硬上限（与 sync runTask/resume 同一防线）。
			const _finalPrompt = `${materializeSelectedEvidence(task, opts.cwd, taskId).trimEnd()}${preflight.text ? `\n\n${preflight.text}` : ""}${SHARED_TREE_DISCIPLINE}${DONE_CONTRACT_REMINDER}`;
			const _pp = planTaskPrompt(_finalPrompt, opts.cwd, taskId);
			if (_pp.action === "reject") {
				return finalizeLaunchFailure(taskId, agent, sessionName, _pp.reason ?? "任务书超硬上限", (r) => {
					releaseAdmission(taskId);
					deliverComplete?.(r);
				});
			}
			if (_pp.action === "offload") {
				try { applyTaskPromptOffload(_pp, _finalPrompt); } catch (e) {
					return finalizeLaunchFailure(taskId, agent, sessionName, `任务书落盘降级失败: ${String(e)}`, (r) => {
						releaseAdmission(taskId);
						deliverComplete?.(r);
					});
				}
				args.push(_pp.prompt);
			} else {
				args.push(_finalPrompt);
			}
		} catch (e) {
			return finalizeLaunchFailure(taskId, agent, sessionName, `prompt tmp 失败: ${String(e)}`, (r) => {
				releaseAdmission(taskId);
				deliverComplete?.(r);
			});
		}
		// 2026-08-16 复盘 P0-1：background 400 tool 消息序自愈。onFinalize 是 close 单次回调，
		// 不能在回调内同步再跑同 taskId（槽位已归还、once 守卫）。策略：命中 400 签名且可修复时，
		// 回调内不释放槽/不交付，改为异步生成恢复副本 + 重派一轮（同 taskId、新进程）；修复失败或
		// 第二次仍 400 才真正收口（有界一次；fresh 后再 400 通常是新写入损坏，交回 Leader）。
		let _toolOrderRetried = false;
		let _formatRepaired = false;
		const onFinalizeWithRepair = (r: { taskId: string; agent: string; status: TaskStatus; output: string; blocked: boolean; blockReason?: "questions" | "needs-handoff"; errorMessage?: string; sessionId?: string; model?: string; completionAnnotation?: string; dispatchRevision?: number; /** ev-20260910-8fbe4e（C）：连接类中断现场报告（仅 error+providerError 终态携带）。 */ interruptionReport?: string; /** F5（diting，附录 B.1）：本轮运行标识与工具观测（payload 重建时透传）。 */ runKey?: string; _toolExecutions?: ReadonlyArray<ToolExecutionObservation>; /** pi 1.1.0 S2-B2：宿主/控制面中止事实——抑制自动修复重派（与 task-tool.ts runTask 同款口径）。 */ aborted?: boolean }): void => {
			if (r.status === "error" && !r.aborted && r.sessionId && !_toolOrderRetried
					&& Math.max(0, parseInt(process.env.AMAGI_SESSION_REPAIR_ROUNDS ?? "1", 10) || 0) > 0
					&& sessionRepairEnabled() && isToolOrder400(r.errorMessage || "")) {
				const repair = repairSessionById(r.sessionId, { cwd: opts.cwd });
				// 2026-08-19 实测：零修正项=当前投影未发现错误、可能是 provider 端瞬时误拒，同样原地重试一轮
				const action = repairAction(repair);
				if (action !== "none") {
					_toolOrderRetried = true;
					const repairAnnotation = action === "transient-retry" ? transientRepairSummary() : repairSummary(repair);
					void (async () => {
						try {
							if (action === "transient-retry") {
								const delay = transientRetryDelayMs();
								if (delay > 0) await new Promise((res) => setTimeout(res, delay));
							}
							const repairNote = action === "transient-retry"
								? TRANSIENT_400_NUDGE
								: repairSummary(repair);
							const nudge = `${EXECUTION_DISCIPLINE_REMINDER}\n\n${repairNote}请继续完成原任务：已完成的步骤无需重做，按完成契约输出 ACHIEVEMENT 与末行 ${AMAGI_DONE_MARKER}。`;
							const resumeArgs = ["--session", repair.recoveryFile ?? r.sessionId!, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
							registry.reopenForAutoContinue(taskId, { allowError: true });
							await runPiTask(agent, resumeArgs, { cwd: opts.cwd, model: effModel, timeoutMs: opts.timeoutMs, command: opts.command, background: true, onStall: opts.onStall, dispatchTime: Date.now(), dispatchRevision, taskCategory: _cat, baselineArtifactRefs: _baselineRefs, fuseWarn: _fuse, protectedPaths: opts.protectedPaths, allowedPaths: opts.allowedPaths, declaredOutputPaths: declaredOutputPathsOf(opts), onFinalize: (r2) => {
								releaseAdmission(taskId);
								snapshotForPersist(undefined);
								deliverComplete?.({ taskId: r2.taskId, agent: r2.agent, status: r2.status, output: r2.output, blocked: r2.blocked, blockReason: r2.blockReason, errorMessage: r2.errorMessage, sessionId: r2.sessionId, model: r2.model, dispatchRevision: r2.dispatchRevision, completionAnnotation: ((r2.completionAnnotation ? `${r2.completionAnnotation}\n` : "") + repairAnnotation), interruptionReport: r2.interruptionReport, runKey: r2.runKey, _toolExecutions: r2._toolExecutions });
								if (tmpFile) try { fs.unlinkSync(tmpFile); } catch {}
								if (tmpDir) try { fs.rmdirSync(tmpDir); } catch {}
							} }, taskId, sessionName);
						} catch {
							// 重派启动失败：按原终态收口（错误现场不丢）
							releaseAdmission(taskId);
							snapshotForPersist(undefined);
							deliverComplete?.({ ...r, completionAnnotation: ((r.completionAnnotation ? `${r.completionAnnotation}\n` : "") + repairAnnotation) });
							if (tmpFile) try { fs.unlinkSync(tmpFile); } catch {}
							if (tmpDir) try { fs.rmdirSync(tmpDir); } catch {}
						}
					})();
					return; // 延迟收口：本轮不释放/不交付，交由重派轮的 onFinalize 收口
				}
			}
			// ev-20261021-e476e9：交付前定向格式补正（有界一次；原稿保留于同一会话历史，注记留痕）。
			const _fmt = !_formatRepaired ? completionFormatRepairPlan(agent.type, r) : null;
			if (_fmt) {
				_formatRepaired = true;
				const fmtAnnotation = `[格式补正] 原终稿完成契约缺陷=${_fmt.cause}，已在同一会话定向补正 1 轮（只校结构；原稿保留于会话历史 session=${r.sessionId}）`;
				void (async () => {
					try {
						const nudge = `${_fmt.nudge}\n\n${EXECUTION_DISCIPLINE_REMINDER}`;
						const resumeArgs = ["--session", r.sessionId!, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
						registry.reopenForAutoContinue(taskId);
						await runPiTask(agent, resumeArgs, { cwd: opts.cwd, model: effModel, timeoutMs: opts.timeoutMs, command: opts.command, background: true, onStall: opts.onStall, dispatchTime: Date.now(), dispatchRevision, taskCategory: _cat, baselineArtifactRefs: _baselineRefs, fuseWarn: _fuse, protectedPaths: opts.protectedPaths, allowedPaths: opts.allowedPaths, declaredOutputPaths: declaredOutputPathsOf(opts), onFinalize: (r2) => {
							const outcome = formatRepairOutcome(r, r2, fmtAnnotation);
							if (formatRepairRoundFailed(r2)) {
								// D-02：补正轮已把 registry 写成 error——恢复原 done 终态与原终稿（与回流同一事实）。
								// 同 task-tool 交付物预检回写口径：受控重开后 patch 终态。
								try {
									registry.reopenForAutoContinue(taskId, { allowError: true });
									registry.patch(taskId, { status: "done", result: r.output, sessionId: r.sessionId, ...(r.model ? { model: r.model } : {}), completionAnnotation: outcome.completionAnnotation });
								} catch { /* lint-exempt:registry 回写尽力而为——回流结果已按原终稿收口 */ }
							}
							onFinalizeWithRepair(outcome);
						} }, taskId, sessionName);
					} catch { /* lint-exempt:补正轮启动失败→按原终态收口（原稿与原告警不丢） */
						onFinalizeWithRepair({ ...r, completionAnnotation: `${r.completionAnnotation ? `${r.completionAnnotation}\n` : ""}[格式补正] 补正轮启动失败，按原终稿收口` });
					}
				})();
				return; // 延迟收口：交由补正轮回调（再经本函数，_formatRepaired 已置位不再补正）
			}
			// 常规收口（含修复失败/重派后仍 400：finalErrorMessage 已带定向提示）
			releaseAdmission(taskId); // v2 批次B：终局归还槽位（含 cancelled 前置路径）——finalize once 守卫保证恰好一次
			snapshotForPersist(undefined); // snapshot 在 execute 层传 pi；此处仅做内部清理
		// v1.5.222：sessionId/model 必须透传——后台任务的 artifact 落盘链（execute onComplete →
			// finalizeTerminal）消费本回调；旧代码重建对象时丢字段，实战 cbc75699/bd35699f 等
			// 全部后台任务的 metadata.json 缺 sessionId（跨 Leader 重启 resume 只能靠目录扫描兑底）。
				deliverComplete?.({ taskId: r.taskId, agent: r.agent, status: r.status, output: r.output, blocked: r.blocked, blockReason: r.blockReason, errorMessage: r.errorMessage, sessionId: r.sessionId, model: r.model, completionAnnotation: r.completionAnnotation, dispatchRevision: r.dispatchRevision, interruptionReport: r.interruptionReport, runKey: r.runKey, _toolExecutions: r._toolExecutions });
			if (tmpFile) try { fs.unlinkSync(tmpFile); } catch {}
			if (tmpDir) try { fs.rmdirSync(tmpDir); } catch {}
		};
		const start = await runPiTask(agent, args, { cwd: opts.cwd, model: effModel, timeoutMs: opts.timeoutMs, command: opts.command, background: true, onStall: opts.onStall, dispatchTime: Date.now(), dispatchRevision, taskCategory: _cat, baselineArtifactRefs: _baselineRefs, fuseWarn: _fuse, protectedPaths: opts.protectedPaths, allowedPaths: opts.allowedPaths, declaredOutputPaths: declaredOutputPathsOf(opts), preflightBytes: _preflightBytes, onFinalize: onFinalizeWithRepair }, taskId, sessionName);
		return start;
	};
	if (_occ === "queued") {
		// 排队态：立即返回排队 handle（execute 透出排队语义）；晋级后异步启动，同 taskId 全程一槽。
		void waitForGrant(taskId).then(async (grant) => {
			const rec = registry.get(taskId);
			if (grant !== "running" || !rec || rec.status === "cancelled") {
				releaseAdmission(taskId);
				deliverComplete?.({ taskId, agent: agent.name, status: "cancelled", output: "", blocked: false, errorMessage: "任务在排队等待执行槽位时被取消", completionAnnotation: "", dispatchRevision });
				return;
			}
			// K5a：晋级 = 内核 grant-start 命令（launchIntent 先于 spawn 持久化）；失败封闭（不 spawn，槽位回收）
			const gs = await grantStartTask(taskId);
			if (!gs.ok) {
				releaseAdmission(taskId);
				deliverComplete?.({ taskId, agent: agent.name, status: "cancelled", output: "", blocked: false, errorMessage: `任务晋级启动失败（未 spawn）：${gs.message}`, completionAnnotation: "", dispatchRevision });
				return;
			}
			try { registry.patch(taskId, { queueMs: Date.now() - (rec.queuedAt || Date.now()), queueReason: "capacity" }); } catch { /* 展示字段失败不阻断启动 */ }
			await _launch();
		}).catch((e) => {
			releaseAdmission(taskId);
			if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, "background queued launch exception", taskId);
			finalizeLaunchFailure(taskId, agent, sessionName, `排队后启动异常: ${String(e)}`, deliverComplete);
		});
		return { taskId, agent: agent.name, status: "queued", sessionName, fuseWarning: _fuse };
	}
	// 立即占槽：launchIntent 先持久化（§3.5）再启动；失败封闭（不 spawn，槽位回收）。
	// ev-20260916-101d8a：冷却占位记录（queued/cooldown）复用同路径晋级（queueMs 含冷却等待；取消竞态由内核 grant 拒绝非 queued 收口）。
	const _gs = await grantStartTask(taskId);
	if (!_gs.ok) {
		releaseAdmission(taskId);
		if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, "background grant-start rejected", taskId);
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: `[submit 拒绝] 启动意图持久化失败（未 spawn）：${_gs.message}` };
	}
	{ const _qRec = registry.get(taskId); if (_qRec?.queuedAt) { try { registry.patch(taskId, { queueMs: Date.now() - _qRec.queuedAt }); } catch {} } }
	return _launch();
}
