/**
 * 原生 MCP 适配：pi 拥有连接、认证、发现与退出收尾；amagi 仅保留路由、授权与兼容工具入口。
 * 原生文件不重复注册；旧配置通过公开 registerMcpServer 进入宿主，禁止另开 transport。
 */
import type { ExtensionAPI, McpServerConfig as HostMcpServerConfig } from "@earendil-works/pi-coding-agent";
import { Type, type Static } from "typebox";
import { checkMcpCallPermission, describeMcpRouteDenial, loadMcpServerConfigs, type McpPermission, type McpRouteIdentity, type McpServerConfig } from "./mcp-config.ts";
import { McpCallOutputSchema, McpListOutputSchema, toMcpCallErrorWire, toMcpCallResultWire, toMcpListResultWire, toMcpListErrorWire } from "./mcp-wire.ts";
import { withArgumentArtifactNormalization } from "./tool-result-adapter.ts";

export interface NativeMcpOptions {
	cwd: string;
	onlyServers?: string[];
	permission?: McpPermission;
	/** ev-20261019-a50ce4：路由身份——仅用于路由拒绝的可行动说明（当前路由键/server 所在路由/修复键与生效时机）。 */
	route?: McpRouteIdentity;
}

const CallParams = Type.Object({
	server: Type.String({ description: "pi MCP server 名。连接、认证与工具名称由原生 /mcp 管理。" }),
	tool: Type.String({ description: "原生 MCP 工具的工具段；冻结授权下不猜测复杂或带 hash 的名称。" }),
	arguments: Type.Optional(Type.Record(Type.String(), Type.Any(), { description: "业务参数；完整原样交给原生工具。" })),
});
const ListParams = Type.Object({ server: Type.Optional(Type.String()) });
const canonical = (name: string) => name.replace(/-/g, "_");
const asWireContent = (wire: unknown) => wire as never;

export function registerNativeMcpTools(pi: ExtensionAPI, opts: NativeMcpOptions) {
	const owned = new Set<string>();
	let projectTrusted = false;
	let cwd = opts.cwd;
	// 在凭据包清除前完成兼容来源解析；原生文件的凭据始终由宿主惰性解析。
	let loaded = loadMcpServerConfigs(cwd);
	let configs = loaded.servers;
	const routeAllows = (server: string) => !opts.onlyServers || opts.onlyServers.some((name) => name === "*" || canonical(name) === canonical(server));
	const routeDenial = (server: string) => `server 未在当前路由中 (${server})${opts.route ? `——${describeMcpRouteDenial(cwd, server, opts.route)}` : ""}`;
	const scoped = () => Object.values(configs).filter((config) => (!config.projectSource || projectTrusted) && routeAllows(config.name));
	/** 配置来源诊断：仅报告与当前路由相关的告警 + 因项目未受信而跳过的项目级 server。 */
	const configDiagnostics = (): string[] => {
		const notes = loaded.warnings.filter((w) => !w.server || routeAllows(w.server)).map((w) => `${w.file}${w.server ? ` [${w.server}]` : ""}：${w.message}`);
		const skipped = Object.values(configs).filter((config) => config.projectSource && !projectTrusted && routeAllows(config.name));
		if (skipped.length > 0) notes.push(`项目未受信，已跳过项目级 MCP server：${skipped.map((config) => `${config.name}（${config.source}）`).join("、")}；授予项目信任后重启或 /reload 生效`);
		return notes;
	};
	const registerCompat = (config: McpServerConfig) => {
		if (config.nativeManaged || owned.has(config.name) || !config.nativeConfig) return;
		// 宿主已有同名扩展注册时不接管它；file-configured server 由 pi 原生优先级管理。
		if (pi.getMcpServers().some((server) => canonical(server.name) === canonical(config.name))) return;
		try {
			pi.registerMcpServer(config.name, config.nativeConfig as unknown as HostMcpServerConfig);
			owned.add(config.name);
		} catch (e) { console.warn(`[amagi-mcp] 兼容配置注册失败 (${config.name}): ${e instanceof Error ? e.message : String(e)}`); }
	};
	for (const config of scoped()) if (!config.projectSource) registerCompat(config);
	pi.on("session_start", (_event, ctx) => {
		if (cwd !== ctx.cwd || (projectTrusted && !ctx.isProjectTrusted())) close();
		if (cwd !== ctx.cwd) { cwd = ctx.cwd; loaded = loadMcpServerConfigs(cwd); configs = loaded.servers; }
		projectTrusted = ctx.isProjectTrusted();
		for (const config of scoped()) registerCompat(config);
		// 配置来源问题（JSON 解析失败、变量未设置、项目未受信而被跳过）此前静默丢弃，用户只看到「没加载」。
		const notes = configDiagnostics();
		if (notes.length > 0) {
			const text = `[amagi-mcp] MCP 配置未完全生效：\n${notes.map((line) => `- ${line}`).join("\n")}`;
			try { if (ctx.hasUI) ctx.ui.notify(text, "warning"); else console.warn(text); } catch { /* lint-exempt:通知失败不影响装配 */ }
		}
	});
	const close = () => {
		for (const name of owned) try { pi.unregisterMcpServer(name); } catch { /* lint-exempt:宿主 reload 已移除时幂等 */ }
		owned.clear();
	};
	pi.on("session_shutdown", close);
	const toolParts = (tool: ReturnType<ExtensionAPI["getAllTools"]>[number]) => {
		const namespace = tool.namespace?.name;
		if (!namespace?.startsWith("mcp__")) return undefined;
		const server = namespace.slice(5);
		const prefix = `${namespace}__`;
		if (!tool.name.startsWith(prefix)) return undefined;
		return { server, tool: tool.name.slice(prefix.length) };
	};
	const fail = (server: string, tool: string, message: string, code: "permission" | "internal" = "permission") => ({
		content: [{ type: "text" as const, text: `[amagi-mcp] ${message}` }], isError: true, details: undefined,
		structuredContent: asWireContent(toMcpCallErrorWire({ server, tool, error: { code, message, repairExamples: [{ server, tool, arguments: {} }] } })),
	});
	pi.registerTool({
		name: "mcp_call", label: "MCP Call",
		description: "兼容 MCP 调用入口，委托 pi 原生工具与权限管线；连接/认证/发现由原生 /mcp 管理。业务字段全部放入 arguments。工具尚未连接时用 /mcp 查看状态；复杂名称由原生入口处理，冻结授权仍须可信名称映射。",
		parameters: CallParams, outputSchema: McpCallOutputSchema,
		async execute(_id, p: Static<typeof CallParams>, signal, onUpdate, ctx) {
			if (!routeAllows(p.server)) return fail(p.server, p.tool, `权限拒绝：${routeDenial(p.server)}`);
			const name = `mcp__${canonical(p.server)}__${p.tool}`;
			if (!/^[A-Za-z0-9_]+$/.test(p.tool) || /_[0-9a-f]{8}$/.test(p.tool) || name.length > 64) {
				return fail(p.server, p.tool, "缺少原始工具名称映射，不能猜测宿主转换/hash 名称；冻结授权须有可信名称映射，或在明确禁用原生 MCP 后用兼容后端。");
			}
			const registered = pi.getAllTools().find((tool) => tool.name === name && toolParts(tool)?.server === canonical(p.server));
			const decision = checkMcpCallPermission(opts.permission, p.server, p.tool, () => registered?.annotations?.readOnlyHint === true ? "read-only" : "unknown");
			if (!decision.allowed) return fail(p.server, p.tool, `权限拒绝：${decision.reason}`);
			if (!registered || registered.exposure === "hidden") return fail(p.server, p.tool, "原生工具尚未连接或已被隐藏/禁用；用 /mcp 查看状态或原生 codemode 等待发现。本入口不会另开连接。", "internal");
			try {
				// 同一个宿主执行事件链保留参数验证、嵌套调用、授权、图片和输出截断语义。
				const outcome = await ctx.executeTool(name, p.arguments ?? {}, { signal, onUpdate });
				const result = outcome.result;
				const text = result.content.filter((block) => block.type === "text").map((block) => block.text).join("\n");
				const remote = result.structuredContent as { structuredContent?: unknown } | undefined;
				const dumpPath = (result.details as { fullOutputPath?: string } | undefined)?.fullOutputPath;
				const payload = { text, images: result.content.filter((block) => block.type === "image"), textTruncated: !!dumpPath, textDumpPath: dumpPath, structuredContent: remote?.structuredContent, remoteOutputSchema: false };
				if (outcome.isError || result.isError) return { ...result, isError: true, structuredContent: asWireContent(toMcpCallErrorWire({ server: p.server, tool: p.tool, error: { code: remote ? "remote" : "internal", message: text }, remoteResult: remote ? payload : undefined })) };
				return { ...result, structuredContent: asWireContent(toMcpCallResultWire({ server: p.server, tool: p.tool, ...payload })) };
			} catch (e) {
				return fail(p.server, p.tool, e instanceof Error ? e.message : String(e), "internal");
			}
		},
	});
	pi.registerTool(withArgumentArtifactNormalization({
		name: "mcp_list_tools", label: "MCP List Tools",
		description: "列出 pi 当前注册的 MCP 工具与授权内参数；不新建连接、不读取旧发现缓存。连接/认证状态用原生 /mcp 查看。",
		parameters: ListParams, outputSchema: McpListOutputSchema,
		async execute(_id: string, p: Static<typeof ListParams>) {
			try {
				if (p.server && !routeAllows(p.server)) throw new Error(routeDenial(p.server));
				const groups = new Map<string, Array<{ name: string; description: string; inputSchema: unknown; annotations?: unknown }>>();
				for (const config of scoped()) if (!p.server || canonical(config.name) === canonical(p.server)) groups.set(config.name, []);
				for (const tool of pi.getAllTools()) {
					const parts = toolParts(tool);
					if (!parts || tool.exposure === "hidden" || !routeAllows(parts.server) || (p.server && canonical(parts.server) !== canonical(p.server))) continue;
					const decision = checkMcpCallPermission(opts.permission, parts.server, parts.tool, () => tool.annotations?.readOnlyHint === true ? "read-only" : "unknown");
					if (!decision.allowed || (opts.permission && /_[0-9a-f]{8}$/.test(parts.tool))) continue;
					const server = [...groups.keys()].find((name) => canonical(name) === canonical(parts.server)) ?? parts.server;
					if (!groups.has(server)) groups.set(server, []);
					groups.get(server)!.push({ name: parts.tool, description: tool.description, inputSchema: tool.parameters, annotations: tool.annotations });
				}
				const data = [...groups].filter(([server]) => !opts.permission || opts.permission.allow.some((grant) => grant.server === "*" || canonical(grant.server) === canonical(server)))
					.map(([name, tools]) => ({ name, status: tools.length ? "live" as const : "error" as const, observedAt: null, tools, error: tools.length ? null : "原生工具尚未可见；用 /mcp 查看连接、禁用与授权状态。" }));
				const diag = configDiagnostics();
				const diagText = diag.length > 0 ? `\n\n## 配置来源诊断\n${diag.map((line) => `- ${line}`).join("\n")}` : "";
				const text = data.map((server) => `## ${server.name}: pi 原生 MCP\n${server.tools.map((tool) => `- ${tool.name}: ${tool.description}`).join("\n") || server.error}`).join("\n\n") || "（没有当前授权内可见的 pi 原生 MCP 工具；用 /mcp 查看状态）";
				const fullText = text + diagText;
				return { content: [{ type: "text" as const, text: fullText }], details: undefined, structuredContent: asWireContent(toMcpListResultWire({ servers: data })) };
			} catch (e) {
				const message = e instanceof Error ? e.message : String(e);
				return { content: [{ type: "text" as const, text: message }], isError: true, details: undefined, structuredContent: asWireContent(toMcpListErrorWire({ error: { code: "internal", message } })) };
			}
		},
	}));
	return { servers: scoped().map((config) => config.name), close };
}
