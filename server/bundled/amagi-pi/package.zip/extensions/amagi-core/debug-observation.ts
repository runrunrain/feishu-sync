/**
 * debug-observation.ts — ev-20260926-bc6ba3（R5）：bash 真实输出轻量观测原语（会话内存 collector）。
 *
 * 定位（修复方案 §③，主上已授权能力边界）：只采集「命令真实最终输出」的生命周期观测——
 *  采集（bash debugTag 参数 / 会话默认标签）、标签聚合、静默（off/clear/generation 失效）、
 *  生命周期清理（会话切换/重载/退出释放内存）。替代手工 console.log 探针的增删清理损耗。
 *
 * 能力边界（不可静默缩水或扩张）：
 *  - 不能读取无输出的程序内部局部变量；不替代通用 debugger；不新增自动源码插桩/断点执行/
 *    语言 preload。需要观察内部值 → 用应用已有日志/调试接口或临时复现脚本。
 *  - 不新增全局 debug 环境变量接口（父子进程环境不一致歧义；env-knobs 零新增）；本模块零 env
 *    读取（唯一例外：AMAGI_TASK_ID 取子代理任务标注——既有注入变量，非新开关，不进 env-knobs）。
 *  - 不承诺跨进程查子进程缓冲：collector 是进程内会话内存态（Leader 与各子代理进程各自独立）。
 *  - 第一版只采最终输出（完成/失败时一次性记录，不累计 onUpdate partial）；无运行中 streaming 聚合。
 *  - debug 不授予 bash：采集参数寄生在已注册的 bash 工具上，shell=deny 角色本无 bash 即无此面。
 *
 * 语义（冻结）：
 *  - 初始态 = 无默认标签、未 muted（与 off 后的 muted 态分开存储）。
 *  - /amagi debug on <tag>：设会话默认标签并解除静默；单次调用显式 debugTag 参数优先于默认标签。
 *  - /amagi debug off：清默认标签并置 muted——后续显式 debugTag 也不采集，直到 on；generation++。
 *  - /amagi debug clear：清空缓冲（默认标签/静默位不动）；generation++——迟到旧工具结果不回填
 *    已清缓冲；不删项目文件/原生临时输出文件（fullOutputPath 属原生产物，clear 不触碰）。
 *  - 上限：256 事件 / 总 256KiB（按事件 text 字节计）/ 单事件 8KiB，超限旧端淘汰，统计 retained/
 *    dropped/truncated 如实透出（show 展示真实 dropped，不美化）。
 *  - 事件 stream 恒 "combined"：原生 bash 输出为 stdout+stderr 合并流，不伪称仅 stdout。
 *
 * P9（寄生设计 §5.3）：provider 流事件受控诊断——同一会话生命周期（generation/clear/reset 共轴）下的
 *  独立 opt-in 白名单元数据采集（/amagi debug provider on|off|clear|show；默认关，不随 bash 采集开关）。
 *  白名单只含 provider/api/model、流事件类型分类、回合序号、时间与计数；错误只留归一分类 token。
 *  原始 token/内容/usage/headers/raw data 一律不读（classifyProviderStreamData 只取枚举形状字段并经
 *  字符集+凭据形状双重净化）；零内容零凭据落缓冲。订阅常驻但未开启时零记录零开销。
 *
 * 依赖纪律：零 import（纯内存模块，无 registry/TaskStore/fs/pi 依赖）——K8c 观察面门禁天然满足。
 */

// ── 常量（采集上限；纯内存无文件副作用） ─────────────────────────────────────

export const DEBUG_MAX_EVENTS = 256;
export const DEBUG_MAX_TOTAL_BYTES = 256 * 1024;
export const DEBUG_MAX_EVENT_BYTES = 8 * 1024;
/** /amagi debug show 缺省展示最近条数。 */
export const DEBUG_SHOW_DEFAULT_LIMIT = 32;
/** 结果尾部聚合摘要上限（bash-override 附注通道，逐行加标签）。 */
export const DEBUG_SUMMARY_MAX_BYTES = 4 * 1024;
/** 摘要含该标签最近事件条数（新→旧）。 */
export const DEBUG_SUMMARY_EVENT_LIMIT = 16;
const DEBUG_SUMMARY_PREVIEW_CHARS = 200;
const DEBUG_SHOW_PREVIEW_CHARS = 800;

// ── P9 常量：provider 流诊断采集上限（元数据事件极小，条数为主 + 估算字节双上限防御） ──

/** provider 观测事件环形缓冲条数上限（超限旧端淘汰，dropped 如实计数）。 */
export const DEBUG_PROVIDER_MAX_EVENTS = 256;
/** provider 观测估算字节总量上限（按事件字符串字段长度估算）。 */
export const DEBUG_PROVIDER_MAX_TOTAL_BYTES = 64 * 1024;
/** 聚合计数 Map 键数上界（类型/模型/回合三类计数共用；超出淘汰计数最小键——基数防御）。 */
export const DEBUG_PROVIDER_AGGREGATE_KEYS = 128;

/** 流事件类型/错误分类 token：枚举形状（anthropic type / openai object / finish_reason / error.type）。 */
const STREAM_TOKEN_RE = /^[A-Za-z0-9_.:-]{1,64}$/;
/** 凭据形状拒绝（防御纵深：即使白名单字段本身呈凭据形状也不落缓冲）。 */
const CREDENTIAL_SHAPE_RE = /(sk|rk|pk|ak|ghp|gho|xox[baprs])-?[A-Za-z0-9_-]{8,}|bearer|authori[sz]ation|api[-_]?key|api[-_]?secret|secret|passwd|password|credential|private[-_]?key/i;
/** 高熵连续字母数字（≥20 位）视为潜在密钥片段，拒收。 */
const HIGH_ENTROPY_RE = /[A-Za-z0-9]{20}/;

/** 合法标签：1-64 位 ASCII [A-Za-z0-9._-]（禁控制符/路径/表达式）。 */
export const DEBUG_TAG_RE = /^[A-Za-z0-9._-]{1,64}$/;

/** 标签校验（bash 参数拒绝与 /amagi debug on 共用同一口径；"."/".." 为路径语义，拒收）。 */
export function debugTagValid(tag: unknown): tag is string {
	if (typeof tag !== "string" || !DEBUG_TAG_RE.test(tag)) return false;
	return tag !== "." && tag !== "..";
}

// ── 事件与采集决定 ───────────────────────────────────────────────────────────

export type DebugEventKind = "bash-output" | "bash-error";

export interface DebugEvent {
	/** 采集时刻（epoch ms）。 */
	at: number;
	/** 采集时会话键（resetDebugObservation 换届；事件保留原键供辨识）。 */
	sessionKey: string;
	toolCallId: string;
	tag: string;
	/** 子代理进程采集时携带（AMAGI_TASK_ID；Leader 主进程采集为 undefined）。 */
	taskId?: string;
	kind: DebugEventKind;
	/** 恒 combined：原生 bash 输出为 stdout+stderr 合并流，不伪称仅 stdout。 */
	stream: "combined";
	/** 真实输出/错误文本（无输出允许空串——记录事件但不编造内容）。 */
	text: string;
	/** 事件文本被截断（collector 单事件 8KiB 上限或原生截断 details.truncation）。 */
	truncated: boolean;
	/** 原生大输出落盘路径（存在时透传供回看全量；clear 不删该文件）。 */
	fullOutputPath?: string;
}

/** 执行前冻结的采集决定（tag+generation；generation 不匹配＝迟到结果，不回填）。 */
export interface DebugCapture {
	tag: string;
	generation: number;
}

export interface DebugObservationStatus {
	sessionKey: string;
	generation: number;
	defaultTag: string | undefined;
	muted: boolean;
	events: number;
	bytes: number;
	dropped: number;
	truncated: number;
}

interface DebugSessionState {
	sessionKey: string;
	generation: number;
	defaultTag: string | undefined;
	muted: boolean;
	events: DebugEvent[];
	totalBytes: number;
	dropped: number;
	truncated: number;
}

const encoder = new TextEncoder();

function byteLength(s: string): number {
	return encoder.encode(s).length;
}

/** 按字节截断（多字节边界可能落到替换符之前截断——truncated=true 如实标注，不编造内容）。 */
function truncateToBytes(text: string, maxBytes: number): { text: string; truncated: boolean } {
	if (byteLength(text) <= maxBytes) return { text, truncated: false };
	let out = "";
	let size = 0;
	for (const ch of text) {
		const chSize = byteLength(ch);
		if (size + chSize > maxBytes) break;
		out += ch;
		size += chSize;
	}
	return { text: out, truncated: true };
}

const state: DebugSessionState = {
	sessionKey: "default",
	generation: 1,
	defaultTag: undefined,
	muted: false,
	events: [],
	totalBytes: 0,
	dropped: 0,
	truncated: 0,
};

// ── P9：provider 流诊断会话态（与 bash collector 同轴生命周期，独立 opt-in） ─────────

/** 白名单观测事件（零内容字段：不含任何流事件原始 data/文本/token）。 */
export interface ProviderStreamObservation {
	/** 采集时刻（epoch ms）。 */
	at: number;
	/** 采集时会话键。 */
	sessionKey: string;
	/** 采集时会话 generation（clear/切换后缓冲已清空，此值供面板辨识）。 */
	generation: number;
	/** 宿主回合序号（turn_start.turnIndex；未见回合边界为 undefined）。 */
	turnIndex: number | undefined;
	provider: string;
	api: string;
	model: string;
	/** 流事件类型分类（白名单提取，见 classifyProviderStreamData）。 */
	streamEventType: string;
	/** 错误归一分类（data 呈错误形状时；只留枚举 token，不留 message）。 */
	errorKind: string | undefined;
}

interface ProviderDebugState {
	enabled: boolean;
	turnIndex: number | undefined;
	events: ProviderStreamObservation[];
	totalBytes: number;
	dropped: number;
	typeCounts: Map<string, number>;
	modelCounts: Map<string, number>;
	turnCounts: Map<number, number>;
}

const providerState: ProviderDebugState = {
	enabled: false,
	turnIndex: undefined,
	events: [],
	totalBytes: 0,
	dropped: 0,
	typeCounts: new Map(),
	modelCounts: new Map(),
	turnCounts: new Map(),
};

/** 当前会话采集状态（只读快照；测试与 show 头部共用）。 */
export function debugObservationStatus(): DebugObservationStatus {
	return {
		sessionKey: state.sessionKey,
		generation: state.generation,
		defaultTag: state.defaultTag,
		muted: state.muted,
		events: state.events.length,
		bytes: state.totalBytes,
		dropped: state.dropped,
		truncated: state.truncated,
	};
}

/** 会话切换/重载/退出：全量释放内存并失效迟到采集（generation++；默认标签/静默位/provider 观测回初始关）。 */
export function resetDebugObservation(sessionKey?: string): void {
	state.sessionKey = typeof sessionKey === "string" && sessionKey
		? sessionKey
		: `sess-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
	state.generation += 1;
	state.defaultTag = undefined;
	state.muted = false;
	state.events = [];
	state.totalBytes = 0;
	state.dropped = 0;
	state.truncated = 0;
	providerState.enabled = false;
	providerState.turnIndex = undefined;
	providerState.events = [];
	providerState.totalBytes = 0;
	providerState.dropped = 0;
	providerState.typeCounts.clear();
	providerState.modelCounts.clear();
	providerState.turnCounts.clear();
}

// ── 命令面状态迁移（/amagi debug on/off/clear） ──────────────────────────────

export type DebugTagOpResult = { ok: true } | { ok: false; code: "invalid-tag"; tag: string };

/** /amagi debug on <tag>：设会话默认标签并解除静默（显式 debugTag 参数优先于默认标签）。 */
export function setDebugDefaultTag(tag: string): DebugTagOpResult {
	if (!debugTagValid(tag)) return { ok: false, code: "invalid-tag", tag: String(tag) };
	state.defaultTag = tag;
	state.muted = false;
	return { ok: true };
}

/** /amagi debug off：清默认标签并置 muted——后续显式 debugTag 也静默直到 on；generation++（迟到结果不回填）。 */
export function muteDebugCollection(): { ok: true } {
	state.defaultTag = undefined;
	state.muted = true;
	state.generation += 1;
	return { ok: true };
}

/** /amagi debug clear：清空缓冲（默认标签/静默位不动）；generation++（迟到旧工具结果不回填）；不删任何文件。P9：provider 诊断缓冲一并清空（同轴生命周期）。 */
export function clearDebugEvents(): { ok: true; cleared: number } {
	const cleared = state.events.length;
	state.events = [];
	state.totalBytes = 0;
	state.generation += 1;
	providerState.events = [];
	providerState.totalBytes = 0;
	providerState.dropped = 0;
	providerState.typeCounts.clear();
	providerState.modelCounts.clear();
	providerState.turnCounts.clear();
	return { ok: true, cleared };
}

// ── 采集（bash-override 接线点） ─────────────────────────────────────────────

/**
 * 委托原生 bash 前冻结采集决定：muted → null；显式标签（优先，须合法）→ 冻结；默认标签 → 冻结；
 * 否则 null（缺省不采集）。generation 一并冻结——完成时若已 off/clear/切换（generation 变化），
 * 迟到结果不回填已清缓冲。
 */
export function freezeDebugCapture(explicitTag: string | undefined): DebugCapture | null {
	if (state.muted) return null;
	if (typeof explicitTag === "string" && explicitTag) {
		return debugTagValid(explicitTag) ? { tag: explicitTag, generation: state.generation } : null;
	}
	if (state.defaultTag !== undefined) return { tag: state.defaultTag, generation: state.generation };
	return null;
}

export interface RecordDebugEventInput {
	toolCallId: string;
	kind: DebugEventKind;
	/** 真实输出/错误文本（无输出允许空串——记录事件但不编造内容）。 */
	text: string;
	/** 原生结果已截断（details.truncation 存在）——事件 truncated 置位。 */
	nativeTruncated?: boolean;
	fullOutputPath?: string;
}

export interface RecordDebugStats {
	recorded: boolean;
	/** true＝capture.generation 已过期（off/clear/会话切换后完成）——不回填已清缓冲。 */
	stale: boolean;
	retained: number;
	dropped: number;
	truncated: number;
}

function evictOldest(): void {
	const e = state.events.shift();
	if (!e) return;
	state.totalBytes = Math.max(0, state.totalBytes - byteLength(e.text));
	state.dropped += 1;
}

/**
 * 完成时记录事件：generation 不匹配 → stale 不回填；单事件 8KiB 截断；条数 256 / 总 256KiB
 * （按 text 字节计）旧端淘汰。taskId 取 AMAGI_TASK_ID（子代理进程标注；Leader 主进程 undefined）。
 */
export function recordDebugEvent(capture: DebugCapture, input: RecordDebugEventInput): RecordDebugStats {
	if (capture.generation !== state.generation) {
		return { recorded: false, stale: true, retained: state.events.length, dropped: state.dropped, truncated: state.truncated };
	}
	const capped = truncateToBytes(String(input.text ?? ""), DEBUG_MAX_EVENT_BYTES);
	const event: DebugEvent = {
		at: Date.now(),
		sessionKey: state.sessionKey,
		toolCallId: String(input.toolCallId ?? ""),
		tag: capture.tag,
		kind: input.kind,
		stream: "combined",
		text: capped.text,
		truncated: capped.truncated || input.nativeTruncated === true,
	};
	const taskId = process.env.AMAGI_TASK_ID;
	if (taskId) event.taskId = taskId;
	if (typeof input.fullOutputPath === "string" && input.fullOutputPath) event.fullOutputPath = input.fullOutputPath;
	state.events.push(event);
	state.totalBytes += byteLength(event.text);
	if (event.truncated) state.truncated += 1;
	while (state.events.length > DEBUG_MAX_EVENTS) evictOldest();
	while (state.totalBytes > DEBUG_MAX_TOTAL_BYTES && state.events.length > 1) evictOldest();
	return { recorded: true, stale: false, retained: state.events.length, dropped: state.dropped, truncated: state.truncated };
}

// ── 展示（/amagi debug show 与 bash 结果尾部摘要共用渲染件） ──────────────────

function timeOf(at: number): string {
	return new Date(at).toISOString().slice(11, 23);
}

function previewOf(text: string, maxChars: number): string {
	const flat = text.length > maxChars ? `${text.slice(0, maxChars)}…(${text.length} chars)` : text;
	return flat.replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}

/**
 * 结果尾部聚合摘要（≤4KiB，逐行 `[debug <tag>]` 前缀）：该标签最近事件（新→旧）+ 真实统计。
 * capture 过期/无该标签事件 → 如实说明（不编造聚合）。bash-override 经 appendAdvisoryNote 尾部
 * 追加——不改写原始行/命令/环境/cwd/退出码/details.fullOutputPath/truncation。
 */
export function debugTagSummary(capture: DebugCapture): string | null {
	if (capture.generation !== state.generation) {
		return `[debug ${capture.tag}] 本条未入会话缓冲（采集决定已过期——off/clear/会话切换后完成，不回填）。`;
	}
	const tagEvents = state.events.filter((e) => e.tag === capture.tag);
	if (!tagEvents.length) {
		return `[debug ${capture.tag}] 本条未入会话缓冲（无该标签事件——可能已被上限淘汰或未记录）。`;
	}
	const recent = tagEvents.slice(-DEBUG_SUMMARY_EVENT_LIMIT).reverse();
	const lines = [
		`[debug ${capture.tag}] 采集摘要（该标签 retained=${tagEvents.length} · dropped=${state.dropped} · truncated=${state.truncated} · 最近 ${recent.length} 条新→旧；/amagi debug show ${capture.tag} 查看更多）：`,
	];
	for (const e of recent) {
		const meta = [e.kind, e.stream, e.truncated ? "truncated" : undefined].filter(Boolean).join(", ");
		lines.push(`[debug ${capture.tag}] ${timeOf(e.at)} ${meta} ${previewOf(e.text, DEBUG_SUMMARY_PREVIEW_CHARS)}`);
	}
	const joined = lines.join("\n");
	const capped = truncateToBytes(joined, DEBUG_SUMMARY_MAX_BYTES - 80);
	return capped.truncated ? `${capped.text}\n[debug] （摘要超 ${DEBUG_SUMMARY_MAX_BYTES} 字节上限截断）` : capped.text;
}

/**
 * /amagi debug show [tag]：展示当前会话聚合（默认最近 32 条，新→旧）；头部含真实统计
 * （事件数/字节/丢弃/截断/generation/默认标签/静默位）——超限 dropped 如实展示，不美化。
 */
export function showDebugEvents(tag?: string, limit: number = DEBUG_SHOW_DEFAULT_LIMIT): string {
	const st = state;
	const header = `[amagi·debug] 会话采集（session=${st.sessionKey} · 默认标签=${st.defaultTag ?? "未设"} · 静默=${st.muted ? "是（off）" : "否"} · 事件 ${st.events.length}/${DEBUG_MAX_EVENTS} · ${(st.totalBytes / 1024).toFixed(1)}KiB/${DEBUG_MAX_TOTAL_BYTES / 1024}KiB · 丢弃 ${st.dropped} · 截断 ${st.truncated} · generation ${st.generation}）`;
	const filtered = typeof tag === "string" && tag ? st.events.filter((e) => e.tag === tag) : st.events;
	if (!filtered.length) {
		return `${header}\n[amagi·debug] （无事件${typeof tag === "string" && tag ? `（标签 ${tag}）` : ""}——bash 带 debugTag 参数或 /amagi debug on <tag> 后采集命令真实最终输出）`;
	}
	const shown = filtered.slice(-Math.max(1, limit)).reverse();
	const body: string[] = [];
	for (const e of shown) {
		const head = `[amagi·debug] ${timeOf(e.at)} [${e.tag}] ${e.kind} (${e.stream}${e.truncated ? ", truncated" : ""})${e.taskId ? ` task=${e.taskId}` : ""} toolCall=${e.toolCallId}`;
		const text = e.text ? e.text.slice(0, DEBUG_SHOW_PREVIEW_CHARS).split("\n").map((l) => `  ${l}`).join("\n") : "  （无输出）";
		body.push(`${head}\n${text}${e.fullOutputPath ? `\n  full: ${e.fullOutputPath}` : ""}`);
	}
	return [
		header,
		`[amagi·debug] （共 ${filtered.length} 条${typeof tag === "string" && tag ? `（标签 ${tag}）` : ""}，展示最近 ${shown.length} 条，新→旧）`,
		...body,
	].join("\n");
}

// ── P9：provider 流事件白名单分类与采集（独立 opt-in；零内容/零凭据） ──────────

/** 元数据字符串净化：截断 + 凭据/高熵形状拒绝（拒绝时降级 fallback，不抛错不存原值）。 */
function safeMetaString(v: unknown, fallback: string): string {
	if (typeof v !== "string" || !v) return fallback;
	const t = v.slice(0, 128);
	return CREDENTIAL_SHAPE_RE.test(t) || HIGH_ENTROPY_RE.test(t) ? fallback : t;
}

/** 流事件枚举 token 净化：字符集白名单 + 长度上限 + 凭据/高熵拒绝（不匹配 → undefined，不保留原值）。 */
function safeStreamToken(v: unknown): string | undefined {
	if (typeof v !== "string") return undefined;
	const t = v.trim().slice(0, 64);
	if (!STREAM_TOKEN_RE.test(t)) return undefined;
	if (CREDENTIAL_SHAPE_RE.test(t) || HIGH_ENTROPY_RE.test(t)) return undefined;
	return t;
}

export interface ProviderStreamClassification {
	/** 流事件类型分类（如 message_start / chat.completion.chunk / chat.completion.chunk:stop / error / unknown）。 */
	streamEventType: string;
	/** 错误归一分类（data 呈错误形状时非空；只取 error.type|code 枚举 token，fallback "error"）。 */
	errorKind: string | undefined;
}

/**
 * 白名单分类器（纯函数）：只读流事件 data 的「枚举形状」字段——anthropic `type`、openai `object`
 * （+choices[0].finish_reason 枚举后缀）、错误形状 `error.type|error.code`——逐 token 净化后拼分类。
 * 其余字段（content/delta 文本、tool 输入、usage、headers、原始字节）一律不读不存；
 * 非普通对象形状归 unknown 桶。永不抛错（任意 data 形状安全）。
 */
export function classifyProviderStreamData(data: unknown): ProviderStreamClassification {
	if (data === null || typeof data !== "object" || Array.isArray(data)) {
		return { streamEventType: "unknown", errorKind: undefined };
	}
	const obj = data as Record<string, unknown>;
	const errRaw = obj.error;
	const errObj = errRaw !== null && typeof errRaw === "object" && !Array.isArray(errRaw)
		? (errRaw as Record<string, unknown>)
		: undefined;
	let errorKind: string | undefined;
	if (obj.type === "error" || errObj !== undefined) {
		errorKind = (errObj ? (safeStreamToken(errObj.type) ?? safeStreamToken(errObj.code)) : undefined) ?? "error";
	}
	const objectTok = safeStreamToken(obj.object);
	const typeTok = safeStreamToken(obj.type) ?? objectTok;
	if (typeTok === undefined) {
		return { streamEventType: errorKind !== undefined ? "error" : "unknown", errorKind };
	}
	let streamEventType = typeTok;
	if (objectTok === "chat.completion.chunk" && Array.isArray(obj.choices)) {
		const first = obj.choices[0];
		const fin = first !== null && typeof first === "object"
			? safeStreamToken((first as Record<string, unknown>).finish_reason)
			: undefined;
		if (fin) streamEventType = `${typeTok}:${fin}`;
	}
	return { streamEventType, errorKind };
}

function providerObsBytes(o: ProviderStreamObservation): number {
	return 64 + o.provider.length + o.api.length + o.model.length + o.streamEventType.length + (o.errorKind?.length ?? 0);
}

/** 聚合计数自增 + 键数上界防御（超出淘汰计数最小键；确定性平键排序）。 */
function bumpCount<K>(map: Map<K, number>, key: K): void {
	map.set(key, (map.get(key) ?? 0) + 1);
	if (map.size <= DEBUG_PROVIDER_AGGREGATE_KEYS) return;
	const entries = [...map.entries()].sort((a, b) => a[1] - b[1] || (String(a[0]) < String(b[0]) ? -1 : 1));
	for (const [k] of entries.slice(0, map.size - DEBUG_PROVIDER_AGGREGATE_KEYS)) map.delete(k);
}

function evictProviderOldest(): void {
	const e = providerState.events.shift();
	if (!e) return;
	providerState.totalBytes = Math.max(0, providerState.totalBytes - providerObsBytes(e));
	providerState.dropped += 1;
}

export interface NoteProviderStreamStats {
	/** enabled=false → recorded=false（订阅常驻但未开启，零采集零开销）。 */
	recorded: boolean;
	enabled: boolean;
	retained: number;
	dropped: number;
}

/**
 * provider_stream_event 接线点（index.ts 订阅回调）：未开启零采集；开启后经白名单分类器只记
 * 元数据观测（零内容/凭据），条数 256 / 估算 64KiB 双上限旧端淘汰，dropped 如实计数非静默。
 * event 形状由宿主定义（provider/api/model/data）——未知形状防御降级 unknown，不抛错。
 */
export function noteProviderStreamEvent(event: unknown): NoteProviderStreamStats {
	if (!providerState.enabled) {
		return { recorded: false, enabled: false, retained: providerState.events.length, dropped: providerState.dropped };
	}
	const e = event !== null && typeof event === "object" ? (event as Record<string, unknown>) : {};
	const cls = classifyProviderStreamData(e.data);
	const obs: ProviderStreamObservation = {
		at: Date.now(),
		sessionKey: state.sessionKey,
		generation: state.generation,
		turnIndex: providerState.turnIndex,
		provider: safeMetaString(e.provider, "unknown"),
		api: safeMetaString(e.api, "unknown"),
		model: safeMetaString(e.model, "unknown"),
		streamEventType: cls.streamEventType,
		errorKind: cls.errorKind,
	};
	providerState.events.push(obs);
	providerState.totalBytes += providerObsBytes(obs);
	bumpCount(providerState.typeCounts, obs.streamEventType);
	bumpCount(providerState.modelCounts, `${obs.provider}/${obs.model}`);
	if (typeof obs.turnIndex === "number") bumpCount(providerState.turnCounts, obs.turnIndex);
	while (providerState.events.length > DEBUG_PROVIDER_MAX_EVENTS) evictProviderOldest();
	while (providerState.totalBytes > DEBUG_PROVIDER_MAX_TOTAL_BYTES && providerState.events.length > 1) evictProviderOldest();
	return { recorded: true, enabled: true, retained: providerState.events.length, dropped: providerState.dropped };
}

/** turn_start 接线点：记录宿主回合序号（后续 provider 观测按最新回合盖章；非法值忽略保持旧值）。 */
export function noteProviderTurn(turnIndex: unknown): void {
	if (typeof turnIndex === "number" && Number.isFinite(turnIndex)) providerState.turnIndex = turnIndex;
}

// ── P9 命令面状态迁移（/amagi debug provider on/off/clear；show 见 showProviderDebugEvents） ──

/** /amagi debug provider on：开启（独立 opt-in，默认关；与 bash 采集开关互不影响；缓冲保留）。 */
export function enableProviderDebug(): { ok: true } {
	providerState.enabled = true;
	return { ok: true };
}

/** /amagi debug provider off：关闭（缓冲保留可 show；后续流事件零采集）。 */
export function disableProviderDebug(): { ok: true } {
	providerState.enabled = false;
	return { ok: true };
}

/** /amagi debug provider clear：清 provider 诊断缓冲与聚合计数（掉落计数归零；bash 缓冲与开关不动）。 */
export function clearProviderDebugEvents(): { ok: true; cleared: number } {
	const cleared = providerState.events.length;
	providerState.events = [];
	providerState.totalBytes = 0;
	providerState.dropped = 0;
	providerState.typeCounts.clear();
	providerState.modelCounts.clear();
	providerState.turnCounts.clear();
	return { ok: true, cleared };
}

export interface ProviderDebugStatus {
	enabled: boolean;
	sessionKey: string;
	generation: number;
	turnIndex: number | undefined;
	events: number;
	bytes: number;
	dropped: number;
	/** 事件类型计数（计数降序；聚合计数不受环形淘汰影响，含已淘汰事件）。 */
	typeCounts: [string, number][];
	/** 模型计数（provider/model → 次数）。 */
	modelCounts: [string, number][];
	/** 回合计数（turnIndex → 事件次数）。 */
	turnCounts: [number, number][];
}

function sortedEntries<K>(m: Map<K, number>): [K, number][] {
	return [...m.entries()].sort((a, b) => b[1] - a[1] || (String(a[0]) < String(b[0]) ? -1 : 1));
}

/** 当前 provider 诊断只读快照（测试与面板头部共用）。 */
export function providerDebugStatus(): ProviderDebugStatus {
	return {
		enabled: providerState.enabled,
		sessionKey: state.sessionKey,
		generation: state.generation,
		turnIndex: providerState.turnIndex,
		events: providerState.events.length,
		bytes: providerState.totalBytes,
		dropped: providerState.dropped,
		typeCounts: sortedEntries(providerState.typeCounts),
		modelCounts: sortedEntries(providerState.modelCounts),
		turnCounts: sortedEntries(providerState.turnCounts),
	};
}

/**
 * /amagi debug provider show：provider 流诊断面板（默认最近 32 条，新→旧）。头部真实统计
 * （开关/回合/事件数/估算字节/掉落/generation）+ 三类聚合计数 + 逐事件白名单元数据行；
 * 超限 dropped 如实展示；零内容字段（不存在文本预览面）。
 */
export function showProviderDebugEvents(limit: number = DEBUG_SHOW_DEFAULT_LIMIT): string {
	const st = providerDebugStatus();
	const header = `[amagi·debug] provider 流诊断（session=${st.sessionKey} · 开=${st.enabled ? "是" : "否（默认关）"} · 回合=${typeof st.turnIndex === "number" ? st.turnIndex : "未见边界"} · 事件 ${st.events}/${DEBUG_PROVIDER_MAX_EVENTS} · ${(st.bytes / 1024).toFixed(1)}KiB/${DEBUG_PROVIDER_MAX_TOTAL_BYTES / 1024}KiB · 丢弃 ${st.dropped} · generation ${st.generation} · 白名单：provider/api/model/事件类型/回合/计数——零内容/凭据采集）`;
	if (!st.events) {
		return `${header}\n[amagi·debug] （无 provider 观测事件——/amagi debug provider on 后采集流事件元数据；bash 输出采集见 /amagi debug show）`;
	}
	const fmtCounts = (entries: [string, number][]) => entries.map(([k, n]) => `${k}→${n}`).join(" · ") || "（无）";
	const turns = st.turnCounts.map(([k, n]) => `${k}→${n}`).join(" · ") || "（无）";
	const shown = providerState.events.slice(-Math.max(1, limit)).reverse();
	const body = shown.map((o) =>
		`[amagi·debug] ${timeOf(o.at)} turn=${typeof o.turnIndex === "number" ? o.turnIndex : "?"} ${o.provider}/${o.model} (${o.api}) ${o.streamEventType}${o.errorKind ? ` error=${o.errorKind}` : ""}`);
	return [
		header,
		`[amagi·debug] 事件类型计数（聚合计数含已淘汰事件）：${fmtCounts(st.typeCounts)}`,
		`[amagi·debug] 模型计数：${fmtCounts(st.modelCounts)}`,
		`[amagi·debug] 回合计数：${turns}`,
		`[amagi·debug] （展示最近 ${shown.length} 条，新→旧）`,
		...body,
	].join("\n");
}
