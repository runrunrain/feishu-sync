/**
 * agents-loader.ts — 发现并解析包内 agents/*.md 角色定义。
 *
 * P2-2 加固（阶段审核）：
 *   - 校验 name/description/type 必需；type ∈ fast|work|expert
 *   - 拒绝 symlink（防包外 Markdown 注入 system prompt）
 *   - 重复 name 报错
 *   - 跳过文件给可定位诊断（console.warn）
 *
 * 设计：agent.name = 文件名 basename（task 查找键；名册单源——I3 负例测试扫描本文件不得出现硬编码角色名）。
 *
 * P1（§5.1/§8.3-P1）：新增 capabilities 结构化能力上限字段解析（validateRoleCapabilities 单一归一化，
 * 非法→ capabilitiesError + warning，通道 fail-closed 不回退宽权限）；tools 双格式归一化
 * （normalizeToolsField：逗号字符串与 YAML 字符串数组等价——§5.1）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import { parseFrontmatter } from "@earendil-works/pi-coding-agent";
import { normalizeToolsField, roleCharterOf, validateRoleCapabilities, type RoleCapabilitySpec } from "./task-permission.ts";

const moduleDir = path.dirname(fileURLToPath(import.meta.url));

/** v2 I2（设计方案 §4.3）：SubAgent 公共基线正文注入——canonical base-constraints 是公共纪律
 *  唯一权威定义，必须在 spawn prompt 真正注入正文（而非只放 amagi_resource 指针）。
 *  复用现有 canonical 组合机制：本函数是全部派发路径（sync/background/resume/#硬路由/export）
 *  共用的 systemPrompt 单点装配处，读一次、拼一次，五份角色文件零复制。 */
function loadBaseConstraints(): string {
	const p = path.resolve(moduleDir, "..", "..", "resources", "core", "common", "agent-base-constraints.md");
	try { return fs.readFileSync(p, "utf8").trim(); }
	catch { console.warn(`[amagi-core/agents-loader] 公共基线缺失: ${p}（spawn prompt 退化为角色正文+运行协议）`); return ""; }
}

const BASE_CONSTRAINTS_PROMPT = loadBaseConstraints();

export type AgentType = "fast" | "work" | "expert";
const VALID_TYPES = new Set<AgentType>(["fast", "work", "expert"]);

/** 所有角色共用的最小运行契约底座；角色卡只保留职责差异，避免每个 system prompt 重复协议。
 *  字节观测（无门禁，主上 2026-09-19 裁定）；prompt-footprint 断言本段在每个 spawn prompt 恰好出现一次。 */
export const COMMON_AGENT_SYSTEM_PROMPT = [
	"[Amagi 独立节点协议]",
	"需要框架细则时调用 amagi_resource（canonical ID，如 quality、workflow）；resources/... 是资源 ID，不是项目路径。",
	"“自动收尾”由 harness 结算；无后续写入的子代理基线可复用，不重跑。",
	"任务末尾附有结果协议时按其输出；未附时：完成用独立标题 ACHIEVEMENT: 逐项写“验收→证据→状态”并以独占末行 <!--AMAGI:DONE--> 收尾，缺关键输入则首行 <!--AMAGI:BLOCKED--> 后接 STATUS: blocked 与 QUESTIONS。",
	"终稿保持紧凑：结论→摘要→artifact 路径→未覆盖/风险；证据只写 ACHIEVEMENT 一次；长内容写 artifact。",
].join("\n");

/** ev-20260914：按 type 差异化的返回格式（对齐 resources/core/collaboration/workflow-rules.md「返回格式」）。
 *  此前该规范只活在 L1 资源里，子 Agent 看不到——fast 型禁方案裁决等约束全靠 Leader 写任务书时自觉携带。
 *  fast 型角色卡的「事实结论」不冲突：事实结论带证据锚点允许，方案裁决/建议禁止。 */
const RETURN_FORMAT_BY_TYPE: Record<AgentType, string> = {
	fast: "返回格式（fast 型）：资料/事实清单 + 出处（路径/行号/链接）+ 置信度 + 待核验项；事实结论带上证据锚点，方便下游直接复核；只给事实与出处，不做方案裁决、建议或“建议下一步”——判断交给下游角色，你的证据链会让它更有把握。",
	work: "返回格式（work 型）：摘要 + artifact 路径 + 引用上游 artifact + 验证/自检结果；可附一行“建议下一步”供 Leader 参考，不自行调度。",
	expert: "返回格式（expert 型）：摘要 + artifact 路径 + 引用上游 artifact + 验证/自检结果；可附一行“建议下一步”供 Leader 参考，不自行调度。",
};

/** 底座 + 按 type 返回格式段的完整公共契约（装配处用它替代裸 COMMON_AGENT_SYSTEM_PROMPT）。 */
export function commonContractFor(type: AgentType): string {
	return `${COMMON_AGENT_SYSTEM_PROMPT}\n${RETURN_FORMAT_BY_TYPE[type]}`;
}

export interface AgentConfig {
	/** 文件名 basename（task 查找键） */
	name: string;
	/** 源 frontmatter name（功能名，如 coder；不用于查找） */
	frontmatterName: string;
	description: string;
	type: AgentType;
	/** pi 内置工具名（小写，如 read/write/bash/grep/find）；双格式归一化（逗号串/YAML 数组等价）。 */
	tools: string[];
	/** undefined（P1 不写死；P3 profiles 解析） */
	model?: string;
	/** P1：角色能力上限（capabilities 结构化字段；唯一能力来源，tools 字符串不推导能力——防迁移误放权）。 */
	capabilities?: RoleCapabilitySpec;
	/** P1：capabilities 非法原因（存在即授权计算 fail-closed 拒绝该角色任务，不回退无限权限）。 */
	capabilitiesError?: string;
	/** 名册主特色短语（frontmatter `feature` 结构化字段；缺省回退 description 主责短语）。 */
	feature?: string;
	/** 角色差异正文 + COMMON_AGENT_SYSTEM_PROMPT。 */
	systemPrompt: string;
	filePath: string;
}

export interface DiscoverResult {
	agents: AgentConfig[];
	/** 跳过文件的可定位诊断 */
	warnings: string[];
}

/**
 * 从 agentsDir 加载所有 *.md 角色定义。
 * symlink 拒绝；重复 name 报错（throw）；校验失败文件跳过 + warning。
 */
export function discoverAgents(agentsDir: string): DiscoverResult {
	const agents: AgentConfig[] = [];
	const warnings: string[] = [];
	const seenAliases = new Set<string>();

	if (!fs.existsSync(agentsDir)) {
		return { agents, warnings: [`agents 目录不存在: ${agentsDir}`] };
	}

	let entries: fs.Dirent[];
	try {
		entries = fs.readdirSync(agentsDir, { withFileTypes: true });
	} catch (e) {
		return { agents, warnings: [`读取 agents 目录失败 ${agentsDir}: ${String(e)}`] };
	}

	for (const entry of entries) {
		if (!entry.name.endsWith(".md")) continue;

		// P2-2: 拒绝 symlink（防包外注入）
		if (entry.isSymbolicLink()) {
			warnings.push(`${entry.name}: 拒绝 symlink（安全：防包外 Markdown 注入 system prompt）`);
			continue;
		}
		if (!entry.isFile()) continue;

		const filePath = path.join(agentsDir, entry.name);
		const fileBase = entry.name.replace(/\.md$/, "");

		let content: string;
		try {
			content = fs.readFileSync(filePath, "utf-8");
		} catch (e) {
			warnings.push(`${entry.name}: 读取失败 ${String(e)}`);
			continue;
		}

		let frontmatter: Record<string, unknown>;
		let body: string;
		try {
			const parsed = parseFrontmatter<Record<string, unknown>>(content);
			frontmatter = parsed.frontmatter;
			body = parsed.body;
		} catch (e) {
			warnings.push(`${entry.name}: frontmatter 解析失败 ${String(e)}，跳过`);
			continue;
		}

		// P2-2: 必需字段校验（frontmatter 结构化后字段类型不定：非字符串必需字段一律拒收，不猜测）
		if (typeof frontmatter.description !== "string" || !frontmatter.description.trim()) {
			warnings.push(`${entry.name}: 缺 description，跳过`);
			continue;
		}
		const type = frontmatter.type as AgentType;
		if (!type || !VALID_TYPES.has(type)) {
			warnings.push(`${entry.name}: type 缺失或非法（${type || "(空)"}），跳过`);
			continue;
		}

		// tools 必须存在且为非空（P0-2: 无白名单角色会扩大权限）；P1 起双格式归一化（逗号串/YAML 数组等价）
		const tools = normalizeToolsField(frontmatter.tools);
		if (tools.length === 0) {
			warnings.push(`${entry.name}: tools 为空（P0-2: 无白名单会扩大子进程权限），跳过`);
			continue;
		}

		// P2-1（复审修正）: alias 唯一性登记放在全部字段校验通过之后（避免无效文件提前占位阻断后续合法文件）
		const rawName = typeof frontmatter.name === "string" && frontmatter.name.trim() ? frontmatter.name.trim() : undefined;
		const alias = rawName ?? fileBase;
		if (seenAliases.has(alias)) {
			throw new Error(`agents-loader: 重复角色 alias "${alias}"（${filePath}；task 工具按 name/frontmatterName 查找，alias 冲突有歧义）`);
		}
		seenAliases.add(alias);

		// P1（§5.1）：capabilities 能力上限（结构化字段，唯一能力来源；非法→ fail-closed 标记，不回退宽权限）
		let capabilities: RoleCapabilitySpec | undefined;
		let capabilitiesError: string | undefined;
		if (frontmatter.capabilities !== undefined) {
			const caps = validateRoleCapabilities(frontmatter.capabilities);
			if (caps.ok) {
				capabilities = caps.value;
			} else {
				capabilitiesError = caps.error.message;
				warnings.push(`${entry.name}: capabilities 非法（${caps.error.message}）——能力通道 fail-closed，该角色任务将被授权计算拒绝`);
			}
		}

		// 名册主特色：结构化 frontmatter `feature`（单行 2..12 字）；非法记诊断并忽略（回退主责短语）。
		let feature: string | undefined;
		if (frontmatter.feature !== undefined) {
			const f = typeof frontmatter.feature === "string" ? frontmatter.feature.trim() : "";
			if (f.length >= 2 && f.length <= 12 && !/[\r\n|]/.test(f)) feature = f;
			else warnings.push(`${entry.name}: feature 非法（须为单行 2..12 字、不含 |），名册回退主责短语`);
		}

		agents.push({
			name: fileBase,
			frontmatterName: rawName ?? fileBase,
			description: frontmatter.description,
			type,
			tools,
			...(capabilities !== undefined ? { capabilities } : {}),
			...(capabilitiesError !== undefined ? { capabilitiesError } : {}),
			...(feature !== undefined ? { feature } : {}),
			model: typeof frontmatter.model === "string" ? frontmatter.model : undefined,
			// v2 装配序：角色正文（特色/方法/标杆/专属边界）→ 公共基线（§4.2 唯一权威，I2 注入）→
			// 运行契约（独立节点协议 + 按 type 返回格式）。公共纪律只此一份，不在角色正文复制。
			systemPrompt: [body.trim(), BASE_CONSTRAINTS_PROMPT, commonContractFor(type)].filter(Boolean).join("\n\n"),
			filePath,
		});
	}

	// 诊断输出（可定位）
	for (const w of warnings) console.warn(`[amagi-core/agents-loader] ${w}`);

	return { agents, warnings };
}

// ── I3（amagi-pi v2 §8.2-I3）：名册单源整形——L0 角色名册唯一登记在 agents/*.md，
//    本模块提供从 description 到有界主责短语的确定性提取与排序，leader-prompt 据此渲染两档名册；
//    任何地方不得再维护第二份手打名册。纯函数（无 fs），双载字节级一致可测。

/** 主责短语截断上限（字符数；中文 UTF-8 下单行 ~96B，13 行名册的注入预算由此锁定）。 */
const DUTY_MAX_CHARS = 32;

/** 从角色 description 提取有界主责短语。
 *  规则（确定性，无内容发明）：优先取「职责：」行；无则取首个非限定行（跳过 禁止/触发/启用条件/
 *  独占/输出契约/用于 前缀行），人设行（天城的/谛听的 开头）剥去首句后取其余正文。
 *  截断：先切到首个 。；；再超长时优先在最近的 ，、空格处断开（≥8 字符才可用），否则硬截断加 …。 */
export function mainDutyOf(description: string): string {
	const lines = description.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
	let raw: string | undefined;
	const dutyLine = lines.find((l) => /^职责[：:]/.test(l));
	if (dutyLine) {
		raw = dutyLine.replace(/^职责[：:]\s*/, "");
	} else {
		const skip = /^(禁止|触发|启用条件|独占|输出契约|用于)/;
		const persona = /^(天城的|谛听的)/;
		for (const line of lines) {
			if (skip.test(line)) continue;
			if (persona.test(line)) {
				const rest = line.replace(/^[^。]*。/, "").trim();
				if (rest) { raw = rest; break; }
				continue;
			}
			raw = line;
			break;
		}
	}
	if (!raw) return "(未声明主责)";
	let duty = raw.split(/[。；;]/)[0].trim();
	if (duty.length > DUTY_MAX_CHARS) {
		// 时序/条件前导从句（在/当 开头）不是主责：取首个逗号后的主句（例：「在……完成后，对阶段 diff 做独立审核」→取后半）
		const comma = duty.indexOf("，");
		if (comma >= 6 && /^(在|当)/.test(duty)) duty = duty.slice(comma + 1).trim();
		// 括号限定语（如「（researcher 级，速度优先）」）是修饰非主责：超长时先剥离再量
		if (duty.length > DUTY_MAX_CHARS) {
			const stripped = duty.replace(/（[^）]*）/g, "");
			if (stripped.length >= 8) duty = stripped;
		}
	}
	if (duty.length > DUTY_MAX_CHARS) {
		const head = duty.slice(0, DUTY_MAX_CHARS);
		const comma = head.lastIndexOf("，");
		const dun = head.lastIndexOf("、");
		const space = head.lastIndexOf(" ");
		let cut = -1;
		if (comma >= 8) cut = comma;
		else if (dun >= 8) cut = dun;
		else if (space >= 8) cut = space;
		duty = cut >= 8 ? head.slice(0, cut) : `${head}…`;
	}
	return duty || "(未声明主责)";
}

/** 名册行（I3 单源投影：name=文件名查找键，type=fast/work/expert，duty=有界主责短语）。 */
export interface RosterRow {
	name: string;
	type: AgentType;
	duty: string;
	/** v2 五特色投影：frontmatter `feature` 结构化字段；未声明回退 duty。 */
	feature: string;
	/** v2 权限标签：可写 / 只读+报告 / 限定 artifact / 能力未声明（唯一据 capabilities 章程投影）。 */
	permission: string;
}

const ROSTER_TYPE_ORDER: Record<AgentType, number> = { fast: 0, work: 1, expert: 2 };

/** 角色是否只读章程（worktree 隔离建议抑制等消费面的唯一判定）：唯一据 capabilities 章程投影
 *  （显式 charter，缺省按 write 上限推导）；description 措辞不参与——改文案不改判定。
 *  capabilities 缺失/非法（该角色派发会被授权计算拒绝）→ false。 */
export function roleIsReadOnly(agent: { capabilities?: RoleCapabilitySpec; capabilitiesError?: string } | undefined): boolean {
	if (!agent || agent.capabilitiesError !== undefined) return false;
	return roleCharterOf(agent.capabilities) === "read-only";
}

/** v2 名册权限标签（唯一据 capabilities 章程投影，确定性）：write→可写；artifact→限定 artifact；
 *  read-only→只读+报告；capabilities 缺失/非法→能力未声明（该角色无法派发）。 */
export function rosterPermissionOf(agent: { capabilities?: RoleCapabilitySpec; capabilitiesError?: string }): string {
	if (agent.capabilitiesError !== undefined) return "能力未声明";
	switch (roleCharterOf(agent.capabilities)) {
		case "write": return "可写";
		case "artifact": return "限定 artifact";
		case "read-only": return "只读+报告";
		default: return "能力未声明";
	}
}

/** 名册行集：按 type（fast→work→expert）稳定排序，组内保持发现序（readdir 序）——
 *  同一目录重复调用字节级一致（cache-observability 前缀稳定不变量）。 */
export function rosterRows(agents: ReadonlyArray<AgentConfig>): RosterRow[] {
	return [...agents]
		.map((a) => {
			const duty = mainDutyOf(a.description);
			return { name: a.name, type: a.type, duty, feature: a.feature ?? duty, permission: rosterPermissionOf(a) };
		})
		.sort((a, b) => ROSTER_TYPE_ORDER[a.type] - ROSTER_TYPE_ORDER[b.type]);
}
