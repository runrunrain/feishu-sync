/**
 * emoji-guard.ts — emoji 内容硬拦截护栏（v2.7.0；主上令：规则禁不住的 emoji 用代码拦）。
 *
 * 实证背景：模型在 rule/prompt 中被明确禁止 emoji 后仍偶尔生成到会话与文档
 * （例：planner-doc-style SKILL.md 混入 emoji）——提示词约束是概率性的，须有确定性执法点。
 *
 * 能力依据（pi dist extensions/types.d.ts）：
 * - tool_call 事件（L679-702）：{ toolCallId, toolName, input }，返回 { block, reason } 可拦截，
 *   原地改写 event.input 可静默修正（edit-guard 同款官方通道）。
 * - tool_result 事件（L726-734）：返回 { content } 可改写工具结果——strip 模式的「强感知」注记通道。
 * - message_end 事件（L604-607 + agent-session.js L409/L477）：返回 { message } 替换已定稿消息，
 *   会话持久化与 agent 状态同步——assistant 会话文本的剥离通道。
 *
 * 检测口径（Unicode 属性，Node 20 原生支持 \p{Extended_Pictographic}）：
 * - 表情序列：\p{Extended_Pictographic}（含 ZWJ 链 👨‍👩‍👧、regional 🇨🇳、变体选择符 FE0F）；
 * - 键帽序列：[#*0-9] + FE0F? + U+20E3（1️⃣——基字符不是 EP，须独立匹配）；
 * - 肤色修饰符 U+1F3FB..U+1F3FF（Emoji_Modifier，非 EP，独立匹配）；
 * - 白名单：本框架自用的文本呈现技术符号（⚠ ↔ ↩ ⏸ ⏱ ⏳ ▶ ⌨ ✖——extensions/rules 实测使用集），
 *   键帽/肤色修饰符/ZWJ 链永不在白名单语义内（多码点序列即使含白名单字符仍视为 emoji）。
 *
 * 安全设计（轻护栏框架）：
 * - 默认关（amagi.json `emojiGuard.enabled` 或 AMAGI_EMOJI_GUARD=1 开启）——升级零行为变化；
 * - edit 的 oldText 永不触碰（oldText 必须逐字匹配文件原文，剥离即必然失配）；
 * - assistant 消息只动 text 块且跳过带 textSignature 的块（签名重放约束）；thinking 块永不动
 *   （thinkingSignature 多轮回放依赖原文）；
 * - strip 剥离后经 tool_result 注记移除清单（模型可感知，后续不再生成），会话面静默剥离；
 * - bash heredoc 写文件不在拦截面内（命令字符串剥离会破坏语法敏感内容，检测误报率高）——
 *   显式边界，文档已披露。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { matchPathAllowed } from "./path-match.ts";

// ── 检测（纯函数） ───────────────────────────────────────────────────────────

/** 表情序列：EP 基字符（可选 FE0F），后接零或多段 ZWJ+EP（可选 FE0F）。 */
const EMOJI_SEQ_RE = /\p{Extended_Pictographic}(?:\uFE0F)?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F)?)*/gu;
/** 键帽序列：# * 0-9 + 可选 FE0F + U+20E3 组合用键帽。 */
const KEYCAP_RE = /[#*0-9]\uFE0F?\u20E3/gu;
/** 肤色修饰符（Emoji_Modifier 区段）。 */
const SKIN_TONE_RE = /[\u{1F3FB}-\u{1F3FF}]/gu;
/** regional 旗帜：U+1F1E6..U+1F1FF 连串（非 EP，独立匹配；成对为旗帜，孤立为孤立指示符）。 */
const REGIONAL_RE = /[\u{1F1E6}-\u{1F1FF}]+/gu;
/** 四组正则属性互斥（EP/键帽基字符/肤色/指示符），扫描区间不重叠。 */
const SCAN_RES = [EMOJI_SEQ_RE, KEYCAP_RE, SKIN_TONE_RE, REGIONAL_RE] as const;
/** 剥离后的孤儿呈现字符：变体选择符/键帽组合符/零宽连接符（文档语义中无合法独立用途）。 */
const ORPHAN_PRESENTATION_RE = /[\uFE0F\u20E3\u200D]/gu;

/** 默认白名单：本框架自用的文本呈现技术符号（码点级）。 */
export const DEFAULT_EMOJI_ALLOW = ["\u26A0", "\u2194", "\u21A9", "\u23F8", "\u23F1", "\u23F3", "\u25B6", "\u2328", "\u2716"] as const;

export interface EmojiHit {
	/** 命中的 emoji 序列原文（可能是多码点）。 */
	char: string;
	/** 码点列表（U+XXXX 形式，空格分隔）。 */
	codepoints: string;
	/** 1 基行号。 */
	line: number;
	/** 1 基列号（码点计）。 */
	column: number;
	/** 序列首码点在原文中的索引（UTF-16 code unit 偏移）。 */
	index: number;
}

/** 序列是否白名单内：仅允许单基字符+可选 FE0F 的文本呈现形态；
 *  ZWJ 链/键帽/肤色修饰符/regional 指示符恒不放行（多码点组合即 emoji 意图）。 */
function isAllowedSequence(match: string, allow: ReadonlySet<string>): boolean {
	if (match.includes("\u200D") || match.includes("\u20E3")) return false;
	for (const ch of match) {
		if (ch === "\uFE0F") continue;
		const cp = ch.codePointAt(0)!;
		if ((cp >= 0x1f3fb && cp <= 0x1f3ff) || (cp >= 0x1f1e6 && cp <= 0x1f1ff)) return false;
		if (!allow.has(ch)) return false;
	}
	return true;
}

function codepointsOf(s: string): string {
	return [...s].map((c) => `U+${c.codePointAt(0)!.toString(16).toUpperCase().padStart(4, "0")}`).join(" ");
}

/** 行列定位（1 基；按码点计列）。 */
function locate(text: string, index: number): { line: number; column: number } {
	let line = 1;
	let lastNl = -1;
	for (let i = 0; i < index; i++) if (text.charCodeAt(i) === 0x0a) { line++; lastNl = i; }
	let column = 0;
	for (let i = lastNl + 1; i < index; i++) {
		const cp = text.codePointAt(i)!;
		if (cp > 0xffff) i++;
		column++;
	}
	return { line, column: column + 1 };
}

/** 扫描全部非白名单 emoji 命中区间（升序；四组正则互斥不重叠）。 */
function scanRanges(src: string, allowSet: ReadonlySet<string>): Array<{ start: number; end: number; match: string }> {
	const out: Array<{ start: number; end: number; match: string }> = [];
	for (const re of SCAN_RES) {
		re.lastIndex = 0;
		let m: RegExpExecArray | null;
		while ((m = re.exec(src)) !== null) {
			if (isAllowedSequence(m[0], allowSet)) continue;
			out.push({ start: m.index, end: m.index + m[0].length, match: m[0] });
		}
	}
	out.sort((a, b) => a.start - b.start);
	return out;
}

/** 找出全部非白名单 emoji（含键帽/肤色修饰符/regional 旗帜）。纯函数，不修改入参。 */
export function findEmoji(text: string, allow?: ReadonlyArray<string>): EmojiHit[] {
	const src = String(text);
	const allowSet = allow === undefined ? new Set<string>(DEFAULT_EMOJI_ALLOW) : new Set(allow);
	return scanRanges(src, allowSet).map(({ start, match }) => {
		const { line, column } = locate(src, start);
		return { char: match, codepoints: codepointsOf(match), line, column, index: start };
	});
}

/** 剥离全部非白名单 emoji + 孤儿呈现字符（FE0F/20E3/200D）。返回剥离后文本与移除清单。 */
export function stripEmoji(text: string, allow?: ReadonlyArray<string>): { text: string; removed: EmojiHit[] } {
	const src = String(text);
	const allowSet = allow === undefined ? new Set<string>(DEFAULT_EMOJI_ALLOW) : new Set(allow);
	const ranges = scanRanges(src, allowSet);
	if (ranges.length === 0) return { text: src, removed: [] };
	let out = "";
	let cursor = 0;
	for (const { start, end } of ranges) {
		if (start < cursor) continue; // 防御：理论不重叠
		out += src.slice(cursor, start);
		cursor = end;
	}
	out += src.slice(cursor);
	const cleaned = out.replace(ORPHAN_PRESENTATION_RE, "");
	const removed = ranges.map(({ start, match }) => {
		const { line, column } = locate(src, start);
		return { char: match, codepoints: codepointsOf(match), line, column, index: start };
	});
	return { text: cleaned, removed };
}

// ── 配置（amagi.json `emojiGuard` 节；全局+项目合并，mtime 缓存；与 decision 同模式）──

export interface EmojiGuardConfig {
	enabled: boolean;
	/** files 面执法模式：strip=剥离放行+结果注记；block=拦截+诊断（模型去 emoji 重试）。 */
	mode: "strip" | "block";
	/** 白名单字符（码点级；项目级声明即完整替换默认技术符号集，显式空数组 = 全禁）。 */
	allow: string[];
	/** 排除路径（plain 前缀 / glob / prefix: 三形态，语义同 task-permission path-match）。 */
	excludePaths: string[];
	/** assistant 会话文本剥离（message_end 面；恒为剥离语义，无 block）。 */
	conversation: boolean;
	/** write/edit 工具面。 */
	files: boolean;
}

const EMOJI_GUARD_DEFAULTS: EmojiGuardConfig = {
	enabled: false,
	mode: "strip",
	allow: [...DEFAULT_EMOJI_ALLOW],
	excludePaths: [],
	conversation: true,
	files: true,
};

function globalAmagiConfigPath(): string {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi.json");
}

const configCache = new Map<string, { stamp: string; cfg: EmojiGuardConfig }>();

/** 测试注入：绕过读盘直接固定配置（null 恢复读盘路径）。 */
export function _setEmojiGuardConfigForTest(cfg: EmojiGuardConfig | null): void {
	injectedConfig = cfg;
	configCache.clear();
}
let injectedConfig: EmojiGuardConfig | null = null;

function readSection(file: string): Record<string, unknown> | null {
	try {
		const json = JSON.parse(fs.readFileSync(file, "utf8"));
		return (json && typeof json === "object" && "emojiGuard" in json) ? (json.emojiGuard as Record<string, unknown>) : null;
	} catch { return null; }
}

function mergeSection(base: EmojiGuardConfig, section: Record<string, unknown>): EmojiGuardConfig {
	const cfg: EmojiGuardConfig = { ...base };
	if (typeof section.enabled === "boolean") cfg.enabled = section.enabled;
	if (section.mode === "strip" || section.mode === "block") cfg.mode = section.mode;
	if (Array.isArray(section.allow)) {
		// diting F2：项目级声明即完整替换（非拼接）；显式空数组 = 全禁（连默认技术符号也拦）。
		cfg.allow = section.allow.filter((c): c is string => typeof c === "string" && c.length > 0);
	}
	if (Array.isArray(section.excludePaths)) {
		const paths = section.excludePaths.filter((p): p is string => typeof p === "string" && p.trim().length > 0);
		cfg.excludePaths = [...new Set([...cfg.excludePaths, ...paths])];
	}
	if (typeof section.conversation === "boolean") cfg.conversation = section.conversation;
	if (typeof section.files === "boolean") cfg.files = section.files;
	return cfg;
}

function applyEnvFlip(cfg: EmojiGuardConfig, env: NodeJS.ProcessEnv): EmojiGuardConfig {
	const v = (env.AMAGI_EMOJI_GUARD ?? "").trim().toLowerCase();
	if (v === "1" || v === "true" || v === "on") return { ...cfg, enabled: true };
	if (v === "0" || v === "false" || v === "off") return { ...cfg, enabled: false };
	return cfg;
}

/** 读 emojiGuard 配置：全局打底、项目覆盖（标量项目优先；allow 项目级完整替换、excludePaths 拼接去重）；mtime 缓存即时生效。 */
export function loadEmojiGuardConfig(cwd?: string): EmojiGuardConfig {
	if (injectedConfig !== null) return injectedConfig;
	const files = [globalAmagiConfigPath(), path.join(path.resolve(cwd ?? process.cwd()), "amagi.json")];
	const stamps = files.map((f) => { try { return `${fs.statSync(f).mtimeMs}`; } catch { return "-"; } }).join("|");
	const cacheKey = files.join("::");
	const cached = configCache.get(cacheKey);
	if (cached && cached.stamp === stamps) return applyEnvFlip(cached.cfg, process.env);
	let cfg = EMOJI_GUARD_DEFAULTS;
	for (const f of files) {
		const section = readSection(f);
		if (section !== null) cfg = mergeSection(cfg, section);
	}
	configCache.set(cacheKey, { stamp: stamps, cfg });
	return applyEnvFlip(cfg, process.env);
}

/** 测试/外部复位缓存。 */
export function resetEmojiGuardConfigCache(): void {
	configCache.clear();
}

// ── 诊断文案 ─────────────────────────────────────────────────────────────────

/** block 模式拦截文案：字符级清单（码点+行列）+ 自纠指引。 */
export function emojiGuardReason(kind: "write" | "edit", target: string, hits: EmojiHit[]): string {
	const listed = hits.slice(0, 8).map((h) => `  第 ${h.line} 行第 ${h.column} 列  ${h.char}  ${h.codepoints}`).join("\n")
		+ (hits.length > 8 ? `\n  …另有 ${hits.length - 8} 处` : "");
	return `[amagi emoji-guard] ${path.basename(target)}（${kind}）内容含 ${hits.length} 处 emoji，已拦截：\n${listed}\n本环境禁止 emoji——请移除 emoji 后用等效文字表达（如 ✅→「通过」、❌→「未通过」、⚠️→「注意：」），再重新发起本次写入。技术符号确需保留时可扩展 amagi.json emojiGuard.allow 白名单；该文件确属 emoji 用途时可配 emojiGuard.excludePaths。`;
}

/** strip 模式 tool_result 注记（强感知：让模型知道落盘内容与所写有差，后续自纠）。 */
export function emojiStripNote(hits: EmojiHit[]): string {
	const chars = [...new Set(hits.map((h) => h.char))].slice(0, 8).join(" ");
	return `[amagi emoji-guard] 已从写入内容中剥离 ${hits.length} 处 emoji（${chars}）——本环境禁止 emoji，落盘内容为剥离后版本；后续输出请直接使用等效文字。`;
}

// ── 注册器 ─────────────────────────────────────────────────────────────────

export interface EmojiGuardPi {
	on(event: "tool_call", handler: (event: { toolCallId: string; toolName: string; input: Record<string, unknown> }) => { block?: boolean; reason?: string } | void): void;
	on(event: "tool_result", handler: (event: { toolCallId: string; toolName: string; content: Array<{ type: string; text?: string }>; isError: boolean }) => { content?: Array<{ type: string; text?: string }> } | void): void;
	on(event: "message_end", handler: (event: { message: unknown }) => { message?: unknown } | void): void;
}

export interface EmojiGuardDeps {
	/** 工作目录（相对路径解析与 excludePaths 匹配基准）。 */
	cwd?: string;
	/** 配置读取器（缺省 loadEmojiGuardConfig；测试注入）。 */
	loadConfig?: (cwd?: string) => EmojiGuardConfig;
	/** 诊断输出（缺省 console.warn；传 null 静音）。 */
	diag?: ((msg: string) => void) | null;
}

/** tool_call 事件处理返回形态（测试可直接驱动）。 */
type ToolCallResult = { block?: boolean; reason?: string } | void;

interface TextBlockLike { type: string; text?: string; textSignature?: string }
interface MessageLike { role?: string; content?: unknown }

/**
 * 注册 emoji 硬拦截护栏。返回各事件处理函数（测试可直接驱动）。
 * - files 面（write.content / edit.edits[].newText）：block 拦截；strip 原地剥离 + tool_result 注记；
 * - conversation 面（assistant text 块）：message_end 替换剥离（textSignature 块跳过）；
 * - 配置每次事件现读（mtime 缓存）——改 amagi.json 即时生效，无需重启。
 */
export function registerEmojiGuard(pi: EmojiGuardPi, deps: EmojiGuardDeps = {}): {
	onToolCall: (event: { toolCallId: string; toolName: string; input: Record<string, unknown> }) => ToolCallResult;
	onToolResult: (event: { toolCallId: string; toolName: string; content: Array<{ type: string; text?: string }>; isError: boolean }) => { content?: Array<{ type: string; text?: string }> } | void;
	onMessageEnd: (event: { message: unknown }) => { message?: unknown } | void;
} {
	const cwd = deps.cwd ?? process.cwd();
	const load = deps.loadConfig ?? loadEmojiGuardConfig;
	const diag = deps.diag === null ? undefined : deps.diag ?? ((m: string) => console.warn(m));
	/** strip 模式待注记清单（toolCallId → 移除记录；上限防膨胀）。 */
	const pendingNotes = new Map<string, EmojiHit[]>();

	const excluded = (target: string): boolean => {
		const cfg = load(cwd);
		if (cfg.excludePaths.length === 0) return false;
		return matchPathAllowed(path.resolve(cwd, target), cfg.excludePaths, cwd);
	};

	const onToolCall = (event: { toolCallId: string; toolName: string; input: Record<string, unknown> }): ToolCallResult => {
		try {
			const cfg = load(cwd);
			if (!cfg.enabled || !cfg.files) return;
			if (event.toolName === "write") {
				const input = event.input as { path?: string; content?: string };
				if (typeof input?.path !== "string" || typeof input?.content !== "string") return;
				if (excluded(input.path)) return;
				const hits = findEmoji(input.content, cfg.allow);
				if (hits.length === 0) return;
				if (cfg.mode === "block") {
					diag?.(`[amagi emoji-guard] ${path.basename(input.path)}（write）：${hits.length} 处 emoji 已 block`);
					return { block: true, reason: emojiGuardReason("write", input.path, hits) };
				}
				const r = stripEmoji(input.content, cfg.allow);
				input.content = r.text; // 原地剥离：落盘为剥离后版本
				pendingNotes.set(event.toolCallId, r.removed);
				if (pendingNotes.size > 64) pendingNotes.delete(pendingNotes.keys().next().value as string);
				diag?.(`[amagi emoji-guard] ${path.basename(input.path)}（write）：已剥离 ${r.removed.length} 处 emoji（strip）`);
				return;
			}
			if (event.toolName === "edit") {
				// pi 0.86.0 edit schema：单文件 { path, edits } / 多文件 { files: string[], edits }
				//（与 edit-override 同形状；diting F1：旧 file_path 形状在 pi 0.86.0 下恒缺失 → edit 面死路）。
				const input = event.input as { path?: string; files?: unknown; selection?: unknown; newText?: string; edits?: Array<{ oldText?: string; newText?: string }> };
				const edits = Array.isArray(input?.edits) ? input.edits : input?.selection !== undefined ? [input] : [];
				if (edits.length === 0) return;
				const targets: string[] = [];
				if (typeof input.path === "string" && input.path.trim() !== "") targets.push(input.path);
				else if (Array.isArray(input.files)) {
					for (const f of input.files) if (typeof f === "string" && f.trim() !== "") targets.push(f);
				}
				if (targets.length === 0) return;
				if (targets.some((t) => excluded(t))) return;
				const label = targets.length === 1 ? targets[0]! : `${targets[0]} 等 ${targets.length} 文件`;
				if (cfg.mode === "block") {
					const reasons: string[] = [];
					for (let i = 0; i < edits.length; i++) {
						const e = edits[i]!;
						if (typeof e?.newText !== "string") continue;
						const hits = findEmoji(e.newText, cfg.allow); // 只查 newText：oldText 必须逐字匹配原文，永不触碰
						if (hits.length > 0) reasons.push(emojiGuardReason("edit", `${label} edits[${i}]`, hits));
					}
					if (reasons.length > 0) {
						diag?.(`[amagi emoji-guard] ${path.basename(label)}（edit）：${reasons.length} 条编辑含 emoji 已 block`);
						return { block: true, reason: reasons.join("\n\n") };
					}
					return;
				}
				let total = 0;
				const merged: EmojiHit[] = [];
				for (let i = 0; i < edits.length; i++) {
					const e = edits[i]!;
					if (typeof e?.newText !== "string") continue;
					const hits = findEmoji(e.newText, cfg.allow); // 命中先收集（剥离后重扫为空）
					if (hits.length === 0) continue;
					const r = stripEmoji(e.newText, cfg.allow);
					e.newText = r.text; // 原地剥离（oldText 永不触碰）
					merged.push(...hits);
					total += hits.length;
				}
				if (total > 0) {
					pendingNotes.set(event.toolCallId, [...(pendingNotes.get(event.toolCallId) ?? []), ...merged]);
					if (pendingNotes.size > 64) pendingNotes.delete(pendingNotes.keys().next().value as string);
					diag?.(`[amagi emoji-guard] ${path.basename(label)}（edit）：已剥离 ${total} 处 emoji（strip）`);
				}
				return;
			}
		} catch { /* 护栏自身异常零干预（放行原生语义） */ }
		return;
	};

	/** strip 模式注记：在工具结果尾部追加剥离清单（不改写原内容）。 */
	const onToolResult = (event: { toolCallId: string; toolName: string; content: Array<{ type: string; text?: string }>; isError: boolean }): { content?: Array<{ type: string; text?: string }> } | void => {
		try {
			const hits = pendingNotes.get(event.toolCallId);
			if (!hits || hits.length === 0) return;
			if (!Array.isArray(event.content)) return; // diting F5：content 不可追加时保留待注记（不吞记录）
			pendingNotes.delete(event.toolCallId);
			return { content: [...event.content, { type: "text", text: emojiStripNote(hits) }] };
		} catch { return; }
	};

	/** 会话面：assistant text 块剥离（textSignature 块与 thinking 块跳过——签名重放约束）。 */
	const onMessageEnd = (event: { message: unknown }): { message?: unknown } | void => {
		try {
			const cfg = load(cwd);
			if (!cfg.enabled || !cfg.conversation) return;
			const msg = event.message as MessageLike | null | undefined;
			if (!msg || msg.role !== "assistant" || !Array.isArray(msg.content)) return;
			let changed = false;
			const content = (msg.content as unknown[]).map((b) => {
				const block = b as TextBlockLike | null;
				if (block && typeof block === "object" && block.type === "text" && typeof block.text === "string" && block.textSignature === undefined) {
					const r = stripEmoji(block.text, cfg.allow);
					if (r.removed.length > 0) {
						changed = true;
						diag?.(`[amagi emoji-guard] 会话 assistant 文本：已剥离 ${r.removed.length} 处 emoji`);
						return { ...block, text: r.text };
					}
				}
				return b;
			});
			return changed ? { message: { ...msg, content } } : undefined;
		} catch { return; }
	};

	pi.on("tool_call", onToolCall);
	pi.on("tool_result", onToolResult);
	pi.on("message_end", onMessageEnd);
	return { onToolCall, onToolResult, onMessageEnd };
}
