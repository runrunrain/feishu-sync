/**
 * data-dir.ts — 运行数据目录统一解析（E2：迁出包目录）。
 *
 * 背景：traces / routing-stats / agent-stats / rpc-sessions / rpc-wal 原落 <packageRoot>/data/，
 * 而 `pi update` 以重装方式更新 git package——包内 data/ 每次更新被清空，路由记忆资产归零。
 * 现默认迁至 <agentDir>/amagi/data/（agentDir 尊重 PI_CODING_AGENT_DIR），与包生命周期解耦。
 *
 * 解析优先级：
 *   1. AMAGI_DATA_DIR（测试/运维注入）
 *   2. <PI_CODING_AGENT_DIR || ~/.pi/agent>/amagi/data
 *
 * 迁移：首次解析时把包内 legacy data/ 的已知条目复制到新目录（仅当目标不存在；复制非移动，失败静默）。
 * 各消费者仍保留原有单项环境变量覆盖（AMAGI_TRACES_PATH / AMAGI_ROUTING_PATH / AMAGI_STATS_PATH /
 * AMAGI_RPC_SESSION_DIR / AMAGI_RPC_WAL_DIR），优先级高于本目录。
 *
 * v2.1-A1 机器身份：machine.json（首次生成随机 UUID，永不变更）存本目录——ownerId 改用
 * user@machineId 派生后不再随网络环境/hostname 漂移；损坏回退 hostname 派生并告警（不阻断启动）。
 */

import { randomUUID } from "node:crypto";
import * as fs from "node:fs";
// 注意：default import 而非 namespace import——内建模块 ESM namespace 冻结不可 mock，
// default 导出是活的 CJS exports 对象（测试经 createRequire 补丁注入 hostname 漂移模拟）。
import os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

/** 包根（extensions/amagi-core/ 上两级）。 */
export function packageRoot(): string {
	return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
}

function agentDir(): string {
	return process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

let migrated = false;

/** 把 legacy 数据目录的已知条目复制到 target（仅当目标条目不存在；复制非移动，单项失败静默）。 */
export function copyLegacyDataItems(legacy: string, target: string): void {
	if (legacy === target) return;
	const items = ["traces", "routing-stats.json", "agent-stats.ndjson", "rpc-sessions", "rpc-wal"];
	for (const item of items) {
		try {
			const src = path.join(legacy, item);
			const dst = path.join(target, item);
			if (!fs.existsSync(src) || fs.existsSync(dst)) continue;
			fs.mkdirSync(path.dirname(dst), { recursive: true });
			fs.cpSync(src, dst, { recursive: true });
		} catch {
			// 容错：单项迁移失败不影响其余条目与主流程
		}
	}
}

/** 首次调用时把包内 legacy data/ 条目复制到新数据目录。 */
function migrateLegacyData(target: string): void {
	if (migrated) return;
	migrated = true;
	copyLegacyDataItems(path.join(packageRoot(), "data"), target);
}

/** amagi 运行数据目录（惰性迁移 + 目录预建；测试注入 AMAGI_DATA_DIR 时不触发迁移）。 */
export function amagiDataDir(): string {
	const dir = process.env.AMAGI_DATA_DIR || path.join(agentDir(), "amagi", "data");
	if (!process.env.AMAGI_DATA_DIR) migrateLegacyData(dir);
	try { fs.mkdirSync(dir, { recursive: true }); } catch {}
	return dir;
}

/** 数据目录内文件解析便捷函数（等价 path.join(amagiDataDir(), ...rel)）。 */
export function amagiDataFile(...rel: string[]): string {
	return path.join(amagiDataDir(), ...rel);
}

// ── v2.1-A1：持久化机器身份（machine.json） ──────────────────────────────────

const MACHINE_ID_FILE = "machine.json";
let machineIdCache: string | undefined;

/** 机器身份损坏/不可持久化时的回退派生（hostname 口径；每进程稳定，修复 machine.json 后重启恢复持久身份）。 */
function hostnameFallbackId(): string {
	let host = "local";
	try { host = os.hostname() || "local"; } catch { /* 兼容无 hostname 环境 */ }
	return `machine-${host}`;
}

/** 读取已持久化的机器身份：ok=有效值；missing=首次生成路径；bad=损坏/不可读（告警后回退，不覆盖）。 */
type PersistedMachineId = { kind: "ok"; id: string } | { kind: "missing" } | { kind: "bad" };

function readPersistedMachineId(file: string): PersistedMachineId {
	let raw: string;
	try {
		raw = fs.readFileSync(file, "utf8");
	} catch (e) {
		if ((e as NodeJS.ErrnoException).code === "ENOENT") return { kind: "missing" };
		console.warn(`[amagi-core] machine.json 读取失败（${file}，${(e as NodeJS.ErrnoException).code ?? String(e)}）——回退 hostname 派生机器身份；修复数据目录后重启恢复持久身份`);
		return { kind: "bad" };
	}
	try {
		const parsed = JSON.parse(raw) as { machineId?: unknown };
		if (typeof parsed.machineId === "string" && parsed.machineId.trim()) return { kind: "ok", id: parsed.machineId.trim() };
	} catch { /* 坏 JSON 走统一告警 */ }
	console.warn(`[amagi-core] machine.json 损坏（${file}）——回退 hostname 派生机器身份；修复/重建该文件后重启恢复持久身份（不自动覆盖损坏文件）`);
	return { kind: "bad" };
}

/** machine.json 首次落盘（仅 missing 路径）：tmp+link（O_EXCL 语义，绝不覆盖已存在文件）；
 *  并发首建竞败时回读对方值。返回生效机器身份（竞胜=新 UUID；竞败=对方已落盘值；失败=undefined）。 */
function persistMachineId(file: string, fresh: string): string | undefined {
	const tmp = `${file}.tmp-${process.pid}-${randomUUID().slice(0, 8)}`;
	try {
		fs.mkdirSync(path.dirname(file), { recursive: true });
		fs.writeFileSync(tmp, `${JSON.stringify({ machineId: fresh, createdAt: new Date().toISOString() }, null, 2)}\n`, "utf8");
		try {
			fs.linkSync(tmp, file); // 原子 create-or-fail：已存在即并发竞败（不覆盖对方）
		} catch (e) {
			if ((e as NodeJS.ErrnoException).code === "EEXIST") {
				// 并发竞败：回读对方值保持本机身份与磁盘一致（静默——对方文件可读即正常路径）
				const winner = readPersistedMachineId(file);
				if (winner.kind === "ok") return winner.id;
				throw new Error("并发首建的 machine.json 不可读");
			}
			throw e;
		}
		return fresh;
	} catch (e) {
		console.warn(`[amagi-core] machine.json 落盘失败（${file}，${e instanceof Error ? e.message : String(e)}）——本进程回退 hostname 派生机器身份；恢复持久身份需修复数据目录后重启`);
		return undefined;
	} finally {
		try { fs.rmSync(tmp, { force: true }); } catch { /* best-effort */ }
	}
}

/**
 * v2.1-A1：本机持久身份。首次调用生成随机 UUID 写入 <amagiDataDir>/machine.json，此后永不变更
 * （跨进程/重启/网络环境变化稳定——ownerId user@machineId 派生不再随 hostname 漂移）。
 * 语义：损坏（坏 JSON/形状非法/读写失败）→ console.warn 告警 + 回退 hostname 派生（不阻断启动、
 * 不自动覆盖损坏文件——修复后重启即恢复持久身份）；每进程缓存（告警至多一次）。
 */
export function getMachineId(): string {
	if (machineIdCache !== undefined) return machineIdCache;
	const file = amagiDataFile(MACHINE_ID_FILE);
	const persisted = readPersistedMachineId(file);
	if (persisted.kind === "ok") {
		machineIdCache = persisted.id;
		return persisted.id;
	}
	// 仅 missing 走首次生成；bad（损坏/不可读）已告警，回退 hostname 派生——不覆盖损坏文件
	const effective = persisted.kind === "missing" ? persistMachineId(file, randomUUID()) : undefined;
	machineIdCache = effective ?? hostnameFallbackId();
	return machineIdCache;
}

/** 测试隔离：复位机器身份缓存（生产不调用；配合 AMAGI_DATA_DIR/损坏文件注入重放解析路径）。 */
export function resetMachineIdForTest(): void {
	machineIdCache = undefined;
}
