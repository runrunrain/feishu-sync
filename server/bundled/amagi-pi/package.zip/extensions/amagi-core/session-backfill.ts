/**
 * session-backfill.ts — resume 跨 Leader 重启的磁盘回填（v1.5.222）。
 *
 * 背景（实战 cbc75699）：task registry 是进程内存态——Leader pi 进程重启后 registry 清空，
 * `task({ session })` 一律 "未找到会话"，哪怕任务 artifact/metadata 完好、pi 会话文件仍在。
 * resume 本不必依赖原进程存活：会话真相在磁盘（artifact metadata.json + pi sessions 目录）。
 *
 * 回填链（缺什么补什么）：
 *   1. 定位任务：`<artifactRoot>/<taskId>/metadata.json`（精确 taskId 直取；前缀走 index.ndjson
 *      从尾向前扫——resume 后缀任务也在索引里，取最新命中）；
 *   2. sessionId：metadata.sessionId（v1.5.222 起索引行也带）缺失信时，扫 pi sessions 目录：
 *      按项目 cwd 推导目录，前 4 行内找 `session_info.name === "<agent>-<taskId8>"` 的
 *      .jsonl，取首行 session 头的 id（实测：部分被杀任务 metadata 无 sessionId）；
 *   3. journal 回退（ev-20260903-a5b662，复盘 §1.2）：artifact 链未命中时查 journal——
 *      被杀任务没有 metadata（只在 finalize 写入），但 dispatch 行（spawn 前）+ session 行
 *      （子进程首帧即落盘）恰好有 taskId/agent/cwd/at/sessionId 全部真相；命中即按中断残留
 *      收编（status=error，与 mapStatus running→error 语义一致）。
 *
 * 边界：只读回填（不写任何文件）；扫盘有界（单目录 ≤300 文件 × 4 行）；任何失败返回 error
 * 理由，调用方降级为原报错文案。状态映射与 restoreFromSnapshot 重启语义一致
 * （running→error / answering→blocked / queued→cancelled）。
 *
 * K8a（方案 §8.1-K8a / §3.4-N9）：历史回填只产候选——磁盘候选导入不再直接收编 registry。
 * 有 v2 契约记录（<contractRoot>/<taskId>/current.json）的任务一律走候选语义：返回 ok:false
 * 并给出对账指引（统一对账入口 task-recovery.applyTaskRecovery → 内核 reconcile 采纳后才进
 * registry 投影）；旧磁盘恢复不得旁路补成功（旧路径把 metadata/journal 的状态猜测直接落进
 * registry，v2 语义下这属于对不确定执行猜测结果）。无契约记录 = v2 前遗留任务，原行为保留
 * （K6 B3 同语义：遗留接管/回填不产生内核态）。fail-closed：契约目录存在但 current.json
 * 不可读同样拒绝自动收编。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { artifactRoot, contractStoreRoot, sanitizeId } from "./artifact.ts";
import { journalLookupByPrefix } from "./journal.ts";
// ev-20261005-055864：gate 放行后的契约真相（current.json）status 覆盖——见 ContractGateDecision.execution

export interface BackfillRecord {
	taskId: string;
	agent: string;
	sessionId?: string;
	model?: string;
	name?: string;
	/** diting F-05/F-02：契约路径下为执行态原值（含 resolved-external/running——resume 准入据此如实拒绝）；仅 legacy 遗留任务走 mapStatus 映射。 */
	status: string;
	/** diting Major-4：blocked 结构化原因（metadata.blockReason；缺省=遗留 questions 语义）。 */
	blockReason?: "questions" | "needs-handoff";
	startedAt: number;
	endedAt?: number;
	blockedAt?: number;
	cwd?: string;
	result?: string;
}

export type BackfillResult =
	| { ok: true; record: BackfillRecord; sessionIdFromDisk: boolean; note: string; /** ev-20261005-055864（diting F-02）：契约任务 gate 放行路径——record.status 是契约执行态原值（非 mapStatus 映射），收编必须走内核权威投影（resolveSessionForResume 的 adoptContractProjection），绝不经 adoptExternal 桥重种子。 */ contractProjection?: boolean }
	| { ok: false; error: string; contractCandidate?: { taskId: string; reason: string } };

const TERMINAL_BACKFILL_STATUS = new Set(["done", "error", "cancelled", "blocked"]);

function mapStatus(raw: unknown): BackfillRecord["status"] {
	if (typeof raw !== "string") return "error";
	if (TERMINAL_BACKFILL_STATUS.has(raw)) return raw as BackfillRecord["status"];
	if (raw === "running" || raw === "answering") return "error"; // 原 Leader 已死：非终态视作 error（answering 保守不回 blocked——无待答证据）
	if (raw === "queued") return "cancelled";
	return "error";
}

function readJson(file: string): Record<string, unknown> | null {
	try {
		return JSON.parse(fs.readFileSync(file, "utf8"));
	} catch {
		return null;
	}
}

// ── K8a：v2 契约记录探测（同步只读）──────────────────────────────────────────

/** 契约记录事实（current.json 轻量读取；不做完整 load——采纳由内核对账入口负责）。 */
interface ContractProbe {
	execution: string;
	recovery: "none" | "needs-reconciliation";
	processState: string;
	hasCurrentReceipt: boolean;
	corrupt: boolean;
}

function probeContractTask(taskId: string): ContractProbe | null {
	let curPath: string;
	try {
		curPath = path.join(contractStoreRoot(), sanitizeId(taskId), "current.json");
	} catch {
		return null; // 契约根不可解析 → 视为无契约记录（遗留任务，原行为）
	}
	let exists = false;
	try { exists = fs.existsSync(curPath); } catch { return null; }
	if (!exists) return null; // 无契约记录 = v2 前遗留任务
	const cur = readJson(curPath);
	if (!cur || typeof cur.taskId !== "string" || typeof cur.execution !== "string") {
		return { execution: "unknown", recovery: "needs-reconciliation", processState: "unknown", hasCurrentReceipt: false, corrupt: true };
	}
	return {
		execution: String(cur.execution),
		recovery: cur.recovery === "needs-reconciliation" ? "needs-reconciliation" : "none",
		processState: typeof cur.processState === "string" ? String(cur.processState) : "unknown",
		hasCurrentReceipt: cur.currentReceipt != null,
		corrupt: false,
	};
}

/** K8a 候选门决策：有契约记录的任务不再无条件自动收编——磁盘候选只保留给对账入口采纳。
 *  ev-20261005-055864（根因修复）：旧 gate 对一切契约任务拒收编，而「统一对账入口采纳」在重启后
 *  从不自动发生（恢复对账只在唤起原会话且 sessionKey 匹配时应用）——resume 死锁：报「磁盘回退
 *  亦未命中」实为候选门拒绝被吞，只能全新重派（scope/模型/cwd 继承语义丢失）。新规则（状态判定
 *  仍单源内核，收编只是 resume 执行面的视图）：
 *  - corrupt → 拒绝（fail-closed，需人工核验）；
 *  - 已标 needs-reconciliation（对账已采纳）→ 放行；
 *  - 干净终态（done/error/cancelled/truncated/resolved-external，无需猜状态）→ 放行；
 *  - 其余活跃/待答态（queued/running/blocked/answering/answered）未标记 → 拒绝但给
 *    contractCandidate（resume 链自动经 reconcileRestartTask 即时对账后重试）。 */
interface ContractGateDecision {
	allowed: boolean;
	reason: string | null;
	/** 拒绝且可经单任务对账解除（resume 链自动处置入口）。 */
	needsReconcile: boolean;
	taskId: string;
	/** 契约真相（current.json 的 execution）——gate 放行时作 status 权威源（不依赖 registry 投影，
	 *  重启场景 kernel.get 不可用；磁盘 metadata 声称的 status 不果信——防旁路补成功语义保持）。 */
	execution?: string;
}

const CLEAN_TERMINAL_EXECUTIONS = new Set(["done", "error", "cancelled", "truncated", "resolved-external"]);

function contractCandidateGate(taskId: string): ContractGateDecision | null {
	const probe = probeContractTask(taskId);
	if (!probe) return null;
	// diting F-04：corrupt（current.json 不可读）优先拒绝且不可经 reconcile 解除——fail-closed，
	// 人工核验（旧实现 probe 携 recovery=needs-reconciliation 被「已标」分支误放行）。
	if (probe.corrupt) {
		return { allowed: false, reason: `v2 契约任务 ${taskId.slice(0, 8)} 的 current.json 不可读（fail-closed）——先人工核验/修复契约记录再 resume（统一对账入口不会修复损坏记录）`, needsReconcile: false, taskId };
	}
	if (probe.recovery === "needs-reconciliation") return { allowed: true, reason: null, needsReconcile: false, taskId, execution: probe.execution };
	if (CLEAN_TERMINAL_EXECUTIONS.has(probe.execution)) return { allowed: true, reason: null, needsReconcile: false, taskId, execution: probe.execution };
const facts = `execution=${probe.execution}, processState=${probe.processState}`;
	const reason = (
		`v2 契约任务 ${taskId.slice(0, 8)} 有契约记录（${facts}）——活跃/待答态未经对账处置不自动收编（K8a/N9：不旁路补状态、不猜）；` +
		`先经统一对账入口（单任务 reconcileRestartTask 即时对账 / applyTaskRecovery）标记后回填`
	);
	return { allowed: false, reason, needsReconcile: !probe.corrupt, taskId };
}

/** 前缀扫 index.ndjson（从尾向前 = 最新优先）；返回最新命中 taskId 或 null。 */
function scanIndexForPrefix(root: string, prefix: string): string | null {
	const idx = path.join(root, "index.ndjson");
	try {
		const text = fs.readFileSync(idx, "utf8");
		const lines = text.split("\n").filter(Boolean);
		for (let i = lines.length - 1; i >= 0; i--) {
			try {
				const e = JSON.parse(lines[i]);
				if (typeof e.taskId === "string" && (e.taskId === prefix || e.taskId.startsWith(prefix))) return e.taskId;
			} catch { /* 脏行跳过 */ }
		}
	} catch { /* 无索引/读失败 */ }
	return null;
}

/** pi sessions 目录扫描：按 session_info.name 匹配 `agent-taskId8`，返回 session id。 */
export function scanPiSessionId(opts: { agent: string; taskId: string; cwd?: string; startedAt?: number }): string | undefined {
	try {
		const agentRoot = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
		const sessionsRoot = path.join(agentRoot, "sessions");
		const wanted = `${opts.agent}-${opts.taskId.slice(0, 8)}`;
		// 项目目录推导：/Users/x/proj → --Users-x-proj--（与 pi sessions 布局一致；cwd 缺失则全 sessions 扫描）
		const projectDirs: string[] = [];
		if (opts.cwd) projectDirs.push(path.join(sessionsRoot, "--" + opts.cwd.split(/[\\/]+/).filter(Boolean).join("-") + "--"));
		projectDirs.push(sessionsRoot); // 兜底：resume 跨 cwd 时任务可能在别的项目目录
		const floor = typeof opts.startedAt === "number" && opts.startedAt > 0 ? opts.startedAt - 24 * 3600_000 : 0;
		for (const dir of projectDirs) {
			let files: string[];
			try { files = fs.readdirSync(dir); } catch { continue; }
			const cands = files
				.filter((f) => f.endsWith(".jsonl"))
				.map((f) => path.join(dir, f))
				.filter((f) => { try { const m = fs.statSync(f).mtimeMs; return m >= floor; } catch { return false; } })
				.sort((a, b) => { try { return fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs; } catch { return 0; } })
				.slice(0, 300);
			for (const file of cands) {
				try {
					const head = fs.readFileSync(file, "utf8").slice(0, 2048).split("\n").slice(0, 4);
					let sid: string | undefined;
					let named = false;
					for (const line of head) {
						if (!line.trim()) continue;
						const ev = JSON.parse(line);
						if (ev?.type === "session" && typeof ev.id === "string") sid = ev.id;
						if (ev?.type === "session_info" && ev?.name === wanted) named = true;
					}
					if (named && sid) return sid;
				} catch { /* 脏文件跳过 */ }
			}
		}
	} catch { /* 全链容错 */ }
	return undefined;
}

/** 从磁盘回填 resume 所需任务记录；失败返回可读理由。 */
/** ev-20260903-a5b662：journal 回退（artifact 真相缺失时的磁盘兑底）。null = journal 未命中
 *  （调用方维持原报错）；sessionId 优先取 journal session 行，缺失时用 dispatch 行的
 *  agent/taskId/cwd/at 调 scanPiSessionId 扫 pi sessions 目录兑底；拿不到则 ok:false 但
 *  文案附 journal 命中信息（taskId/agent 可读，便于人工排查）。 */
function backfillFromJournal(q: string): BackfillResult | null {
	let hit: ReturnType<typeof journalLookupByPrefix>;
	try { hit = journalLookupByPrefix(q); } catch { return null; }
	if (!hit) return null;
	// K8a：契约任务按 gate 决策——ev-20261005-055864：干净终态/已对账处置放行（status 以内核权威
	// 覆盖「固定 error 中断残留」猜测）；活跃未标记拒收编并给 contractCandidate（resume 链即时对账重试）
	const gate = contractCandidateGate(hit.taskId);
	if (gate && !gate.allowed) return { ok: false, error: gate.reason ?? "契约候选门拒绝", ...(gate.needsReconcile ? { contractCandidate: { taskId: gate.taskId, reason: gate.reason ?? "" } } : {}) };
	const kernelExecution = gate?.allowed ? gate.execution : undefined;
	// diting F-02：契约路径 status 为执行态原值（非 mapStatus 映射）+ contractProjection 标记；
	// resume 准入据此如实拒绝（running/resolved-external 不再被映射成 error 绕过拒绝）
	const record: BackfillRecord = {
		taskId: hit.taskId,
		agent: hit.agent,
		// 宿主级联终止时任务在跑：中断残留语义（与 mapStatus running→error 一致）；
		// gate 放行时取内核权威态（journal 无 artifact 真相，磁盘无 status 可信——内核是唯一事实源）
		status: kernelExecution ?? "error",
		startedAt: hit.at,
		cwd: hit.cwd,
		result: "[journal 回填] 宿主级联终止时任务运行中，无 artifact（metadata 只在 finalize 写入）；按 journal dispatch/session 行收编为 error 中断残留",
	};
	const fromJournalSession = typeof hit.sessionId === "string" && hit.sessionId;
	if (fromJournalSession) record.sessionId = hit.sessionId;
	else {
		const sid = scanPiSessionId({ agent: hit.agent, taskId: hit.taskId, cwd: hit.cwd, startedAt: hit.at });
		if (sid) record.sessionId = sid;
	}
	if (!record.sessionId) {
		return { ok: false, error: `journal 命中 ${hit.taskId.slice(0, 8)}（agent=${hit.agent}）但 sessionId 不可恢复（journal 无 session 行且 sessions 目录无 "${hit.agent}-${hit.taskId.slice(0, 8)}" 匹配）` };
	}
	const note = `已从 journal 回填 ${hit.taskId.slice(0, 8)}（${hit.agent}/error；${fromJournalSession ? "sessionId 来自 journal session 行" : "sessionId 由 sessions 目录补齐"}）`;
	return { ok: true, record, sessionIdFromDisk: !fromJournalSession, note, ...(gate?.allowed ? { contractProjection: true } : {}) };
}

export function backfillSessionRecord(query: string): BackfillResult {
	const q = String(query || "").trim();
	if (!q) return { ok: false, error: "空会话标识" };
	if (q.includes("/")) return { ok: false, error: "runId/name 复合键不支持磁盘回填（仅 taskId/前缀）" };
	let root: string;
	try { root = artifactRoot(); } catch { return { ok: false, error: "artifact 根不可用（AMAGI_ARTIFACT_ROOT）" }; }
	// ① 精确目录 → ② 索引前缀扫描
	let taskId: string | null = null;
	const exact = path.join(root, sanitizeId(q), "metadata.json");
	if (fs.existsSync(exact)) {
		taskId = sanitizeId(q);
	} else {
		taskId = scanIndexForPrefix(root, q);
	}
	if (!taskId) {
		// ev-20260903-a5b662：artifact 目录与索引均未命中（被杀任务没有 finalize 落盘）→ journal 回退。
		const jf = backfillFromJournal(q);
		if (jf) return jf;
		return { ok: false, error: `artifact 目录与 index.ndjson 均未命中前缀 "${q}"` };
	}
	// K8a：契约任务按 gate 决策——已对账处置/干净终态放行（ev-20261005-055864），活跃未标记拒收编并
	// 给 contractCandidate（resume 链自动即时对账重试）
	const gate = contractCandidateGate(taskId);
	if (gate && !gate.allowed) return { ok: false, error: gate.reason ?? "契约候选门拒绝", ...(gate.needsReconcile ? { contractCandidate: { taskId: gate.taskId, reason: gate.reason ?? "" } } : {}) };
	const meta = readJson(path.join(root, sanitizeId(taskId), "metadata.json"));
	if (!meta || typeof meta.taskId !== "string" || typeof meta.agent !== "string") {
		// 索引命中但 metadata 缺损（半成品 artifact）→ 同样先 journal 回退再报错。
		const jf = backfillFromJournal(q);
		if (jf) return jf;
		return { ok: false, error: `metadata.json 缺失或无 taskId/agent（${taskId.slice(0, 8)}）` };
	}
	const record: BackfillRecord = {
		taskId: meta.taskId,
		agent: meta.agent,
		status: mapStatus(meta.status),
		startedAt: typeof meta.startedAt === "number" ? meta.startedAt : Date.now(),
	};
	if (typeof meta.sessionId === "string" && meta.sessionId) record.sessionId = meta.sessionId;
	if (typeof meta.model === "string" && meta.model) record.model = meta.model;
	if (typeof meta.name === "string" && meta.name) record.name = meta.name;
	if (typeof meta.endedAt === "number") record.endedAt = meta.endedAt;
	if (typeof meta.cwd === "string" && meta.cwd) record.cwd = meta.cwd;
	if (record.status === "blocked" && (meta.blockReason === "questions" || meta.blockReason === "needs-handoff")) record.blockReason = meta.blockReason;
	if (meta.blocked === true && record.status === "blocked") record.blockedAt = record.endedAt ?? record.startedAt;
	// ev-20261005-055864：契约任务 gate 放行（已对账处置/干净终态）时，status 以契约真相
	// （current.json execution，gate 同源事实）覆盖磁盘 metadata 猜测——磁盘面可声称 done 而契约
	// 真相 running（K8a D2 防旁路语义保持：采纳路径只有契约事实，不信 metadata 声称）。
	if (gate?.allowed) {
		if (gate.execution) record.status = gate.execution; // diting F-02：执行态原值（非映射）——收编走内核权威投影
		else return { ok: false, error: `契约任务 ${taskId.slice(0, 8)} gate 放行但契约真相不可读——先经统一对账入口处置再 resume` };
	}
	// sessionId 缺失 → sessions 目录扫描补齐（实测：被杀/异常路径 metadata 常缺 sessionId）
	let sessionIdFromDisk = false;
	if (!record.sessionId) {
		const sid = scanPiSessionId({ agent: record.agent, taskId: record.taskId, cwd: record.cwd, startedAt: record.startedAt });
		if (sid) { record.sessionId = sid; sessionIdFromDisk = true; }
	}
	if (!record.sessionId) {
		return { ok: false, error: `未定位 sessionId（metadata 缺失且 sessions 目录无 "${record.agent}-${record.taskId.slice(0, 8)}" 匹配）` };
	}
	const note = `已从磁盘回填 ${record.taskId.slice(0, 8)}（${record.agent}/${record.status}${sessionIdFromDisk ? "；sessionId 由 sessions 目录补齐" : ""}）`;
	return { ok: true, record, sessionIdFromDisk, note, ...(gate?.allowed ? { contractProjection: true } : {}) };
}
