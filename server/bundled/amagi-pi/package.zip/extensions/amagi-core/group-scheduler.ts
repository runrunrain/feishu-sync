import type { ContextMode } from "./contracts/task.ts";
/**
 * group-scheduler.ts — Group Scheduler 与结构化交接（v2 批次C）。
 *
 * 背景（v2 分析 §6.3/§7）：五种编排（fanout/pipeline/tournament/redteam/fork）此前是
 * orchestrate 内联宏展开：节点间交接靠前序输出的 1500/2000 字符硬截断（信息损失），
 * 无统一结果封装、无 group 查询/取消、无依赖解锁语义（stale 结果也能解锁下游）。
 *
 * 本模块把五模板统一为 typed group template + 轻量 DAG 执行器：
 *  - ResultEnvelope 是唯一节点终态封装（completed/failed/cancelled/stale；blocked 按
 *    兼容映射为 failed/code=blocked——envelope 只表示终态，待答暂停仍由 TaskRecord 承载）。
 *  - 节点间交接 = envelope + artifactRefs（下游 read result.md 看全文），summary 仅供
 *    快速判断，不承担完整交接——pipeline/tournament/redteam 不再依赖字符硬截断。
 *  - 依赖满足才解锁 ready 节点：unlockOn="completed"（pipeline 链：上游失败即暂停）或
 *    "terminal"（judge/attack barrier：completed|failed 解锁）；**cancelled/stale 一律不解锁**
 *    （退出门：stale revision 不解锁下游），未解锁节点如实列入 skipped 不静默消失。
 *  - K8b（v2 §3.5/§8.1-K8b）：批次依赖解锁消费 K7 回执面。声明 requires 的边走回执三轴通道
 *    （accepted 默认产物边 / ready 审查边 / settled 诊断边）；未声明的边走兼容解释器（旧模板
 *    "done 即解锁"条件显式映射为 envelope 语义保留——新图按新契约）。解锁时把上游回执 hash
 *    固定进下游交接（envelope.receipt 快照 + handoffBlock 锚点——下游引用归档版本，不追随
 *    可变"最新结果"）；组内存在等待 Leader 接受的节点时立即暂停返回（组句柄 + 逐节点状态，
 *    resumeGroupAfterAcceptance 续跑），不同步阻塞等完整图。
 *  - 并发容量由共享 admission 承载（每个节点 runTask/runResume 内部排队），调度器本身
 *    不做第二份并发计数（避免双重排队）。
 *  - submitGroup 异步返回 handle（Leader 不被长 group 隐式 await 占住）；waitGroup 是显式
 *    同步点；cancelGroup 级联取消全部未终态节点（不遗留无人管理的 worker）。
 *  - Group 状态由节点状态推导，不复制一套独立真相（v2 §6.2）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { registry } from "./task-registry.ts";
import { artifactEnabled, findArtifact, taskContextArtifactRefs } from "./artifact.ts";
import { finalizeTerminal, type FinalizeTerminalOpts } from "./finalizer.ts";
import { waitTasks, cancelTask, resolveExternalTask, peekTaskKernel } from "./task-service.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import type { AcceptanceState, ReceiptSettlement } from "./contracts/task.ts";
import type { AgentConfig } from "./agents-loader.ts";
import type { RunResult, BackgroundStart } from "./task-tool.ts";
// ev-20260914-9084ee：allowedPaths 白名单共享 matcher（glob/prefix: 语法；节点级解析与 reportPath 互锁同源）
import { parseAllowedPathEntry, resolveAllowedPathEntry, matchPathAllowed } from "./path-match.ts";

// ─────────────────────────────────────────────────────────────────────────────
// ResultEnvelope（v2 §6.3）
// ─────────────────────────────────────────────────────────────────────────────

export type EnvelopeStatus = "completed" | "failed" | "cancelled" | "stale";

export interface ResultEnvelope {
	taskId: string;
	runId?: string;
	nodeId?: string;
	revision: number;
	status: EnvelopeStatus;
	/** Leader 快速判断用摘要（不承担完整交接；完整结果在 artifactRefs）。 */
	summary: string;
	artifactRefs: string[];
	/** 当前节点真实终稿文件；只有归档存在时提供，不把输入/普通产物冒称完整结果。 */
	resultRef?: string;
	evidenceRefs?: string[];
	acceptance?: { passed: boolean; detailsRef?: string };
	error?: { code: string; message: string };
	/** resume 续接引用（sessionId）。 */
	sessionRef?: string;
	/** 展示 sidecar：保留原始输出/状态标签/标注（编排汇总渲染用；不参与交接协议）。 */
	display?: { output?: string; status?: string; completionAnnotation?: string; modelNote?: string; fuseWarning?: string };
	/** K8b：上游回执摘要快照（节点终态时刻固定——交接引用此归档版本，不随后续 decide/重发变化）。 */
	receipt?: EnvelopeReceiptRef;
}

/** K8b：回执锚点（解锁时固定进下游 spec 的"上游回执 hash"——来自内核 TaskView 当前回执摘要）。 */
export interface EnvelopeReceiptRef {
	receiptId: string;
	receiptSeq: number;
	/** 回执归属任务 revision（内核失效栅栏口径；发布/决策不推进 revision）。 */
	revision: number;
	settlement: ReceiptSettlement;
	acceptance: AcceptanceState;
	specDigest: string;
	/** 回执文件内容寻址引用（digest=SHA-256；回执不可变——hash 即归档版本指纹）。 */
	receiptRef?: { path: string; digest: string; bytes: number };
}

/** RunResult/TaskRecord → ResultEnvelope 兼容映射（done→completed、error→failed、
 *  cancelled→cancelled、blocked→failed/code=blocked；stale 由 finalizer/revision 判定注入）。 */
export function envelopeOf(
	/** diting Major-4：blockReason 区分 questions/needs-handoff（与 RunResult 同源字段，此最小面此前漏声明）。 */
	rr: { taskId: string; status: string; blocked?: boolean; blockReason?: "questions" | "needs-handoff" | string; output?: string; errorMessage?: string; sessionId?: string; completionAnnotation?: string; modelNote?: string; fuseWarning?: string },
	opts?: { runId?: string; nodeId?: string; artifactRefs?: string[]; revision?: number; stale?: boolean },
): ResultEnvelope {
	const rec = registry.get(rr.taskId);
	const revision = opts?.revision ?? rec?.revision ?? 0;
	const cwd = rec?.cwd || process.cwd();
	const artifactRefs = taskContextArtifactRefs(rr.taskId, opts?.artifactRefs ?? rec?.artifactRefs ?? [], rec?.upstreamArtifactRefs ?? [], cwd);
	const resultRef = artifactEnabled() ? findArtifact(cwd, rr.taskId)?.relResult : undefined;
	const summary = (rr.output || rr.errorMessage || "").replace(/\s+/g, " ").trim().slice(0, 500);
	// 展示 sidecar（编排汇总渲染保留原始口径；blocked 状态标签优先）
	const display: ResultEnvelope["display"] = { output: rr.output, status: rr.blocked ? "blocked" : rr.status, completionAnnotation: rr.completionAnnotation, modelNote: rr.modelNote, fuseWarning: rr.fuseWarning };
	const artifactContext = { artifactRefs, ...(resultRef ? { resultRef } : {}) };
	if (rr.status === "cancelled") {
		return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "cancelled", summary, ...artifactContext, sessionRef: rr.sessionId, display, error: { code: "cancelled", message: rr.errorMessage || "任务被取消" } };
	}
	if (opts?.stale) {
		return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "stale", summary, ...artifactContext, sessionRef: rr.sessionId, display, error: { code: "stale", message: "revision 不匹配：结果已过期（stale），不解锁下游、不进最终综合" } };
	}
	if (rr.blocked || rr.status === "blocked") {
		// diting Major-4：handoff 的 blocked 语义是「resume 接手开工」，不是信息不足待答复。
		const _blockedMsg = rr.blockReason === "needs-handoff"
			? "settle 产出窗口收口（NEEDS_HANDOFF，非提问）：任务带交付物但本轮零写盘——resume 续跑接手开工"
			: "任务 blocked（信息不足，待 Leader 答复后续跑）";
		return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "failed", summary, ...artifactContext, sessionRef: rr.sessionId, display, error: { code: "blocked", message: rr.errorMessage || _blockedMsg } };
	}
	if (rr.status === "done") {
		return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "completed", summary, ...artifactContext, sessionRef: rr.sessionId, display };
	}
	// P1（8月迭代第三轮）：输出截断≠失败——会话/产物在，按 completed 解锁下游（display.status 保留
	// truncated 标签 + annotation 指引；终稿由 Leader 决定是否 resume 补拿）。
	if (rr.status === "truncated") {
		return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "completed", summary, ...artifactContext, sessionRef: rr.sessionId, display };
	}
	return { taskId: rr.taskId, runId: opts?.runId, nodeId: opts?.nodeId, revision, status: "failed", summary, ...artifactContext, sessionRef: rr.sessionId, display, error: { code: "error", message: rr.errorMessage || "(无失败根因)" } };
}

/**
 * 节点间交接块（refs 替代字符截断的核心）：下游任务文本引用 artifact 全文 + 摘要。
 * artifact 缺失（artifact store 关闭/测试注入路径）时内联实际输出，不能裁掉唯一可用的任务资料。
 */
export function handoffBlock(label: string, env: ResultEnvelope): string {
	// 老组恢复的 envelope 可能尚无 resultRef，按当前节点 taskId 查实际归档，绝不展开祖先 refs。
	const rec = registry.get(env.taskId);
	const cwd = rec?.cwd || process.cwd();
	let resultRef = artifactEnabled() ? findArtifact(cwd, env.taskId)?.relResult : undefined;
	if (artifactEnabled() && env.resultRef) {
		try { if (fs.statSync(env.resultRef).isFile()) resultRef = env.resultRef; } catch { /* 归档已删除：降级实际输出 */ }
	}
	const refs = taskContextArtifactRefs(env.taskId, env.artifactRefs, rec?.upstreamArtifactRefs || [], cwd);
	const state = env.status === "completed" ? "完成" : env.status === "failed" ? `失败(${env.error?.code || "error"})` : env.status;
	// K8b：回执锚点——解锁时刻固定的上游回执 hash（下游 spec 引用归档版本；receiptDigest 12 位前缀可读）。
	const anchor = env.receipt
		? `\n上游回执（已固定·归档版本）: receiptId=${env.receipt.receiptId} seq=${env.receipt.receiptSeq} settlement=${env.receipt.settlement} acceptance=${env.receipt.acceptance}${env.receipt.receiptRef ? ` receiptDigest=sha256:${env.receipt.receiptRef.digest.slice(0, 12)}…` : ""}（引用此版本，不随后续决策/重发变化）`
		: "";
	const failure = env.error ? `\n原因: ${env.error.message.replace(/\s+/g, " ").slice(0, 500)}` : "";
	if (resultRef) {
		return `[${label}] 状态 ${state}；完整结果已落盘: ${resultRef}（用 read 查看 result.md 全文，不要凭摘要臆断细节）${anchor}\n摘要: ${env.summary || "(无摘要)"}${failure}`;
	}
	// 普通产物引用不等于完整终稿。无归档时用实际输出降级，避免二次裁成 500 字摘要。
	const full = env.display?.output || env.summary || "(无输出)";
	const references = refs.length ? `\n本轮产物引用: ${refs.slice(0, 8).map((ref) => JSON.stringify(ref)).join(", ")}${refs.length > 8 ? `（其余 ${refs.length - 8} 项由 task_query output 查询）` : ""}` : "";
	return `[${label}] 状态 ${state}（artifact 不可用，以下为内联结果）${anchor}\n${full}${failure}${references}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// typed group template（DAG）
// ─────────────────────────────────────────────────────────────────────────────

export interface GroupNode {
	contextMode?: ContextMode;
	/** task_batch 提交点冻结的授权与产物声明；legacy 编排缺省不传。 */
	permission?: Readonly<PermissionGrant>;
	outputs?: ReadonlyArray<{ path: string; kind: "file" | "tree"; required: boolean; purpose?: string }>;
	nodeId: string;
	agent: string;
	model?: string;
	/** 稳定用户句柄；仅 OMP-style batch 设置，旧编排继续用任务正文作 goal。 */
	name?: string;
	/** 缺省 "task"（runTask）；"fork"（runResumeTask useFork 从 spec.forkSession 分叉）。 */
	kind?: "task" | "fork";
	/** 静态任务文本（无依赖或文本与依赖无关）。与 buildTask 二选一。 */
	task?: string;
	/** 动态任务：解锁时刻由已完成依赖的 envelope 构造（refs 交接在此注入）。 */
	buildTask?: (deps: Record<string, ResultEnvelope>) => string;
	/** A2 节点级 cwd：相对 deps.cwd 解析为绝对；空串/不存在/不是目录 → 该节点结构化拒单（不连坐整组）。缺省继承 deps.cwd。 */
	cwd?: string;
	/** 8月迭代 C3：节点级写入白名单（相对节点 cwd 解析为绝对，透传 runTask → 子进程 env AMAGI_ALLOWED_PATHS；
	 *  写入目标不在清单内即阻断）。解析失败（空数组/非法项）→ 节点级结构化拒单（invalid-allowed-paths，不连坐）。 */
	allowedPaths?: string[];
	/** ev-20260907-8abf9a：节点报告落盘路径（完整具体文件路径，相对节点 cwd 解析为绝对后注入该节点
	 *  assignment——消除任务书「…/<节点名>-report.md」尖括号占位符被子 Agent 解析成截断前缀的歧义）。
	 *  静态非法（空/占位符/目录形态）在 task-tool 层整单拒绝；此处节点级兜底 + 存在目录检查 +
	 *  allowedPaths 白名单兼容（不在白名单 → 节点拒单 invalid-report-path，绝不自动扩大白名单）。 */
	reportPath?: string;
	dependsOn?: string[];
	/** 解锁条件：completed=仅上游成功（pipeline 链暂停语义）；terminal=completed|failed（barrier 语义）。
	 *  两种模式下 cancelled/stale 依赖都不解锁（退出门）。缺省 terminal。
	 *  仅作用于未声明 requires 的边（兼容解释器通道）。 */
	unlockOn?: "completed" | "terminal";
	/** K8b（方案 §3.5）：新契约边——声明后本节点全部依赖边走回执三轴通道：
	 *  accepted=默认产物边（上游回执经 Leader 显式 decide accept 才解锁，N8：ready 不蕴含 accepted）；
	 *  ready=审查边（上游回执 settlement=ready 即解锁审查型下游，diting 类，不等人工接受）；
	 *  settled=诊断边（回执已发布即解锁，不继承可用产物——交接内容由模板层决定）。
	 *  两通道共同退出门：cancelled/stale/旧 revision envelope 一律不解锁。 */
	requires?: EdgeRequires;
	/** 关系附加（fork 的 parentTaskId 等）。 */
	parentTaskId?: string;
}

/** K8b：依赖边解锁条件（消费上游回执三轴）。 */
export type EdgeRequires = "accepted" | "ready" | "settled";

export interface GroupSpec {
	runId: string;
	nodes: GroupNode[];
	/** fork 模板：分叉源 session（kind="fork" 节点共用）。 */
	forkSession?: string;
}

export interface GroupRunDeps {
	cwd: string;
	modelRegistry?: unknown;
	command?: { command: string; args: string[] };
	onStall?: (info: { taskId: string; agent: string; idleMs: number }) => void;
	/** 已执行节点结算通知：envelope 入表后立即触发；回调异常不影响 group 调度。 */
	onNodeDone?: (envelope: ResultEnvelope) => void;
	/** 测试注入：替换节点执行（不建 registry/artifact；envelope 由返回值构造）。 */
	testRunNode?: (agent: AgentConfig, task: string, opts: { cwd: string; model?: string }) => Promise<RunResult>;
	/** 生产执行器（注入避免循环依赖：orchestrate 传 task-tool 的 runTask/runResumeTask）。 */
	runTask: (agent: AgentConfig, task: string, opts: Record<string, unknown>) => Promise<RunResult>;
	runResume: (agent: AgentConfig, params: Record<string, unknown>, opts: Record<string, unknown>) => Promise<RunResult | BackgroundStart>;
	findAgent: (name: string) => AgentConfig | undefined;
	/** 证据采集 trust 门（finalizer 透传）。 */
	trusted?: boolean;
	/** K8b：证据采集注入透传（finalizer evidence 口；测试注入结构化 gatherReport 驱动回执 checks。
	 *  生产缺省省略——走真实采集链；trusted/baselinePorcelain 仍由 runGroupNode 自身合并）。 */
	evidence?: { trusted?: boolean; gatherReport?: NonNullable<FinalizeTerminalOpts["evidence"]>["gatherReport"]; gatherEv?: NonNullable<FinalizeTerminalOpts["evidence"]>["gatherEv"]; sharedTree?: boolean };
}

export interface GroupRunOutcome {
	runId: string;
	envelopes: Record<string, ResultEnvelope>;
	/** 因依赖未满足（失败/取消/stale）而从未启动的节点（如实列出，不静默消失）。 */
	skipped: Array<{ nodeId: string; reason: string }>;
	isError: boolean;
	/** K8b：组暂停等待人工接受（非终局）——组内存在 requires=accepted 边且上游回执 unreviewed
	 *  时立即返回（不同步阻塞等完整图）；Leader decide accept 后 resumeGroupAfterAcceptance 续跑。 */
	awaitingAcceptance?: GroupAwaitEntry[];
}

/** K8b：待接受上游明细（阻塞的下游节点清单）。 */
export interface GroupAwaitEntry {
	/** 上游节点 nodeId。 */
	nodeId: string;
	/** 上游 taskId。 */
	taskId: string;
	/** 上游当前回执 receiptId（Leader decide 引用它）。 */
	receiptId: string;
	/** 被该等待阻塞的下游 nodeId。 */
	blockedNodes: string[];
}

/** K8b：暂停组现场（已执行节点 envelope/级联跳过快照——resume 续跑不重复执行已结算节点）。 */
export interface GroupPauseCarry {
	envelopes: Record<string, ResultEnvelope>;
	skipped: Array<{ nodeId: string; reason: string }>;
	isError: boolean;
}

const UNLOCK_TERMINAL = new Set<EnvelopeStatus>(["completed", "failed"]); // cancelled/stale 不解锁

/** 单条依赖边判定（K8b）：ready=解锁 / wait=依赖未终态（不猜，等待） / dead=不可解锁（级联跳过） /
 *  await-accept=上游回执已发布待 Leader 显式接受（组暂停，不级联跳过）。 */
type EdgeVerdict = "ready" | "wait" | "dead" | "await-accept";

function verdictOfEdge(node: GroupNode, e: ResultEnvelope | undefined, stillPending: boolean): EdgeVerdict {
	if (!e) return stillPending ? "wait" : "dead"; // 依赖不存在/已被级联跳过
	if (e.status === "stale" || e.status === "cancelled") return "dead"; // 退出门：stale/cancelled 不解锁（两通道共同）
	const req = node.requires;
	if (!req) {
		// 兼容解释器（K8b）：旧模板"done 即解锁"条件显式映射为 envelope 语义保留——
		// unlockOn=completed ⟺ 上游执行成功；缺省 terminal ⟺ completed|failed（旧 barrier 集）。
		if (node.unlockOn === "completed" && e.status !== "completed") return "dead";
		return UNLOCK_TERMINAL.has(e.status) ? "ready" : "dead";
	}
	// K8b 回执通道（新契约边）：核对内核当前视图三轴（调度侧核对 acceptance/settlement——内核栅栏已拒
	// 旧 revision 回执落盘，此处再核对 envelope↔视图 revision 防 envelope 过期）。
	const view = e.taskId !== "?" ? peekTaskKernel()?.get(e.taskId) : undefined;
	if (!view) {
		// 兼容解释回退：非契约上游（测试注入/无内核任务）无回执面——按旧 envelope 语义显式映射
		//（ready 边 ⟺ completed；accepted/settled 边 ⟺ 旧 terminal 集合）。
		if (req === "ready") return e.status === "completed" ? "ready" : "dead";
		return UNLOCK_TERMINAL.has(e.status) ? "ready" : "dead";
	}
	if (view.revision !== e.revision) return "dead"; // 旧 revision envelope：内核已重写（N3 退出门）
	if (view.execution === "cancelled" || view.execution === "resolved-external") return "dead"; // 取消/外部处置不解锁产物依赖
	const receipt = view.receipt;
	if (!receipt) return "wait"; // 回执未发布（finalize 在途/发布失败/store 回滚）：不猜，等待
	if (req === "accepted") {
		if (view.acceptance === "accepted") return "ready";
		if (view.acceptance === "rejected") return "dead"; // reject 表达不接受——默认边不可解锁
		return "await-accept"; // unreviewed：等待 Leader 显式 decide（N8：ready 不蕴含 accepted）
	}
	if (req === "ready") return receipt.settlement === "ready" ? "ready" : "dead"; // 审查边：ready 即解锁，不等接受
	return "ready"; // settled：回执已发布即解锁（诊断边；不继承可用产物——交接内容由模板层决定）
}

/** K8b：dead 边原因文案（级联跳过 reason；回执通道给出三轴事实）。 */
function deadReasonOf(node: GroupNode, e: ResultEnvelope): string {
	if (!node.requires || e.taskId === "?") return e.status;
	const view = peekTaskKernel()?.get(e.taskId);
	if (!view) return e.status;
	if (view.revision !== e.revision) return `stale（envelope revision=${e.revision} ≠ 当前 ${view.revision}）`;
	if (view.execution === "cancelled" || view.execution === "resolved-external") return view.execution;
	if (view.receipt) {
		if (node.requires === "accepted") return `回执 ${view.receipt.settlement}/${view.acceptance}（requires=accepted 未满足）`;
		if (node.requires === "ready") return `回执 ${view.receipt.settlement}（requires=ready 未满足）`;
	}
	return `execution=${view.execution}（回执未发布）`;
}

/** group 级取消标记：cancelGroup 后置位，调度循环在每层解锁前检查——未启动节点不再解锁（无孤儿 worker）。 */
const cancelledGroups = new Set<string>();

/** A2 节点级 cwd 解析（与 task-tool resolveTaskCwd 同语义；独立实现避免 task-tool⇄group-scheduler 值级循环依赖）。
 * 失败不 throw：返回错误描述由调用方构造节点级结构化拒单 envelope（其余节点不受影响）。 */
function resolveNodeCwd(param: string | undefined, depsCwd: string): { ok: true; cwd: string } | { ok: false; message: string } {
	if (param === undefined) return { ok: true, cwd: depsCwd };
	const trimmed = param.trim();
	if (!trimmed) return { ok: false, message: `节点 cwd 为空串（继承缺省请直接省略 cwd 键；缺省为 ${depsCwd}）` };
	const resolved = path.isAbsolute(trimmed) ? trimmed : path.resolve(depsCwd, trimmed);
	let st: fs.Stats;
	try { st = fs.statSync(resolved); } catch { return { ok: false, message: `节点 cwd "${trimmed}"（解析为 ${resolved}）不存在` }; }
	if (!st.isDirectory()) return { ok: false, message: `节点 cwd "${trimmed}"（解析为 ${resolved}）不是目录` };
	return { ok: true, cwd: resolved };
}

/** C3 节点级 allowedPaths 白名单解析（相对节点 cwd → 绝对；与 task-tool resolveAllowedPaths 同构但失败显式拒单而非静默丢弃——
 *  空清单会阻断该节点全部写入（配置事故），与静默丢弃（等同放行全部）同样危险，故节点级如实拒单）。
 * 失败不 throw：返回错误描述由调用方构造节点级结构化拒单（其余节点不受影响）。
 * ev-20260909-e4d4f2: export 供 task-tool 派发端预检复用 */
export function resolveNodeAllowedPaths(param: unknown, nodeCwd: string): { ok: true; paths: string[] } | { ok: false; message: string } {
	if (param === undefined) return { ok: true, paths: [] };
	if (!Array.isArray(param) || param.length === 0) return { ok: false, message: `[invalid-allowed-paths] 节点 allowedPaths 必须是非空字符串数组（收到 ${Array.isArray(param) ? "空数组" : typeof param}）` };
	const out: string[] = [];
	for (const p of param) {
		if (typeof p !== "string" || !p.trim()) return { ok: false, message: `[invalid-allowed-paths] 节点 allowedPaths 含非法项: ${JSON.stringify(p)}（必须为非空字符串）` };
		// ev-20260914-9084ee：glob（如 "data/cfg/gds_*.tres"）/prefix:（如 "prefix:data/cfg/gds_"）语法条目
		// scheme 保留解析，与写守卫端 matchPathAllowed 同源；语法无效显式拒单（不静默丢弃安全边界声明）。
		const parsed = parseAllowedPathEntry(p);
		if (parsed.invalid) return { ok: false, message: `[invalid-allowed-paths] 节点 allowedPaths 含语法无效项: ${JSON.stringify(p)}（${parsed.invalid}）` };
		out.push(resolveAllowedPathEntry(p, nodeCwd));
	}
	return { ok: true, paths: out };
}

/** ev-20260907-8abf9a（ux/P1）+ Leader 验收修正：reportPath 静态非法检测（task-tool 整单拒绝层与本节点级
 *  兜底层共用同一正则，语义统一）——
 *  ① 未展开占位符三形态：<节点名> / ${name} / {nodeName}（裸花括号标识符——shell/模板变量残留）；
 *  ② 控制字符（\x00-\x1f 含换行/CR/NUL + \x7f）——reportPath 会被注入子进程 prompt 文本，
 *     控制字符是 prompt 注入面，一律拒。
 *  事故：任务书模板「报告写 …/<节点名>-report.md」被 2/11 实现节点解析为截断前缀，落盘单字符路径
 *  …/s2-immortal-sect-dev/c。reportPath 值是 Leader 显式提供的具体路径，出现占位符/控制字符必是
 *  未展开事故或注入，直接拒单（不猜、不静默截断）。 */
export const REPORT_PATH_INVALID_RE = /<[^<>\n]{1,64}>|\$\{[^}\n]{1,64}\}|\{[A-Za-z_][A-Za-z0-9_-]{0,31}\}|[\x00-\x1f\x7f]/;

/** ev-20260907-8abf9a：节点报告路径解析（相对节点 cwd → 绝对）+ 白名单兼容校验。
 *  - 非法（空串/占位符/尾部斜杠目录形态/解析后是已存在目录）→ { ok:false }（节点级拒单，不连坐整组）；
 *  - allowedPaths 白名单存在且非空时：reportPath 绝对路径必须命中白名单之一（与 guards.assertAllowedPaths
 *    同语义前缀匹配——path.relative 不出目录即在内）；不在 → 拒单。绝不把 reportPath 自动追加进白名单
 *    （白名单是安全边界，结构化便利字段不得隐式扩权——需要写就由 Leader 显式把目录放进 allowedPaths）。
 *  供 task-tool 校验层与 runGroupNode 共用（纯函数，无副作用）。 */
export function resolveNodeReportPath(
	param: string | undefined,
	nodeCwd: string,
	allowedPaths: ReadonlyArray<string>,
): { ok: true; reportPathAbs?: string } | { ok: false; message: string } {
	if (param === undefined) return { ok: true };
	const trimmed = param.trim();
	if (!trimmed) return { ok: false, message: "[invalid-report-path] 节点 reportPath 为空串（不注入报告路径请直接省略该键）" };
	if (REPORT_PATH_INVALID_RE.test(trimmed)) {
		return { ok: false, message: `[invalid-report-path] 节点 reportPath 含未展开占位符或控制字符: ${JSON.stringify(trimmed)}——请提供完整具体文件路径（相对节点 cwd 解析，如 reports/c2a-report.md），不要 <节点名> / \${name} / {nodeName} 模板或换行/控制字符（占位符不会被展开，会被当作被截断的路径前缀）` };
	}
	if (/[\\/]$/.test(trimmed)) {
		return { ok: false, message: `[invalid-report-path] 节点 reportPath 以路径分隔符结尾（目录形态）: ${JSON.stringify(trimmed)}——报告路径必须是具体文件路径（如 reports/c2a-report.md），不是目录` };
	}
	const abs = path.isAbsolute(trimmed) ? trimmed : path.resolve(nodeCwd, trimmed);
	let st: fs.Stats | undefined;
	try { st = fs.statSync(abs); } catch { /* 不存在=新文件，合法 */ }
	if (st?.isDirectory()) {
		return { ok: false, message: `[invalid-report-path] 节点 reportPath 解析到已存在目录: ${abs}——报告路径必须是具体文件路径，不是目录` };
	}
	if (allowedPaths.length > 0) {
		// ev-20260914-9084ee：共享 matcher 判定（plain 目录/精确文件语义不变；glob/prefix: 新语法同样生效）
		const inside = matchPathAllowed(abs, allowedPaths, nodeCwd);
		if (!inside) {
			const preview = allowedPaths.slice(0, 3).join("、");
			// ev-20260909-3db230：拒单文案附「按当前参数展开的最小修复路径」——实战三次重提才对齐
			//（白名单目录粒度是子目录、报告落 demo 根，两条修复路径的选择靠试错）。直接给出可复制的
			// 完整候选：① reportPath 改白名单内（首个白名单目录+原文件名）；② 白名单追加报告所在目录。
			const _bn = path.basename(abs);
			const _candA = allowedPaths[0] ? (allowedPaths[0].endsWith(path.sep) ? `${allowedPaths[0]}${_bn}` : `${allowedPaths[0]}${path.sep}${_bn}`) : _bn;
			const _candB = path.dirname(abs);
			return { ok: false, message: `[invalid-report-path] 节点 reportPath 不在该节点 allowedPaths 白名单内: ${abs}（白名单共 ${allowedPaths.length} 项${preview ? `，如：${preview}` : ""}）——reportPath 不会自动扩大写权限。最小修复二选一（按当前参数展开，直接可复制）: ① 改 reportPath 为白名单内路径，如 "${_candA}"（或其他白名单目录内路径）；② tasks[].allowedPaths 追加 "${_candB}"（报告文件所在目录）` };
		}
	}
	return { ok: true, reportPathAbs: abs };
}

/** ev-20260907-8abf9a：reportPath 注入块——解析后的具体绝对路径作为唯一权威落点写入 assignment。
 *  文案要素：①完整绝对路径（子 Agent 无需再解析相对/占位语义）；②「以此行为准」压制任务书内
 *  残留的模糊路径描述；③硬验收声明（Leader 验收修正①：已接入交付物预检验收链——缺失会自动
 *  补跑一轮、仍缺按 blocked(needs-handoff) 收口，不只是文案约定）。 */
export function reportPathInjectionBlock(nodeId: string, reportPathAbs: string): string {
	return `\n\n[batch 节点 ${nodeId} 报告路径（reportPath 已解析）] 本节点报告请落盘到此具体文件路径: ${reportPathAbs}\n（相对路径已按节点工作目录解析为绝对路径；以此行为准——不要截断、改写或另猜路径，任务书内其他报告路径描述一律以本行为准；该路径已接入交付物验收链：未落盘会被自动补跑催交，仍缺则任务不判完成（blocked））`;
}

/** ev-20260917-8651a0（P3）：reportPath 推广到单任务派发（sync/background 顶层参数）——与 batch
 *  节点注入块同语义（解析后绝对路径作为唯一权威落点写入任务书）；静态校验/路径解析/目录拒单/
 *  白名单互锁复用 resolveNodeReportPath 同一实现（与 batch 零分叉）；交付物验收链：sync 走
 *  runTask deliverablePaths 完整预检催交链，background 完成通知附落盘核检提示。 */
export function singleReportPathInjectionBlock(reportPathAbs: string): string {
	return `\n\n[报告路径（reportPath 已解析）] 本任务报告请落盘到此具体文件路径: ${reportPathAbs}\n（相对路径已按任务工作目录解析为绝对路径；以此行为准——不要截断、改写或另猜路径，任务书内其他报告路径描述一律以本行为准；该路径已接入交付物验收链：sync 派发未落盘会被自动补跑催交、仍缺不判完成（blocked），background 派发完成通知附落盘核检）`;
}

/** ev-20260909-c00fcb②：白名单任务书内置「越界阻塞报告」契约段。实战（S4-02 值域扩展联动四层）
 *  靠 Leader 手写该段才兑住跨层联动越界（节点报告 BLOCKED 段落 + 完整补丁要点 → Leader 直修收口）；
 *  任务书没写该段时节点可能停摆或静默绕过。现固化为白名单任务默认注入模板，与 reportPath
 *  注入块同点装配（runGroupNode / 单派发 taskText / resume 续轮各处，覆盖全部派发形态）。 */
export function whitelistOverflowContractBlock(): string {
	// ev-20260914-fd863c：追加「探针文件去向」标准指引——实战：节点拟新建 tests/_n28_probe.gd
	//（白名单外临时探针）触发任务边界守卫反复拦截，达阈值后整进程 terminate、数十分钟工作靠
	// Leader resume 才续接。契约段前置告知正确去向，降低探针类越界的发生率（守卫端另做风险分级）。
	return `\n\n[白名单越界处置契约] 本任务带写入白名单。若完成目标必须修改白名单外的文件：不要停摆、不要静默绕过、不要尝试放宽边界——先完成白名单内的全部改动，然后在最终报告以「BLOCKED：越界文件」为标题成段列出每个越界必需改动（目标绝对路径 + 完整改动要点/补丁内容 + 为什么必须越界），交由 Leader 直修收口；仅靠白名单内改动无法完成时才停在报告处等待，不要自行降低完成标准。【探针文件去向】临时探针/中间验证产物不要写白名单外的仓库路径：优先写系统 tmp 或任务沙箱 amagi-task/<runId>/（自动在白名单内，24h 回收）；需要保留的最终断言并入白名单内既有测试文件，不要在白名单外新建探针文件。`;
}

/** ev-20260918-2fe431：共享资源锚定纪律段——写面含 resources/ 子树（canonical 知识资产）时注入。
 *  实战（batch-82d4bca9）：并行节点压缩 l0-template.md 措辞（字节预算合规、自身定向测试全绿），
 *  但删改措辞是 prompt-footprint/leader-continuation 等既有测试的锚词——共享纪律只要求跑
 *  「自己的测试」，造成 4 项 harness 基线红、跨节点排障两轮才收口。锚定纪律前置进任务书：
 *  改共享资源必须把引用测试全部定向跑绿，压缩措辞时同步锚词是任务责任。无命中返回空串零噪音。 */
export function anchoredResourceDisciplineBlock(entries: ReadonlyArray<string>): string {
	const anchored = entries.filter((e): e is string => typeof e === "string" && (e.startsWith("resources/") || e.includes("/resources/")));
	if (anchored.length === 0) return "";
	const listed = anchored.slice(0, 4).map((e) => JSON.stringify(e)).join("、") + (anchored.length > 4 ? ` 等 ${anchored.length} 项` : "");
	return `\n\n[共享资源锚定纪律] 本任务写面含共享资源（${listed}）。这类文件常被既有测试按具体措辞锚定：改动前先 \`grep -l "<文件路径>" tests/*.test.mjs\` 找出全部引用测试；完成后必须把这些引用测试全部定向跑绿（node --test <引用文件…>），不能只跑自己新增的测试；压缩/改写措辞时同步锚词属本任务责任，锚词失配会让整批 harness 基线变红。`;
}

/** 单节点执行 + 统一收尾 + envelope 构造（stale 判定：finalizer 与 revision 双通道）。 */
async function runGroupNode(spec: GroupSpec, node: GroupNode, depEnvs: Record<string, ResultEnvelope>, deps: GroupRunDeps): Promise<ResultEnvelope> {
	const ag = deps.findAgent(node.agent);
	const baseRev = 0;
	if (!ag) {
		return { taskId: "?", runId: spec.runId, nodeId: node.nodeId, revision: baseRev, status: "failed", summary: "", artifactRefs: [], error: { code: "unknown-agent", message: `未知角色 ${node.agent}` } };
	}
	// A2 节点级 cwd：解析失败 → 该节点结构化拒单，不整组失败（与 unknown-agent 同形态）
	const _cwdRes = resolveNodeCwd(node.cwd, deps.cwd);
	if (!_cwdRes.ok) {
		return { taskId: "?", runId: spec.runId, nodeId: node.nodeId, revision: baseRev, status: "failed", summary: "", artifactRefs: [], error: { code: "invalid-cwd", message: _cwdRes.message } };
	}
	const nodeCwd = _cwdRes.cwd;
	// 8月迭代 C3：节点级 allowedPaths 解析失败 → 该节点结构化拒单（同 invalid-cwd 形态，不连坐整组）
	const _allowedRes = resolveNodeAllowedPaths(node.allowedPaths, nodeCwd);
	if (!_allowedRes.ok) {
		return { taskId: "?", runId: spec.runId, nodeId: node.nodeId, revision: baseRev, status: "failed", summary: "", artifactRefs: [], error: { code: "invalid-allowed-paths", message: _allowedRes.message } };
	}
	// ev-20260907-8abf9a：节点报告路径解析（相对 nodeCwd → 绝对）+ allowedPaths 白名单兼容；
	// 非法/越界 → 节点级结构化拒单（invalid-report-path，不连坐整组——其余节点照常执行）
	const _rpRes = resolveNodeReportPath(node.reportPath, nodeCwd, _allowedRes.paths);
	if (!_rpRes.ok) {
		return { taskId: "?", runId: spec.runId, nodeId: node.nodeId, revision: baseRev, status: "failed", summary: "", artifactRefs: [], error: { code: "invalid-report-path", message: _rpRes.message } };
	}
	// reportPath 注入在 task 文本构造处（生产 runTask/runResume 与测试注入 testRunNode 共享同一路径——
	// 测试捕获的 task 即真实派发 prompt 主体）
	let task = node.buildTask ? node.buildTask(depEnvs) : (node.task || "");
	if (_rpRes.reportPathAbs) task += reportPathInjectionBlock(node.nodeId, _rpRes.reportPathAbs);
	// ev-20260909-c00fcb②：白名单任务注入越界处置契约（不停摆/不静默绕过，报告内成段列补丁要点）
	if (_allowedRes.paths.length > 0) task += whitelistOverflowContractBlock();
	// ev-20260918-2fe431：写面含共享资源（resources/）时注入锚定纪律（引用测试必须全绿）
	task += anchoredResourceDisciplineBlock(_allowedRes.paths);
	// Leader 验收修正①：显式 reportPath 接入 B1 交付物预检验收链（结构化通道 opts.deliverablePaths，
	// 绝对路径直接 existsSync——绕过 extractDeliverablePaths/extractArtifactRefs 的正则 token 分词，
	// 空格/中文路径无损；否则非 agent-outputs 报告路径不入预检，空报告也会被判 done）
	const deliverablePaths = _rpRes.reportPathAbs ? [_rpRes.reportPathAbs] : undefined;
	const relation = { runId: spec.runId, nodeId: node.nodeId, dependsOn: node.dependsOn, parentTaskId: node.parentTaskId };
	// 测试注入路径：不建 registry 记录，直接由返回值构造 envelope
	if (deps.testRunNode) {
		const rr = await deps.testRunNode(ag, task, { cwd: nodeCwd, model: node.model });
		return envelopeOf(rr, { runId: spec.runId, nodeId: node.nodeId });
	}
	let rr: RunResult;
	if (node.kind === "fork") {
		const r = await deps.runResume(ag, { session: spec.forkSession, task, model: node.model, useFork: true }, { cwd: nodeCwd, model: node.model, command: deps.command, skipLease: true, modelRegistry: deps.modelRegistry, onStall: deps.onStall, relation, trusted: deps.trusted });
		if ("status" in r && (r.status === "running" || r.status === "queued")) {
			// fork 节点为 sync 语义，正常不返回 handle；兜底如实 failed（不产生孤儿 worker——
			// background 句柄有自己的 onComplete 收尾链，不属本 group 管理面）。
			return { taskId: r.taskId, runId: spec.runId, nodeId: node.nodeId, revision: baseRev, status: "failed", summary: "", artifactRefs: [], error: { code: "unexpected-handle", message: "fork 节点返回了异步 handle（sync 语义被破坏）" } };
		}
		rr = r as RunResult;
	} else {
		rr = await deps.runTask(ag, task, { cwd: nodeCwd, model: node.model, command: deps.command, modelRegistry: deps.modelRegistry, onStall: deps.onStall, relation, description: node.name, name: node.name, trusted: deps.trusted, allowedPaths: _allowedRes.paths, deliverablePaths, ...(node.contextMode ? { contextMode: node.contextMode } : {}), ...(node.permission ? { permission: node.permission } : {}), ...(node.outputs ? { outputs: node.outputs } : {}) });
	}
	// 统一收尾链：基线必须来自 registry.create 后、执行前的快照；取消会 bump 当前 revision。
	// 不能在 runTask 返回后重读 registry，否则会把取消后的新 revision 当成基线，stale 永远失效。
	// K8b：deps.evidence（结构化 gatherReport 注入口）透传——测试可驱动回执 checks；缺省不变。
	const fin = await finalizeTerminal({ taskId: rr.taskId, agent: ag.name, result: rr, cwd: nodeCwd, evidence: { trusted: deps.evidence?.trusted ?? deps.trusted ?? false, ...(deps.evidence?.gatherReport ? { gatherReport: deps.evidence.gatherReport } : {}), ...(deps.evidence?.gatherEv ? { gatherEv: deps.evidence.gatherEv } : {}), baselinePorcelain: rr.gitBaseline, sharedTree: deps.evidence?.sharedTree === true }, expectedRevision: rr.dispatchRevision ?? baseRev });
	const env = envelopeOf(rr, { runId: spec.runId, nodeId: node.nodeId, stale: fin.stale });
	// K8b：回执面固定进 envelope（节点终态时刻快照；解锁交接引用归档版本——下游不追随可变"最新结果"）。
	// stale 无回执（内核栅栏拒发布）；非契约任务（无内核视图）不携带。
	if (!fin.stale) {
		const rview = peekTaskKernel()?.get(rr.taskId);
		if (rview?.receipt) {
			env.receipt = {
				receiptId: rview.receipt.receiptId,
				receiptSeq: rview.receipt.receiptSeq,
				revision: rview.revision,
				settlement: rview.receipt.settlement,
				acceptance: rview.receipt.acceptance,
				specDigest: rview.receipt.specDigest,
				...(rview.receipt.ref ? { receiptRef: { path: rview.receipt.ref.path, digest: rview.receipt.ref.digest, bytes: rview.receipt.ref.bytes } } : {}),
			};
		}
	}
	// B1（Wave B）：节点完成通知携带产物摘要块（finalizeTerminal 已采集；stale 无写副作用语义，不带）。
	if ((fin.automaticEvidence || fin.artifactSummary) && !fin.stale) {
		env.display = { ...env.display, completionAnnotation: [env.display?.completionAnnotation, fin.automaticEvidence || fin.artifactSummary].filter(Boolean).join("\n") };
	}
	return env;
}

/**
 * DAG 执行器：循环解锁 ready 节点（同层 Promise.all 并发，容量由共享 admission 排队承载）。
 * 依赖未满足（failed/cancelled/stale 上游）的节点级联列入 skipped——不部分静默、不盲目解锁。
 * K8b：requires=accepted 边遇上游回执 unreviewed 时**暂停**（awaitingAcceptance 携带待接受明细
 * 返回，未启动节点不级联跳过）——不同步阻塞等完整图；carry 参数支持暂停后续跑（已结算节点
 * 不重复执行）。
 */
export async function runGroup(spec: GroupSpec, deps: GroupRunDeps, carry?: GroupPauseCarry): Promise<GroupRunOutcome> {
	const envelopes: Record<string, ResultEnvelope> = { ...(carry?.envelopes ?? {}) };
	const skipped: Array<{ nodeId: string; reason: string }> = [...(carry?.skipped ?? [])];
	const pending = new Map<string, GroupNode>(spec.nodes.filter((n) => !envelopes[n.nodeId]).map((n) => [n.nodeId, n]));
	let isError = carry?.isError ?? false;
	let awaitingAcceptance: GroupAwaitEntry[] | undefined;

	/** K8b：收集待接受上游明细（暂停原因；从 pending 节点的 requires=accepted 边反查当前视图）。 */
	const collectAwaiting = (): GroupAwaitEntry[] => {
		const byUpstream = new Map<string, GroupAwaitEntry>();
		for (const [id, n] of pending) {
			if (n.requires !== "accepted") continue;
			for (const d of n.dependsOn || []) {
				const e = envelopes[d];
				if (!e || e.taskId === "?") continue;
				const view = peekTaskKernel()?.get(e.taskId);
				if (!view?.receipt || view.acceptance !== "unreviewed") continue;
				const key = e.nodeId || e.taskId;
				const cur = byUpstream.get(key) ?? { nodeId: key, taskId: e.taskId, receiptId: view.receipt.receiptId, blockedNodes: [] };
				cur.blockedNodes.push(id);
				byUpstream.set(key, cur);
			}
		}
		return [...byUpstream.values()];
	};

	const satisfied = (n: GroupNode): EdgeVerdict => {
		let sawWait = false;
		let sawAwait = false;
		for (const d of n.dependsOn || []) {
			const v = verdictOfEdge(n, envelopes[d], pending.has(d));
			if (v === "dead") return "dead";
			if (v === "wait") sawWait = true;
			else if (v === "await-accept") sawAwait = true;
		}
		return sawWait ? "wait" : sawAwait ? "await-accept" : "ready";
	};

	for (;;) {
		// group 级取消：已取消的 group 不再解锁任何新层（运行中节点由 cancelGroup 逐个 SIGTERM）
		if (cancelledGroups.has(spec.runId) && pending.size > 0) {
			for (const id of pending.keys()) { skipped.push({ nodeId: id, reason: "group 已级联取消，未解锁" }); pending.delete(id); }
			isError = true;
			break;
		}
		const ready: GroupNode[] = [];
		let anyAwait = false;
		for (const n of pending.values()) {
			const v = satisfied(n);
			if (v === "ready") ready.push(n);
			else if (v === "await-accept") anyAwait = true;
		}
		if (ready.length === 0) {
			// K8b：等待人工接受——立即暂停返回（组句柄 + 逐节点状态），不级联跳过未启动节点
			if (anyAwait) {
				awaitingAcceptance = collectAwaiting();
				break;
			}
			// 剩余全部不可解锁：级联跳过（如实记录原因；K8b verdictOfEdge 统一两通道判定）
			for (const [id, n] of pending) {
				const deadDep = (n.dependsOn || []).find((d) => verdictOfEdge(n, envelopes[d], pending.has(d)) === "dead");
				const e = deadDep ? envelopes[deadDep] : undefined;
				skipped.push({ nodeId: id, reason: deadDep ? `上游 ${deadDep} ${e ? deadReasonOf(n, e) : "被跳过"}，依赖未满足` : "依赖未满足" });
				isError = true;
				pending.delete(id);
			}
			break;
		}
		// 同层并发（声明顺序仅用于 Promise.all 结果）；每个节点一结算即先入表再通知，
		// 不等待同层最慢节点。下游解锁仍保持层 barrier，不改变既有 DAG 语义。
		const results = await Promise.all(ready.map(async (n) => {
			pending.delete(n.nodeId);
			let env: ResultEnvelope;
			try {
				const depEnvs: Record<string, ResultEnvelope> = {};
				for (const d of n.dependsOn || []) depEnvs[d] = envelopes[d];
				env = await runGroupNode(spec, n, depEnvs, deps);
			} catch (e) {
				env = { taskId: "?", runId: spec.runId, nodeId: n.nodeId, revision: 0, status: "failed", summary: "", artifactRefs: [], error: { code: "scheduler-error", message: String(e).slice(0, 300) } };
			}
			envelopes[env.nodeId!] = env;
			try { deps.onNodeDone?.(env); } catch {}
			return env;
		}));
		for (const env of results) {
			if (env.status !== "completed") isError = true;
		}
	}
	return { runId: spec.runId, envelopes, skipped, isError, ...(awaitingAcceptance?.length ? { awaitingAcceptance } : {}) };
}

// ─────────────────────────────────────────────────────────────────────────────
// submitGroup 异步 handle + waitGroup + cancelGroup（v2 §7.6 显式等待原则）
// ─────────────────────────────────────────────────────────────────────────────

export interface GroupHandle {
	runId: string;
	nodeIds: string[];
	status: "running";
	/** 节点 taskId（nodeId → taskId，启动后陆续可见；查询/等待/取消用）。 */
	taskIds: () => Record<string, string>;
}

interface GroupEntry {
	spec: GroupSpec;
	deps: GroupRunDeps;
	promise: Promise<GroupRunOutcome>;
	outcome?: GroupRunOutcome;
	/** K8b：暂停现场（requires=accepted 边等待 Leader 接受）；resumeGroupAfterAcceptance 续跑。
	 *  暂停期间 promise 挂起（waitGroup 等待/超时），终局才 resolve。 */
	paused?: GroupPauseCarry;
	resolve?: (outcome: GroupRunOutcome) => void;
	opts?: GroupSubmitOpts;
}

/** K8b：submitGroup 选项（onDone=终局回调；onPaused=暂停回调；carry=从暂停现场恢复首轮）。 */
export interface GroupSubmitOpts {
	onDone?: (outcome: GroupRunOutcome) => void;
	/** K8b：组暂停等待人工接受时触发一次（携带待接受明细；Leader decide 后 resumeGroupAfterAcceptance 续跑）。 */
	onPaused?: (outcome: GroupRunOutcome) => void;
	/** K8b：从暂停现场恢复（同步路径遇暂停转句柄时复用；不重复执行已结算节点）。 */
	carry?: GroupPauseCarry;
}

const groups = new Map<string, GroupEntry>();

/** 测试隔离用复位。 */
export function resetGroupsForTest(): void {
	groups.clear();
	cancelledGroups.clear();
}

/** K8b：驱动组一轮（暂停→保留现场挂起 promise；终局→resolve+onDone；取消→resume 时由 runGroup 退出门收口）。 */
function driveGroup(entry: GroupEntry, carry?: GroupPauseCarry): void {
	void (async () => {
		const outcome = await runGroup(entry.spec, entry.deps, carry);
		if (outcome.awaitingAcceptance?.length && !cancelledGroups.has(entry.spec.runId)) {
			entry.paused = { envelopes: outcome.envelopes, skipped: outcome.skipped, isError: outcome.isError };
			try { entry.opts?.onPaused?.(outcome); } catch {}
			return; // 组未终局：promise 挂起（waitGroup 超时或 resume 后返回）
		}
		entry.outcome = outcome;
		entry.resolve?.(outcome);
		try { entry.opts?.onDone?.(outcome); } catch {}
	})();
}

/** K8b：暂停组续跑（Leader 显式 decide accept 后；多次暂停链式可续）。
 *  无暂停现场/已取消组返回 undefined（取消状态栅栏不撤）。 */
export async function resumeGroupAfterAcceptance(runId: string): Promise<GroupRunOutcome | undefined> {
	const entry = groups.get(runId);
	if (!entry?.paused) return undefined;
	if (cancelledGroups.has(runId)) return undefined;
	const carry = entry.paused;
	entry.paused = undefined;
	driveGroup(entry, carry);
	return entry.promise;
}

/** 异步提交 group：立即返回 handle，执行在后台推进（节点经共享 admission 排队）。
 *  K8b：组内存在等待 Leader 接受的节点时暂停（onPaused 通知；promise 挂起至 resume 终局）。 */
export function submitGroup(spec: GroupSpec, deps: GroupRunDeps, opts?: GroupSubmitOpts): GroupHandle {
	let resolve!: (o: GroupRunOutcome) => void;
	const promise = new Promise<GroupRunOutcome>((res) => { resolve = res; });
	const entry: GroupEntry = { spec, deps, promise, resolve, opts };
	promise.catch(() => {}); // 防 unhandled rejection（outcome 内有 isError/skipped 承载失败）
	groups.set(spec.runId, entry);
	driveGroup(entry, opts?.carry);
	return {
		runId: spec.runId,
		nodeIds: spec.nodes.map((n) => n.nodeId),
		status: "running",
		taskIds: () => {
			const out: Record<string, string> = {};
			for (const r of registry.list()) if (r.runId === spec.runId && r.nodeId) out[r.nodeId] = r.taskId;
			return out;
		},
	};
}

/** 查询 group（状态由节点推导，不复制独立真相）。K8b：paused=组暂停等待人工接受（非终局）。 */
export function getGroup(runId: string): { found: boolean; done: boolean; paused?: boolean; outcome?: GroupRunOutcome; nodeStats: Array<{ nodeId: string; taskId?: string; status?: string }> } {
	const entry = groups.get(runId);
	const nodeStats: Array<{ nodeId: string; taskId?: string; status?: string }> = [];
	const nodes = entry?.spec.nodes || [];
	for (const n of nodes) {
		const rec = registry.list().find((r) => r.runId === runId && r.nodeId === n.nodeId);
		nodeStats.push({ nodeId: n.nodeId, taskId: rec?.taskId, status: rec?.status });
	}
	return { found: !!entry, done: !!entry?.outcome, ...(entry?.paused ? { paused: true } : {}), outcome: entry?.outcome, nodeStats };
}

/** 显式等待：all=等 group 收尾（含 skipped 级联）；any=任一节点终态即返。超时不取消。 */
export async function waitGroup(runId: string, mode: "any" | "all", timeoutMs: number): Promise<{ timedOut: boolean; outcome?: GroupRunOutcome; settled?: Awaited<ReturnType<typeof waitTasks>> }> {
	const entry = groups.get(runId);
	if (!entry) {
		// 句柄不存在（如 restore 后）：降级为按 runId 扫 registry 的 waitTasks
		const ids = registry.list().filter((r) => r.runId === runId).map((r) => r.taskId);
		if (ids.length === 0) return { timedOut: true };
		const settled = await waitTasks(ids, mode, timeoutMs);
		return { timedOut: settled.timedOut, settled };
	}
	if (mode === "all") {
		const winner = await Promise.race([
			entry.promise.then((outcome) => ({ outcome }) as const),
			new Promise((r) => setTimeout(() => r(null), Math.max(0, timeoutMs))) as Promise<null>,
		]);
		return winner ? { timedOut: false, outcome: winner.outcome } : { timedOut: true };
	}
	// any：轮询节点终态（复用 waitTasks；句柄在时节点陆续启动，ids 逐步出现——每轮重扫）
	const deadline = Date.now() + Math.max(0, timeoutMs);
	for (;;) {
		const ids = registry.list().filter((r) => r.runId === runId).map((r) => r.taskId);
		if (ids.length > 0) {
			const settled = await waitTasks(ids, "any", Math.max(0, deadline - Date.now()));
			if (!settled.timedOut) return { timedOut: false, settled };
		}
		if (Date.now() >= deadline || entry.outcome) return { timedOut: !entry.outcome && Date.now() >= deadline, outcome: entry.outcome };
		await new Promise((r) => setTimeout(r, 50));
	}
}

/** K8b：暂停组收尾（取消/外部处置时）——取消栅栏已立（resume 拒绝），未启动节点全部 skipped，
 *  挂起 promise 终局（waitGroup 不再悬挂）。 */
function finishPausedGroup(entry: GroupEntry | undefined, reason: string): void {
	if (!entry?.paused) return;
	const carry = entry.paused;
	entry.paused = undefined;
	const remaining = entry.spec.nodes.filter((n) => !carry.envelopes[n.nodeId]);
	const outcome: GroupRunOutcome = {
		runId: entry.spec.runId,
		envelopes: carry.envelopes,
		skipped: [...carry.skipped, ...remaining.map((n) => ({ nodeId: n.nodeId, reason }))],
		isError: true,
	};
	entry.outcome = outcome;
	entry.resolve?.(outcome);
	try { entry.opts?.onDone?.(outcome); } catch {}
}

/** 级联取消 group 全部未终态节点（不遗留无人管理的 worker——退出门）。返回取消明细。 */
export function cancelGroup(runId: string, reason?: string): { found: boolean; cancelled: string[]; skippedTerminal: string[] } {
	cancelledGroups.add(runId); // 先收口未启动节点（调度循环每层解锁前检查）
	const recs = registry.list().filter((r) => r.runId === runId);
	const cancelled: string[] = [];
	const skippedTerminal: string[] = [];
	for (const r of recs) {
		const cr = cancelTask(r.taskId, reason || `group ${runId} 级联取消`);
		if (cr.ok) cancelled.push(r.taskId);
		else skippedTerminal.push(r.taskId);
	}
	// K8b：暂停组同样收尾（取消状态栅栏不撤；resume 返回 undefined）
	finishPausedGroup(groups.get(runId), "group 已级联取消，未解锁");
	return { found: recs.length > 0 || groups.has(runId), cancelled, skippedTerminal };
}

/** ev-20260908-f189e7：级联外部处置 group 内 blocked/排队节点（与 cancelGroup 句柄对齐）。
 *  运行中节点跳过（外部替代时终止进程是取消语义，不与「已外部处置」混淆——见 resolveExternalTask）；
 *  未启动节点不再解锁（同 cancelledGroups 退出门）；不 spawn、不重跑、不杀进程。 */
export function resolveExternalGroup(runId: string, note?: string): { found: boolean; resolved: string[]; skipped: string[] } {
	cancelledGroups.add(runId); // 收口未启动节点：group 已在外部解决，后续层不再解锁（与 cancel 同退出门）
	const recs = registry.list().filter((r) => r.runId === runId);
	const resolved: string[] = [];
	const skipped: string[] = [];
	for (const r of recs) {
		const rr = resolveExternalTask(r.taskId, note || `group ${runId} 级联外部处置`);
		if (rr.ok) resolved.push(r.taskId);
		else skipped.push(r.taskId);
	}
	// K8b：暂停组同样收尾（后续层不再解锁）
	finishPausedGroup(groups.get(runId), "group 已外部处置，未解锁");
	return { found: recs.length > 0 || groups.has(runId), resolved, skipped };
}
