/**
 * cross-session-writers.ts — ev-20261001-4f2a9c：跨会话同 cwd 并行写入者探测（只读、有界）。
 *
 * 根因（实战 2026-10-01，多会话并行同一仓库）：任务 cwd 缺省继承 Leader 会话目录——会话 B 的
 * Leader/子代理把任务输入材料（如 .design-inputs-webui/，141KB 设计文档）写进共享项目根，
 * 会话 A 的子代理探索 cwd 时撞见、只能靠时间戳猜归因（浪费上下文，且存在误读/误碰风险）。
 * 既有同 cwd 并行甄别（ev-20260918-284677 collectSiblingWriterLabels）只读本进程 registry——
 * 跨会话并行任务对本会话完全不可见。
 *
 * 对策：机器级契约存储（v2-store）本就记录每个任务的 execution 状态（current.json）与
 * workspace.cwd/agent（spec-*.json）——派发时只读扫描「同 cwd 且活跃、且不属于本会话
 * （registry 全部 taskId 之外）」的任务，经 workspace-preflight 的 foreignWriters 注入
 * 「跨会话并行任务」警告到子代理任务书，把外来文件的归因从猜测变成确定性事实。
 *
 * 边界（如实记录）：
 *  - 只探测 v2-store 内核任务；RPC 池会话（rpc-pool WAL）、legacy v1 记录、以及对方会话 Leader
 *    直接写盘（不经任务派发）不在探测面——由 SHARED_TREE_DISCIPLINE 的未归因改动纪律兜底。
 *  - current.json 只在状态迁移时写入（无心跳）：连续运行超 freshnessMs 窗口的任务可能漏报
 *    （watchdog 语义下实际不可达）；blocked/answering 超 staleMs 视为弃置不报（防陈年阻塞
 *    任务永久污染警告）。
 *  - 只读探测，一切 IO 失败静默跳过——绝不因扫描失败阻断派发；AMAGI_CROSS_SESSION_WRITERS_OFF=1
 *    可整体关闭（与 AMAGI_WORKSPACE_PREFLIGHT_OFF 同款逃生舱）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { contractStoreRoot, sanitizeId } from "./artifact.ts";

/** 视为活跃写入者的执行态（与 collectSiblingWriterLabels 的 registry 语义对齐：
 *  blocked/answering 随时可恢复写入——但跨会话无清理保证，须叠加 staleMs 陈旧界）。 */
const ACTIVE_EXECUTIONS: ReadonlySet<string> = new Set(["queued", "running", "blocked", "answering"]);

export interface CrossSessionWriterOptions {
	/** 契约存储根（缺省 contractStoreRoot()；测试注入临时目录）。 */
	storeRoot?: string;
	/** 最多扫描的任务目录数（按 current.json mtime 新→旧；缺省 500）。 */
	maxScanDirs?: number;
	/** 返回标签上限（缺省 4，与 siblingWriters 展示上限一致）。 */
	maxLabels?: number;
	/** 任务目录活跃窗口：current.json mtime 超窗不扫（缺省 7 天；running 任务无心跳，窗口给足）。 */
	freshnessMs?: number;
	/** queued/blocked/answering 的活动陈旧界（按 queuedAt/startedAt 判；缺省 24h）。 */
	staleMs?: number;
	/** 时钟注入（测试）。 */
	now?: () => number;
}

/** current.json 最小读取面（TaskRun 契约字段子集——只取探测所需，不做完整校验）。 */
interface CurrentLike {
	taskId?: unknown;
	specId?: unknown;
	execution?: unknown;
	queuedAt?: unknown;
	startedAt?: unknown;
}

/** spec-*.json 最小读取面（TaskSpec 契约字段子集）。 */
interface SpecLike {
	agent?: unknown;
	workspace?: { cwd?: unknown } | null;
}

function readJsonFile(file: string): unknown | undefined {
	try {
		return JSON.parse(fs.readFileSync(file, "utf8"));
	} catch { /* lint-exempt:只读探测坏 JSON 静默跳过（探测不阻断派发） */
		return undefined;
	}
}

function dirMtimeMs(dir: string): number | undefined {
	try {
		return fs.statSync(dir).mtimeMs;
	} catch { /* lint-exempt:只读探测 stat 失败静默跳过 */
		return undefined;
	}
}

/** 探测开关（每次调用时读取；与既有 AMAGI_*_OFF 逃生舱同款语义）。 */
export function crossSessionWritersEnabled(): boolean {
	return process.env.AMAGI_CROSS_SESSION_WRITERS_OFF !== "1";
}

/**
 * 扫描机器级契约存储，返回与 cwd 相同、执行态活跃、且不属于本会话（excludeTaskIds 之外）
 * 的任务标签（`${agent}/${taskId 前 8 位}`——与 collectSiblingWriterLabels 同格式，由
 * workspace-preflight 的「跨会话并行任务」行承载归属语义）。
 *
 * 纯只读 + 全静默容错：目录不可读/坏 JSON/缺字段一律跳过；无 storeRoot 目录时返回空。
 */
export function collectCrossSessionWriterLabels(
	cwd: string,
	excludeTaskIds: Iterable<string>,
	options: CrossSessionWriterOptions = {},
): string[] {
	if (!crossSessionWritersEnabled()) return [];
	const root = options.storeRoot ?? contractStoreRoot();
	const now = (options.now ?? Date.now)();
	const maxScanDirs = options.maxScanDirs ?? 500;
	const maxLabels = options.maxLabels ?? 4;
	const freshnessMs = options.freshnessMs ?? 7 * 24 * 60 * 60 * 1000;
	const staleMs = options.staleMs ?? 24 * 60 * 60 * 1000;
	const exclude = new Set(excludeTaskIds);

	let mine: string;
	try {
		mine = path.resolve(cwd);
	} catch { /* lint-exempt:非法 cwd 静默返回空（探测不阻断派发） */
		return [];
	}

	let entries: fs.Dirent[];
	try {
		entries = fs.readdirSync(root, { withFileTypes: true });
	} catch { /* lint-exempt:无存储根（全新机器/隔离环境）= 无跨会话任务，静默空 */
		return [];
	}

	// 有界扫描预算：先按 mtime 新→旧排序，只扫活跃窗口内的前 maxScanDirs 个目录。
	const fresh: Array<{ dir: string; mtime: number }> = [];
	for (const e of entries) {
		if (!e.isDirectory()) continue;
		const dir = path.join(root, e.name);
		const mtime = dirMtimeMs(dir);
		if (mtime === undefined || now - mtime > freshnessMs) continue;
		fresh.push({ dir, mtime });
	}
	fresh.sort((a, b) => b.mtime - a.mtime);

	const labels: string[] = [];
	for (const { dir } of fresh.slice(0, maxScanDirs)) {
		const current = readJsonFile(path.join(dir, "current.json")) as CurrentLike | undefined;
		if (!current || typeof current !== "object") continue;
		const taskId = typeof current.taskId === "string" ? current.taskId : "";
		const specId = typeof current.specId === "string" ? current.specId : "";
		const execution = typeof current.execution === "string" ? current.execution : "";
		if (!taskId || !specId || !ACTIVE_EXECUTIONS.has(execution)) continue;
		if (exclude.has(taskId)) continue;
		// running 即活跃；queued/blocked/answering 叠加陈旧界（跨会话无 registry 清理，
		// 陈年阻塞任务若不过期会永久污染每个派发预检）。
		if (execution !== "running") {
			const activityAt = typeof current.startedAt === "number" && current.startedAt > 0
				? current.startedAt
				: (typeof current.queuedAt === "number" ? current.queuedAt : 0);
			if (activityAt <= 0 || now - activityAt > staleMs) continue;
		}
		const spec = readJsonFile(path.join(dir, `spec-${sanitizeId(specId)}.json`)) as SpecLike | undefined;
		if (!spec || typeof spec !== "object") continue;
		const specCwd = typeof spec.workspace?.cwd === "string" ? spec.workspace.cwd : "";
		if (!specCwd) continue;
		try {
			if (path.resolve(specCwd) !== mine) continue;
		} catch { /* lint-exempt:spec cwd 非法静默跳过该记录 */
			continue;
		}
		const agent = typeof spec.agent === "string" && spec.agent ? spec.agent : "unknown";
		const label = `${agent}/${taskId.slice(0, 8)}`;
		if (!labels.includes(label)) labels.push(label);
		if (labels.length >= maxLabels) break;
	}
	return labels;
}
