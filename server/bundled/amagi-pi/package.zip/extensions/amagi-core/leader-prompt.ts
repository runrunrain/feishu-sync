/** leader-prompt.ts — 每轮从 pi 的 base prompt 重新追加 L0；compact 后单次追加 continuation。
 *
 * v1.5.226 P0-1 方案A（缓存前缀稳定，对齐 dsh runtime-context 模式）：
 * - system prompt 只含恒定内容（pi base + L0 + compact 后单次 continuation）——会话内字节级稳定，
 *   供应商 KV cache 以首 token 起前缀匹配，system prompt 前缀稳定 = 全会话缓存不因 Leader 轮次失效。
 * - 路由记忆（动态统计）**不再进 system prompt**：改为 user-role 快照消息注入（pi 的 custom message
 *   在 wire 层转为 role:"user"，见 pi dist/core/messages.js case "custom"），且仅当内容实质变化
 *   （字符串 diff）时才 append 到历史尾部——旧快照保留在历史中，前缀永不回写。
 *   多智能体会话中任务频繁完成、统计高频变化，快照只追加不重写，缓存前缀保持完整。
 * - 会话恢复（新进程续旧 session）时内存快照基线重置，首轮重注入一次：append-only，无损前缀。
 *
 * amagi-pi v2 I3（方案 §8.2-I3 / §4.2 / §4.3）：
 * - 名册单源：L0 角色名册不再手写在 l0-template.md，从 agents/*.md（agents-loader 唯一登记）动态
 *   生成（角色名/类型/主责），模板内以 <!--AMAGI:ROSTER--> 占位；任何第二份名册都是漂移。
 * - compact/guided 两档（等义——字段与权限相同，不为省字节削功能）：guided（缺省）含工具面说明档
 *   引用与接受语义引导；compact 仅短名册+工具速引，且只对 AMAGI_L0_COMPACT_MODELS 已验证模型
 *   启用（未验证/无法解析模型一律回退 guided——弱模型保留完整教学信息）。档位与名册在会话内
 *   一次性定格（首轮 before_agent_start 解析并缓存），维持 system prompt 字节级稳定不变量。
 *
 * B10 L0 结构化分节（十月迭代设计方案 §5.7；受测能力 structuredSystemPromptSections，0.86.0+）：
 * - 能力门通过（宿主 ≥0.86.0 且事件携 systemPromptOptions.sections 可写 record）时，L0 按
 *   模板实际语义段落写入独占分节键（amagi_l0_collab/routing/experts/acceptance/tasks/
 *   resources + 环境注记 amagi_l0_env + 大发射纪律 amagi_l0_emission；压缩存活续跑文本另有
 *   amagi_continuation，非 L0 内容）；
 *   每轮先删自有键再赋值（宿主每轮 normalize 深克隆 base，本无残留——防御宿主复用 base 的
 *   边界形态），绝不 append 倍增；不返回全量 systemPrompt、不设 forceSystemPrompt——宿主工具
 *   分节（tools/rules/docs/cwd）与其它扩展分节全部保留，未变轮次 diff 为空零 transcript 注入。
 * - 分节内容含段落标题行本身且切分/重组字节级保真（见 splitL0IntoSections roundtrip 不变量）；
 *   compact 档接受节整体移除即该轮不设 amagi_l0_acceptance 键（空/禁用 → 删自有键）。
 * - 能力门不可用（宿主 <0.86.0 / 版本未知 / 事件形状缺失）→ 回退原 forced 字符串注入路径，
 *   行为与 B10 前完全等价（同一 appendix 拼接式）。
 * - 字节观测（首轮一次）：分节源文本与最终 prompt 分开计量记录（不混为一项）；预算门禁已按
 *   主上 2026-09-19 裁定移除，观测仅记录不拦截。
 *
 * pi 0.86.0 语义复核（ev-20260920，dist 源码实证，无需短路适配）：
 * - 每轮返回同字节 systemPrompt 是安全的——宿主只对 structured sections 做 diff（agent-session
 *   _preparePromptAndToolLoadout → diffSystemPromptSections），diff 为空则零新 transcript 条目，
 *   不会逐轮重写；forced prompt 仅在请求时投影为 leading system prompt（_installAgentForcedPrompt
 *   Projection），不落盘 transcript，resume 后 before_agent_start 照常触发、L0 每轮重新注入。
 * - 无跨轮双重叠加：emitBeforeAgentStart 每轮 normalizeBuildSystemPromptOptions 深克隆 base 选项
 *   （runner.js），event.systemPrompt 恒为不含本扩展 appendix 的 base 渲染。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { AgentConfig } from "./agents-loader.ts";
import { discoverAgents, rosterRows } from "./agents-loader.ts";
import { refreshContinuationSummary, type ContinuationState } from "./continuation.ts";
import { getLeaderSessionStamp } from "./task-service.ts";
import { formatRoutingHint } from "./routing-stats.ts";
import { probeBashRuntime, formatBashRuntimeNote } from "./runtime-env.ts";
import { capabilityEnabledByVersion, detectHostPackageVersion } from "./host-capabilities.ts";
import { largeEmissionDisciplineLine } from "./large-emission-guard.ts";
import { tuiWarn } from "./tui-console.ts";
/** 模型自行选择工具组合；实际可用状态由共享 runtime 注入。 */
export const CODEMODE_LEADER_CRITERIA = "[amagi codemode 判据] codemode 是已有工具的组合执行方式，无需单独授权或在子任务 scope 中申请。由模型按任务自行选择直接调用或脚本组合；保留局部错误、来源与截断信息。";

const moduleDir = path.dirname(fileURLToPath(import.meta.url));

function loadL0Template(): string {
	const l0Path = path.resolve(moduleDir, "..", "..", "resources", "core", "l0-template.md");
	try { return fs.readFileSync(l0Path, "utf8").trim(); }
	catch { tuiWarn(`[amagi-core] L0 模板未找到: ${l0Path}`); return ""; }
}

// ── I3：L0 两档装配（纯函数，供测试与注册共用） ─────────────────────────────

/** L0 档位：guided=完整教学（缺省）；compact=短名册+工具速引（等义：字段/权限不缺）。 */
export type L0Tier = "guided" | "compact";

/** 模板占位与档位标记（HTML 注释不进入最终 system prompt）。 */
const ROSTER_PLACEHOLDER = "<!--AMAGI:ROSTER-->";
const GUIDED_BLOCK_START = "<!--l0-guided-->";
const GUIDED_BLOCK_END = "<!--/l0-guided-->";

function escapeRegExp(text: string): string {
	return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** 名册两档渲染（单源 agents-loader；v2 §5.2 五行特色短表：| 主特色 | 角色 / 类型 | 权限 |）。
 *  guided/compact 两档同表（字段等义零缺失——compact 档节省来自 guided 专属块移除，
 *  不再从名册里扣字段）；特色来自 frontmatter feature（缺省回退主责描述），权限唯一据 capabilities 章程投影。 */
export function renderRoster(agents: ReadonlyArray<AgentConfig>, _tier: L0Tier): string {
	const rows = rosterRows(agents);
	if (rows.length === 0) return "（名册为空：agents/*.md 未发现角色，当前没有可派发的角色；任务由 Leader 直接处理，不使用名册外的角色名）";
	return ["| 主特色 | 角色 / 类型 | 权限 |", "|---|---|---|", ...rows.map((r) => `| ${r.feature} | ${r.name} / ${r.type} | ${r.permission} |`)].join("\n");
}

/** L0 装配：模板 + 单源名册 + 档位裁剪。compact 档整体移除 guided 专属块；guided 档仅剥标记行。
 *  占位缺失时防御性在末尾补名册段（不静默注入无名册的 L0）。 */
export function buildL0Content(template: string, agents: ReadonlyArray<AgentConfig>, tier: L0Tier): string {
	let out = template;
	if (tier === "compact") {
		const blockRe = new RegExp(`${escapeRegExp(GUIDED_BLOCK_START)}[\\s\\S]*?${escapeRegExp(GUIDED_BLOCK_END)}\\n?`, "g");
		out = out.replace(blockRe, "");
	} else {
		out = out.replaceAll(`${GUIDED_BLOCK_START}\n`, "").replaceAll(`${GUIDED_BLOCK_END}\n`, "")
			.replaceAll(GUIDED_BLOCK_START, "").replaceAll(GUIDED_BLOCK_END, "");
	}
	const roster = renderRoster(agents, tier);
	if (out.includes(ROSTER_PLACEHOLDER)) out = out.replace(ROSTER_PLACEHOLDER, roster);
	else if (roster) out = `${out}\n\n## 角色名册\n\n${roster}`;
	return out.trim();
}

// ── B10：L0 语义分节（纯函数，供测试与注册共用） ─────────────────────────────

/** L0 分节：单节内容 + 独占分节键（宿主节名约束 ^[a-z][a-z0-9_-]*$，非 preamble）。 */
export interface L0Section {
	/** systemPromptOptions.sections 独占键（amagi_l0_ 前缀 = amagi 拥有）。 */
	readonly key: string;
	/** 节内容（含段落标题行本身——与现状拼接文本字节级对齐）。 */
	readonly content: string;
}

/** 模板实际段落到分节键的固定映射（B10 任务书：协作总则/特色路由/专家使用/接受纪律/任务与运行/
 *  按需资源——以现有 L0 实际段落为准，不发明新节；标题前缀匹配容括号尾注）。 */
const L0_HEADING_KEYS: ReadonlyArray<{ prefix: string; key: string }> = [
	{ prefix: "特色路由", key: "amagi_l0_routing" },
	{ prefix: "专家使用", key: "amagi_l0_experts" },
	{ prefix: "接受", key: "amagi_l0_acceptance" },
	{ prefix: "任务与运行", key: "amagi_l0_tasks" },
	{ prefix: "按需资源", key: "amagi_l0_resources" },
];

/** amagi 拥有的全部分节键（含环境注记、大发射纪律与压缩存活续跑；每轮先删后赋的清理集）。 */
export const L0_SECTION_OWN_KEYS: readonly string[] = [
	"amagi_l0_collab", "amagi_l0_routing", "amagi_l0_experts", "amagi_l0_acceptance",
	"amagi_l0_tasks", "amagi_l0_resources", "amagi_l0_env", "amagi_l0_emission", "amagi_continuation",
];

/** 标题行 → 分节键；未知标题返回 null（调用方并入前一节保内容）。 */
function headingSectionKey(heading: string): string | null {
	for (const { prefix, key } of L0_HEADING_KEYS) if (heading.startsWith(prefix)) return key;
	return null;
}

/** 切分前导段/标题块：首段（h1 标题+总则）= amagi_l0_collab；其后每个 `## ` 标题行开新节。
 *  字节保真不变量：sections.map(s => s.content).join("\n\n") === l0Built（非末节恰好剥一个
 *  尾随 \n，重组时空行分隔符完整复原——分节前后语义内容字节级等价，差异仅分节包装/空白）。
 *  未知标题的块并入前一节内容（内容不丢字节；调用方可获告警回调）。纯函数。 */
export function splitL0IntoSections(
	l0Built: string,
	onUnknownHeading?: (heading: string) => void,
): L0Section[] {
	if (!l0Built) return [];
	// 在「行首紧接 ## 」的换行处切分（保留前置空行的第一个 \n 在前块尾部；每块剥一个尾随 \n）
	const blocks = l0Built.split(/\n(?=## )/);
	const sections: L0Section[] = [];
	const strip = (block: string, isLast: boolean): string => (isLast || !block.endsWith("\n") ? block : block.slice(0, -1));
	for (let i = 0; i < blocks.length; i++) {
		const isLast = i === blocks.length - 1;
		const block = strip(blocks[i], isLast);
		if (i === 0 || sections.length === 0) {
			sections.push({ key: "amagi_l0_collab", content: block });
			continue;
		}
		const headingMatch = /^## (.+)$/.exec(block.split("\n", 1)[0] ?? "");
		const key = headingMatch ? headingSectionKey(headingMatch[1].trim()) : null;
		if (key) sections.push({ key, content: block });
		else {
			if (headingMatch) onUnknownHeading?.(headingMatch[1].trim());
			const prev = sections[sections.length - 1];
			sections[sections.length - 1] = { key: prev.key, content: `${prev.content}\n\n${block}` };
		}
	}
	return sections;
}

/** 档位解析（纯函数）：缺省/未知值 → guided；显式 compact 仅对已验证模型生效
 *  （匹配=精确相等或同族前缀，如名单 minimax/MiniMax-M2 命中 minimix/MiniMax-M2.7 同族具体型号）；
 *  未验证/无法解析模型一律回退 guided（弱模型回退——不按价格或速度自动选 compact）。 */
export function resolveL0Tier(tierSpec: string | undefined, modelId: string | undefined, verifiedModels: ReadonlyArray<string>): L0Tier {
	const spec = (tierSpec || "").trim().toLowerCase();
	if (spec !== "compact") return "guided"; // 缺省 guided；未知/非法档位回退 guided
	const model = (modelId || "").trim().toLowerCase();
	if (!model) return "guided";
	const verified = verifiedModels.some((entry) => {
		const v = entry.trim().toLowerCase();
		if (!v) return false;
		// 精确相等，或当前模型以名单条目为前缀（同族具体型号，如名单 minimax/M2 命中 minimax/M2.7）
		return model === v || model.startsWith(v);
	});
	return verified ? "compact" : "guided";
}

/** AMAGI_L0_COMPACT_MODELS（逗号分隔）解析。 */
function parseVerifiedModels(raw: string | undefined): string[] {
	return (raw || "").split(",").map((s) => s.trim()).filter(Boolean);
}

/** 防御性读取当前模型 id（事件/ctx 形状随宿主版本演进；读不到返回 ""，档位安全回退 guided）。 */
function currentModelId(event: unknown, ctx: unknown): string {
	const ev = event as { model?: { id?: unknown } | string } | null;
	const c = ctx as { model?: { id?: unknown } | string; agent?: { model?: { id?: unknown } | string } } | null;
	for (const candidate of [ev?.model, c?.model, c?.agent?.model]) {
		if (typeof candidate === "string" && candidate) return candidate;
		if (candidate && typeof candidate === "object" && typeof (candidate as { id?: unknown }).id === "string") {
			return (candidate as { id: string }).id;
		}
	}
	return "";
}

function sessionKey(ctx: any): string {
	return String(ctx?.sessionManager?.getSessionFile?.() || ctx?.sessionManager?.getSessionId?.() || "unknown-session");
}

/** 路由记忆快照的 wire 文本（历史中可能存在多条，模型以最新一条为准）。 */
export function routingSnapshotText(hint: string): string {
	return `[amagi 路由记忆快照 ${new Date().toISOString().slice(0, 10)}] 以下为历史分派统计，供你分派时参考（只是证据，怎么派仍由你按任务判断）；历史中有多条快照时以最新一条为准：\n${hint}`;
}

export interface RegisterLeaderPromptDeps {
	/** 宿主版本覆写（测试注入；缺省 detectHostPackageVersion()）。 */
	readonly hostVersion?: string | null;
}

export function registerLeaderPrompt(pi: ExtensionAPI, continuationState: ContinuationState, deps: RegisterLeaderPromptDeps = {}): void {
	let l0Content: string | null = null;
	/** 上次注入的路由记忆快照 hint（undefined=本进程从未注入；""=当前无路由数据）。 */
	let lastRoutingHint: string | undefined;
	/** ev-20260830-b70efc：bash 运行时环境自描述（undefined=本进程未探测；null/""=无注入）。
	 *  探测经 runtime-env 模块级缓存一次成型 → 会话内 system prompt 字节级稳定（v1.5.226 不变量）。 */
	let envNote: string | null | undefined;
	/** I3：L0 装配结果（模板+单源名册+档位）——首轮解析后定格，会话内字节级稳定。
	 *  null=尚未装配（首轮 before_agent_start 时解析 env/模型并缓存）。 */
	let l0Built: string | null = null;
	/** B10：结构化分节能力门（进程内定型；宿主 ≥0.86.0 才有 sections 差分/中置更新语义）。 */
	const structuredSectionsEnabled = capabilityEnabledByVersion(
		"structuredSystemPromptSections",
		deps.hostVersion !== undefined ? deps.hostVersion : detectHostPackageVersion(),
	);
	/** B10：字节观测是否已记录（首轮一次；观测仅记录不拦截——预算门禁已移除）。 */
	let observed = false;

	pi.on("before_agent_start", async (event: any, ctx: any): Promise<any> => {
		if (l0Content === null) l0Content = loadL0Template();
		if (l0Built === null) {
			// 名册单源：agents/*.md → agents-loader 唯一登记（会话开始固定；空名册/告警如实上浮）
			const discovered = discoverAgents(path.resolve(moduleDir, "..", "..", "agents"));
			for (const w of discovered.warnings) tuiWarn(`[amagi-core/leader-prompt] ${w}`);
			const tierSpec = process.env.AMAGI_L0_TIER;
			const modelId = currentModelId(event, ctx);
			const tier = resolveL0Tier(tierSpec, modelId, parseVerifiedModels(process.env.AMAGI_L0_COMPACT_MODELS));
			if ((tierSpec || "").trim().toLowerCase() === "compact" && tier !== "compact") {
				tuiWarn(`[amagi-core/leader-prompt] AMAGI_L0_TIER=compact 未生效：模型 "${modelId || "(未解析)"}" 不在 AMAGI_L0_COMPACT_MODELS 已验证名单，回退 guided（未验证模型默认 guided）`);
			}
			l0Built = buildL0Content(l0Content, discovered.agents, tier);
		}
		if (envNote === undefined) {
			try { envNote = formatBashRuntimeNote(probeBashRuntime(String(ctx?.cwd || process.cwd()))); }
			catch { envNote = null; }
		}
		// 实际工具可用状态由共享 codemode runtime 注入；此处只给出选择判据。
		const runtimeNote = [envNote, CODEMODE_LEADER_CRITERIA].filter(Boolean).join("\n\n");
		const epoch = continuationState.getEpoch?.();
		const pendingContinuation = continuationState.consume(sessionKey(ctx));
		const stamp = getLeaderSessionStamp();
		const continuation = pendingContinuation ? await refreshContinuationSummary() : null;
		if (continuationState.getEpoch?.() !== epoch || getLeaderSessionStamp() !== stamp) return undefined;
		// v2.15.0 大发射守卫 · L0 门控：当前进程 provider（PI_PROVIDER → PI_MODEL / 前段，惰性求值）
		// 命中 riskyProviders 时写独占分节 amagi_l0_emission（与 task-tool 子进程门控同一行纪律文案；
		// maxBytes 动态渲染）；不命中整节缺席（未变轮次 diff 为空零注入）。回退路径同源追加——
		// 两路径字节级等价不变量保持（新节独立，分节切分/重组保真不受影响）。
		const emissionNote = largeEmissionDisciplineLine();
		// B10 结构化分节路径：事件携可写 sections record 且能力门通过 → 只写自有键，
		// 不返回 systemPrompt/不设 forceSystemPrompt（宿主工具分节与其它扩展分节全部保留）。
		const sectionsRecord: unknown = event?.systemPromptOptions?.sections;
		if (structuredSectionsEnabled && sectionsRecord !== null && typeof sectionsRecord === "object") {
			const sections = sectionsRecord as Record<string, string>;
			// 字节观测（首轮一次）：base 渲染须在写入自有键前读（getter 反映当刻 options）。
			let baseForObservation = "";
			let observe = !observed;
			if (observe) baseForObservation = String(event.systemPrompt || "");
			// 每轮先删自有键再按序赋值（宿主每轮 normalize 深克隆 base 本无残留；此处防御
			// base 被复用/其它形态——禁止 append 倍增，空/禁用即删：compact 无接受节、
			// 续跑令牌已消费时 amagi_continuation 不设）。
			for (const key of L0_SECTION_OWN_KEYS) delete sections[key];
			const parts: L0Section[] = splitL0IntoSections(l0Built, (heading) => {
				tuiWarn(`[amagi-core/leader-prompt] L0 出现未映射标题「${heading}」：内容并入前一节（保字节不丢；新节须先入 L0_HEADING_KEYS 映射）`);
			});
			if (runtimeNote) parts.push({ key: "amagi_l0_env", content: runtimeNote });
			if (emissionNote) parts.push({ key: "amagi_l0_emission", content: emissionNote });
			for (const part of parts) sections[part.key] = part.content;
			if (continuation) sections.amagi_continuation = continuation;
			if (observe) {
				observed = true;
				// 分节源文本与最终 prompt 分开计量（不混为一项；最终 prompt 含宿主分节包装/基础提示）
				const ownEntries = L0_SECTION_OWN_KEYS.filter((k) => typeof sections[k] === "string");
				const srcBytes = ownEntries.reduce((sum, k) => sum + Buffer.byteLength(sections[k], "utf8"), 0);
				const wrapped = ownEntries.map((k) => `<${k}>\n${sections[k]}\n</${k}>`).join("\n\n");
				const finalBytes = Buffer.byteLength(`${baseForObservation}${wrapped ? `\n\n${wrapped}` : ""}`, "utf8");
				// tuiWarn：无 TUI sink 时回退 console.warn（stderr）——json/rpc 模式 stdout 是协议通道，
				// 禁 console.log 裸写（A1b 同源纪律）；TUI 下经 ctx.ui.notify 有界呈现。
				tuiWarn(`[amagi-core/leader-prompt] B10 结构化分节注入：ownSections=${ownEntries.length} 分节源文本=${srcBytes}B 最终prompt≈${finalBytes}B（字节观测仅记录，无预算门禁）`);
			}
			// 动态路由记忆：与回退路径同源——diff 后以 user-role 快照 append。
			const result: { messages?: Array<{ customType: string; content: Array<{ type: "text"; text: string }> }> } = {};
			const hint = formatRoutingHint();
			if (hint && hint !== lastRoutingHint) {
				lastRoutingHint = hint;
				result.messages = [{ customType: "amagi-routing-memory", content: [{ type: "text", text: routingSnapshotText(hint) }] }];
			}
			return Object.keys(result).length ? result : undefined;
		}
		// 回退路径（宿主 <0.86.0 / 版本未知 / 事件形状缺失）：B10 前 forced 字符串注入，行为等价。
		let appendix = l0Built ? `\n\n${l0Built}` : "";
		if (runtimeNote) appendix += `\n\n${runtimeNote}`;
		if (emissionNote) appendix += `\n\n${emissionNote}`;
		if (continuation) appendix += `\n\n---\n${continuation}`;
		const result: { systemPrompt?: string; messages?: Array<{ customType: string; content: Array<{ type: "text"; text: string }> }> } = {};
		// 恒定前缀：system prompt 只拼 L0 + continuation（compact 后单次），绝不拼动态统计。
		if (appendix) result.systemPrompt = String(event.systemPrompt || "") + appendix;
		// 动态路由记忆：diff 后以 user-role 快照 append（空数据不注入；内容未变 → 本轮零注入，零 token 增量）。
		const hint = formatRoutingHint();
		if (hint && hint !== lastRoutingHint) {
			lastRoutingHint = hint;
			result.messages = [{ customType: "amagi-routing-memory", content: [{ type: "text", text: routingSnapshotText(hint) }] }];
		}
		return Object.keys(result).length ? result : undefined;
	});
}
