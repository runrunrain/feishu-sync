/** New submissions' frozen verification policy, shared with the advisory projection. */
export const SUBMIT_BASELINE_POLICY = Object.freeze({
 objectMode: "snapshot" as const,
 allowSharedFallback: true,
 dependencyMode: "copy-local" as const,
});
