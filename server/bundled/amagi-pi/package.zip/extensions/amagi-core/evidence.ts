/**
 * evidence.ts — P4-3：证据自动化（§9.3 质量反馈循环）。
 *
 * 编码类（work/expert）子 Agent 任务完成回流时，自动采集两类证据附在回流文本末尾：
 *   1. L1 冒烟：探测项目测试命令（package.json scripts.test / Makefile test 目标 / Cargo.toml）并执行；
 *   2. 变更摘要：git diff --stat HEAD（任务工作区 cwd）。
 *
 * 设计原则（规格 §9.3）：
 *   - 失败不拦：测试失败/超时、git 不可用、无测试命令 → 如实呈现，绝不影响主回流、绝不抛错。
 *   - 有界：测试 120s、git 10s 超时上限；输出 tail 截断防爆。
 *   - 无测试项目：明确说明"未探测到"（含探测过的三类来源），不静默。
 *
 * 接入点：task-tool.ts sync 回流组装处（createTaskTool execute 的 sync 分支 return 前）。
 * 独立模块：不依赖 pi 运行时（runCmd 默认用 child_process，可注入测试）。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { pathToFileURL } from "node:url";
import { spawn, execFileSync } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { compactAutomaticText, failureExcerpt, type EvidenceContext } from "./evidence-context.ts";
import { readTaskWrites, readTaskStartState, TASK_START_STATE_ENTRY_CAP, TASK_START_PORCELAIN_MAX_BYTES, porcelainBytes, type TaskStartStateEntry, type TaskStartStateSnapshot } from "./task-write-log.ts";
import { registry, type TaskRecord } from "./task-registry.ts";
import { peekTaskKernel } from "./task-service.ts";
import {
	DEFAULT_EVIDENCE_GIT_TIMEOUT_MS,
	DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS,
	DEFAULT_EVIDENCE_TEST_TIMEOUT_MS,
	EVIDENCE_TEST_MS_MAX,
	EVIDENCE_TEST_MS_MIN,
	checkReuseEnabled,
	readProjectEvidenceTimeouts,
	readProjectVerificationPolicy,
	resolveEvidenceTimeouts,
	resolveEvidenceView,
	type EvidenceView,
	type ResolvedEvidenceTimeouts,
} from "./evidence-options.ts";
// ev-20261020-d56baa：项目 shell.pathPrepend ——自动基线测试命令与声明测试命令共用同一 PATH 前置注入
import { discoverUserToolBinDirs, prependPathEntries, readProjectShellPathPrepend, resolveExecutionEnv, tokenResolvableInPath } from "./shell-env.ts";
import {
	captureVerificationObject,
	compareSourceToManifest,
	verifyCapturedObject,
	type DependencyCaptureSummary,
	type VerificationManifest,
} from "./verification-object.ts";
// ev-20261017-ece384 续 + ev-20261021-fix（diting F6/F7/F8）：Go 模块依赖——离线预检/任务私有
// 缓存执行（宿主 GOMODCACHE 零写入）/工具链 setup 失败分类/快照结果复用禁止。
import {
	GO_OFFLINE_ENV,
	commandEntryNoteOf,
	diffGoCacheSurface,
	goToolchainSetupFailureLabel,
	prepareGoPrivateModuleCache,
	preflightGoModuleCache,
	resolveCommandEntry,
	resolveGoModCacheViaGoEnv,
	resolveHostGoModCache,
	snapshotGoCacheSurface,
	type CommandEntryResolution,
	type GoCacheSurface,
	type GoModulePreflight,
	type GoPrivateCachePrep,
} from "./verification-dependencies.ts";
import {
	createEvidenceSnapshot,
	releaseEvidenceSnapshot,
	resolveEvidenceSnapshotMode,
	type EvidenceSnapshot,
	type EvidenceSnapshotMode,
} from "./worktree.ts";
import {
	validateCheckResult,
	type CheckExemption,
	type CheckId,
	type CheckResult,
	type CheckSpecId,
	type CheckStatus,
	type VerificationMode,
	type VerificationObject,
} from "./contracts/evidence.ts";
// D1（ev-20260922-c896f8）：id 口径类型随结构化检查面同点透出（IO 层统一再导出，避免消费者深嵌 contracts 路径）。
export type { CheckId, CheckSpecId } from "./contracts/evidence.ts";
import type { Ref } from "./contracts/view.ts";
import { reclaimCheckArtifacts } from "./verification-temp-gc.ts";
import { CODE_PRODUCT_AGENTS, codeProductContextOf, producesProjectCodeFromPaths, shouldRunCodeBaseline } from "./agent-aliases.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 公共类型
// ─────────────────────────────────────────────────────────────────────────────

export interface CmdResult {
	ok: boolean;
	stdout: string;
	stderr: string;
	code: number | null;
	timedOut: boolean;
	signal?: string | null;
	durationMs: number;
}

/** 命令执行函数类型（runCmd 注入；默认 defaultRunCmd）。C1（ev-20260922-7d1b10）：可选
 *  执行上下文 ctx——binDirs 为已验证的 bin 目录（绝对路径，PATH 前置序），只对该次 spawn
 *  生效，不改全局 process.env。旧注入实现（三参）形状兼容。 */
export type RunCmd = (cmd: string[], cwd: string, timeoutMs: number, ctx?: RunCmdContext) => Promise<CmdResult>;

/** C1：命令执行上下文——workspace 测试计划核验出的相对 bin 目录经当前验证根映射后的执行面。
 *  C2-a：envExtra——对象外缓存重定向等执行期 env 注入（只对该次 spawn 生效，不改全局）。
 *  ev-20261111-fix（diting F01/F03/F04）：pathPrepend——受信验证根 shell.pathPrepend 解析出的
 *  前置目录（ExecutionEnv.prependDirs）。提供时为**权威值**（defaultRunCmd 不再从执行 cwd
 *  重读 amagi.json——快照/子目录执行不丢根配置、不被对象内容自定环境）；缺省时保持现状
 * （直调方在执行 cwd 读项目声明）。 */
export interface RunCmdContext {
	/** 已验证 bin 目录（绝对路径，PATH 前置序；空数组/缺省 = 无前置，现状行为）。 */
	binDirs?: readonly string[];
	/** 附加 env（覆盖同名白名单变量；缺省 = 无注入）。 */
	envExtra?: Record<string, string>;
	/** 受信根 pathPrepend 前置目录（权威；含空数组——不再从执行 cwd 重读配置）。 */
	pathPrepend?: readonly string[];
	/** 自动发现的用户级工具目录（ev-20261101-bcee0f；追加在宿主 PATH 之后）。提供时为权威值
	 *  （来自受信验证根的 ExecutionEnv）；缺省时 defaultRunCmd 现盘发现（直调方兼容）。 */
	discoveredDirs?: readonly string[];
}

export interface EvidenceDeps {
	/** 命令执行注入（测试用）；默认 child_process.spawn 包装。 */
	runCmd?: RunCmd;
	/** A matching child-process test result captured after its final write; avoids rerunning the same baseline.
	 *  C2-b（方案 §2.8）：仅供受控测试/兼容调用（task-tool sync auto-verifier 从子代理真实执行
	 *  轮次提取）——不能从模型自由文本反序列化构造（叙述文字不是结构化事实）。 */
	preverifiedTest?: { command: string[]; result: CmdResult; execCwd?: string };
	/** C2-b（ev-20260921-89cc12，方案 §2.8）：结构化检查证据引用——展示链测试部分消费的唯一
	 *  执行事实（finalizer 从 runStructuredCheck 产物构造；harness 专用，非第二种 CheckResult，
	 *  模型自报文字进不来）。提供时测试部分不再探测/不再执行（同一检查不双跑）。 */
	structuredTest?: StructuredTestRef;
	/**
	 * 项目是否可信（trust gate，dist ExtensionContext.isProjectTrusted）；默认 true。
	 * false 时跳过项目测试命令 spawn（防不可信仓库读取 ~/.pi/agent/auth.json 等凭据），git diff 仍采集。
	 */
	trusted?: boolean;
}

export interface DetectedTest {
	/** 完整命令 argv（runCmd 接收 string[]）。 */
	cmd: string[];
	/** 展示标签（如 "npm test"）。 */
	label: string;
	/** 命中的来源。 */
	source: "package.json" | "Makefile" | "Cargo.toml" | "go.mod" | "CMakeLists.txt" | "amagi.json" | "package.json-subpkg";
	/** 测试命令执行 cwd：子包级联命中时为 <cwd>/<subdir>；缺省 = 证据采集 effCwd。
	 *  ev-20260906-d9dc13：monorepo 根无 test 时测试在子包内跑，命令必须钉在子包目录。
	 *  C1（ev-20260922-7d1b10）：仅供调用方**显示**（formatTestLine/复用比对），规格唯一数据源
	 *  改为 plan（cwdRel 相对口径）；本字段保留一个发布版本供旧消费者显示。 */
	execCwd?: string;
	/** 命中的子包目录名（仅 package.json-subpkg 有值；展示与 preverified 复用比对用）。 */
	subdir?: string;
	/** C1：workspace 测试执行计划（探测的规格化产物）。命中且可解析时必有；探测级不可用
	 *  （根已声明 test 但 bin 不可达/歧义）时缺席并置 unavailableReason——不产出必败命令。 */
	plan?: TestExecutionPlan;
	/** C1：计划解析命中的本地 bin 名（local/workspace-root/workspace-package 层）——隔离快照内
	 *  bin 预核验用（快照未携带依赖目录时如实 snapshot-bin-missing），不进冻结 plan/spec。 */
	planBin?: string | null;
	/** C1：探测级不可用原因（根已声明 test 但 bin 全链缺失/子包候选歧义——不静默降格为子包
	 *  绿灯或 missing；evidence/finalizer 消费为准确 unavailable）。 */
	unavailableReason?: string;
	/** C1：heuristic 兜底命中标记（无 workspace 声明的一级目录盲扫；不用于借用兄弟包二进制）。 */
	heuristic?: boolean;
	/** ev-20261021-54b4e3：项目声明的执行期环境（资源预算等；仅 source=amagi.json 有值）。 */
	env?: Record<string, string>;
}

/** C1（ev-20260922-7d1b10，方案 §2.7）：测试执行计划——探测返回可执行计划，不返回一条看似
 *  可用的命令。目录均相对 verificationRoot（POSIX 分隔），不携带宿主绝对路径进快照：
 *  cwdRel/binDirsRel 在任意验证对象根（共享树 effCwd、隔离快照 worktree、V3 捕获目录）下
 *  重放解析；verificationRoot 是宿主侧授权锚（计划构建时受任务授权工作区约束的探测根）。 */
export type TestExecutionPlan = {
	/** 受任务已授权工作区约束的探测根（宿主绝对路径；快照/对象消费侧以自身根映射相对字段）。 */
	verificationRoot: string;
	argv: readonly string[];
	/** 执行目录相对 verificationRoot；根用 "."，不是绝对路径。 */
	cwdRel: string;
	/** bin 解析链（PATH 前置序，相对 verificationRoot；空 = 无本地 bin 前缀）。 */
	binDirsRel: readonly string[];
	source: DetectedTest["source"];
	coverage: "root-script" | "selected-package";
	/** coverage=selected-package 时：命中子包相对 verificationRoot 的目录名。 */
	selectedPackage?: string;
	/** 首 token 实际解析层：本包/执行目录 .bin、workspace root .bin、声明子包 .bin 借用、系统 PATH、
	 *  静态不可证明（复杂 script——执行已声明 script 获取真相，不把静态不认识说成环境必缺失）。 */
	resolution: "local" | "workspace-root" | "workspace-package" | "system" | "runtime";
};

export type EvidenceTestStatus = "passed" | "failed" | "timed-out" | "skipped" | "missing" | "error" | "unavailable";

/** Structured result used by the sync auto-verifier; `text` remains the public display contract. */
export interface EvidenceReport {
	text: string;
	/** 详情归档含实际采集到的 stdout/stderr；不注入上下文，也不从日志文字推导状态。 */
	archiveText?: string;
	/** 自动采集的展示副本；text/检查日志仍完整归档，不能用摘要推导结算。 */
	context?: EvidenceContext;
	test: {
		status: EvidenceTestStatus;
		command?: string[];
		label?: string;
		detail: string;
		durationMs: number;
		/** C1（ev-20260922-7d1b10）：unavailable 时 no-object:<reason> 短码（如
		 *  no-object:snapshot-bin-missing:<bin>）——K7 迁移口径合成 objectId 数据源，与 D1 单一
		 *  id 口径协同：unavailable CheckResult 引用完整 checkId，真实原因不丢。 */
		objectRef?: string;
		/** ev-20261105-8d31e3：探测级 unavailable（执行计划不可建立）携带探测来源
		 *  （detected.source，如 package.json/amagi.json）——finalizer 迁移口径据此区分「自动探测
		 *  入口的环境缺口」（尽力基线降 required，不阻断 settlement）与声明/注入面（语义不变）。
		 *  仅探测级 unavailable 分支填写；其余状态与注入面缺省（finalizer 侧 fail-closed 不降级）。 */
		source?: string;
	};
	/** v2.3 C1：证据链 degraded 注记（如隔离快照创建失败回退共享树执行）——验证事实可信度
	 *  降级如实留痕（finalizer 结构化事实 → 回执 degraded[]），不静默；不改变 settlement 判定
	 *  （缺口走 missing/checks 口径）。可选字段：旧注入面/旧回执无此字段照常消费。 */
	degraded?: readonly string[];
}

/** C2-b（ev-20260921-89cc12，方案 §2.8）：结构化检查证据引用——{checkId, logRef} 只指向
 *  harness 已保存的记录（finalizer 构造时校验日志落盘在场）；普通「npm test PASS」文字仅作
 *  叙述保留，不构造本对象、不填 missing。 */
export interface StructuredTestRef {
	/** harness 已保存检查记录 id（与回执 checks[].id 同源——展示与回执引用同一 id）。 */
	checkId: string;
	/** 检查日志引用（harness 保存；文件在场才携带）。 */
	logRef?: Ref;
	label: string;
	source: string;
	argv: readonly string[];
	/** CheckStatus 口径的检查状态（事实来自 runStructuredCheck，非展示文本推导）。 */
	status: CheckStatus;
	/** 退出事实（null = 未执行/无时间窗：unavailable/not-run/error 等非确定绿）。 */
	result: CmdResult | null;
	/** 未执行/异常原因（result=null 时展示；来自检查 notes，非模型文本）。 */
	problem?: string | null;
	coverage?: string;
	/** B10（ev-20261008-eb1e27）：写面感知选择依据（子集选择/全量回退的披露）。 */
	selection?: string;
	/** B10：兄弟切片干扰豁免事实（结构化转发，非展示文本推导）。 */
	exemption?: CheckExemption;
}

// S5/23f4a4：三超时改经 evidence-options 解析（task > env > 默认；默认=旧三常量，行为零变化）。
// 旧导出面/调用不传配置时与原常量语义完全一致；超预算区分阶段与 timeout/exit 非零（formatTestLine/formatDiffLine）。
const TEST_OUT_TAIL = 800;
const TEST_ERR_TAIL = 400;

// ─────────────────────────────────────────────────────────────────────────────
// 默认 runCmd（child_process.spawn + 超时 + 进程组 SIGTERM→SIGKILL）
// M3 加固：输出流式截断（64KB 尾部）、进程组杀（detached）、env 白名单（防凭据泄露）
// ─────────────────────────────────────────────────────────────────────────────

const MAX_CMD_OUTPUT = 64 * 1024; // stdout/stderr 各保留尾部 64KB（流式截断，防失控输出耗尽主进程内存）
const ENV_WHITELIST = new Set([
	"PATH", "HOME", "USER", "LANG", "LC_ALL", "LC_CTYPE", "TZ",
	"SHELL", "TERM", "NODE_PATH", "XDG_CONFIG_HOME", "XDG_CACHE_HOME",
	// win32 关键系统变量（ev-20260830-2c709d 结算修复）：win32 上 npm/make 等以 .cmd 垫片分发的工具
	// 无法被 shell:false 直接 spawn（实测 spawn npm ENOENT），改经 cmd.exe 执行后子进程还需这些
	// 非凭据系统变量（SystemRoot 缺失时 node 子进程异常、APPDATA/TEMP 是 npm 配置/缓存落点）
	"SystemRoot", "ComSpec", "PATHEXT", "windir",
	"APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "USERPROFILE", "HOMEDRIVE", "HOMEPATH",
]);

/** M3: 构造最小 env 白名单（PATH/HOME/LANG 等系统变量），排除全部凭据防子进程环境泄露。 */
export function buildCmdEnv(env: Record<string, string | undefined> = process.env):
	Record<string, string> {
	const out: Record<string, string> = {};
	for (const k of ENV_WHITELIST) {
		const v = env[k];
		if (v !== undefined) out[k] = v;
	}
	return out;
}

// ── 8月迭代第三轮 P0（跨工作树证据污染）：git 环境钉死 ──
// execSync/execFileSync 路径继承完整 process.env：若父进程带 GIT_DIR/GIT_WORK_TREE 等覆盖
// （git hook/链接工作树别名导出等场景），git 会无视 cwd 指向别的仓库/工作树——跨工作树证据污染
// 的直接根因。spawn 路径已走 buildCmdEnv 白名单；本表剥除所有会改写 git 仓库指向的 env 覆盖。
const GIT_ENV_STRIP = new Set([
	"GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY",
	"GIT_COMMON_DIR", "GIT_NAMESPACE", "GIT_CEILING_DIRECTORIES",
]);

/** git exec 环境：process.env 剖除仓库指向覆盖（防跨工作树污染；PATH/HOME 等保留）。 */
export function gitEnv(env: Record<string, string | undefined> = process.env): Record<string, string> {
	const out: Record<string, string> = {};
	for (const [k, v] of Object.entries(env)) {
		if (!GIT_ENV_STRIP.has(k) && v !== undefined) out[k] = v;
	}
	return out;
}

/** M3: 流式尾部截断（保留固定字节 tail，丢弃前部）。 */
function appendCappedBuf(buf: Buffer, chunk: Buffer<ArrayBufferLike>, max: number): Buffer {
	if (buf.length + chunk.length <= max) return Buffer.concat([buf, chunk]);
	const combined = Buffer.concat([buf, chunk]);
	return combined.subarray(combined.length - max);
}

export function defaultRunCmd(cmd: string[], cwd: string, timeoutMs: number, ctx?: RunCmdContext): Promise<CmdResult> {
	return new Promise((resolve) => {
		const t0 = Date.now();
		let stdoutBuf: Buffer<ArrayBufferLike> = Buffer.alloc(0);
		let stderrBuf: Buffer<ArrayBufferLike> = Buffer.alloc(0);
		let timedOut = false;
		let proc;
		try {
			// M3: detached=true 使子进程成进程组 leader（pid=pgid）；env 白名单防凭据泄露进子进程。
			// C1（ev-20260922-7d1b10）：ctx.binDirs 为已验证的相对 bin 解析计划经当前验证根映射后的
			// 绝对目录——PATH 前置构造只对该次 spawn 生效（局部 env 对象），不改全局 process.env。
			// 探测阶段禁止调用可联网安装的 npx/pnpm dlx；本批保留 npm test --silent 口径不变。
			// ev-20261020-d56baa：项目 shell.pathPrepend 同源前置（用户级工具链 cmake/ctest 等）——
			// 在 binDirs 之前（项目声明优先于探测推导链）；幂等去重，不改全局 process.env。
			// ev-20261111-fix（diting F01/F04）：ctx.pathPrepend 提供时为权威值（来自受信验证根的
			// ExecutionEnv）——不再从执行 cwd 重读 amagi.json（子 cwd/快照执行不丢根配置，也不被
			// 对象内容自定环境）；缺省时保持旧行为（执行 cwd 读项目声明，直调方兼容）。
			const env = buildCmdEnv();
			const prepend = ctx?.pathPrepend !== undefined ? ctx.pathPrepend : readProjectShellPathPrepend(cwd).dirs;
			const pathDirs = [...prepend, ...(ctx?.binDirs ?? []).filter((d) => d && d.length > 0)];
			// ev-20261101-bcee0f：自动发现的用户级工具目录（pip --user cmake/ctest、Homebrew keg-only 等）
			// 追加在宿主 PATH 之后——PATH 已可解析者优先（优先级零变化），只在解析不到时兜底命中。
			// 与 locateToolToken/tokenResolvableInPath 候选序同源（预检可定位 → 执行可执行）。
			const discovered = ctx?.discoveredDirs !== undefined ? ctx.discoveredDirs : discoverUserToolBinDirs();
			const pathEntries = pathDirs.length > 0
				? prependPathEntries(process.env.PATH, pathDirs).split(path.delimiter)
				: (process.env.PATH ?? "").split(path.delimiter);
			const appendDirs = discovered.filter((d) => d && !pathEntries.includes(path.resolve(d)));
			if (pathDirs.length > 0 || appendDirs.length > 0) {
				env.PATH = [...pathEntries, ...appendDirs].join(path.delimiter);
			}
			// C2-a：执行期 env 注入（缓存重定向等）——只影响该次 spawn，不改全局 process.env。
			if (ctx?.envExtra) Object.assign(env, ctx.envExtra);
			// ev-20260830-2c709d 结算修复：win32 下 spawn("npm") 必 ENOENT（npm 仅以 npm.cmd 垫片分发，
			// CreateProcess 不解析；直接 spawn npm.cmd 又被 Node BatBadBut 防护拒为 EINVAL）——
			// win32 统一经 cmd.exe（shell:true）执行。argv 均为仓内固定常量（detectTestCommand 探测
			// 结果 / git diff 固定参数），无用户输入拼接，无注入面；POSIX 路径 shell:false 逐字节不变。
			const isWin = process.platform === "win32";
			proc = spawn(cmd[0], cmd.slice(1), { cwd, shell: isWin, stdio: ["ignore", "pipe", "pipe"], env, detached: true, windowsHide: true });
		} catch (e) {
			resolve({ ok: false, stdout: "", stderr: `spawn 失败: ${String(e)}`, code: null, timedOut: false, durationMs: Date.now() - t0 });
			return;
		}
		// M3: 杀整个进程组（含 npm/make 派生的测试子进程），fallback 直接杀 PID
		const killPgrp = (sig: NodeJS.Signals) => {
			try { if (proc.pid) process.kill(-proc.pid, sig); return; } catch {}
			try { proc.kill(sig); } catch {}
		};
		const sigkillTimer = setTimeout(() => killPgrp("SIGKILL"), timeoutMs + 3_000);
		const timer = setTimeout(() => { timedOut = true; killPgrp("SIGTERM"); }, timeoutMs);
		proc.stdout?.on("data", (d: Buffer<ArrayBufferLike>) => { stdoutBuf = appendCappedBuf(stdoutBuf, d, MAX_CMD_OUTPUT); });
		proc.stderr?.on("data", (d: Buffer<ArrayBufferLike>) => { stderrBuf = appendCappedBuf(stderrBuf, d, MAX_CMD_OUTPUT); });
		const done = (code: number | null, signal: NodeJS.Signals | null) => {
			clearTimeout(timer);
			clearTimeout(sigkillTimer);
			resolve({ ok: code === 0, stdout: stdoutBuf.toString("utf8"), stderr: stderrBuf.toString("utf8"), code: code === null ? null : code, timedOut, signal, durationMs: Date.now() - t0 });
		};
		proc.on("error", (e) => { clearTimeout(timer); clearTimeout(sigkillTimer); resolve({ ok: false, stdout: stdoutBuf.toString("utf8"), stderr: `${stderrBuf.toString("utf8")}${String(e)}`, code: null, timedOut, durationMs: Date.now() - t0 }); });
		proc.on("close", (code, signal) => done(code, signal));
	});
}

// ─────────────────────────────────────────────────────────────────────────────
// 测试命令探测（三生态，优先级 package.json > Makefile > Cargo.toml）
// ─────────────────────────────────────────────────────────────────────────────

/** ev-20260906-d9dc13：子包级联探测边界——一级子目录读 package.json 的数量上限（有界 I/O，
 *  超出不扫：接受不完备，绝不递归/全量子包扫描）；跳过的非源码目录。 */
const SUBPKG_SCAN_LIMIT = 16;
const SUBPKG_SKIP_DIRS = new Set(["node_modules", "dist", "build", "out", "coverage", "target", "venv", ".venv"]);

/** ev-20260918-27ab14 → C1（ev-20260922-7d1b10）重写：npm-run script 首 token 解析链。
 *  27ab14 只看 <cwd>/node_modules/.bin 与系统 PATH；C1 按方案 §2.7 扩展为 workspace 链：
 *  - 执行子包 script：该子包 .bin → 最近祖先包 .bin → workspace root .bin → 系统 PATH
 *    （只在 workspace 边界内查，不扫描任意兄弟包；子包与根冲突时子包优先）；
 *  - 执行 root script：root .bin → 声明子包 .bin 的唯一可判定候选 → 系统 PATH
 *    （根有同名可执行时根优先，不让子包遮盖根声明；多候选指向不同真实工具 → 歧义不猜）。
 *  .bin 命中需目标存在（悬空链接 stat 失败）、是普通文件、POSIX 可执行位（win32 只验存在，
 *  shim 合法性交由执行时验证）。子包定义必须有 package.json 且被声明展开包含；heuristic
 *  兜底子包不借兄弟包二进制。复杂 script 静态无法证明 → resolution=runtime（执行已声明
 *  script 获取真相），不把静态“不认识”说成环境必缺失。禁止探测阶段调用可联网安装的
 *  npx/pnpm dlx；本批保留已采用的 npm test --silent 口径。 */

/** C1：script 首 token 提取（有界词法；VAR=VALUE 前缀跳过、复合命令只看首段——27ab14 口径保持）。 */
interface ScriptToken {
	/** 首 token（word 形态；复杂/不可识别为 null）。 */
	first: string | null;
	/** 相对/带分隔符路径形态（./x.sh、../y、C:\\z）。 */
	isPath: boolean;
	/** shell 结构（管道/重定向/控制符/引号拼接等）开头，静态不可证明。 */
	complex: boolean;
}

function scriptFirstToken(script: string): ScriptToken {
	const tokens = script.trim().split(/\s+/).filter((t) => t.length > 0);
	while (tokens.length > 0 && /^[A-Za-z_][A-Za-z0-9_]*=/.test(tokens[0])) tokens.shift();
	const first = tokens[0];
	if (!first) return { first: null, isPath: false, complex: true };
	if (/^[A-Za-z0-9_@.\/\\-]+$/.test(first)) {
		return { first, isPath: first.includes("/") || first.includes("\\"), complex: false };
	}
	return { first: null, isPath: false, complex: true };
}

/** C1：bin 条目可用性——存在（跟随 symlink：悬空链接 stat 抛错）、普通文件、POSIX 可执行位。 */
function binUsable(abs: string): boolean {
	try {
		const st = fs.statSync(abs);
		if (!st.isFile()) return false;
		if (process.platform !== "win32" && (st.mode & 0o111) === 0) return false;
		return true;
	} catch {
		return false;
	}
}

/** 目录包含 workspace 声明（pnpm-workspace.yaml 或 package.json workspaces 字段）。 */
function isWorkspaceDeclaringDir(dir: string): boolean {
	if (fs.existsSync(path.join(dir, "pnpm-workspace.yaml"))) return true;
	try {
		const pj = JSON.parse(fs.readFileSync(path.join(dir, "package.json"), "utf8"));
		const ws = pj?.workspaces;
		if (Array.isArray(ws) && ws.length > 0) return true;
		const wsp = pj?.workspaces?.packages;
		if (Array.isArray(wsp) && wsp.length > 0) return true;
	} catch { /* 非 JSON/不可读：非声明者 */ }
	return false;
}

/** C1：workspace root 探测——cwd 向上、授权 verificationRoot 范围内最近的 pnpm-workspace.yaml
 *  或 package.json workspaces 声明者；verificationRoot 之外的祖先不读（授权边界，不越界）。 */
function findWorkspaceRootDir(cwd: string, verificationRoot: string): string | null {
	const start = path.resolve(cwd);
	const claimed = path.resolve(verificationRoot);
	const limit = isAncestorOrSelf(claimed, start) ? claimed : start;
	let dir: string = start;
	for (;;) {
		if (isWorkspaceDeclaringDir(dir)) return dir;
		if (dir === limit) return null;
		const parent = path.dirname(dir);
		if (parent === dir) return null;
		dir = parent;
	}
}

/** anc 是 p 的祖先目录或相等（路径前缀 + 分隔符判定，避免 /foo-bar 误匹配 /foo）。 */
function isAncestorOrSelf(anc: string, p: string): boolean {
	const a = path.resolve(anc);
	const q = path.resolve(p);
	return a === q || q.startsWith(a + path.sep);
}

/** C1：bin 链解析结果。 */
interface BinChain {
	resolution: TestExecutionPlan["resolution"];
	/** 链上存在的 bin 目录（绝对，PATH 前置序；借用的子包 .bin 含入）。 */
	binDirs: string[];
	/** 命中的本地 bin 名（快照预核验用；system/runtime/相对文件为 null）。 */
	binName: string | null;
	/** 解析失败原因（机器短码见 problemCode；歧义时含候选目录清单）。 */
	problem: string | null;
	/** plan-bin-missing / resolution-ambiguous / script-file-missing；null = 可用。 */
	problemCode: string | null;
}

/** C1：script 首 token 的 bin 解析链（方案 §2.7 顺序；见上方注释块）。relOf 显示用（相对探测根）。 */
function resolveScriptBinChain(
	scriptCwd: string,
	token: ScriptToken,
	workspaceRoot: string | null,
	declaredPackages: readonly string[],
	verificationRoot: string,
	/** ev-20261111-fix（diting F03/F04）：受信配置根 shell.pathPrepend 前置目录——③ 系统工具
	 *  定位与实际 spawn 同源（用户级工具链内的 cmake/ctest 等首 token 不再被误判全链缺失）。 */
	prependDirs: readonly string[] = [],
): BinChain {
	if (token.complex || !token.first) {
		// 复杂 script：静态无法证明可达性——执行已声明 script 获取真相（不猜环境缺失）
		return { resolution: "runtime", binDirs: [], binName: null, problem: null, problemCode: null };
	}
	if (token.isPath) {
		const abs = path.resolve(scriptCwd, token.first);
		return binUsable(abs)
			? { resolution: "local", binDirs: [], binName: null, problem: null, problemCode: null }
			: { resolution: "system", binDirs: [], binName: null, problem: `script 引用的相对文件不可用（${token.first}）`, problemCode: "script-file-missing" };
	}
	const name = token.first;
	const relOf = (abs: string): string => path.relative(verificationRoot, abs).split(path.sep).join("/");
	// ① script 所在包自己的 .bin（local；子包与根冲突时子包优先）
	const ownDir = path.join(scriptCwd, "node_modules", ".bin");
	if (binUsable(path.join(ownDir, name))) {
		return { resolution: "local", binDirs: [ownDir], binName: name, problem: null, problemCode: null };
	}
	const binDirs: string[] = [];
	if (fs.existsSync(ownDir)) binDirs.push(ownDir);
	// ② workspace 边界内链（仅真实 workspace；heuristic 兜底不借兄弟包二进制）
	if (workspaceRoot && isAncestorOrSelf(workspaceRoot, scriptCwd)) {
		if (path.resolve(scriptCwd) === path.resolve(workspaceRoot)) {
			// root script：声明子包 .bin 的唯一可判定候选（只补 PATH，不改 cwd/不改 root script）
			const hits = declaredPackages
				.filter((p) => binUsable(path.join(p, "node_modules", ".bin", name)))
				.map((p) => path.join(p, "node_modules", ".bin"));
			if (hits.length === 1) {
				return { resolution: "workspace-package", binDirs: [...binDirs, ...hits], binName: name, problem: null, problemCode: null };
			}
			if (hits.length > 1) {
				// 唯一真实对象判定：realpath 归一后同一可执行对象 → 稳定排序取一；不同工具/版本 → 歧义不猜
				const targets = [...new Set(hits.map((d) => physicalPath(path.join(d, name))))];
				if (targets.length === 1) {
					return { resolution: "workspace-package", binDirs: [...binDirs, hits.slice().sort()[0]], binName: name, problem: null, problemCode: null };
				}
				return {
					resolution: "system", binDirs: [], binName: name,
					problem: `resolution-ambiguous：声明子包存在 ${hits.length} 个不同的 ${name}（${hits.map(relOf).join(", ")}）——不随机取字母序第一个`,
					problemCode: "resolution-ambiguous",
				};
			}
		} else {
			// 子包 script：最近祖先包 .bin（近→远）→ workspace root .bin；不扫描兄弟包
			const rootAbs = path.resolve(workspaceRoot);
			for (let d = path.dirname(path.resolve(scriptCwd)); d !== rootAbs && isAncestorOrSelf(rootAbs, d); d = path.dirname(d)) {
				if (!fs.existsSync(path.join(d, "package.json"))) continue;
				const dir = path.join(d, "node_modules", ".bin");
				if (fs.existsSync(dir)) binDirs.push(dir);
				if (binUsable(path.join(dir, name))) {
					return { resolution: "workspace-package", binDirs, binName: name, problem: null, problemCode: null };
				}
				if (binDirs.length > SUBPKG_SCAN_LIMIT) break; // 有界：祖先链深上限与子包扫描同界
			}
			const rootDir = path.join(workspaceRoot, "node_modules", ".bin");
			if (fs.existsSync(rootDir)) binDirs.push(rootDir);
			if (binUsable(path.join(rootDir, name))) {
				return { resolution: "workspace-root", binDirs, binName: name, problem: null, problemCode: null };
			}
		}
	}
	// ③ 系统 PATH（argv[0]=npm 本身及系统工具；不前置本地 bin）；pathPrepend 声明目录与
	// 实际 spawn 同源参与（ev-20261111-fix diting F03/F04——用户级工具链首 token 命中）
	for (const dir of [...prependDirs, ...(process.env.PATH ?? "").split(path.delimiter)]) {
		if (dir && binUsable(path.join(dir, name))) {
			return { resolution: "system", binDirs: [], binName: name, problem: null, problemCode: null };
		}
	}
	// ④ 全链缺失：准确 unavailable（根已声明 test 不静默降格）
	return { resolution: "system", binDirs: [], binName: name, problem: `bin 全链缺失（${name}：本包 .bin/workspace 链/系统 PATH 均不可达）`, problemCode: "plan-bin-missing" };
}

/** C1：计划构造（目录相对 verificationRoot 归一；越界目录不进链——授权边界）。 */
function planOf(
	verificationRoot: string,
	scriptCwd: string,
	argv: readonly string[],
	source: DetectedTest["source"],
	chain: BinChain,
	coverage: "root-script" | "selected-package",
	selectedPackage?: string,
): TestExecutionPlan {
	const relDir = (abs: string): string => {
		const rel = path.relative(verificationRoot, path.resolve(abs)).split(path.sep).join("/");
		return rel === "" ? "." : rel;
	};
	return {
		verificationRoot,
		argv,
		cwdRel: relDir(scriptCwd),
		binDirsRel: chain.binDirs.filter((d) => isAncestorOrSelf(verificationRoot, path.resolve(d))).map(relDir),
		source,
		coverage,
		...(selectedPackage ? { selectedPackage } : {}),
		resolution: chain.resolution,
	};
}

/** C1：计划在给定根下重放解析（共享树 effCwd / 隔离快照 worktree / 测试模拟新根共用）。
 *  plan 相对字段 fail-closed 核验：绝对路径/含 .. 拒绝（不猜）。binName 提供且 resolution 为
 *  本地链（local/workspace-root/workspace-package）时核验 bin 在该根链上可用——缺失 → ok=false
 *  + missingBin/problem（快照 unavailable 诚实降级：附 binDirsRel 与缺失 bin 名；C2 的
 *  copy-local 依赖捕获不在本批）。 */
export interface PlanRootResolution {
	ok: boolean;
	/** 该根下计划执行目录（绝对）。 */
	execCwd: string;
	/** 该根下存在的 bin 目录（绝对，PATH 前置序；ok=false 时为空）。 */
	binDirs: string[];
	/** ok=false 时：缺失的 bin 名。 */
	missingBin: string | null;
	/** ok=false 时：问题详情（含 binDirsRel 与缺失说明）。 */
	problem: string | null;
}

export function resolvePlanInRoot(plan: TestExecutionPlan, root: string, binName?: string | null): PlanRootResolution {
	const rootAbs = path.resolve(root);
	const bad = (msg: string): PlanRootResolution => ({ ok: false, execCwd: rootAbs, binDirs: [], missingBin: binName ?? null, problem: msg });
	if (!plan || typeof plan.cwdRel !== "string" || path.isAbsolute(plan.cwdRel) || plan.cwdRel.split(/[\\/]/).includes("..")) {
		return bad("plan.cwdRel 非法（绝对路径或含 ..）");
	}
	const execCwd = plan.cwdRel === "." ? rootAbs : path.resolve(rootAbs, plan.cwdRel);
	const binDirs: string[] = [];
	for (const rel of plan.binDirsRel ?? []) {
		if (typeof rel !== "string" || rel === "" || path.isAbsolute(rel) || rel.split(/[\\/]/).includes("..")) {
			return bad(`plan.binDirsRel 含非法路径（${String(rel)}）`);
		}
		const dir = rel === "." ? rootAbs : path.resolve(rootAbs, rel);
		if (fs.existsSync(dir)) binDirs.push(dir);
	}
	if (binName && (plan.resolution === "local" || plan.resolution === "workspace-root" || plan.resolution === "workspace-package")) {
		for (const dir of binDirs) {
			if (binUsable(path.join(dir, binName))) {
				return { ok: true, execCwd, binDirs, missingBin: null, problem: null };
			}
		}
		return {
			ok: false, execCwd, binDirs: [], missingBin: binName,
			problem: `bin ${binName} 在计划 binDirs 内不可用（binDirsRel=[${(plan.binDirsRel ?? []).join(", ")}], resolution=${plan.resolution}）——快照未携带该依赖目录（copy-local 依赖捕获在 C2）`,
		};
	}
	return { ok: true, execCwd, binDirs, missingBin: null, problem: null };
}

/** 27ab14：展开 workspace 包目录声明（pnpm-workspace.yaml packages 块 + package.json workspaces 字段）。
 *  手写窄解析（不引 yaml 依赖）：packages: 块内逐行取 `- item`（引号/注释剔隙）；模式仅支持
 *  尾部一层 `/*`（pnpm/npm workspace 最常见形态，`**`/中缀通配如实跳过）；展开结果字母序、
 *  去重、有界（≤SUBPKG_SCAN_LIMIT），越界/不可读时返回已展开部分。 */
function expandWorkspaceDecl(cwd: string, rootPjExists: boolean): string[] {
	const patterns: string[] = [];
	const wsYaml = path.join(cwd, "pnpm-workspace.yaml");
	if (fs.existsSync(wsYaml)) {
		try {
			const lines = fs.readFileSync(wsYaml, "utf8").split("\n");
			let inBlock = false;
			for (const line of lines) {
				if (/^\S/.test(line)) { inBlock = /^packages\s*:/.test(line); continue; }
				if (!inBlock) continue;
				const m = /^\s+-\s+['\"]?([^'\"#]+?)['\"]?\s*(?:#.*)?$/.exec(line);
				if (m && m[1].trim()) patterns.push(m[1].trim());
			}
		} catch { /* 不可读：如实退化为空声明 */ }
	}
	if (rootPjExists) {
		try {
			const pj = JSON.parse(fs.readFileSync(path.join(cwd, "package.json"), "utf8"));
			const ws = pj?.workspaces;
			if (Array.isArray(ws)) for (const p of ws) if (typeof p === "string" && p.trim()) patterns.push(p.trim());
			// workspaces.packages 形态（yarn 风格）同样支持
			const wsp = pj?.workspaces?.packages;
			if (Array.isArray(wsp)) for (const p of wsp) if (typeof p === "string" && p.trim()) patterns.push(p.trim());
		} catch { /* 已在主流程解析过，此处容错 */ }
	}
	const dirs: string[] = [];
	const seen = new Set<string>();
	for (const pat of patterns) {
		const star = pat.lastIndexOf("/*");
		if (star >= 0 && !pat.slice(star + 2).includes("*") && !pat.slice(0, star).includes("*")) {
			// 尾部一层通配：扫前缀目录的一级子目录
			const prefix = path.resolve(cwd, pat.slice(0, star));
			let entries: fs.Dirent[];
			try { entries = fs.readdirSync(prefix, { withFileTypes: true }); } catch { continue; }
			for (const e of entries) {
				if (!e.isDirectory() || e.name.startsWith(".") || SUBPKG_SKIP_DIRS.has(e.name)) continue;
				const abs = path.join(prefix, e.name);
				if (!seen.has(abs)) { seen.add(abs); dirs.push(abs); }
			}
		} else if (!pat.includes("*")) {
			const abs = path.resolve(cwd, pat);
			if (abs !== path.resolve(cwd) && !seen.has(abs)) { seen.add(abs); dirs.push(abs); }
		}
		// 其它 glob 形态（**/中缀）如实跳过——不猜测展开
	}
	dirs.sort();
	return dirs.slice(0, SUBPKG_SCAN_LIMIT);
}

/**
 * 探测 cwd 下的测试命令。返回首个命中的来源；均无则 null。
 * - amagi.json verification.testCommand（ev-20261020-c8ca99）：项目声明优先于一切探测——探测是
 *   猜测，声明是权威（C++/UE 等非 JS 栈在此声明 ctest 等真实命令；argv 数组不经 shell）。argv[0]
 *   在 shell.pathPrepend ∪ 系统 PATH 不可解析时不产出必败命令，返回 unavailableReason（准确
 *   unavailable，不静默降格为 missing）。cwd 相对项目根（缺省根）。声明非法（形状/绝对路径/含 ..）
 *   → 视为未声明，回退探测链（doctor 报字段问题）。
 * - package.json：scripts.test 存在且为非空字符串 → `npm test`（ev-20260918-27ab14：首 token
 *   须对 PATH 语义可解析，否则继续级联——pnpm workspace 根 script 引用子包 bin 的形态不再
 *   产出必然 command-not-found 的命令，子包级联命中后在子包 execCwd 执行即恢复可用）
 * - Makefile/makefile/GNUmakefile：含 `test:` 目标 → `make test`
 * - Cargo.toml：存在 → `cargo test`
 * - 子包级联（ev-20260906-d9dc13）：根 package.json 存在但无 test（JS monorepo 形态，如
 *   feishu-sync：根只做构建、测试在 server/package.json）→ 按字母序扫 ≤SUBPKG_SCAN_LIMIT 个
 *   一级子目录的 package.json，首个 scripts.test 命中即采用（cmd 仍在子包 execCwd 执行；
 *   只跑一个子包，绝不并行跑全部子包；不递归下探）。27ab14：级联命中同样过首 token 检查
 *   （子包 .bin 口径），与根 script 同构防护。
 * C1（ev-20260922-7d1b10，方案 §2.7）：探测返回可执行计划（TestExecutionPlan），不返回一条
 * 看似可用的命令——argv 保持 npm test --silent 口径，workspace bin 链落入 plan.binDirsRel
 * （执行时 PATH 前置，不改 cwd、不改 root script 为子包 test）。根已声明 scripts.test 时：解析
 * 成功 → root-script 计划（覆盖根语义；bin 可借唯一声明子包）；bin 全链缺失/子包候选歧义 →
 * unavailableReason（准确 unavailable，不静默降格为子包绿灯或 missing）；复杂 script →
 * resolution=runtime（执行已声明 script 获取真相）。workspace root = cwd 向上、授权
 * verificationRoot 范围内最近的声明者（默认 verificationRoot=cwd，不越界读祖先）；heuristic
 * 兜底子包标记不借兄弟二进制；探测阶段禁止调用可联网安装的 npx/pnpm dlx。 */
/** ev-20261020-c8ca99：项目声明测试命令 → DetectedTest（声明优先于探测；非法声明 → null 回退探测链）。*/
function declaredTestOf(probe: string, verificationRoot: string): DetectedTest | null {
	// ev-20261021-54b4e3：声明存在但非法 / declared-only 策略无声明 → 准确 unavailable，不退回探测链
	//（退回的全量探测命令可能违背项目声明的 guarded 串行入口与资源约束）。
	const policy = readProjectVerificationPolicy(probe);
	if (policy.problem) {
		return { cmd: ["amagi.json"], label: "项目声明（非法）", source: "amagi.json", unavailableReason: `项目验证声明非法：${policy.problem}——自动检查不退回探测链（避免执行与项目约束冲突的命令）；修正 amagi.json verification（/amagi doctor 查看）` };
	}
	const decl = policy.testCommand;
	if (!decl) {
		if (policy.autoBaseline === "declared-only") {
			return { cmd: ["amagi.json"], label: "项目声明（缺失）", source: "amagi.json", unavailableReason: "项目策略 verification.autoBaseline=declared-only 且未声明 verification.testCommand——自动检查只执行项目声明的入口，不探测、不退回全量测试命令" };
		}
		return null;
	}
	const label = `声明: ${decl.argv.join(" ").slice(0, 60)}${decl.cwdRel !== "." ? `（cwd=${decl.cwdRel}）` : ""}`;
	const execDir = path.resolve(probe, decl.cwdRel);
	const plan = planOf(verificationRoot, execDir, decl.argv, "amagi.json", { resolution: "system", binDirs: [], binName: null, problem: null, problemCode: null }, "root-script");
	// ev-20261111-fix（diting F03）：预检与实际 spawn 同源——pathPrepend 从受信配置根（probe）读，
	// 显式相对 token 按声明的实际 execDir 解析（旧实现按 harness 进程 cwd stat，子目录/异仓声明
	// 被误判 plan-bin-missing → 基线 unavailable）。
	const execEnv = resolveExecutionEnv({ configRoot: probe, execDir });
	if (!tokenResolvableInPath(decl.argv[0], execEnv)) {
		return {
			cmd: [...decl.argv], label, source: "amagi.json",
			unavailableReason: `声明的测试命令首 token ${decl.argv[0]} 在 shell.pathPrepend ∪ 系统 PATH（或声明 cwd）均不可解析（plan-bin-missing）——修正 amagi.json verification.testCommand.argv 或在 shell.pathPrepend 声明工具链目录`,
			planBin: decl.argv[0],
		};
	}
	return {
		cmd: [...decl.argv], label, source: "amagi.json", plan,
		...(decl.cwdRel !== "." ? { execCwd: execDir } : {}),
		...(decl.env ? { env: { ...decl.env } } : {}),
	};
}

/** ev-20261020-c8ca99：CMake/ctest 探测常量。CMAKE_BUILD_DIR 候选名（已配置 build 目录的常见命名）*/
const CMAKE_BUILD_DIR_PREFERRED = /^(?:build|build-.+|cmake-build-.+|out)$/i;
/** CMake 探测扫描范围：探测根 + 一级子目录（含子目录如 Cxx/ 的 UE/C++ 混合仓布局）；有界。 */
const CMAKE_SCAN_DIR_LIMIT = 16;
/** 每个 CMake 目录下 build 候选子目录的检查上限（readdir 字母序，超出不猜）。 */
const CMAKE_BUILD_CANDIDATE_LIMIT = 64;

/**
 * ev-20261020-c8ca99：定位已配置的 CMake build 目录（含 CTestTestfile.cmake 才算已配置；
 * 未配置不猜——裸 CMakeLists.txt 产出 cmake 命令必败）。扫描 dir 的直接子目录：偏好
 * build、build-*、cmake-build-*、out 命名，否则取字母序首个含 CTestTestfile.cmake 的子目录。
 * 返回绝对路径；无命中 null（有界 I/O）。
 */
export function locateConfiguredCMakeBuildDir(dir: string): string | null {
	let entries: fs.Dirent[];
	try {
		entries = fs.readdirSync(dir, { withFileTypes: true });
	} catch { return null; /* lint-exempt:目录不可读 → 无已配置 build 目录（未配置不猜） */ }
	const subdirs = entries.filter((e) => e.isDirectory() && !e.name.startsWith(".")).map((e) => e.name).sort().slice(0, CMAKE_BUILD_CANDIDATE_LIMIT);
	const preferred: string[] = [];
	const rest: string[] = [];
	for (const name of subdirs) (CMAKE_BUILD_DIR_PREFERRED.test(name) ? preferred : rest).push(name);
	for (const name of [...preferred, ...rest]) {
		const candidate = path.join(dir, name);
		if (fs.existsSync(path.join(candidate, "CTestTestfile.cmake"))) return candidate;
	}
	return null;
}

/**
 * ev-20261020-c8ca99：CMake/ctest 探测——探测根与一级子目录中首个含 CMakeLists.txt 且已配置
 * （存在含 CTestTestfile.cmake 的 build 目录）的目录 → `ctest --test-dir <绝对 build 目录>`。
 * --test-dir 用绝对路径：CMake build 树经 CMakeCache 钉死源码绝对路径，且 build 目录通常
 * gitignored 不进隔离快照——绝对路径保证共享树/快照两种模式下都指向真实已配置构建树
 * （隔离快照内对 ctest 重放源码冻结语义不成立，属 ctest 固有边界，如实披露在 plan 注记）。未配置
 * build 目录 → null（不猜 cmake configure，探测阶段禁联网/禁写盘）。执行目录为探测根（cwdRel=·）。
 */
function detectCMakeTest(probe: string, verificationRoot: string): DetectedTest | null {
	const roots = [probe];
	try {
		const entries = fs.readdirSync(probe, { withFileTypes: true });
		for (const e of entries) {
			if (roots.length >= 1 + CMAKE_SCAN_DIR_LIMIT) break;
			if (!e.isDirectory() || e.name.startsWith(".") || SUBPKG_SKIP_DIRS.has(e.name)) continue;
			roots.push(path.join(probe, e.name));
		}
	} catch { /* lint-exempt:读目录失败仅探测根（有界 I/O，不阻断探测链） */ }
	for (const dir of roots) {
		if (!fs.existsSync(path.join(dir, "CMakeLists.txt"))) continue;
		const build = locateConfiguredCMakeBuildDir(dir);
		if (!build) continue;
		const relForDisplay = path.relative(probe, build) || build;
		return {
			cmd: ["ctest", "--test-dir", build], label: `ctest --test-dir ${relForDisplay}`, source: "CMakeLists.txt",
			plan: planOf(verificationRoot, dir, ["ctest", "--test-dir", build], "CMakeLists.txt", { resolution: "system", binDirs: [], binName: null, problem: null, problemCode: null }, "root-script"),
		};
	}
	return null;
}

export function detectTestCommand(cwd: string, opts?: { verificationRoot?: string }): DetectedTest | null {
	const probe = path.resolve(cwd);
	const verificationRoot = path.resolve(opts?.verificationRoot ?? cwd);
	const workspaceRoot = findWorkspaceRootDir(probe, verificationRoot);
	// 声明子包（在声明者上展开；非 workspace → 空）。子包须有 package.json（下方循环内校验），
	// 不能因目录内有 node_modules 就认作子包。
	const declaredPackages = workspaceRoot ? expandWorkspaceDecl(workspaceRoot, true) : [];
	// ev-20261111-fix（diting F03/F04）：受信验证根的 pathPrepend 一次解析，探测链各首 token 检查
	// 与实际 spawn 同源（不随执行 cwd 漂移）。
	const prependDirs = readProjectShellPathPrepend(probe).dirs;

	// 0. 项目声明（ev-20261020-c8ca99）：<probe>/amagi.json verification.testCommand ——声明优先于探测。
	// plan 口径与探测同构（cwdRel 相对 verificationRoot；argv 原样入 plan；bin 链不前置本地 .bin——
	// 声明命令若需用户级工具链，配套 shell.pathPrepend 声明，defaultRunCmd 同源注入）。
	const declared = declaredTestOf(probe, verificationRoot);
	if (declared) return declared;

	// 1. package.json（探测根）
	const pjPath = path.join(probe, "package.json");
	let rootPjExists = false;
	if (fs.existsSync(pjPath)) {
		rootPjExists = true;
		try {
			const pj = JSON.parse(fs.readFileSync(pjPath, "utf8"));
			const t = pj?.scripts?.test;
			if (typeof t === "string" && t.trim() !== "") {
				const chain = resolveScriptBinChain(probe, scriptFirstToken(t), workspaceRoot, declaredPackages, verificationRoot, prependDirs);
				if (chain.problemCode) {
					// 根已声明 test 但不可用/歧义：准确 unavailable，不产出必败命令，也不静默降格（方案 §2.7-4）
					return { cmd: ["npm", "test", "--silent"], label: "npm test", source: "package.json", unavailableReason: chain.problem ?? "执行计划不可建立", planBin: chain.binName };
				}
				return {
					cmd: ["npm", "test", "--silent"], label: "npm test", source: "package.json",
					plan: planOf(verificationRoot, probe, ["npm", "test", "--silent"], "package.json", chain, "root-script"),
					planBin: chain.binName,
				};
			}
		} catch {
			// package.json 解析失败：不阻断，继续尝试其他来源
		}
	}

	// 2. Makefile（含 test 目标）
	for (const mf of ["Makefile", "makefile", "GNUmakefile"]) {
		const mfPath = path.join(probe, mf);
		if (fs.existsSync(mfPath)) {
			try {
				const content = fs.readFileSync(mfPath, "utf8");
				// 匹配行首 test 目标定义（^test: 或 ^test : ），排除 .PHONY 之外的误判（保守：只要 test: 目标存在）
				if (/^test\s*:/m.test(content)) {
					return {
						cmd: ["make", "test"], label: "make test", source: "Makefile",
						plan: planOf(verificationRoot, probe, ["make", "test"], "Makefile", { resolution: "system", binDirs: [], binName: null, problem: null, problemCode: null }, "root-script"),
					};
				}
			} catch {}
		}
	}

	// 3. Cargo.toml
	const cargoPath = path.join(probe, "Cargo.toml");
	if (fs.existsSync(cargoPath)) {
		return {
			cmd: ["cargo", "test"], label: "cargo test", source: "Cargo.toml",
			plan: planOf(verificationRoot, probe, ["cargo", "test"], "Cargo.toml", { resolution: "system", binDirs: [], binName: null, problem: null, problemCode: null }, "root-script"),
		};
	}

	// 3b. go.mod（ev-20261017-ece384）：Go 模块根 → go test ./...（模块内全部包；工具链原生入口，
	//    与 cargo test 同构——系统 PATH 解析，不猜 vendor/构建标签）。此前探测链只认 JS/Make/Cargo，
	//    Go 仓库恒判「未探测到测试命令」→ 自动基线 not-run → 子任务恒 incomplete、每次 accept 都要 waive。
	//    优先级排在 Makefile/Cargo 之后：仓库已声明 make test 时尊重其封装（可能含 -race/标签）。
	const goModPath = path.join(probe, "go.mod");
	if (fs.existsSync(goModPath)) {
		return {
			cmd: ["go", "test", "./..."], label: "go test ./...", source: "go.mod",
			plan: planOf(verificationRoot, probe, ["go", "test", "./..."], "go.mod", { resolution: "system", binDirs: [], binName: null, problem: null, problemCode: null }, "root-script"),
		};
	}

	// 3c. CMake/ctest（ev-20261020-c8ca99）：探测根或一级子目录（如 Cxx/）含 CMakeLists.txt 且已
	//    配置的 build 目录（含 CTestTestfile.cmake）→ ctest --test-dir <build>；未配置不猜（探测阶段
	//    禁联网/禁写盘，不自动 cmake configure）。此前 C++/UE 项目恒判「未探测到测试命令」→ 自动基线
	//    not-run → 子任务恒 incomplete、每次 accept 都要 waive（项目声明 verification.testCommand 可
	//    覆盖探测）。优先级在 Makefile/Cargo/go.mod 之后：仓库已声明 make test/go test 时尊重其封装。
	const cmakeTest = detectCMakeTest(probe, verificationRoot);
	if (cmakeTest) return cmakeTest;

	// 4a. workspace 声明清单展开（ev-20260918-27ab14 续）：pnpm-workspace.yaml packages /
	//    package.json workspaces 字段是包目录的**权威声明**——按声明展开（模式支持尾部 /*，
	//    即一层通配；其它 glob 形态如实跳过）后按字母序探测，比盲扫一级目录准确（pnpm
	//    workspace 的包常在 pkgs/* 二级，d9dc13 盲扫够不着）。命中包须同时过首 token 检查
	//    （子包 .bin 口径）。根自身（"."）已探测过，跳过。
	const wsDirs = declaredPackages;
	for (const dir of wsDirs) {
		const subPj = path.join(dir, "package.json");
		if (!fs.existsSync(subPj)) continue;
		try {
			const pj = JSON.parse(fs.readFileSync(subPj, "utf8"));
			const t = pj?.scripts?.test;
			if (typeof t === "string" && t.trim() !== "") {
				const chain = resolveScriptBinChain(dir, scriptFirstToken(t), workspaceRoot, declaredPackages, verificationRoot, prependDirs);
				if (chain.problemCode) continue; // 子包 script 不可解析 → 跳过该子包继续探测（不产出必败命令）
				const subdir = path.relative(verificationRoot, dir) || dir;
				return {
					cmd: ["npm", "test", "--silent"], label: "npm test", source: "package.json-subpkg", execCwd: dir, subdir,
					plan: planOf(verificationRoot, dir, ["npm", "test", "--silent"], "package.json-subpkg", chain, "selected-package", subdir),
					planBin: chain.binName,
				};
			}
		} catch { /* 子包 package.json 解析失败：跳过该子包 */ }
	}

	// 4b. 子包级联（ev-20260906-d9dc13）：盲扫一级子目录兜底（无 workspace 声明或声明未命中时）；
	//    仅根 package.json 存在的 JS monorepo 形态（无根 package.json的多仓父目录不猜测）；
	//    一级、有界、只取首个命中。
	if (rootPjExists) {
		let entries: fs.Dirent[];
		try {
				entries = fs.readdirSync(probe, { withFileTypes: true });
		} catch {
				entries = [];
		}
		const dirs = entries
			.filter((e) => e.isDirectory() && !e.name.startsWith(".") && !SUBPKG_SKIP_DIRS.has(e.name))
			.map((e) => e.name)
			.sort();
		for (const dir of dirs.slice(0, SUBPKG_SCAN_LIMIT)) {
			const abs = path.join(probe, dir);
			const subPj = path.join(abs, "package.json");
			if (!fs.existsSync(subPj)) continue;
			try {
				const pj = JSON.parse(fs.readFileSync(subPj, "utf8"));
				const t = pj?.scripts?.test;
				if (typeof t === "string" && t.trim() !== "" && fs.statSync(subPj).isFile()) {
					// C1：heuristic 兜底——未经声明佐证，bin 链只查本包 .bin 与系统 PATH（workspace 链不生效）
					const chain = resolveScriptBinChain(abs, scriptFirstToken(t), null, [], verificationRoot, prependDirs);
					if (chain.problemCode) continue;
					return {
							cmd: ["npm", "test", "--silent"], label: "npm test", source: "package.json-subpkg", execCwd: abs, subdir: dir,
							plan: planOf(verificationRoot, abs, ["npm", "test", "--silent"], "package.json-subpkg", chain, "selected-package", dir),
							planBin: chain.binName, heuristic: true,
						};
				}
			} catch { /* 子包 package.json 解析失败：跳过该子包 */ }
		}
	}

	return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 文本格式化
// ─────────────────────────────────────────────────────────────────────────────

function tail(str: string, max: number): string {
	const buf = Buffer.from(str, "utf8");
	if (buf.length <= max) return str;
	let cut = max;
	while (cut > 0 && (buf[cut] & 0xc0) === 0x80) cut--;
	return `…(省略前部 ${buf.length - cut} 字节)\n${buf.slice(buf.length - cut).toString("utf8")}`;
}

function fmtSec(ms: number): string {
	return `${(ms / 1000).toFixed(1)}s`;
}

/** S5/23f4a4：超时报告含阶段与实际预算，且明确 timeout ≠ 测试断言失败/exit 非零。 */
function formatTestLine(detected: DetectedTest, r: CmdResult, reused = false, testBudgetMs = DEFAULT_EVIDENCE_TEST_TIMEOUT_MS): string {
	// ev-20260906-d9dc13：子包级联命中时回显命令 cwd 与覆盖范围（验收可核；不模糊“只跑了一个子包”）。
	// C1（ev-20260922-7d1b10）：计划口径——selected-package 明确只覆盖一个子包；root script 经
	// 唯一声明子包借 bin 时回显借用事实与覆盖根语义（不改 cwd、不改 root script）。其余保持原文案。
	const plan = detected.plan;
	const scope = plan?.coverage === "selected-package" && detected.execCwd
		? `；cwd=${detected.execCwd}，仅覆盖 ${plan.selectedPackage ?? detected.subdir} 子包（根与其余子包未跑）`
		: plan?.coverage === "root-script" && plan.resolution === "workspace-package" && plan.binDirsRel.length > 0
			? `；bin 借用唯一声明子包（${plan.binDirsRel.join(",")}），cwd=根（覆盖根语义，不改 root script）`
			: "";
	const head = `• 测试 ${detected.label}（${detected.source}${detected.subdir ? `/${detected.subdir}` : ""}${detected.heuristic ? "/heuristic" : ""}${scope}${reused ? "；复用子代理末次执行" : ""}）`;
	if (r.timedOut) return `${head} → ⏱ 超时（阶段=测试命令执行；预算 ${fmtSec(testBudgetMs)} 已到并终止——是 timeout，不是测试断言失败/exit 非零；预算可提升：amagi.json evidenceTimeouts.testMs / env AMAGI_EVIDENCE_TEST_TIMEOUT_MS，task 参数优先）`;
	const tag = r.ok ? "✓ 通过" : `✗ 失败（exit ${r.code}）`;
	const parts = [`${head} → ${tag}（${fmtSec(r.durationMs)}）`];
	if (!r.ok) {
		if (r.stdout.trim()) parts.push(`  ─ stdout 尾 ─\n${tail(r.stdout, TEST_OUT_TAIL).replace(/^/gm, "  ")}`);
		if (r.stderr.trim()) parts.push(`  ─ stderr 尾 ─\n${tail(r.stderr, TEST_ERR_TAIL).replace(/^/gm, "  ")}`);
	}
	return parts.join("\n");
}

function formatDiffLine(r: CmdResult, effCwd?: string, gitBudgetMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): string {
	if (r.timedOut) return `• diff → ⏱ 超时（阶段=git diff 采集；预算 ${fmtSec(gitBudgetMs)} 已到并终止——是 timeout，不是 git 报错/exit 非零）`;
	const out = r.stdout.trim();
	const echo = effCwd ? `git -C ${effCwd} --no-pager diff --stat HEAD -- .` : "git diff --stat HEAD";
	// git diff HEAD 在无 HEAD/非 git 仓库时 exit!=0 且 stderr 含 "unknown revision"/"not a git repository"
	if (!r.ok) {
		const se = r.stderr.trim();
		if (/not a git repository/i.test(se)) return "• diff → 非 git 仓库（cwd 不在 git 工作区内）";
		if (/unknown revision|bad revision|does not have commits/i.test(se)) {
			// 无 commit：尝试说明工作区状态不可对比 HEAD；如实呈现
			return `• diff → 仓库无 HEAD 提交（${se.split("\n")[0] || "git diff HEAD 不可用"}）`;
		}
		return `• diff → 采集失败（exit ${r.code}${se ? `: ${tail(se, 200)}` : ""}）`;
	}
	if (!out) return `• diff → 无改动（${echo} 为空）`;
	// --stat 输出本身已含 files changed 摘要；原样附上（通常 ≤10 行）；首行回显真实命令行（P0 跨工作树归因可核）
	return `• diff（${echo}）\n${out.replace(/^/gm, "  ")}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// E2: git cwd 解析（P1-1 修正）
// 判定 git 归属改用 `git -C <cwd> rev-parse --is-inside-work-tree`（走注入的 runCmd，真实判定 work tree；
// git 自带上探，覆盖「仓库内无 .git 的合法子目录」如 monorepo 子包）。全程永不抛错：git 命令失败/抛错
// → 按不在 work tree 处理。
// ─────────────────────────────────────────────────────────────────────────────

export interface ResolvedGitCwd {
	/** 实际用于证据采集的目录（cwd 本身或下探到的唯一直接子目录）。 */
	effCwd: string;
	/** cwd 解析说明行（前置到证据块首部）；cwd 即 git 仓库根时为 null。 */
	note: string | null;
}

/** E2: cwd 是否在 git work tree 内（git rev-parse 自带上探；永不抛错）。 */
async function isInsideWorkTree(p: string, runCmd: RunCmd, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Promise<boolean> {
	try {
		const r = await runCmd(["git", "-C", p, "rev-parse", "--is-inside-work-tree"], p, timeoutMs);
		return r.ok && r.stdout.trim() === "true";
	} catch {
		return false;
	}
}

/** E2: 取 git work tree 顶层路径（供子目录场景注明 root 供参考；失败返回 null）。 */
async function gitTopLevel(p: string, runCmd: RunCmd, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Promise<string | null> {
	try {
		const r = await runCmd(["git", "-C", p, "rev-parse", "--show-toplevel"], p, timeoutMs);
		if (r.ok) {
			const t = r.stdout.trim();
		return t || null;
		}
	} catch {}
	return null;
}

/** P0：取 rev-parse 单值输出（--git-dir/--git-common-dir 等；失败返回 null）。 */
async function gitRevParseValue(p: string, what: string, runCmd: RunCmd, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Promise<string | null> {
	try {
		const r = await runCmd(["git", "-C", p, "rev-parse", what], p, timeoutMs);
		if (r.ok) {
			const t = r.stdout.trim().split("\n").pop() || "";
		return t || null;
		}
	} catch {}
	return null;
}

/**
 * P0（跨工作树证据污染）：检测 cwd 是否为 linked worktree（git worktree add 创建的链接工作树）。
 * 主检出：--git-dir 与 --git-common-dir 同指向 <root>/.git；linked worktree：--git-dir 指向
 * <root>/.git/worktrees/<name> 而后者仍指 <root>/.git —— 两者归一后不一致即 linked。
 * 返回 linked 工作树的主仓库根（common-dir 的父目录）；非 linked 返回 null。
 */
async function linkedWorktreeMainRoot(p: string, runCmd: RunCmd, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Promise<string | null> {
	const gitDir = await gitRevParseValue(p, "--git-dir", runCmd, timeoutMs);
	if (!gitDir) return null;
	const commonDir = await gitRevParseValue(p, "--git-common-dir", runCmd, timeoutMs);
	if (!commonDir) return null;
	const resolve = (v: string) => (path.isAbsolute(v) ? v : path.resolve(p, v));
	if (path.resolve(resolve(gitDir)) === path.resolve(resolve(commonDir))) return null;
	return path.dirname(resolve(commonDir));
}

/**
 * 解析证据采集的有效 git cwd（P1-1 修正）。永不抛错。
 *
 * 解析顺序：
 *   1. cwd 在 git work tree 内（rev-parse --is-inside-work-tree 为 true）→
 *        保持原 cwd 跑测试与 git diff（git 命令天然支持子目录），用 --show-toplevel 注明 root 供参考；
 *        cwd 即 root 时 note=null。（monorepo 子包等「仓库内无 .git 的合法子目录」在此正确保留。）
 *   2. cwd 不在任何 work tree：下探——仅当「唯一直接子目录（总数==1）且它确为 git 仓库（rev-parse 真实判定）」
 *        才自动采用；否则保持 cwd（如实失败）+ 警告，不猜仓库跑测试。
 *   3. 以上均不成立 → effCwd=cwd + 「证据不可用」警告（测试/diff 仍按 cwd 如实执行/失败）。
 */
export async function resolveGitCwd(cwd: string, runCmd: RunCmd, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Promise<ResolvedGitCwd> {
	const unresolvable = (): ResolvedGitCwd => ({
		effCwd: cwd,
		note: `[证据不可用] cwd=${cwd} 不在任意 git 工作树内（父/子均无可确认的 git 仓库），测试探测与 git diff 将按 cwd 如实执行/失败——派发任务时请传 cwd=项目根目录`,
	});
	try {
		// 1. cwd 是否在 git work tree 内（git rev-parse 自带上探，覆盖仓库内子目录）
		if (await isInsideWorkTree(cwd, runCmd, timeoutMs)) {
			const root = await gitTopLevel(cwd, runCmd, timeoutMs);
			// P0：linked worktree 标注——cwd 为链接工作树时 diff/status 仅覆盖本工作树检出，
			// 不含主检出/其他 worktree；标注主仓库根，避免“越界/假越界”误读（实战 2 次假越界取证）。
			const mainRoot = await linkedWorktreeMainRoot(cwd, runCmd, timeoutMs);
			const notes: string[] = [];
			if (mainRoot) {
				notes.push(`[linked worktree] cwd=${cwd} 为链接工作树（主仓库 ${mainRoot}）；diff/status 仅覆盖本工作树检出，不含主检出与其他 worktree`);
			}
			if (!root || path.resolve(root) === path.resolve(cwd)) {
				return { effCwd: cwd, note: notes.length ? notes.join("；") : null };
			}
			notes.push(`[git 工作树子目录] cwd=${cwd} 位于 git 工作树内（root=${root}），保持原 cwd 运行测试与 git diff（git 命令天然支持子目录）`);
			return { effCwd: cwd, note: notes.join("；") };
		}

		// 2. cwd 不在任何 work tree：下探「唯一直接子目录（总数==1）且它确为 git 仓库」才采用
		let childDirs: string[] = [];
		try {
			childDirs = fs.readdirSync(cwd, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name);
		} catch {
			// cwd 不可读或不存在 → 视为无可下探子目录
		}
		if (childDirs.length === 1) {
			const child = path.join(cwd, childDirs[0]);
			if (await isInsideWorkTree(child, runCmd, timeoutMs)) {
				return { effCwd: child, note: `[cwd 自动下探] cwd=${cwd} 不在 git 工作树内，已下探到唯一直接子目录（且为 git 仓库）${child}；派发时传 cwd 可消除此猜测` };
			}
		}

		// 3. 无法确定 git cwd：保持 cwd（如实失败）+ 警告
		return unresolvable();
	} catch {
		return unresolvable();
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 主入口
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 采集结构化证据。测试状态供同步任务的确定性收尾循环消费；文本与旧 gatherEvidence
 * 输出完全同构，finalizer 可直接复用，避免同一基线命令重复执行。
 */
/** 8月迭代 F3：任务 spawn 前工作区快照（git status --porcelain 行集；失败 null）。证据归因基线。
 *  ev-20260906-858536：不再 .trim() 整行——trim 会剥掉 `XY ` 固定宽度状态位首位（` M x`→`M x`），
 *  下游 porcelainPath 的 slice(3) 便吃掉 path 首字符（tracked 修改行全部误标 ⚠ext 的直接根因）；
 *  仅剥行尾 \r（跨平台归一）。基线与结算快照同函数采集，字符串集比对口径一致。 */
/** 证据面 git 读取的统一输出上限（ev-20261020-bed300）：派发基线快照与结算侧 gitQuiet 同一口径。
 *  曾经快照沿用 execFileSync 默认的 1MB 上限、结算侧为 4MB，大预脏树在派发点就 ENOBUFS→null，
 *  启动快照整份缺席，TASK_START_PORCELAIN_MAX_BYTES 的包络在生产端到不了。该上限只约束读取，
 *  sidecar 体积仍由 TASK_START_PORCELAIN_MAX_BYTES / ENTRY_CAP 约束。 */
export const EVIDENCE_GIT_MAX_BUFFER = 32 * 1024 * 1024;

export function takeGitStatusSnapshot(cwd: string, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): string[] | null {
	try {
		// P0：-C cwd 钉死 + gitEnv 剩除 GIT_DIR 等指向覆盖（防跨工作树污染）；status 仍为全仓口径（与派发基线可比）
		const out = execFileSync("git", ["-C", cwd, "--no-pager", "status", "--porcelain"], { cwd, env: gitEnv(), timeout: timeoutMs, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], maxBuffer: EVIDENCE_GIT_MAX_BUFFER });
		return out.split("\n").map((l) => l.replace(/\r$/, "")).filter(Boolean);
	} catch {
		return null;
	}
}

// ── ev-20261019-a7519f：任务启动状态快照（产物摘要净变化基准）──────────────────
// 实战根因（evolution ev-20261019-a7519f）：existing 共享树派发前已有大量未提交改动时，产物摘要
// 只有行级基线（gitBaseline porcelain 行集）与 vs HEAD 的 diff 口径——「派发前已改动路径被任务
// 再次修改」状态行不变，行级差集不可见；diff --stat 恒含派发前改动；写日志缺失（只读审查任务
// bash heredoc 写报告）时更回退全树统计。本段补内容级基准：派发时对基线脏路径逐个记录
// mtime+size（小文件附 sha1 指纹），结算侧据此计算任务期间净变化（新增/修改/删除），
// 对 bash 写入同样生效（不依赖登记）。基准范围＝gitBaseline 脏路径（干净路径的起点态 == HEAD，
// 可由 git diff 直接还原，不入快照）——有界：条数 ≤TASK_START_STATE_ENTRY_CAP，sha1 采集限
// 单文件 ≤64KB 且总额 ≤8MB，超出回退 mtime+size 判定。存储首写优先（resume 保最早基准），
// 生命周期与写入登记同（done/truncated 清、error/blocked 留）。

/** 单文件 sha1 采集上限（超出回退 mtime+size 判定——内容指纹是精度增强，不是硬依赖）。 */
const TASK_START_STATE_HASH_FILE_CAP = 64 * 1024;
/** 单快照 sha1 采集总额上限（大仓/大文件派发场景有界：超出回退 mtime+size）。 */
const TASK_START_STATE_HASH_TOTAL_CAP = 8 * 1024 * 1024;

/** lstat 安全包装：不存在/异常 → null（不猜）。 */
function lstatSafe(abs: string): fs.Stats | null {
	try { return fs.lstatSync(abs); } catch { /* lint-exempt:stat 异常=不存在（不猜） */ return null; }
}

/** 文件内容 sha1（≤cap 字节；读取失败/非普通文件 → null）。 */
function sha1OfFile(abs: string, cap: number): string | null {
	try {
		const st = fs.lstatSync(abs);
		if (!st.isFile() || st.size > cap) return null;
		return createHash("sha1").update(fs.readFileSync(abs)).digest("hex");
	} catch { /* lint-exempt:hash 失败回退 mtime+size 判定 */ return null; }
}

/** 有界展开未跟踪目录（porcelain `?? dir/` 折叠）：收集目录内文件条目；预算耗尽置截断。 */
function expandStartStateDir(absDir: string, budget: { hashed: number }, entries: TaskStartStateEntry[], cap: number): boolean {
	let names: string[];
	try { names = fs.readdirSync(absDir).sort(); } catch { /* lint-exempt:不可读目录按展开完成处理（截断由 cap 兜底） */ return true; }
	for (const name of names) {
		if (entries.length >= cap) return false;
		const abs = path.join(absDir, name);
		const st = lstatSafe(abs);
		if (st === null) continue;
		if (st.isDirectory()) { if (!expandStartStateDir(abs, budget, entries, cap)) return false; continue; }
		const entry: TaskStartStateEntry = { file: abs, mtimeMs: st.mtimeMs, size: st.size };
		if (st.isFile() && st.size <= TASK_START_STATE_HASH_FILE_CAP && budget.hashed + st.size <= TASK_START_STATE_HASH_TOTAL_CAP) {
			const h = sha1OfFile(abs, TASK_START_STATE_HASH_FILE_CAP);
			if (h) { entry.sha1 = h; budget.hashed += st.size; }
		}
		entries.push(entry);
	}
	return true;
}

/**
 * 采集任务启动状态快照：gitBaseline 脏路径（含 rename 两侧、未跟踪目录展开）逐个 lstat 记录
 * mtime+size（小文件附 sha1）。baseline 非 git 仓库/仓库根解析失败 → null（调用方不落 sidecar，
 * 摘要回退行级差集口径）。导出供 task-run 派发点与测试直接驱动。
 */
export function takeWorkspaceStateSnapshot(cwd: string, baselinePorcelain: string[] | null, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): TaskStartStateSnapshot | null {
	if (!Array.isArray(baselinePorcelain)) return null;
	const rootReal = repoRootReal(cwd, timeoutMs);
	if (rootReal === null) return null;
	const cap = TASK_START_STATE_ENTRY_CAP;
	const budget = { hashed: 0 };
	const entries: TaskStartStateEntry[] = [];
	let truncated = false;
	const pushFile = (abs: string, st: fs.Stats | null): void => {
		if (st === null) { entries.push({ file: abs, mtimeMs: -1, size: -1 }); return; } // 派发时不存在（D 侧/rename 旧侧）
		const entry: TaskStartStateEntry = { file: abs, mtimeMs: st.mtimeMs, size: st.size };
		if (st.isFile() && st.size <= TASK_START_STATE_HASH_FILE_CAP && budget.hashed + st.size <= TASK_START_STATE_HASH_TOTAL_CAP) {
			const h = sha1OfFile(abs, TASK_START_STATE_HASH_FILE_CAP);
			if (h) { entry.sha1 = h; budget.hashed += st.size; }
		}
		entries.push(entry);
	};
	for (const line of baselinePorcelain) {
		if (truncated) break;
		for (const side of porcelainPath(line).split(" -> ")) {
			const abs = physicalPathDeep(path.join(rootReal, side));
			if (entries.length >= cap) { truncated = true; break; }
			const st = lstatSafe(abs);
			if (st !== null && st.isDirectory()) {
				if (!expandStartStateDir(abs, budget, entries, cap)) truncated = true;
				continue;
			}
			pushFile(abs, st);
		}
	}
	// ev-20261111-fix（diting F06）：同步保存链首轮 porcelain 起点（有界：超 cap 不入，消费侧回退
	// 次轮口径）——后续轮的 RunResult.gitBaseline 含前轮新增产物，整链净变化/差集必须以首轮
	// 起点算，否则首轮新建文件被次轮基线吞掉（「无净变化」假阴性，与未跟踪段自相矛盾）。
	return { v: 1, cwd, repoRoot: rootReal, collectedAt: Date.now(), cap, truncated, entries,
		...(porcelainBytes(baselinePorcelain) <= TASK_START_PORCELAIN_MAX_BYTES ? { baselinePorcelain: [...baselinePorcelain] } : {}) };
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20260903-64641c（P0）：任务写入登记三档归因（attributionLine / buildArtifactDiffSummary 共用）
//
// 实战事故：外部进程与子 Agent 共享工作树并行写入，fresh 差集把外部写入归因为子 Agent 改动，
// Leader 误判越界令回滚，外部进程合法半成品被毁。增强为三档：
//   命中登记 = 确认本任务写入（现有口径不变）；
//   未命中 = 外部写入嫌疑（弱断言警示——登记=确认写入，未登记≠一定外部，bash 复杂写法覆盖不了）；
//   无 taskId（旧调用方）= 恒命中（既有口径零变化，零额外 git 开销）。
// 警示只提示核实 mtime 与内容，绝不作为回滚依据（轻护栏强感知）。
// ─────────────────────────────────────────────────────────────────────────────

/** 外部写入嫌疑警示（弱断言口径，ev-20260903-64641c 约定文案；正文含于消费侧断言）。 */
const EXT_WRITE_WARN = "⚠ext 无本任务写入记录——多进程共享工作树时可能是外部进程合法写入，回滚/归责前先核实 mtime 与内容";

/** porcelain 行 → 路径串。
 *  ev-20260906-858536（bug 修复）：快照/摘要侧曾对行做 .trim()，剥掉 `XY ` 固定宽度状态位后
 *  ` M path` 变 `M path`，原 slice(3) 会吃掉 path 首字符（`server/x` → `erver/x`）→ 三档归因把
 *  本任务 tracked 修改全部误标 ⚠ext（仅 `?? ` 两态位行幸免）。现双口径兼容：
 *    未剥状态位（"XY path"，XY 各为状态字符含空格）→ index 3 起；
 *    已 trim 的单态位行（"Y path"，原 " Y"）→ index 2 起；其余原样。
 *  rename 的 "old -> new" 逐侧解码后原样重组，由匹配器拆分两侧。
 *  引号包裹路径（core.quotepath 非 ASCII 转义）经 decodePorcelainPath 还原真实文件名。 */
/** C 风格控制字符字母转义（git quote_c_style 的字母形式）→ 字节值。 */
const C_LETTER_ESCAPES: Record<string, number> = { a: 0x07, b: 0x08, f: 0x0c, n: 0x0a, r: 0x0d, t: 0x09, v: 0x0b };

/** porcelain 引号路径解码（ev-20260906-858536 残留根因②）。
 *  git core.quotepath 默认 on：含非 ASCII/控制字符/引号的路径输出为 "…" 包裹 + C 风格转义
 *  （如 "\345\242\231" = 三个原始字节，恰为一个 UTF-8 汉字）。登记方（edit/write/bash 覆盖层）
 *  持有真实路径字符串，比对侧若不解码：三档归因恒 miss（子 Agent 已登记写入误标 ⚠ext）、
 *  未跟踪新文件段 stat ENOENT 显示「不可读」而非行数、时间窗豁免 stat 失效。八进制转义按
 *  原始字节累积后整体按 UTF-8 解码（逐 \nnn String.fromCharCode 会把多字节序列拆成 Latin-1
 *  乱码）；非引号包裹（ASCII 直显路径）原样返回，零行为变化。 */
export function decodePorcelainPath(p: string): string {
	if (p.length < 2 || !p.startsWith('"') || !p.endsWith('"')) return p;
	const inner = p.slice(1, -1);
	const chunks: Buffer[] = [];
	let lit = "";
	const flush = (): void => { if (lit) { chunks.push(Buffer.from(lit, "utf8")); lit = ""; } };
	for (let i = 0; i < inner.length; i++) {
		const ch = inner[i];
		if (ch !== "\\") { lit += ch; continue; }
		const rest = inner.slice(i + 1);
		const oct = rest.match(/^[0-7]{1,3}/);
		if (oct) { flush(); chunks.push(Buffer.from([parseInt(oct[0], 8)])); i += oct[0].length; continue; }
		const letter = C_LETTER_ESCAPES[rest[0] ?? ""];
		if (letter !== undefined) { flush(); chunks.push(Buffer.from([letter])); i++; continue; }
		const next = rest[0];
		if (next !== undefined) { lit += next; i++; continue; } // \" 与 \\ 等常规转义取字面
		lit += "\\"; // 末尾孤立反斜杠：原样保留
	}
	flush();
	return Buffer.concat(chunks).toString("utf8");
}

/** porcelain 行展示形态（ev-20260906-858536 残留②联动）：保留 XY 状态前缀，路径段（含 rename
 *  两侧）解码为真实文件名——core.quotepath 八进制转义对 Leader 不可读，逐行 ⚠ext/↔sib 标注
 *  需与文件对得上号；非标准行原样（不做猜测）。ASCII 直显路径逐字不变（零行为变化）。 */
function displayPorcelainLine(l: string): string {
	const two = /^[MADRCU?! ]{2} /.exec(l);
	if (two) return two[0] + porcelainPath(l);
	const one = /^[MADRCU?!] /.exec(l);
	if (one) return one[0] + porcelainPath(l);
	return l;
}

function porcelainPath(l: string): string {
	let raw: string;
	if (/^[MADRCU?! ]{2} /.test(l)) raw = l.slice(3).trim();
	else if (/^[MADRCU?!] /.test(l)) raw = l.slice(2).trim();
	else raw = l.trim();
	// rename 行 "old" -> "new" 两侧各自引号包裹：逐侧解码（整串只剥首尾引号会把中间 " -> " 卷进解码）
	return raw.split(" -> ").map((s) => decodePorcelainPath(s.trim())).join(" -> ");
}

/** 归一化到物理绝对路径（realpath 归一符号链接，如 macOS /var→/private/var——git 报告的是物理
 *  路径而登记方可能持符号链接前缀，不归一会把命中误判为未命中；失败（如目标已删）回退 resolve）。 */
function physicalPath(p: string): string {
	try { return fs.realpathSync(p); } catch { return path.resolve(p); }
}

/** ev-20260923-d7be81（E2）：写面登记专用的物理归一——目标不存在（写后删除/登记时即未落盘）时
 *  逐级上溯 realpath 最近存在祖先再拼回余段，保持 /var→/private/var 前缀归一（physicalPath 的
 *  resolve 回退会留符号链接形态，与物理化的仓库根错位 → 登记被误判为仓库外、写面静默漏计）。 */
function physicalPathDeep(p: string): string {
	try { return fs.realpathSync(p); } catch { /* 目标不存在：上溯最近存在祖先 */ }
	const abs = path.resolve(p);
	let dir = abs;
	const tail: string[] = [];
	for (;;) {
		const parent = path.dirname(dir);
		if (parent === dir) return abs; // 到根仍不存在：退化为字面 resolve
		tail.unshift(path.basename(dir));
		dir = parent;
		try { return path.join(fs.realpathSync(dir), ...tail); } catch { /* 祖先仍不存在：继续上溯 */ }
	}
}

/** repo 根物理路径（rev-parse --show-toplevel + realpath 归一；取不到/异常 → null）。
 *  matchesRecordedSet 与 §5#6 时间窗豁免共用，避免重复 rev-parse。timeoutMs 随所属证据链预算。 */
function repoRootReal(cwd: string, timeoutMs = DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS): string | null {
	try {
		const repoRoot = gitQuiet(["rev-parse", "--show-toplevel"], cwd, timeoutMs)?.trim() || null;
		return repoRoot !== null ? physicalPath(repoRoot) : null;
	} catch {
		return null;
	}
}

// ── 复盘 2026-09-03 §5#6：⚠ext 时间窗+cwd 豁免 ──────────────────────────────
// 实战事故：子 Agent 自己的写入因登记缺失（bash 复杂写法/heredoc 覆盖不了）被标 ⚠ext 无记录，
// 跨进程误报。补充弱证据豁免：路径 mtime 落在任务运行窗口（registry startedAt/endedAt 前后
// 各 2min slack）且位于任务 cwd 之下 → 判定为子 Agent 写入（不标 ⚠ext，弱断言注记）。
// record 或 stat 不可得 → 不豁免（宁保守，不放松外部嫌疑警示）。

/** §5#6：时间窗前后松弛（ms）——文件系统 mtime 粒度与结算时序容差。 */
const EXT_EXEMPT_SLACK_MS = 2 * 60 * 1000;

/** §5#6：fresh 路径中符合时间窗+cwd 豁免的子集（rename 行两侧任一侧命中即整行豁免）。 */
function windowCwdExemption(taskId: string, freshPaths: string[], cwd: string, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): Set<string> {
	const exempt = new Set<string>();
	let rec: Readonly<{ startedAt?: number; endedAt?: number; cwd?: string }> | undefined;
	try { rec = registry.get(taskId); } catch { return exempt; }
	if (!rec || typeof rec.startedAt !== "number" || !Number.isFinite(rec.startedAt)) return exempt;
	const taskCwdReal = physicalPath(typeof rec.cwd === "string" && rec.cwd ? rec.cwd : cwd);
	const end = typeof rec.endedAt === "number" && Number.isFinite(rec.endedAt) ? rec.endedAt : Date.now();
	const lo = rec.startedAt - EXT_EXEMPT_SLACK_MS;
	const hi = end + EXT_EXEMPT_SLACK_MS;
	const rootReal = repoRootReal(cwd, timeoutMs);
	for (const rel of freshPaths) {
		for (const side of rel.split(" -> ").map((s) => s.trim()).filter(Boolean)) {
			const abs = physicalPath(rootReal !== null ? path.join(rootReal, side) : path.resolve(cwd, side));
			let mtimeMs: number;
			try { mtimeMs = fs.statSync(abs).mtimeMs; } catch { continue; }
			if (mtimeMs < lo || mtimeMs > hi) continue;
			const relToTask = path.relative(taskCwdReal, abs);
			if ((relToTask === ".." || relToTask.startsWith(`..${path.sep}`)) || path.isAbsolute(relToTask)) continue;
			exempt.add(rel);
			break;
		}
	}
	return exempt;
}

/**
 * fresh 相对路径（rename 行拆两侧）→ 是否命中登记物理路径集（本任务与同批兄弟共用同一口径）。
 * repoRoot（rev-parse --show-toplevel，与 gitPathBaselineNote 同源）把相对路径对齐登记的绝对
 * 路径；取不到时退化为尾段匹配（弱方向：宁可多命中、少误警示）。rename 行两侧任一命中即命中。
 * taskId 缺省时调用方不建登记集（恒 own 档，旧口径零变化，不触发 git/磁盘开销）。
 */
function matchesRecordedSet(recorded: Set<string>, rootReal: string | null, relPath: string): boolean {
	for (const side of relPath.split(" -> ").map((s) => s.trim()).filter(Boolean)) {
		if (recorded.has(physicalPath(side))) return true;
		if (rootReal !== null) {
			if (recorded.has(physicalPath(path.join(rootReal, side)))) return true;
		} else {
			// repo 根未知（rev-parse 失败的兑底）：尾段匹配（弱方向——多命中、少误警示）
			const tail = side.startsWith("/") ? side : "/" + side;
			for (const f of recorded) if (f.endsWith(tail)) return true;
		}
	}
	return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20260907-e20971（P1）：并行批次同批兄弟写入归因（↔sib 档）。
//
// 实战摩擦：3 个并行批次（5+2+3 节点）的 10 份节点完成通知各携带 5-15 处「⚠ext 无本任务写入
// 记录」——实际 100% 为同批兄弟节点的合法写入（文件边界契约使然），Leader 每份需扫读排除，
// 累计 60-100 行噪声。修复口径（零新 schema，全部复用 registry 已有数据 + 真实登记链）：
//   - registry.get(taskId).runId 圈定同批（一次 orchestrate 一个 runId），同 runId 兄弟 taskId 的
//     真实写入证据 = readTaskWrites(sibling)（子进程成功写盘登记，≤512 行/任务）∪ 兄弟记录
//     lastWritePaths（滚动 ≤8 最近写盘轨迹——兄弟先结算清掉登记文件后仍可归因的错峰兑底）；
//   - 本任务登记优先：同路径双登记 → 本任务归因 + 多方写入统计注记（诚实标签，不静默）；
//   - 不把 allowedPaths 等权限声明当写入证据（只有真实登记/轨迹才算）；
//   - 未知/无登记/其他批次（不同 runId 不扫描）仍保留 ⚠ext 弱断言警示（口径零回退）；
//   - 有界：兄弟扫描 ≤SIBLING_SCAN_MAX 个（界外计数注记），登记每任务 ≤512 行（写入侧既有上限）；
//   - 完成通知（buildArtifactDiffSummary）与证据块归因行共用同一 classify，两输出口径一致；
//     合法兄弟写入标 ↔sib 短标记 + 一句有界统计（runId + 逐兄弟计数），不逐条重复长警告。
// 无 taskId / 无 runId（独立任务）/registry 不可用 → 扫描 null，输出与既有三档口径零变化。
// ─────────────────────────────────────────────────────────────────────────────

/** 同批兄弟扫描上限（有界 I/O；一次 orchestrate 节点数上界量级，界外计数不扫）。 */
const SIBLING_SCAN_MAX = 12;

interface SiblingScan {
	/** 本任务所属批次 runId；独立派发的并行任务无 runId（ev-20261108-fdd626：按同 cwd 圈定兄弟；
	 *  ev-20261108-m7：无 runId 时加运行窗口重叠与 resume/fork 链排除判据——见 isParallelSiblingRecord）。 */
	runId?: string;
	/** ev-20260918-d8ac4f：扫描面扩展为「同 runId ∪ 同 cwd（归一比较）」——跨批（不同 runId）
	 *  但共享同一工作树的并行任务写入同样有真实登记/轨迹，折叠 ⚠ext 是归因噪音（实战 62+25+24
	 *  处全部为合法兄弟写入）。仍只用真实登记口径（readTaskWrites ∪ lastWritePaths），不把权限
	 *  声明当写入证据；同批优先排序。 */
	siblings: Array<{ taskId: string; label: string; files: Set<string>; sameBatch: boolean }>;
	/** 界外未扫描的兄弟数（>0 时注记说明，不静默）。 */
	overflow: number;
	/** 跨批（同 cwd）命中计数——注记文案区分同批与跨批（口径诚实）。 */
	crossBatchUsed: boolean;
}

/** ev-20261108-m7（diting 审 m7）：无 runId 独立任务的同 cwd 并行兄弟判据（纯函数，单源）。
 *  fdd626 的同 cwd 圈定过宽修正：兄弟须与本任务运行窗口重叠（r 未结束，或 r.endedAt ≥
 *  mine.startedAt——本任务启动前已结束的同 cwd 旧任务不是并行兄弟，其登记/lastWritePaths
 *  不充当兄弟证据，外部写入如实保留 ⚠ext）；并排除 resume/fork 链亲缘（parentTaskId 直接
 *  互指）与同 name 前序记录（resume 新 taskId 续作同 name 的兑底——窗口判据已排除绝大多数
 *  已结束祖先，此处补齐并行同名歧义）。mine 有 runId 时调用方不经本函数（同批/d8ac4f 跨批
 *  口径不变）；evidence.ts collectSiblingWrites 与 context-budget.ts collectRelayArtifacts 共用。 */
export function isParallelSiblingRecord(mine: Readonly<TaskRecord>, r: Readonly<TaskRecord>): boolean {
	if (r.taskId === mine.taskId) return false;
	// resume/fork 链亲缘：直接父子互指不当兄弟（祖先/后代）。
	if (r.parentTaskId === mine.taskId || mine.parentTaskId === r.taskId) return false;
	// 同 name 前序兑底：同 name 记录视作同一任务的 resume 前序，不当并行兄弟。
	if (mine.name && r.name && mine.name === r.name) return false;
	if (!mine.cwd || !r.cwd) return false;
	try { if (path.resolve(r.cwd) !== path.resolve(mine.cwd)) return false; } catch { /* lint-exempt:cwd 归一化失败按非兄弟处理（保守，不扩大归因面） */ return false; }
	// 运行窗口重叠：r 仍在跑（endedAt 缺省）或在本任务启动后才结束。
	return r.endedAt === undefined || r.endedAt >= (mine.startedAt ?? 0);
}

/** 同批兄弟写入证据收集（口径见 ev-20260907-e20971 段注释；d8ac4f 扩同 cwd）。taskId 缺省/无 runId/异常 → null。 */
function collectSiblingWrites(taskId: string | undefined): SiblingScan | null {
	if (!taskId) return null;
	let mine: TaskRecord | undefined;
	let runId: string | undefined;
	try { mine = registry.get(taskId); runId = mine?.runId; } catch { return null; }
	// ev-20261108-fdd626：独立派发（task_submit 逐个提交）的并行任务无 runId——此前直接返回 null，
	// 同树并行任务的互写全落「未归因」、↔sib 恒 0。现无 runId 时仅按同 cwd 圈定兄弟（登记口径不变）；
	// 既无 runId 也无 cwd（无从圈定）才 null。ev-20261108-m7：无 runId 的同 cwd 圈定加并行性判据
	//（运行窗口重叠 + resume/fork 链排除，isParallelSiblingRecord 单源）；mine 有 runId 的同批与
	// d8ac4f 跨批同 cwd 口径不经该判据（保持既有语义）。
	if (!runId && !mine?.cwd) return null;
	let all: Readonly<TaskRecord>[];
	try { all = registry.list(); } catch { return null; }
	const myCwd = mine?.cwd ? path.resolve(mine.cwd) : null;
	const isSibling = (r: Readonly<TaskRecord>): boolean => {
		if (r.taskId === taskId) return false;
		if (runId && r.runId === runId) return true;
		if (!myCwd || !r.cwd) return false;
		try { if (path.resolve(r.cwd) !== myCwd) return false; } catch { /* lint-exempt:cwd 归一化失败按非兄弟处理（保守，不扩大归因面） */ return false; }
		return runId ? true : (!!mine && isParallelSiblingRecord(mine, r));
	};
	const matched = all.filter(isSibling);
	// 同批优先（登记链最完整），跨批同 cwd 兄弟随后
	matched.sort((a, b) => ((runId && a.runId === runId) ? 0 : 1) - ((runId && b.runId === runId) ? 0 : 1) || (b.startedAt ?? 0) - (a.startedAt ?? 0));
	const overflow = Math.max(0, matched.length - SIBLING_SCAN_MAX);
	const siblings: SiblingScan["siblings"] = [];
	let crossBatchUsed = false;
	for (const r of matched.slice(0, SIBLING_SCAN_MAX)) {
		const files = new Set<string>();
		for (const w of readTaskWrites(r.taskId)) files.add(physicalPath(w.file));
		for (const p of r.lastWritePaths ?? []) files.add(physicalPath(p));
		const sameBatch = !!runId && r.runId === runId;
		if (!sameBatch && files.size > 0) crossBatchUsed = true;
		siblings.push({ taskId: r.taskId, label: r.name || r.nodeId || r.taskId.slice(0, 8), files, sameBatch });
	}
	return { runId, siblings, overflow, crossBatchUsed };
}

/** fresh 路径分类结果（attributionLine 与 buildArtifactDiffSummary 共用，两输出口径一致）。 */
interface FreshAttribution {
	/** 命中本任务写入登记（确认本任务写入）。 */
	own: Set<string>;
	/** 仅命中同批兄弟写入证据 → 兄弟标签列表（多方同写同路径时多标签）。 */
	sibOnly: Map<string, string[]>;
	/** 同时命中本任务与兄弟登记（本任务优先归因；标签留存供审计）。 */
	multi: Map<string, string[]>;
	/** 兄弟写入逐标签计数（仅 sibOnly 命中计入，与“其中 X 处”总数对账）。 */
	sibCounts: Array<{ label: string; count: number }>;
	/** 无任何登记 → ⚠ext 候选（attributionLine 侧再做 §5#6 豁免）。 */
	unattributed: string[];
	/** 兄弟扫描上下文（null=无 runId/独立任务）。 */
	scan: SiblingScan | null;
}

/** fresh 路径四档分类（own / sibOnly / multi / unattributed）。taskId 缺省 → 恒 own 档（旧口径零变化）。
 *  S5/23f4a4：timeoutMs 透传 repoRootReal（随所属证据链预算：证据块=gitMs，摘要块=summaryGitMs）。 */
function classifyFreshPaths(taskId: string | undefined, cwd: string, freshPaths: string[], scan: SiblingScan | null, timeoutMs = DEFAULT_EVIDENCE_GIT_TIMEOUT_MS): FreshAttribution {
	const rootReal = repoRootReal(cwd, timeoutMs);
	const ownRecorded = taskId ? new Set(readTaskWrites(taskId).map((r) => physicalPath(r.file))) : null;
	const out: FreshAttribution = { own: new Set(), sibOnly: new Map(), multi: new Map(), sibCounts: [], unattributed: [], scan };
	const counts = new Map<string, number>();
	for (const p of freshPaths) {
		const isOwn = ownRecorded === null || matchesRecordedSet(ownRecorded, rootReal, p);
		const sibHits: string[] = [];
		if (scan) for (const s of scan.siblings) if (matchesRecordedSet(s.files, rootReal, p)) sibHits.push(s.label);
		if (sibHits.length > 0) {
			(isOwn ? out.multi : out.sibOnly).set(p, sibHits);
			if (!isOwn) for (const label of sibHits) counts.set(label, (counts.get(label) ?? 0) + 1);
			continue;
		}
		if (isOwn) { out.own.add(p); continue; }
		out.unattributed.push(p);
	}
	out.sibCounts = [...counts.entries()].map(([label, count]) => ({ label, count }));
	return out;
}

/** ev-20260907-e20971：同批兄弟写入统计注记（两输出口径共用；sep=拼接前缀：证据块"；"/摘要块换行缩进）。
 *  ev-20260918-d8ac4f：跨批（同 cwd）命中分标——不冒充同批口径。 */
function siblingAttributionNote(cls: FreshAttribution, sep: string): string {
	const scan = cls.scan;
	if (!scan || cls.sibOnly.size === 0) return "";
	const counts = cls.sibCounts.map((c) => `${c.label} ${c.count} 处`).join("、");
	const overflow = scan.overflow > 0 ? `；另有 ${scan.overflow} 个兄弟任务界外未扫（上限 ${SIBLING_SCAN_MAX}）` : "";
	const cross = scan.crossBatchUsed && scan.runId ? "（含同 cwd 跨批并行任务）" : "";
	return `${sep}其中 ${cls.sibOnly.size} 处为兄弟任务已登记写入（${scan.runId ? `run=${scan.runId}` : "同 cwd 并行任务（运行窗口重叠）"}${cross}：${counts}${overflow}）——有兄弟写入证据，合并展示；登记不证明最终内容仅由该任务写入`;
}

// ─────────────────────────────────────────────────────────────────────────────
// S5/01ef8c（方案 §5.4）：compact/full 归因呈现层。
//
// 不改 classifyFreshPaths 四档算法与 §5#6 ±2min 窗口（上方实现零变化）；只在其结果之上：
//   - FreshTiers：own / multi / window（§5#6 豁免拆分——窗口内未归因候选）/ sib / ext 五桶；
//   - compact renderer（默认）：可见清单优先 own、multi（不受 mtime 窗限制，以免隐藏本任务
//     登记），再列窗口内 cwd 未归因候选（标注「窗口内未归因」，不改名为 own）；sibling-only
//     与窗口外历史/未知折成计数；总数与各档数量保留，可见清单沿用有界行数（不再被大批
//     ⚠ext 挤掉）；multi 保留多方写入标记；
//   - EvidenceClassificationSnapshot：有界结构化完整分类结果，随任务证据保存一份
//     （finalizer → artifact classification.json），full 展开用它——结束后工作树改动不改变旧详情；
//   - AMAGI_EVIDENCE_VIEW=legacy（evidence-options.resolveEvidenceView）回旧呈现：
//     只切 renderer，底层分类与记录不变。
// ─────────────────────────────────────────────────────────────────────────────

/** 快照单档有界上限（每档 ≤100 条；超限截断并置 truncated——full ≠ 无限清单）。 */
export const EVIDENCE_CLASSIFICATION_LIST_CAP = 100;

/** 结构化完整分类结果（随任务证据保存；query evidenceDetail=full 展开源）。 */
export interface EvidenceClassificationSnapshot {
	formatVersion: 1;
	/** 结束快照采集时刻（epoch ms）；full 展开以它为准，此后工作树改动不回写。 */
	collectedAt: number;
	/** 采集基准 cwd（摘要块/证据链 effCwd）。 */
	cwd: string;
	/** fresh 差集去重总数（各档计数之和；不丢原总数）。 */
	freshTotal: number;
	/** 派发基线已有未提交改动计数（非本任务产出）。 */
	baselineCount: number;
	counts: { own: number; multi: number; window: number; sib: number; ext: number };
	/** 命中本任务写入登记。 */
	own: string[];
	/** 本任务+兄弟双登记（保留多方写入标记）。 */
	multi: Array<{ path: string; labels: string[] }>;
	/** §5#6 窗口豁免命中（mtime 在任务运行窗口且 cwd 内；未归因——不是 own）。 */
	window: string[];
	/** 仅同批兄弟登记（↔sib）。 */
	sib: Array<{ path: string; labels: string[] }>;
	/** 无任何登记且窗口外（⚠ext 外部写入嫌疑）。 */
	ext: string[];
	/** 兄弟逐标签计数（与 sibOnly 命中对账）。 */
	sibCounts: Array<{ label: string; count: number }>;
	runId?: string;
	/** 任一档触达 LIST_CAP 截断。 */
	truncated: boolean;
	/** ⚠ext 弱断言警示原文（full 展开保留口径）。 */
	extWarnText: string;
	/** ev-20261019-a7519f：快照基准净变化计数（有启动快照且基线脏路径非空时存在；缺省 = 无快照口径）。 */
	net?: { added: number; modified: number; deleted: number; baselineUnchanged: number; truncated: boolean; /** ev-20261105-52d40b（D37-03）：归因三态分账（own=写证据命中 / unattributed=未归因不作非本任务结论 / sib=已证实兄弟登记）；readOnlyGrant=内核冻结授权写面为空（仅 reportFiles，可能性提示依据）。 */ attribution?: { own: { added: number; modified: number; deleted: number }; unattributed: { added: number; modified: number; deleted: number }; sib: { added: number; modified: number; deleted: number }; readOnlyGrant?: boolean } };
}

/** 五桶视图（compact/full renderer 与快照共用底座；由 FreshAttribution + 豁免集派生）。 */
interface FreshTiers {
	own: string[];
	multi: Array<{ path: string; labels: string[] }>;
	window: string[];
	sib: Array<{ path: string; labels: string[] }>;
	ext: string[];
	freshTotal: number;
	baselineCount: number;
	cls: FreshAttribution;
	exempt: Set<string>;
}

function freshTiersOf(cls: FreshAttribution, exempt: Set<string>, freshTotal: number, baselineCount: number): FreshTiers {
	return {
		own: [...cls.own],
		multi: [...cls.multi.entries()].map(([path, labels]) => ({ path, labels })),
		window: cls.unattributed.filter((p) => exempt.has(p)),
		sib: [...cls.sibOnly.entries()].map(([path, labels]) => ({ path, labels })),
		ext: cls.unattributed.filter((p) => !exempt.has(p)),
		freshTotal,
		baselineCount,
		cls,
		exempt,
	};
}

function buildClassificationSnapshot(cwd: string, t: FreshTiers, net?: EvidenceClassificationSnapshot["net"]): EvidenceClassificationSnapshot {
	const cut = <T,>(arr: T[]): T[] => arr.slice(0, EVIDENCE_CLASSIFICATION_LIST_CAP);
	return {
		formatVersion: 1,
		collectedAt: Date.now(),
		cwd,
		freshTotal: t.freshTotal,
		baselineCount: t.baselineCount,
		counts: { own: t.own.length, multi: t.multi.length, window: t.window.length, sib: t.sib.length, ext: t.ext.length },
		own: cut(t.own),
		multi: cut(t.multi),
		window: cut(t.window),
		sib: cut(t.sib),
		ext: cut(t.ext),
		sibCounts: t.cls.sibCounts,
		...(t.cls.scan?.runId ? { runId: t.cls.scan.runId } : {}),
		truncated: [t.own, t.multi, t.window, t.sib, t.ext].some((a) => a.length > EVIDENCE_CLASSIFICATION_LIST_CAP),
		extWarnText: EXT_WRITE_WARN,
		...(net ? { net } : {}),
	};
}

/** 各档计数段（仅非零档；compact 头部/折叠注记共用）。 */
function tierCountSegments(c: { own: number; multi: number; window: number; sib: number; ext: number }): string {
	return [
		c.own > 0 ? `own ${c.own}` : null,
		c.multi > 0 ? `multi ${c.multi}` : null,
		c.window > 0 ? `窗口内未归因 ${c.window}` : null,
		c.sib > 0 ? `↔sib ${c.sib}` : null,
		c.ext > 0 ? `⚠ext ${c.ext}` : null,
	].filter(Boolean).join("·");
}

/** ev-20260917-589972（P2）：共享树模式下 ⚠ext 档降噪文案——外部并行写入为预期（派发已声明
 *  共享工作树），折叠计数提示人工核对关键文件，不再携带逐条弱断言长警告。非共享树维持原文案。 */
const SHARED_TREE_EXT_NOTE = "共享树模式：外部并行写入为预期（派发已声明共享工作树），请人工核对关键文件";

/** ext 档折叠注记（compact 归因行/摘要块共用）：共享树模式换降噪文案。 */
function extFoldNote(extCount: number, sharedTree: boolean): string {
	return `窗口外/未知来源 ${extCount} 处折叠为计数——${sharedTree ? SHARED_TREE_EXT_NOTE : EXT_WRITE_WARN}`;
}

/** compact 归因行（证据块）：own/multi 优先可见，窗口候选次之；sibling-only 与窗口外折计数。 */
function renderAttributionCompact(t: FreshTiers, sharedTree = false): string {
	const c = { own: t.own.length, multi: t.multi.length, window: t.window.length, sib: t.sib.length, ext: t.ext.length };
	const visible: string[] = [];
	for (const p of t.own) { if (visible.length >= 10) break; visible.push(p); }
	for (const m of t.multi) { if (visible.length >= 10) break; visible.push(`${m.path}↔multi(${m.labels.join("·")})`); }
	for (const p of t.window) { if (visible.length >= 10) break; visible.push(`${p}（窗口内未归因）`); }
	const hidden = t.freshTotal - visible.length;
	const segs = tierCountSegments(c);
	let line = `• 归因：任务期间新增/变化 ${t.freshTotal} 处${t.freshTotal > 0 ? `（${visible.join(", ")}${hidden > 0 ? ` …另有 ${hidden} 处未列出` : ""}${segs ? `｜${segs}` : ""}）` : ""}${t.baselineCount > 0 ? `；基线已有 ${t.baselineCount} 处未提交改动（非本任务产出，diff 数字含既有改动）` : ""}`;
	const notes: string[] = [];
	const sibNote = siblingAttributionNote(t.cls, "；");
	if (sibNote) notes.push(sibNote.slice(1));
	if (c.multi > 0) notes.push(`其中 ${c.multi} 处同时有本任务与同批兄弟写入登记（多方写入，本任务优先归因）`);
	const folded: string[] = [];
	if (c.sib > 0) folded.push(`↔sib（仅兄弟登记）${c.sib} 处折叠为计数`);
	if (c.ext > 0) folded.push(extFoldNote(c.ext, sharedTree));
	if (folded.length > 0) notes.push(folded.join("；"));
	if (c.window > 0) notes.push(`其中 ${c.window} 处 mtime 在任务运行窗口内且位于任务 cwd 下（窗口内未归因·登记缺失弱断言，不是 own）`);
	return notes.length > 0 ? `${line}\n  ${notes.join("；")}` : line;
}

/** legacy 归因行（AMAGI_EVIDENCE_VIEW=legacy 回滚）：与 01ef8c 改动前逐字一致。 */
function renderAttributionLegacy(cls: FreshAttribution, exempt: Set<string>, freshPaths: string[], baseCount: number): string {
	const missCount = cls.unattributed.filter((p) => !exempt.has(p)).length;
	const exemptCount = cls.unattributed.length - missCount;
	const listed = freshPaths.slice(0, 10).map((p) => {
		if (cls.own.has(p) || cls.multi.has(p) || exempt.has(p)) return p; // multi：本任务优先归因（统计另注多方写入）
		return cls.sibOnly.has(p) ? `${p}↔sib` : `${p}⚠ext`;
	}).join(", ") + (freshPaths.length > 10 ? ` …共${freshPaths.length}` : "");
	let line = `• 归因：任务期间新增/变化 ${freshPaths.length} 处${freshPaths.length ? `（${listed}）` : ""}${baseCount > 0 ? `；基线已有 ${baseCount} 处未提交改动（非本任务产出，diff 数字含既有改动）` : ""}`;
	line += siblingAttributionNote(cls, "；");
	if (cls.multi.size > 0) {
		line += `；其中 ${cls.multi.size} 处同时有本任务与同批兄弟写入登记（多方写入，本任务优先归因）`;
	}
	const siblingActive = !!cls.scan && cls.scan.siblings.length > 0;
	if (missCount === freshPaths.length && freshPaths.length > 0) {
		line += `；${EXT_WRITE_WARN}（全部 ${missCount} 处均无${siblingActive ? "本任务及同批兄弟" : "本任务"}写入记录——多进程共享工作树时更可能是外部进程写入，回滚/归责前务必逐项核实）`;
	} else if (missCount > 0) {
		line += `；其中 ${missCount} 处${EXT_WRITE_WARN}`;
	}
	if (exemptCount > 0) {
		line += `；其中 ${exemptCount} 处 mtime 在任务运行窗口内且位于任务 cwd 下，判定为子 Agent 写入（登记缺失，弱断言）`;
	}
	return line;
}

/** 8月迭代 F3：归因行——结算快照 vs 派发基线，区分本任务期间变化与既有改动（multi-writer 归因不失真）。
 *  ev-20260903-64641c：三档归因；ev-20260907-e20971：同批兄弟归因档（历史口径见 legacy renderer）。
 *  S5/01ef8c：compact（默认）/legacy 双 renderer（AMAGI_EVIDENCE_VIEW），只切呈现，
 *  不改四档归因与 §5#6 窗口算法；gitTimeoutMs 随证据链预算（S5/23f4a4）。 */
function attributionLine(baseline: string[] | null | undefined, current: string[] | null, taskId?: string, cwd?: string, opts?: { gitTimeoutMs?: number; view?: EvidenceView; sharedTree?: boolean }): string | null {
	if (!current) return null;
	const baseSet = new Set(baseline ?? []);
	const fresh = current.filter((l) => !baseSet.has(l));
	const pathOf = porcelainPath;
	const freshPaths = [...new Set(fresh.map(pathOf))];
	const baseCount = new Set([...baseSet].map(pathOf)).size;
	if (freshPaths.length === 0 && baseCount === 0) return null;
	const effCwd = cwd ?? process.cwd();
	const gitTimeoutMs = opts?.gitTimeoutMs ?? DEFAULT_EVIDENCE_GIT_TIMEOUT_MS;
	// ev-20260907-e20971：四档分类（own/sibOnly/multi/unattributed；无 runId → 扫描 null，零变化）
	const cls = classifyFreshPaths(taskId, effCwd, freshPaths, collectSiblingWrites(taskId), gitTimeoutMs);
	// §5#6：时间窗+cwd 豁免（仅无任何登记的路径参与判定；taskId 缺省恒空集，零变化）
	const exempt = taskId ? windowCwdExemption(taskId, cls.unattributed, effCwd, gitTimeoutMs) : new Set<string>();
	if ((opts?.view ?? resolveEvidenceView()) === "compact") {
		return renderAttributionCompact(freshTiersOf(cls, exempt, freshPaths.length, baseCount), opts?.sharedTree === true);
	}
	return renderAttributionLegacy(cls, exempt, freshPaths, baseCount);
}

// ─────────────────────────────────────────────────────────────────────────────
// B1（Wave B）：完成通知产物摘要块（finalizeTerminal 消费）
// ─────────────────────────────────────────────────────────────────────────────

/** 产物摘要块首行标注（通知契约：改动范围供抽查，非验收替代）。 */
export const ARTIFACT_SUMMARY_LABEL = "[产物摘要] 改动范围供抽查，非验收替代";

// S5/23f4a4：旧常量 SUMMARY_GIT_TIMEOUT_MS 迁入 evidence-options（默认 5000 = 旧值；可经 task/env 配置）。
const SUMMARY_STATUS_MAX_LINES = 15;
const SUMMARY_STAT_TAIL = 5;

/** 阻塞风险控制：execFileSync + 限时（默认/回滚 = 旧 5s 常量）；任何失败（非 git 仓库/超时/输出超限）→ null 静默省略。 */
function gitQuiet(args: string[], cwd: string, timeoutMs = DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS): string | null {
	try {
		// P0：-C cwd 钉死 + gitEnv 剩除 GIT_DIR 等指向覆盖（防跨工作树污染）
		return execFileSync("git", ["-C", cwd, ...args], { cwd, env: gitEnv(), timeout: timeoutMs, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], maxBuffer: EVIDENCE_GIT_MAX_BUFFER });
	} catch {
		return null;
	}
}

/**
 * ev-20260901-cd4173 C：产物摘要块路径基准标注——块内 diff/status 路径相对**本检出**仓库根，
 * linked worktree 任务回流的子目录前缀（如 battle-simulator/…）曾被误读为主树改动。
 * 判定与 resolveGitCwd 的 [linked worktree] 标注同源：--git-dir ≠ --git-common-dir（归一后）→
 * 「路径基准：worktree <toplevel>（分支 <branch>）」；主检出 → 「路径基准：主仓 <toplevel>」。
 * 归一用 realpath：子目录 cwd 下 --git-dir 输出物理绝对路径而 --git-common-dir 相对路径
 * 经 cwd（可能含符号链接，如 macOS /var→/private/var）解析后字面不等——不归一会把主仓子目录
 * 误标为 worktree；realpath 任一失败退化为字面比较。rev-parse 任一值缺失 → null 省略标注
 * （宁缺不误标）；detached HEAD 退化为短 SHA。
 */
function gitPathBaselineNote(cwd: string, timeoutMs = DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS): string | null {
	const toplevel = gitQuiet(["rev-parse", "--show-toplevel"], cwd, timeoutMs)?.trim();
	const gitDir = gitQuiet(["rev-parse", "--git-dir"], cwd, timeoutMs)?.trim();
	const commonDir = gitQuiet(["rev-parse", "--git-common-dir"], cwd, timeoutMs)?.trim();
	if (!toplevel || !gitDir || !commonDir) return null;
	const resolve = (v: string) => (path.isAbsolute(v) ? v : path.resolve(cwd, v));
	const norm = (p: string): string => {
		try { return fs.realpathSync(p); } catch { return path.resolve(p); }
	};
	if (norm(resolve(gitDir)) !== norm(resolve(commonDir))) {
		let branch = gitQuiet(["rev-parse", "--abbrev-ref", "HEAD"], cwd, timeoutMs)?.trim();
		if (!branch || branch === "HEAD") {
			const sha = gitQuiet(["rev-parse", "--short", "HEAD"], cwd, timeoutMs)?.trim();
			branch = sha ? `detached@${sha}` : "未知";
		}
		return `路径基准：worktree ${toplevel}（分支 ${branch}）`;
	}
	return `路径基准：主仓 ${toplevel}`;
}

// ── ev-20260923-d7be81（E2）：产物摘要任务写面口径 ──────────────────────────
// 实战摩擦（同会话三次实证）：产物摘要的 `git diff --stat HEAD -- .` 是共享树全量汇总口径——
// 并行会话/兄弟任务的改动（webui/src 等）混入任务产物摘要，advisory 据此误报
// 「疑似范围外产物」，Leader 每次需人工甄别。本段把 diff --stat 与未跟踪两段改为以本任务写面
// （task-write-log 登记的本任务写入路径集，B0 归因同源）为过滤器：
//   - diff --stat：`git diff --stat HEAD -- <登记路径…>`（物理绝对 pathspec，限仓库根内）；
//   - 未跟踪段：?? 条目 ∩ 写面登记（目录折叠双向包含：?? dir/ ↔ 登记目录内文件）；
//   - 归因行（own/窗口内未归因/ext）不动——另一条链路（B0 已用），状态差集仍全仓口径；
//   - 写日志缺失（无 taskId/无登记/仓库根解析失败）→ 回退 `-- .` 全量并显式标注口径；
//   - 有界：登记去重后超 SUMMARY_WRITE_FACE_PATH_CAP 截断 pathspec 并标注。

/** ev-20260923-d7be81：写面 pathspec 上限（登记 ≤512 行/任务；去重后超 200 处截断标注）。 */
const SUMMARY_WRITE_FACE_PATH_CAP = 200;

/** ev-20260923-d7be81：产物摘要写面过滤口径（diff --stat pathspec + untracked 交集源）。 */
interface SummaryWriteFace {
	/** 本任务写面登记全集（物理绝对路径去重；含仓库外路径——供 untracked 匹配与计数标注）。 */
	recorded: Set<string>;
	/** 仓库根内的 diff pathspec（物理绝对路径；≤CAP，超限截断保留登记序）。 */
	specs: string[];
	/** 截断标注（specs 触达上限截断时非空，拼入 diff 段口径说明）。 */
	truncNote: string;
}

/**
 * 本任务写面解析：taskId+登记+仓库根齐备 → 过滤口径；任一缺失 → null（调用方回退共享树全量
 * 并显式标注）。任务零写入与登记缺失不可区分——同样回退全量（口径标注如实说明）。
 */
function resolveSummaryWriteFace(taskId: string | undefined, rootReal: string | null): SummaryWriteFace | { fallbackReason: "no-log" | "no-root" } | null {
	if (!taskId) return null;
	const recs = readTaskWrites(taskId);
	if (recs.length === 0) return { fallbackReason: "no-log" }; // 写日志缺失（旧任务/异常/零登记）→ 回退全量
	if (rootReal === null) return { fallbackReason: "no-root" }; // 仓库根解析失败 → 无法构造域内 pathspec，回退全量（M3：与登记缺失分叉标注）
	const recorded = new Set<string>();
	for (const r of recs) recorded.add(physicalPathDeep(r.file)); // 深归一：不存在路径也保持物理前缀（见 physicalPathDeep）
	const inRepo: string[] = [];
	for (const p of recorded) {
		const rel = path.relative(rootReal, p);
		if (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel)) inRepo.push(p); // 仓库根本身（rel=""）也入列：登记即全仓写面
	}
	const truncNote = inRepo.length > SUMMARY_WRITE_FACE_PATH_CAP
		? `；写面登记 ${inRepo.length} 处超上限，仅统计前 ${SUMMARY_WRITE_FACE_PATH_CAP} 处`
		: "";
	return { recorded, specs: inRepo.slice(0, SUMMARY_WRITE_FACE_PATH_CAP), truncNote };
}

/** ev-20260923-d7be81：未跟踪条目 ∩ 写面登记（双向目录包含：porcelain 折叠目录 `?? dir/` 需
 *  命中 dir 内登记文件；登记为目录（bash cp -t DIR）需覆盖目录内未跟踪条目；登记即仓库根恒命中）。 */
function ownWriteFaceContains(recorded: Set<string>, rootReal: string, entryRel: string): boolean {
	if (matchesRecordedSet(recorded, rootReal, entryRel)) return true;
	const dir = entryRel.replace(/\/+$/, "");
	if (!dir) return false;
	const prefix = dir + path.sep;
	for (const p of recorded) {
		const rel = path.relative(rootReal, p);
		if ((rel === ".." || rel.startsWith(`..${path.sep}`)) || path.isAbsolute(rel)) continue;
		if (rel === "") return true; // 登记即仓库根：全仓写面
		if (rel === dir || rel.startsWith(prefix)) return true; // 登记文件位于折叠目录内
		if (dir.startsWith(rel.endsWith(path.sep) ? rel : rel + path.sep)) return true; // 登记目录包含未跟踪条目
	}
	return false;
}

// ── ev-20260906-50a3e6：未跟踪新文件有界清单（独立段，不混入 tracked diff）──────────
// 实战：新建产物（bitable-exporter.ts 等 1330+610 行）untracked 不进 git diff --stat HEAD，
// 验收方必须自行 git status 补验。本段从同一 porcelain 行集提取 ?? 条目，有界列出文件名+行数
//（目录不展开；≤8 条 + 溢出计数；行数只读前 256KB，超大文件标注截断）。
const UNTRACKED_LIST_MAX = 8;
const UNTRACKED_LINE_READ_CAP = 256 * 1024;

/** ev-20261012-21074e③：未跟踪目录展开项数上限（本任务写面登记命中的文件 ≤8 项 + 溢出计数）。 */
const UNTRACKED_DIR_EXPAND_MAX = 8;

/** 单个未跟踪条目描述：目录→未展开；普通文件→逻辑行数（含无结尾换行的末行；非 wc -l 的新行符计数）
 *  （≤256KB 读，更大标注截断）。lstat 不跟进符号链接（目标可能在采集边界外，不读外部目标）、
 *  非 regular（FIFO/套接字/设备）不 open（防阻塞）只标注跳过（ev-20260906-50a3e6 Leader 反馈修正）。
 *  导出供测试直接驱动边界分支（真实 git porcelain 不列出 FIFO 等非普通文件，无法经真实仓库触达）。 */
export function untrackedEntryDesc(abs: string): string {
	try {
		const st = fs.lstatSync(abs);
		if (st.isSymbolicLink()) return "符号链接（不跟进）";
		if (st.isDirectory()) return "目录（未展开）";
		if (!st.isFile()) return "非普通文件（跳过）";
		if (st.size === 0) return "0 行";
		const cap = Math.min(st.size, UNTRACKED_LINE_READ_CAP);
		const fd = fs.openSync(abs, "r");
		try {
			const buf = Buffer.alloc(cap);
			const n = fs.readSync(fd, buf, 0, cap, 0);
			const text = buf.subarray(0, n).toString("utf8");
			if (text.includes("\u0000")) return `${(st.size / 1024).toFixed(0)}KB 二进制`;
			const parts = text.split("\n");
			// 逻辑行数：末段非空（无结尾换行）也计为一行
			const lines = parts[parts.length - 1] === "" ? parts.length - 1 : parts.length;
			return st.size > UNTRACKED_LINE_READ_CAP ? `≥${lines} 行（仅计前 256KB）` : `${lines} 行`;
		} finally {
			fs.closeSync(fd);
		}
	} catch {
		return "不可读";
	}
}

/** 未跟踪目录展开（ev-20261012-21074e③）：porcelain 折叠的 `?? dir/` 条目按**本任务写面登记**展开
 *  目录内本任务写入的文件（登记 = write/edit/bash 成功写盘记录——跨任务/外部进程写入不在本任务
 *  登记，不列不误报；未登记文件不臆测，仅提示不展开）。≤UNTRACKED_DIR_EXPAND_MAX 项 + 溢出计数；
 *  无登记命中 → null（保持「目录（未展开）」原描述）。仅在产物摘要链（face 有写日志）调用；
 *  导出供测试直接驱动。 */
export function untrackedDirExpansion(recorded: Set<string>, rootReal: string, dirRel: string): string | null {
	const dir = dirRel.replace(/\/+$/, "");
	if (!dir) return null;
	const prefix = dir + path.sep;
	const rels: string[] = [];
	for (const p of recorded) {
		const rel = path.relative(rootReal, p);
		if (rel === dir) continue; // 登记目录本身（如 bash cp -t DIR）：无逐文件信息，不展开
		if (rel.startsWith(prefix)) rels.push(rel);
	}
	if (rels.length === 0) return null;
	rels.sort(); // 确定性展示（登记 Set 无序）
	const shown = rels.slice(0, UNTRACKED_DIR_EXPAND_MAX);
	const overflow = rels.length - shown.length;
	const lines = shown.map((rel) => `    ${rel}（${untrackedEntryDesc(path.join(rootReal, rel))}）`);
	if (overflow > 0) lines.push(`    …另有 ${overflow} 项登记未列出（目录内未登记文件不展开）`);
	return `  ${dirRel}（目录，展开本任务写面登记 ${rels.length} 项）:\n${lines.join("\n")}`;
}

/** 未跟踪段文本：porcelain 行集 → ?? 条目清单（无未跟踪 → null）。路径相对仓库根（porcelain 口径）。
 *  条目路径不 realpath（不预解析符号链接——那是 untrackedEntryDesc lstat 拒绝跟进的对象）。
 *  ev-20260923-d7be81（E2）：face 提供（产物摘要链）时按本任务写面过滤——仅列登记命中的
 *  ?? 条目，共享树其余未跟踪改动不进摘要；face=null（写日志缺失）回退全量并标注口径；
 *  face 未传（证据块链 gatherEvidenceReport）与既有文案零变化。
 *  ev-20261012-21074e③：face 提供时的目录条目展开为目录内本任务写面登记文件（写日志缺失/
 *  证据块链零变化——无登记源不展开，保持「目录（未展开）」）。 */
function untrackedSection(cwd: string, statusLines: string[], timeoutMs = DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS, face?: SummaryWriteFace | null): string | null {
	let entries = statusLines
		.filter((l) => /^\?\? /.test(l) || l.trimStart().startsWith("?? "))
		.map((l) => porcelainPath(l));
	if (entries.length === 0) return null;
	const rootReal = repoRootReal(cwd, timeoutMs) ?? cwd;
	if (face) {
		entries = entries.filter((rel) => ownWriteFaceContains(face.recorded, rootReal, rel));
		if (entries.length === 0) return null; // 写面过滤后无本任务未跟踪新文件 → 整段省略（共享树其余未跟踪不进摘要）
	}
	const shown = entries.slice(0, UNTRACKED_LIST_MAX);
	const overflow = entries.length - shown.length;
	// ev-20261012-21074e③：face 提供时目录条目展开（本任务写面登记源）；其余链路零变化。
	const renderEntry = (rel: string): string => {
		const abs = path.join(rootReal, rel);
		if (face) {
			try { if (fs.lstatSync(abs).isDirectory()) { const exp = untrackedDirExpansion(face.recorded, rootReal, rel); if (exp) return exp; } } catch { /* lint-exempt:stat 异常保持原描述（展开是增强呈现，不阻摘要） */ }
		}
		return `  ${rel}（${untrackedEntryDesc(abs)}）`;
	};
	const body = shown.map(renderEntry).join("\n");
	const header = face
		? `• 未跟踪新文件 ${entries.length} 处（git status ?? 条目 ∩ 本任务写面登记；共享树其余未跟踪改动不列入）:`
		: face === null
			? `• 未跟踪新文件 ${entries.length} 处（git status ?? 条目，共享树全量口径——本任务写日志缺失）:`
			: `• 未跟踪新文件 ${entries.length} 处（git status ?? 条目，不计入 diff --stat 的 tracked 口径）:`;
	return `${header}\n${body}${overflow > 0 ? `\n  …另有 ${overflow} 处未列出` : ""}`;
}

/**
 * B1：产物摘要块——派发基线（gitBaseline porcelain）与结束时 git status 的差集
 * （有界 ≤15 行，超出折叠为一行计数）+ git diff --stat 尾部 ≤5 行（无 diff 省略该段）。
 * 非 git 仓库/采集失败 → null（调用方静默省略，绝不报错）。baseline 未采集（undefined）时
 * 不做差集归因（防把派发前的既有未提交改动误标为本任务产出），仅保留 diff --stat 段。
 * ev-20260901-cd4173 C：首行下方标注路径基准（worktree/主仓，见 gitPathBaselineNote）。
 * ev-20260903-64641c：三档归因——taskId 提供时 fresh 差集逐路径查任务写入登记，未命中行尾
 * 标注 ⚠ext 弱断言警示；fresh 全部未命中时追加一句汇总警示；taskId 缺省输出与既有一致。
 * ev-20260906-50a3e6：追加未跟踪新文件独立段（?? 条目 + 行数，不混入 tracked diff）。
 * ev-20260906-858536：行集不再 .trim()（剥状态位导致 porcelainPath 吃首字符，三档归因全误标）；
 * 与 takeGitStatusSnapshot 同口径只剥行尾 \r，基线/结算字符串集比对一致。
 * ev-20260907-e20971：同批兄弟归因档——与 attributionLine 共用 classifyFreshPaths（两输出口径
 * 一致）：兄弟登记/轨迹写入标 ↔sib 短标记 + 有界统计注记，不逐条重复 ⚠ext 长警告（并行批次
 * 完成通知噪声根治）；未知写入仍保留完整警示。
 * ev-20260923-d7be81（E2）：diff --stat 与未跟踪段改任务写面口径（task-write-log 登记路径集
 * 为过滤器；写日志缺失回退共享树全量并显式标注；归因行/状态差集不动）。
 */
/** S5/01ef8c：摘要块可选输入（预算/呈现；缺省 = 旧常量与 env 解析视图）。 */
export interface ArtifactDiffSummaryOpts {
	/** S5/23f4a4：摘要块 git 预算（task/env 配置的 summaryGitMs；缺省 = 旧 5000ms 常量）。 */
	summaryGitMs?: number;
	/** S5/01ef8c：呈现模式（缺省 resolveEvidenceView()——默认 compact；legacy 回旧呈现）。 */
	view?: EvidenceView;
	/** ev-20260917-589972（P2）：共享树模式（派发声明 sharedTree:true）——⚠ext 档降噪：外部并行
	 *  写入为预期，折叠计数提示人工核对关键文件，不再逐条弱断言警告（只改呈现，不改归因算法）。 */
	sharedTree?: boolean;
}

/** S5/01ef8c：摘要块采集结果——文本（通知用）+ 结构化完整分类快照（随任务证据保存供 full 展开）。 */
export interface ArtifactDiffSummaryResult {
	text: string | null;
	/** 与同次采集同源的有界上下文投影，完整 text 与 classification 留档。 */
	contextText?: string;
	/** fresh>0 且有派发基线时产出；否则 null（旧任务无基线/非 git → full 明确不可用，不臆造）。 */
	classification: EvidenceClassificationSnapshot | null;
}

/** legacy 摘要状态段（AMAGI_EVIDENCE_VIEW=legacy 回滚）：与 01ef8c 改动前逐字一致。 */
function renderSummaryStatusLegacy(fresh: string[], cls: FreshAttribution): string {
	const tier = (l: string): "own" | "sib" | "miss" => {
		const rel = porcelainPath(l);
		if (cls.own.has(rel) || cls.multi.has(rel)) return "own"; // multi：本任务优先归因（统计另注多方写入）
		return cls.sibOnly.has(rel) ? "sib" : "miss";
	};
	const shown = fresh.slice(0, SUMMARY_STATUS_MAX_LINES);
	const overflow = fresh.length - shown.length;
	const missAll = fresh.every((l) => tier(l) === "miss");
	const siblingActive = !!cls.scan && cls.scan.siblings.length > 0;
	let block = `• 任务期间新增/变化 ${fresh.length} 处（git status 差集 vs 派发基线）:\n${shown.map((l) => {
		const t = tier(l);
		// ev-20260906-858536 残留②：展示行解码引号路径（⚠ext/↔sib 标注须与真实文件名对得上号）
		return `  ${displayPorcelainLine(l)}${t === "sib" ? "  ↔sib" : t === "miss" ? `  ${EXT_WRITE_WARN}` : ""}`;
	}).join("\n")}${overflow > 0 ? `\n  …另有 ${overflow} 处未列出` : ""}`;
	block += siblingAttributionNote(cls, "\n  ");
	if (cls.multi.size > 0) {
		block += `\n  其中 ${cls.multi.size} 处同时有本任务与同批兄弟写入登记（多方写入，本任务优先归因）`;
	}
	if (missAll) {
		block += `\n  ${EXT_WRITE_WARN}（全部 ${fresh.length} 处均无${siblingActive ? "本任务及同批兄弟" : "本任务"}写入记录——多进程共享工作树时更可能是外部进程写入，回滚/归责前务必逐项核实）`;
	}
	return block;
}

/** compact 摘要状态段：own/multi 行优先可见（multi 保留多方写入标记），窗口候选次之标「窗口内未归因」；
 *  sibling-only 与窗口外折成计数——可见清单不再被大批 ⚠ext 行挤掉；总数与各档数量保留。 */
function renderSummaryStatusCompact(fresh: string[], t: FreshTiers, sharedTree = false): string {
	const c = { own: t.own.length, multi: t.multi.length, window: t.window.length, sib: t.sib.length, ext: t.ext.length };
	const rows: Array<{ line: string; mark: string }> = [];
	for (const l of fresh) {
		if (rows.length >= SUMMARY_STATUS_MAX_LINES) break;
		const rel = porcelainPath(l);
		if (t.cls.own.has(rel)) rows.push({ line: l, mark: "" });
		else if (t.cls.multi.has(rel)) rows.push({ line: l, mark: `  ↔multi(${(t.cls.multi.get(rel) ?? []).join("·")})` });
	}
	for (const l of fresh) {
		if (rows.length >= SUMMARY_STATUS_MAX_LINES) break;
		const rel = porcelainPath(l);
		if (t.exempt.has(rel)) rows.push({ line: l, mark: "  窗口内未归因（弱断言）" });
	}
	const overflow = fresh.length - rows.length;
	const segs = tierCountSegments(c);
	let block = `• 任务期间新增/变化 ${fresh.length} 处（git status 差集 vs 派发基线${segs ? `；${segs}` : ""}):\n${rows.map(({ line, mark }) => `  ${displayPorcelainLine(line)}${mark}`).join("\n")}${overflow > 0 ? `\n  …另有 ${overflow} 处未列出` : ""}`;
	const folded: string[] = [];
	if (c.sib > 0) folded.push(`↔sib（仅兄弟登记）${c.sib} 处折叠为计数`);
	if (c.ext > 0) folded.push(extFoldNote(c.ext, sharedTree));
	if (folded.length > 0) block += `\n  （${folded.join("；")}）`;
	const sibNote = siblingAttributionNote(t.cls, "\n  ");
	if (sibNote) block += sibNote;
	if (c.multi > 0) block += `\n  其中 ${c.multi} 处同时有本任务与同批兄弟写入登记（多方写入，本任务优先归因）`;
	return block;
}

// ── ev-20261019-a7519f：任务净变化计算与呈现（快照基准，existing 共享树主口径）────────
// 差集口径的两个盲区由本段补齐：①「派发前已改动路径被任务再次修改」行级差集不可见（状态行
// 不变）；②写日志缺失（bash heredoc 写报告/只读审查任务）时回退全树统计。净变化 = 启动快照
// （内容级）与结算态的逐路径比对——对 bash 写入同样生效；无法归责的呈现为「声明写面 vs 实测
// 命中」对账，不再退化为全树统计。快照缺失/仓库根漂移 → null 回退既有行级差集口径（零变化）。

/** 净变化计算结果（相对仓库根的单侧路径；rename 已拆侧）。 */
interface TaskNetChanges {
	added: string[];
	modified: string[];
	deleted: string[];
	/** 修改档中「现与 HEAD 一致」（任务期间被改回）的路径集。 */
	nowClean: Set<string>;
	/** 快照内任务期间未再变化的基线脏路径数（不计入净变化）。 */
	baselineUnchanged: number;
	truncated: boolean;
	cap: number;
	snapshotAt: number;
}

/**
 * 任务净变化计算：启动快照条目逐个内容级比对（sha1 优先，回退 mtime+size），叠加行级 fresh
 * （派发时干净/不存在的路径——起点态 == HEAD，porcelain 现态即净变化，与快照条目物理去重）。
 * rename 旧侧计删除、新侧计新增/修改；现与 HEAD 一致（porcelain 行已消失但内容变过）计入修改
 * 并标 nowClean。仓库根与快照不一致（跨树/搬仓）→ null（不跨树比较）。
 */
function computeTaskNetChanges(cwd: string, snapshot: TaskStartStateSnapshot, baselinePorcelain: string[], currentLines: string[], timeoutMs: number): TaskNetChanges | null {
	const rootReal = repoRootReal(cwd, timeoutMs);
	if (rootReal === null || rootReal !== snapshot.repoRoot) return null;
	const baselineSet = new Set(baselinePorcelain);
	const fresh = currentLines.filter((l) => !baselineSet.has(l));
	const currentSides = new Set<string>();
	for (const l of currentLines) for (const s of porcelainPath(l).split(" -> ").filter(Boolean)) currentSides.add(s);
	const snapAbs = new Set(snapshot.entries.map((e) => e.file));
	const added: string[] = [], modified: string[] = [], deleted: string[] = [];
	const nowClean = new Set<string>();
	let unchanged = 0;
	for (const e of snapshot.entries) {
		const rel = path.relative(snapshot.repoRoot, e.file);
		if (rel === "" || rel === ".." || rel.startsWith(`..${path.sep}`) || path.isAbsolute(rel)) { unchanged++; continue; } // 仓库外（防御）
		const st = lstatSafe(e.file);
		if (st === null) {
			if (e.mtimeMs >= 0) deleted.push(rel); else unchanged++; // 派发时即不存在且仍不存在
			continue;
		}
		if (e.mtimeMs < 0) { added.push(rel); continue; } // 派发时不存在，现在出现
		let changed: boolean;
		if (e.sha1 !== undefined && st.isFile() && st.size === e.size && st.size <= TASK_START_STATE_HASH_FILE_CAP) {
			const h = sha1OfFile(e.file, TASK_START_STATE_HASH_FILE_CAP);
			changed = h === null ? (st.mtimeMs !== e.mtimeMs || st.size !== e.size) : h !== e.sha1;
		} else {
			changed = st.mtimeMs !== e.mtimeMs || st.size !== e.size;
		}
		if (!changed) { unchanged++; continue; }
		modified.push(rel);
		if (!currentSides.has(rel)) nowClean.add(rel); // 现与 HEAD 一致（任务期间被改回）
	}
	for (const l of fresh) {
		const sides = porcelainPath(l).split(" -> ").filter(Boolean);
		for (let i = 0; i < sides.length; i++) {
			const side = sides[i];
			if (snapAbs.has(physicalPathDeep(path.join(rootReal, side)))) continue; // 快照已判定（内容级优先）
			if (sides.length === 2 && i === 0) { deleted.push(side); continue; } // rename 旧侧
			if (l.startsWith("??")) { added.push(side); continue; }
			const y = l[1] ?? " ";
			(y === "D" ? deleted : modified).push(side);
		}
	}
	const dedupe = (arr: string[]): string[] => [...new Set(arr)].sort();
	return { added: dedupe(added), modified: dedupe(modified), deleted: dedupe(deleted), nowClean, baselineUnchanged: unchanged, truncated: snapshot.truncated, cap: snapshot.cap, snapshotAt: snapshot.collectedAt };
}

/** 净变化路径归因标注（classifyFreshPaths 四档 + §5#6 窗口豁免共用；单侧路径无 rename 拆分）。 */
function netChangeLabelOf(rel: string, cls: FreshAttribution, exempt: ReadonlySet<string>): string {
	if (cls.own.has(rel)) return ""; // 登记命中
	const multi = cls.multi.get(rel);
	if (multi) return `↔multi(${multi.join("·")})`;
	const sib = cls.sibOnly.get(rel);
	if (sib) return `↔sib(${sib.join("·")})`;
	return exempt.has(rel) ? "未登记·窗口内" : "未登记·⚠ext";
}

/** 声明写面 vs 实测命中对账（无法归责的部分如实列出，不退化为全树统计）。 */
interface NetFaceReconciliation {
	registeredTotal: number;
	inRepo: number;
	outOfRepo: number;
	/** 命中净变化的登记数（仓库内登记 ∩ 实测净变化）。 */
	hit: number;
	/** 仓库内登记但未见于净变化（内容未变/被 git 忽略不可见）：仓库根相对路径，≤展示上限。 */
	missIn: string[];
	missInOverflow: number;
	/** 仓库外登记（git 快照口径不可见，如报告目录）：绝对路径，≤展示上限。 */
	outOfRepoList: string[];
	outOfRepoOverflow: number;
}

const NET_FACE_LIST_MAX = 5;

function netFaceReconciliation(rootReal: string, face: SummaryWriteFace | null, measuredAbs: ReadonlySet<string>): NetFaceReconciliation | null {
	if (face === null) return null;
	const missIn: string[] = [];
	const outOfRepoList: string[] = [];
	let inRepo = 0, hit = 0;
	for (const p of face.recorded) {
		const rel = path.relative(rootReal, p);
		const inside = rel !== "" && rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel);
		if (!inside) { outOfRepoList.push(p); continue; }
		inRepo++;
		if (measuredAbs.has(p)) hit++;
		else missIn.push(rel);
	}
	missIn.sort(); outOfRepoList.sort();
	return {
		registeredTotal: face.recorded.size, inRepo, outOfRepo: outOfRepoList.length, hit,
		missIn: missIn.slice(0, NET_FACE_LIST_MAX), missInOverflow: Math.max(0, missIn.length - NET_FACE_LIST_MAX),
		outOfRepoList: outOfRepoList.slice(0, NET_FACE_LIST_MAX), outOfRepoOverflow: Math.max(0, outOfRepoList.length - NET_FACE_LIST_MAX),
	};
}

/** 净变化段每档内展示路径上限（有界呈现；超出折计数）。 */
const NET_LIST_MAX = 6;

function renderNetList(title: string, paths: string[], labels: ReadonlyMap<string, string>, nowClean?: ReadonlySet<string>): string | null {
	if (paths.length === 0) return null;
	const shown = paths.slice(0, NET_LIST_MAX).map((p) => {
		const label = labels.get(p);
		const clean = nowClean?.has(p) ? "现与 HEAD 一致——任务期间被改回" : "";
		const mark = label && clean ? `（${label}；${clean}）` : label ? `（${label}）` : clean ? `（${clean}）` : "";
		return `${compactAutomaticText(p, 160, 1)}${mark}`;
	});
	const overflow = paths.length - shown.length;
	return `  ${title}: ${shown.join("、")}${overflow > 0 ? ` …另有 ${overflow} 处` : ""}`;
}

// ── ev-20261105-52d40b：净变化头条归因分账（D37-03 修复轮三态版）──────────────────
// 实战根因：共享树上的只读子任务（scope 无 write，仅 reportFiles 写报告）结算时，并行工作线的
// 改动（baize 2a090cf4：修改 19 处）全部以「未登记·窗口内」计入头条「任务净变化」，Leader 误以为
// 只读任务写了源码。结构性修法（diting D37-03 修正后口径）：
//   - own（写证据命中）：写入登记 readTaskWrites ∪ registry 工具事件轨迹 lastWritePaths（porcelain
//     目录折叠双向含容）命中的路径——头条只计这一档（写证据口径的本任务产出下界）；
//   - 未归因：无本任务写证据的变化——**不得**推断为「非本任务」（node -e/脚本写文件等常规写法
//     不在写目标静态解析覆盖内，证据缺失≠他者写入）；单列中性醒目行「未归因变化 N 处（本任务
//     无写入记录：可能来自并行写者，或本任务未被登记的写法……；归责前核实）」+ 路径抽样；
//   - 已证实他者：仅当有兄弟任务登记等正面证据（沿用既有 ↔sib 口径）；
//   - 「更可能来自并行写者」提示只依据**可信冻结任务语义**（内核冻结 spec.permission 授权写面
//     为空、仅 reportFiles），不依据「解析器未命中」——措辞为可能性而非结论。

/** 本任务写证据收集：写入登记（readTaskWrites，子进程工具/bash 写目标落账）∪ registry 工具事件
 *  轨迹（lastWritePaths，滚动 ≤8——登记 jsonl 缺失时仍可归因的兜底网）。深归一绝对路径集。 */
function collectOwnWriteEvidence(taskId: string | undefined): Set<string> {
	const files = new Set<string>();
	if (!taskId) return files;
	for (const r of readTaskWrites(taskId)) files.add(physicalPathDeep(r.file));
	try { for (const p of registry.get(taskId)?.lastWritePaths ?? []) files.add(physicalPathDeep(p)); } catch { /* lint-exempt:registry 不可读按无轨迹（弱断言证据宁缺不猜） */ }
	return files;
}

/** 可信冻结只读语义（D37-03）：内核冻结 spec.permission（register 后不可变，与 store 回读等价）
 *  授权写面为空（仅 reportFiles 报告通道）→ true；有写面 false；legacy 占位/内核未持有/跨会话
 *  不可见 → undefined（不提示——证据缺失不得推断只读身份）。 */
function frozenWriteFaceEmpty(taskId: string | undefined): boolean | undefined {
	if (!taskId) return undefined;
	try {
		const grant = peekTaskKernel()?.frozenPermissionOf(taskId);
		return grant === undefined ? undefined : grant.write.length === 0;
	} catch { /* lint-exempt:内核不可读=无冻结语义，不提示 */ return undefined; }
}

/** 净变化三档 × 归因三态的分桶结构。 */
interface NetAttributionSplit {
	/** 写证据命中（本任务产出下界）。 */
	own: { added: string[]; modified: string[]; deleted: string[] };
	/** 未归因（无本任务写证据——不作「非本任务」结论）。 */
	unattributed: { added: string[]; modified: string[]; deleted: string[] };
	/** 已证实他者（仅兄弟任务登记命中等正面证据）。 */
	sib: { added: string[]; modified: string[]; deleted: string[] };
}

function splitNetByAttribution(net: TaskNetChanges, cls: FreshAttribution, isAttributable: (p: string) => boolean): NetAttributionSplit {
	const pick = (arr: string[], bucket: (p: string) => boolean): string[] => arr.filter(bucket);
	const isOwn = (p: string) => isAttributable(p);
	// 三档互斥分区（增量复审 D37-05）：own 优先——写证据命中即计 own，sib 只收非 own 的兄弟专属命中，
	// 双方命中由标签注记 multi 只计一次；三档之和恒等于净变化总数。
	const isSib = (p: string) => !isOwn(p) && cls.sibOnly.has(p);
	const isUnattributed = (p: string) => !isOwn(p) && !cls.sibOnly.has(p);
	return {
		own: { added: pick(net.added, isOwn), modified: pick(net.modified, isOwn), deleted: pick(net.deleted, isOwn) },
		unattributed: { added: pick(net.added, isUnattributed), modified: pick(net.modified, isUnattributed), deleted: pick(net.deleted, isUnattributed) },
		sib: { added: pick(net.added, isSib), modified: pick(net.modified, isSib), deleted: pick(net.deleted, isSib) },
	};
}

/** 净变化段（产物摘要正文版；替代行级差集段——快照基准存在时）。
 *  ev-20261105-52d40b（D37-03 三态）：头条=写证据命中计数 + 未归因/↔sib 计数分列；未归因单列
 *  中性醒目行（不丢可见性、不作「非本任务」结论）。 */
function renderNetChangeSection(net: TaskNetChanges, split: NetAttributionSplit, labels: ReadonlyMap<string, string>, baselineCount: number, faceRec: NetFaceReconciliation | null, readOnlyGrant: boolean | undefined): string {
	const trunc = net.truncated ? `；快照截断（基线脏路径超 ${net.cap}）：超界路径净变化不可判，仍按行级差集` : "";
	const base = `• 任务净变化 vs 任务启动快照（派发前已改动 ${baselineCount} 处已入基准，不计入本段；基准 mtime+size+小文件 sha1${trunc}）`;
	const counts = (b: { added: string[]; modified: string[]; deleted: string[] }): string => `新增 ${b.added.length} · 修改 ${b.modified.length} · 删除 ${b.deleted.length}`;
	const ownTotal = split.own.added.length + split.own.modified.length + split.own.deleted.length;
	const unatTotal = split.unattributed.added.length + split.unattributed.modified.length + split.unattributed.deleted.length;
	const sibTotal = split.sib.added.length + split.sib.modified.length + split.sib.deleted.length;
	// 未归因/↔sib 均为 0 时保持旧文案逐字不变（既有消费者/测试口径零扰动）；有分账才切换措辞
	const head = (unatTotal + sibTotal) > 0
		? `${base}：本任务（写证据命中）${counts(split.own)}；另有未归因 ${unatTotal} 处${sibTotal > 0 ? ` + 已证实兄弟写入（↔sib）${sibTotal} 处` : ""}（见下行）`
		: `${base}：${ownTotal > 0 ? counts(split.own) : "0 处（新增 0 · 修改 0 · 删除 0）——本任务期间无净变化"}`;
	const lines = [head];
	const a = renderNetList("新增", split.own.added, labels);
	const m = renderNetList("修改", split.own.modified, labels, net.nowClean);
	const d = renderNetList("删除", split.own.deleted, labels);
	for (const seg of [a, m, d]) if (seg) lines.push(seg);
	if (unatTotal > 0) {
		// 中性醒目行：可能性提示只依据可信冻结只读语义（授权写面为空），措辞为「更可能」非结论
		const readOnlyNote = readOnlyGrant === true ? "；本任务授权写面为空（仅 reportFiles）——更可能来自并行写者" : "";
		lines.push(`  未归因变化 ${unatTotal} 处（本任务无写入记录：可能来自并行写者，或本任务未被登记的写法如 node -e/脚本写文件；归责前核实${readOnlyNote}）：${counts(split.unattributed)}`);
		for (const seg of [
			renderNetList("未归因·新增", split.unattributed.added, labels),
			renderNetList("未归因·修改", split.unattributed.modified, labels, net.nowClean),
			renderNetList("未归因·删除", split.unattributed.deleted, labels),
		]) if (seg) lines.push(seg);
	}
	if (sibTotal > 0) {
		lines.push(`  已证实他者（↔sib，兄弟任务登记命中——正面证据，非推断）${sibTotal} 处：${counts(split.sib)}`);
		for (const seg of [
			renderNetList("↔sib·新增", split.sib.added, labels),
			renderNetList("↔sib·修改", split.sib.modified, labels, net.nowClean),
			renderNetList("↔sib·删除", split.sib.deleted, labels),
		]) if (seg) lines.push(seg);
	}
	if (faceRec) {
		const missShown = faceRec.missIn.map((p) => compactAutomaticText(p, 160, 1)).join("、") + (faceRec.missInOverflow > 0 ? ` …另 ${faceRec.missInOverflow} 处` : "");
		const outShown = faceRec.outOfRepoList.map((p) => compactAutomaticText(p, 160, 1)).join("、") + (faceRec.outOfRepoOverflow > 0 ? ` …另 ${faceRec.outOfRepoOverflow} 处` : "");
		lines.push(`  声明写面 vs 实测命中：登记 ${faceRec.registeredTotal} 处（仓库内 ${faceRec.inRepo} · 仓库外 ${faceRec.outOfRepo}）→ 命中净变化 ${faceRec.hit}${faceRec.missIn.length > 0 || faceRec.missInOverflow > 0 ? `；未命中 ${faceRec.inRepo - faceRec.hit}（内容未变或被 git 忽略不可见：${missShown}）` : ""}${faceRec.outOfRepoList.length > 0 || faceRec.outOfRepoOverflow > 0 ? `；仓库外登记（git 快照口径不可见）：${outShown}` : ""}`);
	}
	return lines.join("\n");
}

export function collectArtifactDiffSummary(cwd: string, baselinePorcelain: string[] | null | undefined, taskId?: string, opts?: ArtifactDiffSummaryOpts): ArtifactDiffSummaryResult {
	const summaryGitMs = opts?.summaryGitMs ?? DEFAULT_EVIDENCE_SUMMARY_GIT_TIMEOUT_MS;
	const view = opts?.view ?? resolveEvidenceView();
	const sharedTree = opts?.sharedTree === true;
	const currentRaw = gitQuiet(["--no-pager", "status", "--porcelain"], cwd, summaryGitMs);
	if (currentRaw === null) return { text: null, classification: null }; // 非 git 仓库/超时/失败：静默省略整块
	const baselineNote = gitPathBaselineNote(cwd, summaryGitMs);
	const currentLines = currentRaw.split("\n").map((l) => l.replace(/\r$/, "")).filter(Boolean);
	const parts: string[] = [];
	const contextParts: string[] = [];
	let classification: EvidenceClassificationSnapshot | null = null;
	// ev-20261019-a7519f：任务启动快照（内容级基准，task-run 派发点采集落 sidecar）。派发前已有脏
	// 路径时净变化段替代行级差集段（行级差集对「预脏路径被任务再修改」不敏感）；快照缺失/条目为空
	//（干净树/worktree 模式）→ net=null，既有呈现零变化。
	// ev-20261111-fix（diting F06）：整链时间基准统一——sidecar 首写优先保留首轮 entries **与首轮
	// porcelain 起点**；后续轮（resume/修复）的 RunResult.gitBaseline 含前轮新增产物，若仍按次轮
	// porcelain 算 fresh/净变化，首轮新建文件会被次轮基线吞掉（「无净变化」假阴性，与未跟踪段
	// 自相矛盾）。首轮 porcelain 在场时以它为整链差集基准；缺席（旧 sidecar/超界未存）回退次轮口径。
	const rootReal = repoRootReal(cwd, summaryGitMs);
	const startState = taskId ? readTaskStartState(taskId) : null;
	const chainBaseline = startState?.baselinePorcelain;
	const effectiveBaseline = chainBaseline ?? baselinePorcelain;
	const snapshotBasis = startState !== null && startState.entries.length > 0 && Array.isArray(effectiveBaseline) ? startState : null;
	let net: TaskNetChanges | null = null;
	if (snapshotBasis !== null) {
		try { net = computeTaskNetChanges(cwd, snapshotBasis, effectiveBaseline as string[], currentLines, summaryGitMs); } catch { net = null; /* lint-exempt:快照异常回退差集口径，不阻摘要 */ }
	}
	const baselineCount = Array.isArray(effectiveBaseline) ? new Set([...effectiveBaseline].map(porcelainPath)).size : 0;
	// ev-20260923-d7be81（E2）：写面口径（提前计算——净变化段的「声明写面 vs 实测命中」对账输入）。
	const faceRaw = taskId ? resolveSummaryWriteFace(taskId, rootReal) : null;
	// M3：回退原因分叉（no-log/no-root）；face 保持 SummaryWriteFace | null——回退形态统一并入 null 口径，后续引用零改动
	const face = faceRaw !== null && !("fallbackReason" in faceRaw) ? faceRaw : null;
	const faceFallback = faceRaw !== null && "fallbackReason" in faceRaw ? faceRaw.fallbackReason : (taskId ? null : "no-log" as const);
	if (Array.isArray(effectiveBaseline)) {
		const baseSet = new Set(effectiveBaseline);
		const fresh = currentLines.filter((l) => !baseSet.has(l));
		const freshPaths = [...new Set(fresh.map(porcelainPath))];
		let cls: FreshAttribution | null = null;
		let exempt = new Set<string>();
		let tiers: FreshTiers | null = null;
		if (freshPaths.length > 0) {
			// ev-20260907-e20971：与 attributionLine 同一 classify（完成通知与证据块两输出口径一致）
			cls = classifyFreshPaths(taskId, cwd, freshPaths, taskId ? collectSiblingWrites(taskId) : null, summaryGitMs);
			// S5/01ef8c：compact 的窗口候选 = §5#6 豁免拆分（算法/窗口不变，只做呈现拆桶）；
			// 结构化快照一并产出（保存后 full 展开不再重扫工作树）
			exempt = taskId ? windowCwdExemption(taskId, cls.unattributed, cwd, summaryGitMs) : new Set<string>();
			tiers = freshTiersOf(cls, exempt, freshPaths.length, baselineCount);
			classification = buildClassificationSnapshot(cwd, tiers);
		}
		if (net !== null) {
			// ev-20261019-a7519f：净变化段（快照基准）替代行级差集段——数字是本任务净增量，
			// 不再含派发前已有改动；无法归责部分以「声明写面 vs 实测命中」对账呈现。
			// ev-20261105-52d40b（D37-03 三态）：头条只统计本任务写证据（登记∪工具事件轨迹，目录
			// 折叠双向含容）命中；未归因变化单列中性醒目行（不作「非本任务」结论）；↔sib 沿用既有
			// 兄弟登记口径；「更可能来自并行写者」提示只依据内核冻结授权写面为空的可信语义。
			const netAll = [...new Set([...net.added, ...net.modified, ...net.deleted])];
			const netCls = classifyFreshPaths(taskId, cwd, netAll, taskId ? collectSiblingWrites(taskId) : null, summaryGitMs);
			const netExempt = taskId ? windowCwdExemption(taskId, netCls.unattributed, cwd, summaryGitMs) : new Set<string>();
			const ownEvidence = collectOwnWriteEvidence(taskId);
			const isAttributable = (p: string): boolean => netCls.own.has(p) || netCls.multi.has(p)
				|| (rootReal !== null && ownWriteFaceContains(ownEvidence, rootReal, p));
			const labels = new Map(netAll.map((p) => [p, netChangeLabelOf(p, netCls, netExempt)]));
			for (const p of netAll) {
				const label = labels.get(p) ?? "";
				if (!isAttributable(p)) continue;
				if (label.startsWith("未登记")) labels.set(p, ""); // 写证据命中（含容/轨迹兜底）→ 登记命中口径
				else if (label.startsWith("↔sib")) labels.set(p, label.replace("↔sib", "↔multi")); // 双方写入（本任务轨迹兜底命中）
			}
			const netSplit = splitNetByAttribution(net, netCls, isAttributable);
			const measuredAbs = new Set(netAll.map((p) => physicalPathDeep(path.join(rootReal ?? cwd, p))));
			const faceRec = rootReal !== null ? netFaceReconciliation(rootReal, face, measuredAbs) : null;
			const readOnlyGrant = frozenWriteFaceEmpty(taskId);
			parts.push(renderNetChangeSection(net, netSplit, labels, baselineCount, faceRec, readOnlyGrant));
			const ownHit = netCls.own.size + netCls.multi.size;
			const windowCount = netCls.unattributed.filter((p) => netExempt.has(p)).length;
			const sibCount = netCls.sibOnly.size;
			const extCount = netCls.unattributed.length - windowCount;
			const unatTotal = netSplit.unattributed.added.length + netSplit.unattributed.modified.length + netSplit.unattributed.deleted.length;
			const sibTotal = netSplit.sib.added.length + netSplit.sib.modified.length + netSplit.sib.deleted.length;
			// D37-03：context 面同口径分账——未归因中性表述，可能性提示只依据可信冻结只读语义
			const readOnlyNote = readOnlyGrant === true ? "；本任务授权写面为空（仅 reportFiles）——更可能来自并行写者" : "";
			const unatSeg = unatTotal > 0 ? `；未归因 新增 ${netSplit.unattributed.added.length} · 修改 ${netSplit.unattributed.modified.length} · 删除 ${netSplit.unattributed.deleted.length}（本任务无写入记录：可能来自并行写者，或本任务未被登记的写法；归责前核实${readOnlyNote}）` : "";
			const sibSeg = sibTotal > 0 ? `；↔sib 已证实兄弟写入 新增 ${netSplit.sib.added.length} · 修改 ${netSplit.sib.modified.length} · 删除 ${netSplit.sib.deleted.length}` : "";
			contextParts.push(`• 净变化（vs 任务启动快照）：本任务（写证据命中）新增 ${netSplit.own.added.length} · 修改 ${netSplit.own.modified.length} · 删除 ${netSplit.own.deleted.length}${unatSeg}${sibSeg}；登记命中 ${ownHit}，窗口内未归因 ${windowCount}，↔sib ${sibCount}，⚠ext ${extCount}${net.nowClean.size > 0 ? `（其中 ${net.nowClean.size} 处现与 HEAD 一致）` : ""}`);
			if (faceRec) contextParts.push(`  声明写面 vs 实测：登记 ${faceRec.registeredTotal} 处（仓库内 ${faceRec.inRepo} · 仓库外 ${faceRec.outOfRepo}）→ 命中 ${faceRec.hit}；未命中 ${faceRec.inRepo - faceRec.hit}（内容未变或被 git 忽略不可见）`);
			if (windowCount + sibCount + extCount > 0) contextParts.push("  未归因/仅兄弟登记的变化不能视为本任务独立产出。");
			contextParts.push(`  基线已有 ${baselineCount} 处未提交改动（已入启动快照基准，不计入净变化）；diff 段仍为 vs HEAD 口径。`);
			if (classification) classification.net = { added: net.added.length, modified: net.modified.length, deleted: net.deleted.length, baselineUnchanged: net.baselineUnchanged, truncated: net.truncated, ...((unatTotal + sibTotal) > 0 ? { attribution: { own: { added: netSplit.own.added.length, modified: netSplit.own.modified.length, deleted: netSplit.own.deleted.length }, unattributed: { added: netSplit.unattributed.added.length, modified: netSplit.unattributed.modified.length, deleted: netSplit.unattributed.deleted.length }, sib: { added: netSplit.sib.added.length, modified: netSplit.sib.modified.length, deleted: netSplit.sib.deleted.length }, ...(readOnlyGrant !== undefined ? { readOnlyGrant } : {}) } } : {}) };
		} else if (tiers !== null && cls !== null) {
			parts.push(view === "compact" ? renderSummaryStatusCompact(fresh, tiers, sharedTree) : renderSummaryStatusLegacy(fresh, cls));
			const c = classification!.counts;
			contextParts.push(`• 归因：任务期间新增/变化 ${classification!.freshTotal} 处；own ${c.own}，multi ${c.multi}，窗口内未归因 ${c.window}，↔sib ${c.sib}，⚠ext ${c.ext}`);
			const ownPaths = [...tiers.own, ...tiers.multi.map((m) => `${m.path}（多方写入）`)];
			if (ownPaths.length > 0) contextParts.push(`  登记路径：${ownPaths.slice(0, 5).map((p) => compactAutomaticText(p, 160, 1)).join("、")}${ownPaths.length > 5 ? ` …另 ${ownPaths.length - 5} 处` : ""}`);
			if (c.window + c.sib + c.ext > 0) contextParts.push("  未归因/仅兄弟登记的变化不能视为本任务独立产出。");
			if (tiers.baselineCount > 0) contextParts.push(`  基线已有 ${tiers.baselineCount} 处未提交改动；diff 数字含既有改动。`);
		}
	}
	// ev-20260923-d7be81（E2）：diff --stat 段改任务写面口径——以 task-write-log 登记的本任务
	// 写入路径集为 pathspec，共享树并行/兄弟改动不再混入产物摘要（advisory 输入即摘要，从根上
	// 消除「疑似范围外产物」误报）。写日志缺失（无 taskId/无登记/仓库根解析失败）→ 回退 P0 子树
	// 限幅形态（`-- .`）并显式标注口径；状态差集与归因行仍全仓口径（另一条链路，B0 已用）。
	// ev-20261019-a7519f：净变化段在场时尾注指向净增量，不再让 vs HEAD 数字被误读为本任务产出。
	const netRef = net !== null ? "；净增量见「任务净变化」段" : "";
	let statRaw: string | null;
	if (face === null) {
		statRaw = gitQuiet(["--no-pager", "diff", "--stat", "HEAD", "--", "."], cwd, summaryGitMs);
	} else if (face.specs.length === 0) {
		statRaw = ""; // 写面登记均不在本仓库内（如报告目录）——写面内无 tracked 改动
	} else {
		statRaw = gitQuiet(["--no-pager", "diff", "--stat", "HEAD", "--", ...face.specs], cwd, summaryGitMs);
	}
	if (statRaw !== null) {
		const statLines = statRaw.split("\n").map((l) => l.trimEnd()).filter(Boolean);
		contextParts.push(`• diff（${face !== null ? `任务写面登记 ${face.specs.length} 处，登记覆盖有限${face.truncNote}；相对 HEAD${net !== null ? "（含派发前已有改动），净增量见净变化段" : "，非本次净增量"}` : `共享树全量口径，无法独立归责${netRef}`}）：${statLines.at(-1)?.trim() || "无 tracked 改动"}`);
		if (statLines.length > 0) {
			const tail = statLines.slice(-SUMMARY_STAT_TAIL);
			const omitted = statLines.length - tail.length;
			const scope = face !== null
				? `git -C ${cwd} --no-pager diff --stat HEAD -- <本任务写面登记 ${face.specs.length} 处>${face.truncNote}；任务写面口径（登记覆盖有限：bash 复杂写法不入登记，未登记改动见归因段），共享树并行改动不计入${netRef}`
				: faceFallback === "no-root"
					? `git -C ${cwd} --no-pager diff --stat HEAD -- .；共享树全量口径——仓库根解析失败（无法构造写面 pathspec）${netRef}`
					: `git -C ${cwd} --no-pager diff --stat HEAD -- .；共享树全量口径——本任务写日志缺失${netRef}`;
			parts.push(`• git diff --stat 尾部（${scope}）:\n${tail.map((l) => `  ${l}`).join("\n")}${omitted > 0 ? `\n  …（前 ${omitted} 行省略）` : ""}`);
		} else if (face !== null) {
			// 写面口径下无 tracked 改动（如本任务只新建未跟踪文件/写面均在本仓库外）：明示口径结果，
			// 与「git 采集失败静默省略」可区分
			parts.push(`• git diff --stat（任务写面口径${face.truncNote}）→ 本任务写面内无 tracked 改动`);
		}
	}
	if (statRaw === null) contextParts.push("• diff → 采集不可用（未取得统计，详情见路径/归因记录）");
	// ev-20260906-50a3e6：未跟踪新文件独立段（?? 条目 + 行数；不混入上方 tracked diff）
	// ev-20260923-d7be81（E2）：同样按写面过滤（face=null 时回退全量并标注口径）
	try {
		const untracked = untrackedSection(cwd, currentLines, summaryGitMs, face);
		if (untracked) parts.push(untracked);
		if (untracked) contextParts.push(compactAutomaticText(untracked.split("\n")[0], 384, 1));
	} catch { /* 未跟踪段失败静默：不影响摘要块其余部分 */ }
	if (parts.length === 0) return { text: null, classification };
	return { text: `${ARTIFACT_SUMMARY_LABEL}${baselineNote ? `\n${baselineNote}` : ""}\n${parts.join("\n")}`, classification,
		contextText: `${ARTIFACT_SUMMARY_LABEL}\n${baselineNote ? compactAutomaticText(baselineNote, 384, 1) + "\n" : ""}${contextParts.join("\n")}` };
}

/** 兼容包装：仅取文本（既有调用方口径零变化；需要结构化快照用 collectArtifactDiffSummary）。 */
export function buildArtifactDiffSummary(cwd: string, baselinePorcelain: string[] | null | undefined, taskId?: string, opts?: ArtifactDiffSummaryOpts): string | null {
	return collectArtifactDiffSummary(cwd, baselinePorcelain, taskId, opts).text;
}

export interface FreshAttributionCounts {
	/** 任务期间新增/变化路径总数（fresh 差集去重）。 */
	fresh: number;
	/** 命中本任务写入登记（含 multi 多方写入——本任务优先归因，与摘要块 tier 口径一致）。 */
	own: number;
	/** 仅命中同批兄弟写入证据（↔sib）。 */
	sib: number;
	/** 无任何登记（⚠ext 外部写入嫌疑）。 */
	ext: number;
}

/**
 * ev-20260910-8fbe4e（C）：中断现场报告的差集归因档位计数——fresh 差集 → own/↔sib/⚠ext 计数，
 * 与 buildArtifactDiffSummary/attributionLine 共用 classifyFreshPaths（三输出口径一致）。
 * baseline 缺省（非数组，如迟终态回推重建场景无 spawn 前快照）或 git 不可用 → null（调用方省略
 * 归因段，不猜测）；fresh 为空返回全零计数（如实呈现「任务期间无新增/变化」）。
 */
export function freshAttributionCounts(cwd: string, baselinePorcelain: string[] | null | undefined, taskId?: string): FreshAttributionCounts | null {
	if (!Array.isArray(baselinePorcelain)) return null;
	const currentRaw = gitQuiet(["--no-pager", "status", "--porcelain"], cwd);
	if (currentRaw === null) return null;
	const currentLines = currentRaw.split("\n").map((l) => l.replace(/\r$/, "")).filter(Boolean);
	const baseSet = new Set(baselinePorcelain);
	const fresh = currentLines.filter((l) => !baseSet.has(l));
	const freshPaths = [...new Set(fresh.map(porcelainPath))];
	if (freshPaths.length === 0) return { fresh: 0, own: 0, sib: 0, ext: 0 };
	const cls = classifyFreshPaths(taskId, cwd, freshPaths, taskId ? collectSiblingWrites(taskId) : null);
	return { fresh: freshPaths.length, own: cls.own.size + cls.multi.size, sib: cls.sibOnly.size, ext: cls.unattributed.length };
}

// ── S5/01ef8c：full 展开接口（S2 query_task evidenceDetail=full 消费；快照来自结束时刻） ──

/** 校验已保存的结构化快照（旧任务无快照/版本不符/形状损坏 → null：明确不可用，不臆造）。 */
export function parseEvidenceClassificationSnapshot(raw: unknown): EvidenceClassificationSnapshot | null {
	if (typeof raw !== "object" || raw === null) return null;
	const r = raw as Record<string, unknown>;
	if (r.formatVersion !== 1) return null;
	const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
	const strArr = (v: unknown): string[] | null => (Array.isArray(v) && v.every((x) => typeof x === "string") ? (v as string[]) : null);
	const labelArr = (v: unknown): Array<{ path: string; labels: string[] }> | null => {
		if (!Array.isArray(v)) return null;
		const out: Array<{ path: string; labels: string[] }> = [];
		for (const e of v) {
			if (typeof e !== "object" || e === null) return null;
			const o = e as Record<string, unknown>;
			if (typeof o.path !== "string" || !Array.isArray(o.labels) || !o.labels.every((x) => typeof x === "string")) return null;
			out.push({ path: o.path, labels: o.labels as string[] });
		}
		return out;
	};
	const counts = r.counts as Record<string, unknown>;
	const own = strArr(r.own), window = strArr(r.window), ext = strArr(r.ext);
	const multi = labelArr(r.multi), sib = labelArr(r.sib);
	const freshTotal = num(r.freshTotal), baselineCount = num(r.baselineCount), collectedAt = num(r.collectedAt);
	const co = num(counts?.own), cm = num(counts?.multi), cw = num(counts?.window), cs = num(counts?.sib), ce = num(counts?.ext);
	if (![own, window, ext, multi, sib, freshTotal, baselineCount, collectedAt, co, cm, cw, cs, ce].every((v) => v !== null)) return null;
	if (typeof r.cwd !== "string" || typeof r.extWarnText !== "string") return null;
	const sibCounts = Array.isArray(r.sibCounts)
		? (r.sibCounts as Array<Record<string, unknown>>).flatMap((e) => (typeof e?.label === "string" && typeof e?.count === "number") ? [{ label: e.label, count: e.count }] : [])
		: [];
	// ev-20261019-a7519f：可选净变化计数（旧快照无此字段；形状不符时忽略不拒收整份快照）
	let net: EvidenceClassificationSnapshot["net"];
	if (typeof r.net === "object" && r.net !== null) {
		const n = r.net as Record<string, unknown>;
		const na = num(n.added), nm = num(n.modified), nd = num(n.deleted), nb = num(n.baselineUnchanged);
		const nAttr = (typeof n.attribution === "object" && n.attribution !== null ? n.attribution : null) as Record<string, unknown> | null;
		const numTrip = (b: unknown): { added: number; modified: number; deleted: number } | null => {
			if (typeof b !== "object" || b === null) return null;
			const o = b as Record<string, unknown>;
			const a = num(o.added), m = num(o.modified), d = num(o.deleted);
			return a === null || m === null || d === null ? null : { added: a, modified: m, deleted: d };
		};
		const attrOwn = nAttr === null ? null : numTrip(nAttr.own);
		const attrUnat = nAttr === null ? null : numTrip(nAttr.unattributed);
		const attrSib = nAttr === null ? null : numTrip(nAttr.sib);
		const attribution = (attrOwn === null || attrUnat === null || attrSib === null) ? undefined : { own: attrOwn, unattributed: attrUnat, sib: attrSib, ...(typeof nAttr!.readOnlyGrant === "boolean" ? { readOnlyGrant: nAttr!.readOnlyGrant as boolean } : {}) };
		net = (na === null || nm === null || nd === null || nb === null) ? undefined : { added: na, modified: nm, deleted: nd, baselineUnchanged: nb, truncated: n.truncated === true, ...(attribution ? { attribution } : {}) };
	} else net = undefined;
	return {
		formatVersion: 1,
		collectedAt: collectedAt as number,
		cwd: r.cwd,
		freshTotal: freshTotal as number,
		baselineCount: baselineCount as number,
		counts: { own: co as number, multi: cm as number, window: cw as number, sib: cs as number, ext: ce as number },
		own: own as string[],
		multi: multi as Array<{ path: string; labels: string[] }>,
		window: window as string[],
		sib: sib as Array<{ path: string; labels: string[] }>,
		ext: ext as string[],
		sibCounts,
		...(typeof r.runId === "string" ? { runId: r.runId } : {}),
		truncated: r.truncated === true,
		extWarnText: r.extWarnText,
		...(net ? { net } : {}),
	};
}

/** full 展开：从**结束快照**还原各档完整清单（结束后工作树改动不改变旧详情；不重扫工作树）。 */
export function renderClassificationFull(s: EvidenceClassificationSnapshot): string {
	const lines: string[] = [];
	lines.push(`[证据归因·full] 结束快照（采集于 ${new Date(s.collectedAt).toISOString()}；此后工作树改动不改变本明细）`);
	lines.push(`任务期间新增/变化 ${s.freshTotal} 处 = own ${s.counts.own} · multi ${s.counts.multi} · 窗口内未归因 ${s.counts.window} · ↔sib ${s.counts.sib} · ⚠ext ${s.counts.ext}${s.baselineCount > 0 ? `；基线已有 ${s.baselineCount} 处未提交改动（非本任务产出）` : ""}${s.runId ? `；runId=${s.runId}` : ""}`);
	// ev-20261019-a7519f：快照基准净变化计数（有启动快照时在场；缺省 = 无快照口径的旧快照）
	if (s.net) lines.push(`任务净变化（vs 任务启动快照）：${s.net.attribution ? `本任务（写证据命中）新增 ${s.net.attribution.own.added} · 修改 ${s.net.attribution.own.modified} · 删除 ${s.net.attribution.own.deleted}；未归因 新增 ${s.net.attribution.unattributed.added} · 修改 ${s.net.attribution.unattributed.modified} · 删除 ${s.net.attribution.unattributed.deleted}（本任务无写入记录：可能来自并行写者，或本任务未被登记的写法；归责前核实${s.net.attribution.readOnlyGrant === true ? "；本任务授权写面为空（仅 reportFiles）——更可能来自并行写者" : ""}）；↔sib 已证实兄弟写入 新增 ${s.net.attribution.sib.added} · 修改 ${s.net.attribution.sib.modified} · 删除 ${s.net.attribution.sib.deleted}（总计 新增 ${s.net.added} · 修改 ${s.net.modified} · 删除 ${s.net.deleted}${s.net.truncated ? "；快照截断，超界路径不可判" : ""}）` : `新增 ${s.net.added} · 修改 ${s.net.modified} · 删除 ${s.net.deleted}${s.net.truncated ? "（快照截断，超界路径不可判）" : ""}`}；基线脏路径未再动 ${s.net.baselineUnchanged}`);
	const section = (title: string, items: string[]): void => {
		if (items.length === 0) return;
		lines.push(`${title}（${items.length}）:`);
		for (const it of items) lines.push(`  ${it}`);
	};
	section("own（本任务登记命中）", s.own);
	section("multi（多方写入，本任务优先归因）", s.multi.map((m) => `${m.path}↔multi(${m.labels.join("·")})`));
	section("窗口内未归因（mtime 在任务运行窗口且 cwd 内，弱断言——不是 own）", s.window);
	section("↔sib（仅同批兄弟登记）", s.sib.map((x) => `${x.path}↔sib(${x.labels.join("·")})`));
	section(`⚠ext（无任何登记；${s.extWarnText}）`, s.ext);
	if (s.sibCounts.length > 0) lines.push(`同批兄弟逐标签计数: ${s.sibCounts.map((x) => `${x.label} ${x.count} 处`).join("、")}`);
	if (s.truncated) lines.push(`（部分档触达 ${EVIDENCE_CLASSIFICATION_LIST_CAP} 条上限已截断——full ≠ 无限扫描，不重扫工作树补归属证据）`);
	return lines.join("\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// v2.3 C1：evidence 隔离快照——测试命令执行环境（判定与生命周期集中封装，勿散开）。
//
// 基线验证的测试命令在 git 快照（worktree.ts createEvidenceSnapshot：临时 index+悬空 commit+
// worktree 检出，依赖目录符号链接）上执行，隔离其他并行任务对共享树的写入干扰；git diff
// 采集/探针等非验证命令不经快照（归因需要共享树口径）。三档失败语义（不猜成功红线）：
//   off             直接在共享树执行（现状零变化）；
//   shared-fallback 快照创建失败 → 回退共享树执行并注记 degraded（回执 degraded[] 有据）；
//   strict          快照创建失败 → 不执行、检查记 unavailable（回执侧如实 incomplete），不静默回退。
// ─────────────────────────────────────────────────────────────────────────────

/** C1：测试命令经隔离快照执行的三档结果（gatherEvidenceReport 消费）。 */
interface SnapshotTestExec {
	/** 命令真实执行结果；null = 未执行（strict 快照创建失败/快照内 bin 预核验失败）。 */
	result: CmdResult | null;
	/** strict 快照创建失败/快照内 bin 预核验失败原因（result=null 时有值；不猜成功，不回退）。 */
	unavailableReason: string | null;
	/** C1（ev-20260922-7d1b10）：unavailable 短码（no-object:<reason>，如 snapshot-bin-missing:<bin>）。 */
	objectRef: string | null;
	/** shared-fallback 回退共享树的 degraded 注记（EvidenceReport.degraded → 回执 degraded[] 数据源）。 */
	degraded: string[];
	/** 隔离/回退事实注记（附到测试 detail 尾部，供验收核对快照事实）。 */
	note: string | null;
	/** ev-20260919：是否真实在隔离快照内执行——供「快照环境依赖缺失≠任务失败」误判豁免。 */
	executedInSnapshot: boolean;
}

/** C1：快照内 verificationRoot 对应目录——快照检出整仓，effCwd（realpath 归一，与 repoRoot
 *  同物理口径）映射为 worktree 内相对路径；解析失败退化 snap.execCwd（旧口径）。 */
function snapshotRootFor(snap: EvidenceSnapshot, effCwd: string): string {
	try {
		const effReal = fs.realpathSync(effCwd);
		const rel = path.relative(snap.repoRoot, effReal);
		if (rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel))) return rel === "" ? snap.worktree : path.join(snap.worktree, rel);
	} catch { /* realpath 失败：退化旧口径 */ }
	return snap.execCwd;
}

/** C1：三档快照执行环境封装（局部唯一入口；快照用完即清理，不留半成品 worktree）。
 *  ev-20260922-7d1b10：测试命令按 TestExecutionPlan 在当前验证根下相对解析——共享树根
 *  （off/回退）与隔离快照 worktree 根共用同一相对计划（cwdRel/binDirsRel）；快照内 bin
 *  预核验失败（快照仅符号链接两级依赖目录，借用链上的子包 .bin 不在场）→ unavailable
 *  报告附计划详情（binDirsRel/缺失 bin 名）——诚实降级，不猜成功；copy-local 依赖捕获在 C2。 */
async function runTestUnderEvidenceSnapshot(detected: DetectedTest, effCwd: string, timeoutMs: number, runCmd: RunCmd, mode: EvidenceSnapshotMode): Promise<SnapshotTestExec> {
	const cmd = detected.cmd;
	const plan = detected.plan;
	const testCwd = plan ? (plan.cwdRel === "." ? effCwd : path.resolve(effCwd, plan.cwdRel)) : (detected.execCwd ?? effCwd);
	// ev-20261111-fix（diting F04）：受信验证根 pathPrepend 随执行传递——子目录执行不丢根配置
	//（声明 cwd 在子目录时不再从子目录重读 amagi.json；不无界向上搜索）。
	const trustedPrepend = readProjectShellPathPrepend(effCwd).dirs;
	const ctxOf = (binDirs: string[]): RunCmdContext | undefined => {
		const ctx: RunCmdContext = {};
		if (binDirs.length > 0) ctx.binDirs = binDirs;
		if (trustedPrepend.length > 0) ctx.pathPrepend = trustedPrepend;
		if (detected.env) ctx.envExtra = { ...detected.env }; // ev-20261021-54b4e3：声明的资源环境到达实际执行
		return Object.keys(ctx).length > 0 ? ctx : undefined;
	};
	if (mode === "off") {
		// 共享树：计划相对字段以 effCwd 为根重放（bin 链 PATH 前置；只该次 spawn 生效）
		const shared = plan ? resolvePlanInRoot(plan, effCwd) : null;
		return { result: await runCmd(cmd, testCwd, timeoutMs, ctxOf(shared?.binDirs ?? [])), unavailableReason: null, objectRef: null, degraded: [], note: null, executedInSnapshot: false };
	}
	const attempt = createEvidenceSnapshot(effCwd, testCwd);
	if (!attempt.ok) {
		if (mode === "strict") {
			return {
				result: null,
				unavailableReason: `隔离快照创建失败（${attempt.reason}）——AMAGI_EVIDENCE_SNAPSHOT=strict 不回退共享树（不猜成功红线），检查记 unavailable`,
				objectRef: "no-object:snapshot-create-failed",
				degraded: [],
				note: null,
				executedInSnapshot: false,
			};
		}
		return {
			result: await runCmd(cmd, testCwd, timeoutMs, ctxOf(plan ? (resolvePlanInRoot(plan, effCwd).binDirs) : [])),
				unavailableReason: null,
				objectRef: null,
				degraded: [`evidence-snapshot:隔离快照创建失败（${attempt.reason}）→回退共享树执行（AMAGI_EVIDENCE_SNAPSHOT=shared-fallback）——本结果未隔离，可能受并行写入干扰`],
				note: "  └ [快照 degraded] 创建失败回退共享树——本结果未隔离，可能受并行写入干扰（v2.3 C1）",
				executedInSnapshot: false,
		};
	}
	const snap = attempt.snapshot;
	try {
		if (plan) {
			// 快照内重放：verificationRoot（effCwd）映射到 worktree 内对应目录；bin 预核验失败 → 诚实 unavailable
			const res = resolvePlanInRoot(plan, snapshotRootFor(snap, effCwd), detected.planBin);
			if (!res.ok) {
				return {
					result: null,
					unavailableReason: `隔离快照内 bin 解析失败（snapshot-bin-missing:${res.missingBin ?? "?"}）：${res.problem}——非任务失败，不猜成功；可在共享树人工复核（copy-local 依赖捕获在 C2）`,
					objectRef: `no-object:snapshot-bin-missing:${res.missingBin ?? "?"}`,
					degraded: [],
					note: null,
					executedInSnapshot: false,
				};
			}
			const result = await runCmd(cmd, res.execCwd, timeoutMs, ctxOf(res.binDirs));
			return {
					result,
					unavailableReason: null,
					objectRef: null,
					degraded: [],
					note: `  └ [隔离快照] git worktree 冻结执行（deps 链接: ${snap.linkedDeps.length ? snap.linkedDeps.join(",") : "无"}；执行计划 cwdRel=${plan.cwdRel}, binDirsRel=[${plan.binDirsRel.join(",") || "无"}], resolution=${plan.resolution}）——并行共享树写入不干扰本结果（v2.3 C1）`,
					executedInSnapshot: true,
			};
		}
		const result = await runCmd(cmd, snap.execCwd, timeoutMs);
		return {
			result,
			unavailableReason: null,
			objectRef: null,
			degraded: [],
			note: `  └ [隔离快照] git worktree 冻结执行（deps 链接: ${snap.linkedDeps.length ? snap.linkedDeps.join(",") : "无"}）——并行共享树写入不干扰本结果（v2.3 C1）`,
			executedInSnapshot: true,
		};
	} finally {
		releaseEvidenceSnapshot(snap);
	}
}

export async function gatherEvidenceReport(cwd: string, deps?: EvidenceDeps, opts?: { baselinePorcelain?: string[] | null; taskId?: string; timeouts?: ResolvedEvidenceTimeouts; view?: EvidenceView; sharedTree?: boolean }): Promise<EvidenceReport> {
	const runCmd = deps?.runCmd ?? defaultRunCmd;
	const trusted = deps?.trusted ?? true;
	// S5/23f4a4：超时优先级链 task > env > 项目（ev-20261011-ad4513：<cwd>/amagi.json
	// evidenceTimeouts——全量测试超 120s 的仓库自声明预算）> 默认（=旧三常量，旧调用零变化）；
	// S2 在派发侧解析后传入冻结值（冻结值优先——项目层不逆向覆盖已冻结配置）；非法 env 回退并
	// 随证据文本一次性提示（0 不代表无限）。
	const timeouts = opts?.timeouts ?? resolveEvidenceTimeouts(undefined, process.env, readProjectEvidenceTimeouts(cwd));
	const lines: string[] = [];
	const contextNotes: string[] = [];
	const contextGit: string[] = [];
	const { effCwd, note } = await resolveGitCwd(cwd, runCmd, timeouts.gitMs);
	if (note) lines.push(note);
	if (note) contextNotes.push(note);
	if (timeouts.envWarning) lines.push(`• [证据超时配置] ${timeouts.envWarning}（本任务仅提示一次）`);
	if (timeouts.envWarning) contextNotes.push(`• [证据超时配置] ${timeouts.envWarning}`);

	const detected = deps?.structuredTest ? null : detectTestCommand(effCwd);
	const structured = deps?.structuredTest;
	let test: EvidenceReport["test"];
	let testResult: CmdResult | null = null;
	const degraded: string[] = [];
	if (!trusted) {
		const detail = "• 测试 → 已跳过（项目未信任：不自动执行项目测试命令，防不可信仓库读取凭据；git diff 仍采集）";
		lines.push(detail);
		test = { status: "skipped", detail, durationMs: 0 };
	} else if (structured) {
		testResult = structured.result;
		// C2-b（ev-20260921-89cc12，方案 §2.8）：测试部分消费结构化检查执行事实（单一事实源）——
		// 引用 harness 已保存的 {checkId, logRef}，不探测、不再执行（同一检查不双跑；展示与回执
		// 引用同一 id）。与 V3 矛盾的通过结论不再产生：无退出事实时如实呈现非确定绿状态。
		// Exit facts and coverage validity are separate: object-changed can retain exit=0
		// without being either a passing check or a test assertion failure.
		const nonDefinitive = structured.status !== "passed" && structured.status !== "failed" && structured.status !== "timed-out";
		// B10（ev-20261008-eb1e27）③：对象变化不再渲染为「测试失败」——非豁免形态准确显示
		// 「检查未覆盖当前对象」（覆盖无效≠断言失败，旧文案关键词保留供既有锚点检索）；豁免形态
		// 用 ◎ 显式披露豁免与依据（漂移/失败文件、归属并行写面、own 复核事实）。
		const selectionNote = structured.selection ? `\n  └ [写面感知] ${compactAutomaticText(structured.selection, 400, 2)}` : "";
		const detail = structured.result && nonDefinitive
			? structured.exemption
				? `• 测试 ${structured.label}（${structured.source}）→ ◎ ${structured.status}（sibling-interference-exempt；命令 exit ${structured.result.code ?? "未知"}——漂移/失败文件均不在本任务写面，本任务写面覆盖有效，非测试断言失败；豁免依据：${compactAutomaticText(structured.exemption.detail, 400, 2)}）${structured.problem ? `\n  ${compactAutomaticText(structured.problem, 300, 2)}` : ""}\n  └ [结构化检查] 引用 ${structured.checkId}（harness 已保存记录${structured.logRef ? "，日志 " + structured.logRef.path : ""}，未重复执行）${selectionNote}`
				: `• 测试 ${structured.label}（${structured.source}）→ ⛔ ${structured.status}（命令 exit ${structured.result.code ?? "未知"}${structured.result.timedOut ? "，命令超时" : ""}；${structured.status === "object-changed" ? "被验证对象发生变化——检查未覆盖当前对象，检查覆盖无效，非测试断言失败" : "未取得可用检查事实"}，不能判通过）${structured.problem ? `：${structured.problem}` : ""}\n  └ [结构化检查] 引用 ${structured.checkId}（harness 已保存记录${structured.logRef ? "，日志 " + structured.logRef.path : ""}，未重复执行）${selectionNote}`
			: structured.result
			? formatTestLine({ cmd: [...structured.argv], label: structured.label, source: structured.source as DetectedTest["source"] }, structured.result, false, timeouts.testMs)
				+ `\n  └ [结构化检查] 引用 ${structured.checkId}（harness 已保存记录${structured.logRef ? "，日志 " + structured.logRef.path : ""}）——同一执行事实，未重复执行（C2）${selectionNote}`
			: `• 测试 ${structured.label}（${structured.source}）→ ⛔ ${structured.status}${structured.problem ? `：${structured.problem}` : ""}\n  └ [结构化检查] 引用 ${structured.checkId}（harness 已保存记录，未重复执行）${selectionNote}`;
		lines.push(detail);
		const statusOf: Record<CheckStatus, EvidenceTestStatus> = {
			passed: "passed", failed: "failed", "timed-out": "timed-out", error: "error",
			unavailable: "unavailable", "not-run": "unavailable", "object-changed": "unavailable",
		};
		test = {
			status: statusOf[structured.status],
			command: [...structured.argv],
			label: structured.label,
			detail,
			durationMs: structured.result?.durationMs ?? 0,
		};
	} else if (detected && !detected.plan) {
		// C1（ev-20260922-7d1b10）：探测级 unavailable——根已声明 test 但 bin 全链缺失/子包候选歧义
		// （不静默降格为子包绿灯或 missing；不产出必败命令）。回执迁移口径消费 objectRef（D1 单一 id 协同）。
		const detail = `• 测试 ${detected.label}（${detected.source}）→ ⛔ unavailable：${detected.unavailableReason ?? "执行计划不可建立"}——不猜成功；可人工核对 scripts.test 与 bin 布局（C1）`;
		lines.push(detail);
		const ambiguous = (detected.unavailableReason ?? "").startsWith("resolution-ambiguous");
		test = {
			status: "unavailable", command: detected.cmd, label: detected.label, detail, durationMs: 0,
			...(detected.planBin || ambiguous ? { objectRef: `no-object:${ambiguous ? "resolution-ambiguous" : `plan-bin-missing:${detected.planBin ?? "?"}`}` } : {}),
			source: detected.source,
		};
	} else if (detected) {
		try {
			const reused = deps?.preverifiedTest;
			// ev-20260906-d9dc13：复用还需比对执行 cwd——子包级联命中的 npm test 必须钉在同一子包
			// （argv 相同而 cwd 不同的基线不得互串）；缺省 cwd 与本次采集 effCwd 一致时才可复用。
			// C1：规格 cwd 唯一数据源是 plan.cwdRel（相对 effCwd 重放；与旧 execCwd 同值）。
			const testCwd = detected.plan ? (detected.plan.cwdRel === "." ? effCwd : path.resolve(effCwd, detected.plan.cwdRel)) : (detected.execCwd ?? effCwd);
			const canReuse = !!reused
				&& reused.command.length === detected.cmd.length
				&& reused.command.every((part, i) => part === detected.cmd[i])
				&& (reused.execCwd ?? effCwd) === testCwd;
			// v2.3 C1：基线验证测试命令经隔离快照执行（off=现状零变化；复用 preverified 时不重跑亦不经快照）
			const exec = canReuse
				? { result: reused.result, unavailableReason: null as string | null, objectRef: null as string | null, degraded: [] as string[], note: null as string | null, executedInSnapshot: false }
				: await runTestUnderEvidenceSnapshot(detected, effCwd, timeouts.testMs, runCmd, resolveEvidenceSnapshotMode());
			degraded.push(...exec.degraded);
			if (exec.result === null) {
				// strict 快照创建失败/快照内 bin 预核验失败：检查记 unavailable（回执侧 checkStatusOfEvidenceTest→unavailable→missing→incomplete，不猜成功）
				const detail = `• 测试 ${detected.label}（${detected.source}）→ ⛔ unavailable：${exec.unavailableReason}`;
				lines.push(detail);
				test = { status: "unavailable", command: detected.cmd, label: detected.label, detail, durationMs: 0, ...(exec.objectRef ? { objectRef: exec.objectRef } : {}) };
			} else {
				const r = exec.result;
				testResult = r;
				// ev-20260919（P3-7）：快照内失败含依赖缺失特征（pnpm workspace 布局 .bin 相对符号链接跨快照
				// 断链、根 npm script 找不到子包二进制）→ 环境不可验证（unavailable）非任务失败；不猜成功，也不把
				// 环境局限记 failed——回执侧 unavailable→missing→incomplete 链如实呈现，可在共享树人工复核。
				const depMissing = exec.executedInSnapshot && !r.ok && !r.timedOut
					&& /(command not found|cannot find module|module_not_found|no such file or directory)/i.test(`${r.stdout}\n${r.stderr}`);
				if (depMissing) {
					const detail = `• 测试 ${detected.label}（${detected.source}）→ ⛔ unavailable：隔离快照环境依赖缺失（如 pnpm workspace 布局下 .bin 相对链接跨快照断链）——非任务失败，不猜成功；可在共享树人工复核（v2.4 P3-7）\n  ${(r.stderr || r.stdout).split("\n").filter(Boolean).slice(-3).join("\n  ") || "（无输出）"}`;
					lines.push(detail);
					test = { status: "unavailable", command: detected.cmd, label: detected.label, detail, durationMs: r.durationMs, objectRef: "no-object:snapshot-deps-missing" };
				} else {
					const detail = formatTestLine(detected, r, canReuse, timeouts.testMs) + (exec.note ? `\n${exec.note}` : "");
					lines.push(detail);
					test = {
						status: r.timedOut ? "timed-out" : r.ok ? "passed" : "failed",
						command: detected.cmd,
						label: detected.label,
						detail,
						durationMs: r.durationMs,
					};
				}
			}
		} catch (e) {
			const detail = `• 测试 ${detected.label}（${detected.source}）→ 采集异常：${e instanceof Error ? e.message : String(e)}`;
			lines.push(detail);
			test = { status: "error", command: detected.cmd, label: detected.label, detail, durationMs: 0 };
		}
	} else {
		const detail = `• 测试 → 未探测到测试命令（已查项目 amagi.json verification.testCommand 声明、根 package.json scripts.test / Makefile test / Cargo.toml / go.mod / CMakeLists.txt（含一级子目录、需已配置 build 目录）与一级子包 package.json scripts.test（JS monorepo 级联，最多 ${SUBPKG_SCAN_LIMIT} 个、跳过 node_modules 等），均无。非 JS 栈项目可在 amagi.json 声明 verification.testCommand: { argv: [...] }（声明优先于探测）`;
		lines.push(detail);
		test = { status: "missing", detail, durationMs: 0 };
	}

	try {
		// P0：-C effCwd 钉死 + 子树限幅（-- .）——命令行回显到 diff 行首，供验收时核对采集基准
		const diffCmd = ["git", "-C", effCwd, "--no-pager", "diff", "--stat", "HEAD", "--", "."];
		const r = await runCmd(diffCmd, effCwd, timeouts.gitMs);
		lines.push(formatDiffLine(r, effCwd, timeouts.gitMs));
		contextGit.push(r.ok && !r.timedOut
			? `• diff（共享树全量口径，含既有/并行改动）：${r.stdout.trim().split("\n").at(-1) || "无 tracked 改动"}`
			: formatDiffLine(r, effCwd, timeouts.gitMs));
		if (!r.ok || r.timedOut) contextNotes.push(formatDiffLine(r, effCwd, timeouts.gitMs));
	} catch (e) {
		lines.push(`• diff → 采集异常：${e instanceof Error ? e.message : String(e)}`);
		contextGit.push(lines.at(-1)!);
		contextNotes.push(lines.at(-1)!);
	}
	// 8月迭代 F3：归因行（快照对比；非 git 仓库/采集失败静默缺省）
	// ev-20260903-64641c：taskId 提供时三档归因（未命中标 ⚠ext 弱断言警示）
	// ev-20260906-50a3e6：同一 status 快照双用——先附未跟踪新文件独立段，再做归因差集
	const snap = takeGitStatusSnapshot(effCwd, timeouts.gitMs);
	try {
		const untracked = untrackedSection(effCwd, snap ?? []);
		if (untracked) lines.push(untracked);
		if (untracked) contextGit.push(untracked.split("\n")[0]);
	} catch {}
	try {
		const attr = attributionLine(opts?.baselinePorcelain, snap, opts?.taskId, effCwd, { gitTimeoutMs: timeouts.gitMs, view: opts?.view, sharedTree: opts?.sharedTree });
		if (attr) lines.push(attr);
		if (attr) contextGit.push(compactAutomaticText(attr, 768, 2));
	} catch {}
	const tags: Record<EvidenceTestStatus, string> = {
		passed: "✓ 通过", failed: `✗ 失败（exit ${testResult?.code ?? "未知"}）`,
		"timed-out": `⏱ 超时（阶段=测试命令执行；预算 ${fmtSec(timeouts.testMs)} 已到并终止——是 timeout，不是测试断言失败/exit 非零；预算可提升：amagi.json evidenceTimeouts.testMs / env AMAGI_EVIDENCE_TEST_TIMEOUT_MS，task 参数优先）`,
		skipped: "已跳过（项目未信任）", missing: "未探测到测试命令",
		error: "采集异常（spawn/执行器失败——非测试断言失败；真实原因见下方注记）", unavailable: "unavailable（环境缺口：未取得可用检查事实，非测试失败）",
	};
	const contextTag = structured?.exemption
		? `◎ sibling-interference-exempt（检查状态 ${structured.status}，命令 exit ${testResult?.code ?? "未知"}——漂移/失败文件均不在本任务写面，本任务写面覆盖有效）`
		: structured?.status === "object-changed"
		? `⛔ object-changed（命令 exit ${testResult?.code ?? "未知"}；被验证对象发生变化——检查未覆盖当前对象，检查覆盖无效，非测试断言失败）`
		: tags[test.status];
	let testContext = `• 测试 ${compactAutomaticText(test.label ?? "项目基线", 160, 1)} → ${contextTag}（${fmtSec(test.durationMs)}）${structured ? `\n  检查 ${structured.checkId}（未重复执行）` : ""}`;
	if (test.status !== "passed" && test.status !== "failed" && test.status !== "timed-out" && test.status !== "missing" && test.status !== "skipped") {
		testContext += `\n  ${compactAutomaticText(structured?.problem ?? test.detail.split("\n")[0], 480, 2)}`;
	}
	if (testResult && test.status !== "passed") {
		const excerpt = failureExcerpt(testResult.stdout, testResult.stderr);
		if (excerpt) testContext += `\n  ${test.status === "failed" || test.status === "timed-out" ? "失败线索" : "执行输出"}（节选）：\n${excerpt}`;
	}
	const scopeNote = structured?.coverage ?? (detected?.plan?.coverage === "selected-package" ? `仅 ${detected.plan.selectedPackage ?? detected.subdir} 子包；根与其余子包未跑。` : null);
	if (scopeNote) contextNotes.unshift(`• 覆盖范围：${scopeNote}`);
	// B10 ①：写面感知选择依据进上下文注记（compact 视图同样可见子集/全量回退原因）。
	if (structured?.selection) contextNotes.unshift(`• [写面感知] ${compactAutomaticText(structured.selection, 400, 1)}`);
	contextNotes.unshift(...degraded.map((s) => `• [快照 degraded] ${s}`));
	const text = "📋 证据（自动采集）\n" + lines.join("\n");

	return {
		text,
		archiveText: testResult ? `${text}\n\n[测试采集日志]\nstdout:\n${testResult.stdout}\nstderr:\n${testResult.stderr}` : text,
		context: { test: testContext, notes: contextNotes, git: contextGit.join("\n") },
		test,
		...(degraded.length > 0 ? { degraded: [...degraded] } : {}),
	};
}

/**
 * 采集证据文本块（附在子 Agent 回流末尾）。永不抛错——内部失败转为如实说明文本。
 * S5/23f4a4：timeouts 为 S2 冻结后的解析值（缺省内部走 env 链回默认）；view 透传呈现模式。
 */
export async function gatherEvidence(cwd: string, deps?: EvidenceDeps & { baselinePorcelain?: string[] | null; taskId?: string; timeouts?: ResolvedEvidenceTimeouts; view?: EvidenceView; sharedTree?: boolean }): Promise<string> {
	const { baselinePorcelain, taskId, timeouts, view, sharedTree, ...rest } = deps ?? {};
	return (await gatherEvidenceReport(cwd, rest, { baselinePorcelain, taskId, timeouts, view, sharedTree })).text;
}

// ── ev-20260917-8651a0（P3③）：[未自证] 回执轻量核验指引 ──
// 实战：多个 done 回执标 [未自证]，Leader 每轮全套重跑四包测试+typecheck 复核（≈3-5 分钟/轮、
// 单会话 ≈5 轮）；而回执证据块已含「测试 ✓ 通过」与 own 归因（子 Agent 真实写入登记命中）——
// 差异化核验指引：该形态下建议定向抽查关键产物，无需全套重跑。纯函数，通知尾部拼接消费。

/** [未自证] 轻量核验指引：终稿文本含 [未自证] 标记且证据块已含测试通过（✓ 通过）与 own 归因
 *  （own N，N≥1）时返回一行指引；其余形态返回空串（不产生噪音）。 */
export function lightVerifyHint(body: string): string {
	if (!body.includes("[未自证]")) return "";
	if (!/✓ 通过/.test(body)) return "";
	if (!/\bown\s+([1-9][0-9]*)\b/.test(body)) return "";
	return "\n[轻量核验] 回执未自证但证据块已含通过验证（测试 ✓）与 own 归因——建议定向抽查关键产物，无需全套重跑";
}

// ─────────────────────────────────────────────────────────────────────────────
// M2: 共享「编码任务完成回流」证据组装（覆盖 sync 直跑 / sync resume / #角色 硬路由）
// ─────────────────────────────────────────────────────────────────────────────

/**
 * v2（§7.1-B）：代码产物候选角色——与 task-tool AUTO_VERIFY 共用 agent-aliases.ts 的
 * CODE_PRODUCT_AGENTS 只读定义（{luban, luoshen, fuxi}），不能各维护一份。
 * 候选集合不是无条件执行集合：实际触发 = shouldRunCodeBaseline（候选 && producesProjectCode
 * && (非 fuxi || attack)；D1 裁决下 fuxi 恒 false）。
 */
export const DEFAULT_CODE_AGENTS = CODE_PRODUCT_AGENTS;

/**
 * 判定是否应对该 agent 跑证据：代码产物候选 + 完成态（v2 §7.1 统一判定）。
 * M2: 排除 running（未完成）/blocked（fence marker 判 blocked 后并非"完成"，不应跑未完成代码的测试）。
 * v2: producesProjectCode 由调用层从 fresh 变更路径分类（null=无法判定保守 true——不能因任务
 * 声称文档跳过代码验收）；旧调用方缺省 true 保持候选必跑口径。
 */
export function shouldGatherEvidence(agentName: string, status: string, producesProjectCode: boolean = true): boolean {
	if (!shouldRunCodeBaseline(codeProductContextOf(agentName, producesProjectCode))) return false;
	// v2 批次B：cancelled 同样排除——取消非完成态，半成品代码不应触发测试/证据采集。
	if (status === "running" || status === "blocked" || status === "cancelled") return false;
	// ev-20260908-f189e7：外部处置终态同样排除——产物已在外部采用，本地半成品/未验证代码不跑基线。
	if (status === "resolved-external") return false;
	return true;
}

/**
 * v2 §7.1-B：fresh 变更路径集（当前 git status 减去 baseline 快照行；rename 拆两侧；引号路径解码）。
 * 供代码产物分类（producesProjectCodeFromPaths）与两调用点（task-tool 自动验证门、finalizer 证据门）
 * 共用同一判定输入。非 git 仓库/探测失败 → null（无法判定，调用方保守处理）。
 */
export function freshChangedPaths(cwd: string, baselinePorcelain: readonly string[] | null | undefined): string[] | null {
	const current = takeGitStatusSnapshot(cwd);
	if (current === null) return null;
	const base = baselinePorcelain ? new Set(baselinePorcelain) : null;
	const paths: string[] = [];
	for (const line of current) {
		if (base?.has(line)) continue; // 基线已有行（非本任务产出）不参与产物分类
		const raw = porcelainPath(line);
		for (const side of raw.split(" -> ")) {
			const p = side.trim();
			if (p) paths.push(p);
		}
	}
	return paths;
}

/** v2 §7.1-B 便捷门控：候选角色 + fresh 路径分类 → producesProjectCode（fuxi 按 D1 裁决恒 false）。 */
export function producesProjectCodeOf(agentName: string, cwd: string, baselinePorcelain: readonly string[] | null | undefined): boolean {
	if (agentName === "fuxi") return false;
	return producesProjectCodeFromPaths(freshChangedPaths(cwd, baselinePorcelain));
}

/**
 * 在回流文本末尾附证据（仅编码角色 + 完成态才采集），否则原样返回。永不抛错。
 * @param gatherEv 证据采集注入（默认 gatherEvidence；测试注入避免跑真实命令）
 */
export interface AppendEvidenceOpts {
	/** 证据采集注入（默认 gatherEvidence；测试注入避免跑真实命令）。 */
	gatherEv?: (cwd: string) => Promise<string>;
	/** 项目是否可信（透传 gatherEvidence trust gate；调用方从 ctx.isProjectTrusted() 取）。 */
	trusted?: boolean;
}

/**
 * 在回流文本末尾附证据（仅编码角色 + 完成态才采集），否则原样返回。永不抛错。
 * trust gate：opts.trusted=false 时（项目未信任），gatherEvidence 跳过项目测试 spawn（仍采集 git diff）。
 * ev-20260903-64641c：opts.taskId 透传三档归因（fresh 差集逐路径查任务写入登记，未命中标
 * ⚠ext 弱断言警示）。写入登记文件的清理**不在此处**——finalizer 的产物摘要块在本函数之后
 * 还要读登记做三档归因，此处清理会把命中误降级为外部嫌疑；清理统一收口在收尾链末尾
 * （finalizer.ts，buildArtifactDiffSummary 之后；blocked 不清理，resume 续跑继续累积）。
 */
export async function appendEvidence(
	text: string,
	agentName: string,
	status: string,
	cwd: string,
	opts?: AppendEvidenceOpts & { baselinePorcelain?: string[] | null; taskId?: string; timeouts?: ResolvedEvidenceTimeouts; view?: EvidenceView },
): Promise<string> {
	// v2 §7.1-B：基线判定 = shouldRunCodeBaseline（候选 && 产物分类）；baselinePorcelain 缺省时
	// 无法分类 → 保守 true（候选必跑旧口径）；fuxi 按 D1 裁决恒 false。
	const _producesProjectCode = opts?.baselinePorcelain ? producesProjectCodeFromPaths(freshChangedPaths(cwd, opts.baselinePorcelain)) : true;
	if (!shouldGatherEvidence(agentName, status, _producesProjectCode)) return text;
	try {
		const evidence = opts?.gatherEv
			? await opts.gatherEv(cwd)
			: await gatherEvidence(cwd, { trusted: opts?.trusted ?? true, baselinePorcelain: opts?.baselinePorcelain, taskId: opts?.taskId, timeouts: opts?.timeouts, view: opts?.view });
		return evidence ? `${text}\n\n${evidence}` : text;
	} catch {
		return text; // 证据失败不影响主回流
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// V2（方案 §7.2 / §8.5-V2）：结构化检查执行、复用与结算判定面
//
// 上方命令发现/执行/写入归因能力全部保留；本节在其上新增结构化对象/策略关联：
//   1. runStructuredCheck：检查经 V1 对象捕获（或 shared-tree 显式允许模式）→ 在对象上执行 →
//      产出 K1 契约 CheckResult（objectId/policyDigest/实际 cwd+argv/退出码/时间/日志引用，§7.2）。
//      七种状态不混淆：超时≠failed（timed-out）、spawn 失败/执行器异常=error、对象漂移=
//      object-changed（exit 0 也不得 passed，§7.1.6）、对象模式不可建立=not-run（V1 判定面，
//      结算 incomplete 由 V3 消费）、必要输入被排除=unavailable（§7.1.4）。
//   2. 复用只认 harness 捕获的结构化记录（StructuredCheckRecord：CheckResult+对象，均本函数产出
//      或等价 JSON 恢复——子进程任务里模型自报的 PASS 文本不在此面，天然不满足）：对象完全一致
//      （objectId 内容寻址 = 清单+环境一致，另核对 manifest Ref digest 双保险）+ 策略一致
//      （policyDigest）+ 实际 cwd/argv 一致；任一不符拒绝复用重新执行。「最后一次写之后跑过测试」
//      不足以跨快照复用——legacy preverifiedTest 同树复用（gatherEvidenceReport，任务内同树口径）
//      不进入本面，也不作为 ready 依据。
//   3. deriveSettlementFace：结算判定面（K7 finalizer V3 接线消费，本片只导出结构化结果）——
//      缺机器检查的任务走产物完整性检查 + 人工验收条件，不伪造机器检查。
//   4. 每次重验 = 新捕获（内容寻址同 id 才可复用）+ 新 CheckResult id + 新日志文件——检查执行
//      幂等可重入，每次重验生成新回执记录（V3 回执面消费）。
// ─────────────────────────────────────────────────────────────────────────────

/** 结构化检查规格（策略冻结面；§7「模型可请求已有检查名，不能注入任意结算 shell 命令」——
 *  argv 由受信验证计划在派发时冻结，本层只执行，不解析/不接受模型侧任意命令）。 */
export interface StructuredCheckSpec {
	/** 检查名（回执/日志归档键；进 policyDigest）。D1（ev-20260922-c896f8）：规格名（CheckSpecId）
	 *  只用于配置面，不作为回执引用 id——回执引用面唯一可引用的是 CheckResult.id（newCheckId 分配）。 */
	id: CheckSpecId;
	/** 是否必要检查（required failed → 结算 failed；V3 finalizer 消费）。 */
	required: boolean;
	/** 实际执行 argv（进 policyDigest；复用比对项——任一元素不同拒绝复用）。 */
	argv: readonly string[];
	/** 单次执行预算 ms（进 policyDigest——预算不同即不同策略）；缺省 120s，区间同 EVIDENCE_TEST_MS。 */
	timeoutMs?: number;
	/** 对象策略（进 policyDigest）；缺省 { objectMode: "snapshot", allowSharedFallback: false }。
	 *  C2-a（ev-20260921-89cc12，方案 §2.8）：dependencyMode=copy-local 时捕获冻结依赖对象
	 *  （root + 声明 workspace 子包 node_modules 私有副本；进 policyDigest——依赖模式是执行
	 *  语义；旧规格缺字段不补默认键，历史 digest 输入不变）。 */
	policy?: { objectMode: VerificationMode; allowSharedFallback: boolean; dependencyMode?: "none" | "copy-local" };
	/** 对象内相对执行目录（monorepo 子包等；**不进 policyDigest**——实际 cwd 是 §7.2 独立比对轴）。
	 *  必须是相对路径且不含 ..；缺省 = 对象根（snapshot 模式即捕获根副本中的对应目录）。 */
	execCwd?: string;
	/** C1（ev-20260922-7d1b10）：相对 bin 解析计划（workspace 链，有序；进 policyDigest——
	 *  有序 bin 解析计划是执行语义）。相对对象根、非绝对、不含 ..、非空串；缺省 = 无本地
	 *  bin 前缀（旧规格 digest 输入不变）。 */
	binDirsRel?: readonly string[];
	/** B10（ev-20261008-eb1e27，主上裁定①）：写面感知选择依据（子集/全量回退的披露文案；
	 *  **不进 policyDigest**——选择是运行编排事实而非执行语义，历史 digest 输入不变）。
	 *  runStructuredCheck 将其入 notes 与检查日志；展示链经 StructuredTestRef.selection 披露。 */
	selection?: { basis: string };
	/** ev-20261021-54b4e3：项目声明的执行期环境（资源预算/runner 并发等；**进 policyDigest**——
	 *  资源配置是执行语义；缺省不补键，历史 digest 输入不变）。保留键（PATH/隔离注入）在读取时已拒。 */
	env?: Readonly<Record<string, string>>;
	/** ev-20261021-54b4e3：入口来源披露（声明/探测 + 标签；不进 policyDigest）——notes 记录实际入口。 */
	entry?: { source: string; label: string };
}

/** harness 捕获的结构化检查记录（复用判定输入；runStructuredCheck 产出可 JSON 持久化后回填）。 */
export interface StructuredCheckRecord {
	check: CheckResult;
	/** 检查所跑对象（cwd 键归一：snapshot 捕获根逐次不同，比对按对象内相对路径）。 */
	object: VerificationObject;
}

/** 规格校验（fail-closed：非法规格 → error 结果，不抛出——结算链不得被规格问题打断）。 */
function structuredSpecProblem(spec: StructuredCheckSpec): string | null {
	if (!spec || typeof spec.id !== "string" || spec.id.trim() === "") return "spec.id 必须是非空字符串";
	if (!Array.isArray(spec.argv) || spec.argv.length === 0 || spec.argv.some((a) => typeof a !== "string" || a === "")) {
		return "spec.argv 必须是非空字符串组成的非空数组";
	}
	if (spec.timeoutMs !== undefined && (!Number.isInteger(spec.timeoutMs) || spec.timeoutMs < EVIDENCE_TEST_MS_MIN || spec.timeoutMs > EVIDENCE_TEST_MS_MAX)) {
		return `spec.timeoutMs=${String(spec.timeoutMs)} 越界（合法区间 ${EVIDENCE_TEST_MS_MIN}–${EVIDENCE_TEST_MS_MAX} 整数毫秒；0 不代表无限）`;
	}
	if (spec.execCwd !== undefined && (typeof spec.execCwd !== "string" || spec.execCwd === "" || path.isAbsolute(spec.execCwd) || spec.execCwd.split(/[\\/]/).includes(".."))) {
		return "spec.execCwd 必须是对象内相对路径（非绝对、不含 ..）";
	}
	if (spec.binDirsRel !== undefined && (!Array.isArray(spec.binDirsRel) || spec.binDirsRel.some((d) => typeof d !== "string" || d === "" || path.isAbsolute(d) || d.split(/[\\/]/).includes("..")))) {
		return "spec.binDirsRel 必须是相对路径组成的数组（非绝对、不含 ..、非空串）";
	}
	if (spec.policy !== undefined && (!spec.policy || !["snapshot", "shared-tree"].includes(spec.policy.objectMode) || typeof spec.policy.allowSharedFallback !== "boolean")) {
		return "spec.policy 必须是 { objectMode: snapshot|shared-tree, allowSharedFallback: boolean }";
	}
	if (spec.env !== undefined && (spec.env === null || typeof spec.env !== "object" || Array.isArray(spec.env)
		|| Object.entries(spec.env).some(([k, v]) => !/^[A-Za-z_][A-Za-z0-9_]*$/.test(k) || typeof v !== "string"))) {
		return "spec.env 必须是 环境变量名 → 字符串 的映射";
	}
	// C2-a：依赖模式封闭枚举（缺省 = none——旧规格合法；非法值 fail-closed）
	if (spec.policy?.dependencyMode !== undefined && !["none", "copy-local"].includes(spec.policy.dependencyMode)) {
		return "spec.policy.dependencyMode 必须是 none|copy-local";
	}
	return null;
}

/** 规范化 JSON（键排序稳定序列化；policyDigest 与检查日志落盘共用）。 */
function canonicalJsonOf(v: unknown): string {
	if (Array.isArray(v)) return `[${v.map(canonicalJsonOf).join(",")}]`;
	if (v && typeof v === "object") {
		const rec = v as Record<string, unknown>;
		return `{${Object.keys(rec).sort().map((k) => `${JSON.stringify(k)}:${canonicalJsonOf(rec[k])}`).join(",")}}`;
	}
	return JSON.stringify(v) ?? "null";
}

/**
 * 策略 digest（§7.2）：检查执行策略的规范化 hash——检查 id + argv + 超时预算 + 对象模式策略。
 * required 是结算属性（不改变执行语义）、execCwd 是实际 cwd 轴（§7.2 与策略 digest 并列的独立
 * 比对项）——两者均不入 digest。同策略同 digest；改变任一执行语义维度即不同 digest → 拒绝复用。
 */
export function digestCheckPolicy(spec: StructuredCheckSpec): string {
	// C1（ev-20260922-7d1b10）：有序 bin 解析计划入 digest；缺省不补键（旧规格 digest 输入逐字节
	// 不变——历史记录可读/可复用，方案 §2.8 口径）。
	const normalized: Record<string, unknown> = {
		id: spec.id,
		argv: [...spec.argv],
		timeoutMs: spec.timeoutMs ?? DEFAULT_EVIDENCE_TEST_TIMEOUT_MS,
		policy: spec.policy ?? { objectMode: "snapshot", allowSharedFallback: false },
	};
	if (spec.binDirsRel !== undefined) normalized.binDirsRel = [...spec.binDirsRel];
	if (spec.env !== undefined && Object.keys(spec.env).length > 0) normalized.env = { ...spec.env };
	return createHash("sha256").update(canonicalJsonOf(normalized), "utf8").digest("hex");
}

/** §7.1.4「被排除的必要输入 → 相关检查 unavailable」判定：相关 = ①被排除路径被 argv 引用；
 *  ②snapshot 模式下依赖锁文件在场且命令是包管理/构建工具——在快照上跑只会把环境缺失误报成
 *  failed。shared-tree 运行于共享树本体（依赖在场），②不适用。
 *  C2-a（ev-20260921-89cc12，方案 §2.8）：②改看真实依赖捕获状态——仅 mode=copy-local 且完整
 *  校验通过才解除缺口；old none / 无依赖根（未安装）/ 捕获失败 / 复制不全继续 unavailable
 *  （锁文件只是输入之一，不代用判断）。 */
// ev-20261017-ece384（diting F2）：go 同 cargo——go.sum 在场时依赖在对象外的全局模块缓存，冷缓存会联网下载、
// 离线以 [setup failed] 误报 failed。ev-20261017-ece384 续（本批）：go 不再一刀切 unavailable——
// 依赖走只读离线复用本机 GOMODCACHE 路径（verification-dependencies.ts：离线预检完备即解除门控，
// 不安装、不联网、不捕获副本）；cargo/make 等其余工具维持 F2 保守口径。
const DEPS_REQUIRING_TOOLS = new Set(["npm", "npx", "pnpm", "yarn", "bun", "cargo", "make", "go"]);

function unavailableReason(
	manifest: VerificationManifest,
	argv: readonly string[],
	mode: VerificationMode,
	entry: CommandEntryResolution,
	deps?: DependencyCaptureSummary | null,
	goCache?: GoModulePreflight | null,
): { reason: string; missingExecutable: boolean } | null {
	for (const ex of manifest.excluded) {
		if (!ex.required) continue;
		if (argv.some((tok) => tok.includes(ex.path))) {
			return { reason: `必要输入被排除（${ex.reason}:${ex.path}）且被检查命令引用——相关检查不可执行（§7.1.4）`, missingExecutable: false };
		}
	}
	if (mode === "snapshot" && deps && !deps.ok && deps.code !== "no-capture-root") {
		return { reason: `dependencies-capture-failed（${deps.code}）——${deps.reason}——检查不可在快照上执行（copy-local 捕获未完成，不降格通过）`, missingExecutable: false };
	}
	// ev-20261019-9321ad：工具名/go 判定改消费统一命令入口解析（entry：透明包装器剥离 +
	// realpath 识别）——`env <go> test`/异名 Go 符号链接不再绕过依赖门控（与复用/预检/注入同一解析）。
	const entryToolName = entry.toolName;
	const entryIsGo = entry.isGo;
	if (mode === "snapshot" && manifest.lockFiles.length > 0 && (DEPS_REQUIRING_TOOLS.has(entryToolName) || entryIsGo)
		&& !(entryIsGo && goCache?.ok)) {
		// ev-20261017-ece384 续：go 走离线只读模块缓存路径——node_modules 捕获（deps.ok）不能
		// 代偿 GOMODCACHE 缺口，go 分支先于 deps 判定；预检由 runStructuredCheck ② 在快照上执行。
		if (entryIsGo) {
			if (goCache && !goCache.ok) {
				return { reason: `${goCache.reason ?? "Go 模块缓存不完备（离线预检失败）"}——检查不可在快照上执行（${goCache.detail}；只读复用本机 GOMODCACHE 路径须离线预检通过；依赖安装须策略明确且已有授权，§7.1.4）`, missingExecutable: false };
			}
			// goCache 缺席（理论不可达：go.sum 在场必先预检）——保守维持 F2 原口径
		}
		if (!deps?.ok) {
			if (deps) {
				return { reason: `dependencies-capture-failed（${deps.code}）——${deps.reason}——检查不可在快照上执行（copy-local 捕获未完成，不降格通过）`, missingExecutable: false };
			}
			return { reason: `dependencies-not-captured（${manifest.lockFiles.join(",")}）而 ${entryToolName || argv[0]} 需要依赖安装产物——检查不可在快照上执行（依赖安装须策略明确且已有授权，§7.1.4；dependencyMode=copy-local 可捕获冻结依赖）`, missingExecutable: false };
		}
	}
	// 仅工具缺失可尽力降级；先保留对象/依赖缺口，不能被同时缺工具遮蔽（diting F02）。
	if (entry.unlocatable) {
		const discovered = discoverUserToolBinDirs();
		return {
			reason: `工具不可定位（${entry.toolToken}：shell.pathPrepend/binDirs/系统 PATH/常见用户级目录${discovered.length > 0 ? `（已探测：${discovered.join(":")}` : ""}均未命中可执行文件）——环境缺口非测试失败，检查记 unavailable 不执行；可在 amagi.json 声明 shell.pathPrepend: ["<工具所在目录>"] 或安装工具（自动发现覆盖 ~/.local/bin、~/Library/Python/*/bin、Homebrew、CMake.app 等常见用户级目录）`,
			missingExecutable: true,
		};
	}
	return null;
}

/** ev-20261111-fix（diting F05）：argv 中引用了对象外/清单未冻结路径的 token 清单。
 *  判定口径：工具 token（含包装器链，toolIndex 及之前）不入判——工具二进制位置由入口解析面
 *  承担（realpath 识别/复用门控），工具本身不是被验证输入。工具后的 token：绝对路径一律判定；
 *  含分隔符的相对 token 仅在磁盘存在且为普通文件时判定（"./..." 等 glob 形态不是路径引用，
 *  避免误判噪音）。越出对象根 → 未冻结；对象内但清单无等值条目且无子树条目（gitignored/排除
 *  目录，如共享构建树 build/）→ 未冻结。返回原文 token 去重列表（空 = 全部冻结/无路径引用）。 */
function argvUnfrozenReferences(argv: readonly string[], object: VerificationObject, manifest: VerificationManifest, toolIndex: number): string[] {
	const out: string[] = [];
	const seen = new Set<string>();
	for (let i = toolIndex + 1; i < argv.length; i++) {
		const raw = argv[i];
		if (typeof raw !== "string" || !raw) continue;
		for (const tok of argvPathCandidates(raw)) {
		if (!tok || seen.has(tok)) continue;
		const isAbs = path.isAbsolute(tok);
		if (!isAbs && tok.startsWith("-")) continue; // 旗标本体（值位已由 argvPathCandidates 拆出）
		const abs = isAbs ? path.normalize(tok) : path.resolve(object.cwd, tok);
		if (!isAbs) {
			// evolve 2.21.11 复审 F-R4-1：相对 token 以「执行目录下实际存在」判定路径引用——文件与目录
			// 一视同仁、裸名（`--test-dir build`）与带分隔符同口径；不存在（glob 形态 ./...、普通参数）
			// 不入判。旧口径只认含分隔符的普通文件，相对目录引用（共享构建树）漏判、旧绿灯复用。
			try { fs.statSync(abs); } catch { continue; /* lint-exempt:相对 token 不存在 → 非实际路径引用（glob 形态不入判） */ }
		}
		const rel = path.relative(object.cwd, abs);
		if (rel === "") { seen.add(tok); continue; } // 对象根本身（`.`）——内容即清单冻结面
		const inside = rel !== "" && !path.isAbsolute(rel) && rel !== ".." && !rel.startsWith(`..${path.sep}`);
		if (inside) {
			const relPosix = rel.split(path.sep).join("/");
			const covered = manifest.entries.some((e) => e.path === relPosix || e.path.startsWith(`${relPosix}/`));
			if (covered) { seen.add(tok); continue; } // 对象内且清单冻结
		}
		seen.add(tok);
		out.push(tok);
		}
	}
	return out;
}

/** evolve 2.21.11 复审残留（F05 option=value 绕过）：单个 argv token 内的路径引用候选。
 *  旗标形态把路径嵌在 token 内（`--test-dir=/x`、`--require=/x`、`-I/x`、`--a=/x,/y`），
 *  只看整 token 会漏判。候选 = 整 token；旗标 `=` 之后的值；无 `=` 的短旗标首个 `/` 起的
 *  剩余（-I/x）；以上各自按 `,` 拆分的成员。路径判定口径仍由调用方统一执行。 */
function argvPathCandidates(tok: string): string[] {
	const cands = [tok];
	if (tok.startsWith("-")) {
		const eq = tok.indexOf("=");
		if (eq >= 0) cands.push(tok.slice(eq + 1));
		else {
			const slash = tok.search(/[\\/]/);
			if (slash > 1) cands.push(tok.slice(slash));
		}
	}
	for (const c of [...cands]) if (c.includes(",")) cands.push(...c.split(","));
	return cands;
}

/** 规格执行目录解析（对象根相对；规格已过 structuredSpecProblem 校验，null 分支不可达）。 */
function execCwdOf(object: VerificationObject, spec: StructuredCheckSpec): string {
	return spec.execCwd ? path.resolve(object.cwd, spec.execCwd) : object.cwd;
}

/** 对象内相对执行路径（cwd 比对键）：snapshot 捕获根逐次不同（mkdtemp），绝对路径比对会让
 *  同内容快照互斥——按对象内相对路径归一。越界（..）→ null（记录与对象无所属关系，比对不成立）。 */
function objectRelativeCwd(object: VerificationObject, actualCwd: string): string | null {
	const rel = path.relative(object.cwd, actualCwd);
	if (path.isAbsolute(rel) || (rel === ".." || rel.startsWith(`..${path.sep}`))) return null;
	return rel;
}

/** 复用拒绝原因（机器可读短码；§7.2 任一条件不符即拒绝）。ev-20261021-fix（diting F8）：
 *  go-deps-not-captured=快照 go 检查外部依赖（模块缓存/本地 replace/工具链）未捕获指纹，一律禁复用。
 *  ev-20261019-9321ad：entry-unresolved=命令入口不可识别（透明包装器改写 PATH/清空 env/查询
 *  形态/工具不可定位且名字无法保守归类/同名包装器无法证明系统身份）——不能证明检查不依赖
 *  对象外未冻结依赖，禁复用。
 *  ev-20261111-fix（diting F05）：argv-outside-object=argv 引用对象外/清单未冻结路径（如
 *  ctest --test-dir 共享构建树）——对象不覆盖真实测试输入，输入变化不可检测，先验绿灯禁复用。 */
export type CheckReuseRejectReason =
	| "reuse-disabled" | "no-prior" | "prior-not-passed"
	| "object-mismatch" | "policy-mismatch" | "cwd-mismatch" | "argv-mismatch"
	| "go-deps-not-captured"
	| "entry-unresolved"
	| "argv-outside-object";

export interface CheckReuseVerdict {
	ok: boolean;
	reason?: CheckReuseRejectReason;
	message: string;
}

/**
 * §7.2 复用判定（纯函数）：prior 必须是 harness 捕获的结构化记录（本函数输入即 harness 记录面，
 * 模型自报 PASS 文本进不来）；四条件全符才可复用——
 *   ①对象完全一致：objectId（内容寻址：清单+环境）相等，另核对 manifest Ref digest（§7.2「对象
 *     id/manifest hash」双保险；不一致视为记录损坏，拒绝）；
 *   ②策略一致：policyDigest 相等；
 *   ③实际 cwd 一致：对象内相对执行路径相等（snapshot 捕获根逐次不同，按对象内归一）；
 *   ④实际 argv 一致：逐元素相等。
 * 仅 passed 可复用：failed/timed-out/error 等非确定绿事实重跑取新证据（诊断与重验需要）。
 * AMAGI_CHECK_REUSE=0（checkReuseEnabled=false）→ 一律拒绝（风险/回滚：关闭复用可重验）。
 */
export function checkReuseVerdict(
	prior: StructuredCheckRecord | undefined,
	next: { object: VerificationObject; spec: StructuredCheckSpec },
	opts?: { reuseEnabled?: boolean },
): CheckReuseVerdict {
	const reuseEnabled = opts?.reuseEnabled ?? checkReuseEnabled();
	if (!reuseEnabled) return { ok: false, reason: "reuse-disabled", message: "复用已关闭（AMAGI_CHECK_REUSE=0）——每次重验重新执行" };
	if (!prior) return { ok: false, reason: "no-prior", message: "无可复用的结构化检查记录" };
	if (prior.check.status !== "passed") {
		return { ok: false, reason: "prior-not-passed", message: `先验记录非 passed（${prior.check.status}）——不作为复用依据，重新执行取新事实` };
	}
	if (prior.object.id !== next.object.id) {
		return { ok: false, reason: "object-mismatch", message: `对象不一致（prior ${prior.object.id} ≠ 当前 ${next.object.id}）——内容/环境已变，拒绝复用` };
	}
	if (prior.object.manifest.digest !== next.object.manifest.digest) {
		return { ok: false, reason: "object-mismatch", message: "对象清单 manifest hash 不一致（记录与对象指纹不符）——拒绝复用" };
	}
	const priorPolicy = prior.check.policyDigest;
	const nextPolicy = digestCheckPolicy(next.spec);
	if (priorPolicy !== nextPolicy) {
		return { ok: false, reason: "policy-mismatch", message: `策略不一致（policyDigest ${priorPolicy.slice(0, 12)}… ≠ ${nextPolicy.slice(0, 12)}…）——检查配置已变，拒绝复用` };
	}
	const priorRel = objectRelativeCwd(prior.object, prior.check.cwd);
	const nextCwd = execCwdOf(next.object, next.spec);
	const nextRel = objectRelativeCwd(next.object, nextCwd);
	if (priorRel === null || nextRel === null || priorRel !== nextRel) {
		return { ok: false, reason: "cwd-mismatch", message: `实际执行 cwd 不一致（prior ${prior.check.cwd} ≠ ${nextCwd}）——拒绝复用` };
	}
	if (prior.check.argv.length !== next.spec.argv.length || prior.check.argv.some((a, i) => a !== next.spec.argv[i])) {
		return { ok: false, reason: "argv-mismatch", message: "实际执行 argv 不一致——拒绝复用" };
	}
	return { ok: true, message: "对象/策略/实际 cwd+argv 完全一致——复用先验结构化记录，不重复执行" };
}

/** B10（ev-20261008-eb1e27，主上裁定②）：基线检查的写面感知守卫（finalizer/baseline-scope 按
 *  任务 own 写面构造后注入 runStructuredCheck；纯数据，判定执行面在 runStructuredCheck）。
 *  - ownFiles/ownPrefixes：本任务 own 写面（相对检查 sourceCwd 的 POSIX 相对路径；prefix 含尾 /）。
 *    own 文件集在检查执行前快照（sha256）、结果落地前复核——own 写面本身被改则豁免不成立
 *    （维持硬语义，防把本任务晚写/他人越面漂移豁免成绿）。
 *  - siblings：同 cwd 并行切片写面（豁免归属披露；未命中=「未归属已知并行任务」如实标注）。
 *  - testFiles：已知测试文件字典（failed 状态从执行输出解析失败所涉文件；相对 sourceCwd）。
 *  豁免范围：仅已执行检查（有退出事实）的 object-changed（对象漂移）与 failed（测试失败）；
 *  捕获失败/执行前漂移/超时/spawn 错误不豁免（无本任务覆盖事实，不得伪造覆盖）。 */
export interface BaselineScopeGuard {
	ownFiles: readonly string[];
	ownPrefixes: readonly string[];
	siblings: readonly { label: string; files: readonly string[]; prefixes: readonly string[] }[];
	testFiles: readonly string[];
	/** B10 修复轮 F-02（diting 终裁）：own 责任测试集——子集推导命中（含传递命中/不可判定纳入）
	 *  的测试文件。这些测试验证 own 写面内容，其失败不得豁免。缺省 []（旧守卫兼容：failed 型
	 *  正归属门兜底——无兄弟正归属的失败一律不豁免）。 */
	responsibleTests?: readonly string[];
}

/** 结构化检查执行结果（V3 回执/结算面消费；manifest 供归档复核）。 */
export interface StructuredCheckOutcome {
	/** K1 契约校验过的检查结果（七状态之一；N7：passed 必带时间事实与 exitCode=0）。 */
	check: CheckResult;
	/** 检查运行的对象（capture 成功才有；mode-unavailable/object-changed/capture-error 无对象）。 */
	object: VerificationObject | null;
	manifest: VerificationManifest | null;
	/** 捕获根（成功对象保留供复核，§7.1.5；调用方决定何时 releaseCaptureDir）。 */
	captureRoot: string | null;
	/** true = 检查命令真实执行过（spawn）；false = 复用/对象不可建立/输入被排除/执行前漂移。 */
	executed: boolean;
	/** 复用判定事实（opts.prior 提供时记录；未提供为 undefined）。 */
	reuse?: CheckReuseVerdict;
	/** C2-a：依赖捕获事实（copy-local 时有；成功/失败均如实携带——失败 → unavailable 口径）。 */
	dependencyCapture?: DependencyCaptureSummary;
	/** C2-a：runner 缓存重定向目录（对象外临时输出；copy-local 且捕获成功才有）。 */
	cacheRoot?: string | null;
	/** ev-20261021-fix（diting F6）：任务私有 Go 模块缓存根（快照 go 执行时必有；GOMODCACHE 钉到该根，
	 *  宿主缓存零写入）。 */
	goModuleCacheRoot?: string;
	/** B10（ev-20261008-eb1e27）：写面感知选择依据（spec.selection 转发；展示链披露）。 */
	selection?: { basis: string };
	/** B10：兄弟切片干扰豁免事实（判定成立时携带；CheckResult.exemption 同源）。 */
	exemption?: CheckExemption;
	/** 人工可读注记（归档与回执呈现）。 */
	notes: string[];
}

/** 检查记录 id（每次执行/复用唯一——每次重验生成新回执记录，幂等可重入）。
 *  D1（ev-20260922-c896f8）：随机 id 分配归 IO/执行层本函数（contracts 保持零 crypto/fs）；
 *  返回 CheckId（回执引用面唯一可引用的检查 id——状态不编码进 id）。 */
export function newCheckId(specId: string): CheckId {
	const safe = specId.replace(/[^A-Za-z0-9_.-]/g, "_").slice(0, 48) || "check";
	return `chk-${safe}-${randomUUID().slice(0, 8)}` as CheckId;
}

// ── ev-20261108-m3（diting 审 m3）：「自动基线探测级环境缺口降级」展示判据（单源） ──────
// 回执 checks 中存在 id 前缀 chk-auto-baseline-test-、status=unavailable 且 required=false
// 的检查（ev-20261105-8d31e3 降级面）即「settlement=ready 但零自动测试事实」。settlement 判定
// 不变；task_query summary/receipt 视图行、task_control accept 返回附注、[待接受] 提示与
// finalizer 一次性提示触发共用本判据——禁止在调用方复制条件表达式。

/** 自动基线检查记录 id 前缀（newCheckId(AUTO_CHECK_ID) 形态；finalizer 生成侧同源字符串）。 */
export const AUTO_BASELINE_CHECK_RECORD_PREFIX = "chk-auto-baseline-test-";

/** baselineEnvGapOf 命中事实（展示层消费；不改 CheckResult/TaskReceipt 契约字段）。 */
export interface BaselineEnvGapFact {
	/** 命中的检查记录 id（完整字面，供回执归档定位）。 */
	checkId: string;
	/** 原因短码（objectId，如 no-object:plan-bin-missing:npm；有界截断展示，空串回退 checkId）。 */
	objectId: string;
}

/** 从回执 checks 派生「自动基线未执行（探测级环境缺口降级）」事实；无命中 → null。
 *  checks 形状宽松（归档 JSON 只读展开，判据字段子集匹配，不重复契约校验）；
 *  普通检查（passed/failed/required 保留的 unavailable/其他前缀）一律不命中。 */
export function baselineEnvGapOf(checks: readonly unknown[] | undefined | null): BaselineEnvGapFact | null {
	if (!checks) return null;
	for (const c of checks) {
		if (!c || typeof c !== "object") continue;
		const { id, status, required, objectId } = c as { id?: unknown; status?: unknown; required?: unknown; objectId?: unknown };
		if (typeof id !== "string" || !id.startsWith(AUTO_BASELINE_CHECK_RECORD_PREFIX)) continue;
		if (status !== "unavailable" || required !== false) continue;
		return { checkId: id, objectId: typeof objectId === "string" ? objectId.slice(0, 80) : "" };
	}
	return null;
}

/** 检查日志落盘（captureRoot/checks/<checkId>.json；canonical JSON → Ref 内容寻址）。
 *  日志不在清单内（capture 之后写入），不影响对象前后指纹比对。失败 → undefined（不阻断结果）。 */
function writeCheckLog(captureRoot: string, checkId: string, payload: Record<string, unknown>): Ref | undefined {
	try {
		const dir = path.join(captureRoot, "checks");
		fs.mkdirSync(dir, { recursive: true });
		const abs = path.join(dir, `${checkId}.json`);
		const body = canonicalJsonOf(payload);
		fs.writeFileSync(abs, body, "utf8");
		return { path: abs, digest: createHash("sha256").update(body, "utf8").digest("hex"), bytes: Buffer.byteLength(body, "utf8") };
	} catch {
		return undefined;
	}
}

/** 契约自检（不变量：产出记录必须能被 K1 消费端校验通过；失败属实现 bug——fail-closed 降级为
 *  最小合法 error 记录，绝不输出形状非法记录）。 */
function contractChecked(check: CheckResult, notes: string[]): CheckResult {
	const v = validateCheckResult(check);
	if (v.ok) return check;
	notes.push(`产出 CheckResult 未过契约校验（实现 bug）: ${v.error.message}`);
	return { id: check.id, required: check.required, objectId: check.objectId, policyDigest: check.policyDigest, status: "error", argv: [...check.argv], cwd: check.cwd };
}

// ── B10（ev-20261008-eb1e27，主上裁定②）：兄弟切片干扰豁免判定面（纯函数 + 有界文件读） ──

/** own 写面文件快照（源树口径）：rel → sha256（缺失文件 = null）。 */
function snapshotOwnSurfaceFiles(guard: BaselineScopeGuard, root: string): Map<string, string | null> {
	const m = new Map<string, string | null>();
	for (const rel of guard.ownFiles) {
		try {
			m.set(rel, createHash("sha256").update(fs.readFileSync(path.join(root, rel))).digest("hex"));
		} catch { /* lint-exempt:own 文件缺失/不可读→null（快照口径如实记录，复核比对同口径） */
			m.set(rel, null);
		}
	}
	return m;
}

/** own 写面复核：全部 own 文件 digest 与快照一致（缺失状态也须一致）——任一变化 = 不可豁免。 */
function ownSurfaceUnchanged(guard: BaselineScopeGuard, before: Map<string, string | null>, root: string): boolean {
	for (const rel of guard.ownFiles) {
		let now: string | null = null;
		try {
			now = createHash("sha256").update(fs.readFileSync(path.join(root, rel))).digest("hex");
		} catch { /* lint-exempt:复核读取失败→null（与快照缺失口径一致，变化即不可豁免） */
			now = null;
		}
		if (now !== before.get(rel)) return false;
	}
	return true;
}

/** 路径是否落入写面（文件级相等或目录前缀包含；prefix 含尾 /）。 */
function surfaceContainsRel(files: readonly string[], prefixes: readonly string[], rel: string): boolean {
	if (files.includes(rel)) return true;
	for (const p of prefixes) {
		if (p.endsWith("/") ? rel.startsWith(p) || rel + "/" === p : rel.startsWith(p) || rel === p) return true;
	}
	return false;
}

/** B10 修复轮 F-01：失败定位行判定——只有「test at <path>」失败汇总头（spec）与 at 定位行
 *  （`at X (file://…)` / TAP `at: (…)`）是失败归属证据；正文普通行（console.log 回显路径等
 *  log-pollution 形态）不构成归属。 */
function failureLocusLine(line: string): boolean {
	return /^test at\s+\S+/.test(line) || /\bat[(:]?\s.*file:\/\//.test(line) || /^\s*at:\s*\(/.test(line);
}

/** 定位行中提取失败文件（相对 execCwd 的 POSIX 相对路径）。 */
interface FailureLocusExtraction {
	/** 成功相对化的失败文件（去行列后缀、排序去重）。 */
	files: string[];
	/** true = 存在无法相对化/解析的定位路径（不能证明非 own——整体不豁免）。 */
	opaque: boolean;
}

function failingFilesFromLocus(output: string, execCwd: string): FailureLocusExtraction {
	const hits = new Set<string>();
	let opaque = false;
	// 绝对路径相对化双基准：spawn cwd 与其 realpath（macOS /var → /private/var 挂载别名——
	// file URL 按 realpath 规范化，单基准会把同目录文件误判出界 → opaque 误伤正归属豁免）
	const bases = [path.resolve(execCwd)];
	try {
		const rp = fs.realpathSync(execCwd);
		if (!bases.includes(rp)) bases.push(rp);
	} catch { /* lint-exempt:cwd 不可达→单基准（realpath 双基准降级） */ }
	for (const rawLine of output.split("\n")) {
		const line = rawLine.trimEnd();
		if (!failureLocusLine(line)) continue;
		const candidates: string[] = [];
		const head = line.match(/^test at\s+(\S+?):\d+:\d+/);
		if (head) candidates.push(head[1]);
		const url = line.match(/file:\/\/([^)\s]+?):\d+:\d+/);
		if (url) {
			try { candidates.push(decodeURIComponent(url[1])); } catch { /* lint-exempt:URL 解码失败→原样（尽力口径） */ candidates.push(url[1]); }
		} else {
			const abs = line.match(/at:\s*\(([^)\s]+?):\d+:\d+/);
			if (abs) candidates.push(abs[1]);
		}
		if (candidates.length === 0) { opaque = true; continue; }
		for (const c of candidates) {
			if (!path.isAbsolute(c)) { hits.add(c.split(path.sep).join("/")); continue; }
			let rel: string | null = null;
			for (const base of bases) {
				const r = path.relative(base, c);
				if (r !== "" && !path.isAbsolute(r) && !r.startsWith("..")) { rel = r; break; }
			}
			if (rel === null) { opaque = true; continue; }
			hits.add(rel.split(path.sep).join("/"));
		}
	}
	return { files: [...hits].sort(), opaque };
}

/** 责任面文件集（F-02 own 写面 ∪ own 责任测试；F-04 各自追加仓内实体路径——realpath 解析后
 *  的别名目标同样视作 own，符号链接形态的责任不得经别名漂白）。 */
function responsibleFileSet(guard: BaselineScopeGuard, sourceCwd: string): Set<string> {
	const out = new Set<string>();
	let realRoot: string | null = null;
	try { realRoot = fs.realpathSync(sourceCwd); } catch { /* lint-exempt:根不可达→仅规范路径责任面 */ }
	const addWithReal = (rel: string): void => {
		out.add(rel);
		if (realRoot === null) return;
		try {
			const rp = fs.realpathSync(path.join(sourceCwd, rel));
			const realRel = path.relative(realRoot, rp);
			if (realRel !== "" && !realRel.startsWith("..") && !path.isAbsolute(realRel)) out.add(realRel.split(path.sep).join("/"));
		} catch { /* lint-exempt:断链/不可达→仅保留规范路径 */ }
	};
	for (const f of guard.ownFiles) addWithReal(f);
	for (const t of guard.responsibleTests ?? []) addWithReal(t);
	return out;
}

/** 兄弟面实体扩展（F-04 同口径：sibling 的别名目标同样可归属）。 */
function siblingFileSetOf(s: { files: readonly string[]; prefixes: readonly string[] }, sourceCwd: string): Set<string> {
	const out = new Set<string>();
	let realRoot: string | null = null;
	try { realRoot = fs.realpathSync(sourceCwd); } catch { /* lint-exempt:根不可达→规范路径归属 */ }
	for (const f of s.files) {
		out.add(f);
		if (realRoot === null) continue;
		try {
			const rp = fs.realpathSync(path.join(sourceCwd, f));
			const realRel = path.relative(realRoot, rp);
			if (realRel !== "" && !realRel.startsWith("..") && !path.isAbsolute(realRel)) out.add(realRel.split(path.sep).join("/"));
		} catch { /* lint-exempt:断链→规范路径归属 */ }
	}
	return out;
}

/** 豁免判定（B10 ②；修复轮 F-01/F-02/F-04 收紧）：own 复核一致为共同前置，之后按执行事实分型——
 *   执行失败型（exit≠0 或 timed-out）：object-changed 不得消除非零退出事实——失败定位行必须
 *   全部解析（解析不足/opaque 不豁免）、全部不在责任面（own 写面 ∪ own 责任测试 ∪ 实体路径）、
 *   且每个失败文件正归属到并行写面（无正归属不豁免——「非本任务写面」单独不构成豁免依据）；
 *   漂移型（exit=0 且未超时的 object-changed）：漂移路径全部不在责任面即可豁免（exit 0 + own
 *   复核一致 + 漂移非 own——活体口径，不要求正归属：缓存类漂移常无并行登记）。
 *  返回 null = 不豁免。 */
function evaluateSiblingInterference(
	guard: BaselineScopeGuard,
	ownBefore: Map<string, string | null>,
	sourceCwd: string,
	r: CmdResult,
	driftPaths: readonly string[] | null,
	execCwd: string,
): { exemption: CheckExemption; note: string } | null {
	if (!ownSurfaceUnchanged(guard, ownBefore, sourceCwd)) return null;
	const responsible = responsibleFileSet(guard, sourceCwd);
	const execFailed = r.timedOut || r.code !== 0;
	if (execFailed) {
		if (r.timedOut) return null; // 超时=执行事实不完整，覆盖不可信（F-01：独立排除）
		const locus = failingFilesFromLocus(`${r.stdout}\n${r.stderr}`, execCwd);
		if (locus.opaque || locus.files.length === 0) return null; // 解析不足不豁免
		if (locus.files.some((f) => responsible.has(f) || surfaceContainsRel(guard.ownFiles, guard.ownPrefixes, f))) return null;
		const unattributed = locus.files.filter((f) => !guard.siblings.some((s) => {
			const files = siblingFileSetOf(s, sourceCwd);
			return files.has(f) || surfaceContainsRel([...files], s.prefixes, f);
		}));
		if (unattributed.length > 0) return null; // 无兄弟正归属的失败不豁免（F-02）
		const attributed = locus.files.slice(0, 8).map((f) => {
			const owner = guard.siblings.find((s) => {
				const files = siblingFileSetOf(s, sourceCwd);
				return files.has(f) || surfaceContainsRel([...files], s.prefixes, f);
			});
			return `${f}（归属并行写面 ${owner!.label}）`;
		});
		const detail = `失败所涉文件均正归属并行写面：${attributed.join("；")}${locus.files.length > 8 ? ` 等 ${locus.files.length} 项` : ""}；own 写面/责任测试（含实体路径）复核一致，不在失败面`.slice(0, 600);
		return { exemption: { kind: "sibling-interference", detail }, note: `◎ sibling-interference-exempt（B10）：${detail}` };
	}
	// 漂移型：exit=0
	if (driftPaths === null || driftPaths.length === 0) return null;
	const drift = [...new Set(driftPaths)].sort();
	if (drift.some((f) => responsible.has(f) || surfaceContainsRel(guard.ownFiles, guard.ownPrefixes, f))) return null;
	const attributed = drift.slice(0, 8).map((f) => {
		const owner = guard.siblings.find((s) => {
			const files = siblingFileSetOf(s, sourceCwd);
			return files.has(f) || surfaceContainsRel([...files], s.prefixes, f);
		});
		return `${f}（${owner ? `归属并行写面 ${owner.label}` : "非本任务写面，未归属已知并行任务"}）`;
	});
	const detail = `漂移所涉文件均在非本任务写面：${attributed.join("；")}${drift.length > 8 ? ` 等 ${drift.length} 项` : ""}；own 写面 ${guard.ownFiles.length} 项文件执行前后复核一致`.slice(0, 600);
	return { exemption: { kind: "sibling-interference", detail }, note: `◎ sibling-interference-exempt（B10）：${detail}` };
}

/** runStructuredCheck 选项（见 runStructuredCheck 文档）。 */
type StructuredCheckOpts = {
		/** 命令执行注入（测试）；默认 defaultRunCmd（env 白名单 + 进程组超时杀）。 */
		runCmd?: RunCmd;
		/** mkdtemp 根（测试隔离）；缺省 os.tmpdir()。 */
		tmpDir?: string;
		/** 快照开关透传（缺省按 env：AMAGI_VERIFICATION_SNAPSHOT）。 */
		snapshotEnabled?: boolean;
		/** 复用候选（先前 StructuredCheckOutcome 的 {check, object}，可跨进程 JSON 恢复）。 */
		prior?: StructuredCheckRecord;
		/** 复用开关（缺省 checkReuseEnabled(env)）。 */
		reuseEnabled?: boolean;
		/** 捕获后、执行前注入点（测试漂移夹具 / 上层「共享树写者退出」冻结屏障——§7.1.1）。 */
		beforeExecute?: () => void;
		/** ev-20261105-8d31e3（承接 ev-20261101-bcee0f steer #4）：尽力基线内部通道——true 时
		 *  （仅 finalizer 自动探测入口设置），检查因**环境缺口不可执行**（unavailableReason 的全部
		 *  先验分支：入口工具不可定位/必要输入被排除/依赖未捕获或捕获失败/Go 离线预检失败——检查
		 *  未执行、未取得任何测试事实）把该条结果的 required 降为 false（环境缺口不阻断 settlement，
		 *  状态与原因如实保留）；其他一切（对象捕获失败 not-run、capture 期 object-changed、真实
		 *  failed/timed-out/error）required 一律保留。显式 amagi.json 声明、ev.checkSpecs 注入与直接
		 *  调用不得设置（调用方 spec.required 语义不被改写，optional 不会被改成 required）。 */
		bestEffortEnvGap?: boolean;
		/** C2-a：依赖清单建立后、依赖复制前注入点（测试依赖漂移夹具）。 */
		afterDependencyManifest?: () => void;
		/** B10（ev-20261008-eb1e27）：写面感知守卫（own 写面快照/复核 + 兄弟面归属 + 测试字典）。
		 *  提供时对已执行检查的 object-changed/failed 判定兄弟切片干扰豁免；缺省零行为变化。 */
		scopeGuard?: BaselineScopeGuard;
		/** ev-20261105-0a2e43：true = 检查结束后保留验证对象内容镜像/依赖副本/runner 缓存（调试与测试复核用）；
		 *  缺省 false——检查结束即回收大体积内容，只留 manifest/dependency-manifest/checks 日志（回执 log 回源有效）。 */
		retainObjectContent?: boolean;
	};

/**
 * 执行结构化检查（§7.2 检查执行管线：捕获对象 → （必要时拒绝执行）→ 在对象上执行 → 前后指纹
 * 复核 → CheckResult 绑定对象/策略/实际 cwd+argv/退出码/时间/日志）。
 *
 * 状态映射（七状态语义，不混淆）：
 *   passed          命令退出 0 且对象前后指纹一致（N7：必带 startedAt/endedAt/exitCode=0）；
 *   failed          命令退出码非 0（真实断言失败——超时/spawn 失败绝不归入此档）；
 *   not-run         对象模式不可建立（快照关闭且策略未显式允许 shared-tree——V1 判定面；结算 incomplete）；
 *   unavailable     对象已建立但必要输入被排除/依赖未捕获（§7.1.4），检查不可执行；
 *   timed-out       超预算被终止（是 timeout，不是断言失败/exit 非零）；
 *   error           spawn 失败（code=null 且未超时）/执行器异常/规格非法/捕获槽失败；
 *   object-changed  捕获期间源内容变化（V1 检出）或检查前后对象指纹不一致（检查修改了被验证
 *                   输入——exit 0 也不得通过，§7.1.6）。
 */
export async function runStructuredCheck(sourceCwd: string, spec: StructuredCheckSpec, opts: StructuredCheckOpts = {}): Promise<StructuredCheckOutcome> {
	const outcome = await runStructuredCheckImpl(sourceCwd, spec, opts);
	if (!opts.retainObjectContent) {
		// 回收失败只计入返回值，不影响检查结论（尽力而为；启动期清扫兜底，verification-temp-gc.ts）。
		try { await reclaimCheckArtifacts(outcome); } catch { /* lint-exempt:GC 失败不影响检查结论 */ }
	}
	return outcome;
}

async function runStructuredCheckImpl(
	sourceCwd: string,
	spec: StructuredCheckSpec,
	opts: StructuredCheckOpts,
): Promise<StructuredCheckOutcome> {
	const notes: string[] = [];
	const invalid = structuredSpecProblem(spec);
	const checkId = newCheckId(typeof spec?.id === "string" ? spec.id : "");
	const required = spec?.required === true;
	if (invalid) {
		notes.push(`规格非法: ${invalid}`);
		const check = contractChecked({ id: checkId, required, objectId: "no-object:invalid-spec", policyDigest: "invalid-spec", status: "error", argv: [...(spec?.argv ?? [])], cwd: path.resolve(sourceCwd) }, notes);
		return { check, object: null, manifest: null, captureRoot: null, executed: false, notes };
	}
	// ev-20261011-ad4513（diting F-01）：规格无预算时在策略 digest 前归一化——项目层
	// （<sourceCwd>/amagi.json evidenceTimeouts）经同一解析链（task > env > project > 默认）填入
	// spec.timeoutMs；先填后 digest 保证策略 digest 反映实际执行预算（复用判定面不失真），
	// 执行/日志/展示同源。无项目声明时解析回默认 120s——旧规格 digest 逐字节不变。
	if (spec.timeoutMs === undefined) {
		spec = { ...spec, timeoutMs: resolveEvidenceTimeouts(undefined, process.env, readProjectEvidenceTimeouts(sourceCwd)).testMs };
	}
	const policyDigest = digestCheckPolicy(spec);
	const timeoutMs = spec.timeoutMs ?? DEFAULT_EVIDENCE_TEST_TIMEOUT_MS;

	// B10（ev-20261008-eb1e27）①：写面感知选择依据披露（进检查日志/notes/详情；不进 policyDigest）。
	if (spec.selection) notes.push(`写面感知基线选择：${spec.selection.basis}`);
	// ev-20261021-54b4e3：记录实际入口与有效资源环境（env 白名单不继承宿主 NODE_OPTIONS 等——未声明即 runner 默认）。
	if (spec.entry) notes.push(`执行入口：${spec.argv.join(" ").slice(0, 160)}（来源：${spec.entry.source}${spec.entry.source === "amagi.json" ? "，项目声明" : "，探测——项目未声明 verification.testCommand；guarded 入口/资源预算须在 amagi.json 声明"}）`);
	notes.push(spec.env && Object.keys(spec.env).length > 0
		? `资源环境：${Object.entries(spec.env).map(([k, v]) => `${k}=${v}`).join(" ").slice(0, 240)}（项目声明 verification.testCommand.env）`
		: "资源环境：未声明（宿主 NODE_OPTIONS 等不继承——env 白名单；并发与堆为 runner/Node 默认）");
	// B10 ②：own 写面对象执行前快照（源树口径；结果落地前复核——own 本身被改则豁免不成立）。
	const scopeOwnBefore = opts.scopeGuard ? snapshotOwnSurfaceFiles(opts.scopeGuard, sourceCwd) : null;

	// ① 对象捕获（V1；fail-closed：mode-unavailable/object-changed/capture-error 均不产出对象；
	// C2-a：policy.dependencyMode=copy-local 时同步捕获冻结依赖——失败不阻断对象产出，② 消费）
	const captured = captureVerificationObject(sourceCwd, {
		executionPlan: { execCwd: spec.execCwd ?? ".", binDirsRel: spec.binDirsRel ?? [] },
		policy: spec.policy ?? { objectMode: "snapshot", allowSharedFallback: false },
		snapshotEnabled: opts.snapshotEnabled,
		tmpDir: opts.tmpDir,
		...(opts.afterDependencyManifest ? { afterDependencyManifest: opts.afterDependencyManifest } : {}),
	});
	if (!captured.ok) {
		const status: CheckStatus = captured.code === "mode-unavailable" ? "not-run" : captured.code === "object-changed" ? "object-changed" : "error";
		notes.push(captured.message);
		const check = contractChecked({ id: checkId, required, objectId: `no-object:${captured.code}`, policyDigest, status, argv: [...spec.argv], cwd: path.resolve(sourceCwd) }, notes);
		return { check, object: null, manifest: null, captureRoot: captured.captureRoot ?? null, executed: false, notes };
	}
	const { object, manifest, captureRoot, mode } = captured;
	const depCapture = captured.dependencyCapture ?? null;
	const depManifest = captured.dependencyManifest ?? null;
	if (depCapture?.ok) {
		notes.push(`依赖对象冻结（copy-local）：${depCapture.roots} 根依赖树 ${depCapture.files} 文件/${depCapture.symlinks} 链接/${(depCapture.bytes / 1024 / 1024).toFixed(1)}MiB（digest ${depCapture.digest.slice(0, 12)}…，${depCapture.durationMs}ms）`);
	}
	const execCwd = execCwdOf(object, spec);

	// ev-20261019-9321ad：统一命令入口解析——透明包装器（env/timeout/nice/nohup/command）逐层
	// 剥离 + realpath 识别真实工具（异名符号链接归一到真实 basename）。依赖门控（unavailableReason）、
	// GOMODCACHE 解析/离线预检、离线 env 注入、失败分类与复用拒绝共用同一份解析（与 spawn 同源：
	// cwd=execCwd、PATH=binDirs 前置）——不再各看 argv[0] 字面（`env <go> test`、异名 Go 符号链接
	// 不再绕过 go 判定面）。解析是机器状态（同预检口径，不进 policyDigest——§7.2 策略 digest 冻结
	// 为规格纯函数）。不可识别入口 fail-closed：复用一律拒绝（不能证明无对象外未冻结依赖）。
	const binDirs = spec.binDirsRel && spec.binDirsRel.length > 0
		? spec.binDirsRel.map((rel) => path.resolve(object.cwd, rel))
		: [];
	// ev-20261111-fix（diting F01/F04）：有效执行环境单一解析——受信根配置（sourceCwd，验证根）
	// 一次读取 shell.pathPrepend，入口判定与实际 spawn 消费同一份 PATH 次序（prepend → binDirs →
	// 宿主 PATH）。快照模式下不从对象内子 cwd 重读 amagi.json（对象是被验证内容，不能自定执行
	// 环境），也不无界向上搜索。机器状态，不进 policyDigest（§7.2 digest 冻结为规格纯函数）。
	const executionEnv = resolveExecutionEnv({ configRoot: sourceCwd, execDir: execCwd, binDirs });
	const commandEntry = resolveCommandEntry(spec.argv, { cwd: execCwd, binDirs, pathPrepend: executionEnv.prependDirs });
	const commandEntryNote = commandEntryNoteOf(commandEntry);
	if (commandEntryNote !== null) notes.push(commandEntryNote);
	// ev-20261111-fix（diting F02 消费点同步）：包装器剥离只认可证明的系统权威身份——本地撞名
	// env 的 recognized=false 在下方复用面 fail-closed（entry-unresolved），不再误剥后复用旧绿灯。
	//
	// ev-20261111-fix（diting F05）：argv 引用对象外/未冻结路径的检查（如 ctest --test-dir 共享
	// 构建树——manifest 不含 gitignored build，输入变化不可检测）——对象边界如实披露，先验绿灯
	// 一律禁复用（argv-outside-object），以本次真实执行为准。
	const unfrozenArgvRefs = argvUnfrozenReferences(spec.argv, object, manifest, commandEntry.toolIndex);
	if (unfrozenArgvRefs.length > 0) {
		notes.push(`检查 argv 引用对象外/未冻结路径（${unfrozenArgvRefs.slice(0, 3).join(", ")}${unfrozenArgvRefs.length > 3 ? ` 等 ${unfrozenArgvRefs.length} 项` : ""}）——验证对象不覆盖该路径内容（清单未冻结），先验结果禁复用，以本次真实执行为准（对象边界如实披露，ev-20261111-fix diting F05）`);
	}

	// ② 必要输入排除判定（§7.1.4 → unavailable；不执行）。C2-a：依赖型缺口改看真实捕获状态——
	// 仅 copy-local 且完整校验通过才解除；old none/依赖缺失/复制不全继续 unavailable。
	// ev-20261017-ece384 续：go.sum 在场的快照 go 命令先做离线预检（快照对象 cwd 上 go list -m all，
	// GOFLAGS=-mod=readonly GOPROXY=off）：模块图完备 → 解除 DEPS_REQUIRING_TOOLS 门控；环境缺失 →
	// 保持 unavailable（缓存缺失 ≠ 检查失败）。
	// ev-20261021-fix（diting F6/F8）：预检成功不再直接执行在宿主 GOMODCACHE 上——go list -m 成功
	// 不能证明源码完备，且 go test 会向宿主缓存解压写源码（F6 实证）；现在预检成功后建立**任务私有
	// 模块缓存**（prepareGoPrivateModuleCache：拷贝模块图 download 工件，执行面 GOMODCACHE=私有 +
	// GOPROXY=file:// 本地镜像，宿主缓存零写入并事后核对），私有缓存不可建立 → 保守 unavailable
	//（如实标因，不虚称根治）。预检口径与结果记 notes + 检查日志（goPreflight 字段），不进
	// policyDigest：digest 冻结为规格纯函数（§7.2 同策略同 digest），预检结果是机器状态非策略维度。
	// ev-20261111-fix（diting F01/F04）：runCmd 统一携带受信根 pathPrepend（预检/执行同源）——
	// 注入 runner 与 defaultRunCmd 都收到同一份 ExecutionEnv 投影；快照/子目录执行不丢根配置。
	const baseRunCmd = opts.runCmd ?? defaultRunCmd;
	const runCmd: RunCmd = (cmd, cwd, timeoutMs, ctx) => baseRunCmd(cmd, cwd, timeoutMs, { pathPrepend: executionEnv.prependDirs, discoveredDirs: executionEnv.discoveredDirs, ...ctx });
	const hostGoModCacheEnv = resolveHostGoModCache();
	const hostGoModCache = hostGoModCacheEnv ?? (mode === "snapshot" && commandEntry.isGo && manifest.lockFiles.includes("go.sum")
		? await resolveGoModCacheViaGoEnv(runCmd, execCwd, commandEntry.toolToken)
		: null);
	let goCache: GoModulePreflight | null = null;
	let goPrivate: GoPrivateCachePrep | null = null;
	if (mode === "snapshot" && commandEntry.isGo && manifest.lockFiles.includes("go.sum")) {
		if (!hostGoModCache) {
			goCache = { ok: false, reason: "本机 GOMODCACHE 无法解析（env 未配置且 go env GOMODCACHE 失败）——任务私有模块缓存不可建立，不猜路径", detail: "GOMODCACHE 解析失败", exitCode: null };
			notes.push(`Go 模块缓存解析失败：${goCache.reason}`);
		} else {
			goCache = await preflightGoModuleCache(runCmd, execCwd, { executable: commandEntry.toolToken, envExtra: { GOMODCACHE: hostGoModCache } });
			if (goCache.ok) {
				// F6：预检成功 → 建立任务私有缓存（拷贝而非直用宿主缓存执行）。
				goPrivate = prepareGoPrivateModuleCache(hostGoModCache, goCache.modules ?? [], { tmpDir: opts.tmpDir });
				if (!goPrivate.ok) {
					goCache = { ok: false, reason: `任务私有模块缓存不可建立（${goPrivate.reason}）——检查不可在快照上执行`, detail: goCache.detail, exitCode: goCache.exitCode };
				}
			}
			const pre = goCache.ok
				? `完备——解除依赖门控；任务私有模块缓存已建立（拷贝 ${goPrivate?.modulesCopied ?? 0} 模块工件 ${((goPrivate?.bytes ?? 0) / 1024).toFixed(0)}KiB${goPrivate?.localReplaceTargets?.length ? `；本地目录 replace ${goPrivate.localReplaceTargets.length} 项不入缓存（依赖未冻结，结果禁复用）` : ""}）`
				: `不完备——${goCache.reason ?? "缓存缺失"}`;
			notes.push(`Go 模块缓存离线预检（go list -m all，GOFLAGS=-mod=readonly GOPROXY=off GOMODCACHE=${hostGoModCache}）：${pre}（${goCache.detail}）`);
		}
	}
	const unavail = unavailableReason(manifest, spec.argv, mode, commandEntry, depCapture, goCache);
	if (unavail) {
		notes.push(unavail.reason);
		// ev-20261105-8d31e3：尽力基线降级从「仅 missingExecutable」扩到全部 unavailableReason 分支——
		// 本判定点的 unavailable 全部是「检查未执行、未取得任何测试事实」的先验环境/对象/依赖缺口
		//（必要输入被排除/依赖捕获失败/依赖未捕获/Go 预检失败/工具不可定位），对自动探测入口
		//（bestEffortEnvGap=true）一律降 required=false（不阻断 settlement，状态与原因如实保留）；
		// 真实执行结果（failed/timed-out/object-changed/error）与对象捕获失败（not-run）required 恒
		// 保留——对象不可建立/应跑未跑仍 fail-closed。调用方显式 optional 的 spec 不被改写。
		const effRequired = required && opts.bestEffortEnvGap !== true;
		if (effRequired !== required) notes.push("尽力基线（自动探测入口）：环境缺口降 required——不阻断结算，状态与原因如实保留（ev-20261101-bcee0f；ev-20261105-8d31e3 扩至全部环境缺口分支）");
		const log = writeCheckLog(captureRoot, checkId, { kind: "unavailable", checkId, objectId: object.id, policyDigest, reason: unavail.reason, argv: [...spec.argv], cwd: execCwd, ...(depCapture ? { dependencyCapture: depCapture } : {}), ...(goCache ? { goPreflight: { ok: goCache.ok, reason: goCache.reason, detail: goCache.detail, exitCode: goCache.exitCode } } : {}), at: Date.now() });
		const check = contractChecked({ id: checkId, required: effRequired, objectId: object.id, policyDigest, status: "unavailable", argv: [...spec.argv], cwd: execCwd, ...(log ? { log } : {}) }, notes);
		return { check, object, manifest, captureRoot, executed: false, ...(goPrivate?.ok && goPrivate.privateCache ? { goModuleCacheRoot: goPrivate.privateCache } : {}), ...(depCapture ? { dependencyCapture: depCapture } : {}), notes: [...notes] };
	}

	opts.beforeExecute?.();

	// ③ shared-tree 前指纹（§7.1.7 记录验证前后对象指纹；snapshot 完整性由 V1 捕获时双核对保证）
	if (mode === "shared-tree") {
		const pre = compareSourceToManifest(manifest, object.cwd);
		if (pre.changed.length > 0 || pre.missing.length > 0) {
			const detail = `检查执行前共享树与对象清单不一致（changed=[${pre.changed.slice(0, 5).join(", ")}] missing=[${pre.missing.slice(0, 5).join(", ")}]）——对象漂移，不执行检查（§7.1.7）`;
			notes.push(detail);
			const log = writeCheckLog(captureRoot, checkId, { kind: "object-changed", checkId, objectId: object.id, policyDigest, phase: "pre-check", detail, argv: [...spec.argv], cwd: execCwd, at: Date.now() });
			const check = contractChecked({ id: checkId, required, objectId: object.id, policyDigest, status: "object-changed", argv: [...spec.argv], cwd: execCwd, ...(log ? { log } : {}) }, notes);
			return { check, object, manifest, captureRoot, executed: false, ...(goPrivate?.ok && goPrivate.privateCache ? { goModuleCacheRoot: goPrivate.privateCache } : {}), notes };
		}
	}

	// ④ 复用判定（§7.2：对象/策略/实际 cwd+argv 完全一致才复用；否则重新执行）
	let verdict = checkReuseVerdict(opts.prior, { object, spec }, { reuseEnabled: opts.reuseEnabled });
	// ev-20261021-fix（diting F8）：快照 go 检查一律禁复用——对象清单只覆盖仓库内文件，外部
	// 实际依赖（GOMODCACHE 源码/工具链环境/本地 replace 目标/go.work 界外引用）未捕获未指纹化，
	// 对象/策略一致不能证明依赖未变（实证：replace 外部源码改变后仍 reused passed）。未捕获/
	// 指纹证明前禁复用，重新执行取新事实。ev-20261019-9321ad：go 判定改消费统一命令入口解析
	//（commandEntry.isGo——`env <go> test`/异名 Go 符号链接同被拦截）。
	if (verdict.ok && mode === "snapshot" && commandEntry.isGo) {
		verdict = { ok: false, reason: "go-deps-not-captured", message: "快照 go 检查依赖对象外模块缓存/本地 replace/工具链环境，未捕获指纹前禁复用先验绿灯（对象一致不证明依赖未变）——重新执行取新事实" };
	}
	// ev-20261019-9321ad：不可识别入口 fail-closed——包装器改写 PATH/清空 env/查询形态/工具
	// 不可定位且名字无法保守归类时，不能证明检查不依赖对象外未冻结依赖，禁复用先验绿灯。
	// ev-20261111-fix（diting F02）：本地撞名同名包装器（realpath 不在系统权威位置）同样
	// recognized=false → 此门拦截（不再误剥后复用旧绿灯）。
	if (verdict.ok && mode === "snapshot" && !commandEntry.recognized) {
		verdict = { ok: false, reason: "entry-unresolved", message: `命令入口不可识别（${commandEntry.problem ?? "未知"}）——不能证明检查不依赖对象外未冻结依赖，禁复用先验绿灯——重新执行取新事实` };
	}
	// ev-20261111-fix（diting F05）：argv 引用对象外/未冻结路径（ctest --test-dir 共享构建树等）
	// ——对象不覆盖真实测试输入，前后指纹/复用条件检测不到其变化，先验绿灯禁复用，重新执行
	// 取新事实（快照保证无法建立时以真实执行 + 对象边界披露替代，不只改标签）。
	if (verdict.ok && unfrozenArgvRefs.length > 0) {
		verdict = { ok: false, reason: "argv-outside-object", message: `argv 引用对象外/未冻结路径（${unfrozenArgvRefs.slice(0, 3).join(", ")}）——验证对象不含该路径内容，输入变化不可检测，禁复用先验绿灯——重新执行取新事实（对象边界见 notes）` };
	}
	if (verdict.ok && opts.prior) {
		const prior = opts.prior;
		notes.push(`复用先验结构化记录 ${prior.check.id}（对象/策略/实际 cwd+argv 一致——§7.2），未重复执行`);
		const log = writeCheckLog(captureRoot, checkId, { kind: "reuse", checkId, reusedFrom: prior.check.id, objectId: object.id, policyDigest, prior: { startedAt: prior.check.startedAt, endedAt: prior.check.endedAt, exitCode: prior.check.exitCode }, argv: [...spec.argv], at: Date.now() });
		// K1 CheckResult.log 单引用：优先保留先验执行日志（退出事实的原始凭据）；无先验日志时挂本次复用审计日志
		const check = contractChecked({
			id: checkId, required, objectId: prior.check.objectId, policyDigest, status: "passed",
			argv: [...prior.check.argv], cwd: prior.check.cwd,
			...(prior.check.startedAt !== undefined ? { startedAt: prior.check.startedAt } : {}),
			...(prior.check.endedAt !== undefined ? { endedAt: prior.check.endedAt } : {}),
			...(prior.check.exitCode !== undefined ? { exitCode: prior.check.exitCode } : {}),
			...(prior.check.log ? { log: prior.check.log } : log ? { log } : {}),
		}, notes);
		return { check, object, manifest, captureRoot, executed: false, reuse: verdict, ...(depCapture ? { dependencyCapture: depCapture } : {}), notes };
	}
	if (opts.prior) notes.push(`复用被拒（${verdict.reason}）: ${verdict.message}——重新执行`);

	// ⑤ 执行（实际 cwd/argv 即 CheckResult.cwd/argv；时间与退出码如实记录）。C1：binDirsRel
	// 相对对象根解析为 PATH 前置目录（只该次 spawn 生效，不改全局 process.env）——已在 ② 前统一
	// 解析（commandEntry 与 spawn 同源；ev-20261019-9321ad）。C2-a：copy-local
	// 依赖冻结成功时经已声明 runner 配置把缓存定向到对象外临时目录（VITEST_CACHE_DIR /
	// npm_config_cache；无可验证缓存隔离时依赖 digest 复核如实 object-changed，不全局忽略换绿）。
	let cacheRoot: string | null = null;
	let envExtra: Record<string, string> | undefined;
	if (mode === "snapshot" && depCapture?.ok) {
		try {
			cacheRoot = fs.mkdtempSync(path.join(path.dirname(captureRoot), `${path.basename(captureRoot)}-cache-`));
			envExtra = {
				VITEST_CACHE_DIR: path.join(cacheRoot, "vitest"),
				npm_config_cache: path.join(cacheRoot, "npm"),
				// ev-20261011-ad4513：jiti 编译缓存同样定向对象外——tests/helpers/jiti-loader.mjs
				// 缺省会写 <对象>/node_modules/.cache/jiti（依赖区新路径 → object-changed，实战 148 项）；
				// 识别 AMAGI_TEST_JITI_CACHE_DIR 的测试装载器（本仓及同构仓库）重定向到临时根。
				AMAGI_TEST_JITI_CACHE_DIR: path.join(cacheRoot, "jiti"),
			};
			notes.push(`runner 缓存重定向：VITEST_CACHE_DIR/npm_config_cache/AMAGI_TEST_JITI_CACHE_DIR → ${cacheRoot}（对象外临时目录；VITEST_CACHE_DIR 仅对显式读取它的项目配置生效——Vitest 自身结果缓存固定写 node_modules/.vite/vitest/<hash>/results.json，由 runner 输出边界承接，ev-20261021-ba6114）`);
		} catch { /* 缓存目录创建失败：不注入 env，依赖 digest 复核兑底（如实 object-changed） */ }
	}
	// ev-20261017-ece384 续：快照上 go 命令注入只读离线执行环境（GO_OFFLINE_ENV：覆盖式注入，
	// 不与用户 GOFLAGS 合并——-mod=mod 会改写对象内 go.mod/go.sum → object-changed；GOPROXY/
	// GOSUMDB/GOTOOLCHAIN 禁网络与工具链下载）。无 go.sum（stdlib-only）同样注入——口径统一，
	// 杜绝快照检查意外联网。GOMODCACHE 显式钉住（预检与执行同一缓存，见 ② 注释）；GOCACHE 不重
	// 定向——构建缓存写入在对象外本机缓存区（不触 §7.1.6），预热可复用。口径记录于 notes +
	// 检查日志（goOfflineEnv 字段），不进 policyDigest（同 ② 预检口径说明）。
	// ev-20261021-fix（diting F6）：GOMODCACHE 不再钉宿主缓存——统一钉任务私有缓存目录
	//（有外部模块=prepareGoPrivateModuleCache 的拷贝镜像 + GOPROXY=file:// 本地镜像，允许 go 从
	// 本地 zip 副本解压写入私有缓存；无外部模块=空私有目录，任何意外获取在 GOPROXY=off 下失败），
	// 宿主缓存零写入（执行前后经快照面核对，差异如实上报）。GOCACHE 不重定向——构建缓存写入在
	// 对象外本机缓存区（不触 §7.1.6），预热可复用。
	let goOffline = false;
	let goCacheSurfaceBefore: GoCacheSurface | null = null;
	let goExecCacheEnv: Record<string, string> = {};
	if (mode === "snapshot" && commandEntry.isGo) {
		let execModCache: string;
		if (goPrivate?.ok && goPrivate.privateCache) {
			execModCache = goPrivate.privateCache;
			goExecCacheEnv = { GOMODCACHE: execModCache, GOPROXY: pathToFileURL(path.resolve(execModCache, "cache", "download")).href };
		} else {
			// stdlib-only（无 go.sum）或未建镜像：空私有目录 + GOPROXY=off（意外获取失败不开网）。
			try { execModCache = fs.mkdtempSync(path.join(opts.tmpDir ?? os.tmpdir(), "amagi-gomod-empty-")); }
			catch { execModCache = ""; /* lint-exempt:空缓存目录创建失败时退回 GOPROXY=off（意外获取显式失败不开网） */ }
			goExecCacheEnv = execModCache ? { GOMODCACHE: execModCache } : {};
		}
		envExtra = { ...(envExtra ?? {}), ...GO_OFFLINE_ENV, ...goExecCacheEnv };
		goOffline = true;
		if (hostGoModCache) goCacheSurfaceBefore = snapshotGoCacheSurface(hostGoModCache);
		notes.push(`Go 离线执行环境注入：GOFLAGS=-mod=readonly GOPROXY=${goExecCacheEnv.GOPROXY ?? "off"} GOSUMDB=off GOTOOLCHAIN=local GOENV=off${goExecCacheEnv.GOMODCACHE ? ` GOMODCACHE=${goExecCacheEnv.GOMODCACHE}（任务私有缓存，宿主缓存零写入）` : ""}——不安装、不联网；file:// 仅本地 zip 副本镜像（ev-20261021-fix diting F6）`);
	}
	// ev-20261021-54b4e3：声明资源环境先铺底，harness 隔离注入（缓存重定向/Go 离线）后覆盖——保留键读取时已拒，双保险。
	if (spec.env && Object.keys(spec.env).length > 0) envExtra = { ...spec.env, ...(envExtra ?? {}) };
	const execCtx = { ...(binDirs.length > 0 ? { binDirs } : {}), ...(envExtra ? { envExtra } : {}) };
	const startedAt = Date.now();
	let r: CmdResult;
	try {
		r = await runCmd([...spec.argv], execCwd, timeoutMs, Object.keys(execCtx).length > 0 ? execCtx : undefined);
	} catch (e) {
		r = { ok: false, stdout: "", stderr: `执行器异常: ${e instanceof Error ? e.message : String(e)}`, code: null, timedOut: false, durationMs: Date.now() - startedAt };
	}
	const endedAt = Date.now();

	// ⑥ 后指纹复核（§7.1.6：检查修改被验证输入 → object-changed，exit 0 也不得通过）。
	// C2-a：snapshot 副本改用 verifyCapturedObject 单口径——源码区 digest + 依赖区
	// digest/链接文本 + 清单外新路径（检查期间写入的测试产物/runner 缓存全部入 unexpected，
	// 不全局忽略任何目录换绿）。shared-tree 保持源树前后对照（现状口径，§7.1.7）。
	let status: CheckStatus;
	// B10（ev-20261008-eb1e27）②：对象漂移路径集（object-changed 分支记录，豁免判定输入）。
	let objectDriftPaths: readonly string[] | null = null;
	if (mode === "snapshot") {
		const post = verifyCapturedObject(object.cwd, manifest, depManifest);
		// ev-20261021-ba6114：runner 输出边界——源侧既有结果缓存照常冻结为输入（检查在真实输入上运行）；
		// 检查期写出/就地改写且内容形态校验通过的结果缓存不计输入漂移（逐项透出，不靠目录忽略换绿）；
		// 形态不符/删除/同目录其它写出仍计漂移。
		if (post.runnerOutputs.length > 0) {
			const ps = post.runnerOutputs.map((o) => o.path);
			notes.push(`runner 输出边界：检查期写出 ${ps.length} 项结果缓存经形态校验归输出不计漂移（${ps.slice(0, 4).join(", ")}${ps.length > 4 ? " …" : ""}；源侧既有缓存已照常冻结为输入）（ev-20261021-ba6114）`);
		}
		// ev-20260930-91f621（diting F-01 修正）：良性 runner 产物（缓存/coverage/tsbuildinfo 形态）只做
		// 信息性分组展示供 Leader 据实裁决（accept 时 waive 有判据，不再每次深挖）——**不豁免判定**：
		// 目录前缀无法证明文件不可被 runner 加载换绿（实测检查命令可在 coverage/ 下生成 .cjs 并 require），
		// §7.1.6 换绿防线对全部 unexpected 保持 ✗（exit 0 也不得通过）。
		if (post.benignArtifacts.length > 0) {
			const byLabel = new Map<string, string[]>();
			for (const b of post.benignArtifacts) {
				const list = byLabel.get(b.label) ?? [];
				list.push(b.path);
				byLabel.set(b.label, list);
			}
			const summary = [...byLabel.entries()].map(([label, ps]) => `${label}×${ps.length}（${ps.slice(0, 4).join(", ")}${ps.length > 4 ? " …" : ""}）`).join("；");
			notes.push(`unexpected 中含 ${post.benignArtifacts.length} 项良性 runner 产物形态（可再生状态，据实裁决参考）：${summary}——仍计入对象漂移（形态无法证明不可被加载换绿），accept 时如确认检查未生成可加载代码可 waive 本项（ev-20260930-91f621）`);
		}
		if (post.changed.length > 0 || post.missing.length > 0 || post.unexpected.length > 0) {
			status = "object-changed";
			objectDriftPaths = [...post.changed, ...post.missing, ...post.unexpected];
			notes.push(`检查修改了被验证输入（changed ${post.changed.length} 项=[${post.changed.slice(0, 8).join(", ")}] missing ${post.missing.length} 项=[${post.missing.slice(0, 8).join(", ")}] unexpected ${post.unexpected.length} 项=[${post.unexpected.slice(0, 8).join(", ")}]）——对象漂移，不能以 exit ${r.code ?? "?"} 通过（§7.1.6/C2：全部 unexpected 严格计入，不忽略换绿；良性形态分组见上注）`);
		} else if (r.timedOut) {
			status = "timed-out";
			notes.push(`超预算（${timeoutMs} ms）已终止——是 timeout，不是测试断言失败/exit 非零`);
		} else if (r.code === null) {
			status = "error";
			notes.push(`spawn/执行失败（无退出码）: ${r.stderr.trim().split("\n").slice(-3).join(" ").slice(0, 160)}`);
		} else {
			status = r.code === 0 ? "passed" : "failed";
		}
	} else {
		const post = compareSourceToManifest(manifest, object.cwd);
		if (post.changed.length > 0 || post.missing.length > 0) {
			status = "object-changed";
			objectDriftPaths = [...post.changed, ...post.missing];
			notes.push(`检查修改了被验证输入（changed=[${post.changed.slice(0, 5).join(", ")}] missing=[${post.missing.slice(0, 5).join(", ")}]）——对象漂移，不能以 exit ${r.code ?? "?"} 通过（§7.1.6）`);
		} else if (r.timedOut) {
			status = "timed-out";
			notes.push(`超预算（${timeoutMs} ms）已终止——是 timeout，不是测试断言失败/exit 非零`);
		} else if (r.code === null) {
			status = "error";
			notes.push(`spawn/执行失败（无退出码）: ${r.stderr.trim().split("\n").slice(-3).join(" ").slice(0, 160)}`);
		} else {
			status = r.code === 0 ? "passed" : "failed";
		}
	}
	// C2-a：依赖已冻结（copy-local 完整校验通过）的对象上出现「命令找不到/模块缺失」特征 →
	// 环境捕获不完备而非断言失败（与 v2.4 P3-7 快照链同口径）——如实 unavailable，不误报 failed。
	if (status === "failed" && mode === "snapshot" && depCapture?.ok
			&& /(command not found|cannot find module|module_not_found|no such file or directory)/i.test(`${r.stdout}\n${r.stderr}`)) {
		status = "unavailable";
		notes.push(`冻结对象内环境依赖缺失特征（command not found/cannot find module）——环境捕获不完备，非任务断言失败；如实 unavailable，不猜成功也不误诊 failed（v2.4 P3-7 同口径）\n  ${(r.stderr || r.stdout).split("\n").filter(Boolean).slice(-3).join("\n  ") || "（无输出）"}`);
	}
	// ev-20261017-ece384 续 + ev-20261021-fix（diting F7）：离线环境（⑤ 注入面）下 go 的模块/
	// 锁文件/工具链 **setup 诊断** → unavailable（环境缺失 ≠ 检查失败）。分类器只认 go 工具链专属
	// 字符串且真实测试失败（--- FAIL / 无 [setup failed] 后缀的 FAIL 行）优先保留 failed——被测程序
	// 自身输出（dial tcp 等网络错误）不统归 unavailable。仅限快照注入面（goOffline）：shared-tree
	// 运行用户真实环境，联网/锁更新是用户可自行修复的正常失败，不改判。
	if (status === "failed" && mode === "snapshot" && commandEntry.isGo && goOffline) {
		const goEnvLabel = goToolchainSetupFailureLabel(`${r.stdout}\n${r.stderr}`);
		if (goEnvLabel) {
			status = "unavailable";
			notes.push(`Go 离线执行环境缺失特征（${goEnvLabel}）——模块缓存/锁文件不完备，非任务断言失败；如实 unavailable，不猜成功也不误诊 failed（环境缺失 ≠ 检查失败，ev-20261021-fix diting F7）\n  ${(r.stderr || r.stdout).split("\n").filter(Boolean).slice(-3).join("\n  ") || "（无输出）"}`);
		}
	}
	// ev-20261021-fix（diting F6）：宿主模块缓存零写入事后核对——执行面 GOMODCACHE 已钉任务私有
	// 缓存，此处对宿主缓存面做前后比对（新增/移除/mtime 变化），差异或不可核对均如实入 notes。
	if (goOffline && goCacheSurfaceBefore && hostGoModCache) {
		const after = snapshotGoCacheSurface(hostGoModCache);
		const diff = diffGoCacheSurface(goCacheSurfaceBefore, after);
		if (!diff.comparable) notes.push(`宿主模块缓存零写入核对：不可判定（缓存面过大/快照失败，${hostGoModCache}）——隔离承诺未经事后核实，如实披露（写入防护仍由 GOMODCACHE=私有缓存钉死承担）`);
		else if (diff.added.length || diff.removed.length || diff.changed.length) notes.push(`⚠ 宿主模块缓存检测到变化（added ${diff.added.length}=[${diff.added.slice(0, 4).join(", ")}] removed ${diff.removed.length} changed ${diff.changed.length}=[${diff.changed.slice(0, 4).join(", ")}]，${hostGoModCache}）——与「宿主缓存零写入」承诺不符，请核查（可能为并行 go 进程写入；不静默忽略）`);
		else notes.push(`宿主模块缓存递归元数据核对：未检测到变化（${hostGoModCache}；不证明内容字节未变或期间从未写入）`);
	}
	// （有退出事实）的 object-changed（对象漂移）与 failed（测试失败）判定：own 写面对象
	// 执行前后未变，且漂移/失败所涉文件全部不在本任务 own 写面 → 判 sibling-interference-exempt
	//（status 保持真实不改写；豁免进 CheckResult.exemption，结算面据此不落 missing/failed，
	// 回执与详情显式披露依据）。任一失败/漂移落在本任务写面 → 维持现有失败语义；捕获失败/
	// 执行前漂移/超时/spawn 错误不豁免（无本任务覆盖事实，不得伪造覆盖）。
	let exemption: CheckExemption | undefined;
	if (opts.scopeGuard && scopeOwnBefore !== null && (status === "object-changed" || status === "failed") && Number.isInteger(r.code)) {
		const verdictB10 = evaluateSiblingInterference(opts.scopeGuard, scopeOwnBefore, sourceCwd, r, objectDriftPaths, execCwd);
		if (verdictB10) {
			exemption = verdictB10.exemption;
			notes.push(verdictB10.note);
		}
	}

	const log = writeCheckLog(captureRoot, checkId, {
		kind: "execute", checkId, objectId: object.id, objectMode: mode, policyDigest,
		argv: [...spec.argv], cwd: execCwd, status, startedAt, endedAt,
		exitCode: r.code, signal: r.signal ?? null, timedOut: r.timedOut, durationMs: r.durationMs,
		stdout: r.stdout, stderr: r.stderr, notes: notes.slice(),
		...(depCapture ? { dependencyDigest: depCapture.ok ? depCapture.digest : null, dependencyCapture: depCapture } : {}),
		...(cacheRoot ? { cacheRoot } : {}),
		...(goCache ? { goPreflight: { ok: goCache.ok, reason: goCache.reason, detail: goCache.detail, exitCode: goCache.exitCode } } : {}),
		...(goOffline ? { goOfflineEnv: { ...GO_OFFLINE_ENV, ...goExecCacheEnv } } : {}),
		...(exemption ? { exemption } : {}),
	});
	const check = contractChecked({
		id: checkId, required, objectId: object.id, policyDigest, status,
		argv: [...spec.argv], cwd: execCwd, startedAt, endedAt,
		...(Number.isInteger(r.code) ? { exitCode: r.code as number } : {}),
		...(log ? { log } : {}),
		...(exemption ? { exemption } : {}),
	}, notes);
	return {
		check, object, manifest, captureRoot, executed: true, reuse: verdict,
		...(depCapture ? { dependencyCapture: depCapture } : {}),
		...(cacheRoot !== null ? { cacheRoot } : {}),
		...(goExecCacheEnv.GOMODCACHE ? { goModuleCacheRoot: goExecCacheEnv.GOMODCACHE } : {}),
		...(spec.selection ? { selection: spec.selection } : {}),
		...(exemption ? { exemption } : {}),
		notes,
	};
}

// ── V2 §7 头段：缺机器检查任务的结算判定面（产物完整性 + 人工验收条件，不伪造机器检查） ──

/** 产物完整性事实（缺机器检查任务的机器可查部分：存在/可读/非空/内容指纹——非需求正确性）。 */
export interface ArtifactIntegrityItem {
	/** 声明路径（原样，调用方口径）。 */
	path: string;
	abs: string;
	ok: boolean;
	kind?: "file" | "dir";
	bytes?: number;
	/** 工作树字节 SHA-256（kind=file 且可读时）。 */
	digest?: string;
	problem?: "missing" | "unreadable" | "empty" | "empty-dir" | "not-regular-file";
}

/** 产物完整性检查：声明交付产物逐项核查（stat 跟随 symlink；缺失/不可读/空产物如实记 problem）。 */
export function inspectArtifactIntegrity(cwd: string, declaredOutputs: readonly string[]): ArtifactIntegrityItem[] {
	return declaredOutputs.map((p) => {
		const abs = path.resolve(cwd, p);
		let st: fs.Stats;
		try {
			st = fs.statSync(abs);
		} catch {
			return { path: p, abs, ok: false, problem: "missing" as const };
		}
		if (st.isDirectory()) {
			let n = 0;
			try {
				n = fs.readdirSync(abs).length;
			} catch {
				return { path: p, abs, ok: false, kind: "dir" as const, problem: "unreadable" as const };
			}
			return n > 0 ? { path: p, abs, ok: true, kind: "dir" as const } : { path: p, abs, ok: false, kind: "dir" as const, problem: "empty-dir" as const };
		}
		if (!st.isFile()) return { path: p, abs, ok: false, problem: "not-regular-file" as const };
		try {
			const buf = fs.readFileSync(abs);
			if (buf.length === 0) return { path: p, abs, ok: false, kind: "file" as const, bytes: 0, problem: "empty" as const };
			return { path: p, abs, ok: true, kind: "file" as const, bytes: buf.length, digest: createHash("sha256").update(buf).digest("hex") };
		} catch {
			return { path: p, abs, ok: false, kind: "file" as const, problem: "unreadable" as const };
		}
	});
}

/** 结算判定面输入（K7 finalizer V3 接线消费；本片导出结构化结果）。 */
export interface SettlementFaceInput {
	/** 本片产出的结构化检查结果集（可空——缺机器检查任务不伪造）。 */
	checks?: readonly CheckResult[];
	/** 应跑而未产出结构化事实的必要检查 id（K7 同名概念，如实缺口）。 */
	missing?: readonly string[];
	/** 声明交付产物（相对 cwd 路径；缺机器检查任务的产物完整性检查输入）。 */
	declaredOutputs?: readonly string[];
	/** declaredOutputs 解析基准；提供 declaredOutputs 时必填（缺省记缺口）。 */
	cwd?: string;
	/** 人工验收条件（criteria 摘录；由人裁决——不伪造机器检查，acceptance 面归 V3）。 */
	manualAcceptance?: readonly string[];
}

export interface SettlementFace {
	settlement: "ready" | "failed" | "incomplete";
	/** 如实缺口（必要检查非确定绿 / 应跑未跑 / 产物完整性问题 / 无机器检查任务缺验收面）。 */
	missing: string[];
	/** 产物完整性事实（declaredOutputs 提供时）。 */
	artifacts: readonly ArtifactIntegrityItem[];
	/** 人工验收条件（过滤空串后透传——供人工裁决，非机器判定）。 */
	manualAcceptance: readonly string[];
	/** 机器面摘要（真实计数；展示用）。 */
	summary: string;
}

/** 非确定绿状态（不能作为 ready 依据；failed 单独归 failed 结算）。 */
const NON_DEFINITIVE_STATUSES: readonly CheckStatus[] = ["not-run", "unavailable", "timed-out", "error", "object-changed"];

/**
 * 结算判定面（§7.2/§7 头段；纯函数，K7 finalizer V3 接线）：
 *   - required 检查 failed → settlement=failed；
 *   - 任一缺口（missing 输入 / required 非确定绿 / 产物完整性问题 / 无机器检查任务缺产物或验收面）
 *     → incomplete（不强行绿灯）；
 *   - 有机器检查且全 passed 无缺口 → ready（机器面完成；代码检查通过不证明需求完整——人工核对
 *     归 acceptance 面）；无机器检查任务：产物完整性全绿 + 人工验收条件已列明 → ready
 *     （不伪造机器检查——机器面如实为「无」）。
 */
export function deriveSettlementFace(input: SettlementFaceInput): SettlementFace {
	const checks = [...(input.checks ?? [])];
	const missing = [...(input.missing ?? [])];
	const manualAcceptance = (input.manualAcceptance ?? []).filter((s) => typeof s === "string" && s.trim() !== "");
	let artifacts: ArtifactIntegrityItem[] = [];
	if (input.declaredOutputs !== undefined) {
		if (typeof input.cwd !== "string" || input.cwd === "") {
			missing.push("artifact-integrity:cwd-missing");
		} else {
			artifacts = inspectArtifactIntegrity(input.cwd, input.declaredOutputs);
			for (const a of artifacts) if (!a.ok) missing.push(`artifact-integrity:${a.path}:${a.problem}`);
		}
	}
	// B10（ev-20261008-eb1e27，主上裁定②）：豁免检查（exemption=sibling-interference）不进
	// failed/missing——漂移/失败所涉文件均不在本任务写面且 own 复核一致（判定见
	// runStructuredCheck/evaluateSiblingInterference）；status 保持真实，summary 披露豁免计数。
	const exempted = checks.filter((c) => c.exemption !== undefined);
	const requiredFailed = checks.filter((c) => c.required && c.status === "failed" && c.exemption === undefined);
	// D1（ev-20260922-c896f8）：机器检查缺口只 push 纯 c.id（不得拼 `${id}:${status}`）——
	// 状态原位保存在 CheckResult.status，由 summary 渲染；回执引用面单一 id 口径。
	const requiredNonDefinitive = checks.filter((c) => c.required && NON_DEFINITIVE_STATUSES.includes(c.status) && c.exemption === undefined);
	for (const c of requiredNonDefinitive) missing.push(c.id);
	let settlement: SettlementFace["settlement"];
	if (requiredFailed.length > 0) settlement = "failed";
	else if (missing.length > 0) settlement = "incomplete";
	else if (checks.length > 0) settlement = "ready";
	else {
		if (input.declaredOutputs === undefined) missing.push("artifact-integrity:not-declared");
		if (manualAcceptance.length === 0) missing.push("manual-acceptance:not-declared");
		settlement = missing.length > 0 ? "incomplete" : "ready";
	}
	const passedCount = checks.filter((c) => c.status === "passed").length;
	const artSeg = artifacts.length > 0 ? `；产物完整性 ${artifacts.filter((a) => a.ok).length}/${artifacts.length}` : "";
	const manSeg = manualAcceptance.length > 0 ? `；人工验收条件 ${manualAcceptance.length} 项待人工裁决` : "";
	// D1：summary 渲染 required 非确定绿的 id+status（展示面拼接，机器引用面只认 missing 里的纯 id）。
	const nonDefSeg = requiredNonDefinitive.length > 0
		? `；required 未定绿 ${requiredNonDefinitive.length} 项（${requiredNonDefinitive.slice(0, 5).map((c) => `${c.id}=${c.status}`).join("、")}${requiredNonDefinitive.length > 5 ? "…" : ""}）`
		: "";
	// ev-20261101-bcee0f：非 required 检查的非确定绿（自动探测尽力基线的环境缺口 unavailable 等）
	// 不进 missing（不阻断 settlement），但状态如实——summary 展示面披露（不假通过、可见可核）。
	const bestEffortNonDefinitive = checks.filter((c) => !c.required && NON_DEFINITIVE_STATUSES.includes(c.status) && c.exemption === undefined);
	const bestEffortSeg = bestEffortNonDefinitive.length > 0
		? `；尽力基线未定绿 ${bestEffortNonDefinitive.length} 项（${bestEffortNonDefinitive.slice(0, 5).map((c) => `${c.id}=${c.status}`).join("、")}${bestEffortNonDefinitive.length > 5 ? "…" : ""}；环境缺口如实保留，不阻断结算）`
		: "";
	// B10：豁免计数与依据披露（summary 展示面；机器引用面不受影响）。
	const exemptSeg = exempted.length > 0
		? `；sibling-interference 豁免 ${exempted.length} 项（${exempted.slice(0, 3).map((c) => c.id).join("、")}${exempted.length > 3 ? "…" : ""}）`
		: "";
	const summary = checks.length > 0
		? `机器检查 ${passedCount}/${checks.length} passed${requiredFailed.length > 0 ? `（required failed ${requiredFailed.length}）` : ""}${nonDefSeg}${bestEffortSeg}${exemptSeg}${artSeg}${manSeg}`
		: `无机器检查（不伪造）${artSeg}${manSeg}`;
	return { settlement, missing: [...new Set(missing)], artifacts, manualAcceptance, summary };
}

// ── C15（设计 §6.5）：进程内 advisory 展示注记——与机器检查证据同文件明示语义边界 ──

/** advisory 注记行前缀（稳定标识；检索/测试引用）。 */
export const ADVISORY_NOTE_LABEL = "[in-process advisory]";
/** advisory 解释正文入注记的长度上限（字符；超出尾部裁剪并标注）。 */
export const ADVISORY_NOTE_TEXT_CAP = 1200;

export interface AdvisoryEvidenceNoteInput {
	/** 调用层实现标识（mock-advisory / host-stream）。 */
	callerId: string;
	/** 显式物理模型名。 */
	modelRef: string;
	/** 提示版本（promptVersion 事实字段）。 */
	promptVersion: string;
	/** 解释正文（advisory 通道输出）。 */
	text: string;
	usageStatus: "reported" | "unknown";
}

/**
 * 渲染 advisory 展示注记行（finalizer 拼入收尾正文尾部）。证据面明示义务（设计 §6.5「模块/入侵面」：
 * evidence 标明非机器验证结论）：恒携带「非机器验证结论，不参与 settlement/acceptance」标注与
 * 通道/模型/提示版本溯源——机器检查证据（checks/settlement）与模型解释永不混淆。纯展示行：
 * 不写 TaskReceipt/TaskSpec 新字段，不进三轴判定（纪律红线）。
 */
export function renderAdvisoryEvidenceNote(input: AdvisoryEvidenceNoteInput): string {
	const text = input.text.trim();
	const clipped = text.length > ADVISORY_NOTE_TEXT_CAP ? `${text.slice(0, ADVISORY_NOTE_TEXT_CAP)}…[advisory-clipped]` : text;
	return `${ADVISORY_NOTE_LABEL}（${input.callerId} · ${input.modelRef} · ${input.promptVersion}）机器检查解释（advisory 通道输出——非机器验证结论，不参与 settlement/acceptance 判定，仅供 Leader 参考）：${clipped}｜usage: ${input.usageStatus}`;
}

// ── C14（十月迭代 M4，设计 §6.4/F6 终局）：图像产物证据条目 v2（限域解码事实；机器不记视觉/格式符合性判断） ──
// 生图产物作为参考证据入链：路径 + digest + 生成参数摘要 + 宿主解码观测（image-decoder.ts 联合类型）。
// F6 终局语义：amagi 证明产物存在、字节数与 digest 一致，并记录「指定宿主解码器在指定范围内成功」
// 的限域事实（scope=host-primary-raster：宿主实际加载的主栅格及显示尺寸）——完整格式符合性
// （formatConformance）与视觉有效性（visualValidity）恒 not-assessed：前者属解码器规范裁决
// （宿主容错接受≠规范合法），后者由 luoshen/人工确认。base64 图像数据不入本条目。
// 历史兼容（设计 §6）：新写仅 v2；已存在 v1 文件不覆写、不回填 passed——读取时经
// imageEvidenceDecodeProjection 投影为 decode=not-assessed/legacy-no-proof（尺寸视为历史未核
// 声明），不得满足新严格成功判据；需重新证明时以新检查时间/宿主版本另建 v2 条目，原条目保留。

/** 视觉有效性口径声明（条目消费方展示必附；luoshen/人工确认，机器不代判）。 */
export const IMAGE_VISUAL_VALIDITY_NOTE =
	"视觉有效性不在机器证据面——由 luoshen/人工确认（机器只记录宿主主栅格解码事实，不做视觉判断）；完整格式符合性同样恒 not-assessed（F6 终局：不声明格式规范正确）";

/** 宿主解码观测证据形状（结构镜像 image-decoder.ts ImageDecodeObservation——本模块保持零运行时依赖，字面量口径注释锚定）。 */
export interface ImageDecodeEvidencePassed {
	status: "passed";
	backend: "pi-coding-agent.resizeImage";
	hostVersion: string;
	policyVersion: "host-primary-raster-v1";
	inputSha256: string;
	scope: "host-primary-raster";
	width: number;
	height: number;
	dimensionBasis: "host-oriented-raster";
}

export interface ImageDecodeEvidenceNotAssessed {
	status: "not-assessed";
	reason:
		| "unsupported-format"
		| "mime-signature-mismatch"
		| "backend-unavailable"
		| "host-version-unverified"
		| "no-decode-proof"
		| "timeout"
		| "cancelled"
		| "invalid-backend-result"
		| "legacy-no-proof";
}

export type ImageDecodeEvidence = ImageDecodeEvidencePassed | ImageDecodeEvidenceNotAssessed;

/** 图像产物证据条目 v2（image-generation.ts runImageGeneration 产出；快照/回执面可 JSON 序列化）。 */
export interface ImageEvidenceEntry {
	formatVersion: 2;
	kind: "image-artifact";
	/** 归因 taskId（artifact 归档目录同名 sanitizeId）。 */
	taskId: string;
	/** 归因角色（如 luoshen/leader）。 */
	agent: string;
	/** 适配器来源（mock=机制验证；host=宿主 generateImages）。 */
	adapter: string;
	modelRef: string;
	/** prompt sha256（原文不入证据——有界且去敏）。 */
	promptDigest: string;
	/** 参考图 sha256 列表（引用输入来源可追溯——设计 §6.4）。 */
	referenceDigests: readonly string[];
	/** 产物绝对路径。 */
	path: string;
	bytes: number;
	/** 产物字节 sha256（落盘回读后计；decode passed 时必须等于 decode.inputSha256——字节绑定）。 */
	sha256: string;
	/** 原始产物的规范化声明 MIME（非宿主检测值——resize 的 mimeType 可能是输入 echo 或输出格式，不可当 detected MIME）。 */
	mimeType: string;
	/** 恒 "adapter-declared"。 */
	mimeSource: "adapter-declared";
	/** 严格生图成功恒 "signature-matched"（仅说明固定签名前缀一致——不构成格式正确证明）。 */
	mimeConsistency: "signature-matched";
	/** decode passed 时从宿主观测复制（正 safe integer；不从模型/mock 声明优先取值）。 */
	width?: number;
	height?: number;
	/** decode passed 时恒 "host-oriented-raster"（方向处理后主栅格尺寸——非原容器存储尺寸）。 */
	dimensionBasis?: "host-oriented-raster";
	/** 宿主解码观测（passed.inputSha256 必须等于本条目 sha256）。 */
	decode: ImageDecodeEvidence;
	generatedAt: number;
	/** 用量摘要（costKnown=false 表示 provider 未上报费用——如实 unknown，不伪造 0）。 */
	usage?: { inputTokens?: number; outputTokens?: number; totalTokens?: number; costUsd?: number; costKnown: boolean };
	/** 恒 "not-assessed"——机器不声明完整格式规范符合性（F6 终局撤回该承诺）。 */
	formatConformance: "not-assessed";
	/** 恒 "not-assessed"——机器不伪造视觉判断（见 IMAGE_VISUAL_VALIDITY_NOTE）。 */
	visualValidity: "not-assessed";
}

const HEX64_RE = /^[0-9a-f]{64}$/;

/** 构造图像证据条目 v2（纯函数；formatConformance/visualValidity 强制 not-assessed——调用方无法
 *  宣称格式/视觉结论；decode passed 时 width/height 恒取宿主观测且 digest 必须字节绑定，否则抛错）。 */
export function buildImageEvidenceEntry(input: {
	taskId: string;
	agent: string;
	adapter: string;
	modelRef: string;
	promptDigest: string;
	referenceDigests?: readonly string[];
	path: string;
	bytes: number;
	sha256: string;
	mimeType: string;
	generatedAt: number;
	usage?: { inputTokens?: number; outputTokens?: number; totalTokens?: number; costUsd?: number; costKnown: boolean };
	decode: ImageDecodeEvidence;
}): ImageEvidenceEntry {
	if (input.decode.status === "passed" && input.decode.inputSha256 !== input.sha256) {
		throw new Error(
			`decode.inputSha256 与条目 sha256 不一致（字节绑定破坏：probe ${input.decode.inputSha256.slice(0, 12)}… vs 条目 ${input.sha256.slice(0, 12)}…）——禁止签发`,
		);
	}
	return {
		formatVersion: 2,
		kind: "image-artifact",
		taskId: input.taskId,
		agent: input.agent,
		adapter: input.adapter,
		modelRef: input.modelRef,
		promptDigest: input.promptDigest,
		referenceDigests: [...(input.referenceDigests ?? [])],
		path: input.path,
		bytes: input.bytes,
		sha256: input.sha256,
		mimeType: input.mimeType,
		mimeSource: "adapter-declared",
		mimeConsistency: "signature-matched",
		...(input.decode.status === "passed"
			? { width: input.decode.width, height: input.decode.height, dimensionBasis: "host-oriented-raster" as const }
			: {}),
		decode: input.decode,
		generatedAt: input.generatedAt,
		...(input.usage !== undefined ? { usage: input.usage } : {}),
		formatConformance: "not-assessed",
		visualValidity: "not-assessed",
	};
}

/** 历史条目读取投影：v1 → decode=not-assessed/legacy-no-proof（文件事实仍可展示；不得作为严格
 *  解码证明或升级为 passed——v1 不覆写不回填）；v2 → 原样返回 decode，缺场视为无证明。 */
export function imageEvidenceDecodeProjection(e: unknown): ImageDecodeEvidence {
	const v = e as Partial<ImageEvidenceEntry> | null;
	if (v && typeof v === "object" && (v as { formatVersion?: unknown }).formatVersion === 1) {
		return { status: "not-assessed", reason: "legacy-no-proof" };
	}
	const decode = (v as { decode?: unknown } | null)?.decode;
	if (
		decode !== null &&
		typeof decode === "object" &&
		((decode as { status?: unknown }).status === "passed" || (decode as { status?: unknown }).status === "not-assessed")
	) {
		return decode as ImageDecodeEvidence;
	}
	return { status: "not-assessed", reason: "no-decode-proof" };
}

/** 图像证据条目形状校验（严格消费者；返回问题描述或 null）。
 *  拒收：非法版本（v1 历史条目不作为严格解码证明——走 imageEvidenceDecodeProjection 展示）、
 *  非法 digest/尺寸/路径、非 image mime、decode 联合不自洽（passed 缺身份/scope/策略版本、
 *  inputSha256≠条目 sha256、not-assessed 携带已测尺寸）、伪造视觉/格式符合性状态。
 *  注意：形状校验不能靠对象本身证明真的调用过宿主——真实调用与持久化绑定由生产入口和集成测试证明。 */
export function imageEvidenceEntryProblem(e: unknown): string | null {
	const v = e as Partial<ImageEvidenceEntry> | null;
	if (!v || typeof v !== "object") return "条目非对象";
	if (v.formatVersion !== 2) {
		return `formatVersion 必须为 2（v1 历史条目仅可经 imageEvidenceDecodeProjection 展示为 legacy-no-proof，不升级不降写），实测 ${String(v.formatVersion)}`;
	}
	if (v.kind !== "image-artifact") return `kind 必须为 image-artifact，实测 ${String(v.kind)}`;
	for (const f of ["taskId", "agent", "adapter", "modelRef", "path", "mimeType"] as const) {
		if (typeof v[f] !== "string" || (v[f] as string).length === 0) return `${f} 必须为非空字符串`;
	}
	if (!String(v.mimeType).startsWith("image/")) return `mimeType 必须以 image/ 开头，实测 ${String(v.mimeType)}`;
	if (v.mimeSource !== "adapter-declared") return `mimeSource 恒为 adapter-declared，实测 ${String(v.mimeSource)}`;
	if (v.mimeConsistency !== "signature-matched") return `mimeConsistency 恒为 signature-matched（仅签名前缀一致），实测 ${String(v.mimeConsistency)}`;
	if (typeof v.bytes !== "number" || !Number.isFinite(v.bytes) || v.bytes <= 0) return `bytes 必须为正数，实测 ${String(v.bytes)}`;
	if (typeof v.sha256 !== "string" || !HEX64_RE.test(v.sha256)) return "sha256 必须为 64 位 hex digest";
	if (typeof v.promptDigest !== "string" || !HEX64_RE.test(v.promptDigest)) return "promptDigest 必须为 64 位 hex digest";
	if (!Array.isArray(v.referenceDigests) || v.referenceDigests.some((d) => typeof d !== "string" || !HEX64_RE.test(d))) {
		return "referenceDigests 必须为 64 位 hex digest 数组";
	}
	if (typeof v.generatedAt !== "number" || !Number.isFinite(v.generatedAt) || v.generatedAt <= 0) return "generatedAt 必须为正数时间戳";
	if (v.formatConformance !== "not-assessed") {
		return `formatConformance 恒为 not-assessed（机器不声明完整格式规范符合性——F6 终局），实测 ${String(v.formatConformance)}`;
	}
	if (v.visualValidity !== "not-assessed") {
		return `visualValidity 恒为 not-assessed（机器不伪造视觉判断，${IMAGE_VISUAL_VALIDITY_NOTE}），实测 ${String(v.visualValidity)}`;
	}
	const d = v.decode as Partial<ImageDecodeEvidence> | null | undefined;
	if (!d || typeof d !== "object") return "decode 必须为解码观测对象";
	if (d.status === "passed") {
		if (d.backend !== "pi-coding-agent.resizeImage") return `decode.backend 必须为 pi-coding-agent.resizeImage，实测 ${String(d.backend)}`;
		if (d.policyVersion !== "host-primary-raster-v1") return `decode.policyVersion 必须为 host-primary-raster-v1，实测 ${String(d.policyVersion)}`;
		if (d.scope !== "host-primary-raster") return `decode.scope 必须为 host-primary-raster，实测 ${String(d.scope)}`;
		if (typeof d.hostVersion !== "string" || d.hostVersion.length === 0) return "decode.hostVersion 必须为非空字符串";
		if (typeof d.inputSha256 !== "string" || !HEX64_RE.test(d.inputSha256)) return "decode.inputSha256 必须为 64 位 hex digest";
		if (d.inputSha256 !== v.sha256) return "decode.inputSha256 必须等于条目 sha256（字节绑定——被解码/落盘/回读/引用须为同一组字节）";
		for (const [f, val] of [["width", d.width], ["height", d.height]] as const) {
			if (typeof val !== "number" || !Number.isSafeInteger(val) || val <= 0) return `decode.${f} 必须为正 safe integer，实测 ${String(val)}`;
		}
		if (!Number.isSafeInteger(d.width! * d.height!)) return "decode.width×height 必须为 safe integer（主栅格像素乘积）";
		if (v.dimensionBasis !== "host-oriented-raster") return `decode passed 时 dimensionBasis 恒为 host-oriented-raster，实测 ${String(v.dimensionBasis)}`;
		if (v.width !== d.width || v.height !== d.height) return "条目 width/height 必须与宿主观测一致（不从模型/mock 声明优先取值）";
	} else if (d.status === "not-assessed") {
		const reasons = ["unsupported-format", "mime-signature-mismatch", "backend-unavailable", "host-version-unverified", "no-decode-proof", "timeout", "cancelled", "invalid-backend-result", "legacy-no-proof"];
		if (typeof d.reason !== "string" || !reasons.includes(d.reason)) return `decode.reason 必须为已知原因（${reasons.join("|")}），实测 ${String(d.reason)}`;
		if (v.width !== undefined || v.height !== undefined || v.dimensionBasis !== undefined) {
			return "decode not-assessed 不得携带已测尺寸/dimensionBasis（未评估不填伪尺寸）";
		}
	} else {
		return `decode.status 必须为 passed|not-assessed，实测 ${String(d.status)}`;
	}
	return null;
}
