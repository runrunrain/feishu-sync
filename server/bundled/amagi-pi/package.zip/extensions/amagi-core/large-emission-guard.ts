/**
 * large-emission-guard.ts — 大发射守卫（v2.15.0）：超长单次工具调用参数发射的防护 · 工具层与文案源。
 *
 * 实证背景（4 组定向探针 + 会话尸检闭环，勿重复取证）：amagi-glm/glm-5.3 通道在模型发射巨型
 * 工具调用参数（实测单次 write 1500+ 行 HTML ≈ 60-100KB 内容）时服务端静默 265s 无任何字节且
 * 无 `: ping` 心跳——静默 >300s 触发 undici bodyTimeout（TypeError: terminated，cause Body
 * Timeout Error），或服务端 ~135s 处硬切流；短轮/中轮全健康（600s/4.7MB 纯文本流无恙），停摆
 * 与切断均为随机性、重试可过。
 *
 * 关键机理（决定架构）：流死在**发射阶段**——工具被调到时当轮已死或已落地，纯工具闸救不了
 * 当轮。因此双层防线：
 *   - prompt 层（事前引导）：task-tool 派发子进程（effModel provider 命中时 --append-system-prompt
 *     末尾追加分节）与 leader-prompt L0 独占分节 amagi_l0_emission 注入同一行纪律文案——模型
 *     生成前就知道「单次发射 ≤ maxBytes」的规矩；
 *   - 工具层（硬闸，本模块）：write-override/edit-override execute 内超限 throw——违规企图反弹
 *     成下一轮拆段（骨架 + heredoc 追加 / edit 分段替换占位），封顶后续发射尺寸。
 *
 * 设计约束：
 * - 处方式 throw 文案写死（确定性诊断：路径/字节数/上限/通道 + 拆段步骤）；观测走 console.error
 *   单行（子进程 stderr 进任务日志，不建新日志文件）；
 * - provider 解析 execute 时惰性求值（PI_PROVIDER → PI_MODEL 的 / 前段 → 空串），不模块加载期
 *   固化；无 provider 信息一律放行（防误伤未知通道）；
 * - 配置 amagi.json `largeEmissionGuard` 分节：全局（PI_CODING_AGENT_DIR || ~/.pi/agent）打底、
 *   项目 <cwd>/amagi.json 覆盖标量；riskyProviders/skipPatterns 项目级完整替换（emoji-guard
 *   allow 同款裁定）；mtime 缓存即时生效；非法值仅忽略不抛；
 * - env 逃生舱 1/true/on 强制开、0/false/off 全关（含 prompt 层——纪律行同步缺席，整档回滚只需
 *   一个变量）；
 * - 守卫自身异常（读配置失败等）静默放行，绝不阻断正常写入路径；拦截 throw 与 write-override
 *   内 enforceFileWriteTargets 越界 throw 同语义（原生失败以 throw 表达，覆盖层不捕获不改写）；
 * - glob 自包含实现（`*` 单段、`**` 跨段；不含 / 的 pattern 按 basename 匹配——gitignore 惯例，
 *   嵌套 yarn.lock / 深层 bundle.min.js 同样豁免），不引依赖；
 * - base64/数据资产启发豁免：内容存在 ≥5000 连续字符的 [A-Za-z0-9+/=\s] 游程（锁文件快照、内嵌
 *   资源整段搬运）→ 放行——这类内容按字节发射，拆分必坏，与代码/文档类巨型生成不同。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
// B0-3（§9.2）：大发射阻断观测——只在真实阻断分支记一次（不在提示文案生成处记）；
// trace.ts 是纯观测落盘叶子模块，无反向依赖（不引入循环）。
import { writeObservation } from "./trace.ts";

// ── 配置（amagi.json `largeEmissionGuard` 节；全局+项目合并，mtime 缓存；与 emoji-guard 同模式）──

export interface LargeEmissionGuardConfig {
	enabled: boolean;
	/** 单次发射字节上限（write content / 单段 edit newText）。 */
	maxBytes: number;
	/** 风险 provider 名单（model spec 的 / 前段；未知 provider 不在名单即放行）。 */
	riskyProviders: string[];
	/** 豁免路径模式（glob；不含 / 按 basename）。 */
	skipPatterns: string[];
}

const DEFAULT_RISKY_PROVIDERS = ["amagi-glm"] as const;
const DEFAULT_SKIP_PATTERNS = ["*.lock", "*.min.js", "*.min.css", "dist/**", "node_modules/**", "*.snap"] as const;

const LARGE_EMISSION_GUARD_DEFAULTS: LargeEmissionGuardConfig = {
	enabled: true,
	maxBytes: 24576,
	riskyProviders: [...DEFAULT_RISKY_PROVIDERS],
	skipPatterns: [...DEFAULT_SKIP_PATTERNS],
};

/** base64/数据资产启发豁免：≥5000 连续字符的 [A-Za-z0-9+/=\s] 游程。 */
const BASE64_RUN_RE = /[A-Za-z0-9+/=\s]{5000,}/;

function globalAmagiConfigPath(): string {
	const agentDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi.json");
}

const configCache = new Map<string, { stamp: string; cfg: LargeEmissionGuardConfig }>();

let injectedConfig: LargeEmissionGuardConfig | null = null;

/** 测试注入：绕过读盘直接固定配置（null 恢复读盘路径）。 */
export function _setLargeEmissionGuardConfigForTest(cfg: LargeEmissionGuardConfig | null): void {
	injectedConfig = cfg;
	configCache.clear();
}

/** 测试/外部复位缓存。 */
export function resetLargeEmissionGuardConfigCache(): void {
	configCache.clear();
}

function readSection(file: string): Record<string, unknown> | null {
	try {
		const json = JSON.parse(fs.readFileSync(file, "utf8"));
		return (json && typeof json === "object" && "largeEmissionGuard" in json) ? (json.largeEmissionGuard as Record<string, unknown>) : null;
	} catch { /* lint-exempt:配置不可读按缺节处理（全局打底，不抛） */ return null; }
}

function mergeSection(base: LargeEmissionGuardConfig, section: Record<string, unknown>): LargeEmissionGuardConfig {
	const cfg: LargeEmissionGuardConfig = { ...base };
	if (typeof section.enabled === "boolean") cfg.enabled = section.enabled;
	if (typeof section.maxBytes === "number" && Number.isFinite(section.maxBytes) && section.maxBytes > 0) {
		cfg.maxBytes = Math.floor(section.maxBytes);
	}
	if (Array.isArray(section.riskyProviders)) {
		// 项目级声明即完整替换（emoji-guard allow 同款裁定）：全局名单不再拼接进来。
		cfg.riskyProviders = [...new Set(
			section.riskyProviders.filter((p): p is string => typeof p === "string" && p.trim().length > 0).map((p) => p.trim()),
		)];
	}
	if (Array.isArray(section.skipPatterns)) {
		cfg.skipPatterns = section.skipPatterns
			.filter((p): p is string => typeof p === "string" && p.trim().length > 0)
			.map((p) => p.trim());
	}
	return cfg;
}

function applyEnvFlip(cfg: LargeEmissionGuardConfig, env: NodeJS.ProcessEnv): LargeEmissionGuardConfig {
	const v = (env.AMAGI_LARGE_EMISSION_GUARD ?? "").trim().toLowerCase();
	if (v === "1" || v === "true" || v === "on") return { ...cfg, enabled: true };
	if (v === "0" || v === "false" || v === "off") return { ...cfg, enabled: false };
	return cfg;
}

/** 读 largeEmissionGuard 配置：全局打底、项目覆盖（enabled/maxBytes 标量项目优先；riskyProviders/
 *  skipPatterns 项目级完整替换）；mtime 缓存即时生效；env 逃生舱最高优先。 */
export function loadLargeEmissionGuardConfig(cwd?: string): LargeEmissionGuardConfig {
	if (injectedConfig !== null) return injectedConfig;
	const files = [globalAmagiConfigPath(), path.join(path.resolve(cwd ?? process.cwd()), "amagi.json")];
	const stamps = files.map((f) => { try { return `${fs.statSync(f).mtimeMs}`; } catch { return "-"; /* lint-exempt:mtime 不可读按无文件 */ } }).join("|");
	const cacheKey = files.join("::");
	const cached = configCache.get(cacheKey);
	if (cached && cached.stamp === stamps) return applyEnvFlip(cached.cfg, process.env);
	let cfg = LARGE_EMISSION_GUARD_DEFAULTS;
	for (const f of files) {
		const section = readSection(f);
		if (section !== null) cfg = mergeSection(cfg, section);
	}
	configCache.set(cacheKey, { stamp: stamps, cfg });
	return applyEnvFlip(cfg, process.env);
}

// ── provider 解析（守卫与 prompt 门控共用；execute 时惰性求值） ────────────────

/** 当前进程 provider：PI_PROVIDER 优先；未设取 PI_MODEL 的 / 前段（provider/model(:level)? 形态）；
 *  都无（或 PI_MODEL 无 / 前段）→ 空串——无 provider 信息不拦截，防误伤未知通道。 */
export function currentModelProvider(env: NodeJS.ProcessEnv = process.env): string {
	const direct = (env.PI_PROVIDER ?? "").trim();
	if (direct) return direct;
	const model = (env.PI_MODEL ?? "").trim();
	const i = model.indexOf("/");
	return i > 0 ? model.slice(0, i) : "";
}

// ── glob（自包含；`*` 单段、`**` 跨段；不含 / 的 pattern 按 basename 匹配） ────

function escapeReChar(ch: string): string {
	return /[.*+?^${}()|[\]\\]/.test(ch) ? `\\${ch}` : ch;
}

/**
 * glob 模式 → 锚定 RegExp（段级转换）：
 * - 跨段 `**`：非末段时表任意层目录（可空——a 与 b 之间夹跨段通配可匹配 a/b、a/x/b）；
 *   末段时表其后任意内容（dist 前缀 + 跨段通配匹配 dist/x.js、dist/a/b.js，不匹配 dist 自身）；
 * - `*`（单段）：段内任意非 / 字符（`*.lock` 只匹配段内，跨层由 basename 匹配承担）；
 * - 其余字符字面转义。纯函数导出供测试直接断言。
 */
export function globToRegExp(pattern: string): RegExp {
	const segs = pattern.split("/");
	let re = "";
	for (let i = 0; i < segs.length; i++) {
		const seg = segs[i]!;
		if (seg === "**") {
			// 跨段 **：前有字面段时补分隔符 /（尾部 ** 缺它会把 dist/** 编成 ^dist.*$ 误吞 distX/…
			// 与 dist 自身；中段 ** 缺它则 a/**/b 匹配不了 a/b）；** 的重复组自带尾随 /，后段不再补。
			re += `${i > 0 ? "/" : ""}${i === segs.length - 1 ? ".*" : "(?:[^/]+/)*"}`;
			continue;
		}
		// 分隔符：首段无；前一段是跨段 `**` 时已被其吸收（(?:[^/]+/)* 每次重复自带尾随 /）。
		if (i > 0 && segs[i - 1] !== "**") re += "/";
		for (const ch of seg) re += ch === "*" ? "[^/]*" : escapeReChar(ch);
	}
	return new RegExp(`^${re}$`);
}

const globCache = new Map<string, RegExp>();

function compiledGlob(pattern: string): RegExp {
	let re = globCache.get(pattern);
	if (re === undefined) {
		re = globToRegExp(pattern);
		if (globCache.size >= 256) globCache.clear(); // 上限防膨胀（配置面有限，实际难触顶）
		globCache.set(pattern, re);
	}
	return re;
}

/** skipPatterns 命中：路径归一分隔符（win32 反斜杠）后——含 / 的 pattern 对完整路径与 cwd 相对
 *  形态匹配；不含 / 的 pattern 对 basename 匹配（gitignore 惯例）。 */
function pathSkipped(target: string, patterns: ReadonlyArray<string>, cwd?: string): boolean {
	const raw = typeof target === "string" ? target.trim() : "";
	if (!raw || patterns.length === 0) return false;
	const norm = raw.replaceAll("\\", "/");
	const candidates = [norm];
	try {
		const base = path.resolve(cwd ?? process.cwd());
		const abs = path.resolve(base, raw);
		if (abs.startsWith(`${base}${path.sep}`)) {
			const rel = abs.slice(base.length + 1).replaceAll("\\", "/");
			if (rel && rel !== norm) candidates.push(rel);
		}
	} catch { /* lint-exempt:路径解析失败退回原样匹配 */ }
	for (const p of patterns) {
		const re = compiledGlob(p);
		if (p.includes("/")) {
			for (const c of candidates) if (re.test(c)) return true;
		} else if (re.test(norm.slice(norm.lastIndexOf("/") + 1))) {
			return true;
		}
	}
	return false;
}

// ── 拦截判定与文案 ───────────────────────────────────────────────────────────

interface EmissionViolation {
	bytes: number;
	maxBytes: number;
	provider: string;
}

/** 判定核心（纯函数）：enabled && provider ∈ riskyProviders && 字节数超限 && 路径不豁免 &&
 *  无 base64 长游程。非字符串内容/空内容不判违规（形态错误交原生通道裁决）。 */
function emissionViolation(
	filePath: string,
	content: unknown,
	cfg: LargeEmissionGuardConfig,
	cwd?: string,
): EmissionViolation | null {
	if (!cfg.enabled) return null;
	const provider = currentModelProvider();
	if (!provider || !cfg.riskyProviders.includes(provider)) return null;
	if (typeof content !== "string" || content.length === 0) return null;
	const bytes = Buffer.byteLength(content, "utf8");
	if (bytes <= cfg.maxBytes) return null;
	if (pathSkipped(filePath, cfg.skipPatterns, cwd)) return null;
	if (BASE64_RUN_RE.test(content)) return null;
	return { bytes, maxBytes: cfg.maxBytes, provider };
}

/** 拦截 throw 文案（处方式写死保确定性；edit 通道同款——「写入」换「编辑」、提 edits[].newText 单段）。 */
export function largeEmissionReason(kind: "write" | "edit", target: string, bytes: number, maxBytes: number, provider: string): string {
	const head = kind === "write"
		? `拒绝写入：${target} 内容 ${bytes} 字节`
		: `拒绝编辑：${target} edits[].newText 单段 ${bytes} 字节`;
	return `[amagi large-emission guard] ${head}超过单次发射上限 ${maxBytes} 字节（当前模型通道 ${provider} 对超长单次发射不稳定，流会在发射中途被掐断）。请拆分：① 先 write 文件骨架/首段（≤${maxBytes} 字节，段尾留分段占位标记）；② 后续内容用 bash heredoc 追加（cat >> ${target} <<'EOF' … EOF）或 edit 分段替换占位，每段 ≤${maxBytes} 字节。二进制/产物类文件若确需整写，可在 amagi.json 的 largeEmissionGuard.skipPatterns 加路径模式放行。`;
}

/** 单次发射上限的人类可读渲染（整 KB 倍数 → KB，否则字节）——纪律文案动态渲染用。 */
function renderLimit(maxBytes: number): string {
	return maxBytes % 1024 === 0 ? `${maxBytes / 1024}KB` : `${maxBytes}B`;
}

/** 纪律文案一行（prompt 层共用：task-tool 子进程门控与 leader L0 分节同源）。provider ∈
 *  riskyProviders 且守卫开启时返回一行行为契约（只给规矩不给原理），否则空串。provider 缺省
 *  时按当前进程 env 惰性解析。守卫自身异常零注入。 */
export function largeEmissionDisciplineLine(provider?: string, cwd?: string): string {
	try {
		const cfg = loadLargeEmissionGuardConfig(cwd);
		if (!cfg.enabled) return "";
		const p = (provider ?? currentModelProvider()).trim();
		if (!p || !cfg.riskyProviders.includes(p)) return "";
		return `当前模型通道对超长单次发射不稳定：单次 write 内容与单段 edit newText 均须 ≤${renderLimit(cfg.maxBytes)}。写大文件先 write 骨架（含分段占位标记），再用 bash heredoc 追加或 edit 分段补全；超限写入会被守卫拒绝并要求拆分。`;
	} catch { /* lint-exempt:守卫异常零注入（prompt 面静默） */ return ""; }
}

// ── 执法入口（write/edit 通道挂载点调用） ────────────────────────────────────

function enforceEmission(kind: "write" | "edit", filePath: string, content: unknown, cwd?: string): void {
	let violation: EmissionViolation | null = null;
	try {
		violation = emissionViolation(filePath, content, loadLargeEmissionGuardConfig(cwd), cwd);
	} catch { /* lint-exempt:守卫自身异常静默放行——绝不阻断正常写入路径 */ return; }
	if (violation === null) return;
	// 观测：单行 stderr（子进程 stderr 进任务日志；不建新日志文件）。
	console.error(`[amagi large-emission guard] blocked ${filePath} ${violation.bytes}B/${violation.maxBytes}B provider=${violation.provider}`);
	// B0-3：观测行追加 observations.ndjson（真实阻断分支恰一次；子进程经 AMAGI_TASK_ID/
	// AMAGI_RUN_KEY env 关联任务与运行；写失败只补一行 bounded 诊断，不改变拦截语义）。
	try {
		const written = writeObservation({
			formatVersion: 1,
			kind: "large-emission-block",
			...(process.env.AMAGI_TASK_ID ? { taskId: process.env.AMAGI_TASK_ID.slice(0, 128) } : {}),
			...(process.env.AMAGI_RUN_KEY ? { runKey: process.env.AMAGI_RUN_KEY.slice(0, 256) } : {}),
			tool: kind,
			target: String(filePath).slice(0, 400),
			bytes: violation.bytes,
			maxBytes: violation.maxBytes,
			provider: violation.provider,
			at: Date.now(),
		});
		if (!written) console.error(`[amagi large-emission guard] observation write failed (observations.ndjson 不可写；拦截不受影响)`);
	} catch { /* lint-exempt:观测绝不反噬拦截路径 */ }
	throw new Error(largeEmissionReason(kind, filePath, violation.bytes, violation.maxBytes, violation.provider));
}

/** write 通道检查：单次发射内容超限 throw（与 enforceFileWriteTargets 越界 throw 同语义——
 *  原生 write 以 throw 表达失败，覆盖层不捕获）。cwd 供项目级 amagi.json 与 skipPatterns
 *  相对形态解析（缺省 process.cwd()）。 */
export function enforceLargeWriteEmission(filePath: string, content: unknown, cwd?: string): void {
	enforceEmission("write", filePath, content, cwd);
}

/** edit 通道检查：单段 edits[].newText 超限 throw（oldText 不罚——锚点原文由既有文件决定；
 *  挂载点在任何原生委托之前，files 模式整单零写入契约保持）。 */
export function enforceLargeEditEmission(filePath: string, newText: unknown, cwd?: string): void {
	enforceEmission("edit", filePath, newText, cwd);
}
