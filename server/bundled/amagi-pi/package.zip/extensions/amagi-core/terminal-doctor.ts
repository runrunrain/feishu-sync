/**
 * terminal-doctor.ts — 终端渲染健康检测（v1.5.175）：iTerm2 Bold 色板过暗检测。
 *
 * 实战根因（主上截图+plist 双实证）：pi 对 markdown `**粗体**` 发标准 SGR 1（无颜色，
 * 字节级验证），但活动 iTerm2 profile 的 "Bold Color" 色板被设为近黑 #101010，
 * iTerm2 用该色板渲染 default-FG 粗体 → 粗体在深背景上几乎不可见。
 * pi 的 bold 渲染是硬编码 chalk.bold（插件/主题不可改），因此插件提供"强感知"：
 * session_start 检测活动 profile Bold 色板亮度，过暗时一次性 stderr 警告 + 修复指引
 * （scripts/fix-terminal-bold-color.mjs 写 Dynamic Profile 热生效）。
 *
 * 仅 macOS + iTerm2（TERM_PROGRAM=iTerm.app）执行；其余环境 checked=false。
 * 全程 best-effort 不抛错：检测失败静默跳过（不阻塞启动）。
 */

import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { errorKindOfEntry, tracesFile, type ErrorKind } from "./trace.ts";
import { stripModelThinkingSuffix } from "./model-resolver.ts";

export interface BoldColorCheck {
	/** 是否实际执行了检测（非 macOS/iTerm2/plutil 不可用 → false）。 */
	checked: boolean;
	/** checked=true 时：Bold 色板是否可读（亮度达标或无法判定时 true）。 */
	ok: boolean;
	/** 异常/跳过原因说明。 */
	reason?: string;
	/** 活动 profile 名与 Bold 色板 hex（异常时填充，供警告文案）。 */
	profileName?: string;
	boldHex?: string;
}

interface RgbComponents { "Red Component"?: number; "Green Component"?: number; "Blue Component"?: number }
interface ItermProfile {
	Name?: string;
	Guid?: string;
	"Use Separate Colors for Light and Dark Mode"?: boolean;
	"Bold Color"?: RgbComponents;
	"Bold Color (Dark)"?: RgbComponents;
}

/** 感知亮度 0-1（ITU-R BT.601）。 */
export function luminance(c?: RgbComponents): number {
	if (!c) return 1;
	const r = c["Red Component"] ?? 0, g = c["Green Component"] ?? 0, b = c["Blue Component"] ?? 0;
	return 0.299 * r + 0.587 * g + 0.114 * b;
}

/** 亮度阈值：低于此值判定"过暗不可读"（深背景场景）。 */
export const BOLD_LUMINANCE_MIN = 0.35;

function hex(c: RgbComponents): string {
	const n = (k: string) => Math.round(((c as Record<string, number>)[k] ?? 0) * 255).toString(16).padStart(2, "0");
	return `#${n("Red Component")}${n("Green Component")}${n("Blue Component")}`;
}

/**
 * 评估单个 profile 的 Bold 色板（纯函数）：separate=false → legacy "Bold Color"；
 * separate=true → "Bold Color (Dark)"（深色模式终端的主流形态）。
 * 返回 undefined=可读；否则返回异常描述。
 */
export function evaluateProfileBold(profile: ItermProfile): { ok: boolean; boldHex: string; lum: number } {
	const separate = profile["Use Separate Colors for Light and Dark Mode"] === true;
	const swatch = separate ? profile["Bold Color (Dark)"] : profile["Bold Color"];
	const lum = luminance(swatch);
	return { ok: lum >= BOLD_LUMINANCE_MIN, boldHex: swatch ? hex(swatch) : "(未设置)", lum };
}

/**
 * 选择活动 profile：ITERM_PROFILE 环境变量（当前会话 profile 名）优先，
 * 其次 Default Bookmark Guid，最后首个 profile。
 */
export function selectActiveProfile(
	bookmarks: ItermProfile[],
	envProfileName?: string,
	defaultGuid?: string,
): ItermProfile | undefined {
	if (envProfileName) {
		const byName = bookmarks.find((b) => b.Name === envProfileName);
		if (byName) return byName;
	}
	if (defaultGuid) {
		const byGuid = bookmarks.find((b) => b.Guid === defaultGuid);
		if (byGuid) return byGuid;
	}
	return bookmarks[0];
}

export interface CheckDeps {
	platform?: string;
	termProgram?: string;
	envProfileName?: string;
	/** 注入的 plutil 执行器（测试用）；生产缺省走 execFileSync。 */
	readPrefs?: () => { bookmarks: ItermProfile[]; defaultGuid?: string } | undefined;
}

/** 生产实现：plutil -extract json 读取 iTerm2 偏好（二进制 plist 无依赖解析）。 */
function readItermPrefs(): { bookmarks: ItermProfile[]; defaultGuid?: string } | undefined {
	try {
		const home = process.env.HOME || "";
		const out = execFileSync("plutil", ["-extract", "New Bookmarks", "json", "-o", "-", `${home}/Library/Preferences/com.googlecode.iterm2.plist`], { encoding: "utf8", timeout: 3000 });
		const bookmarks = JSON.parse(out) as ItermProfile[];
		let defaultGuid: string | undefined;
		try {
			defaultGuid = execFileSync("plutil", ["-extract", "Default Bookmark Guid", "raw", "-o", "-", `${home}/Library/Preferences/com.googlecode.iterm2.plist`], { encoding: "utf8", timeout: 3000 }).trim() || undefined;
		} catch { /* 无默认 guid 也无妨 */ }
		return { bookmarks, defaultGuid };
	} catch { return undefined; }
}

/**
 * iTerm2 Bold 色板健康检查：过暗 → { checked:true, ok:false, reason }。
 * 非 macOS/iTerm2、读取失败、无 profile → checked:false 或 ok:true（静默跳过，不误报）。
 */
export function checkItermBoldColor(deps: CheckDeps = {}): BoldColorCheck {
	const platform = deps.platform ?? process.platform;
	const termProgram = deps.termProgram ?? process.env.TERM_PROGRAM;
	if (platform !== "darwin" || termProgram !== "iTerm.app") return { checked: false, ok: true };
	const prefs = deps.readPrefs ? deps.readPrefs() : readItermPrefs();
	if (!prefs || !Array.isArray(prefs.bookmarks) || prefs.bookmarks.length === 0)
		return { checked: false, ok: true, reason: "iTerm2 prefs 读取失败或无 profile（跳过）" };
	const profile = selectActiveProfile(prefs.bookmarks, deps.envProfileName ?? process.env.ITERM_PROFILE, prefs.defaultGuid);
	if (!profile) return { checked: false, ok: true, reason: "无活动 profile（跳过）" };
	const ev = evaluateProfileBold(profile);
	if (ev.ok) return { checked: true, ok: true, profileName: profile.Name };
	return {
		checked: true, ok: false,
		profileName: profile.Name, boldHex: ev.boldHex,
		reason: `iTerm2 profile "${profile.Name}" 的 Bold Color 为 ${ev.boldHex}（亮度 ${ev.lum.toFixed(2)} < ${BOLD_LUMINANCE_MIN}）——markdown **粗体** 将渲染为近黑不可读`,
	};
}

// ── pi settings 健康检测（v1.5.177）：retry 关闭告警 ─────────────────────────
// 实战根因（主上会话 3+ 次 "Error: Connection error" 中断）：settings.json 里
// retry.enabled=false——pi 的 agent 级瞬时错误重试（默认开，2s/4s/8s 指数退避 ×3）被关，
// provider 网络一抖即杀 turn。插件 session_start 检测并一次性警告（强感知）。

export interface RetrySettingCheck {
	checked: boolean;
	ok: boolean;
	reason?: string;
	settingsPath?: string;
	/** v1.5.185 非阻断提示（ok 不变）：provider 超时配置偏短等韧性风险。 */
	warnings?: string[];
}

/** doctor 侧自查的模型配置源（v1.5.2xx 复盘 P1-3）。直接用 fs+path 读 JSON，不触发 resolver 的自动配置创建或选模诊断；字段 null=文件不存在/损坏（按无配置处理）。 */
export interface RetryConfigSources {
	global?: { profile?: unknown; agents?: Record<string, unknown> } | null;
	project?: { profile?: unknown; agents?: Record<string, unknown> } | null;
	profileFile?: { leader?: unknown; fast?: unknown; work?: unknown; expert?: unknown; agentOverrides?: Record<string, unknown> } | null;
}

export interface RetryCheckDeps {
	agentDir?: string;
	/** 项目 amagi.json 定位用 cwd；缺省 process.cwd()（测试可注入覆盖）。 */
	cwd?: string;
	/** 注入读取器（测试用）；生产读 <agentDir>/settings.json。 */
	readSettings?: () => { retry?: { enabled?: boolean; provider?: { timeoutMs?: number } } } | undefined;
	/** 注入配置源读取器（测试用）；生产读全局/项目 amagi.json + profiles/<profile>.json。 */
	readConfigs?: () => RetryConfigSources | undefined;
	/** 注入写回器（测试用）；生产实现=先备份 settings.json.amagi-bak-<epoch> 再写回合并结果，返回备份路径。 */
	writeSettings?: (settingsPath: string, merged: unknown) => string | undefined;
}

/** 高 thinking 档后缀（复盘 P1-3 实证：glm-5.2:max 长思考首字节慢，SDK 默认~60s 连续 Request timed out）。 */
const HIGH_THINKING_SUFFIX_RE = /:(max|xhigh|high)$/;

function readJsonOrNull(p: string): any {
	try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return null; }
}

/** 生产配置源读取：全局 <agentDir>/amagi.json + 项目 <cwd>/amagi.json + 生效 profile 文件（模块相对 profiles/，定位与 model-resolver 同源；profile 名非法/缺失回退 tiered）。 */
function readRetryConfigSources(agentDir: string, cwd: string): RetryConfigSources {
	const globalCfg = readJsonOrNull(path.join(agentDir, "amagi.json"));
	const projectCfg = readJsonOrNull(path.join(cwd, "amagi.json"));
	const rawProfile = projectCfg?.profile ?? globalCfg?.profile;
	const profileName = typeof rawProfile === "string" && /^(tiered|inherit)$/.test(rawProfile) ? rawProfile : "tiered";
	const moduleDir = path.dirname(new URL(import.meta.url).pathname);
	const profileFile = readJsonOrNull(path.resolve(moduleDir, "..", "..", "profiles", `${profileName}.json`));
	return { global: globalCfg, project: projectCfg, profileFile };
}

/** amagi.json agents 值取 model 字符串（兼容裸字符串与 {model:"..."} 对象两种写法）。 */
function modelOf(v: unknown): string | undefined {
	if (typeof v === "string") return v;
	if (v && typeof v === "object" && typeof (v as { model?: unknown }).model === "string") return (v as { model: string }).model;
	return undefined;
}

/**
 * 扫描生效配置里实际使用的高 thinking 档 spec：amagi.json agents（项目键覆盖全局）
 * + 生效 profile 文件的 tier 模型与 agentOverrides。返回命中的 spec 列表（空=无高档）。
 */
function scanHighThinking(sources: RetryConfigSources | undefined): string[] {
	if (!sources) return [];
	const agents: Record<string, unknown> = {};
	if (sources.global?.agents && typeof sources.global.agents === "object") Object.assign(agents, sources.global.agents);
	if (sources.project?.agents && typeof sources.project.agents === "object") Object.assign(agents, sources.project.agents); // 项目键覆盖全局
	const specs: string[] = [];
	for (const v of Object.values(agents)) {
		const m = modelOf(v);
		if (m) specs.push(m);
	}
	const pf = sources.profileFile;
	if (pf && typeof pf === "object") {
		for (const key of ["leader", "fast", "work", "expert"] as const) {
			const m = modelOf(pf[key]);
			if (m) specs.push(m);
		}
		if (pf.agentOverrides && typeof pf.agentOverrides === "object") {
			for (const v of Object.values(pf.agentOverrides)) {
				const m = modelOf(v);
				if (m) specs.push(m);
		}
		}
	}
	return specs.filter((s) => HIGH_THINKING_SUFFIX_RE.test(s));
}

/** 推荐超时：env AMAGI_DOCTOR_TIMEOUT_MS（合法正数，主上紧急覆盖用）> thinking 档推导（高档 300000 / 无档 180000）。 */
function recommendedTimeoutMs(highThinking: boolean): number {
	const raw = process.env.AMAGI_DOCTOR_TIMEOUT_MS;
	if (typeof raw === "string" && raw.trim() !== "") {
		const n = Number(raw);
		if (Number.isFinite(n) && n > 0) return Math.round(n);
	}
	return highThinking ? 300_000 : 180_000;
}

/** 深合并写入 timeoutMs（只补 retry.provider 一条路径，settings 其余键原样保留）。 */
function mergeProviderTimeout(settings: Record<string, unknown>, timeoutMs: number): Record<string, unknown> {
	const retry = (settings.retry && typeof settings.retry === "object" ? { ...(settings.retry as Record<string, unknown>) } : {}) as Record<string, unknown>;
	const provider = (retry.provider && typeof retry.provider === "object" ? { ...(retry.provider as Record<string, unknown>) } : {}) as Record<string, unknown>;
	provider.timeoutMs = timeoutMs;
	retry.provider = provider;
	return { ...settings, retry };
}

/** 生产写回：先备份原始内容为 settings.json.amagi-bak-<epoch> 再写合并结果；任一步失败抛错（调用方降级为建议文案，绝不向上抛）。 */
function defaultWriteSettings(settingsPath: string, merged: unknown): string {
	const bak = `${settingsPath}.amagi-bak-${Date.now()}`;
	fs.writeFileSync(bak, fs.readFileSync(settingsPath, "utf8"));
	fs.writeFileSync(settingsPath, JSON.stringify(merged, null, "\t") + "\n");
	return bak;
}

export function checkRetrySetting(deps: RetryCheckDeps = {}): RetrySettingCheck {
	const agentDir = deps.agentDir ?? process.env.PI_CODING_AGENT_DIR ?? path.join(os.homedir(), ".pi", "agent");
	const settingsPath = path.join(agentDir, "settings.json");
	let settings: { retry?: { enabled?: boolean; provider?: { timeoutMs?: number } } } | undefined;
	if (deps.readSettings) settings = deps.readSettings();
	else {
		try { settings = JSON.parse(fs.readFileSync(settingsPath, "utf8")); } catch { settings = undefined; }
	}
	if (!settings) return { checked: false, ok: true, reason: "settings.json 读取失败（跳过）" };
	// 缺省 true（pi 默认）；仅显式 false 判定异常（v1.5.177 语义保持，早退不触达超时写入）
	if (settings.retry?.enabled === false) {
		return {
			checked: true, ok: false, settingsPath,
			reason: `settings.json 的 retry.enabled=false——provider 瞬时错误（Connection error 等）将不重试直接中断会话；建议改为 true（agent 级指数退避 ×3）`,
		};
	}
	// v1.5.2xx（复盘 P1-3）：推荐超时按实际 thinking 档自适应，且 doctor 直接写入而非仅建议。
	// 实战根因：旧版（v1.5.185）静态建议 300000——不感知实际档位、也从不落盘，主上环境从未真正改过，
	// glm-5.2:max 长思考首字节慢 + SDK 默认~60s 连续 Request timed out → agent 级退避×3 沉默烧 2min。
	// 写入只在高 thinking 档触发（实证故障模式；缺 timeoutMs 或低于推荐值即补齐）；无高档只建议
	// 180000 不动用户文件；AMAGI_DOCTOR_TIMEOUT_FIX=0 全局关闭写入；写入/备份失败降级为建议，绝不抛错。
	let sources: RetryConfigSources | undefined;
	try {
		sources = deps.readConfigs ? deps.readConfigs() : readRetryConfigSources(agentDir, deps.cwd ?? process.cwd());
	} catch { sources = undefined; }
	const hits = scanHighThinking(sources);
	const highThinking = hits.length > 0;
	const recommended = recommendedTimeoutMs(highThinking);
	const warnings: string[] = [];
	const timeoutMs = settings.retry?.provider?.timeoutMs;
	if (typeof timeoutMs !== "number" || timeoutMs < recommended) {
		const current = typeof timeoutMs === "number" ? `${timeoutMs}ms` : "未设（SDK 默认~60s）";
		const cause = highThinking ? `——命中高 thinking 档 [${hits.join(", ")}]，长思考首字节慢，provider 请求易超时并触发 agent 级退避×3（沉默烧分钟级时间）` : "";
		const fixEnabled = process.env.AMAGI_DOCTOR_TIMEOUT_FIX !== "0";
		let handled = false;
		if (highThinking && fixEnabled) {
			try {
				const merged = mergeProviderTimeout(settings as Record<string, unknown>, recommended);
				const bak = deps.writeSettings ? deps.writeSettings(settingsPath, merged) : defaultWriteSettings(settingsPath, merged);
				warnings.push(`已写入 ${settingsPath}：retry.provider.timeoutMs ${current}→${recommended}${cause}；备份 ${bak ?? "(注入模式未返回备份路径)"}；不满意可回滚`);
				handled = true;
			} catch (e) {
				warnings.push(`settings.json 的 retry.provider.timeoutMs ${current}${cause}；自动写入失败（${e instanceof Error ? e.message : String(e)}）——请手动设为 ${recommended}`);
				handled = true;
			}
		}
		if (!handled) {
			const fixNote = highThinking
				? (fixEnabled ? "" : "（AMAGI_DOCTOR_TIMEOUT_FIX=0 已禁用自动写入）")
				: "（未检测到高 thinking 档，仅建议不自动写入）";
			warnings.push(`settings.json 的 retry.provider.timeoutMs ${current}${cause}；建议设 ${recommended}${fixNote}`);
		}
	}
	return { checked: true, ok: true, settingsPath, ...(warnings.length ? { warnings } : {}) };
}

// ── P2-B（2026-08-19 插件进化）：doctor 启动画像提示 ─────────────────────────
// 默认 provider+model 近 7 日 errorKind 分布：读 traces.ndjson（路径同 trace.ts 的
// AMAGI_TRACES_PATH/<amagiDataDir> 推导），把 P2-A 的错误分类观测转化为启动时可感知信号。
// 仅当该模型任务 error 占比 >20% 且样本 ≥10 时提示 top-2 errorKind 及定向建议
// （quota 风暴/过载窗口/超时偏短等提前一轮会话暴露）。读取有界：尾部最多
// PROFILE_TAIL_LINES(5000) 行、PROFILE_SCAN_MAX_BYTES(4MB) 字节窗——与 bold/retry
// 检测同为 session_start 同步毫秒级预算内完成，不新增长等待。
// AMAGI_DOCTOR_PROFILE_OFF=1 一键关闭。旧行（v1 无 errorKind）读侧归 unknown：
// 计入样本数与 error 数，但不进 top-2 建议（未分类给不出定向动作）。

export interface DoctorProfileCheck {
	/** 是否实际执行了检测（开关关闭/provider+model 不可得/traces 不可读 → false）。 */
	checked: boolean;
	/** false = 触发提示（error 占比 >20% 且样本 ≥10）。 */
	ok: boolean;
	/** 提示文案（含错误分类分布与定向建议）。 */
	reason?: string;
	/** 匹配的默认模型 spec（provider/model）。 */
	model?: string;
	/** 近 7 日该模型任务样本数（含非 error 行）。 */
	sampleCount?: number;
	/** 近 7 日该模型 error 行数。 */
	errorCount?: number;
}

export interface ProfileCheckDeps {
	/** 默认 provider；缺省 process.env.PI_PROVIDER。 */
	provider?: string;
	/** 默认 model；缺省 process.env.PI_MODEL。 */
	model?: string;
	/** traces 文件注入（测试用）；缺省 trace.ts 的 tracesFile()。 */
	tracesFile?: string;
	/** 当前时刻注入（测试用）；缺省 Date.now()。 */
	now?: number;
}

/** P2-B 阈值/有界常量：7 日窗口、尾扫 5000 行、4MB 字节窗、样本 ≥10、error 占比 >20%。 */
export const PROFILE_WINDOW_MS = 7 * 24 * 3600 * 1000;
export const PROFILE_TAIL_LINES = 5000;
export const PROFILE_SCAN_MAX_BYTES = 4 * 1024 * 1024;
export const PROFILE_MIN_SAMPLES = 10;
export const PROFILE_ERROR_RATIO = 0.2;

/** top-2 errorKind → 定向建议（P2-B 契约；quota/transient-400/model/timeout 为任务指定文案）。 */
const PROFILE_ADVICE: Record<ErrorKind, string> = {
	quota: "查 provider 配额（控制台/账单）或临时换模型（amagi.json agents 覆盖 / task model 参数）",
	"transient-400": "provider 过载窗口 400 误拒——见 docs/new-provider-guide.md 过载窗口节；session-repair 自动重试已内置，通常无需干预",
	"context-limit": "上下文超限族——拆小任务或换大上下文模型 resume",
	"doom-loop": "死循环看门狗终止——检查任务书是否足以让子 Agent 收敛",
	stall: "停滞无输出——检查网络稳定性与任务规模",
	timeout: "建议调大 settings.json 的 retry.provider.timeoutMs（推荐值可用 AMAGI_DOCTOR_TIMEOUT_MS 紧急覆盖）",
	policy: "provider 内容策略拦截（任务内容触发，非容量/配额）——改写任务书措辞（攻击性字面量改中性占位）后新派，或临时更换该角色模型（amagi.json agents.<role>.model / rpc_task model，换模型须显式披露）",
	aborted: "用户/控制面主动中止（非能力、非 provider 健康信号）——需要继续时 task_resume 续接或重派",
	model: "provider/模型侧故障（容量/5xx/凭据/网络）——考虑换 provider 或核对 API key",
	other: "未分类错误——可对照 traces.ndjson 明细定位",
};

/** spec 匹配（忽略 thinking 档后缀与大小写）：trace 行 model 为 provider/model[:thinking] 全形态。 */
function specMatchesModel(entryModel: string | undefined, provider: string, model: string): boolean {
	if (!entryModel) return false;
	return stripModelThinkingSuffix(entryModel).toLowerCase() === `${provider}/${model}`.toLowerCase();
}

/** 有界尾读：从文件尾部 maxBytes 字节窗解析 NDJSON 行，取最后 maxLines 行（窗首可能截断的半行丢弃）。 */
function readTraceTailLines(file: string, maxBytes: number, maxLines: number): string[] {
	const size = fs.statSync(file).size;
	const start = Math.max(0, size - maxBytes);
	const fd = fs.openSync(file, "r");
	try {
		const len = size - start;
		const buf = Buffer.alloc(len);
		fs.readSync(fd, buf, 0, len, start);
		let text = buf.toString("utf8");
		if (start > 0) text = text.replace(/^[^\n]*\n/, ""); // 窗首半行（非行边界起点）丢弃
		return text.split("\n").filter(Boolean).slice(-maxLines);
	} finally {
		fs.closeSync(fd);
	}
}

export function checkModelProfile(deps: ProfileCheckDeps = {}): DoctorProfileCheck {
	if (process.env.AMAGI_DOCTOR_PROFILE_OFF === "1")
		return { checked: false, ok: true, reason: "AMAGI_DOCTOR_PROFILE_OFF=1 已关闭启动画像检测（跳过）" };
	const provider = deps.provider ?? process.env.PI_PROVIDER;
	const model = deps.model ?? process.env.PI_MODEL;
	if (!provider || !model)
		return { checked: false, ok: true, reason: "未取到默认 provider/model（PI_PROVIDER/PI_MODEL 缺失，跳过）" };
	const file = deps.tracesFile ?? tracesFile();
	let lines: string[];
	try {
		lines = readTraceTailLines(file, PROFILE_SCAN_MAX_BYTES, PROFILE_TAIL_LINES);
	} catch {
		return { checked: false, ok: true, reason: "traces.ndjson 不可读（跳过）" };
	}
	const now = deps.now ?? Date.now();
	const since = now - PROFILE_WINDOW_MS;
	let sampleCount = 0;
	let errorCount = 0;
	const kindCounts = new Map<ErrorKind | "unknown", number>();
	for (const line of lines) {
		let e: { status?: string; model?: string; at?: number; errorKind?: ErrorKind };
		try { e = JSON.parse(line); } catch { continue; }
		if (typeof e.at !== "number" || e.at < since) continue;
		if (!specMatchesModel(e.model, provider, model)) continue;
		sampleCount++;
		const kind = errorKindOfEntry(e); // 旧行 v1 无 errorKind → "unknown"（计样本，不进建议）
		if (kind === undefined) continue;
		errorCount++;
		kindCounts.set(kind, (kindCounts.get(kind) ?? 0) + 1);
	}
	if (sampleCount < PROFILE_MIN_SAMPLES || errorCount / sampleCount <= PROFILE_ERROR_RATIO)
		return { checked: true, ok: true, model: `${provider}/${model}`, sampleCount, errorCount };
	// top-2：计数降序（并列按 kind 字典序，确定性）；unknown 不计入建议但已计入样本/error 数
	const top = [...kindCounts.entries()]
		.filter(([k]) => k !== "unknown")
		.sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
		.slice(0, 2);
	const pct = Math.round((errorCount / sampleCount) * 100);
	const dist = top.length
		? top.map(([k, n]) => `${k} ×${n}`).join("、")
		: "全部为未分类错误（旧 formatVersion 行无 errorKind）";
	const advice = top.map(([k]) => k === "unknown" ? "unknown→（无细分归因，看 status/model 分布）" : `${k}→${PROFILE_ADVICE[k as ErrorKind]}`).join("；");
	return {
		checked: true, ok: false,
		model: `${provider}/${model}`, sampleCount, errorCount,
		reason: `默认模型 ${provider}/${model} 近 7 日 ${sampleCount} 次任务中 ${errorCount} 次 error（${pct}%）——错误分类分布 top-2：${dist}${advice ? `；建议：${advice}` : ""}；明细可查 traces.ndjson`,
	};
}
