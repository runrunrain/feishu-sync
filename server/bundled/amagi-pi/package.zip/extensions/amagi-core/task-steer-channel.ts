/**
 * task-steer-channel.ts — ev-20260930-0dd26f（R6）：steer 通道文件层——解析/精确状态投影/安全生命周期 GC。
 *
 * 模块纪律（任务书 §1）：本模块只依赖 node:fs / node:path / data-dir——零 registry、kernel、recovery、
 * store 依赖（depcruise no-cycles + 测试源码断言双保险）。GC 的「保护证据」由应用层
 * （task-recovery.ts 组合根：全局契约 store + 本进程 registry）构造分类器**注入**本模块的清扫函数，
 * 本模块不越权猜测任何任务生命周期。
 *
 * 从 task-steer.ts 拆出的公共契约（消费者兼容：task-steer.ts 重导出）：
 *   - steerChannelFile / parseSteerChannel / appendSteerMessage / readSteerChannelState（旧 API，
 *     pending 语义升级为精确算法，不再用 seq>maxAckSeq 虚假归零估算）/ activeSteers（共享预算函数）。
 *
 * 精确投影（本文件核心修正，ev-20260930-0dd26f 根因）：
 *   - 旧估算 `pending = #(steer.seq > maxAckSeq)` 在活跃预算淘汰旧未注入 steer 时虚假归零——较新 seq 的
 *     ack 不能证明旧 seq 曾注入。新投影 SteerChannelSnapshot 按「每条 steer 是否找到对应 seq 的有效 ack」
 *     精确计数：ack 必须有对应 steer seq；重复 ack 不多计；孤立 ack 不抹 pending。
 *   - pendingActive（当前活跃集中未注入）/ inactiveUnacked（被 8KiB 字节预算淘汰且从未 ack）分项——
 *     淘汰项不会在下个请求自动注入，文案必须明示，不以新展示面放大旧估算。
 *   - ack 仅表示已加入某次模型请求上下文——pending 文案统一「未注入」，不用「执行完成」。
 *   - availability=absent → 「未记录或已回收，无法据此证明全部注入」（可用审计最近项说明回收）；
 *     unreadable → 不当 pending=0 成功（无法核对 ≠ 全部注入）。stat→read 的 TOCTOU 容错保留
 *     （不扩成锁服务）。
 *
 * GC 八条规则（§②，安全优先；参数主上已授权：最小可删年龄 24h / TTL 7d / 目录软阈值 64 / 孤儿保守保留）：
 *   ① 执行方仅 Leader（AMAGI_TASK_ID 置位的子进程与未隔离 node:test 进程一律 disabled，绝不触默认数据
 *      目录）；由应用层在「启动恢复完成后」（index.ts）与「新 steer 写入后」（task-facets steer）低频
 *      触发，节流 30 分钟，无后台定时器。
 *   ② 保护证据经 classifier 注入：queued/running/answering/blocked（待处理链）、process alive/unknown、
 *      needs-reconciliation 均保护（应用层从全局契约 store 构造，不只本会话）。
 *   ③ 可删资格 = 分类 terminal-exited（契约明确终态且 processState=exited、无待对账）且文件 ≥24h 未修改；
 *      steer 任务不能同 taskId 重开（resume 新 taskId 另建通道）；取消但进程活着由分类层保护。
 *   ④ TTL 7d；目录 >64 时对具资格文件按 mtime 旧→新删到 64 或候选耗尽；mtime 相同按 taskId 稳定排序。
 *   ⑤ 64 为软阈值——活跃/不确定/年轻终态超 64 宁可暂超限（如实返回 remaining，不为硬数量删通信）。
 *   ⑥ 无可信契约孤儿（classifier 返回 no-contract）先保护并列需人工确认；不从「老而 registry 没有」
 *      推断进程死（该推断由应用层分类器禁止）。
 *   ⑦ 仅识别安全 taskId 常规 .jsonl；lstat 拒 symlink/目录；只遍历通道目录内条目、不删除目录外目标；
 *      删除前复核生命周期与文件身份（dev/ino）/mtime，变化则延后；只整文件删除，不压缩/重写活跃文件。
 *   ⑧ 回收写 ≤256 行有界审计（taskId/原因/mtime/bytes/回收前 pending 分项）；错误如实计入 failed/
 *      deferred，绝不影响 steer 投递/结算；查询缺文件可用审计最近项说明回收，审计过期保持未知。
 *
 * 环境开关：AMAGI_TASK_STEER_GC=0/false/off 关闭（env-knobs.md 已登记）；阈值不加 env 配置矩阵，
 * 测试从 options 注入 now/minAgeMs/ttlMs/maxFiles/force/dryRun。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { amagiDataDir } from "./data-dir.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 通道文件契约（父/子共享；自 task-steer.ts 原样迁入，协议零变化）
// ─────────────────────────────────────────────────────────────────────────────

const STEER_DIR_NAME = "task-steer";
/** 活跃 steer 注入总量上限（UTF-8 字节；超出淘汰最旧——调整是短指令不是长文）。 */
const MAX_ACTIVE_STEER_BYTES = 8 * 1024;
/** 单条 steer 消息上限（UTF-8 字节）——必须 ≤ MAX_ACTIVE_STEER_BYTES（不变量，两常量同值）：
 *  diting F1（2026-09-30 审核）：曾为 16KB，单条落入 (8KB,16KB] 时通过入口校验却被
 *  activeSteers 预算循环全量淘汰（start 停留初值，slice 为空集）——注入恒空、pending 永久挂起、
 *  成功文案失真（承诺注入实则永不注入）。对齐后超限在入口拒绝，Leader 当场可见。 */
const MAX_STEER_MESSAGE_BYTES = MAX_ACTIVE_STEER_BYTES;
/** 通道行数硬上限（防异常膨胀；正常 = steer 条数 + ack 条数）。 */
const MAX_CHANNEL_LINES = 256;
/** taskId 安全样式（防路径穿越；真实 taskId 为 UUID 派生）。 */
const SAFE_TASK_ID = /^[A-Za-z0-9._-]+$/;

export interface SteerEntry { kind: "steer"; seq: number; at: number; message: string }
export interface AckEntry { kind: "ack"; seq: number; at: number; pid: number }
export type SteerChannelEntry = SteerEntry | AckEntry;

/** 通道目录（<amagiData>/task-steer；测试可经 AMAGI_DATA_DIR 隔离）。 */
export function steerDir(dataDir?: string): string {
	return path.join(dataDir ?? amagiDataDir(), STEER_DIR_NAME);
}

export function steerChannelFile(taskId: string, dataDir?: string): string {
	return path.join(steerDir(dataDir), `${taskId}.jsonl`);
}

/** 解析通道文本（纯函数；容错：单行损坏跳行不弃整个通道）。 */
export function parseSteerChannelText(raw: string): { entries: SteerChannelEntry[]; badLines: number } {
	const entries: SteerChannelEntry[] = [];
	let badLines = 0;
	for (const line of raw.split("\n")) {
		if (!line.trim()) continue;
		try {
			const v = JSON.parse(line);
			if (v?.kind === "steer" && Number.isInteger(v.seq) && typeof v.message === "string") entries.push({ kind: "steer", seq: v.seq, at: v.at, message: v.message });
			else if (v?.kind === "ack" && Number.isInteger(v.seq)) entries.push({ kind: "ack", seq: v.seq, at: v.at, pid: v.pid });
			else badLines++;
		} catch { /* lint-exempt:单行损坏跳行不弃整个通道 */ badLines++; }
	}
	return { entries, badLines };
}

/** 解析通道文件（容错：不可读/不存在 → 空条目——快速路径语义与 task-steer.ts 原实现一致）。 */
export function parseSteerChannel(file: string): { entries: SteerChannelEntry[]; badLines: number } {
	let raw: string;
	try { raw = fs.readFileSync(file, "utf8"); } catch { /* lint-exempt:无通道文件=常态快速路径 */ return { entries: [], badLines: 0 }; }
	return parseSteerChannelText(raw);
}

/** Leader 侧：追加一条 steer（单写者——仅 Leader 进程写 steer 行）。 */
export function appendSteerMessage(taskId: string, message: string): { ok: true; seq: number; file: string } | { ok: false; error: string } {
	if (!SAFE_TASK_ID.test(taskId)) return { ok: false, error: `taskId 含不安全字符: ${taskId}` };
	// diting F2：whitespace-only 消息拦截（isNonEmptyString 只查 length>0，空白串可入通道注入空调整段）
	if (!message.trim()) return { ok: false, error: "steer 消息为空白——调整指令须有实质内容（空调整段只会污染通道与上下文）" };
	const bytes = Buffer.byteLength(message, "utf8");
	if (bytes > MAX_STEER_MESSAGE_BYTES) return { ok: false, error: `steer 消息超限（${bytes}B > ${MAX_STEER_MESSAGE_BYTES}B）——拆分为多条（每条 ≤${MAX_STEER_MESSAGE_BYTES}B）或改用 task_resume 传递完整指令` };
	const dir = steerDir();
	const file = path.join(dir, `${taskId}.jsonl`);
	try {
		fs.mkdirSync(dir, { recursive: true });
		const { entries } = parseSteerChannel(file);
		if (entries.length >= MAX_CHANNEL_LINES) return { ok: false, error: `通道行数超限（${entries.length} ≥ ${MAX_CHANNEL_LINES}）——任务已收多轮调整，新指令请经 task_resume 开新一轮` };
		const seq = Math.max(0, ...entries.map((e) => e.seq)) + 1;
		const entry: SteerEntry = { kind: "steer", seq, at: Date.now(), message };
		fs.appendFileSync(file, `${JSON.stringify(entry)}\n`, "utf8");
		return { ok: true, seq, file };
	} catch (e) {
		return { ok: false, error: `通道写入失败: ${e instanceof Error ? e.message : String(e)}` };
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// 活跃集（注入与投影共享同一预算函数——仍 8KiB，不改淘汰语义）
// ─────────────────────────────────────────────────────────────────────────────

/** 活跃 steer 集（seq 升序；超字节预算淘汰最旧）。子进程注入（registerSteerInjection）与本模块
 *  状态投影（pendingActive 分项）共享——确保「待注入」承诺与真实注入面逐字节一致。 */
export function activeSteers(entries: readonly SteerChannelEntry[]): SteerEntry[] {
	const steers = entries.filter((e): e is SteerEntry => e.kind === "steer").sort((a, b) => a.seq - b.seq);
	if (steers.length === 0) return [];
	// 预算：从最新往回收，收满后余下最旧的淘汰
	let budget = MAX_ACTIVE_STEER_BYTES;
	let start = steers.length;
	for (let i = steers.length - 1; i >= 0; i--) {
		const b = Buffer.byteLength(steers[i]!.message, "utf8");
		if (b > budget) break;
		budget -= b;
		start = i;
	}
	return steers.slice(start);
}

// ─────────────────────────────────────────────────────────────────────────────
// 精确状态投影（ev-20260930-0dd26f 根治核心）
// ─────────────────────────────────────────────────────────────────────────────

/**
 * 通道状态快照（精确投影 DTO，任务书 §1）。
 *  - pending（未注入合计）= 未找到对应有效 ack 的 steer 数 = pendingActive + inactiveUnacked。
 *  - ackedCount 只计「有对应 steer seq」的有效 ack（按 seq 去重）；孤立 ack 不计入、不抹 pending。
 *  - ackedSeq 仅为最大有效 ack 的诊断值——不用它推断此前 seq 全部注入（旧估算缺陷）。
 *  - pendingActive：当前活跃集（8KiB 预算幸存）中未注入数——只有这部分承诺「下个模型请求前注入」。
 *  - inactiveUnacked：被活跃预算淘汰且从未 ack 的记录数——不会在下个请求自动注入，文案必须明示。
 */
export interface SteerChannelSnapshot {
	availability: "readable" | "absent" | "unreadable";
	observedAt: number;
	/** steer 行总数（不含 ack）。 */
	total: number;
	/** 有效 ack 数（有对应 steer seq、按 seq 去重）。 */
	ackedCount: number;
	/** 最大有效 ack seq（诊断值；孤立 ack 不计）。 */
	ackedSeq: number;
	/** 未注入合计（= pendingActive + inactiveUnacked）。 */
	pending: number;
	/** 活跃集中未注入数。 */
	pendingActive: number;
	/** 被活跃预算淘汰且从未 ack 的记录数。 */
	inactiveUnacked: number;
	/** 解析失败的坏行数。 */
	badLines: number;
	/** 最后一条 steer 时刻（无 steer 时缺省）。 */
	lastSteerAt?: number;
	/** availability=absent 时：审计日志中该 taskId 最近一次回收记录（审计过期/无记录 → 缺省，保持未知）。 */
	reclaimed?: { reason: "ttl" | "cap"; at: number };
}

function emptySnapshot(availability: SteerChannelSnapshot["availability"], observedAt: number, reclaimed?: { reason: "ttl" | "cap"; at: number }): SteerChannelSnapshot {
	return { availability, observedAt, total: 0, ackedCount: 0, ackedSeq: 0, pending: 0, pendingActive: 0, inactiveUnacked: 0, badLines: 0, ...(reclaimed !== undefined ? { reclaimed } : {}) };
}

/**
 * 读取通道精确快照（零写入、不触发 GC）。absent = 无通道文件（未记录或已回收，可附审计回收说明）；
 * unreadable = 文件存在但读失败（EACCES 等，非 ENOENT）或 taskId 不安全——pending=0 不是成功信号，
 * 渲染层必须声明「无法核对」。stat→read 间 TOCTOU（读时文件被删 → ENOENT 路径）按 absent 容错，
 * 不扩成锁服务。
 */
export function readSteerChannelSnapshot(taskId: string): SteerChannelSnapshot {
	const observedAt = Date.now();
	if (!SAFE_TASK_ID.test(taskId)) return emptySnapshot("unreadable", observedAt); // 不安全 id：无法核对（不当成功）
	let raw: string;
	try {
		raw = fs.readFileSync(steerChannelFile(taskId), "utf8");
	} catch (e) {
		const code = (e as NodeJS.ErrnoException).code;
		if (code === "ENOENT" || code === "ENOTDIR") return emptySnapshot("absent", observedAt, findSteerChannelReclaim(taskId));
		return emptySnapshot("unreadable", observedAt);
	}
	const { entries, badLines } = parseSteerChannelText(raw);
	const steers = entries.filter((e): e is SteerEntry => e.kind === "steer");
	const steerSeqs = new Set(steers.map((s) => s.seq));
	const ackedSeqs = new Set<number>();
	for (const e of entries) if (e.kind === "ack" && steerSeqs.has(e.seq)) ackedSeqs.add(e.seq);
	const activeSeqs = new Set(activeSteers(entries).map((s) => s.seq));
	let pending = 0;
	let pendingActive = 0;
	for (const s of steers) {
		if (ackedSeqs.has(s.seq)) continue;
		pending++;
		if (activeSeqs.has(s.seq)) pendingActive++;
	}
	const inactiveUnacked = pending - pendingActive;
	return {
		availability: "readable",
		observedAt,
		total: steers.length,
		ackedCount: ackedSeqs.size,
		ackedSeq: ackedSeqs.size > 0 ? Math.max(...ackedSeqs) : 0,
		pending,
		pendingActive,
		inactiveUnacked,
		badLines,
		...(steers.length > 0 ? { lastSteerAt: steers[steers.length - 1]!.at } : {}),
	};
}

/** 旧 API 兼容（task-steer.ts 原公共面）：pending 已升级为精确算法（不用 seq>maxAckSeq 估算，
 *  孤立 ack 不再虚假归零）；不可读/无文件时返回零值（调用方据此走 absent/unreadable 语义需改用快照）。 */
export interface SteerChannelState { total: number; ackedSeq: number; pending: number; lastSteerAt?: number }

export function readSteerChannelState(taskId: string): SteerChannelState {
	const snap = readSteerChannelSnapshot(taskId);
	if (snap.availability !== "readable") return { total: 0, ackedSeq: 0, pending: 0 };
	return { total: snap.total, ackedSeq: snap.ackedSeq, pending: snap.pending, ...(snap.lastSteerAt !== undefined ? { lastSteerAt: snap.lastSteerAt } : {}) };
}

/**
 * 通道状态单行渲染（task_query summary / recovery show 消费同一文案）。
 *  - readable 且有未注入：分项列活跃待注入（承诺下个请求注入）与已淘汰未注入（明示不会自动注入）。
 *  - absent：「未记录或已回收，无法据此证明全部注入」（有审计回收记录则附回收时刻/原因）。
 *  - unreadable：「不可读——不视为全部注入」（pending=0 不是成功信号）。
 */
export function formatSteerChannelLine(s: Readonly<SteerChannelSnapshot>): string {
	if (s.availability === "absent") {
		const reclaim = s.reclaimed !== undefined
			? `（${new Date(s.reclaimed.at).toISOString()} 因${s.reclaimed.reason === "ttl" ? "TTL 7 天" : "目录软阈值"}回收——回收前状态见 task-steer-gc.log 审计行）`
			: "";
		return `steer 通道: 未记录或已回收${reclaim}，无法据此证明全部注入`;
	}
	if (s.availability === "unreadable") {
		return "steer 通道: 不可读（无法核对注入状态——不视为全部注入）";
	}
	if (s.pending === 0) {
		return `steer 通道: 已注入 ${s.ackedCount}/${s.total}${s.badLines > 0 ? `·坏行 ${s.badLines}` : ""}`;
	}
	const parts = [`未注入 ${s.pending}/${s.total}`];
	if (s.pendingActive > 0) parts.push(`活跃待注入 ${s.pendingActive}（下个模型请求前注入）`);
	if (s.inactiveUnacked > 0) parts.push(`已被活跃预算淘汰未注入 ${s.inactiveUnacked}（不会在下个请求自动注入）`);
	if (s.badLines > 0) parts.push(`坏行 ${s.badLines}`);
	return `steer 通道: ${parts.join("·")}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// 安全生命周期 GC（§② 八条规则；分类保护由应用层注入）
// ─────────────────────────────────────────────────────────────────────────────

/** 主上授权参数：最小可删年龄 24h（契约终态 exited 也要等满窗口才可删）。 */
export const STEER_CHANNEL_MIN_AGE_DEFAULT_MS = 24 * 60 * 60 * 1000;
/** 主上授权参数：TTL 7 天（超龄终态文件按 TTL 回收，reason=ttl）。 */
export const STEER_CHANNEL_TTL_DEFAULT_MS = 7 * 24 * 60 * 60 * 1000;
/** 主上授权参数：目录软阈值 64（>64 才对具资格文件按 mtime 旧→新删到 64；保护文件宁可暂超限）。 */
export const STEER_CHANNEL_MAX_FILES_DEFAULT = 64;
/** 低频节流：同进程两次真实清扫最小间隔（30 分钟；无后台定时器，触发点=启动恢复完成后/新 steer 写入后）。 */
export const STEER_CHANNEL_SWEEP_INTERVAL_MS = 30 * 60 * 1000;
/** 审计日志保留行数（≤256 行自截断保留最新；审计过期时回收说明退化为「未知」）。 */
const STEER_GC_LOG_MAX_LINES = 256;
const STEER_GC_LOG_NAME = "task-steer-gc.log";

/** 总开关：`AMAGI_TASK_STEER_GC=0/false/off` 关闭 steer 通道生命周期 GC（查询投影不受影响）。 */
export function steerChannelGcEnabled(): boolean {
	const v = process.env.AMAGI_TASK_STEER_GC?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** 单文件生命周期分类（应用层注入；本模块零生命周期知识）。 */
export type SteerChannelLifecycleClass =
	| { kind: "terminal-exited" }
	| { kind: "protected"; reason: "active" | "process-alive" | "process-unknown" | "needs-reconciliation" | "no-contract" };

/** 分类器（taskId → 生命周期分类；可异步——应用层经契约 store load）。 */
export type SteerChannelClassifier = (taskId: string) => SteerChannelLifecycleClass | Promise<SteerChannelLifecycleClass>;

/** 回收审计事件（taskId/原因/mtime/bytes/回收前 pending 分项，§⑧）。 */
export interface SteerChannelGcEvent {
	taskId: string;
	reason: "ttl" | "cap";
	mtimeMs: number | null;
	bytes: number | null;
	at: number;
	/** 回收前 pending 分项（快照可读时；不可读 null——如实，不臆造）。 */
	pending: { pending: number; pendingActive: number; inactiveUnacked: number } | null;
}

/** 清扫结果（§⑤：protected/deferred/remaining 统计如实返回，不为硬数量删通信）。 */
export interface SteerChannelSweepResult {
	/** true = 本次真实执行了扫描（含 dry-run）。 */
	scanned: boolean;
	/** true = 被开关关闭/子进程身份/未隔离 node:test 跳过（三者都不应动真实通道文件）。 */
	disabled: boolean;
	/** true = 节流窗口内（force 可绕过；dry-run 不节流）。 */
	throttled: boolean;
	/** true = 只分类不删除（部署首轮校验/测试）。 */
	dryRun: boolean;
	/** 扫描时通道文件总数（清扫前；不含 ignored 非常规条目）。 */
	total: number;
	/** 非常规条目数（非 .jsonl/不安全 taskId/symlink/目录/并发消失——一律不碰）。 */
	ignored: number;
	/** 分类保护数（含删除前复核期变卦）。 */
	protectedCount: number;
	/** 保护原因 → 计数（active/process-alive/process-unknown/needs-reconciliation/no-contract）。 */
	protectedReasons: Readonly<Record<string, number>>;
	/** 无可信契约孤儿样例（≤8 个 taskId，需人工确认；总数见 protectedReasons["no-contract"]）。 */
	manualReview: readonly string[];
	/** 具资格但延后（年轻终态 <24h / 删除前复核文件身份·mtime·生命周期变化 / 软阈值未选中）。 */
	deferred: number;
	/** 实际删除事件（含真实 taskId/reason/pending 分项，与审计行一致）。 */
	deleted: readonly SteerChannelGcEvent[];
	/** dry-run 候选计划（按删除序；不执行、不写审计）。 */
	wouldDelete: readonly { taskId: string; reason: "ttl" | "cap" }[];
	/** 清扫后剩余通道文件数（软阈值下可 >64——保护文件宁可暂超限）。 */
	remaining: number;
	/** 删除尝试失败数（文件保留原样，下次清扫重试）。 */
	failed: number;
}

export interface SteerChannelSweepOpts {
	/** 注入当前时刻（测试）；缺省 Date.now()。 */
	now?: number;
	/** 绕过节流（测试/显式运维）。 */
	force?: boolean;
	/** 最小可删年龄覆盖（缺省 24h；<=0 视为 0——仅测试用）。 */
	minAgeMs?: number;
	/** TTL 覆盖（缺省 7d；<=0 关闭 TTL 回收）。 */
	ttlMs?: number;
	/** 目录软阈值覆盖（缺省 64；<=0 关闭 cap 回收）。 */
	maxFiles?: number;
	/** 只分类不删除不写审计（部署首轮校验）。 */
	dryRun?: boolean;
}

/** 未隔离 node:test 进程绝不触默认数据目录（同 task-write-log 守卫动机：防测试删真实数据）。 */
function gcBlockedInUnisolatedTest(): boolean {
	return Boolean(process.env.NODE_TEST_CONTEXT && !process.env.AMAGI_DATA_DIR);
}

/** 清扫节流状态（进程级；resetSteerChannelForTest 复位）。 */
let lastSweepAt = 0;

function steerGcLogFile(): string {
	return path.join(amagiDataDir(), STEER_GC_LOG_NAME);
}

/** 审计日志落盘（追加 + ≤256 行自截断保留最新；失败静默——审计不得反噬回收本身，§⑧）。 */
function appendSteerGcLog(events: readonly SteerChannelGcEvent[]): void {
	if (events.length === 0) return;
	const logFile = steerGcLogFile();
	try {
		let lines: string[] = [];
		try { lines = fs.readFileSync(logFile, "utf8").split("\n").filter(Boolean); } catch { /* lint-exempt:审计日志首读无文件 */ }
		for (const e of events) {
			lines.push(JSON.stringify({
				at: new Date(e.at).toISOString(), taskId: e.taskId, reason: e.reason,
				mtime: e.mtimeMs === null ? null : new Date(e.mtimeMs).toISOString(), bytes: e.bytes,
				pending: e.pending,
			}));
		}
		const overflow = lines.length - STEER_GC_LOG_MAX_LINES;
		if (overflow > 0) lines = lines.slice(overflow);
		fs.writeFileSync(logFile, lines.join("\n") + "\n", "utf8");
	} catch { /* lint-exempt:审计失败静默 */ }
}

/** 审计最近项：该 taskId 最后一次回收记录（倒序找；无审计/被截断 → undefined 保持未知，§⑧）。 */
export function findSteerChannelReclaim(taskId: string): { reason: "ttl" | "cap"; at: number } | undefined {
	let lines: string[];
	try { lines = fs.readFileSync(steerGcLogFile(), "utf8").split("\n").filter(Boolean); } catch { /* lint-exempt:审计日志不可读=无回收记录 */ return undefined; }
	for (let i = lines.length - 1; i >= 0; i--) {
		try {
			const v = JSON.parse(lines[i]!) as { taskId?: unknown; reason?: unknown; at?: unknown };
			if (v.taskId === taskId && (v.reason === "ttl" || v.reason === "cap")) {
				// 审计行 at 为 ISO 字符串（写入侧 new Date(e.at).toISOString()）；兼容数字形态防御未来改写
				const at = typeof v.at === "number" ? v.at : typeof v.at === "string" ? Date.parse(v.at) : NaN;
				if (Number.isFinite(at)) return { reason: v.reason, at };
			}
		} catch { /* lint-exempt:坏审计行跳过 */ }
	}
	return undefined;
}

/**
 * 安全生命周期清扫（§② 八条规则）。分类器由应用层注入（本模块不读 registry/store）；
 * classify 抛错按 no-contract 保护（fail-safe，宁可保留不可误删）。
 * 只整文件删除（rmSync），永不压缩/重写通道文件内容（§⑦）。
 */
export async function sweepSteerChannels(classify: SteerChannelClassifier, opts: SteerChannelSweepOpts = {}): Promise<SteerChannelSweepResult> {
	const now = opts.now ?? Date.now();
	const dryRun = opts.dryRun === true;
	const result: SteerChannelSweepResult = {
		scanned: false, disabled: false, throttled: false, dryRun,
		total: 0, ignored: 0, protectedCount: 0, protectedReasons: {}, manualReview: [],
		deferred: 0, deleted: [], wouldDelete: [], remaining: 0, failed: 0,
	};
	// ① 执行方仅 Leader：开关关闭 / 子进程身份 / 未隔离 node:test → disabled（在任何目录访问之前判定，
	//    保证未隔离测试绝不触默认数据目录）。
	if (!steerChannelGcEnabled()) { result.disabled = true; return result; }
	if (process.env.AMAGI_TASK_ID) { result.disabled = true; return result; }
	if (gcBlockedInUnisolatedTest()) { result.disabled = true; return result; }
	// ① 低频节流（30 分钟；dry-run 是校验工具不节流、不更新节流时刻）
	if (!dryRun && !opts.force && now - lastSweepAt < STEER_CHANNEL_SWEEP_INTERVAL_MS) { result.throttled = true; return result; }
	if (!dryRun) lastSweepAt = now;

	const dir = steerDir();
	let names: string[];
	try { names = fs.readdirSync(dir); } catch { /* lint-exempt:无通道目录=零文件常态 */ result.remaining = 0; return result; }
	result.scanned = true;

	/** classify 安全包装：抛错 → no-contract 保护（fail-safe）。 */
	const safeClassify = async (taskId: string): Promise<SteerChannelLifecycleClass> => {
		try { return await classify(taskId); } catch { /* lint-exempt:分类器异常按 no-contract 保护（fail-safe 宁可保留不可误删） */ return { kind: "protected", reason: "no-contract" }; }
	};

	const minAge = opts.minAgeMs !== undefined ? Math.max(0, opts.minAgeMs) : STEER_CHANNEL_MIN_AGE_DEFAULT_MS;
	const ttl = opts.ttlMs !== undefined ? Math.max(0, opts.ttlMs) : STEER_CHANNEL_TTL_DEFAULT_MS;
	const maxFiles = opts.maxFiles !== undefined ? Math.floor(opts.maxFiles) : STEER_CHANNEL_MAX_FILES_DEFAULT;

	const protectedReasons: Record<string, number> = {};
	const manualReview: string[] = [];
	interface Cand { taskId: string; file: string; mtimeMs: number; bytes: number; dev: number; ino: number }
	const candidates: Cand[] = [];
	let total = 0;
	let ignored = 0;
	let deferred = 0;
	for (const name of names) {
		if (!name.endsWith(".jsonl")) { ignored++; continue; }
		const taskId = name.slice(0, -6);
		if (!SAFE_TASK_ID.test(taskId)) { ignored++; continue; } // ⑦ 仅识别安全 taskId 常规 .jsonl
		const file = path.join(dir, name);
		let st: fs.Stats;
		try { st = fs.lstatSync(file); } catch { /* lint-exempt:并发消失条目跳过 */ ignored++; continue; }
		if (st.isSymbolicLink() || !st.isFile()) { ignored++; continue; } // ⑦ lstat 拒 symlink/目录
		total++;
		const cls = await safeClassify(taskId);
		if (cls.kind !== "terminal-exited") {
			result.protectedCount++;
			protectedReasons[cls.reason] = (protectedReasons[cls.reason] ?? 0) + 1;
			if (cls.reason === "no-contract" && manualReview.length < 8) manualReview.push(taskId);
			continue;
		}
		if (now - st.mtimeMs < minAge) { deferred++; continue; } // ③ young closed：等满 24h
		candidates.push({ taskId, file, mtimeMs: st.mtimeMs, bytes: st.size, dev: st.dev, ino: st.ino });
	}
	result.total = total;
	result.ignored = ignored;
	result.protectedReasons = protectedReasons;
	result.manualReview = manualReview;

	// ④ 稳定排序：mtime 旧→新；相同按 taskId 字典序
	candidates.sort((a, b) => (a.mtimeMs - b.mtimeMs) || (a.taskId < b.taskId ? -1 : a.taskId > b.taskId ? 1 : 0));

	// ④ 计划：TTL（≥7d）全删；目录 >64 时补 cap（具资格文件旧→新删到 64 或候选耗尽）
	const plan: Array<{ c: Cand; reason: "ttl" | "cap" }> = [];
	const inPlan = new Set<string>();
	if (ttl > 0) {
		for (const c of candidates) {
			if (now - c.mtimeMs >= ttl) { plan.push({ c, reason: "ttl" }); inPlan.add(c.taskId); }
		}
	}
	if (maxFiles > 0 && total - plan.length > maxFiles) {
		let picked = 0;
		const need = total - plan.length - maxFiles;
		for (const c of candidates) {
			if (picked >= need) break;
			if (inPlan.has(c.taskId)) continue;
			plan.push({ c, reason: "cap" });
			inPlan.add(c.taskId);
			picked++;
		}
	}

	if (dryRun) {
		result.wouldDelete = plan.map(({ c, reason }) => ({ taskId: c.taskId, reason }));
		result.deferred = deferred + (candidates.length - plan.length); // 未入选候选也属「本次不删」
		result.remaining = total;
		return result;
	}

	// ⑦ 执行删除：删除前复核文件身份（dev/ino）与 mtime 未变 + 生命周期仍 terminal-exited；变化则延后
	const events: SteerChannelGcEvent[] = [];
	let failed = 0;
	for (const { c, reason } of plan) {
		let cur: fs.Stats;
		try { cur = fs.lstatSync(c.file); } catch { /* lint-exempt:并发消失不计数为删 */ deferred++; continue; }
		if (cur.isSymbolicLink() || !cur.isFile() || cur.dev !== c.dev || cur.ino !== c.ino || cur.mtimeMs !== c.mtimeMs) {
			deferred++;
			continue;
		}
		const recheck = await safeClassify(c.taskId);
		if (recheck.kind !== "terminal-exited") {
			result.protectedCount++;
			protectedReasons[recheck.reason] = (protectedReasons[recheck.reason] ?? 0) + 1;
			deferred++;
			continue;
		}
		// ⑧ 审计携带回收前 pending 分项（快照不可读如实 null）
		const snap = readSteerChannelSnapshot(c.taskId);
		const pendingPart = snap.availability === "readable"
			? { pending: snap.pending, pendingActive: snap.pendingActive, inactiveUnacked: snap.inactiveUnacked }
			: null;
		try {
			fs.rmSync(c.file, { force: true });
		} catch {
			/* lint-exempt:rm 失败计入 failed 留原文件下次重试（§⑧ 不影响投递/结算） */
			failed++;
			continue;
		}
		events.push({ taskId: c.taskId, reason, mtimeMs: c.mtimeMs, bytes: c.bytes, at: now, pending: pendingPart });
	}
	appendSteerGcLog(events);
	result.deleted = events;
	result.deferred = deferred;
	result.failed = failed;
	result.remaining = total - events.length;
	return result;
}

/**
 * 测试隔离：清空当前 AMAGI_DATA_DIR 下的 task-steer 目录与 GC 审计日志，复位清扫节流。
 * 仅在 AMAGI_DATA_DIR 显式注入（测试契约）时清盘；节流复位无条件（不触碰任何用户数据）。
 */
export function resetSteerChannelForTest(): void {
	lastSweepAt = 0;
	if (!process.env.AMAGI_DATA_DIR) return;
	try { fs.rmSync(steerDir(), { recursive: true, force: true }); } catch { /* lint-exempt:测试清理尽力而为 */ }
	try { fs.rmSync(steerGcLogFile(), { force: true }); } catch { /* lint-exempt:同上 */ }
}
