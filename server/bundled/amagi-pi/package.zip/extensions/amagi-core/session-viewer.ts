/**
 * session-viewer.ts — 子 Agent 会话只读查看器（面板与交互优化 M4）。
 *
 * 能力：
 *   - resolveSessionFile：taskId/sessionId 前缀 → 会话 JSONL 文件路径（registry 优先，
 *     兜底 sessions 目录文件名 uuid 前缀匹配；name 经 TaskRecord.name 覆盖）。
 *   - parseSessionJsonl：JSONL → 渲染条目（user/assistant/toolCall/toolResult/meta 折叠，
 *     损坏行计数跳过）。纯函数。
 *   - renderViewerLines：viewport 窗口渲染（header/条目/footer）。纯函数。
 *   - createViewerComponent：结构化 Component（pi-tui 契约 render/handleInput/invalidate/dispose），
 *     异步加载（>2MB 尾载，cap 最近 2000 条），j/k/d/u/g/G 滚动、q/Esc 经 onExit 回调逐级返回。
 *
 * dist 证据：
 *   - 文件位置/编码：session-manager.js getDefaultSessionDirPath —— `--${cwd.replace(/^[/\\]/,"").replace(/[/\\:]/g,"-")}--`
 *     （实测目录 ~/.pi/agent/sessions/--Users-...--，文件名 <ISO时间戳>_<sessionUuid>.jsonl，uuid 即 session id）
 *   - 条目结构：docs/session-format.md —— type: session/message/model_change/thinking_level_change/
 *     compaction/branch_summary/custom/custom_message/label/session_info；message.content 块：
 *     text/thinking/toolCall；toolResult 为 role="toolResult" 的 message（含 toolName/isError）
 *   - Component 契约：pi-tui tui.d.ts L10-28（render(width):string[] / handleInput(data) / invalidate / dispose）
 *
 * 上游：技术实现方案 §7；交互设计 §5。渲染路径绝不抛错（P2 原则）。
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { TaskRecord } from "./task-registry.ts";
import { fmtKey, paint, sectionLine, trimDisplayOf, cellWidthOf, type ThemeLike } from "./ui-shared.ts";

// ── 定位（M4-01） ───────────────────────────────────────────────────────────

function defaultAgentDir(): string {
	return process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

/** cwd → sessions 子目录名（与 session-manager getDefaultSessionDirPath 同规则）。 */
export function encodeCwdDir(cwd: string): string {
	const resolved = path.resolve(cwd);
	return `--${resolved.replace(/^[/\\]/, "").replace(/[/\\:]/g, "-")}--`;
}

/** 全局兜底索引缓存（sessions 根 → 全部 .jsonl 路径；TTL 5s——低频点查共享一次目录遍历）。 */
const sessionFilesIndexCache = new Map<string, { at: number; files: string[] }>();
const SESSION_FILES_INDEX_TTL_MS = 5_000;

/** 列出 sessions 根下全部子目录的 .jsonl 文件（单层子目录；各子目录不可读互不影响）。 */
function listAllSessionFiles(sessionsRoot: string, now: number): string[] {
	const cached = sessionFilesIndexCache.get(sessionsRoot);
	if (cached && now - cached.at < SESSION_FILES_INDEX_TTL_MS) return cached.files;
	const files: string[] = [];
	try {
		for (const e of fs.readdirSync(sessionsRoot, { withFileTypes: true })) {
			if (!e.isDirectory()) continue;
			const sub = path.join(sessionsRoot, e.name);
			let names: fs.Dirent[];
			try { names = fs.readdirSync(sub, { withFileTypes: true }); } catch { continue; }
			for (const f of names) {
				if (f.isFile() && f.name.endsWith(".jsonl")) files.push(path.join(sub, f.name));
			}
		}
	} catch { /* sessions 根不可读 → 空索引（本次与 TTL 内后续调用均不命中） */ }
	sessionFilesIndexCache.set(sessionsRoot, { at: now, files });
	return files;
}

export interface ResolveSessionOpts {
	/** registry 快照（优先从中取 sessionId/name）。 */
	records?: Readonly<TaskRecord>[];
	/** 任务工作目录（子会话落盘目录按任务 cwd 编码）。缺省 process.cwd()。 */
	cwd?: string;
	/** 测试注入 agent 根目录。 */
	agentDir?: string;
}

/**
 * 解析查询（taskId / sessionId / name 前缀，大小写不敏感）→ 会话文件绝对路径。
 * 匹配序：registry 精确 taskId → registry sessionId/name 前缀（新到旧）→
 * sessions 目录文件名 uuid 前缀（mtime 新到旧）→ 全局兜底（跨全部 sessions 子目录，
 * 2026-09-11 新增：record.cwd 与实际落盘目录不一致时仍可定位）。未命中返回 undefined。
 */
export function resolveSessionFile(query: string, opts: ResolveSessionOpts = {}): string | undefined {
	const q = String(query || "").trim().toLowerCase();
	if (!q) return undefined;
	const cwd = opts.cwd || process.cwd();
	const agentDir = opts.agentDir || defaultAgentDir();
	const base = path.join(agentDir, "sessions", encodeCwdDir(cwd));
	let sessionId: string | undefined;

	const records = [...(opts.records ?? [])].sort((a, b) => (b.startedAt || 0) - (a.startedAt || 0));
	const byTaskId = records.find((r) => r.taskId.toLowerCase() === q && r.sessionId);
	if (byTaskId) sessionId = byTaskId.sessionId;
	if (!sessionId) {
		const byPrefix = records.find((r) =>
			(r.sessionId?.toLowerCase().startsWith(q) || r.name?.toLowerCase().startsWith(q)) && r.sessionId);
		if (byPrefix) sessionId = byPrefix.sessionId;
	}
	const target = sessionId?.toLowerCase() || q;

	// 目录扫描：文件名 uuid 段前缀匹配（registry 命中的 sessionId 或裸查询词），mtime 新到旧取首个。
	// session 文件名 = <ISO时间戳>_<sessionUuid>.jsonl：无 timestamp 无法直拼真名，统一走前缀扫描。
	const hits: { file: string; mtime: number }[] = [];
	let entries: fs.Dirent[] = [];
	try { entries = fs.readdirSync(base, { withFileTypes: true }); } catch { /* cwd 编码目录缺失 → 全局兜底 */ }
	for (const e of entries) {
		if (!e.isFile() || !e.name.endsWith(".jsonl")) continue;
		const uuid = e.name.replace(/\.jsonl$/, "").split("_").slice(1).join("_");
		if (uuid && uuid.toLowerCase().startsWith(target)) {
			try { hits.push({ file: path.join(base, e.name), mtime: fs.statSync(path.join(base, e.name)).mtimeMs }); } catch {}
		}
	}
	if (hits.length === 0) {
		// 全局兜底（2026-09-11 真机「未找到会话文件」修复）：record.cwd 与子进程实际 session 目录
		// 不一致（cwd 字段缺失回退 Leader cwd / 跨项目任务 / worktree）时 base 目录不是会话所在；
		// 跨全部 sessions 子目录按 target 前缀再搜（索引 5s 缓存，低频调用近零成本；
		// target=sessionId 时 UUID 前缀足够独特，误配概率可忽略）。
		for (const file of listAllSessionFiles(path.join(agentDir, "sessions"), Date.now())) {
			if (path.dirname(file) === base) continue; // primary 已扫过
			const uuid = path.basename(file).replace(/\.jsonl$/, "").split("_").slice(1).join("_");
			if (!uuid || !uuid.toLowerCase().startsWith(target)) continue;
			try { hits.push({ file, mtime: fs.statSync(file).mtimeMs }); } catch {}
		}
	}
	if (hits.length === 0) return undefined;
	hits.sort((a, b) => b.mtime - a.mtime);
	return hits[0].file;
}

// ── 解析 + 渲染行（M4-01，纯函数） ──────────────────────────────────────────

export type ViewEntryKind = "user" | "assistant" | "tool" | "meta" | "custom" | "other";

export interface ViewEntry {
	kind: ViewEntryKind;
	/** 标签行（含符号与角色/工具名，已可着色前的裸文本）。 */
	label: string;
	/** 预览正文行（已折叠 ≤maxPreviewLines，含缩进）。 */
	lines: string[];
}

export interface ParseResult {
	entries: ViewEntry[];
	/** 损坏/未知行计数。 */
	skipped: number;
	/** 命中条目总数（解析成功行数，含 meta）。 */
	parsed: number;
}

const MAX_PREVIEW = 3;

function oneLine(text: unknown, max = 160): string {
	const s = String(text ?? "").replace(/\s+/g, " ").trim();
	return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

function contentPreview(blocks: unknown[], theme: ThemeLike, indent: string): { lines: string[]; thinkingHidden: number } {
	const out: string[] = [];
	let thinkingHidden = 0;
	for (const b of blocks) {
		const blk = b as Record<string, unknown>;
		if (blk?.type === "text" && typeof blk.text === "string") {
			const segs = blk.text.replace(/\s+$/g, "").split("\n");
			for (const seg of segs) {
				if (out.length >= MAX_PREVIEW) return { lines: out, thinkingHidden };
				out.push(trimDisplayOf(indent + paint(theme, "text", oneLine(seg)), 240));
			}
		} else if (blk?.type === "thinking") {
			thinkingHidden++;
		}
	}
	return { lines: out, thinkingHidden };
}

/**
 * 解析会话 JSONL 文本 → 渲染条目。
 * 折叠规则（交互设计 §5）：正文 ≤3 行预览；thinking 折叠计数；toolCall/toolResult 单行；
 * meta（model_change 等）单行 muted；custom 大 data 单行标注。
 */
export function parseSessionJsonl(text: string, theme?: ThemeLike): ParseResult {
	const entries: ViewEntry[] = [];
	let skipped = 0;
	for (const raw of String(text ?? "").split("\n")) {
		const line = raw.trim();
		if (!line) continue;
		let d: Record<string, unknown>;
		try { d = JSON.parse(line); } catch { skipped++; continue; }
		if (!d || typeof d !== "object" || typeof d.type !== "string") { skipped++; continue; }
		const ts = typeof d.timestamp === "string" ? d.timestamp.slice(11, 19) : "";
		const tsSeg = ts ? paint(theme, "dim", ts) + " " : "";
		switch (d.type) {
			case "session":
			case "model_change":
			case "thinking_level_change":
			case "compaction":
			case "branch_summary":
			case "label":
			case "session_info": {
				const label = d.type === "session" ? "session 头"
					: d.type === "session_info" ? `session_info ${oneLine(d.name, 40)}`
					: d.type === "model_change" ? `model → ${String(d.modelId ?? d.provider ?? "?")}`
					: d.type === "thinking_level_change" ? `thinking ${String(d.thinkingLevel ?? "?")}`
					: d.type === "compaction" ? "compaction 摘要"
					: d.type === "branch_summary" ? `branch ${oneLine(d.summary, 40)}`
					: `label ${oneLine(d.label, 40)}`;
				entries.push({ kind: "meta", label: `${tsSeg}${paint(theme, "muted", label)}`, lines: [] });
				continue;
			}
			case "custom": {
				entries.push({ kind: "custom", label: `${tsSeg}${paint(theme, "muted", `custom ${String(d.customType ?? "?")}`)}`, lines: [] });
				continue;
			}
			case "custom_message": {
				entries.push({ kind: "custom", label: `${tsSeg}${paint(theme, "muted", `custom_message ${String(d.customType ?? "?")}`)}`, lines: [trimDisplayOf("  " + oneLine(d.content), 240)] });
				continue;
			}
			case "message": {
				const msg = d.message as Record<string, unknown> | undefined;
				if (!msg || typeof msg.role !== "string") { skipped++; continue; }
				if (msg.role === "user") {
					const blocks = Array.isArray(msg.content)
						? msg.content
						: [{ type: "text", text: String(msg.content ?? "") }];
					const prev = contentPreview(blocks, theme, "  ");
					entries.push({ kind: "user", label: `${tsSeg}${paint(theme, "accent", "user")}`, lines: prev.lines });
					continue;
				}
				if (msg.role === "toolResult") {
					const blocks = Array.isArray(msg.content) ? msg.content : [];
					const first = blocks.find((b) => (b as Record<string, unknown>)?.type === "text");
					const txt = first ? oneLine((first as Record<string, unknown>).text, 120) : "（无文本输出）";
					const err = msg.isError ? paint(theme, "error", "✗") : paint(theme, "success", "✓");
					entries.push({ kind: "tool", label: `${tsSeg}${paint(theme, "toolTitle", "tool")} ${String(msg.toolName ?? "?")} ${err} ${paint(theme, "dim", txt)}`, lines: [] });
					continue;
				}
				if (msg.role === "assistant") {
					const blocks = (Array.isArray(msg.content) ? msg.content : []) as Record<string, unknown>[];
					const toolCalls = blocks.filter((b) => b?.type === "toolCall");
					const prev = contentPreview(blocks, theme, "  ");
					const think = prev.thinkingHidden > 0 ? paint(theme, "dim", `（thinking×${prev.thinkingHidden} 折叠）`) : "";
					entries.push({
						kind: "assistant",
						label: `${tsSeg}${paint(theme, "accent", "assistant")} ${think}`,
						lines: prev.lines,
					});
					for (const tc of toolCalls) {
						const args = tc.arguments as Record<string, unknown> | undefined;
						const argKey = args && typeof args === "object" ? Object.keys(args).slice(0, 3).join(",") : "";
						entries.push({
							kind: "tool",
							label: `${tsSeg}${paint(theme, "toolTitle", "tool")} ${String(tc.name ?? "?")}(${argKey})`,
							lines: [],
						});
					}
					continue;
				}
				entries.push({ kind: "other", label: `${tsSeg}${paint(theme, "muted", `message(${msg.role})`)}`, lines: [] });
				continue;
			}
			default:
				skipped++;
		}
	}
	return { entries, skipped, parsed: entries.length };
}

/** 条目 → 扁平行（label 行 + lines），供窗口切片。 */
export function flattenEntries(entries: ViewEntry[]): string[] {
	const out: string[] = [];
	for (const e of entries) {
		out.push(e.label);
		out.push(...e.lines);
	}
	return out;
}

export interface ViewerRenderOpts {
	width: number;
	/** 窗口起始行（0 基，相对扁平行）。 */
	offset: number;
	/** 可见行数（正文区，不含 header/footer）。 */
	viewport: number;
	/** 头部标题行（由调用方组装 agent/session 信息）。 */
	header: string;
	/** 总条目数与跳过数（footer 展示）。 */
	parsed: number;
	skipped: number;
	theme?: ThemeLike;
	/** 加载态文案（异步加载中）。 */
	loading?: string;
	/** 加载失败文案（有值时正文区显示错误块）。 */
	error?: string;
}

/** viewport 渲染：header + 窗口切片 + 位置指示 + footer 键位（mac 符号，R4）。 */
export function renderViewerLines(lines: string[], opts: ViewerRenderOpts): string[] {
	const w = Math.max(24, opts.width - 2);
	const vp = Math.max(1, opts.viewport);
	const total = lines.length;
	const header = trimDisplayOf(opts.header, w);
	const footer = trimDisplayOf(
		paint(opts.theme, "dim", `${fmtKey("j")}/${fmtKey("k")}↑↓ · ${fmtKey("d")}/${fmtKey("u")}半页 · ${fmtKey("g")}/${fmtKey("G")}首尾 · ${fmtKey("q")}/${fmtKey("esc")}返回`),
		w,
	);
	if (opts.error) {
		return [header, paint(opts.theme, "error", `✗ ${opts.error}`), footer];
	}
	if (opts.loading) {
		return [header, paint(opts.theme, "muted", `⏳ ${opts.loading}`), footer];
	}
	const maxOffset = Math.max(0, total - vp);
	const offset = Math.min(Math.max(0, opts.offset), maxOffset);
	const window_ = lines.slice(offset, offset + vp);
	const pos = total > vp ? ` [${offset + 1}-${offset + window_.length}/${total}]` : "";
	const skipNote = opts.skipped > 0 ? ` · 跳过 ${opts.skipped} 损坏行` : "";
	const bar = trimDisplayOf(paint(opts.theme, "dim", `──${pos}${skipNote}──`), w);
	return [header, ...window_, bar, footer];
}

// ── 异步加载（M4-02 组件数据源） ────────────────────────────────────────────

export const LARGE_FILE_BYTES = 2 * 1024 * 1024;
export const TAIL_ENTRY_CAP = 2000;

/** 读取会话文件文本：小文件全量；大文件尾窗（256KiB 行对齐，条目 cap 由 parse 层无、由调用方截取）。 */
export async function readSessionText(file: string): Promise<{ text: string; truncated: boolean }> {
	const st = await fs.promises.stat(file);
	if (st.size <= LARGE_FILE_BYTES) {
		return { text: await fs.promises.readFile(file, "utf8"), truncated: false };
	}
	const tailBytes = Math.min(st.size, 256 * 1024);
	const fh = await fs.promises.open(file, "r");
	try {
		const buf = Buffer.alloc(tailBytes);
		await fh.read(buf, 0, tailBytes, st.size - tailBytes);
		let text = buf.toString("utf8");
		const firstNl = text.indexOf("\n");
		if (firstNl >= 0) text = text.slice(firstNl + 1); // 丢弃残行
		return { text, truncated: true };
	} finally {
		await fh.close().catch(() => {});
	}
}

// ── 组件（M4-02） ───────────────────────────────────────────────────────────

export interface ViewerComponentDeps {
	registry: { list(): Readonly<TaskRecord>[] };
	/** 查询（taskId/sessionId/name 前缀）。 */
	query: string;
	/** 任务工作目录（resolveSessionFile 用；缺省 process.cwd()）。 */
	cwd?: string;
	/** 测试注入 agent 根目录。 */
	agentDir?: string;
	/** 组件标题附注（agent 名等）。 */
	titleNote?: string;
	onExit: () => void;
	theme?: ThemeLike;
	/** 测试注入读取器。 */
	read?: (file: string) => Promise<{ text: string; truncated: boolean }>;
	/** 测试注入时钟。 */
	now?: () => number;
}

export interface ViewerHandle {
	lines(): string[];
	offset(): number;
	total(): number;
	error(): string | undefined;
	loading(): boolean;
	truncatedNote(): string | undefined;
	/** 键输入（测试驱动）。 */
	input(data: string): void;
	setViewport(vp: number): void;
}

/**
 * 创建 viewer 结构化组件（同步返回；内部异步加载数据完成后 requestRender 重渲）。
 * 键位：j/k 行滚 · d/u 半页 · g/G 首尾 · r 重载 · q/Esc onExit 逐级返回。
 */
export function createViewerComponent(deps: ViewerComponentDeps): {
	render: (width: number) => string[];
	handleInput: (data: string) => void;
	invalidate: () => void;
	dispose: () => void;
	/** 测试观测面。 */
	handle: ViewerHandle;
} {
	const state = {
		lines: [] as string[],
		offset: 0,
		parsed: 0,
		skipped: 0,
		loading: true,
		error: "" as string | undefined,
		truncatedNote: undefined as string | undefined,
		viewport: 10,
		atBottom: true,
	};
	const read = deps.read ?? readSessionText;
	let disposed = false;
	let requestRender: (() => void) | undefined;
	const now = deps.now ?? Date.now;

	async function load(): Promise<void> {
		state.loading = true;
		state.error = undefined;
		try {
			const file = resolveSessionFile(deps.query, { records: deps.registry.list(), cwd: deps.cwd, agentDir: deps.agentDir });
			if (!file) {
				state.error = `未找到会话：${deps.query}（registry 无记录且 sessions 目录无 uuid 前缀匹配）`;
			} else {
				const { text, truncated } = await read(file);
				if (disposed) return;
				const res = parseSessionJsonl(text, deps.theme);
				let entries = res.entries;
				let skipped = res.skipped;
				let note: string | undefined;
				if (truncated || entries.length > TAIL_ENTRY_CAP) {
					const dropped = truncated ? `（文件 >2MB 已尾载）` : "";
					const cut = Math.max(0, entries.length - TAIL_ENTRY_CAP);
					entries = entries.slice(-TAIL_ENTRY_CAP);
					skipped += cut;
					note = `已跳过较早 ${cut} 条${dropped}，完整文件 ${file}`;
				}
				state.lines = flattenEntries(entries);
				state.parsed = entries.length;
				state.skipped = skipped;
				state.truncatedNote = note;
				state.offset = Math.max(0, state.lines.length - state.viewport); // 初始定位最新（底部）
			}
		} catch (e) {
			state.error = `读取失败：${e instanceof Error ? e.message : String(e)}`;
		} finally {
			state.loading = false;
			state.atBottom = true;
			try { requestRender?.(); } catch {}
		}
	}
	void load();

	const clamp = (): void => {
		const maxOffset = Math.max(0, state.lines.length - state.viewport);
		state.offset = Math.min(Math.max(0, state.offset), maxOffset);
	};

	const handle: ViewerHandle = {
		lines: () => [...state.lines],
		offset: () => state.offset,
		total: () => state.lines.length,
		error: () => state.error,
		loading: () => state.loading,
		truncatedNote: () => state.truncatedNote,
		setViewport: (vp: number) => { state.viewport = Math.max(1, Math.floor(vp)); clamp(); },
		input: (data: string) => {
			const half = Math.max(1, Math.floor(state.viewport / 2));
			if (data === "\x1b" || data === "q") { try { deps.onExit(); } catch {} }
			else if (data === "\x1b[B" || data === "j") { state.offset += 1; clamp(); }
			else if (data === "\x1b[A" || data === "k") { state.offset -= 1; clamp(); }
			else if (data === "\x1b[6~" || data === "d") { state.offset += half; clamp(); }
			else if (data === "\x1b[5~" || data === "u") { state.offset -= half; clamp(); }
			else if (data === "g") { state.offset = 0; }
			else if (data === "G") { state.offset = state.lines.length; clamp(); }
			else if (data === "r") { void load(); }
		},
	};

	const headerOf = (): string => {
		const note = deps.titleNote ? ` · ${deps.titleNote}` : "";
		const size = state.loading ? "" : ` · ${state.parsed} 条`;
		return `会话${note}${size}`;
	};

	return {
		render(width: number): string[] {
			const extra: string[] = [];
			if (state.truncatedNote) extra.push(state.truncatedNote);
			return renderViewerLines([...extra, ...state.lines], {
				width,
				offset: state.truncatedNote ? Math.max(0, state.offset - 1) : state.offset,
				viewport: state.viewport,
				header: headerOf(),
				parsed: state.parsed,
				skipped: state.skipped,
				theme: deps.theme,
				loading: state.loading ? "加载会话中…" : undefined,
				error: state.error,
			});
		},
		handleInput: (data: string) => handle.input(data),
		invalidate: () => {},
		dispose: () => { disposed = true; },
		handle,
	};
}

// re-export 便捷（tree-shaking 友好；cellWidthOf 供调用方对齐）
export { cellWidthOf };
