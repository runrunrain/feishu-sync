import * as fs from "node:fs";
import type { EventEnvelope } from "./events.ts";

export const HISTORY_PAGE_LIMIT = 200;
const MASK = "••••";
const SENSITIVE_FIELD = /token|secret|password|authorization/i;

export type SessionEntry = Record<string, unknown> & {
	type: string;
	id?: string;
	parentId?: string | null;
	timestamp?: string;
};

export interface ParsedSessionJsonl {
	header?: Record<string, unknown>;
	entries: SessionEntry[];
	skipped: number;
}

export interface HistoryStoreOptions {
	getSessionFile?: () => string | null | undefined;
	getProjection?: () => readonly unknown[] | undefined | Promise<readonly unknown[] | undefined>;
	/**
	 * v1.0.19：context 视图的运行时权威投影源。只接收 pi 0.87.1
	 * SessionManager.buildSessionProjection().entries（ProjectedSessionEntry[]
	 * 的结构子集 {sourceEntry, messages}）；不能混入 buildContextEntries() 结果
	 * （后者是未应用 context_edit 的 raw 选中条目）。空数组是合法权威结果，
	 * 不回退磁盘；返回错误形状按回调不可用处理走降级链；回调异常同样降级，
	 * 不向上扩大成宿主状态修改。原 getProjection 保持 history 视图用途不变。
	 */
	getContextProjection?: () => readonly unknown[] | undefined | Promise<readonly unknown[] | undefined>;
	getBufferedEvents?: () => readonly (EventEnvelope | unknown)[];
	readFile?: (file: string) => string | Promise<string>;
	/**
	 * v1.0.6：首页（无 since 且无 rev）usage 恢复基准快照源（可选注入，server.ts 装配点
	 * 接闭包常驻 UsageStore.snapshot()——活内存，不读盘）。返回非对象/形状不全 → 首页字段
	 * 缺席；注入方抛出的异常向上传播（page() 调用方决定 500），不做静默吞错。
	 */
	getUsageSnapshot?: () => unknown;
}

/** v1.0.19：历史视图（原始条目，缺省）与上下文视图（模型上下文投影）。 */
export type HistoryView = "history" | "context";

export interface HistoryPageQuery {
	since: string | null;
	limit: string | null;
	rev: string | null;
	/** v1.0.19：可选视图选择。缺省与未知值按 history（与既有缺省行为兼容）。 */
	view?: string | null;
}

export interface HistoryPage {
	v: 1;
	entries: Array<{ cursor: number; type: string; data: SessionEntry }>;
	nextCursor: number | null;
	revision: number;
	total: number;
	/** v1.0.19：本页实际使用的视图（history=原始历史；context=模型上下文投影）。 */
	view?: HistoryView;
	/**
	 * v1.0.6：仅首页（无 since 且无 rev）携带的 usage 恢复基准（形状与 v1.0.4
	 * hello.usage/usage_stats 的 UsageSnapshot 完全一致）。未注入/形状不全时字段缺席，
	 * 客户端按 §2 前向兼容规则忽略缺席。来自服务端可信聚合器的冻结深拷贝，
	 * 不走 entries 的敏感字段掩码（leader.contextTokens 与 usage_stats 豁免同口径）。
	 */
	usage?: unknown;
}

export class HistoryRequestError extends Error {
	readonly statusCode = 410;
	readonly body: { error: "cursor_expired"; currentRevision: number };

	constructor(currentRevision: number) {
		super("history cursor or revision is no longer valid");
		this.name = "HistoryRequestError";
		this.body = { error: "cursor_expired", currentRevision };
	}
}

function isSessionEntry(value: unknown): value is SessionEntry {
	return !!value && typeof value === "object"
		&& typeof (value as Record<string, unknown>).type === "string"
		&& (value as Record<string, unknown>).type !== "session";
}

/** Parse JSONL defensively like session-viewer: blank or damaged lines are skipped. */
export function parseSessionJsonl(text: string): ParsedSessionJsonl {
	let header: Record<string, unknown> | undefined;
	const entries: SessionEntry[] = [];
	let skipped = 0;
	for (const raw of String(text ?? "").split("\n")) {
		const line = raw.trim();
		if (!line) continue;
		let value: unknown;
		try { value = JSON.parse(line); } catch { skipped++; continue; }
		if (!value || typeof value !== "object" || typeof (value as Record<string, unknown>).type !== "string") {
			skipped++;
			continue;
		}
		if ((value as Record<string, unknown>).type === "session") {
			header ??= value as Record<string, unknown>;
			continue;
		}
		entries.push(value as SessionEntry);
	}
	return { header, entries, skipped };
}

/**
 * v1.0.19：活动分支选择——原 buildActiveProjection 的 parentId 回溯部分。
 * 从最后一个有 id 的条目（磁盘 fallback leaf）沿 parentId 走到根；visited 防环。
 * 返回原始条目引用，不做 compaction 截断，也不应用 context_edit。
 */
export function selectActiveBranch(entries: readonly SessionEntry[]): SessionEntry[] {
	if (entries.length === 0) return [];
	const byId = new Map<string, SessionEntry>();
	for (const entry of entries) if (typeof entry.id === "string") byId.set(entry.id, entry);
	let current = [...entries].reverse().find((entry) => typeof entry.id === "string");
	if (!current) return [];
	const reversed: SessionEntry[] = [];
	const visited = new Set<string>();
	while (current && typeof current.id === "string" && !visited.has(current.id)) {
		reversed.push(current);
		visited.add(current.id);
		current = typeof current.parentId === "string" ? byId.get(current.parentId) : undefined;
	}
	return reversed.reverse();
}

function isSystemMessageEntry(entry: SessionEntry): boolean {
	if (entry.type !== "message") return false;
	const message = entry.message;
	return !!message && typeof message === "object" && (message as Record<string, unknown>).role === "system";
}

/**
 * v1.0.19：context 视图的 compaction 区间选择（对齐 pi 0.87.1 buildContextEntries）。
 * 无 compaction → 整条活动分支；有 → 取路径上最后一个 compaction，输出
 * [最新 compaction, firstKeptEntryId 起保留的非 system 前缀, compaction 后条目]。
 * firstKeptEntryId 自指（retain-none）或引用无效/缺失 → 只保留最新 compaction 及其后，
 * 绝不保留已总结历史。仅旧形态（无该字段但有 retainedTail 数组）保持既有从 compaction
 * 截断的容错，不尝试由该数组重造会话消息。返回原始条目引用，不应用编辑。
 */
export function selectContextEntries(branch: readonly SessionEntry[]): SessionEntry[] {
	const compactionIndex = branch.findLastIndex((entry) => entry.type === "compaction");
	if (compactionIndex < 0) return branch.slice();
	const compaction = branch[compactionIndex];
	if (typeof compaction.firstKeptEntryId !== "string") {
		// 旧 retainedTail 形态与缺引用容错同形：[compaction, ...其后条目]。
		return branch.slice(compactionIndex);
	}
	const selected: SessionEntry[] = [compaction];
	let foundFirstKept = false;
	for (let i = 0; i < compactionIndex; i++) {
		const entry = branch[i];
		if (entry.id === compaction.firstKeptEntryId) foundFirstKept = true;
		if (foundFirstKept && !isSystemMessageEntry(entry)) selected.push(entry);
	}
	selected.push(...branch.slice(compactionIndex + 1));
	return selected;
}

type EditableTargetRole = "user" | "assistant" | "toolResult" | "custom";

/** 可编辑目标 = message(user/assistant/toolResult) 或 custom_message；system/compaction/其余类型不可编辑。 */
function editableTargetRole(entry: SessionEntry): EditableTargetRole | null {
	if (entry.type === "custom_message") return "custom";
	if (entry.type === "message") {
		const message = entry.message;
		if (message !== null && typeof message === "object") {
			const role = (message as Record<string, unknown>).role;
			if (role === "user" || role === "assistant" || role === "toolResult") return role;
		}
	}
	return null;
}

/** replacement 合法形状：null（省略）或含 string/array content 的对象。 */
function isReplacementShape(value: unknown): value is { content: unknown } {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const content = (value as Record<string, unknown>).content;
	return typeof content === "string" || Array.isArray(content);
}

/** assistant/toolResult 的 content 必须是块数组：字符串替换归一为单 text 块。 */
function normalizeReplacementContent(role: EditableTargetRole, content: unknown): unknown {
	if ((role === "assistant" || role === "toolResult") && typeof content === "string") {
		return [{ type: "text", text: content }];
	}
	return content;
}

/** 整个 content 替换（不拼接、不合并 replacement 额外键）；浅复制 entry/message，不改源对象。 */
function copyWithReplacedContent(
	entry: SessionEntry,
	role: EditableTargetRole,
	content: unknown,
	normalize: boolean,
): SessionEntry {
	const finalContent = normalize ? normalizeReplacementContent(role, content) : content;
	if (entry.type === "custom_message") return { ...entry, content: finalContent };
	const message = entry.message;
	if (message === null || typeof message !== "object") return entry;
	return { ...entry, message: { ...(message as Record<string, unknown>), content: finalContent } };
}

/**
 * v1.0.19：对已选中的 context 区间应用 context_edit，返回投影副本（不改入参）。
 * 区间形状：无 compaction 时整条活动分支；有 compaction 时 selectContextEntries
 * （或旧宿主 buildContextEntries）的输出。规则（§3.2）：
 * - 同目标取区间内最后一个有效编辑（按区间顺序，不按 timestamp）。
 * - 可编辑目标必须先于编辑出现（拒绝未来引用）；目标不在区间（被总结/跨支）→ 编辑惰性。
 * - 非 message(user/assistant/toolResult)/custom_message 目标与坏形状 replacement 按
 *   无效元数据保留，不作用于内容；控制条目 context_edit 自身保留为元数据。
 * - 省略目标不进入输出；替换只改返回副本的 content。
 * - 旧 compaction（非首个）不贡献 checkpoint/summary，不再呈现为当前摘要。
 */
export function applyContextEdits(selected: readonly SessionEntry[]): SessionEntry[] {
	const positions = new Map<string, number>();
	for (let i = 0; i < selected.length; i++) {
		const id = selected[i].id;
		if (typeof id === "string") positions.set(id, i);
	}
	const edits = new Map<string, { content: unknown }>();
	for (let i = 0; i < selected.length; i++) {
		const entry = selected[i];
		if (entry.type !== "context_edit") continue;
		const targetId = entry.targetId;
		if (typeof targetId !== "string") continue;
		const replacement = entry.replacement;
		if (replacement !== null && !isReplacementShape(replacement)) continue;
		const targetIndex = positions.get(targetId);
		if (targetIndex === undefined || targetIndex >= i) continue;
		if (editableTargetRole(selected[targetIndex]) === null) continue;
		edits.set(targetId, replacement === null
			? { content: null }
			: { content: (replacement as { content: unknown }).content });
	}
	const output: SessionEntry[] = [];
	let keptCompaction = false;
	for (const entry of selected) {
		if (entry.type === "compaction") {
			if (keptCompaction) continue;
			keptCompaction = true;
			output.push(entry);
			continue;
		}
		const edit = typeof entry.id === "string" ? edits.get(entry.id) : undefined;
		if (!edit) {
			output.push(entry);
			continue;
		}
		if (edit.content === null) continue; // 省略：目标不返回
		const role = editableTargetRole(entry);
		if (role === null) {
			output.push(entry);
			continue;
		}
		output.push(copyWithReplacedContent(entry, role, edit.content, true));
	}
	return output;
}

function isRuntimeProjectedEntry(value: unknown): value is { sourceEntry: SessionEntry; messages: readonly unknown[] } {
	if (!value || typeof value !== "object") return false;
	const record = value as Record<string, unknown>;
	return isSessionEntry(record.sourceEntry) && Array.isArray(record.messages);
}

function projectedMessageContent(messages: readonly unknown[], role: string): unknown {
	for (const message of messages) {
		if (message !== null && typeof message === "object"
			&& (message as Record<string, unknown>).role === role) {
			return (message as Record<string, unknown>).content;
		}
	}
	return undefined;
}

/**
 * v1.0.19：运行时权威投影转换——接受 SDK ProjectedSessionEntry[] 的结构子集
 * （{sourceEntry, messages}），把模型可见贡献转回本接口条目（不改源对象）：
 * - 可编辑 sourceEntry 的 messages=[] 表示省略（不进入输出）；有消息时从与 source
 *   role 对应的投影消息取 content，浅复制 entry/message 后替换。
 * - custom_message 从投影 custom 消息取 content；不把多个 SDK messages 摊平为新 id，
 *   不生成假 parentId。
 * - compaction 只保留真正有 checkpoint/summary 贡献的最新条目（messages=[] 的旧
 *   compaction 不再呈现为当前摘要）；其余合法状态/meta 条目原样保留。
 * 任何元素形状错误 → 整批按回调不可用处理（返回 null），不把缺字段对象当合法空投影。
 */
export function projectRuntimeEntries(projected: readonly unknown[]): SessionEntry[] | null {
	const output: SessionEntry[] = [];
	let keptCompaction = false;
	for (const item of projected) {
		if (!isRuntimeProjectedEntry(item)) return null;
		const entry = item.sourceEntry;
		if (entry.type === "compaction") {
			if (item.messages.length > 0 && !keptCompaction) {
				keptCompaction = true;
				output.push(entry);
			}
			continue;
		}
		const role = editableTargetRole(entry);
		if (role === null) {
			output.push(entry);
			continue;
		}
		if (item.messages.length === 0) continue; // 省略
		const content = projectedMessageContent(item.messages, role);
		output.push(content === undefined ? entry : copyWithReplacedContent(entry, role, content, false));
	}
	return output;
}

export interface ActiveProjectionOptions {
	/** v1.0.19：缺省 history（行为与既往一致）；context = 模型上下文投影。 */
	view?: HistoryView;
}

/**
 * JSONL fallback for current-branch projection. SessionManager.buildContextEntries
 * is preferred at runtime because an in-memory /tree selection need not be on disk.
 * v1.0.19：options.view="context" 走 selectActiveBranch → selectContextEntries →
 * applyContextEdits；缺省 history 行为字节不变（compaction 检查点截断）。
 */
export function buildActiveProjection(entries: readonly SessionEntry[], options: ActiveProjectionOptions = {}): SessionEntry[] {
	const branch = selectActiveBranch(entries);
	if (options.view === "context") return applyContextEdits(selectContextEntries(branch));
	const compactionIndex = branch.findLastIndex((entry) => entry.type === "compaction");
	if (compactionIndex < 0) return branch;
	const compaction = branch[compactionIndex];
	if (Array.isArray(compaction.retainedTail)) return branch.slice(compactionIndex);
	if (typeof compaction.firstKeptEntryId === "string") {
		const firstKept = branch.findIndex((entry) => entry.id === compaction.firstKeptEntryId);
		if (firstKept >= 0) return branch.slice(firstKept);
	}
	return branch.slice(compactionIndex);
}

function bufferedEntryCandidates(events: readonly (EventEnvelope | unknown)[]): SessionEntry[] {
	const output: SessionEntry[] = [];
	for (const item of events) {
		const event = item && typeof item === "object" && "kind" in item && "event" in item
			? (item as EventEnvelope).event
			: item;
		if (!event || typeof event !== "object") continue;
		const record = event as Record<string, unknown>;
		const nestedData = record.data && typeof record.data === "object" ? record.data as Record<string, unknown> : undefined;
		const candidates = [record.entry, record.historyEntry, nestedData?.entry, event];
		const candidate = candidates.find(isSessionEntry);
		if (candidate && typeof candidate.id === "string") output.push(candidate);
	}
	return output;
}

/** Merge runtime-only persisted entries without losing older JSONL entries after ring overflow.
 * v1.0.19：options.view="context" 启用 context 模式（见下 MergeBufferedContextOptions）
 * ——返回未应用编辑、未截断的原始分支，交由调用方重做 compaction 选择与编辑投影。 */
export function mergeBufferedEntries(
	projection: readonly SessionEntry[],
	events: readonly (EventEnvelope | unknown)[],
	options?: MergeBufferedContextOptions,
): SessionEntry[] {
	if (options?.view === "context") {
		return mergeBufferedContextEntries(projection, events, options.persistedIds ?? new Set());
	}
	const merged = projection.slice();
	for (const candidate of bufferedEntryCandidates(events)) {
		const existing = merged.findIndex((entry) => entry.id === candidate.id);
		if (existing >= 0) {
			merged[existing] = candidate;
			continue;
		}
		if (candidate.parentId === null) {
			merged.splice(0, merged.length, candidate);
			continue;
		}
		const parent = typeof candidate.parentId === "string"
			? merged.findIndex((entry) => entry.id === candidate.parentId)
			: -1;
		if (parent >= 0) merged.splice(parent + 1, merged.length - parent - 1, candidate);
		else merged.push(candidate);
	}
	return merged;
}

/** v1.0.19：mergeBufferedEntries 的 context 模式选项（§3.3）。 */
export interface MergeBufferedContextOptions {
	/** 必须为 "context"（类型层面固定 context 合并语义；缺省调用走既有合并路径）。 */
	view: "context";
	/** 本次完整磁盘 entries 的 id 集（磁盘权威）：已落盘 id 不被 ring 旧副本覆盖，遗弃分支旧事件也不重新加入。 */
	persistedIds?: ReadonlySet<string>;
}

/**
 * v1.0.19：context 模式缓冲合并——仍负责原始拓扑合并，不能先删除省略目标再合并
 * （被省略目标仍可能是后继条目的 parentId）。合并后由调用方重做 compaction 选择与
 * 编辑投影；本函数返回未应用编辑、未截断的原始分支。规则：
 * 1. persistedIds 命中的候选直接跳过（磁盘权威，遗弃分支旧事件不复活）。
 * 2. 候选按事件顺序处理、同一 id 去重；parentId=null 是明确新根（整表替换承接新分支）；
 *    父在当前分支时替换父之后的尾部；父在本批候选但尚未加入的条目有界暂存推进。
 * 3. 父缺失且非新根的候选本次不追加（下次磁盘/宿主快照补齐），绝不未知父硬拼。
 * 4. 无跨 refresh 原始副本缓存——每次从当前权威快照重建。
 */
function mergeBufferedContextEntries(
	rawBranch: readonly SessionEntry[],
	events: readonly (EventEnvelope | unknown)[],
	persistedIds: ReadonlySet<string>,
): SessionEntry[] {
	const merged = rawBranch.slice();
	const present = new Set<string>();
	for (const entry of merged) if (typeof entry.id === "string") present.add(entry.id);
	const candidates: Array<{ id: string; entry: SessionEntry }> = [];
	const seen = new Set<string>();
	for (const candidate of bufferedEntryCandidates(events)) {
		const id = candidate.id;
		if (typeof id !== "string" || seen.has(id) || persistedIds.has(id)) continue;
		seen.add(id);
		candidates.push({ id, entry: candidate });
	}
	const placed = new Set<string>();
	let progressed = true;
	while (progressed) {
		progressed = false;
		for (const candidate of candidates) {
			if (placed.has(candidate.id) || present.has(candidate.id)) continue;
			const entry = candidate.entry;
			if (entry.parentId === null) {
				merged.splice(0, merged.length, entry);
				present.clear();
				for (const item of merged) if (typeof item.id === "string") present.add(item.id);
				placed.add(candidate.id);
				progressed = true;
				continue;
			}
			const parentId = entry.parentId;
			if (typeof parentId !== "string" || !present.has(parentId)) continue; // 暂存：父未出现
			const parentIndex = merged.findIndex((item) => item.id === parentId);
			if (parentIndex < 0) continue;
			const removedTail = merged.splice(parentIndex + 1, merged.length - parentIndex - 1, entry);
			for (const removed of removedTail) if (typeof removed.id === "string") present.delete(removed.id);
			present.add(candidate.id);
			placed.add(candidate.id);
			progressed = true;
		}
	}
	return merged;
}

function isSensitiveField(name: string): boolean {
	const lower = name.toLowerCase();
	return lower === "key" || lower === "apikey" || SENSITIVE_FIELD.test(lower);
}

/** History keeps field shape for rendering but masks credential-like values. */
export function filterHistorySecrets<T>(value: T): T {
	const ancestors = new WeakSet<object>();
	const visit = (input: unknown): unknown => {
		if (input === null || typeof input !== "object") return input;
		if (ancestors.has(input)) return undefined;
		ancestors.add(input);
		try {
			if (Array.isArray(input)) return input.map(visit);
			const output: Record<string, unknown> = {};
			for (const [key, child] of Object.entries(input)) {
				output[key] = isSensitiveField(key) ? MASK : visit(child);
			}
			return output;
		} finally {
			ancestors.delete(input);
		}
	};
	return visit(value) as T;
}

function identityOf(entry: SessionEntry, index: number): string {
	if (typeof entry.id === "string") return entry.id;
	return `${entry.type}:${typeof entry.timestamp === "string" ? entry.timestamp : ""}:${index}`;
}

/**
 * v1.0.19：context 视图内容签名——对条目可观察形状做 JSON 序列化（不保存会被原位
 * 修改的对象引用作为旧快照比较依据；不落盘、不记录日志）。序列化失败退回身份键。
 */
function contentSignature(entry: SessionEntry, index: number): string {
	try {
		const signature = JSON.stringify(entry);
		return typeof signature === "string" ? signature : identityOf(entry, index);
	} catch { /* lint-exempt:非 JSON 安全条目退回身份键签名，签名失败不中断分页 */
		return identityOf(entry, index);
	}
}

function sameIdentity(left: readonly string[], right: readonly string[]): boolean {
	return left.length === right.length && left.every((value, index) => value === right[index]);
}

function isPureAppend(
	previous: readonly string[],
	next: readonly string[],
	entries: readonly SessionEntry[],
): boolean {
	if (next.length < previous.length) return false;
	if (!previous.every((value, index) => value === next[index])) return false;
	return !entries.slice(previous.length).some((entry) => entry.type === "compaction");
}

/**
 * v1.0.19：context 视图纯追加判定——旧前缀内容签名完全相同且尾部只有普通追加
 * （不含新 context_edit/compaction——即便最终内容相同也保守视为非纯追加）。
 */
function isContextPureAppend(
	previous: readonly string[],
	next: readonly string[],
	entries: readonly SessionEntry[],
): boolean {
	if (next.length < previous.length) return false;
	if (!previous.every((value, index) => value === next[index])) return false;
	return !entries.slice(previous.length).some((entry) => entry.type === "compaction" || entry.type === "context_edit");
}

function parseCursor(value: string | null): number | undefined {
	if (value === null || value === "") return 0;
	const parsed = Number(value);
	return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : undefined;
}

/**
 * rev 解析（M3）：since（cursor）仍要求非负整数序号；rev 只要求非负有限数值——
 * history 自然数与 context 半整数两个空间都是合法输入，garbage 输入照旧经解析
 * 失败或与当前 revision 不相等拒绝，410 错误形态与既有完全一致。
 */
function parseRevision(value: string | null): number | undefined {
	if (value === null || value === "") return 0;
	const parsed = Number(value);
	return Number.isFinite(parsed) && parsed >= 0 ? parsed : undefined;
}

function pageLimit(value: string | null): number {
	if (value === null || value === "") return HISTORY_PAGE_LIMIT;
	const parsed = Number(value);
	if (!Number.isSafeInteger(parsed) || parsed < 1) return HISTORY_PAGE_LIMIT;
	return Math.min(parsed, HISTORY_PAGE_LIMIT);
}

/**
 * v1.0.6：首页 usage 恢复字段的形状防御——与 v1.0.4 冻结 wire 形状（UsageSnapshot）
 * 一致：models 为普通对象、leader 具备 model/contextTokens/contextWindow、scope 为
 * null 或 {tasks, active}、updatedAt 为有限数值。非对象/形状不全 → 字段缺席。
 */
function isUsageSnapshotLike(value: unknown): boolean {
	if (!value || typeof value !== "object") return false;
	const snapshot = value as Record<string, unknown>;
	if (!snapshot.models || typeof snapshot.models !== "object" || Array.isArray(snapshot.models)) return false;
	const leader = snapshot.leader;
	if (!leader || typeof leader !== "object") return false;
	const leaderRecord = leader as Record<string, unknown>;
	if (!("model" in leaderRecord) || !("contextTokens" in leaderRecord) || !("contextWindow" in leaderRecord)) return false;
	const scope = snapshot.scope;
	if (scope !== null) {
		if (!scope || typeof scope !== "object") return false;
		const scopeRecord = scope as Record<string, unknown>;
		if (!("tasks" in scopeRecord) || !("active" in scopeRecord)) return false;
	}
	return typeof snapshot.updatedAt === "number" && Number.isFinite(snapshot.updatedAt);
}

/** 每视图独立快照空间：revision、cursor 序列与指纹互不污染（§3.1/§3.5）。 */
interface ViewSnapshotState {
	revision: number;
	/** 本视图是否已服务过至少一页（续拉前置：切换视图必须从无 since/rev 首页开始）。 */
	served: boolean;
	entries: readonly SessionEntry[];
	/** history=identityOf 身份键；context=contentSignature 内容签名。 */
	fingerprints?: string[];
}

/**
 * M3 跨视图游标执法补强（2026-09-30 审计收口）：两视图 revision 数值空间结构性
 * 不相交——history 恒为自然数（初始 1，变更 +1，既有行为字节不变）；context 恒为
 * 半整数（初始 1.5，代数步进仍为 +1：1.5→2.5→…）。任一视图下发的 rev 在另一
 * 视图恒不匹配，page() 的 revision 相等比较因此无条件拒绝跨视图 cursor/rev 复用
 * （含两视图均已服务过、各自代数相同的常态，契约 §4.2 错误表措辞由此成立）。
 * 客户端只做 rev 相等/不等比较与原样回传；cursor 仍为视图内 entry 序号，均不受
 * 数值空间影响。
 */
const CONTEXT_REVISION_OFFSET = 0.5;

export class HistoryStore {
	#options: HistoryStoreOptions;
	#views: Record<HistoryView, ViewSnapshotState>;

	constructor(options: HistoryStoreOptions = {}) {
		this.#options = options;
		this.#views = {
			history: { revision: 1, served: false, entries: [] },
			context: { revision: 1 + CONTEXT_REVISION_OFFSET, served: false, entries: [] },
		};
	}

	get revision(): number { return this.#views.history.revision; }

	async page(query: HistoryPageQuery): Promise<HistoryPage> {
		const view: HistoryView = query.view === "context" ? "context" : "history";
		const state = this.#views[view];
		await this.#refreshView(view);
		const since = parseCursor(query.since);
		const suppliedRevision = parseRevision(query.rev);
		const continuingWithoutRevision = since !== undefined && since > 0 && query.rev === null;
		const continuation = (since !== undefined && since > 0) || query.rev !== null;
		// M3：两视图 revision 数值空间结构性不相交（history 自然数 / context 半整数），
		// 下方 suppliedRevision !== state.revision 的相等比较即无条件拒绝任何跨视图
		// rev 复用；跨视图仅 cursor（rev=null）由 continuingWithoutRevision 拒绝。
		if (since === undefined || since > state.entries.length || suppliedRevision === undefined
			|| continuingWithoutRevision || (query.rev !== null && suppliedRevision !== state.revision)
			|| (continuation && !state.served)) {
			throw new HistoryRequestError(state.revision);
		}
		const limit = pageLimit(query.limit);
		const selected = state.entries.slice(since, since + limit);
		const entries = selected.map((entry, offset) => ({
			cursor: since + offset + 1,
			type: entry.type,
			data: filterHistorySecrets(entry),
		}));
		const hasMore = since + selected.length < state.entries.length;
		const page: HistoryPage = {
			v: 1,
			entries,
			nextCursor: hasMore && entries.length > 0 ? entries.at(-1)!.cursor : null,
			revision: state.revision,
			total: state.entries.length,
			view,
		};
		// v1.0.6：仅首页（无 since 且无 rev）携带 usage 恢复基准；快照来自活内存
		// （最后一次快照 + 其后全部增量事件，与前端时间线的衔接由前端负责）。
		// 形状不全 → 字段缺席；注入方异常向上传播（服务端 500），不静默吞错。
		if (query.since === null && query.rev === null) {
			const usage = this.#options.getUsageSnapshot?.();
			if (isUsageSnapshotLike(usage)) page.usage = usage;
		}
		state.served = true;
		return page;
	}

	async refresh(): Promise<readonly SessionEntry[]> {
		return this.#refreshView("history");
	}

	async #refreshView(view: HistoryView): Promise<readonly SessionEntry[]> {
		const state = this.#views[view];
		const projection = view === "context" ? await this.#contextProjection() : await this.#historyProjection();
		const fingerprints = projection.map(view === "context" ? contentSignature : identityOf);
		if (state.fingerprints && !sameIdentity(state.fingerprints, fingerprints)
			&& !(view === "context"
				? isContextPureAppend(state.fingerprints, fingerprints, projection)
				: isPureAppend(state.fingerprints, fingerprints, projection))) {
			state.revision++;
		}
		state.fingerprints = fingerprints;
		state.entries = projection;
		return projection.slice();
	}

	async #diskEntries(): Promise<SessionEntry[]> {
		const file = this.#options.getSessionFile?.();
		if (!file) return [];
		const text = await (this.#options.readFile
			? this.#options.readFile(file)
			: fs.promises.readFile(file, "utf8"));
		return parseSessionJsonl(text).entries;
	}

	/** history 视图：既有路径字节不变（getProjection → JSONL fallback → 缓冲合并）。 */
	async #historyProjection(): Promise<SessionEntry[]> {
		let runtimeProjection: readonly unknown[] | undefined;
		try { runtimeProjection = await this.#options.getProjection?.(); } catch { /* JSONL is the fallback */ }
		let projection: SessionEntry[];
		if (Array.isArray(runtimeProjection)) {
			// buildContextEntries() is already the authoritative active projection;
			// avoid rereading an ever-growing JSONL file on every pagination request.
			projection = runtimeProjection.filter(isSessionEntry);
		} else {
			projection = buildActiveProjection(await this.#diskEntries());
		}
		return mergeBufferedEntries(projection, this.#options.getBufferedEvents?.() ?? []);
	}

	/**
	 * v1.0.19：context 视图降级链（§3.3）——
	 * 1. 运行时权威 getContextProjection（pi buildSessionProjection().entries）：
	 *    空数组合法不回退磁盘；不把缓冲事件合并进已投影结果（防省略内容被重放复活）。
	 * 2. 回调缺失/异常/错误形状 → 原 getProjection（旧宿主 buildContextEntries 输出，
	 *    已选 raw context entries）直接 applyContextEdits：不再次猜 leaf、不结构合并缓冲。
	 * 3. 两者都不可用 → JSONL：selectActiveBranch → context 缓冲合并（persistedIds=
	 *    完整磁盘 id 集）→ selectContextEntries → applyContextEdits。
	 */
	async #contextProjection(): Promise<SessionEntry[]> {
		let runtime: readonly unknown[] | undefined;
		try { runtime = await this.#options.getContextProjection?.(); } catch { /* lint-exempt:context 权威回调不可用按降级链处理，不放大成宿主状态修改 */ }
		if (Array.isArray(runtime)) {
			const projected = projectRuntimeEntries(runtime);
			if (projected) return projected;
			// 错误形状按回调不可用处理，继续降级链。
		}
		let legacy: readonly unknown[] | undefined;
		try { legacy = await this.#options.getProjection?.(); } catch { /* lint-exempt:旧宿主投影回调不可用按降级链走 JSONL */ }
		if (Array.isArray(legacy)) return applyContextEdits(legacy.filter(isSessionEntry));
		const diskEntries = await this.#diskEntries();
		const persistedIds = new Set<string>();
		for (const entry of diskEntries) if (typeof entry.id === "string") persistedIds.add(entry.id);
		const merged = mergeBufferedEntries(
			selectActiveBranch(diskEntries),
			this.#options.getBufferedEvents?.() ?? [],
			{ view: "context", persistedIds },
		);
		return applyContextEdits(selectContextEntries(merged));
	}
}
