import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as http from "node:http";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { Socket } from "node:net";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { EventStream, WEBUI_PROTOCOL_VERSION, type EventEnvelope } from "./events.ts";
import type { AgentSessionResult, InteractResult } from "./agent-session.ts";
import { listForkPoints, resolveForkTarget, WEBUI_FORK_COMMAND, type ForkMode, type ForkPoint, type ForkPosition } from "./fork.ts";
import { HistoryStore, parseSessionJsonl, selectActiveBranch, type HistoryPage } from "./history.ts";
import {
	defaultAgentDir,
	pruneDeadRegistryEntries,
	removeRegistryEntry,
	resolveRegistryFile,
	writeRegistryEntry,
	type WebUiRegistryEntry,
} from "./registry.ts";
import type { TaskPanelSnapshot } from "./task-panel.ts";
import { ROUND_ENTRY_CUSTOM_TYPE, RoundTracker, type RoundSnapshot } from "./round-tracker.ts";
import { UsageStore, type UsageSnapshot } from "./usage-store.ts";
import { projectToolPresentation } from "../tool-presentation.ts";
import { visionFallbackNote } from "../vision-fallback.ts";
// B7（十月迭代 §5.4）：RPC 活跃对话框应答链注入面（server 只承担 HTTP 语义；broker 本体在
// rpc-extension-ui.ts，由 index.ts 组合根闭包注入——webui 子树不 import rpc-pool 运行时）。
import type { RpcDialogAnswer, RpcDialogEnvelope } from "../rpc-extension-ui.ts";

const HOST = "127.0.0.1" as const;
const DEFAULT_STATIC_DIR = fileURLToPath(new URL("./static", import.meta.url));
const HOST_PATTERN = /^127\.0\.0\.1(:\d+)?$/;
const CAPABILITY_PATTERN = /^[A-Za-z0-9_-]{22,}$/;
const MAX_WS_FRAME_BYTES = 16 * 1024 * 1024;
export const MAX_INPUT_TEXT_BYTES = 128 * 1024;
export const MAX_INPUT_QUEUE = 16;
/** v1.0.18 /api/input 图片附件（剪贴板粘贴）：张数与单张 base64 上限（冻结值，
 * 与前端 MAX_ATTACH_* 同值；单张 4 MiB base64 ≈ 3 MB 位图，覆盖常规截图）。 */
export const MAX_INPUT_IMAGES = 4;
export const MAX_INPUT_IMAGE_B64_BYTES = 4 * 1024 * 1024;
const MAX_INPUT_REQUEST_BYTES = MAX_INPUT_TEXT_BYTES * 8 + 1024;
/** v1.0.18：携带图片的 /api/input 请求体上限（4×4 MiB + 文本通道余量）；
 * 其余 JSON 端点（draft/agent-interact）维持原 1 MiB 紧上限。 */
const MAX_INPUT_REQUEST_IMAGES_BYTES = MAX_INPUT_IMAGES * MAX_INPUT_IMAGE_B64_BYTES + MAX_INPUT_REQUEST_BYTES;
/** v1.0.18：图片 mime 白名单（粘贴通道仅取位图格式；svg 等可携带脚本的矢量格式不接受）。 */
const IMAGE_MIME_ALLOWLIST = new Set(["image/png", "image/jpeg", "image/webp", "image/gif"]);
/** v1.0.14 /api/fs/dirs：单层目录枚举上限（超出截断并 truncated:true）。 */
const MAX_FS_DIR_ENTRIES = 500;
/** B7 链路②：resume-entry 签发 nonce 的有效期（5 分钟；过期重取）。 */
export const RESUME_NONCE_TTL_MS = 5 * 60_000;

interface SessionState {
	sessionId: string | null;
	sessionFile: string | null;
	model: { provider: string; id: string } | null;
}

export interface HistoryPageProvider {
	page(query: { since: string | null; limit: string | null; rev: string | null; view?: string | null }): Promise<HistoryPage>;
}

export interface WebUiInputAdapter {
	isIdle(): boolean;
	hasPendingMessages(): boolean;
	/** v1.0.18：content 扩展为 string | 内容块数组（text+image），透传给
	 * pi ExtensionAPI.sendUserMessage 的同名签名；无图片时维持纯 string。 */
	sendUserMessage(content: string | Array<{ type: "text"; text: string } | { type: "image"; data: string; mimeType: string }>,
		options?: { deliverAs?: "steer"; expandPromptTemplates?: boolean }): void;
	/** v1.0.12：可选命令枚举源（pi.getCommands）；缺失/异常时 /api/commands 返回空列表。 */
	getCommands?(): Array<{ name: string; description?: string; source?: string; scope?: string }>;
	/** v1.0.19：可选模型视觉能力探测（pi.getModel()?.input 含 "image"）。
	 * false = 当前模型确定不支持 image 输入 → /api/input 图片附件降级落盘并在文本附路径；
	 * true/undefined（含探测异常与 adapter 缺失）→ 维持 v1.0.18 语义原样传 image 块。 */
	modelSupportsImages?(): boolean | undefined;
}

export interface QueueSnapshot {
	steering: string[];
	followUp: string[];
}

/**
 * v1.0.15：子 Agent 会话查询/交互的编排 adapter（server.ts 唯一注入面）。
 * webui 子树不得 import task-tool/orchestrate/group-scheduler/task-service（depcruise
 * webui-isolated）——registry 匹配、会话文件定位与 runResumeTask 全部在 index.ts 闭包装配，
 * server 只负责 HTTP 语义（鉴权/参数/状态码/并发防抖）。缺席时两路由 503 orch_disabled。
 */
export interface WebUiOrchAdapter {
	agentSession(taskId: string): Promise<AgentSessionResult>;
	interact(taskId: string, text: string): Promise<InteractResult>;
}

/**
 * v1.0.17：恢复对账只读报告（/api/recovery 数据源）。结构 = task-recovery RecoveryReport
 * 的只读投影（scannedAt/root/items/summary）；items 逐条携带 A1 字段（sessionBinding/
 * machineId/leaderSession 等如实在场，扫描方决定）。webui 子树不 import task-recovery
 * （depcruise webui-isolated）——扫描本体（scanTaskRecovery 只读模式，零写入零 spawn）
 * 由 index.ts 组合根闭包注入，server 只负责 HTTP 语义（鉴权/方法/状态码/形状防御）。
 * v1.0.20（ev-20260930-08a8e7）：items[i].checkpoint（可选）原样透传——恢复现场投影
 * （声明产物逐路径观测：present/missing/kind-mismatch/unreadable/denied + bytes/mtime/
 * freshness + 任务书摘要）。保留协议既有字段（items 仍为原样数组，summary 形状校验不变；
 * checkpoint 缺席 = 该任务无投影（非会话绑定/非可信不确定现场），前端按缺省渲染不破协议）。
 */
export interface WebUiRecoveryReport {
	scannedAt: number;
	root: string;
	items: readonly unknown[];
	summary: {
		total: number;
		uncertain: number;
		actionable: number;
		clean: number;
		applied: number;
		failed: number;
	};
}

export interface WebUiRecoveryAdapter {
	/** 只读扫描；抛错由路由转 500（异常不得逸出请求处理器）。 */
	scan(): Promise<WebUiRecoveryReport>;
}

/** B7（十月迭代 §5.4）：RPC 活跃对话框应答面（链路①）。数据源 = RpcDialogBroker（primary+
 *  adopted 汇聚，由 index.ts 装配）；鉴权走既有 bearer capability 管道（网页应答属于控制权）。
 *  两链路不冒充：本面只应答存活进程的 extension_ui_request，blocked 任务恢复走 WebUiResumeAdapter。 */
export interface WebUiRpcDialogAdapter {
	/** 当前 pending 对话快照（envelope 投影）。 */
	dialogs(): RpcDialogEnvelope[];
	/** 提交应答（完整关联键 + 类型化三语义）；跨 broker 汇聚由装配方负责。 */
	respond(key: { workerKey: string; workerGeneration: number; sessionId: string; requestId: string }, answer: RpcDialogAnswer): Promise<{ ok: boolean; code: string; message?: string }>;
	/** pending 表/投影事件订阅（server 转发 rpc_dialog 事件到 WS）；缺席则不广播。 */
	subscribe?(listener: (event: unknown) => void): () => void;
	/** 最后一个 WS 客户端断开钩子：装配方立即取消危险确认（confirm/select）。 */
	onClientsEmpty?(): void;
}

/** B7（十月迭代 §5.4 链路②）：blocked 任务远程恢复入口（/api/tasks/:taskId/resume-entry +
 *  resume-answer）。不向旧 stdin 写 extension_ui_response、不用 rpc adjust 代替恢复——
 *  调用既有 task_resume 路径（装配方闭包，含 runResumeTask 的 N6 lease/防重语义）。 */
export interface WebUiResumeEntryData {
	taskId: string;
	agent: string;
	status: "blocked";
	blockReason: "questions" | "needs-handoff" | null;
	/** QUESTIONS 要点（blockedQuestions 全量，服务端已裁剪）。 */
	questions: string[];
	/** task_resume 参数草稿（renderRelaySubmitDraft 同源渲染，供 Leader/用户比对）。 */
	resumeDraft: string;
}

export type WebUiResumeEntryResult =
	| { ok: true; entry: WebUiResumeEntryData }
	| { ok: false; error: "task_not_found" | "not_blocked" | "no_session"; message?: string };

export type WebUiResumeAnswerResult =
	| { ok: true; taskId: string; successorTaskId: string; status: string }
	| { ok: false; error: "task_not_found" | "not_blocked" | "conflict" | "rejected"; message?: string };

export interface WebUiResumeAdapter {
	/** 恢复入口数据（当前任务状态为准；running/终态 → not_blocked）。 */
	entry(taskId: string): Promise<WebUiResumeEntryResult>;
	/** 提交恢复答案（装配方重查状态 + 既有 resume 链；nonce 一次性消费由 server 把关）。 */
	answer(taskId: string, answerText: string): Promise<WebUiResumeAnswerResult>;
}

/**
 * v1.0.24：从任意用户轮次分叉新会话（/api/fork-points + /api/fork）。
 * ctx.fork 只存在于 ExtensionCommandContext——registerWebUi 装配默认 adapter，经隐藏命令
 * （WEBUI_FORK_COMMAND）+ pi.sendUserMessage(expandPromptTemplates) 取得命令上下文；
 * server 只承担 HTTP 语义（鉴权/方法/参数/idle 守卫/状态码）。缺席时两路由 503 fork_disabled。
 */
export type WebUiForkResult =
	| { ok: true; mode: ForkMode; position: ForkPosition; targetEntryId: string }
	| { ok: false; error: "entry_not_found" | "not_user_message" | "fork_unavailable" | "agent_streaming"; message?: string };

export interface WebUiForkAdapter {
	/** 活动分支用户轮次锚点；宿主不支持（无 getBranch）→ undefined。 */
	points(): ForkPoint[] | undefined;
	/** 受理一次分叉：成功=命令已受理，会话切换随后经 bye/新 hello 完成；失败返回错误码。 */
	fork(entryId: string, mode: ForkMode): Promise<WebUiForkResult>;
}

export interface WebUiServerOptions {
	port?: number;
	registryFile?: string;
	staticDir?: string;
	events?: EventStream;
	history?: HistoryPageProvider;
	input?: WebUiInputAdapter;
	/** v1.0.19：图片降级落盘目录（缺省 <agentDir>/amagi/webui-uploads；测试注入临时目录）。 */
	uploadDir?: string;
	pid?: number;
	startedAt?: Date;
	/** v1.0.13：流标识（缺席时自动生成 uuid；测试可注入固定值断言 hello 搭带）。 */
	stream?: string;
	/** v1.5.259：生命周期诊断日志（缺席时读 env.AMAGI_WEBUI_DEBUG）。 */
	debug?: boolean;
	token?: string;
	env?: NodeJS.ProcessEnv;
	logger?: (message: string) => void;
	/** v1.0.4：初始 usage 快照（构造注入；后续更新走 updateUsage）。 */
	usage?: UsageSnapshot;
	/** v1.0.5：初始编排实况面板快照（构造注入；后续更新走 updatePanel）。 */
	panel?: TaskPanelSnapshot;
	/** v1.0.22：初始本轮用时快照（构造注入，null=无计时数据；后续更新走 updateRound）。 */
	round?: RoundSnapshot | null;
	/** v1.0.15：子 Agent 会话查询/交互 adapter（可选注入；缺席时两路由 503 orch_disabled）。 */
	orch?: WebUiOrchAdapter;
	/** v1.0.17：恢复对账只读报告 adapter（可选注入；缺席时 /api/recovery 503 recovery_disabled）。 */
	recovery?: WebUiRecoveryAdapter;
	/** B7（十月迭代 §5.4 链路①）：RPC 活跃对话框应答 adapter（可选注入；缺席 503 rpc_dialog_disabled）。 */
	rpcDialogs?: WebUiRpcDialogAdapter;
	/** B7（十月迭代 §5.4 链路②）：blocked 任务远程恢复 adapter（可选注入；缺席 503 resume_disabled）。 */
	resume?: WebUiResumeAdapter;
	/** v1.0.24：从用户轮次分叉新会话 adapter（可选注入；registerWebUi 默认装配；缺席 503 fork_disabled）。 */
	fork?: WebUiForkAdapter;
}

export interface RegisterWebUiOptions extends WebUiServerOptions {
	teardownDelayMs?: number;
}

/** v1.0.5 编排实况面板闭包暂存层：快照经此入楼，server 未创建时暂存于闭包。 */
export interface WebUiPanelCache {
	/** 暂存最新快照；server 已创建时同步转发 updatePanel（立即发布 task_panel）。 */
	update(snapshot: TaskPanelSnapshot): void;
}

/** registerWebUi 返回句柄：惰性 server 访问器 + v1.0.4 usage 聚合器 + v1.0.5 panel 暂存层（闭包常驻）。 */
export interface WebUiHandle {
	current(): WebUiServer | undefined;
	/**
	 * v1.0.4 usage 聚合器：闭包常驻——server 未创建（session_start 前 / 启动失败）时
	 * 数据暂存于此，server 创建时经构造注入最新快照；usage 采集不依赖 server 生命周期。
	 */
	usage: UsageStore;
	/**
	 * v1.0.5 编排实况面板暂存层（与 usage 同型）：闭包常驻——server 未创建时快照暂存于
	 * 此，server 创建时经构造注入进 hello；面板选择/排序由 index 装配点的 registry.onChange
	 * 接线驱动（本层只负责暂存与转发，不做选择）。
	 */
	panel: WebUiPanelCache;
}

export function isAllowedHost(host: string): boolean {
	return HOST_PATTERN.test(host);
}

export function configuredPort(env: NodeJS.ProcessEnv = process.env): number {
	const raw = env.AMAGI_WEBUI_PORT;
	if (!raw) return 0;
	const value = Number(raw);
	return Number.isSafeInteger(value) && value >= 0 && value <= 65535 ? value : 0;
}

export function isWebUiEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	if (env.AMAGI_WEBUI_OFF === "1") return false;
	return !/^(0|false|off)$/i.test(env.AMAGI_WEBUI || "1");
}

/** Resolve the per-session bearer capability. Injected values are opaque base64url tokens. */
export function resolveWebUiToken(env: NodeJS.ProcessEnv = process.env): string {
	const injected = env.AMAGI_WEBUI_TOKEN;
	if (injected !== undefined && injected !== "") {
		if (!CAPABILITY_PATTERN.test(injected)) {
			throw new Error("AMAGI_WEBUI_TOKEN must be an unpadded base64url capability of at least 22 characters");
		}
		return injected;
	}
	return crypto.randomBytes(32).toString("base64url");
}

function requestOrigin(req: http.IncomingMessage): string | undefined {
	return typeof req.headers.origin === "string" ? req.headers.origin : undefined;
}

function isAllowedOrigin(origin: string | undefined, host: string): boolean {
	return origin === undefined || origin === "null" || origin === `http://${host}`;
}

function apiCorsHeaders(origin: string | undefined): Record<string, string> {
	return {
		// v1.0.16：经 trusted host 反代加载的 opaque 页面以 credentials:'include'
		// 跨源携带 device cookie —— 响应须回 allow-credentials，否则浏览器拒收。
		...(origin === "null"
			? {
					"access-control-allow-origin": "null",
					"access-control-allow-credentials": "true",
					vary: "Origin",
				}
			: {}),
		"access-control-allow-methods": "GET, POST, PUT, OPTIONS",
		"access-control-allow-headers": "Authorization, Content-Type",
	};
}

function jsonResponse(
	res: http.ServerResponse,
	status: number,
	body: Record<string, unknown>,
	headers: Record<string, string> = {},
): void {
	// v1.0.16 契约冻结（docs/webui-protocol.md §1/§4.4/§9）：顶层 v:1 对成功与错误响应统一注入
	//（含 4xx/5xx 错误体）——错误响应缺 v 会被旧客户端硬校验误判为协议违规，真实错误码被
	// 「invalid protocol response」掩盖并主动断 WS。读面（probeReady 的 503 infoBody、
	// fetchCommands/fetchDirs/draft 等）均不因多余 v 字段受影响（§2 未知字段忽略）。
	// 勿改为「仅成功响应携带 v」。
	const payload = JSON.stringify({ v: WEBUI_PROTOCOL_VERSION, ...body });
	res.writeHead(status, {
		"content-type": "application/json",
		"content-length": Buffer.byteLength(payload),
		...headers,
	});
	res.end(payload);
}

function capabilityMatches(supplied: string, expected: string): boolean {
	const suppliedBytes = Buffer.from(supplied);
	const expectedBytes = Buffer.from(expected);
	return suppliedBytes.length === expectedBytes.length && crypto.timingSafeEqual(suppliedBytes, expectedBytes);
}

function hasBearerCapability(req: http.IncomingMessage, expected: string): boolean {
	const authorization = req.headers.authorization;
	return typeof authorization === "string"
		&& authorization.startsWith("Bearer ")
		&& capabilityMatches(authorization.slice("Bearer ".length), expected);
}

function requestedProtocols(req: http.IncomingMessage): string[] {
	const header = req.headers["sec-websocket-protocol"];
	if (typeof header !== "string") return [];
	return header.split(",").map((value) => value.trim()).filter(Boolean);
}

function rejectUpgrade(socket: Socket): void {
	if (!socket.destroyed && socket.writable) {
		socket.end("HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n");
	} else {
		socket.destroy();
	}
}

function mimeType(file: string): string {
	switch (path.extname(file).toLowerCase()) {
		case ".html": return "text/html; charset=utf-8";
		case ".css": return "text/css; charset=utf-8";
		case ".js": case ".mjs": return "text/javascript; charset=utf-8";
		case ".json": return "application/json; charset=utf-8";
		case ".svg": return "image/svg+xml";
		case ".png": return "image/png";
		case ".jpg": case ".jpeg": return "image/jpeg";
		case ".webp": return "image/webp";
		case ".ico": return "image/x-icon";
		default: return "application/octet-stream";
	}
}

function encodeWsFrame(opcode: number, payload: Buffer): Buffer {
	let header: Buffer;
	if (payload.length < 126) {
		header = Buffer.from([0x80 | opcode, payload.length]);
	} else if (payload.length <= 0xffff) {
		header = Buffer.allocUnsafe(4);
		header[0] = 0x80 | opcode;
		header[1] = 126;
		header.writeUInt16BE(payload.length, 2);
	} else {
		header = Buffer.allocUnsafe(10);
		header[0] = 0x80 | opcode;
		header[1] = 127;
		header.writeBigUInt64BE(BigInt(payload.length), 2);
	}
	return Buffer.concat([header, payload]);
}

class RawWebSocket {
	readonly socket: Socket;
	#buffer = Buffer.alloc(0);
	#closed = false;
	#onClosed: () => void;

	constructor(socket: Socket, head: Buffer, onClosed: () => void) {
		this.socket = socket;
		this.#onClosed = onClosed;
		socket.setNoDelay(true);
		socket.unref();
		socket.on("data", (chunk) => this.#consume(chunk as Buffer));
		socket.once("close", () => this.#finish());
		socket.once("end", () => this.#finish());
		socket.once("error", () => this.#finish());
		if (head.length > 0) this.#consume(head);
	}

	get open(): boolean { return !this.#closed && !this.socket.destroyed && this.socket.writable; }

	sendJson(value: unknown): void {
		if (!this.open) return;
		this.socket.write(encodeWsFrame(0x1, Buffer.from(JSON.stringify(value))));
	}

	close(code = 1000, reason = ""): void {
		if (!this.open) return;
		const reasonBytes = Buffer.from(reason).subarray(0, 123);
		const payload = Buffer.allocUnsafe(2 + reasonBytes.length);
		payload.writeUInt16BE(code, 0);
		reasonBytes.copy(payload, 2);
		this.socket.end(encodeWsFrame(0x8, payload));
	}

	#finish(): void {
		if (this.#closed) return;
		this.#closed = true;
		this.#onClosed();
	}

	#consume(chunk: Buffer): void {
		if (this.#closed) return;
		this.#buffer = Buffer.concat([this.#buffer, chunk]);
		while (this.#buffer.length >= 2) {
			const opcode = this.#buffer[0] & 0x0f;
			const second = this.#buffer[1];
			const masked = (second & 0x80) !== 0;
			let length = second & 0x7f;
			let offset = 2;
			if (length === 126) {
				if (this.#buffer.length < 4) return;
				length = this.#buffer.readUInt16BE(2);
				offset = 4;
			} else if (length === 127) {
				if (this.#buffer.length < 10) return;
				const wide = this.#buffer.readBigUInt64BE(2);
				if (wide > BigInt(MAX_WS_FRAME_BYTES)) { this.socket.destroy(); return; }
				length = Number(wide);
				offset = 10;
			}
			if (length > MAX_WS_FRAME_BYTES) { this.socket.destroy(); return; }
			const maskBytes = masked ? 4 : 0;
			if (this.#buffer.length < offset + maskBytes + length) return;
			const mask = masked ? this.#buffer.subarray(offset, offset + 4) : undefined;
			offset += maskBytes;
			const payload = Buffer.from(this.#buffer.subarray(offset, offset + length));
			this.#buffer = this.#buffer.subarray(offset + length);
			if (mask) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
			if (opcode === 0x8) {
				if (this.open) this.socket.end(encodeWsFrame(0x8, payload));
				return;
			}
			if (opcode === 0x9 && this.open) this.socket.write(encodeWsFrame(0xA, payload));
			// Text/binary/continuation/pong frames are deliberately ignored (v1 is downlink-only).
		}
	}

}

function parseSince(value: string | null): number {
	if (value === null || value === "") return 0;
	const parsed = Number(value);
	return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : 0;
}

function normalizeModel(value: unknown): SessionState["model"] {
	if (!value || typeof value !== "object") return null;
	const model = value as Record<string, unknown>;
	const provider = typeof model.provider === "string" ? model.provider : undefined;
	const id = typeof model.id === "string" ? model.id : typeof model.modelId === "string" ? model.modelId : undefined;
	return provider && id ? { provider, id } : null;
}

/** v1.0.18（F1 裁决方向 A）：WS 实时通道对 user 图片统一剥离——`input` 事件的顶层
 * `images` 数组、`message_start`/`message_update`/`message_end` 的 `message.content`、
 * `agent_end` 聚合的 `messages[]` 中 user 消息 content，图片块 `data` 一律置空串占位
 * （新对象替换，不修改原 pi 事件对象）。防 4×4 MiB 级帧进入广播与 4096 槽回放环；
 * 真图仅发送端本地回显与 /api/history（HTTP 通道）承载；页面按「文本+张数+窗口」
 * 去重合并。assistant/toolResult 消息不在剥离面（工具结果图片是既有链路）。 */
/** 图片块剥离（新对象替换，不改原对象）：data 非空 → 拷贝置空串；无图片块时原样返回。 */
function stripImageBlocks(content: unknown): unknown {
	if (!Array.isArray(content)) return content;
	let changed = false;
	const next = content.map((block) => {
		if (block && typeof block === "object" && (block as { type?: unknown }).type === "image"
			&& typeof (block as { data?: unknown }).data === "string" && (block as { data: string }).data.length > 0) {
			changed = true;
			return { ...(block as Record<string, unknown>), data: "" };
		}
		return block;
	});
	return changed ? next : content;
}

/** user 消息内容块剥离：非 user/非数组 content 原样返回；剥离时返回新消息对象。 */
function strippedUserMessage(message: unknown): unknown {
	if (!message || typeof message !== "object") return message;
	const m = message as { role?: unknown; content?: unknown };
	if (m.role !== "user" || !Array.isArray(m.content)) return message;
	const next = stripImageBlocks(m.content);
	if (next === m.content) return message;
	return { ...m, content: next };
}

/** B4（十月迭代 §5.1）：tool_execution_end 事件附着语义投影（纯函数，FORWARDED_EVENTS 接线 +
 *  测试直驱）。事件载荷含完整 result（实时 wire 档可投影）；text 档不附着=前端原样。
 *  只改传入副本的 presentation 键，不碰事件原字段；非 amagi 工具零变化。 */
export function attachToolEventPresentation(event: Record<string, unknown>): void {
	const e = event as { toolName?: unknown; result?: { structuredContent?: unknown; details?: unknown; content?: unknown } };
	if (typeof e.toolName !== "string") return;
	const content = Array.isArray(e.result?.content)
		? (e.result.content as ReadonlyArray<{ type?: string; text?: unknown }>) : undefined;
	const presentation = projectToolPresentation(e.toolName, {
		content,
		details: e.result?.details,
		structuredContent: e.result?.structuredContent,
		isError: event.isError === true,
	});
	if (presentation && presentation.source !== "text") event.presentation = presentation;
}

export function stripImagePayloadsFromEvent(event: Record<string, unknown>): void {
	if (Array.isArray(event.images)) {
		event.images = (event.images as unknown[]).map(
			(img) => (img && typeof img === "object" && typeof (img as { data?: unknown }).data === "string"
				&& (img as { data: string }).data.length > 0
					? { ...(img as Record<string, unknown>), data: "" }
					: img),
		);
	}
	if (event.message !== undefined) {
		const stripped = strippedUserMessage(event.message);
		if (stripped !== event.message) event.message = stripped;
	}
	if (Array.isArray(event.messages)) {
		let changed = false;
		const next = (event.messages as unknown[]).map((message) => {
			const stripped = strippedUserMessage(message);
			if (stripped !== message) changed = true;
			return stripped;
		});
		if (changed) event.messages = next;
	}
}

/** pi 0.84.x AgentSession emits queue_update with full steering/followUp string snapshots. */
export function parseQueueSnapshot(value: unknown): QueueSnapshot | null {
	if (!value || typeof value !== "object") return null;
	const event = value as Record<string, unknown>;
	if (event.type !== "queue_update" && event.type !== "queue") return null;
	if (!Array.isArray(event.steering) || !event.steering.every((item) => typeof item === "string")) return null;
	if (!Array.isArray(event.followUp) || !event.followUp.every((item) => typeof item === "string")) return null;
	return { steering: [...event.steering], followUp: [...event.followUp] };
}

function textOfUserMessage(value: unknown): string | null {
	if (!value || typeof value !== "object") return null;
	const message = value as { role?: unknown; content?: unknown };
	if (message.role !== "user") return null;
	if (typeof message.content === "string") return message.content;
	if (!Array.isArray(message.content)) return null;
	return message.content
		.filter((part): part is { type: "text"; text: string } => Boolean(part && typeof part === "object"
			&& (part as { type?: unknown }).type === "text" && typeof (part as { text?: unknown }).text === "string"))
		.map((part) => part.text)
		.join("\n");
}

export class WebUiServer {
	readonly events: EventStream;
	readonly registryFile: string;
	readonly pid: number;
	readonly startedAt: Date;
	/** v1.0.13：事件流标识——每 WebUiServer 实例唯一，随 hello 下发（协议 §7.5 流重置判定）。 */
	readonly stream: string;
	#desiredPort: number;
	#staticDir: string;
	#history?: HistoryPageProvider;
	#input?: WebUiInputAdapter;
	#queue: QueueSnapshot = { steering: [], followUp: [] };
	#logger: (message: string) => void;
	#token: string;
	#server?: http.Server;
	#port: number | null = null;
	#session: SessionState = { sessionId: null, sessionFile: null, model: null };
	#clients = new Set<RawWebSocket>();
	#sockets = new Set<Socket>();
	#unsubscribe?: () => void;
	#stopped = false;
	/** v1.5.259：AMAGI_WEBUI_DEBUG=1 时输出生命周期诊断（start/stop/port/registry），默认静默。 */
	#debug: boolean;
	/** v1.5.259：registry 死条目清扫节流——每实例仅在自己首次写条目后扫一次。 */
	#prunedOnce = false;
	#usage: UsageSnapshot | undefined;
	#panel: TaskPanelSnapshot | undefined;
	/** v1.0.22：本轮用时快照（与 usage/panel 同型；null=无计时数据，hello 恒携带）。 */
	#round: RoundSnapshot | null = null;
	/** v1.0.15：编排 adapter（子 Agent 会话查询/交互）；缺席时整面 503 orch_disabled。 */
	#orch?: WebUiOrchAdapter;
	/** v1.0.17：恢复对账只读 adapter；缺席时 /api/recovery 503 recovery_disabled。 */
	#recovery?: WebUiRecoveryAdapter;
	/** B7（十月迭代 §5.4 链路①）：RPC 活跃对话框 adapter；缺席时两路由 503 rpc_dialog_disabled。 */
	#rpcDialogs?: WebUiRpcDialogAdapter;
	/** B7（十月迭代 §5.4 链路②）：blocked 远程恢复 adapter；缺席时两路由 503 resume_disabled。 */
	#resume?: WebUiResumeAdapter;
	#fork?: WebUiForkAdapter;
	/** B7 链路②：resume-entry 签发的单次操作标识（taskId → {nonce, expiresAt}；一次性消费）。 */
	#resumeNonces = new Map<string, { nonce: string; expiresAt: number }>();
	/** B7 链路②：进行中的 resume-answer taskId（并发防抖，同 interact 语义）。 */
	#resumeInFlight = new Set<string>();
	/** B7 链路①：WS 客户端空窗钩子防重（从 ≥1 → 0 只触发一次）。 */
	#hadClients = false;
	/** v1.0.15 并发防抖：进行中的 interact taskId（同 taskId 未完成前重入 → 409 interaction_in_flight）。 */
	#interactions = new Set<string>();
	/** v1.0.9 草稿面：sessionId → 输入框草稿（内存态，随 server 销毁；PUT 空串等价清除）。 */
	#drafts = new Map<string, string>();
	/** v1.0.19：图片降级落盘目录（模型不支持 image 输入时图片写盘、文本附路径）。 */
	#uploadDir: string;

	constructor(options: WebUiServerOptions = {}) {
		const env = options.env ?? process.env;
		this.events = options.events ?? new EventStream();
		this.pid = options.pid ?? process.pid;
		this.startedAt = options.startedAt ?? new Date();
		this.stream = options.stream ?? crypto.randomUUID();
		this.registryFile = options.registryFile ?? resolveRegistryFile(env, this.pid);
		this.#desiredPort = options.port ?? configuredPort(env);
		this.#staticDir = path.resolve(options.staticDir ?? DEFAULT_STATIC_DIR);
		this.#history = options.history;
		this.#input = options.input;
		this.#uploadDir = path.resolve(options.uploadDir ?? path.join(defaultAgentDir(env), "amagi", "webui-uploads"));
		this.#token = options.token ?? resolveWebUiToken(env);
		this.#debug = options.debug ?? /^1|true$/i.test(env.AMAGI_WEBUI_DEBUG ?? "");
		if (!CAPABILITY_PATTERN.test(this.#token)) throw new Error("invalid webui capability token");
		this.#logger = options.logger ?? ((message) => console.error(`[amagi-webui] ${message}`));
		this.#usage = options.usage;
		this.#panel = options.panel;
		this.#round = options.round ?? null;
		this.#orch = options.orch;
		this.#recovery = options.recovery;
		this.#rpcDialogs = options.rpcDialogs;
		this.#resume = options.resume;
		this.#fork = options.fork;
		// B7 链路①：broker 变更 → rpc_dialog 事件（可回放）；最后客户端断开钩子挂接在 WS 生命周期。
		options.rpcDialogs?.subscribe?.((event) => {
			if (this.#stopped) return;
			this.publish({ type: "rpc_dialog", change: event });
		});
	}

	get port(): number | null { return this.#port; }
	get ready(): boolean { return this.#session.sessionId !== null; }
	/** v1.5.259：幂等重入判定——session_start 双发防护需要知道旧实例是否已收口。 */
	get stopped(): boolean { return this.#stopped; }
	get clients(): number { return this.#clients.size; }
	get pendingCount(): number { return this.#queue.steering.length + this.#queue.followUp.length; }

	/** Apply the frozen pi queue snapshot, normalizing queue_update to the v1 wire event name queue. */
	applyQueueEvent(event: unknown): boolean {
		const snapshot = parseQueueSnapshot(event);
		if (!snapshot) return false;
		this.#setQueue(snapshot);
		return true;
	}

	/** Message start is the consumption edge observed immediately after pi removes a queued item. */
	observeQueueConsumption(event: unknown, hasPendingMessages?: boolean): void {
		if (!event || typeof event !== "object") return;
		const typed = event as { type?: unknown; message?: unknown };
		if (typed.type === "message_start") {
			const text = textOfUserMessage(typed.message);
			if (text !== null && this.#removeQueuedText(text)) this.#publishQueue();
		}
		if ((typed.type === "agent_end" || typed.type === "agent_settled")
			&& hasPendingMessages === false && this.pendingCount > 0) {
			this.#setQueue({ steering: [], followUp: [] });
		}
	}

	async start(): Promise<number> {
		if (this.#server && this.#port !== null) return this.#port;
		this.#stopped = false;
		const server = http.createServer((req, res) => { void this.#handleRequest(req, res); });
		this.#server = server;
		server.on("connection", (socket) => {
			this.#sockets.add(socket);
			socket.unref();
			socket.once("close", () => this.#sockets.delete(socket));
		});
		server.on("upgrade", (req, socket, head) => this.#handleUpgrade(req, socket as Socket, head));

		try {
			await this.#listen(this.#desiredPort);
		} catch (error) {
			const code = (error as NodeJS.ErrnoException).code;
			if (this.#desiredPort !== 0 && (code === "EADDRINUSE" || code === "EACCES")) {
				this.#logger(`port ${this.#desiredPort} unavailable (${code}); falling back to an ephemeral port`);
				await this.#listen(0);
			} else {
				this.#server = undefined;
				throw error;
			}
		}
		server.unref();
		const address = server.address();
		if (!address || typeof address === "string") throw new Error("webui server has no TCP address after listen");
		this.#port = address.port;
		if (this.#debug) this.#logger(`[debug] start pid=${this.pid} stream=${this.stream} desired=${this.#desiredPort} actual=${this.#port} registry=${this.registryFile}`);
		server.on("error", (error) => {
			this.#logger(`server error: ${error.message}`);
			for (const client of this.#clients) client.close(1011, "server error");
		});
		this.#unsubscribe = this.events.subscribe((envelope) => this.#broadcast(envelope));
		this.#writeRegistry(); // authoritative first write: listen callback has supplied the actual port
		return address.port;
	}

	updateSession(state: SessionState): void {
		this.#session = {
			sessionId: state.sessionId,
			sessionFile: state.sessionFile,
			model: state.model,
		};
		if (this.#port !== null) this.#writeRegistry();
	}

	updateModel(model: SessionState["model"]): void {
		this.#session.model = model;
		if (this.#port !== null) this.#writeRegistry();
	}

	/** v1.0.4 usage 数据面：更新最新快照并立即合成发布 usage_stats（走 events 流，可被 replay）。 */
	updateUsage(snapshot: UsageSnapshot): void {
		this.#usage = snapshot;
		this.publish({ type: "usage_stats", usage: snapshot });
	}

	/** v1.0.5 编排实况面板数据面：更新最新快照并立即合成发布 task_panel（走 events 流，可被 replay）。 */
	updatePanel(snapshot: TaskPanelSnapshot): void {
		this.#panel = snapshot;
		this.publish({ type: "task_panel", panel: snapshot });
	}

	/** v1.0.22 本轮用时数据面：更新最新快照并立即合成发布 round_state（走 events 流，可被 replay）。 */
	updateRound(snapshot: RoundSnapshot | null): void {
		this.#round = snapshot;
		this.publish({ type: "round_state", round: snapshot });
	}

	publish(event: unknown): EventEnvelope {
		return this.events.publish(event);
	}

	broadcastBye(reason: string): EventEnvelope {
		return this.events.publishBye(reason);
	}

	infoBody(): Record<string, unknown> {
		return {
			v: WEBUI_PROTOCOL_VERSION,
			ready: this.ready,
			sessionId: this.#session.sessionId,
			sessionFile: this.#session.sessionFile,
			model: this.#session.model,
			pid: this.pid,
			port: this.#port,
			startedAt: this.startedAt.toISOString(),
			seq: this.events.sequence,
			buffered: this.events.buffered,
			clients: this.#clients.size,
			pendingCount: this.pendingCount,
		};
	}

	async stop(reason = "shutdown"): Promise<void> {
		if (this.#stopped) return;
		this.#stopped = true;
		if (this.#debug) this.#logger(`[debug] stop reason=${reason} port=${this.#port}`);
		this.#unsubscribe?.();
		this.#unsubscribe = undefined;
		for (const client of this.#clients) client.close(1000, reason);
		this.#clients.clear();
		const server = this.#server;
		this.#server = undefined;
		this.#port = null;
		if (server) {
			try { server.close(); } catch {}
			try { server.closeAllConnections?.(); } catch {}
		}
		for (const socket of this.#sockets) {
			if (!socket.destroyed) socket.destroySoon?.();
		}
		this.#sockets.clear();
		// B7 链路②：停服时清空 nonce（单次操作标识随 server 生命周期，不残留）。
		this.#resumeNonces.clear();
		removeRegistryEntry(this.registryFile);
	}

	cleanupRegistry(): void {
		removeRegistryEntry(this.registryFile);
	}

	#listen(port: number): Promise<void> {
		const server = this.#server!;
		return new Promise((resolve, reject) => {
			const cleanup = () => {
				server.off("error", onError);
				server.off("listening", onListening);
			};
			const onError = (error: Error) => { cleanup(); reject(error); };
			const onListening = () => { cleanup(); resolve(); };
			server.once("error", onError);
			server.once("listening", onListening);
			try { server.listen(port, HOST); } catch (error) { cleanup(); reject(error); }
		});
	}

	#writeRegistry(): void {
		if (this.#port === null) return;
		const entry: WebUiRegistryEntry = {
			v: 1,
			pid: this.pid,
			host: HOST,
			port: this.#port,
			token: this.#token,
			sessionId: this.#session.sessionId,
			sessionFile: this.#session.sessionFile,
			ready: this.ready,
			startedAt: this.startedAt.toISOString(),
		};
		try {
			writeRegistryEntry(this.registryFile, entry);
			if (this.#debug) this.#logger(`[debug] registry write port=${this.#port} sessionId=${this.#session.sessionId}`);
		} catch (error) {
			this.#logger(`registry write failed: ${error instanceof Error ? error.message : String(error)}`);
			return;
		}
		// v1.5.259：顺带清扫同目录死 pid 条目（每实例一次；崩溃/SIGKILL 残留膨胀，实测 492 条）。
		if (!this.#prunedOnce) {
			this.#prunedOnce = true;
			const removed = pruneDeadRegistryEntries(this.registryFile, this.pid);
			if (this.#debug && removed > 0) this.#logger(`[debug] registry pruned ${removed} dead entries`);
		}
	}

	async #handleRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<void> {
		const requestPath = req.url || "/";
		const isApi = requestPath === "/api" || requestPath.startsWith("/api/");
		const host = String(req.headers.host || "");
		if (!isAllowedHost(host)) {
			jsonResponse(res, 403, { error: "forbidden_host" });
			return;
		}
		let url: URL;
		try { url = new URL(requestPath, `http://${host}`); }
		catch { jsonResponse(res, 400, { error: "bad_request" }); return; }

		if (isApi) {
			const origin = requestOrigin(req);
			if (!isAllowedOrigin(origin, host)) {
				jsonResponse(res, 403, { error: "forbidden_origin" });
				return;
			}
			const cors = apiCorsHeaders(origin);
			const respond = (status: number, body: Record<string, unknown>) => jsonResponse(res, status, body, cors);
			// Browser preflight cannot carry Authorization. It is allowed only for trusted page origins;
			// every actual data request below still requires the bearer capability.
			if (req.method === "OPTIONS") {
				res.writeHead(204, cors);
				res.end();
				return;
			}
			if (!hasBearerCapability(req, this.#token)) {
				respond(403, { error: "forbidden_capability" });
				return;
			}
			if (url.pathname === "/api/info") {
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				respond(this.ready ? 200 : 503, this.infoBody());
				return;
			}
			if (url.pathname === "/api/history") {
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.ready) { respond(503, { error: "not_ready" }); return; }
				if (!this.#history) { respond(500, { error: "internal_error", message: "history provider unavailable" }); return; }
				try {
					const body = await this.#history.page({
						since: url.searchParams.get("since"),
						limit: url.searchParams.get("limit"),
						rev: url.searchParams.get("rev"),
						view: url.searchParams.get("view"), // v1.0.19：可选 context 视图；缺省/未知按 history
					});
					respond(200, body as unknown as Record<string, unknown>);
				} catch (error) {
					const typed = error as { statusCode?: number; body?: Record<string, unknown> };
					if (typed.statusCode && typed.body) respond(typed.statusCode, typed.body);
					else {
						this.#logger(`history request failed: ${error instanceof Error ? error.message : String(error)}`);
						respond(500, { error: "internal_error" });
					}
				}
				return;
			}
			if (url.pathname === "/api/commands") {
				// v1.0.12：命令枚举（扩展命令/prompt 模板/skill）。仅展示字段（name/description/
				// source/scope）；sourceInfo.path 等内部路径不下发。枚举源缺失/异常 → 空列表（防御降级）。
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				const commands = this.#safeProbe(() => this.#input?.getCommands?.() ?? [], []).filter(
					(c): c is { name: string; description?: string; source?: string; sourceInfo?: { scope?: unknown } } =>
						!!c && typeof c.name === "string" && c.name !== "" && c.name !== WEBUI_FORK_COMMAND,
				).map((c) => ({
					name: c.name,
					description: typeof c.description === "string" ? c.description : "",
					source: typeof c.source === "string" ? c.source : "extension",
					scope: typeof c.sourceInfo?.scope === "string" ? c.sourceInfo.scope : "",
				}));
				respond(200, { v: 1, commands });
				return;
			}
			if (url.pathname === "/api/input") {
				if (req.method !== "POST") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#input) { respond(405, { error: "input_disabled" }); return; }
				if (!this.ready) { respond(503, { error: "not_ready" }); return; }
				await this.#handleInput(req, respond);
				return;
			}
			if (url.pathname === "/api/fork-points") {
				// v1.0.24：活动分支用户轮次锚点（前端把 doc 用户气泡对位到 pi entry id）。
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#fork) { respond(503, { error: "fork_disabled" }); return; }
				if (!this.ready) { respond(503, { error: "not_ready" }); return; }
				const points = this.#safeProbe(() => this.#fork!.points(), undefined);
				if (!points) { respond(503, { error: "fork_disabled", message: "host does not expose session branch" }); return; }
				respond(200, { points });
				return;
			}
			if (url.pathname === "/api/fork") {
				if (req.method !== "POST") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#fork) { respond(503, { error: "fork_disabled" }); return; }
				if (!this.ready) { respond(503, { error: "not_ready" }); return; }
				await this.#handleFork(req, respond);
				return;
			}
			if (url.pathname === "/api/draft") {
				if (req.method !== "GET" && req.method !== "PUT") { respond(405, { error: "method_not_allowed" }); return; }
				// v1.0.9：键 = 当前 sessionId；未就绪（null）与无草稿统一 404 no_draft（契约 §4.5）。
				const sessionId = this.#session.sessionId;
				if (sessionId === null) { respond(404, { error: "no_draft" }); return; }
				if (req.method === "GET") {
					const text = this.#drafts.get(sessionId);
					if (text === undefined) { respond(404, { error: "no_draft" }); return; }
					respond(200, { text });
					return;
				}
				await this.#handleDraftPut(req, res, respond, cors);
				return;
			}
			if (url.pathname === "/api/fs/dirs") {
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				await this.#handleFsDirs(url.searchParams.get("path"), respond);
				return;
			}
			if (url.pathname === "/api/agent-session") {
				// v1.0.15：子 Agent 会话尾部查询（侧边栏轮询数据源）。鉴权/CORS 由上方统一管道完成，
				// 此处只做方法/参数/adapter 语义；orchestration 数据全经注入 adapter（缺席 503）。
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#orch) { respond(503, { error: "orch_disabled" }); return; }
				const taskId = (url.searchParams.get("taskId") ?? "").trim();
				if (taskId === "") { respond(400, { error: "bad_request", message: "taskId is required" }); return; }
				let sessionResult: AgentSessionResult;
				try {
					sessionResult = await this.#orch.agentSession(taskId);
				} catch (error) {
					this.#logger(`agent-session failed: ${error instanceof Error ? error.message : String(error)}`);
					respond(500, { error: "internal_error" });
					return;
				}
				if (!sessionResult.ok) { respond(404, { error: sessionResult.error }); return; }
				respond(200, sessionResult.body as unknown as Record<string, unknown>);
				return;
			}
			if (url.pathname === "/api/agent-interact") {
				// v1.0.15：blocked/已结算任务续跑（resume background 由 adapter 执行；此路由绝不同步等待）。
				// 错误码：404 task_not_found / 409 not_interactable|resolved_external|no_session|interaction_in_flight
				// / 400 bad_request / 500 internal_error / 503 orch_disabled。
				if (req.method !== "POST") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#orch) { respond(503, { error: "orch_disabled" }); return; }
				const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
				if (contentType !== "application/json") {
					respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
					return;
				}
				const body = await this.#readJsonObjectBody(req, respond);
				if (!body) return;
				const rawTaskId = body.taskId;
				const text = body.text;
				if (typeof rawTaskId !== "string" || rawTaskId.trim() === ""
					|| typeof text !== "string" || text.length === 0
					|| Buffer.byteLength(text, "utf8") > MAX_INPUT_TEXT_BYTES) {
					respond(400, { error: "bad_request", message: "taskId or text is invalid" });
					return;
				}
				const taskId = rawTaskId.trim();
				// 并发防抖：同一 taskId 进行中的 interact 未完成时直接拒绝（双击/重试不得重复 spawn resume）。
				if (this.#interactions.has(taskId)) { respond(409, { error: "interaction_in_flight" }); return; }
				this.#interactions.add(taskId);
				let interactResult: InteractResult | undefined;
				try {
					interactResult = await this.#orch.interact(taskId, text);
				} catch (error) {
					this.#logger(`agent-interact failed: ${error instanceof Error ? error.message : String(error)}`);
					respond(500, { error: "internal_error" });
					return;
				} finally {
					this.#interactions.delete(taskId);
				}
				if (!interactResult) { respond(500, { error: "internal_error" }); return; }
				if (!interactResult.ok) {
					respond(interactResult.error === "task_not_found" ? 404 : 409, interactResult.message !== undefined
						? { error: interactResult.error, message: interactResult.message }
						: { error: interactResult.error });
					return;
				}
				respond(200, { ok: true, taskId: interactResult.taskId, status: interactResult.status });
				return;
			}
			if (url.pathname === "/api/recovery") {
				// v1.0.17：恢复对账报告只读查询（协议 §4.10）。scanTaskRecovery 只读模式经注入
				// adapter 承载（webui 子树不 import task-recovery）；报告结构原样透传（A1 字段
				// actionable/sessionBinding/machineId 如实呈现，v1.0.20 起 items[i].checkpoint 可选
				// 透传），扫描零写入零 spawn。
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#recovery) { respond(503, { error: "recovery_disabled" }); return; }
				let report: WebUiRecoveryReport;
				try {
					report = await this.#recovery.scan();
				} catch (error) {
					this.#logger(`recovery scan failed: ${error instanceof Error ? error.message : String(error)}`);
					respond(500, { error: "internal_error" });
					return;
				}
				// 形状防御：注入方产出畸形报告（非数组 items / 非数值 summary）→ 500，不发垃圾 wire。
				const s = report?.summary;
				if (!report || typeof report !== "object" || !Array.isArray(report.items)
					|| typeof report.root !== "string" || !Number.isFinite(report.scannedAt)
					|| !s || typeof s !== "object" || ![s.total, s.uncertain, s.actionable, s.clean, s.applied, s.failed]
						.every((n) => typeof n === "number" && Number.isFinite(n))) {
					this.#logger("recovery adapter returned malformed report");
					respond(500, { error: "internal_error" });
					return;
				}
				respond(200, {
					scannedAt: report.scannedAt,
					root: report.root,
					items: report.items,
					summary: { total: s.total, uncertain: s.uncertain, actionable: s.actionable, clean: s.clean, applied: s.applied, failed: s.failed },
				});
				return;
			}
			// ── B7（十月迭代 §5.4 链路①）：RPC 活跃对话框应答面 ──
			if (url.pathname === "/api/rpc/dialogs") {
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#rpcDialogs) { respond(503, { error: "rpc_dialog_disabled" }); return; }
				respond(200, { dialogs: this.#safeProbe(() => this.#rpcDialogs!.dialogs(), []) });
				return;
			}
			if (url.pathname === "/api/rpc/ui-response") {
				if (req.method !== "POST") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#rpcDialogs) { respond(503, { error: "rpc_dialog_disabled" }); return; }
				await this.#handleRpcUiResponse(req, respond);
				return;
			}
			// ── B7（十月迭代 §5.4 链路②）：blocked 任务远程恢复入口（与①不冒充：走既有 task_resume 链）──
			const resumeEntryMatch = /^\/api\/tasks\/([^/]+)\/resume-entry$/.exec(url.pathname);
			if (resumeEntryMatch) {
				if (req.method !== "GET") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#resume) { respond(503, { error: "resume_disabled" }); return; }
				await this.#handleResumeEntry(decodeURIComponent(resumeEntryMatch[1]), respond);
				return;
			}
			const resumeAnswerMatch = /^\/api\/tasks\/([^/]+)\/resume-answer$/.exec(url.pathname);
			if (resumeAnswerMatch) {
				if (req.method !== "POST") { respond(405, { error: "method_not_allowed" }); return; }
				if (!this.#resume) { respond(503, { error: "resume_disabled" }); return; }
				await this.#handleResumeAnswer(req, decodeURIComponent(resumeAnswerMatch[1]), respond);
				return;
			}
			respond(404, { error: "not_found" });
			return;
		}
		await this.#serveStatic(url.pathname, req.method || "GET", res);
	}

	/**
	 * v1.0.24 POST /api/fork：body {entryId, mode?: "turn"|"edit"}（缺省 turn）。
	 * 202 {ok:true,mode,position,targetEntryId}=受理（会话切换随后发生，响应已先行写出）；
	 * 400 bad_request|not_user_message / 404 entry_not_found / 409 agent_streaming /
	 * 503 fork_unavailable / 500 internal_error。受理后的失败经 WS 事件 fork_failed 通知。
	 */
	async #handleFork(
		req: http.IncomingMessage,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
		if (contentType !== "application/json") {
			respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
			return;
		}
		const body = await this.#readJsonObjectBody(req, respond);
		if (!body) return;
		const entryId = body.entryId;
		const mode = body.mode ?? "turn";
		if (typeof entryId !== "string" || entryId.trim() === "" || entryId.length > 128 || (mode !== "turn" && mode !== "edit")) {
			respond(400, { error: "bad_request", message: "entryId or mode is invalid" });
			return;
		}
		let result: WebUiForkResult;
		try {
			result = await this.#fork!.fork(entryId.trim(), mode);
		} catch (error) {
			this.#logger(`fork failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		}
		if (!result.ok) {
			const status = result.error === "entry_not_found" ? 404
				: result.error === "not_user_message" ? 400
				: result.error === "agent_streaming" ? 409 : 503;
			respond(status, result.message !== undefined ? { error: result.error, message: result.message } : { error: result.error });
			return;
		}
		respond(202, { ok: true, mode: result.mode, position: result.position, targetEntryId: result.targetEntryId });
	}

	/**
	 * v1.0.15：/api/input、/api/draft、/api/agent-interact 共用的 JSON object body 读取
	 * （Content-Type 由调用方先校验，与 /api/input 既有读取模式完全同规：有界累积 + JSON.parse）。
	 * 超限/非法 JSON/非对象 → 回 400 bad_request 并返回 undefined。
	 */
	async #readJsonObjectBody(
		req: http.IncomingMessage,
		respond: (status: number, body: Record<string, unknown>) => void,
		maxBytes: number = MAX_INPUT_REQUEST_BYTES,
	): Promise<Record<string, unknown> | undefined> {
		let body: unknown;
		try {
			const chunks: Buffer[] = [];
			let bytes = 0;
			for await (const raw of req) {
				const chunk = Buffer.isBuffer(raw) ? raw : Buffer.from(raw);
				bytes += chunk.length;
				if (bytes > maxBytes) throw new Error("request_too_large");
				chunks.push(chunk);
			}
			body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
		} catch {
			respond(400, { error: "bad_request", message: "invalid JSON body" });
			return undefined;
		}
		if (!body || typeof body !== "object" || Array.isArray(body)) {
			respond(400, { error: "bad_request", message: "body must be an object" });
			return undefined;
		}
		return body as Record<string, unknown>;
	}

	async #handleInput(
		req: http.IncomingMessage,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
		if (contentType !== "application/json") {
			respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
			return;
		}
		// v1.0.18：图片请求体走独立大上限（4×4 MiB + 文本余量）。
		const input = await this.#readJsonObjectBody(req, respond, MAX_INPUT_REQUEST_IMAGES_BYTES);
		if (!input) return;
		// v1.0.18：可选 images（剪贴板粘贴图片）；非数组/越限/非法项 → 400（详见 #parseInputImages）。
		const images = this.#parseInputImages(input.images);
		if (!images.ok) {
			respond(400, { error: "bad_request", message: images.message });
			return;
		}
		const hasImages = images.images.length > 0;
		// v1.0.18：text 缺席/空串在携带图片时合法（图片-only 消息）；纯文本路径维持非空约束。
		const text = typeof input.text === "string" ? input.text : "";
		// v1.0.10 mode 语义：缺省/"auto" 由服务端按 isIdle 自动选路（idle→立即投递，非 idle→
		// 按 steer 排队），消除客户端 doc.streaming 与 server isIdle 在工具执行/轮次间隙短暂
		// 失同步时 prompt 撞 409 的问题；显式 "prompt"（now-only）保留非 idle 409 agent_streaming
		// 兼容语义；"steer" 维持强制排队。三者在 idle 期行为等价。
		const mode = input.mode ?? "auto";
		if (Buffer.byteLength(text, "utf8") > MAX_INPUT_TEXT_BYTES
			|| (text.length === 0 && !hasImages)
			|| (mode !== "auto" && mode !== "prompt" && mode !== "steer")) {
			respond(400, { error: "bad_request", message: "text or mode is invalid" });
			return;
		}

		// v1.0.8 输入面防御：适配器探测抛错（stale pi ctx）必须转化为 HTTP 5xx，绝不让异常
		// 逸出请求处理器（否则 Node unhandled rejection 杀死宿主进程）。
		let isIdle: boolean;
		try {
			isIdle = this.#input!.isIdle();
		} catch (error) {
			this.#logger(`input idle check failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		}
		if (isIdle && this.pendingCount > 0) this.#setQueue({ steering: [], followUp: [] });
		// 仅显式 mode:"prompt"（now-only 语义）在非 idle 拒绝；缺省/"auto"/"steer" 落到下方排队路径。
		if (!isIdle && mode === "prompt") {
			respond(409, {
				error: "agent_streaming",
				message: "agent is streaming; retry with mode:\"steer\" or wait",
				pendingCount: this.pendingCount,
			});
			return;
		}
		if (!isIdle && this.pendingCount >= MAX_INPUT_QUEUE) {
			respond(409, { error: "queue_full", message: "input queue is full", pendingCount: this.pendingCount });
			return;
		}

		try {
			// v1.0.12 命令派发：text 以 "/" 开头时开启 expandPromptTemplates——扩展命令经
			// prompt() 的 _tryExecuteExtensionCommand 立即执行（流式中也不排队），skill 与
			// prompt 模板展开后作为真实 prompt 发送（非 idle 时按 mode 排队，与普通输入同路径）。
			// 普通文本不带该选项，行为与 v1.0.10 冻结语义完全一致。
			const expand = text.startsWith("/") && text.length > 0;
			// v1.0.19 视觉降级：当前模型确定不支持 image 输入（如纯文本端点 glm-5.3）时，
			// pi-ai transformMessages 会把 image 块降级成 "(image omitted)" 占位——模型侧
			// 图片完全丢失。改为把图片落盘 webui-uploads 并在文本附路径（read 工具可读图、
			// bash 可处理，浏览器/终端均可追溯）；落盘失败维持原 image 块投递（交给宿主降级，
			// 与 v1.0.18 行为一致）。探测为 true/undefined 时不动 wire（模型支持视觉）。
			let deliverText = text;
			let deliverImages = hasImages ? images.images : undefined;
			if (hasImages && this.#input?.modelSupportsImages?.() === false) {
				const saved = await this.#saveInputImages(images.images);
				if (saved.length > 0) {
					const note = saved.map((p) => visionFallbackNote(p)).join("\n");
					deliverText = deliverText.length > 0 ? `${deliverText}\n\n${note}` : note;
					deliverImages = undefined;
					this.#logger(`input images downgraded to files: ${saved.join(", ")}`);
				}
			}
			// v1.0.18：携带图片时以内容块数组投递（pi sendUserMessage 同名签名）；图片-only
			// 消息不虚构空文本块。纯文本路径维持原 string 投递，wire/行为不变。
			const content = deliverImages === undefined
				? deliverText
				: deliverText.length > 0 ? [{ type: "text" as const, text: deliverText }, ...deliverImages] : deliverImages;
			if (isIdle) this.#input!.sendUserMessage(content, expand ? { expandPromptTemplates: true } : undefined);
			else this.#input!.sendUserMessage(content, { deliverAs: "steer", ...(expand ? { expandPromptTemplates: true } : {}) });
		} catch (error) {
			this.#logger(`input delivery failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		}
		if (!isIdle) {
			// 队列快照是展示通道（string[]）：图片-only 消息展示为「[图片]」占位；消费边
			// 由 pi queue_update 全量快照接管，不依赖此处的精确对账。
			this.#queue.steering.push(text.length > 0 ? text : "[图片]");
			this.#publishQueue();
		}
		// v1.0.8 输入面防御：stale pi ctx（会话切换后旧 runtime 已 dispose）会让 adapter 探测抛错；
		// 202 状态构造回退安全值（isIdle:true、hasPendingMessages:false），响应仍正常返回。
		respond(202, {
			delivered: isIdle ? "now" : "queued",
			isIdle: this.#safeProbe(() => this.#input!.isIdle(), true),
			hasPendingMessages: this.pendingCount > 0 || this.#safeProbe(() => this.#input!.hasPendingMessages(), false),
			pendingCount: this.pendingCount,
		});
	}

	/** v1.0.19 图片降级落盘：逐张写 <uploadDir>/webui-<yyyymmdd-HHMMss>-<rand6>.<ext>；
	 * 目录递归创建，任一张写失败即中断并返回已成功路径（调用方按落盘数决定降级与否）。 */
	async #saveInputImages(images: ReadonlyArray<{ type: "image"; data: string; mimeType: string }>): Promise<string[]> {
		const extOf = (mime: string): string => {
			switch (mime) {
				case "image/png": return "png";
				case "image/jpeg": return "jpg";
				case "image/gif": return "gif";
				case "image/webp": return "webp";
				default: return "bin";
			}
		};
		const stamp = () => {
			const d = new Date();
			const p = (n: number, w = 2) => String(n).padStart(w, "0");
			return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
		};
		const saved: string[] = [];
		try {
			fs.mkdirSync(this.#uploadDir, { recursive: true });
			for (const image of images) {
				const name = `webui-${stamp()}-${crypto.randomBytes(3).toString("hex")}.${extOf(image.mimeType)}`;
				const file = path.join(this.#uploadDir, name);
				await fs.promises.writeFile(file, Buffer.from(image.data, "base64"));
				saved.push(file);
			}
		} catch (error) {
			this.#logger(`input image save failed: ${error instanceof Error ? error.message : String(error)}`);
		}
		return saved;
	}

	/** v1.0.18 /api/input images 字段解析与防御：非数组/超张数/非白名单 mime/非 base64/
	 * 超尺寸 → {ok:false, message}（路由层转 400）；防御性接受完整 data URL 前缀并归一。 */
	#parseInputImages(value: unknown):
		| { ok: true; images: Array<{ type: "image"; data: string; mimeType: string }> }
		| { ok: false; message: string } {
		if (value === undefined || value === null) return { ok: true, images: [] };
		if (!Array.isArray(value)) return { ok: false, message: "images must be an array" };
		if (value.length > MAX_INPUT_IMAGES) return { ok: false, message: `too many images (max ${MAX_INPUT_IMAGES})` };
		const images: Array<{ type: "image"; data: string; mimeType: string }> = [];
		for (const raw of value) {
			if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { ok: false, message: "images[i] must be an object" };
			const item = raw as { data?: unknown; mimeType?: unknown };
			if (typeof item.data !== "string") return { ok: false, message: "images[i].data must be a base64 string" };
			if (typeof item.mimeType !== "string") return { ok: false, message: "images[i].mimeType must be a string" };
			let data: string = item.data;
			let mimeType: string = item.mimeType;
			// 防御：接受 data:image/png;base64,xxx 完整形式，归一为裸 base64 + 前缀 mime；
			// 前缀 mime 与显式 mimeType 同时存在且不一致 → 显式拒绝（diting F3：静默取
			// 显式值会掩盖发送端组装错误，双源不一致本身就是非法形状）。
			const prefix = /^data:([^;,]+);base64,/.exec(data);
			if (prefix) {
				data = data.slice(prefix[0].length);
				const prefixMime = prefix[1].trim().toLowerCase();
				if (!mimeType) mimeType = prefixMime;
				else if (mimeType.trim().toLowerCase() !== prefixMime) {
					return { ok: false, message: `images[i] data URL mime (${prefixMime}) conflicts with mimeType (${mimeType})` };
				}
			}
			mimeType = mimeType.trim().toLowerCase();
			if (!IMAGE_MIME_ALLOWLIST.has(mimeType)) return { ok: false, message: `images[i].mimeType not allowed: ${mimeType}` };
			data = data.replace(/\s+/g, "");
			if (data.length === 0) return { ok: false, message: "images[i].data is empty" };
			if (data.length > MAX_INPUT_IMAGE_B64_BYTES) return { ok: false, message: `images[i].data exceeds ${MAX_INPUT_IMAGE_B64_BYTES} base64 chars` };
			if (!/^[A-Za-z0-9+/]+={0,2}$/.test(data)) return { ok: false, message: "images[i].data is not valid base64" };
			if (Buffer.byteLength(Buffer.from(data, "base64")) === 0) return { ok: false, message: "images[i].data is empty" };
			images.push({ type: "image", data, mimeType });
		}
		return { ok: true, images };
	}

	/**
	 * v1.0.9 PUT /api/draft：校验 JSON body 与 128 KiB text 上限后写入内存 Map；
	 * 空串等价清除（从 Map 删除）。成功 204（无响应体，携 CORS 头）。
	 */
	async #handleDraftPut(
		req: http.IncomingMessage,
		res: http.ServerResponse,
		respond: (status: number, body: Record<string, unknown>) => void,
		cors: Record<string, string>,
	): Promise<void> {
		const sessionId = this.#session.sessionId;
		if (sessionId === null) { respond(404, { error: "no_draft" }); return; }
		const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
		if (contentType !== "application/json") {
			respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
			return;
		}
		const body = await this.#readJsonObjectBody(req, respond);
		if (!body) return;
		const text = body.text;
		if (typeof text !== "string" || Buffer.byteLength(text, "utf8") > MAX_INPUT_TEXT_BYTES) {
			respond(400, { error: "bad_request", message: "text is invalid or exceeds the draft size limit" });
			return;
		}
		if (text === "") this.#drafts.delete(sessionId);
		else this.#drafts.set(sessionId, text);
		res.writeHead(204, cors);
		res.end();
	}

	/**
	 * v1.0.14 GET /api/fs/dirs：单层子目录枚举（快捷功能「输入工作路径」的数据源）。
	 * 无 path 参数 → root = dirname(process.cwd())（会话工作目录的父目录，便于直选兄弟项目）。
	 * 仅返回目录名与绝对路径（不含文件内容）；指向目录的 symlink 经 stat 校验纳入；跳过
	 * . 开头；大小写不敏感排序；上限 MAX_FS_DIR_ENTRIES 条，超出截断 truncated:true。
	 * 单层枚举、不递归，天然无符号链接循环风险。
	 */
	async #handleFsDirs(
		rawPath: string | null,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		const requested = rawPath !== null && rawPath !== "" ? rawPath : path.dirname(process.cwd());
		if (!path.isAbsolute(requested)) { respond(400, { error: "bad_request" }); return; }
		const root = path.resolve(requested);
		try {
			const stat = await fs.promises.stat(root);
			if (!stat.isDirectory()) { respond(404, { error: "not_found" }); return; }
		} catch (error) {
			const code = (error as NodeJS.ErrnoException).code;
			if (code === "ENOENT" || code === "ENOTDIR") { respond(404, { error: "not_found" }); return; }
			this.#logger(`fs dirs stat failed for ${root}: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal" });
			return;
		}
		let dirents: fs.Dirent[];
		try {
			dirents = await fs.promises.readdir(root, { withFileTypes: true });
		} catch (error) {
			this.#logger(`fs dirs readdir failed for ${root}: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal" });
			return;
		}
		const collected: Array<{ name: string; path: string }> = [];
		for (const dirent of dirents) {
			if (dirent.name.startsWith(".")) continue;
			if (dirent.isDirectory()) {
				collected.push({ name: dirent.name, path: path.join(root, dirent.name) });
				continue;
			}
			// 指向目录的 symlink 纳入（readdir 的 dirent 为 lstat 语义，需 stat 校验目标）；
			// 失效/不可访问的 symlink 静默跳过（逐条过滤决策，不构成端点错误）。
			if (dirent.isSymbolicLink()) {
				try {
					if ((await fs.promises.stat(path.join(root, dirent.name))).isDirectory()) {
						collected.push({ name: dirent.name, path: path.join(root, dirent.name) });
					}
				} catch { /* broken symlink → skip */ }
			}
		}
		collected.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
		const truncated = collected.length > MAX_FS_DIR_ENTRIES;
		const parent = path.dirname(root);
		respond(200, {
			root,
			parent: parent === root ? null : parent,
			dirs: truncated ? collected.slice(0, MAX_FS_DIR_ENTRIES) : collected,
			truncated,
		});
	}

	/** 输入 adapter 探测防御包装：抛错时记日志并回退安全值（isIdle→true、hasPendingMessages→false、getCommands→[]）。v1.5.248：泛化签名——命令枚举调用点传入数组 fallback，原仅 boolean 签名使 .filter 误判为 boolean。 */
	#safeProbe<T>(probe: () => T, fallback: T): T {
		try {
			return probe();
		} catch (error) {
			this.#logger(`input adapter probe failed: ${error instanceof Error ? error.message : String(error)}`);
			return fallback;
		}
	}

	/** B7 链路①：POST /api/rpc/ui-response 请求体解析（仅接受完整关联键 + 类型化三语义应答）。
	 *  非法形状 → 400；未鉴权由上方统一管道拦截（网页应答属于控制权）。 */
	#parseRpcUiResponse(body: Record<string, unknown>): { key: { workerKey: string; workerGeneration: number; sessionId: string; requestId: string }; answer: RpcDialogAnswer } | { error: string } {
		const workerKey = body.workerKey;
		const workerGeneration = body.workerGeneration;
		const sessionId = body.sessionId;
		const requestId = body.requestId;
		if (typeof workerKey !== "string" || workerKey === ""
			|| typeof workerGeneration !== "number" || !Number.isSafeInteger(workerGeneration) || workerGeneration < 0
			|| typeof sessionId !== "string"
			|| typeof requestId !== "string" || requestId === "") {
			return { error: "dialog key (workerKey/workerGeneration/sessionId/requestId) is invalid" };
		}
		const raw = body.answer;
		if (!raw || typeof raw !== "object" || Array.isArray(raw)) return { error: "answer must be an object" };
		const answer = raw as Record<string, unknown>;
		if (answer.kind === "cancelled") return { key: { workerKey, workerGeneration, sessionId, requestId }, answer: { kind: "cancelled" } };
		if (answer.kind === "confirmed") {
			if (typeof answer.confirmed !== "boolean") return { error: "answer.confirmed must be a boolean" };
			return { key: { workerKey, workerGeneration, sessionId, requestId }, answer: { kind: "confirmed", confirmed: answer.confirmed } };
		}
		if (answer.kind === "value") {
			if (typeof answer.value !== "string") return { error: "answer.value must be a string" };
			return { key: { workerKey, workerGeneration, sessionId, requestId }, answer: { kind: "value", value: answer.value } };
		}
		return { error: "answer.kind must be value|confirmed|cancelled" };
	}

	async #handleRpcUiResponse(
		req: http.IncomingMessage,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
		if (contentType !== "application/json") {
			respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
			return;
		}
		const body = await this.#readJsonObjectBody(req, respond);
		if (!body) return;
		const parsed = this.#parseRpcUiResponse(body);
		if ("error" in parsed) {
			respond(400, { error: "bad_request", message: parsed.error });
			return;
		}
		let result: { ok: boolean; code: string; message?: string };
		try {
			result = await this.#rpcDialogs!.respond(parsed.key, parsed.answer);
		} catch (error) {
			this.#logger(`rpc ui-response failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		}
		if (result.ok) { respond(200, { ok: true, code: result.code }); return; }
		const status = result.code === "not-found" ? 404 : result.code === "invalid-answer" ? 400 : 409;
		respond(status, result.message !== undefined ? { error: result.code, message: result.message } : { error: result.code });
	}

	/** B7 链路②：GET resume-entry——adapter 取当前任务事实，server 签发单次 nonce（5 分钟有效）。
	 *  nonce 是服务端签发的单次操作标识：客户端只回传它，不携带 agent/cwd/grant/任意命令。 */
	async #handleResumeEntry(
		taskId: string,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		if (taskId === "") { respond(400, { error: "bad_request", message: "taskId is required" }); return; }
		let entry: WebUiResumeEntryResult;
		try {
			entry = await this.#resume!.entry(taskId);
		} catch (error) {
			this.#logger(`resume entry failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		}
		if (!entry.ok) {
			respond(entry.error === "task_not_found" ? 404 : 409, entry.message !== undefined
				? { error: entry.error, message: entry.message }
				: { error: entry.error });
			return;
		}
		const nonce = crypto.randomUUID();
		const expiresAt = Date.now() + RESUME_NONCE_TTL_MS;
		this.#resumeNonces.set(taskId, { nonce, expiresAt });
		respond(200, { ...entry.entry, nonce, expiresAt });
	}

	/** B7 链路②：POST resume-answer——nonce 一次性消费 + adapter 重查状态（服务端以当前任务
	 *  状态为准；重复/状态改变 → conflict；多用户并发恢复只提交一次——admission/lease 防重
	 *  由既有 resume 链承担，不建第二状态机）。 */
	async #handleResumeAnswer(
		req: http.IncomingMessage,
		taskId: string,
		respond: (status: number, body: Record<string, unknown>) => void,
	): Promise<void> {
		if (taskId === "") { respond(400, { error: "bad_request", message: "taskId is required" }); return; }
		const contentType = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
		if (contentType !== "application/json") {
			respond(400, { error: "bad_request", message: "Content-Type must be application/json" });
			return;
		}
		const body = await this.#readJsonObjectBody(req, respond);
		if (!body) return;
		const nonce = body.nonce;
		const answer = body.answer;
		if (typeof nonce !== "string" || nonce === "" || typeof answer !== "string" || answer.trim() === ""
			|| Buffer.byteLength(answer, "utf8") > MAX_INPUT_TEXT_BYTES) {
			respond(400, { error: "bad_request", message: "nonce or answer is invalid" });
			return;
		}
		// nonce 校验：不匹配/过期 → 409（不区分探测）；仅匹配且过期才清除条目——
		// 伪 nonce 尝试不得废除真 nonce（防探测性 DoS）。
		const held = this.#resumeNonces.get(taskId);
		if (!held || held.nonce !== nonce || held.expiresAt < Date.now()) {
			if (held && held.nonce === nonce) this.#resumeNonces.delete(taskId);
			respond(409, { error: "conflict", message: "nonce 无效或已消费（重新获取 resume-entry；任务状态改变同样返回本错误）" });
			return;
		}
		this.#resumeNonces.delete(taskId); // 消费在前：提交动作本身不得被重复 nonce 重放
		if (this.#resumeInFlight.has(taskId)) { respond(409, { error: "conflict", message: "同一任务的恢复提交进行中" }); return; }
		this.#resumeInFlight.add(taskId);
		let result: WebUiResumeAnswerResult;
		try {
			result = await this.#resume!.answer(taskId, answer.trim());
		} catch (error) {
			this.#logger(`resume answer failed: ${error instanceof Error ? error.message : String(error)}`);
			respond(500, { error: "internal_error" });
			return;
		} finally {
			this.#resumeInFlight.delete(taskId);
		}
		if (result.ok) { respond(200, { ok: true, taskId: result.taskId, successorTaskId: result.successorTaskId, status: result.status }); return; }
		respond(result.error === "task_not_found" ? 404 : 409, result.message !== undefined
			? { error: result.error, message: result.message }
			: { error: result.error });
	}

	async #serveStatic(urlPath: string, method: string, res: http.ServerResponse): Promise<void> {
		if (method !== "GET" && method !== "HEAD") {
			res.writeHead(405, { "content-type": "text/plain; charset=utf-8" });
			res.end("method not allowed");
			return;
		}
		let decoded: string;
		try { decoded = decodeURIComponent(urlPath); } catch { decoded = ""; }
		const relative = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
		const file = path.resolve(this.#staticDir, relative);
		if (file !== this.#staticDir && !file.startsWith(`${this.#staticDir}${path.sep}`)) {
			res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
			res.end("not found");
			return;
		}
		try {
			const stat = await fs.promises.stat(file);
			if (!stat.isFile()) throw new Error("not a file");
			res.writeHead(200, {
				"content-type": mimeType(file),
				"content-length": stat.size,
				// sandbox="allow-scripts" gives the page an opaque origin; module assets therefore need CORS too.
				"access-control-allow-origin": "*",
			});
			if (method === "HEAD") res.end();
			else fs.createReadStream(file).on("error", () => res.destroy()).pipe(res);
		} catch {
			res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
			res.end("not found");
		}
	}

	#setQueue(snapshot: QueueSnapshot): void {
		this.#queue = { steering: [...snapshot.steering], followUp: [...snapshot.followUp] };
		this.#publishQueue();
	}

	#removeQueuedText(text: string): boolean {
		const steering = this.#queue.steering.indexOf(text);
		if (steering >= 0) { this.#queue.steering.splice(steering, 1); return true; }
		const followUp = this.#queue.followUp.indexOf(text);
		if (followUp >= 0) { this.#queue.followUp.splice(followUp, 1); return true; }
		return false;
	}

	#publishQueue(): void {
		this.publish({
			type: "queue",
			steering: [...this.#queue.steering],
			followUp: [...this.#queue.followUp],
			pendingCount: this.pendingCount,
		});
	}

	#handleUpgrade(req: http.IncomingMessage, socket: Socket, head: Buffer): void {
		const host = String(req.headers.host || "");
		if (!isAllowedHost(host)) { socket.destroy(); return; }
		let url: URL;
		try { url = new URL(req.url || "/", `http://${host}`); }
		catch { socket.destroy(); return; }
		const key = typeof req.headers["sec-websocket-key"] === "string" ? req.headers["sec-websocket-key"] : "";
		if (url.pathname !== "/ws/events" || !key || req.headers["sec-websocket-version"] !== "13") {
			socket.destroy();
			return;
		}
		const protocols = requestedProtocols(req);
		if (!isAllowedOrigin(requestOrigin(req), host)
			|| protocols.length !== 2
			|| protocols[0] !== "webui"
			|| !CAPABILITY_PATTERN.test(protocols[1])
			|| !capabilityMatches(protocols[1], this.#token)) {
			rejectUpgrade(socket);
			return;
		}
		const accept = crypto.createHash("sha1").update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest("base64");
		socket.write([
			"HTTP/1.1 101 Switching Protocols",
			"Upgrade: websocket",
			"Connection: Upgrade",
			`Sec-WebSocket-Accept: ${accept}`,
			"Sec-WebSocket-Protocol: webui",
			"\r\n",
		].join("\r\n"));
		let client!: RawWebSocket;
		client = new RawWebSocket(socket, head, () => {
			this.#clients.delete(client);
			// B7 链路①：最后一个有应答权限客户端断开 → 立即取消危险确认（confirm/select）。
			// 其它问答最迟到本地 deadline（broker 内 timer）；空窗→重连不重复触发。
			if (this.#hadClients && this.#clients.size === 0) {
				this.#hadClients = false;
				try { this.#rpcDialogs?.onClientsEmpty?.(); } catch (error) { this.#logger(`rpc dialogs onClientsEmpty failed: ${error instanceof Error ? error.message : String(error)}`); }
			}
		});
		this.#clients.add(client);
		this.#hadClients = true;
		const since = parseSince(url.searchParams.get("since"));
		const { hello, replay } = this.events.createHello({
			sessionId: this.#session.sessionId,
			sessionFile: this.#session.sessionFile,
			model: this.#session.model,
			pid: this.pid,
			stream: this.stream,
			pendingCount: this.pendingCount,
			usage: this.#usage, // v1.0.4：最新 usage 快照（未注入时 hello 缺省该字段）
			panel: this.#panel, // v1.0.5：最新编排实况面板快照（未注入时 hello 缺省该字段）
			round: this.#round, // v1.0.22：本轮用时快照（恒携带；null=无计时数据）
		}, since);
		try {
			client.sendJson(hello);
			for (const envelope of replay) client.sendJson(envelope);
		} catch {
			client.close(1011, "serialization failure");
		}
	}

	#broadcast(envelope: EventEnvelope): void {
		for (const client of this.#clients) {
			try { client.sendJson(envelope); } catch { client.close(1011, "send failure"); }
		}
	}
}

const FORWARDED_EVENTS = [
	"session_info_changed",
	"model_select",
	"agent_start",
	"agent_end",
	"turn_start",
	"turn_end",
	"message_start",
	"message_end",
	"message_update",
	"tool_execution_start",
	"tool_execution_update",
	"tool_execution_end",
	"agent_settled",
	"session_tree", // v1.0.19：会话树导航（/tree 分支切换后）只读转发——context 视图失效探测信号
	"session_compact", // v1.0.19：上下文压缩完成只读转发——context 视图失效探测信号
	"queue",
	"queue_update",
	"input",
] as const;

/** switch 类 session_shutdown reason（pi /resume、/new、fork、reload 走 switchSession）。
 * 真实 pi 的 createRuntime 在 switchSession 后整体重载扩展：本注册闭包随旧 runtime 一起
 * 销毁，随后的 session_start 属于新闭包的冷启动（热切换分支永不触发）。因此 switch 类也
 * 必须**立即停服**——bye 后同步 stop 释放注入端口与注册条目，让新注册实例稳定重绑同一
 * 端口；否则旧 server 占死端口，新注册只能漂移到临时端口、页面继续连向已 dispose 的旧
 * 数据面。quit 等真退出维持 bye + 延迟 stop。 */
const SWITCH_SHUTDOWN_REASONS = new Set(["resume", "new", "fork", "reload"]);

function contextSessionState(ctx: unknown): SessionState {
	const context = ctx as {
		sessionManager?: { getSessionId?: () => string; getSessionFile?: () => string | undefined };
		model?: unknown;
	} | undefined;
	return {
		sessionId: context?.sessionManager?.getSessionId?.() ?? null,
		sessionFile: context?.sessionManager?.getSessionFile?.() ?? null,
		model: normalizeModel(context?.model),
	};
}

/** v1.0.7：发布的 session_start 附带会话标识（§2 前向兼容新增字段；页面据此更新 meta）。 */
function sessionStartEvent(event: unknown, state: SessionState): Record<string, unknown> {
	const payload: Record<string, unknown> = {
		...(event && typeof event === "object" ? event as Record<string, unknown> : {}),
		type: "session_start",
	};
	if (state.sessionId !== null) payload.sessionId = state.sessionId;
	if (state.sessionFile !== null) payload.sessionFile = state.sessionFile;
	return payload;
}

/** Register lifecycle handlers only; no socket, timer, or background work starts here. */
export function registerWebUi(pi: ExtensionAPI, options: RegisterWebUiOptions = {}): WebUiHandle {
	let current: WebUiServer | undefined;
	let inputContext: {
		isIdle?: () => boolean;
		hasPendingMessages?: () => boolean;
		getModel?: () => { input?: ReadonlyArray<string> } | undefined;
	} | undefined;
	const delay = options.teardownDelayMs ?? 50;
	const logger = options.logger ?? ((message: string) => console.error(`[amagi-webui] ${message}`));

	// ── v1.0.4 usage 数据面（源 a/c）：闭包常驻聚合器 + Leader 事件累计 ──────
	const usageStore = new UsageStore();

	// ── v1.0.11 usage 历史种子（/resume 冷启动恢复，TCER pi 口径）──────────
	// 闭包冷启动时 store 为空；session_start 从会话活动投影（buildContextEntries，含
	// resume 父链）聚合 assistant usage 灌入，hello.usage / 首页基准立即反映已有会话的
	// 累计消耗与缓存命中。粒度对齐 TCER pi_reader：全零 usage 行跳过；按 message.id
	// 去重（pi 无 CC 多行重复，防御性沿用）；水位 getContextUsage 优先、末条 usage 估算兑底。
	let usageSeeded = false;
	const finiteUsage = (v: unknown): number | undefined => {
		const n = typeof v === "number" ? v : Number(v);
		return Number.isFinite(n) ? n : undefined;
	};
	const seedUsageFromHistory = async (
		manager: { buildContextEntries?: () => unknown; getSessionFile?: () => string | undefined } | undefined,
		ctx: unknown,
	): Promise<void> => {
		if (usageSeeded) return; // 幂等：每闭包只种一次（switch 类 session_start 属新闭包）
		usageSeeded = true;
		try {
			let projection: readonly unknown[] | undefined;
			try {
				const p = manager?.buildContextEntries?.();
				projection = Array.isArray(p) ? p : (p instanceof Promise ? await p : undefined);
			} catch { /* 投影不可用 → 回退会话文件 */ }
			if (!Array.isArray(projection)) {
				const file = manager?.getSessionFile?.();
				if (file) projection = parseSessionJsonl(await fs.promises.readFile(file, "utf8")).entries;
			}
			if (!Array.isArray(projection)) return;
			const seenIds = new Set<string>();
			let lastUsage: { input: number; output: number; cacheRead: number; cacheWrite: number } | null = null;
			for (const raw of projection) {
				const entry = raw as {
					type?: unknown;
					message?: { id?: unknown; role?: unknown; provider?: unknown; model?: unknown; usage?: Record<string, unknown> } | null;
				} | null;
				if (!entry || entry.type !== "message" || !entry.message || typeof entry.message !== "object") continue;
				const message = entry.message;
				if (message.role !== "assistant" || !message.usage || typeof message.usage !== "object") continue;
				const id = typeof message.id === "string" ? message.id : "";
				if (id) {
						if (seenIds.has(id)) continue;
						seenIds.add(id);
					}
				const input = finiteUsage(message.usage.input);
				const output = finiteUsage(message.usage.output);
				const cacheRead = finiteUsage(message.usage.cacheRead);
				const cacheWrite = finiteUsage(message.usage.cacheWrite);
				if (!input && !output && !cacheRead && !cacheWrite) continue; // TCER empty_usage_skipped
					usageStore.recordLeader({
						provider: typeof message.provider === "string" ? message.provider : undefined,
						model: typeof message.model === "string" ? message.model : undefined,
						usage: { input, output, cacheRead, cacheWrite, cost: message.usage.cost as number | { total?: number; totalFromProvider?: boolean } | undefined },
					});
					lastUsage = { input: input ?? 0, output: output ?? 0, cacheRead: cacheRead ?? 0, cacheWrite: cacheWrite ?? 0 };
				}
				// 水位：getContextUsage 优先（resume 后已含历史）；缺省以末条 usage 估算
				//（末次请求总输入+输出 ≈ 当前上下文占用），contextWindow 留 null 待首个 live 事件补。
				if (!refreshLeaderContext(ctx) && lastUsage) {
					usageStore.setLeaderContext({
						contextTokens: lastUsage.input + lastUsage.cacheRead + lastUsage.cacheWrite + lastUsage.output,
					});
				}
			} catch (error) {
				logger(`usage seed failed (ignored): ${error instanceof Error ? error.message : String(error)}`);
			}
		};

	// ── v1.0.5 编排实况面板数据面：闭包暂存层（server 未创建时暂存，创建时构造注入）──
	let panelSnapshot: TaskPanelSnapshot | undefined;
	const panelCache: WebUiPanelCache = {
		update(snapshot) {
			panelSnapshot = snapshot;
			current?.updatePanel(snapshot);
		},
	};

	// ── v1.0.22 本轮用时数据面：闭包常驻 tracker（起止事实采集 + appendEntry 持久化）──
	// 计时口径见 round-tracker.ts 模块注记：无在途轮时的首个 agent_start → agent_settled
	//（含工具循环/自动恢复/排队续跑；同轮重复 run 不重开）；起止事实持久化为 custom entry
	//（不入模型上下文、不物理改写历史），冷启动由 seedRoundFromHistory 从会话投影恢复。
	const roundTracker = new RoundTracker((record) => {
		try {
			pi.appendEntry(ROUND_ENTRY_CUSTOM_TYPE, record);
		} catch (error) {
			logger(`round persist failed (ignored): ${error instanceof Error ? error.message : String(error)}`);
		}
	});
	let roundSeeded = false;
	const seedRoundFromHistory = async (
		manager: { getBranch?: () => unknown; buildContextEntries?: () => unknown; getSessionFile?: () => string | undefined } | undefined,
	): Promise<void> => {
		if (roundSeeded) return; // 幂等：每闭包只种一次（switch 类 session_start 属新闭包）
		roundSeeded = true;
		try {
			// 种子源优先级：① getBranch() 完整活动分支——compaction 后 buildContextEntries
			// 可能截掉最近的计时记录（custom entry 不入模型上下文，但投影截断仍可能丢弃）；
			// ② 压缩投影兑底（旧宿主无 getBranch）；③ 会话文件 JSONL 回退——必须先
			// selectActiveBranch 取活动分支链，不得直接用 parse.entries（会混入废弃分支上的
			// 计时记录；磁盘 leaf 取文件尾，与 /api/history 磁盘回退同口径）。
			let entries: readonly unknown[] | undefined;
			try {
				const branch = manager?.getBranch?.();
				if (Array.isArray(branch)) entries = branch;
			} catch { /* lint-exempt:getBranch 不可用 → 下一层降级 */ }
			if (!Array.isArray(entries)) {
				try {
					const p = manager?.buildContextEntries?.();
					entries = Array.isArray(p) ? p : (p instanceof Promise ? await p : undefined);
				} catch { /* lint-exempt:投影不可用 → 会话文件回退 */ }
			}
			if (!Array.isArray(entries)) {
				const file = manager?.getSessionFile?.();
				if (file) entries = selectActiveBranch(parseSessionJsonl(await fs.promises.readFile(file, "utf8")).entries);
			}
			if (Array.isArray(entries)) roundTracker.seedRoundFromEntries(entries);
		} catch (error) {
			logger(`round seed failed (ignored): ${error instanceof Error ? error.message : String(error)}`);
		}
	};

	// v1.0.8 输入面防御（stale ctx 探测只告警一次，不刷屏）。
	let warnedIdleProbe = false;
	let warnedPendingProbe = false;

	const publishUsage = (): void => {
		const server = current;
		if (!server) return; // server 未启动：数据已在闭包 store 暂存，创建时经构造注入
		server.updateUsage(usageStore.snapshot());
	};

	/** 防御性读 ctx.getContextUsage?.()；缺失/异常保留最近已知水位（null=未知，如压缩后）。 */
	const refreshLeaderContext = (ctx: unknown): boolean => {
		try {
			const info = (ctx as { getContextUsage?: () => { tokens?: unknown; contextWindow?: unknown } | undefined } | undefined)
				?.getContextUsage?.();
			if (!info || typeof info !== "object") return false;
			usageStore.setLeaderContext({
				contextTokens: typeof info.tokens === "number" && Number.isFinite(info.tokens) ? info.tokens : null,
				contextWindow: typeof info.contextWindow === "number" && Number.isFinite(info.contextWindow) ? info.contextWindow : null,
			});
			return true;
		} catch {
			return false;
		}
	};

	const recordUsageEvent = (name: string, event: unknown, ctx: unknown): void => {
		try {
			if (name === "message_end") {
				const message = (event as { message?: { role?: unknown; provider?: unknown; model?: unknown; usage?: unknown } | undefined } | undefined)?.message;
				if (!message || typeof message !== "object" || message.role !== "assistant"
					|| !message.usage || typeof message.usage !== "object") return;
				usageStore.recordLeader({
					provider: typeof message.provider === "string" ? message.provider : undefined,
					model: typeof message.model === "string" ? message.model : undefined,
					// v1.0.23：cost 原样透传（对象/标量两形态在 UsageStore 内归一，口径随帧合并）。
					usage: message.usage as { input?: number; output?: number; cacheRead?: number; cacheWrite?: number; cost?: number | { total?: number; totalFromProvider?: boolean } },
				});
				refreshLeaderContext(ctx);
				publishUsage();
				return;
			}
			if ((name === "agent_settled" || name === "agent_end") && refreshLeaderContext(ctx)) publishUsage();
		} catch { /* usage 数据面绝不影响事件转发主路径 */ }
	};

	// ── v1.0.24 从用户轮次分叉新会话 ─────────────────────────────────────────
	// ctx.fork 仅存在于 ExtensionCommandContext：注册隐藏命令，HTTP 受理后经
	// pi.sendUserMessage("/amagi-webui-fork <id>", {expandPromptTemplates:true}) 派发（命令
	// 立即执行、不进入模型上下文，与 reload-runtime 官方范式同源）。分叉参数留在闭包 pending
	// 表，命令文本只带一次性随机 id（用户手敲也无法伪造分叉目标）。
	let forkBranchSource: (() => readonly Record<string, unknown>[] | undefined) | undefined;
	const pendingForks = new Map<string, { entryId: string; position: ForkPosition; accepted: () => void; rejectIdle: () => void; timer: ReturnType<typeof setTimeout> }>();
	const FORK_ACCEPT_TIMEOUT_MS = 5000;
	/** 受理后让出时间窗：先行写出 202 响应，再触发会换 runtime 的 fork（switch 类 shutdown 会立即停服）。 */
	const FORK_RESPONSE_FLUSH_MS = 150;
	if (typeof (pi as { registerCommand?: unknown }).registerCommand === "function") {
		pi.registerCommand(WEBUI_FORK_COMMAND, {
			description: "WebUI 内部命令：从指定用户轮次分叉新会话（由页面 /api/fork 触发，勿手动调用）",
			handler: async (args: string, ctx) => {
				const id = String(args ?? "").trim();
				const pending = pendingForks.get(id);
				if (!pending) return; // 过期/未知 id：静默忽略（不分叉）
				pendingForks.delete(id);
				clearTimeout(pending.timer);
				let idle = true;
				try { idle = ctx.isIdle(); } catch { /* lint-exempt:探测异常按空闲处理，fork 本身会校验 */ }
				if (!idle) { pending.rejectIdle(); return; }
				pending.accepted();
				await new Promise<void>((resolve) => setTimeout(resolve, FORK_RESPONSE_FLUSH_MS));
				const failed = (reason: string, message?: string): void => {
					try { current?.publish({ type: "fork_failed", reason, ...(message ? { message } : {}) }); } catch { /* lint-exempt:通知失败不影响宿主 */ }
				};
				try {
					const result = await ctx.fork(pending.entryId, { position: pending.position });
					if (result.cancelled) failed("cancelled", "分叉被扩展取消");
				} catch (error) {
					const message = error instanceof Error ? error.message : String(error);
					logger(`fork failed: ${message}`);
					failed("error", message);
				}
			},
		});
	}
	const forkAdapter: WebUiForkAdapter = {
		points: () => {
			const branch = forkBranchSource?.();
			return branch ? listForkPoints(branch) : undefined;
		},
		fork: async (entryId, mode) => {
			const branch = forkBranchSource?.();
			if (!branch) return { ok: false, error: "fork_unavailable", message: "宿主不支持读取会话分支" };
			const target = resolveForkTarget(branch, entryId, mode);
			if (!target.ok) return target;
			let idle = true;
			try { idle = inputContext?.isIdle?.() ?? true; } catch { /* lint-exempt:stale ctx 探测按空闲处理，命令内再次校验 */ }
			if (!idle) return { ok: false, error: "agent_streaming", message: "智能体运行中，请等待结束后再分叉" };
			let hasCommand = false;
			try { hasCommand = pi.getCommands().some((c) => c.name === WEBUI_FORK_COMMAND); } catch { /* lint-exempt:枚举失败按不可用 */ }
			if (!hasCommand) return { ok: false, error: "fork_unavailable", message: "分叉命令未注册" };
			const id = crypto.randomUUID();
			const outcome = new Promise<"accepted" | "streaming" | "timeout">((resolve) => {
				const timer = setTimeout(() => {
					pendingForks.delete(id);
					resolve("timeout");
				}, FORK_ACCEPT_TIMEOUT_MS);
				timer.unref?.();
				pendingForks.set(id, {
					entryId: target.entryId,
					position: target.position,
					accepted: () => resolve("accepted"),
					rejectIdle: () => resolve("streaming"),
					timer,
				});
			});
			try {
				pi.sendUserMessage(`/${WEBUI_FORK_COMMAND} ${id}`, { expandPromptTemplates: true });
			} catch (error) {
				const pending = pendingForks.get(id);
				if (pending) { clearTimeout(pending.timer); pendingForks.delete(id); }
				return { ok: false, error: "fork_unavailable", message: error instanceof Error ? error.message : String(error) };
			}
			const settled = await outcome;
			if (settled === "streaming") return { ok: false, error: "agent_streaming", message: "智能体运行中，请等待结束后再分叉" };
			if (settled === "timeout") return { ok: false, error: "fork_unavailable", message: "分叉命令未响应" };
			return { ok: true, mode, position: target.position, targetEntryId: target.entryId };
		},
	};

	pi.on("session_start", async (event: unknown, ctx: unknown) => {
		// ev-20260905-03eee2：print 模式（pi --print/--list-models 等 headless 短命令）不建
		// server——无交互界面可服务，且并行 headless 进程会与主会话 TUI 抢同一注入端口
		// （AMAGI_WEBUI_PORT）互刷 EADDRINUSE 噪音。usage 种子/闭包聚合器保持惰性无害，
		// 正常 TUI 冷启动不受影响。
		if ((ctx as { mode?: string } | undefined)?.mode === "print") return;
		inputContext = ctx as typeof inputContext;
		const manager = (ctx as {
			sessionManager?: {
				getSessionFile?: () => string | undefined;
				buildContextEntries?: () => readonly unknown[];
				// v1.0.19：pi 0.87.1 SessionManager 新增；旧宿主缺席 → context 视图走降级链
				buildSessionProjection?: () => { entries: readonly unknown[] };
				// v1.0.22：完整活动分支（round 种子首选源——compaction 不截断）；旧宿主缺席
				getBranch?: () => readonly unknown[];
			};
		} | undefined)?.sessionManager;
		// v1.0.8 冷启动（唯一路径）：真实 pi 在 switchSession（/resume 等）后整体重载扩展，
		// session_start 总是发生在新注册闭包（新 server、新 EventStream）——端口由注入配置
		// 决定（旧实例已在 switch 类 shutdown 中停服释放），不存在跨闭包热切换。
		// v1.0.11：先种 usage 历史种子（resume 恢复），再构造 server——hello.usage 与
		// /api/history 首页基准立即携带已有会话的累计消耗/缓存命中/水位。
		await seedUsageFromHistory(manager, ctx);
		// v1.0.22：种本轮用时种子（最近一轮起止事实；未闭合 start → interrupted），
		// hello.round 立即反映重开前的计时状态。
		await seedRoundFromHistory(manager);
		// v1.5.259 幂等重入防护（ev-20260902-464797）：真实 TUI 单发，但 pi 的 bindExtensions
		// 每次调用都 emit session_start（RPC 模式 switch_session 后 rebindSession 会二次
		// 调用，实测双发间隔 4ms）——无保护时产生双 server：旧实例占注入端口、新实例
		// EADDRINUSE 漂移临时端口并覆盖 registry 与 current。重入时先收口未停旧实例再建新。
		const previous = current;
		if (previous && !previous.stopped) {
			try { await previous.stop("superseded"); }
			catch (error) { logger(`superseded stop failed: ${error instanceof Error ? error.message : String(error)}`); }
		}
		const forkManager = (ctx as { sessionManager?: { getBranch?: () => readonly Record<string, unknown>[] } } | undefined)?.sessionManager;
		forkBranchSource = typeof forkManager?.getBranch === "function"
			? () => { try { return forkManager.getBranch!(); } catch { /* lint-exempt:stale manager → 不可用 */ return undefined; } }
			: undefined;
		const events = options.events ?? new EventStream();
		const history = options.history ?? new HistoryStore({
			getSessionFile: () => manager?.getSessionFile?.(),
			getProjection: manager?.buildContextEntries ? () => manager.buildContextEntries!() : undefined,
			// v1.0.19：context 视图运行时权威源——只接 buildSessionProjection().entries
			//（已应用 compaction 区间与 context_edit 的投影），不混 buildContextEntries 结果。
			// 调用原 getProjection 的 usage 种子路径（seedUsageFromHistory）不变：省略不使
			// 历史消费量缩水。
			getContextProjection: manager?.buildSessionProjection ? () => manager.buildSessionProjection!().entries : undefined,
			getBufferedEvents: () => events.bufferSnapshot(),
			// v1.0.6：首页 usage 恢复基准——与 updateUsage 同源的闭包常驻 UsageStore 活内存
			// 快照（不读盘：恢复 = 最后一次快照 + 其后全部增量事件，时间线衔接由前端负责）。
			getUsageSnapshot: () => usageStore.snapshot(),
		});
		// v1.0.8 默认输入 adapter 防御化：stale ctx 的 isIdle/hasPendingMessages 抛错时回退
		// 安全值（true/false）并各记一次日志——切换后旧 ctx 已 dispose，探测异常不是错误输入。
		const input = options.input ?? {
			isIdle: () => {
				try { return inputContext?.isIdle?.() ?? true; }
				catch (error) {
					if (!warnedIdleProbe) {
						warnedIdleProbe = true;
						logger(`input ctx isIdle() threw: ${error instanceof Error ? error.message : String(error)}`);
					}
					return true;
				}
			},
			hasPendingMessages: () => {
				try { return inputContext?.hasPendingMessages?.() ?? false; }
				catch (error) {
					if (!warnedPendingProbe) {
						warnedPendingProbe = true;
						logger(`input ctx hasPendingMessages() threw: ${error instanceof Error ? error.message : String(error)}`);
					}
					return false;
				}
			},
			sendUserMessage: (
				content: string | Array<{ type: "text"; text: string } | { type: "image"; data: string; mimeType: string }>,
				inputOptions?: { deliverAs?: "steer"; expandPromptTemplates?: boolean },
			) => pi.sendUserMessage(content as string | Array<{ type: "text"; text: string } | { type: "image"; data: string; mimeType: string }>, inputOptions),
			// v1.0.12 命令枚举：pi.getCommands（扩展命令/prompt 模板/skill）；探测抛错回退
			// 空列表（页面仅看不到命令，不影响其它输入面）。
			getCommands: () => {
				try { return pi.getCommands(); } catch { return []; }
			},
			// v1.0.19：当前模型 image 输入能力探测（pi-ai Model.input: ("text"|"image")[]；
			// ctx.getModel 在事件 ctx 上，经 inputContext 滚动更新——自定义 provider 模型
			// 未声明 input 时 pi 回退纯文本能力面，返回 false 触发服务端图片降级落盘。
			// 探测异常/无模型/无声明数组 → undefined（维持原 image 块投递，与 v1.0.18 一致）。
			modelSupportsImages: () => {
				try { return inputContext?.getModel?.()?.input?.includes("image"); } catch { /* lint-exempt:ctx 探测防御，异常语义即 undefined */ return undefined; }
			},
		};
		let server: WebUiServer | undefined;
		try {
			server = new WebUiServer({ ...options, fork: options.fork ?? forkAdapter, events, history, input, logger, usage: usageStore.snapshot(), panel: panelSnapshot, round: roundTracker.snapshot() });
			current = server;
			await server.start(); // first registry write is unready and has the actual bound port
			const state = contextSessionState(ctx);
			server.updateSession(state); // second write makes the entry ready
			server.publish(sessionStartEvent(event, state));
		} catch (error) {
			server?.cleanupRegistry();
			if (current === server) current = undefined;
			logger(`server failed to start: ${error instanceof Error ? error.message : String(error)}`);
		}
	});

	for (const name of FORWARDED_EVENTS) {
		pi.on(name as never, async (event: unknown, ctx: unknown) => {
			inputContext = ctx as typeof inputContext;
			recordUsageEvent(name, event, ctx); // v1.0.4：先累计（server 未启动也不丢数据），再转发
			// v1.0.22 本轮用时：起止事实采集（server 未启动也不丢——tracker 闭包常驻，
			// server 创建时经构造注入 hello；采集先于下方转发早退分支）。
			if (name === "agent_start") {
				if (roundTracker.observeAgentStart(Date.now())) current?.updateRound(roundTracker.snapshot());
			} else if (name === "agent_settled") {
				// pi 1.1.0+ 携带 aborted（host-capabilities agentSettledAborted：字段缺席
				// 维持旧行为、不依赖版本门）；旧宿主由轮内 aborted stopReason 信号回退。
				const aborted = (event as { aborted?: unknown } | undefined)?.aborted === true;
				if (roundTracker.observeAgentSettled(aborted, Date.now())) current?.updateRound(roundTracker.snapshot());
			} else if (name === "message_end") {
				// 旧宿主中止回退：assistant 消息 aborted stopReason（与前端 turn-interrupt 同源信号）
				const message = (event as { message?: { role?: unknown; stopReason?: unknown } | undefined } | undefined)?.message;
				if (message?.role === "assistant" && message.stopReason === "aborted") roundTracker.observeAbortSignal();
			}
			const server = current;
			if (!server) return;
			if (name === "queue" || name === "queue_update") {
				server.applyQueueEvent(event);
				return;
			}
			if (name === "model_select") {
				const fromEvent = normalizeModel((event as { model?: unknown } | undefined)?.model ?? event);
				const fromContext = contextSessionState(ctx).model;
				server.updateModel(fromEvent ?? fromContext);
			}
			const normalized: Record<string, unknown> = { ...(event && typeof event === "object" ? event : {}), type: name };
			// v1.0.18（F1 方向 A）：WS 实时通道对 user 图片统一剥离（见 stripImagePayloadsFromEvent 注记）。
			stripImagePayloadsFromEvent(normalized);
			// B4（十月迭代 §5.1）：tool_execution_end 附着语义投影（wire/details 档；text 档不附着=原样）。
			if (name === "tool_execution_end") attachToolEventPresentation(normalized);
			// v1.0.8 输入面防御：stale ctx 的探测抛错不得中断事件转发（回退 undefined = 未知）。
			let pending: boolean | undefined;
			try { pending = inputContext?.hasPendingMessages?.(); } catch { pending = undefined; }
			server.observeQueueConsumption(normalized, pending);
			server.publish(normalized);
		});
	}

	pi.on("session_shutdown", async (event: unknown) => {
		const server = current;
		if (!server) return;
		const reason = (event as { reason?: string } | undefined)?.reason ?? "shutdown";
		server.publish({ ...(event && typeof event === "object" ? event : {}), type: "session_shutdown", reason });
		server.broadcastBye(reason); // synchronous write before the server stops
		if (current === server) current = undefined;
		if (SWITCH_SHUTDOWN_REASONS.has(reason)) {
			// v1.0.8 switch 类（resume/new/fork/reload）：真实 pi 在 switchSession 后整体重载
			// 扩展，本闭包随旧 runtime 销毁，随后的 session_start 属于新闭包的冷启动——必须
			// 立即停服（不经 delay）：stop() 同步 close+closeAllConnections+删注册条目，端口
			// 立即释放；teardownCurrent 会 await 本 handler，扩展重载耗时远大于停服，新注册
			// 可稳定重绑同一注入端口。
			await server.stop(reason);
			return;
		}
		const timer = setTimeout(() => {
			void server.stop(reason);
		}, delay);
		timer.unref?.();
	});

	process.once("exit", () => current?.cleanupRegistry());
	return { current: () => current, usage: usageStore, panel: panelCache };
}
