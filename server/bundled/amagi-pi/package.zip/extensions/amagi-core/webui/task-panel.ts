/**
 * task-panel.ts — webui「amagi 编排实况」常驻面板数据面（协议 v1.0.5，docs/webui-protocol.md §5）。
 *
 * 冻结 wire 契约：hello.panel 与 task_panel 事件共用同一快照形状（TaskPanelSnapshot）。
 * 本模块是快照的唯一选择/排序/裁剪实现，语义权威 = TUI status-ui.ts 的选择口径：
 *   - 在途（running+queued）startedAt 升序，上限 8；
 *   - blocked 常驻（无 TTL），blockedAt??endedAt??startedAt 新→旧，上限 5；
 *   - 最近结算（终态 done/error/cancelled/answered 且 endedAt 距 now ≤ 15s）endedAt 新→旧，上限 8；
 *   - blockedQuestion：needs-handoff → 固定接手指引；否则 blockedQuestions[0] → result 压空白
 *     截断 → 占位（与 status-ui blockedQuestion 同规）。
 *
 * 纯函数无副作用、不触网不触盘：快照为冻结深拷贝（updatedAt=快照时刻 epoch ms），调用方
 * （server.updatePanel / index 装配点）持有的快照与 registry 后续状态完全隔离。
 * 裁剪按 code point 截断（UTF-8 安全：多字节字符与代理对不切半）；同刻记录按 taskId 定序
 * 保证 wire 输出确定。answering 是未确认 spawn 的过渡态，不在任何选择段（与 TUI 口径一致）。
 */

import type { TaskRecord } from "../task-registry.ts";
import { axisLabelOf, NO_RECEIPT_NOTE, safeAxisOf, type TaskAxisOf } from "../panel-model.ts";

export interface TaskPanelItem {
	taskId: string;
	agent: string;
	/** 编排节点名（缺省缺席）。 */
	name?: string;
	status: "queued" | "running" | "blocked" | "done" | "error" | "cancelled" | "answered" | "resolved-external";
	mode?: "sync" | "background";
	model?: string;
	/** 任务摘要（服务端裁剪，UTF-8 安全）。 */
	goal?: string;
	/** 最新活动摘要（服务端裁剪）。 */
	latestActivity?: string;
	blockReason?: "questions" | "needs-handoff";
	/** blocked 时问题/接手摘要（服务端裁剪）。 */
	blockedQuestion?: string;
	/** B0-2（webui 面板占比环）：该任务最近一次模型调用的上下文 token 数（input+cacheRead+cacheWrite
	 *  三分项和，累计口径 lastCall 同源）；运行中随事件更新。可选字段：未观测=缺席（不冒充 0）。 */
	contextTokens?: number;
	/** B0-2：模型上下文窗口上限（宿主 modelRegistry 只读解析成功时携带；缺席=上限未知——
	 *  前端显示绝对 token 数并标注「上限未知」，不得编造上限或假 0%/100%）。 */
	contextWindow?: number;
	/** K8c 三轴标签（axisOf 供给可用且任务已结算时携带；如「执行结束，待接受」——执行结束≠已验收）。
	 *  V3 兼容显示（可选字段，向后兼容）：终态而无标签（legacy 无回执）时携 axisNote 明确注记——不补 ready/accepted。 */
	axisLabel?: string;
	axisNote?: string;
	startedAt: number;
	endedAt?: number;
	blockedAt?: number;
}

export interface TaskPanelSnapshot {
	/** 服务端已选择+排序：在途(running+queued, startedAt 升序, 上限 16) → blocked(blockedAt 新→旧, 上限 8) → 最近结算(TTL 15s, endedAt 新→旧, 上限 8) */
	tasks: TaskPanelItem[];
	/** v1.0.6：registry 全量计数（与分段上限无关，供标题统计段始终准确）。 */
	total: number;
	/** v1.0.6：queued 计数。 */
	queued: number;
	/** v1.0.6：blocked 计数。 */
	blocked: number;
	/** v1.0.6：running 计数。 */
	active: number;
	/** v1.0.6：在途或 blocked 因上限未入列的任务数（窗口口径：settled 不计；无丢弃时为 0 而非缺席，避免旧快照计数粘滞）。 */
	droppedWhenNonZero: number;
	/** epoch ms。 */
	updatedAt: number;
}

/** buildTaskPanel 可调项（测试注入短 TTL；生产缺省 15s）。 */
export interface TaskPanelOptions {
	settledTtlMs?: number;
	/** K8c 只读三轴供给（DI）：组合根接内核视图，默认接 registry 投影（无验收轴→无标签）。 */
	axisOf?: TaskAxisOf;
	/** B0-2 只读注入（DI）：任务实时上下文 token（consumeLine 喂入的 lastCall 三分项和）。
	 *  缺席=未观测（字段缺席，不冒充 0）；非有限/负值同样跳过。 */
	contextTokensOf?: (taskId: string) => number | undefined;
	/** B0-2 只读注入（DI）：模型上下文窗口上限解析（宿主 modelRegistry；返回 undefined=上限未知）。 */
	contextWindowOf?: (model: string | undefined) => number | undefined;
}

/** 最近结算可见窗口（与 status-ui DEFAULT_SETTLED_TTL_MS 一致）：刚结束的编排结果短暂驻留，到期自消失。 */
export const TASK_PANEL_SETTLED_TTL_MS = 15_000;

const MAX_INFLIGHT = 16;
const MAX_BLOCKED = 8;
const MAX_SETTLED = 8;
/** 总量硬上限（三段各自上限之和 32 之内即天然满足；防御性兜底）。 */
const MAX_TASKS = 32;
const MAX_GOAL_CHARS = 120;
const MAX_ACTIVITY_CHARS = 120;
const MAX_BLOCKED_QUESTION_CHARS = 160;

/** 终态集合（与 task-registry TERMINAL / status-ui SETTLED_SYMBOL 覆盖一致）。 */
const SETTLED_STATUS = new Set(["done", "error", "cancelled", "answered", "truncated", "resolved-external"]);

/** needs-handoff 的固定接手摘要（非提问：settle 产出窗口收口，resume 接手）。 */
const HANDOFF_QUESTION = "待接手（resume）：settle 产出窗口收口，非提问";
/** 无任何问题来源时的占位（与 status-ui 同文案）。 */
const EMPTY_QUESTION = "（无问题摘要）";

/** code point 截断（UTF-8 安全：代理对/多字节字符不拆半，无替换符污染）。 */
function capChars(value: string, maxChars: number): string {
	if (value.length <= maxChars) return value; // UTF-16 长度 ≥ code point 数：不超必不超
	let count = 0, i = 0;
	while (i < value.length && count < maxChars) {
		i += value.codePointAt(i)! > 0xffff ? 2 : 1; // 代理对整对跳过
		count++;
	}
	return value.slice(0, i);
}

/** 同刻记录的确定性次序（taskId 字典序），保证 wire 输出稳定可测。 */
function byTaskId(a: Readonly<TaskRecord>, b: Readonly<TaskRecord>): number {
	return a.taskId < b.taskId ? -1 : a.taskId > b.taskId ? 1 : 0;
}

/** blocked 排序键：blockedAt??endedAt??startedAt（与 status-ui selectBlockedTasks 同规）。 */
function blockedSortKey(r: Readonly<TaskRecord>): number {
	return r.blockedAt ?? r.endedAt ?? r.startedAt;
}

/** blocked 行动项摘要：handoff 固定指引 > blockedQuestions 首条 > result 压空白截断 > 占位。 */
function blockedQuestionOf(rec: Readonly<TaskRecord>): string {
	if (rec.blockReason === "needs-handoff") return HANDOFF_QUESTION;
	if (rec.blockedQuestions && rec.blockedQuestions.length > 0)
		return capChars(rec.blockedQuestions[0], MAX_BLOCKED_QUESTION_CHARS);
	if (rec.result) return capChars(rec.result.replace(/\s+/g, " ").trim(), MAX_BLOCKED_QUESTION_CHARS);
	return EMPTY_QUESTION;
}

/** 最新活动摘要：activityWindow 末条 ActivityEvent 的 summary（无/空 → 字段缺席）。 */
function latestActivityOf(rec: Readonly<TaskRecord>): string | undefined {
	const win = rec.activityWindow;
	const last = win && win.length > 0 ? win[win.length - 1] : undefined;
	return typeof last?.summary === "string" && last.summary !== ""
		? capChars(last.summary, MAX_ACTIVITY_CHARS)
		: undefined;
}

/** 单条 wire item 组装（选择后的记录才进来；status 恒为三段枚举之一）。 */
function buildItem(rec: Readonly<TaskRecord>, axisOf?: TaskAxisOf, contextTokensOf?: TaskPanelOptions["contextTokensOf"], contextWindowOf?: TaskPanelOptions["contextWindowOf"]): TaskPanelItem {
	const item: TaskPanelItem = {
		taskId: rec.taskId,
		agent: rec.agent,
		status: rec.status as TaskPanelItem["status"],
		startedAt: rec.startedAt,
	};
	if (rec.name !== undefined) item.name = rec.name;
	if (rec.mode !== undefined) item.mode = rec.mode;
	if (rec.model !== undefined) item.model = rec.model;
	if (rec.goal !== undefined) item.goal = capChars(rec.goal, MAX_GOAL_CHARS);
	const activity = latestActivityOf(rec);
	if (activity !== undefined) item.latestActivity = activity;
	if (rec.status === "blocked") {
		if (rec.blockReason !== undefined) item.blockReason = rec.blockReason;
		item.blockedQuestion = blockedQuestionOf(rec);
	}
	if (rec.endedAt !== undefined && Number.isFinite(rec.endedAt)) item.endedAt = rec.endedAt;
	if (rec.blockedAt !== undefined) item.blockedAt = rec.blockedAt;
	const axisLabel = axisLabelOf(safeAxisOf(axisOf, rec.taskId));
	if (axisLabel !== undefined) item.axisLabel = axisLabel;
	else if (SETTLED_STATUS.has(rec.status)) item.axisNote = NO_RECEIPT_NOTE;
	// B0-2 上下文占比：tokens 已观测才携带；上限只在 tokens 存在且解析为正有限数时携带（未知不编造）。
	const ctxTokens = contextTokensOf?.(rec.taskId);
	if (typeof ctxTokens === "number" && Number.isFinite(ctxTokens) && ctxTokens >= 0) {
		item.contextTokens = ctxTokens;
		const win = contextWindowOf?.(rec.model);
		if (typeof win === "number" && Number.isFinite(win) && win > 0) item.contextWindow = win;
	}
	return Object.freeze(item);
}

/**
 * 构建编排实况面板快照：三段选择（在途 → blocked → 最近结算）+ 排序 + 上限 + 裁剪，
 * 返回冻结深拷贝。`now` 由调用方注入（wire 的 updatedAt 同源）。
 */
export function buildTaskPanel(
	records: Readonly<TaskRecord>[],
	now: number,
	options?: TaskPanelOptions,
): TaskPanelSnapshot {
	const ttlMs = options?.settledTtlMs ?? TASK_PANEL_SETTLED_TTL_MS;
	// 在途：running+queued（queued 也是可钻取的在途任务），startedAt 升序。
	const inflight = records
		.filter((r) => r.status === "running" || r.status === "queued")
		.sort((a, b) => a.startedAt - b.startedAt || byTaskId(a, b))
		.slice(0, MAX_INFLIGHT);
	// blocked 常驻：无 TTL（等待用户答复/接手），排序键新→旧。
	const blocked = records
		.filter((r) => r.status === "blocked")
		.sort((a, b) => blockedSortKey(b) - blockedSortKey(a) || byTaskId(a, b))
		.slice(0, MAX_BLOCKED);
	// 最近结算：终态且 endedAt 有限、距 now 不超过 TTL（新→旧）；无 endedAt 的终态不可派生结算时刻 → 不计入。
	const settled = records
		.filter((r) => SETTLED_STATUS.has(r.status) && Number.isFinite(r.endedAt) && now - (r.endedAt as number) <= ttlMs)
		.sort((a, b) => (b.endedAt as number) - (a.endedAt as number) || byTaskId(a, b))
		.slice(0, MAX_SETTLED);
	const tasks = [...inflight, ...blocked, ...settled].slice(0, MAX_TASKS).map((r) => buildItem(r, options?.axisOf, options?.contextTokensOf, options?.contextWindowOf));
	// v1.0.6 全量计数：与分段上限无关，标题统计段始终准确；dropped 窗口口径＝在途+blocked 未入列数。
	const activeCount = records.filter((r) => r.status === "running").length;
	const queuedCount = records.filter((r) => r.status === "queued").length;
	const blockedCount = records.filter((r) => r.status === "blocked").length;
	const dropped = Math.max(0, activeCount + queuedCount - inflight.length) + Math.max(0, blockedCount - blocked.length);
	const snapshot: TaskPanelSnapshot = {
		tasks, total: records.length, queued: queuedCount, blocked: blockedCount, active: activeCount,
		droppedWhenNonZero: dropped, updatedAt: now,
	};
	Object.freeze(tasks); // 运行时深冻结（元素已在 buildItem 冻结）；丢弃 readonly 返回值以保持契约类型
	Object.freeze(snapshot);
	return snapshot;
}

/**
 * TTL 过期推导：快照中（TTL 内且未被上限截断）最早将过期的 settled 项时刻 =
 * min(endedAt) + ttlMs；无候选 → null。onChange 只在 registry 变更时触发，结算项到期
 * 消失需要时间驱动——调用方据此安排一次性 timer 在该时刻再发一次快照。
 */
export function earliestExpiryAt(
	records: Readonly<TaskRecord>[],
	now: number,
	ttlMs: number = TASK_PANEL_SETTLED_TTL_MS,
): number | null {
	const visible = records
		.filter((r) => SETTLED_STATUS.has(r.status) && Number.isFinite(r.endedAt) && now - (r.endedAt as number) <= ttlMs)
		.sort((a, b) => (b.endedAt as number) - (a.endedAt as number))
		.slice(0, MAX_SETTLED);
	let earliest: number | null = null;
	for (const r of visible) {
		const expiry = (r.endedAt as number) + ttlMs;
		if (earliest === null || expiry < earliest) earliest = expiry;
	}
	return earliest;
}
