/**
 * v1.0.22 本轮用时数据面（webui 协议 round_state 事件 + hello.round 字段的单一实现）。
 *
 * 计时口径（冻结）：「一轮」= 无在途轮时的首个 agent_start → agent_settled。
 * - agent_start/agent_end 是单次模型 run 的边界；工具循环、自动重试/恢复与排队
 *   steer/followUp 续跑会产生新的 run，但 pi 在队列清空前不结算——agent_settled
 *   才是「Pi 停止自动运行」的最终权威边界（pi extensions.md）。因此同轮内重复的
 *   agent_start/agent_settled 之外的 agent_start/agent_end 不重开、不截断计时；
 *   排队输入（steer/followUp）在结算前被消费，自然并入当前轮，不产生独立计时。
 * - abort 口径：agent_settled.aborted === true（pi 1.1.0+ 携带，host-capabilities
 *   version-table agentSettledAborted：字段缺席维持旧行为、不依赖版本门）。旧宿主
 *   字段缺席时以 observeAbortSignal 回退：轮内（最近一次 agent_start 之后）出现过
 *   assistant message_end.stopReason === "aborted"（用户 Escape；与前端 turn-interrupt
 *   同源信号）也判中止——避免无字段宿主把中止误标为 done。事件本体 agent_settled
 *   在最低兼容宿主 0.99.1 口径内由既有 FORWARDED_EVENTS/子进程结算链无条件消费。
 *
 * 持久化：起止事实经 pi.appendEntry 以 custom entry（customType=amagi-webui-round）
 * 追加进会话 JSONL——不入模型上下文、不物理改写历史（pi session-format.md）。
 * 冷启动（含 /resume 等 switch 类扩展重载）由 seedRoundFromEntries 从会话活动投影
 * 恢复最近一轮；未闭合 start（上进程异常退出，无 agent_settled）诚实标记
 * interrupted（endMs=null），客户端隐藏标签、不得虚构结束时刻，也不会随重开无限增长。
 */

/** 会话 JSONL custom entry 的 customType（appendEntry 第一参数；重载识别键）。 */
export const ROUND_ENTRY_CUSTOM_TYPE = "amagi-webui-round";

export type RoundStatus = "running" | "done" | "aborted" | "interrupted";

/** wire 快照（hello.round 与 round_state 事件共用；冻结形状）。 */
export interface RoundSnapshot {
	/** 轮起时刻（epoch ms，服务端事件处理时刻）。 */
	startMs: number;
	/** 结束时刻；null = 进行中（running）或结束时刻未知（interrupted）。 */
	endMs: number | null;
	status: RoundStatus;
}

/** appendEntry 持久化记录（custom entry 的 data 字段；自包含起止事实）。 */
export interface RoundPersistRecord {
	v: 1;
	phase: "start" | "end";
	startMs: number;
	endMs?: number;
	status?: "done" | "aborted";
}

/** wire 快照形状校验（hello/事件载荷防御；非法值按缺席处理）。 */
export function isRoundSnapshot(value: unknown): value is RoundSnapshot {
	if (!value || typeof value !== "object") return false;
	const v = value as Record<string, unknown>;
	const status = v.status;
	if (!Number.isFinite(v.startMs)) return false;
	if (status !== "running" && status !== "done" && status !== "aborted" && status !== "interrupted") return false;
	if (status === "done" || status === "aborted") return Number.isFinite(v.endMs);
	return v.endMs == null;
}

/** 持久化记录解析（seed 用；非法数据返回 null 跳过，不抛错）。 */
function parsePersistRecord(data: unknown): RoundPersistRecord | null {
	if (!data || typeof data !== "object") return null;
	const d = data as Record<string, unknown>;
	if (d.v !== 1) return null;
	if (d.phase === "start" && Number.isFinite(d.startMs)) {
		return { v: 1, phase: "start", startMs: d.startMs as number };
	}
	if (d.phase === "end" && Number.isFinite(d.startMs) && Number.isFinite(d.endMs)
		&& (d.endMs as number) >= (d.startMs as number)
		&& (d.status === "done" || d.status === "aborted")) {
		return { v: 1, phase: "end", startMs: d.startMs as number, endMs: d.endMs as number, status: d.status };
	}
	return null;
}

/**
 * 单轮状态机（webui 子树内纯模块，不 import pi——持久化经构造注入回调，由
 * registerWebUi 装配为 pi.appendEntry；depcruise webui-isolated 边界不变）。
 */
export class RoundTracker {
	#activeStartMs: number | null = null;
	#last: RoundSnapshot | null = null;
	/** 轮内中止信号（最近一次 agent_start 之后是否见过 aborted stopReason；旧宿主字段缺席回退）。 */
	#abortSinceRunStart = false;
	readonly #persist: (record: RoundPersistRecord) => void;

	constructor(persist: (record: RoundPersistRecord) => void) {
		this.#persist = persist;
	}

	/** agent_start：无在途轮时开新轮（重复 run 不重开；新 run 重置轮内中止信号）。返回状态是否变化。 */
	observeAgentStart(nowMs: number): boolean {
		this.#abortSinceRunStart = false;
		if (this.#activeStartMs !== null) return false;
		this.#activeStartMs = nowMs;
		this.#safePersist({ v: 1, phase: "start", startMs: nowMs });
		return true;
	}

	/** assistant message_end.stopReason === "aborted"：旧宿主无 agent_settled.aborted 字段的
	 * 中止回退信号（仅影响在途轮；与 agent_start 重置配合，只反映最后一个 run 的中止）。 */
	observeAbortSignal(): void {
		if (this.#activeStartMs !== null) this.#abortSinceRunStart = true;
	}

	/** agent_settled：在途轮收口（aborted=pi 1.1.0+ 的宿主中止事实；旧宿主回退轮内 aborted
	 *  stopReason 信号）。返回状态是否变化。 */
	observeAgentSettled(aborted: boolean, nowMs: number): boolean {
		const startMs = this.#activeStartMs;
		if (startMs === null) return false;
		this.#activeStartMs = null;
		const status = aborted || this.#abortSinceRunStart ? "aborted" : "done";
		this.#abortSinceRunStart = false;
		this.#last = { startMs, endMs: nowMs, status };
		this.#safePersist({ v: 1, phase: "end", startMs, endMs: nowMs, status });
		return true;
	}

	/**
	 * 冷启动种子：按顺序消费会话投影/JSONL 条目，恢复最近一轮事实。
	 * - 末条为 end → 冻结快照（done/aborted，精确起止）；
	 * - 末条为未闭合 start → interrupted（上进程异常退出；不追加补偿记录，重复
	 *   重开幂等不增长）；
	 * - 无记录/全部非法/未知 customType → null（旧会话无计时数据，客户端隐藏）。
	 * 非本扩展的 custom 条目一律忽略（兼容未知 custom 记录）。
	 */
	seedRoundFromEntries(entries: readonly unknown[]): void {
		this.#activeStartMs = null;
		this.#last = null;
		let pendingStart: number | null = null;
		for (const raw of entries) {
			const entry = raw as { type?: unknown; customType?: unknown; data?: unknown } | null;
			if (!entry || entry.type !== "custom" || entry.customType !== ROUND_ENTRY_CUSTOM_TYPE) continue;
			const record = parsePersistRecord(entry.data);
			if (!record) continue;
			if (record.phase === "start") {
				pendingStart = record.startMs; // 连续未闭合 start：取最后一个（脏数据防御）
			} else {
				pendingStart = null;
				this.#last = { startMs: record.startMs, endMs: record.endMs!, status: record.status! };
			}
		}
		if (pendingStart !== null) {
			this.#last = { startMs: pendingStart, endMs: null, status: "interrupted" };
		}
	}

	/** 当前快照：在途轮优先，否则最近已结束轮，无数据 null。 */
	snapshot(): RoundSnapshot | null {
		return this.#activeStartMs !== null
			? { startMs: this.#activeStartMs, endMs: null, status: "running" }
			: this.#last;
	}

	#safePersist(record: RoundPersistRecord): void {
		try { this.#persist(record); } catch { /* lint-exempt:持久化尽力而为——appendEntry 失败不阻塞状态机，装配层已记日志 */ }
	}
}
