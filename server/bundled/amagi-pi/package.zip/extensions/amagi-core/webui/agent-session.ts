/**
 * agent-session.ts — webui 子 Agent 会话查询与交互的纯数据面（协议 v1.0.15，
 * docs/webui-protocol.md §4.8 GET /api/agent-session、§4.9 POST /api/agent-interact）。
 * v1.0.20：条目新增可选 omitted 标记——pi 溢出/截断恢复丢弃的 toolCall 尝试（从未执行）
 * 不再被侧边栏渲染成「运行中」。
 *
 * 职责：把 pi 会话 JSONL 投影为**中立 JSON 条目**（不带 ANSI/主题/折叠渲染），供 webui
 * 「编排实况」侧边栏轮询展示；以及提供 taskId 精确/唯一前缀匹配、响应组装与 wire 类型。
 * 渲染职责在前端；registry 查询、会话文件定位（resolveSessionFile）与 resume 派发
 * （runResumeTask）属运行时依赖，由 index.ts 装配的 WebUiOrchAdapter 闭包注入——本模块与
 * server.ts 一样不 import task-tool/orchestrate/group-scheduler/task-service（depcruise
 * webui-isolated），除 node 内置模块外零依赖。
 *
 * dist / 上游证据：
 *   - 条目结构：pi 包 docs/session-format.md —— entry 类型全集 session/message/model_change/
 *     thinking_level_change/compaction/branch_summary/custom/custom_message/label/session_info
 *     /context_edit（pi 0.87.1 追加：targetId + replacement{content}|null 的 append-only 上下文编辑）；
 *     message.content 块 text/thinking/toolCall；toolResult 为 role="toolResult" 的 message
 *     （toolName/isError/toolCallId）；entry.timestamp 为 ISO 字符串，message.timestamp 为 Unix ms。
 *     （消费者可对照 node_modules/@earendil-works/pi-coding-agent/dist/core/session-manager.js 的
 *     SessionEntry 类型与 messages.ts 的 AgentMessage 联合。）
 *   - 会话文件布局：<agentDir>/sessions/--<cwd 编码>--/<ISO时间戳>_<sessionUuid>.jsonl
 *     （session-viewer.ts resolveSessionFile 的实测定格；本模块只接收已解析的路径）。
 *   - 尾载口径：与 extensions/amagi-core/session-viewer.ts readSessionText 同规则——文件
 *     ≤ 2 MiB 全量读；> 2 MiB 只读尾部 256 KiB 行对齐窗口并标记 truncated（丢弃窗口前的
 *     全部条目）。
 *
 * 错误面：解析层零抛错（损坏行计数跳过）；尾读的文件 I/O 异常向调用方抛出，由 adapter
 * 转成 200 + entries:[] + error 文案的降级响应（协议 §4.8）。
 */

import * as fs from "node:fs";
import { projectToolPresentation, type ToolPresentation } from "../tool-presentation.ts";

/** entries 尾部窗口上限（协议 §4.8 冻结值 400）。 */
export const AGENT_SESSION_ENTRY_CAP = 400;
/** 单条 text 截断上限（协议 §4.8 冻结值 2000 字符，code point 计）。 */
export const AGENT_SESSION_TEXT_CAP = 2000;
/** 截断后缀（协议 §4.8 冻结文案）。 */
export const AGENT_SESSION_TRUNCATION_SUFFIX = "…(截断)";
/** 全量/尾载分界（与 session-viewer LARGE_FILE_BYTES 同值）。 */
export const AGENT_SESSION_LARGE_FILE_BYTES = 2 * 1024 * 1024;
/** >2 MiB 时的尾读窗口（与 session-viewer 尾载同值）。 */
export const AGENT_SESSION_TAIL_BYTES = 256 * 1024;
/** blockedQuestion 派生摘要上限（与 webui/task-panel.ts blocked 段同文案口径）。 */
export const AGENT_SESSION_BLOCKED_QUESTION_CAP = 160;

/** needs-handoff 的固定接手摘要（与 task-panel.ts HANDOFF_QUESTION 同文案）。 */
const HANDOFF_QUESTION = "待接手（resume）：settle 产出窗口收口，非提问";
/** 无任何问题来源时的占位（与 task-panel.ts EMPTY_QUESTION 同文案）。 */
const EMPTY_QUESTION = "（无问题摘要）";

export type AgentSessionEntryKind = "user" | "assistant" | "thinking" | "toolCall" | "toolResult" | "meta";

export interface AgentSessionEntry {
	kind: AgentSessionEntryKind;
	/** ISO 8601；无可用时间戳时为 null。 */
	ts: string | null;
	text: string;
	/** toolCall/toolResult 专用。 */
	toolName?: string;
	/** v2.8.0：toolCall（pi 原生 id）/toolResult（toolCallId）配对凭证；旧会话数据缺席。 */
	toolCallId?: string;
	/** v1.0.20：toolCall 专用——所在 assistant 消息已被后续 context_edit（replacement=null）
	 *  省略且无同 id toolResult 配对：pi 溢出/截断恢复（_omitRecoveryAttempt）在工具执行前
	 *  丢弃了整个尝试，该调用从未运行（半截参数不会落盘）。前端据此显示「未执行」而非
	 *  「运行中」；context_edit 行被尾窗/条目上限裁掉时本字段缺席（保守不标记）。 */
	omitted?: boolean;
	/** toolResult 专用。 */
	isError?: boolean;
	/** B4（十月迭代 §5.1）：toolResult 语义投影（服务端同一模型；仅 details 档——会话 JSONL
	 *  不持久化 structuredContent，历史无 wire 档；纯文本历史不携带本字段=「原样」）。 */
	presentation?: ToolPresentation;
}

export interface AgentSessionBody {
	v: 1;
	taskId: string;
	agent: string;
	status: string;
	blockReason: "questions" | "needs-handoff" | null;
	blockedQuestion: string | null;
	sessionId: string | null;
	sessionFile: string | null;
	/** 本次读取窗口（>2 MiB 时为尾窗）内的非空 JSONL 行数（含损坏行）。 */
	totalLines: number;
	/** true 表示 entries 有丢弃：文件超 2 MiB 尾载，或解析条目超出尾部窗口 400 上限。 */
	truncated: boolean;
	entries: AgentSessionEntry[];
	/** 会话文件缺失/读失败时的降级文案；正常为 null。 */
	error: string | null;
	updatedAt: string;
}

/** GET /api/agent-session 的 adapter 结果（404 由 adapter 判定）。 */
export type AgentSessionResult =
	| { ok: true; body: AgentSessionBody }
	| { ok: false; error: "task_not_found" };

/** POST /api/agent-interact 的 adapter 结果错误码（server 另增 interaction_in_flight/internal_error）。 */
export type InteractErrorCode = "task_not_found" | "not_interactable" | "resolved_external" | "no_session";

export type InteractResult =
	| { ok: true; taskId: string; status: "running" }
	| { ok: false; error: InteractErrorCode; message?: string };

// ── 解析（纯函数，零 IO） ────────────────────────────────────────────────────

/** code point 截断（UTF-16 长度不切半代理对；task-panel.capChars 同规则）。 */
function capChars(value: string, maxChars: number): string {
	if (value.length <= maxChars) return value; // UTF-16 长度 ≥ code point 数：不超必不超
	let count = 0, i = 0;
	while (i < value.length && count < maxChars) {
		i += value.codePointAt(i)! > 0xffff ? 2 : 1;
		count++;
	}
	return value.slice(0, i);
}

/** 单条 text 截断：超上限时截断并追加冻结后缀。 */
export function truncateAgentEntryText(text: string): string {
	return text.length > AGENT_SESSION_TEXT_CAP
		? capChars(text, AGENT_SESSION_TEXT_CAP) + AGENT_SESSION_TRUNCATION_SUFFIX
		: text;
}

/** entry/message 时间戳 → ISO；ISO 字符串与 Unix ms 数字均接受，非法返回 null。 */
function isoOf(value: unknown): string | null {
	if (typeof value === "string" && value !== "") {
		return Number.isFinite(Date.parse(value)) ? value : null;
	}
	if (typeof value === "number" && Number.isFinite(value)) {
		try { return new Date(value).toISOString(); } catch { return null; }
	}
	return null;
}

/** 内容块 → 文本（text 块拼接；image 块标记；字符串原样）。 */
function textOfContent(content: unknown): string {
	if (typeof content === "string") return content;
	if (!Array.isArray(content)) return "";
	const parts: string[] = [];
	for (const block of content) {
		if (!block || typeof block !== "object") continue;
		const b = block as Record<string, unknown>;
		if (b.type === "text" && typeof b.text === "string") parts.push(b.text);
		else if (b.type === "image") parts.push("[image]");
	}
	return parts.join("\n");
}

/** thinking 块文本（pi 用 `thinking`；兼容旧形态 `text`）。 */
function textOfThinking(block: Record<string, unknown>): string {
	if (typeof block.thinking === "string") return block.thinking;
	return typeof block.text === "string" ? block.text : "";
}

/** toolCall 参数 → 单行 JSON（stringify 失败时退 String）。 */
function textOfToolCallArgs(args: unknown): string {
	try {
		const json = JSON.stringify(args);
		return json === undefined ? "" : json;
	} catch {
		return String(args);
	}
}

/**
 * context_edit（pi 0.87.1 ContextEditEntry）→ meta 文案（升级方案 §3.6 冻结口径）。
 * 只描述编辑事实：不展开 replacement 正文；不据尾窗是否含目标判断目标存在性——目标可能在
 * 256 KiB 尾窗之外，且本投影无活动 leaf 与完整分支图，不做删除/替换，目标原始 message
 * 条目原样保留。字段残缺（缺 targetId / 缺 replacement / primitive replacement / content
 * 形状不合法）按无效编辑降级成 meta，不静默丢弃。
 */
function textOfContextEdit(d: Record<string, unknown>): string {
	const targetId = typeof d.targetId === "string" && d.targetId !== "" ? d.targetId : "";
	const replacement = d.replacement;
	if (targetId && replacement === null) {
		return `context_edit target=${targetId}：从后续模型上下文省略（原始记录保留）`;
	}
	if (targetId && replacement !== null && typeof replacement === "object" && !Array.isArray(replacement)) {
		const content = (replacement as Record<string, unknown>).content;
		if (typeof content === "string" || Array.isArray(content)) {
			return `context_edit target=${targetId}：替换后续模型上下文内容（原始记录保留）`;
		}
	}
	return `context_edit${targetId ? ` target=${targetId}` : ""}：无效编辑字段（未应用）`;
}

export interface ParsedAgentSession {
	entries: AgentSessionEntry[];
	/** JSON 解析失败 / 非对象 / 缺 type 的行数。 */
	skipped: number;
	/** 非空行数（含损坏行）。 */
	totalLines: number;
}

/**
 * pi 会话 JSONL → 中立条目。折叠/映射规则（协议 §4.8 kind 枚举）：
 *   - message(role=user) → user；message(role=assistant) 的 text/thinking/toolCall 块逐块成条；
 *   - message(role=toolResult)、message(role=bashExecution) → toolResult（toolName/isError）；
 *   - custom/custom_message/message(custom…) 与 session/model_change/compaction/… 行 → meta；
 *     context_edit（pi 0.87.1）→ meta 固定文案（textOfContextEdit），不做删除/替换；
 *   - 未知 type 行 → meta（type 原文），不静默丢弃；损坏行计入 skipped。
 */
export function parseAgentSessionJsonl(text: string): ParsedAgentSession {
	const entries: AgentSessionEntry[] = [];
	let skipped = 0;
	let totalLines = 0;
	// v1.0.20 恢复性省略标记素材：message entry id → toolCall 条目下标；context_edit
	// （replacement=null）targetId 集合；toolResult 配对过的 toolCall id 集合（已执行的工具
	// 不标记——结果条目仍在原始转录，配对语义优先）。
	const toolCallsByMessageId = new Map<string, number[]>();
	const omittedMessageIds = new Set<string>();
	const pairedToolCallIds = new Set<string>();
	for (const raw of String(text ?? "").split("\n")) {
		const line = raw.trim();
		if (!line) continue;
		totalLines++;
		let parsed: unknown;
		try { parsed = JSON.parse(line); } catch { skipped++; continue; }
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)
			|| typeof (parsed as { type?: unknown }).type !== "string") {
			skipped++;
			continue;
		}
		const d = parsed as Record<string, unknown> & { type: string };
		const ts = isoOf(d.timestamp);
		if (d.type === "message") {
			const msg = d.message;
			if (!msg || typeof msg !== "object") { skipped++; continue; }
			const m = msg as Record<string, unknown>;
			const mts = ts ?? isoOf(m.timestamp);
			switch (m.role) {
				case "user":
					entries.push({ kind: "user", ts: mts, text: textOfContent(m.content) });
					continue;
				case "assistant": {
					const blocks = Array.isArray(m.content) ? m.content : [];
					let emitted = false;
					for (const block of blocks) {
						if (!block || typeof block !== "object") continue;
						const b = block as Record<string, unknown>;
						if (b.type === "text" && typeof b.text === "string") {
							entries.push({ kind: "assistant", ts: mts, text: b.text });
							emitted = true;
						} else if (b.type === "thinking") {
							entries.push({ kind: "thinking", ts: mts, text: textOfThinking(b) });
							emitted = true;
						} else if (b.type === "toolCall") {
							entries.push({
								kind: "toolCall",
								ts: mts,
								toolName: typeof b.name === "string" ? b.name : "",
								text: textOfToolCallArgs(b.arguments),
								// v2.8.0：透传 pi JSONL 原生调用 id——侧边栏多工具交错时按 id 精确配对
								// （旧会话数据无此字段，前端 FIFO 兑底）。可选字段，旧前端忽略不破坏。
								toolCallId: typeof b.id === "string" ? b.id : undefined,
							});
							// v1.0.20：记录所属 message entry id，供 context_edit 省略后置标记。
							if (typeof d.id === "string" && d.id !== "") {
								const list = toolCallsByMessageId.get(d.id);
								if (list) list.push(entries.length - 1);
								else toolCallsByMessageId.set(d.id, [entries.length - 1]);
							}
							emitted = true;
						} else if (b.type === "image") {
							entries.push({ kind: "assistant", ts: mts, text: "[image]" });
							emitted = true;
						}
					}
					// 无可见块的 assistant（如 stopReason=error）：保底一条，避免轮次断档。
					if (!emitted) {
						entries.push({ kind: "assistant", ts: mts, text: typeof m.errorMessage === "string" ? m.errorMessage : "" });
					}
					continue;
				}
				case "toolResult": {
					const toolName = typeof m.toolName === "string" ? m.toolName : "";
					// B4：toolResult 语义投影（details 档可证明字段；text 档不携带 presentation——前端维持原样）。
					const content = Array.isArray(m.content)
						? (m.content as ReadonlyArray<{ type?: string; text?: unknown }>) : undefined;
					const presentation = projectToolPresentation(toolName, {
						content,
						details: m.details,
						isError: m.isError === true,
					});
					entries.push({
						kind: "toolResult",
						ts: mts,
						toolName,
						// v2.8.0：与 toolCall.id 同源配对凭证（见上方注释）。
						toolCallId: typeof m.toolCallId === "string" ? m.toolCallId : undefined,
						isError: m.isError === true,
						text: textOfContent(m.content),
						...(presentation && presentation.source === "details" ? { presentation } : {}),
					});
					// v1.0.20：记录已配对 toolCall id（省略标记对已执行工具不生效）。
					if (typeof m.toolCallId === "string") pairedToolCallIds.add(m.toolCallId);
					continue;
				}
				case "bashExecution": {
					const exitCode = typeof m.exitCode === "number" ? m.exitCode : undefined;
					const command = typeof m.command === "string" ? m.command : "";
					const output = typeof m.output === "string" ? m.output : "";
					entries.push({
						kind: "toolResult",
						ts: mts,
						toolName: "bash",
						isError: (exitCode !== undefined && exitCode !== 0) || m.cancelled === true,
						text: `$ ${command}${output ? `\n${output}` : ""}`,
					});
					continue;
				}
				case "custom":
					entries.push({
						kind: "meta",
						ts: mts,
						text: `custom ${String(m.customType ?? "?")}${m.content !== undefined ? `: ${textOfContent(m.content)}` : ""}`,
					});
					continue;
				case "branchSummary":
				case "compactionSummary":
					entries.push({ kind: "meta", ts: mts, text: typeof m.summary === "string" ? m.summary : "" });
					continue;
				default:
					entries.push({ kind: "meta", ts: mts, text: `message(${String(m.role ?? "?")})` });
					continue;
			}
		}
		switch (d.type) {
			case "session":
				entries.push({ kind: "meta", ts, text: `session v${String(d.version ?? 1)} id=${String(d.id ?? "?")}` });
				continue;
			case "model_change":
				entries.push({ kind: "meta", ts, text: `model_change ${String(d.provider ?? "?")}/${String(d.modelId ?? "?")}` });
				continue;
			case "thinking_level_change":
				entries.push({ kind: "meta", ts, text: `thinking_level_change ${String(d.thinkingLevel ?? "?")}` });
				continue;
			case "compaction":
				entries.push({ kind: "meta", ts, text: typeof d.summary === "string" ? d.summary : "compaction" });
				continue;
			case "branch_summary":
				entries.push({ kind: "meta", ts, text: typeof d.summary === "string" ? d.summary : "branch_summary" });
				continue;
			case "custom":
				entries.push({ kind: "meta", ts, text: `custom ${String(d.customType ?? "?")}` });
				continue;
			case "custom_message":
				entries.push({
					kind: "meta",
					ts,
					text: `custom_message ${String(d.customType ?? "?")}${d.content !== undefined ? `: ${textOfContent(d.content)}` : ""}`,
				});
				continue;
			case "label":
				entries.push({ kind: "meta", ts, text: `label ${String(d.label ?? "")}` });
				continue;
			case "session_info":
				entries.push({ kind: "meta", ts, text: `session_info ${String(d.name ?? "")}` });
				continue;
			case "context_edit":
				// v1.0.20：省略编辑（replacement=null）记 targetId，供 toolCall 恢复性省略后置标记。
				if (d.replacement === null && typeof d.targetId === "string" && d.targetId !== "") {
					omittedMessageIds.add(d.targetId);
				}
				entries.push({ kind: "meta", ts, text: textOfContextEdit(d) });
				continue;
			default:
				// 未来新增类型：type 原文成 meta（前向兼容，不静默丢弃）。
				entries.push({ kind: "meta", ts, text: d.type });
				continue;
		}
	}
	// v1.0.20 后置标记：消息被 context_edit（replacement=null）省略且其 toolCall 无任何
	// toolResult 配对 → 恢复性省略（pi _omitRecoveryAttempt 在执行前丢弃尝试，工具从未运行）。
	for (const [messageId, indexes] of toolCallsByMessageId) {
		if (!omittedMessageIds.has(messageId)) continue;
		for (const idx of indexes) {
			const entry = entries[idx];
			if (entry.kind !== "toolCall") continue;
			if (entry.toolCallId !== undefined && pairedToolCallIds.has(entry.toolCallId)) continue;
			entry.omitted = true;
		}
	}
	return { entries, skipped, totalLines };
}

export interface AgentSessionEntriesWindow {
	entries: AgentSessionEntry[];
	totalLines: number;
	truncated: boolean;
	/** 损坏行计数（wire 不下发，供调用方/测试观测）。 */
	skipped: number;
}

/**
 * 解析 + 尾部窗口裁剪 + 单条 text 截断（协议 §4.8 冻结语义）。
 * `tailTruncated` 由 readAgentSessionText 提供（文件 >2 MiB 只读了尾部）。
 */
export function buildAgentSessionEntries(text: string, tailTruncated = false): AgentSessionEntriesWindow {
	const parsed = parseAgentSessionJsonl(text);
	const dropped = Math.max(0, parsed.entries.length - AGENT_SESSION_ENTRY_CAP);
	const kept = dropped > 0 ? parsed.entries.slice(-AGENT_SESSION_ENTRY_CAP) : parsed.entries;
	const entries = kept.map((entry) => {
		const capped = truncateAgentEntryText(entry.text);
		return capped === entry.text ? entry : { ...entry, text: capped };
	});
	return {
		entries,
		totalLines: parsed.totalLines,
		truncated: tailTruncated || dropped > 0,
		skipped: parsed.skipped,
	};
}

// ── 读取（全文 / >2 MiB 尾窗） ───────────────────────────────────────────────

export interface AgentSessionRead {
	text: string;
	truncated: boolean;
}

/**
 * 读取会话文件：≤2 MiB 全量；>2 MiB 只读尾部 256 KiB（首行可能被截半 → 丢弃残行），
 * truncated=true。I/O 异常向调用方抛出（adapter 转降级响应）。
 */
export async function readAgentSessionText(file: string): Promise<AgentSessionRead> {
	const st = await fs.promises.stat(file);
	if (st.size <= AGENT_SESSION_LARGE_FILE_BYTES) {
		return { text: await fs.promises.readFile(file, "utf8"), truncated: false };
	}
	const tailBytes = Math.min(st.size, AGENT_SESSION_TAIL_BYTES);
	const fh = await fs.promises.open(file, "r");
	try {
		const buf = Buffer.alloc(tailBytes);
		await fh.read(buf, 0, tailBytes, st.size - tailBytes);
		let text = buf.toString("utf8");
		const firstNl = text.indexOf("\n");
		if (firstNl >= 0) text = text.slice(firstNl + 1); // 丢弃残行
		return { text, truncated: true };
	} finally {
		await fh.close().catch(() => {});
	}
}

// ── taskId 匹配 + 响应组装 ───────────────────────────────────────────────────

/**
 * taskId 精确或唯一前缀匹配：精确命中优先；否则前缀命中恰好 1 条返回；0 或多义（>1）
 * 返回 undefined（协议 §4.8：404 task_not_found；调用方不得猜测歧义前缀）。
 * 前缀比较大小写不敏感（taskId 生成形态可含大小写字母）。
 */
export function matchTaskId<T extends { taskId: string }>(records: readonly T[], query: string): T | undefined {
	const q = String(query ?? "").trim();
	if (!q) return undefined;
	const exact = records.find((r) => r.taskId === q);
	if (exact) return exact;
	const lower = q.toLowerCase();
	const hits = records.filter((r) => r.taskId.toLowerCase().startsWith(lower));
	return hits.length === 1 ? hits[0] : undefined;
}

/**
 * resolveAgentSessionFile 的注入面（index.ts 装配；webui 子树不 import session-viewer/journal
 * 运行时，依赖经此注入）。
 */
export interface AgentSessionResolveDeps<RecordLike = unknown> {
	/** session-viewer.resolveSessionFile 的注入形态（按 query 在 records/目录中定位会话文件）。 */
	resolveFile(query: string, opts: { records: Readonly<RecordLike>[]; cwd: string }): string | undefined;
	/** 运行中 record.sessionId 未回填时，从 journal 首帧 session 见证行补读映射（无映射返回 undefined）。 */
	findJournalSessionId(taskId: string): string | undefined;
}

/**
 * 定位任务会话文件（含运行中兜底链路，2026-09-11 真机「未找到会话文件」修复）：
 *  1. 先按 taskId 查询（resolveSessionFile 经 records 命中 record.sessionId）；
 *  2. record.sessionId 缺失（任务运行中——registry 于终结时才回填）时，经 journal 首帧
 *     session 见证行（task-run.ts ev-20260903-a5b662，spawn 后 ~首帧即落盘）补读 sessionId
 *     后再查——webui 侧边栏实时查看运行中任务的会话依赖此兜底；
 *  3. 仍无 → undefined（调用方降级 200 + entries:[] + error 文案）。
 * 查询失败一律静默降级（只读路径，不让观测面反噬主流程）。
 */
export function resolveAgentSessionFile<RecordLike>(
	record: { taskId: string; sessionId?: string },
	ctx: { records: Readonly<RecordLike>[]; cwd: string },
	deps: AgentSessionResolveDeps<RecordLike>,
): string | undefined {
	const direct = deps.resolveFile(record.taskId, { records: ctx.records, cwd: ctx.cwd });
	if (direct) return direct;
	if (record.sessionId) return undefined; // 已有 sessionId 仍找不到：文件缺失/被清理，不再猜
	let journalSessionId: string | undefined;
	try { journalSessionId = deps.findJournalSessionId(record.taskId); } catch { journalSessionId = undefined; }
	if (!journalSessionId) return undefined;
	return deps.resolveFile(journalSessionId, { records: ctx.records, cwd: ctx.cwd });
}

/** 响应组装所需的 registry 记录结构子集（避免 webui 子树 import task-registry 运行时）。 */
export interface AgentSessionRecordLike {
	taskId: string;
	agent: string;
	status: string;
	sessionId?: string;
	blockReason?: string;
	blockedQuestions?: readonly string[];
	result?: string;
}

/** blocked 行动摘要：needs-handoff 固定指引 > blockedQuestions 首条 > result 压空白 → 占位。 */
function blockedQuestionOf(record: AgentSessionRecordLike): string | null {
	if (record.status !== "blocked") return null;
	if (record.blockReason === "needs-handoff") return HANDOFF_QUESTION;
	const first = record.blockedQuestions?.[0];
	if (first) return capChars(first, AGENT_SESSION_BLOCKED_QUESTION_CAP);
	if (record.result) return capChars(record.result.replace(/\s+/g, " ").trim(), AGENT_SESSION_BLOCKED_QUESTION_CAP);
	return EMPTY_QUESTION;
}

/**
 * 记录 + 会话文件 + 读取结果 → 200 响应体（协议 §4.8）。
 * `read` 为 null 表示会话文件缺失/读失败：entries:[]、totalLines:0、error 携带降级文案。
 */
export function buildAgentSessionBody(
	record: AgentSessionRecordLike,
	sessionFile: string | null,
	read: AgentSessionRead | null,
	error: string | null = null,
	now: string = new Date().toISOString(),
): AgentSessionBody {
	const window = read
		? buildAgentSessionEntries(read.text, read.truncated)
		: { entries: [] as AgentSessionEntry[], totalLines: 0, truncated: false, skipped: 0 };
	return {
		v: 1,
		taskId: record.taskId,
		agent: record.agent,
		status: record.status,
		blockReason: record.blockReason === "questions" || record.blockReason === "needs-handoff"
			? record.blockReason
			: null,
		blockedQuestion: blockedQuestionOf(record),
		sessionId: record.sessionId ?? null,
		sessionFile,
		totalLines: window.totalLines,
		truncated: window.truncated,
		entries: window.entries,
		error,
		updatedAt: now,
	};
}
