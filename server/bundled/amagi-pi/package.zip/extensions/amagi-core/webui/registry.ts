import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export interface WebUiRegistryEntry {
	v: 1;
	pid: number;
	host: "127.0.0.1";
	port: number;
	token: string;
	sessionId: string | null;
	sessionFile: string | null;
	ready: boolean;
	startedAt: string;
	/** 写入进程平台（process.platform）。prune 只清同平台条目：共享 agent 根
	 *  场景（codebox 钉定 PI_CODING_AGENT_DIR 后 Windows 与 WSL 的 pi 写同一
	 *  目录）pid 命名空间互不相通，process.kill 判活会把对方活条目当死条目
	 *  误删（跨系统 pid 等值撞到无关进程/不存在均不可信）。缺省（旧条目）
	 *  跳过清理，探测方自愈兑底。 */
	platform?: string;
}

export function defaultAgentDir(env: NodeJS.ProcessEnv = process.env): string {
	return env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
}

/** AMAGI_WEBUI_PORT_FILE is an exact per-process file override for isolated tests. */
export function resolveRegistryFile(
	env: NodeJS.ProcessEnv = process.env,
	pid = process.pid,
): string {
	if (env.AMAGI_WEBUI_PORT_FILE) return path.resolve(env.AMAGI_WEBUI_PORT_FILE);
	return path.join(defaultAgentDir(env), "amagi", "webui-registry", `${pid}.json`);
}

export function writeRegistryEntry(file: string, entry: WebUiRegistryEntry): void {
	fs.mkdirSync(path.dirname(file), { recursive: true });
	const temporary = `${file}.tmp`;
	try {
		fs.writeFileSync(temporary, `${JSON.stringify(entry, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
		fs.renameSync(temporary, file);
	} catch (error) {
		try { fs.rmSync(temporary, { force: true }); } catch {}
		throw error;
	}
}

export function removeRegistryEntry(file: string): void {
	try { fs.rmSync(file, { force: true }); } catch { /* best effort during shutdown */ }
}

/** v1.5.259：清扫注册表目录内已死 pid 的残留条目（崩溃/SIGKILL 无法走 exit 钩，实测
 *  目录膨胀至 492 条）。判定保守：仅删除 JSON 可解析且 pid 存在但进程已清亡（ESRCH）的
 *  条目；解析失败、pid 缺失、探活抛 EPERM（存在但非本用户）一律跳过——探测方已有自愈，
 *  这里只做确定性清理，绝不动活条目。共享 agent 根场景下只清同平台（platform 字段）
 *  条目：跨系统 pid 命名空间互不相通，判活不可信（见 WebUiRegistryEntry.platform）。
 *  返回删除数。 */
export function pruneDeadRegistryEntries(currentFile: string, currentPid: number): number {
	let removed = 0;
	const dir = path.dirname(currentFile);
	let names: string[];
	try { names = fs.readdirSync(dir); } catch { return 0; }
	for (const name of names) {
		if (!name.endsWith(".json")) continue;
		const file = path.join(dir, name);
		if (file === currentFile) continue;
		try {
			const entry = JSON.parse(fs.readFileSync(file, "utf8")) as { pid?: unknown; platform?: unknown };
			const pid = typeof entry.pid === "number" ? entry.pid : null;
			if (pid === null || pid === currentPid) continue;
			// 仅清同平台条目：异平台/无平台标记（旧条目）的 pid 判活不可信，跳过。
			if (entry.platform !== process.platform) continue;
			try { process.kill(pid, 0); } catch (error) {
				if ((error as NodeJS.ErrnoException).code === "ESRCH") {
					removeRegistryEntry(file);
					removed++;
				}
			}
		} catch { /* 残缺/不可读条目不动：探测方自愈覆盖 */ }
	}
	return removed;
}

