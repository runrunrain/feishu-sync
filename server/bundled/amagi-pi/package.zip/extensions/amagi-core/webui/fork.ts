/**
 * fork.ts — webui「从任意轮次分叉新会话」的纯数据面（协议 v1.0.24：
 * GET /api/fork-points、POST /api/fork、WS 事件 fork_failed）。
 *
 * 职责：在活动分支（SessionManager.getBranch()，root→leaf 的原始条目）上
 *   1. 枚举用户轮次锚点（listForkPoints）——前端把 doc 中的用户气泡按文本顺序对位到
 *      pi 条目 id（实时事件里的消息尚无 entry id，持久化发生在扩展事件分发之后）；
 *   2. 把「轮次 + 模式」解析成 ctx.fork(entryId, {position}) 的真实参数（resolveForkTarget）：
 *      - mode="turn"（保留本轮）：position="at"，目标 = 本轮最后一条可作为上下文终点的
 *        assistant 回复（无 toolCall、非 error/aborted）；无则退回用户条目自身。
 *        新会话含本轮及之前全部上下文，继续对话即可。
 *      - mode="edit"（编辑重发）：position="before"，目标 = 用户条目；新会话停在本轮之前，
 *        前端把原提示词回填输入框。
 *
 * 零 pi / fs / UI 依赖（depcruise webui-isolated），可直接单测。
 */

/** 隐藏的内部命令名：页面 POST /api/fork 经 pi.sendUserMessage 派发，取得 ExtensionCommandContext.fork。 */
export const WEBUI_FORK_COMMAND = "amagi-webui-fork";

export type ForkMode = "turn" | "edit";
export type ForkPosition = "before" | "at";

/** 锚点文本上限（code unit）；前端按同一上限对位。 */
export const FORK_POINT_TEXT_CAP = 200;
/** 单次下发锚点上限（取最近 N 个用户轮次）。 */
export const FORK_POINT_LIMIT = 2000;

export interface ForkPoint {
	/** 用户消息条目 id（POST /api/fork 的 entryId）。 */
	entryId: string;
	/** 用户文本（text 块以 \n 连接、trim、截断到 FORK_POINT_TEXT_CAP）。 */
	text: string;
	/** ISO 时间戳；缺失为 null。 */
	ts: string | null;
}

export type ForkResolveResult =
	| { ok: true; entryId: string; position: ForkPosition }
	| { ok: false; error: "entry_not_found" | "not_user_message" };

type BranchEntry = Record<string, unknown>;

function messageOf(entry: BranchEntry): Record<string, unknown> | null {
	if (entry.type !== "message") return null;
	const m = entry.message;
	return m && typeof m === "object" ? (m as Record<string, unknown>) : null;
}

function isUserEntry(entry: BranchEntry): boolean {
	return messageOf(entry)?.role === "user";
}

function textOfUserEntry(entry: BranchEntry): string {
	const content = messageOf(entry)?.content;
	if (typeof content === "string") return content;
	if (!Array.isArray(content)) return "";
	return content
		.filter((b): b is { type: "text"; text: string } =>
			!!b && typeof b === "object" && (b as { type?: unknown }).type === "text" && typeof (b as { text?: unknown }).text === "string")
		.map((b) => b.text)
		.join("\n");
}

function tsOf(entry: BranchEntry): string | null {
	return typeof entry.timestamp === "string" && entry.timestamp !== "" ? entry.timestamp : null;
}

/** 活动分支上的用户轮次锚点（时间正序，最多最近 FORK_POINT_LIMIT 个）。 */
export function listForkPoints(branch: readonly BranchEntry[]): ForkPoint[] {
	const points: ForkPoint[] = [];
	for (const entry of branch) {
		if (!entry || typeof entry !== "object" || typeof entry.id !== "string" || !isUserEntry(entry)) continue;
		points.push({
			entryId: entry.id,
			text: textOfUserEntry(entry).trim().slice(0, FORK_POINT_TEXT_CAP),
			ts: tsOf(entry),
		});
	}
	return points.length > FORK_POINT_LIMIT ? points.slice(-FORK_POINT_LIMIT) : points;
}

/** assistant 条目是否可作为「保留本轮」的终点：非 error/aborted 且不含 toolCall（避免悬空工具调用）。 */
function isCleanAssistantEnd(entry: BranchEntry): boolean {
	const m = messageOf(entry);
	if (!m || m.role !== "assistant") return false;
	if (m.stopReason === "error" || m.stopReason === "aborted") return false;
	const content = Array.isArray(m.content) ? m.content : [];
	return !content.some((b) => !!b && typeof b === "object" && (b as { type?: unknown }).type === "toolCall");
}

/** 解析 (用户条目 id, 模式) → ctx.fork 参数；只接受活动分支上的用户消息条目。 */
export function resolveForkTarget(
	branch: readonly BranchEntry[],
	entryId: string,
	mode: ForkMode,
): ForkResolveResult {
	const index = branch.findIndex((e) => !!e && typeof e === "object" && e.id === entryId);
	if (index < 0) return { ok: false, error: "entry_not_found" };
	if (!isUserEntry(branch[index])) return { ok: false, error: "not_user_message" };
	if (mode === "edit") return { ok: true, entryId, position: "before" };
	let end = branch.length;
	for (let i = index + 1; i < branch.length; i++) {
		if (isUserEntry(branch[i])) { end = i; break; }
	}
	for (let i = end - 1; i > index; i--) {
		const candidate = branch[i];
		if (typeof candidate.id === "string" && isCleanAssistantEnd(candidate)) {
			return { ok: true, entryId: candidate.id, position: "at" };
		}
	}
	return { ok: true, entryId, position: "at" };
}
