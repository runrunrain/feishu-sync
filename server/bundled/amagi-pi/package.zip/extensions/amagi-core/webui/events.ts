import type { RoundSnapshot } from "./round-tracker.ts";
import type { TaskPanelSnapshot } from "./task-panel.ts";
import type { UsageSnapshot } from "./usage-store.ts";

export const WEBUI_PROTOCOL_VERSION = 1 as const;
export const EVENT_BUFFER_CAPACITY = 4096;

export type EnvelopeKind = "session_event" | "hello" | "bye";

export interface EventEnvelope {
	v: 1;
	seq: number;
	ts: string;
	kind: EnvelopeKind;
	event: unknown;
}

export interface HelloMetadata {
	sessionId: string | null;
	sessionFile: string | null;
	model: { provider: string; id: string } | null;
	pid: number;
	/** v1.0.13：事件流标识（server 实例唯一 id）。停服重建（/resume 等 switch 类）后
	 * EventStream seq 归零，重连客户端携带的旧水位 since 会剪掉新流全部回放帧（含
	 * session_start），页面因此收不到会话切换信号。hello 携带 stream 让客户端识别
	 * “流已重置”并强制全量 refetch（协议 §7.5）。可选字段：缺席时客户端维持旧行为。 */
	stream?: string;
	pendingCount?: number;
	/** v1.0.4：最新 usage 快照（可选；未注入时字段缺席，客户端按前向兼容规则忽略）。 */
	usage?: UsageSnapshot;
	/** v1.0.5：最新编排实况面板快照（可选；未注入时字段缺席，客户端按前向兼容规则忽略）。 */
	panel?: TaskPanelSnapshot;
	/** v1.0.22：本轮用时快照（始终携带：null=无计时数据——旧会话/未开轮；客户端隐藏标签）。
	 * running=在途轮（startMs 起实时累计）；done/aborted=冻结起止；interrupted=历史未闭合
	 * start（上进程异常退出，endMs=null 结束时刻未知——不得虚构用时）。 */
	round?: RoundSnapshot | null;
}

const SENSITIVE_FIELD = /token|secret|password|authorization/i;

function isSensitiveField(name: string): boolean {
	const lower = name.toLowerCase();
	return lower === "key" || lower === "apikey" || SENSITIVE_FIELD.test(lower);
}

/**
 * Defensive copy for event payloads. Sensitive properties are removed rather
 * than masked so a future pi event cannot accidentally expose credentials.
 */
export function filterEventPayload<T>(value: T): T {
	const ancestors = new WeakSet<object>();
	const visit = (input: unknown): unknown => {
		if (input === null || typeof input !== "object") return input;
		if (ancestors.has(input)) return undefined;
		ancestors.add(input);
		try {
			if (Array.isArray(input)) return input.map(visit);
			const output: Record<string, unknown> = {};
			for (const [key, child] of Object.entries(input)) {
				if (!isSensitiveField(key)) output[key] = visit(child);
			}
			return output;
		} finally {
			ancestors.delete(input);
		}
	};
	return visit(value) as T;
}

/**
 * v1.0.4：usage_stats 为服务端合成事件（载荷全部来自 UsageStore.snapshot() 的冻结
 * 深拷贝——数值与受限字符串，无凭据路径）。其 leader.contextTokens 字段名含 "token"
 * 子串，会被透传防御过滤器误删；合成事件数据源可信，跳过过滤以保住冻结 wire 形状。
 * 豁免做形状校验：缺 models/leader/updatedAt 的伪 usage_stats 仍走透传过滤；
 * pi 事件透传的过滤行为不变。
 */
function isUsageStatsEvent(event: unknown): boolean {
	if (!event || typeof event !== "object") return false;
	const typed = event as { type?: unknown; usage?: unknown };
	if (typed.type !== "usage_stats" || !typed.usage || typeof typed.usage !== "object") return false;
	const usage = typed.usage as Record<string, unknown>;
	return usage.models !== null && typeof usage.models === "object"
		&& usage.leader !== null && typeof usage.leader === "object"
		&& typeof usage.updatedAt === "number";
}

/** task_panel 的 contextTokens 是用量数值。先过滤整个事件，再仅恢复任务项此字段，
 * 避免 token 子串误删；不豁免整份面板，其他位置/类型及凭据字段仍执行防御过滤。 */
function filterSessionEvent(event: unknown): unknown {
	if (isUsageStatsEvent(event)) return event;
	const filtered = filterEventPayload(event);
	if (!event || typeof event !== "object") return filtered;
	const typed = event as { type?: unknown; panel?: { tasks?: unknown } };
	if (typed.type !== "task_panel" || !Array.isArray(typed.panel?.tasks)) return filtered;
	const copies = (filtered as { panel?: { tasks?: unknown } }).panel?.tasks;
	if (!Array.isArray(copies)) return filtered;
	for (const [i, item] of typed.panel.tasks.entries()) {
		if (!item || typeof item !== "object") continue;
		const tokens = (item as { contextTokens?: unknown }).contextTokens;
		const copy = copies[i];
		if (typeof tokens === "number" && Number.isFinite(tokens) && tokens >= 0
			&& copy && typeof copy === "object" && !Array.isArray(copy)) {
			(copy as { contextTokens?: number }).contextTokens = tokens;
		}
	}
	return filtered;
}

export class EventStream {
	readonly capacity: number;
	#seq = 0;
	#ring: EventEnvelope[] = [];
	#listeners = new Set<(envelope: EventEnvelope) => void>();

	constructor(capacity = EVENT_BUFFER_CAPACITY) {
		if (!Number.isSafeInteger(capacity) || capacity < 1) throw new RangeError("event buffer capacity must be a positive integer");
		this.capacity = capacity;
	}

	get sequence(): number { return this.#seq; }
	get buffered(): number { return this.#ring.length; }
	get floor(): number { return this.#ring[0]?.seq ?? this.#seq + 1; }

	bufferSnapshot(): readonly EventEnvelope[] {
		return this.#ring.slice();
	}

	subscribe(listener: (envelope: EventEnvelope) => void): () => void {
		this.#listeners.add(listener);
		return () => this.#listeners.delete(listener);
	}

	publish(event: unknown): EventEnvelope {
		const envelope = this.#next("session_event", filterSessionEvent(event));
		this.#ring.push(envelope);
		if (this.#ring.length > this.capacity) this.#ring.splice(0, this.#ring.length - this.capacity);
		this.#emit(envelope);
		return envelope;
	}

	createHello(metadata: HelloMetadata, since: number): { hello: EventEnvelope; replay: readonly EventEnvelope[] } {
		const replay = this.replaySince(since);
		const hello = this.#next("hello", {
			sessionId: metadata.sessionId,
			sessionFile: metadata.sessionFile,
			model: metadata.model,
			pid: metadata.pid,
			...(metadata.stream !== undefined ? { stream: metadata.stream } : {}),
			since,
			replay: replay.length,
			floor: this.floor,
			pendingCount: metadata.pendingCount ?? 0,
			// v1.0.4：usage 快照随 hello 下发（可选字段，未注入时缺席；客户端忽略未知字段）。
			...(metadata.usage !== undefined ? { usage: metadata.usage } : {}),
			// v1.0.5：编排实况面板快照随 hello 下发（可选字段，未注入时缺席；客户端忽略未知字段）。
			...(metadata.panel !== undefined ? { panel: metadata.panel } : {}),
			// v1.0.22：本轮用时快照随 hello 下发（本仓 server 恒携带，null=无计时数据；旧/mock
			// 注入面缺席时字段缺席，客户端按无数据处理）。
			...(metadata.round !== undefined ? { round: metadata.round } : {}),
		});
		return { hello, replay };
	}

	publishBye(reason: string): EventEnvelope {
		const envelope = this.#next("bye", { reason });
		this.#emit(envelope);
		return envelope;
	}

	replaySince(since: number): readonly EventEnvelope[] {
		return this.#ring.filter((envelope) => envelope.kind === "session_event" && envelope.seq > since);
	}

	#next(kind: EnvelopeKind, event: unknown): EventEnvelope {
		return {
			v: WEBUI_PROTOCOL_VERSION,
			seq: ++this.#seq,
			ts: new Date().toISOString(),
			kind,
			event,
		};
	}

	#emit(envelope: EventEnvelope): void {
		for (const listener of this.#listeners) {
			try { listener(envelope); } catch { /* one client cannot break the stream */ }
		}
	}
}
