/**
 * usage-store.ts — webui usage 数据面聚合器（协议 v1.0.4，docs/webui-protocol.md §5）。
 *
 * 冻结 wire 契约：hello.usage 与 usage_stats 事件共用同一快照形状（UsageSnapshot）。
 * 本模块是该快照的唯一内存聚合源：Leader 轮次（assistant message_end 的
 * provider/model/usage）与子任务（task-tool writeStats 漏斗分流）按模型 key 累计
 * token 用量，另附 Leader 上下文水位与子任务 scope。
 *
 * 并发模型：单进程事件循环内串行调用，无需锁；snapshot() 返回冻结深拷贝
 * （updatedAt=快照时刻 epoch ms），调用方持有的快照与内部状态完全隔离。
 *
 * 缓存命中率口径（与 TCER CHR / stats-aggregate.ts hitRate 一致）：
 * cacheRead/(input+cacheRead+cacheWrite)；pi 的 input 不含缓存（Anthropic 语义），
 * 每条 assistant 恰携一个 usage（无 Claude Code 多行重复），全零行跳过（见 #accumulate）。
 * 由前端按此口径渲染，服务端不预计算派生值。
 *
 * 幂等权衡：同一任务 resume 多轮会多次喂入（writeStats 每轮落盘一次）——usage 定位为
 * **累计仪表盘**（本进程生命周期内的总消耗视图），接受重复累计而非按任务去重；按任务
 * 精确去重的口径由 data/agent-stats.ndjson / traces.ndjson 落盘链路承担。
 *
 * B0-1（附录 B.1）：writeStats 行升级为累计口径（一行=一次运行可见事件累计，非末轮值）——
 * recordChild 携带 calls（assistant 完结事件数）时 requests 按调用数入账；缺省回退 1
 * （旧调用面/旧行兼容）。嵌套/压缩分项不经本面（单列在 trace/agent-stats 落盘行）。
 */

export interface ModelUsageRow {
	input: number;
	output: number;
	cacheRead: number;
	cacheWrite: number;
	requests: number;
}

/** B0-2（webui 统计弹窗）：按角色累计行——与 ModelUsageRow 同入账口径（writeStats 漏斗分流），
 *  另计 tasks（本进程内观察到带 usage 的唯一 taskId 数；resume 多轮不重复计）。 */
export interface AgentUsageRow {
	tasks: number;
	requests: number;
	input: number;
	output: number;
	cacheRead: number;
	cacheWrite: number;
}

export interface UsageSnapshot {
	/** key: `${provider}/${model}`；无 provider 信息时直接用 model id 字符串。 */
	models: Record<string, ModelUsageRow>;
	/** B0-2：按角色累计（key=agent 名）；无任何子任务 usage=字段缺席（旧前端忽略未知字段）。
 *  与 models 同源同口径（同一 writeStats entry 分流累计），幂等权衡同 models（resume 多轮重复累计）。 */
	agents?: Record<string, AgentUsageRow>;
	/** contextTokens 来自 getContextUsage().tokens；null=未知（如压缩后）。 */
	leader: { model: string | null; contextTokens: number | null; contextWindow: number | null };
	/** 子任务总数与运行中数；无任何子任务=null。 */
	scope: { tasks: number; active: number } | null;
	/** epoch ms。 */
	updatedAt: number;
}

export interface LeaderUsageInput {
	provider?: string;
	model?: string;
	usage?: { input?: number; output?: number; cacheRead?: number; cacheWrite?: number };
}

export interface ChildUsageInput {
	agent: string;
	/** B0-2：任务标识（按角色统计弹窗的唯一 taskId 计数用；缺席=不计数）。 */
	taskId?: string;
	model?: string;
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	/** B0-1：本行 assistant 完结事件数（累计行=一次运行的调用数；缺省回退 1）。 */
	calls?: number;
	/** F2（diting，附录 B.1）：分模型小计——携带时 models 面按各桶实际模型入账（顶层
	 *  model 的总额不重复入账）；分项 undefined=该桶未观察，不入账不补零。 */
	modelSubtotals?: ReadonlyArray<{ model: string; input?: number; output?: number; cacheRead?: number; cacheWrite?: number; cost?: number; assistantCalls?: number }>;
}

const UNKNOWN_MODEL = "unknown";

function finite(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

/**
 * 模型 key：provider/model 齐备时拼 `${provider}/${model}`；model 已含 '/'（子任务侧
 * 已是 provider/model 形态，或上游只给复合 id）原样使用；两者皆缺记 'unknown'。
 */
export function modelKeyOf(provider: string | undefined, model: string | undefined): string {
	const p = typeof provider === "string" && provider.trim() !== "" ? provider.trim() : undefined;
	const m = typeof model === "string" && model.trim() !== "" ? model.trim() : undefined;
	if (m && m.includes("/")) return m;
	if (p && m) return `${p}/${m}`;
	return m || p || UNKNOWN_MODEL;
}

export class UsageStore {
	#models = new Map<string, ModelUsageRow>();
	/** B0-2：按角色累计（与 #models 同一 entry 分流）；tasks 计数用唯一 taskId 集。 */
	#agents = new Map<string, AgentUsageRow & { taskIds: Set<string> }>();
	#leader: UsageSnapshot["leader"] = { model: null, contextTokens: null, contextWindow: null };
	#scope: UsageSnapshot["scope"] = null;

	/** Leader 轮次：assistant message_end 的 provider/model/usage 累计进对应模型行，并更新 leader.model。 */
	recordLeader(message: LeaderUsageInput): void {
		const usage = message.usage;
		if (!usage || typeof usage !== "object") return;
		const key = modelKeyOf(message.provider, message.model);
		this.#leader.model = key;
		this.#accumulate(key, usage);
	}

	/**
	 * 子任务：writeStats entry 喂入。model 缺省记 'unknown'；key 直接用传入 model 字符串
	 * （已含 '/' 原样用）。四项 token 全部非有限数值时不累计（如 spawn 失败的 error
	 * entry——无模型消耗可观测，不产生行也不计 requests）。B0-1：calls 携带时 requests
	 * 按调用数入账（一行=一次运行累计）。B0-2：同一 entry 分流进按角色累计（同跳过规则）。
	 * F2（附录 B.1）：携带分模型小计时 models 面按各桶入账（顶层不重复；角色面仍按整行累计）。
	 */
	recordChild(entry: ChildUsageInput): void {
		const subtotals = Array.isArray(entry.modelSubtotals) && entry.modelSubtotals.length > 0 ? entry.modelSubtotals : undefined;
		let accumulated: number | undefined;
		if (subtotals) {
			let callsSum = 0;
			for (const st of subtotals) {
				const c = this.#accumulate(modelKeyOf(undefined, st?.model), { ...st, calls: st?.assistantCalls });
				if (c !== undefined) callsSum += c;
			}
			accumulated = callsSum > 0 ? callsSum : undefined;
		} else {
			accumulated = this.#accumulate(modelKeyOf(undefined, entry.model), entry);
		}
		if (accumulated) this.#accumulateAgent(entry, accumulated);
	}

	/** Leader 上下文水位（getContextUsage 投影）。字段缺省保留最近值；显式 null=未知（如压缩后）。 */
	setLeaderContext(info: { model?: string | null; contextTokens?: number | null; contextWindow?: number | null }): void {
		if (info.model !== undefined) this.#leader.model = info.model;
		if (info.contextTokens !== undefined) this.#leader.contextTokens = info.contextTokens;
		if (info.contextWindow !== undefined) this.#leader.contextWindow = info.contextWindow;
	}

	/** 子任务 scope；null=无任何子任务。 */
	setScope(scope: UsageSnapshot["scope"]): void {
		this.#scope = scope;
	}

	/** 冻结深拷贝快照；updatedAt=快照时刻。 */
	snapshot(): UsageSnapshot {
		const models: Record<string, ModelUsageRow> = {};
		for (const [key, row] of this.#models) models[key] = Object.freeze({ ...row });
		// B0-2：有任一角色入账才携带 agents（旧快照形状不变——leader-only 会话字段缺席）。
		const agents: Record<string, AgentUsageRow> = {};
		for (const [key, row] of this.#agents) {
			const { taskIds, ...rest } = row;
			agents[key] = Object.freeze({ ...rest, tasks: taskIds.size });
		}
		return Object.freeze({
			models: Object.freeze(models),
			...(Object.keys(agents).length > 0 ? { agents: Object.freeze(agents) } : {}),
			leader: Object.freeze({ ...this.#leader }),
			scope: this.#scope === null ? null : Object.freeze({ ...this.#scope }),
			updatedAt: Date.now(),
		});
	}

	/**
	 * 累计一行：四项 token 全部非有限时直接丢弃（不产生行、不计 requests）。
	 * TCER 口径对齐（empty_usage_skipped）：全零 usage 行同样跳过——不虚增 requests，
	 * 不把 0/0 污进缓存命中分母（真实请求 input 恒 >0，全零行是空响应/探针噪声）。
	 * B0-1：calls 携带时 requests += max(1, calls)（累计行按调用数入账；非法值回退 1）。
	 * B0-2：返回实际入账的调用数（未入账=undefined，供角色分流同规则跳过）。
	 */
	#accumulate(key: string, values: { input?: unknown; output?: unknown; cacheRead?: unknown; cacheWrite?: unknown; calls?: unknown }): number | undefined {
		const input = finite(values.input);
		const output = finite(values.output);
		const cacheRead = finite(values.cacheRead);
		const cacheWrite = finite(values.cacheWrite);
		const row = this.#models.get(key) ?? { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, requests: 0 };
		let touched = false;
		if (input) { row.input += input; touched = true; }
		if (output) { row.output += output; touched = true; }
		if (cacheRead) { row.cacheRead += cacheRead; touched = true; }
		if (cacheWrite) { row.cacheWrite += cacheWrite; touched = true; }
		if (!touched) return undefined;
		const calls = typeof values.calls === "number" && Number.isFinite(values.calls) && values.calls >= 1 ? Math.floor(values.calls) : 1;
		row.requests += calls;
		this.#models.set(key, row);
		return calls;
	}

	/**
	 * B0-2：按角色累计（与 #accumulate 同 entry、同跳过规则与入账值；agent 名归一 trim 后作 key，
	 * 空/缺=unknown 桶不丢计量）。tasks=唯一 taskId 计数（缺席不计）；重复 entry（resume 多轮）
	 * 的 token/requests 与 models 面同样接受重复累计，taskId 集合天然去重。
	 */
	#accumulateAgent(entry: ChildUsageInput, calls: number): void {
		const name = typeof entry.agent === "string" && entry.agent.trim() !== "" ? entry.agent.trim() : UNKNOWN_MODEL;
		const row = this.#agents.get(name) ?? { tasks: 0, requests: 0, input: 0, output: 0, cacheRead: 0, cacheWrite: 0, taskIds: new Set<string>() };
		const input = finite(entry.input);
		const output = finite(entry.output);
		const cacheRead = finite(entry.cacheRead);
		const cacheWrite = finite(entry.cacheWrite);
		if (input) row.input += input;
		if (output) row.output += output;
		if (cacheRead) row.cacheRead += cacheRead;
		if (cacheWrite) row.cacheWrite += cacheWrite;
		row.requests += calls;
		if (typeof entry.taskId === "string" && entry.taskId !== "") row.taskIds.add(entry.taskId);
		this.#agents.set(name, row);
	}
}
