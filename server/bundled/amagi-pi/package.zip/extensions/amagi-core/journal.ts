/**
 * journal.ts — 派发 journal 落盘（8月迭代第三轮 P0.5：「在途无痕」→「有迹可循」）。
 *
 * 实战事故（2026-08-18 吸引力系统会话）：终端更新杀死 pi 主进程，registry 全内存——
 * 在途任务（含 2 个并行 batch 节点）瞬间无痕，恢复靠 Leader 手工翻 worktree git 历史，
 * 6 轮才找回现场。journal 以 append-only JSONL 记录每次派发与结算：
 *   - dispatch 行：spawn 前 append（taskId/agent/goal/cwd/mode/model/时间/pid）；
 *   - settle 行：registry 到达终态时 append（taskId/status/时间）；
 *   - session 行（ev-20260903-a5b662，复盘 §1.2）：子进程首个 session 事件即 append
 *     （taskId/sessionId/时间）——宿主级联终止的被杀任务没有 artifact（metadata 只在
 *     finalize 写入），journal 的 dispatch+session 行成为唯一磁盘真相，backfill 据此恢复 resume。
 * 恢复链：启动时差集（dispatch − settle）= 中断时在途任务 → 通知 Leader 带 resume 指引；
 * board headless 快照尾部展示「中断残留」分区。
 *
 * 设计边界：
 *   - 永不影响派发/结算主流程：所有 IO 失败静默（journal 是可观测性，不是正确性依赖）；
 *   - 有界：单文件 append，启动时 sweep 重写只保留 maxAgeMs（默认 7 天）内的行；
 *   - 单进程假设：pi 主进程唯一写者（子进程不注册 journal——派发只发生在 Leader 侧）。
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { amagiDataFile } from "./data-dir.ts";
// ev-20260914-4150dd：残留对账只读依赖——registry 终态核对 + artifact 报告落盘探测（均无反向依赖，无环）。
import { registry, isTerminalStatus } from "./task-registry.ts";
import { findArtifact } from "./artifact.ts";
// C15（设计 §6.5）：进程内 advisory 调用事实行的类型面（写入经 journalAdvisory；无反向依赖）。
import type { AdvisoryUsage } from "./in-process-advisory.ts";

export interface JournalDispatchEntry {
	type: "dispatch";
	taskId: string;
	agent: string;
	name?: string;
	/** 任务书摘要（截断防 journal 爆炸）。 */
	goal: string;
	cwd: string;
	mode: string;
	model?: string;
	runId?: string;
	nodeId?: string;
	at: number;
	pid: number;
}

export interface JournalSettleEntry {
	type: "settle";
	taskId: string;
	status: string;
	at: number;
}

/** ev-20260903-a5b662：子进程会话见证行——首帧 session 事件即落盘，级联终止后 resume 有磁盘真相。 */
export interface JournalSessionEntry {
	type: "session";
	taskId: string;
	sessionId: string;
	at: number;
}

/** A2（ev-20260910-d86779）：瞬时故障自动重派见证行——退避定时器安排时落盘（原 taskId、第 n 次、
 *  退避 ms、下次 model）；与 dispatch 行（重派 fresh spawn 各自再记）拼成完整审计链。 */
export interface JournalRetryEntry {
	type: "retry";
	taskId: string;
	n: number;
	backoffMs: number;
	nextModel?: string;
	at: number;
}

/** ev-20260920-6e687c：恢复通知已发出见证行——journalRecoveryText(markNotified) 构造通知时落盘。
 *  根因：残留通知判定只有「同项目+Leader 死+无 settle」三条件，无「已通知」记忆面——旧会话遗留
 *  未收口残留（blocked 后关会话/对账已完结但缺 settle 行/终端被杀）在每个新会话启动时重复全量弹出，
 *  直到 7 天 sweep 或手动 abandon，与新任务毫无关系地持续干扰。notified 行使「每残留最多主动打扰一次」；
 *  board 拉取面（includeNotified）保留全部可见性。append-only 留痕，sweep 按 at 同寿命。 */
export interface JournalNotifiedEntry {
	type: "notified";
	taskId: string;
	at: number;
}

/** C15（设计 §6.5）：进程内 advisory 调用事实行——按设计字段集 {kind, parentTaskId, invocationId,
 *  modelRef, inputDigest, promptVersion, startedAt, endedAt, stopReason, usageStatus} 落盘。
 *  纪律：kind 恒 "in-process-advisory"，与 dispatch 行（真实子进程派发）类型面隔离——不伪造
 *  taskId 派发/WAL；journalInflight/恢复差集只认 dispatch/settle/notified，advisory 行零影响。
 *  detail 只携带真实机器错误关键词（无错误不携带，不编造失败）；usage 为单列费用事实
 *  （非工具执行场景宿主不自动记账）。sweep 按 at 同寿命（7 天窗口）。 */
export interface JournalAdvisoryEntry {
	type: "advisory";
	kind: "in-process-advisory";
	parentTaskId: string;
	invocationId: string;
	modelRef: string;
	inputDigest: string;
	promptVersion: string;
	startedAt: number;
	endedAt: number;
	stopReason: string;
	usageStatus: "reported" | "unknown";
	usage?: AdvisoryUsage;
	/** 失败说明（真实机器错误关键词；成功/无错误不携带）。 */
	detail?: string;
	at: number;
}

/** B5B（ev-20261012-7517d8 批B §9）：codemode 持久账户审计引用行——派发/续接受控 codemode grant 的
 *  任务时落盘（有界：taskId + grantDigest 前 16 hex + 阶段；零脚本正文/零账户文件内容——完整账目
 *  以 <amagiDataDir>/codemode-ledger/ 为准，本行只提供任务↔账户族的检索锚）。 */
export interface JournalCodemodeAccountEntry {
	type: "codemode-account";
	taskId: string;
	/** 冻结 grant 摘要前 16 hex（检索锚，非完整 digest——账本/回执引用有界）。 */
	grantDigestPrefix: string;
	phase: "dispatch" | "resume";
	at: number;
}

export type JournalEntry = JournalDispatchEntry | JournalSettleEntry | JournalSessionEntry | JournalRetryEntry | JournalNotifiedEntry | JournalAdvisoryEntry | JournalCodemodeAccountEntry;

/** 单条 dispatch 行 goal 落盘上限（字符）——接力包回读时据此如实标注「可能截断」（ev-20260910-352a91）。
 *  ev-20260914-ce6bd2：500 → 4000——500 字留档在 worktree 标注/长任务书场景下回读价值耗尽
 *  （恢复链路只剩头部 500 字，resume 接力被迫凭记忆重写任务书）；4000 字覆盖常规任务书全文，
 *  仍保持有界（单行 JSONL ≤ ~12KB UTF-8，7 天 sweep 兑底）。 */
export const JOURNAL_GOAL_CAP = 4000;
/** 旧版留档上限（ev-20260914-ce6bd2 前为 500）：回读侧判定旧档「恰达上限=可能截断」用。 */
export const LEGACY_JOURNAL_GOAL_CAP = 500;
export const DEFAULT_JOURNAL_MAX_AGE_MS = 7 * 24 * 3600 * 1000;

function journalPath(): string {
	return journalPathOverride ?? amagiDataFile("journal", "dispatch.jsonl");
}

/** 测试注入路径覆盖（隔离真实 ~/.pi 数据）。 */
export function _setJournalPathForTest(p: string | null): void {
	journalPathOverride = p === null ? undefined : p;
}
let journalPathOverride: string | undefined;

function appendLine(entry: JournalEntry): boolean {
	try {
		// 回归守卫（2026-08-19 实战）：未隔离的 node:test 进程绝不动生产 journal——
		// model-resolver 测试未引 isolate-env，7 次全量套件把 mock 派发写进真实 journal，
		// 下次启动 journalRecoveryText 误报 7 个假中断任务。已隔离测试（isolate-env 注入
		// AMAGI_TEST_ISOLATED=1）写隔离 HOME 路径，不受本守卫影响。
		if (process.env.NODE_TEST_CONTEXT && process.env.AMAGI_TEST_ISOLATED !== "1") return false;
		const p = journalPath();
		fs.mkdirSync(path.dirname(p), { recursive: true });
		fs.appendFileSync(p, JSON.stringify(entry) + "\n", "utf8");
		return true;
	} catch {
		/* 静默：journal 失败不影响主流程 */
		return false;
	}
}

/** 记录一次派发（spawn 前）。goal 自动截断。 */
export function journalDispatch(e: Omit<JournalDispatchEntry, "type" | "at" | "pid" | "goal"> & { goal: string }): void {
	appendLine({
		type: "dispatch",
		taskId: String(e.taskId),
		agent: String(e.agent),
		name: e.name ? String(e.name).slice(0, 64) : undefined,
		goal: String(e.goal).slice(0, JOURNAL_GOAL_CAP),
		cwd: String(e.cwd),
		mode: String(e.mode),
		model: e.model ? String(e.model) : undefined,
		runId: e.runId ? String(e.runId) : undefined,
		nodeId: e.nodeId ? String(e.nodeId) : undefined,
		at: Date.now(),
		pid: process.pid,
	});
}

/** 记录一次结算（registry 到达终态）。 */
export function journalSettle(taskId: string, status: string): void {
	appendLine({ type: "settle", taskId: String(taskId), status: String(status), at: Date.now() });
}

/** 记录子进程会话见证（ev-20260903-a5b662）：stdout 首个 session 事件即落盘 sessionId。
 *  每个 runPiTask 调用记一次（task-run 闭包 sessionJournaled 置位防同轮重复）；自动续跑/resume
 *  轮是新的 runPiTask 调用各自再记——lookupByPrefix 取最新 session 行，天然覆盖续跑/fork 场景。 */
export function journalSession(e: Omit<JournalSessionEntry, "type" | "at">): void {
	appendLine({ type: "session", taskId: String(e.taskId), sessionId: String(e.sessionId), at: Date.now() });
}

/** A2（ev-20260910-d86779）：记录一次自动重派安排（退避定时器设定时）。 */
export function journalRetry(e: Omit<JournalRetryEntry, "type" | "at">): void {
	appendLine({ type: "retry", taskId: String(e.taskId), n: Number(e.n), backoffMs: Number(e.backoffMs), nextModel: e.nextModel ? String(e.nextModel) : undefined, at: Date.now() });
}

/** ev-20260920-6e687c：记录恢复通知已发出（每 taskId 一条；重复 append 无害，读取侧取 max(at)）。 */
export function journalMarkNotified(taskIds: readonly string[]): void {
	for (const taskId of taskIds) appendLine({ type: "notified", taskId: String(taskId), at: Date.now() });
}

/** C15（设计 §6.5）：记录一次进程内 advisory 调用事实（成功与失败恒记录；不伪造 dispatch）。
 *  返回是否真实落盘（appendLine 语义：静默失败/测试守卫拒绝=false——调用方如实标注 journalRecorded）。 */
export function journalAdvisory(e: Omit<JournalAdvisoryEntry, "type" | "kind" | "at">): boolean {
	return appendLine({
		type: "advisory",
		kind: "in-process-advisory",
		parentTaskId: String(e.parentTaskId),
		invocationId: String(e.invocationId),
		modelRef: String(e.modelRef),
		inputDigest: String(e.inputDigest),
		promptVersion: String(e.promptVersion),
		startedAt: Number(e.startedAt),
		endedAt: Number(e.endedAt),
		stopReason: String(e.stopReason),
		usageStatus: e.usageStatus === "reported" ? "reported" : "unknown",
		...(e.usage ? { usage: e.usage } : {}),
		...(e.detail ? { detail: String(e.detail).slice(0, 400) } : {}),
		at: Date.now(),
	});
}

function readEntries(): JournalEntry[] {
	try {
		const raw = fs.readFileSync(journalPath(), "utf8");
		const out: JournalEntry[] = [];
		for (const line of raw.split("\n")) {
			const t = line.trim();
			if (!t) continue;
			try {
				const e = JSON.parse(t);
				if (e && (e.type === "dispatch" || e.type === "settle" || e.type === "session" || e.type === "retry" || e.type === "notified" || e.type === "advisory" || e.type === "codemode-account")) out.push(e);
			} catch { /* 跳过损坏行（半写等） */ }
		}
		return out;
	} catch {
		return [];
	}
}

/** B5B：codemode 持久账户审计引用（dispatch/resume 阶段各至多一条/轮；append-only 不重写历史）。 */
export function journalCodemodeAccount(e: Omit<JournalCodemodeAccountEntry, "type" | "at">): boolean {
	return appendLine({ type: "codemode-account", taskId: String(e.taskId), grantDigestPrefix: String(e.grantDigestPrefix).slice(0, 16), phase: e.phase === "resume" ? "resume" : "dispatch", at: Date.now() });
}

/** v1.5.233：跨进程探活——dispatch 行的 Leader pid 还活着，共在途任务就不属于「中断残留」
 *  （属那个活会话自己的管辖，另一个会话不得接管/重复派发）。kill(pid,0)：ESRCH=不存在，
 *  EPERM=存在但无权限（也算活）。pid 复用窗口内可能误判为活而漏报——漏报代价（journal 仍留痕
 *  可手动查）远小于误报代价（诱导接管活会话任务），可接受。 */
function isLeaderAlive(pid: number): boolean {
	try { process.kill(pid, 0); return true; } catch (e: unknown) { return (e as NodeJS.ErrnoException)?.code === "EPERM"; }
}

/** 同项目判定（v1.5.233 → ev-20260920-journal-leak 重写）：
 *  v1.5.233 原用「互为路径祖先」——实战暴露两个结构性缺陷（主上 2026-09-20 反馈）：
 *  ① 共同祖先过匹配：会话 cwd 处于残留 cwd 的祖先（workpace 根/家目录）或反之时，无关项目的
 *     残留全部涌入新会话启动通知（真实 journal 复现：workpace 根会话同时看到 battle-sim
 *     worktree 与 Database 项目两条无关残留）；路径前缀 ≠ 项目归属。
 *  ② worktree 是母仓的兄弟子树而非后代——从母仓检出子目录开会话看不到自己 worktree 在途（误过滤）。
 *  重写：git 仓库根归一（rev-parse --git-common-dir；worktree 与母仓同源）——同仓互认同项目，
 *  跨仓互不可见；任一侧非 git 目录回退「路径全等」（保守：宁可漏报不可跨项目骚扰）。 */
const _gitRootCache = new Map<string, string | null>();
function gitCommonRoot(dir: string): string | null {
	const cached = _gitRootCache.get(dir);
	if (cached !== undefined) return cached;
	let out: string | null = null;
	try {
		// 不用 --path-format=absolute（需 git≥2.31）——相对输出按 -C 目录 resolve 同样正确。
		// realpath 归一：worktree 的 common-dir 输出是真实路径（符号链接已解，如 /tmp→/private/tmp），
		// 母仓相对输出锚定在传入目录前缀（可能含符号链接）——两端不归一会字符串不等（实测 macOS 复现）。
		const raw = execFileSync("git", ["-C", dir, "rev-parse", "--git-common-dir"],
			{ encoding: "utf8", timeout: 2000, stdio: ["ignore", "pipe", "ignore"] }).trim();
		if (raw) {
			const root = path.dirname(path.resolve(dir, raw)).replace(/\/+$/, "");
			if (root && root !== "/") {
				try { out = fs.realpathSync(root); } catch { out = root; }
			}
		}
	} catch { out = null; }
	_gitRootCache.set(dir, out);
	return out;
}

function isSameProject(a: string, b: string): boolean {
	const ga = gitCommonRoot(a);
	const gb = gitCommonRoot(b);
	if (ga !== null && gb !== null) return ga === gb;
	// 非 git 回退：路径全等（杀掉共同祖先过匹配；非 git 项目的母↔子在途可见性让位——保守方向）
	const x = a.replaceAll("\\", "/").replace(/\/+$/, "");
	const y = b.replaceAll("\\", "/").replace(/\/+$/, "");
	return x === y;
}

/** 测试隔离用：清空 git 仓库根缓存（生产无调用面）。 */
export function _resetGitRootCacheForTest(): void {
	_gitRootCache.clear();
}

/** ev-20260914-4150dd：journalInflight 返回项——dispatch 事实 + 只读对账标注。 */
export interface InflightResidue extends JournalDispatchEntry {
	/** 对账标注：`已收口（registry 终态 …）` / `报告已落盘`；缺省=仍在途，维持现状提示人工判断。 */
	reconcile?: string;
	/** ev-20260920-6e687c：恢复通知已发出时间（includeNotified=true 且存在 notified 行时携带；
	 *  缺省排除已通知项——通知一次性，不重复打扰新会话）。 */
	notifiedAt?: number;
}

/** ev-20260914-4150dd：中断残留对账（轻量启发式，只读交叉核对——不自动清理、不阻断展示）：
 *  ① registry 该 taskId 已终态（含重启后磁盘回填收编的 done/resolved-external 等）→「已收口」；
 *  ② 关联报告产物已存在——amagi artifact 目录 result.md（findArtifact）或任务书内绝对 reportPath
 *     （含 report/agent-outputs 语义的 .md 路径，防「读某篇现存文档」型误报）→「报告已落盘」；
 *  ③ 皆否返回 null（保持现状提示）。实战：blocked→Leader 直修收口并 commit 的任务，journal 无
 *  settle 行而残留误报在途——对账标注让 Leader 一眼识别「其实已完成」。 */
export function reconcileResidueNote(d: JournalDispatchEntry): string | null {
	try {
		const rec = registry.get(d.taskId);
		if (rec && isTerminalStatus(rec.status)) return `已收口（registry 终态 ${rec.status}）`;
	} catch { /* 只读核对失败静默 */ }
	try {
		if (findArtifact(d.cwd, d.taskId)) return "报告已落盘";
		// ev-20260914-4150dd：任务书内绝对 reportPath 启发式——只认含 report/agent-outputs 的 .md
		// 路径（输入型文档引用不误标）；goal 落盘上限 4000 字，取前 5 条候选即够。
		const paths = (d.goal || "").match(/\/[^\s"'`（），。；]+\.md/g) || [];
		for (const p of paths.slice(0, 5)) {
			if (!/report|agent-outputs/i.test(p)) continue;
			if (fs.existsSync(p)) return "报告已落盘";
		}
	} catch { /* 同上 */ }
	return null;
}

/** 在途差集：dispatch 行减去其后任意 settle 行（同 taskId）。maxAgeMs 内的派发才算在途。
 * 缺省排除本进程 pid 的在途（那是 registry 实时可见的，非中断残留）；includeOwnPid 供测试/自检。
 * ev-20260914-4150dd：逐条附对账标注（reconcileResidueNote，只读）供展示层消费。 */
export function journalInflight(maxAgeMs: number = DEFAULT_JOURNAL_MAX_AGE_MS, opts?: { includeOwnPid?: boolean; cwd?: string; includeAlive?: boolean; includeNotified?: boolean }): InflightResidue[] {
	const entries = readEntries();
	const settled = new Set<string>();
	const notifiedAt = new Map<string, number>();
	const dispatches: JournalDispatchEntry[] = [];
	const cutoff = Date.now() - maxAgeMs;
	for (const e of entries) {
		if (e.type === "settle") settled.add(e.taskId);
		else if (e.type === "notified") notifiedAt.set(e.taskId, Math.max(notifiedAt.get(e.taskId) ?? 0, e.at));
		else if (e.type === "dispatch" && e.at >= cutoff) dispatches.push(e);
	}
	// v1.5.233 隔离修复（主上实战：battle-sim 活会话的在途任务涌入 amagi-pi 新会话启动通知）：
	//  ① cwd 过滤——只报当前项目（互为祖先）的在途，跨项目互不可见；
	//  ② 活 Leader 探活（默认开启）——pid 还在跑的会话自己管自己的在途，不算中断残留；
	//    includeOwnPid=true（测试/自省）时全故行，不受探活限制。
	// ev-20260920-6e687c：③ 已通知排除（默认）——恢复通知每残留只主动弹一次，新会话不再被旧残留
	//  重复打扰；includeNotified=true（board 拉取面）保留全部并附 notifiedAt 标注。notified 早于
	//  dispatch（同 taskId 后派发）不生效——新派发重新可通知。
	return dispatches.filter((d) =>
		!settled.has(d.taskId)
		&& (opts?.includeOwnPid || (d.pid !== process.pid && !isLeaderAlive(d.pid)))
		&& (!opts?.cwd || isSameProject(d.cwd, opts.cwd))
	).filter((d) => opts?.includeNotified || (notifiedAt.get(d.taskId) ?? 0) < d.at)
		.map((d) => {
			const reconcile = reconcileResidueNote(d);
			const nAt = notifiedAt.get(d.taskId);
			const notified = opts?.includeNotified && nAt !== undefined && nAt >= d.at;
			return { ...d, ...(reconcile ? { reconcile } : {}), ...(notified ? { notifiedAt: nAt } : {}) };
		});
}

/**
 * 启动清扫：重写 journal 只保留 maxAgeMs 内的行（有界）；失败静默。
 * 返回保留的行数（测试用）。
 */
export function journalSweep(maxAgeMs: number = DEFAULT_JOURNAL_MAX_AGE_MS): number {
	try {
		const entries = readEntries();
		const cutoff = Date.now() - maxAgeMs;
		const kept = entries.filter((e) => e.at >= cutoff);
		const p = journalPath();
		fs.mkdirSync(path.dirname(p), { recursive: true });
		fs.writeFileSync(p, kept.map((e) => JSON.stringify(e)).join("\n") + (kept.length ? "\n" : ""), "utf8");
		return kept.length;
	} catch {
		return -1;
	}
}

/** journalAbandon 单条清理结果（ev-20260825-3bf9b2）。 */
export interface JournalAbandonResult {
	/** 用户输入（前缀或全 Id）。 */
	input: string;
	/** 解析命中的完整 taskId（settled / already-settled / error 时有值）。 */
	taskId?: string;
	action: "settled" | "already-settled" | "not-found" | "ambiguous" | "error";
	/** ambiguous 时的候选全 Id。 */
	candidates?: string[];
	/** error 时的原因。 */
	error?: string;
}

/**
 * 单条废弃清理（ev-20260825-3bf9b2）：给指定 taskId（前缀或全 Id）的在途 dispatch 补一条
 * settle(status="abandoned") 行——append-only 补结算而非删行（历史留痕），恢复通知差集即清。
 * 与 journalSweep 互补：sweep 只按年龄整体重写，清不动 maxAgeMs 内的新鲜残留。
 * 逐条独立判定（歧义/未命中/已结算均跳过并说明），不抛异常；沿用 appendLine 的测试守卫
 * （未隔离 node:test 进程拒绝写，防生产 journal 二次污染）。
 */
export function journalAbandon(taskIds: string[], status = "abandoned"): JournalAbandonResult[] {
	const results: JournalAbandonResult[] = [];
	const entries = readEntries();
	const settled = new Set<string>();
	const dispatchIds = new Set<string>();
	for (const e of entries) {
		if (e.type === "settle") settled.add(e.taskId);
		else if (e.type === "dispatch") dispatchIds.add(e.taskId);
	}
	const testGuarded = Boolean(process.env.NODE_TEST_CONTEXT && process.env.AMAGI_TEST_ISOLATED !== "1");
	for (const input of taskIds) {
		const id = String(input);
		const matches = id ? [...dispatchIds].filter((t) => t.startsWith(id)) : [];
		if (matches.length === 0) results.push({ input, action: "not-found" });
		else if (matches.length > 1) results.push({ input, action: "ambiguous", candidates: matches });
		else {
			const taskId = matches[0];
			if (settled.has(taskId)) results.push({ input, taskId, action: "already-settled" });
			else if (testGuarded) results.push({ input, taskId, action: "error", error: "test-guard：未隔离测试进程拒绝写生产 journal" });
			else {
				try {
					const p = journalPath();
					fs.mkdirSync(path.dirname(p), { recursive: true });
					fs.appendFileSync(p, JSON.stringify({ type: "settle", taskId, status: String(status), at: Date.now() }) + "\n", "utf8");
					results.push({ input, taskId, action: "settled" });
				} catch (err) {
					results.push({ input, taskId, action: "error", error: String(err) });
				}
			}
		}
	}
	return results;
}

/** abandon CLI 自定位路径（jiti 加载下 import.meta.url 指向本 .ts 源文件）。 */
const ABANDON_SCRIPT = (() => {
	try { return fileURLToPath(new URL("../../scripts/journal-abandon.mjs", import.meta.url)); }
	catch { return "scripts/journal-abandon.mjs（amagi-pi 仓库根）"; }
})();

/** journalLookupByPrefix 命中（ev-20260903-a5b662）：最新 dispatch 行 + 关联最新 session 行。 */
export interface JournalLookupHit {
	taskId: string;
	agent: string;
	cwd: string;
	at: number;
	/** 该 taskId 最新一条 session 行的 sessionId（子进程首帧未到/未落盘时缺省）。 */
	sessionId?: string;
}

/** 前缀反查任务（ev-20260903-a5b662）：taskId === prefix || startsWith(prefix) 的 dispatch 行取
 *  at 最新一条（resume 轮次各自有 dispatch 行，恢复应指向最近一次派发），再按该 taskId 关联最新
 *  一条 session 行取 sessionId。只读不写（无测试守卫需求）；复用 journalPath 覆盖通道
 *  （_setJournalPathForTest）。maxAgeMs 缺省同 sweep 窗口；未命中/空前缀返回 null。 */
export function journalLookupByPrefix(prefix: string, maxAgeMs?: number): JournalLookupHit | null {
	const p = String(prefix || "").trim();
	if (!p) return null;
	const cutoff = Date.now() - (maxAgeMs ?? DEFAULT_JOURNAL_MAX_AGE_MS);
	const entries = readEntries();
	let best: JournalDispatchEntry | undefined;
	for (const e of entries) {
		if (e.type !== "dispatch" || e.at < cutoff) continue;
		if ((e.taskId === p || e.taskId.startsWith(p)) && (!best || e.at >= best.at)) best = e;
	}
	if (!best) return null;
	let sessionId: string | undefined;
	let sessionAt = -1;
	for (const e of entries) {
		if (e.type !== "session" || e.taskId !== best.taskId) continue;
		if (typeof e.sessionId === "string" && e.sessionId && e.at >= sessionAt) { sessionId = e.sessionId; sessionAt = e.at; }
	}
	return { taskId: best.taskId, agent: best.agent, cwd: best.cwd, at: best.at, sessionId };
}

/** ev-20260910-352a91：dispatch 链回读命中——resume 超窗拒单接力包回填原任务书/轮次的第二真相源。 */
export interface JournalChainHit {
	/** 链锚 taskId（前缀入参解析出的完整 taskId）。 */
	taskId: string;
	agent: string;
	cwd: string;
	name?: string;
	/** 链内选中的任务书文本（journal 落盘上限 JOURNAL_GOAL_CAP=4000 字；旧档为 500 字）。 */
	goal?: string;
	/** goal 恰达落盘上限（当前 4000 或旧档 500）→ 原文可能更长（调用方须如实标注，不得当全文）。 */
	goalTruncated: boolean;
	/** 选中 goal 的派发行 taskId（溯源用；可能不同于链锚）。 */
	goalTaskId?: string;
	/** 链上 dispatch 行数（含锚行，taskId+at 去重）——派发轮次计。 */
	dispatchCount: number;
	firstAt: number;
	lastAt: number;
}

/**
 * ev-20260910-352a91：按 taskId（精确或前缀）回读 dispatch 链。
 * 实战：P1 任务被宿主级联中断后 resume 被超窗拒单，registry 磁盘回填（task-registry
 * adoptExternal）丢 goal/rounds → 接力包「原任务书未留档」，Leader 只能凭记忆重建任务书。
 * journal dispatch 行在 spawn 前落盘且带任务书文本，是本回读链的现成留档。
 * 链圈定（并集，taskId+at 去重）：
 *   ① 锚 taskId 自身的 dispatch 行；
 *   ② 同 sessionId 见证行关联出的 taskId（resume 以 --session 续接同一会话文件，续派 taskId
 *      各不相同但 session 行共享 sessionId）；
 *   ③ 同非空 name + 同 agent 的续派行（task-resume journalDispatch 继承 prev.name；双方 runId
 *      均存在且不同时排除，防跨 run 同名节点误并）；
 *   ④ 同 runId+nodeId 的编排节点续派行。
 * goal 选取：锚 taskId 最新非空派发行为准（「最近一次派发记录」）；锚行无 goal 时取链内最早
 * 非空 goal（原任务书）。只读不写——无命中/解析异常返回 null，调用方如实降级。
 */
export function journalLookupChain(taskIdOrPrefix: string, opts?: { sessionId?: string; name?: string; runId?: string; nodeId?: string; maxAgeMs?: number }): JournalChainHit | null {
	const q = String(taskIdOrPrefix || "").trim();
	if (!q) return null;
	let entries: JournalEntry[];
	try { entries = readEntries(); } catch { return null; }
	const cutoff = Date.now() - (opts?.maxAgeMs ?? DEFAULT_JOURNAL_MAX_AGE_MS);
	const dispatches = entries.filter((e): e is JournalDispatchEntry => e.type === "dispatch" && e.at >= cutoff);
	// 锚：精确 taskId 优先，未命中再前缀取 at 最新（口径同 journalLookupByPrefix）
	let anchor: JournalDispatchEntry | undefined;
	for (const d of dispatches) if (d.taskId === q && (!anchor || d.at >= anchor.at)) anchor = d;
	if (!anchor) for (const d of dispatches) if (d.taskId.startsWith(q) && (!anchor || d.at >= anchor.at)) anchor = d;
	if (!anchor) return null;
	// 锚会话：调用方（record.sessionId）优先，否则取锚 taskId 最新 session 见证行
	let anchorSession = typeof opts?.sessionId === "string" && opts.sessionId ? opts.sessionId : undefined;
	if (!anchorSession) {
		let sessionAt = -1;
		for (const e of entries) {
			if (e.type !== "session" || e.taskId !== anchor.taskId || !e.sessionId) continue;
			if (e.at >= sessionAt) { anchorSession = e.sessionId; sessionAt = e.at; }
		}
	}
	const sessionTaskIds = new Set<string>();
	if (anchorSession) for (const e of entries) if (e.type === "session" && e.sessionId === anchorSession) sessionTaskIds.add(e.taskId);
	const anchorName = opts?.name || anchor.name;
	const anchorRunId = opts?.runId || anchor.runId;
	const anchorNodeId = opts?.nodeId || anchor.nodeId;
	const chain: JournalDispatchEntry[] = [];
	const seen = new Set<string>();
	for (const d of dispatches) {
		const sameAnchor = d.taskId === anchor.taskId;
		const sameSession = sessionTaskIds.has(d.taskId);
		const sameName = !!anchorName && d.name === anchorName && d.agent === anchor.agent && !(anchorRunId && d.runId && d.runId !== anchorRunId);
		const sameNode = !!anchorRunId && !!anchorNodeId && d.runId === anchorRunId && d.nodeId === anchorNodeId;
		if (!sameAnchor && !sameSession && !sameName && !sameNode) continue;
		const key = `${d.taskId}@${d.at}`;
		if (seen.has(key)) continue;
		seen.add(key);
		chain.push(d);
	}
	chain.sort((a, b) => a.at - b.at); // 文件追加序≈时间序，但手写/迁移行不保证——显式排序
	// goal 选取：锚 taskId 最新非空 → 链内最早非空（原任务书）
	let goalRow: JournalDispatchEntry | undefined;
	for (const d of chain) if (d.taskId === anchor.taskId && d.goal && (!goalRow || d.at >= goalRow.at)) goalRow = d;
	if (!goalRow) goalRow = chain.find((d) => d.goal);
	const goal = goalRow?.goal || undefined;
	return {
		taskId: anchor.taskId,
		agent: anchor.agent,
		cwd: anchor.cwd,
		name: anchor.name,
		goal,
		// ev-20260914-ce6bd2：新档按当前上限（4000）判定；旧档（cap 500 时代落盘）恰达 500 也如实标可能截断
		goalTruncated: goal !== undefined && (goal.length >= JOURNAL_GOAL_CAP || goal.length === LEGACY_JOURNAL_GOAL_CAP),
		goalTaskId: goalRow?.taskId,
		dispatchCount: chain.length,
		firstAt: chain[0].at,
		lastAt: chain[chain.length - 1].at,
	};
}

/** 恢复指引文本（供启动通知/消费方）；无在途返回 null。v1.5.233：opts.cwd 项目隔离 +
 *  默认排除活 Leader（只报真中断残留）。ev-20260920-6e687c：markNotified=true 时构造通知即落
 *  notified 见证行——同一残留不再次主动弹（新会话零重复打扰）；已通知项 board 面 includeNotified 可见。 */
export function journalRecoveryText(maxAgeMs: number = DEFAULT_JOURNAL_MAX_AGE_MS, opts?: { includeOwnPid?: boolean; cwd?: string; includeAlive?: boolean; markNotified?: boolean }): string | null {
	const inflight = journalInflight(maxAgeMs, opts);
	if (inflight.length === 0) return null;
	const lines = inflight.slice(-10).map((d) => {
		const rel = new Date(d.at).toTimeString().slice(0, 8);
		const goal = d.goal.slice(0, 80).replace(/\s+/g, " ");
		// ev-20260914-4150dd：对账标注（只读核对）——已收口/报告已落盘如实标出，免把已完任务误判在途
		const mark = d.reconcile ? ` 【对账:${d.reconcile}】` : "";
		return `  • ${d.taskId.slice(0, 8)} ${d.agent}${d.mode === "background" ? "(bg)" : ""} @${rel} cwd=${d.cwd}${mark}\n    任务: ${goal}${d.name ? ` [${d.name}]` : ""}`;
	});
	const more = inflight.length > 10 ? `\n  …另有 ${inflight.length - 10} 条见 journal 文件` : "";
	const text = `[amagi journal] 检测到 ${inflight.length} 个上次会话中断时的在途任务（registry 内存态已随进程丢失，journal 落盘留痕）：\n${lines.join("\n")}${more}\n恢复指引：a) query_task({ session: "<taskId 前缀>" }) 查会话轨迹（磁盘回退）；b) 子进程可能仍在跑——先 ps 核对，勿重复派发；c) 需要结果时 task({ session: "<前缀>", task: "请给出最终交付报告" }) resume 续接；d) 确认已废弃：node ${ABANDON_SCRIPT} <taskId前缀>... 补 abandoned 结算行即清（append-only 留痕，支持多条）。标注【对账:已收口/报告已落盘】= 该残留实已完结（registry 终态或报告已存在），通常补结算行清残留即可；无标注项仍需人工判断。本通知每条残留只发一次——后续会话不再重复提醒（board 面 query_task({board:true}) 可随时回查全部，含已通知项）。`;
	// ev-20260920-6e687c：通知发出即落 notified 行——后续会话零重复打扰（fail-open：落盘失败下次重发，可接受）。
	if (opts?.markNotified) journalMarkNotified(inflight.map((d) => d.taskId));
	return text;
}
