/**
 * reliability.ts — T2-7 可靠性三件套（§9.4 失败恢复循环）。
 *
 * a) 停滞看门狗阈值（runPiTask 内滚动计时，stdout 静默超阈值提醒）
 * b) provider 错误识别 + 模型降档链（:max→:high→:medium，有界降一档）
 * c) 幂等分派：contract 哈希（agent+task+cwd）窗口去重
 *
 * 纯函数 + 内存窗口，无 pi 运行时依赖（测试友好）。task-tool 接入。
 */

import * as crypto from "node:crypto";
import { normalizeModelSpec, type ModelRegistryLike, type QuotaRecoveryCandidate } from "./model-resolver.ts";

// ════════════════════════════════════════════════════════════════════════════
// T2-7a 停滞看门狗阈值
// ════════════════════════════════════════════════════════════════════════════

/** 子进程 stdout 静默超此阈值（默认 5min，动态读 env 便于测试）→ onStall 提醒（不杀，仅提示主会话）。 */
export function getStallThresholdMs(): number {
	const v = Number(process.env.AMAGI_STALL_MS);
	return Number.isFinite(v) ? v : 5 * 60 * 1000;
}
/** 看门狗检查间隔（取 min(阈值, 30s)，避免长阈值下检查过疏）。 */
export function getStallCheckIntervalMs(): number {
	return Math.min(getStallThresholdMs(), 30_000);
}

/** v1.5.194 启动就绪守卫：子进程 spawn 后零输出（stdout+stderr 无任何字节）超此阈值
 *  （默认 30s，AMAGI_SPAWN_READY_MS 可调，0=关闭）→ 主动杀死并给明确根因。
 *  背景（2026-07-31 实战）：pi 本体启动期网络操作（pi.dev 相关，PI_OFFLINE 可禁用）无超时
 *  挂死全部新 pi 进程——启动挂起发生在扩展加载前，插件内看门狗无法介入，但 spawn 侧
 *  「零输出」是可观测信号：正常子进程数秒内必有首帧，30s 零输出=启动即死。 */
export function getSpawnReadyMs(): number {
	const v = Number(process.env.AMAGI_SPAWN_READY_MS);
	return Number.isFinite(v) ? v : 30_000;
}

// ════════════════════════════════════════════════════════════════════════════
// T2-7b provider 错误识别 + 降档
// ════════════════════════════════════════════════════════════════════════════

/** provider 错误模式（限流/鉴权/超时/过载/context-length/网络层失败等，可识别降档场景）。 */
// fetch failed/ECONNREFUSED/ENOTFOUND 等网络层失败也是 provider 可达性问题（实战：expert tier
// openai-codex 端点 fetch failed 两次，因未入正则未触发自动降档）——ETIMEDOUT 单列（与 timeout 拼写不同）。
// ev-20260917-9746aa：补 "connection error"（pi provider 断连原文形态——2026-09-17 battle-simulator F6
// 实战：连续 Connection error 未命中本 RE，sync 降级链/降档 resume 整体哑火，只能人工换模型救场）。
// pi 1.5.0 #11492：补上下文超限（LiteLLM ContextWindowExceededError / "Context Window exceeded"——
// 上下文超限也是 provider 可降档场景，与 context length/token limit 同语义）。
// E-03（diting Phase E，Minor）：超限证据只认 #11492 的两类签名（类名/短语+超限语义词）——
// 参数名本身（Invalid parameter context_window: expected a positive integer）不构成超限证据。
const CONTEXT_WINDOW_EXCEEDED_RE = /ContextWindowExceeded(?:Error)?|context[\s_-]?window[^\n]{0,60}?(?:exceed\w*|overflow\w*)/i;
const PROVIDER_ERROR_RE = /rate.?limit|429|quota|too many requests|unauthorized|invalid api key|timeout|timed out|context length|token limit|overloaded|503|connection error|connection reset|ECONNRESET|fetch failed|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|socket hang up|network error|getaddrinfo/i;

/** 判定是否为 provider 类错误（可降档重试）。ev-20261017-88cb27：内容/安全策略拦截除外——它是
 *  任务内容触发的确定性拒绝（provider-safety-refusal），进入自动降档/重试链只会同内容复现撞墙
 *  （实战：H Gate 审核被 cybersecurity flag 后原样续接停摆 4h）；恢复路径只有改措辞重派或
 *  显式换模型（见 recoveryActionOf policy-reject 分支），child-network-recovery 同款排除。 */
export function isProviderError(errorMessage?: string, stopReason?: string): boolean {
	if (isContentPolicyRejection(errorMessage)) return false;
	const combined = `${errorMessage || ""} ${stopReason || ""}`;
	return isAccountQuotaError(errorMessage) || isStreamDisconnectError(errorMessage) || PROVIDER_ERROR_RE.test(combined) || CONTEXT_WINDOW_EXCEEDED_RE.test(combined);
}

/**
 * 模型降档（tier 链 :max→:high→:medium）。
 * @returns 降档后 model spec；已最低档或无 tier → undefined（不可降）。
 */
export function downgradeModel(model?: string): string | undefined {
	if (!model) return undefined;
	if (model.endsWith(":max")) return model.slice(0, -":max".length) + ":high";
	if (model.endsWith(":high")) return model.slice(0, -":high".length) + ":medium";
	return undefined; // :medium 或无 tier，不可降
}

// ── ev-20260905-fdbb89：账号级限额识别 + 跨 provider 降档候选链 ──
// 实战（降档事故）：kimi-k3:high 429 后自动降档到同 provider 的 kimi-k3:medium，但 opencode.ai
// workspace 限额是账号级共享——同 provider 必然再 429（实证失败）。账号级限额必须跨 provider
// 全量降档；候选链来自 env AMAGI_FALLBACK_MODELS / amagi.json fallbackModels（loadFallbackModels）。

/** 账号级/workspace 级限额词族（opencode.ai GoUsageLimitError、usage limit、组织/团队配额等）。 */
const ACCOUNT_QUOTA_RE = /usage.?limit|workspace.*(limit|quota)|account.*(limit|quota)|GoUsageLimitError|组织.*配额|团队.*(限额|配额)|(?:\d+\s*小时|每(?:日|月|周)|账户|账号).*(?:使用上限|用量上限|配额|额度用尽)|已达到.*使用上限/i;
/** 429/限流信号（账号级限额需与词族同时命中；纯瞬时 429 不算）。 */
const RATE_LIMIT_SIGNAL_RE = /429|rate.?limit|too many requests/i;

/** diting 审核 Minor-1：429/限流信号判定（与 planChainExhaustedCooldown 同款口径）——
 *  task 降档循环 tier 步失败用它决定是否进链尽冷却（普通 provider 错误 503/timeout 等不走冷却，
 *  维持既有 A3 重派建议终态）。 */
export function isRateLimitSignal(errorMessage?: string): boolean {
	return !!errorMessage && RATE_LIMIT_SIGNAL_RE.test(errorMessage);
}

/** 硬额度耗尽签名（ev-20261017-88cb27）——无需 429/限流信号共现即成立：『The usage limit has
 *  been reached』『exceeded your current quota』『quota exhausted / 额度已耗尽』等 provider 侧硬
 *  额度文案。实战：OpenAI usage limit 原文既无 429 也无 rate limit 词，旧「限流信号+词族」双门槛
 *  漏配 → 分类 other、恢复指引误报「确定性失败先修因」；本类是 provider 侧非任务原因，恢复路径
 *  是等待额度恢复或换 provider，不是修任务。 */
const HARD_QUOTA_RE = /usage.?limit\s+(?:has\s+been\s+|was\s+|is\s+|would\s+be\s+|apparently\s+)?(?:reached|exceeded|hit)|(?:reached|hit|exceeded)\s+(?:your\s+|the\s+)?usage.?limit|exceeded\s+(?:your\s+|the\s+)?(?:current\s+)?quota|(?:quota|配额|额度)\s*(?:has\s+been\s+|was\s+|已(?:经)?(?:被)?)?\s*(?:exhausted|耗尽|用尽)/i;

/** provider 侧确定性限额码（直接按 quota 分类，无需词族共现）。pi 1.4/1.5 基线适配（Phase A）：
 *  ①Zhipu/Z.ai（open.bigmodel.cn）code 1308——套餐用量上限，以 HTTP 429 伪装但按小时重置（pi
 *  1.5.0 #11537 已改不重试）；pi-ai 权威形态为 code 键携带 1308——旧双门槛（1308 信号+词族共现）
 *  在智谱英文/无词族文案下漏配成 other，直接命中对齐。
 *  ②Sign in with ChatGPT 限额码 subscription_sharing_usage_limit_exceeded（订阅共享额度，小时级重置）
 *  与 subscription_sharing_workplace_individual_usage_limit_exceeded（ChatGPT Business 工作区管理员
 *  设额，pi 1.4.0 起不重试）——码自带 usage_limit 词根但常无 429 共现，直接命中。
 *  防误配边界：1308 仍要求 code 键前缀（"1308 assertions failed" 等纯数字文本不命中）；
 *  E-fix（diting Phase E Info）：1308 收完整码边界——`1308.1`、`13080` 等相邻码不做前缀吞入。 */
const PROVIDER_QUOTA_CODE_RE = /(?:["']?code["']?\s*[:=]\s*["']?1308|错误码\s*[:：]?\s*1308)(?![\d.])|subscription_sharing_(?:workplace_individual_)?usage_limit_exceeded/i;

/**
 * 账号级限额错误判定（纯函数）：硬额度签名**直接命中**，或 429/限流信号 + workspace/账号级
 * 配额词族**同时命中**才算——账号级限额共享，同 provider 降档/重试必然复现，应走跨 provider
 * 降档；纯瞬时 429（"429 rate limit exceeded"，无限额词族）不算，维持同模型 tier 降档语义。
 */
export function isAccountQuotaError(errorMessage?: string): boolean {
	if (!errorMessage) return false;
	if (HARD_QUOTA_RE.test(errorMessage)) return true;
	if (PROVIDER_QUOTA_CODE_RE.test(errorMessage)) return true;
	return (RATE_LIMIT_SIGNAL_RE.test(errorMessage) || /(?:["\']?code["\']?\s*[:=]\s*["\']?1308|错误码\s*[:：]?\s*1308)(?![\d.])/i.test(errorMessage)) && ACCOUNT_QUOTA_RE.test(errorMessage);
}

/** spec 的 provider 段（无 / → 空串；本地实现避免向 task-run 引入新依赖边）。 */
function providerOfSpecLocal(spec: string): string {
	const i = spec.indexOf("/");
	return i > 0 ? spec.slice(0, i) : "";
}

/**
 * 跨 provider 降档候选解析（纯函数）：候选链中取首个与失败 spec **不同 provider**、未被排除、且 registry
 * 可用（normalizeModelSpec 通过；registry 缺省直通）的全量 spec。同 provider 候选跳过（账号级
 * 限额共享，必然复现）；excludeProviders 命中跳过（ev-20260917-9746aa：熔断 Open 的 provider——
 * 推荐位只给可用通道）；无可行候选 → undefined（调用方回退 tier 降档链）。
 */
export function crossProviderDowngrade(failedSpec: string | undefined, candidates: readonly string[] | undefined, registry?: ModelRegistryLike, excludeProviders?: ReadonlySet<string>): string | undefined {
	if (!failedSpec || !candidates || candidates.length === 0) return undefined;
	const failedNorm = normalizeModelSpec(failedSpec, registry);
	const failedProvider = providerOfSpecLocal(failedNorm.ok ? failedNorm.spec || failedSpec : failedSpec);
	for (const raw of candidates) {
		const spec = raw.trim();
		if (!spec || spec === failedSpec) continue;
		const nm = normalizeModelSpec(spec, registry);
		if (!nm.ok || !nm.spec) continue;
		// Bare aliases can resolve into the failed provider: compare only the normalized full spec.
		const candProvider = providerOfSpecLocal(nm.spec);
		if (!failedProvider || !candProvider || candProvider === failedProvider) continue;
		if (excludeProviders?.has(candProvider)) continue;
		return nm.spec;
	}
	return undefined;
}

/** 降档决策结果：降档后 spec + 是否跨 provider（供 tag 文案区分）。 */
export interface DowngradeDecision {
	spec: string;
	crossProvider: boolean;
}

/**
 * 降档决策（纯函数，ev-20260905-fdbb89）：账号级限额错误 → 优先跨 provider 候选链
 * （候选不可用回退 tier 链）；普通 provider 错误 → 维持既有同模型 tier 降一档
 * （downgradeModel 原语义，公共签名不变）。均不可降 → undefined。
 */
export function resolveDowngrade(failedModel: string | undefined, errorMessage: string | undefined, opts: { candidates?: readonly string[]; registry?: ModelRegistryLike; excludeProviders?: ReadonlySet<string> }): DowngradeDecision | undefined {
	if (isAccountQuotaError(errorMessage)) {
		const cp = crossProviderDowngrade(failedModel, opts.candidates, opts.registry, opts.excludeProviders);
		return cp ? { spec: cp, crossProvider: true } : undefined;
	}
	if (opts.excludeProviders?.has(providerOfSpecLocal(failedModel || ""))) return undefined;
	const tier = downgradeModel(failedModel);
	return tier ? { spec: tier, crossProvider: false } : undefined;
}

// ════════════════════════════════════════════════════════════════════════════
// T2-7c 幂等分派（contract 哈希窗口去重）
// ════════════════════════════════════════════════════════════════════════════

/** 幂等窗口（默认 5min，动态读 env 便于测试）：同 contract 在窗口内重复 sync 分派命中去重。 */
export function getIdempotencyWindowMs(): number {
	const v = Number(process.env.AMAGI_IDEMPOTENCY_MS);
	return Number.isFinite(v) ? v : 5 * 60 * 1000;
}

export interface DispatchRecord {
	taskId: string;
	agent: string;
	status: string;
	at: number;
	output?: string;
}

/** 进程内窗口（跨子进程不共享；同主会话有效）。测试用 resetIdempotencyWindow 清空。 */
const dispatchWindow = new Map<string, DispatchRecord>();

export function resetIdempotencyWindow(): void {
	dispatchWindow.clear();
}

/** contract 哈希：agent + task 文本 + cwd（同三要素 = 同 contract）。 */
export function contractHash(agent: string, task: string, cwd: string, model?: string): string {
	return crypto.createHash("sha256").update(`${agent}\0${task}\0${cwd}\0${model || ""}`).digest("hex").slice(0, 16);
}

/**
 * 查窗口内是否已有同 contract 分派。
 * @returns 命中（窗口内 + 非空）→ DispatchRecord（调用方返引用不起新进程）；未命中 → null。
 */
export function findDuplicate(hash: string): DispatchRecord | null {
	const rec = dispatchWindow.get(hash);
	if (!rec) return null;
	if (Date.now() - rec.at >= getIdempotencyWindowMs()) {
		dispatchWindow.delete(hash);
		return null;
	}
	return rec;
}

/** 记录分派开始（sync 分派前调）。 */
export function recordDispatch(hash: string, taskId: string, agent: string): void {
	dispatchWindow.set(hash, { taskId, agent, status: "running", at: Date.now() });
}

/** 记录分派终态（完成后调，供后续命中引用结果）。hash 唯一标识，更新占位 taskId → 真实。 */
export function recordDispatchResult(hash: string, taskId: string, status: string, output?: string): void {
	const rec = dispatchWindow.get(hash);
	if (rec) {
		rec.taskId = taskId; // 占位 "pending" → 真实 taskId
		rec.status = status;
		rec.output = output ? output.slice(0, 500) : undefined;
	}
}

// ════════════════════════════════════════════════════════════════════════════
// T2-7d provider 熔断器（v1.5.186，grok xai-circuit-breaker 移植）
// 实战：glm-5.2 超时风暴时每个新任务仍盲派，各自烧 agent 级退避×3（~2min/任务）——
// 跨任务故障记忆 + 熔断窗内 fail-fast + HalfOpen 单探针自动恢复。纯内存（进程级）。
// ════════════════════════════════════════════════════════════════════════════

/** 瞬时故障模式（熔断只统计这类；鉴权/配额等确定性错误不烧熔断窗——它们应直接报错给人看）。
 *  pi 1.3.0 新增两案网关瞬时文案（宿主自身自动重试已认，amagi 分类对齐）：
 *  "The service is temporarily unavailable"（#10965）/"Unable to forward upstream stream"（#10920，
 *  OpenAI Responses response.failed 无错误码形态）。仅入 TRANSIENT（熔断计数/退避/resume 建议/既定隐式重试
 *  预算），不入 CHANNEL_DISCONNECT（自动降链触发面不扩）；policy/quota 排除优先级在调用方先行不变。
 *  pi 1.4/1.5 基线适配（Phase A）：①"stream disconnected before completion"（#11057，Codex CLI
 *  代理包装的中流断连原文）②node-fetch 系统错误形态 "request to <url> failed, reason:"（#10996——
 *  Google Vertex ADC OAuth token refresh 失败常为空 reason，不含 ENOTFOUND 等既有词根）——同仅入
 *  TRANSIENT，不入 CHANNEL_DISCONNECT（换 provider 自动降链触发面不扩）。
 *  pi 1.5.1 基线适配（P1a）：③"cut short after the reply had begun"（#11879，Magpie 网关中转上游
 *  Anthropic 流中断原文，如 "Claude Code's stream from Anthropic was cut short after the reply had
 *  begun"——pi-ai 1.5.1 retry 已认入可重试集；宿主耗尽重试后落到子进程终态错误时 amagi 须同认瞬时，
 *  否则不触发自动恢复/隐式重派）——同前例仅入 TRANSIENT，不入 CHANNEL_DISCONNECT（降链触发面
 *  不扩）；policy/quota/TLS 确定性排除优先级不变。
 *  E-01（diting Phase E，Major）：②的前缀不再无条件接纳任意非空 reason——证书/TLS 类配置错误
 *  （certificate has expired / self-signed certificate / CERT_* / 主机名不匹配）重试必复现，误入
 *  瞬时会烧无效隐式重试并错误熔断。收窄为：reason 行内为空（NODE_FETCH_EMPTY_REASON_RE，#10996
 *  真实兼容样本）或 reason 本身含既有瞬时词根（TRANSIENT_PROVIDER_RE 对全文匹配兜住）；TLS 签名
 *  确定性排除在瞬时/隐式重试/熔断之外（与 policy/quota 排除同款单源），修因走 deterministicFixOf
 *  TLS 分支。 */
const TRANSIENT_PROVIDER_RE = /timed?\s*out|timeout|ETIMEDOUT|connection error|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|fetch failed|socket hang up|network error|getaddrinfo|429|too many requests|rate.?limit|overloaded|500 internal|502 bad|503|504|service is temporarily unavailable|unable to forward upstream|stream disconnected before completion|cut short after the reply had begun/i;

/** node-fetch 系统错误空 reason 形态（E-01）：reason: 后至行尾仅空白（含尾随换行的堆栈续行）
 *  才算空——非空 reason 交给既有词根判定，不再凭前缀无条件瞬时。 */
const NODE_FETCH_EMPTY_REASON_RE = /request to \S+ failed, reason:[ \t]*(?:\r?\n|$)/i;

/** TLS/证书校验类确定性失败签名（E-01）：证书过期/未生效/吊销、自签/信任链不全、主机名不匹配
 *  （Node/OpenSSL 双形态，含 CERT_* 验证码）——修证书/信任链/系统时间才恢复，重试必复现。 */
const TLS_CERT_FAILURE_PHRASE_RE = /certificate (?:has expired|is not yet valid|has been revoked)|self[- ]signed certificate|unable to verify (?:the )?(?:first|leaf) certificate|(?:hostname|ip address|alternate name|altnames?)[^\n]{0,60}(?:mismatch|doesn'?t match|does not match|doesn'?t certify)/i;
/** OpenSSL/Node 验证码按原样大写匹配（不加 /i）且要求词边界——URL 中 cert_id/cert_status 等普通标识不得冒充证书失败（E2-01）。 */
const TLS_CERT_FAILURE_CODE_RE = /(?<![A-Za-z0-9_])(?:UNABLE_TO_VERIFY_LEAF_SIGNATURE|DEPTH_ZERO_SELF_SIGNED_CERT|SELF_SIGNED_CERT_IN_CHAIN|ERR_TLS_CERT_ALTNAME_INVALID|CERT_[A-Z][A-Z_]*)(?![A-Za-z0-9_])/;
/** 判定前剥离 URL（端点路径/查询参数可能含任意 cert 字样），只对错误叙述本身判定。 */
function isTlsCertFailure(message: string): boolean {
	const text = message.replace(/\b[a-z][a-z0-9+.-]*:\/\/\S+/gi, "<url>");
	return TLS_CERT_FAILURE_PHRASE_RE.test(text) || TLS_CERT_FAILURE_CODE_RE.test(text);
}

/** 模型流断连的原始签名。裸 terminated 是 HTTP 流错误；带进程/取消原因的文本（前缀形态，如
 *  process terminated by SIGTERM）不据此猜测。pi 1.5.1 #11695：pi-ai withCauseDetail 把
 *  TypeError('terminated')+cause 链拼为单行 `terminated: <deepest cause>[(code)]`（实测形态
 *  `terminated: other side closed (UND_ERR_SOCKET)`，见 agent-outputs/workflow/pi-1.5.1-adapt/
 *  p2-terminated-cause-evidence.log）。
 *  P3-02（diting P3 审核）收窄：宿主 withCauseDetail 不校验 cause 内容（只拼最深 cause 文本），
 *  `.+` 后缀会把取消/鉴权/参数配置等确定性原因无条件认成断流（实测 `terminated: operation
 *  canceled by user`/`terminated: invalid configuration` 曾四谓词全 true 并进隐式重试/重派计划/熔断）。
 *  修正：裸 terminated（无后缀）保持既有兼容；冒号后缀仅认可可复核的网络断流窄集
 *  （TERMINATED_NETWORK_CAUSE_RE：真实 undici 断流 cause 文案/验证码）；窄集外后缀由
 *  isRejectedTerminatedCause 在瞬时/通道层整体否决（不经任何词根兜底——取消混合文案可携带
 *  timeout 等词根）。确定性排除仍在调用方先行：transient 层 E-01 TLS/quota/policy、channel 层
 *  policy。 */
const TERMINATED_NETWORK_CAUSE_RE = /^(?:(?:other side closed|socket hang up|read ECONNRESET|connection reset|connect ECONNREFUSED|connect ETIMEDOUT|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|fetch failed|network error|getaddrinfo)|UND_ERR_(?:SOCKET|CONNECT_TIMEOUT|HEADERS_TIMEOUT|BODY_TIMEOUT))(?:\s+\(UND_ERR_(?:SOCKET|CONNECT_TIMEOUT|HEADERS_TIMEOUT|BODY_TIMEOUT)\))?$/i;

/** terminated:cause 后缀形态的确定性否决（P3-02）：后缀不在可复核网络窄集 → 整体不得经任何词根
 *  兜底进瞬时/通道（取消/鉴权/参数配置等原因，含携带 timeout 词根的混合文案）。裸 terminated
 *  （无后缀）不否决——保持 HTTP 流错误原始形态的既有兼容。 */
export function isRejectedTerminatedCause(errorMessage?: string): boolean {
	if (!errorMessage) return false;
	const m = /^terminated:[\s\S]*$/i.exec(errorMessage.trim());
	if (!m) return false;
	const cause = errorMessage.trim().replace(/^terminated:\s?/i, "");
	return !TERMINATED_NETWORK_CAUSE_RE.test(cause.trim());
}

export function isStreamDisconnectError(errorMessage?: string): boolean {
	if (!errorMessage) return false;
	const text = errorMessage.trim();
	// 裸 terminated（无后缀）＝HTTP 流错误原始形态，既有兼容（含前后空白/换行 trim 语义）
	if (/^terminated$/i.test(text)) return true;
	// 冒号后缀（pi 1.5.1 withCauseDetail 形态）仅认可复核网络窄集（P3-02）；窄集外含取消/
	// 鉴权/配置等原因——不据此猜测（由 isRejectedTerminatedCause 在瞬时/通道层整体否决）
	if (/^terminated:/i.test(text)) {
		const cause = text.replace(/^terminated:\s?/i, "");
		return TERMINATED_NETWORK_CAUSE_RE.test(cause.trim());
	}
	return /\bwebsocket (?:error|connection (?:closed|failed)|closed unexpectedly)\b/i.test(text);
}

export function isTransientProviderError(errorMessage?: string): boolean {
	// ev-20261021-fix（diting F9）：内容策略拦截是任务内容触发的确定性拒绝——混合签名（403/timeout
	// 字样与策略文案共现）不得因词根命中进入瞬时类（与 isProviderError 同口径排除；共享谓词单源，
	// 隐式重试/自动重派/A3 建议/降档链全部消费本判定，不再各自漏排）。
	// E-01（diting Phase E）：TLS/证书类同理确定性排除——同一谓词单源覆盖隐式重试/熔断/恢复建议。
	// P3-02：terminated 后缀窄集外否决同源接入——取消/配置类后缀（含携带 timeout 词根的混合文案）
	// 不得经 TRANSIENT_PROVIDER_RE 兜底进瞬时（单改 stream 锚不够，词根对全文匹配）。
	return !!errorMessage && !isContentPolicyRejection(errorMessage) && !isAccountQuotaError(errorMessage) && !isTlsCertFailure(errorMessage) && !isRejectedTerminatedCause(errorMessage)
		&& (isStreamDisconnectError(errorMessage) || NODE_FETCH_EMPTY_REASON_RE.test(errorMessage) || TRANSIENT_PROVIDER_RE.test(errorMessage));
}

// ── ev-20260917-9746aa（P1）：通道级断连分类——断连/超时类网络层故障子集（不含 429/5xx 过载限流）。
// 实战：provider 连续 Connection error 时，即使 Leader 声明了 model 数组降级链也未自动落下一节点
//（background autoRetry 为 opt-in，未声明即不重派；同模型退避对通道级故障无意义——换 provider 才有效）。
// 声明链本身就是降级意图声明：断连类错误 × 声明链剩余节点 → 自动落链（task-tool 隐式重派预算=链长）。
const CHANNEL_DISCONNECT_RE = /connection error|connection reset|ECONNRESET|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|ETIMEDOUT|timed?\s*out|timeout|fetch failed|socket hang up|network error|getaddrinfo/i;

/** 通道级断连判定（纯函数）：Connection error/timeout 类网络层故障（TRANSIENT 子集，排除 429/限流/过载）。
 *  ev-20261021-fix（diting F9）：同源排除内容策略拦截——策略文案含 timeout 词根时不得触发
 *  「通道级断连→自动降链」（task-tool 隐式链式预算消费本判定）。
 *  P3-02：terminated 后缀窄集外否决同源接入（取消/配置类后缀含 timeout 词根时不得凭词根降链）。 */
export function isChannelDisconnectError(errorMessage?: string): boolean {
	return !!errorMessage && !isContentPolicyRejection(errorMessage) && !isRejectedTerminatedCause(errorMessage)
		&& (isStreamDisconnectError(errorMessage) || CHANNEL_DISCONNECT_RE.test(errorMessage));
}

// ── ev-20261012-21074e①：provider 内容策略拦截文案识别（trace.classifyErrorKind 与恢复建议共用单源）──
// 实战：diting 审核任务 29b30b41 被 openai-codex 网络安全策略拦截（『flagged for possible
// cybersecurity risk』），旧分类归 other、恢复建议泛化到确定性兜底。本正则只认明确的内容策略
// 拒绝签名（策略拦截是任务内容触发的确定性拒绝，非配额/瞬时/模型容量故障）；签名必须先于
// quota/model 兜底匹配——策略文案可含 forbidden/unauthorized 词根（403 表述），误入 model 会丢修因。
// ev-20261017-88cb27：补 daybreak access 签名（OpenAI 安全拦截专属计划名——截断/改述后不含
// 『flagged … risk』骨架时仍可识别；Daybreak 只出现于该拦截文案，无误报面）。
const CONTENT_POLICY_RE = /flagged for possible [\w\s-]{0,40}risk|content[- ](?:polic|filter|moderat)|usage[- ]polic|safety[- ](?:system|polic)|(?:policy|guidelines?) violation|inappropriate content|violat(?:e|es|ing) (?:the |our )?(?:content |usage |acceptable-use )?polic|daybreak\s+access/i;

/** provider 内容策略拦截判定（纯函数）：『flagged for possible … risk』『content policy』『usage
 *  policy』『safety system』『policy violation』『Daybreak access』等拒绝文案 → true。配额
 * （rate limit/1308/usage limit reached）与上下文超限文案不含这些复合签名，不误分。 */
export function isContentPolicyRejection(errorMessage?: string): boolean {
	return !!errorMessage && CONTENT_POLICY_RE.test(errorMessage);
}

// ── ev-20261017-88cb27：provider 侧非任务原因失败类（分类单源）──
// 两个可区分的失败类进入既有分类链：provider-safety-refusal（内容/安全拦截，含 cybersecurity
// flag / Daybreak 形态 → policy 类）与 provider-quota-exhausted（usage limit / quota / 硬额度
// 耗尽 → quota 类）。trace.classifyErrorKind 用同一谓词；registry lastErrorKind 快照（task-run
// finalize 唯一写点）经 lastErrorKindOfMessage 取同一口径，不再拼第二份判断。

/** registry lastErrorKind 合法值（与 task-registry VALID_ERROR_KIND 同步；policy=v2.21.6 新增——
 *  provider 安全拦截可区分标签，resume 中断包/快照往返可见）。 */
export type LastErrorKind = "policy" | "transient" | "quota" | "other";

/** error 终态根因 → lastErrorKind 快照（纯函数，单源）：policy（安全拦截，优先于额度/瞬时——
 *  策略文案可含 403/timeout 词根）→ quota（硬额度/账号级配额）→ transient（瞬时 provider
 *  故障）→ other。空消息返回 other（与旧内联写点行为一致：error 终态必落一类）。 */
export function lastErrorKindOfMessage(errorMessage?: string): LastErrorKind {
	if (isContentPolicyRejection(errorMessage)) return "policy";
	if (isAccountQuotaError(errorMessage)) return "quota";
	if (isTransientProviderError(errorMessage)) return "transient";
	return "other";
}

export function isProviderBreakerEnabled(): boolean {
	return process.env.AMAGI_CB_ENABLED !== "0";
}
export function getProviderBreakerThreshold(): number {
	const v = Number(process.env.AMAGI_CB_THRESHOLD);
	return Number.isFinite(v) && v > 0 ? v : 3;
}
export function getProviderBreakerOpenMs(): number {
	const v = Number(process.env.AMAGI_CB_OPEN_MS);
	return Number.isFinite(v) && v > 0 ? v : 5 * 60 * 1000;
}

interface ProviderBreakerState {
	/** 连续瞬时故障计数（成功清零）。 */
	consecutiveFailures: number;
	/** Open 起始时间（undefined=Closed）。 */
	openedAt?: number;
	/** HalfOpen 探针在飞（同 provider 同时只放一个探针）。 */
	probeInFlight: boolean;
}

const providerBreakers = new Map<string, ProviderBreakerState>();

/** 测试用：清空全部熔断状态。 */
export function resetProviderBreaker(): void { providerBreakers.clear(); }

export interface ProviderBreakerCheck {
	open: boolean;
	/** true=HalfOpen 探针（放行；成败由 success/failure 记账决定闭合/重开）。 */
	probe: boolean;
	retryAfterMs?: number;
	consecutiveFailures: number;
}

/** 派发前检查：Open 且冷却未过 → 拦（fail-fast）；冷却已过 → 放一个探针（HalfOpen）。 */
export function providerBreakerCheck(provider: string): ProviderBreakerCheck {
	const st = providerBreakers.get(provider);
	if (!st || st.openedAt === undefined) return { open: false, probe: false, consecutiveFailures: st?.consecutiveFailures ?? 0 };
	const retryAfterMs = st.openedAt + getProviderBreakerOpenMs() - Date.now();
	if (retryAfterMs > 0) return { open: true, probe: false, retryAfterMs, consecutiveFailures: st.consecutiveFailures };
	if (st.probeInFlight) return { open: true, probe: false, retryAfterMs: 30_000, consecutiveFailures: st.consecutiveFailures };
	st.probeInFlight = true;
	return { open: true, probe: true, consecutiveFailures: st.consecutiveFailures };
}

/** 任务成功（done/blocked 都算 provider 可用）→ 复位闭合。 */
export function providerBreakerSuccess(provider: string): void {
	const st = providerBreakers.get(provider);
	if (!st) return;
	st.consecutiveFailures = 0;
	st.openedAt = undefined;
	st.probeInFlight = false;
}

/** 任务失败且为瞬时 provider 故障 → 计数；达阈值 → Open（探针失败=重新计时冷却）。非瞬时故障不动熔断。 */
export function providerBreakerFailure(provider: string, errorMessage?: string): void {
	const st = providerBreakers.get(provider);
	if (st) st.probeInFlight = false; // 探针落幕（成败记账必居其一）
	if (!isTransientProviderError(errorMessage)) return;
	const s = st ?? { consecutiveFailures: 0, probeInFlight: false };
	if (!st) providerBreakers.set(provider, s);
	s.consecutiveFailures++;
	if (s.consecutiveFailures >= getProviderBreakerThreshold()) s.openedAt = Date.now();
}

/** 只读观测（A3 ev-20260910-d86779）：读取熔断剩余恢复时间/连续瞬时数，**不触发 HalfOpen 探针占位**
 *  ——providerBreakerCheck 的冷却到期分支会消费探针名额，建议段/重派决策计算绝不能借道它。 */
export function providerBreakerPeek(provider: string): ProviderBreakerCheck {
	const st = providerBreakers.get(provider);
	if (!st || st.openedAt === undefined) return { open: false, probe: false, consecutiveFailures: st?.consecutiveFailures ?? 0 };
	const retryAfterMs = st.openedAt + getProviderBreakerOpenMs() - Date.now();
	return { open: true, probe: st.probeInFlight, retryAfterMs: Math.max(retryAfterMs, 0), consecutiveFailures: st.consecutiveFailures };
}

// ════════════════════════════════════════════════════════════════════════════
// ev-20260910-d86779（A2/A3）：瞬时故障自动恢复链——autoRetry 退避重派决策 + 终态重派建议段。
// 设计原则（evo×4 §A）：轻护栏、强感知、可回滚——自动动作一律 opt-in 声明式（缺省关闭），
// 熔断状态只读观测（peek），journal 留痕由调用方（task-tool）执行。
// ════════════════════════════════════════════════════════════════════════════

/** A2 autoRetry 配置（task 参数；缺省关闭）。 */
export interface AutoRetryConfig {
	/** 瞬时类最大自动重派次数（0=显式关闭）。 */
	retries: number;
	/** 首次退避 ms（指数退避 backoffMs×2^n，n=已重试次数）。 */
	backoffMs: number;
}

/** 退避延迟硬上限（90s×2^10 不可控；封顶 30min）。 */
const AUTO_RETRY_DELAY_CAP_MS = 30 * 60 * 1000;

/** AMAGI_AUTORETRY_OFF=1 一键关（守卫层短路：计划器恒返回 undefined）。 */
export function isAutoRetryEnabled(): boolean {
	return process.env.AMAGI_AUTORETRY_OFF !== "1";
}

/** 参数归一（纯函数）：retries 缺省 2（0..10 整数）；backoffMs 缺省 90s（1..3600000）。
 *  非法值显式报错（不静默吞配置事故）；raw 缺省返回空 config（= 未声明）。 */
export function normalizeAutoRetryConfig(raw: unknown): { config?: AutoRetryConfig; error?: string } {
	if (raw === undefined || raw === null) return {};
	if (typeof raw !== "object" || Array.isArray(raw)) return { error: `autoRetry 必须是对象 { retries?, backoffMs? }（收到 ${Array.isArray(raw) ? "数组" : typeof raw}）` };
	const o = raw as { retries?: unknown; backoffMs?: unknown };
	let retries = 2;
	let backoffMs = 90_000;
	if (o.retries !== undefined) {
		if (typeof o.retries !== "number" || !Number.isInteger(o.retries) || o.retries < 0 || o.retries > 10)
			return { error: `autoRetry.retries 必须是 0..10 的整数（收到 ${JSON.stringify(o.retries)}）` };
		retries = o.retries;
	}
	if (o.backoffMs !== undefined) {
		if (typeof o.backoffMs !== "number" || !Number.isFinite(o.backoffMs) || o.backoffMs < 1 || o.backoffMs > 3_600_000)
			return { error: `autoRetry.backoffMs 必须是 1..3600000 的毫秒数（收到 ${JSON.stringify(o.backoffMs)}）` };
		backoffMs = o.backoffMs;
	}
	return { config: { retries, backoffMs } };
}

/** ev-20260919-226d6f：未声明 autoRetry 的单任务派发（sync/background）隐式瞬时重试预算。
 *  根因：瞬时传输类（timeout/断连/5xx）是唯一「零声明=零恢复」的失败类——对照同族恢复机制
 * （自动续跑缺省 2 轮、孤儿 400 修复缺省 1 轮均默认开），实战 luoshen 76min 长任务因单请求
 * 首字节超时（Request timed out，TRANSIENT 类）整单 error 零落盘，恢复成本全转嫁 Leader 手动重派。
 *  隐式预算保守：缺省 1 轮；AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关隐式；AMAGI_AUTORETRY_OFF=1
 *  全局一键关（调用点已有判定）。仅接入已有退避/熔断感知/落盘分流/journal 留痕语义的单任务路径；
 *  batch/编排维持 opt-in（组语义，断连链降级已有隐式覆盖）。 */
export function getImplicitAutoRetryRounds(): number {
	const v = parseInt(process.env.AMAGI_AUTORETRY_IMPLICIT_ROUNDS ?? "1", 10);
	return Number.isInteger(v) && v >= 0 && v <= 10 ? v : 1;
}

/** 隐式预算退避基值（默认 90s，与声明式缺省一致；1..3600000，非法回退默认——测试/运维可调）。 */
export function getImplicitAutoRetryBackoffMs(): number {
	const v = parseInt(process.env.AMAGI_AUTORETRY_IMPLICIT_BACKOFF_MS ?? "90000", 10);
	return Number.isFinite(v) && v >= 1 && v <= 3_600_000 ? v : 90_000;
}

/** 隐式 autoRetry 配置（纯函数）：隐式轮数为 0 → undefined（= 未启用）；否则 1 轮级保守配置。 */
export function implicitAutoRetryConfig(): AutoRetryConfig | undefined {
	const retries = getImplicitAutoRetryRounds();
	return retries > 0 ? { retries, backoffMs: getImplicitAutoRetryBackoffMs() } : undefined;
}

/** ev-20260919-226d6f 收窄：隐式预算仅接管传输类瞬时错（timeout/断连/5xx）。
 *  429/限流类（含账号配额）有专属恢复路径（链尽冷却 ev-20260916-101d8a / 配额换 provider 建议 A3）——
 *  隐式不得抢先截胡改变既有语义（实战回归：429 单模型无链本应进冷却，被隐式重派截胡）。 */
export function implicitRetryApplicable(errorMessage?: string): boolean {
	// ev-20261021-fix（diting F9）：策略拦截优先排除（isTransientProviderError 单源已排除，此处显式
	// 表达同一语义——安全拒绝不得进入隐式重试预算）。
	return !isContentPolicyRejection(errorMessage) && isTransientProviderError(errorMessage) && !isRateLimitSignal(errorMessage) && !isAccountQuotaError(errorMessage);
}

/** A2 重派计划：n=第几次重派（1 起）；delayMs=退避毫秒；nextModel=下次派发 model（undefined=同模型）。 */
export interface AutoRetryPlan {
	n: number;
	delayMs: number;
	nextModel?: string;
}

/** A2 决策（纯函数 + 熔断只读 peek）：瞬时 error 终态且预算未尽 → 退避重派计划；否则 undefined。
 *  退避 = backoffMs×2^attempt，但不早于熔断 Open 剩余恢复时间（盲派只会重复烧退避），封顶 30min。
 *  账号级配额 + 无备选 model（nextModel 缺省）→ 不重派：配额共享，同 provider 退避必复现，
 *  直接交回 A3 建议（换 provider）比烧一次重派更诚实。 */
export function nextAutoRetryPlan(o: { status: string; errorMessage?: string; spawnError?: string; stopReason?: string; model?: string; attempt: number; config: AutoRetryConfig | undefined; nextModel?: string }): AutoRetryPlan | undefined {
	if (!o.config || !isAutoRetryEnabled()) return undefined;
	if (o.status !== "error") return undefined;
	const cause = o.errorMessage || o.spawnError;
	// ev-20261021-fix（diting F9）：策略拦截优先排除——混合签名（策略文案含 timeout/429 词根）不得
	// 触发自动重试或自动换 provider；配额（quota）与普通瞬时仍按既有区分处理。
	if (isContentPolicyRejection(cause)) return undefined;
	const quota = isAccountQuotaError(cause);
	if (!quota && !isTransientProviderError(cause)) return undefined;
	if (o.attempt >= o.config.retries) return undefined;
	if (quota && (!o.nextModel || !providerOfSpecLocal(o.model || "") || !providerOfSpecLocal(o.nextModel) || providerOfSpecLocal(o.model || "") === providerOfSpecLocal(o.nextModel))) return undefined;
	let delayMs = quota ? 0 : o.config.backoffMs * 2 ** o.attempt;
	const peek = providerBreakerPeek(providerOfSpecLocal(o.model || ""));
	if (peek.open && peek.retryAfterMs !== undefined && peek.retryAfterMs > delayMs) delayMs = peek.retryAfterMs;
	return { n: o.attempt + 1, delayMs: Math.min(delayMs, AUTO_RETRY_DELAY_CAP_MS), nextModel: o.nextModel };
}

/** A3 建议输入（纯函数；candidates 由调用方经 loadFallbackModels 加载，保持本模块零 IO）。 */
export interface RetryAdviceOptions {
	taskId: string;
	/** 受派角色名（可复制重派命令内引用）。 */
	agent?: string;
	/** 失败轮使用的模型 spec。 */
	model?: string;
	errorMessage?: string;
	spawnError?: string;
	/** 备选模型候选链（AMAGI_FALLBACK_MODELS / amagi.json fallbackModels）。 */
	candidates?: readonly string[];
	excludeProviders?: ReadonlySet<string>;
	registry?: ModelRegistryLike;
	/** 失败任务会话仍在时的 resume 续接句柄（有上下文时 resume 优先于 fresh 重派）。 */
	sessionId?: string;
}

/** A3（ev-20260910-d86779）：error 终态且瞬时类时的「重派建议」段（纯函数；sync 通知与 bg steer 共用）。
 *  三要素：① 推荐退避秒数（熔断 Open 剩余恢复时间，无熔断则按连续瞬时数取阶梯 90/180/360s）
 *  ② 推荐备选模型（异 provider 候选链首优先——429/503 风暴期同 provider 无意义；无则 tier 降档）
 *  ③ 可复制重派命令（有 sessionId 时优先 resume 续接）。非瞬时（鉴权等确定性错误）返回 undefined。
 *  ev-20260917-9746aa（P1）：推荐位结合熔断器状态——失败 provider Open 时不再推荐同 provider
 *  tier 降档（实战：熔断提示「X Open，恢复 287s」与「推荐备选：X/gemini:medium」同块自相矛盾），
 *  候选链逐 provider peek 排除 Open 项；全部候选熔断中时明示等待恢复或人工指定，不再给自相矛盾推荐。 */
/** D2（ev-20260922-727096）：瞬时故障建议等待事实——从 buildRetryAdvice 提取的单源事实
 *  （恢复指引 recoveryActionOf 与 A3 重派建议共用同一等待口径，不维护第二份阶梯/熔断推导）。 */
export interface TransientBackoffHint {
	/** 失败模型 provider 段（空 spec → 空串）。 */
	provider: string;
	/** 熔断只读观测（peek——不消费 HalfOpen 探针名额）。 */
	breaker: ProviderBreakerCheck;
	/** 建议等待秒数（熔断 Open 剩余恢复时间优先，否则按连续瞬时数取阶梯）。 */
	seconds: number;
	/** true=取自熔断 Open 剩余恢复时间（非阶梯默认）。 */
	openWait: boolean;
	/** 人读等待建议行（含依据——与 buildRetryAdvice 推荐退避行同源同文）。 */
	text: string;
}

/** 瞬时故障建议等待（纯函数 + 熔断只读 peek）：熔断 Open 且冷却未过 → 剩余恢复时间；
 *  否则按连续瞬时数取阶梯 90/180/360s（本次失败已计入 consecutiveFailures，故 cf-1 入梯；cf=0 保守取 90s）。 */
export function transientBackoffHint(model?: string): TransientBackoffHint {
	const provider = providerOfSpecLocal(model || "");
	const cb = providerBreakerPeek(provider);
	const LADDER = [90, 180, 360];
	const ladderSec = LADDER[Math.min(Math.max(cb.consecutiveFailures - 1, 0), LADDER.length - 1)];
	const openWait = cb.open && !cb.probe && typeof cb.retryAfterMs === "number" && cb.retryAfterMs > 0;
	const seconds = openWait ? Math.ceil(cb.retryAfterMs! / 1000) : ladderSec;
	const text = openWait
		? `约 ${seconds}s（熔断器 ${provider || "?"} Open，取剩余恢复时间）`
		: `约 ${seconds}s（阶梯默认；${provider || "?"} 连续瞬时 ${cb.consecutiveFailures} 次）`;
	return { provider, breaker: cb, seconds, openWait, text };
}

/** Preserve the server timestamp verbatim; an unlabelled timestamp has no inferred timezone. */
export function quotaResetHint(cause?: string): string | undefined {
	if (!cause) return undefined;
	const match = cause.match(/(?:重置|恢复|reset)[^\n]{0,60}?(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?(?:\s*(?:(?:UTC|GMT)(?:[+-]\d{1,2}(?::?\d{2})?)?|Z|[+-]\d{2}:?\d{2}))?)/i)
		?? cause.match(/(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?(?:\s*(?:(?:UTC|GMT)(?:[+-]\d{1,2}(?::?\d{2})?)?|Z|[+-]\d{2}:?\d{2}))?)[^\n]{0,60}?(?:重置|恢复|reset)/i);
	return match ? `服务端标明额度恢复时间：${match[1].trim()}（保留原文时间口径）` : undefined;
}

export function buildRetryAdvice(o: RetryAdviceOptions): string | undefined {
	const cause = o.errorMessage || o.spawnError;
	// ev-20261021-fix（diting F9）：A3 入口优先排除策略拦截——安全拒绝的恢复路径是合法范围核查/
	// 授权/申诉（recoveryActionOf policy-reject 专属指引），不把自动换 provider/退避重试当解法。
	if (isContentPolicyRejection(cause)) return undefined;
	if (isAccountQuotaError(cause)) {
		const excluded = new Set([...(o.excludeProviders ?? []), ...(o.candidates ?? []).map(c => { const n = normalizeModelSpec(c, o.registry); return n.ok ? providerOfSpecLocal(n.spec || "") : ""; }).filter(p => p && providerBreakerPeek(p).open)]);
		const alt = crossProviderDowngrade(o.model, o.candidates, o.registry, excluded);
		return ["[重派建议] 账号级配额耗尽，恢复路径：", quotaResetHint(cause) ?? "服务端未提供可确认的额度恢复时间，先核对账号额度。",
			"- 同 provider 退避大概率无效，直接换 provider；同账号换模型/思考档不会恢复额度。",
			alt ? `- 推荐备选模型：${alt}（不同 provider，排除熔断通道）` : "- 无可用异 provider 候选；等待额度恢复后续接，不建议短退避原样重试。"].join("\n");
	}
	if (!isTransientProviderError(cause)) return undefined;
	const hint = transientBackoffHint(o.model);
	const provider = hint.provider;
	const cb = hint.breaker;
	const backoffSec = hint.seconds;
	const openWait = hint.openWait;
	// ev-20260917-9746aa：Open provider 集合（失败 provider + 候选链逐 provider peek；probe 在飞同属不可派）
	const fusedProviders = new Set<string>();
	const quotaBlocked = o.excludeProviders ?? new Set<string>();
	if (cb.open) fusedProviders.add(provider);
	for (const c of o.candidates ?? []) {
		const cp = providerOfSpecLocal(c);
		if (cp && cp !== provider && providerBreakerPeek(cp).open) fusedProviders.add(cp);
	}
	const unavailableProviders = new Set([...fusedProviders, ...quotaBlocked]);
	const alt = crossProviderDowngrade(o.model, o.candidates, o.registry, unavailableProviders);
	// 失败 provider Open → tier 降档（同 provider）不再推荐；健康时保留既有 tier 降一档回退
	const tierAlt = unavailableProviders.has(provider) ? undefined : downgradeModel(o.model);
	const finalAlt = alt ?? tierAlt;
	const lines = [`[重派建议] 瞬时 provider 故障（transient），恢复路径：`];
	lines.push(`- 推荐退避：约 ${backoffSec}s${openWait ? `（熔断器 ${provider || "?"} Open，取剩余恢复时间）` : `（阶梯默认；${provider || "?"} 连续瞬时 ${cb.consecutiveFailures} 次）`}`);
	if (finalAlt) {
		lines.push(`- 推荐备选模型：${finalAlt}${alt && unavailableProviders.size > 0 ? quotaBlocked.size ? "（已排除配额耗尽或熔断的 provider）" : "（已排除熔断 Open 的 provider）" : ""}`);
	} else if (quotaBlocked.size > 0) {
		lines.push(`- 推荐备选模型：无可用候选；已排除配额耗尽通道（${[...quotaBlocked].join("、")}），须核对账号额度恢复${fusedProviders.size ? `及熔断通道（${[...fusedProviders].join("、")}）状态` : "时间"}后再选择。`);
	} else if (fusedProviders.size > 0) {
		lines.push(`- 推荐备选模型：无——候选链当前全部熔断中（Open：${[...fusedProviders].filter(Boolean).join("、") || provider || "?"}），建议等待熔断恢复（约 ${backoffSec}s）或人工指定 model 重派`);
	}
	const agentPart = o.agent ? `agent: "${o.agent}", ` : "";
	const cmd = o.sessionId
		? `task({ ${agentPart}session: "${o.sessionId.slice(0, 8)}", task: "接手继续完成原任务"${finalAlt ? `, model: "${finalAlt}"` : ""} })（resume 续接，保留已产出上下文）`
		: `task({ ${agentPart}task: <原任务书>${finalAlt ? `, model: "${finalAlt}"` : o.model ? `, model: "${o.model}"` : ""} })`;
	lines.push(`- 可复制重派：${cmd}`);
	// ev-20260918-172ac9：通道级断连专属建议——同 provider 换模型对中转站/provider 级故障大概率无效，
	// 补「改派等价职能角色」维度（实战：单角色端点连挂 2 轮零产出，同期其他角色通道正常；A3 既有
	// 建议只有换模型/resume，缺换角色路径，Leader 两轮试错后才发现改派即成功）。
	if (isChannelDisconnectError(cause)) {
		lines.push(`- 通道级断连（Connection error/timeout 类）：若同 provider 其它模型同样失败，多为 provider/中转站级故障——建议改派等价职能角色（换 agent，走其模型链）或显式指定其它 provider 的 model 重派，勿盲目原样重派`);
	}
	return lines.join("\n");
}

// ══════════════════════════════════════════════════════════════════════════
// D2（ev-20260922-727096）：外部中断恢复指引单源——recoveryActionOf + renderRecoveryAdvice。
// 裁决（方案 §2.10）：只采方案 a（恢复描述单源），不新增 b（pre-execution 传输错误自动重试），
// 不引入 blocked-external 执行态。error 并非不可 resume（会话仍在即有续接载体），但恢复能力必须
// 一致投射到通知/稳定分面/查询——本节是唯一判断与渲染源，task-facets/task-query/task-tool 消费，
// 不各自拼第二份文案。
//
// b 的边界（本批不实施、不作为关闭 ev 条件——仅留存设计约束）：若后续单独批准自动重试，只允许
// 执行器能证明「模型工具尚未 dispatch，且无任何外部调用」的 pre-execution 传输错误；已写入/已调用/
// 观察不完整均禁止；同任务链合计额外一次、默认 90s、熔断剩余等待超过 180s 交人工；quota/429、用户
// 取消、超时、guard block 不触发；继承原 session、新 taskId、同租约与 revision fence，取消/人工
// resume 优先、持久预算跨重启不重置，且不得另加在既有隐式重试之上。当前执行器没有可信任的
// 阶段信息，不以猜测实现。
// ══════════════════════════════════════════════════════════════════════════

/** D2 恢复建议的续接消息（稳定 task_resume.message / legacy task.task 共用单源文案）——
 *  子进程可能已编辑文件/执行 shell/MCP 外部副作用，零 writeToolCalls 或本地 diff 空都不能证明
 *  无副作用；续接前必须先核对已完成写入与外部副作用，不重放已成功操作。 */
export const RECOVERY_RESUME_MESSAGE = "先核对已完成写入和外部副作用，再继续原任务的未完成部分；不要重放已成功操作。";

/** ev-20261012-21074e②：policy 恢复建议列出已写入文件的项数上限（溢出折叠计数）。 */
export const POLICY_WRITTEN_FILES_MAX = 8;

/** 恢复动作判别联合（内部纯数据；展示统一走 renderRecoveryAdvice，调用形态由会话 surfaceVersion 决定）。 */
export type RecoveryAction =
	| { kind: "resume"; handle: string; cause: "transient" | "quota" | "deterministic"; waitHint?: string; caveat: string; /** ev-20261031-7110a8：quota 换模候选（配置枚举+registry 只读探测；额度不可知，渲染层明示）。 */ switchCandidates?: readonly QuotaRecoveryCandidate[]; /** ev-20261031-7110a8：本任务 resume 父链连续 quota 类失败数（含本次；≥2 不再默认建议同 provider 重试）。 */ quotaChainFailures?: number }
	| { kind: "new-task"; reason: string }
	| { kind: "policy-reject"; reason: string; writtenFiles?: string[] }
	| { kind: "none"; reason: string };

/** recoveryActionOf 输入：真实执行/会话/进程状态及错误分类（不能仅看一段错误文字）。
 *  事实由调用方从 RunResult/registry 记录/准入判定取；本函数纯判断，不查任何运行时状态。 */
export interface RecoveryActionInput {
	/** 任务完整 taskId（resume 句柄——完整 id，不用可能歧义的八位前缀）。 */
	taskId: string;
	/** 终态执行状态：仅 "error" 进入恢复判定；cancelled/blocked/running 等返回 undefined（各自另有展示语义）。 */
	status: string;
	/** registry lastErrorKind 快照（task-run finalize 唯一收口写入；缺省由 errorMessage 现场分类）。 */
	errorKind?: LastErrorKind;
	/** 失败根因原文（errorMessage；保留原文不截断）。 */
	errorMessage?: string;
	spawnError?: string;
	stopReason?: string;
	/** 引擎/控制面中止（AbortSignal 取消、abort 终止——用户取消不鼓励自动恢复）。 */
	userAborted?: boolean;
	/** 引擎超时终止（[超时]——给针对性修因，不按瞬时故障盲目重试）。 */
	timedOut?: boolean;
	/** 守卫硬边界终止（按守卫 reason 修因；未修因直接续接大概率再次触界）。 */
	guardTerminated?: boolean;
	/** 子进程已确认退出（close 已达/终态记录；迟到事件窗口不承诺可续接）。 */
	processExited?: boolean;
	/** 会话可用（resume 的必要载体；缺失 → artifact 接力新任务，不造必失败的续接）。 */
	sessionId?: string;
	/** 原工作目录仍存在（会话与 cwd 绑定；缺失 → 新任务）。 */
	cwdAvailable?: boolean;
	/** resume 准入阻塞码（运行中/answering-lease/resolved-external——调用方经 resumeAdmissionCodeOf 从当前记录取；建议不是准入授权，执行时重查）。 */
	admissionBlockedCode?: string;
	/** 失败模型 spec（transient 等待建议从熔断/阶梯取，与 buildRetryAdvice 同源）。 */
	model?: string;
	/** ev-20261012-21074e②：该任务已写入文件清单（任务写面登记去重；policy 拦截恢复建议列出供核对——
	 *  error 终态可能已有部分产物，先核对再续接/重派。装配方 readTaskWrites；纯函数不读盘）。 */
	writtenFiles?: string[];
	/** ev-20261031-7110a8：本任务 resume 父链连续 quota 类失败次数（含本次；由 recoveryActionOfRecord
	 *  沿 registry.parentTaskId 链装配；≥QUOTA_CHAIN_SWITCH_THRESHOLD 时不再默认建议同 provider 重试）。 */
	quotaChainFailures?: number;
	/** ev-20261031-7110a8：换模候选（配置枚举 + registry 只读探测；额度不可知——渲染层明示不假称）。 */
	switchCandidates?: readonly QuotaRecoveryCandidate[];
}

/** 确定性失败的针对性修因（鉴权/参数/上下文损坏等——不把所有 error 标 transient）。 */
function deterministicFixOf(cause: string, stopReason?: string): string {
	if (/unauthorized|invalid api key|api key|鉴权|401/i.test(cause)) return "鉴权/凭据失败——先修复 provider 凭据（settings/env）再续接；凭据未修前同 provider 续接必复现";
	if (stopReason === "aborted") return "provider abort（stopReason=aborted）——核对 provider 侧终止原因（内容策略/上游断开）修因后续接";
	// E-01（diting Phase E）：TLS/证书类确定性修因——OAuth/代理 TLS 配置错误不给泛化文案。
	if (isTlsCertFailure(cause)) return "TLS/证书校验失败——先修 provider 端点证书/信任链（CA bundle、代理 TLS 拦截、系统时间）再续接；证书未修前同请求必复现，不按瞬时重试";
	// pi 1.5.0 #11492 对齐：LiteLLM ContextWindowExceededError / "Context Window exceeded" 纳入上下文超限文案。
	// E-03（diting Phase E）：只认超限签名（CONTEXT_WINDOW_EXCEEDED_RE 单源）；参数名本身不算超限证据。
	if (/context length|token limit|上下文超限/i.test(cause) || CONTEXT_WINDOW_EXCEEDED_RE.test(cause)) return "上下文超限——换更大窗口模型重派，或续接轮先把已产出状态落 artifact 再继续";
	if (/\b400\b|invalid_request|model names|模型/i.test(cause)) return "模型/请求参数类 4xx——核对模型名与参数修因后续接（必要时新派任务换模型策略）";
	return "见失败根因原文修因（确定性失败不会因等待自愈）";
}

/** D2 恢复动作判定（纯函数）：error + 已确认进程退出 + 可用 session/cwd + 无准入阻塞 → 可 resume
 *  （完整 taskId 为句柄）；任务运行中/lease 占用/resolved-external/会话缺失不承诺可续接；
 *  aborted 区分用户取消（不鼓励自动恢复）；超时/守卫/鉴权给针对性修因，不把所有 error 标 transient。
 *  「可恢复」只是描述性建议——错误回执仍保持 error coverage 缺口，不写成通过的检查事实。 */
export function recoveryActionOf(o: RecoveryActionInput): RecoveryAction | undefined {
	if (o.status !== "error") return undefined;
	if (o.userAborted) return { kind: "none", reason: `用户/控制面中止（abort）——用户取消不鼓励自动恢复；确需继续时再显式续接（句柄 ${o.taskId}）` };
	if (o.processExited !== true) return { kind: "none", reason: "子进程退出尚未确认（迟到事件窗口）——先等终态收口（wait/查询）再评估续接，此刻不承诺可续接" };
	if (o.admissionBlockedCode === "running") return { kind: "none", reason: "任务仍在运行——不可续接（等终态或 cancel 止损）" };
	if (o.admissionBlockedCode === "answering-lease") return { kind: "none", reason: "续接进行中（session lease 被并发 resume 持有，N6 只启动一个）——已有续接在跑，勿重复续接" };
	if (o.admissionBlockedCode === "resolved-external") return { kind: "none", reason: "任务已外部处置收口（resolved-external）——产物已在外部采用，如需重跑请新派任务" };
	if (!o.sessionId) {
		return { kind: "new-task", reason: `会话缺失（无 sessionId，resume 无载体）——从归档 artifact 接力：先取产物引用与 result.md（task_query/query_task），再新派任务承接；不构造必失败的续接` };
	}
	if (o.cwdAvailable === false) {
		return { kind: "new-task", reason: "原任务工作目录已不存在（会话与 cwd 绑定）——先取归档 artifact，再新派任务承接" };
	}
	const cause = o.errorMessage || o.spawnError || "";
	const quota = o.errorKind === "quota" || isAccountQuotaError(cause);
	const handle = o.taskId;
	// ev-20261012-21074e② / ev-20261017-88cb27 / ev-20261021-fix（diting F9）：provider 安全拦截
	//（provider-safety-refusal：内容策略/cybersecurity flag/Daybreak）——任务内容触发的确定性拒绝：
	// 同内容原样 resume 必复现；不自动重试、不自动换模型/降档（共享 transient/A3 入口已同源排除）。
	// 恢复路径优先级（主上 2026-10-21 裁定）：先核查任务是否确在合法授权范围内；确属正当安全
	// 工作→走 provider 授权/申诉渠道（如 Daybreak access 申请）；不以改措辞规避审查、不把换
	// provider 当绕过安全限制的默认解——确需调整任务/模型时由主上显式裁定后重派。
	if (o.errorKind === "policy" || isContentPolicyRejection(cause)) {
		return {
			kind: "policy-reject",
			reason: "provider 内容策略拦截（provider-safety-refusal：内容/安全审查拒绝，如 cybersecurity flag / Daybreak）——原样续接会再次被拦：同内容原样 resume 必复现。恢复路径按优先级：① 核查任务是否确在合法授权范围内（正当安全测试须先具备授权）；② 确属正当但被误拦→走 provider 官方授权/申诉渠道（如 Daybreak access 申请），不改写措辞规避审查、不自动重试、不自动换 provider/模型绕过安全限制；③ 任务确需调整时由主上显式裁定后重派（换模型须显式披露，不静默切换）",
			...(o.writtenFiles && o.writtenFiles.length > 0 ? { writtenFiles: o.writtenFiles } : {}),
		};
	}
	if (o.timedOut) {
		return { kind: "resume", handle, cause: "deterministic", caveat: `超时终止——修因后续接：调整 timeoutMs / AMAGI_TASK_TIMEOUT_MS（设 0 关闭上限）或拆小任务；不按瞬时故障盲目立即重试` };
	}
	if (o.guardTerminated) {
		return { kind: "resume", handle, cause: "deterministic", caveat: "守卫硬边界终止——先核对任务书与派发边界（allowedPaths/protectedPaths/守卫 reason）修因再续接；未修因直接续接大概率再次触界" };
	}
	if (quota) {
		// quota（provider-quota-exhausted，ev-20261017-88cb27）：provider 侧硬额度耗尽是账号/工作区级
		// 非任务原因——恢复路径是等待额度恢复或切换其它 provider 模型，不是修任务；同 provider 换模型/
		// 退避不会恢复额度。ev-20261031-7110a8：换模候选/父链计数进入建议（task_resume 面已有可选 model
		// 覆盖，渲染层给可复制换模续接调用，不再要求手改全局配置换 provider）。
		return {
			kind: "resume", handle, cause: "quota", waitHint: quotaResetHint(cause),
			switchCandidates: o.switchCandidates, quotaChainFailures: o.quotaChainFailures,
			caveat: "配额类故障（provider-quota-exhausted：账号级/工作区硬额度耗尽，如 usage limit reached）——先等待额度恢复或由 Leader 换模续接/重派可变更模型策略的新任务（推荐切换其它 provider 模型；同账号同 provider 换模型/思考档不会恢复额度）；默认续接按当前配置解析，不承诺同 provider 立即恢复",
		};
	}
	// P3-03（diting P3）：TLS/证书确定性失败优先于原始 stream 兜底——带排除语义的确定性分支。
	// 修复前 `isStreamDisconnectError(cause)` 直通 transient 分支，把 `terminated: certificate …`
	//（channel=true 但 transient=false、plan=null）错误地给出瞬时退避建议；修因应走证书/CA 分支
	//（deterministicFixOf TLS），与 policy/quota 优先级同理。nextAutoRetryPlan 的 quota/transient
	// 最终门控保持不变（TLS plan=null，不自动降链）。
	if (isTlsCertFailure(cause)) {
		return { kind: "resume", handle, cause: "deterministic", caveat: `确定性失败——先修因（${deterministicFixOf(cause, o.stopReason)}）再续接` };
	}
	if (o.errorKind === "transient" || isStreamDisconnectError(cause) || (!o.errorKind && isTransientProviderError(cause))) {
		// steer 2-①（ev-20261031-7110a8）：transient（含裸 429/瞬时限流）同样携带非强制换模候选——
		// 分类与默认重试语义不变（等待后原链续接仍是缺省建议）。
		return { kind: "resume", handle, cause: "transient", waitHint: transientBackoffHint(o.model).text, switchCandidates: o.switchCandidates, caveat: "瞬时 provider 故障——错误可能短暂，但不证明重跑幂等；续接前先核对已完成写入与外部副作用" };
	}
	return { kind: "resume", handle, cause: "deterministic", caveat: `确定性失败——先修因（${deterministicFixOf(cause, o.stopReason)}）再续接` };
}

/** 续接调用形态（按会话 surfaceVersion 渲染；新会话不得收到未注册的 legacy task 建议）：
 *  稳定面 task_resume 为 handle/message（ev-20261031-7110a8 起可选 model 一次性覆盖——换模续接
 *  建议携带、缺省建议不带）；legacy 面 task 沿用 session/task（可选 agent/model）。 */
export function resumeCallOf(surfaceVersion: number | undefined, o: { handle: string; message?: string; agent?: string; model?: string }): string {
	const message = o.message ?? RECOVERY_RESUME_MESSAGE;
	if (surfaceVersion === 1) {
		const agentPart = o.agent ? `agent: "${o.agent}", ` : "";
		return `task({ ${agentPart}session: "${o.handle}", task: "${message}"${o.model ? `, model: "${o.model}"` : ""} })`;
	}
	return `task_resume({ handle: "${o.handle}", message: "${message}"${o.model ? `, model: "${o.model}"` : ""} })`;
}

function recoveryCauseLabel(cause: "transient" | "quota" | "deterministic"): string {
	if (cause === "transient") return "瞬时 provider 故障";
	if (cause === "quota") return "账号级配额";
	return "确定性失败（先修因）";
}

// ── ev-20261031-7110a8：quota 换模建议段（配置候选 + 可复制换模续接 + 分类证据边界） ──
// 实战（kb-org-orchestration-dev 复盘 §2.1）：同 fuxi 父链连续 3 轮 anthropic 429，恢复靠 4 次手工
// 改 amagi.json 换 provider 再改回。本段把「配置内可枚举候选 + 可复制换模续接（task_resume 可选
// model）+ 父链连续失败事实」透出给 Leader；额度不可探测，只声明到「注册/凭据配置」为止。

/** 父链连续 quota 类失败达到此数时，不再默认建议同 provider 重试/退避（直接换 provider 或等额度恢复）。 */
export const QUOTA_CHAIN_SWITCH_THRESHOLD = 2;

function quotaCandidateReachLabel(reach: QuotaRecoveryCandidate["reach"]): string {
	switch (reach) {
		case "auth": return "已注册·凭据已配置";
		case "registered": return "已注册·凭据未证实";
		default: return "registry 不可用·未探测";
	}
}

/** quota 恢复建议行（renderRecoveryAdvice quota 分支单源）：候选分级/可复制换模续接/诚实边界/父链判定。 */
function quotaSwitchAdviceLines(action: Extract<RecoveryAction, { kind: "resume" }>, surface: number): string[] {
	const lines: string[] = [];
	if (typeof action.quotaChainFailures === "number" && action.quotaChainFailures >= QUOTA_CHAIN_SWITCH_THRESHOLD) {
		lines.push(`- 同 provider 重试判定：本任务父链已连续 ${action.quotaChainFailures} 次配额类失败——不再默认建议同 provider 重试/退避（账号级配额共享，退避大概率复现）；直接换 provider 续接（见换模候选）或等待额度恢复。`);
	}
	const cands = action.switchCandidates;
	if (cands === undefined) {
		lines.push(`- 换模：切换其它 provider 模型续接（task_resume 可选 model 一次性覆盖，不改 amagi.json）；候选清单经 task_query 查看本任务恢复指引，或查阅 amagi.json agents/fallbackModels。`);
	} else if (cands.length === 0) {
		lines.push(`- 换模候选：当前配置（fallbackModels/amagi.json agents/profiles）未枚举到与失败模型不同 provider 的候选——等待额度恢复（见建议等待行），或在 amagi.json 配置 fallbackModels/agents.<role>.model 后重试；不需要手改全局配置换 provider（换模续接走 task_resume 可选 model）。`);
	} else {
		const list = cands.map((c) => `${c.spec}←${c.source}（${quotaCandidateReachLabel(c.reach)}）`).join("、");
		const providerBoundary = cands.some((c) => !c.provider)
			? "已排除确认同 provider 的条目；部分 provider 未确认，不保证跨 provider"
			: "只含与失败模型不同 provider 的条目";
		lines.push(`- 换模候选（当前配置枚举，${providerBoundary}）: ${list}`);
		lines.push(`- 候选边界：以上只证明配置内存在；registry 注册/凭据配置按各项标签披露，未探测项不视为已注册；额度与服务端实际可调用未探测，不假称可用——首次换模续接即真实探测。`);
		lines.push(`- 可复制换模续接：${resumeCallOf(surface, { handle: action.handle, model: cands[0]!.spec })}（model 为本轮一次性覆盖：不改 amagi.json、不扩权限；额度恢复后缺省续接自动回到配置解析模型）`);
	}
	lines.push(`- 分类边界：账号级配额判定＝硬额度文案（usage limit reached 等）或「429/限流＋账号级配额词族」同时命中；单纯 429/rate limit 属瞬时限流（等待后可再试）——不凭 429 推断账号封禁。`);
	return lines;
}

/** D2 恢复指引渲染（单源文案——通知/同步返回/查询/legacy 通知共用，不维护第二份）：
 *  - resume：列出实际 task_resume 句柄与副作用核对消息 + 继承语义（session/上下文/cwd/原范围、关联新 taskId、旧 error 回执保留）；
 *  - new-task：给 artifact 接力指引，不造必失败的 resume；
 *  - none：明确不鼓励自动恢复的原因。surfaceVersion 缺省按稳定分面渲染（2）。 */
export function renderRecoveryAdvice(action: RecoveryAction | undefined, opts?: { surfaceVersion?: number }): string | undefined {
	if (!action) return undefined;
	const surface = opts?.surfaceVersion ?? 2;
	if (action.kind === "none") return `[恢复指引] 不建议自动恢复：${action.reason}`;
	if (action.kind === "new-task") return `[恢复指引] 无法续接：${action.reason}`;
	// ev-20261012-21074e②：policy 拦截专属渲染——不造 resume 调用（同内容续接必复现），列出已写入
	// 文件供核对（≤8 项 + 溢出计数；error 终态可能已有部分产物——本会话实证 diting 被拦后 4 个中间
	// 产物靠手工 ls 才发现）。无登记时回退只读核验指引（task_query 产物摘要/未跟踪段）。
	if (action.kind === "policy-reject") {
		const lines = [
			`[恢复指引] ${action.reason}：`,
			"- 先核对已写入文件再续接/重派：" + (action.writtenFiles && action.writtenFiles.length > 0
				? `${action.writtenFiles.slice(0, POLICY_WRITTEN_FILES_MAX).join("、")}${action.writtenFiles.length > POLICY_WRITTEN_FILES_MAX ? ` …另 ${action.writtenFiles.length - POLICY_WRITTEN_FILES_MAX} 处` : ""}`
				: "本任务无写面登记——可经 task_query 产物摘要/未跟踪段或 git status 复核"),
		];
		return lines.join("\n");
	}
	const lines = [
		`[恢复指引] error 终态可续接（${recoveryCauseLabel(action.cause)}）——由 Leader 显式续接，不自动重跑：`,
		`- 续接调用：${resumeCallOf(surface, { handle: action.handle })}`,
		`- 继承语义：续接继承原会话/上下文/cwd/原范围，创建关联新 taskId（父链可见）；原 error 回执保留不改写（验收仍须显式 accept，本指引不是检查事实）。`,
	];
	if (action.waitHint) lines.push(`- 建议等待：${action.waitHint}`);
	if (action.cause === "quota") lines.push(...quotaSwitchAdviceLines(action, surface));
	// steer 2-①（ev-20261031-7110a8）：transient（含裸 429/瞬时限流）同样附非强制换模候选——
	// 原始 429 场景也能看到临时换模入口；分类与默认重试语义不变（等待后原链续接仍是缺省建议）。
	if (action.cause === "transient" && action.switchCandidates && action.switchCandidates.length > 0) {
		const cands = action.switchCandidates.slice(0, 3);
		lines.push(`- 可选换模候选（非强制；分类与默认重试语义不变，缺省仍是等待后原链续接）: ${cands.map((c) => `${c.spec}←${c.source}（${quotaCandidateReachLabel(c.reach)}）`).join("、")}——只证明配置+注册/凭据配置，实际可用未探测。`);
		lines.push(`- 可选换模续接（等待后仍持续限流时再用）：${resumeCallOf(surface, { handle: action.handle, model: action.switchCandidates[0]!.spec })}（model 为本轮一次性覆盖，不改 amagi.json、不扩权限）`);
	}
	if (action.caveat) lines.push(`- 注意：${action.caveat}`);
	return lines.join("\n");
}

// ════════════════════════════════════════════════════════════════════════════
// ev-20260916-101d8a：链尽 429 单次冷却（方案 §4.2）——Retry-After 解析 + 冷却计划器（纯函数）。
// 触发限定：provider 层明确 429/限流（非账号级配额——配额共享退避必复现，交回 A3/接管）、候选链
// 与 tier 降档已用尽（由调用方判定后进入）、未取消、零残留、冷却次数未消费；Retry-After 只认
// 明确带名字段（秒数/HTTP-date），拿不到按估计冷却并标注；retryAt 不早于熔断剩余恢复时间；
// 自动等待有上限，超限不截短服务端要求——返回带绝对可重试时刻的接管信息。
// ════════════════════════════════════════════════════════════════════════════

/** 链尽冷却总开关：AMAGI_CHAIN_COOLDOWN=0 关闭（默认开启；关闭后维持既有链尽 error 终态与 A3 接管建议）。 */
export function isChainCooldownEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	return !(env.AMAGI_CHAIN_COOLDOWN === "0" || env.AMAGI_CHAIN_COOLDOWN === "false");
}

/** 无有效 Retry-After 时的估计冷却时长（默认 90s；AMAGI_CHAIN_COOLDOWN_MS 可调——测试用短值）。 */
export function chainCooldownEstimateMs(env: NodeJS.ProcessEnv = process.env): number {
	const v = Number(env.AMAGI_CHAIN_COOLDOWN_MS);
	return Number.isFinite(v) && v >= 0 ? v : 90_000;
}

/** 自动冷却等待上限（默认 30min；AMAGI_CHAIN_COOLDOWN_MAX_MS 可调，>=1000ms）。服务端要求更久时
 *  不自动排队、不截短——返回带绝对可重试时刻的接管信息。 */
export function chainCooldownMaxWaitMs(env: NodeJS.ProcessEnv = process.env): number {
	const v = Number(env.AMAGI_CHAIN_COOLDOWN_MAX_MS);
	return Number.isFinite(v) && v >= 1000 ? v : 30 * 60 * 1000;
}

/** 单值解析：非负秒数（含小数秒）→ receivedAt + s；HTTP-date → 绝对时刻（过期按 receivedAt 处理）；
 *  负数/NaN/无法解析 → undefined。尾随标点（括号/逗号/分号等事件文本包裹符）先剥再解析。 */
function parseDelayOrDate(candidate: string, receivedAt: number): number | undefined {
	const t = candidate.trim().replace(/^["']+|["']+$/g, "").replace(/[)\]},.;，。；）】」]+$/, "").trim();
	if (!t || t.toLowerCase() === "nan" || t.startsWith("-")) return undefined;
	if (/^\d+(\.\d+)?$/.test(t)) {
		const sec = Number(t);
		if (!Number.isFinite(sec) || sec < 0) return undefined;
		return receivedAt + sec * 1000;
	}
	const ms = Date.parse(t);
	if (Number.isFinite(ms)) return Math.max(ms, receivedAt);
	return undefined;
}

/** 明确带名的 Retry-After 标记（事件文本穿透用：只认带名出现，不从任意数字猜秒数）。 */
const RETRY_AFTER_NAMED_RE = /retry[ -]after\s*[:=]\s*([^\r\n"']+)/i;

/**
 * 解析 Retry-After（穿透事件文本）：value 可为 header 值本身（"120" 秒数或 HTTP-date），或包含
 * 明确带名 `Retry-After: <v>` 的 provider 错误/事件文本（取标记后值段——首 token 为秒数形态则按秒，
 * 否则整段按 HTTP-date）。拒绝 NaN/负秒；过期日期按 receivedAt 处理；无带名且整体不可解析 → undefined。
 */
export function parseRetryAfter(value: string | undefined, receivedAt: number = Date.now()): number | undefined {
	if (typeof value !== "string") return undefined;
	const text = value.trim();
	if (!text) return undefined;
	const named = text.match(RETRY_AFTER_NAMED_RE);
	if (named) {
		// 带名值段先剥尾随标点（事件文本常以括号/引号包裹，如 "Retry-After: 1)"；首 token 剥逗号等分隔符）
		const candidate = named[1].trim().replace(/[)\]},.;，。；）】」]+$/, "").trim();
		const first = (candidate.split(/\s+/)[0] ?? "").replace(/[)\]},.;，。；）】」]+$/, "");
		if (/^\d+(\.\d+)?$/.test(first)) return parseDelayOrDate(first, receivedAt);
		return parseDelayOrDate(candidate, receivedAt);
	}
	return parseDelayOrDate(text, receivedAt);
}

/** 链尽冷却计划（方案 §4.2 拟定接口；exceedsCap=true 时不自动排队——reason 含绝对可重试时刻的接管信息）。 */
export interface ChainExhaustedCooldownPlan {
	/** 冷却到期时刻（epoch ms；到期后以原任务书 fresh 重派最后已尝试模型）。 */
	retryAt: number;
	/** 重试模型（最后已尝试模型；缺省 undefined = 沿用派发解析默认）。 */
	model?: string;
	/** 决策理由（含「估计冷却」标注或超限接管信息）。 */
	reason: string;
	/** true = 无有效带名 Retry-After，按估计冷却（chainCooldownEstimateMs）。 */
	estimated: boolean;
	/** true = 服务端要求 > 自动等待上限——不自动排队、不截短；到 retryAt 时刻可人工重派。 */
	exceedsCap: boolean;
}

function fmtUtc(ms: number): string {
	return `${new Date(ms).toISOString().slice(0, 19).replace("T", " ")} UTC`;
}

/**
 * 链尽冷却决策（纯函数 + 熔断只读输入）：429/限流类且非账号级配额、未取消、零残留、冷却未消费、
 * autoRetry.retries≠0 → 计划 { retryAt, model, reason }；否则 undefined（维持既有 error 终态 + A3）。
 * retryAt = max(带名 Retry-After 时刻 | 估计冷却 now+chainCooldownEstimateMs, breakerUntil)；
 * 等待超 chainCooldownMaxWaitMs → exceedsCap=true（不截短服务端要求）。
 */
export function planChainExhaustedCooldown(o: {
	providerFailure: string;
	lastModel?: string;
	now?: number;
	/** 熔断 Open 的剩余恢复到期时刻（epoch ms；providerBreakerPeek 派生；冷却不得早于它）。 */
	breakerUntil?: number;
	/** 残留检测已确认工作区写入（true = 只给接管，不自动重派——fresh 重跑可能覆盖半成品）。 */
	writesDetected?: boolean;
	cancelled?: boolean;
	/** 本逻辑派发的链尽冷却机会是否已消费（每派发最多一次）。 */
	cooldownUsed?: boolean;
	/** autoRetry 声明（retries=0 = 显式禁止自动重派，连同冷却一起禁用；未声明不限制）。 */
	retryPolicy?: AutoRetryConfig;
}): ChainExhaustedCooldownPlan | undefined {
	if (!isChainCooldownEnabled()) return undefined;
	if (o.cancelled) return undefined;
	if (o.cooldownUsed) return undefined;
	if (o.retryPolicy && o.retryPolicy.retries === 0) return undefined;
	const cause = o.providerFailure || "";
	if (!RATE_LIMIT_SIGNAL_RE.test(cause)) return undefined; // 只认 429/rate-limit 信号（普通脚本输出 429 不算——须同时为 provider 失败根因，由调用方保证）
	if (isAccountQuotaError(cause)) return undefined; // 账号级配额不可恢复：同 provider 冷却必复现，交回 A3（换 provider）
	if (o.writesDetected) return undefined;
	const now = o.now ?? Date.now();
	// Retry-After 只认明确带名出现（方案 §4.2：不从任意数字猜秒数）
	const named = RETRY_AFTER_NAMED_RE.test(cause) ? parseRetryAfter(cause, now) : undefined;
	const estimated = named === undefined;
	const estimateMs = chainCooldownEstimateMs();
	const breakerFloor = typeof o.breakerUntil === "number" && Number.isFinite(o.breakerUntil) ? o.breakerUntil : 0;
	const retryAt = Math.max(estimated ? now + estimateMs : named!, breakerFloor);
	const modelNote = o.lastModel ? `最后模型 ${o.lastModel}` : "原派发模型";
	if (retryAt - now > chainCooldownMaxWaitMs()) {
		return {
			retryAt, model: o.lastModel, estimated, exceedsCap: true,
			reason: `链尽 429/限流，服务端 Retry-After 要求等待至 ${fmtUtc(retryAt)}，超出自动冷却等待上限（${Math.round(chainCooldownMaxWaitMs() / 60000)}min）——不自动重派、不截短服务端要求；到时可用同任务书重派（${modelNote}）或换其他 provider 接管`,
		};
	}
	return {
		retryAt, model: o.lastModel, estimated, exceedsCap: false,
		reason: estimated
			? `链尽 429/限流且未穿透 Retry-After——按估计冷却 ${Math.round(estimateMs / 1000)}s 后以原任务书重派（${modelNote}；估计冷却，非服务端指定）`
			: `链尽 429/限流，Retry-After 已解析——冷却至 ${fmtUtc(retryAt)} 后以原任务书重派（${modelNote}）`,
	};
}
