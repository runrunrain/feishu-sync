/** 自动采集结果的上下文投影；原始终稿与机器检查事实不经过此模块。 */
import { stripVTControlCharacters } from "node:util";
import * as fs from "node:fs";
import { createHash } from "node:crypto";

export interface EvidenceContext {
	test: string;
	notes: string[];
	git: string;
}

interface ArchivedCollectionProjection {
	taskId: string;
	body: string;
	start: number;
	end: number;
	archive: string;
	archiveStat: fs.Stats;
}

// 只接收收尾生产者给出的精确范围，不按正文标题、路径或工具名猜测采集来源。
// 有界登记只用于结果交付前生成来源证明；已落盘的证明不依赖此缓存。
// 旧会话/未取到证明时保守保留，不从历史正文重建来源。
const archivedCollections: ArchivedCollectionProjection[] = [];
const COLLECTION_CACHE_BYTES = 8 * 1024 * 1024;
let collectionCacheBytes = 0;
export const COLLECTION_DETAILS_KEY = "amagiArchivedCollection";
export const TASK_COMPLETION_TYPE = "amagi:task-completion";
interface CollectionSpan {
	part: number; digest: string; start: number; end: number; archive: string;
	file: Pick<fs.Stats, "dev" | "ino" | "size" | "mtimeMs" | "ctimeMs">;
}
interface CollectionProof { version: 1; taskId: string; spans: CollectionSpan[]; }
const digestOf = (text: string): string => createHash("sha256").update(text).digest("hex");

/** 在原生结果落盘前绑定精确正文；恢复仅消费此元数据，不从历史正文猜来源。 */
export function archivedCollectionDetails(content: Array<{ type: string; text?: string }>, taskId: string): CollectionProof | undefined {
	const spans: CollectionSpan[] = [];
	for (let part = 0; part < content.length; part++) {
		const text = content[part]?.type === "text" ? content[part].text : undefined;
		if (typeof text !== "string") continue;
		for (const entry of [...archivedCollections].reverse()) {
			if (entry.taskId !== taskId) continue;
			const offset = text.indexOf(entry.body);
			// 重复引用不能确定附加采集的归属，保守保留。
			if (offset < 0 || text.indexOf(entry.body, offset + 1) >= 0
				|| content.some((other, index) => index !== part && other.type === "text" && other.text?.includes(entry.body))) continue;
			const { dev, ino, size, mtimeMs, ctimeMs } = entry.archiveStat;
			spans.push({ part, digest: digestOf(text), start: offset + entry.start, end: offset + entry.end, archive: entry.archive, file: { dev, ino, size, mtimeMs, ctimeMs } });
			break;
		}
	}
	return spans.length ? { version: 1, taskId, spans } : undefined;
}

export interface TaskCompletionSink {
	sendMessage?: (msg: { customType: string; content: string; display: boolean; details?: Record<string, unknown> }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void;
	sendUserMessage?: (msg: string, opts?: { deliverAs?: "steer" | "followUp" }) => void;
}
export const GROUP_TERMINAL_TYPE = "amagi:group-terminal";
export const MACHINE_NOTICE_TYPE = "amagi:machine-notice";
/** ev-20261101-7fffc6：机器通知统一走 pi 原生 custom 消息通道（role=custom + customType/details 携带
 *  结构化来源；display:true + triggerTurn:steer 对齐旧 sendUserMessage 的用户可见性与自动触发轮）。
 *  旧宿主无 sendMessage 时回退 sendUserMessage（role=user、无来源元数据——该边界如实保留，不按
 *  正文前缀猜测身份）。details 只放真实标识（taskId/runId），不把 groupId 冒充 taskId。 */
export function sendMachineNotice(pi: TaskCompletionSink | undefined, customType: string, text: string, details?: Record<string, unknown>): void {
	if (pi?.sendMessage) pi.sendMessage({ customType, content: text, display: true, ...(details ? { details } : {}) }, { triggerTurn: true, deliverAs: "steer" });
	else pi?.sendUserMessage?.(text, { deliverAs: "steer" });
}
/** 走 pi 原生消息投影/落盘，后台回流与同步结果使用相同来源证明。 */
export function sendTaskCompletion(pi: TaskCompletionSink | undefined, text: string, taskId: string): void {
	const proof = pi?.sendMessage ? archivedCollectionDetails([{ type: "text", text }], taskId) : undefined;
	sendMachineNotice(pi, TASK_COMPLETION_TYPE, text, { taskId, ...(proof ? { [COLLECTION_DETAILS_KEY]: proof } : {}) });
}

export function rememberArchivedCollection(body: string, start: number, end: number, archive: string, taskId: string): void {
	// 每次生产都使旧范围失效；legacy/无归档的新结果也不能误借同任务旧登记。
	for (let i = archivedCollections.length - 1; i >= 0; i--) {
		if (archivedCollections[i].taskId !== taskId) continue;
		collectionCacheBytes -= Buffer.byteLength(archivedCollections[i].body);
		archivedCollections.splice(i, 1);
	}
	if (!taskId || !archive || !Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end <= start || end > body.length) return;
	const bytes = Buffer.byteLength(body);
	if (bytes > COLLECTION_CACHE_BYTES) return;
	let archiveStat: fs.Stats;
	try { archiveStat = fs.lstatSync(archive); if (!archiveStat.isFile()) return; } catch { /* lint-exempt:归档不可验证时拒绝登记，保留正文 */ return; }
	archivedCollections.push({ taskId, body, start, end, archive, archiveStat });
	collectionCacheBytes += bytes;
	while (archivedCollections.length > 128 || collectionCacheBytes > COLLECTION_CACHE_BYTES) {
		collectionCacheBytes -= Buffer.byteLength(archivedCollections.shift()!.body);
	}
}

/** 只投影已经登记的采集范围，任务终稿、附加裁决和其他工具内容均不在范围内。 */
export function pruneArchivedCollectionText(text: string, maxBytes: number, taskId: string, proof: unknown = null, part = 0): string {
	const p = proof as Partial<CollectionProof> | null;
	if (!p || p.version !== 1 || p.taskId !== taskId || !Array.isArray(p.spans)) return text;
	for (const span of p.spans) {
		if (span?.part !== part || span.digest !== digestOf(text) || !Number.isInteger(span.start) || !Number.isInteger(span.end)
			|| span.start < 0 || span.end <= span.start || span.end > text.length || typeof span.archive !== "string" || !span.file) continue;
		const compact = projectCollection(text.slice(span.start, span.end), maxBytes, span.archive, span.file);
		if (compact !== null) return text.slice(0, span.start) + compact + text.slice(span.end);
	}
	return text;
}

function projectCollection(collection: string, maxBytes: number, archive: string, file: CollectionSpan["file"]): string | null {
	if (Buffer.byteLength(collection) <= maxBytes) return null;
	try {
		const current = fs.lstatSync(archive);
		if (!current.isFile() || current.dev !== file.dev || current.ino !== file.ino || current.size !== file.size
			|| current.mtimeMs !== file.mtimeMs || current.ctimeMs !== file.ctimeMs) return null;
	} catch { /* lint-exempt:归档缺失或不可验证时保留正文 */ return null; }
	const reference = `\n[采集详情] ${archive}（按需 read）`;
	const compact = compactAutomaticText(collection, Math.max(0, maxBytes - Buffer.byteLength(reference)), 12) + reference;
	return Buffer.byteLength(compact) < Buffer.byteLength(collection) ? compact : null;
}

/** 终端控制码/进度覆盖只在展示副本清理，归档保留原文。 */
export function cleanAutomaticText(text: string): string {
	return stripVTControlCharacters(text).replace(/\r\n/g, "\n").split("\n")
		.map((line) => line.split("\r").at(-1) ?? "")
		.join("\n").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "");
}

function headUtf8(text: string, bytes: number): string {
	const buf = Buffer.from(text);
	if (buf.length <= bytes) return text;
	let end = Math.max(0, bytes);
	while (end > 0 && (buf[end] & 0xc0) === 0x80) end--;
	return buf.subarray(0, end).toString("utf8");
}

/** 总字节和行数双限幅；截断必须明示，不能让节选被误认为完整证据。 */
export function compactAutomaticText(text: string, maxBytes = 1200, maxLines = 8): string {
	const seen = new Set<string>();
	const lines = cleanAutomaticText(text).split("\n").map((s) => s.trimEnd()).filter((line) => {
		const key = line.trim();
		if (!key || seen.has(key)) return false;
		seen.add(key);
		return true;
	});
	const body = lines.slice(0, maxLines).join("\n");
	if (lines.length <= maxLines && Buffer.byteLength(body) <= maxBytes) return body;
	const note = " …（节选，详情见采集归档）";
	return headUtf8(body, Math.max(0, maxBytes - Buffer.byteLength(note))) + note;
}

/** 优先带回首个失败及邻近诊断，避免测试套件成功行/进度条淹没根因。 */
export function failureExcerpt(stdout: string, stderr: string): string {
	const lines = cleanAutomaticText(`${stderr}\n${stdout}`).split("\n");
	const interesting = /(?:^\s*(?:not ok\b|FAIL\b|✗|×)|\b(?:AssertionError|TypeError|SyntaxError|ReferenceError|ERR_[A-Z_]+)\b|\berror(?:\s+TS\d+)?\s*:)/i;
	const hits = lines.flatMap((line, i) => interesting.test(line) ? [i] : []);
	if (hits.length === 0) return compactAutomaticText(lines.filter((s) => s.trim()).slice(-8).join("\n"), 1200, 8);
	const chosen = new Set<number>();
	for (const i of hits.slice(0, 3)) {
		for (let j = Math.max(0, i - 1); j <= Math.min(lines.length - 1, i + 3); j++) chosen.add(j);
	}
	return compactAutomaticText([...chosen].sort((a, b) => a - b).map((i) => lines[i])
		.filter((line) => !/^\s*(?:ok\s|PASS\s|✓)/i.test(line)).join("\n"), 1200, 8);
}

/** 各通道单独限幅，失败结论不受庞大文件清单挤占；Git 摘要只出现一次。 */
export function renderEvidenceContext(context: EvidenceContext, gitOverride?: string | null): string {
	const parts = [
		compactAutomaticText(context.test, 2000, 12),
		compactAutomaticText(context.notes.join("\n"), 768, 4),
		compactAutomaticText(gitOverride ?? context.git, 1536, 8),
	].filter(Boolean);
	const seen = new Set<string>();
	const body = parts.join("\n").split("\n").filter((line) => {
		const key = line.trim();
		if (seen.has(key)) return false;
		seen.add(key);
		return true;
	}).join("\n");
	return body ? `📋 证据（自动采集·摘要）\n${body}` : "";
}
