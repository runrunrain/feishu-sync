/**
 * panel-widget.ts — 常驻分块面板组件（面板与交互优化 M2-02；交互设计 §7）。
 *
 * setWidget(key, factory) 组件工厂形态（技术方案 D-3；dist interactive-mode.js:1685-1692
 * 证 string[] 才受 MAX_WIDGET_LINES=10 上限，factory 无此限）：四块结构
 * 概要条(无框) → 角色矩阵 → 任务流 → 结算（视觉风格 §4 R-Grid）。
 * 刷新：registry.onChange 立即 + intervalMs 心跳兜底；dispose 退订。
 * 窄终端降级（视觉风格 §9）：<60 列折叠两块（概要+任务流）；<40 列仅概要条。
 * 渲染路径绝不抛错（P2）；数据全部现读 registry（P5 单向流）。
 */

import type { TaskRecord } from "./task-registry.ts";
import { buildPanelModel, type LeaderInfo, type PanelModel } from "./panel-model.ts";
import { boxBlock, budget, entryHint, paint, sectionLine, trimDisplayOf, cellWidthOf, STATUS_STYLE, type ThemeLike } from "./ui-shared.ts";

export interface PanelWidgetRegistry {
	list(): Readonly<TaskRecord>[];
	onChange?(fn: () => void): () => void;
}

export interface PanelWidgetDeps {
	taskRegistry: PanelWidgetRegistry;
	/** Leader 模型面（R8）：现读注入（ctx.model/ctx.thinkingLevel 投影）。 */
	getLeader?: () => LeaderInfo | undefined;
	/** 行预算（默认 12；ui.panel.maxLines 6-24）。 */
	maxLines?: number;
	/** 心跳 ms（默认 2000）。 */
	intervalMs?: number;
	/** 最近结算 TTL（默认 15s，与 status-ui 语义一致）。 */
	settledTtlMs?: number;
	/** 终端列宽读取器（测试注入）。 */
	getColumns?: () => number | undefined;
	/** 测试注入时钟。 */
	now?: () => number;
}

export const PANEL_WIDGET_KEY = "amagi:panel";

/** 渲染面板行（纯函数，可测；theme 可选）。 */
export function renderPanelLines(model: PanelModel, width: number, maxLines = 12, theme?: ThemeLike): string[] {
	const w = Math.max(8, Math.floor(width));
	const full = w - 2; // boxBlock 边框内宽

	// <40 列：仅概要条
	if (w < 40) {
		return [trimDisplayOf(summaryLine(model, w, theme), w)];
	}

	// 概要条（无框，常驻首行；含 ⌥W 入口提示与 leader 模型面 R8）
	const head = trimDisplayOf(summaryLine(model, w, theme), w);

	// 空态收敛为单行（交互设计 §6；f3：仅 leader 模型面；无 leader 则不占行）
	if (model.agents.length === 0 && model.running.length === 0 && model.blocked.length === 0 && model.settled.length === 0) {
		return head.trim() === "" ? [] : [head];
	}

	// <60 列：概要 + 任务流两块
	if (w < 60) {
		const flowLines = flowBlockLines(model, full - 2, theme).slice(0, 6);
		return [head, ...boxBlock({ title: "任务", width: w, lines: flowLines, theme })];
	}

	// 完整四块：行预算（概要 1 行已占）→ 角色 ≤3 / 任务流 ≤5 / 结算 ≤3
	const total = Math.max(4, maxLines) - 1;
	const agentLines = agentMatrixLines(model, full - 2, theme);
	const flowLines = flowBlockLines(model, full - 2, theme);
	const settledLines = settledBlockLines(model, full - 2, theme);
	const alloc = budget(
		[
			{ lines: agentLines, weight: 1, max: 3 },
			{ lines: flowLines, weight: 0, max: 8 }, // 任务流最优先
			{ lines: settledLines, weight: 2, max: 3 },
		],
		total,
	);
	const blocks: string[] = [];
	const cut = (lines: string[], n: number, name: string, more: number): string[] => {
		const shown = lines.slice(0, n);
		if (more > 0 && n > 0) shown.push(paint(theme, "dim", `…还有 ${more} 项（${entryHint("board", ["alt+w"]).split("（")[0]}）`));
		return shown.length > 0 ? shown : [paint(theme, "dim", `（无${name}）`)];
	};
	blocks.push(...boxBlock({ title: `角色${model.hiddenCounts.agents > 0 ? ` · ${model.hiddenCounts.agents} 空闲` : ""}`, width: w, lines: cut(agentLines, alloc[0], "活动角色", Math.max(0, agentLines.length - alloc[0])), theme }));
	blocks.push(...boxBlock({ title: "任务流", width: w, lines: cut(flowLines, alloc[1], "运行任务", Math.max(0, flowLines.length - alloc[1])), theme }));
	if (alloc[2] > 0 || settledLines.length > 0) {
		blocks.push(...boxBlock({ title: "最近结算", width: w, lines: cut(settledLines, alloc[2], "结算", Math.max(0, settledLines.length - alloc[2])), theme }));
	}
	return [head, ...blocks];
}

/**
 * 概要条行（v1.5.218-f3 主上验收反馈）：
 *   空闲（无任何活动/结算）：仅 `leader provider/model:推理强度`；无 leader 信息则空串（面板不渲染）。
 *   活动：`⬤ amagi 2▶ 1⏸ · leader … · ⌥W 编排实况`——⌥W 提示只在有 Agent 活动时出现（名称精简：实况）。
 */
export function summaryLine(model: PanelModel, width: number, theme?: ThemeLike): string {
	const active = model.running.length > 0 || model.blocked.length > 0 || model.settled.length > 0;
	const segs: string[] = [];
	if (active) {
		if (model.summary.text) segs.push(model.summary.text);
		if (model.summary.queued) segs.push(`${model.summary.queued} 排队`);
	}
	if (model.summary.leaderSeg) segs.push(paint(theme, "muted", `leader ${model.summary.leaderSeg}`));
	if (active) segs.push(paint(theme, "dim", "⌥W 实况"));
	return segs.filter(Boolean).join(" · ");
}

function agentMatrixLines(model: PanelModel, inner: number, theme?: ThemeLike): string[] {
	if (model.agents.length === 0) return [];
	const lines: string[] = [];
	let cur = "";
	for (const a of model.agents) {
		const badge = [
			a.running > 0 ? paint(theme, "accent", `▶${a.running}`) : "",
			a.queued > 0 ? paint(theme, "muted", `…${a.queued}`) : "",
			a.blocked > 0 ? paint(theme, "warning", `⏸${a.blocked}`) : "",
		].filter(Boolean).join("");
		const cell = ` ${a.name} ${badge}`;
		if (cellWidthOf(cur) + cellWidthOf(cell) > inner && cur !== "") {
			lines.push(cur);
			cur = cell;
		} else {
			cur += cell;
		}
	}
	if (cur.trim() !== "") lines.push(cur);
	return lines;
}

function flowBlockLines(model: PanelModel, inner: number, theme?: ThemeLike, cap = 16): string[] {
	// cap 为数据硬上限（防极端 registry）；展示截断由 budget 决定以产生 …还有 提示。
	const rows = [...model.running, ...model.blocked].slice(0, cap);
	return rows.map((r) => {
		const sym = r.status === "blocked" ? STATUS_STYLE.blocked : r.status === "queued" ? STATUS_STYLE.queued : STATUS_STYLE.running;
		const painted = paint(theme, sym.color, `${sym.symbol} ${r.agent}`) + " " + paint(theme, "dim", trimDisplayOf(r.summary, Math.max(8, inner - 24)));
		return trimDisplayOf(`${painted} ${paint(theme, "text", r.dur)}`, inner + 2);
	});
}

function settledBlockLines(model: PanelModel, inner: number, theme?: ThemeLike): string[] {
	return model.settled.map((r) => {
		const st = STATUS_STYLE[r.status] ?? STATUS_STYLE.done;
		return trimDisplayOf(`${paint(theme, st.color, st.symbol)} ${r.agent} ${paint(theme, "dim", trimDisplayOf(r.summary, Math.max(8, inner - 12)))}`, inner + 2);
	});
}

export interface PanelWidget {
	/** 注册到 aboveEditor（factory 形态）；非 TUI no-op。 */
	start(): void;
	stop(): void;
	refresh(): void;
}

export interface PanelWidgetCtx {
	mode: string;
	ui: {
		setWidget(key: string, content: string[] | ((tui: unknown, theme: unknown) => unknown) | undefined, options?: { placement?: "aboveEditor" | "belowEditor" }): void;
	};
}

/** 创建并注册常驻面板。渲染行渲染函数暴露给测试（renderPanelLines 已纯函数化）。 */
export function createPanelWidget(deps: PanelWidgetDeps & { ctx: PanelWidgetCtx }): PanelWidget {
	const intervalMs = deps.intervalMs ?? 2000;
	const maxLines = Math.max(6, Math.min(24, deps.maxLines ?? 12));
	let timer: ReturnType<typeof setInterval> | undefined;
	let unsubChange: (() => void) | undefined;
	let requestRender: (() => void) | undefined;
	let lastModel: PanelModel | undefined;
	const now = deps.now ?? Date.now;

	function model(): PanelModel {
		lastModel = buildPanelModel(deps.taskRegistry.list(), now(), {
			leader: deps.getLeader?.(),
			settledTtlMs: deps.settledTtlMs,
		});
		return lastModel;
	}

	const component = {
		render(width: number): string[] {
			try {
				const m = model();
				return renderPanelLines(m, width, maxLines, undefined);
			} catch {
				return []; // P2：渲染失败绝不抛错
			}
		},
		invalidate(): void {},
		dispose(): void {
			requestRender = undefined;
		},
	};

	function start(): void {
		if (timer || deps.ctx.mode !== "tui") return;
		try {
			deps.ctx.ui.setWidget(PANEL_WIDGET_KEY, (tui: unknown, _theme: unknown) => {
				requestRender = () => { try { (tui as { requestRender(): void }).requestRender(); } catch {} };
				return component;
			}, { placement: "aboveEditor" });
		} catch { /* 注册失败静默（不影响编排） */ }
		unsubChange = deps.taskRegistry.onChange?.(() => { try { requestRender?.(); } catch {} });
		timer = setInterval(() => { try { requestRender?.(); } catch {} }, intervalMs);
		timer.unref?.();
	}

	function stop(): void {
		unsubChange?.(); unsubChange = undefined;
		if (timer) { clearInterval(timer); timer = undefined; }
		try { deps.ctx.ui.setWidget(PANEL_WIDGET_KEY, undefined); } catch {}
	}

	return { start, stop, refresh: () => { try { requestRender?.(); } catch {} } };
}

// sectionLine re-export（消费方底栏分隔用，保持 ui-shared 单一来源）
export { sectionLine };
