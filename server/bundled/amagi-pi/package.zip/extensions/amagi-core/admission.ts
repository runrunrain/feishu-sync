/**
 * admission.ts — 共享准入队列（v2 批次B；provider/model 分池限流）。
 *
 * 背景（v2 分析 §5）：此前并发控制分散且语义不一——sync 任务无上限、background 任务
 * MAX_BACKGROUND 超限直接拒绝（整单丢失）、编排分支上限靠 AMAGI_ORCH_MAX_BRANCHES 拒绝。
 * 三条路径各自为政，既无法排队，也无法统一观测排队耗时（queueMs 字段在批次A已落 registry
 * 但没有真实生产者）。
 *
 * 本模块是唯一产品级准入闸：所有 spawn 路径（sync/background/resume/编排分支；RPC 批次D
 * 接入）在 registry.create 后、真实 spawn 前经过 tryOccupy。任务按最终模型 spec 分池——
 * 不同 provider 的 API 并发配额互相独立，全局单槽位会让他们互相争抢：
 *   池键解析（amagi.json `concurrency`，项目键优先，每次读盘即时生效）：
 *   ① spec 去 thinking 档后缀后精确命中 `concurrency.models["provider/model"]` → 独立模型池；
 *   ② 否则池键 = provider（spec 的 `/` 前缀，复用 task-run.providerOfSpec；无前缀 = "default"），
 *      容量 = `concurrency.providers[provider]`；
 *   ③ 未显式配置的池容量 = `concurrency.default`（缺省 4）。AMAGI_ADMISSION_MAX 环境变量
 *      优先于 default 配置值（向后兼容）；显式 providers/models 容量不受 env 影响。
 *
 * 各池独立 FIFO，同池语义与既有契约完全一致：
 *  - tryOccupy 同步原子：返回 "running" 即已占槽；返回 "queued" 即已入队（waitForGrant 取证）。
 *    taskId 即槽位键，幂等——同 taskId 重复调用不改变状态（自动续跑续用同 taskId 不重复占槽、
 *    不换池）；首次占位登记 taskId→池索引，release/取消/查询不带 spec 也能路由回池。
 *  - waitForGrant 仅三种终局："running"（晋级，已占槽）/ "cancelled"（排队中被取消，未占槽）。
 *  - release 幂等：仅 running 持有者调用生效；同步晋级本池队首（resolve 在微任务前已置 running 集，
 *    因此单池容量永不被突破；跨池互不阻塞）。
 *  - cancelQueued 仅对仍在队列者生效；已晋级者由调用方走 running 取消路径（杀进程 + release）。
 *  - 队列不跨重启：registry restore 把 queued 记录恢复为 cancelled（批次B B1），本模块内存
 *    队列随进程消亡，两者天然一致。
 *  - 容量即时生效：占位/晋级/观测均现读 amagi.json（派发频率低，直读可接受，模式对齐
 *    mcp-config.loadMcpRouting）；配置上调容量后，排队者在下一次占位/release 时机按新容量晋级
 *    （占位前先晋级队首——新来者不得越过既有排队者）。
 *
 * K5a（方案 §3.1）依赖解耦：admission 是应用层准入闸，不得反向依赖执行后端 task-run.ts——
 * 模型池键解析下沉为本模块纯函数（providerOfModelSpec/resolveAdmissionPoolKey，与 task-run.providerOfSpec
 * 同语义：spec 首个 "/" 前缀，无前缀 = "default"；由 tests/v2-K5a-submit-path.test.mjs 源码断言 +
 * admission-pools 回归共同锚定）；配置读取保留注入面（injectedConfig/_setAdmissionConfigForTest）+
 * model-resolver 受信配置读取（纯配置模块，非执行后端）。分池 FIFO 行为零变化。
 */

import { loadConcurrencyLimits, stripModelThinkingSuffix, type ConcurrencyLimits } from "./model-resolver.ts";

type GrantResult = "running" | "cancelled";

interface Waiter {
	taskId: string;
	promise: Promise<GrantResult>;
	resolve: (v: GrantResult) => void;
	settled: boolean;
}

interface Pool {
	/** 池键：模型池 = 去 thinking 后缀的 "provider/model"；否则 = provider（无前缀 = "default"）。 */
	key: string;
	/** 模型池键（models 精确命中时才有；容量查 models 表，未命中退 providers[provider]）。 */
	modelKey?: string;
	/** spec 的 provider 段（providerOfSpec；无 `/` = "default"）。 */
	provider: string;
	/** 首次建池时的派发 cwd（项目级 amagi.json 解析基准；跨 cwd 复用同键池时沿用首建 cwd）。 */
	cwd?: string;
	running: Set<string>;
	waiters: Waiter[];
}

const pools = new Map<string, Pool>();
/** taskId → 池键（占槽/入队时登记，release/cancelQueued 移除）——不带 spec 的调用据此路由回池。 */
const taskPoolIndex = new Map<string, string>();
let capacityOverride: number | undefined;
/** 测试注入配置（undefined=未注入走真实读盘；null=显式无配置）。 */
let injectedConfig: ConcurrencyLimits | null | undefined;

const DEFAULT_POOL_KEY = "default";

function readConfig(cwd?: string): ConcurrencyLimits {
	if (injectedConfig !== undefined) return injectedConfig ?? { providers: {}, models: {} };
	return loadConcurrencyLimits(cwd);
}

function envCapacity(): number | undefined {
	const v = Number(process.env.AMAGI_ADMISSION_MAX);
	return Number.isFinite(v) && v >= 1 ? Math.floor(v) : undefined;
}

/** K5a（§3.1 解耦）：model spec → provider 键纯函数（无 provider 前缀 = "default"；与 task-run.providerOfSpec 同语义）。 */
export function providerOfModelSpec(spec?: string): string {
	const i = spec?.indexOf("/") ?? -1;
	return i > 0 ? spec!.slice(0, i) : "default";
}

/** K5a（§3.1 解耦）：池键解析纯函数——models 精确键（去 thinking 后缀）> provider > default。 */
export function resolveAdmissionPoolKey(
	spec: string | undefined,
	cfg: ConcurrencyLimits,
): { key: string; modelKey?: string; provider: string } {
	let modelKey: string | undefined;
	let provider: string;
	if (spec) {
		const stripped = stripModelThinkingSuffix(spec);
		if (cfg.models[stripped] !== undefined) modelKey = stripped;
		provider = providerOfModelSpec(spec);
	} else {
		provider = DEFAULT_POOL_KEY;
	}
	return { key: modelKey ?? provider, ...(modelKey !== undefined ? { modelKey } : {}), provider };
}

function resolvePool(spec: string | undefined, cwd: string | undefined, cfg: ConcurrencyLimits): Pool {
	const { key, modelKey, provider } = resolveAdmissionPoolKey(spec, cfg);
	let pool = pools.get(key);
	if (!pool) {
		pool = { key, modelKey, provider, cwd, running: new Set(), waiters: [] };
		pools.set(key, pool);
	}
	return pool;
}

/** 池容量解析：models 精确键 > providers[provider] > default（env > 配置 > 4）；capacityOverride 为测试级全局覆盖。 */
function capacityOf(pool: Pool, cfgIn?: ConcurrencyLimits): number {
	if (capacityOverride !== undefined) return capacityOverride;
	const cfg = cfgIn ?? readConfig(pool.cwd);
	if (pool.modelKey !== undefined) {
		const m = cfg.models[pool.modelKey];
		if (m !== undefined) return m;
	}
	const p = cfg.providers[pool.provider];
	if (p !== undefined) return p;
	return envCapacity() ?? cfg.default ?? 4;
}

/** 当前 default 池容量（测试覆盖 > 环境变量 > concurrency.default > 默认 4；兼容旧观测入口）。 */
export function admissionCapacity(): number {
	return capacityOf({ key: DEFAULT_POOL_KEY, provider: DEFAULT_POOL_KEY, running: new Set(), waiters: [] });
}

/**
 * 同步原子占位（在所属池内）。有槽→立即占（running 集入键）；满→入该池 FIFO 队尾。
 * 幂等：同 taskId 重复调用不改变状态（自动续跑续用同 taskId 不重复占槽、不换池）。
 * modelSpec = 任务最终模型 spec（如 "zhipuai/glm-5.2:max"）；缺省/无 spec 归 default 池。
 */
export function tryOccupy(taskId: string, opts?: { modelSpec?: string; cwd?: string }): "running" | "queued" {
	const existing = taskPoolIndex.get(taskId);
	if (existing !== undefined) {
		const pool = pools.get(existing);
		if (pool) return pool.running.has(taskId) ? "running" : "queued";
		taskPoolIndex.delete(taskId); // 防御：池已清而索引残留（正常路径不可达）
	}
	const cfg = readConfig(opts?.cwd);
	const pool = resolvePool(opts?.modelSpec, opts?.cwd, cfg);
	promoteNext(pool, cfg); // 容量可能已被配置上调：先按当前容量晋级队首，新来者不得越过既有排队者
	if (pool.running.size < capacityOf(pool, cfg)) {
		pool.running.add(taskId);
		taskPoolIndex.set(taskId, pool.key);
		return "running";
	}
	let resolve!: (v: GrantResult) => void;
	const promise = new Promise<GrantResult>((res) => { resolve = res; });
	pool.waiters.push({ taskId, promise, resolve, settled: false });
	taskPoolIndex.set(taskId, pool.key);
	return "queued";
}

/**
 * 等待晋级/取消。已占槽→立即 "running"；在队→挂起直至 release 晋级或 cancelQueued；
 * 既不在跑也不在队（从未占位或已被取消出队）→ "cancelled"（调用方据此放弃 spawn）。
 */
export function waitForGrant(taskId: string): Promise<GrantResult> {
	const key = taskPoolIndex.get(taskId);
	if (key === undefined) return Promise.resolve("cancelled");
	const pool = pools.get(key);
	if (!pool) return Promise.resolve("cancelled");
	if (pool.running.has(taskId)) return Promise.resolve("running");
	const w = pool.waiters.find((x) => x.taskId === taskId);
	if (!w) return Promise.resolve("cancelled");
	return w.promise;
}

/** 释放槽位（仅 running 持有者生效；幂等）。同步晋级同池队首——容量在 resolve 前已重新占满。
 *
 * A2（ev-20260910-d86779）瞬时故障自动重派的重入契约：重派不占着旧槽位 sleep——失败任务的槽位由
 * 其 onFinalize 链 release 归还，退避定时器在槽位外等待；退避结束后以新 taskId（fresh spawn，
 * 非 resume）走正常 tryOccupy 排到所属池 FIFO 队尾（不插队——既有排队者优先），与排队语义完全一致。
 * 换 model 重派（降级链）自然落入新 provider/model 池，旧池不再被占用。 */
export function release(taskId: string): void {
	const key = taskPoolIndex.get(taskId);
	if (key === undefined) return; // queued/从未占位：no-op（queued 由 cancelQueued 处理）
	const pool = pools.get(key);
	if (!pool) { taskPoolIndex.delete(taskId); return; }
	if (!pool.running.delete(taskId)) return;
	taskPoolIndex.delete(taskId);
	promoteNext(pool);
	cleanupPool(pool);
}

function promoteNext(pool: Pool, cfgIn?: ConcurrencyLimits): void {
	const cap = capacityOf(pool, cfgIn);
	while (pool.running.size < cap && pool.waiters.length > 0) {
		const w = pool.waiters.shift()!;
		if (w.settled) continue;
		w.settled = true;
		pool.running.add(w.taskId);
		w.resolve("running");
	}
}

/** 空池回收（running 与队列均空时从池表移除；索引项已先于本调用清除，不留悬挂）。 */
function cleanupPool(pool: Pool): void {
	if (pool.running.size === 0 && pool.waiters.length === 0) pools.delete(pool.key);
}

/** 取消仍在队列的任务：出队并 resolve "cancelled"。返回是否命中（已晋级/未知返回 false）。 */
export function cancelQueued(taskId: string): boolean {
	const key = taskPoolIndex.get(taskId);
	if (key === undefined) return false;
	const pool = pools.get(key);
	if (!pool) return false;
	const i = pool.waiters.findIndex((w) => w.taskId === taskId);
	if (i < 0) return false;
	const [w] = pool.waiters.splice(i, 1);
	taskPoolIndex.delete(taskId);
	if (!w.settled) {
		w.settled = true;
		w.resolve("cancelled");
	}
	cleanupPool(pool);
	return true;
}

/** 查询任务在准入层的位置（cancel 路径据此分流 queued/running 处理）。 */
export function admissionStateOf(taskId: string): "running" | "queued" | undefined {
	const key = taskPoolIndex.get(taskId);
	if (key === undefined) return undefined;
	const pool = pools.get(key);
	if (!pool) return undefined;
	if (pool.running.has(taskId)) return "running";
	if (pool.waiters.some((w) => w.taskId === taskId)) return "queued";
	return undefined;
}

/** 单池观测行（key/capacity/running/queued）。 */
export interface AdmissionPoolStats {
	key: string;
	capacity: number;
	running: number;
	queued: number;
}

/**
 * 观测快照（面板/排队文案/测试断言用）。向后兼容：capacity/running/queued 为全池聚合
 * （capacity=各活动池容量之和；无活动池时=default 池容量），pools 为逐池明细。
 */
export function admissionStats(): { capacity: number; running: number; queued: number; pools: AdmissionPoolStats[] } {
	const list: AdmissionPoolStats[] = pools.size === 0
		? [{ key: DEFAULT_POOL_KEY, capacity: admissionCapacity(), running: 0, queued: 0 }]
		: [...pools.values()].map((pool) => ({ key: pool.key, capacity: capacityOf(pool), running: pool.running.size, queued: pool.waiters.length }));
	return {
		capacity: list.reduce((s, p) => s + p.capacity, 0),
		running: list.reduce((s, p) => s + p.running, 0),
		queued: list.reduce((s, p) => s + p.queued, 0),
		pools: list,
	};
}

/** 多池观测摘要（排队文案用）：单池零噪声省略；多池附「键 在跑/容量·排队数」逐池明细。 */
export function admissionPoolNote(stats: { pools: AdmissionPoolStats[] }): string {
	if (stats.pools.length <= 1) return "";
	return `；分池: ${stats.pools.map((p) => `${p.key} ${p.running}/${p.capacity}${p.queued ? `·${p.queued}排` : ""}`).join("，")}`;
}

/** 测试：全局容量覆盖（undefined 恢复环境变量/配置/默认；对全部池生效——单池语义见 _setAdmissionConfigForTest）。 */
export function _setAdmissionCapacityForTest(n?: number): void {
	capacityOverride = typeof n === "number" && Number.isFinite(n) && n >= 1 ? Math.floor(n) : undefined;
	for (const pool of pools.values()) promoteNext(pool); // 容量上调后立即晋级可晋级者
}

/** 测试：注入/清除分池配置（null=显式无配置；缺省 undefined 走真实读盘路径）。容量可能上调，注入后立即晋级。 */
export function _setAdmissionConfigForTest(cfg: ConcurrencyLimits | null): void {
	injectedConfig = cfg;
	for (const pool of pools.values()) promoteNext(pool);
}

/** 测试隔离：清空全部状态（未决 waiter 以 cancelled 收口，不留悬挂 promise）。 */
export function resetAdmissionForTest(): void {
	for (const pool of pools.values()) {
		for (const w of pool.waiters.splice(0)) {
			if (!w.settled) { w.settled = true; w.resolve("cancelled"); }
		}
	}
	pools.clear();
	taskPoolIndex.clear();
	capacityOverride = undefined;
	injectedConfig = undefined;
}
