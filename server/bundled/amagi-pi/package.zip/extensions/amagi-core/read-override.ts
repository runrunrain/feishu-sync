/**
 * read-override.ts — ev-20260925-287e93（双宿主根治 §2.2）：同名覆盖内置 read——POSIX 绝对
 * 路径按 bash 运行时宿主重定向（win32 宿主 + bash 跑在 WSL 的 codebox 双宿主架构）。
 *
 * 痛点（复盘 §2.2「跨工具文件系统分裂」）：read 在 Windows 侧按当前盘根解析 POSIX 绝对路径
 * （/tmp/x.py → X:\tmp\x.py）——bash（WSL）侧文件永远读不到；write/edit 已按同源语义重定向
 * （write-override / edit-override），若 read 不跟进，被重定向落盘到 WSL 文件系统的文件在本
 * 工具回读时仍错位——三件套必须同口径闭环，跨工具传文件才真正双侧一致。
 *
 * 机制与 write-override 同构（pi extensions.md「Overriding Built-in Tools」官方模式）：
 * 非 POSIX 绝对路径（或非 win32 宿主）零改写、全参数委托原生定义（截断/图片附件/abort 语义
 * 全原生）；POSIX 绝对路径重定向：/mnt/<盘>/P → <盘>:\P（drvfs 同一文件系统，确定性映射、
 * 零探测）；其余（/home、/tmp 等 WSL 内部路径）→ \\wsl.localhost\<distro><P>（9P UNC，需
 * distro 已知——探测失败不重定向，维持原语义，让原生 ENOENT 如实暴露）。
 * 提示与渲染元数据继承原生定义，避免宿主升级后手写文案漂移。
 * 所有宿主注册可选范围引用；未请求引用的读取继续直接委托原生。
 */

import { createReadToolDefinition } from "@earendil-works/pi-coding-agent";
import * as fs from "node:fs";
import { Type } from "typebox";
import { isPosixStyleAbsolutePath, posixToWindowsVisible, probeBashRuntime, type BashRuntimeInfo } from "./runtime-env.ts";
import { resolveBuiltinConstrainedSampling } from "./host-capabilities.ts";
import { builtinFileCwd } from "./builtin-file-target.ts";
import { fileReadPermissionBlockReason, getActiveFilePermissionEnforcer } from "./file-permission.ts";
import { defaultEditSnapshots, recordEditingRegistration, snapshotNotice, snapshotScope, snapshotText, type EditSnapshotStore } from "./edit-snapshot.ts";
import { EditFailure } from "./edit-recovery.ts";

export interface ReadOverrideDeps {
	snapshots?: EditSnapshotStore;
	/** 工作目录（缺省 process.cwd()）。 */
	cwd?: string;
	/** 宿主平台注入（测试；缺省 process.platform）。 */
	hostPlatform?: string;
	/** bash 运行时探测注入（测试；缺省 runtime-env 模块级缓存探测）。 */
	bashRuntime?: (baseCwd?: string) => BashRuntimeInfo;
}

/** POSIX 绝对路径 → WSL 侧可见路径（非可重定向形态返回原值，绝不抛错）。 */
function redirectToWindowsVisible(p: string, baseCwd: string, deps: ReadOverrideDeps): string {
	const raw = p;
	if (!raw || !isPosixStyleAbsolutePath(raw)) return p;
	let target = posixToWindowsVisible(raw, { probed: false, wsl: false });
	if (target === null) {
		try {
			const info = deps.bashRuntime ? deps.bashRuntime(baseCwd) : probeBashRuntime(baseCwd);
			target = posixToWindowsVisible(raw, info);
		} catch { /* lint-exempt:探测失败不重定向——维持原语义，原生 ENOENT 如实暴露 */ }
	}
	return target ?? p;
}

/** Optional observed-range references plus win32 path redirection; ordinary reads delegate unchanged. */
export function createReadOverrideTool(baseCwd: string = process.cwd(), deps: ReadOverrideDeps = {}) {
	const baseDef = createReadToolDefinition(baseCwd);
	const snapshots = deps.snapshots ?? defaultEditSnapshots;
	return {
		...baseDef,
		name: "read" as const,
		label: "read",
		description: `${baseDef.description} Optional editReference:true issues a version-checked reference for fully shown text lines, for long rewrites using edit selection. Ordinary reads are unchanged.`,
		parameters: Type.Object({ ...baseDef.parameters.properties, editReference: Type.Optional(Type.Boolean({ description: "Return a session-local reference for fully shown text lines; use before long whole-line rewrites without repeating oldText." })) }),
		outputSchema: baseDef.outputSchema,
		constrainedSampling: resolveBuiltinConstrainedSampling(),
		async execute(
			toolCallId: string,
			args: { path: string; offset?: number; limit?: number; editReference?: boolean },
			signal: AbortSignal | undefined,
			onUpdate: ((partial: unknown) => void) | undefined,
			ctx: unknown,
		) {
			if ((deps.hostPlatform ?? process.platform) === "win32" && typeof args?.path === "string") {
				args = { ...args, path: redirectToWindowsVisible(args.path, builtinFileCwd(baseCwd, ctx), deps) };
			}
			if (args.editReference !== true) return await baseDef.execute(toolCallId, args, signal, onUpdate as never, ctx as never);
			args = { ...args };
			if (args.offset === null) delete args.offset;
			if (args.limit === null) delete args.limit;
			if ((args.offset !== undefined && args.offset !== null && (!Number.isSafeInteger(args.offset) || args.offset < 1))
				|| (args.limit !== undefined && args.limit !== null && (!Number.isSafeInteger(args.limit) || args.limit < 1))) throw new EditFailure("invalid-input", "范围引用需要正整数 offset/limit。");
			const cwd = builtinFileCwd(baseCwd, ctx);
			const readReason = fileReadPermissionBlockReason(cwd, args.path);
			if (readReason) throw new EditFailure("permission", readReason);
			// Images retain the native decoder and structured output. References only cover text.
			if (/\.(png|jpe?g|gif|webp|bmp|svg|avif)$/i.test(args.path)) return await baseDef.execute(toolCallId, args, signal, onUpdate as never, ctx as never);
			let captured: { file: string; canonicalPath: string; bytes: Buffer } | undefined;
			const capture = createReadToolDefinition(baseCwd, { operations: {
				access: async file => {
					const reason = fileReadPermissionBlockReason(cwd, file, false);
					if (reason) throw new EditFailure("permission", reason);
					await fs.promises.access(file, fs.constants.R_OK);
				},
				readFile: async file => {
					const reason = fileReadPermissionBlockReason(cwd, file, false);
					if (reason) throw new EditFailure("permission", reason);
					const canonicalPath = fs.realpathSync.native(file);
					const bytes = await fs.promises.readFile(file);
					if (fs.realpathSync.native(file) !== canonicalPath) throw new EditFailure("path-mismatch", "读取期间路径目标变化；请重新读取。");
					snapshotText(bytes); // unsupported/image bytes fall back to the untouched native reader
					captured = { file, canonicalPath, bytes };
					return bytes;
				},
			} });
			let result: Awaited<ReturnType<typeof baseDef.execute>>;
			try { result = await capture.execute(toolCallId, args, signal, onUpdate as never, ctx as never); }
			catch (error) {
				if (!(error instanceof EditFailure) || error.code !== "unsupported-content") throw error;
				return await baseDef.execute(toolCallId, args, signal, onUpdate as never, ctx as never);
			}
			let notice: string;
			try {
				if (!captured || result.details?.truncation?.truncated) throw new EditFailure("unobserved-range", "读取被截断；请缩小 offset/limit 后取得范围引用。");
				const rawLines = captured.bytes.toString("utf8").split("\n");
				const start = (args.offset ?? 1) - 1;
				const end = Math.min(start + (args.limit ?? rawLines.length), rawLines.length);
				const shown = rawLines.slice(start, end).join("\n");
				const text = result.content[0];
				if (text?.type !== "text" || (text.text !== shown && !text.text.startsWith(`${shown}\n\n[`))) throw new EditFailure("unobserved-range", "无法验证原生读取的完整展示范围；未签发引用。");
				const snapshot = snapshots.issue(captured.file, captured.bytes, snapshotScope(cwd, ctx, getActiveFilePermissionEnforcer()), start + 1,
					Math.min(end, snapshotText(captured.bytes).lines.length));
				if (snapshot.canonicalPath !== captured.canonicalPath) throw new EditFailure("path-mismatch", "读取期间路径目标变化；未签发引用，请重新读取。");
				notice = snapshotNotice(snapshot);
			} catch (error) {
				if (!(error instanceof EditFailure)) throw error;
				notice = error.message;
			}
			return { ...result, content: [...result.content, { type: "text" as const, text: notice }],
				...(typeof result.structuredContent === "string" ? { structuredContent: `${result.structuredContent}\n\n${notice}` } : {}) };
		},
	};
}

// ── 注册器 ──────────────────────────────────────────────────────────────────

export interface ReadOverridePi {
	registerTool(tool: unknown): void;
}

/**
 * 注册 read 覆盖版：注册失败由调用方静默降级（原生 read 不受影响）——read 无权限执法点
 * （纯读取），无 write/edit 的严格任务 fail-closed 语义。
 */
export function registerReadOverrideTool(pi: ReadOverridePi, deps: ReadOverrideDeps = {}): void {
	pi.registerTool(createReadOverrideTool(deps.cwd ?? process.cwd(), deps));
	recordEditingRegistration(pi, "read", deps.snapshots ?? defaultEditSnapshots);
}
