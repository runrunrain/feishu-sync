/**
 * shell-env.ts — ev-20261020-d56baa：项目级 PATH 前缀声明（amagi.json shell.pathPrepend）。
 *
 * 根因：用户级工具链（pip --user 的 cmake/ctest 等）只装在用户目录，不在子 Agent 与
 * harness spawn 的 PATH 里——run_bg exit 127、每次 bash 手动 export、任务书重复抄写 PATH。
 * 修复：项目 amagi.json 声明 `shell.pathPrepend: string[]`（绝对路径、存在性校验），
 * amagi 控制的四个 spawn 点同源注入：
 *   1. bash 工具 spawnHook（bash-override.ts——宿主原生 bash 经 amagi 覆盖注册，spawn 前
 *      env 可调，这是 amagi 对前台 bash 的唯一控制点）；
 *   2. run_bg 后台命令（run-bg.ts spawn）；
 *   3. 子 Agent pi 进程（task-run.ts buildMinimalEnv——子进程继承后其内部 bash/run_bg
 *      的 PATH 天然携带）；
 *   4. 自动基线测试执行（evidence.ts defaultRunCmd——与 ev-20261020-c8ca99 的声明测试命令
 *      共用同一注入）。
 *
 * 边界（如实）：宿主进程自身的 process.env 不被改写（注入都发生在 spawn 副本上）；
 * 非 amagi 控制的进程（用户手工终端、其它 IDE）不受影响。exit 127 的既有 Bash 诊断软提示
 * 指引声明本字段（guards.ts）。
 *
 * 容错口径与 evidenceTimeouts/concurrency 段一致：非法值（非数组/非字符串/相对路径/不存在的
 * 目录）跳过该条并收集 problems（doctor 诊断；不阻断派发）。每次读取现盘（KB 级文件，
 * bash spawn 频率下 fs 开销微秒级；与 mcp 段调用时读取同口径，改动即时生效）。
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

// ─────────────────────────────────────────────────────────────────────────────
// ev-20261101-bcee0f：常见用户级工具目录自动发现
// ─────────────────────────────────────────────────────────────────────────────
// 根因：用户级工具链（pip --user 的 cmake/ctest 装在 ~/Library/Python/<ver>/bin 或 ~/.local/bin、
// Homebrew keg-only cmake 在 /opt/homebrew/opt/cmake/bin、CMake.app 在 /Applications/CMake.app/
// Contents/bin）不随非交互 shell 的 PATH 继承——探测型基线入口（ctest 等）在 pathPrepend/binDirs/
// 宿主 PATH 均未命中时预检仍称「已解析入口」，执行 spawn ENOENT 记 error → settlement=incomplete
// → 每次 accept 强制 waive。本节提供有界只读探测：存在的用户级 bin 目录供工具定位与 spawn PATH
// **补充**（追加在宿主 PATH 之后——PATH 已能解析的工具优先级零变化，只在解析不到时兜底命中）。

/** ~/Library/Python 下版本目录形态（3.9/3.13 等；版本数值降序，实际安装的全部入池）。 */
const PYTHON_VERSION_DIR = /^\d+\.\d+$/;

/**
 * 发现常见用户级工具 bin 目录（存在才收；声明序稳定）。纯只读 stat/readdir，无 spawn 无副作用——
 * 供探测预检（tokenResolvableInPath）、入口解析（locateToolToken）与实际 spawn（defaultRunCmd）
 * 共用同一份候选目录（预检与执行同源，ev-20261101-bcee0f）。
 * 候选集（按平台）：~/.local/bin、~/bin、~/.cargo/bin、~/go/bin；darwin 另含
 * ~/Library/Python/<ver>/bin（pip --user 实际安装位）、/opt/homebrew/bin、/opt/homebrew/opt/cmake/bin
 * （keg-only）、/Applications/CMake.app/Contents/bin、/usr/local/bin；win32 另含 %LOCALAPPDATA%\Python\Scripts。
 * homedir 可注入（测试隔离）；缺省 os.homedir()（POSIX 读 $HOME 现值）。
 */
export function discoverUserToolBinDirs(opts?: { homedir?: string }): string[] {
	const home = path.resolve(opts?.homedir ?? os.homedir());
	const candidates: string[] = [
		path.join(home, ".local", "bin"),
		path.join(home, "bin"),
		path.join(home, ".cargo", "bin"),
		path.join(home, "go", "bin"),
	];
	if (process.platform === "darwin") {
		// pip --user（macOS）：~/Library/Python/<ver>/bin——M01 实战 ctest 的实际安装位。
		// 版本按数值降序（新版本优先——字母序会把 3.9 排在 3.10 之后，M01 实战形态反而靠后）；
		// steer #4：不设目录数上限——固定候选有限，Python 版本目录以实际安装为界（天然有界），
		// 任意截断会把 CMake.app/Python 旧版本再次饿死；工具定位按具体工具名查找，不限制目录能力。
		try {
			const verKey = (s: string): [number, number] => [Number(s.split(".")[0]) || 0, Number(s.split(".")[1]) || 0];
			const versions = fs.readdirSync(path.join(home, "Library", "Python"), { withFileTypes: true })
				.filter((e) => e.isDirectory() && PYTHON_VERSION_DIR.test(e.name)).map((e) => e.name)
				.sort((a, b) => { const [am, an] = verKey(a); const [bm, bn] = verKey(b); return bm - am || bn - an; });
			candidates.splice(1, 0, ...versions.map((v) => path.join(home, "Library", "Python", v, "bin")));
		} catch { /* lint-exempt:目录不存在/不可读 → 无 pip --user 目录（有界只读，如实跳过） */ }
		candidates.push("/opt/homebrew/bin", "/opt/homebrew/opt/cmake/bin", "/Applications/CMake.app/Contents/bin", "/usr/local/bin");
	} else if (process.platform === "win32") {
		const localAppData = process.env.LOCALAPPDATA;
		if (localAppData) candidates.push(path.join(localAppData, "Python", "Scripts"));
	}
	const out: string[] = [];
	for (const dir of candidates) {
		if (out.includes(dir)) continue;
		try {
			if (fs.statSync(dir).isDirectory()) out.push(dir);
		} catch { /* lint-exempt:候选目录不存在 → 不收（存在才收，无副作用） */ }
	}
	return out;
}

/** 项目 shell 段解析结果：dirs 为通过校验的前置目录（保持声明序）；problems 为被跳过项的归因。 */
export interface ProjectShellPathPrepend {
	dirs: string[];
	problems: string[];
}

/** pathPrepend 目录数量上限（有界声明；超出截断并入 problems——防滥用把 PATH 撑爆）。 */
export const SHELL_PATH_PREPEND_MAX = 16;

/**
 * 读取 <cwd>/amagi.json 的 shell.pathPrepend（项目级声明）。
 * 容错：文件缺失/不可读/非法 JSON/段形状非法 → { dirs: [], problems: [] }（现状行为零变化）。
 * 单条校验：非空字符串 + 绝对路径 + 存在且为目录；非法条目跳过并记 problems。
 * readFileSync 可注入供测试隔离。
 */
export function readProjectShellPathPrepend(
	cwd: string | undefined,
	readFileSync: (p: string, enc: "utf8") => string = (p, enc) => fs.readFileSync(p, enc),
): ProjectShellPathPrepend {
	if (typeof cwd !== "string" || !cwd) return { dirs: [], problems: [] };
	let raw: string;
	try {
		raw = readFileSync(path.join(cwd, "amagi.json"), "utf8");
	} catch { return { dirs: [], problems: [] }; /* lint-exempt:文件缺失/不可读 → 零声明零问题（容错口径同 evidenceTimeouts） */ }
	let parsed: unknown;
	try {
		parsed = JSON.parse(raw);
	} catch { return { dirs: [], problems: [] }; /* lint-exempt:非法 JSON → 容错回退零声明（不阻断派发） */ }
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return { dirs: [], problems: [] };
	const section = (parsed as Record<string, unknown>).shell;
	if (section === undefined) return { dirs: [], problems: [] };
	if (section === null || typeof section !== "object" || Array.isArray(section)) {
		return { dirs: [], problems: ["shell.pathPrepend 必须是字符串数组（绝对路径），实际不是"] };
	}
	const list = (section as Record<string, unknown>).pathPrepend;
	if (list === undefined) return { dirs: [], problems: [] };
	if (!Array.isArray(list)) return { dirs: [], problems: ["shell.pathPrepend 必须是字符串数组（绝对路径），实际不是"] };
	const dirs: string[] = [];
	const problems: string[] = [];
	for (let i = 0; i < list.length; i++) {
		const v = list[i];
		if (typeof v !== "string" || v.trim() === "") {
			problems.push(`shell.pathPrepend[${i}] 必须是非空字符串，实际: ${String(v)}`);
			continue;
		}
		if (!path.isAbsolute(v)) {
			problems.push(`shell.pathPrepend[${i}]=${v} 必须是绝对路径（相对路径随执行 cwd 漂移，不收）`);
			continue;
		}
		if (dirs.length >= SHELL_PATH_PREPEND_MAX) {
			problems.push(`shell.pathPrepend 声明超 ${SHELL_PATH_PREPEND_MAX} 条，第 ${i + 1} 条起忽略`);
			break;
		}
		try {
			const st = fs.statSync(v);
			if (!st.isDirectory()) {
				problems.push(`shell.pathPrepend[${i}]=${v} 不是目录`);
				continue;
			}
		} catch {
			problems.push(`shell.pathPrepend[${i}]=${v} 不存在或不可访问`); /* lint-exempt:不可访问目录如实归因到 problems（doctor 可见，不静默） */
			continue;
		}
		dirs.push(v);
	}
	return { dirs, problems };
}

/**
 * PATH 前置构造（纯函数）：返回新 PATH 字符串。声明目录**真正前置**——已在 PATH 中的目录
 * 也移到最前（ev-20261111-fix，diting F01 最小修复方向「保持已存在目录也能真正前置的次序
 * 语义」：旧实现见 seen 集去重会把已存在目录留在原位，pathPrepend 声明被 PATH 中更早的
 * 同名工具遮蔽而不生效）；声明序内去重、其余 PATH 条目保持原相对次序。
 */
export function prependPathEntries(currentPath: string | undefined, prependDirs: readonly string[]): string {
	// 空 PATH 条目表示执行 cwd；与相对目录一样保留 execvp 语义。
	const existing = currentPath === undefined ? [] : currentPath.split(path.delimiter);
	const seen = new Set<string>();
	const add: string[] = [];
	for (const d of prependDirs) {
		if (!d) continue;
		const key = path.resolve(d);
		if (seen.has(key)) continue; // 声明序内去重（子 Agent 继承注入后幂等）
		seen.add(key);
		add.push(d);
	}
	if (add.length === 0) return existing.join(path.delimiter);
	// 真正前置：已存在的声明目录从原位移除后置于最前，不被 PATH 中更早的同名工具遮蔽
	const rest = existing.filter((p) => !seen.has(path.resolve(p)));
	return [...add, ...rest].join(path.delimiter);
}

/**
 * spawn env 的 PATH 前置（浅拷贝，不改入参；dirs 为空返回原引用——零开销零变化）。
 * 消费点：bash spawnHook / run_bg spawn / 子 Agent spawn / 证据命令 defaultRunCmd。
 */
export function envWithPathPrepend<T extends Record<string, string | undefined>>(env: T, prependDirs: readonly string[]): T {
	if (prependDirs.length === 0) return env;
	return { ...env, PATH: prependPathEntries(env.PATH, prependDirs) };
}

/**
 * 首 token 可解析性检查（无 spawn，纯 fs 扫描）：目录 = 声明 pathPrepend ∪ 系统 PATH ∪ 自动
 * 发现的用户级工具目录（ev-20261101-bcee0f，追加在 PATH 后——PATH 已可解析者优先）。
 * POSIX 追加可执行位校验；win32 只验存在（与 evidence.ts resolveScriptBinChain ③ 同口径）。
 * 供声明测试命令的 argv[0] 预检（探测不产出必败命令）与 doctor 语义校验共用。
 *
 * ev-20261111-fix（diting F03/F04）：配置根与执行目录分离——pathPrepend 从受信配置根
 * （configRoot，探测/验证根）读取，**不随执行 cwd 漂移、不向上搜索**；显式相对 token
 * （含路径分隔符）按实际 execDir 解析并校验普通文件 + POSIX 执行位（旧实现 fs.statSync(token)
 * 相对 harness 进程 cwd 解析，多项目/子目录声明被误判 plan-bin-missing——diting F03 实证）。
 * 入参支持 ExecutionEnv（推荐）或旧字符串形态（configRoot=execDir 兼容直调）。
 */
export function tokenResolvableInPath(
	token: string,
	env: string | { configRoot: string | undefined; execDir?: string },
	readFileSync?: (p: string, enc: "utf8") => string,
): boolean {
	const configRoot = typeof env === "string" ? env : env.configRoot;
	const execDir = typeof env === "string" ? env : (env.execDir ?? env.configRoot);
	if (token && (token.includes("/") || token.includes("\\"))) {
		// 含路径分隔符的 token 按显式路径处理（声明面已允许绝对/相对 argv[0]）：相对 execDir 解析，
		// 须为普通文件且（POSIX）有执行位——与实际 spawn 的解析同源（F03：不再按进程 cwd 误判）。
		const abs = path.isAbsolute(token) ? token : path.resolve(execDir ?? ".", token);
		let st: fs.Stats;
		try { st = fs.statSync(abs); } catch { return false; /* lint-exempt:显式路径不可解析 → 如实不可用 */ }
		if (!st.isFile()) return false;
		if (process.platform === "win32") return true;
		try { fs.accessSync(abs, fs.constants.X_OK); return true; } catch { return false; /* lint-exempt:无执行位不可执行 */ }
	}
	const dirs = [...readProjectShellPathPrepend(configRoot, readFileSync).dirs, ...(process.env.PATH ?? "").split(path.delimiter), ...discoverUserToolBinDirs()];
	for (const d of dirs) {
		const full = path.resolve(execDir ?? ".", d, token);
		let st: fs.Stats;
		try { st = fs.statSync(full); } catch { continue; /* lint-exempt:单目录探测失败跳下一个候选（无 spawn 纯扫描） */ }
		if (!st.isFile()) continue;
		if (process.platform === "win32") return true;
		try {
			fs.accessSync(full, fs.constants.X_OK);
			return true;
		} catch { continue; /* lint-exempt:单个候选无执行位跳过（win32 只验存在） */ }
	}
	return false;
}

/**
 * 有效执行环境（ev-20261111-fix，diting F01/F03/F04 根因归并：「有效执行环境」此前没有作为
 * 单一对象从计划传递到解析/预检/doctor/spawn，各消费点各自重算——pathPrepend 声明目录遮蔽
 * 宿主 PATH 时入口判定与实际执行不同源（F01），子 cwd 执行丢根配置（F04），相对入口按进程
 * cwd 误判（F03））。本对象是唯一解析入口：受信根配置（configRoot 一次读取，不随执行目录
 * 漂移、不无界向上搜索）→ PATH 次序（prependDirs → binDirs → 宿主 PATH）+ 相对入口的
 * execDir 解析基准。消费点：declaredTestOf/tokenResolvableInPath（探测预检）、doctor
 * （configuration-diagnostics）、resolveCommandEntry（入口身份）、defaultRunCmd（实际 spawn）。
 */
export interface ExecutionEnv {
	/** 受信配置根（读 amagi.json 的目录）：探测/验证根——快照执行时是源验证根，不是对象内子 cwd。 */
	configRoot: string;
	/** 实际执行目录：相对入口 token 的解析基准（与 spawn cwd 同源）。缺省 = configRoot。 */
	execDir: string;
	/** shell.pathPrepend 声明目录（来自 configRoot 的受信配置；保持声明序）。 */
	prependDirs: readonly string[];
	/** 计划 bin 目录（绝对；探测推导链，如 workspace .bin）。 */
	binDirs: readonly string[];
	/** 自动发现的常见用户级工具目录（ev-20261101-bcee0f；追加在宿主 PATH 之后——PATH 已可解析的
	 *  工具优先级不变，只在解析不到时兜底）。预检/入口解析/spawn 共用。 */
	discoveredDirs: readonly string[];
}

/** 解析有效执行环境（单一对象；configRoot 为受信读取点，execDir/binDirs 缺省为根/空）。 */
export function resolveExecutionEnv(opts: { configRoot: string; execDir?: string; binDirs?: readonly string[] }): ExecutionEnv {
	const configRoot = path.resolve(opts.configRoot);
	const execDir = opts.execDir === undefined ? configRoot : path.resolve(opts.execDir);
	const binDirs = (opts.binDirs ?? []).filter((d): d is string => typeof d === "string" && d.length > 0);
	return { configRoot, execDir, prependDirs: readProjectShellPathPrepend(configRoot).dirs, binDirs, discoveredDirs: discoverUserToolBinDirs() };
}
