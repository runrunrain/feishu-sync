/**
 * transform-display.ts — 显示层 markdown 变换：绝对路径链接化（8月迭代 pi-0.84 配合 P2⑦）。
 *
 * 依据（pi 0.84.4 docs/extensions.md registerMarkdownTransformer）：
 *   - 渲染层原生渲染 markdown 链接，并做终端 hyperlink（OSC8）能力检测——无能力终端
 *     自动降级纯文本。因此本模块只产出标准 `[path](file://path)` 形态，不裸发转义码，
 *     零垃圾字符风险；
 *   - transformer 链式执行（扩展加载序），display-only：session 与模型上下文原文不变；
 *     新消息/流式增量/恢复会话/列宽变化都会重跑 → 必须同步、廉价、无状态。
 *
 * linkifyPaths 纯函数替换面（两形态，均要求绝对路径）：
 *   1. 反引号包裹：`` `/Users/a/b.md` `` → `[/Users/a/b.md](file:///Users/a/b.md)`
 *      （反引号移除、路径文本保留；路径须紧贴两侧反引号，防止误吞句中片段）；
 *   2. 行首裸路径（允许前导空白）：同样链接化；行中裸路径不动（避免误伤句子内斜杠串）。
 *   - POSIX（/ 开头且至少两段）与 Windows 盘符（C:\ 或 C:/）都识别；
 *   - maxLinks（默认 20）为总替换上限，超出不再替换（长输出防刷屏）；
 *   - 已是 `](file://…)` 形态的链接目标不重复包裹——两形态锚定（紧贴反引号/行首紧贴
 *     缩进）天然跳过 `[x](file://…)`（其行首字符是 `[`，反引号内容以 `file` 开头）。
 *
 * isStreaming 与 assistant-thinking 不在本函数处理——由注册处 registerDisplayTransforms
 * 统一跳过（流式分片会被链接语法撕裂，thinking 折叠区无需交互）。
 */

import { pathToFileURL } from "node:url";

/** 路径段字符：排除空白、反引号（\x60）、markdown 结构字符与路径分隔符 / \。 */
const SEG = String.raw`[^\s\x60<>()\[\]'"\\/]+`;

/** POSIX 绝对路径：/ 开头且至少两段（/a/b；单段 /tmp 不链接——多为缩写引用）。 */
const POSIX_PATH = String.raw`\/${SEG}(?:\/${SEG})+`;

/** Windows 盘符绝对路径：C:\ 或 C:/ 开头（C:\file.md 即绝对，不强制两段）。 */
const WIN_PATH = String.raw`[A-Za-z]:[\/\\]${SEG}(?:[\/\\]${SEG})*`;

/** 绝对路径候选（POSIX 优先，Windows 次之）。 */
const ABS_PATH = `(?:${POSIX_PATH}|${WIN_PATH})`;

/** 反引号包裹形态：路径紧贴两侧反引号（整条反引号内容恰为绝对路径才替换）。 */
const BACKTICK_PATH_RE = new RegExp(String.raw`\x60(${ABS_PATH})\x60`, "g");

/** 行首裸形态：行首仅空白（空格/Tab，不含换行）后直接是绝对路径。 */
const LINE_START_PATH_RE = new RegExp(`^([ \\t]*)(${ABS_PATH})`, "gm");

/** 行首裸路径尾随标点剥离（路径段允许 `.`，末尾句读标点不属于路径）。 */
const TRAILING_PUNCT_RE = /[.,;:!?…、。，；：！？"']+$/;

export const DEFAULT_MAX_LINKS = 20;

/** 绝对路径 → file:// URL：node:url pathToFileURL 负责百分号编码（空格/中文/井号等保留字符）与
 * Windows 盘符（file:///C:/…，RFC 8089）；入参先「\ 归一为 /」（URL 反斜杠兼容性差）。
 * diting 修复轮 Minor-6：原手工拼接未编码保留字符，含空格/中文路径产出的链接 href 断链。 */
function toFileUrl(p: string): string {
	try {
		const normalized = p.replace(/[\\]/g, "/");
		// Windows 盘符形态（C:/…）在 POSIX 宿主被 pathToFileURL 当相对路径解析拼 cwd ——
		// 预补 / 前缀使其成为绝对形态，产出 RFC 8089 的 file:///C:/…。
		const drivePrefixed = /^[A-Za-z]:\//.test(normalized) ? `/${normalized}` : normalized;
		return pathToFileURL(drivePrefixed).href;
	} catch {
		const normalized = p.replace(/[\\]/g, "/");
		return `file://${normalized.startsWith("/") ? "" : "/"}${normalized}`;
	}
}

/** 剥离行首路径匹配尾部的句读标点（如 `/a/b.md：` → 路径 + "："），全部剥离后无效则原样返回。 */
function splitTrailingPunct(p: string): { path: string; trail: string } {
	const m = TRAILING_PUNCT_RE.exec(p);
	if (!m || m[0].length === 0 || m[0].length >= p.length) return { path: p, trail: "" };
	return { path: p.slice(0, -m[0].length), trail: m[0] };
}

/**
 * 绝对路径链接化（纯函数）。反引号形态优先（显式引用置信度更高），行首裸形态次之；
 * 两者共享 maxLinks 总预算，超出原样保留。
 */
export function linkifyPaths(markdown: string, opts?: { maxLinks?: number }): string {
	if (typeof markdown !== "string" || markdown.length === 0) return markdown;
	const raw = opts?.maxLinks;
	const max = typeof raw === "number" && Number.isFinite(raw) && raw >= 0 ? Math.floor(raw) : DEFAULT_MAX_LINKS;
	if (max === 0) return markdown;
	let used = 0;
	let out = markdown.replace(BACKTICK_PATH_RE, (whole: string, p: string): string => {
		if (used >= max) return whole;
		used++;
		return `[${p}](${toFileUrl(p)})`;
	});
	if (used < max) {
		out = out.replace(LINE_START_PATH_RE, (whole: string, indent: string, p: string): string => {
			if (used >= max) return whole;
			const { path, trail } = splitTrailingPunct(p);
			if (!path) return whole;
			used++;
			return `${indent}[${path}](${toFileUrl(path)})${trail}`;
		});
	}
	return out;
}

/**
 * 注册显示层变换（8月迭代 pi-0.84 配合 P2⑦）：仅 messageType 为 "user"/"assistant"
 * 且非 isStreaming 时过 linkifyPaths，其余（流式分片/assistant-thinking）原样返回。
 * 结构子集参数面（真实 ExtensionAPI 直接兼容）；注册或执行失败静默——显示增强
 * 绝不影响消息渲染主流程。
 *
 * H2（amagi-pi v2，§8.4-H2/§6.2.8）官方 transformer 只做显示：registerMarkdownTransformer
 * 链为纯显示层（宿主契约：session 与模型上下文原文不变），产物不回流消息存储/wire
 * message_end 权威帧——终稿提取（task-jsonl processLine/getFinalOutput）永远消费原文，
 * 与本层互不越界（两套 message 语义注记见 task-jsonl.ts 文件头）。
 */
export function registerDisplayTransforms(pi: {
	registerMarkdownTransformer?: (fn: (md: string, ctx: { messageType: string; isStreaming: boolean }) => string) => void;
}): void {
	try {
		pi?.registerMarkdownTransformer?.((md: string, ctx: { messageType: string; isStreaming: boolean }): string => {
			if (!ctx || ctx.isStreaming) return md;
			if (ctx.messageType !== "user" && ctx.messageType !== "assistant") return md;
			try {
				return linkifyPaths(md);
			} catch {
				return md; // pi 对抛错 transformer 有兜底，但保持自防御更稳
			}
		});
	} catch {
		/* 注册失败静默 */
	}
}
