/**
 * contracts/task.ts — 任务实体契约、三轴状态机与 specDigest（amagi-pi v2 K1，方案 §3.2/§3.4）。
 *
 * 依赖方向：task → {view, permission, evidence}，node:crypto（唯一 node 依赖，纯计算）。
 * 承载：TaskSpec/TaskRun/TaskReceipt 及其构成类型、Execution/Settlement/Acceptance 三轴枚举、
 * 状态迁移合法性表（§3.4）、三轴组合校验（含 N5/N8 语义）、canonical JSON 与 SHA-256 specDigest
 * （排序键、排除 specDigest 自身字段）、反序列化校验器（不能依赖 TypeScript 阻止磁盘坏数据）。
 *
 * 布局说明（K1 裁量）：TaskView/TaskPage/TaskSpecSummary/ReceiptSummary 是任务实体的只读投影，
 * 定义在本模块——view.ts 是 DAG 叶子（Ref/Result 等原语的家），若 TaskView 放 view.ts 会形成
 * type-only 环（no-cycles 门禁包含 type-only import，§3.1）。
 */
import { createHash } from "node:crypto";
import {
	CONTRACT_VERSION,
	CONTRACT_ERROR_CODES,
	err,
	isHex64,
	isKnownContractVersion,
	isNonEmptyString,
	isNonNegativeInt,
	isPositiveInt,
	isRecord,
	ok,
	rejectUnknownKeys,
	validateRef,
	validateTaskKey,
	type ContractVersion,
	type Ref,
	type Result,
	type TaskKey,
} from "./view.ts";
import { validatePermissionGrant, type PermissionGrant } from "./permission.ts";
import {
	validateCheckResult,
	validateReceiptEvidenceLinks,
	validateVerificationObject,
	type CheckResult,
	type VerificationMode,
	type VerificationObject,
} from "./evidence.ts";

// ── 构成类型（§3.2） ─────────────────────────────────────────────────────────

export type InputRef = Ref & { purpose: string; required: boolean };

export type OutputRef = Ref & { sourcePath: string; kind: "file" | "tree" };

export interface OutputSpec {
	path: string;
	kind: "file" | "tree";
	required: boolean;
	/** 产物用途说明（可选；ev-20260919 与 inputs.purpose 对称——模型面直觉填充 purpose 不再被封闭规格拒单）。 */
	purpose?: string;
}

export interface WorkspaceSpec {
	cwd: string;
	repoRoot?: string;
	mode: "existing" | "worktree";
	dependencyVisibility: "portable" | "main-tree" | "unknown";
	baseCommit?: string;
	/** ev-20261017-cd233f：worktree 检出基线模式（head=仓库当前 HEAD，缺省；dirty-snapshot=主树工作区
	 *  脏快照 commit——未提交/未跟踪全量带入，排除 .amagi-worktrees）。可选字段向后兼容：旧冻结 spec
	 *  缺字段按 head（canonicalJson 缺席键口径不变，历史 specDigest 绝不回改）。 */
	base?: "head" | "dirty-snapshot";
	leaseId?: string;
	/** worktree 冻结分支身份（resume 跨 lease 覆盖/重启仍可验证）；旧 spec 无此键，digest 不回改。 */
	branch?: string;
}

export interface VerificationCheck {
	id: string;
	argv: readonly string[];
	cwdRel: string;
	timeoutMs: number;
	required: boolean;
}

export interface VerificationPolicy {
	id: string;
	version: number;
	objectMode: VerificationMode;
	allowSharedFallback: boolean;
	/** C2-a（ev-20260921-89cc12，方案 §2.8）：依赖对象模式——none=不捕获（旧语义：锁文件在场时
	 *  依赖型检查 unavailable）；copy-local=私有复制冻结本地已有依赖（root + 声明 workspace 子包
	 *  node_modules，pnpm .pnpm 与内部链接保持对象内；跨授权根链接/缺文件如实 unavailable）。
	 *  copy-local 只复制已有本地依赖，不获得安装、网络、凭据读取权限。可选字段向后兼容：旧冻结
	 *  spec 缺字段按 none（canonicalJson 缺席键口径不变，历史 specDigest 绝不回改）。 */
	dependencyMode?: "none" | "copy-local";
	checks: readonly VerificationCheck[];
	acceptance: "manual";
	criteria: readonly string[];
}

export interface EffectiveConfig {
	profileId: string;
	profileDigest: string;
	model: string;
	fallbackModels: readonly string[];
	hostVersion: string;
	surfaceVersion: number;
}

export type ContextMode = "isolated" | "selected" | "fork";
export const CONTEXT_MODES: readonly ContextMode[] = ["isolated", "selected", "fork"];

/** 冻结任务规格：派发时由应用服务冻结；模型只输入自然语言任务及少量结构字段，不手填 digest/owner/有效配置。 */
export interface TaskSpec {
	version: ContractVersion;
	specId: string;
	specDigest: string;
	agent: string;
	assignment: string;
	inputs: readonly InputRef[];
	outputs: readonly OutputSpec[];
	permission: PermissionGrant;
	workspace: WorkspaceSpec;
	verification: VerificationPolicy;
	effective: EffectiveConfig;
	contextMode: ContextMode;
	parentTaskId?: string;
	/** v2.1 会话盖章：派发时 Leader 进程当前会话标识（sessionFile 路径优先，回退 sessionId；
	 *  组合根 session_start 捕获注入 task-service 冻结入口）。恢复对账按此把在途记录精确绑定到
	 *  原会话——无盖章的旧记录按 pull-only 对待（只入全量视图，不触发新会话对账横幅/应用）。
	 *  可选字段向后兼容：旧 spec 无此字段照常 load（canonicalJson 缺席键口径不变，digest 不变）。 */
	leaderSession?: string;
	/** v2.1-A1 机器盖章：派发时本机持久身份（data-dir machine.json 随机 UUID，永不变更）。
	 *  恢复对账按此把 ownerId 不匹配但 machineId 匹配的记录识别为本机历史（hostname/网络漂移
	 *  不再误报 foreign-owner）；旧记录无此字段保持 foreign-owner 报告，可经 /amagi recovery adopt
	 *  确认收口。可选字段向后兼容：旧 spec 无此字段照常 load（缺席键不入 canonicalJson，digest 口径不变）。 */
	machineId?: string;
}

// ── 三轴状态（§3.2/§3.4） ────────────────────────────────────────────────────

export type ExecutionState =
	| "queued"
	| "running"
	| "done"
	| "blocked"
	| "error"
	| "answering"
	| "answered"
	| "cancelled"
	| "truncated"
	| "resolved-external";
export const EXECUTION_STATES: readonly ExecutionState[] = [
	"queued", "running", "done", "blocked", "error", "answering", "answered", "cancelled", "truncated", "resolved-external",
];

export type SettlementState = "pending" | "ready" | "failed" | "incomplete";
export const SETTLEMENT_STATES: readonly SettlementState[] = ["pending", "ready", "failed", "incomplete"];

export type AcceptanceState = "unreviewed" | "accepted" | "rejected";
export const ACCEPTANCE_STATES: readonly AcceptanceState[] = ["unreviewed", "accepted", "rejected"];

/** 回执结算态：回执一旦发布，settlement 不可能是 pending（Exclude<SettlementState,"pending">）。 */
export type ReceiptSettlement = Exclude<SettlementState, "pending">;

// ── TaskRun（内核维护；句柄只留执行适配器，不进公开 View 或持久化对象） ─────────

export type BackendKind = "json" | "rpc";
export const BACKEND_KINDS: readonly BackendKind[] = ["json", "rpc"];

export type ProcessState = "not-started" | "alive" | "exited" | "unknown";
export const PROCESS_STATES: readonly ProcessState[] = ["not-started", "alive", "exited", "unknown"];

export type RecoveryFlag = "none" | "needs-reconciliation";
export const RECOVERY_FLAGS: readonly RecoveryFlag[] = ["none", "needs-reconciliation"];

export interface LaunchIntent {
	nonce: string;
	at: number;
}

export interface TaskRun extends TaskKey {
	version: ContractVersion;
	specId: string;
	stateSeq: number;
	execution: ExecutionState;
	settlement: SettlementState;
	acceptance: AcceptanceState;
	currentReceipt?: Ref;
	backend: BackendKind;
	backendRunId?: string;
	sessionId?: string;
	groupId?: string;
	nodeId?: string;
	parentTaskId?: string;
	recovery: RecoveryFlag;
	successorTaskId?: string;
	queuedAt: number;
	startedAt?: number;
	exitedAt?: number;
	processState: ProcessState;
	launchIntent?: LaunchIntent;
}

// ── TaskReceipt（每一版不可变；初始接受状态恒为 unreviewed） ──────────────────

export interface ReceiptDecision {
	actor: "leader" | "user";
	reason: string;
	at: number;
	waivedCheckIds: readonly string[];
	previousReceiptId: string;
}

export interface TaskReceipt extends TaskKey {
	version: ContractVersion;
	receiptId: string;
	receiptSeq: number;
	specDigest: string;
	outputs: readonly OutputRef[];
	object?: VerificationObject;
	checks: readonly CheckResult[];
	settlement: ReceiptSettlement;
	missing: readonly string[];
	acceptance: AcceptanceState;
	decision?: ReceiptDecision;
	executionObserved: ExecutionState;
	createdAt: number;
}

// ── 只读投影 DTO（§3.3：TaskView 是 spec 摘要、TaskRun 和回执摘要的 readonly DTO） ──

export interface TaskSpecSummary {
	specId: string;
	specDigest: string;
	agent: string;
	assignment: string;
	outputs: readonly OutputSpec[];
	contextMode: ContextMode;
	parentTaskId?: string;
}

export interface ReceiptSummary {
	receiptId: string;
	receiptSeq: number;
	settlement: ReceiptSettlement;
	acceptance: AcceptanceState;
	specDigest: string;
	missing: readonly string[];
	/** ev-20260924-a28713：可 waive id 全集（availableWaiverIds 单源填充：missing ∪ checks[].id）。
	 *  accept 决策（decision.waivedCheckIds）取自此集合——决策所需信息在决策点前可见，不必从拒绝
	 *  响应里抄 id。settlement=ready 且无未过检查时为空数组。 */
	waivable: readonly string[];
	ref?: Ref;
}

export interface TaskView {
	viewVersion: 1;
	taskId: string;
	ownerId: string;
	revision: number;
	stateSeq: number;
	execution: ExecutionState;
	settlement: SettlementState;
	acceptance: AcceptanceState;
	/** diting-M3-A4：任务授权承诺等级（真实 P1 grant → 其 assurance；legacy v1 占位 → guarded）。
	 *  guarded 承诺局限：壳承诺非对抗隔离，hash 仅证一致性不证可信来源（§5.1）。 */
	assurance: "tool-enforced" | "guarded";
	degraded: readonly string[];
	spec: TaskSpecSummary;
	run: Readonly<TaskRun>;
	receipt?: ReceiptSummary;
	nextActions: readonly string[];
}

export interface TaskPage {
	items: readonly TaskView[];
	nextCursor?: string;
	truncated: boolean;
	snapshotSeq: number;
}

// ── 状态迁移合法性表（§3.4 迁移枚举） ────────────────────────────────────────
// answered/resolved-external/cancelled 不可重开；error/done/truncated 的后续执行均创建新 taskId。

export const EXECUTION_TRANSITIONS: Readonly<Record<ExecutionState, readonly ExecutionState[]>> = {
	queued: ["running", "cancelled", "error", "resolved-external"],
	running: ["done", "blocked", "error", "truncated", "cancelled"],
	blocked: ["answering", "cancelled", "resolved-external"],
	answering: ["answered", "blocked", "cancelled", "resolved-external"],
	done: [],
	error: [],
	answered: [],
	cancelled: [],
	truncated: [],
	"resolved-external": [],
};

export function isExecutionState(v: unknown): v is ExecutionState {
	return typeof v === "string" && EXECUTION_STATES.includes(v as ExecutionState);
}

export function canTransitionExecution(from: ExecutionState, to: ExecutionState): boolean {
	const allowed = EXECUTION_TRANSITIONS[from];
	return Array.isArray(allowed) && allowed.includes(to);
}

export function validateExecutionTransition(from: unknown, to: unknown): Result<{ from: ExecutionState; to: ExecutionState }> {
	if (!isExecutionState(from)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `from 必须是合法执行态之一（${EXECUTION_STATES.join("/")}）`, ["from"]);
	}
	if (!isExecutionState(to)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `to 必须是合法执行态之一（${EXECUTION_STATES.join("/")}）`, ["to"]);
	}
	if (!canTransitionExecution(from, to)) {
		return err(
			CONTRACT_ERROR_CODES.INVALID_TRANSITION,
			`非法状态迁移 ${from}→${to}（answered/resolved-external/cancelled 不可重开；error/done/truncated 后续执行须新建 taskId；允许表见 EXECUTION_TRANSITIONS）`,
			["from", "to"],
			"none",
			[{ from, to: "新任务 register" }],
		);
	}
	return ok({ from, to });
}

/** §3.4 取消例外：结算仍为 pending 时，允许取消已退出但尚在收尾的 done/truncated 记录
 *  （含义是撤销本轮结果采纳，不伪造进程被杀）；已发布结算回执的完成记录拒绝 cancel，用 reject 表达不接受。 */
export function canCancelExecution(execution: ExecutionState, settlement: SettlementState): boolean {
	switch (execution) {
		case "queued":
		case "running":
		case "blocked":
		case "answering":
			return true;
		case "done":
		case "truncated":
			return settlement === "pending";
		default:
			return false; // answered / cancelled / error / resolved-external：不允许取消
	}
}

// ── 三轴组合校验（N5/N8 语义） ───────────────────────────────────────────────

export interface StateTripleInput {
	execution: unknown;
	settlement: unknown;
	acceptance: unknown;
	hasReceipt: boolean;
}

export interface StateTriple {
	execution: ExecutionState;
	settlement: SettlementState;
	acceptance: AcceptanceState;
}

/**
 * 三轴状态合法性（§3.2/§3.4）：
 *  1) 无回执只能 pending/incomplete 且 unreviewed（必要存储故障只在 TaskView 标 degraded，不冒充已持久化状态）；
 *  2) 有回执时 settlement 不可能是 pending（回执结算态 Exclude pending；run 三轴与 currentReceipt 一致提交）；
 *  3) accepted/rejected 必须有回执可引用（decide 指向当前 receiptId；模型参数不能伪造用户身份）；
 *  4) ready ⇒ execution ∈ {done, truncated}（error/blocked/cancelled 的回执可存调查资料但不能 ready；
 *     ready 不蕴含 accepted——N8：接受是显式动作，与本校验正交）。
 */
export function validateStateTriple(input: StateTripleInput): Result<StateTriple> {
	if (!isExecutionState(input.execution)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `execution 必须是 ${EXECUTION_STATES.join("/")} 之一`, ["execution"]);
	}
	if (typeof input.settlement !== "string" || !SETTLEMENT_STATES.includes(input.settlement as SettlementState)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `settlement 必须是 ${SETTLEMENT_STATES.join("/")} 之一`, ["settlement"]);
	}
	if (typeof input.acceptance !== "string" || !ACCEPTANCE_STATES.includes(input.acceptance as AcceptanceState)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `acceptance 必须是 ${ACCEPTANCE_STATES.join("/")} 之一`, ["acceptance"]);
	}
	const execution = input.execution;
	const settlement = input.settlement as SettlementState;
	const acceptance = input.acceptance as AcceptanceState;
	if (typeof input.hasReceipt !== "boolean") {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "hasReceipt 必须是布尔值（由 currentReceipt 派生）", ["hasReceipt"]);
	}
	if (input.hasReceipt) {
		if (settlement === "pending") {
			return err(CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE, "有 currentReceipt 时 settlement 不可为 pending（回执结算态 Exclude pending，须与回执一致提交）", ["settlement"]);
		}
	} else {
		if (settlement !== "pending" && settlement !== "incomplete") {
			return err(
				CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
				"无回执只能 pending/incomplete 且 unreviewed（N8：接受必须显式 decide 生成回执）",
				["settlement", "acceptance"],
				"none",
				[{ settlement: "pending", acceptance: "unreviewed" }],
			);
		}
		if (acceptance !== "unreviewed") {
			return err(CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE, "无回执时 acceptance 必须 unreviewed（接受/拒绝引用当前回执）", ["acceptance"]);
		}
	}
	if (settlement === "ready" && execution !== "done" && execution !== "truncated") {
		return err(
			CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
			`settlement=ready 要求 execution ∈ {done, truncated}（${execution} 的回执可存调查资料但不能 ready）`,
			["execution", "settlement"],
		);
	}
	return ok({ execution, settlement, acceptance });
}

// ── canonical JSON 与 specDigest（§3.2：排序键；计算时排除 specDigest 自身字段） ──

/** 规范 JSON：对象键按字典序排序；数组保序；undefined 键视同缺席（与 JSON.stringify 语义一致，
 *  保证同内容不同键序同 digest）。 */
export function canonicalJson(value: unknown): string {
	if (value === null || typeof value !== "object") return JSON.stringify(value) ?? "null";
	if (Array.isArray(value)) return `[${value.map((v) => canonicalJson(v)).join(",")}]`;
	const src = value as Record<string, unknown>;
	const keys = Object.keys(src)
		.filter((k) => src[k] !== undefined)
		.sort();
	return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalJson(src[k])}`).join(",")}}`;
}

/** SHA-256 specDigest：对排除 specDigest 自身字段后的排序键规范 JSON 计算。 */
export function computeSpecDigest(spec: Readonly<Omit<TaskSpec, "specDigest"> | TaskSpec>): string {
	const { specDigest: _excluded, ...rest } = spec as TaskSpec;
	return createHash("sha256").update(canonicalJson(rest), "utf8").digest("hex");
}

/** 冻结封印：为无 digest 的 spec 计算并填入 specDigest（应用服务冻结路径）。 */
export function sealSpec(spec: Readonly<Omit<TaskSpec, "specDigest">>): TaskSpec {
	return { ...spec, specDigest: computeSpecDigest(spec) };
}

// ── 反序列化校验器（§3.2：反序列化后重新校验，不依赖 TypeScript 阻止磁盘坏数据） ──

function invalidField(field: string, message: string) {
	return err(CONTRACT_ERROR_CODES.INVALID_FIELD, message, [field]);
}

function validateEnumMember<T extends string>(v: unknown, values: readonly T[], field: string): Result<T> {
	if (typeof v !== "string" || !values.includes(v as T)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `${field} 必须是 ${values.join("/")} 之一`, [field]);
	}
	return ok(v as unknown as T);
}

function validateStringArrayField(v: unknown, field: string): Result<readonly string[]> {
	if (!Array.isArray(v)) return invalidField(field, `${field} 必须是字符串数组`);
	for (let i = 0; i < v.length; i++) {
		if (!isNonEmptyString(v[i])) return invalidField(`${field}[${i}]`, `${field}[${i}] 必须是非空字符串`);
	}
	return ok(v as readonly string[]);
}

export function validateInputRef(v: unknown, field: string): Result<InputRef> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const ref = validateRef(v, field, ["purpose", "required"]);
	if (!ref.ok) return ref;
	if (!isNonEmptyString(v.purpose)) return invalidField(`${field}.purpose`, `${field}.purpose 必须是非空字符串`);
	if (typeof v.required !== "boolean") return invalidField(`${field}.required`, `${field}.required 必须是布尔值`);
	return ok({ ...ref.value, purpose: v.purpose, required: v.required });
}

export function validateOutputSpec(v: unknown, field: string): Result<OutputSpec> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const shape = rejectUnknownKeys(v, ["path", "kind", "required", "purpose"], field);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, [field]);
	if (!isNonEmptyString(v.path)) return invalidField(`${field}.path`, `${field}.path 必须是非空字符串`);
	const kind = validateEnumMember(v.kind, ["file", "tree"] as const, `${field}.kind`);
	if (!kind.ok) return kind;
	if (typeof v.required !== "boolean") return invalidField(`${field}.required`, `${field}.required 必须是布尔值`);
	// ev-20260919：purpose 可选（提供时须非空字符串）；旧 spec（无 purpose）在同版本校验器下仍合法（向后兼容，可选字段不升 ContractVersion）。
	if (v.purpose !== undefined && !isNonEmptyString(v.purpose)) return invalidField(`${field}.purpose`, `${field}.purpose 提供时必须是非空字符串`);
	return ok(v.purpose !== undefined ? { path: v.path, kind: kind.value, required: v.required, purpose: v.purpose } : { path: v.path, kind: kind.value, required: v.required });
}

export function validateOutputRef(v: unknown, field: string): Result<OutputRef> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const ref = validateRef(v, field, ["sourcePath", "kind"]);
	if (!ref.ok) return ref;
	if (!isNonEmptyString(v.sourcePath)) return invalidField(`${field}.sourcePath`, `${field}.sourcePath 必须是非空字符串（原交付位置）`);
	const kind = validateEnumMember(v.kind, ["file", "tree"] as const, `${field}.kind`);
	if (!kind.ok) return kind;
	return ok({ ...ref.value, sourcePath: v.sourcePath, kind: kind.value });
}

function validateWorkspaceSpec(v: unknown): Result<WorkspaceSpec> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "workspace 必须是对象", ["workspace"]);
	const shape = rejectUnknownKeys(v, ["cwd", "repoRoot", "mode", "dependencyVisibility", "baseCommit", "base", "leaseId", "branch"], "workspace");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["workspace"]);
	if (!isNonEmptyString(v.cwd)) return invalidField("workspace.cwd", "workspace.cwd 必须是非空字符串（路径统一以冻结 cwd 解析）");
	if (v.repoRoot !== undefined && !isNonEmptyString(v.repoRoot)) return invalidField("workspace.repoRoot", "workspace.repoRoot 必须是非空字符串");
	const mode = validateEnumMember(v.mode, ["existing", "worktree"] as const, "workspace.mode");
	if (!mode.ok) return mode;
	const depVis = validateEnumMember(v.dependencyVisibility, ["portable", "main-tree", "unknown"] as const, "workspace.dependencyVisibility");
	if (!depVis.ok) return depVis;
	if (v.baseCommit !== undefined && !isNonEmptyString(v.baseCommit)) return invalidField("workspace.baseCommit", "workspace.baseCommit 必须是非空字符串");
	if (v.base !== undefined) {
		const base = validateEnumMember(v.base, ["head", "dirty-snapshot"] as const, "workspace.base");
		if (!base.ok) return base;
	}
	if (v.leaseId !== undefined && !isNonEmptyString(v.leaseId)) return invalidField("workspace.leaseId", "workspace.leaseId 必须是非空字符串");
	if (v.branch !== undefined && !isNonEmptyString(v.branch)) return invalidField("workspace.branch", "workspace.branch 必须是非空字符串");
	return ok(v as unknown as WorkspaceSpec);
}

function validateVerificationPolicy(v: unknown): Result<VerificationPolicy> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "verification 必须是对象", ["verification"]);
	const shape = rejectUnknownKeys(v, ["id", "version", "objectMode", "allowSharedFallback", "dependencyMode", "checks", "acceptance", "criteria"], "verification");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["verification"]);
	if (!isNonEmptyString(v.id)) return invalidField("verification.id", "verification.id 必须是非空字符串");
	if (!isPositiveInt(v.version)) return invalidField("verification.version", "verification.version 必须是正整数");
	const objectMode = validateEnumMember(v.objectMode, ["snapshot", "shared-tree"] as const, "verification.objectMode");
	if (!objectMode.ok) return objectMode;
	if (typeof v.allowSharedFallback !== "boolean") return invalidField("verification.allowSharedFallback", "verification.allowSharedFallback 必须是布尔值");
	// C2-a：可选 dependencyMode（缺省 = none，旧 spec 合法；非法值封闭拒绝——不猜）
	if (v.dependencyMode !== undefined) {
		const depMode = validateEnumMember(v.dependencyMode, ["none", "copy-local"] as const, "verification.dependencyMode");
		if (!depMode.ok) return depMode;
	}
	if (!Array.isArray(v.checks)) return invalidField("verification.checks", "verification.checks 必须是数组");
	for (let i = 0; i < v.checks.length; i++) {
		const c = v.checks[i];
		const cf = `verification.checks[${i}]`;
		if (!isRecord(c)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${cf} 必须是对象`, [cf]);
		const cShape = rejectUnknownKeys(c, ["id", "argv", "cwdRel", "timeoutMs", "required"], cf);
		if (cShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, cShape, [cf]);
		if (!isNonEmptyString(c.id)) return invalidField(`${cf}.id`, `${cf}.id 必须是非空字符串`);
		const argv = validateStringArrayField(c.argv, `${cf}.argv`);
		if (!argv.ok) return argv;
		if (!isNonEmptyString(c.cwdRel)) return invalidField(`${cf}.cwdRel`, `${cf}.cwdRel 必须是非空字符串`);
		if (!isPositiveInt(c.timeoutMs)) return invalidField(`${cf}.timeoutMs`, `${cf}.timeoutMs 必须是正整数毫秒`);
		if (typeof c.required !== "boolean") return invalidField(`${cf}.required`, `${cf}.required 必须是布尔值`);
	}
	if (v.acceptance !== "manual") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "verification.acceptance 当前封闭为 manual（新接受模式须升契约版本）", ["verification.acceptance"]);
	}
	const criteria = validateStringArrayField(v.criteria, "verification.criteria");
	if (!criteria.ok) return criteria;
	return ok(v as unknown as VerificationPolicy);
}

function validateEffectiveConfig(v: unknown): Result<EffectiveConfig> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "effective 必须是对象", ["effective"]);
	const shape = rejectUnknownKeys(v, ["profileId", "profileDigest", "model", "fallbackModels", "hostVersion", "surfaceVersion"], "effective");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["effective"]);
	for (const f of ["profileId", "profileDigest", "model", "hostVersion"] as const) {
		if (!isNonEmptyString(v[f])) return invalidField(`effective.${f}`, `effective.${f} 必须是非空字符串`);
	}
	const fallbackModels = validateStringArrayField(v.fallbackModels, "effective.fallbackModels");
	if (!fallbackModels.ok) return fallbackModels;
	if (!isPositiveInt(v.surfaceVersion)) return invalidField("effective.surfaceVersion", "effective.surfaceVersion 必须是正整数");
	return ok(v as unknown as EffectiveConfig);
}

export function validateTaskSpec(v: unknown): Result<TaskSpec> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "spec 必须是对象", ["spec"]);
	// ContractVersion 拒绝：未知必要版本拒绝（含 version 非数字/缺_missing），不回退猜测。
	if (!isKnownContractVersion(v.version)) {
		return err(
			CONTRACT_ERROR_CODES.UNSUPPORTED_VERSION,
			`未知或缺失的必要契约版本 version=${JSON.stringify(v.version) ?? "undefined"}（当前支持 ${CONTRACT_VERSION}）`,
			["version"],
			"none",
			[{ version: 1 }],
		);
	}
	const shape = rejectUnknownKeys(
		v,
		["version", "specId", "specDigest", "agent", "assignment", "inputs", "outputs", "permission", "workspace", "verification", "effective", "contextMode", "parentTaskId", "leaderSession", "machineId"],
		"spec",
	);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["spec"]);
	if (!isNonEmptyString(v.specId)) return invalidField("spec.specId", "spec.specId 必须是非空字符串");
	if (!isHex64(v.specDigest)) return invalidField("spec.specDigest", "spec.specDigest 必须是 64 位小写十六进制 SHA-256（由应用服务 sealSpec 冻结）");
	if (!isNonEmptyString(v.agent)) return invalidField("spec.agent", "spec.agent 必须是非空字符串");
	if (!isNonEmptyString(v.assignment)) return invalidField("spec.assignment", "spec.assignment 必须是非空字符串");
	if (!Array.isArray(v.inputs)) return invalidField("spec.inputs", "spec.inputs 必须是数组");
	for (let i = 0; i < v.inputs.length; i++) {
		const r = validateInputRef(v.inputs[i], `spec.inputs[${i}]`);
		if (!r.ok) return r;
	}
	if (!Array.isArray(v.outputs)) return invalidField("spec.outputs", "spec.outputs 必须是数组");
	for (let i = 0; i < v.outputs.length; i++) {
		const r = validateOutputSpec(v.outputs[i], `spec.outputs[${i}]`);
		if (!r.ok) return r;
	}
	const permission = validatePermissionGrant(v.permission);
	if (!permission.ok) return permission;
	const workspace = validateWorkspaceSpec(v.workspace);
	if (!workspace.ok) return workspace;
	const verification = validateVerificationPolicy(v.verification);
	if (!verification.ok) return verification;
	const effective = validateEffectiveConfig(v.effective);
	if (!effective.ok) return effective;
	const contextMode = validateEnumMember(v.contextMode, CONTEXT_MODES, "spec.contextMode");
	if (!contextMode.ok) return contextMode;
	if (v.parentTaskId !== undefined && !isNonEmptyString(v.parentTaskId)) return invalidField("spec.parentTaskId", "spec.parentTaskId 必须是非空字符串");
	if (v.leaderSession !== undefined && !isNonEmptyString(v.leaderSession)) return invalidField("spec.leaderSession", "spec.leaderSession 必须是非空字符串（派发会话盖章；缺省=旧记录无盖章，对账按 pull-only）");
	if (v.machineId !== undefined && !isNonEmptyString(v.machineId)) return invalidField("spec.machineId", "spec.machineId 必须是非空字符串（本机持久身份盖章；缺省=旧记录无机器盖章，对账按 foreign-owner 报告可 adopt 收口）");
	// digest 复核：排除自身字段后重算必须一致（防磁盘坏数据/字段漂移）。
	if (v.specDigest !== computeSpecDigest(v as unknown as TaskSpec)) {
		return err(
			CONTRACT_ERROR_CODES.DIGEST_MISMATCH,
			"specDigest 与排除自身字段后的 canonical JSON SHA-256 不一致",
			["specDigest"],
			"none",
			[{ hint: "用 sealSpec(...) 重新冻结，或修正被篡改/漂移的字段" }],
		);
	}
	return ok(v as unknown as TaskSpec);
}

const TASK_RUN_FIELDS = ["ownerId", "taskId", "revision", "version", "specId", "stateSeq", "execution", "settlement", "acceptance", "currentReceipt", "backend", "backendRunId", "sessionId", "groupId", "nodeId", "parentTaskId", "recovery", "successorTaskId", "queuedAt", "startedAt", "exitedAt", "processState", "launchIntent"] as const;

export function validateTaskRun(v: unknown): Result<TaskRun> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "run 必须是对象", ["run"]);
	if (!isKnownContractVersion(v.version)) {
		return err(
			CONTRACT_ERROR_CODES.UNSUPPORTED_VERSION,
			`未知或缺失的必要契约版本 version=${JSON.stringify(v.version) ?? "undefined"}（当前支持 ${CONTRACT_VERSION}）`,
			["version"],
			"none",
			[{ version: 1 }],
		);
	}
	const shape = rejectUnknownKeys(v, TASK_RUN_FIELDS, "run");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["run"]);
	const key = validateTaskKey(v, "run", TASK_RUN_FIELDS);
	if (!key.ok) return key;
	if (!isNonEmptyString(v.specId)) return invalidField("run.specId", "run.specId 必须是非空字符串");
	if (!isNonNegativeInt(v.stateSeq)) return invalidField("run.stateSeq", "run.stateSeq 必须是非负整数（N2：每次持久状态提交序号，CAS 使用）");
	let hasReceipt = false;
	if (v.currentReceipt !== undefined) {
		const receiptRef = validateRef(v.currentReceipt, "run.currentReceipt");
		if (!receiptRef.ok) return receiptRef;
		hasReceipt = true;
	}
	// 三轴组合校验（含 N5/N8 语义），hasReceipt 由 currentReceipt 派生。
	const triple = validateStateTriple({ execution: v.execution, settlement: v.settlement, acceptance: v.acceptance, hasReceipt });
	if (!triple.ok) return triple;
	const backend = validateEnumMember(v.backend, BACKEND_KINDS, "run.backend");
	if (!backend.ok) return backend;
	for (const f of ["backendRunId", "sessionId", "groupId", "nodeId", "parentTaskId", "successorTaskId"] as const) {
		if (v[f] !== undefined && !isNonEmptyString(v[f])) return invalidField(`run.${f}`, `run.${f} 必须是非空字符串`);
	}
	const recovery = validateEnumMember(v.recovery, RECOVERY_FLAGS, "run.recovery");
	if (!recovery.ok) return recovery;
	if (!isNonNegativeInt(v.queuedAt)) return invalidField("run.queuedAt", "run.queuedAt 必须是非负整数（epoch ms）");
	if (v.startedAt !== undefined && !isNonNegativeInt(v.startedAt)) return invalidField("run.startedAt", "run.startedAt 必须是非负整数");
	if (v.exitedAt !== undefined && !isNonNegativeInt(v.exitedAt)) return invalidField("run.exitedAt", "run.exitedAt 必须是非负整数");
	const processState = validateEnumMember(v.processState, PROCESS_STATES, "run.processState");
	if (!processState.ok) return processState;
	if (v.launchIntent !== undefined) {
		if (!isRecord(v.launchIntent)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "run.launchIntent 必须是对象", ["run.launchIntent"]);
		const liShape = rejectUnknownKeys(v.launchIntent, ["nonce", "at"], "run.launchIntent");
		if (liShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, liShape, ["run.launchIntent"]);
		if (!isNonEmptyString(v.launchIntent.nonce)) return invalidField("run.launchIntent.nonce", "run.launchIntent.nonce 必须是非空字符串");
		if (!isNonNegativeInt(v.launchIntent.at)) return invalidField("run.launchIntent.at", "run.launchIntent.at 必须是非负整数");
	}
	return ok(v as unknown as TaskRun);
}

const TASK_RECEIPT_FIELDS = ["ownerId", "taskId", "revision", "version", "receiptId", "receiptSeq", "specDigest", "outputs", "object", "checks", "settlement", "missing", "acceptance", "decision", "executionObserved", "createdAt"] as const;

export function validateTaskReceipt(v: unknown): Result<TaskReceipt> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "receipt 必须是对象", ["receipt"]);
	if (!isKnownContractVersion(v.version)) {
		return err(
			CONTRACT_ERROR_CODES.UNSUPPORTED_VERSION,
			`未知或缺失的必要契约版本 version=${JSON.stringify(v.version) ?? "undefined"}（当前支持 ${CONTRACT_VERSION}）`,
			["version"],
			"none",
			[{ version: 1 }],
		);
	}
	const shape = rejectUnknownKeys(v, TASK_RECEIPT_FIELDS, "receipt");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["receipt"]);
	const key = validateTaskKey(v, "receipt", TASK_RECEIPT_FIELDS);
	if (!key.ok) return key;
	if (!isNonEmptyString(v.receiptId)) return invalidField("receipt.receiptId", "receipt.receiptId 必须是非空字符串");
	if (!isPositiveInt(v.receiptSeq)) return invalidField("receipt.receiptSeq", "receipt.receiptSeq 必须是正整数（接受/拒绝生成新 receiptSeq）");
	if (!isHex64(v.specDigest)) return invalidField("receipt.specDigest", "receipt.specDigest 必须是 64 位小写十六进制 SHA-256（绑定交付版本）");
	if (!Array.isArray(v.outputs)) return invalidField("receipt.outputs", "receipt.outputs 必须是数组");
	for (let i = 0; i < v.outputs.length; i++) {
		const r = validateOutputRef(v.outputs[i], `receipt.outputs[${i}]`);
		if (!r.ok) return r;
	}
	if (v.object !== undefined) {
		const object = validateVerificationObject(v.object);
		if (!object.ok) return object;
	}
	if (!Array.isArray(v.checks)) return invalidField("receipt.checks", "receipt.checks 必须是数组");
	for (let i = 0; i < v.checks.length; i++) {
		const c = validateCheckResult(v.checks[i]);
		if (!c.ok) return c;
	}
	const settlement = validateEnumMember(v.settlement, ["ready", "failed", "incomplete"] as const, "receipt.settlement");
	if (!settlement.ok) return settlement;
	const missing = validateStringArrayField(v.missing, "receipt.missing");
	if (!missing.ok) return missing;
	const acceptance = validateEnumMember(v.acceptance, ACCEPTANCE_STATES, "receipt.acceptance");
	if (!acceptance.ok) return acceptance;
	// decide 语义：接受/拒绝必须带 decision（含理由与豁免清单）；unreviewed 不得携带 decision。
	if (acceptance.value === "unreviewed") {
		if (v.decision !== undefined) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "acceptance=unreviewed 不得携带 decision（接受/拒绝是显式动作生成的新回执）", ["receipt.decision"]);
		}
	} else if (!isRecord(v.decision)) {
		return err(
			CONTRACT_ERROR_CODES.INVALID_FIELD,
			`acceptance=${acceptance.value} 必须携带 decision（actor 由入口身份提供，模型参数不能伪造用户身份）`,
			["receipt.decision"],
			"none",
			[{ actor: "leader", reason: "…", waivedCheckIds: [], previousReceiptId: "…" }],
		);
	} else {
		const dShape = rejectUnknownKeys(v.decision, ["actor", "reason", "at", "waivedCheckIds", "previousReceiptId"], "receipt.decision");
		if (dShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, dShape, ["receipt.decision"]);
		const actor = validateEnumMember(v.decision.actor, ["leader", "user"] as const, "receipt.decision.actor");
		if (!actor.ok) return actor;
		if (!isNonEmptyString(v.decision.reason)) return invalidField("receipt.decision.reason", "receipt.decision.reason 必须是非空字符串");
		if (!isNonNegativeInt(v.decision.at)) return invalidField("receipt.decision.at", "receipt.decision.at 必须是非负整数");
		const waived = validateStringArrayField(v.decision.waivedCheckIds, "receipt.decision.waivedCheckIds");
		if (!waived.ok) return waived;
		if (!isNonEmptyString(v.decision.previousReceiptId)) return invalidField("receipt.decision.previousReceiptId", "receipt.decision.previousReceiptId 必须是非空字符串");
	}
	const executionObserved = validateEnumMember(v.executionObserved, EXECUTION_STATES, "receipt.executionObserved");
	if (!executionObserved.ok) return executionObserved;
	if (!isNonNegativeInt(v.createdAt)) return invalidField("receipt.createdAt", "receipt.createdAt 必须是非负整数");
	return ok(v as unknown as TaskReceipt);
}

/**
 * D1（ev-20260922-c896f8，方案 §2.9）新回执发布校验入口：在读取校验（validateTaskReceipt，
 * 旧回执宽容兼容）之上叠加 evidence link 校验——检查记录 id 唯一；机器检查缺口只引用 checks[].id；
 * 非检查缺口必须是已注册 GapId；`id:status` 拼接拒绝。仅新发布（publish-receipt 命令面）调用；
 * 旧回执读取（store.load / 恢复对账 / decide 沿用）不走本入口，历史归档不重写。
 */
export function validateTaskReceiptForPublish(v: unknown): Result<TaskReceipt> {
	const base = validateTaskReceipt(v);
	if (!base.ok) return base;
	const links = validateReceiptEvidenceLinks({ checks: base.value.checks, missing: base.value.missing });
	if (!links.ok) return links;
	return base;
}
