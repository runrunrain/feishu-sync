/**
 * contracts/command.ts — 命令与公共端口契约（amagi-pi v2 K1，方案 §3.3/§4.1）。
 *
 * 依赖方向：command → {view, task}。内部判别联合命令；外部工具面采用普通 object schema
 * （供应商 JSON Schema 不承担权限执法，字段组合与业务校验在执行前完成）。
 * KernelCommand 封闭为十种命令，不暴露通用 patch；ControlCommand 为 wait/cancel/
 * resolve-external/steer/accept/reject 判别联合。TaskApplication/TaskKernel/TaskStore 端口
 * 一并声明于此（命令面向的公共端口；ExecutionPort 在根 execution-port.ts）。
 */
import {
	CONTRACT_ERROR_CODES,
	deepStripNulls,
	err,
	isNonEmptyString,
	isNonNegativeInt,
	isRecord,
	ok,
	rejectUnknownKeys,
	validateTaskKey,
	type Ref,
	type Result,
	type TaskKey,
	type TaskQuery,
} from "./view.ts";
import {
	validateTaskReceiptForPublish,
	validateTaskSpec,
	type ExecutionState,
	type TaskPage,
	type TaskReceipt,
	type TaskRun,
	type TaskSpec,
	type TaskView,
} from "./task.ts";

// ── 提交输入（§3.3/§4.1：SubmitInput 是工具参数去掉 delivery；模型不手填 digest/owner/有效配置） ──

export interface SubmitInputRef {
	path: string;
	purpose: string;
	required?: boolean;
}

export interface SubmitOutputSpec {
	path: string;
	kind?: "file" | "tree";
	required?: boolean;
}

/** scope 请求 read/write/deny/reportFiles/shell/MCP/LSP 的子集；实际范围由角色上限∩授权∩请求∩后端决定。 */
/** scope 请求 read/write/deny/reportFiles/shell/MCP/LSP 的子集；实际范围由角色上限∩授权∩请求∩后端决定。
 *  shell 三态（ev-20260930-c703e3）：guarded=必需（交集为空整单拒绝）；optional=非必需（交集为空
 *  自动降级 deny 并在提交回执告警，不拒单）；deny/缺省=不请求。授予结果仍为封闭 ShellPolicy。 */
export type ShellChannelRequest = "deny" | "guarded" | "optional";
export const SHELL_CHANNEL_REQUESTS: readonly ShellChannelRequest[] = ["deny", "guarded", "optional"];

export interface SubmitScope {
	read?: readonly string[];
	write?: readonly string[];
	deny?: readonly string[];
	reportFiles?: readonly string[];
	shell?: ShellChannelRequest;
	mcp?: readonly string[];
	lsp?: readonly ("diagnostics" | "definition" | "references" | "hover" | "rename")[];
	/** B5A（7517d8 设计 §3.1）：codemode 只读受控请求面。仅认 "read-only"（显式请求，必需通道——
	 *  四方交集任一缺口整单拒绝）；缺省=不请求（与现状一致）。实际授予还需角色能力上限、受信
	 *  配置角色开关、后端已验证装配同时成立，才冻结 PermissionGrant.codemode（policyVersion=2）。 */
	codemode?: "read-only";
	advisor?: "consult";
}

export interface SubmitWorkspaceRequest {
	cwd?: string;
	mode?: "existing" | "worktree";
	worktreeName?: string;
	dependencyVisibility?: "portable" | "main-tree" | "unknown";
	/** ev-20261017-cd233f：worktree 检出基线（head=仓库当前 HEAD，缺省；dirty-snapshot=主树工作区脏快照）。 */
	base?: "head" | "dirty-snapshot";
}

export interface SubmitInput {
	agent: string;
	assignment: string;
	inputs?: readonly SubmitInputRef[];
	outputs?: readonly SubmitOutputSpec[];
	scope?: SubmitScope;
	workspace?: SubmitWorkspaceRequest;
	/** 受信配置中的 profile 名，不是任意覆盖字典。 */
	profile?: string;
	contextMode?: "isolated" | "selected" | "fork";
	parentTaskId?: string;
}

/** 调用者上下文：仅由组合根提供（owner、Leader/用户身份、授权上限），不能从模型参数构造。 */
export interface CallerContext {
	ownerId: string;
	actor: "leader" | "user";
	actorId: string;
	authority: {
		/** 可批准的保证等级上限（§5.1）。 */
		maxAssurance: "tool-enforced" | "guarded";
		/** 可用的受信 profile 名单。 */
		profiles: readonly string[];
		/** 分面启用上限（§4.3：CallerContext 决定 task_batch 等延迟分面）。 */
		facets: readonly ("batch")[];
	};
}

// ── 控制命令（§3.3：wait/cancel/resolve-external/accept/reject 判别联合） ──────

export type WaitMode = "any" | "all";

export type ControlCommand =
	| { action: "wait"; handles: readonly string[]; mode?: WaitMode; timeoutMs?: number }
	| { action: "cancel"; handles: readonly string[]; reason: string }
	| { action: "resolve-external"; handles: readonly string[]; reason: string }
	| { action: "steer"; handle: string; message: string }
	| { action: "accept"; handle: string; receiptId: string; expectedRevision: number; reason: string; waivedCheckIds?: readonly string[] }
	| { action: "reject"; handle: string; receiptId: string; expectedRevision: number; reason: string }
	/** ev-20261021-a8de95：恢复对账——本会话不持有运行实体的契约记录，探测存活后关闭（stale）或拒绝（live/unknown）。 */
	| { action: "reconcile"; handles: readonly string[]; reason: string };

export const CONTROL_ACTIONS: readonly ("wait" | "cancel" | "resolve-external" | "steer" | "accept" | "reject" | "reconcile")[] = [
	"wait", "cancel", "resolve-external", "steer", "accept", "reject", "reconcile",
];

// ── receiptId 形状口径与差异定位（ev-20261014-4f7500；ev-20261021-fix 收窄为诊断用） ──

/** 当前全仓 receiptId 生产生成点唯一形态：`receipt-${randomUUID()}`（finalizer.ts 首发 +
 *  task-kernel.ts decide 链式）——receipt- 后 8-4-4-4-12 位小写十六进制，总长 44；
 *  生成点产出——形状口径只用于 stale-receipt 不匹配输入的诊断提示（非当前 id 且非 uuid 形状时
 *  提示疑似转录畸变），不作为工具面栅栏：发布面 validateTaskReceiptForPublish 对 receiptId
 *  形态开放（历史 v2-store 合成回执生态依赖），不得单端收紧发布/存储仍开放的契约。 */
export const RECEIPT_ID_SHAPE_RE = /^receipt-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export function isValidReceiptIdShape(v: unknown): boolean {
	return typeof v === "string" && RECEIPT_ID_SHAPE_RE.test(v);
}

/** 两侧 receiptId 的机器可读差异定位（首差位 + 上下文窗口片段 + 长度差），供 stale-receipt
 *  错误渲染复用——人类对 44 位十六进制串的目视比对不可靠（ev-20261014 事故放大器：
 *  两侧完整渲染仍被误读为「字节相同」）。 */
export function receiptIdMismatchHint(current: string, submitted: string): string {
	const lenNote = current.length === submitted.length ? "" : `，长度 ${current.length} vs ${submitted.length}`;
	let i = 0;
	const n = Math.min(current.length, submitted.length);
	while (i < n && current[i] === submitted[i]) i++;
	if (i >= n) return `前 ${n} 字符逐字节相同${lenNote}（差异仅在尾部长度）`;
	const win = (s: string) => `…${s.slice(Math.max(0, i - 8), i + 8)}…`;
	return `首差位 ${i}（0 起${lenNote}）：当前 ${win(current)} vs 收到 ${win(submitted)}`;
}

// ── 执行观察事件（§3.3 observe：事件只含 started/session/activity/exited） ────
// ev-20261019-06c169：exited 增可选封闭字段 executionPolicy="preserve"——JSON 引擎的物理退出
// 观察只更新 processState/exitedAt/backendRunId，不推导业务终态（running→done/error 的退出码映射
// 保留给 RPC/缺省语义）。瞬时内核命令字段：不进 TaskSpec digest、不进 TaskRun/回执持久 schema。
export type ExecutionEvent =
	| { kind: "started"; at: number }
	| { kind: "session"; sessionId: string }
	| { kind: "activity"; note: string }
	| { kind: "exited"; exitCode: number | null; at: number; executionPolicy?: "preserve" };

export const EXECUTION_EVENT_KINDS: readonly ("started" | "session" | "activity" | "exited")[] = [
	"started", "session", "activity", "exited",
];

export function validateExecutionEvent(v: unknown): Result<ExecutionEvent> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "event 必须是对象", ["event"]);
	const kind = v.kind;
	switch (kind) {
		case "started": {
			const shape = rejectUnknownKeys(v, ["kind", "at"], "event");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["event"]);
			if (!isNonNegativeInt(v.at)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "event.at 必须是非负整数", ["event.at"]);
			return ok({ kind: "started", at: v.at });
		}
		case "session": {
			const shape = rejectUnknownKeys(v, ["kind", "sessionId"], "event");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["event"]);
			if (!isNonEmptyString(v.sessionId)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "event.sessionId 必须是非空字符串", ["event.sessionId"]);
			return ok({ kind: "session", sessionId: v.sessionId });
		}
		case "activity": {
			const shape = rejectUnknownKeys(v, ["kind", "note"], "event");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["event"]);
			if (!isNonEmptyString(v.note)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "event.note 必须是非空字符串", ["event.note"]);
			return ok({ kind: "activity", note: v.note });
		}
		case "exited": {
			const shape = rejectUnknownKeys(v, ["kind", "exitCode", "at", "executionPolicy"], "event");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["event"]);
			if (v.exitCode !== null && !Number.isInteger(v.exitCode)) {
				return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "event.exitCode 必须是整数或 null（被信号杀死无退出码）", ["event.exitCode"]);
			}
			if (!isNonNegativeInt(v.at)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "event.at 必须是非负整数", ["event.at"]);
			// ev-20261019-06c169：封闭枚举——只认 preserve（物理观察不推导业务终态）；其它值整单拒绝。
			if (v.executionPolicy !== undefined && v.executionPolicy !== "preserve") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "event.executionPolicy 只认 preserve（物理退出观察不迁移 execution；缺省保持退出码映射）", ["event.executionPolicy"]);
			}
			return ok(v.executionPolicy === "preserve"
				? { kind: "exited", exitCode: v.exitCode as number | null, at: v.at, executionPolicy: "preserve" }
				: { kind: "exited", exitCode: v.exitCode as number | null, at: v.at });
		}
		default:
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `event.kind 必须是 ${EXECUTION_EVENT_KINDS.join("/")} 之一`, ["event.kind"]);
	}
}

// ── 内核命令（§3.3：封闭十种；每种定义必需字段，不暴露通用 patch） ─────────────

export type ResumeLease = { holder: string; nonce: string; at: number };

export type ReconcileDisposition = "needs-reconciliation" | "close-unexecuted" | "confirm-exited" | "manual-takeover";

export interface ReconcileFact {
	code: string;
	detail: string;
}

export type KernelCommand =
	| { type: "register"; spec: TaskSpec; groupId?: string; nodeId?: string }
	| { type: "grant-start"; key: TaskKey; backend: "json" | "rpc"; launchIntent: { nonce: string; at: number } }
	| { type: "observe"; key: TaskKey; backendRunId: string; observationSeq: number; event: ExecutionEvent }
	| { type: "cancel"; key: TaskKey; reason: string }
	| { type: "resolve-external"; key: TaskKey; reason: string }
	| { type: "begin-resume"; key: TaskKey; lease: ResumeLease }
	| { type: "finish-resume"; key: TaskKey; outcome: "answered" | "blocked"; reason: string; successorTaskId?: string }
	| { type: "publish-receipt"; key: TaskKey; receipt: TaskReceipt }
	| { type: "decide"; key: TaskKey; receiptId: string; verdict: "accept" | "reject"; decision: { actor: "leader" | "user"; reason: string; waivedCheckIds: readonly string[] } }
	| { type: "reconcile"; key: TaskKey; facts: readonly ReconcileFact[]; disposition: ReconcileDisposition };

export const KERNEL_COMMAND_TYPES: readonly ("register" | "grant-start" | "observe" | "cancel" | "resolve-external" | "begin-resume" | "finish-resume" | "publish-receipt" | "decide" | "reconcile")[] = [
	"register", "grant-start", "observe", "cancel", "resolve-external", "begin-resume", "finish-resume", "publish-receipt", "decide", "reconcile",
];

// ── decide accept 前置与强制豁免（v2.3，ev-20260918-0784ed） ──────────────────

/** decide(accept) 的合法执行前置（v2.3 扩至 error）：error 是「外部采用收口」——接受的是
 *  「产物已被外部核采用」的事实而非执行成功本身，故必须显式 waive
 *  {@link ERROR_EXECUTION_COVERAGE_GAP_ID}（无该豁免的 error accept 由内核整单拒绝，effects=none）。
 *  前置语义属内核 plan 校验（本契约层只冻结字面集合，不做执行态校验）。 */
export const DECIDE_ACCEPT_EXECUTIONS: readonly ExecutionState[] = ["done", "truncated", "error"];

/** execution=error 的 decide(accept) 强制豁免缺口注记 id（v2.3，ev-20260918-0784ed）——
 *  与 finalizer.ts ERROR_EXEC_GAP_ID（回执 missing 注记权威）同字面双处定义（内核不 import
 *  执行后端防循环依赖）；漂移由 tests/v2-decide-error-accept.test.mjs 源断言看守。 */
export const ERROR_EXECUTION_COVERAGE_GAP_ID = "error-execution-coverage";

// ── 公共端口（§3.3：TaskApplication/TaskKernel/TaskStore） ─────────────────────

export interface TaskApplication {
	submit(input: SubmitInput, caller: CallerContext): Promise<Result<TaskView>>;
	resume(handle: string, message: string, caller: CallerContext): Promise<Result<TaskView>>;
	control(command: ControlCommand, caller: CallerContext): Promise<Result<readonly TaskView[]>>;
	query(query: TaskQuery): Promise<Result<TaskPage>>;
}

export interface TaskKernel {
	apply(command: KernelCommand): Promise<Result<TaskView>>;
	get(taskId: string): Readonly<TaskView> | undefined;
}

export interface TaskStore {
	saveSpec(spec: Readonly<TaskSpec>): Promise<Ref>;
	saveReceipt(receipt: Readonly<TaskReceipt>): Promise<Ref>;
	replaceCurrent(expectedSeq: number | null, run: Readonly<TaskRun>): Promise<void>;
	load(taskId: string): Promise<Result<{ spec: TaskSpec; run: TaskRun; receipt?: TaskReceipt }>>;
}

// ── 校验器 ────────────────────────────────────────────────────────────────────

function invalidField(field: string, message: string) {
	return err(CONTRACT_ERROR_CODES.INVALID_FIELD, message, [field]);
}

function validateHandles(v: unknown, field: string): Result<readonly string[]> {
	if (!Array.isArray(v) || v.length === 0) {
		return invalidField(field, `${field} 必须是非空字符串数组（空清单的控制动作无意义，整单拒绝）`);
	}
	for (let i = 0; i < v.length; i++) {
		if (!isNonEmptyString(v[i])) return invalidField(`${field}[${i}]`, `${field}[${i}] 必须是非空字符串`);
	}
	return ok(v as readonly string[]);
}

export function validateSubmitInput(v: unknown): Result<SubmitInput> {
	// ev-20260919（P0-1）：null 值键视为缺席（strict 采样全字段携带的序列化伪影——嵌套 scope/outputs 同样被 nullable 化）。
	const input = deepStripNulls(v);
	if (!isRecord(input)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "input 必须是对象", ["input"]);
	const shape = rejectUnknownKeys(input, ["agent", "assignment", "inputs", "outputs", "scope", "workspace", "profile", "contextMode", "parentTaskId"], "input");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["input"]);
	if (!isNonEmptyString(input.agent)) return invalidField("input.agent", "input.agent 必须是非空字符串");
	if (!isNonEmptyString(input.assignment)) return invalidField("input.assignment", "input.assignment 必须是非空字符串");
	if (input.inputs !== undefined) {
		if (!Array.isArray(input.inputs)) return invalidField("input.inputs", "input.inputs 必须是数组（path/purpose/required）");
		for (let i = 0; i < input.inputs.length; i++) {
			const r = input.inputs[i];
			const f = `input.inputs[${i}]`;
			if (!isRecord(r)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${f} 必须是对象`, [f]);
			const rShape = rejectUnknownKeys(r, ["path", "purpose", "required"], f);
			if (rShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, rShape, [f]);
			if (!isNonEmptyString(r.path)) return invalidField(`${f}.path`, `${f}.path 必须是非空字符串`);
			if (!isNonEmptyString(r.purpose)) return invalidField(`${f}.purpose`, `${f}.purpose 必须是非空字符串`);
			if (r.required !== undefined && typeof r.required !== "boolean") return invalidField(`${f}.required`, `${f}.required 必须是布尔值`);
		}
	}
	if (input.outputs !== undefined) {
		if (!Array.isArray(input.outputs)) return invalidField("input.outputs", "input.outputs 必须是数组（path/kind/required）");
		for (let i = 0; i < input.outputs.length; i++) {
			const o = input.outputs[i];
			const f = `input.outputs[${i}]`;
			if (!isRecord(o)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${f} 必须是对象`, [f]);
			const oShape = rejectUnknownKeys(o, ["path", "kind", "required", "purpose"], f); // ev-20260919：purpose 与 inputs 对称
			if (oShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, oShape, [f]);
			if (!isNonEmptyString(o.path)) return invalidField(`${f}.path`, `${f}.path 必须是非空字符串`);
			if (o.kind !== undefined && o.kind !== "file" && o.kind !== "tree") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `${f}.kind 必须是 file/tree 之一`, [`${f}.kind`]);
			}
			if (o.required !== undefined && typeof o.required !== "boolean") return invalidField(`${f}.required`, `${f}.required 必须是布尔值`);
		}
	}
	if (input.scope !== undefined) {
		if (!isRecord(input.scope)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "input.scope 必须是对象", ["input.scope"]);
		const sShape = rejectUnknownKeys(input.scope, ["read", "write", "deny", "reportFiles", "shell", "mcp", "lsp", "codemode", "advisor"], "input.scope");
		if (sShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, sShape, ["input.scope"]);
		for (const f of ["read", "write", "deny", "reportFiles", "mcp"] as const) {
			if (input.scope[f] !== undefined) {
				if (!Array.isArray(input.scope[f])) return invalidField(`input.scope.${f}`, `input.scope.${f} 必须是字符串数组`);
				for (let i = 0; i < input.scope[f]!.length; i++) {
					if (!isNonEmptyString(input.scope[f]![i])) return invalidField(`input.scope.${f}[${i}]`, `input.scope.${f}[${i}] 必须是非空字符串`);
				}
			}
		}
		if (input.scope.shell !== undefined && !SHELL_CHANNEL_REQUESTS.includes(input.scope.shell as ShellChannelRequest)) {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.scope.shell 必须是 deny/guarded/optional 之一（guarded=必需交集拒绝；optional=交集为空降级 deny+告警）", ["input.scope.shell"]);
		}
		if (input.scope.lsp !== undefined) {
			if (!Array.isArray(input.scope.lsp)) return invalidField("input.scope.lsp", "input.scope.lsp 必须是数组");
			for (let i = 0; i < input.scope.lsp.length; i++) {
				const cap = input.scope.lsp[i]!;
				if (cap !== "diagnostics" && cap !== "definition" && cap !== "references" && cap !== "hover" && cap !== "rename") {
					return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `input.scope.lsp[${i}] 非法能力名`, [`input.scope.lsp[${i}]`]);
				}
			}
		}
		if (input.scope.advisor !== undefined && input.scope.advisor !== "consult") return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "scope.advisor 只认 consult", ["input.scope.advisor"]);
		// B5A 修复轮 F10：codemode 枚举校验独立于 lsp 字段存在性（封闭契约不因无关字段改变合法性）。
		if (input.scope.codemode !== undefined && input.scope.codemode !== "read-only") {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.scope.codemode 只认 read-only（显式请求才准入；无 on/full/write 值）", ["input.scope.codemode"]);
		}
	}
	if (input.workspace !== undefined) {
		if (!isRecord(input.workspace)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "input.workspace 必须是对象", ["input.workspace"]);
		const wShape = rejectUnknownKeys(input.workspace, ["cwd", "mode", "worktreeName", "dependencyVisibility", "base"], "input.workspace");
		if (wShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, wShape, ["input.workspace"]);
		if (input.workspace.cwd !== undefined && !isNonEmptyString(input.workspace.cwd)) return invalidField("input.workspace.cwd", "input.workspace.cwd 必须是非空字符串");
		if (input.workspace.mode !== undefined && input.workspace.mode !== "existing" && input.workspace.mode !== "worktree") {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.workspace.mode 必须是 existing/worktree 之一", ["input.workspace.mode"]);
		}
		if (input.workspace.worktreeName !== undefined && !isNonEmptyString(input.workspace.worktreeName)) return invalidField("input.workspace.worktreeName", "input.workspace.worktreeName 必须是非空字符串");
		const dv = input.workspace.dependencyVisibility;
		if (dv !== undefined && dv !== "portable" && dv !== "main-tree" && dv !== "unknown") {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.workspace.dependencyVisibility 必须是 portable/main-tree/unknown 之一", ["input.workspace.dependencyVisibility"]);
		}
		const wb = input.workspace.base;
		if (wb !== undefined && wb !== "head" && wb !== "dirty-snapshot") {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.workspace.base 必须是 head/dirty-snapshot 之一", ["input.workspace.base"]);
		}
	}
	if (input.profile !== undefined && !isNonEmptyString(input.profile)) return invalidField("input.profile", "input.profile 必须是受信配置中的 profile 名");
	if (input.contextMode !== undefined && input.contextMode !== "isolated" && input.contextMode !== "selected" && input.contextMode !== "fork") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "input.contextMode 必须是 isolated/selected/fork 之一", ["input.contextMode"]);
	}
	if (input.parentTaskId !== undefined && !isNonEmptyString(input.parentTaskId)) return invalidField("input.parentTaskId", "input.parentTaskId 必须是非空字符串");
	return ok(v as unknown as SubmitInput);
}

export function validateCallerContext(v: unknown): Result<CallerContext> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "caller 必须是对象（仅由组合根提供，不能从模型参数构造）", ["caller"]);
	const shape = rejectUnknownKeys(v, ["ownerId", "actor", "actorId", "authority"], "caller");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["caller"]);
	if (!isNonEmptyString(v.ownerId)) return invalidField("caller.ownerId", "caller.ownerId 必须是非空字符串（稳定 Leader 逻辑身份）");
	if (v.actor !== "leader" && v.actor !== "user") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "caller.actor 必须是 leader/user 之一", ["caller.actor"]);
	}
	if (!isNonEmptyString(v.actorId)) return invalidField("caller.actorId", "caller.actorId 必须是非空字符串");
	if (!isRecord(v.authority)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "caller.authority 必须是对象", ["caller.authority"]);
	const aShape = rejectUnknownKeys(v.authority, ["maxAssurance", "profiles", "facets"], "caller.authority");
	if (aShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, aShape, ["caller.authority"]);
	if (v.authority.maxAssurance !== "tool-enforced" && v.authority.maxAssurance !== "guarded") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "caller.authority.maxAssurance 必须是 tool-enforced/guarded 之一", ["caller.authority.maxAssurance"]);
	}
	if (!Array.isArray(v.authority.profiles)) return invalidField("caller.authority.profiles", "caller.authority.profiles 必须是字符串数组");
	if (!Array.isArray(v.authority.facets)) return invalidField("caller.authority.facets", "caller.authority.facets 必须是数组");
	for (const f of v.authority.facets) {
		if (f !== "batch") return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "caller.authority.facets 只接受 batch", ["caller.authority.facets"]);
	}
	return ok(v as unknown as CallerContext);
}

export function validateControlCommand(v: unknown): Result<ControlCommand> {
	// ev-20260919（P0-1）：null 值键视为缺席（strict 采样全字段携带的序列化伪影）——剥后再校验。
	const input = deepStripNulls(v);
	if (!isRecord(input)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "command 必须是对象", ["command"]);
	switch (input.action) {
		case "wait": {
			const shape = rejectUnknownKeys(input, ["action", "handles", "mode", "timeoutMs"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const handles = validateHandles(input.handles, "command.handles");
			if (!handles.ok) return handles;
			if (input.mode !== undefined && input.mode !== "any" && input.mode !== "all") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "command.mode 必须是 any/all 之一", ["command.mode"]);
			}
			if (input.timeoutMs !== undefined && !isNonNegativeInt(input.timeoutMs)) {
				return invalidField("command.timeoutMs", "command.timeoutMs 必须是非负整数毫秒（超时只观察，不取消）");
			}
			return ok(input as unknown as ControlCommand);
		}
		case "cancel":
		case "resolve-external":
		case "reconcile": {
			const shape = rejectUnknownKeys(input, ["action", "handles", "reason"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const handles = validateHandles(input.handles, "command.handles");
			if (!handles.ok) return handles;
			if (!isNonEmptyString(input.reason)) return invalidField("command.reason", `command.reason 必须是非空字符串（${input.action} 须可追溯）`);
			return ok(input as unknown as ControlCommand);
		}
		case "steer": {
			// steer 用单一 handle + message：对 queued/running 任务投递运行中调整（通道见 task-steer.ts）。
			const shape = rejectUnknownKeys(input, ["action", "handle", "message"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			if (!isNonEmptyString(input.handle)) return invalidField("command.handle", "command.handle 必须是非空字符串（steer 单一 handle）");
			if (!isNonEmptyString(input.message)) return invalidField("command.message", "command.message 必须是非空字符串（运行中调整指令）");
			return ok(input as unknown as ControlCommand);
		}
		case "accept":
		case "reject": {
			// accept/reject 用单一 handle，必带 receiptId/expectedRevision/reason；accept 可携显式 waivedCheckIds。
			const shape = rejectUnknownKeys(input, ["action", "handle", "receiptId", "expectedRevision", "reason", "waivedCheckIds"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			if (!isNonEmptyString(input.handle)) return invalidField("command.handle", "command.handle 必须是非空字符串（accept/reject 单一 handle）");
			if (!isNonEmptyString(input.receiptId)) return invalidField("command.receiptId", "command.receiptId 必须是非空字符串（决策引用当前回执）");
			if (!isNonNegativeInt(input.expectedRevision)) return invalidField("command.expectedRevision", "command.expectedRevision 必须是非负整数（失效栅栏）");
			if (!isNonEmptyString(input.reason)) return invalidField("command.reason", "command.reason 必须是非空字符串");
			if (input.waivedCheckIds !== undefined) {
				if (input.action === "reject") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "reject 不接受 waivedCheckIds（只有 accept 可豁免检查）", ["command.waivedCheckIds"]);
				if (!Array.isArray(input.waivedCheckIds)) return invalidField("command.waivedCheckIds", "command.waivedCheckIds 必须是字符串数组");
				for (let i = 0; i < input.waivedCheckIds.length; i++) {
					if (!isNonEmptyString(input.waivedCheckIds[i])) return invalidField(`command.waivedCheckIds[${i}]`, `command.waivedCheckIds[${i}] 必须是非空字符串`);
				}
			}
			// ev-20261021-fix（diting F1）：撤销无条件 UUID 形状栅栏——发布面 validateTaskReceiptForPublish
			// 对 receiptId 形态开放（历史/合成回执仍是可成功发布的合法契约对象），工具单端收紧会造成
			// 「发布/存储认为合法、决策通道永久拒绝」的契约断裂。形状检查降级为不匹配输入的诊断增强：
			// 非当前 receiptId 的 stale-receipt 报错附形状可疑提示（task-facets/task-service 同源）。
			return ok(input as unknown as ControlCommand);
		}
		default:
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `command.action 必须是 ${CONTROL_ACTIONS.join("/")} 之一`, ["command.action"]);
	}
}

export function validateKernelCommand(v: unknown): Result<KernelCommand> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "command 必须是对象", ["command"]);
	switch (v.type) {
		case "register": {
			const shape = rejectUnknownKeys(v, ["type", "spec", "groupId", "nodeId"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const spec = validateTaskSpec(v.spec);
			if (!spec.ok) return spec;
			if (v.groupId !== undefined && !isNonEmptyString(v.groupId)) return invalidField("command.groupId", "command.groupId 必须是非空字符串");
			if (v.nodeId !== undefined && !isNonEmptyString(v.nodeId)) return invalidField("command.nodeId", "command.nodeId 必须是非空字符串");
			return ok(v as unknown as KernelCommand);
		}
		case "grant-start": {
			const shape = rejectUnknownKeys(v, ["type", "key", "backend", "launchIntent"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (v.backend !== "json" && v.backend !== "rpc") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "command.backend 必须是 json/rpc 之一", ["command.backend"]);
			}
			if (!isRecord(v.launchIntent)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "command.launchIntent 必须是对象（持久化后才允许 spawn）", ["command.launchIntent"]);
			const liShape = rejectUnknownKeys(v.launchIntent, ["nonce", "at"], "command.launchIntent");
			if (liShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, liShape, ["command.launchIntent"]);
			if (!isNonEmptyString(v.launchIntent.nonce)) return invalidField("command.launchIntent.nonce", "command.launchIntent.nonce 必须是非空字符串");
			if (!isNonNegativeInt(v.launchIntent.at)) return invalidField("command.launchIntent.at", "command.launchIntent.at 必须是非负整数");
			return ok(v as unknown as KernelCommand);
		}
		case "observe": {
			const shape = rejectUnknownKeys(v, ["type", "key", "backendRunId", "observationSeq", "event"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (!isNonEmptyString(v.backendRunId)) return invalidField("command.backendRunId", "command.backendRunId 必须是非空字符串");
			if (!isNonNegativeInt(v.observationSeq)) return invalidField("command.observationSeq", "command.observationSeq 必须是非负整数（单次后端内递增；重复序号无副作用）");
			const event = validateExecutionEvent(v.event);
			if (!event.ok) return event;
			return ok(v as unknown as KernelCommand);
		}
		case "cancel":
		case "resolve-external": {
			const shape = rejectUnknownKeys(v, ["type", "key", "reason"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (!isNonEmptyString(v.reason)) return invalidField("command.reason", `command.reason 必须是非空字符串（${v.type} 须可追溯）`);
			return ok(v as unknown as KernelCommand);
		}
		case "begin-resume": {
			const shape = rejectUnknownKeys(v, ["type", "key", "lease"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (!isRecord(v.lease)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "command.lease 必须是对象（session lease 防并发续接）", ["command.lease"]);
			const lShape = rejectUnknownKeys(v.lease, ["holder", "nonce", "at"], "command.lease");
			if (lShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, lShape, ["command.lease"]);
			if (!isNonEmptyString(v.lease.holder)) return invalidField("command.lease.holder", "command.lease.holder 必须是非空字符串");
			if (!isNonEmptyString(v.lease.nonce)) return invalidField("command.lease.nonce", "command.lease.nonce 必须是非空字符串");
			if (!isNonNegativeInt(v.lease.at)) return invalidField("command.lease.at", "command.lease.at 必须是非负整数");
			return ok(v as unknown as KernelCommand);
		}
		case "finish-resume": {
			const shape = rejectUnknownKeys(v, ["type", "key", "outcome", "reason", "successorTaskId"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (v.outcome !== "answered" && v.outcome !== "blocked") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "command.outcome 必须是 answered/blocked 之一（启动失败回 blocked 走内核）", ["command.outcome"]);
			}
			if (!isNonEmptyString(v.reason)) return invalidField("command.reason", "command.reason 必须是非空字符串");
			if (v.successorTaskId !== undefined && !isNonEmptyString(v.successorTaskId)) return invalidField("command.successorTaskId", "command.successorTaskId 必须是非空字符串");
			return ok(v as unknown as KernelCommand);
		}
		case "publish-receipt": {
			const shape = rejectUnknownKeys(v, ["type", "key", "receipt"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			// D1（ev-20260922-c896f8）：发布面走 validateTaskReceiptForPublish（叠加 evidence link 校验——
			// 检查 id 唯一、机器检查缺口只引用 checks[].id）；旧回执读取仍走 validateTaskReceipt（宽容）。
			const receipt = validateTaskReceiptForPublish(v.receipt);
			if (!receipt.ok) return receipt;
			return ok(v as unknown as KernelCommand);
		}
		case "decide": {
			const shape = rejectUnknownKeys(v, ["type", "key", "receiptId", "verdict", "decision"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (!isNonEmptyString(v.receiptId)) return invalidField("command.receiptId", "command.receiptId 必须是非空字符串（决策引用当前回执）");
			// K1 改版 v1.1（Leader 集成负责人裁定，2026-09-16）：decide 增 verdict 判别字段——
			// reject 表达“不接受当前回执”（含 failed 回执），accept 才走 waive 门槛；方案 §3.3 ControlCommand 同构。
			// v2.3（ev-20260918-0784ed）：accept 合法前置从 done/truncated 扩至 +error（DECIDE_ACCEPT_EXECUTIONS）
			// ——error 终态产物被外部核验采用后的收口路径；error 前置必须显式 waive
			// ERROR_EXECUTION_COVERAGE_GAP_ID（执行语义门槛在内核 plan，此处只冻结命令形状）。
			if (v.verdict !== "accept" && v.verdict !== "reject") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "command.verdict 必须是 accept/reject 之一（K1 v1.1：显式判别接受/拒绝，取消后的完成记录用 reject 表达不接受）", ["command.verdict"]);
			}
			if (!isRecord(v.decision)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "command.decision 必须是对象", ["command.decision"]);
			const dShape = rejectUnknownKeys(v.decision, ["actor", "reason", "waivedCheckIds"], "command.decision");
			if (dShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, dShape, ["command.decision"]);
			if (v.decision.actor !== "leader" && v.decision.actor !== "user") {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "command.decision.actor 必须是 leader/user 之一（入口身份提供，子进程 DONE 标记不能调用 decide）", ["command.decision.actor"]);
			}
			if (!isNonEmptyString(v.decision.reason)) return invalidField("command.decision.reason", "command.decision.reason 必须是非空字符串");
			if (!Array.isArray(v.decision.waivedCheckIds)) return invalidField("command.decision.waivedCheckIds", "command.decision.waivedCheckIds 必须是字符串数组");
			for (let i = 0; i < v.decision.waivedCheckIds.length; i++) {
				if (!isNonEmptyString(v.decision.waivedCheckIds[i])) return invalidField(`command.decision.waivedCheckIds[${i}]`, `command.decision.waivedCheckIds[${i}] 必须是非空字符串`);
			}
			return ok(v as unknown as KernelCommand);
		}
		case "reconcile": {
			const shape = rejectUnknownKeys(v, ["type", "key", "facts", "disposition"], "command");
			if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["command"]);
			const key = validateTaskKey(v.key, "command.key");
			if (!key.ok) return key;
			if (!Array.isArray(v.facts)) return invalidField("command.facts", "command.facts 必须是数组（只确认可观察事实，不自动重放任务）");
			for (let i = 0; i < v.facts.length; i++) {
				const f = v.facts[i];
				const ff = `command.facts[${i}]`;
				if (!isRecord(f)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${ff} 必须是对象`, [ff]);
				const fShape = rejectUnknownKeys(f, ["code", "detail"], ff);
				if (fShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, fShape, [ff]);
				if (!isNonEmptyString(f.code)) return invalidField(`${ff}.code`, `${ff}.code 必须是非空字符串`);
				if (typeof f.detail !== "string") return invalidField(`${ff}.detail`, `${ff}.detail 必须是字符串`);
			}
			const dispositions: readonly ReconcileDisposition[] = ["needs-reconciliation", "close-unexecuted", "confirm-exited", "manual-takeover"];
			if (!dispositions.includes(v.disposition as ReconcileDisposition)) {
				return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `command.disposition 必须是 ${dispositions.join("/")} 之一`, ["command.disposition"]);
			}
			return ok(v as unknown as KernelCommand);
		}
		default:
			return err(
				CONTRACT_ERROR_CODES.INVALID_ENUM,
				`command.type 必须是 ${KERNEL_COMMAND_TYPES.join("/")} 之一（封闭命令集，不暴露通用 patch）`,
				["command.type"],
			);
	}
}
