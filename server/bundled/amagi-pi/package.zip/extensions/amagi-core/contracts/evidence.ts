/**
 * contracts/evidence.ts — 验证对象与检查结果契约（amagi-pi v2 K1，方案 §3.2 / §7）。
 *
 * 依赖方向：evidence → view（Ref/Result 共享原语）。N7 证据不变量的纯校验面：
 * passed 必须有实际对象（objectId）、检查配置（policyDigest/argv）、时间（startedAt/endedAt）
 * 和退出事实（exitCode=0）；未知、未运行不能变 passed——回执校验器不解析展示文本推导结论。
 */
import {
	CONTRACT_ERROR_CODES,
	err,
	isNonEmptyString,
	isNonNegativeInt,
	isRecord,
	ok,
	rejectUnknownKeys,
	validateRef,
	type Ref,
	type Result,
} from "./view.ts";

export type CheckStatus = "passed" | "failed" | "not-run" | "unavailable" | "timed-out" | "error" | "object-changed";
export const CHECK_STATUSES: readonly CheckStatus[] = ["passed", "failed", "not-run", "unavailable", "timed-out", "error", "object-changed"];

export type VerificationMode = "snapshot" | "shared-tree";
export const VERIFICATION_MODES: readonly VerificationMode[] = ["snapshot", "shared-tree"];

/** 验证对象：检查运行所处的冻结内容与环境快照（§7.1）。 */
export interface VerificationObject {
	id: string;
	manifest: Ref;
	mode: VerificationMode;
	cwd: string;
	sourceCwd: string;
	capturedAt: number;
	environmentDigest: string;
	limitations: readonly string[];
}

export function validateVerificationObject(v: unknown): Result<VerificationObject> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "object 必须是对象", ["object"]);
	const shape = rejectUnknownKeys(v, ["id", "manifest", "mode", "cwd", "sourceCwd", "capturedAt", "environmentDigest", "limitations"], "object");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["object"]);
	if (!isNonEmptyString(v.id)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.id 必须是非空字符串", ["object.id"]);
	const manifest = validateRef(v.manifest, "object.manifest");
	if (!manifest.ok) return manifest;
	if (!VERIFICATION_MODES.includes(v.mode as VerificationMode)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `object.mode 必须是 ${VERIFICATION_MODES.join("/")} 之一`, ["object.mode"]);
	}
	if (!isNonEmptyString(v.cwd)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.cwd 必须是非空字符串", ["object.cwd"]);
	if (!isNonEmptyString(v.sourceCwd)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.sourceCwd 必须是非空字符串", ["object.sourceCwd"]);
	if (!isNonNegativeInt(v.capturedAt)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.capturedAt 必须是非负整数（epoch ms）", ["object.capturedAt"]);
	if (!isNonEmptyString(v.environmentDigest)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.environmentDigest 必须是非空字符串", ["object.environmentDigest"]);
	if (!Array.isArray(v.limitations)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "object.limitations 必须是字符串数组", ["object.limitations"]);
	for (let i = 0; i < v.limitations.length; i++) {
		if (typeof v.limitations[i] !== "string") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `object.limitations[${i}] 必须是字符串`, [`object.limitations[${i}]`]);
	}
	return ok(v as unknown as VerificationObject);
}

/** B10（ev-20261008-eb1e27，主上裁定②）：兄弟切片干扰豁免标注。
 *  检查状态保持真实（object-changed/failed 不改写），但豁免成立（漂移/失败所涉文件均不在本任务
 *  own 写面、own 写面对象执行前后复核未变）时结算面不把该项记入 failed/missing；豁免依据
 *  （所涉文件清单、归属并行写面、own 复核事实）在 detail 显式披露——回执/详情可追溯，人工验收
 *  仍可否决（acceptance 面不受影响）。 */
export interface CheckExemption {
	kind: "sibling-interference";
	detail: string;
}

/** 单项检查结果：必须关联同一 VerificationObject.id、策略 digest、实际 cwd/argv、退出码、时间与日志引用（§7.2）。 */
export interface CheckResult {
	id: CheckId;
	required: boolean;
	objectId: string;
	policyDigest: string;
	status: CheckStatus;
	argv: readonly string[];
	cwd: string;
	startedAt?: number;
	endedAt?: number;
	exitCode?: number;
	log?: Ref;
	/** B10：兄弟切片干扰豁免（可选；缺省=历史记录零变化——旧回执/日志原样可读）。 */
	exemption?: CheckExemption;
}

export function validateCheckResult(v: unknown): Result<CheckResult> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "check 必须是对象", ["check"]);
	const shape = rejectUnknownKeys(v, ["id", "required", "objectId", "policyDigest", "status", "argv", "cwd", "startedAt", "endedAt", "exitCode", "log", "exemption"], "check");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["check"]);
	if (!isNonEmptyString(v.id)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.id 必须是非空字符串", ["check.id"]);
	if (typeof v.required !== "boolean") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.required 必须是布尔值", ["check.required"]);
	if (!isNonEmptyString(v.objectId)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.objectId 必须是非空字符串（N7：passed 须有实际对象）", ["check.objectId"]);
	if (!isNonEmptyString(v.policyDigest)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.policyDigest 必须是非空字符串", ["check.policyDigest"]);
	if (!CHECK_STATUSES.includes(v.status as CheckStatus)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `check.status 必须是 ${CHECK_STATUSES.join("/")} 之一`, ["check.status"]);
	}
	if (!Array.isArray(v.argv)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.argv 必须是字符串数组", ["check.argv"]);
	for (let i = 0; i < v.argv.length; i++) {
		if (typeof v.argv[i] !== "string") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `check.argv[${i}] 必须是字符串`, [`check.argv[${i}]`]);
	}
	if (!isNonEmptyString(v.cwd)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.cwd 必须是非空字符串", ["check.cwd"]);
	if (v.startedAt !== undefined && !isNonNegativeInt(v.startedAt)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.startedAt 必须是非负整数", ["check.startedAt"]);
	if (v.endedAt !== undefined && !isNonNegativeInt(v.endedAt)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.endedAt 必须是非负整数", ["check.endedAt"]);
	if (v.exitCode !== undefined && !Number.isInteger(v.exitCode)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.exitCode 必须是整数", ["check.exitCode"]);
	if (v.log !== undefined) {
		const log = validateRef(v.log, "check.log");
		if (!log.ok) return log;
	}
	// B10（ev-20261008-eb1e27）：豁免标注封闭校验（kind 封闭枚举；detail 非空有界——回执面防注入）。
	if (v.exemption !== undefined) {
		const ex = v.exemption as { kind?: unknown; detail?: unknown };
		if (!ex || typeof ex !== "object" || ex.kind !== "sibling-interference"
			|| typeof ex.detail !== "string" || ex.detail.trim() === "" || ex.detail.length > 1024) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, 'check.exemption 必须是 { kind: "sibling-interference", detail: 非空字符串（≤1024 字符） }', ["check.exemption"]);
		}
	}
	// N7：passed 必须有时间与退出事实——无退出事实/退出码非 0/缺时间戳的 passed 一律拒绝；
	// 超时或 spawn 失败保留各自状态（timed-out/unavailable/error），不归入 failed。
	if (v.status === "passed") {
		if (v.startedAt === undefined || v.endedAt === undefined) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "status=passed 必须携带 startedAt/endedAt（N7：时间事实）", ["check.startedAt", "check.endedAt", "check.status"]);
		}
		if (v.endedAt < v.startedAt) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "check.endedAt 不得早于 startedAt", ["check.endedAt"]);
		}
		if (v.exitCode !== 0) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "status=passed 必须 exitCode=0（N7：退出事实）", ["check.exitCode", "check.status"]);
		}
	}
	return ok(v as unknown as CheckResult);
}

// ── D1（ev-20260922-c896f8，方案 §2.9）：missing/checks 单一 id 口径 ──────────────
//
// 裁决：checks 的完整记录 id（CheckId）是机器检查唯一可引用 id，状态不编码进 id；
// 检查规格名（CheckSpecId）只用于配置面（StructuredCheckSpec.id / AUTO_CHECK_ID 等），
// 不作为回执引用 id。非检查缺口保有自身稳定 GapId（§非检查缺口注册面），不能把
// artifact/error 缺口伪装成机器检查。本段全部为纯函数：随机 id 分配留在 IO/执行层
// newCheckId（evidence.ts），contracts 不引入 crypto/fs。

/** 机器检查记录 id（回执/decide 引用面唯一可引用的检查 id——状态不编码进 id）。 */
export type CheckId = string & { readonly __checkId: unique symbol };
/** 检查规格名（规格配置面：StructuredCheckSpec.id、AUTO_CHECK_ID 等；不作为回执引用 id）。 */
export type CheckSpecId = string & { readonly __checkSpecId: unique symbol };

/** 受信字符串 → CheckId（IO/执行层构造 CheckResult 时使用；contracts 不分配随机 id）。 */
export function asCheckId(s: string): CheckId {
	return s as CheckId;
}
/** 字符串 → CheckSpecId（受信规格配置面构造）。 */
export function asCheckSpecId(s: string): CheckSpecId {
	return s as CheckSpecId;
}

/** 非检查缺口稳定 GapId——精确注册面（新增 GapId 必须先在此注册，拒绝临时拼接 check 状态）。
 *  error-execution-coverage（内核：error 执行态结算缺口）、truncation-coverage（finalizer：截断缺口）、
 *  manual-acceptance:not-declared / artifact-integrity:cwd-missing / artifact-integrity:not-declared
 *  （deriveSettlementFace：缺机器检查任务的两面缺口）。这些缺口不要求出现在 checks。 */
export const NON_CHECK_GAP_EXACT_IDS: readonly string[] = [
	"error-execution-coverage",
	"truncation-coverage",
	"manual-acceptance:not-declared",
	"artifact-integrity:cwd-missing",
	"artifact-integrity:not-declared",
];
/** 非检查缺口前缀注册面：artifact-integrity:<path>:<problem>（路径动态，按前缀注册）。 */
export const NON_CHECK_GAP_PREFIXES: readonly string[] = ["artifact-integrity:"];

/** 非检查缺口判定（纯函数）：精确命中或已注册前缀命中。 */
export function isNonCheckGapId(id: string): boolean {
	if (NON_CHECK_GAP_EXACT_IDS.includes(id)) return true;
	return NON_CHECK_GAP_PREFIXES.some((p) => id.startsWith(p));
}

/** evidence link 校验入参（结构化——不从 contracts/evidence 反向导入 TaskReceipt，避免 task→evidence→task 循环）。 */
export interface ReceiptEvidenceLinkInput {
	checks: readonly CheckResult[];
	missing: readonly string[];
}

/**
 * 新回执发布前的 evidence link 校验（§2.9；纯函数）：
 *   1. 检查记录 id 唯一（重复 id 拒绝）；
 *   2. 机器检查缺口只引用 checks[].id（悬空引用拒绝）；
 *   3. 非检查缺口必须是已注册 GapId（isNonCheckGapId）；`id:status` 拼接（状态编码进 id）拒绝。
 * 仅用于新发布（validateTaskReceiptForPublish）；旧回执读取（validateTaskReceipt）保持宽容——
 * 历史回执的 `id:status`/短名形态照实读入，decide 对其仍使用实际存储 id。
 */
export function validateReceiptEvidenceLinks(v: ReceiptEvidenceLinkInput): Result<null> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "evidence link 输入必须是对象", ["evidenceLinks"]);
	if (!Array.isArray(v.checks)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "evidenceLinks.checks 必须是数组", ["evidenceLinks.checks"]);
	if (!Array.isArray(v.missing)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "evidenceLinks.missing 必须是数组", ["evidenceLinks.missing"]);
	const seen = new Set<string>();
	for (let i = 0; i < v.checks.length; i++) {
		const c = v.checks[i];
		if (!isRecord(c) || typeof c.id !== "string") {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `checks[${i}] 缺有效 id`, [`checks[${i}].id`]);
		}
		if (seen.has(c.id)) {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `检查记录 id 重复：${c.id}（回执检查 id 必须唯一——每次执行/重验分配新 id）`, ["checks"], "none", [{ hint: "重复提交的检查记录应各分配一次完整 CheckId（newCheckId），不得复用同 id" }]);
		}
		seen.add(c.id);
	}
	const checkIds = new Set(v.checks.map((c) => (isRecord(c) && typeof c.id === "string" ? c.id : "")));
	for (let i = 0; i < v.missing.length; i++) {
		const gap = v.missing[i];
		if (typeof gap !== "string" || gap === "") {
			return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `missing[${i}] 必须是非空字符串`, [`missing[${i}]`]);
		}
		if (isNonCheckGapId(gap)) continue;
		if (checkIds.has(gap)) continue;
		const colon = gap.lastIndexOf(":");
		if (colon > 0 && CHECK_STATUSES.includes(gap.slice(colon + 1) as CheckStatus)) {
			return err(
				CONTRACT_ERROR_CODES.INVALID_FIELD,
				`missing[${i}]=${gap} 把状态编码进了 id（旧 id:status 拼接形态）——机器检查缺口只引用 checks[].id，状态保存在 CheckResult.status`,
				[`missing[${i}]`], "none",
				[{ hint: `改为只引用检查记录 id：${JSON.stringify(gap.slice(0, colon))}（状态由对应 check 的 status 字段承载）` }],
			);
		}
		return err(
			CONTRACT_ERROR_CODES.INVALID_FIELD,
			`missing[${i}]=${gap} 既非已注册非检查 GapId（新增 GapId 必须在 NON_CHECK_GAP_EXACT_IDS/PREFIXES 注册），也未引用任何 checks[].id（悬空机器检查引用）`,
			[`missing[${i}]`], "none",
			[{ hint: "机器检查缺口必须先产出真实 CheckResult（含完整 id）再引用该 id；非检查缺口用稳定 GapId 并在 contracts 注册" }],
		);
	}
	return ok(null);
}

/** 可 waive id 全集输入（结构化；decide 面与展示面共用口径）。 */
export interface WaiverIdSource {
	checks: readonly { id: string }[];
	missing: readonly string[];
}

/**
 * 可 waive id 全集（§2.9；纯函数，唯一来源）：当前回执 missing ∪ checks[].id，去重、稳定顺序
 * （missing 存储序在前，checks.id 序在后）。旧回执照实取存储字面量（含 id:status 形态）——
 * 不猜测映射、不剥离后缀；decide 对旧回执仍使用实际存储 id。
 */
export function availableWaiverIds(source: WaiverIdSource): string[] {
	const seen = new Set<string>();
	const out: string[] = [];
	const push = (id: unknown): void => {
		if (typeof id !== "string" || id === "" || seen.has(id)) return;
		seen.add(id);
		out.push(id);
	};
	if (Array.isArray(source.missing)) for (const m of source.missing) push(m);
	if (Array.isArray(source.checks)) for (const c of source.checks) push(c?.id);
	return out;
}

/**
 * 旧回执 `id:status` 拼接形态识别（仅展示适配用；纯函数）：拆出的 id 部分必须精确匹配
 * 本回执 checks[].id（唯一识别——不猜 hash、不截字符串做多义映射）；状态后缀必须是已知
 * CheckStatus。无法唯一识别返回 null（调用方保留原 literal id 展示，decide 引用照旧）。
 */
export function splitLegacyCheckGapId(gapId: string, checkIds: readonly string[]): { checkId: string; status: CheckStatus } | null {
	const colon = gapId.lastIndexOf(":");
	if (colon <= 0) return null;
	const status = gapId.slice(colon + 1);
	if (!CHECK_STATUSES.includes(status as CheckStatus)) return null;
	const checkId = gapId.slice(0, colon);
	return checkIds.includes(checkId) ? { checkId, status: status as CheckStatus } : null;
}
