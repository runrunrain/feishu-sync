/** 桌面委托声明。apps 是可选目标提示，不承担应用隔离或调用许可。 */
export interface ComputerUseGrant {
	readonly apps?: readonly string[];
}

/** 校验输入形状；不要求重复配置应用许可。 */
export function computerUseGrantProblem(value: unknown): string | undefined {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return "computerUse 必须为对象";
	if (Object.keys(value as Record<string, unknown>).some((k) => k !== "apps")) return "computerUse 只认 apps 字段";
	const apps = (value as { apps?: unknown }).apps;
	if (apps === undefined) return undefined;
	if (!Array.isArray(apps) || apps.some(a => typeof a !== "string" || !a.trim())) return "computerUse.apps 必须是非空白字符串数组";
	return undefined;
}
