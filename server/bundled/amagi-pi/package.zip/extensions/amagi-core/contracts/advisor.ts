/** 可选咨询能力；冻结模型和预算，缺席即未授权。纯校验供配置与任务契约共用。 */
import { isRecord, rejectUnknownKeys } from "./view.ts";
export interface AdvisorGrant {
	readonly model: string;
	readonly backend?: "pi" | "codex-chat";
	readonly codex?: { readonly mode?: "managed" | "existing"; readonly socketPath?: string; readonly threadId?: string; readonly model?: string; readonly reasoningEffort?: "low" | "medium" | "high" | "xhigh" | "max" };
	readonly maxCalls: number;
	readonly maxTokens: number;
	readonly timeoutMs: number;
}
export function advisorGrantProblem(value: unknown): string | undefined {
	if (!isRecord(value)) return "advisor 必须为对象";
	const shape = rejectUnknownKeys(value, ["model", "maxCalls", "maxTokens", "timeoutMs", "backend", "codex"], "advisor");
	if (shape) return shape;
	if (typeof value.model !== "string" || !/^[^\s/]+\/\S+$/.test(value.model)) return "advisor.model 必须是 provider/model[:thinking]";
	if (value.backend !== undefined && value.backend !== "pi" && value.backend !== "codex-chat") return "advisor.backend 只认 pi/codex-chat";
	if (value.backend === "codex-chat") {
		if (!isRecord(value.codex) || rejectUnknownKeys(value.codex, ["mode", "socketPath", "threadId", "model", "reasoningEffort"], "advisor.codex")) return "advisor.codex 字段无效";
		const mode = value.codex.mode ?? (value.codex.threadId ? "existing" : "managed");
		if (mode === "managed") {
			if (value.codex.threadId !== undefined || value.codex.socketPath !== undefined) return "自有咨询会话不接受其他聊天 ID 或共享连接";
			if (value.codex.model !== undefined && (typeof value.codex.model !== "string" || !/^\S+$/.test(value.codex.model))) return "advisor.codex.model 无效";
			if (value.codex.reasoningEffort !== undefined && !["low", "medium", "high", "xhigh", "max"].includes(value.codex.reasoningEffort as string)) return "advisor.codex.reasoningEffort 无效";
			if (value.model !== "codex-chat/managed") return "自有咨询会话身份不一致";
		} else if (mode === "existing") {
			if (typeof value.codex.socketPath !== "string" || (value.codex.socketPath !== "auto" && !/^(?:\/|[A-Za-z]:[\\/]|\\\\)/.test(value.codex.socketPath))) return "advisor.codex.socketPath 必须为 auto 或本机绝对 socket 路径";
			if (typeof value.codex.threadId !== "string" || !/^[a-zA-Z0-9-]{8,128}$/.test(value.codex.threadId)) return "advisor.codex.threadId 无效";
			if (value.model !== `codex-chat/${value.codex.threadId}` || value.codex.model !== undefined || value.codex.reasoningEffort !== undefined) return "Codex 既有聊天身份不一致或请求改变其模型/思考档位";
		} else return "advisor.codex.mode 只认 managed/existing";
	} else if (value.codex !== undefined) return "pi 后端不接受 codex 授权";
	for (const [key, max] of [["maxCalls", 50], ["maxTokens", 16384], ["timeoutMs", 300000]] as const) {
		const n = value[key];
		if (typeof n !== "number" || !Number.isSafeInteger(n) || n < 1 || n > max) return `advisor.${key} 必须为 1–${max} 的整数`;
	}
	return undefined;
}
