import { advisorGrantProblem, type AdvisorGrant } from "./advisor.ts";
/**
 * contracts/permission.ts — 权限授予契约（amagi-pi v2 K1，方案 §3.2 PermissionGrant / §5.1）。
 *
 * 叶子模块：零 import。实际权限 = 角色能力上限 ∩ 用户/受信项目授权 ∩ 本次任务请求 ∩ 后端可兑现能力；
 * deny 优先。本模块只定义冻结形状与纯校验，不做路径匹配执法（执法属执行通道，§5.2，后续切片）。
 * 语义要点（校验器强制）：
 *  - tool-enforced ⇒ shell 必须 deny（§5.1：受控工具通道下 shell 必须禁用）；
 *  - 空数组 = 没有该项权限（省略不等于无限制——省略由应用层按受信命名策略继承，§5.1）；
 *  - PathRule 显式语法：file/directory/glob/prefix，prefix 不隐式当目录（§5.2）。
 */
import {
	CONTRACT_ERROR_CODES,
	err,
	isNonEmptyString,
	isPositiveInt,
	isRecord,
	ok,
	rejectUnknownKeys,
	type Result,
} from "./view.ts";

export type PathRuleKind = "file" | "directory" | "glob" | "prefix";
export const PATH_RULE_KINDS: readonly PathRuleKind[] = ["file", "directory", "glob", "prefix"];

export interface PathRule {
	kind: PathRuleKind;
	value: string;
}

/** 保证等级：tool-enforced=受控工具通道逐次校验；guarded=显式授权通用 shell（回执须声明局限）。 */
export type PermissionAssurance = "tool-enforced" | "guarded";
export const PERMISSION_ASSURANCES: readonly PermissionAssurance[] = ["tool-enforced", "guarded"];

export type ShellPolicy = "deny" | "guarded";
export const SHELL_POLICIES: readonly ShellPolicy[] = ["deny", "guarded"];

export interface McpToolGrant {
	server: string;
	tool: string;
	policyDigest: string;
}

export type LspCapability = "diagnostics" | "definition" | "references" | "hover" | "rename";
export const LSP_CAPABILITIES: readonly LspCapability[] = ["diagnostics", "definition", "references", "hover", "rename"];

// ── B5A（ev-20261012-7517d8 设计 §3.1/§5.1）：codemode 只读受控授权子对象 ──────────

/** codemode 脚本可调用工具的封闭集（精确名；不含 ls/amagi_resource/MCP/LSP/task 族——设计 §2.1 不变量 2）。 */
export const CODEMODE_SCRIPT_TOOLS: readonly ("read" | "grep" | "find")[] = ["read", "grep", "find"];

/** codemode 受控预算（设计 §5.1 固定字段与值域；grant 冻结时全字段物化，无缺省继承）。 */
export interface CodemodeGrantBudget {
	/** 单会话脚本执行次数上限（1–200）。 */
	readonly maxScriptsPerSession: number;
	/** 单脚本 @options max_output_tokens 声明上限（1–10000）。 */
	readonly maxOutputTokensPerScript: number;
	/** 单脚本 @options timeout_ms 声明上限（1–600000）。 */
	readonly maxTimeoutMsPerScript: number;
	/** 会话聚合输出 tokens 上限（1–200000，且 ≤ 次数×单次）。 */
	readonly maxTotalOutputTokens: number;
	/** 会话聚合时限上限（1–6000000，且 ≤ 次数×单次）。 */
	readonly maxTotalTimeoutMs: number;
}

/** 只读 codemode 授予（PermissionGrant 可选子对象；缺省=未授予，行为与历史字节级一致）。 */
export interface ReadOnlyCodemodeGrant {
	readonly mode: "read-only";
	/** 冻结脚本工具集：CODEMODE_SCRIPT_TOOLS 子集（非空去重精确名；须同时是顶层 grant.tools 子集）。 */
	readonly tools: readonly ("read" | "grep" | "find")[];
	/** models 桥恒 false——本契约不存在 models:true 逃生舱（设计 §4.1）。 */
	readonly models: false;
	readonly budget: CodemodeGrantBudget;
}

/** §5.1 预算单字段值域（config 分层逐字段校验与 grant 整体校验共用单一来源）。 */
const CODEMODE_BUDGET_FIELD_RANGES: ReadonlyArray<[string, number, number]> = [
	["maxScriptsPerSession", 1, 200],
	["maxOutputTokensPerScript", 1, 10_000],
	["maxTimeoutMsPerScript", 1, 600_000],
	["maxTotalOutputTokens", 1, 200_000],
	["maxTotalTimeoutMs", 1, 6_000_000],
];

/** 预算单字段值域校验（B5A 终裁 R3-01：config 分层只查显式字段——不做缺省物化与乘积判定；
 *  乘积约束仅对合并物化后的完整预算检查，见 codemodeGrantBudgetProblem）。返回 null=合法。 */
export function codemodeBudgetFieldRangeProblem(key: string, value: number, field: string): string | null {
	const entry = CODEMODE_BUDGET_FIELD_RANGES.find(([k]) => k === key);
	if (!entry) return `${field} 未知预算字段 "${key}"`;
	const [, min, max] = entry;
	if (!Number.isSafeInteger(value) || value < min || value > max) {
		return `${field}.${key} 必须是 ≥${min} 且 ≤${max} 的 safe integer（显式越界配置拒绝，不静默接受无限值）`;
	}
	return null;
}

/** 校验 CodemodeGrantBudget（§5.1 值域 + 聚合 ≤ 次数×单次乘积；safe integer，不做字符串数字强转）。
 *  返回 null=合法；否则返回错误消息。契约层单一实现，config/grant 消费方共用。 */
export function codemodeGrantBudgetProblem(v: unknown, field: string): string | null {
	if (!isRecord(v)) return `${field} 必须是对象（字段：maxScriptsPerSession/maxOutputTokensPerScript/maxTimeoutMsPerScript/maxTotalOutputTokens/maxTotalTimeoutMs）`;
	const shape = rejectUnknownKeys(v, ["maxScriptsPerSession", "maxOutputTokensPerScript", "maxTimeoutMsPerScript", "maxTotalOutputTokens", "maxTotalTimeoutMs"], field);
	if (shape) return shape;
	const values: Record<string, number> = {};
	for (const [key, min, max] of CODEMODE_BUDGET_FIELD_RANGES) {
		const raw = (v as Record<string, unknown>)[key];
		if (typeof raw !== "number" || !Number.isSafeInteger(raw) || raw < min || raw > max) {
			return `${field}.${key} 必须是 ≥${min} 且 ≤${max} 的 safe integer（显式越界配置拒绝，不静默接受无限值）`;
		}
		values[key] = raw;
	}
	if (values.maxTotalOutputTokens! > values.maxScriptsPerSession! * values.maxOutputTokensPerScript!) {
		return `${field}.maxTotalOutputTokens（${values.maxTotalOutputTokens}）不得大于 次数×单次输出（${values.maxScriptsPerSession}×${values.maxOutputTokensPerScript}）`;
	}
	if (values.maxTotalTimeoutMs! > values.maxScriptsPerSession! * values.maxTimeoutMsPerScript!) {
		return `${field}.maxTotalTimeoutMs（${values.maxTotalTimeoutMs}）不得大于 次数×单次时限（${values.maxScriptsPerSession}×${values.maxTimeoutMsPerScript}）`;
	}
	return null;
}

function validateReadOnlyCodemodeGrant(v: unknown): Result<ReadOnlyCodemodeGrant> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "permission.codemode 必须是对象", ["permission.codemode"]);
	const shape = rejectUnknownKeys(v, ["mode", "tools", "models", "budget"], "permission.codemode");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["permission.codemode"]);
	if (v.mode !== "read-only") {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "permission.codemode.mode 必须是 read-only（本批无其它模式）", ["permission.codemode.mode"]);
	}
	if (v.models !== false) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, "permission.codemode.models 必须为 false（models 桥不存在 true 逃生舱）", ["permission.codemode.models"]);
	}
	if (!Array.isArray(v.tools) || v.tools.length === 0) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.codemode.tools 必须是非空数组（read/grep/find 精确名子集）", ["permission.codemode.tools"]);
	}
	const seen = new Set<string>();
	for (let i = 0; i < v.tools.length; i++) {
		const t = v.tools[i];
		if (typeof t !== "string" || !(CODEMODE_SCRIPT_TOOLS as readonly string[]).includes(t)) {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `permission.codemode.tools[${i}] 必须是 read/grep/find 之一（封闭精确名集）`, [`permission.codemode.tools[${i}]`]);
		}
		if (seen.has(t)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `permission.codemode.tools 含重复项 ${t}（非空去重精确集合）`, ["permission.codemode.tools"]);
		seen.add(t);
	}
	const budgetProblem = codemodeGrantBudgetProblem(v.budget, "permission.codemode.budget");
	if (budgetProblem !== null) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, budgetProblem, ["permission.codemode.budget"]);
	return ok(v as unknown as ReadOnlyCodemodeGrant);
}

export interface PermissionGrant {
	policyVersion: number;
	assurance: PermissionAssurance;
	tools: readonly string[];
	read: readonly PathRule[];
	write: readonly PathRule[];
	deny: readonly PathRule[];
	reportFiles: readonly string[];
	scratchRoot?: string;
	shell: ShellPolicy;
	mcp: readonly McpToolGrant[];
	lsp: readonly LspCapability[];
	/** B5A：codemode 只读受控授予子对象（可选；缺省=未授予，序列化字节与历史一致）。
	 *  携带时 policyVersion 为 2，或并有 advisor 时为 3；policyVersion 1 携带本字段拒绝（旧 grant 不得自动获得 codemode）。 */
	codemode?: ReadOnlyCodemodeGrant;
	advisor?: AdvisorGrant;
}

export function validatePathRule(v: unknown, field: string): Result<PathRule> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const shape = rejectUnknownKeys(v, ["kind", "value"], field);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, [field]);
	if (!PATH_RULE_KINDS.includes(v.kind as PathRuleKind)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `${field}.kind 必须是 ${PATH_RULE_KINDS.join("/")} 之一`, [`${field}.kind`]);
	}
	if (!isNonEmptyString(v.value)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.value 必须是非空字符串`, [`${field}.value`]);
	return ok({ kind: v.kind as PathRuleKind, value: v.value });
}

function validatePathRules(v: unknown, field: string): Result<readonly PathRule[]> {
	if (!Array.isArray(v)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field} 必须是数组（空数组=无该项权限）`, [field]);
	const out: PathRule[] = [];
	for (let i = 0; i < v.length; i++) {
		const r = validatePathRule(v[i], `${field}[${i}]`);
		if (!r.ok) return r;
		out.push(r.value);
	}
	return ok(out);
}

function validateStringArray(v: unknown, field: string): Result<readonly string[]> {
	if (!Array.isArray(v)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field} 必须是字符串数组`, [field]);
	for (let i = 0; i < v.length; i++) {
		if (!isNonEmptyString(v[i])) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}[${i}] 必须是非空字符串`, [`${field}[${i}]`]);
	}
	return ok(v as readonly string[]);
}

export function validatePermissionGrant(v: unknown): Result<PermissionGrant> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "permission 必须是对象", ["permission"]);
	const shape = rejectUnknownKeys(
		v,
		["policyVersion", "assurance", "tools", "read", "write", "deny", "reportFiles", "scratchRoot", "shell", "mcp", "lsp", "codemode", "advisor"],
		"permission",
	);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["permission"]);
	if (!isPositiveInt(v.policyVersion)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.policyVersion 必须是正整数", ["permission.policyVersion"]);
	if (!PERMISSION_ASSURANCES.includes(v.assurance as PermissionAssurance)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `permission.assurance 必须是 ${PERMISSION_ASSURANCES.join("/")} 之一`, ["permission.assurance"]);
	}
	const tools = validateStringArray(v.tools, "permission.tools");
	if (!tools.ok) return tools;
	const read = validatePathRules(v.read, "permission.read");
	if (!read.ok) return read;
	const write = validatePathRules(v.write, "permission.write");
	if (!write.ok) return write;
	const deny = validatePathRules(v.deny, "permission.deny");
	if (!deny.ok) return deny;
	const reportFiles = validateStringArray(v.reportFiles, "permission.reportFiles");
	if (!reportFiles.ok) return reportFiles;
	if (v.scratchRoot !== undefined && !isNonEmptyString(v.scratchRoot)) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.scratchRoot 必须是非空字符串", ["permission.scratchRoot"]);
	}
	if (!SHELL_POLICIES.includes(v.shell as ShellPolicy)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `permission.shell 必须是 ${SHELL_POLICIES.join("/")} 之一`, ["permission.shell"]);
	}
	// §5.1：tool-enforced 保证等级下 shell 必须 deny（未审计通用 shell 不可用）。
	if (v.assurance === "tool-enforced" && v.shell !== "deny") {
		return err(
			CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
			"assurance=tool-enforced 时 shell 必须为 deny（受控工具通道不接受通用 shell）",
			["permission.assurance", "permission.shell"],
			"none",
			[{ assurance: "tool-enforced", shell: "deny" }],
		);
	}
	if (!Array.isArray(v.mcp)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.mcp 必须是数组", ["permission.mcp"]);
	for (let i = 0; i < v.mcp.length; i++) {
		const m = v.mcp[i];
		if (!isRecord(m)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `permission.mcp[${i}] 必须是对象`, [`permission.mcp[${i}]`]);
		const mShape = rejectUnknownKeys(m, ["server", "tool", "policyDigest"], `permission.mcp[${i}]`);
		if (mShape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, mShape, [`permission.mcp[${i}]`]);
		if (!isNonEmptyString(m.server)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `permission.mcp[${i}].server 必须是非空字符串`, [`permission.mcp[${i}].server`]);
		if (!isNonEmptyString(m.tool)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `permission.mcp[${i}].tool 必须是非空字符串`, [`permission.mcp[${i}].tool`]);
		if (!isNonEmptyString(m.policyDigest)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `permission.mcp[${i}].policyDigest 必须是非空字符串`, [`permission.mcp[${i}].policyDigest`]);
	}
	if (!Array.isArray(v.lsp)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.lsp 必须是数组", ["permission.lsp"]);
	for (let i = 0; i < v.lsp.length; i++) {
		if (!LSP_CAPABILITIES.includes(v.lsp[i] as LspCapability)) {
			return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `permission.lsp[${i}] 必须是 ${LSP_CAPABILITIES.join("/")} 之一`, [`permission.lsp[${i}]`]);
		}
	}
	// ── B5A：codemode 子对象可选；与 policyVersion 成对（1↔缺席，2↔携带）——旧 policyVersion=1 且缺
	//  codemode 的历史 grant 字节级/digest 不变；旧 v1 grant 异常携带 codemode 拒绝，不在恢复时自动填授权。──
	if (v.codemode !== undefined) {
		if (v.policyVersion !== 2 && v.policyVersion !== 3) {
			return err(
				CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
				`permission.codemode 携带时 policyVersion 必须为 2/3（当前 ${v.policyVersion}）——旧 v1 grant 不携带 codemode，异常携带一律拒绝`,
				["permission.policyVersion", "permission.codemode"],
				"none",
				[{ policyVersion: 2 }],
			);
		}
		// tools 子集不变量（设计 §3.1：codemode.tools 必须是顶层 grant.tools 子集；codemode 本身不进子列表）
		if (!Array.isArray(v.tools)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.tools 必须是字符串数组", ["permission.tools"]);
		const topTools = new Set(v.tools as readonly string[]);
		const cgTools = (v.codemode as { tools?: unknown } | null | undefined)?.tools;
		for (const t of Array.isArray(cgTools) ? (cgTools as readonly string[]) : []) {
			if (!topTools.has(t)) {
				return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `permission.codemode.tools 含顶层 grant.tools 外的工具 "${t}"（子对象工具集必须是顶层授予子集）`, ["permission.codemode.tools"]);
			}
			if (t === "codemode") {
				return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "permission.codemode.tools 不能包含 codemode 自身", ["permission.codemode.tools"]);
			}
		}
		const cg = validateReadOnlyCodemodeGrant(v.codemode);
		if (!cg.ok) return cg;
	} else if (v.policyVersion === 2) {
		return err(
			CONTRACT_ERROR_CODES.INVALID_STATE_TRIPLE,
			"permission.policyVersion=2 时必须携带 codemode 子对象（v2 授权面与 codemode 成对）",
			["permission.policyVersion", "permission.codemode"],
			"none",
			[{ hint: "未授予 codemode 的任务使用 policyVersion=1（与历史字节级一致）" }],
		);
	}
	if (v.advisor !== undefined) {
		const problem = advisorGrantProblem(v.advisor);
		if ((v.assurance === "tool-enforced" || (Array.isArray(v.deny) && v.deny.length > 0)) && (v.advisor as { backend?: string })?.backend === "codex-chat") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "Codex 咨询仅支持无 deny 的 guarded 承诺；无法证明原生工具受 pi 的受控围栏约束", ["permission.advisor"]);
		if (problem || v.policyVersion !== 3 || !(v.tools as string[]).includes("amagi_advisor")) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, problem ?? "advisor 须使用 policyVersion=3 且 tools 含 amagi_advisor", ["permission.advisor"]);
	} else if (v.policyVersion === 3 || (v.tools as string[]).includes("amagi_advisor")) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "amagi_advisor 须有冻结 advisor 授权", ["permission.advisor"]);
	}
	return ok(v as unknown as PermissionGrant);
}
