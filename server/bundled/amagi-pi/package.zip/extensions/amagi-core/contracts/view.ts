/**
 * contracts/view.ts — 公共契约原语（amagi-pi v2 K1，方案 §3.2/§3.3）。
 *
 * 本模块是 contracts 依赖 DAG 的**叶子**：零 import（node 内置也不依赖），承载跨契约通用小类型
 * ContractVersion / Ref / TaskKey / Result / ContractError / TaskQuery 与共享校验原语。
 *
 * 布局说明（K1 裁量，保持封闭）：TaskView/TaskPage 是任务实体的只读投影，定义在 task.ts——
 * 若放本模块会与 task.ts 形成 type-only 环，而 no-cycles 门禁包含 type-only import（§3.1）。
 * 模块纯度由 depcruise 规则 v2-contracts-pure 断言：只允许 node 内置与 contracts 内部互引。
 */

/** 新契约自身起始版本，与产品版本独立（§3.2）。 */
export type ContractVersion = 1;
export const CONTRACT_VERSION: ContractVersion = 1;

/** 未知必要版本拒绝（§3.2：未知必要版本拒绝，不回退猜测）。 */
export function isKnownContractVersion(v: unknown): v is ContractVersion {
	return v === CONTRACT_VERSION;
}

/** 内容寻址引用：path 指向归档内容或目录清单；digest 为 SHA-256 hex；bytes 为字节长度。 */
export interface Ref {
	path: string;
	digest: string;
	bytes: number;
}

/** 任务身份三元组：ownerId（稳定 Leader 逻辑身份）+ taskId（内核生成的安全 UUID）+ revision（失效栅栏）。 */
export interface TaskKey {
	ownerId: string;
	taskId: string;
	revision: number;
}

/** 统一错误对象（§4.2：错误对象统一 ContractError）。effects 语义：
 *  none=未产生任何副作用；started=可能已启动外部动作；unknown=副作用状态不可确认。 */
export interface ContractError {
	code: string;
	message: string;
	fields: readonly string[];
	effects: "none" | "started" | "unknown";
	repairExamples: readonly object[];
}

export type Result<T> = { ok: true; value: T } | { ok: false; error: ContractError };

export function ok<T>(value: T): Result<T> {
	return { ok: true, value };
}

export function err(
	code: string,
	message: string,
	fields: readonly string[] = [],
	effects: ContractError["effects"] = "none",
	repairExamples: readonly object[] = [],
): Result<never> {
	return { ok: false, error: { code, message, fields, effects, repairExamples } };
}

/** 契约错误码封闭集（K1 冻结；新增码须同步升契约版本说明）。
 *  ev-20261014-4f7500：新增 INVALID_RECEIPT_ID——accept/reject 的 receiptId 形状栅栏
 *  （模型输入口专属；不改变 wire 形状，旧消费方按 code 字符串开放集容错，不升 ContractVersion）。 */
export const CONTRACT_ERROR_CODES = {
	UNSUPPORTED_VERSION: "unsupported-contract-version",
	INVALID_SHAPE: "invalid-contract-shape",
	INVALID_FIELD: "invalid-contract-field",
	INVALID_ENUM: "invalid-contract-enum",
	UNKNOWN_FIELD: "unknown-contract-field",
	DIGEST_MISMATCH: "contract-digest-mismatch",
	INVALID_STATE_TRIPLE: "invalid-state-triple",
	INVALID_TRANSITION: "invalid-execution-transition",
	INVALID_RECEIPT_ID: "invalid-receipt-id",
} as const;

// ── 共享校验原语（仅运行时类型谓词，不含业务语义；供各契约模块复用） ──────────

export function isRecord(v: unknown): v is Record<string, unknown> {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}

export function isNonEmptyString(v: unknown): v is string {
	return typeof v === "string" && v.length > 0;
}

export function isNonNegativeInt(v: unknown): v is number {
	return typeof v === "number" && Number.isInteger(v) && v >= 0;
}

export function isPositiveInt(v: unknown): v is number {
	return typeof v === "number" && Number.isInteger(v) && v > 0;
}

export function isHex64(v: unknown): v is string {
	return typeof v === "string" && /^[0-9a-f]{64}$/.test(v);
}

/** 封闭规格检查：对象含已知字段集之外的键（undefined 视为缺席）即拒绝。
 *  K1 冻结口径：同版本契约必须同形状；新增字段走契约版本升级（§3.2「未知必要版本拒绝」的同族纪律）。 */
export function rejectUnknownKeys(
	v: Record<string, unknown>,
	known: readonly string[],
	field: string,
): string | null {
	const unknown = Object.keys(v).filter((k) => !known.includes(k) && v[k] !== undefined);
	return unknown.length
		? `${field} 含未知字段 ${unknown.join(",")}（契约封闭规格；新增字段须升 ContractVersion）`
		: null;
}

/** ev-20260919（P0-1 修复）：深度剥离对象中的 null 值键（视为缺席，与 undefined 同语义）。
 *  动机：pi 宿主 constrainedSampling strict 转换把全部可选属性 required+nullable 化（anyOf:[x,null]），
 *  模型（尤其 fast 档）按 schema 全字段携带、可选位填 null——契约层若把 null 键当「携带未知字段」
 *  拒绝，wait/cancel 等判别联合动作结构性不可用（repairExamples 的最小集在 strict 渲染下发不出来）。
 *  语义：对象值 === null → 删除键后递归其余；数组元素 null **保留**（元素级坏值由字段校验拒绝，
 *  不与「属性缺席」混同）；标量原样。磁盘回读的 spec/receipt 无 null 键，行为不变。 */
export function deepStripNulls<T>(v: T): T {
	if (Array.isArray(v)) {
		return v.map((e) => deepStripNulls(e)) as unknown as T;
	}
	if (isRecord(v)) {
		const out: Record<string, unknown> = {};
		for (const [k, val] of Object.entries(v)) {
			if (val === null) continue; // null 键 = 序列化伪影的「缺席」
			out[k] = deepStripNulls(val);
		}
		return out as unknown as T;
	}
	return v;
}

/** ev-20260920（P1 修复）：strict 采样字符串位伪影字面量。宿主 constrainedSampling strict 转换把可选
 *  属性 required+nullable 化后，部分供应商/结构化输出层在序列化 tool_call 时把字符串型（含枚举）位的
 *  JSON null 串化为字符串 "null"（实测 host 0.84 真机参数回显：string/enum 位收到 "null" 字符串、
 *  number/array 位保留真 null——后者由宿主 normalizeOptionalNulls 删除，前者穿透宿主枚举校验拒收）。
 *  自动补 null 的后端因此结构性拒收受影响动作（task_control accept 的 mode、task_query 的 view…）
 *  ——与 ev-20260919 的 null 键伪影同族不同形。 */
export const STRING_NULL_ARTIFACT = "null";

/** ev-20260920：深度剥离对象中的 "null" 字符串属性值（STRING_NULL_ARTIFACT，视为缺席）。
 *  语义与 deepStripNulls 对称：对象属性值 === "null" 字符串 → 删除键后递归其余；数组元素**保留**
 *  （元素级坏值由字段校验拒绝，不与「属性缺席」混同）；标量原样。仅用于模型面工具参数归一
 *  （prepareArguments / execute 入口），不用于磁盘回读。已知取舍：语义上恰为 "null" 的合法字符串
 *  值（如 reason 全文恰为 "null"）会被视为缺席——按字段缺失拒绝并给修复提示，比伪影穿透宿主
 *  校验的结构性死锁可恢复（自动补 null 后端无法省略受影响参数）。 */
export function deepStripNullStringArtifacts<T>(v: T): T {
	if (Array.isArray(v)) {
		return v.map((e) => deepStripNullStringArtifacts(e)) as unknown as T;
	}
	if (isRecord(v)) {
		const out: Record<string, unknown> = {};
		for (const [k, val] of Object.entries(v)) {
			if (val === STRING_NULL_ARTIFACT) continue; // "null" 字符串 = 序列化伪影的「缺席」
			out[k] = deepStripNullStringArtifacts(val);
		}
		return out as unknown as T;
	}
	return v;
}

/** 模型面工具参数伪影归一（ev-20260919 null 键 + ev-20260920 "null" 字符串，一次到位）：
 *  宿主 prepareArguments（validateToolArguments 之前执行）与 execute 入口（直调/测试路径）共用。 */
export function normalizeToolArgumentArtifacts<T>(v: T): T {
	return deepStripNullStringArtifacts(deepStripNulls(v));
}

/** extraKnown：扩展 Ref 的构成类型（如 InputRef 的 purpose/required）声明的额外合法键。 */
export function validateRef(v: unknown, field = "ref", extraKnown: readonly string[] = []): Result<Ref> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const shape = rejectUnknownKeys(v, ["path", "digest", "bytes", ...extraKnown], field);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, [field]);
	if (!isNonEmptyString(v.path)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.path 必须是非空字符串`, [`${field}.path`]);
	if (!isHex64(v.digest)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.digest 必须是 64 位小写十六进制 SHA-256`, [`${field}.digest`]);
	if (!isNonNegativeInt(v.bytes)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.bytes 必须是非负整数`, [`${field}.bytes`]);
	return ok({ path: v.path, digest: v.digest, bytes: v.bytes });
}

/** extraKnown：TaskKey 扩展对象（如 TaskRun/TaskReceipt）声明的额外合法键（顶层封闭清单由调用方持有）。 */
export function validateTaskKey(v: unknown, field = "key", extraKnown: readonly string[] = []): Result<TaskKey> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, `${field} 必须是对象`, [field]);
	const shape = rejectUnknownKeys(v, ["ownerId", "taskId", "revision", ...extraKnown], field);
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, [field]);
	if (!isNonEmptyString(v.ownerId)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.ownerId 必须是非空字符串`, [`${field}.ownerId`]);
	if (!isNonEmptyString(v.taskId)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.taskId 必须是非空字符串`, [`${field}.taskId`]);
	if (!isNonNegativeInt(v.revision)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, `${field}.revision 必须是非负整数（失效栅栏，N2）`, [`${field}.revision`]);
	return ok({ ownerId: v.ownerId, taskId: v.taskId, revision: v.revision });
}

// ── 查询面（§3.3：TaskQuery 包含 handle/view/cursor/limit；查询不 spawn、不续接、不修复磁盘） ──

export type TaskViewLevel = "summary" | "receipt" | "output";
export const TASK_VIEW_LEVELS: readonly TaskViewLevel[] = ["summary", "receipt", "output"];

export interface TaskQuery {
	handle?: string;
	view?: TaskViewLevel;
	cursor?: string;
	limit?: number;
}

export function validateTaskQuery(v: unknown): Result<TaskQuery> {
	if (!isRecord(v)) return err(CONTRACT_ERROR_CODES.INVALID_SHAPE, "query 必须是对象", ["query"]);
	const shape = rejectUnknownKeys(v, ["handle", "view", "cursor", "limit"], "query");
	if (shape) return err(CONTRACT_ERROR_CODES.UNKNOWN_FIELD, shape, ["query"]);
	if (v.handle !== undefined && !isNonEmptyString(v.handle)) return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "query.handle 必须是非空字符串", ["query.handle"]);
	if (v.view !== undefined && !TASK_VIEW_LEVELS.includes(v.view as TaskViewLevel)) {
		return err(CONTRACT_ERROR_CODES.INVALID_ENUM, `query.view 必须是 ${TASK_VIEW_LEVELS.join("/")} 之一`, ["query.view"]);
	}
	if (v.cursor !== undefined && typeof v.cursor !== "string") return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "query.cursor 必须是字符串", ["query.cursor"]);
	if (v.limit !== undefined && !(isPositiveInt(v.limit) && v.limit <= 500)) {
		return err(CONTRACT_ERROR_CODES.INVALID_FIELD, "query.limit 必须是 1..500 的整数", ["query.limit"]);
	}
	return ok(v as TaskQuery);
}
