/**
 * browser-reaper.ts — agent-browser 无头 Chrome 残留自动回收（ev-20260830-52106c）。
 *
 * 实战事故：agent-browser 会话异常中断（进程被强杀/宿主崩溃）后无头 Chrome 未被回收，
 * 8 个 Helper 以 94-100% CPU 持续空转 5 天 10 小时（累计 1300+ CPU 小时），设备异常发烫。
 *
 * 机制（零模型负担——纯基础设施层，不追加任何 prompt/skill 指令）：
 *   - 心跳观测：tool_call 检出 bash 命令含 agent-browser，或 mcp_call 调用 agent_browser_* → touch 共享心跳文件
 *     （主进程/子进程两侧注册，跨会话共享——任何 pi 实例在用就持续刷新，防并行误杀）。
 *   - idle 回收：仅主进程 5min 节拍扫描；心跳超 AMAGI_BROWSER_IDLE_MS（默认 30min）
 *     且存在 agent-browser 无头 Chrome 进程 → 优雅关闭（agent-browser close --all，10s
 *     超时）→ 残留则 pkill（TERM → 2s 宽限 → KILL）。只匹配 user-data-dir 含
 *     agent-browser-chrome- 的进程，绝不触碰用户日常浏览器（无该特征）。
 *   - 首次部署保守：心跳文件不存在时仅建立心跳不杀（一个 idle 周期后进入正常保护），
 *     防止部署瞬间误清用户手动正用的实例。
 *
 * 开关：AMAGI_BROWSER_REAPER=0/false 关闭整套回收；AMAGI_BROWSER_IDLE_MS 覆盖阈值
 * （<=0 等效禁用回收）。仅 darwin/linux；其余平台静默跳过。
 */

import { execFile } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { promisify } from "node:util";
import { amagiDataFile } from "./data-dir.ts";

const execFileAsync = promisify(execFile);

/** 心跳节流：idle 阈值分钟级，10s 节流误差可忽略，避免高频 bash 调用反复 utimes。 */
const HEARTBEAT_THROTTLE_MS = 10_000;
const DEFAULT_IDLE_MS = 30 * 60_000;
/** 扫描节拍（unref 定时器，绝不阻塞退出）。 */
const SWEEP_INTERVAL_MS = 5 * 60_000;
const CLOSE_TIMEOUT_MS = 10_000;
const PROBE_TIMEOUT_MS = 5_000;
const TERM_GRACE_MS = 2_000;
/** 无头实例特征：user-data-dir 路径段（用户日常浏览器绝无此串）。 */
const CHROME_MARKER = "agent-browser-chrome-";

export function heartbeatFile(): string {
	return amagiDataFile("browser-heartbeat");
}

/** 判定 bash 命令是否驱动 agent-browser（含 pgrep/ps 排查类调用——touch 心跳无害，一并算活跃）。 */
export function isAgentBrowserCommand(command: string): boolean {
	return /\bagent-browser\b/.test(command);
}

let lastTouchMs = 0;

/** touch 心跳（默认 10s 节流；force 用于测试与回收后刷新）。 */
export function touchHeartbeat(nowMs: number = Date.now(), force: boolean = false): void {
	if (!force && nowMs - lastTouchMs < HEARTBEAT_THROTTLE_MS) return;
	lastTouchMs = nowMs;
	const file = heartbeatFile();
	try {
		fs.mkdirSync(path.dirname(file), { recursive: true });
		const now = new Date(nowMs);
		try {
			fs.utimesSync(file, now, now);
		} catch {
			fs.writeFileSync(file, "");
		}
	} catch {
		// 心跳失败静默（下次调用重试；最坏后果是提前一轮回收判定）
	}
}

/**
 * 心跳观测注册：主进程与子进程（AMAGI_SUBAGENT）均生效——子 Agent 经 bash 驱动
 * agent-browser 的调用同样刷新共享心跳，保证并行任务不误杀。
 */
export function registerBrowserHeartbeat(pi: any): void {
	pi.on("tool_call", (event: any) => {
		try {
			const toolName = String(event?.toolName || "").toLowerCase();
			const cli = toolName === "bash" && isAgentBrowserCommand(String(event?.input?.command || ""));
			const mcp = toolName === "mcp_call" && /^agent_browser_/.test(String(event?.input?.tool || ""));
			if (cli || mcp) touchHeartbeat();
		} catch {
			// 观测失败静默
		}
	});
}

/** idle 阈值解析：非法回落缺省；<=0 等效禁用回收（返回 Infinity）。 */
export function reaperIdleMs(env: NodeJS.ProcessEnv = process.env): number {
	const raw = env.AMAGI_BROWSER_IDLE_MS;
	if (raw === undefined || raw === "") return DEFAULT_IDLE_MS;
	const n = Number(raw);
	if (!Number.isFinite(n)) return DEFAULT_IDLE_MS;
	return n <= 0 ? Infinity : n;
}

/** 总开关：AMAGI_BROWSER_REAPER=0/false 关闭。 */
export function reaperEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
	const v = env.AMAGI_BROWSER_REAPER;
	return !(v === "0" || /^(false|off|no)$/i.test(v || ""));
}

async function defaultRun(cmd: string, args: string[], timeoutMs: number): Promise<{ stdout: string }> {
	const { stdout } = await execFileAsync(cmd, args, { timeout: timeoutMs, killSignal: "SIGKILL" });
	return { stdout: String(stdout ?? "") };
}

export interface ReaperDeps {
	platform?: NodeJS.Platform;
	heartbeatPath?: string;
	now?: () => number;
	env?: NodeJS.ProcessEnv;
	run?: (cmd: string, args: string[], timeoutMs: number) => Promise<{ stdout: string }>;
	sleep?: (ms: number) => Promise<void>;
	log?: (msg: string) => void;
}

export type SweepAction = "noop" | "armed" | "reaped" | "skipped";

export interface SweepResult {
	action: SweepAction;
	reason: string;
	/** 回收时观测到的残留进程数（回收前快照）。 */
	residualPids: number;
}

function parsePids(stdout: string): string[] {
	return stdout.trim().split(/\s+/).filter(Boolean);
}

/** 单次扫描与回收（导出供测试/手动验证；生产由 startBrowserReaper 定时驱动）。 */
export async function sweepOnce(deps: ReaperDeps = {}): Promise<SweepResult> {
	const platform = deps.platform ?? process.platform;
	if (platform !== "darwin" && platform !== "linux") {
		return { action: "skipped", reason: `platform=${platform} 不支持，静默跳过`, residualPids: 0 };
	}
	const run = deps.run ?? defaultRun;
	const sleep = deps.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
	const log = deps.log ?? ((msg: string) => console.warn(`[amagi-core] browser-reaper: ${msg}`));
	const hb = deps.heartbeatPath ?? heartbeatFile();
	const now = (deps.now ?? Date.now)();
	const idleMs = reaperIdleMs(deps.env);

	let mtimeMs: number;
	try {
		mtimeMs = fs.statSync(hb).mtimeMs;
	} catch {
		// 首次部署保守：仅建立心跳，一个 idle 周期后进入正常保护（防止部署瞬间误清手动正用实例）
		try {
			fs.mkdirSync(path.dirname(hb), { recursive: true });
			fs.writeFileSync(hb, "");
		} catch {}
		return { action: "armed", reason: "心跳首次建立，下个 idle 周期起进入回收保护", residualPids: 0 };
	}

	if (idleMs !== Infinity && now - mtimeMs <= idleMs) {
		return { action: "noop", reason: "心跳新鲜（agent-browser 活跃中）", residualPids: 0 };
	}
	if (idleMs === Infinity && now - mtimeMs <= DEFAULT_IDLE_MS) {
		// AMAGI_BROWSER_IDLE_MS<=0 禁用回收：仍 noop，但按缺省窗口判定避免每 5min 空报告
		return { action: "noop", reason: "idle 回收已禁用（AMAGI_BROWSER_IDLE_MS<=0）", residualPids: 0 };
	}

	// 残留检测：只匹配无头实例特征进程
	let pids: string[] = [];
	try {
		const { stdout } = await run("pgrep", ["-f", CHROME_MARKER], PROBE_TIMEOUT_MS);
		pids = parsePids(stdout);
	} catch {
		// pgrep 非零退出 = 无匹配进程（正常态）
	}
	if (pids.length === 0) {
		return { action: "noop", reason: "无残留实例", residualPids: 0 };
	}

	// 优雅关闭（CLI 不在 PATH 时 ENOENT → 落入兜底强杀）
	try {
		await run("agent-browser", ["close", "--all"], CLOSE_TIMEOUT_MS);
	} catch {}
	await sleep(500);
	try {
		await run("pkill", ["-f", CHROME_MARKER], PROBE_TIMEOUT_MS);
	} catch {}
	await sleep(TERM_GRACE_MS);
	// SIGKILL 兜底（本次实战：忙等空转状态对 SIGTERM 无响应）
	try {
		const { stdout } = await run("pgrep", ["-f", CHROME_MARKER], PROBE_TIMEOUT_MS);
		if (parsePids(stdout).length > 0) await run("pkill", ["-9", "-f", CHROME_MARKER], PROBE_TIMEOUT_MS);
	} catch {}

	// 回收后刷新心跳（直接写 sweep 判定用的路径，避免每个扫描节拍重复报告）
	try {
		const t = new Date(now);
		try {
			fs.utimesSync(hb, t, t);
		} catch {
			fs.writeFileSync(hb, "");
		}
	} catch {}
	touchHeartbeat(now, true);
	log(`已回收 ${pids.length} 个残留无头 Chrome 进程（idle ${Math.round((now - mtimeMs) / 60_000)}min，ev-20260830-52106c）`);
	return { action: "reaped", reason: `idle 超时回收 ${pids.length} 个残留进程`, residualPids: pids.length };
}

/**
 * idle 回收器启动（仅主进程装配）：session_start 立即扫一次 + 5min 节拍定时器（unref）；
 * session_shutdown 清理定时器。所有异常静默——回收器任何失败都不影响主流程。
 */
export function startBrowserReaper(pi: any): void {
	if (!reaperEnabled()) return;
	if (process.platform !== "darwin" && process.platform !== "linux") return;
	let timer: NodeJS.Timeout | undefined;
	let sweeping = false;
	const tick = async () => {
		if (sweeping) return;
		sweeping = true;
		try {
			await sweepOnce();
		} catch {
			// 回收失败下个节拍重试
		} finally {
			sweeping = false;
		}
	};
	try {
		pi.on("session_start", () => {
			void tick();
			if (!timer) {
				timer = setInterval(() => void tick(), SWEEP_INTERVAL_MS);
				timer.unref?.();
			}
		});
		pi.on("session_shutdown", () => {
			if (timer) {
				clearInterval(timer);
				timer = undefined;
			}
		});
	} catch {
		// 事件不可用防御（与 index.ts 其他装配一致）
	}
}
