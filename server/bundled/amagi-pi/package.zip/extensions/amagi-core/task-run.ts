import { appendAdvisorEnv } from "./advisor-config.ts";
import { RUNTIME_FINGERPRINT, observeRuntimeEvent, runtimeObservation, type RuntimeObservation } from "./runtime-fingerprint.ts";
import type { ContextMode } from "./contracts/task.ts";
/**
 * task-run.ts — SubAgent 统一 spawn 引擎 + 共享类型/工具函数 + stats/shutdown（P3-C：2026-08-19 插件进化，第二/三批拆分自 task-tool.ts）。
 *
 * 来源行段（拆分前 task-tool.ts，共 3094 行）：
 *   L56-1231   边界常量 / env 最小化（P1-3）/ 工具函数（marker・blocked/done 检测・annotateCompletion・交付物预检）/
 *              RunResult・BackgroundStart・BackgroundOpts・PiTaskOpts 类型 / finalizeLaunchFailure・classifyTask 家族 / runPiTask 统一管线
 *   L2985-3043 P15-4 stats（writeStats 漏斗 + webui usage 监听器 setStatsListener）
 *   L3044-3094 P15-4 shutdown 清理（cleanupChildrenOnShutdown）+ registry 持久化 snapshotForPersist
 * 纯搬家纪律（P3-C）：函数体零改动；唯一适配 = 上列内部函数/接口补 export 关键字（供新兄弟模块消费）。
 * stats 段未随 query_task 驻 task-query.ts 的原因（任务约束#2 grep 消费方后的搬移方向裁定）：
 *   writeStats 消费方 = finalizeLaunchFailure/runPiTask finalize/runTask 聚合（引擎终态链）；task-query.ts 依赖
 *   task-resume.ts（resolveSessionWithBackfill），task-resume.ts 依赖本模块——stats 若驻 task-query 将成环
 *   task-run→task-query→task-resume→task-run。外部消费方（index.ts/tests）全部经 task-tool re-export，公共面零变化。
 *
 * amagi-pi v2 K4（方案 §3.1/§3.3/§8.1-K4）：JSON 后端观察化——引擎在 legacy 直写语义之外新增「观察模式」
 * （PiTaskOpts.observation，由 json-execution-adapter 注入）：started/session/activity/exited 经
 * RunObservationRelay 回流（key/backendRunId/observationSeq 单后端内递增、退出幂等去重）；观察模式下
 * 状态写权移交内核（sink 侧 kernel.apply(observe) 真实内核命令，N1 单写者），registry 仅保留无命令等价物
 * 的终稿字段投影（桥受控写入）。进程组终止链/看门狗/JSONL 限流/cooldown/槽位归还链路零改动（§8.1-K4）。
 */
import { spawn, execFileSync } from "node:child_process";
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import { appendCompactionEnv } from "./compaction-config.ts";
import * as os from "node:os";
import * as path from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import type { AgentConfig } from "./agents-loader.ts";
import { registry, type TaskRecord, type TaskStatus, type TaskRelationMeta } from "./task-registry.ts";
import type { ModelRegistryLike } from "./model-resolver.ts";
import { agentSkillAllowlist } from "./model-resolver.ts";
import { takeGitStatusSnapshot, freshAttributionCounts, takeWorkspaceStateSnapshot, type StructuredCheckOutcome } from "./evidence.ts";
// ev-20260910-8fbe4e（C）：中断现场报告的写入登记数据源（与 evidence.ts 同源；零循环边）
import { readTaskWrites, recordTaskStartState } from "./task-write-log.ts";
import { amagiDataFile } from "./data-dir.ts";
import { journalCodemodeAccount, journalSession } from "./journal.ts";
import { writeTrace, classifyErrorKind, type TraceEntry, type TraceModelSubtotal } from "./trace.ts";
import { updateRoutingStats, fuseStatus, routingDimKey } from "./routing-stats.ts";
// ev-20260914-9084ee：allowedPaths 白名单共享 matcher（glob/prefix: 语法；派发端预检与写守卫端同源）
import { parseAllowedPathEntry, resolveAllowedPathEntry } from "./path-match.ts";
// ev-20261020-d56baa：项目 shell.pathPrepend ——子 Agent spawn 同源 PATH 前置（与 bash/run_bg/基线测试共用）
import { prependPathEntries, readProjectShellPathPrepend } from "./shell-env.ts";
import { getStallThresholdMs, getStallCheckIntervalMs, getSpawnReadyMs, providerBreakerSuccess, providerBreakerFailure, lastErrorKindOfMessage } from "./reliability.ts";
// K4（amagi-pi v2，方案 §3.1/§3.3/§8.1-K4）：执行端口观察回流——只引纯契约叶子模块（execution-port/contracts），
// 引擎经 RunObservationTarget 发射 started/session/activity/exited（key/backendRunId/observationSeq），
// 状态写权移交内核（sink 侧 kernel.apply(observe) 真实内核命令）；本模块不 import 适配器
// （json-execution-adapter 单向复用 runPiTask 唯一 spawn 入口，不建第二套执行链）。
import type { ExecutionEvent } from "./contracts/command.ts";
import type { TaskView } from "./contracts/task.ts";
import type { Result, TaskKey } from "./contracts/view.ts";
import type { ExecutionObservation, RunObservationTarget } from "./execution-port.ts";
export type { RunObservationTarget };
// P4（amagi-pi v2，方案 §5.1/§5.2/§8.3-P4）：子进程权限交付——冻结授权从 v2-store 读取
//（task-service 面读，引擎不直连 task-store：K8c 单写者门禁），派生 --tools 严格名单与
// AMAGI_PERMISSION_GRANT/CWD/DIGEST env（子端 file-permission bootstrap 校验 digest 一致才激活）。
import { createDefaultJsonObservation, getFrozenPermissionGrant, getLeaderSessionStamp, type WorktreeDispatchFacts } from "./task-service.ts";
import { findDispatchRequirementGaps } from "./dispatch-preflight.ts";
import { PERMISSION_CWD_ENV, PERMISSION_DIGEST_ENV, PERMISSION_GRANT_ENV, permissionGrantDigest } from "./file-permission.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import { beginSyncWait, endSyncWait } from "./sync-wait.ts";
import { appendMcpCredentialEnv, resolveAgentMcpServers, normalizeMcpPermission, type McpPermission } from "./mcp-config.ts";
import { recordUsageFooterRow } from "./usage-footer.ts";
import { isToolOrder400, isContextLimitError } from "./session-repair.ts";
import { recordLaunchAnchor } from "./launch-anchor.ts";
import { ProcessAuditor, readKernelProcessIdentities, readKernelProcessIdentitiesAsync, type KernelProcessIdentity, type ProcessAuditDeps } from "./process-audit.ts";
import {
	advisorConsultationPending, ACTIVITY_NOISE, capUtf8, drainWritePaths, extractArtifactRefs, extractBlockedQuestions, extractUsage, extractUsageDetail, usageCoverageOf, readUsageFigures, addUsageFigures, newUsageTotals,
	getDoomLoopThreshold, getFinalOutput, looksLikeFinalReport, newParseContext, processLine,
	resolveArtifactAbs, settleWriteCredit, stripCodeBlocks, toolResultText, truncatedFallbackPeek, type CallUsage, type ToolExecutionObservation, type UsageFigures,
} from "./task-jsonl.ts";

// ── 边界常量（P1-1） ─────────────────────────────────────────────────────────
/**
 * 任务总时长默认不设上限：健康 Agent 可能持续工作一小时以上，不能把墙钟时长当成挂起证据。
 * 挂起由子进程 watchdog 按“连续静默 30min”兜底；每个新事件都会重置其计时。
 * 调用方仍可用 timeoutMs，运维也可设 AMAGI_TASK_TIMEOUT_MS > 0，显式启用总时长硬上限。
 * 显式 0 与未设置都表示关闭总时长上限。
 */
export function resolveTaskTimeoutMs(explicit?: number, envValue = process.env.AMAGI_TASK_TIMEOUT_MS): number | undefined {
	const raw = explicit !== undefined ? explicit : envValue;
	if (raw === undefined || raw === "") return undefined;
	const value = Number(raw);
	return Number.isFinite(value) && value > 0 ? value : undefined;
}

function formatTaskTimeout(ms: number): string {
	if (ms < 60_000) return `${Number((ms / 1000).toFixed(1))}s`;
	return `${Number((ms / 60_000).toFixed(1))}min`;
}
const SIGKILL_GRACE_MS = 3000;
const STDERR_TAIL = 4 * 1024;
const MAX_LINE_BYTES = 1024 * 1024; // 1MB 单行
const MAX_TOTAL_STDOUT = 50 * 1024 * 1024; // 50MB 总 stdout
// P3-02（diting）：总预算耗尽后的控制帧消费上限——短小合法的 agent_settled 控制事实仍在界内消费；
// 大帧仍被丢弃（限流不撤）。真实 agent_settled 帧数百字节，64KiB 足够覆盖且远离噪音帧尺寸。
const CONTROL_FRAME_MAX_BYTES = 64 * 1024;

// v1.5.183 噪音行快速识别（data handler 热路径免 JSON.parse）：pi json 模式 type 恒为首字段。
// 与 ACTIVITY_NOISE 单一数据源派生，永不失配。
const NOISE_LINE_RE = new RegExp(`^\\{"type":"(?:${[...ACTIVITY_NOISE].join("|")})"`);

const CLOSED_CHILDREN = new WeakSet<object>();

// ── env 最小化（P1-3） ──────────────────────────────────────────────────────
const ENV_WHITELIST = [
	"PATH", "HOME", "USER", "SHELL", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR", "TERM", "TZ",
	// 用户明确设置的编辑器环境透传；非交互默认值仅在工具 spawn 环境补充
	"GIT_EDITOR", "GIT_SEQUENCE_EDITOR", "EDITOR", "VISUAL", "GIT_PAGER", "PAGER", "GIT_TERMINAL_PROMPT", "GCM_INTERACTIVE",
	// v1.5.195 代理变量透传（实战事故：expert 档 openai-codex/gpt-5.6-sol 子 Agent 持续 fetch failed，
	// 根因 = env 最小化剥离代理变量，子进程无法经代理访问被墙 provider；zhipuai 直连可用掩盖了问题，
	// 主会话与独立 terminal 因持有完整 env 均正常）。代理变量非凭据，子进程网络条件应与主进程一致。
	"HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
	"http_proxy", "https_proxy", "all_proxy", "no_proxy",
	// P1-D（插件进化8.19）：edit/write 诊断注入开关透传（非凭据；主进程关闭时子进程同口径关闭）
	"AMAGI_EDIT_DIAGNOSTICS",
	// 8月迭代 pi-0.84 配合 修复轮（Major-3）：硬边界 terminate 语义开关透传（非凭据；同款
	// 「主进程口径透传」——guards 子进程侧读取该开关决定阻断是否 terminate，主进程关闭时子进程须同口径）
	"AMAGI_BOUNDARY_TERMINATE",
	// ev-20260909-729b99（P3）：amagi-task/ 撞名消歧环境变量透传
	"AMAGI_TASK_TMP_NAMECLASH",
	// v2.8.8：运行中 steer 通道父/子目录对齐——父进程若注入自定义数据目录（测试/运维），
	// 子进程必须同目录，否则 task-steer/<taskId>.jsonl 互不可见（非凭据，同口径透传）
	"AMAGI_DATA_DIR",
	"AMAGI_AUTORETRY_OFF",
];
/**
 * provider → 凭据 env 映射（附录 B 全部注册名）。
 * P1-1（复审修正）：按解析后实际 provider 放行对应凭据（最小权限），不放行全部 provider 密钥。
 */
const PROVIDER_KEY_MAP: Record<string, string[]> = {
	openrouter: ["OPENROUTER_API_KEY"],
	zhipuai: ["ZHIPU_API_KEY"],
	yescode: ["YES_API_KEY"],
	minimax: ["MINIMAX_API_KEY"],
	deepseek: ["DEEPSEEK_API_KEY"],
	anthropic: ["ANTHROPIC_API_KEY"],
	"anthropic-relay": ["ANTHROPIC_RELAY_API_KEY"],
	google: ["GOOGLE_API_KEY", "GEMINI_API_KEY"],
	openai: ["OPENAI_API_KEY"],
	moonshot: ["MOONSHOT_API_KEY", "KIMI_API_KEY"],
	"kimi-for-coding": ["MOONSHOT_API_KEY", "KIMI_API_KEY"],
	"kimi-coding": ["KIMI_API_KEY"],
	tbrouter: ["TBROUTER_API_KEY"],
	"bailian-coding": ["DASHSCOPE_CODING_API_KEY", "DASHSCOPE_API_KEY"],
	dashscope: ["DASHSCOPE_API_KEY", "DASHSCOPE_CODING_API_KEY"],
	bailian: ["DASHSCOPE_API_KEY", "DASHSCOPE_CODING_API_KEY"],
};

function buildMinimalEnv(modelSpec?: string, agentName?: string, cwd?: string, protectedPaths?: string[], allowedPaths?: string[], taskTmpDir?: string, taskId?: string, taskTmpNameclash?: string, mcpPermission?: McpPermission): Record<string, string> {
	const env: Record<string, string> = {};
	// 8月迭代 F5：任务硬边界（派发方声明；子进程 guards 读取并阻断 edit/write 越界）
	if (protectedPaths && protectedPaths.length > 0) env.AMAGI_PROTECTED_PATHS = JSON.stringify(protectedPaths);
	// 8月迭代 C3：任务白名单（派发方声明；子进程 guards 读取，写入目标不在清单内即阻断）。
	// 与 PROTECTED 同位注入；两者同设时子进程取交集语义（都放行才放行）。
	// ev-20260902-772c7f：白名单由调用方追加了任务专属验证产物临时目录（见 prepareTaskTmpDir）。
	if (allowedPaths && allowedPaths.length > 0) env.AMAGI_ALLOWED_PATHS = JSON.stringify(allowedPaths);
	// ev-20260902-772c7f：验证产物目录告知（子进程 guards 在 session_start 提示与边界拦截 reason 中引导）。
	if (taskTmpDir) env.AMAGI_TASK_TMP_DIR = taskTmpDir;
	// ev-20260922-1eea28（B2）：丢弃预授权不透明引用透传——仅 Leader 在任务书/scope 显式声明丢弃授权
	// （宿主签发 DiscardApproval 后）时设置；子进程 guard 消费时对宿主受保护记录重新验真（命令/
	// 内容指纹/归属/有效期/单次消费），工作区 JSON 不能自证。子 Agent 自行设置无法通过验真。
	if (process.env.AMAGI_DISCARD_APPROVAL_REF) env.AMAGI_DISCARD_APPROVAL_REF = process.env.AMAGI_DISCARD_APPROVAL_REF;
	// ev-20260909-729b99：工作区内 amagi-task/ 撞名消歧绝对路径告知
	const resolvedNameclash = taskTmpNameclash ?? process.env.AMAGI_TASK_TMP_NAMECLASH;
	if (resolvedNameclash) env.AMAGI_TASK_TMP_NAMECLASH = resolvedNameclash;
	for (const k of ENV_WHITELIST) {
		const v = process.env[k];
		if (v !== undefined) env[k] = v;
	}
	// pi 配置变量（PI_* 前缀）
	for (const k of Object.keys(process.env)) {
		if (k.startsWith("PI_")) env[k] = process.env[k]!;
	}
	// P1-1: 仅放行解析后实际 provider 的凭据（最小权限，不兜底全量）
	if (modelSpec) {
		const provider = modelSpec.split("/")[0].toLowerCase();
		const keys = PROVIDER_KEY_MAP[provider] || [];
		for (const k of keys) {
			const v = process.env[k];
			if (v !== undefined) env[k] = v; // 密钥值不进日志
		}
	}
	// MCP 凭据完全按配置/角色/冻结授权交付，不为已删除的专用工具无条件透传密钥。
	if (cwd) appendMcpCredentialEnv(env, cwd, agentName, mcpPermission);
	if (cwd) appendCompactionEnv(env, cwd);
	// ev-20260903-64641c（P0）：任务写入登记标识——子进程 write/edit/bash 覆盖层在成功写盘后把绝对
	// 路径登记到 <amagiData>/task-writes/<taskId>.jsonl，结算证据三档归因区分「子 Agent 写入」与
	// 「外部进程写入」（防多进程共享工作树时误归因 → 误回滚）。resume/bg-resume/worktree 全路径
	// 共用 runPiTask 唯一 spawn 点，此处一次注入全覆盖。
	if (taskId) env.AMAGI_TASK_ID = taskId;
	// ev-20261020-d56baa：项目 shell.pathPrepend 前置注入（cwd 项目 amagi.json 声明；幂等去重，
	// 子进程内 bash/run_bg 再读同一配置时零重复）——子 Agent 不再需要任务书重复抄写用户级工具链 PATH。
	const _pathPrepend = readProjectShellPathPrepend(cwd).dirs;
	if (_pathPrepend.length > 0) env.PATH = prependPathEntries(env.PATH ?? process.env.PATH, _pathPrepend);
	if (RUNTIME_FINGERPRINT.hostVersion && RUNTIME_FINGERPRINT.digest) env.AMAGI_LEADER_RUNTIME_DIGEST = RUNTIME_FINGERPRINT.digest;
	env.AMAGI_SUBAGENT = "1"; // 防递归
	if (modelSpec) env.AMAGI_DISPATCH_MODEL = modelSpec;
	if (process.env.AMAGI_CODEX_FRONTLINE !== undefined) env.AMAGI_CODEX_FRONTLINE = process.env.AMAGI_CODEX_FRONTLINE;
	if (agentName) env.AMAGI_AGENT = agentName; // 子 Agent 角色标识（MCP 路由过滤用）
	return env;
}

/**
 * 角色静态白名单 + 配置驱动的只读 MCP 发现入口。
 * mcp_call 仍必须由角色卡显式授权，避免“配置了 server”隐式扩大执行权限。
 */
/** 8月迭代 F5：保护路径解析（相对 cwd → 绝对；非法项静默丢弃；返回空数组表示无边界）。 */
export function resolveProtectedPaths(paths: unknown, cwd: string): string[] {
	if (!Array.isArray(paths)) return [];
	const out: string[] = [];
	for (const p of paths) {
		if (typeof p !== "string" || !p.trim()) continue;
		const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
		out.push(abs);
	}
	return out;
}

/** 8月迭代 C3：白名单路径解析（与 resolveProtectedPaths 同构：相对 cwd → 绝对；非法项静默丢弃；返回空数组表示无白名单）。
 *  ev-20260914-9084ee：prefix:/glob 语法条目 scheme 保留解析（prefix:xxx → "prefix:"+绝对；
 *  通配符原样透传），守卫端 matchPathAllowed 共享同一语义源。 */
export function resolveAllowedPaths(paths: unknown, cwd: string): string[] {
	if (!Array.isArray(paths)) return [];
	const out: string[] = [];
	for (const p of paths) {
		if (typeof p !== "string" || !p.trim()) continue;
		const parsed = parseAllowedPathEntry(p);
		if (parsed.invalid) continue; // 语法无效项静默丢弃（与既有非法项语义一致；节点级 resolveNodeAllowedPaths 显式拒单）
		out.push(resolveAllowedPathEntry(p, cwd));
	}
	return out;
}

export function resolveAgentTools(agent: AgentConfig, cwd: string): string[] {
	const tools = agent.tools.length > 0 ? [...agent.tools] : ["read"];
	// 注意：不自动加 mcp_call——「配置 server 不得隐式扩大为通用调用权限」是既有安全语义
	// （tests/task-tool.test.mjs 守护）；需要免发现通用调用的角色在卡内显式声明 mcp_call。
	if (resolveAgentMcpServers(cwd, agent.name).length > 0 && !tools.includes("mcp_list_tools")) tools.push("mcp_list_tools");
	return tools;
}

/** §9.5 G20（Batch 3·技能 allowlist）：agents.<role>.skills 配置时产出 --no-skills + 逐项 --skill 注入。
 *  语义实证（宿主 DefaultResourceLoader 真实装配，见 .agent-outputs/skill-allowlist-probe/）：
 *  noSkills 时 CLI --skill 路径仍加载，settings/auto 目录发现全剥离 → 子进程恰好只收清单内技能。
 *  未配置返回 []（零注入，行为零变化）；空数组 = ["--no-skills"]（全量剥离技能描述）。
 *  路径语义同 pi --skill（~ / 绝对 / 相对——相对按子进程 cwd 解析，宿主 resolveCliPaths 展开）。 */
export function agentSkillSpawnArgs(agentName: string, cwd: string | undefined): string[] {
	const allow = agentSkillAllowlist(agentName, cwd);
	if (allow === undefined) return [];
	const out: string[] = ["--no-skills"];
	for (const p of allow) out.push("--skill", p);
	return out;
}

// ── v2 P4（方案 §5.1/§5.2/§8.3-P4）：子进程权限交付（冻结 grant → --tools 严格名单 + digest env） ──

export interface SpawnPermissionDelivery {
	/** 冻结授权（真实 P1 grant——legacy v1 占位不进入本面）。 */
	grant: Readonly<PermissionGrant>;
	/** 注入原文（digest 基准：sha256(rawGrantJson)，子端按同串校验）。 */
	rawGrantJson: string;
	/** 授权清单摘要（防传输篡改）。 */
	digest: string;
	/** grant.tools ∩ 派发工具面（--tools 严格名单；shell=deny 的 grant 不含 bash——不可调用）。 */
	tools: readonly string[];
}

/** 派发工具面是确切名单，不采纳 pi 1.1 的 defaultTools 相对修饰语法。 */
function validateDispatchToolNames(tools: readonly string[]): void {
	for (const raw of tools) {
		const name = raw.trim();
		if (/^[+-]/.test(name)) throw new Error(`[tools] 拒绝修饰语法 "${name}"；请改用完整显式名单；权限交集不会展开宿主 defaultTools`);
		if (/[*?\[\]]/.test(name)) throw new Error(`[tools] 拒绝工具 pattern "${name}"；请列全确切工具名字`);
	}
}

// 只检查选项位置；提示词/正文（包括 -- 后）不是工具名单。与宿主 CLI 的值选项对齐。
const TOOL_ARG_VALUE_OPTIONS = new Set([
	"--mode", "--provider", "--model", "--api-key", "--system-prompt", "--append-system-prompt",
	"--name", "-n", "--session", "--session-id", "--fork", "--session-dir", "--models",
	"--exclude-tools", "-xt", "--thinking", "--export", "--extension", "-e", "--skill",
	"--prompt-template", "--theme", "--use-theme", "--tui-mode",
]);
/** 选项扫描结果：--tools/-t 索引与真正选项位置的正文分隔符索引（-1 = 无）。
 *  P3-01（diting）：分隔符只在选项位置命中——值选项（如 --system-prompt）消费的字面 `--` 是参数值
 *  不是分隔符；无上下文 indexOf 会把它当插入锚点，把 --tools 搬进值位/正文位（tools/mode 落位丢失）。 */
interface ToolArgScan { selector: number; bodySeparator: number; }
function scanToolArgs(args: readonly string[]): ToolArgScan {
	const scan: ToolArgScan = { selector: -1, bodySeparator: -1 };
	for (let i = 0; i < args.length; i++) {
		const arg = args[i];
		if (arg === "--") { scan.bodySeparator = i; break; }
		if (arg.startsWith("--tools=") || arg.startsWith("-t=")) throw new Error("[tools] 不支持 --tools= / -t= 拼写，请使用 --tools <完整显式名单>");
		if (arg === "--tools" || arg === "-t") {
			if (scan.selector >= 0) throw new Error("[tools] 重复工具选择器（--tools/-t），拒绝歧义派发");
			if (args[i + 1] === undefined || args[i + 1] === "--") throw new Error("[tools] 工具选择器缺值");
			scan.selector = i++;
			validateDispatchToolNames(args[i].split(",").map((t) => t.trim()).filter(Boolean));
		} else if (TOOL_ARG_VALUE_OPTIONS.has(arg)) i++;
		else if (arg === "-p" || arg === "--print" || arg === "--list-models") {
			const next = args[i + 1];
			if (next !== undefined && !next.startsWith("@") && (!next.startsWith("-") || next.startsWith("---"))) i++;
		} else if (arg.startsWith("--") && !arg.includes("=")) {
			// 未知扩展字符串选项：宿主消费其后非 flag 值。
			const next = args[i + 1];
			if (next !== undefined && !next.startsWith("-") && !next.startsWith("@")
				&& !/^(?:--no-|--continue$|--resume$|--verbose$|--offline$|--approve$|--help$|--version$)/.test(arg)) i++;
		}
	}
	return scan;
}
function toolsSelectorIndex(args: readonly string[]): number {
	return scanToolArgs(args).selector;
}

/** --tools/-t 归一为唯一显式名单；新增选项必须在 -- 正文分隔符之前。 */
export function enforceToolsArgument(args: readonly string[], enforcedTools: readonly string[]): string[] {
	const scan = scanToolArgs(args);
	validateDispatchToolNames(enforcedTools);
	const out = [...args];
	if (scan.selector >= 0) out.splice(scan.selector, 2, "--tools", enforcedTools.join(","));
	// P3-01：插入锚点用选项扫描的正文分隔符——值位的字面 `--`（如 --system-prompt --）不是分隔符。
	else { const end = scan.bodySeparator; out.splice(end < 0 ? out.length : end, 0, "--tools", enforcedTools.join(",")); }
	return out;
}

/** 派发 args 中的确切名单（未提供 → undefined；非法选择器抛出可诊断错误）。 */
export function dispatchToolsOfArgs(args: readonly string[]): string[] | undefined {
	const i = toolsSelectorIndex(args);
	return i < 0 ? undefined : args[i + 1].split(",").map((t) => t.trim()).filter(Boolean);
}

/** 冻结授权 → spawn 交付面：--tools 交集非空才成立（交集为空 = 授权面与派发面无重叠，
 *  子进程无可注册工具——fail-closed 拒发，不降级为任一单侧名单）。legacy 占位/无记录 → undefined（零执法）。 */
export async function resolveSpawnPermissionDelivery(
	taskId: string,
	cwd: string,
	dispatchTools: readonly string[] | undefined,
): Promise<SpawnPermissionDelivery | { error: string } | undefined> {
	try { if (dispatchTools !== undefined) validateDispatchToolNames(dispatchTools); }
	catch (e) { return { error: String(e instanceof Error ? e.message : e) }; }
	const grant = await getFrozenPermissionGrant(taskId);
	if (grant === undefined) return undefined;
	try { validateDispatchToolNames(grant.tools); }
	catch (e) { return { error: String(e instanceof Error ? e.message : e) }; } // legacy v1 面（占位授权）——行为零变化
	const rawGrantJson = JSON.stringify(grant);
	let tools: readonly string[];
	if (dispatchTools === undefined) {
		tools = [...grant.tools]; // 无派发名单（非标准入口）：grant 面即严格名单（子进程工具均实际注册）
	} else {
		const dispatchSet = new Set(dispatchTools);
		tools = grant.tools.filter((t) => dispatchSet.has(t));
		if (tools.length === 0) {
			return { error: `[P4 权限交付] 授权工具面（${grant.tools.join(", ")}）与派发工具面（${dispatchTools.join(", ")}）交集为空——子进程无可注册工具，拒绝启动（检查角色卡 tools 与任务 scope 授权）` };
		}
	}
	return { grant, rawGrantJson, digest: permissionGrantDigest(rawGrantJson), tools: [...new Set([...tools, "codemode", "toolcall_continue"])] };
}

/** 权限 env 注入（AMAGI_PERMISSION_GRANT/CWD/DIGEST；字面量与 file-permission 权威常量防漂移断言——
 *  单一来源：常量漂移时拒绝注入而非静默改用异名 env）。 */
export function appendPermissionGrantEnv(env: Record<string, string>, rawGrantJson: string, cwd: string, digest: string): void {
	if (PERMISSION_GRANT_ENV !== "AMAGI_PERMISSION_GRANT" || PERMISSION_CWD_ENV !== "AMAGI_PERMISSION_CWD" || PERMISSION_DIGEST_ENV !== "AMAGI_PERMISSION_DIGEST") {
		throw new Error("[amagi] 权限 env 常量漂移：task-run 注入字面量与 file-permission 权威常量不一致，拒绝注入");
	}
	env.AMAGI_PERMISSION_GRANT = rawGrantJson;
	env.AMAGI_PERMISSION_CWD = cwd;
	env.AMAGI_PERMISSION_DIGEST = digest;
}

// ── B5A（ev-20261012-7517d8 批A）：codemode 受控试点 spawn 面守卫 ──────────────────

/** 会话续接类参数扫描（值选项 --session/--fork 消费其后非 flag 值；flag 型 --continue/-c/--resume 直判）。
 *  B5A 曾作「同 grant 最多一次 run」守卫；B5B 起由持久账本接管额度强制（resume/fork 沿用同账户，
 *  设计 §5.3）——本扫描保留供 journal codemode-account 行的阶段标注与测试消费，不再拦截派发。 */
export function argsIndicateSessionResume(args: readonly string[]): boolean {
	for (let i = 0; i < args.length; i++) {
		const arg = args[i]!;
		if (arg === "--" ) break; // 正文分隔符后不是选项
		if (arg === "--continue" || arg === "-c" || arg === "--resume" || arg === "--fork") return true;
		if (arg === "--session" || arg === "--session-id") {
			// --session/--session-id 接驳既有会话即续接语义（--session-id 新建同名会话除外——取值形态与
			// --session 同面处理，保守判续接：受控 grant 下多拒一次无扩权风险）。
			return true;
		}
	}
	return false;
}

/** 保留旧函数名；CodeMode 沿用现有工具面，Advisor 仍须冻结授权，legacy 不交付。 */
export function legacyDispatchToolsWithoutCodemode(tools: readonly string[]): string[] {
	return tools.filter((t) => t !== "amagi_advisor");
}


/** A1 交付物口径：artifact refs（agent-outputs/ 引用）数 + 任务文本「交付物：」标记行数。
 *  产出窗口判定（NEEDS_HANDOFF）与 settle 宽限自适应的共享输入。 */
function deliverableCountOf(rec: Readonly<TaskRecord> | undefined, baselineRefs?: string[]): number {
	const refs = Math.max(rec?.artifactRefs?.length ?? 0, baselineRefs?.length ?? 0);
	const markers = (rec?.goal || "").split("\n").filter((line) => /交付物[:：]/.test(line)).length;
	return refs + markers;
}

/**
 * B1（Wave B）交付物预检①：「交付物：」标记行路径解析。
 * 标记行须位于行首（容忍空白/项目符/粗体包裹）——正文讨论「交付物：」不误触；
 * 行内支持空白/顿号/逗号/分号分隔，标记行留空则取后续逐行清单（项目符行或裸单 token 行，
 * 空行/正文行终止）。token 需含路径特征（/ . _ @ 或反斜杠）——纯中文短语/裸英文词
 * （如「无」「见上文」「done」）不误收。去重有界 ≤16 项。
 */
export function extractDeliverablePaths(task: string): string[] {
	const out: string[] = [];
	const pushToken = (raw: string): void => {
		let t = raw.trim();
		t = t.replace(/^[`"'“「『]+/, "").replace(/[`"'”」』]+$/, ""); // 剥包裹引号
		t = t.replace(/[(（「《【].*$/, "").trim(); // 截掉尾部括号注释（如「（终稿）」）
		t = t.replace(/[，。；、,.;:！！?？）)…]+$/, "").trim(); // 剥尾随标点
		if (!t) return;
		if (!/[\/._@\\]/.test(t)) return; // 路径特征门槛：无路径字符则不当作交付物
		if (out.length >= 16) return;
		out.push(t);
	};
	const lines = task.split(/\r?\n/);
	for (let i = 0; i < lines.length; i++) {
		const m = lines[i].match(/^\s*(?:[-*·•]\s*)?\**\s*交付物\s*\**\s*[:：]\s*(.*)$/);
		if (!m) continue;
		const inline = (m[1] || "").trim();
		if (inline) {
			for (const tok of inline.split(/[\s、，,；;]+/)) pushToken(tok);
			continue;
		}
		// 标记行留空：后续逐行清单（项目符行或裸单 token 行；空行/普通正文行终止）
		for (let j = i + 1; j < lines.length; j++) {
			const l = lines[j];
			if (!l.trim()) break;
			const bullet = l.match(/^\s*[-*·•]\s+(.*)$/);
			if (bullet) {
				pushToken((bullet[1] || "").trim().split(/\s+/)[0] || "");
				continue;
			}
			if (/^\s*\S+\s*$/.test(l)) { pushToken(l.trim()); continue; }
			break;
		}
	}
	return [...new Set(out)];
}

/**
 * B1（Wave B）交付物预检②：逐个 existsSync（相对任务 cwd 解析；绝对路径原样）。
 * v1.5.248：agent-outputs 类 ref 加「cwd 基准宽容」——任务文本里的回退措辞（如「则落 amagi-pi/agent-outputs/review/ 下」）
 * 提取出带 cwd 名前缀的相对路径，解析为 cwd/amagi-pi/agent-outputs/... 后永不存在；而子 Agent 实际把
 * 产物落在 cwd/agent-outputs/...（等价尾段）。对含 agent-outputs/ 的缺失 ref，取从 agent-outputs/ 起的尾段
 * 重试 resolve(cwd)，存在则不算缺——防「注定的缺失」把正常落盘收口成 blocked（diting 审核会话实录）。
 * 返回缺失路径的原文清单（通知呈现用）；解析异常按缺失计（如实呈现）。永不抛错。
 */
export function missingDeliverablePaths(paths: readonly string[], cwd: string): string[] {
	const missing: string[] = [];
	for (const p of paths) {
		try {
			const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
			if (fs.existsSync(abs)) continue;
			// cwd 基准宽容：仅限 agent-outputs 类（提取语义明确，误放面小）；完全未落盘时尾段同样不存在，不误放。
			const marker = p.indexOf("agent-outputs/");
			if (marker >= 0) {
				const tail = p.slice(marker);
				if (tail !== p && fs.existsSync(path.resolve(cwd, tail))) continue;
			}
			missing.push(p);
		} catch {
			missing.push(p);
		}
	}
	return missing;
}

/**
 * ev-20260909-819976：交付物预检「等价落盘」匹配——缺失声明路径 vs 本任务实际写盘轨迹
 * （Wave C2 creditedWritePaths → registry.lastWritePaths，绝对路径）。按 basename 等值匹配：
 * 实战 S3-01 真实交付完整（8 文件+单测全绿），但任务书声明路径与实际落盘路径不一致
 * （语义性声明而非字面路径），existsSync 永远落空 → blocked 驻留 38 分钟。子 Agent 在本任务
 * 会话内真实写入过同名文件即采信为等价交付（写盘轨迹本身是强证据：该文件确实被创建/更新过）。
 * 误放面：恰有同名无关文件的写盘记录——annotation 会列出 declared→actual 对照，验收时可核。
 */
export function matchEquivalentDeliverableWrites(missing: readonly string[], writePaths: readonly string[]): Array<{ declared: string; actual: string }> {
	const norm = (p: string): string => p.replace(/\\/g, "/").replace(/\/+$/, "");
	const out: Array<{ declared: string; actual: string }> = [];
	for (const p of missing) {
		const bn = path.basename(norm(p));
		if (!bn || bn === "." || bn === "..") continue;
		for (const w of writePaths) {
			if (path.basename(norm(w)) === bn) { out.push({ declared: p, actual: w }); break; }
		}
	}
	return out;
}

/**
 * ev-20260909-819976：交付物预检判定明细——每个缺失声明路径给出「原文→解析绝对路径」解析过程，
 * 附进 blocked 回推通知，Leader 无需深挖即可判断缺失是真未落盘还是声明口径偏差（语义/未激活类）。
 */
export function deliverableResolutionNotes(missing: readonly string[], cwd: string): string {
	return missing.map((p) => {
		try {
			const abs = path.isAbsolute(p) ? path.normalize(p) : path.resolve(cwd, p);
			return `${p}→${abs}（不存在）`;
		} catch {
			return `${p}（路径解析失败）`;
		}
	}).join("；");
}

/** ev-20260920-61839b：产物落位机器注入段标记（幂等锚点——含此标记的任务书不再重复追加）。 */
export const DECLARED_OUTPUTS_SECTION_MARKER = "── 产物落位（机器注入段 · task_submit outputs[] 声明契约）──";

/** ev-20260920-61839b：outputs[].path 声明契约闭环——声明冻结时机器注入任务书末尾。
 *  根因（reflect 复盘 §2.1）：outputs[].path 此前只流入权限交集计算，执行者（fast 型弱模型）
 *  只依据任务书正文行动，3/3 调研任务把报告写进 agent-outputs/ 而非声明路径，返工 3 轮 resume。
 *  闭环三层：①本注入段（信息面——子 Agent 看到契约）；②spec.outputs 冻结（契约面——记录声明）；
 *  ③结算面 declaredOutputs 完整性（finalizer）。注入段刻意**不用**「交付物：」标记格式——
 *  标记行解析按空白切分首 token，路径含空格会被截断出「注定的缺失」；落位执法走结构化通道
 *  opts.deliverablePaths（精确路径），文本注入段只供模型阅读。ev-20260929-3c5db4（P0 漏层防线）：
 *  传入 opts.cwd 时每行追加机器解析的绝对路径——子 Agent 以冻结快照为准，不再凭记忆重构绝对
 *  路径（实战：提交路径正确但子 Agent 重构时漏层，ENOENT 连环 blocked）。 */
export function appendDeclaredOutputsSection(
	task: string,
	outputs: ReadonlyArray<{ path: string; kind?: string; required?: boolean; purpose?: string }>,
	opts: { cwd?: string } = {},
): string {
	if (outputs.length === 0) return task;
	if (task.includes(DECLARED_OUTPUTS_SECTION_MARKER)) return task; // 幂等（resume 续接/重复调用防双注入）
	const absNote = opts.cwd !== undefined ? "；→ 后为冻结时机器解析的绝对路径，以此为准不要凭记忆重构" : "";
	const lines = outputs.map((o, i) =>
		`${i + 1}. ${o.path}${opts.cwd !== undefined ? ` → ${path.resolve(opts.cwd, o.path)}` : ""}${o.kind === "tree" ? "（目录）" : ""}${o.required === false ? "（可选）" : "（必需）"}`,
	);
	return [
		task.trimEnd(),
		"",
		DECLARED_OUTPUTS_SECTION_MARKER,
		`最终产物必须写入以下声明路径本身（任务书正文其它落位描述以此为准；相对路径按任务工作目录解析${absNote}；不要改写到 agent-outputs/ 等其它位置）：`,
		...lines,
	].join("\n");
}

// ── 工具函数 ─────────────────────────────────────────────────────────────────
export function genTaskId(): string {
	return crypto.randomUUID(); // 完整 UUID（P2-1 防碰撞）
}

/** 决定 spawn 命令（官方 getPiInvocation 同款）；测试可经 opts.command 注入 fake runner */
function getPiInvocation(args: string[]): { command: string; args: string[] } {
	const current = process.argv[1];
	const isBunVirtual = current?.startsWith("/$bunfs/root/");
	if (current && !isBunVirtual && fs.existsSync(current)) {
		return { command: process.execPath, args: [current, ...args] };
	}
	const execName = path.basename(process.execPath).toLowerCase();
	if (!/^(node|bun)(\.exe)?$/.test(execName)) {
		return { command: process.execPath, args };
	}
	return { command: "pi", args };
}

/** ev-20260922-1b1662：spawn ENOENT 归因增强——Node 报文只含命令名（cwd 缺失与命令缺失同形），
 *  实战曾把「任务目录被移动导致 cwd 失效」误诊为「fnm node 二进制丢失」而废弃运行环境。
 *  此处实测命令与 cwd 存在性，把真实归因附进 spawnError，失败时零歧义。 */
export function diagnoseSpawnFailure(err: Error, command: string, cwd: string): string {
	const base = String(err);
	if (!/ENOENT/.test(err.message)) return base;
	const causes: string[] = [];
	if (!fs.existsSync(command)) causes.push(`命令不存在: ${command}`);
	if (!fs.existsSync(cwd)) causes.push(`工作目录不存在: ${cwd}（目录可能被移动/重命名——cwd 缺失同样触发本报文，此为真实根因的概率最高）`);
	if (causes.length === 0) causes.push("命令与工作目录均存在——可能是瞬时竞态（spawn 与目录删除并发）或脚本解释器/shebang 缺失");
	return `${base}〔归因: ${causes.join("；")}〕`;
}

// ── ev-20260914-8f2669①：长命令纪律（子进程系统提示默认段）──
// 实战 4 次（含 2 次收尾阶段，其中一次实现已 100% 落盘仅差报告）：批量图片/文件生成类单命令
// 处理数十文件、无周期输出，子进程 watchdog 按静默超时判死 abort。该纪律此前只存在于 Leader
// 人工写的任务书里，节点系统提示并不知晓——writePromptTmp 是 sync/background/resume 三条派发
// 路径共用的系统提示落盘唯一漏斗，在此默认下发（措辞 ≤150 字，不膨胀系统提示）。
export const LONG_COMMAND_DISCIPLINE =
	"[amagi 长命令纪律] 预计超过 3 分钟的 bash 命令应拆批执行（每批 ≤3 分钟），批次间 echo 一行进度；批量生成/处理脚本每完成若干项输出一行进度——长时间无输出会被看门狗按静默超时（默认 30 分钟）中止。";
const LONG_COMMAND_DISCIPLINE_ANCHOR = "[amagi 长命令纪律]";

export async function writePromptTmp(name: string, prompt: string): Promise<{ dir: string; file: string }> {
	// P1-2: 自回滚——write 失败时清理 mkdtemp 的目录
	const dir = await fs.promises.mkdtemp(path.join(os.tmpdir(), "amagi-task-"));
	try {
		const safe = name.replace(/[^\w.-]+/g, "_");
		const file = path.join(dir, `prompt-${safe}.md`);
		// ev-20260914-8f2669①：长命令纪律随子进程系统提示默认下发（幂等：含锚不再追加）
		const content = prompt.includes(LONG_COMMAND_DISCIPLINE_ANCHOR) ? prompt : `${prompt.trimEnd()}\n\n${LONG_COMMAND_DISCIPLINE}`;
		await fs.promises.writeFile(file, content, { mode: 0o600 });
		return { dir, file };
	} catch (e) {
		try {
			await fs.promises.rm(dir, { recursive: true });
		} catch {
			/* best effort */
		}
		throw e;
	}
}

/**
 * 权威 blocked 信号 marker（精确 HTML 注释子串匹配，免疫全部 markdown 边缘形态）。
 * 子 Agent 真 blocked 时第一行输出此 marker；复述契约（无此 marker）不命中。
 */
export const AMAGI_BLOCKED_MARKER = "<!--AMAGI:BLOCKED-->";

/**
 * 权威完成信号 marker（与 AMAGI_BLOCKED_MARKER 对称）。
 * 子 Agent（编码角色）完成时在终稿末行输出，上方为 ACHIEVEMENT 清单（验收标准→证据→状态）。
 * 用于「完成度自证」校验——防截断/降级伪装成 done。检测严格（hasDoneMarker，P2-1）：
 * 末行精确 === 本 marker + 前文含 ACHIEVEMENT 清单（验收标准→证据→状态）才算已自证。
 */
export const AMAGI_DONE_MARKER = "<!--AMAGI:DONE-->";

/**
 * 8月迭代 pi-0.84 配合 P1④：子进程 guards 硬边界（protectedPaths/allowedPaths 命中）阻断
 * reason 的精确前缀（跨节点契约：guards 节点保证 reason 以此开头且 terminate:true）。
 * pi 0.84.1 起 tool_call 阻断返回支持 terminate——批次内全部终止性结果才提前结束 run
 * （无后续 assistant 文本）；结算侧据此识别「边界终止」并抑制自动续跑。
 */
export const BOUNDARY_GUARD_MARKER = "[AMAGI 守卫·硬边界]";
/** 边界终止结算根因的有界截断（字符）。 */
const BOUNDARY_GUARD_REASON_CAP = 200;

/**
 * 所有新派发与 resume 共用的执行纪律。
 * 名称和参数严格对齐 pi 内置工具：grep/find/ls/read/edit/write/bash。
 */
export const EXECUTION_DISCIPLINE_REMINDER = `\n\n[amagi 执行纪律] “工作区预检”段已由脚本采集目录、索引、测试命令与部分正文：已内联的内容不要重复 pwd/ls/find/cat/read 获取，未内联或可能并发变化的目标按需定位与读取；无预检时先定位、读取再修改。文件读取、搜索和修改按场景选择原生工具或 shell 命令（如 sed/grep/awk），不因工具选择本身视为错误。Bash 失败先查 cwd/路径/依赖/参数/代码——原样重试通常还会失败，定位原因再跑更省力。`;

/** 新派发与 resume 共用的最小完成协议。 */
export const DONE_CONTRACT_REMINDER = `${EXECUTION_DISCIPLINE_REMINDER}\n\n[amagi 结果协议] 缺信息：首行 ${AMAGI_BLOCKED_MARKER}，随后 STATUS: blocked + QUESTIONS。完成：终稿必须含独立标题 ACHIEVEMENT:，其下用列表或表格逐项写“验收→证据→状态”，并以独占末行 ${AMAGI_DONE_MARKER} 收尾；没做完或拿不准时不输出 marker，如实写明进展与卡点即可。终稿保持紧凑（要点摘要 ≤30 行）。长报告写 artifact。`;

/** ev-20260917-589972（P2）：共享工作树纪律——「外部合法并行写入」一等公民语义。
 *  实战：共享树多进程协作时子 Agent 为归因把主上未提交改动 stash 后恢复（中断即丢）；未归因
 *  改动对子 Agent 只读——禁 stash/checkout/restore/reset 等操作他人未提交工作，归因只观察不改变
 *  工作区状态（守卫层同步补子 Agent stash 硬拦截，git-discard-guard decideSubagentStashGate）。
 *  ev-20261001-4f2a9c：补跨会话归因一句——多会话同仓库时，与任务书无关的新目录/文件（如其它
 *  会话的任务输入/草稿）按并行会话中间产物处理（跨会话探测见 cross-session-writers.ts；本句
 *  兜底探测盲区：对方 Leader 直接写盘/RPC 会话/陈旧窗口）。独立块注入（不并入
 *  DONE_CONTRACT_REMINDER——后者已贴近 700B 预算上限，prompt-footprint 门禁）。
 *  ev-20261031-561b9d：补时序+归因句——并行写入者快照（预检/续轮刷新行）只反映注入时刻，先派
 *  任务看不到快照后启动的兄弟；全仓编译/测试读取整个仓库（read 面不等于声明面）。公共纪律对
 *  所有共享树任务（含 resume 续轮）统一：中途全仓验证失败按因果核对（review F01：报错路径在
 *  写面外 ≠ 外因——自己的接口/依赖变化会让未改动文件报错），确属外来中间态/既有问题才说明后
 *  继续；不假定自己失败、不盲改他人；自己的变更引起的范围外报错在自己写面内修正。可能性措辞
 *  ——不把没有兄弟说成有；纯信息面，无新增拒绝/权限。 */
export const SHARED_TREE_DISCIPLINE = `\n\n[amagi 共享树纪律] 工作区内未归因改动只读：请不要 stash/checkout/restore/reset 等改动或丢弃他人未提交工作（那可能是别人正在做的事）；归因分析只观察（git status/diff/log），不改变工作区状态。与你的任务书无关的新目录/文件可能是并行会话/任务的中间产物：不改、不删、不纳入产出，不因它们中断。并行写入者快照（预检/续轮刷新行）只反映注入时刻，之后同 cwd 仍可能有新兄弟或其它会话启动写入；全仓编译/测试读取的是整个仓库而非只有你的写面——中途失败按因果核对，不只看报错路径在不在写面：自己的接口/依赖变化也会让未改动的文件报错，先对照自己的改动逐条判定来源（git diff/status + 报错语义）；确属外来中间态或既有问题的，如实说明后继续，不把失败默认当成自己的，也不去改他人的文件；由你的改动引起的范围外报错，在自己写面内修正（范围不够时报告约束）；最终验收以结算隔离快照为准。`;

// ── ev-20260914-ce6bd2：超长任务书 argv 降级 + E2BIG 防线 ──────────────────────
// 实战缺口：最终任务书（任务文本 + 工作区预检 + 完成契约提醒）拼装后作为单个 argv 参数传给
// 子进程 pi；OS 对单参数/argv 总量有上限（Linux MAX_ARG_STRING 单串 128KB、ARG_MAX 常见 2MB，
// macOS E2BIG 同族），超限 spawn 直接失败——此前零降级，超长任务书=必死派发。两级防线：
//   >TASK_PROMPT_FILE_THRESHOLD：完整最终任务书落盘 <任务cwd>/amagi-task/<taskId>/goal-full.md
//     （目录自动创建；amagi-task/ 是任务沙箱惯用前缀），argv 只投 [派发降级] 摘要
//     （read 指引 + 首 500 字），子 Agent 开工第一步自读全文；
//   >TASK_PROMPT_HARD_LIMIT：拒单（该体量连落盘降级都失去意义——任务书本身就该拆，
//     建议与 warnLongTaskTexts 同款：长材料先落 artifact 只留路径）。
// 派发三路径同款接线：sync runTask（task-tool）/ background runBackgroundTask / resume _launch（task-resume）。
export const TASK_PROMPT_FILE_THRESHOLD = 128 * 1024;
export const TASK_PROMPT_HARD_LIMIT = 900 * 1024;

/** 上下文中的旧任务/旧产物不参与本节点目标、分类与上游引用推导；执行提示仍保留完整快照。 */
export function currentAssignmentBody(task: string): string {
	const marker = "\n[当前任务书]\n";
	const cut = task.startsWith("[Leader 上下文快照·历史资料]\n") ? task.indexOf(marker) : -1;
	return cut >= 0 ? task.slice(cut + marker.length) : task;
}

export interface TaskPromptPlan {
	action: "pass" | "offload" | "reject";
	/** 最终任务书 UTF-8 字节数。 */
	bytes: number;
	/** offload：替换 argv 的 [派发降级] 摘要；pass：原文。 */
	prompt: string;
	/** reject 拒单文案。 */
	reason?: string;
	/** offload 全文落盘绝对路径（applyTaskPromptOffload 写入）。 */
	offloadPath?: string;
	/** 活动登记用 taskId。 */
	taskId: string;
}

/** 纯决策（不落盘不写 registry，可直测）：按最终 prompt UTF-8 字节数三态分流。 */
export function planTaskPrompt(finalPrompt: string, cwd: string, taskId: string): TaskPromptPlan {
	const bytes = Buffer.byteLength(finalPrompt, "utf8");
	if (bytes <= TASK_PROMPT_FILE_THRESHOLD) return { action: "pass", bytes, prompt: finalPrompt, taskId };
	if (bytes > TASK_PROMPT_HARD_LIMIT) {
		return {
			action: "reject", bytes, prompt: finalPrompt, taskId,
			reason: `[任务书超限拒单] 最终任务书约 ${(bytes / 1024).toFixed(0)}KB，超过硬上限 ${Math.round(TASK_PROMPT_HARD_LIMIT / 1024)}KB——argv 传参必 E2BIG，落盘降级也已失去意义。请：a) 拆成更小的独立任务（各节点自读文件）；b) 长材料/文档先落 artifact 只留路径引用，任务书只保留目标+约束+验收。`,
		};
	}
	const abs = path.join(cwd || process.cwd(), "amagi-task", taskId, "goal-full.md");
	return {
		action: "offload", bytes, taskId,
		prompt: `[派发降级] 完整任务书已落盘 ${abs}（${finalPrompt.length} 字）。开工第一步：用 read 工具完整读取该文件后再执行——本段只是摘要，细节与验收都在文件里。摘要（首 500 字）：${finalPrompt.slice(0, 500)}`,
		offloadPath: abs,
	};
}

/** 执行 offload：全文落盘 + registry 活动登记（type=prompt_offload，summary ≤200 字——轨迹可查）。
 *  写盘失败抛错：调用方按启动失败收口（回退 argv 原文必 E2BIG，不静默降级）。 */
export function applyTaskPromptOffload(plan: TaskPromptPlan, fullPrompt: string): void {
	if (plan.action !== "offload" || !plan.offloadPath) return;
	fs.mkdirSync(path.dirname(plan.offloadPath), { recursive: true });
	fs.writeFileSync(plan.offloadPath, fullPrompt, "utf8");
	try {
		registry.appendActivity(plan.taskId, {
			type: "prompt_offload",
			// 路径前置：200 字截断优先保全落盘坐标，说明性尾文可被切
			summary: `[任务书落盘降级] ${plan.offloadPath}（${(plan.bytes / 1024).toFixed(0)}KB 超 argv 阈值 ${Math.round(TASK_PROMPT_FILE_THRESHOLD / 1024)}KB，已改投 [派发降级] 摘要）`.slice(0, 200),
			ts: Date.now(),
		});
	} catch { /* 活动登记失败不影响派发主流程 */ }
}


/**
 * regex 兜底（弱模型忘 marker 时的辅助；保留既有水平）。
 * 简化：token 间用 [ \t*]*（空格/tab/*）容忍任意粗体组合；行首 ^ {0,3} 排除缩进代码块；
 * 全角冒号/全角感叹号；独占整行。
 */
export const BLOCKED_REGEX = /^ {0,3}\**STATUS[ \t*]*[:：][ \t*]*blocked\b[ \t*]*[.。!！]?[ \t*]*$/im;

/**
 * blocked 结果的 Leader 行动指令（实战事故：后台 blocked 通知送达后 Leader 只确认不答复，
 * 子 Agent 的 QUESTIONS 被无限搁置）。所有 blocked 输出（sync 结果/后台完成通知/resume 结果）
 * 统一追加本指令——明确"必须当轮 resume 答复或升级主上"，把协议义务写进消息本体而非仅靠 L0 记忆。
 * diting Major-4：blockReason 区分两类行动语义——"questions"（缺省，遗留语义不变）要求
 * 逐项答复；"needs-handoff"（settle 产出窗口收口）是接手开工指令，绝不出现 QUESTIONS/逐项答复文案。
 */
export function blockedReplyDirective(taskId: string, blocked: boolean, blockReason?: "questions" | "needs-handoff"): string {
	if (!blocked) return "";
	if (blockReason === "needs-handoff") {
		return `\n\n【Leader 行动要求】该子 Agent 在产出窗口被 settle 收口（NEEDS_HANDOFF，非提问）：任务声明了交付物但本轮零写盘，会话上下文完好。请在本轮用 task({ session: "${taskId}", task: "接手开工，继续完成交付" }) resume 续跑；交付物尚未开工，不要按 done 结案，也没有问题需要答复。`;
	}
	return `\n\n【Leader 行动要求】该子 Agent 信息不足已退出（QUESTIONS 见上），正在等待答复。请在本轮用 task({ session: "${taskId}", task: "逐项答复" }) 续接回复；确实答不了的，如实告知主上并请其裁决。该任务在等答复，请不要沉默搁置或只确认不回复——一句简短的答复就能让它继续推进。`;
}

/**
 * ev-20260910-8fbe4e（C）：error 终态是否为连接/provider 类中断——finalize 侧 providerError 的
 * registry 等价判定（迟终态回推重建现场报告时复用同一口径）：stopReason=error/aborted 或
 * errorMessage 为裸 provider 文本。引擎主动终止根因（[超时]/[中止]/[截断]/[死循环]/
 * [killed-by-settle]/[NEEDS_HANDOFF]/[启动就绪超时]、启动失败）均以本地标记开头，不属连接类中断。
 */
export function isProviderInterruption(status: string, stopReason?: string, errorMessage?: string): boolean {
	if (status !== "error") return false;
	if (stopReason === "error" || stopReason === "aborted") return true;
	return typeof errorMessage === "string" && errorMessage !== "" && !/^\[/.test(errorMessage) && !errorMessage.startsWith("启动失败");
}

/** ev-20260910-8fbe4e（C）：中断现场报告输入（buildInterruptionReport 参数面；纯数据，可注入供测试）。 */
export interface InterruptionReportInput {
	taskId: string;
	/** 任务工作目录（git 差集归因基准；缺省省略归因段）。 */
	cwd?: string;
	/** 任务写入登记（readTaskWrites(taskId)；含 at 时间）。 */
	writes: ReadonlyArray<{ file: string; tool: string; at: number }>;
	/** 最后活动时刻（取大者另一源：finalize 传最后干净终稿帧 lastAssistantEndTs；迟终态回推传活动窗口尾 ts）。 */
	lastAssistantEndTs?: number;
	/** 终态时刻（缺省 Date.now()）。 */
	endedAt?: number;
	/** spawn 前工作区快照（gitBaseline；非数组省略差集归因段）。 */
	gitBaseline?: string[] | null;
	/** 会话标识（有产物时的 resume 建议命令）。 */
	sessionId?: string;
}

/** 中断现场报告已写文件清单上限（超出折叠为计数；登记本身有界 ≤512 行）。 */
const INTERRUPTION_LISTED_FILES_MAX = 8;

function fmtClock(ts: number): string {
	return formatAmagiClock(ts, "local");
}

// ── ev-20260916-804ea3（方案 §5.5）：统一时区标注时间输出 ──
// 旧态混用两套时基（query 侧 toISOString 的 UTC 时分秒 vs 停滞告警/进程实况的 toTimeString 本地
// 时分秒），同名异基不可辨。统一为带日期与时区标注的 `YYYY-MM-DD HH:mm:ss UTC`；
// AMAGI_QUERY_TIME_FORMAT=legacy 回旧文本格式（query=ISO 时分秒；local=本机 toTimeString）。
// 存储时基（epoch ms）不变；测试用固定 epoch，不依赖运行机器时区。

/** 804ea3：AMAGI_QUERY_TIME_FORMAT=legacy 回旧文本格式（缺省/非法回 utc）。 */
export function queryTimeFormatLegacy(env: NodeJS.ProcessEnv = process.env): boolean {
	return env.AMAGI_QUERY_TIME_FORMAT === "legacy";
}

/** 804ea3：统一时间输出（含日期与时区标注）。style 仅在 legacy 模式下生效（query=旧 ISO 时分秒 /
 *  local=旧本机 toTimeString 时分秒）；非法/缺失时间返回显式占位。 */
export function formatAmagiClock(ts: number | string, style: "query" | "local" = "query"): string {
	const d = new Date(ts);
	const valid = typeof ts === "number" ? Number.isFinite(ts) && ts > 0 : !isNaN(d.getTime());
	if (!valid) return style === "local" ? "—" : "??:??:??";
	if (queryTimeFormatLegacy()) {
		return style === "local" ? d.toTimeString().slice(0, 8) : d.toISOString().slice(11, 19);
	}
	return `${d.toISOString().slice(0, 19).replace("T", " ")} UTC`;
}

/**
 * ev-20260910-8fbe4e（C）：连接类中断现场报告（纯函数，永不抛错）。
 * 三要素：① 已写文件清单（写入登记含 at 时间 + git 差集归因档位计数，own/↔sib/⚠ext）
 * ② 最后活动时间（最后写盘 at / lastAssistantEndTs 取大者）+ 距终态时长
 * ③ 续点建议：有产物 → resume 续接（session 保留）优先或 fresh+接力包；无产物 → 直接重派。
 * 痛点背景：error 终态通知只有一行根因，产物归因数据在 finalizeTerminal 体系内但 error 场景
 * 不汇总输出，Leader 需 3 次 bash 手工盘点（evo 现状调查 §2.3）。
 */
export function buildInterruptionReport(o: InterruptionReportInput): string {
	const endedAt = o.endedAt ?? Date.now();
	// ① 已写文件清单：按文件去重（同一文件多次写入保留最新 at），按 at 降序有界列出
	const latest = new Map<string, { tool: string; at: number }>();
	for (const w of o.writes) {
		if (!w || typeof w.file !== "string" || !w.file) continue;
		const at = typeof w.at === "number" && Number.isFinite(w.at) && w.at > 0 ? w.at : 0;
		const prev = latest.get(w.file);
		if (!prev || at >= prev.at) latest.set(w.file, { tool: String(w.tool || "?").slice(0, 16), at });
	}
	const files = [...latest.entries()].sort((a, b) => b[1].at - a[1].at);
	const lines: string[] = [];
	const shown = files.slice(0, INTERRUPTION_LISTED_FILES_MAX).map(([f, m]) => `  - ${f}（${m.tool}，${fmtClock(m.at)}）`).join("\n");
	const overflow = files.length - Math.min(files.length, INTERRUPTION_LISTED_FILES_MAX);
	lines.push(files.length > 0
		? `• 已写文件：${files.length} 个（任务写入登记，含 at 时间）\n${shown}${overflow > 0 ? `\n  …另有 ${overflow} 个未列出` : ""}`
		: "• 已写文件：0 个（无写入登记——中断前未落盘）");
	// ①归因档位：git 差集 vs 派发基线（baseline 缺省/git 不可用 → 省略段，不猜测）
	if (o.cwd && Array.isArray(o.gitBaseline)) {
		try {
			const counts = freshAttributionCounts(o.cwd, o.gitBaseline, o.taskId);
			if (counts) lines.push(`• git 差集归因：任务期间新增/变化 ${counts.fresh} 处——own ${counts.own}、↔sib ${counts.sib}、⚠ext ${counts.ext}（详单见产物摘要块）`);
		} catch { /* 归因失败静默省略（观测面绝不反噬主流程） */ }
	}
	// ② 最后活动时间（最后写盘 at / lastAssistantEndTs 取大者）+ 距终态时长
	const lastWriteAt = files.length ? files[0][1].at : 0;
	const lastAssistant = typeof o.lastAssistantEndTs === "number" && Number.isFinite(o.lastAssistantEndTs) && o.lastAssistantEndTs > 0 ? o.lastAssistantEndTs : 0;
	const lastTs = Math.max(lastWriteAt, lastAssistant);
	if (lastTs > 0) {
		const gap = formatRunDuration(Math.max(0, Math.round((endedAt - lastTs) / 1000)));
		const parts: string[] = [];
		if (lastWriteAt > 0) parts.push(`最后写盘 ${fmtClock(lastWriteAt)}`);
		if (lastAssistant > 0) parts.push(`最后活动帧 ${fmtClock(lastAssistant)}`);
		lines.push(`• 最后活动：${parts.length > 1 ? `${parts.join(" / ")} → 取 ${fmtClock(lastTs)}` : parts[0]}，距终态 ${gap}（终态 ${fmtClock(endedAt)}）`);
	} else {
		lines.push("• 最后活动：无记录（零写盘、无干净终稿帧——疑启动即断）");
	}
	// ③ 续点建议：有产物 → resume 续接优先或 fresh+接力包；无产物 → 直接重派
	lines.push(files.length > 0
		? `• 建议：已有 ${files.length} 个写入产物——resume 续接优先（session 保留${o.sessionId ? `，可 task({ session: "${o.sessionId.slice(0, 8)}", task: "接手继续" })` : ""}）；或 fresh 派发+接力包（上下文不回放，带产物清单重新开工）`
		: "• 建议：无产物落盘——直接重派（fresh 重发任务书；session 无可续上下文，resume 意义不大）");
	return `[中断现场报告] 连接类中断现场盘点（provider 断连/超时）：\n${lines.join("\n")}`;
}

/**
 * v1.5.216: 停滞警告最近活动摘要——activityWindow 尾部至多 2 条（每条截断 60 字，空白归一），
 * 供 Leader 一眼区分「健康长命令（最近活动持续推进）」与「真卡死（最近活动停在中途）」。
 * 无活动窗口/全空摘要返回空串（警告文案保持原样）。
 */
export function stallActivityDigest(rec: Readonly<{ activityWindow?: Array<{ type: string; summary?: string }> }> | undefined): string {
	const acts = (rec?.activityWindow ?? [])
		.slice(-2)
		.map((ev) => String(ev.summary || ev.type || "").replace(/\s+/g, " ").trim().slice(0, 60))
		.filter(Boolean);
	return acts.length ? `；最近活动: ${acts.join(" | ")}` : "";
}

/**
 * 有界运行时长文案（秒→分→时，供进程实况注记与终态回推共用）。
 */
export function formatRunDuration(sec: number): string {
	const s = Number.isFinite(sec) && sec >= 0 ? Math.round(sec) : 0;
	if (s < 120) return `${s}s`;
	const m = Math.round(s / 60);
	if (m < 120) return `${m} 分钟`;
	return `${(m / 60).toFixed(1)} 小时`;
}

/**
 * ev-20260905-24558f（P0）：task error 返回体的进程实况注记（纯函数，now 可注入供测试）。
 *
 * 实战事故（fuxi/503b960c）：sync 派发返回体报 error（SSE 超时+降档拒单），但子进程实际
 * 继续运行 85 分钟才 settled(error) 零产出——返回体只报根因不报进程存续，Leader 误以为
 * 已全部收场而干等。判定口径：child 句柄未清 / status 仍 running → 仍在运行（附最近活动
 * 时间与摘要、已运行时长，引导 query_task 观察或 task cancel 止损）；否则 endedAt 存在 →
 * 已退出（附 endedAt 时刻）。无记录 / 未启动（无 endedAt 的非终态）→ 空串不追加。
 */
export function processLivenessNote(
	rec: Readonly<Pick<TaskRecord, "status" | "child" | "startedAt" | "endedAt" | "activityWindow">> | undefined,
	now: number = Date.now(),
): string {
	if (!rec) return "";
	if (rec.status === "running" || rec.child !== undefined) {
		const acts = rec.activityWindow ?? [];
		const lastTs = acts.length ? acts[acts.length - 1].ts : undefined;
		const at = typeof lastTs === "number" && Number.isFinite(lastTs) && lastTs > 0
			? formatAmagiClock(lastTs, "local")
			: "(尚无活动记录)";
		const digest = stallActivityDigest(rec).replace(/^；最近活动: /, " · ");
		const runSec = Math.max(0, Math.round((now - (rec.startedAt || now)) / 1000));
		return `[进程实况] 仍在运行（最近活动: ${at}${digest}，已运行 ${formatRunDuration(runSec)}）——建议 query_task 观察 或 task cancel 止损`;
	}
	if (typeof rec.endedAt === "number" && Number.isFinite(rec.endedAt) && rec.endedAt > 0) {
		return `[进程实况] 已退出（endedAt ${formatAmagiClock(rec.endedAt, "local")}）`;
	}
	return "";
}

/**
 * blocked 信号检测（Leader 协议裁定）：
 *   1. CRLF 归一化（\r\n / 孤立 \r → \n）
 *   2. 权威 marker 协议：**第一非空物理行**整行（trimEnd 去行尾空白，保留前导以拒绝缩进）精确 === `<!--AMAGI:BLOCKED-->`
 *      — 出现在正文/引用/inline code/blockquote/缩进代码/后续行/前后缀/尾随标点的 marker 均无效（引用讨论，非信号）
 *   3. regex 兜底（stripCodeBlocks 后；弱模型忘 marker 时的裸文本 STATUS 辅助）
 * marker 路径不 strip（第一非空物理行原样判断，fence 内的 marker 自然不在第一非空行）。
 */
export function detectBlocked(text: string): boolean {
	const normalized = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
	const firstNonEmpty = normalized.split("\n").find((l) => l.trim() !== "");
	if (firstNonEmpty !== undefined && firstNonEmpty.trimEnd() === AMAGI_BLOCKED_MARKER) {
		return true;
	}
	return BLOCKED_REGEX.test(stripCodeBlocks(normalized));
}

/**
 * 完成 marker 检测（严格末行协议，P2-1 修复）：
 *   1. CRLF 归一化 + stripCodeBlocks（移除代码块内 marker——代码块复述不算自证）。
 *   2. 最后一个非空物理行 trimEnd 后精确 === AMAGI_DONE_MARKER（保留前导以拒绝缩进/引用块/行内复述）。
 *   3. 前文含独立 ACHIEVEMENT 标题行，且标题后至少有一个非空列表项，或一个含数据行的 Markdown 表格；
 *      空心/否定复述及只有表头的空表不得通过。
 * 与 detectBlocked 的权威首行协议对称：done marker 必须独占末行。
 * 直接对全文末尾判定（不切字节窗口）：消除「窗口切点落在 marker 内」的漏判，简单可靠优先。
 */
/**
 * ee7357（ev-20261012）：完成契约未自证成因诊断——与 hasDoneMarker 同一契约口径（CRLF 归一 +
 *  stripCodeBlocks + 末非空行精确匹配 + 独立 ACHIEVEMENT 标题 + 有效清单），只诊断不改判：
 * hasDoneMarker 仍是不自证标注/自动续跑豁免的唯一判定源，本函数仅把「未通过」细分为形态供
 * annotateCompletion 精确告警（旧实现统一说「未输出 AMAGI:DONE 清单」，真实终稿（标题拼成
 * ACCOMPLIEVEMENT、marker 合规）与完全无 marker 混为一谈）。形态：
 *  - tail-marker-missing：全文无独立 marker 行（代码块内/引用/缩进/行内复述均被 strip/精确匹配排除）；
 *  - tail-marker-position：独立 marker 行存在但未独占末非空行（位置错误/收尾中断）；
 *  - heading-missing / heading-typo：标准 ACHIEVEMENT 标题缺失 / 疑似拼错（如 ACCOMPLIEVEMENT——
 *    拼错不计为自证，判定不放宽）；
 *  - list-empty：标题在但清单无有效内容（无列表项也无含数据行的表格；空心复述/仅表头空表不算）。 */
export type CompletionContractCause = "tail-marker-missing" | "tail-marker-position" | "heading-missing" | "heading-typo" | "list-empty";

/** 诊断结果：ok=true 自证通过；false 时 cause 必填，heading-typo 附疑似拼错行文本。 */
export interface CompletionContractDiagnosis {
	ok: boolean;
	cause?: CompletionContractCause;
	/** heading-typo：疑似拼错的标题位行文本（trim 后，供告警引用原文）。 */
	headingLike?: string;
}

/** be7271（ev-20261020）：标准 ACHIEVEMENT 标题行判定（诊断/定位共用单源——diagnoseCompletionContract
 *  的合法标题判定与已落盘产物定位 locatorAchievementHeading 共用同一口径）。 */
const ACHIEVEMENT_TITLE_RE = /^\s*#{0,6}\s*\**\s*ACHIEVEMENT\b/i;

/** 标题样行首 token 提取：剥行首 #（≤6 级）/粗体包裹后取首个字母词（覆盖 # 引导、**加粗、
 *  裸行内冒号三种形态）；无字母词返回 null。 */
function titleLikeFirstWord(line: string): string | null {
	const m = /^\s*#{0,6}\s*\**\s*([A-Za-z]+)/.exec(line);
	return m ? m[1] : null;
}

/** 有界 Levenshtein（词长 ≤20；两词一致 0）。诊断词量小（每行一首 token），O(n²) 微秒级。 */
function levenshteinAtMost(a: string, b: string, cap: number): number {
	if (Math.abs(a.length - b.length) > cap) return cap + 1;
	const m = a.length, n = b.length;
	const prev = new Array<number>(n + 1);
	const cur = new Array<number>(n + 1);
	for (let j = 0; j <= n; j++) prev[j] = j;
	for (let i = 1; i <= m; i++) {
		cur[0] = i;
		let rowMin = cur[0];
		for (let j = 1; j <= n; j++) {
			cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
			if (cur[j] < rowMin) rowMin = cur[j];
		}
		if (rowMin > cap) return cap + 1;
		for (let j = 0; j <= n; j++) prev[j] = cur[j];
	}
	return prev[n];
}

/** be7271（ev-20261020）：近形拼写统一度量——大小写无关、首锚 AC、对目标词族
 *  {ACHIEVEMENT, ACCOMPLISHMENT}（协议标题与其常见语义兄弟词）的编辑距离 ≤3。
 *  取代旧枚举式正则（AC[COG]\w*EMENT|ACCOMPLISH\w*|…——枚举覆盖不全，ACPIEMENT 两度漏判报
 *  「全文无标题」）。统一度量覆盖 ACPIEMENT(3)/ACCOMIEVEMENT(3)/ACCOMVEMENT(3)/ACCOMPLIEVEMENT(3)/
 *  ACCOMPLISHMENT(0)/ACHIEVMENT(1)/ACHIVEMENT(1)/ACHIEVEMENTS(1)；ACCOUNT(7)/ACCIDENT(5)/
 *  ACKNOWLEDGMENT(7)/ACQUIREMENT(4) 等真实不相关词不命中。只用于告警定位，不影响判定。 */
const NEAR_FORM_REFERENCE_WORDS = ["ACHIEVEMENT", "ACCOMPLISHMENT"] as const;
const NEAR_FORM_DISTANCE_CAP = 3;

export function isNearAchievementWord(word: string): boolean {
	if (word.length < 7 || word.length > 16) return false;
	const upper = word.toUpperCase();
	if (!upper.startsWith("AC")) return false; // 首锚：协议词族全部 AC 开头
	for (const ref of NEAR_FORM_REFERENCE_WORDS) {
		if (levenshteinAtMost(upper, ref, NEAR_FORM_DISTANCE_CAP) <= NEAR_FORM_DISTANCE_CAP) return true;
	}
	return false;
}

/** 完成契约诊断（纯函数，hasDoneMarker 的细化单源）。 */
export function diagnoseCompletionContract(text: string): CompletionContractDiagnosis {
	const stripped = stripCodeBlocks(text.replace(/\r\n/g, "\n").replace(/\r/g, "\n"));
	const lines = stripped.split("\n");
	let lastNonEmptyIdx = -1;
	for (let i = lines.length - 1; i >= 0; i--) {
		if (lines[i].trim() !== "") { lastNonEmptyIdx = i; break; }
	}
	if (lastNonEmptyIdx === -1 || lines[lastNonEmptyIdx].trimEnd() !== AMAGI_DONE_MARKER) {
		// 独立 marker 行（trimEnd 后精确相等）存在于他处 → 位置错误；否则缺失。
		const elsewhere = lines.some((l) => l.trimEnd() === AMAGI_DONE_MARKER);
		return { ok: false, cause: elsewhere ? "tail-marker-position" : "tail-marker-missing" };
	}
	// 独立 ACHIEVEMENT 标题 + 有效列表或表格；接受模型自然生成的两种“清单”形态，
	// 避免合法表格被误判后触发昂贵自动续跑（与旧 hasDoneMarker 同一判定）。
	const titleIdx = lines.findIndex((l) => ACHIEVEMENT_TITLE_RE.test(l));
	if (titleIdx === -1) {
		// 近形标题位探测（be7271 统一度量，见 isNearAchievementWord；只用于告警定位与核验建议，
		// 不影响 hasDoneMarker 判定）。
		const typoLine = lines.find((l) => {
			const w = titleLikeFirstWord(l);
			return w !== null && isNearAchievementWord(w);
		});
		return {
			ok: false,
			cause: typoLine ? "heading-typo" : "heading-missing",
			...(typoLine ? { headingLike: typoLine.trim().replace(/^\**/, "").replace(/\**$/, "") } : {}),
		};
	}
	const LIST_RE = /^\s*(?:[-*]\s+|\d+[.)]\s+)\S/;
	const TABLE_RE = /^\s*\|.*\|\s*$/;
	const TABLE_SEPARATOR_RE = /^\s*\|(?:\s*:?-{3,}:?\s*\|)+\s*$/;
	const body = lines.slice(titleIdx + 1, lastNonEmptyIdx);
	if (body.some((l) => LIST_RE.test(l))) return { ok: true };
	for (let i = 1; i < body.length - 1; i++) {
		if (!TABLE_SEPARATOR_RE.test(body[i]) || !TABLE_RE.test(body[i - 1])) continue;
		if (body.slice(i + 1).some((l) => TABLE_RE.test(l) && !TABLE_SEPARATOR_RE.test(l))) return { ok: true };
	}
	return { ok: false, cause: "list-empty" };
}

export function hasDoneMarker(text: string): boolean {
	return diagnoseCompletionContract(text).ok;
}

/**
 * ee7357（ev-20261012）：未自证告警按成因给对应只读核验建议。默认 v2 面建议 task_query
 * （自 v2.2 单轨起在所有会话恒注册，缺省建议恒可执行）；legacy query_task 仅在
 * AMAGI_SURFACE_LEGACY=1 逃生舱（可自证该面已注册）时提示——双轨留档会话是会话层状态，引擎不可见，
 * 不臆测。边界：不放宽 hasDoneMarker、不把标题拼错当自证、不自动续跑、不改三轴语义。
 */
export function unverifiedCompletionWarning(diag: CompletionContractDiagnosis): string {
	const query = process.env.AMAGI_SURFACE_LEGACY === "1" ? "task_query（legacy 双轨面亦可用 query_task）" : "task_query";
	switch (diag.cause) {
		case "tail-marker-position":
			return `[完成契约缺失] AMAGI:DONE 标记存在但未独占末行（协议要求最后一个非空行整行精确匹配；代码块/引用块/缩进/行内复述均无效）——完成度未自证。建议核验：${query}（view=output）查终稿尾部行，确认是否收尾中断或复述失格，勿据文字宣告验收`;
		case "heading-missing":
			return `[完成契约缺失] 末行 AMAGI:DONE 合规，但全文无独立 ACHIEVEMENT 标题（验收→证据→状态清单载体缺失）——完成度未自证。建议核验：${query} 查终稿结构，并跑构建/测试确认真实产出`;
		case "heading-typo":
			return `[完成契约缺失] 末行 AMAGI:DONE 合规，但标准标题疑似拼错（检测到「${diag.headingLike ?? "近形标题行"}」——须为独立 ACHIEVEMENT 标题行，拼错不计为自证）——完成度未自证。建议核验：${query} 查终稿标题行与清单内容`;
		case "list-empty":
			return `[完成契约缺失] 末行 AMAGI:DONE 与 ACHIEVEMENT 标题合规，但标题后无有效清单内容（须至少一个非空列表项或含数据行的表格；空心复述/仅表头空表不算）——完成度未自证。建议核验：${query} 查终稿清单段，逐项核对产出证据`;
		case "tail-marker-missing":
		default:
			return `[完成契约缺失] 子 Agent 未输出 AMAGI:DONE 尾标记（全文未见独立 marker 行）——完成度未自证。建议核验：跑构建/测试或 ${query} 查轨迹，勿直接采信`;
	}
}

/**
 * ev-20261021-e476e9：交付前定向格式补正指令——与 unverifiedCompletionWarning 同一诊断源
 * （diagnoseCompletionContract），按成因点名具体缺陷与合规形态。只校结构：明令不编造证据、
 * 不重跑大型测试/构建、不改动已完成工作；非空清单要求与 hasDoneMarker 判定不放宽。
 * tail-marker-missing 不在此列（那是早停/未完成，由通用自动续跑处理，不能当格式问题收窄）。
 */
export function completionContractRepairNudge(diag: CompletionContractDiagnosis): string | null {
	let defect: string;
	switch (diag.cause) {
		case "heading-typo":
			defect = `标题拼错：检测到「${diag.headingLike ?? "近形标题行"}」，须改为独立一行 \`ACHIEVEMENT:\`（可加粗，拼写精确）`;
			break;
		case "heading-missing":
			defect = "全文缺少独立的 `ACHIEVEMENT:` 标题行（清单载体缺失）";
			break;
		case "list-empty":
			defect = "`ACHIEVEMENT:` 标题后没有有效清单（须至少一个非空列表项 `- …`/`1. …`，或含数据行的表格；仅表头/空心复述不算）";
			break;
		case "tail-marker-position":
			defect = `\`${AMAGI_DONE_MARKER}\` 未独占最后一个非空行（代码块/引用/缩进/行内复述均无效）`;
			break;
		default:
			return null;
	}
	return `[amagi 完成契约格式补正] 你的终稿未通过完成契约结构校验：${defect}。这是一次只针对结构的补正：请直接重新输出终稿——独立 \`ACHIEVEMENT:\` 标题行，其后逐项列出「验收标准 → 证据 → 状态」（证据只引用你本次已实际执行/产出的内容；未验证项如实标注未验证），最后一个非空行独占 \`${AMAGI_DONE_MARKER}\`。不要编造证据，不要为补格式重跑大型测试/构建，不要修改已完成的工作。`;
}

/** be7271（ev-20261020）：在任务声明产物中定位合规 ACHIEVEMENT 标题段——终稿缺标题而声明报告
 *  已含合规段时，告警指出路径:行（仍不计为自证：自证只在终稿文本内成立）。有界：≤16 个文件、
 *  每个只读头部 256KiB；路径相对 cwd 解析，展示相对化。无命中/不可读 → null。 */
const ACHIEVEMENT_LOCATE_MAX_FILES = 16;
const ACHIEVEMENT_LOCATE_MAX_BYTES = 256 * 1024;

export function locateAchievementHeadingInOutputs(cwd: string, paths: readonly string[] | undefined): string | null {
	if (!paths || paths.length === 0) return null;
	for (const p of paths.slice(0, ACHIEVEMENT_LOCATE_MAX_FILES)) {
		if (typeof p !== "string" || p.trim() === "") continue;
		const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
		let st: fs.Stats;
		try { st = fs.statSync(abs); } catch { continue; /* lint-exempt:单个声明路径不可访问跳过（定位器零噪音） */ }
		if (!st.isFile() || st.size === 0) continue;
		let content: string;
		try {
			const fd = fs.openSync(abs, "r");
			try {
				const buf = Buffer.alloc(Math.min(st.size, ACHIEVEMENT_LOCATE_MAX_BYTES));
				fs.readSync(fd, buf, 0, buf.length, 0);
				content = buf.toString("utf8");
			} finally { fs.closeSync(fd); }
		} catch { continue; /* lint-exempt:单文件读取失败跳过（有界定位，不阻断告警链） */ }
		const lines = content.split("\n");
		for (let i = 0; i < lines.length; i++) {
			if (ACHIEVEMENT_TITLE_RE.test(lines[i])) {
				const rel = path.relative(cwd, abs);
				const shown = rel && !rel.startsWith("..") && !path.isAbsolute(rel) ? rel : abs;
				return `${shown}:${i + 1}`;
			}
		}
	}
	return null;
}

/**
 * v1.5.188 E1/E3：回流完成契约标注（advisory，不改 status、不进 stats 新维度）。
 *   E1：编码角色（work/expert 型）status=done 且原始终稿未通过 hasDoneMarker（末行精确 ===
 *       AMAGI_DONE_MARKER + 前文含 ACHIEVEMENT）→ 警告「完成度未自证，建议核验」。
 *       P1-3③：判定来源由 DEFAULT_CODE_AGENTS 名单改为 agent.type（名名单漏 cangjie=work、diting/fuxi/puti=
 *       expert；与「work/expert 型才标注」计划对齐）。注：证据（test/diff）仍用 evidence.ts 的
 *       DEFAULT_CODE_AGENTS 名单（仅真编码角色跑测试），E1 标注与证据是两套独立门控。
 *   E3：status=error 时，仅当**本轮终稿新引入**的 agent-outputs 引用（排除任务文本已有引用 + resume
 *       继承的旧 refs）且真实落盘 ≥1 个，才标注「产物已落盘，错误发生于收尾，可 resume 补收尾」。
 *       （P1-2 修复：旧实现用「引用并集」判定，输入 artifact / 继承 refs 已存在即误标成功产物。）
 * v1.5.188 P1-3②：标注调用收口到 runPiTask 的 finalize（唯一终态处理），结果带 completionAnnotation
 *       字段；sync/background/pipeline/硬路由/自动降档全部天然覆盖，execute 层不再重复接线。
 * @param text 待标注回流文本（警告追加到末尾）；收口模式下传 "" 仅取后缀
 * @param finalOutput 子 Agent 原始终稿（E1 marker 检测 + E3 本轮新引用提取基准——fold 后可能丢失末尾，故用原始 output）
 * @param agent 角色（用 .type 判 E1 标注范围：work/expert）
 * @param baselineArtifactRefs E3 基线引用：派发前已知的「任务文本引用 ∪ resume 继承的父 record refs」。
 *        这些是输入/继承而非本轮新产物，必须排除（调用方在 persistArtifact 前计算；不含 persistArtifact 自身目录）。
 * @param cwd 任务工作目录（相对 artifact 路径解析基准）
 * @param errorMessage 失败根因（标注文案引用）
 * @param dispatchTime 派发时刻（Date.now()，派发前记录的 stat 基线）：E3 mtime 门槛——只认
 *        mtime > dispatchTime 的非空文件为本轮产物，旧 artifact 即便路径别名绕过基线也不误标。
 * @param declaredOutputs be7271（ev-20261020）：任务声明的产物路径（reportPath/交付物/冻结 spec
 *        outputs 投影）。终稿缺 ACHIEVEMENT 标题而声明产物中某文件含合规标题段时，告警指出
 *        路径:行（仍不计为自证——自证只在终稿文本内成立）。
 */
export function annotateCompletion(
	text: string,
	finalOutput: string,
	agent: AgentConfig,
	status: TaskStatus,
	baselineArtifactRefs: string[] | undefined,
	cwd: string,
	errorMessage?: string,
	dispatchTime?: number,
	declaredOutputs?: readonly string[],
): string {
	let out = text;
	// E1：完成契约缺失警告（仅 work/expert 型 + done 态）——ee7357（ev-20261012）：按成因
	// 精确区分（尾标记缺失/位置错误、标题缺失/拼错、清单无有效内容），各给对应只读核验建议；
	// 判定源仍单点 hasDoneMarker（selfVerified/自动续跑豁免不受诊断细化影响）。
	if (status === "done" && (agent.type === "work" || agent.type === "expert") && !hasDoneMarker(finalOutput)) {
		const diag = diagnoseCompletionContract(finalOutput);
		out += `\n\n${unverifiedCompletionWarning(diag)}`;
		// be7271：标题缺失/拼错且声明产物中已有合规段 → 指出位置，减少 Leader 翻找；不以此计自证。
		if ((diag.cause === "heading-missing" || diag.cause === "heading-typo")) {
			const located = locateAchievementHeadingInOutputs(cwd, declaredOutputs);
			if (located) {
				out += `\n[标题段定位] 声明产物 ${located} 已含合规 ACHIEVEMENT 标题段——终稿仍须自带标题与清单（不以此计自证）；可 task({ session }) resume 补终稿结构，或直接采信报告后核验`;
			}
		}
	}
	// E3：仅本轮终稿「新引入」的引用（排除任务文本已有 + 继承旧 refs 及其后代），且真实落盘、
	// 且为本轮（派发后）新增/更新的非空文件，才视为本轮产物。
	// R2 修复（路径规范化）：baseline 与 final refs 统一 resolve 为规范绝对路径后，排除「相同路径或
	// baseline 目录后代」——`./` 前缀等价写法、继承目录后代（…/old/result.md ∈ …/old/）均命中排除。
	// 叠加 mtime 门槛（派发前记录 dispatchTime 基线）：只认 mtime > dispatchTime 的非空文件，
	// 旧 artifact 即便路径别名绕过基线也不误标本轮产物（P1-2 核心可信度）。
	if (status === "error") {
		const finalRefs = extractArtifactRefs(finalOutput) || [];
		const baselineAbs = (baselineArtifactRefs || []).map((r) => resolveArtifactAbs(cwd, r)).filter((p): p is string => !!p);
		const isBaselineCovered = (refAbs: string): boolean =>
			baselineAbs.some((b) => { const rel = path.relative(b, refAbs); return rel === "" || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel)); });
		const produced: string[] = [];
		for (const ref of finalRefs) {
			const refAbs = resolveArtifactAbs(cwd, ref);
			if (!refAbs) continue;
			if (isBaselineCovered(refAbs)) continue; // 输入/继承 ref 或其目录后代：非本轮新产物
			try {
				if (!fs.existsSync(refAbs)) continue;
				// R3（Major-1）：目录引用必须含至少一个「本轮新增/更新的非空普通文件」，
				// 不能以目录 inode size 充当内容证据（空目录在 macOS 上 size=64 会误标）；
				// 普通文件要求 isFile && size>0。目录扫描有界（深度 3 / 200 项防爆）。
				if (!hasProducedContent(refAbs, dispatchTime, 0)) continue;
				produced.push(ref);
			} catch { /* 路径解析/统计失败：不计为本轮产物 */ }
		}
		if (produced.length > 0) {
			out += `\n\n[产物已落盘] 本轮终稿新引用 ${produced.length} 个 artifact 已落盘（错误发生于收尾阶段：${errorMessage || "未知错误"}）——产物可能完整可用，核验后可 task({session}) resume 补收尾`;
		}
	}
	return out;
}

/**
 * R3（Major-1）：判定引用路径是否含「本轮产物内容」。
 * - 普通文件：isFile && size>0（dispatchTime 提供时要求 mtime > dispatchTime）；
 * - 目录：有界递归（深度≤3、条目≤200），存在至少一个满足上述条件的后代文件即为真；
 *   空目录/仅含旧文件的目录不算产物。
 */
function hasProducedContent(p: string, dispatchTime: number | undefined, depth: number): boolean {
	const st = fs.statSync(p);
	if (st.isFile()) {
		if (st.size === 0) return false;
		if (dispatchTime !== undefined && st.mtimeMs <= dispatchTime) return false;
		return true;
	}
	if (!st.isDirectory() || depth >= 3) return false;
	let entries: fs.Dirent[];
	try { entries = fs.readdirSync(p, { withFileTypes: true }).slice(0, 200); } catch { return false; }
	for (const e of entries) {
		try {
			if (hasProducedContent(path.join(p, e.name), dispatchTime, depth + 1)) return true;
		} catch { /* 单项失败跳过 */ }
	}
	return false;
}


/** model spec → provider 键（无 provider 前缀 = "default"）。 */
export function providerOfSpec(spec?: string): string {
	const i = spec?.indexOf("/") ?? -1;
	return i > 0 ? spec!.slice(0, i) : "default";
}



// ── RunResult ────────────────────────────────────────────────────────────────
// ════════════════════════════════════════════════════════════════════════════

// 统一 runPiTask 管线（sync/background/resume/bg-resume 共享一条路径）
// ════════════════════════════════════════════════════════════════════════════

export interface RunResult {
	runtimeObservation?: RuntimeObservation;
	taskId: string; output: string; exitCode: number; stderr: string;
	blocked: boolean; sessionId?: string; model?: string;
	/** diting Major-4：blocked 结构化原因（"questions"=QUESTIONS 待答；"needs-handoff"=settle
	 *  产出窗口收口，resume 接手开工）。仅 status=blocked 时携带。 */
	blockReason?: "questions" | "needs-handoff";
	/** ev-20260909-ec769a（P2）：完成契约自证结构化标记。仅对适用完成契约的角色（编码类 work/expert，
	 *  fast 角色不校验）且 status==="done" 时赋值：hasDoneMarker→true，否则 false。 */
	selfVerified?: boolean;
	/** ev-20260914：角色类型（fast/work/expert）——finalizer 折叠 marker 豁免仅对契约适用
	 *  角色（编码类 work/expert）生效；fast 型带 marker 的终稿照常折叠（不校验却豁免是逻辑错位）。 */
	agentType?: string;
	/** 实际 close 原码；exitCode 是后端结果码，host-aborted + 原码 0 时为 1。未 spawn 不填。 */
	processExitCode?: number | null;
	isError: boolean; status: TaskStatus; timedOut: boolean; aborted: boolean;
	sessionName: string; stopReason?: string; errorMessage?: string; spawnError?: string;
	/** ev-20260822-872c59：准入前拒绝标记（resume 链）——未 spawn、未建新记录、无新 artifact，
	 *  taskId 仅为定位用途（常为 prev.taskId）。消费者必须直接透出 errorMessage 根因，
	 *  禁入统一收尾链：旧 taskId 的 finalizer 幂等缓存会回放上一轮终稿，把失败根因顶掉。 */
	rejected?: true;
	/** registry.create 后捕获的修订号；统一收尾用它识别取消后的迟到回流。 */
	dispatchRevision?: number;
	/** v1.5.184 耗时拆分：模型生成累计 ms（thinking 主导时用于定位"时间花在思考"）。 */
	thinkMs?: number;
	/** v1.5.184 耗时拆分：工具执行累计 ms。 */
	toolMs?: number;
	/** v1.5.187 耗时拆分：冷启动延迟 ms（spawn→首个 stdout 事件）。 */
	startupMs?: number;
	/** v1.5.176: 派发前归一裸模型名时携带的说明（调用方决定透出位置）。 */
	modelNote?: string;
	/** v1.5.188 P1-3②：E1/E3 完成契约标注后缀（finalize 唯一收口计算；消费者追加到回流末尾，fold 后可见）。 */
	completionAnnotation?: string;
	/** v1.5.188 P1-4⑤：派发前熔断查询命中警告（runTask 内计算；消费者 prepend 到回流/通知）。 */
	fuseWarning?: string;
	/** v1.5.188 自动续跑：deferStats 时由 runTask 聚合后统一落盘的中间载体（内部字段，消费者勿用）。
	 *  B0-1（附录 B.1）：升级为累计口径（v2 新字段随 payload 携带；task-tool 多轮聚合消费）。 */
	_statsPayload?: CumulativeStatsEntry;
	_tracePayload?: TraceEntry;
	/** B0-1（附录 B.1）：本次真实子运行的稳定标识（spawn 时刻生成；trace/stats/观测行同源）。 */
	runKey?: string;
	/** 本轮任务因完成契约缺失续跑的轮数。 */
	autoContinued?: number;
	/** 确定性基线失败后，harness 自动交回同会话修复的轮数。 */
	autoRepaired?: number;
	/** 自动验证及 diff 的最终证据；finalizer 直接复用，避免重复执行。 */
	evidenceText?: string;
	/** 同一自动验证报告的展示投影，随同步结果交接；不是新的检查事实。 */
	evidenceReport?: import("./evidence.ts").EvidenceReport;
	/** ev-20260924-0cf0e7：sync auto-verifier 交接的结构化检查事实（runBaselineVerification →
	 *  runStructuredCheck 产物，绑验证对象 + copy-local 依赖冻结）；finalizer 直接收编为唯一执行事实。 */
	structuredChecks?: StructuredCheckOutcome[];
	/** harness 自动验证累计耗时。 */
	verificationMs?: number;
	/** v1.5.248：provider 态重试次数（ctx.retryAttempts 回流；此前仅进 stats 未入 RunResult 声明）。 */
	retryAttempts?: number;
	/** v1.5.248：provider 态重试累计等待 ms（同上，仅进 stats；声明补齐）。 */
	retryWaitMs?: number;
	/** 8月迭代 F3：spawn 前工作区 git 快照（归因基线；finalizer 透传给 evidence，非 git 仓库 null）。 */
	gitBaseline?: string[] | null;
	/** 8月迭代 F6c：终止者归因（settle-fallback/doom-loop/timeout/abort；续跑决策与死因可见性）。 */
	terminatedBy?: string;
	/** 8月迭代 C3：自动续跑逐轮摘要（一行/轮：状态+末事件摘录+契约有无），进回流与通知，免 query_task 翻 JSONL。 */
	autoRoundSummary?: string;
	/** ev-20260910-8fbe4e（C）：连接类中断现场报告——仅 status=error 且 providerError 时携带
	 *  （finalize 唯一收口计算；三要素：已写文件清单+差集归因/最后活动与距终态/续点建议）。
	 *  消费面：sync 返回体、bg 完成通知、迟终态回推（terminal-push 按登记+registry 重建）。 */
	interruptionReport?: string;
	/** Bounded child tool receipts; used only to avoid rerunning a final matching baseline. */
	_toolExecutions?: ReadonlyArray<ToolExecutionObservation>;
}

export interface BackgroundStart { taskId: string; agent: string; status: "running" | "queued"; sessionName: string; modelNote?: string; /** P1-4⑤：派发前熔断警告（立即返回时携带，供 execute prepend）。 */ fuseWarning?: string }

export interface BackgroundOpts {
	contextMode?: ContextMode;
	cwd: string;
	model?: string;
	fallbackModel?: string;
	/** v1.5.176: 派发前模型归一/校验（编排/resume/直接调用路径全覆盖）。 */
	modelRegistry?: ModelRegistryLike;
	timeoutMs?: number;
	command?: { command: string; args: string[] };
	/** 8月迭代 F5：任务硬边界保护路径。 */
	protectedPaths?: string[];
	/** 8月迭代 C3：任务白名单路径（写入目标不在清单内即子进程阻断）。 */
	allowedPaths?: string[];
	onComplete?: PiTaskOpts["onFinalize"];
	onFinalize?: PiTaskOpts["onFinalize"];
	/** v1.5.181: 任务短名（面板/看板/通知显示；缺省用任务文本）。 */
	description?: string;
	/** ed-20260910 diting m-1：journal 派发留档用的原始任务书（缺省 = task）——worktree 派发的
	 *  task 前置注入 [全仓检出] 标注会吃满 journal 500 字留档预算，标注只进子进程任务书与回流文案。 */
	journalGoal?: string;
	/** v1.5.248: 稳定节点名（journalDispatch 既有字段；batch/编排 background 化时携带，普通 background 缺省 undefined）。 */
	name?: string;
	/** T2-10 fork 模式跳过 lease（允许从同一 session 并发分叉多枝）。 */
	skipLease?: boolean;
	/** Project trust gates source preflight and execution of project-owned verification scripts. */
	trusted?: boolean;
	/** T2-7a 停滞看门狗（background 路径也接，A6）。 */
	onStall?: (info: { taskId: string; agent: string; idleMs: number }) => void;
	/** v2 批次A 运行图：编排 group 关联字段（registry.create 透传，trace 随之携带）。 */
	relation?: TaskRelationMeta;
	/** P4 §7-1 接缝（M3 生产激活）：四方交集冻结授权（task_submit 分面计算后透传；legacy 缺省 v1 占位）。 */
	permission?: Readonly<PermissionGrant>;
	worktreeDispatch?: Readonly<WorktreeDispatchFacts>;
	/** ev-20260920-61839b：声明产物契约（task_submit outputs[]）——冻结进 spec.outputs + 结算面产物完整性
	 *  （background 无 B1 预检执法面，声明契约靠注入段 + 结算闭环；与 sync 路径共享字段语义）。 */
	outputs?: ReadonlyArray<{ path: string; kind: "file" | "tree"; required: boolean; purpose?: string }>;
	/** ev-20260916-101d8a：复用链尽冷却占位记录（queued/cooldown）作为本次派发记录——派发链内
	 *  不再 registry.create/journalDispatch（记录与留痕已在冷却开始时建档）。 */
	preCreatedTaskId?: string;
}

// ── K4（amagi-pi v2，方案 §3.1/§3.3/§8.1-K4）：执行端口观察回流（json-execution-adapter 消费）──
// 观察模式由调用方显式开启（PiTaskOpts.observation）：状态迁移的唯一写者是内核（sink 侧真实内核命令），
// registry 记录仅保留无内核命令等价物的终稿字段投影（桥受控写入，K5/K8 拆除清单见 K4-report）。
// 缺省不提供 → legacy 直写语义零变化（task-tool/task-background/task-resume 等 K5 前调用方不受影响）。
// ev-20261019-06c169：RunObservationTarget 类型上移 execution-port（task-service 默认 sink 工厂共构消费）；
// 未注册契约任务的纯 legacy 环境引擎自动回退原业务路径（见 runPiTask 默认 sink 接管判据）。

/** 引擎侧观察中继：observationSeq 单后端内严格递增；exited 恰好发射一次（重复 close/迟到 exit 幂等去重——
 *  内核低序号保护（§3.3 observe）之外的第二道闸）。
 *  ev-20261019-06c169：①exited 统一携带 executionPolicy=preserve（JSON 引擎的物理退出不推导业务终态，
 *  exitCode 用 Node 原始值含信号 null）；②发射按到达序同步调用 sink、结果串入同一 promise 链
 *  （调用方可 await 观察提交链——close 正常路径先记物理观察再写业务终态）；③sink 返回 {ok:false}/
 *  抛错留下 bounded 诊断（观察提交失败可见，不伪装已落盘）。 */
export interface RunObservationRelay {
	readonly backendRunId: string;
	/** 非终结事件发射（回流失败不反噬引擎主流程；失败记入 bounded 诊断）。 */
	emit(event: ExecutionEvent): void;
	/** 退出观察恰好一次（preserve + 原始退出码）；返回是否本次首发（false = 重复 close/迟到回流，已被去重）。 */
	emitExitedOnce(exitCode: number | null): Promise<boolean>;
	/** bounded 观察提交失败诊断（≤8 条；成功路径为空）。 */
	observeFailures(): readonly string[];
}

export function createObservationRelay(target: RunObservationTarget): RunObservationRelay {
	let seq = -1;
	let exitedEmitted = false;
	let chain: Promise<unknown> = Promise.resolve();
	const failures: string[] = [];
	const noteFailure = (s: string) => {
		failures.push(s);
		if (failures.length > 8) failures.shift();
	};
	const fire = (event: ExecutionEvent): Promise<unknown> => {
		// 观察对象与序号在事件到达时刻定格（不能用 drain 完成时刻代替事件时序）；
		// sink 同步调用（内核观察命令的同步提交段即线性化点，事件序＝内核序），
		// 返回结果串入同一 promise 链供 emitExitedOnce 等待完整提交。
		const observation: ExecutionObservation = { key: target.key, backendRunId: target.backendRunId, observationSeq: ++seq, event };
		let r: unknown;
		try {
			r = target.emit(observation);
		} catch (e) {
			noteFailure(`observe-emit-threw:${String(e instanceof Error ? e.message : e).slice(0, 120)}`);
			return chain;
		}
		const settled = Promise.resolve(r).then(
			(v) => {
				if (v && typeof v === "object" && (v as { ok?: unknown }).ok === false) {
					const er = (v as { error?: { code?: string; message?: string } }).error;
					noteFailure(`observe-apply-failed:${er?.code ?? "unknown"}:${String(er?.message ?? "").slice(0, 120)}`);
				}
			},
			(e) => { noteFailure(`observe-emit-rejected:${String(e instanceof Error ? e.message : e).slice(0, 120)}`); },
		);
		chain = chain.then(() => settled, () => settled);
		return chain;
	};
	return {
		backendRunId: target.backendRunId,
		emit: (event) => { fire(event); },
		observeFailures: () => [...failures],
		async emitExitedOnce(exitCode) {
			if (exitedEmitted) return false;
			exitedEmitted = true;
			await fire({ kind: "exited", exitCode, at: Date.now(), executionPolicy: "preserve" });
			return true;
		},
	};
}

export interface PiTaskOpts {
	cwd: string; model?: string; signal?: AbortSignal; timeoutMs?: number;
	command?: { command: string; args: string[] };
	/** background 模式：立即返回，close 时回调 */
	background?: boolean;
	/** v1.5.188 P1-3②：E1/E3 标注基线（派发前已知的 artifact 引用：任务文本引用 ∪ resume 继承父 refs）。 */
	baselineArtifactRefs?: string[];
	/** v1.5.188 P1-4⑤：派发前熔断查询命中的警告文本（runTask 内计算，透传到 finalize→RunResult）。 */
	fuseWarn?: string;
	/** R2：派发时刻（Date.now()）——E3 mtime 基线，只认本轮新增/更新的非空文件为本轮产物。 */
	dispatchTime?: number;
	/** R2（P1-4 分类一致性）：派发入口统一计算的 taskCategory（description || task 源），trace/fuse 共用，消除源不一致。 */
	taskCategory?: string;
	/** 8月迭代 F5：任务硬边界保护路径（绝对或相对 cwd 解析为绝对后注入子进程 AMAGI_PROTECTED_PATHS）。 */
	protectedPaths?: string[];
	/** 8月迭代 C3：任务白名单路径（注入子进程 AMAGI_ALLOWED_PATHS；写入目标不在清单内即阻断）。 */
	allowedPaths?: string[];
	/** ev-20260909-1face0：孙进程审计依赖注入（仅测试 mock 使用，生产缺省） */
	processAuditDeps?: ProcessAuditDeps;
	/** Test seam for deterministic event-duration accounting; production uses Date.now(). */
	eventClockForTest?: (event: { type?: string }) => number;
	/** be7271（ev-20261020）：任务声明产物路径（reportPath/交付物标记/冻结 spec outputs 的投影）——
	 *  终稿缺 ACHIEVEMENT 标题时告警定位声明报告中的合规段（不以此计自证）。 */
	declaredOutputPaths?: readonly string[];
	/** v1.5.188 自动续跑：true 时 finalize 不写 stats/trace，payload 挂到 RunResult 由调用方聚合落盘。 */
	deferStats?: boolean;
	/** B0-1（附录 B.1）：本次实际注入预检快照的 UTF-8 字节数（未注入=0；随 stats/trace 落盘供裁剪决策）。 */
	preflightBytes?: number;
	/** registry.create 后捕获的 stale 基线；取消会 bump registry.revision，但不得改写本值。 */
	dispatchRevision?: number;
	/** 终态回调（回流/snapshot/stats 统一入口） */
	onFinalize?: (r: { runtimeObservation?: RuntimeObservation; taskId: string; agent: string; /** ev-20260914：角色类型（finalizer 折叠 marker 豁免用）。 */ agentType?: string; status: TaskStatus; output: string; blocked: boolean; blockReason?: "questions" | "needs-handoff"; errorMessage?: string; sessionId?: string; model?: string; completionAnnotation?: string; dispatchRevision?: number; selfVerified?: boolean; /** ev-20260910-8fbe4e（C）：连接类中断现场报告（仅 error+providerError 终态携带）。 */ interruptionReport?: string; /** F5（diting，附录 B.1）：本轮运行标识与工具观测——finalizer 观测链消费，不得在重建 payload 时丢弃。 */ runKey?: string; _toolExecutions?: ReadonlyArray<ToolExecutionObservation>; /** pi 1.1.0 S2-B2：宿主/控制面中止事实（agent_settled.aborted=true 或 abort 信号）——自动修复消费者据此抑制重派。 */ aborted?: boolean; /** ev-20261021-e476e9：引擎终止裁决（与返回值 terminatedBy 同源）——后台格式补正据此抑制。 */ terminatedBy?: string }) => void;
	/** child_process 的真实 spawn 事件；仅在 OS 已成功创建子进程后触发。 */
	onSpawn?: () => void;
	/** T2-7a 停滞看门狗：stdout 静默超 STALL_THRESHOLD_MS 触发（不杀，仅提醒主会话）。
	 * P2（8月迭代第三轮）kind 分流：exec=执行中静默（工具在飞，仅 3× 阈值硬上限提示）；
	 * no-call=无调用静默（零工具调用，建议精简重派）；normal=常规停滞。 */
	onStall?: (info: { taskId: string; agent: string; idleMs: number; kind?: "exec" | "no-call" }) => void;
	/** v1.5.181 运行中进度回流（pi 官方 subagent 示例 onUpdate 模式）：节流 emit 当前状态行+终稿尾部，
	 *  TUI 实时可见 sync 子 Agent 进度（此前 sync 任务全程黑盒，结束才见结果）。 */
	onUpdate?: (partial: { content: Array<{ type: "text"; text: string }> }) => void;
	/** K4（v2）：执行端口观察回流——提供即进入观察模式（状态写权移交内核 sink；registry 仅保留终稿字段投影）。
	 *  json-execution-adapter 注入；K5 前的生产调用方均不提供（legacy 直写语义零变化）。 */
	observation?: RunObservationTarget;
}

export function makeErrorResult(taskId: string, agent: AgentConfig, output: string, stderr: string, sessionName: string, errorMessage?: string): RunResult {
	return { taskId, output, exitCode: 1, stderr, blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, errorMessage, completionAnnotation: "", dispatchRevision: -1 };
}

/** 取消不抹除 SIGTERM 前的真实输出；原因作为尾注展示。 */
export function appendCancellationReason(output: string | undefined, errorMessage: string | undefined): string {
	const note = `[已取消] ${errorMessage || "任务被取消"}`;
	return output ? `${output}\n\n${note}` : note;
}

/** v2 批次A：从 registry 记录提取运行图字段（trace 透传；缺省字段 JSON 序列化时自然省略）。 */
function traceRelationOf(rec: Readonly<TaskRecord> | undefined): Partial<TraceEntry> {
	if (!rec) return {};
	return {
		runId: rec.runId, parentTaskId: rec.parentTaskId, nodeId: rec.nodeId, dependsOn: rec.dependsOn,
		backend: rec.backend, revision: rec.revision, queuedAt: rec.queuedAt, queueMs: rec.queueMs,
	};
}

/** create 后、child 可用前的统一终结路径：状态/统计/回调都恰好一次。
 *  ev-20261019-06c169：启动失败保留 error 业务状态（registry patch → 桥受控迁移进内核），但不再
 *  emitExitedOnce(1)——未 spawn 的进程不伪装成物理退出（不变量：processState=exited 只由真实
 *  exit/close 观察或具名人工确认产生）；观察回流仅用于句柄回投等诊断，不合成 started/exited。 */
export function finalizeLaunchFailure(
	taskId: string,
	agent: AgentConfig,
	sessionName: string,
	error: unknown,
	onFinalize?: PiTaskOpts["onFinalize"],
	_observation?: RunObservationTarget,
): RunResult {
	const dispatchRevision = registry.get(taskId)?.revision ?? 0;
	const errorMessage = `启动失败: ${String(error)}`;
	try { registry.patch(taskId, { status: "error", errorMessage }); } catch {}
	const rec = registry.get(taskId);
	// B0-1（附录 B.1）：启动失败也有运行身份（未 spawn 的尝试仍是独立一次运行；零用量如实缺席，不补 0）。
	const runKey = nextRunKey(taskId);
	const _leaderSession = getLeaderSessionStamp();
	writeStats({ taskId, agent: agent.name, model: rec?.model, status: "error", durationMs: (rec?.endedAt || 0) - (rec?.startedAt || 0), usageScope: "cumulative", assistantCalls: 0, runKey, ...(_leaderSession !== undefined ? { leaderSession: _leaderSession } : {}), preflightBytes: 0, usageCoverage: "abnormal-exit" });
	// T2-8: 启动失败也采 trace（status=error, toolCalls=0）
	const _failRounds = rec?.rounds?.length || 0;
	const _failEntry: TraceEntry = {
		formatVersion: 3, taskId, agent: agent.name,
		mode: _failRounds > 0 ? (rec?.mode === "background" ? "bg-resume" : "resume") : (rec?.mode || "sync"),
		status: "error", durationMs: (rec?.endedAt || 0) - (rec?.startedAt || 0),
		// P2-A：错误分类枚举（只落分类，绝不落 errorMessage 明文）
		errorKind: classifyErrorKind(errorMessage),
		usageScope: "cumulative", assistantCalls: 0, runKey, ...(_leaderSession !== undefined ? { leaderSession: _leaderSession } : {}), preflightBytes: 0, usageCoverage: "abnormal-exit",
		toolCalls: 0, blocked: false, resumeRounds: _failRounds, model: rec?.model,
		// v1.5.188 P1-4④：启动失败 trace 补 taskCategory——否则重复故障累计到 unknown 路由键，
		// 派发查询按 goal 分类永不命中，熔断不可达。
		taskCategory: classifyTask(rec?.goal || ""), ...traceRelationOf(rec), at: Date.now(),
	};
	writeTrace(_failEntry);
	updateRoutingStats(_failEntry);
	recordLastSelfVerified(taskId, undefined);
	try { onFinalize?.({ taskId, agent: agent.name, status: "error", output: "", blocked: false, errorMessage, completionAnnotation: "", dispatchRevision, selfVerified: undefined }); } catch {}
	return { ...makeErrorResult(taskId, agent, "", errorMessage, sessionName, errorMessage), spawnError: errorMessage, fuseWarning: "", dispatchRevision, runKey };
}

/**
 * 统一 spawn 管线。一个 spawn 封装 + 一个 processLine parser + once-finalizer。
 * sync 模式 await 返回 RunResult；background 模式立即返回 BackgroundStart。
 */

/** A10: 启发式任务类别分类（供 trace 维度 + routing 记忆同类任务证据）。 */
export function classifyTask(text: string): string {
	if (/bug|修复|fix|错误|fail/i.test(text)) return "bug-fix";
	if (/测试|test|验证|探针/i.test(text)) return "test";
	if (/审核|review|检查|diting/i.test(text)) return "review";
	if (/重构|refactor|优化|清理/i.test(text)) return "refactor";
	if (/文档|doc|readme/i.test(text)) return "doc";
	return "feature";
}

/**
 * R2（P1-4 分类一致性）：派发入口统一分类源 = description || task——与 registry.goal（= description || task）
 * 同源，保证 trace（按 goal 分类）与 fuse 查询命中同一 routing 维度键，消除带 description 时
 * 「记录 bug-fix、查询 feature」的稳定漏警告。
 */
export function taskCategoryFor(description: string | undefined, task: string): string {
	return classifyTask(description || task);
}

// ── B0-1（附录 B.1）：runKey —— 一次真实子运行的稳定标识 ─────────────────────
// 复用现有运行身份派生：taskId + 本进程内该任务的自增 spawn 序号 + spawn 时刻（journal dispatch
// 行同源事实）。不只用 taskId——同一逻辑任务的 resume/自动修复/自动续跑各有各自增量；跨进程
// 重启后序号重置由时刻段消解碰撞。子进程经 AMAGI_RUN_KEY env 拿到同一标识（大发射观测关联用）。
const runKeyCounters = new Map<string, number>();

export function nextRunKey(taskId: string, now: number = Date.now()): string {
	const n = (runKeyCounters.get(taskId) ?? 0) + 1;
	if (runKeyCounters.size > 512) runKeyCounters.clear(); // 有界：极端多任务进程防膨胀（计数仅用于标识唯一性）
	runKeyCounters.set(taskId, n);
	return `${taskId}#r${n}@${now.toString(36)}`;
}

// ── ev-20260902-772c7f：白名单任务的验证产物临时目录（自动授权 + TTL 回收）──
// 根因：两次实战边界终止均发生在收尾验证阶段——子 Agent 想把 stub server/验证脚本写到
// 系统 /tmp 根或任务范围外路径，被 allowedPaths 硬边界一击终止、丢失当轮上下文。
// 对策：白名单任务派发时自动创建专属临时目录，追加进白名单并经 AMAGI_TASK_TMP_DIR 告知
//（guards 侧 session_start 前置提示 + 边界拦截 reason 引导），验证产物有安全落点。
const TASK_TMP_TTL_MS = 24 * 60 * 60 * 1000;

/** 验证产物目录根（系统 tmp 下 amagi-task/，只动自己的子目录，不碰其它临时文件）。 */
export function taskTmpRoot(tmpBase?: string): string {
	return path.join(tmpBase ?? os.tmpdir(), "amagi-task");
}

/** 创建本任务专属临时目录（幂等 mkdir）；顺带清扫超 TTL 的历史任务目录（best-effort，失败静默）。 */
export function prepareTaskTmpDir(runKey: string, opts: { ttlMs?: number; now?: () => number; root?: string } = {}): string {
	const root = opts.root ?? taskTmpRoot();
	sweepTaskTmp({ ttlMs: opts.ttlMs ?? TASK_TMP_TTL_MS, now: opts.now ?? Date.now, root });
	const safe = String(runKey).replace(/[^A-Za-z0-9_-]/g, "").slice(0, 48) || "task";
	const dir = path.join(root, safe);
	fs.mkdirSync(dir, { recursive: true });
	return dir;
}

/** ev-20260909-729b99（P3）：检测工作区 cwd 下是否存在历史 amagi-task 目录并返回绝对路径 */
export function detectTaskTmpNameclash(cwd: string): string | undefined {
	try {
		const p = path.join(cwd, "amagi-task");
		if (fs.existsSync(p)) return path.resolve(p);
	} catch {}
	return undefined;
}

// ── ev-20260909-ec769a：最近一次任务运行的自证结果记录（按 taskId 索引，供测试/调用方观测）──
const lastSelfVerifiedMap = new Map<string, boolean | undefined>();
let lastGlobalSelfVerified: boolean | undefined = undefined;

export function getLastSelfVerified(taskId?: string): boolean | undefined {
	if (taskId && lastSelfVerifiedMap.has(taskId)) return lastSelfVerifiedMap.get(taskId);
	return lastGlobalSelfVerified;
}

export function recordLastSelfVerified(taskId: string, val: boolean | undefined): void {
	lastSelfVerifiedMap.set(taskId, val);
	lastGlobalSelfVerified = val;
	if (lastSelfVerifiedMap.size > 256) {
		const oldest = lastSelfVerifiedMap.keys().next().value;
		if (oldest !== undefined) lastSelfVerifiedMap.delete(oldest);
	}
}

/** TTL 清扫：仅删除 root 下 mtime 早于 cutoff 的子项（递归）；返回删除数。 */
export function sweepTaskTmp(opts: { ttlMs: number; now: () => number; root: string }): number {
	let removed = 0;
	try {
		const cutoff = opts.now() - opts.ttlMs;
		for (const ent of fs.readdirSync(opts.root, { withFileTypes: true })) {
			const p = path.join(opts.root, ent.name);
			let st: fs.Stats;
			try { st = fs.statSync(p); } catch { continue; }
			if (st.mtimeMs < cutoff) {
				try { fs.rmSync(p, { recursive: true, force: true }); removed++; } catch {}
			}
		}
	} catch {}
	return removed;
}

/** E4（ev-8cbe23）：派发命中熔断路由 → 前置 advisory 警告（不阻断派发，可能是唯一可用模型）。空串=未熔断。
 *  R2：taskCategory 由调用方按 description || task 统一计算后传入（不再各自 classify 导致源不一致）。 */
export function fuseWarningFor(agentName: string, model: string | undefined, taskCategory: string): string {
	const { fused, streak } = fuseStatus(taskCategory, agentName, model);
	if (!fused) return "";
	return `[路由熔断] ${routingDimKey(taskCategory, agentName, model)} 近 ${streak} 次全部瞬时失败（疑规格/配置问题），本次仍继续派发；建议修复配置或换 model\n\n`;
}

// ── ev-20260916-5d0ef1（方案 §4.3）：POSIX 自有进程组取消 ─────────────────────
// darwin/linux 上 runPiTask 新 spawn 用 detached:true（子进程即组长，pgid===pid，spawn 时定格
// 不事后猜测）；stdio 继续 pipe、不 unref，父进程仍管理退出与输出。cancel/timeout/abort/doom/
// spawn-ready/settle 共用同一幂等组级终止入口：SIGTERM → 3s → 身份复核后 SIGKILL（组已空 ESRCH
// 静默；身份不能确认时不向可能复用的 pgid 发信号，交 ProcessAuditor 兜底报告）。Windows 保持现状
// （仅直接 child SIGTERM→SIGKILL）；AMAGI_TASK_PROCESS_GROUP=0 回旧行为（只影响新 run）。

/** 5d0ef1：进程组取消开关（仅 darwin/linux 生效；AMAGI_TASK_PROCESS_GROUP=0 关闭）。platform/env 可注入供测试。 */
export function taskProcessGroupEnabled(platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = process.env): boolean {
	if (platform !== "darwin" && platform !== "linux") return false;
	return !(env.AMAGI_TASK_PROCESS_GROUP === "0" || env.AMAGI_TASK_PROCESS_GROUP === "false");
}

/** 进程组成员快照（pid/ppid；ps 不可用/超时 → null，不猜测）。 */
export interface GroupMember { pid: number; ppid: number; identityToken?: string; }
function snapshotGroupMembers(pgid: number): GroupMember[] | null {
	try {
		const out = execFileSync("ps", ["axo", "pid,ppid,pgid"], { timeout: 3000, encoding: "utf8", maxBuffer: 4 * 1024 * 1024 });
		const members: GroupMember[] = [];
		for (const line of out.split("\n")) {
			const m = line.trim().match(/^(\d+)\s+(\d+)\s+(\d+)$/);
			if (!m) continue;
			if (Number(m[3]) === pgid) members.push({ pid: Number(m[1]), ppid: Number(m[2]) });
		}
		const identities = readKernelProcessIdentities(members.map(m => m.pid));
		return members.map(m => { const k = identities.get(m.pid); return { ...m, ...(k && k.ppid === m.ppid && k.pgid === pgid ? { identityToken: k.identityToken } : {}) }; });
	} catch {
		return null;
	}
}

/** Every current group member must connect to an unchanged owned incarnation; one PID match is insufficient. */
export function processGroupBelongsTo(current: readonly GroupMember[], known: ReadonlyMap<number, string>): boolean {
	if (!current.length || current.some(m => !m.identityToken)) return false;
	const owned = new Set(current.filter(m => known.get(m.pid) === m.identityToken).map(m => m.pid));
	for (let pass = 0; pass < current.length; pass++) {
		let changed = false;
		for (const m of current) if (!owned.has(m.pid) && owned.has(m.ppid)) { owned.add(m.pid); changed = true; }
		if (!changed) break;
	}
	return current.every(m => owned.has(m.pid));
}


export async function runPiTask(agent: AgentConfig, args: string[], opts: PiTaskOpts, taskId: string, sessionName: string): Promise<RunResult | BackgroundStart> {
	// 8月迭代 pi-0.84 配合 修复轮（Major-4）：auth 预检已上移至 sync/background 两个公共入口
	// （task-tool.ts runTask / task-background.ts runBackgroundTask，均在准入占位与建档之前——
	// fail-fast 失败不占并发槽、不留 error 记录）。引擎层不再预检：resume/自动续跑路径复用
	// 首派发时已验证过的会话模型，重复探测只添延迟。
	const model = opts.model;
	const rec0 = registry.get(taskId);
	// K4 观察回流中继 + ev-20261019-06c169 默认观察 sink：显式 target（适配器路径）优先；缺席时对
	// 已注册契约任务自动接管物理观察（真实 spawn/close 事实回流内核——覆盖 fresh/background/resume/
	// 自动修复/自动续跑全路径，调用方零改造）；既无已注册契约又无显式 target 的纯 legacy 环境保持原
	// 业务路径（不为观察自动建档）。
	const explicitObs = opts.observation;
	const obsTarget = explicitObs ?? createDefaultJsonObservation(taskId, `json-${crypto.randomUUID()}`);
	const obsRelay = obsTarget ? createObservationRelay(obsTarget) : undefined;
	if (!rec0) return finalizeLaunchFailure(taskId, agent, sessionName, "task record 不存在", opts.onFinalize, obsTarget);
	const dispatchRevision = opts.dispatchRevision ?? rec0.revision ?? 0;
	// v2 批次B 取消收口①：spawn 前复查——排队/在跑期间被取消的任务不再启动子进程。
	// 不写 stats/trace/routing（取消非能力信号）；onFinalize 以 cancelled 收口恰好一次，槽位由调用方在回调中释放。
	if (rec0.status === "cancelled") {
		const msg = "任务在启动前被取消";
		recordLastSelfVerified(taskId, undefined);
		// ev-20261019-06c169：未启动即取消——不合成 started/exited（未创建的进程没有退出事实）。
		try { opts.onFinalize?.({ taskId, agent: agent.name, status: "cancelled", output: "", blocked: false, errorMessage: msg, completionAnnotation: "", dispatchRevision, selfVerified: undefined }); } catch {}
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, errorMessage: msg, completionAnnotation: "", dispatchRevision, selfVerified: undefined };
	}

	// ── P4（amagi-pi v2，§8.3-P4）：子进程权限交付——冻结授权解析（legacy 占位=零执法，行为零变化）。
	// 授权只从冻结 spec 读（digest 自洽：注入原文即序列化产物）；缺项检查先于任何 spawn 副作用。 ──
	// §9.5 G20（技能 allowlist）：唯一 spawn 点尾部注入（sync/background/resume/修复续跑/#硬路由/v2 适配器
	// 全路径共经此处）；未配置 = 零注入，launchArgs 与现状逐字节一致。旗标落在正文之后是安全的——宿主
	// CLI 参数解析全程扫旗标（cli/args.js，非首个位置参数即停），--skill 已在 TOOL_ARG_VALUE_OPTIONS 扫描面内。
	const launchArgs = [...(opts.command ? opts.command.args || [] : []), ...args, ...agentSkillSpawnArgs(agent.name, opts.cwd)];
	let dispatchTools: string[] | undefined;
	try {
		validateDispatchToolNames(agent.tools);
		dispatchTools = dispatchToolsOfArgs(launchArgs);
	} catch (e) { return finalizeLaunchFailure(taskId, agent, sessionName, e, opts.onFinalize, obsTarget); }
	const permissionDelivery0 = await resolveSpawnPermissionDelivery(taskId, opts.cwd, dispatchTools);
	if (permissionDelivery0 !== undefined && "error" in permissionDelivery0) {
		return finalizeLaunchFailure(taskId, agent, sessionName, permissionDelivery0.error, opts.onFinalize, obsTarget);
	}
	// ev-20260919（LSP 降级执法）：lsp 是辅助能力（诊断/跳转）非任务必要条件——缺项剥除 grant.lsp 照常
	// spawn（子进程不注册 lsp 工具，子 Agent 用 read/grep 替代），不再整单 error 拒发（实战：battle-sim
	// 无 LSP 二进制导致 luban 派发全败，Leader 被迫修参重派）；降级事实随 completionAnnotation 透出。
	// mcp 缺项保持拒发（显式请求的工具名是硬依赖，剥除会让任务书依赖的工具静默消失）。
	let permissionDelivery = permissionDelivery0;
	let lspDegradedNote: string | null = null;
	if (permissionDelivery !== undefined) {
		const gaps = findDispatchRequirementGaps(opts.cwd, permissionDelivery.grant);
		if (gaps.length > 0) {
			const mcpGaps = gaps.filter((g) => g.channel === "mcp");
			const lspGaps = gaps.filter((g) => g.channel === "lsp");
			if (mcpGaps.length > 0) {
				return finalizeLaunchFailure(
					taskId, agent, sessionName,
					`[P4 派发预检] 任务声明的必要 MCP 工具存在缺项（不 spawn，交回 Leader 修配置后重派）：\n${mcpGaps.map((g) => `- ${g.reason}`).join("\n")}`,
					opts.onFinalize, obsTarget,
				);
			}
			if (lspGaps.length > 0) {
				const stripped = { ...permissionDelivery.grant, lsp: [] as typeof permissionDelivery.grant.lsp, tools: permissionDelivery.grant.tools.filter((t) => t !== "lsp") };
				const rawGrantJson = JSON.stringify(stripped);
				permissionDelivery = { grant: stripped, rawGrantJson, digest: permissionGrantDigest(rawGrantJson), tools: permissionDelivery.tools.filter((t) => t !== "lsp") };
				lspDegradedNote = `[LSP 降级] 项目未检测到可用语言服务器（${lspGaps[0].reason.replace(/^.*但/, "").trim()}）——已剥除本任务 LSP 能力照常派发；子 Agent 请用 read/grep 替代诊断与跳转，不影响任务目标（ev-20260919）。`;
			}
		}
	}
	const spawnArgs = permissionDelivery !== undefined ? enforceToolsArgument(launchArgs, permissionDelivery.tools)
		// legacy 保留 CodeMode 工具组合；Advisor 继续走原有授权链。
		: dispatchTools !== undefined ? enforceToolsArgument(launchArgs, [...new Set([...legacyDispatchToolsWithoutCodemode(dispatchTools), "toolcall_continue"])]) : launchArgs;
	// 续接历史受控 grant 时保留 journal 账户引用；新任务无独立 CodeMode 额度账户。
	if (permissionDelivery !== undefined && permissionDelivery.grant.codemode !== undefined) {
		try { journalCodemodeAccount({ taskId, grantDigestPrefix: permissionDelivery.digest.slice(0, 16), phase: argsIndicateSessionResume(launchArgs) ? "resume" : "dispatch" }); } catch { /* lint-exempt:journal 可观测性，失败不阻断派发 */ }
	}
	// 8月迭代 F3：spawn 前工作区快照（证据归因基线；非 git 仓库为 null）。
	// v1.5.233 修复（ev-20260819-06c47f）：快照原在 spawn 之后执行——负载下父进程被调度出去，
	// 子进程抢先写盘，基线吞掉子进程写入 → 产物摘要差集归零（1/2 全量套件偶发）。
	// 必须严格在 spawn 前采集，与调度序无关。
	const gitBaseline = takeGitStatusSnapshot(opts.cwd);
	// ev-20261019-a7519f：任务启动状态快照（path→mtime+size+小文件 sha1，有界）——existing 共享树
	// 产物摘要的净变化基准：派发前已有未提交改动时，行级差集对「预脏路径被任务再修改」不敏感、
	// diff --stat 恒为 vs HEAD 绝对口径。与 gitBaseline 同点采集（严格 spawn 前）；sidecar 首写优先
	//（resume/修复轮保留最早基准，净变化覆盖整链）；非 git 仓库/采集失败静默（缺快照回退差集口径）。
	try {
		const startState = takeWorkspaceStateSnapshot(opts.cwd, gitBaseline);
		if (startState) recordTaskStartState(taskId, startState);
	} catch { /* lint-exempt:快照失败不阻派发，摘要回退既有差集口径 */ }
	// ev-20260902-772c7f：白名单任务自动附带专属验证产物临时目录（追加进白名单 + AMAGI_TASK_TMP_DIR
	// 告知）；protectedPaths 黑名单模式无白名单边界，不需要临时落点。
	const taskTmpDir = opts.allowedPaths && opts.allowedPaths.length > 0 ? prepareTaskTmpDir(taskId) : undefined;
	const effectiveAllowedPaths = taskTmpDir && opts.allowedPaths ? [...opts.allowedPaths, taskTmpDir] : opts.allowedPaths;
	// ev-20260909-729b99：工作区内 amagi-task/ 目录撞名检测
	const taskTmpNameclash = taskTmpDir ? detectTaskTmpNameclash(opts.cwd) : undefined;
	// B0-1（附录 B.1）：本次真实子运行的稳定标识——spawn 前生成，finalize 落 trace/stats、
	// env 注入子进程（大发射观测关联）；同一逻辑任务的续跑/修复轮各自新 runKey（各自增量）。
	const runKey = nextRunKey(taskId);
	let proc: ReturnType<typeof spawn> | undefined;
	// ev-20261019-06c169：物理退出观察栅栏——只有真实收到 spawn 事件后到达的 close 才提交 exited
	//（spawn error + close / 同步 spawn throw / 预检失败 / 启动前取消均不得合成 started/exited）；
	// close 正常路径先记物理观察（await 提交链）再写业务终态（finalize 消费 physicalExitCommitted）。
	let sawSpawn = false;
	let closedPhysical: { code: number | null; at: number } | undefined;
	let physicalExitCommitted: Promise<unknown> = Promise.resolve();
	let finalizeEntered = false;
	// ev-20260922-1b1662：invocation 提升到 try 外（纯计算零副作用）——catch 归因诊断需要命令路径
	const invocation = opts.command
		? { command: opts.command.command, args: spawnArgs }
		: getPiInvocation(spawnArgs);
	try {
		registry.preSpawnCheck(); // create→await→spawn 竞态在此转为结构化 error
		const childEnv = buildMinimalEnv(model, agent.name, opts.cwd, opts.protectedPaths, effectiveAllowedPaths, taskTmpDir, taskId, taskTmpNameclash,
			permissionDelivery ? normalizeMcpPermission(permissionDelivery.grant.mcp) : undefined);
		appendAdvisorEnv(childEnv, permissionDelivery?.grant.advisor);
		// B0-1：runKey 注入子进程（子进程内大发射观测行携带同一标识，与父侧 trace 行可关联）。
		childEnv.AMAGI_RUN_KEY = runKey;
		// P4：冻结授权 env 注入（子端 file-permission bootstrap 校验 digest 一致才激活；失败 exit 1）。
		if (permissionDelivery !== undefined) appendPermissionGrantEnv(childEnv, permissionDelivery.rawGrantJson, opts.cwd, permissionDelivery.digest);
		proc = spawn(invocation.command, invocation.args, {
			cwd: opts.cwd, shell: false, stdio: ["ignore", "pipe", "pipe"], env: childEnv,
			// 5d0ef1：POSIX 自有进程组（子进程即组长 pgid===pid；Windows/开关关闭保持现状）
			detached: taskProcessGroupEnabled() ? true : undefined,
		});
		// C3-R4-A: 真实 spawn 事件才是“答案已交付/子会话已启动”的状态边界。
		if (proc) {
			// K4：启动观察（started 恰好一次——真实 OS spawn 事件为界，与 onSpawn 同源）
			proc.once("spawn", () => { sawSpawn = true; obsRelay?.emit({ kind: "started", at: Date.now() }); try { opts.onSpawn?.(); } catch {} });
			// ev-20261019-06c169：独立 close 监听器负责物理退出观察（与业务 finalize 的 once 门分开，
			// 不被 finalized 短路）；先于 finalize 注册。close 到达时：业务 finalize 尚未进入 → 只记录物理
			// 退出事实（由 finalize 在终稿引用 activity 之后、业务 status 之前提交）；已进入（error 事件先行，
			// 进程当时仍活）→ 迟到 close 在此独立提交退出观察，不被 finalize 的 once 门短路。
			proc.once("close", (closeCode) => {
				if (proc) CLOSED_CHILDREN.add(proc);
				obsTarget?.onProcess?.(undefined);
				if (!sawSpawn) return; // spawn 失败 + close：未创建进程不得合成退出事实
				if (finalizeEntered) physicalExitCommitted = obsRelay?.emitExitedOnce(closeCode) ?? Promise.resolve();
				else closedPhysical = { code: closeCode, at: Date.now() };
			});
			// sync/background 都登记 child；shutdown 必须能观察并终止全部模式。
			registry.patch(taskId, { child: proc });
			obsTarget?.onProcess?.(proc); // K4：句柄回投适配器私有映射（§3.2；registry child 为迁移期兼容投影，K5/K8 拆除）
		}
	} catch (e) {
		// ev-20260922-1b1662：spawn 同步抛出同样可能由 cwd 缺失触发（报文只含命令名）——归因后再上抛
		const attributed = e instanceof Error ? new Error(diagnoseSpawnFailure(e, invocation.command, opts.cwd)) : e;
		return finalizeLaunchFailure(taskId, agent, sessionName, attributed, opts.onFinalize, obsTarget);
	}

	// ev-20260909-1face0（P2）：孙进程审计器（记录子进程 pid，周期追踪后代树并在终态回收残留）
	const rootBirthPromise = opts.processAuditDeps?.rootBirthToken ? Promise.resolve(opts.processAuditDeps.rootBirthToken)
		: (typeof proc?.pid === "number" ? readKernelProcessIdentitiesAsync([proc.pid]).then(ids => !childExited(proc) ? ids.get(proc.pid!)?.identityToken : undefined) : Promise.resolve(undefined));
	const auditor = (proc && typeof proc.pid === "number")
		? new ProcessAuditor(proc.pid, { ...opts.processAuditDeps, taskId, cwd: opts.cwd, parentPid: process.pid, rootBirthPromise, auditPath: amagiDataFile("process-audits", taskId.replace(/[^a-zA-Z0-9_-]/g, "_"), "process-audit.json") })
		: undefined;
	void auditor?.sample(true); // pin lineage while the owned root is alive; final snapshot cannot invent ownership

	// ── 5d0ef1：本 run 的幂等组级终止入口（cancel/timeout/abort/doom/spawn-ready/settle 共用）──
	// 句柄附在运行时 child 管理面（(child as any).__amagiTerminateOwnedRun），不写进持久化 registry 数据。
	const ownedPgid = taskProcessGroupEnabled() && typeof proc?.pid === "number" ? proc.pid : undefined;
	// ev-20261021-a8de95（diting F-01）：持久启动锚点——日后恢复对账以 rootPid/进程组/出生令牌正向证明退出
	//（环境标签缺席不是退出证据）。写入失败只记活动注记，不阻断运行（对账届时如实判 unknown）。
	// 同步写入（先于 spawn 事件触发的 started 观察）——契约记录出现的 backendRunId 必有锚点；令牌异步补齐。
	if (typeof proc?.pid === "number" && obsRelay) {
		const anchorRec = recordLaunchAnchor(taskId, { backendRunId: obsRelay.backendRunId, pid: proc.pid, ...(ownedPgid !== undefined ? { pgid: ownedPgid } : {}), identityToken: rootBirthPromise });
		const noteAnchor = (failure: string | undefined, what: string) => { if (failure) registry.appendActivity(taskId, { type: "launch_anchor", summary: `[启动锚点] ${what}失败（${failure}）——恢复对账无法自证退出`, ts: Date.now() }); };
		noteAnchor(anchorRec.failure, "写入");
		void anchorRec.tokens.then((f) => noteAnchor(f, "出生令牌补齐"), (e) => noteAnchor(String(e), "出生令牌补齐"));
	}
	let groupTerminateState: "idle" | "armed" | "done" = "idle";
	let originalRootBirth = opts.processAuditDeps?.rootBirthToken;
	void rootBirthPromise.then(token => { originalRootBirth = token; });
	const groupCleanupNotes: string[] = [];
	const terminateOwnedRun = (reason: string): void => {
		if (ownedPgid === undefined || groupTerminateState !== "idle") return;
		groupTerminateState = "armed";
		// 首帧期间也可能取消。等本次 spawn 已发起的有界探针完成后再核验，
		// 不能把“尚未完成”当成永久未知后丢弃终止请求，也不能从后续 ps 自学根身份。
		void rootBirthPromise.then(token => {
			originalRootBirth = token;
			const known = auditor?.getSeenBirthTokens() ?? new Map<number, string>();
			if (originalRootBirth) known.set(ownedPgid, originalRootBirth);
			const membersAtTerm = snapshotGroupMembers(ownedPgid);
			const groupEvents: object[] = [];
			const groupAuditPath = amagiDataFile("process-audits", taskId.replace(/[^a-zA-Z0-9_-]/g, "_"), "process-group-audit.json");
			const record = (signal: string, decision: string, members: GroupMember[] | null): void => {
				groupEvents.push({ at: Date.now(), signal, decision, members });
				try { fs.mkdirSync(path.dirname(groupAuditPath), { recursive: true, mode: 0o700 }); fs.writeFileSync(groupAuditPath, JSON.stringify({ taskId, cwd: opts.cwd, rootPid: ownedPgid, originalRootBirth, reason, events: groupEvents }, null, 2) + "\n", { mode: 0o600 }); } catch { /* lint-exempt:signal safety never depends on log success */ }
			};
			if (!membersAtTerm || !processGroupBelongsTo(membersAtTerm, known)) {
				record("SIGTERM", "skip group: ownership unconfirmed", membersAtTerm);
				groupCleanupNotes.push(`[进程组清理] 身份未确认，跳过组信号（${reason}）；证据：${groupAuditPath}`);
				// A failed group snapshot cannot justify killing unrelated descendants. The direct child is
				// still independently killable only if its original precise token remains unchanged.
				const direct = readKernelProcessIdentities([ownedPgid]).get(ownedPgid);
				if (originalRootBirth && direct?.identityToken === originalRootBirth && proc && !childExited(proc)) {
					try { proc.kill("SIGTERM"); record("SIGTERM child", "sent to verified root", membersAtTerm); } catch { /* journal:owned-root-term-failed */ record("SIGTERM child", "signal failed", membersAtTerm); }
					const timer = setTimeout(() => {
						groupTerminateState = "done";
						const live = readKernelProcessIdentities([ownedPgid]).get(ownedPgid);
						if (live?.identityToken !== originalRootBirth || !proc || childExited(proc)) { record("SIGKILL child", "skip: root changed, unknown or exited", null); return; }
						try { proc.kill("SIGKILL"); record("SIGKILL child", "sent to verified root", null); } catch { /* journal:owned-root-kill-failed */ record("SIGKILL child", "signal failed", null); }
					}, SIGKILL_GRACE_MS); timer.unref?.();
					return;
				}
				groupTerminateState = "done"; return;
			}
			try { process.kill(-ownedPgid, "SIGTERM"); record("SIGTERM", "sent after ownership check", membersAtTerm); }
			catch { /* journal:owned-group-term-failed */ record("SIGTERM", "signal failed or group exited", membersAtTerm); groupTerminateState = "done"; return; }
			const pinned = new Map(membersAtTerm.map(m => [m.pid, m.identityToken!]));
			const timer = setTimeout(() => {
				groupTerminateState = "done";
				const current = snapshotGroupMembers(ownedPgid);
				if (current?.length === 0) { record("SIGKILL", "group exited", current); return; }
				if (!current || !processGroupBelongsTo(current, pinned)) {
					record("SIGKILL", "skip: ownership changed or unconfirmed", current);
					groupCleanupNotes.push(`[进程组清理] 出生身份改变或不可确认，跳过 SIGKILL；证据：${groupAuditPath}`); return;
				}
				try { process.kill(-ownedPgid, "SIGKILL"); record("SIGKILL", "sent after ownership check", current); }
				catch { /* journal:owned-group-kill-failed */ record("SIGKILL", "signal failed or group exited", current); }
			}, SIGKILL_GRACE_MS);
			timer.unref?.();
		});
	};
	if (proc) {
		// ev-20261008-30e744（R2）：精确 spawn 出生身份 getter——独立于进程组模式挂载（组模式/
		// 非组模式真实 run 一律可核验）。shutdown 对直接子进程的每个信号都必须经它新核验；
		// 身份未知/无面一律明确拒绝，绝不从 shutdown 时探测到的当前身份自学授权。
		try {
			(proc as any).__amagiOwnedRootBirth = async (): Promise<string | undefined> => {
				if (originalRootBirth) return originalRootBirth;
				let timer: ReturnType<typeof setTimeout> | undefined;
				try {
					return await Promise.race([rootBirthPromise, new Promise<undefined>((r) => { timer = setTimeout(() => r(undefined), 1500); timer.unref?.(); })]);
				} catch { /* lint-exempt:身份未知时安全跳过，不授权信号 */ return undefined; }
				finally { if (timer) clearTimeout(timer); }
			};
		} catch { /* lint-exempt:面挂载失败 → shutdown 明确拒绝并留证据 */ }
	}
	if (ownedPgid !== undefined && proc) {
		try { (proc as any).__amagiTerminateOwnedRun = terminateOwnedRun; } catch { /* 句柄挂载失败仅允许已核验身份的 child 信号 */ }
	}

	const ctx = newParseContext();
	// v1.5.219：记录 spawn 全形态模型（--model provider/model:thinking）供流内合并。
	{ const mi = args.indexOf("--model"); if (mi >= 0 && typeof args[mi + 1] === "string") ctx.spawnModel = args[mi + 1]; }
	let timedOut = false, aborted = false, doomKilled = false;
	let hostRunAborted = false; // 宿主事实独立于父侧 signal；本轮 true 不被缺字段/false 清除。
	// 8月迭代 pi-0.84 配合 P1④：硬边界终止识别（检测见 data handler 的 tool_execution_end 分支，
	// 结算见 finalize 的 boundaryGuardHit；guards 契约见 BOUNDARY_GUARD_MARKER 注释）。
	let boundaryTerminated = false;
	let boundaryGuardReason = "";
	let buffer = "", totalBytes = 0, stderrBuf = "";
	// T2-7a 停滞看门狗：stdout 静默超 STALL_THRESHOLD_MS → onStall 提醒（不杀进程，仅提示主会话）
	// P2（8月迭代第三轮）：区分「执行中静默/无调用静默」——实战 11 条停滞警告全部为合法长命令
	//（浏览器验证/长构建，0 真停滞）。工具在飞时挂起常规告警计时（execSilentMs 累计到 3× 阈值
	// 硬上限才提示一次，防真挂死的 bash 永无告警）；零工具调用的静默单独标注（疑似任务书过载）。
	let lastActivity = Date.now();
	let execSilentMs = 0;
	// ev-20260903-a5b662（复盘 §1.2）：本 runPiTask 调用内是否已落盘 session 见证行（幂等置位）。
	let sessionJournaled = false;
	// 复盘 §5#3：provider 自动重试等待窗口（auto_retry_start 的 delay + 30s 余量）内静默抑制
	// 常规/无调用停滞告警——实战 glm 退避等待期间连报 3 次误报停滞，Leader 自白浪费轮次。
	let retryQuietUntil = 0;
	// v1.5.194 启动就绪守卫：spawn 后零输出（stdout+stderr 无任何字节）超 AMAGI_SPAWN_READY_MS（默认 30s）
	// → 主动杀死。启动期挂起发生在扩展加载前，插件看门狗无法介入，但 spawn 侧零输出可观测。
	let everActivity = false;
	let spawnDead = false;
	// v1.5.181 onUpdate 进度回流节流阀（首帧必发；AMAGI_UPDATE_THROTTLE_MS 可调）
	let lastEmit = 0;
	const UPDATE_THROTTLE_MS = (() => {
		const v = Number(process.env.AMAGI_UPDATE_THROTTLE_MS);
		return Number.isFinite(v) && v >= 0 ? v : 800;
	})();
	// 检查节拍顾及启动就绪阈值（小阈值测试/配置不等 30s 首检）
	const _spawnReadyMs0 = getSpawnReadyMs();
	const _stallCheckMs = Math.max(25, Math.min(getStallCheckIntervalMs(), _spawnReadyMs0 > 0 ? _spawnReadyMs0 : 30_000));
	const stallChecker = setInterval(() => {
		void auditor?.sample();
		const idle = Date.now() - lastActivity;
		// v1.5.194 启动就绪守卫：零输出超阈值 → 杀（不重置 everActivity，一次性判定）
		const spawnReadyMs = getSpawnReadyMs();
		if (!everActivity && spawnReadyMs > 0 && idle >= spawnReadyMs) {
			spawnDead = true;
			try { killTimeout = killTimer(proc); } catch {}
			return;
		}
		if (idle >= getStallThresholdMs()) {
			// 复盘 §5#3：provider 重试退避等待窗口内不告警（子进程在等 provider 回包，静默是预期；
			// exec 分支同理不受影响——重试等待期无工具在飞，真挂死的 3× 硬上限由窗口外的常规节拍覆盖）。
			if (Date.now() < retryQuietUntil) return;
			lastActivity = Date.now(); // 重置避免重复提醒（每阈值一次）
			// 终态竞态守卫：finalize 与本回调并发时以 registry 为唯一终态真相（防终态后误报）
			if (registry.get(taskId)?.status !== "running") return;
			// P2：执行中静默（工具在飞）——合法长命令，挂起常规告警；3× 阈值硬上限提示一次
			if (ctx.pendingToolExecutions.size > 0) {
				execSilentMs += idle;
				if (execSilentMs < getStallThresholdMs() * 3) return;
				const _execAccum = execSilentMs;
				execSilentMs = 0;
				try { opts.onStall?.({ taskId, agent: agent.name, idleMs: _execAccum, kind: "exec" }); } catch {}
				return;
			}
			execSilentMs = 0;
			// P1：无调用静默（全程零工具调用）——疑似任务书过长/模型停滞，分流到精简重派建议
			const _kind = (ctx.toolCalls || 0) === 0 ? "no-call" as const : undefined;
			try { opts.onStall?.({ taskId, agent: agent.name, idleMs: idle, kind: _kind }); } catch {}
		}
	}, _stallCheckMs);
	stallChecker.unref?.();

	// ── v1.5.218 settle 收口兜底：assistant 终稿帧已到但进程不退（句柄泄漏挂死事件循环） → 宽限后 SIGTERM ──
	// 实战根因：amagi.json mcp 路由给子进程加载 stdio 型 server（npx 常驻子进程），turn 完成后管道挂住
	// print 模式退出（baize settle 后挂 16min 被手动 abort）。根治在 mcp-client lazyDiscovery + agent_settled
	// close；本兜底覆盖任何未知的句柄泄漏，且收口不误伤——终稿已在则按 done 结算并附诊断注记。
	// A1（ev-20260815-35219a）信任链闭环：① 宽限自适应 = 基础值 + 交付物数×30s（附加封顶 10min，
	// AMAGI_SETTLE_REF_GRACE_MS 可调）；② 产出窗口判定在 SIGTERM 之前——任务带交付物且本轮零写盘
	// 绝不杀，放行一轮宽限继续跑（实战：cangjie 读完 6 个大文件后构思首次写盘时被误杀仍标 done）；
	// ③ 收口终稿判定收紧（见 finalize settledExit）——中途文本帧不再放行 done。
	const settledBaseMs = (() => {
		const v = Number(process.env.AMAGI_SETTLED_EXIT_MS);
		return Number.isFinite(v) ? v : 25_000;
	})();
	const SETTLE_GRACE_CAP_MS = 10 * 60_000;
	const _deliverableCount = deliverableCountOf(registry.get(taskId), opts.baselineArtifactRefs);
	let settleGraceMs = 0;
	if (settledBaseMs > 0) {
		const refGraceMs = (() => {
			const v = Number(process.env.AMAGI_SETTLE_REF_GRACE_MS);
			return Number.isFinite(v) && v >= 0 ? v : 30_000;
		})();
		settleGraceMs = settledBaseMs + Math.min(_deliverableCount * refGraceMs, SETTLE_GRACE_CAP_MS);
	}
	let settledKilled = false;
	let settleHandoffDefered = false; // 产出窗口已放行过一轮（只放行一次，防无限拖延收口；收口分类由 finalize 重推导）
	if (settleGraceMs > 0) {
		const settledChecker = setInterval(() => {
			if (settledKilled || aborted || timedOut || spawnDead || doomKilled) return;
			if (advisorConsultationPending(ctx, permissionDelivery && !("error" in permissionDelivery) ? permissionDelivery.grant.advisor?.timeoutMs : undefined)) return;
			if (registry.get(taskId)?.status !== "running") return;
			const ts = ctx.lastAssistantEndTs;
			if (!ts || Date.now() - ts < settleGraceMs) return;
			// A1 产出窗口判定（SIGTERM 前）：任务带交付物且本轮零写盘——模型可能正处「读完全部
			// 上下文、构思首次写盘」的长思考。绝不 SIGTERM：放行一轮宽限继续跑；后续自行推进则
			// 计时基线自然更新/重置，仍零写盘才收口为 NEEDS_HANDOFF（见 finalize：blocked + resume
			// 指引，绝不静默按 done 收口）。
			if (!settleHandoffDefered && _deliverableCount > 0 && ctx.writeToolCalls === 0) {
				settleHandoffDefered = true;
				settleGraceMs += settleGraceMs; // 放行一轮宽限（加倍）
				// K4：观察模式活动摘要经 sink（内核内存 ring，§3.4 分层）；legacy 保持 registry 活动登记
				// K4：观察模式活动摘要经 sink（内核内存 ring，§3.4 分层）；ev-20261019-06c169 默认观察
				// 模式下同步保留 registry 活动登记（面板/看板数据源是迁移期兼容投影，不因默认接管而断流）。
				if (obsRelay) {
					obsRelay.emit({ kind: "activity", note: `settle_handoff: [NEEDS_HANDOFF 观察] 零写盘、${_deliverableCount} 项交付物未开工——放行继续跑（宽限加倍）`.slice(0, 160) });
					if (!explicitObs) { try { registry.appendActivity(taskId, { type: "settle_handoff", summary: `[NEEDS_HANDOFF 观察] settle 兜底触发时零写盘、${_deliverableCount} 项交付物未开工——放行继续跑（宽限加倍），若仍零写盘将按 NEEDS_HANDOFF 收口`, ts: Date.now() }); } catch {} }
				}
				else { try { registry.appendActivity(taskId, { type: "settle_handoff", summary: `[NEEDS_HANDOFF 观察] settle 兜底触发时零写盘、${_deliverableCount} 项交付物未开工——放行继续跑（宽限加倍），若仍零写盘将按 NEEDS_HANDOFF 收口`, ts: Date.now() }); } catch {} }
				return;
			}
			settledKilled = true;
			try { killTimeout = killTimer(proc); } catch {}
		}, Math.max(250, Math.min(1000, settleGraceMs / 4)));
		settledChecker.unref?.();
	}

	// ── 显式总时长超时 + abort + SIGTERM→SIGKILL（唯一一份）──
	// 5d0ef1：进程组模式下统一走组级终止入口（cancel/timeout/abort 同一入口；不再另起宽限 timer）。
	const killTimer = (p: any) => {
		if (ownedPgid !== undefined) { try { terminateOwnedRun("engine"); } catch {} return undefined; }
		try { p.kill("SIGTERM"); } catch {}
		return setTimeout(() => { try { p.kill("SIGKILL"); } catch {} }, SIGKILL_GRACE_MS);
	};
	let killTimeout: ReturnType<typeof setTimeout> | undefined;
	const taskTimeoutMs = resolveTaskTimeoutMs(opts.timeoutMs);
	const timer = taskTimeoutMs === undefined
		? undefined
		: setTimeout(() => { timedOut = true; killTimeout = killTimer(proc); }, taskTimeoutMs);
	const onAbort = () => { aborted = true; killTimeout = killTimer(proc); };
	if (opts.signal) { if (opts.signal.aborted) onAbort(); else opts.signal.addEventListener("abort", onAbort, { once: true }); }

	// ── once-finalizer（error/close 只执行一次） ──
	let finalized = false;
	const finalize = async (code: number | null, signal: NodeJS.Signals | null): Promise<RunResult> => {
		if (finalized) return null as any; // once guard
		finalized = true;
		finalizeEntered = true; // ev-20261019-06c169：告知物理 close 监听器业务收口已进入（迟到 close 独立提交退出观察）
		if (timer) clearTimeout(timer); if (killTimeout) clearTimeout(killTimeout); clearInterval(stallChecker);
		if (opts.signal) opts.signal.removeEventListener("abort", onAbort);
		// flush 尾帧
		if (buffer.trim()) {
			if (Buffer.byteLength(buffer, "utf8") > MAX_LINE_BYTES) ctx.lineTruncated = true;
			else consumeLine(buffer);
		}
		// Wave C2：尾帧核销的写盘目标在终态 patch 前入列（保持 running 窗口语义）
		drainWritePaths(ctx, taskId, opts.cwd);
		ctx.stderr = stderrBuf.slice(-STDERR_TAIL);
		// 终态判定（错误优先 > truncated > blocked > done）
		const output = getFinalOutput(ctx.messages);
		const blocked = detectBlocked(output);
		const providerError = ctx.stopReason === "error" || ctx.stopReason === "aborted" || !!ctx.errorMessage;
		// v2 批次B 取消真相：cancelTask 已把 registry 置 cancelled 并 SIGTERM 子进程——
		// close 到达时以 registry 为唯一终态真相覆写本地判定（partial output 保留于 RunResult/artifact）。
		const cancelledByRegistry = registry.get(taskId)?.status === "cancelled";
		// diting Major-2：显式终止原因（timeout/abort/doom/spawn-dead/provider/截断/取消）优先于
		// settle 收口三分类——settle SIGTERM 后子进程不退、控制面终止与 settle 同窗口竞态时，
		// status/errorMessage/terminatedBy 取更明确的显式原因统一推导，杜绝
		// status=blocked + timedOut=true + terminatedBy=timeout 这类自相矛盾的结算。
		const explicitTerm = timedOut || aborted || hostRunAborted || !!ctx.doomLoop || spawnDead || providerError || truncatedFallbackPeek(ctx) || cancelledByRegistry;
		// 8月迭代 pi-0.84 配合 P1④：边界终止结算——guards 硬边界已终止本轮 run（terminate 语义，
		// 无后续 assistant 文本）。仅在无更高优先显式原因（cancel/doom-loop/timeout/abort/provider
		// 错误/截断）时主导结算：status=blocked + terminatedBy=boundary-guard，守卫 reason 行
		// （≤200 字符）作为根因透出交回 Leader。blockReason 维持结构化枚举
		// （questions/needs-handoff）不动——边界终止不属于任一既有语义，具体根因走 errorMessage
		// （枚举跨 artifact/finalizer/registry 白名单多文件窄类型契约，本批不扩）。
		const boundaryGuardHit = boundaryTerminated && !explicitTerm;
		const _boundaryGuardReason = boundaryGuardHit ? (boundaryGuardReason || BOUNDARY_GUARD_MARKER) : undefined;
		// v1.5.218 settle 收口豁免：终稿帧已到（lastAssistantEndTs）且被本兜底 SIGTERM——
		// 工作已完成，进程不退是句柄泄漏（根因 MCP stdio，见 settledChecker 注释），不判 error。
		// v1.5.222 硬化：兜底 SIGTERM 仅在「真终稿已交付」时按 done 结算——
		// ① lastAssistantEndTs 仅由白名单终稿帧置位（见 processLine）；② 末帧非 provider error/aborted
		// （实战 cbc75699：error 帧曾置位计时→误杀→豁免抹掉 error 误标 done，outputBytes:0）；
		// ③ 终稿非空（零输出的 done 必为误判）。任一不满足 → 维持 error + 真实根因 + resume 指引。
		// A1（ev-20260815-35219a）终稿判定收紧：上述白名单只证「帧干净」，不证「真终稿」——中途
		// 文本帧（「我已读完，现在开始写」）同样干净。新增硬条件 settledTrueFinal：末帧文本含
		// AMAGI_DONE_MARKER（完成契约自证），或任务无交付物且本轮有写盘证据（只读调查类真干完活）。
		// 零写盘被杀不再放行 done——那必是未开工即被收口。
		// A1-R（diting Major-1）无交付物只读终稿分支：零写盘且无 marker 时，写盘次数不再是否决条件
		// ——由独立信号区分中途宣告与真终稿（末帧为完整陈述性报告 looksLikeFinalReport 且无未完
		// 工具执行轮），恢复纯只读调查任务合法终稿的 done 收口（不误判 killed-by-settle error）。
		const settledTrueFinal = output.includes(AMAGI_DONE_MARKER)
			|| (_deliverableCount === 0 && ctx.writeToolCalls > 0)
			|| (_deliverableCount === 0 && ctx.pendingToolExecutions.size === 0 && looksLikeFinalReport(output));
		const settledExit = settledKilled && !!ctx.lastAssistantEndTs && !explicitTerm && output.length > 0 && settledTrueFinal;
		// A1 产出窗口收口：任务带交付物但本轮零写盘 → 绝不按 done（也绝不裸 error）静默收口——
		// 置 blocked（NEEDS_HANDOFF）+ resume 指引交回 Leader；会话上下文完好，resume 即接手开工。
		// diting Major-2：显式终止原因（timeout/abort/cancel 等）到达时不收口为 handoff——
		// 显式执行上限/中止/取消策略的语义优先，绝不产生 blocked+timedOut 矛盾结算。
		const settledNeedsHandoff = settledKilled && !settledExit && !explicitTerm && _deliverableCount > 0 && ctx.writeToolCalls === 0;
		const signalKilled = (code === null || signal !== null) && !settledExit;
		const truncated = ctx.stdoutCapped || ctx.messageTruncated || ctx.lineTruncated;
		const fatal = timedOut || aborted || hostRunAborted || signalKilled || providerError || (code !== null && code !== 0 && !settledExit);
		// P1（8月迭代第三轮）：输出超限截断≠执行失败——终稿帧丢失但会话/产物在，独立 truncated 终态；
		// finalizer 证据绿（测试通过+有交付 diff）时升级 done；不再一刀切标 error（实战：batch 节点交付完成
		// 仅因输出截断被误标 failed，浪费 2 轮取证）。
		let status: TaskStatus = fatal ? "error" : truncated ? "truncated" : blocked ? "blocked" : "done";
		// A1：产出窗口收口按 blocked/NEEDS_HANDOFF（绝不 done；signal→error 的通用规则被显式覆盖）。
		if (settledNeedsHandoff) status = "blocked";
		if (boundaryGuardHit) status = "blocked"; // 8月迭代 pi-0.84 配合 P1④：边界终止按 blocked 结算（run 被守卫终止，非执行失败亦非完成）
		if (status === "done" && !output && (ctx.parseErrors.length > 0 || ctx.messages.length === 0)) status = "error";
		if (status === "done" && ctx.doomLoop) status = "error"; // v1.5.186 doom-loop 命中绝不标 done
		if (cancelledByRegistry) status = "cancelled";
		// 超时/中止必须给出明确根因——否则 errorMessage 为空，回流只显示 "error —"，
		// Leader/用户无法判断是被 timeout 杀死（实战：双 luban 600s 被杀、原因栏空白）。
		const _killReason = timedOut
			? `[超时] 子进程达到显式配置的 ${formatTaskTimeout(taskTimeoutMs!)} 总时长上限，已触发终止请求（实际信号/跳过见清理证据）。可调整 timeoutMs / AMAGI_TASK_TIMEOUT_MS，设 0 或不设置则关闭总时长上限`
			: aborted ? "[中止] 收到 abort 信号，已触发子进程终止请求" : undefined;
		// v1.5.194 启动就绪超时根因（最优先：最具体的终止原因）
		const _spawnDeadReason = spawnDead
			? `[启动就绪超时] 子进程 ${Math.round(getSpawnReadyMs() / 1000)}s 内零输出被终止——启动期挂起（疑 pi 本体启动网络操作无超时，2026-07-31 实战：pi.dev 相关调用挂死全部新 pi 进程）；应急：设 PI_OFFLINE=1 后重试；AMAGI_SPAWN_READY_MS 可调/0 关闭`
			: undefined;
		// 截断同样必须给明确根因（P1-2 最终帧不可信仍判 error；实战：luban/diting 缓冲截断后
		// 根因回退到误导性的 stopReason:toolUse，且输出被清零——保留部分输出 + resume 指引）。
		const _truncReason = truncated
			? `[截断] 单行/单条消息或总输出超上限，最终帧不可信（AMAGI_MAX_MESSAGE_BYTES 可调缓冲；会话完整，可 resume 续接拿终稿）`
			: undefined;
		// A1 settle 收口根因（最优先：收口方式的直接因果，errorMessage 首行即收口语义；provider/超时根因随后附注保留）。
		// ④ 兜底 kill 且未过收紧判定 → error，首行 [killed-by-settle] + 零/低写盘证据 + resume 指引；
		// ③ 产出窗口（NEEDS_HANDOFF）→ blocked，原因首行注明 + task({session}) resume 指引。
		// diting Major-2：settle 收口仅在显式终止原因之外才是主导因果——timeout/abort/cancel/doom/
		// provider/截断与 settle 同窗口竞态时根因让位（finalErrorMessage 链自然取显式原因，
		// 取消态则优先 registry 记录的取消原因，绝不残留 NEEDS_HANDOFF/killed-by-settle）。
		const _settleDominant = settledKilled && !explicitTerm;
		const _settleHandoffReason = _settleDominant && settledNeedsHandoff
			? `[NEEDS_HANDOFF] settle 兜底在「产出窗口」收口：任务声明 ${_deliverableCount} 项交付物（artifactRefs/交付物标记），但本轮零写盘类工具调用（write/edit/写文件 bash）——疑似刚读完上下文、尚未开工即被收口。它并未完成，不能按 done 结案；请用 task({ session: ${ctx.sessionId || sessionName} }) resume 续跑接手开工。`
			: undefined;
		const _settleKillReason = _settleDominant && !settledExit && !settledNeedsHandoff
			? `[killed-by-settle] settle 兜底 SIGTERM：收紧后的终稿判定未通过（末帧无 ${AMAGI_DONE_MARKER} 完成契约自证；本轮写盘类工具调用 ${ctx.writeToolCalls} 次${ctx.writeToolCalls === 0 ? "（零写盘）" : ""}）。会话已保存，可 task({ session: ${ctx.sessionId || sessionName} }) resume 续接；宽限可调 AMAGI_SETTLED_EXIT_MS（已含交付物数自适应加成，设 0 关闭兜底）。`
			: undefined;
		let finalErrorMessage = _boundaryGuardReason || _settleHandoffReason || _settleKillReason || ctx.errorMessage || ctx.spawnError || _spawnDeadReason || _killReason || _truncReason;
		if ((_settleHandoffReason || _settleKillReason) && ctx.errorMessage) finalErrorMessage += `\n[附带错误] ${ctx.errorMessage}`;
		// P1（8月迭代第三轮）：truncated 非失败——根因降级为 completionAnnotation（通知可见但不染红），
		// 证据绿时 finalizer 升级 done；errorMessage 只留真实 provider 错误。
		let _truncDowngraded = false;
		if (status === "truncated") {
			const _keep = ctx.errorMessage || ctx.spawnError;
			_truncDowngraded = true;
			finalErrorMessage = _keep || undefined;
		}
		// v1.5.218 settle 收口：终稿完整 → 按 done 结算，诊断降级为 completionAnnotation（回流可见但不染红）。
		if (settledExit) {
			finalErrorMessage = undefined;
			status = blocked ? "blocked" : "done";
		}
		// v1.5.186 P2 doom-loop 根因优先（最具体的终止原因）。
		if (ctx.doomLoop) {
			finalErrorMessage = `[死循环] 同一工具调用连续重复 ${getDoomLoopThreshold()} 次（${ctx.doomLoop}），已主动终止——疑似模型 doom-loop（grok doom_loop 同款检测，AMAGI_DOOM_LOOP_THRESHOLD 可调/0 关闭）；建议换模型或调整任务表述后 resume`;
		}
		// v1.5.185 provider 超时定向提示（实战：glm-5.2:max 长思考首字节慢，SDK 默认超时~60s
		// 连续 Request timed out → agent 级退避×3 烧 2min；给出 settings 修复方向而非裸错）。
		if (providerError && finalErrorMessage && /timed?\s*out|timeout/i.test(finalErrorMessage)) {
			finalErrorMessage += `；[提示] 高 thinking 档首字节慢，SDK 默认请求超时偏短——建议在 settings.json 设 retry.provider.timeoutMs=300000（doctor 启动检测覆盖此项）；瞬时传输类错误（timeout/断连/5xx）单任务派发缺省已有 1 轮隐式自动重派兜底（AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关，AMAGI_AUTORETRY_OFF=1 全关）`;
		}
		// 2026-08-16 复盘 P0-1：400 tool 消息序定向提示（实战：终验段 2 次死派发——session 历史含
		// 孤儿 tool 消息，resume 回放必复现 400；sync/background/resume 续跑回路会自动清除并重派一轮，
		// 此提示覆盖无法自动救的路径并给出手工恢复方向）。
		if (providerError && finalErrorMessage && isToolOrder400(finalErrorMessage)) {
			finalErrorMessage += `；[提示] provider 拒绝会话消息序（孤儿 tool 消息，session 历史损坏）——harness 将自动清除孤儿消息并重派一轮（AMAGI_SESSION_REPAIR=0 关闭）；若再失败请 fresh 派发恢复，勿 resume 本 session`;
		}
		// 2026-08-16 复盘 P0-2：上下文超限恢复指引（实战：luoshen 401 context 上限留半成品，
		// 恢复链烧 3 派发当量；给出优先级化恢复路径而非裸错）。
		if (providerError && finalErrorMessage && isContextLimitError(finalErrorMessage)) {
			finalErrorMessage += `；[提示] 疑似上下文超限——恢复优先级：a) 换大上下文模型 resume（task({ session: "${(ctx.sessionId || sessionName).slice(0, 8)}", model: "<大窗口模型>", task: "接手继续" })，会话上下文保留）；b) 拆小任务/缩减引用文件后 fresh 派发；c) resume 让子 Agent 先把状态落 artifact 再继续`;
		}
		if (hostRunAborted) {
			const hostReason = "[host-aborted] 宿主报告本轮中止（agent_settled.aborted=true），未宣称父侧已杀死进程";
			finalErrorMessage = cancelledByRegistry || ctx.doomLoop || timedOut || aborted || spawnDead
				? `${finalErrorMessage || hostReason}\n${hostReason}`
				: `${hostReason}${finalErrorMessage ? `\n[附带错误] ${finalErrorMessage}` : ""}`;
		}
		// 截断不清零输出：已收集的部分输出是真实工作成果（禁假数据≠丢弃真实数据），附非终稿声明
		const _truncNote = truncated && output
			? `\n\n[截断] 单行/单条消息或总输出超上限，最终帧丢失——以下为最后完整收到的部分输出（非终稿；会话完整，可 resume 续接拿完整结果）`
			: "";
		// A1：NEEDS_HANDOFF 收口的输出附注——blocked 通知路径以输出为正文（errorMessage 不入正文），指引必须随行。
		const _handoffNote = settledNeedsHandoff
			? `\n\n[NEEDS_HANDOFF] 上方为子 Agent 被收口前的最后输出（非终稿）：任务声明 ${_deliverableCount} 项交付物但本轮零写盘——settle 兜底未按 done 结案，请 task({ session: ${ctx.sessionId || sessionName} }) resume 续跑接手。`
			: "";
		// 缓冲淘汰如实标注：终稿帧完整保留（不判 error），但中间帧已被淘汰，全量轨迹在会话 JSONL。
		const _evictNote = ctx.evictedMessages > 0
			? `\n\n[缓冲淘汰] 累计消息缓冲超上限，为保住终稿帧已淘汰最早 ${ctx.evictedMessages} 条中间帧（终稿与工具计数完整；AMAGI_MAX_MESSAGE_BYTES 可调；全量轨迹见会话 JSONL，query_task({ full: true }) 可查）`
			: "";
		// 已完整接收的任务正文原样回流；wire 单帧/总量守卫及真实截断状态仍按上方处理。
		const completeOutput = output + _evictNote + _truncNote + _handoffNote;
		const existingArtifactRefs = registry.get(taskId)?.artifactRefs || [];
		const finalArtifactRefs = [...new Set([...existingArtifactRefs, ...(extractArtifactRefs(completeOutput) || [])])].slice(0, 10);
		// registry patch + stats + onFinalize（唯一终态处理）
		// v1.5.173：undefined 键剔除后再 patch——否则 Object.assign 以 undefined 覆盖 create 时
		// 记录的解析模型/sessionId/artifactRefs（既有数据丢失 bug：ctx.model 依赖进程流探测，
		// 缺失时把 registry.model 抹成 undefined，污染 query_task/路由记忆）。
		// v1.5.187 P7 冷启动延迟（spawn→首个 stdout 事件；grok PromptLatency pre_model 维度对应）。
		const _taskStartedAt = registry.get(taskId)?.startedAt;
		const _startupMs = typeof ctx.firstEventTs === "number" && _taskStartedAt ? Math.max(0, ctx.firstEventTs - _taskStartedAt) : undefined;
		// v1.5.188 E1/E3 完成契约标注——唯一收口（sync/background/resume/bg-resume 共享此 finalize）。
		// diting Major-1（v1.5.248）：计算上移至终态 patch 之前，随 _finalPatch 一并写入 registry——
		// 此前独立 patch 在终态后必被「终态不可回退」守卫拒绝，看板 truncated 态恒读缺省文案。
		let completionAnnotation = annotateCompletion("", completeOutput, agent, status, opts.baselineArtifactRefs, opts.cwd, finalErrorMessage, opts.dispatchTime, opts.declaredOutputPaths);
		// ev-20260919（LSP 降级）：预检剥除 lsp 的降级事实随终稿透出（Leader/回执可见，不染红终态）。
		const backendExitCode = hostRunAborted && code === 0 ? 1 : code;
		if (hostRunAborted) completionAnnotation += `\n[host-aborted] agent_settled.aborted=true / processExitCode=${code} / backendExitCode=${backendExitCode}`;
		if (lspDegradedNote) completionAnnotation += `\n${lspDegradedNote}`;
		if (settledExit) {
			completionAnnotation += `\n[settle 收口] 子进程终稿帧已交付（未截断）但 ${Math.round((Date.now() - (ctx.lastAssistantEndTs || 0)) / 1000)}s 未自然退出，已被兜底 SIGTERM（疑句柄挂住事件循环；诊断与开关：AMAGI_SETTLED_EXIT_MS 可调宽限，设 0 关闭兜底）。请按完成契约核验产物。`;
		}
		if (settledNeedsHandoff) {
			completionAnnotation += `\n[NEEDS_HANDOFF] settle 兕底在产出窗口收口（零写盘、交付物未开工）——已置 blocked 交回 Leader，请 task({ session: ${ctx.sessionId || sessionName} }) resume 续跑，勿按完成结案。`;
		}
		if (boundaryGuardHit) {
			completionAnnotation += `\n[边界终止] 子 Agent 的工具调用被任务硬边界守卫阻断并终止（pi 0.84.1 terminate 语义，terminatedBy=boundary-guard）——run 已提前结束、无后续 assistant 文本。请核对任务书与派发边界（allowedPaths/protectedPaths）后重新派发；直接 resume 大概率再次触界，故不自动续跑。`;
		}
		if (groupCleanupNotes.length) completionAnnotation += `\n${groupCleanupNotes.join("\n")}`;
		// ev-20260909-1face0（P2）：子进程终态残留进程审计与清理（只杀确认血缘内存活进程，失败静默）
		if (auditor) {
			try {
				const auditResult = await auditor.auditAndClean();
				if (auditResult.summary) {
					completionAnnotation += `\n${auditResult.summary}`;
				}
			} catch {
				// 进程清理失败静默降级，不阻断主收尾流程
			}
		}
		// ev-20260905-24558f（P0）：不朽进程形态——finalize 运行时子进程尚未 close（error 事件先到 /
		// 终止信号未生效），registry 即将写入终态并清 child 句柄；此刻按 pre-patch 记录定格进程实况
		// 注记（此刻 rec.status 仍 running → 「仍在运行」档），随 completionAnnotation 流入返回体与通知。
		// 事故形态：返回体报 error 后子进程又独立运行 85 分钟——不定格就只剩「已退出」的假象。
		if (status === "error" && !settledExit && !childClosed(proc)) {
			const _liveNote = processLivenessNote(registry.get(taskId));
			if (_liveNote) completionAnnotation += `\n${_liveNote}`;
		}
		// P1（8月迭代第三轮）：truncated 根因降级到此（回流/通知可见但不染红）
		if (_truncDowngraded && _truncReason) {
			completionAnnotation += `\n${_truncReason}`;
			completionAnnotation += `\n[输出截断·非失败] 终稿帧丢失但会话/产物完整——回流尾部证据（测试+diff）绿则按完成采信；需完整终稿可 task({ session: "${(ctx.sessionId || sessionName).slice(0, 8)}", task: "请给出最终交付报告" }) resume。`;
		}
		// diting Major-4：blocked 结构化原因——"questions"（QUESTIONS 待答，缺省/遗留语义）vs
		// "needs-handoff"（settle 产出窗口收口：resume 接手开工而非逐项答复）。通知/wait/
		// answer-queue/resume 状态机据此区分两类行动语义。
		const blockReason: "questions" | "needs-handoff" | undefined = status === "blocked"
			? (settledNeedsHandoff ? "needs-handoff" : boundaryGuardHit ? undefined : "questions")
			: undefined;

		// ev-20260909-ec769a（P2）：完成契约自证结构化标记
		// 仅对适用完成契约的角色（编码类 work/expert，fast 角色不校验）且 status==="done" 时赋值：
		// hasDoneMarker→true，否则 false（annotation 照旧附加）。其余（fast/blocked/error 等）为 undefined。
		const isDoneEligible = status === "done" && (agent.type === "work" || agent.type === "expert");
		const selfVerified: boolean | undefined = isDoneEligible ? hasDoneMarker(completeOutput) : undefined;
		// Leader 可见的最终输出文本：done 且未自证时在文本起始处加显式前缀标记 [未自证]（输出头部独立一行标记 + 换行）
		const finalOutputText = (selfVerified === false && completeOutput.trim() !== "")
			? `[未自证]\n${completeOutput}`
			: completeOutput;
		recordLastSelfVerified(taskId, selfVerified);
		// ev-20260910-8fbe4e（C）：连接类中断现场报告——仅 error 终态且 providerError（连接/网络类）
		// 时生成，随 RunResult/onFinalize 透出（sync 返回体、bg 完成通知、迟终态回推三处消费）。
		// 关键顺序：本 finalize 先于收尾链 finalizeTerminal 的 clearTaskWrites 读取写入登记
		// （且 error 终态已改为跳过清理，保留 resume 后归因能力——见 finalizer.ts）。
		let interruptionReport: string | undefined;
		if (status === "error" && providerError) {
			try {
				interruptionReport = buildInterruptionReport({
					taskId, cwd: opts.cwd, writes: readTaskWrites(taskId),
					lastAssistantEndTs: ctx.lastAssistantEndTs, endedAt: Date.now(),
					gitBaseline, sessionId: ctx.sessionId,
				});
			} catch { /* 观测面绝不反噬主流程 */ }
		}

		const runtimeFacts = runtimeObservation(ctx.runtimeEvents);
		const _finalPatch: Record<string, unknown> = {
			runtimeObservation: runtimeFacts,
			status, result: finalOutputText, sessionId: ctx.sessionId, model: ctx.model,
			blockedQuestions: status === "blocked" ? extractBlockedQuestions(completeOutput) : undefined,
			blockReason,
			artifactRefs: finalArtifactRefs.length ? finalArtifactRefs : undefined,
			stopReason: ctx.stopReason, errorMessage: finalErrorMessage, signal, timedOut, aborted: aborted || hostRunAborted,
			thinkMs: ctx.thinkMs || undefined, toolMs: ctx.toolMs || undefined,
			retryAttempts: ctx.retryAttempts || undefined, retryWaitMs: ctx.retryWaitMs || undefined,
			startupMs: _startupMs,
			completionAnnotation: completionAnnotation || undefined,
			// A4（ev-20260910-d86779）：error 终态的错误类别快照（非 error 终态不写）——供看板展示与
			// A3 建议推导，与 rounds[].status 拼出连续瞬时序列，不引入独立计数器。ev-20261017-88cb27：
			// 判定收敛到单源 lastErrorKindOfMessage（policy=provider 安全拦截优先；quota 含 usage limit
			// 硬额度耗尽形态），不再内联第二份 quota/transient 次序。
			lastErrorKind: status === "error" ? lastErrorKindOfMessage(finalErrorMessage) : undefined,
		};
		for (const k of Object.keys(_finalPatch)) if (_finalPatch[k] === undefined) delete _finalPatch[k];
		// ev-20261019-06c169 close 正常路径（设计时序 #4，观察模式）：终稿引用 activity（§8.1-K4）→
		// 物理退出观察（preserve + close 原始码，仅当 close 已到达且进程确已 spawn）→ 等提交链落盘 →
		// 再写最终业务 status（业务终态不再从 patch 剥离——blocked/needs-handoff/truncated/host-aborted/
		// settle 后合法 done 继续由桥受控迁移进内核，JSON 桥不再合成假退出；error 先到而进程仍活时
		// 不提前 exited，迟到 close 由独立监听器补交）。
		if (obsRelay) {
			_finalPatch.endedAt = _finalPatch.endedAt ?? Date.now();
			if (completeOutput.trim()) obsRelay.emit({ kind: "activity", note: `final-output ${Buffer.byteLength(completeOutput, "utf8")}B: ${completeOutput.replace(/\s+/g, " ").slice(0, 96)}` });
			if (closedPhysical !== undefined) {
				physicalExitCommitted = obsRelay.emitExitedOnce(closedPhysical.code);
				closedPhysical = undefined;
			}
			await physicalExitCommitted;
		}
		try { registry.patch(taskId, _finalPatch); } catch {
			if (status === "cancelled") {
				registry.recordCancelledResult(taskId, { result: completeOutput, sessionId: ctx.sessionId, model: ctx.model });
			}
		}
		// 观察提交失败以 bounded 诊断透出（不伪装已落盘；退出事实缺席时恢复对账保持待对账）。
		if (obsRelay) {
			const obsFailures = obsRelay.observeFailures();
			if (obsFailures.length > 0) completionAnnotation += `\n[观察提交失败] ${obsFailures.length} 条观察未落盘（${obsFailures[obsFailures.length - 1]}）——退出事实可能缺席，恢复对账将保持待对账；诊断保留在引擎 relay 有界环形内`;
		}
		const _rec = registry.get(taskId);
		if (status === "cancelled") {
			// diting Major-2：取消原因优先——cancelTask 已在 registry 记录取消事实与原因；
			// 竞态窗口内 settle 收口根因（NEEDS_HANDOFF/killed-by-settle）不得覆盖取消语义。
			const _cancelMsg = _rec?.errorMessage;
			if (typeof _cancelMsg === "string" && _cancelMsg) finalErrorMessage = _cancelMsg;
		}
		// v1.5.186 T2-7d 熔断记账：瞬时 provider 故障计数；成功复位（探针成败决定 HalfOpen 去向）；
		// 任务超时/doom/spawn 失败等非 provider 根因不计（熔断窗只烧真故障）。
		// v2 批次B：cancelled 不记熔断——取消是用户/系统行为，非 provider 健康信号。
		const _cbProvider = providerOfSpec(_rec?.model || ctx.model);
		if (status === "cancelled") { /* 取消不记 provider 熔断 */ }
		else if (status === "done" || status === "blocked") providerBreakerSuccess(_cbProvider);
		else if (providerError && !timedOut && !aborted && !hostRunAborted && !ctx.doomLoop && !ctx.spawnError) providerBreakerFailure(_cbProvider, ctx.errorMessage);
		const _effModel = ctx.model || _rec?.model; // stats/trace 模型：运行实测优先，回退 create 时解析值
		// B0-1（附录 B.1）：累计口径 usage（权威完结帧入账一次；末轮诊断快照与分栏单列）。
		const _usage = extractUsage(ctx);
		const _usageDetail = extractUsageDetail(ctx);
		const _usageCoverage = usageCoverageOf(ctx, status);
		const _leaderSession = getLeaderSessionStamp();
		const _statsPayload: CumulativeStatsEntry = { taskId, agent: agent.name, model: _effModel, status, durationMs: (_rec?.endedAt || 0) - (_rec?.startedAt || 0), thinkMs: ctx.thinkMs || undefined, toolMs: ctx.toolMs || undefined, retryAttempts: ctx.retryAttempts || undefined, retryWaitMs: ctx.retryWaitMs || undefined, startupMs: _startupMs, ..._usage, usageScope: "cumulative", assistantCalls: _usageDetail.assistantCalls, ...(ctx.usageMissingCalls > 0 ? { usageMissingCalls: _usageDetail.usageMissingCalls } : {}), ...(_usageDetail.firstCallContext !== undefined ? { firstCallContext: _usageDetail.firstCallContext } : {}), ...(_usageDetail.lastCall !== undefined ? { lastCall: _usageDetail.lastCall } : {}), ...(_usageDetail.nestedUsage !== undefined ? { nestedUsage: _usageDetail.nestedUsage } : {}), ...(_usageDetail.compactionUsage !== undefined ? { compactionUsage: _usageDetail.compactionUsage } : {}), ...(_leaderSession !== undefined ? { leaderSession: _leaderSession } : {}), runKey, preflightBytes: opts.preflightBytes ?? 0, usageCoverage: _usageCoverage };
		// T2-8 trace 采集 + T2-3a 路由记忆聚合（sync/background/resume 三路径统一在 finalize）
		const _resumeRounds = _rec?.rounds?.length || 0;
		const _traceEntry: TraceEntry = {
			formatVersion: 3, taskId, agent: agent.name,
			mode: _resumeRounds > 0 ? (_rec?.mode === "background" ? "bg-resume" : "resume") : (_rec?.mode || "sync"),
			status, durationMs: (_rec?.endedAt || 0) - (_rec?.startedAt || 0), thinkMs: ctx.thinkMs || undefined, toolMs: ctx.toolMs || undefined, retryAttempts: ctx.retryAttempts || undefined, retryWaitMs: ctx.retryWaitMs || undefined, startupMs: _startupMs, ..._usage,
			usageScope: "cumulative", assistantCalls: _usageDetail.assistantCalls, ...(ctx.usageMissingCalls > 0 ? { usageMissingCalls: _usageDetail.usageMissingCalls } : {}), ...(_usageDetail.firstCallContext !== undefined ? { firstCallContext: _usageDetail.firstCallContext } : {}), ...(_usageDetail.lastCall !== undefined ? { lastCall: _usageDetail.lastCall } : {}), ...(_usageDetail.nestedUsage !== undefined ? { nestedUsage: _usageDetail.nestedUsage } : {}), ...(_usageDetail.compactionUsage !== undefined ? { compactionUsage: _usageDetail.compactionUsage } : {}), ...(_leaderSession !== undefined ? { leaderSession: _leaderSession } : {}), runKey, preflightBytes: opts.preflightBytes ?? 0, usageCoverage: _usageCoverage,
			toolCalls: ctx.toolCalls, blocked: status === "blocked", resumeRounds: _resumeRounds, model: _effModel,
			// P2-A：仅 status=error 行落错误分类枚举（finalErrorMessage 为 finalize 后的最终根因链；
			// 只落分类不落明文，分类失败/无消息时缺省 → 读侧归一 unknown）
			errorKind: status === "error" ? classifyErrorKind(finalErrorMessage) : undefined,
			taskCategory: opts.taskCategory || classifyTask(_rec?.goal || completeOutput.slice(0, 200)), toolNames: [...ctx.toolNames], ...traceRelationOf(_rec), at: Date.now(),
		};
		// v1.5.188 自动续跑：deferStats 时 stats/trace 不落盘，由调用方（runTask）把多轮聚合成一条逻辑记录后统一写入——
		// 防止一次逻辑任务因自动续跑产生多条 done 记录污染路由记忆/成本统计。
		let _deferred: { stats: typeof _statsPayload; trace: TraceEntry } | undefined;
		if (opts.deferStats) {
			_deferred = { stats: _statsPayload, trace: _traceEntry };
		} else {
			writeStats(_statsPayload);
			writeTrace(_traceEntry);
			updateRoutingStats(_traceEntry);
		}
		// v1.5.248 diting Major-1：completionAnnotation 计算已上移至 _finalPatch 之前（随终态 patch 一并写入 registry）；
		// 此处仅保留消费面（onFinalize/回流），不再二次计算/二次 patch（旧独立 patch 在终态后被守卫拒绝，异常被吞，属静默 no-op）。
		const _fuseWarn = opts.fuseWarn || "";
		// F5（diting 终审）：回调 payload 补齐 runKey/_toolExecutions——与返回值对象同源（runKey 闭包变量/
		// ctx.toolExecutions）；后台完成链走回调（不走返回值），缺字段会让 task-background 侧透传收到 undefined。
		// ev-20261021-e476e9：终止裁决单源——返回值与后台回调同一 terminatedBy（后台格式补正据此抑制）。
		const terminatedBy = cancelledByRegistry ? "cancel" : ctx.doomLoop ? "doom-loop" : timedOut ? "timeout" : aborted ? "abort" : hostRunAborted ? "host-aborted" : boundaryGuardHit ? "boundary-guard" : settledKilled ? "settle-fallback" : undefined;
		try { opts.onFinalize?.({ runtimeObservation: runtimeFacts, taskId, agent: agent.name, agentType: agent.type, status, output: finalOutputText, blocked: status === "blocked", blockReason, errorMessage: finalErrorMessage, sessionId: ctx.sessionId, model: ctx.model, completionAnnotation, dispatchRevision, selfVerified, interruptionReport, aborted: aborted || hostRunAborted, terminatedBy, runKey, _toolExecutions: ctx.toolExecutions }); } catch { /* journal: optional finalization callback failed */ console.warn("[amagi] task finalization callback unavailable"); }
		return { runtimeObservation: runtimeFacts, taskId, output: finalOutputText, agentType: agent.type, exitCode: backendExitCode === null ? 1 : backendExitCode, processExitCode: code, stderr: ctx.stderr, blocked: status === "blocked", blockReason, selfVerified, sessionId: ctx.sessionId, model: ctx.model, isError: status === "error", status, timedOut, aborted: aborted || hostRunAborted, sessionName, stopReason: ctx.stopReason, errorMessage: finalErrorMessage, spawnError: ctx.spawnError, thinkMs: ctx.thinkMs || undefined, toolMs: ctx.toolMs || undefined, retryAttempts: ctx.retryAttempts || undefined, retryWaitMs: ctx.retryWaitMs || undefined, startupMs: _startupMs, completionAnnotation, interruptionReport, fuseWarning: _fuseWarn, dispatchRevision, runKey, _statsPayload: _deferred?.stats, _tracePayload: _deferred?.trace, _toolExecutions: ctx.toolExecutions, gitBaseline, terminatedBy };
	};

	// LF 与 close 尾帧共用同一消费入口（限流、核销、宿主事实、活动摘要都一致）。
	// B0-2：lastCall 快照引用哨兵——assistant 完结帧入账 usage 时 processLine 会替换 ctx.lastCallUsage
	// 对象，引用变化即「本任务最近一次模型调用已更新」；纯观测哨兵，不参与终态判定。
	let lastCallUsageSeen: CallUsage | undefined;
	const consumeLine = (line: string): boolean => {
		let chunkDirty = false;
			// v1.5.183 流式快照噪音豁免上限：pi json 模式 message_update 携带流式增量（pi 0.84.0 起
			// 仅发 delta，历史版本每行携带完整累计快照、stdout 体积随消息长度平方增长；升级 pi 0.84.0+
			// 后该豁免降为冗余安全网，保留以防降级运行）。噪音行进 processLine 亦无消费方，一并跳过。
			const noise = NOISE_LINE_RE.test(line);
			if (!noise) {
				totalBytes += Buffer.byteLength(line, "utf8");
				if (totalBytes > MAX_TOTAL_STDOUT) {
					ctx.stdoutCapped = true;
					// P3-02（diting Major）：总预算耗尽后不丢宿主控制事实——短小合法的
					// agent_settled.aborted=true 经有界路径仍被采集（fatal/backend 1/host-aborted 链路
					// 由此成立）；正文消费与大帧解析照旧丢弃，总量防护与单行限制不变。
					if (Buffer.byteLength(line, "utf8") <= CONTROL_FRAME_MAX_BYTES) {
						let ev: any; try { ev = JSON.parse(line); } catch { ev = null; }
						if (ev?.type === "agent_settled" && ev.aborted === true) hostRunAborted = true;
					}
					return false;
				}
				if (Buffer.byteLength(line, "utf8") > MAX_LINE_BYTES) { ctx.lineTruncated = true; processLine(line.slice(0, Math.floor(MAX_LINE_BYTES * 0.9)), ctx); }
				else processLine(line, ctx);
				// B0-2（webui 面板占比环）：lastCall 快照变化 → 更新本任务实时上下文 token 数
				//（input+cacheRead+cacheWrite 三分项和，与 Batch 0 lastCall 口径一致；末帧缺 usage 不覆盖
				//  前值——保留最后一次「已观测」值，不冒充）。纯只读投影，不回流执行链/终态判定。
				if (ctx.lastCallUsage !== lastCallUsageSeen) {
					lastCallUsageSeen = ctx.lastCallUsage;
					const fig = lastCallUsageSeen;
					if (fig) {
						let sum = 0, seen = false;
						for (const v of [fig.input, fig.cacheRead, fig.cacheWrite]) {
							if (typeof v === "number" && Number.isFinite(v) && v > 0) { sum += v; seen = true; }
						}
						if (seen) recordLiveContextTokens(taskId, sum);
					}
				}
				// v1.5.186 P2 doom-loop 命中 → 主动终止（SIGTERM→SIGKILL 与超时同路径；组模式走组级入口）。
				if (ctx.doomLoop && !doomKilled) {
					doomKilled = true;
				try { killTimeout = killTimer(proc); } catch {}
				}
			}
			// activity tracking（全模式：面板/看板数据源——sync 曾不记录导致面板只显示"等待首个动作…"）
			{
				let ev: any; try { ev = JSON.parse(line); } catch { ev = null; }
				if (ev) {
					observeRuntimeEvent(ctx.runtimeEvents, ev);
					if (ev.type === "agent_settled" && ev.aborted === true) hostRunAborted = true;
					// v1.5.184 耗时拆分：本 block 是唯一遍历全部行（含噪音）的位置，计时统一在此。
					const eventNow = opts.eventClockForTest ? opts.eventClockForTest(ev) : Date.now();
					if (ev.type === "turn_start" || ev.type === "agent_start") ctx.lastAssistantEndTs = undefined;
					if (ev.type === "message_start") ctx.msgStartTs = eventNow;
					else if (ev.type === "tool_execution_start") {
						ctx.toolStartTs = eventNow;
						ctx.toolSequence++;
						const toolName = typeof ev.toolName === "string" ? ev.toolName : "";
						const toolCallId = typeof ev.toolCallId === "string" ? ev.toolCallId : "";
						if (toolCallId && (toolName === "bash" || toolName === "edit" || toolName === "write")) {
							const args: Record<string, unknown> = {};
							if (toolName === "bash" && typeof ev.args?.command === "string") args.command = ev.args.command.slice(0, 4096);
							ctx.pendingToolExecutions.set(toolCallId, { toolName, args, startedAt: eventNow, order: ctx.toolSequence });
						}
					} else if (ev.type === "tool_execution_end") {
						if (ctx.toolStartTs) { ctx.toolMs += eventNow - ctx.toolStartTs; ctx.toolStartTs = undefined; }
						const toolCallId = typeof ev.toolCallId === "string" ? ev.toolCallId : "";
						// A1-R（diting Major-3）：tool_execution_end 与 toolResult 消息帧双信号幂等核销写盘证据
						//（成功才计数；与消息级帧先到先销，同一 toolCall 不双计）。
						if (toolCallId) settleWriteCredit(ctx, toolCallId, ev.isError === true);
						// 8月迭代 pi-0.84 配合 修复轮（Major-2）：硬边界终止识别用三重结构化判据——
						// isError===true 且 result.terminate===true 且 result 文本含精确前缀。
						// 权威证据（pi-agent-core/dist/agent-loop.js:306-316,417-427）：blocked tool_call
						// 返回 kind:"immediate" 的 finalized，必发 tool_execution_end（isError 恒 true），
						// 且 beforeResult.terminate===true 时 result.terminate=true 落在 result 对象上。
						// 只查文本会误报：任意工具的成功输出（如 read/grep 读到含该字符串的文件）
						// 即被误判为边界终止。
						if (!boundaryTerminated && ev.isError === true && ev.result?.terminate === true) {
							const _guardText = toolResultText(ev.result);
							if (_guardText.includes(BOUNDARY_GUARD_MARKER)) {
								boundaryTerminated = true;
								boundaryGuardReason = (_guardText.split(/\r?\n/).find((l) => l.includes(BOUNDARY_GUARD_MARKER)) || BOUNDARY_GUARD_MARKER).slice(0, BOUNDARY_GUARD_REASON_CAP).trimEnd();
							}
						}
						const pending = ctx.pendingToolExecutions.get(toolCallId);
						if (pending) {
							ctx.pendingToolExecutions.delete(toolCallId);
							ctx.toolExecutions.push({
								toolName: pending.toolName,
								args: pending.args,
								resultText: toolResultText(ev.result),
								isError: ev.isError === true,
								durationMs: Math.max(0, eventNow - pending.startedAt),
								order: pending.order,
							});
							if (ctx.toolExecutions.length > 64) ctx.toolExecutions.shift();
						}
					} else if (ev.type === "message_end" && ev.message?.role === "assistant" && ctx.msgStartTs) {
						ctx.thinkMs += eventNow - ctx.msgStartTs;
						ctx.msgStartTs = undefined;
					} else if (ev.type === "compaction_end") {
						// B0-1（附录 B.1）：压缩模型用量累计——compaction_end 是 NOISE_LINE_RE 噪音行，
						// processLine 不会收到（本 block 是唯一遍历全部行（含噪音）的位置）；与 assistant/nested
						// 分栏单列，不计成工作模型调用。无 result.usage 的宿主如实缺席（未覆盖，不冒充 0）。
						const fig = readUsageFigures((ev as { result?: { usage?: unknown } }).result?.usage);
						if (fig) {
							if (!ctx.compactionUsage) ctx.compactionUsage = newUsageTotals();
							addUsageFigures(ctx.compactionUsage, fig);
							ctx.compactionEvents++;
						}
					} else if (ev.type === "session" && typeof ev.id === "string" && ev.id && !sessionJournaled) {
						// ev-20260903-a5b662：sessionId 见证早落盘——首帧 session 事件即写 journal，使宿主级联
						// 终止（被杀任务无 artifact metadata）后 resume 有磁盘真相可回填；失败静默（可观测性非正确性）。
						sessionJournaled = true;
						obsRelay?.emit({ kind: "session", sessionId: ev.id }); // K4：会话建立观察（恰好一次，与 journal 同门）
						try { journalSession({ taskId, sessionId: ev.id }); } catch { /* 静默 */ }
					} else if (ev.type === "auto_retry_start") {
						ctx.retryAttempts++;
						const delay = Number(ev.delayMs);
						if (Number.isFinite(delay) && delay > 0) ctx.retryWaitMs += delay;
						// 复盘 §5#3：重试退避窗口内静默抑制停滞告警（delay 缺省按 120s 估 + 30s 余量）。
						retryQuietUntil = Math.max(retryQuietUntil, Date.now() + (Number.isFinite(delay) && delay > 0 ? delay : 120_000) + 30_000);
					}
					if (ev.type === "message_end" && ev.message) chunkDirty = true;
					// v1.5.182 事件白名单：流式生命周期事件（message_update/turn_start 等）是高频噪音，
					// 会挤掉有意义的活动条目（实战：4 个 baize 面板全部只显示 message_update/turn_start）
					const t = String(ev.type ?? "");
					if (!ACTIVITY_NOISE.has(t)) {
						let sm: string;
						if (t === "message_end") {
							const parts = Array.isArray(ev.message?.content) ? ev.message.content : [];
							const tools = parts.filter((p: any) => p?.type === "toolCall" && typeof p.name === "string").map((p: any) => p.name);
							// 工具帧优先显示工具名（面板一眼看到"在干什么"），文本帧取首 80 字
							sm = tools.length
								? `调用工具: ${[...new Set(tools)].join(", ")}`.slice(0, 120)
								: String(parts.filter((p: any) => p?.type === "text").map((p: any) => p?.text ?? "").join("")).replace(/\s+/g, " ").trim().slice(0, 80);
						} else if (t === "tool_execution_start" || t === "tool_execution_end") {
							if (t === "tool_execution_end") void auditor?.sample(true);
							const nm = typeof ev.toolName === "string" ? ev.toolName : (typeof ev.name === "string" ? ev.name : "?");
							const argSrc = ev.args && typeof ev.args === "object" ? (ev.args.command ?? ev.args.path ?? ev.args.file_path ?? "") : "";
							const arg = String(argSrc || "").replace(/\s+/g, " ").trim();
							const duration = t === "tool_execution_end" && typeof ev.durationMs === "number" && Number.isFinite(ev.durationMs) && ev.durationMs >= 0
								? ` execute=${Math.round(ev.durationMs)}ms` : "";
							sm = `${t === "tool_execution_start" ? "执行" : "完成"}: ${nm}${arg ? ` ${arg.slice(0, 40)}` : ""}`.slice(0, 120 - duration.length) + duration;
						} else if (t === "session") sm = "会话开始";
						else sm = t;
						// K4：观察模式活动摘要经 sink（限流沿用 ACTIVITY_NOISE 白名单与摘要上限——§3.4 分层：仅内核内存 ring）；
						// ev-20261019-06c169：默认观察模式下同步保留 registry 活动登记（面板/看板消费 activityWindow，
						// 迁移期兼容投影不因默认接管而断流）；显式 target（适配器）保持仅 sink。
						if (obsRelay) {
							obsRelay.emit({ kind: "activity", note: `${t}: ${sm}`.slice(0, 160) });
							if (!explicitObs) { try { registry.appendActivity(taskId, { type: t, summary: sm, ts: Date.now() }); } catch {} }
						} else registry.appendActivity(taskId, { type: t, summary: sm, ts: Date.now() });
					}
				}
			}
		return chunkDirty;
	};
	proc.stdout!.on("data", (data: Buffer) => {
		if (ctx.firstEventTs === undefined) {
			ctx.firstEventTs = Date.now();
			setTimeout(() => { void auditor?.sample(); }, 500).unref?.();
		}
		everActivity = true;
		lastActivity = Date.now();
		execSilentMs = 0;
		buffer += data.toString();
		const lines = buffer.split("\n");
		buffer = lines.pop() || "";
		let chunkDirty = false;
		for (const line of lines) chunkDirty = consumeLine(line) || chunkDirty;
		// Wave C2 写入路径可观测：本 chunk 核销的写盘目标实时入 registry（供 running 态查询/冲突提示）
		drainWritePaths(ctx, taskId, opts.cwd);
		// v1.5.181 onUpdate 回流（节流；新 assistant 帧（dirty）必发，保证每个进展可见）
		if (opts.onUpdate) {
			const now = Date.now();
			if (chunkDirty || now - lastEmit >= UPDATE_THROTTLE_MS) {
				lastEmit = now;
				const rec = registry.get(taskId);
				const acts = rec?.activityWindow ?? [];
				const lastAct = acts.length ? acts[acts.length - 1] : null;
				const tail = getFinalOutput(ctx.messages);
				const elapsed = Math.max(0, Math.round((now - (rec?.startedAt || now)) / 1000));
				const text = `[task ${taskId.slice(0, 8)} ${agent.name} · 运行中 ${elapsed}s]${lastAct ? ` 最近: ${lastAct.summary || lastAct.type}` : " 等待首个动作…"}${tail ? `\n\n…${tail.slice(-1500)}` : ""}`;
				try { opts.onUpdate({ content: [{ type: "text", text }] }); } catch {}
			}
		}
	});
	proc.stderr!.on("data", (data: Buffer) => { everActivity = true; stderrBuf += data.toString(); if (stderrBuf.length > STDERR_TAIL * 4) stderrBuf = stderrBuf.slice(-STDERR_TAIL * 2); });

	// ── background 模式：立即返回 ──
	if (opts.background) {
		proc.on("error", (err: Error) => { ctx.spawnError = diagnoseSpawnFailure(err, invocation.command, opts.cwd); void finalize(1, null); });
		proc.on("close", (code, signal) => { void finalize(code, signal); });
		return { taskId, agent: agent.name, status: "running", sessionName, fuseWarning: opts.fuseWarn || "" };
	}

// ── sync 模式：await close ──
	// 等待期间登记 sync-wait——自定义 task 虽有 tool_execution_start/end 边界事件，长等待期
	// 未必持续发 update；用领域计数避免 watchdog 把健康的分钟级同步派发误判为沉默挂起。
	beginSyncWait();
	try {
		const result = await new Promise<RunResult>((resolve) => {
			proc.on("error", async (err: Error) => { ctx.spawnError = diagnoseSpawnFailure(err, invocation.command, opts.cwd); resolve(await finalize(1, null)); });
			proc.on("close", async (code, signal) => resolve(await finalize(code, signal)));
		});
		return result;
	} finally {
		endSyncWait();
	}
}

// ── P15-4: stats（token usage/cost 写 data/agent-stats.ndjson） ──────────────
// P1-5: stats 路径可注入（AMAGI_STATS_PATH 环境变量；测试/probe 指向临时路径，不触碰真实 data/）
function statsFile(): string {
	// 每次写入时读取，测试可在第一次 write 前注入；默认新扩展名避免破坏历史 JSON array。
	// E2: 默认路径迁至 <amagiDataDir>/agent-stats.ndjson（pi update 不再清空）。
	return process.env.AMAGI_STATS_PATH || amagiDataFile("agent-stats.ndjson");
}

function finiteNumber(value: unknown): number | undefined {
	return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

// ── v1.0.4: webui usage 数据面监听器（writeStats 漏斗分流） ──────────────────
// writeStats 是所有子任务 usage 落盘的唯一漏斗；webui 在扩展装配点（index.ts 调用
// registerWebUi 处）经 setStatsListener 注册消费同一 entry——不改 writeStats 签名与
// 调用方。传原始 entry 引用：有限值过滤由监听器侧（UsageStore）自行执行。

/** B0-1（附录 B.1）：agent-stats v2 行——累计口径字段（usageScope/assistantCalls/首末上下文/分栏/身份）。
 *  独立接口：RunResult._statsPayload 与 writeStats 入口共用；旧调用方缺省字段仍兼容（全部可选）。 */
export interface CumulativeStatsEntry {
	taskId: string;
	agent: string;
	model?: string;
	status: string;
	input?: number;
	output?: number;
	cacheRead?: number;
	cacheWrite?: number;
	cost?: number;
	rounds?: number;
	durationMs?: number;
	thinkMs?: number;
	toolMs?: number;
	retryAttempts?: number;
	retryWaitMs?: number;
	startupMs?: number;
	/** v2 新字段（附录 B.1）。 */
	usageScope?: "cumulative";
	assistantCalls?: number;
	usageMissingCalls?: number;
	firstCallContext?: number;
	lastCall?: CallUsage;
	nestedUsage?: UsageFigures;
	compactionUsage?: UsageFigures;
	leaderSession?: string;
	runKey?: string;
	preflightBytes?: number;
	/** F2（diting，附录 B.1）：分模型小计贯通到 stats 行（多轮聚合时携带；读侧按实际模型拆桶）。 */
	modelSubtotals?: ReadonlyArray<TraceModelSubtotal>;
	usageCoverage?: string;
}

export interface StatsListenerEntry {
	taskId: string; agent: string; model?: string; status: string;
	input?: number; output?: number; cacheRead?: number; cacheWrite?: number;
	/** B0-1：累计口径行携带（usage-store 语义升级：一行=一次运行累计，requests 按调用数入账）。 */
	usageScope?: "cumulative";
	/** 本行 assistant 完结事件数（缺省=1——旧调用面/末轮旧行兼容）。 */
	calls?: number;
}
let statsListener: ((entry: StatsListenerEntry) => void) | undefined;

/** 注册/替换（传 undefined 清除）writeStats 漏斗监听器；返回被替换的前一个监听器。 */
export function setStatsListener(fn: ((entry: StatsListenerEntry) => void) | undefined): ((entry: StatsListenerEntry) => void) | undefined {
	const previous = statsListener;
	statsListener = fn;
	return previous;
}

// ── B0-2（webui 编排面板）：子任务实时上下文 token 只读投影 ─────────────────
// consumeLine 在 assistant 完结帧入账 usage 后，把该任务最近一次模型调用的
// input+cacheRead+cacheWrite 三分项和写入本表（与 Batch 0 lastCall 同口径）；index.ts 装配点
// 经 liveContextTokensOf 注入 buildTaskPanel 选项。刻意不进 registry/内核（纯观测面：不推进
// 状态、不落盘、不受终态写保护约束；条目随会话进程存活，量级=会话任务数×一个数字）。
const liveContextTokens = new Map<string, number>();
/** F8（diting）：有界缓存上限——纯观测面不随会话无限增长；超限逐出最早插入的条目。 */
const LIVE_CONTEXT_TOKENS_MAX = 1024;

/** B0-2 补链：上下文 token 观测通知（webui 编排面板重发驱动）。consumeLine 的 lastCall
 * 三分项和入账时经 recordLiveContextTokens 触发——此前面板快照仅 registry.onChange 发布，
 * running 长任务状态不变而上下文持续增长 → 占比环不动/迟现。观测面约定同 statsListener：
 * 异常静默、绝不反噬任务主流程；装配点（index.ts webui 段）注册并节流重发。 */
let panelContextListener: ((taskId: string, tokens: number) => void) | undefined;

/** 注册/替换（传 undefined 清除）面板上下文观测监听器；返回被替换的前一个监听器。 */
export function setPanelContextListener(fn: ((taskId: string, tokens: number) => void) | undefined): ((taskId: string, tokens: number) => void) | undefined {
	const previous = panelContextListener;
	panelContextListener = fn;
	return previous;
}

/** 只读查询：该任务最近一次观测到的上下文 token 数；未观测=undefined（不冒充 0）。 */
export function liveContextTokensOf(taskId: string): number | undefined {
	return liveContextTokens.get(taskId);
}

/** 更新（consumeLine 唯一写方；非有限/负值/空 taskId 丢弃）。F8：先删后插保持最近更新
 *  在尾（近似 LRU），超上限逐出最早插入条目（记录未观测任务下限诚实——回退 undefined）。 */
export function recordLiveContextTokens(taskId: string, tokens: number): void {
	if (typeof taskId !== "string" || taskId === "" || !Number.isFinite(tokens) || tokens < 0) return;
	liveContextTokens.delete(taskId);
	liveContextTokens.set(taskId, tokens);
	if (liveContextTokens.size > LIVE_CONTEXT_TOKENS_MAX) {
		const oldest = liveContextTokens.keys().next().value;
		if (typeof oldest === "string") liveContextTokens.delete(oldest);
	}
	try { panelContextListener?.(taskId, tokens); } catch { /* lint-exempt:观测通知面不反噬主流程（同 statsListener 口径） */ }
}

export function writeStats(entry: CumulativeStatsEntry): void {
	try {
		// 单行先有界化，保证并发 append 保持“一次小写入=一条完整记录”。
		// B0-1（附录 B.1）：formatVersion 2——累计口径行（usageScope=cumulative + 新字段；
		// 旧 v1 行读侧按 last-call 单独分组，不与新行混加）。
		const bounded = {
			formatVersion: 2,
			usageScope: "cumulative" as const,
			taskId: capUtf8(String(entry.taskId), 256).split("\n\n[输出截断")[0],
			agent: capUtf8(String(entry.agent), 128).split("\n\n[输出截断")[0],
			model: entry.model === undefined ? undefined : capUtf8(String(entry.model), 256).split("\n\n[输出截断")[0],
			status: capUtf8(String(entry.status), 32).split("\n\n[输出截断")[0],
			input: finiteNumber(entry.input), output: finiteNumber(entry.output),
			cacheRead: finiteNumber(entry.cacheRead), cacheWrite: finiteNumber(entry.cacheWrite),
			cost: finiteNumber(entry.cost),
			assistantCalls: finiteNumber(entry.assistantCalls), usageMissingCalls: finiteNumber(entry.usageMissingCalls),
			firstCallContext: finiteNumber(entry.firstCallContext),
			lastCall: entry.lastCall === undefined ? undefined : {
				input: finiteNumber(entry.lastCall.input), output: finiteNumber(entry.lastCall.output),
				cacheRead: finiteNumber(entry.lastCall.cacheRead), cacheWrite: finiteNumber(entry.lastCall.cacheWrite),
				cost: finiteNumber(entry.lastCall.cost),
				...(typeof entry.lastCall.stopReason === "string" ? { stopReason: capUtf8(entry.lastCall.stopReason, 64).split("\n\n[输出截断")[0] } : {}),
			},
			nestedUsage: entry.nestedUsage === undefined ? undefined : {
				input: finiteNumber(entry.nestedUsage.input), output: finiteNumber(entry.nestedUsage.output),
				cacheRead: finiteNumber(entry.nestedUsage.cacheRead), cacheWrite: finiteNumber(entry.nestedUsage.cacheWrite), cost: finiteNumber(entry.nestedUsage.cost),
			},
			compactionUsage: entry.compactionUsage === undefined ? undefined : {
				input: finiteNumber(entry.compactionUsage.input), output: finiteNumber(entry.compactionUsage.output),
				cacheRead: finiteNumber(entry.compactionUsage.cacheRead), cacheWrite: finiteNumber(entry.compactionUsage.cacheWrite), cost: finiteNumber(entry.compactionUsage.cost),
			},
			leaderSession: entry.leaderSession === undefined ? undefined : capUtf8(String(entry.leaderSession), 512).split("\n\n[输出截断")[0],
			runKey: entry.runKey === undefined ? undefined : capUtf8(String(entry.runKey), 256).split("\n\n[输出截断")[0],
			// F2（diting）：分模型小计贯通落盘（有界：≤16 桶×短串，非有限分项剔除保持未知）。
			modelSubtotals: entry.modelSubtotals === undefined ? undefined : entry.modelSubtotals.slice(0, 16).map((st) => ({
				model: capUtf8(String(st.model ?? ""), 256).split("\n\n[输出截断")[0],
				input: finiteNumber(st.input), output: finiteNumber(st.output),
				cacheRead: finiteNumber(st.cacheRead), cacheWrite: finiteNumber(st.cacheWrite),
				cost: finiteNumber(st.cost),
				assistantCalls: finiteNumber(st.assistantCalls),
				runs: finiteNumber(st.runs),
				coverage: st.coverage === "partial" ? "partial" : "complete",
			})).filter((st) => st.model !== ""),
			preflightBytes: finiteNumber(entry.preflightBytes),
			usageCoverage: entry.usageCoverage === undefined ? undefined : capUtf8(String(entry.usageCoverage), 128).split("\n\n[输出截断")[0],
			rounds: finiteNumber(entry.rounds), durationMs: finiteNumber(entry.durationMs),
			thinkMs: finiteNumber(entry.thinkMs), toolMs: finiteNumber(entry.toolMs),
			retryAttempts: finiteNumber(entry.retryAttempts), retryWaitMs: finiteNumber(entry.retryWaitMs),
			startupMs: finiteNumber(entry.startupMs), at: Date.now(),
		};
		// Batch 3（§9.5 成本进入 footer）：终值只读登记——footer 读侧单一来源（runKey 对账一次；
		// 装配点纯读渲染不重算累计）。放在 bounded 构造后、落盘前：磁盘写失败不丢登记（聚合终值已存在，
		// 与监听器同语义的观测面）；不改本函数任何写入语义（落盘行与监听器 payload 与接入前逐字节一致）。
		try { recordUsageFooterRow(bounded); } catch { /* lint-exempt:footer 终值登记观测面绝不反噬 writeStats */ }
		const line = JSON.stringify(bounded) + "\n";
		const file = statsFile();
		const dir = path.dirname(file);
		fs.mkdirSync(dir, { recursive: true });
		fs.appendFileSync(file, line, { encoding: "utf8", mode: 0o600 });
	} catch {
		// 容错：不可写时静默（OpenCode 教训 #6）
	}
	// v1.0.4：通知 webui usage 监听器。放 try 外——磁盘不可写不阻断内存聚合；
	// 监听器自身异常也吞掉（观测面绝不反噬主流程）。B0-1：携带 calls（一行=一次运行累计，
	// requests 按调用数入账；旧调用面缺省回退 1）。
	try { statsListener?.({ ...entry, calls: entry.assistantCalls ?? 1 }); } catch { /* 静默 */ }
}

// ── P15-4: shutdown 清理（真实 close 判定，SIGTERM→grace→SIGKILL） ───────────
function childExited(child: any): boolean {
	return child?.exitCode !== null && child?.exitCode !== undefined
		|| child?.signalCode !== null && child?.signalCode !== undefined;
}

function childClosed(child: any): boolean {
	return !!child && typeof child === "object" && CLOSED_CHILDREN.has(child);
}

function waitChildClose(child: any, timeoutMs?: number): Promise<boolean> {
	if (childClosed(child)) return Promise.resolve(true);
	return new Promise((resolve) => {
		let settled = false;
		const finish = (closed: boolean) => {
			if (settled) return;
			settled = true;
			if (timer) clearTimeout(timer);
			child?.removeListener?.("close", onClose);
			resolve(closed);
		};
		const onClose = () => finish(true);
		const timer = timeoutMs === undefined ? undefined : setTimeout(() => finish(childClosed(child)), timeoutMs);
		child?.once?.("close", onClose);
	});
}

export interface ShutdownCleanupDeps {
	/** 精确内核出生身份读取（默认真实探针；测试注入用）。 */
	readIdentities?: (pids: readonly number[]) => Map<number, KernelProcessIdentity>;
}

/**
 * ev-20261008-30e744（R2）：shutdown 对直接子进程的每个信号（TERM/KILL）逐信号新核验精确出生
 * 身份（spawn 时定格 token vs 当前内核身份）。无身份面（legacy/外来 child）、token 未知（探针
 * 不可用/未完成）或已改变（无法排除 PID 复用）→ 明确拒绝并落审计证据，绝不自学当前身份；
 * 数值 PID 从查询到发信号存在非原子窗口，这里是保守 best-effort，不构成原子句柄保证。
 * 返回是否已发信号（调用方仅对已发信号者等待 close；拒绝者不等待，避免 shutdown 悬挂）。
 */
async function verifiedShutdownSignal(child: any, taskId: string, signal: NodeJS.Signals, deps: ShutdownCleanupDeps): Promise<boolean> {
	const pid = child?.pid;
	const auditPath = amagiDataFile("process-audits", taskId.replace(/[^a-zA-Z0-9_-]/g, "_"), "shutdown-signal-audit.json");
	const record = (decision: string, rootBirth?: string): void => {
		let events: unknown[] = [];
		try { events = JSON.parse(fs.readFileSync(auditPath, "utf8")).events ?? []; } catch { /* 首次写入 */ }
		events.push({ at: Date.now(), signal, decision, ...(rootBirth !== undefined ? { rootBirth } : {}) });
		try {
			fs.mkdirSync(path.dirname(auditPath), { recursive: true, mode: 0o700 });
			fs.writeFileSync(auditPath, JSON.stringify({ version: 1, taskId, reason: "shutdown", rootPid: pid, events, identityMethod: "pid+kernel birth token captured at spawn; rechecked before each signal; not an atomic handle" }, null, 2) + "\n", { mode: 0o600 });
		} catch { /* lint-exempt:signal safety never depends on log success */ }
	};
	if (!Number.isInteger(pid) || pid <= 1 || childExited(child)) { record("skip: child exited or invalid pid"); return false; }
	const face = (child as any).__amagiOwnedRootBirth as (() => Promise<string | undefined>) | undefined;
	if (typeof face !== "function") {
		record("skip: no spawn birth identity face (legacy or foreign child) — signal refused; identity is never self-learned at shutdown");
		return false;
	}
	let rootBirth: string | undefined;
	try { rootBirth = await face(); } catch { /* lint-exempt:身份未知不授权信号 */ rootBirth = undefined; }
	if (!rootBirth) {
		record("skip: root birth token unknown (probe unavailable or pending) — signal refused; live child left running, bounded handover NOT implemented this round (ev-20261008-30e744; needs Leader handover decision)");
		return false;
	}
	let fresh: KernelProcessIdentity | undefined;
	try { fresh = (deps.readIdentities ?? readKernelProcessIdentities)([pid]).get(pid); }
	catch { /* lint-exempt:probe failure cannot authorize a signal */ fresh = undefined; }
	if (!fresh || fresh.identityToken !== rootBirth) { record("skip: root identity changed or unverifiable (possible PID reuse)", rootBirth); return false; }
	try {
		if (!child.kill(signal)) { record("signal failed", rootBirth); return false; }
		record("sent to verified root", rootBirth); return true;
	}
	catch { /* journal:shutdown-verified-signal-failed */ record("signal failed", rootBirth); return false; }
}

export async function cleanupChildrenOnShutdown(graceMs = 2000, deps: ShutdownCleanupDeps = {}): Promise<void> {
	const running = registry.getRunningChildren();
	const children = running.map(({ child }) => child);
	for (let i = 0; i < running.length; i++) {
		const child = children[i];
		// 5d0ef1：优先组级终止入口（幂等；自带 SIGTERM→3s→SIGKILL 收口）；非组模式维持 child 级。
		const term = (child as any)?.__amagiTerminateOwnedRun as ((reason: string) => void) | undefined;
		if (typeof term === "function") { try { term("shutdown"); continue; } catch {} }
		// ev-20261008-30e744（R2）：非组模式真实 run 的直接子进程 TERM 同样逐信号新核验；
		// 无身份面/token 未知/身份改变一律明确拒绝（legacy 裸 TERM→KILL 路径退役）。
		await verifiedShutdownSignal(child, running[i].taskId, "SIGTERM", deps);
	}
	const graceful = await Promise.all(children.map((child) => waitChildClose(child, graceMs)));
	const pendingClose: any[] = [];
	for (let i = 0; i < children.length; i++) {
		if (graceful[i]) continue;
		// KILL 升级同样逐信号新核验（组模式/非组模式/legacy 全路径一致）；拒绝即不等待 close
		// （不悬挂），活进程交接（R1）本轮未实现——保持冻结，由 Leader 决策。
		if (await verifiedShutdownSignal(children[i], running[i].taskId, "SIGKILL", deps)) pendingClose.push(children[i]);
	}
	// child.killed 仅表示 signal 已发送；必须等待 close 证据（仅对已发信号者）。
	await Promise.all(pendingClose.map((child) => waitChildClose(child)));
}

// ── P15-4: registry 持久化 snapshot（appendEntry） ───────────────────────────
export function snapshotForPersist(pi: ExtensionAPI | undefined): void {
	if (!pi?.appendEntry) return;
	try {
		pi.appendEntry("amagi:task-registry", registry.snapshot());
	} catch {}
}
