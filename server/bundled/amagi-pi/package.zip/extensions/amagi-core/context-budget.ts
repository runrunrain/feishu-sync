/**
 * context-budget.ts — 派发前 context 预算预估（P3-B：2026-08-19 插件进化，整段拆分自 task-tool.ts L1352-1411）。
 * 原段（2026-08-16 复盘 P0-2：401 上下文上限死派发前置拦截）注释随段整体搬移，函数体零改动。
 * task-tool.ts re-export 三个导出函数（contextWindowOf/contextBudgetReject/resumeBudgetReject），公共面冻结。
 * ev-20260910-2899d3（B）：resume 超预算拒单自动接力包 buildResumeRelayPack——拒单点已持有 prev 全量
 * 记录（goal/rounds/lastWritePaths/result/cwd），此前只回两条文字建议，Leader 需手工盘点+重写任务书。
 * 四要素：原任务书摘要 / 已落盘产物清单（mtime+own·sib 归因）/ 中断状态 / 可复制改派的 fresh 任务书模板。
 * 纯输出增强：只读（statSync mtime + readTaskWrites + registry 同批兄弟扫描），不派发不写盘、缺省零变化。
 * ev-20260910-352a91：磁盘回填记录（adoptExternal）丢 goal/rounds 时原任务书为空——改为只读回读
 * journal dispatch 链（spawn 前落盘的任务书留档，上限 4000 字）回填 goal 与派发轮次；连 journal
 * 也无记录时保持原「未留档」降级文案（不虚构）。ev-20260914-ce6bd2：读到截断留档时追加独立一行
 * 标注（完整版见会话 JSONL；建议 resume 接力而非凭截断版重写）。
 */
import * as fs from "node:fs";
import * as path from "node:path";
import * as piHost from "@earendil-works/pi-coding-agent";
import type { TaskSpec } from "./contracts/task.ts";
import { stripModelThinkingSuffix, type ModelRegistryLike } from "./model-resolver.ts";
import { locateSessionJsonl } from "./session-repair.ts";
import { readTaskWrites } from "./task-write-log.ts";
import { registry, type TaskRecord } from "./task-registry.ts";
import { journalLookupChain, type JournalChainHit } from "./journal.ts";
import { isParallelSiblingRecord } from "./evidence.ts";

// ── 2026-08-16 复盘 P0-2：派发前 context 预算预估（401 上下文上限死派发前置拦截）──
// 实战（复盘 P2-D）：luoshen 401 context 上限留半成品，恢复链燒 3 派发当量。子 Agent 模型
// 与 Leader 不同（tiered profile 小窗角色），Leader 对自己的上下文无感——派发前用
// modelRegistry 的 contextWindow 真值 ×预算比对任务文本体积，超限拒单并给恢复优先级。
// 字节估算并非 tokenizer，也不是原生压缩阈值。默认交由 pi 管理上下文与自动压缩；
// 只有显式 AMAGI_CTX_BUDGET_RATIO>0 才启用派发前的粗略检查，不作为任务 token/成本配额。

const BYTES_PER_TOKEN_APPROX = 4;
function ctxBudgetRatio(): number {
	// 未设/非法/0 → 关闭；显式 N>0 → opt-in 粗略检查。
	const raw = process.env.AMAGI_CTX_BUDGET_RATIO;
	if (raw === undefined || raw === "") return 0;
	const v = Number(raw);
	return Number.isFinite(v) && v >= 0 ? v : 0;
}

/** 模型上下文窗口（token 数；registry 未注册/无字段 → undefined，不做预算拒单）。 */
export function contextWindowOf(modelRegistry: ModelRegistryLike | undefined, spec: string | undefined): number | undefined {
	if (!modelRegistry || !spec) return undefined;
	const slash = spec.indexOf("/");
	if (slash <= 0) return undefined;
	const provider = spec.slice(0, slash);
	const model = stripModelThinkingSuffix(spec).slice(slash + 1);
	try {
		const found = modelRegistry.find(provider, model);
		if (found && typeof found === "object") {
			const cw = (found as { contextWindow?: unknown }).contextWindow;
			if (typeof cw === "number" && cw > 0) return cw;
		}
	} catch { /* find 异常按未知处理 */ }
	return undefined;
}

/** 派发前预算检查：任务文本超窗预算 → 拒单文案；未超/无法判定 → null（放行）。 */
export function contextBudgetReject(taskText: string, spec: string | undefined, modelRegistry: ModelRegistryLike | undefined): string | null {
	const ratio = ctxBudgetRatio();
	if (ratio <= 0) return null;
	const cw = contextWindowOf(modelRegistry, spec);
	if (!cw) return null;
	const estBytes = Buffer.byteLength(taskText, "utf8");
	const budgetBytes = Math.floor(cw * BYTES_PER_TOKEN_APPROX * ratio);
	if (estBytes <= budgetBytes) return null;
	return `[context 预算拒单] 任务文本约 ${(estBytes / 1024).toFixed(0)}KB，超过模型 ${spec} 上下文窗口（${cw} tokens）派发预算 ${Math.round(ratio * 100)}%（约 ${(budgetBytes / 1024).toFixed(0)}KB）——直接派发大概率 401/上下文超限死派发。请：a) 拆成更小的独立任务（各节点自读文件）；b) 换大上下文模型（model 参数或 amagi.json 覆盖）；c) 缩减任务内粘贴的文件内容，改用路径引用让子 Agent 自行探索。`;
}

/** 只读原生当前分支投影，尊重 compaction/context_edit。旧宿主或不完整历史返回 null，
 *  由调用方保留文件体积的保守检查；禁止 SessionManager.open 对源历史执行隐式迁移。 */
function resumeProjectionBytes(file: string): number | null {
	try {
		if (typeof piHost.parseSessionEntries !== "function" || typeof piHost.buildSessionProjection !== "function") return null;
		const raw = fs.readFileSync(file, "utf8");
		for (const line of raw.split("\n")) if (line.trim()) JSON.parse(line);
		const parsed = piHost.parseSessionEntries(raw);
		const header = parsed.find((entry) => entry.type === "session");
		if (!header || header.version !== 3) return null;
		const entries = parsed.filter((entry): entry is import("@earendil-works/pi-coding-agent").SessionEntry => entry.type !== "session");
		const ids = new Set<string>();
		for (const entry of entries) {
			if (typeof entry.id !== "string" || ids.has(entry.id) || (entry.parentId !== null && !ids.has(entry.parentId))) return null;
			ids.add(entry.id);
		}
		return Buffer.byteLength(JSON.stringify(piHost.buildSessionProjection(entries).messages), "utf8");
	} catch { return null; /* lint-exempt:无法验证原生投影时保守估算磁盘体积，不裁剪/改写源文件 */ }
}

/** resume 原生有效上下文超窗预算 → 拒单文案（恢复指引）；否则 null。
 *  ev-20260910-2899d3：可选 prev（拒单点的原任务记录）——携带时拒单文案后接自动接力包
 *  （buildResumeRelayPack）；缺省不接，旧调用方输出零变化（公共面兼容扩展）。 */
export function resumeBudgetReject(sessionId: string, spec: string | undefined, modelRegistry: ModelRegistryLike | undefined, cwd?: string, prev?: Readonly<TaskRecord>, sourceSpec?: Readonly<TaskSpec>): string | null {
	const ratio = ctxBudgetRatio();
	if (ratio <= 0) return null;
	const cw = contextWindowOf(modelRegistry, spec);
	if (!cw) return null;
	const file = locateSessionJsonl(sessionId, cwd ? { cwd } : undefined);
	if (!file) return null; // 定位不到不阻断（磁盘真相缺失时交由运行时如实报错）
	let size: number;
	try { size = fs.statSync(file).size; } catch { return null; }
	const budgetBytes = Math.floor(cw * BYTES_PER_TOKEN_APPROX * ratio);
	const projectionBytes = resumeProjectionBytes(file);
	const estimatedBytes = projectionBytes ?? size;
	if (estimatedBytes <= budgetBytes) return null;
	// ev-20260910-2899d3：调用方携带 prev（task-resume 拒单点持有原记录）时，拒单文案后接自动
	// 接力包（四要素盘点 + 可复制 fresh 任务书）；未携带（旧调用方/纯函数调用）输出零变化。
	const estimate = projectionBytes !== null ? `原生有效上下文 ${path.basename(file)} 约 ${(estimatedBytes / 1024).toFixed(0)}KB` : `无法验证原生投影，会话文件 ${path.basename(file)} 约 ${(size / 1024).toFixed(0)}KB，按文件体积保守预算`;
	const base = `[context 预算拒单] ${estimate}，超过模型 ${spec} 上下文窗口（${cw} tokens）派发预算 ${Math.round(ratio * 100)}%（约 ${(budgetBytes / 1024).toFixed(0)}KB）。请：a) 换大上下文模型 resume（model 参数）；b) 从父任务 artifact 接力 fresh 派发（上下文不回放，只带结论）。`;
	return prev ? `${base}\n${buildResumeRelayPack(prev, file, size / 1024, sourceSpec)}` : base;
}

// ── ev-20261002-c2b7ad（friction/P1）：接力包产物化 + task_submit 参数草稿 ──────
// 实战（2026-09-30 任务框架 demo 会话）：fuxi（1529KB）/luban P8b（3106KB）两次 resume 拒单，
// 接力包四要素已在拒单消息内展示，但它是一过性错误文本——Leader 需从错误消息里手工转写
// task_submit 参数（agent/任务书/workspace 组装），且消息沉入会话历史后无 artifact 可回溯。
// 两层增强（纯函数层保持只读：写盘由调用方 task-resume 拒单点执行）：
//  ① renderRelaySubmitDraft：把任务书模板渲染为预填 task_submit 参数草稿（agent/cwd 预填，
//     确认或微调后提交）；
//  ② persistResumeRelayPack：接力包全文写盘 agent-outs 可回溯（同任务幂等覆盖，异常零故障放大）。

/** task_submit 草稿：预填 agent/cwd 的参数形态渲染（供拒单消息尾部与产物化落盘共用）。 */
export function renderRelaySubmitDraft(prev: Readonly<TaskRecord>): string {
	return [
		"▸ task_submit 草稿（预填，确认或微调后提交）：",
		"  task_submit({",
		`	  agent: "${prev.agent || "luban"}",`,
		"	  task: （上方「任务书（复制起点/终点）」段全文粘贴）", 
		`	  workspace: { cwd: "${prev.cwd || "（补全原任务工作目录）"}" },`,
		"	  // 视前次产物清单补充 inputs/outputs；model 不指定则按 profile 缺省", 
		"	})",
	].join("\n");
}

/** 接力包产物化：写盘 <cwd>/agent-outputs/resume-relay-<taskId>.md（幂等覆盖）；返回相对路径，
 *  异常/无 cwd 返回 null（拒单零故障放大防线——产物化失败不影响拒单语义）。 */
export function persistResumeRelayPack(prev: Readonly<TaskRecord>, packText: string): string | null {
	try {
		if (!prev?.taskId || !prev.cwd) return null;
		const dir = path.join(prev.cwd, "agent-outputs");
		fs.mkdirSync(dir, { recursive: true });
		const file = path.join(dir, `resume-relay-${prev.taskId}.md`);
		fs.writeFileSync(file, packText, "utf8");
		return path.join("agent-outputs", `resume-relay-${prev.taskId}.md`);
	} catch { return null; /* lint-exempt:产物化失败降级为仅消息展示——拒单零故障放大 */ }
}

// ── ev-20260910-2899d3（B）：resume 超预算接力包 ──────────────────────────────
// 实测痛点：拒单点已持有 prev.goal/rounds/lastWritePaths/result/cwd，拒单却只给两条文字建议，
// Leader 手工盘点+重写任务书每次 5~10 分钟且有漏细节风险。本段把「现场盘点 + 任务书草稿」
// 自动生成（见 reviews/evo4-优化设计方案-2026-09-10.md §B）。归因口径对齐 evidence.ts
// ev-20260907-e20971：登记 = 确认本任务写入（own）；lastWritePaths 仅轨迹观测（own·轨迹，弱
// 断言）；同 runId 兄弟登记/轨迹也写过 → 追加 ↔sib 标注（own 优先保留，不静默多方写入）。

/** 接力包：goal 摘要长度（字符）与终态输出摘要长度（字符）上限。 */
const RELAY_GOAL_SUMMARY_CHARS = 300;
const RELAY_RESULT_SUMMARY_CHARS = 200;
/** 产物清单展示上限（lastWritePaths ≤8 ∪ task-writes ≤512 差集仍可能几十条——有界展示，界外计数不静默）。 */
const RELAY_ARTIFACTS_MAX = 20;
/** 同批兄弟扫描上限（量级对齐 evidence.ts SIBLING_SCAN_MAX：有界 I/O，界外不扫）。 */
const RELAY_SIB_SCAN_MAX = 12;

function clipText(s: string, max: number): string {
	return s.length <= max ? s : `${s.slice(0, max)}…`;
}

/** 路径归一比较键（resolve；不做 symlink 折叠——宁可漏标 sib 不误标，口径同弱断言纪律）。 */
function relayPathKey(p: string): string {
	try { return path.resolve(p); } catch { return p; }
}

function fmtTs(ms: number): string {
	const d = new Date(ms);
	const p = (n: number): string => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

interface RelayArtifact {
	/** 展示/续做用原始路径（lastWritePaths 或登记原文）。 */
	file: string;
	/** 磁盘 mtime；stat 失败回退登记/轨迹时刻，均无 → null。 */
	mtimeMs: number | null;
	/** mtime 来源注记（stat=磁盘真相；登记=写盘时刻回退，弱断言）。 */
	mtimeSource: "stat" | "登记" | "无";
	/** 命中本任务 task-writes 登记（确认 own）；false = 仅 lastWritePaths 轨迹观测。 */
	registered: boolean;
	/** 同批兄弟（同 runId）也写过的标签（name/nodeId/taskId 前缀）。 */
	sibLabels: string[];
}

/** 收集已落盘产物：prev.lastWritePaths ∪ task-writes/taskId 差集（去重，lastWritePaths 优先序）+ mtime + own/sib 归因。 */
function collectRelayArtifacts(prev: Readonly<TaskRecord>): { artifacts: RelayArtifact[]; overflow: number } {
	// 本任务登记集（key → 最近一次写盘时刻，作 mtime 回退与 own 确认依据）
	const registered = new Map<string, number>();
	for (const w of readTaskWrites(prev.taskId)) registered.set(relayPathKey(w.file), w.at);
	// 同批兄弟写入证据（同 runId 兄弟的登记 ∪ lastWritePaths；口径同 evidence.ts collectSiblingWrites；
	// ev-20261108-m7（diting 审 m7）：无 runId 独立任务按「同 cwd + 运行窗口重叠」圈定（isParallelSiblingRecord
	// 单源）——与 evidence 侧归因口径对齐，此前 relay 无 runId 恒不圈兄弟，两处口径不一致。
	const sibWrites = new Map<string, string[]>();
	{
		let all: Readonly<TaskRecord>[];
		try { all = registry.list(); } catch { all = []; }
		for (const r of all.filter((x) => x.taskId !== prev.taskId && (prev.runId ? x.runId === prev.runId : isParallelSiblingRecord(prev, x))).slice(0, RELAY_SIB_SCAN_MAX)) {
			const label = r.name || r.nodeId || r.taskId.slice(0, 8);
			const files = new Set<string>();
			for (const w of readTaskWrites(r.taskId)) files.add(relayPathKey(w.file));
			for (const p of r.lastWritePaths ?? []) files.add(relayPathKey(p));
			for (const f of files) {
				const cur = sibWrites.get(f) ?? [];
				if (!cur.includes(label)) cur.push(label);
				sibWrites.set(f, cur);
			}
		}
	}
	// 并集去重：lastWritePaths（滚动最近 ≤8，无时刻字段）优先，再补登记差集
	const seen = new Set<string>();
	const artifacts: RelayArtifact[] = [];
	const push = (file: string): void => {
		const key = relayPathKey(file);
		if (seen.has(key)) return;
		seen.add(key);
		let mtimeMs: number | null = null;
		let mtimeSource: RelayArtifact["mtimeSource"] = "无";
		try { mtimeMs = fs.statSync(file).mtimeMs; mtimeSource = "stat"; } catch { /* 文件已不存在/不可达 → 回退登记时刻 */ }
		const regAt = registered.get(key);
		if (mtimeSource !== "stat" && regAt !== undefined) { mtimeMs = regAt; mtimeSource = "登记"; }
		artifacts.push({ file, mtimeMs, mtimeSource, registered: regAt !== undefined, sibLabels: sibWrites.get(key) ?? [] });
	};
	for (const p of prev.lastWritePaths ?? []) push(p);
	for (const key of registered.keys()) if (!seen.has(key)) push(key);
	const overflow = Math.max(0, artifacts.length - RELAY_ARTIFACTS_MAX);
	return { artifacts: artifacts.slice(0, RELAY_ARTIFACTS_MAX), overflow };
}

function relayArtifactLine(a: RelayArtifact): string {
	const own = a.registered ? "own" : "own·轨迹";
	const sib = a.sibLabels.length ? ` ↔sib:${a.sibLabels.join("+")}` : "";
	const mtime = a.mtimeMs !== null ? `mtime ${fmtTs(a.mtimeMs)}${a.mtimeSource !== "stat" ? `（${a.mtimeSource}）` : ""}` : "mtime 未知（文件已不在磁盘）";
	return `  - ${a.file}（${mtime}；${own}${sib}）`;
}

/**
 * ev-20260910-2899d3（B）：resume 超预算拒单接力包（纯输出增强，只读不写盘）。
 * 四要素：① 原任务书（record goal/rounds → 缺省回读 journal 派发链；前 300 字摘要+总字数）
 * ② 已落盘产物清单（lastWritePaths ∪ task-writes 差集，带 mtime，own/↔sib 归因）③ 中断状态
 * （status/result 摘要截断 200 字）④ 可直接复制改派的 fresh 任务书模板（原 goal + 半成品核对段
 * + 清单 + 缺省 cwd/model）。
 * sessionFile/sizeKB 由拒单点透传（拒单文案已含体积结论，此处补「历史保留在磁盘」指引）。
 * ev-20260910-352a91：①/③ 的 goal/rounds 缺档时经 journalLookupChain 只读回读（任务书留档
 * 上限 4000 字，命中上限时如实标注截断）；journal 无记录 → 维持原「未留档」降级。
 */
export function buildResumeRelayPack(prev: Readonly<TaskRecord>, sessionFile: string | null, sizeKB: number, sourceSpec?: Readonly<TaskSpec>): string {
	// ① 原任务书：当前冻结契约 assignment 全文优先；旧记录才回退 goal/rounds/journal。
	// sourceSpec 由已验证的恢复入口交付，任务标识不符时不能借用其他任务的资料。
	const frozenGoal = sourceSpec?.specId === prev.taskId ? sourceSpec.assignment : "";
	// 旧记录 goal（create 定格，≤2048B）；磁盘回填记录可能缺 goal → 回退最后轮次 task；
	// 两者皆空（ev-20260910-352a91 实战：宿主级联中断后 adoptExternal 回填丢 goal/rounds）→ 只读
	// 回读 journal dispatch 链（spawn 前落盘的任务书留档）回填；仍未命中则维持「未留档」真实降级。
	const lastRoundTask = prev.rounds?.length ? prev.rounds[prev.rounds.length - 1].task : "";
	const recordGoal = frozenGoal || prev.goal || lastRoundTask || "";
	const recordRounds = prev.rounds?.length ?? 0;
	let journalChain: JournalChainHit | null = null;
	if (!recordGoal || recordRounds === 0) {
		try {
			journalChain = journalLookupChain(prev.taskId, { sessionId: prev.sessionId, name: prev.name, runId: prev.runId, nodeId: prev.nodeId });
		} catch { journalChain = null; } // 回读是增强不是依赖：异常按未命中降级
	}
	const goal = recordGoal || journalChain?.goal || "";
	const goalFromJournal = !recordGoal && !!journalChain?.goal;
	const journalGoalTaskId = journalChain?.goalTaskId;
	const goalMeta = [
		frozenGoal ? "冻结任务契约全文" : "",
		goalFromJournal ? `journal 派发链回读${journalGoalTaskId && journalGoalTaskId !== prev.taskId ? `（源 taskId ${journalGoalTaskId.slice(0, 8)}）` : ""}` : "",
		`共 ${goal.length} 字${goal.length > RELAY_GOAL_SUMMARY_CHARS ? `，前 ${RELAY_GOAL_SUMMARY_CHARS} 字` : ""}`,
	].filter(Boolean).join(" · ");
	// ev-20260914-ce6bd2：读到截断留档（goalTruncated 标志，含旧档恰达 500 旧上限）→ 独立一行显式标注：
	// 完整版在会话 JSONL，改派勿凭截断版重写（resume 接力才保上下文）。
	const goalTruncNote = goalFromJournal && journalChain?.goalTruncated
		? "（任务书留档截断，完整版见会话 JSONL；建议 resume 接力而非凭截断版重写）"
		: "";
	const goalLine = goal
		? `▸ 原任务书（${goalMeta}）：${clipText(goal, RELAY_GOAL_SUMMARY_CHARS)}`
		: "▸ 原任务书：未留档（goal 与 rounds 均为空——改派时请人工补全目标）";
	// ② 已落盘产物（mtime + 归因）
	const { artifacts, overflow } = collectRelayArtifacts(prev);
	const artifactLines = artifacts.length
		? artifacts.map(relayArtifactLine)
		: ["  （无写入登记——lastWritePaths 与 task-writes 均为空；改派后先 git status 核对工作树实际状态）"];
	if (overflow > 0) artifactLines.push(`  （另有 ${overflow} 处界外未列；task-writes 登记单任务 ≤512 行，可按 taskId 全量查阅）`);
	// ③ 中断状态：终态 status + result/errorMessage 摘要（压平空白截断 200 字）；轮次缺档
	// （磁盘回填记录 rounds 为空）→ 用 journal 派发链行数（派发次数）并如实标注来源
	const resultSrc = (prev.result || prev.errorMessage || prev.stopReason || "").replace(/\s+/g, " ").trim();
	const roundsText = recordRounds > 0 || !journalChain ? `${recordRounds} 轮` : `${journalChain.dispatchCount} 轮（journal 派发链计数）`;
	// ev-20261017-88cb27：lastErrorKind 人读标签（provider 侧非任务原因两类可区分可见——安全拦截/
	// 硬额度耗尽；未登记值回退原文，旧快照兼容）。
	const LAST_ERROR_KIND_LABEL: Record<string, string> = {
		policy: "provider 安全拦截（内容策略）",
		quota: "provider 硬额度耗尽",
		transient: "瞬时 provider 故障",
		other: "其它错误",
	};
	const statusLine = `▸ 中断状态：status=${prev.status}${prev.lastErrorKind ? `（${LAST_ERROR_KIND_LABEL[prev.lastErrorKind] ?? prev.lastErrorKind}）` : ""}，共 ${roundsText}；终态输出摘要${resultSrc ? `（截断 ${RELAY_RESULT_SUMMARY_CHARS} 字）：${clipText(resultSrc, RELAY_RESULT_SUMMARY_CHARS)}` : "：无终态输出"}`;
	// ④ 可直接复制改派的 fresh 任务书模板（半成品核对段：先通读核对，勿盲目重写）
	const template = [
		"▸ 续点建议——可直接复制改派的 fresh 任务书：",
		"  -----任务书（复制起点）-----",
		`  ${goal || "（原任务目标未留档，请补全）"}`,
		"  工作树已有前次半成品，先通读核对再续做（勿盲目重写；mtime 供时序核对，↔sib=同批兄弟节点也写过）：",
		...(artifacts.length ? artifacts.map((a) => relayArtifactLine(a)) : ["  （写入登记为空——先 git status 核对工作树实际状态）"]),
		overflow > 0 ? `  （另有 ${overflow} 处界外未列，见上方清单注记）` : "",
		`  -----任务书（复制终点）-----（cwd: ${prev.cwd || "未指定，按派发时缺省"}；model: 不指定则按 profile 缺省；原会话 ${sessionFile ? path.basename(sessionFile) : "未知"} 约 ${Math.round(sizeKB)}KB 超窗保留在磁盘，仅作人工查阅、不再回放）`,
	].filter((l) => l !== "");
	// ev-20261002-c2b7ad：预填 task_submit 参数草稿（agent/cwd 预填，任务书留粘贴位）——
	// 拒单消息从「模板展示」并档到「确认即可提交」，省 Leader 手工组装参数。
	const draft = renderRelaySubmitDraft(prev);
	return [
		"【接力包】（拒单现场自动盘点：fresh 接力不回放历史，只带结论与产物坐标）",
		goalLine,
		...(goalTruncNote ? [goalTruncNote] : []),
		"▸ 已落盘产物（lastWritePaths ∪ task-writes 差集，mtime+归因；own=本任务登记确认，own·轨迹=仅轨迹观测，↔sib=同批兄弟也写过）：",
		...artifactLines,
		statusLine,
		...template,
		...draft.split("\n"),
	].join("\n");
}
