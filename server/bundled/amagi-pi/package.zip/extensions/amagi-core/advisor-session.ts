/** 自有 Codex 咨询会话索引；只记 ID，历史由 Codex 原生持久化。身份按调用者与冻结授权隔离。 */
import * as fs from "node:fs";
import * as path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { amagiDataDir } from "./data-dir.ts";
export function leaseAdvisorSession(identity: string): { threadId?: string; save: (threadId: string) => void; release: () => void } {
	const key = createHash("sha256").update(identity).digest("hex"), root = path.join(amagiDataDir(), "advisor-sessions");
	fs.mkdirSync(root, { recursive: true, mode: 0o700 });
	const file = path.join(root, `${key}.json`), lock = `${file}.lock`;
	let fd: number;
	try { fd = fs.openSync(lock, "wx", 0o600); }
	catch (error) {
		if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
		let owner: number;
		try { owner = JSON.parse(fs.readFileSync(lock, "utf8")).pid; if (!Number.isSafeInteger(owner) || owner < 1) throw new Error(); }
		catch { /* lint-exempt:未知占用者不自动清理锁。 */ throw new Error("Codex 咨询会话锁不可识别，须核实占用者后恢复"); }
		try { process.kill(owner, 0); throw new Error("Codex 咨询会话正由另一调用占用"); }
		catch (probe) { if ((probe as NodeJS.ErrnoException).code !== "ESRCH") throw probe; }
		fs.unlinkSync(lock); fd = fs.openSync(lock, "wx", 0o600);
	}
	fs.writeFileSync(fd, JSON.stringify({ pid: process.pid }));
	const release = () => { fs.closeSync(fd); fs.unlinkSync(lock); };
	let threadId: string | undefined;
	try {
		try {
			const saved = JSON.parse(fs.readFileSync(file, "utf8"));
			if (saved.owner !== key || saved.owned !== true || typeof saved.threadId !== "string" || !/^[a-zA-Z0-9-]{8,128}$/.test(saved.threadId)) throw new Error("Codex 咨询会话索引无效");
			threadId = saved.threadId;
		} catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
		return { threadId, save(id) {
			if (!/^[a-zA-Z0-9-]{8,128}$/.test(id)) throw new Error("Codex 未返回有效会话 ID");
			const tmp = `${file}.${randomUUID()}.tmp`;
			try { fs.writeFileSync(tmp, JSON.stringify({ owner: key, owned: true, threadId: id }), { mode: 0o600, flag: "wx" }); fs.renameSync(tmp, file); }
			finally { fs.rmSync(tmp, { force: true }); }
		}, release };
	} catch (error) { release(); throw error; }
}
