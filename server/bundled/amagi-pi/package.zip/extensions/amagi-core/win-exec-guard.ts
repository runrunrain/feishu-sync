/**
 * win-exec-guard.ts — M8：win_exec 的破坏性操作守卫适配（guards.ts tool_call 层调用点）。
 *
 * 不另起一套规则：把模型入参（program/args 数组）规范化为等价命令串（basename=git 时
 * `git <args…>`，与 win-exec.ts canonicalGitCommand 同源——票据绑定口径一致），复用
 * git-discard-guard 的 decideStashChainGate / decideDiscardGate 同一判定与 B2 授权票据机制。
 * guards.ts 仅留一个 win_exec 分支调用本函数（最小加法，不改动其既有逻辑）。
 */

import { decideStashChainGate, decideDiscardGate } from "./git-discard-guard.ts";
import { discardApprovalRefFromEnv, authorizeDiscardBackupAndExecute } from "./git-discard-backup.ts";

export interface WinExecGuardInput {
	program?: unknown;
	args?: unknown;
}

export interface WinExecGuardContext {
	/** bash 路径同款 cwd 解析（调用方传 effectiveBashCwd 结果）。 */
	cwd: string;
	toolCallId: string;
	/** 警示通道（guards 的 guard-note steer；不可用时静默跳过 warn 注记）。 */
	notify?: (text: string) => void;
}

/** 规范化命令串（与 win-exec.ts canonicalGitCommand 同一拼装——票据指纹匹配前提）。 */
export function winExecCanonicalCommand(input: WinExecGuardInput): string | null {
	const program = typeof input.program === "string" ? input.program.trim() : "";
	if (program === "") return null;
	const args = Array.isArray(input.args) ? input.args.filter((a): a is string => typeof a === "string") : [];
	const base = program.toLowerCase().split(/[\\/]/).pop() ?? "";
	const isGit = base === "git" || base === "git.exe" || base === "git.bat" || base === "git.cmd";
	if (!isGit) return null;
	return ["git", ...args].join(" ");
}

/**
 * win_exec 破坏性 git 门（返回 block 决策或 null=放行）。语义与 bash 路径一致：
 *  - stash 串联：block（win_exec 单调用无串联面，但判定复用同一函数保持口径）；
 *  - discard：block→block；warn→guard-note 放行；confirm→B2 预授权（AMAGI_DISCARD_APPROVAL_REF
 *    验真通过 backup-and-execute 放行，否则 block 并附可供有权会话批准的清单）。
 *  授权票据（绑定 toolCallId/canonical/cwd）由 win-exec.ts 执行边界消费（takeDiscardExecutionTicket）。
 */
export function winExecGuardDecision(input: WinExecGuardInput, ctx: WinExecGuardContext): { block: true; reason: string } | null {
	const canonical = winExecCanonicalCommand(input);
	if (canonical === null) return null; // 非 git 程序：白名单/参数门在工具执行层
	const chain = decideStashChainGate(canonical, ctx.cwd);
	if (chain) return { block: true, reason: chain.reason };
	const gate = decideDiscardGate(canonical, ctx.cwd);
	if (gate === null) return null;
	if (gate.action === "block") return { block: true, reason: gate.reason };
	if (gate.action === "warn") {
		try { ctx.notify?.(`[丢弃改动风险·软提示·win_exec]（warn 策略：只警示不确认） ${gate.reason}`); } catch { /* lint-exempt:警示失败不阻断 */ }
		return null;
	}
	if (gate.action !== "confirm") return null; // allow
	// confirm：B2 预授权通道（与 bash 路径同一 authorizeDiscardBackupAndExecute）
	const approvalRef = discardApprovalRefFromEnv();
	if (approvalRef) {
		const authorized = authorizeDiscardBackupAndExecute({ command: canonical, cwd: ctx.cwd, inspection: gate.inspection, ref: approvalRef, toolCallId: ctx.toolCallId });
		if (authorized.ok) return null; // 放行：win_exec 执行边界凭票据消费
		return { block: true, reason: `[amagi 守卫·丢弃确认·win_exec] 预授权验真/备份未通过，命令未执行：${authorized.reason}${authorized.approvalText ? `（${authorized.approvalText}）` : ""}` };
	}
	return {
		block: true,
		reason: `[amagi 守卫·丢弃确认·win_exec] 检测到将丢弃未提交改动的 Git 操作（${gate.inspection.kindLabel}：${canonical.slice(0, 120)}）——win_exec 通道与 bash 同门：无真实确认渠道/预授权不执行。批准方式：① 在具备确认渠道的会话执行同一命令并确认；② Leader 经 /amagi discard-approve 预授权后由本会话调用（win_exec 执行边界将验真票据：相同命令与 cwd 才消费）。`,
	};
}
