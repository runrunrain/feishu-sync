/**
 * sync-wait.ts — 同步 SubAgent 派发在飞计数（v1.5.197）。
 *
 * 背景（2026-08-01 实战事故）：主进程 TUI 同步派发 fuxi 任务，子进程正常工作 13 分钟，
 * 主进程活性看门狗（watchdog.ts）却按"32s 无事件"误判挂起并 abort，把健康的长任务杀死。
 * 根因：pi 0.83.0 的自定义工具会发射 tool_execution_start/end，但长时间执行期间若没有
 * onUpdate，只有边界事件，仍可能超过静默窗口；历史实现又无法从通用事件可靠区分“健康的
 * 子进程等待”和“工具自身卡死”。
 *
 * 解法：task-tool 与 watchdog 同处一个 extension，用模块级计数表达更精确的领域状态——同步派发等待期间
 * （runPiTask sync 尾段 await close）计数 +1，主进程 watchdog tick 不干预委托等待；实际活性由
 * 子进程自己的 watchdog 按连续静默窗口监视。任务总时长默认不限，只有显式 timeoutMs 或
 * AMAGI_TASK_TIMEOUT_MS > 0 时才启用墙钟硬上限。
 */

let active = 0;
/** begin/end 变更代次（watchdog 以此感知"等待结束"事件并校准活性——纯序号，不跨时钟基：
 * watchdog 的 now 可注入（测试），若这里用 Date.now() 时间戳，混合时基会出现未来时间戳导致
 * 永不 abort（快审 R3 major 修复）。 */
let generation = 0;

/** 进入同步派发等待（runPiTask sync 尾段调用）。 */
export function beginSyncWait(): void {
	active += 1;
	generation += 1;
}

/** 退出同步派发等待（finally 保证配平）。 */
export function endSyncWait(): void {
	active = Math.max(0, active - 1);
	generation += 1;
}

/** watchdog tick 查询：>0 = 有同步 SubAgent 派发在飞，沉默合法。 */
export function syncWaitsInFlight(): number {
	return active;
}

/** begin/end 变更代次（watchdog 记录已见代次，变化即"刚发生过 begin/end"）。 */
export function syncWaitGeneration(): number {
	return generation;
}

/** 测试隔离用复位。 */
export function resetSyncWaits(): void {
	active = 0;
	generation = 0;
}
