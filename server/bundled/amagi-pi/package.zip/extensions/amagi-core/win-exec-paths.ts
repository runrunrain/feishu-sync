/**
 * win-exec-paths.ts — win_exec 的路径翻译与安全归一（WSL ↔ Windows）。
 *
 * v2（diting 审核 M1/m5）：挂载根不再硬编码 /mnt——所有校验经 mntRoot 参数（生产侧统一传
 * win-exec-mnt.wslMntRoot()，/etc/wsl.conf [automount] root 自定义机器不失效；纯函数单测缺省
 * /mnt）。新增安全归一 normalizeMntPath：拒绝 `..` 段（路径穿越）、`\\?\` 前缀、UNC、尾随点/
 * 空格段、8.3 短名（~数字尾）与控制字符；容器比较按 Windows 语义大小写不敏感；存在时经
 * realpath 复核仍在 root 内（junction/符号链接外指拒绝）。
 *
 * 约定：Linux 侧挂载形态 <mntRoot>/<单盘符>/…；Windows 侧 <盘符>:\…。不在挂载根下的 Linux
 * 路径不翻译，由调用方保留并提示一次。
 */

/** Windows 侧显式可执行文件允许的扩展名（大小写不敏感）。 */
export const WIN_EXEC_FILE_EXTS = [".exe", ".bat", ".cmd", ".ps1"] as const;

export interface MntPathOptions {
	/** WSL automount 根（缺省 /mnt；生产侧传 wslMntRoot()）。 */
	mntRoot?: string;
}

function rootPrefix(mntRoot?: string): string {
	const r = (mntRoot && mntRoot.trim() !== "" ? mntRoot.trim() : "/mnt").replace(/\/+$/, "");
	return r;
}

/** 判断是否为 <mntRoot>/<单盘符>/ 形态的 Linux 绝对路径。 */
export function isUnderMnt(p: string, opts: MntPathOptions = {}): boolean {
	const r = rootPrefix(opts.mntRoot);
	const re = new RegExp(`^${r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\/[A-Za-z](\\/|$)`);
	return re.test(p) || new RegExp(`^${r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\/[A-Za-z]$`).test(p);
}

/** <mntRoot>/<盘>/P → <盘>:\P（盘符大写、正斜杠归一为反斜杠、去尾分隔符）；非挂载形态返回 null。 */
export function linuxToWindowsPath(p: string, opts: MntPathOptions = {}): string | null {
	const r = rootPrefix(opts.mntRoot);
	const m = new RegExp(`^${r.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\/([A-Za-z])(\\/.*)?$`).exec(String(p ?? ""));
	if (!m) return null;
	const drive = m[1]!.toUpperCase();
	const rest = (m[2] ?? "").replace(/\/+$/, "");
	const body = rest.split("/").filter(Boolean).join("\\");
	return body ? `${drive}:\\${body}` : `${drive}:\\`;
}

/** <盘>:\P → <mntRoot>/<盘>/P（盘符统一小写）；非 Windows 绝对路径返回 null。 */
export function windowsToLinuxPath(p: string, opts: MntPathOptions = {}): string | null {
	const m = /^([A-Za-z]):[\\/](.*)$/.exec(String(p ?? "").trim());
	if (!m) return null;
	const drive = m[1]!.toLowerCase();
	const rest = m[2]!.replace(/[\\/]+$/, "");
	const body = rest.split(/[\\/]/).filter(Boolean).join("/");
	return body ? `${rootPrefix(opts.mntRoot)}/${drive}/${body}` : `${rootPrefix(opts.mntRoot)}/${drive}`;
}

/** 判断字符串是否为 Windows 绝对路径形态（X:\… 或 X:/…）。UNC（\\…）不是本形态。 */
export function isWindowsAbsolutePath(p: string): boolean {
	return /^[A-Za-z]:[\\/]/.test(String(p ?? "").trim());
}

/** 显式程序路径的扩展名校验（.exe/.bat/.cmd/.ps1；大小写不敏感）。 */
export function hasAllowedExecutableExt(p: string): boolean {
	const lower = String(p ?? "").toLowerCase();
	return WIN_EXEC_FILE_EXTS.some((ext) => lower.endsWith(ext));
}

// ── M1：安全归一（拒绝穿越/短名/NT 预留形态） ────────────────────────────────

export type NormalizeMntResult = { ok: true; value: string } | { ok: false; reason: string };

/** 段级安全校验：拒绝 `..`、尾随点/空格、8.3 短名尾（~数字）、控制字符；空段与 "." 段合法（归一时剥除）。 */
function safeSegment(seg: string, i: number): string | null {
	if (seg === "" || seg === ".") return null;
	if (seg === "..") return `第 ${i} 段是 ".."（路径穿越）`;
	if (/[\x00-\x1f\x7f]/.test(seg)) return `第 ${i} 段含控制字符`;
	if (/\s$/.test(seg) || /\.$/.test(seg)) return `第 ${i} 段 "${seg}" 以空格/点结尾（Windows 名保留形态）`;
	if (/~\d+$/i.test(seg)) return `第 ${i} 段 "${seg}" 是 8.3 短名形态（~数字尾，指向不确定）`;
	return null;
}

/**
 * 归一为 <mntRoot>/<盘符小写>/… 形态：Windows 形态先转挂载形态；剥冗余分隔符与 "." 段；
 * 拒绝 `..`、`\\?\`、UNC、尾随点/空格、8.3 短名、控制字符。大小写保留原文（比较另经
 * caseInsensitiveEqual）。
 */
export function normalizeMntPath(p: string, opts: MntPathOptions = {}): NormalizeMntResult {
	const raw = String(p ?? "").trim();
	if (raw === "") return { ok: false, reason: "路径为空" };
	// NT 设备命名空间前缀与 UNC 直接拒绝（\\?\C:\、\\.\、\\server\share）
	if (/^\\\\[?.]/.test(raw) || /^\\\\/.test(raw)) {
		return { ok: false, reason: `路径 "${raw}" 是 UNC/NT 设备命名空间形态（\\\\… / \\\\?\\…），win_exec 不放行` };
	}
	const asMnt = isWindowsAbsolutePath(raw) ? windowsToLinuxPath(raw, opts) : raw;
	if (asMnt === null || !isUnderMnt(asMnt, opts)) {
		return { ok: false, reason: `路径 "${raw}" 不在挂载根 ${rootPrefix(opts.mntRoot)}/<盘符>/ 下（win_exec 只放行 Windows 侧可见程序）` };
	}
	const r = rootPrefix(opts.mntRoot);
	const parts = asMnt.slice(r.length + 1).split("/");
	const drive = (parts.shift() ?? "").toLowerCase();
	if (!/^[a-z]$/.test(drive)) return { ok: false, reason: `路径 "${raw}" 盘符段非法` };
	const segs: string[] = [];
	for (let i = 0; i < parts.length; i++) {
		const bad = safeSegment(parts[i]!, i + 2); // 行内偏移：root(1)+盘符(2) 起
		if (bad !== null) return { ok: false, reason: `路径 "${raw}" ${bad}` };
		if (parts[i] !== "" && parts[i] !== ".") segs.push(parts[i]!);
	}
	return { ok: true, value: `${r}/${drive}${segs.length > 0 ? "/" : ""}${segs.join("/")}` };
}

/** Windows 语义大小写不敏感相等（归一后 toLowerCase 比较）。 */
export function caseInsensitiveEqual(a: string, b: string): boolean {
	return a.toLowerCase() === b.toLowerCase();
}

/** 容器判定（纯词法、大小写不敏感；不做归一——调用方先 normalizeMntPath）。 */
function isLexicallyUnder(candidateMnt: string, rootMnt: string): boolean {
	const c = candidateMnt.toLowerCase().replace(/\/+$/, "");
	const r = rootMnt.toLowerCase().replace(/\/+$/, "");
	if (c === r) return true;
	return c.startsWith(`${r}/`);
}

export interface RealpathFn { (p: string): string | null }

/**
 * M1 容器判定（防逃逸完整版）：词法包含（大小写不敏感）＋ 双侧 realpath 复核（junction/
 * 符号链接外指拒绝）。realpath 失败侧回退词法形态（程序侧 existsSync 门仍在前）；两侧都
 * realpath 成功时以真实路径比较为准。
 */
export function isPathUnderRootSafe(
	candidateMnt: string, rootMnt: string,
	realpath: RealpathFn = () => null,
): { ok: boolean; reason?: string } {
	if (!isLexicallyUnder(candidateMnt, rootMnt)) {
		return { ok: false, reason: `"${candidateMnt}" 不在放行根 "${rootMnt}" 之内` };
	}
	const realCand = realpath(candidateMnt);
	const realRoot = realpath(rootMnt);
	if (realCand !== null && realRoot !== null) {
		if (!isLexicallyUnder(realCand, realRoot)) {
			return { ok: false, reason: `"${candidateMnt}" 经符号链接/junction 实际指向 "${realCand}"，已逃出放行根 "${realRoot}"——拒绝执行` };
		}
		return { ok: true };
	}
	if (realCand !== null && realRoot === null) {
		// 根不存在（配置漂移）：程序真实路径仍须词法落在配置根内
		if (!isLexicallyUnder(realCand, rootMnt)) {
			return { ok: false, reason: `"${candidateMnt}" 实际指向 "${realCand}"，不在放行根 "${rootMnt}" 之内` };
		}
	}
	return { ok: true };
}

// ── 参数翻译（确定性形态，无探测） ─────────────────────────────────────────────

export interface TranslatedArg {
	value: string;
	translated: boolean;
}

/**
 * 单个参数的路径翻译：整参挂载形态 → 盘符形态；`前缀=值`（--opt=/mnt/…、-DX=/mnt/…、
 * -DCMAKE_INSTALL_PREFIX:PATH=/mnt/…）只译值侧；其余原样。mntRoot 与 isUnderMnt 同源。
 */
export function translateArgPath(arg: string, opts: MntPathOptions = {}): TranslatedArg {
	const raw = String(arg ?? "");
	if (isUnderMnt(raw, opts)) {
		const win = linuxToWindowsPath(raw, opts);
		if (win !== null) return { value: win, translated: true };
	}
	const eq = raw.indexOf("=");
	if (eq > 0) {
		const head = raw.slice(0, eq);
		const tail = raw.slice(eq + 1);
		if (isUnderMnt(tail, opts)) {
			const win = linuxToWindowsPath(tail, opts);
			if (win !== null) return { value: `${head}=${win}`, translated: true };
		}
	}
	return { value: raw, translated: false };
}

/** 批量翻译：翻译后参数表 + 未翻译但形似 Linux 路径的参数清单（供结果末尾提示一次）。 */
export function translateArgList(args: readonly string[], opts: MntPathOptions = {}): { values: string[]; translatedCount: number; keptLinuxPaths: string[] } {
	const values: string[] = [];
	const keptLinuxPaths: string[] = [];
	let translatedCount = 0;
	for (const a of args) {
		const t = translateArgPath(a, opts);
		values.push(t.value);
		if (t.translated) translatedCount++;
		else if (typeof a === "string" && a.startsWith("/") && !isUnderMnt(a, opts)) keptLinuxPaths.push(a);
	}
	return { values, translatedCount, keptLinuxPaths };
}

/**
 * win_exec cwd 校验：必须是 <mntRoot>/<盘符>/ 下的 Linux 路径（Windows 进程无法以 ext4/UNC
 * 作 cwd）。返回挂载形态与 Windows 形态；非法返回中文拒绝理由。
 */
export function validateWindowsCwd(cwd: string, opts: MntPathOptions = {}): { ok: true; linux: string; windows: string } | { ok: false; reason: string } {
	const raw = String(cwd ?? "").trim();
	if (!raw) return { ok: false, reason: `cwd 不能为空（收到 ${JSON.stringify(cwd)}）` };
	if (isWindowsAbsolutePath(raw)) {
		const linux = windowsToLinuxPath(raw, opts);
		if (linux !== null) return { ok: true, linux, windows: raw.trim() };
		return { ok: false, reason: `cwd "${raw}" 不是合法的 Windows 绝对路径形态` };
	}
	if (!raw.startsWith("/")) return { ok: false, reason: `cwd "${raw}" 必须是 ${rootPrefix(opts.mntRoot)}/<盘符>/… 下的 Linux 绝对路径（Windows 进程的 cwd 必须落在 drvfs 上；相对路径会随宿主进程漂移，不收）` };
	if (!isUnderMnt(raw, opts)) return { ok: false, reason: `cwd "${raw}" 不在 ${rootPrefix(opts.mntRoot)}/<盘符>/ 下——Windows 进程无法以 ext4/WSL 内部路径作工作目录；请改用项目所在的挂载路径（drvfs 同一文件系统）` };
	const win = linuxToWindowsPath(raw, opts);
	if (win === null) return { ok: false, reason: `cwd "${raw}" 无法翻译为 Windows 形态（应为 ${rootPrefix(opts.mntRoot)}/<单盘符>/… 形态）` };
	return { ok: true, linux: raw.replace(/\/+$/, "") || raw, windows: win };
}
