/**
 * amagi-commands.ts — /amagi 斜杠命令层（面板与交互优化 M1-02；交互设计 §3）。
 *
 * L1 命令层是零键位依赖的交互主通道（调研01/04：mac 终端修饰键不可达面大，
 * 纯文本输入必达）。子命令：
 *   /amagi board [前缀]  — 打开看板（可直达任务面板）
 *   /amagi tasks         — 任务列表 widget 开/关
 *   /amagi session <前缀> — 直接打开会话 viewer（M3 接线后生效；解析层已支持）
 *   /amagi review        — 派发 diting 审当前 diff
 *   /amagi discard-approve <丢弃命令> [--cwd <dir>] — 采集影响清单并签发一次性丢弃授权
 *     （ev-20260922-1eea28 E1：签发源①；首跑只展示清单，显式 --yes 才签发）
 *   /amagi help（缺省）   — 入口帮助 + 各终端 ⌥ 开启指引
 *
 * dist 证据：RegisteredCommand（types.d.ts L852-858）name/description/
 * getArgumentCompletions(argumentPrefix)→AutocompleteItem[]|null/handler(args, ctx)。
 *
 * 能力横幅（R7）：maybeShowShortcutHint 按 data-dir 版本记录只显示一次；
 * amagi.json ui.shortcutHint:false 或环境 AMAGI_SHORTCUT_HINT=off 关闭。
 */

import * as fs from "node:fs";
import { tuiLog } from "./tui-console.ts";
import * as path from "node:path";
import type { TaskRecord } from "./task-registry.ts";
import { fmtKey, entryHint } from "./ui-shared.ts";
import { amagiDataFile } from "./data-dir.ts";
import { DEFAULT_UI_KEYS } from "./ui-config.ts";
import { harnessGuide, HARNESS_GUIDE_TOPICS } from "./harness-help.ts";
import type { ConfigurationReport } from "./configuration-diagnostics.ts";
import type { OrphanProc, ReapResult } from "./orphan-reaper.ts";
import { inspectDiscard } from "./git-discard-guard.ts";
import { collectDiscardImpact, issueDiscardApproval, type DiscardImpact } from "./git-discard-backup.ts";
// ev-20260926-bc6ba3（R5）：/amagi debug 会话采集——命令面直接驱动纯内存 collector（零注入面，
// K8c 观察面门禁天然满足；测试隔离经 resetDebugObservation）。
import { setDebugDefaultTag, muteDebugCollection, clearDebugEvents, showDebugEvents, debugObservationStatus, enableProviderDebug, disableProviderDebug, clearProviderDebugEvents, showProviderDebugEvents, providerDebugStatus, DEBUG_PROVIDER_MAX_EVENTS } from "./debug-observation.ts";

export interface AmagiCommandsDeps {
	/** 用户请求的帮助/配置输出；生产 TUI 用原生非上下文 entry，不追加模型消息。 */
	showInfo?(text: string, ctx: unknown): void;
	configuration?: {
		explain(ctx: unknown, agent?: string): ConfigurationReport;
		doctor(ctx: unknown): ConfigurationReport;
		initialize(ctx: unknown, preset: string): ConfigurationReport;
	};
	taskRegistry: { list(): Readonly<TaskRecord>[] };
	/** 派发 review（shortcuts 同款 deps：agents + runTask）。 */
	runReview(pi: { sendUserMessage(msg: string): void; sendMessage?: (msg: { customType: string; content: string; display: boolean; details?: Record<string, unknown> }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void }, ctx: { cwd: string; ui?: { notify?(msg: string, level?: string): void } }): void;
	/** 打开看板；focusTaskId 直达任务面板（M3 接线；缺省仅提示）。 */
	openBoard?(ctx: unknown, opts?: { taskId?: string }): void | Promise<void>;
	/** 任务列表 widget 开/关（shortcuts 同款 reset 语义；缺省仅提示）。 */
	toggleTasks?(ctx: unknown): void;
	/** v2.1-A1：确认收口 foreign-owner 历史记录（组合根注入 task-recovery.adoptRecoveryRecord）。 */
	adoptRecoveryTask?(taskId: string): Promise<{ ok: boolean; message: string }> | { ok: boolean; message: string };
	/** ev-20261021-a8de95：主上人工确认无残留进程（无启动锚点记录的收口证据；组合根注入 task-reconcile.attestTaskExited）。 */
	attestRecoveryExit?(taskId: string): Promise<{ ok: boolean; message: string }>;
	/** ev-20260930-08a8e7：恢复对账清单（/amagi recovery 列表——scan 只读 + formatRecoveryReport）。 */
	scanRecoveryReport?(): Promise<{ ok: boolean; message: string }>;
	/** ev-20260930-08a8e7：单任务断点明细（/amagi recovery show——store 精确查 + 重新观测 + 完整声明清单）。 */
	showRecoveryTask?(taskId: string): Promise<{ ok: boolean; message: string }>;
	/** ev-20260917-7b9298：/amagi orphans——amagi 血统孤儿进程诊断（组合根注入 orphan-reaper，含 run_bg 句柄排除）。 */
	diagnoseOrphans?(): Promise<{ orphans: OrphanProc[]; summary: string }>;
	/** ev-20260917-7b9298：/amagi orphans clean——显式回收诊断出的孤儿（SIGTERM→宽限→SIGKILL）。 */
	reapDiagnosedOrphans?(orphans: OrphanProc[]): Promise<ReapResult>;
	/** 测试注入数据目录；缺省 data-dir 解析。 */
	dataDir?: string;
	/** 测试注入版本；缺省读 package.json。 */
	version?: string;
	/** B0-2（§3.4）：/amagi stats 文本供给（组合根注入：aggregateStats + 本会话分支视图）；
	 *  ctx 为命令 handler 原始上下文（sessionManager.getBranch 投影用）。输出只进用户界面。 */
	statsSummary?(days: number | undefined, ctx: unknown): string;
}

// ── args 解析（纯函数） ─────────────────────────────────────────────────────

export type AmagiCommand =
	| { kind: "guide"; topic: string }
	| { kind: "doctor" }
	| { kind: "config-explain"; agent?: string }
	| { kind: "config-init"; preset: string }
	| { kind: "config-invalid" }
	| { kind: "board"; taskPrefix?: string }
	| { kind: "tasks" }
	| { kind: "review" }
	| { kind: "discard-approve"; command: string; cwd?: string; confirmed: boolean }
	| { kind: "recovery-list" }
	| { kind: "recovery-adopt"; taskId: string }
	| { kind: "recovery-confirm-exited"; taskId: string }
	| { kind: "recovery-show"; taskId: string }
	| { kind: "session"; query: string }
	// B0-2（§3.4）：用户统计入口——/amagi stats [days]，输出只在主上界面（不进模型上下文）。
	| { kind: "stats"; days?: number }
	| { kind: "stats-invalid"; word: string }
	| { kind: "orphans" }
	| { kind: "orphans-clean" }
	// ev-20260926-bc6ba3（R5）：会话采集生命周期（on/off/clear/show；非法标签/未知子动作明确报错）
	| { kind: "debug-on"; tag: string }
	| { kind: "debug-off" }
	| { kind: "debug-clear" }
	| { kind: "debug-show"; tag?: string }
	// P9（寄生设计 §5.3）：provider 流诊断子族（独立 opt-in 默认关；白名单元数据采集）
	| { kind: "debug-provider-on" }
	| { kind: "debug-provider-off" }
	| { kind: "debug-provider-clear" }
	| { kind: "debug-provider-show" }
	| { kind: "debug-provider-unknown"; word: string }
	| { kind: "debug-unknown"; word: string }
	| { kind: "help" };

/** 解析 /amagi 后续参数。未知子命令 → help（附原词）。 */
export function parseCommandArgs(args: string): AmagiCommand {
	const parts = String(args ?? "").trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return { kind: "help" };
	const [head, ...rest] = parts;
	switch (head.toLowerCase()) {
		case "guide": return { kind: "guide", topic: rest.join(" ") || "overview" };
		case "doctor": return rest.length ? { kind: "config-invalid" } : { kind: "doctor" };
		case "config": {
			if (rest.length === 0) return { kind: "config-explain" };
			if (rest[0]?.toLowerCase() === "explain" && rest.length <= 2) return { kind: "config-explain", ...(rest[1] ? { agent: rest[1] } : {}) };
			if (rest[0]?.toLowerCase() === "init" && rest.length === 2) return { kind: "config-init", preset: rest[1]! };
			return { kind: "config-invalid" };
		}
		case "board": {
			if (rest.length === 0) return { kind: "board" };
			return { kind: "board", taskPrefix: rest.join(" ") };
		}
		case "tasks": return { kind: "tasks" };
		case "review": return { kind: "review" };
		case "recovery": {
			// ev-20260930-08a8e7：裸 recovery = 列表；子动作 adopt（收口）/ show（断点明细）；
			// v2.x：list 是裸命令的显式同义词（自动收口汇总行文案引用它）；缺 taskId/未知子动作 → help
			const [sub, id] = rest;
			if (rest.length === 0) return { kind: "recovery-list" };
			if (sub?.toLowerCase() === "list" && rest.length === 1) return { kind: "recovery-list" };
			if (sub?.toLowerCase() === "adopt" && id) return { kind: "recovery-adopt", taskId: rest.slice(1).join(" ") };
			if (sub?.toLowerCase() === "show" && id) return { kind: "recovery-show", taskId: rest.slice(1).join(" ") };
			if (sub?.toLowerCase() === "confirm-exited" && id) return { kind: "recovery-confirm-exited", taskId: rest.slice(1).join(" ") };
			return { kind: "help" };
		}
		case "session": {
			if (rest.length === 0) return { kind: "help" };
			return { kind: "session", query: rest.join(" ") };
		}
		case "stats": {
			// B0-2：/amagi stats [days]——days 须为正整数（其它形态明确报错不静默全量，防手滑把窗口看成全量）。
			if (rest.length === 0) return { kind: "stats" };
			if (rest.length === 1 && /^\d+$/.test(rest[0]!) && Number(rest[0]) > 0) return { kind: "stats", days: Number(rest[0]) };
			return { kind: "stats-invalid", word: rest.join(" ") };
		}
		case "orphans": {
			// ev-20260917-7b9298：orphans 诊断 + orphans clean 显式回收（子动作式，同 recovery）
			if (rest[0]?.toLowerCase() === "clean") return { kind: "orphans-clean" };
			return { kind: "orphans" };
		}
		case "debug": {
			// ev-20260926-bc6ba3（R5）：会话采集生命周期——on <tag>（缺参 → help，同 session 口径）/
			// off / clear / show [tag]；未知子动作明确报错（debug-unknown，不静默 help）。
			// 标签含空格时整体拼接交由 handler 校验拒绝（如实回显尝试的标签，不静默截断）。
			if (rest.length === 0) return { kind: "help" };
			const [sub, ...valueRest] = rest;
			const value = valueRest.join(" ");
			const s = sub?.toLowerCase();
			if (s === "on") return value ? { kind: "debug-on", tag: value } : { kind: "help" };
			if (s === "off") return { kind: "debug-off" };
			if (s === "clear") return { kind: "debug-clear" };
			if (s === "show") return { kind: "debug-show", ...(value ? { tag: value } : {}) };
			// P9（寄生设计 §5.3）：provider 子族——on/off/clear/show；裸 provider → show（只读面板）；
			// 未知子动作明确报错（debug-provider-unknown，不静默 help）。
			if (s === "provider") {
				const [act, ...extra] = valueRest;
				const a = act?.toLowerCase();
				if (extra.length > 0) return { kind: "debug-provider-unknown", word: value };
				if (a === "on") return { kind: "debug-provider-on" };
				if (a === "off") return { kind: "debug-provider-off" };
				if (a === "clear") return { kind: "debug-provider-clear" };
				if (a === undefined || a === "" || a === "show") return { kind: "debug-provider-show" };
				return { kind: "debug-provider-unknown", word: String(act) };
			}
			return { kind: "debug-unknown", word: String(sub) };
		}
		case "discard-approve": {
			// ev-20260922-1eea28（E1）：签发源①。--cwd <dir>（git 自身目录参数是 -C，无语法冲突）；
			// 确认 = 末位显式键入 --yes（本文件无既有确认惯例——两步式：首跑只展示影响清单，
			// 重跑附 --yes 才签发；拒绝/取消零副作用）。
			const tokens = [...rest];
			let confirmed = false;
			if (tokens[tokens.length - 1] === "--yes") { confirmed = true; tokens.pop(); }
			let cwd: string | undefined;
			const commandTokens: string[] = [];
			for (let i = 0; i < tokens.length; i++) {
				if (tokens[i] === "--cwd") {
					const value = tokens[i + 1];
					if (!value) return { kind: "help" };
					cwd = value;
					i++;
					continue;
				}
				commandTokens.push(tokens[i]!);
			}
			if (commandTokens.length === 0) return { kind: "help" };
			return { kind: "discard-approve", command: commandTokens.join(" "), ...(cwd !== undefined ? { cwd } : {}), confirmed };
		}
		default: return { kind: "help" };
	}
}

export const SUBCOMMANDS = ["guide", "doctor", "config", "board", "tasks", "review", "discard-approve", "recovery", "session", "stats", "orphans", "debug", "help"] as const;

// ── 帮助文本（R4：mac 键位符号 + 文本命令等价物并列） ───────────────────────

export function helpText(defaultKeys: { board: string[]; tasks: string[]; review: string[] } = DEFAULT_UI_KEYS): string {
	return [
		"amagi 交互入口（命令必达；⌥ 快捷键视终端配置）",
		"  /amagi guide [主题]      起步帮助（overview/tasks/config/mcp/recovery；按需读取）",
		"  /amagi doctor            只读检查宿主接口、角色声明和模型/认证配置（不发网络请求）",
		"  /amagi config explain [角色]  有效模型及来源；config init inherit|tiered 创建项目预设（已有配置不覆盖）",
		`  /amagi board [任务前缀]  打开看板（可直达任务面板；${entryHint("board", defaultKeys.board)}）`,
		`  /amagi tasks             任务列表 widget 开/关（${entryHint("tasks", defaultKeys.tasks)}）`,
		`  /amagi review            派发 diting 审当前 diff（${entryHint("review", defaultKeys.review)}）`,
		"  /amagi discard-approve <丢弃命令> [--cwd <dir>] [--yes]  采集丢弃影响清单并签发一次性授权（10 分钟有效、单次消费；首跑只看清单，显式 --yes 才签发）",
		"  /amagi recovery [list]       恢复对账清单（扫描契约存储：现场/缺口/断点——含已自动收口判据明细）",
		"  /amagi recovery show <完整taskId>  断点明细：任务书摘要 + 声明产物逐路径观测（存在/大小/mtime/类型；续接派新 taskId）",
		"  /amagi recovery adopt <taskId>  确认收口 foreign-owner 历史记录（本机旧记录归并对账流；他人机器记录拒绝）",
		"  /amagi recovery confirm-exited <taskId>  人工确认无残留进程（无启动锚点的旧记录；之后 task_control reconcile 收口）",
		"  /amagi session <任务前缀> 直接打开该任务的完整会话查看器",
		"  /amagi stats [天数]    成本/质量统计（按角色/模型分组：任务数/成功率/token/缓存命中/调用数；附本会话分支可见用量 + 本会话工具调用/isError/软提示/子任务终态——全会话含压缩前与全分支）",
		"  /amagi orphans [clean]   诊断/清理 amagi 血统孤儿进程（父链已死且 env 带标记；clean 显式回收）",
		"  /amagi debug on <tag>    开启会话默认采集标签（bash 可显式传 debugTag 覆盖；采集命令真实最终输出，非程序内部变量）",
		"  /amagi debug off / clear / show [tag]  off=静默（显式 debugTag 也不采集）/ clear=清空缓冲 / show=查看标签聚合",
		"  /amagi debug provider on|off|clear|show  provider 流事件元数据诊断（独立 opt-in 默认关：只采 provider/api/model/事件类型/回合/计数，零内容/凭据）",
		"  /amagi help              本帮助",
		"看板内：j/k 移动 · ⏎ 任务面板 · v 完整会话 · r 刷新 · q/Esc 逐级返回",
		"若 ⌥ 键无效：Terminal.app → 设置 → 键盘 → 勾选「将 Option 键用作 Meta 键」；iTerm2 → Keys → Option key sends: Esc+。",
	].join("\n");
}

// ── 能力横幅（R7） ──────────────────────────────────────────────────────────

function readPackageVersion(): string {
	try {
		const pkg = JSON.parse(fs.readFileSync(path.resolve(import.meta.dirname, "..", "..", "package.json"), "utf8"));
		return String(pkg.version || "0");
	} catch { return "0"; }
}

/**
 * 版本变更时输出一次横幅；同版本不重复。返回 true 表示已输出。
 * 开关：amagi.json ui.shortcutHint=false 由调用方读取后传 hintEnabled=false；
 * 环境变量 AMAGI_SHORTCUT_HINT=off 直接短路。
 */
export function maybeShowShortcutHint(opts: { dataDir?: string; version?: string; hintEnabled?: boolean; out?: (s: string) => void }): boolean {
	if (process.env.AMAGI_SHORTCUT_HINT === "off") return false;
	if (opts.hintEnabled === false) return false;
	const version = opts.version ?? readPackageVersion();
	const out = opts.out ?? ((s: string) => { tuiLog(s); });
	const stateFile = path.join(opts.dataDir ?? path.dirname(amagiDataFile("x")), "ui-hint.json");
	try {
		let last = "";
		try { last = String(JSON.parse(fs.readFileSync(stateFile, "utf8")).version || ""); } catch { last = ""; }
		if (last === version) return false;
		fs.mkdirSync(path.dirname(stateFile), { recursive: true });
		fs.writeFileSync(stateFile, JSON.stringify({ version, at: new Date().toISOString() }));
	} catch { /* 状态读写失败不阻断提示，只是可能重复 */ }
	out(`⌨ amagi 交互：/amagi board ${fmtKey(DEFAULT_UI_KEYS.board[0])} 实况 · /amagi tasks ${fmtKey(DEFAULT_UI_KEYS.tasks[0])} · /amagi review ${fmtKey(DEFAULT_UI_KEYS.review[0])} · /amagi help 帮助。若 ⌥ 键无效见 /amagi help（本提示每版本仅一次；amagi.json ui.shortcutHint:false 关闭）。`);
	return true;
}

// ── discard-approve 输出与清单（ev-20260922-1eea28 E1：签发源①接通）──────────

/** discard-approve 输出 sink 类型（与 pi.sendMessage 消费面同构；注入式，测试传 mock）。 */
export type DiscardApproveSink = (msg: { customType: string; content: string; display: boolean }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void;

/** 命令输出通道：pi.sendMessage（customType=amagi:discard-approve，display:true 进会话展示与
 *  上下文）优先；不可用（headless/注入缺省）回落 console.log（与既有命令输出一致）。 */
export function discardApproveEmitter(pi: { sendMessage?: DiscardApproveSink }): (text: string) => void {
	const sink = pi.sendMessage;
	if (typeof sink === "function") {
		return (text: string): void => {
			try { sink.call(pi, { customType: "amagi:discard-approve", content: text, display: true }); }
			catch { tuiLog(text); }
		};
	}
	return (text: string): void => { tuiLog(text); };
}

/** 影响清单展示（路径×side×规模）：collectDiscardImpact 产物逐条列出（与授权绑定同口径）。 */
export function discardImpactListText(impact: DiscardImpact, sides: { index: number; worktree: number }): string {
	if (!impact.entries.length) return "影响清单（0 条——pathspec 范围内当前无待丢弃改动/障碍路径）：";
	const lines = impact.entries.map((e) => {
		const sideParts: string[] = [];
		if (e.kind === "untracked" || e.kind === "ignored") sideParts.push(e.kind);
		else sideParts.push("worktree");
		if (e.blobOid !== undefined) sideParts.push("index");
		const sizeParts: string[] = [];
		if (e.worktreeTombstone) sizeParts.push("工作树无文件（删除事实）");
		if (e.bytes !== undefined) sizeParts.push(`${e.bytes} 字节`);
		if (e.blobBytes !== undefined) sizeParts.push(`index ${e.blobBytes} 字节`);
		return `  ${e.path}  [${sideParts.join("+")}] ${sizeParts.join(" · ") || "0 字节"}`;
	});
	return [
		`影响清单（${impact.entries.length} 条 · index 侧 ${sides.index} · worktree 侧 ${sides.worktree} · 备份规模 ${impact.totalBytes} 字节；含 tracked 改动/untracked 与 ignored 障碍/rename 两侧）：`,
		...lines,
	].join("\n");
}

// ── 注册 ────────────────────────────────────────────────────────────────────

export function registerAmagiCommands(pi: {
	registerCommand(name: string, options: {
		description?: string;
		getArgumentCompletions?: (argumentPrefix: string) => { value: string; label: string; description?: string }[] | null;
		handler: (args: string, ctx: unknown) => Promise<void>;
	}): void;
	/** discard-approve 输出通道（注入式；缺省时该命令回落 console.log）。 */
	sendMessage?: DiscardApproveSink;
}, deps: AmagiCommandsDeps): void {
	pi.registerCommand("amagi", {
		description: "amagi 交互入口：guide 帮助 / doctor 诊断 / config 配置解释 / board 看板 / tasks / review / recovery / help",
		getArgumentCompletions: (prefix: string) => {
			const p = prefix.trim().toLowerCase();
			// A1b（pi 1.0.2）：AutocompleteItem 契约 value 为必填——旧实现只给 label，
			// pi 1.0.2 编辑器 getBestAutocompleteMatchIndex 直接读 items[i].value.startsWith
			// → 缺 value 即 TypeError 崩溃整个 pi 进程（实测 /amagi 补全触发 uncaught_exception）。
			const items: { value: string; label: string; description?: string }[] = [];
			for (const value of [...HARNESS_GUIDE_TOPICS.map((topic) => `guide ${topic}`), "config explain", "config init inherit", "config init tiered"]) {
				if ((p.includes(" ") || /\s$/.test(prefix)) && value.startsWith(p)) items.push({ value, label: value, description: "amagi 起步与配置" });
			}
			for (const sub of SUBCOMMANDS) {
				const label = ["board", "session", "recovery", "debug", "guide", "config"].includes(sub) ? `${sub} ` : sub;
				if (!p || label.toLowerCase().startsWith(p)) {
					items.push({ value: label, label, description: cmdDescription(sub) });
				}
			}
			// ev-20260926-bc6ba3（R5）：debug 子动作补全（on/off/clear/show）；P9：provider 子族
			const debugActs = p.split(/\s+/);
			if (debugActs.length >= 1 && debugActs[0] === "debug") {
				for (const act of ["on ", "off", "clear", "show", "provider on", "provider off", "provider clear", "provider show"]) {
					const label = `debug ${act.trim()}`;
					if (label.toLowerCase().startsWith(p)) items.push({ value: label, label, description: cmdDescription("debug") });
				}
			}
			// 前缀后半段匹配任务（board/session 已输入子命令后）
			const parts = p.split(/\s+/);
			if (parts.length >= 2 && ["board", "session"].includes(parts[0])) {
				const q = parts.slice(1).join(" ");
				for (const t of deps.taskRegistry.list()) {
					const label = `${parts[0]} ${t.taskId.slice(0, 8)}`;
					if (label.toLowerCase().startsWith(p) || t.name?.toLowerCase().startsWith(q)) {
						items.push({ value: label, label, description: `${t.agent} · ${t.status}` });
					}
				}
			}
			return items.length > 0 ? items : null;
		},
		handler: async (args: string, ctxRaw: unknown) => {
			const ctx = ctxRaw as { mode?: string; cwd?: string };
			const cmd = parseCommandArgs(args);
			const showInfo = (text: string) => deps.showInfo ? deps.showInfo(text, ctxRaw) : tuiLog(text);
			switch (cmd.kind) {
				case "guide": showInfo(harnessGuide(cmd.topic).text); return;
				case "doctor": showInfo(deps.configuration?.doctor(ctxRaw).text ?? "配置诊断未接线；用 /amagi guide config 查看入口。"); return;
				case "config-explain": showInfo(deps.configuration?.explain(ctxRaw, cmd.agent).text ?? "配置解释未接线；用 /amagi guide config 查看入口。"); return;
				case "config-init": showInfo(deps.configuration?.initialize(ctxRaw, cmd.preset).text ?? "配置创建未接线；未写入任何文件。"); return;
				case "config-invalid": showInfo("用法：/amagi doctor | /amagi config explain [角色] | /amagi config init inherit|tiered；未知参数未执行。"); return;
				case "board": {
					if (ctx.mode === "tui" && deps.openBoard) {
						await deps.openBoard(ctx, cmd.taskPrefix ? { taskId: cmd.taskPrefix } : undefined);
					} else if (cmd.taskPrefix) {
						const rec = deps.taskRegistry.list().find((r) => r.taskId.startsWith(cmd.taskPrefix!) || r.name === cmd.taskPrefix || r.sessionId?.startsWith(cmd.taskPrefix!));
						tuiLog(rec ? `（非 TUI）任务 ${rec.taskId.slice(0, 8)} · ${rec.agent} · ${rec.status}` : `（非 TUI）未匹配任务：${cmd.taskPrefix}`);
					} else {
						tuiLog("（非 TUI）看板仅 TUI 模式可用；任务状态请用 task_query。");
					}
					return;
				}
				case "tasks": {
					if (ctx.mode === "tui" && deps.toggleTasks) deps.toggleTasks(ctx);
					else tuiLog("（非 TUI）任务列表 widget 仅 TUI 模式可用；任务状态请用 task_query 工具。");
					return;
				}
				case "review": {
					deps.runReview(pi as unknown as { sendUserMessage(m: string): void; sendMessage?: (m: { customType: string; content: string; display: boolean; details?: Record<string, unknown> }, o?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void }, ctx as { cwd: string });
					return;
				}
				case "recovery-list": {
					// ev-20260930-08a8e7：恢复对账清单（scan 只读 + 渲染；不靠本进程 registry）
					if (!deps.scanRecoveryReport) {
						tuiLog("（未接线）恢复对账清单不可用（组合根未注入 scanRecoveryReport）；清单见启动对账提示，明细命令：/amagi recovery show <taskId>。");
						return;
					}
					try {
						const res = await deps.scanRecoveryReport();
						tuiLog(res.message);
					} catch (e) {
						tuiLog(`[recovery 异常] 对账清单失败：${e instanceof Error ? e.message : String(e)}（零副作用；可重试）`);
					}
					return;
				}
				case "recovery-adopt": {
					// v2.1-A1：用户显式确认“该记录属本机”——采纳注记落盘 + 归并对账流（拒绝面由核心层判定并说明）
					if (!deps.adoptRecoveryTask) {
						tuiLog("（未接线）恢复收口通道不可用（组合根未注入 adoptRecoveryTask）；清单见启动对账提示或任务存储对账报告，收口命令：/amagi recovery adopt <taskId>。");
						return;
					}
					try {
						const res = await deps.adoptRecoveryTask(cmd.taskId);
						tuiLog(res.message);
					} catch (e) {
						tuiLog(`[adopt 异常] 收口失败：${e instanceof Error ? e.message : String(e)}`);
					}
					return;
				}
				case "recovery-confirm-exited": {
					// ev-20261021-a8de95：人工退出确认只经 TUI（模型工具面不能自证退出）；只写注记，收口仍走 reconcile
					if (!deps.attestRecoveryExit) {
						tuiLog("（未接线）人工退出确认通道不可用（组合根未注入 attestRecoveryExit）。");
						return;
					}
					try {
						tuiLog((await deps.attestRecoveryExit(cmd.taskId)).message);
					} catch (e) {
						tuiLog(`[confirm-exited 异常] ${e instanceof Error ? e.message : String(e)}`);
					}
					return;
				}
				case "recovery-show": {
					// ev-20260930-08a8e7：单任务断点明细（精确查 store + 重新观测 + 完整声明清单；不靠 registry 曾恢复成功）
					if (!deps.showRecoveryTask) {
						tuiLog("（未接线）断点明细通道不可用（组合根未注入 showRecoveryTask）；用法：/amagi recovery show <完整taskId>。");
						return;
					}
					try {
						const res = await deps.showRecoveryTask(cmd.taskId);
						tuiLog(res.message);
					} catch (e) {
						tuiLog(`[show 异常] 断点明细失败：${e instanceof Error ? e.message : String(e)}（零副作用；可重试）`);
					}
					return;
				}
				case "session": {
					if (ctx.mode === "tui" && deps.openBoard) {
						// M3：经看板直达 viewer（openBoard 支持 initialView 扩展由 board 层实现）
						await deps.openBoard(ctx, { taskId: cmd.query, initialView: "viewer" } as { taskId?: string });
					} else {
						tuiLog("（非 TUI）会话查看器仅 TUI 模式可用。");
					}
					return;
				}
				case "stats": {
					// B0-2：用户统计入口——showInfo 走原生非上下文 entry（不进模型上下文）；未接线时如实提示。
					if (!deps.statsSummary) {
						showInfo("（未接线）统计供给不可用（组合根未注入 statsSummary）；trace 数据在 <amagi数据目录>/traces/traces.ndjson。");
						return;
					}
					try {
						showInfo(deps.statsSummary(cmd.days, ctxRaw));
					} catch (e) {
						showInfo(`[amagi stats] 统计失败：${e instanceof Error ? e.message : String(e)}（零副作用，可重试）`);
					}
					return;
				}
				case "stats-invalid": {
					showInfo(`用法：/amagi stats [天数]——天数须为正整数（如 /amagi stats 7）；「${cmd.word}」未执行。缺省天数=全量。`);
					return;
				}
				case "orphans":
				case "orphans-clean": {
					// ev-20260917-7b9298：孤儿进程诊断/显式回收（bash 超时自动回收之外的跨会话兑底入口）
					if (!deps.diagnoseOrphans || !deps.reapDiagnosedOrphans) {
						tuiLog("（未接线）孤儿诊断通道不可用（组合根未注入）；bash 超时自动回收不受影响。");
						return;
					}
					try {
						const diag = await deps.diagnoseOrphans();
						if (cmd.kind === "orphans" || diag.orphans.length === 0) {
							tuiLog(diag.summary);
							return;
						}
						const res = await deps.reapDiagnosedOrphans(diag.orphans);
						tuiLog(`${diag.summary}\n[清理] ${res.summary || "无进程需要回收"}`);
					} catch (e) {
						tuiLog(`[orphans 异常] 诊断/清理失败：${e instanceof Error ? e.message : String(e)}（不杀任何进程）`);
					}
					return;
				}
				case "debug-on":
				case "debug-off":
				case "debug-clear":
				case "debug-show":
				case "debug-provider-on":
				case "debug-provider-off":
				case "debug-provider-clear":
				case "debug-provider-show":
				case "debug-provider-unknown":
				case "debug-unknown": {
					// ev-20260926-bc6ba3（R5）：会话采集生命周期（纯内存 collector；非法标签/未知子动作明确报错，零副作用）
					if (cmd.kind === "debug-on") {
						const res = setDebugDefaultTag(cmd.tag);
						tuiLog(res.ok
							? `[amagi·debug] 已设会话默认标签「${cmd.tag}」——本会话后续 bash 调用自动按该标签采集真实最终输出（显式 debugTag 参数优先）；/amagi debug show ${cmd.tag} 查看聚合。`
							: `[amagi·debug] 非法标签 ${JSON.stringify(cmd.tag)}：须为 1-64 位 ASCII 字符 [A-Za-z0-9._-]（禁控制符/路径/表达式）——未开启任何采集（零副作用）。`);
						return;
					}
					if (cmd.kind === "debug-off") {
						muteDebugCollection();
						tuiLog("[amagi·debug] 已静默：清除默认标签且后续显式 debugTag 也不采集（迟到旧调用结果不回填），直至 /amagi debug on <tag>。缓冲不清空，/amagi debug show 仍可查看既有采集。");
						return;
					}
					if (cmd.kind === "debug-clear") {
						const r = clearDebugEvents();
						tuiLog(`[amagi·debug] 已清空采集缓冲（${r.cleared} 条事件；迟到旧调用结果不回填；不删项目文件与原生临时输出文件）；默认标签/静默位不变。`);
						return;
					}
					if (cmd.kind === "debug-show") {
						tuiLog(showDebugEvents(cmd.tag));
						return;
					}
					// P9（寄生设计 §5.3）：provider 流诊断子族——独立 opt-in（默认关），白名单元数据采集，
					// 与 bash 采集开关互不影响；零内容/凭据入缓冲（详见 debug-observation.ts 白名单分类器）。
					if (cmd.kind === "debug-provider-on") {
						enableProviderDebug();
						tuiLog("[amagi·debug] provider 流诊断已开启：本会话后续 provider 流事件按白名单采集元数据（provider/api/model/事件类型/回合/计数——零内容/凭据采集，不落盘）；/amagi debug provider show 查看面板。");
						return;
					}
					if (cmd.kind === "debug-provider-off") {
						disableProviderDebug();
						tuiLog("[amagi·debug] provider 流诊断已关闭：后续流事件零采集；既有缓冲保留，/amagi debug provider show 仍可查看。");
						return;
					}
					if (cmd.kind === "debug-provider-clear") {
						const r = clearProviderDebugEvents();
						tuiLog(`[amagi·debug] 已清空 provider 诊断缓冲（${r.cleared} 条事件与聚合计数；掉落计数一并归零）；bash 采集缓冲与开关不受影响。`);
						return;
					}
					if (cmd.kind === "debug-provider-show") {
						tuiLog(showProviderDebugEvents());
						return;
					}
					if (cmd.kind === "debug-provider-unknown") {
						const pst = providerDebugStatus();
						tuiLog(`[amagi·debug] 未知 provider 子动作「${cmd.word || "（空）"}」——可用：on / off / clear / show（独立 opt-in 默认关，与 bash 采集开关互不影响）；当前状态：开=${pst.enabled ? "是" : "否"} · 事件 ${pst.events}/${DEBUG_PROVIDER_MAX_EVENTS} · 丢弃 ${pst.dropped}。`);
						return;
					}
					const st = debugObservationStatus();
					tuiLog(`[amagi·debug] 未知子命令「${cmd.word || "（空）"}」——可用：on <tag> / off / clear / show [tag] / provider on|off|clear|show（流诊断，默认关）（详见 /amagi help）；当前状态：默认标签=${st.defaultTag ?? "未设"} · 静默=${st.muted ? "是" : "否"} · 事件 ${st.events}/256。`);
					return;
				}
				case "discard-approve": {
					// ev-20260922-1eea28（E1）：签发源①接通——调 inspectDiscard 采集影响清单，显式 --yes
					// 确认后调 issueDiscardApproval（B2 落地后 issueDiscardApproval 此前零生产调用点）。
					// 验真链/备份协议全在 git-discard-backup（已验收面，本层不重复实现）；拒绝/取消零副作用。
					const emit = discardApproveEmitter(pi);
					const refuse = (reason: string): void => {
						emit(`[amagi·discard-approve] 不是可授权的丢弃命令：${reason}\n未签发任何授权（零副作用）。仅路径级 checkout/restore 进入授权通道；reset --hard / checkout --force / clean / stash / 子模块等走人工处置。`);
					};
					if (cmd.cwd !== undefined && !fs.existsSync(cmd.cwd)) {
						emit(`[amagi·discard-approve] --cwd 目录不存在：${cmd.cwd}\n未签发任何授权（零副作用）。请核对目录后重试。`);
						return;
					}
					const sessionCwd = typeof ctx?.cwd === "string" && ctx.cwd ? ctx.cwd : process.cwd();
					const cwd = cmd.cwd ?? sessionCwd;
					const inspection = inspectDiscard(cmd.command, cwd);
					if (!inspection) { refuse(`命令未识别为丢弃操作（「${cmd.command}」）`); return; }
					if (!inspection.repoRoot || inspection.unknownReason) { refuse(inspection.unknownReason ?? "仓库根不可定位"); return; }
					if (inspection.kind !== "checkout-paths" && inspection.kind !== "restore") {
						refuse(`丢弃形态「${inspection.kindLabel}」不在授权通道支持范围（仅路径级 checkout/restore）`);
						return;
					}
					if (inspection.splitBefore) { refuse(`复合命令需拆开执行（${inspection.splitBefore}）`); return; }
					if (!inspection.pathspecs.length) { refuse("全仓形态（无 pathspec）不进入授权通道，走人工处置"); return; }
					const impactResult = collectDiscardImpact(inspection.cwd, inspection.repoRoot, inspection.pathspecs);
					if (!impactResult.ok) { refuse(`影响清单采集失败：${impactResult.reason}`); return; }
					const listText = discardImpactListText(impactResult.impact, inspection.sides);
					if (!cmd.confirmed) {
						emit([
							"[amagi·discard-approve] 影响清单（未签发——需显式键入 yes 确认）",
							`命令：${cmd.command}`,
							`仓库：${inspection.repoRoot}`,
							`形态：${inspection.kindLabel}`,
							listText,
							"确认丢弃上述改动（执行时守卫将先备份全部影响字节再放行）请显式键入 yes 重新执行：",
							`  /amagi discard-approve ${cmd.command}${cmd.cwd !== undefined ? ` --cwd ${cmd.cwd}` : ""} --yes`,
							"不确认则到此为止（未签发、未执行任何丢弃，零副作用）。",
						].join("\n"));
						return;
					}
					const issued = issueDiscardApproval({ command: cmd.command, cwd, inspection, issuedVia: "slash-command" });
					if (!issued.ok) {
						emit(`[amagi·discard-approve] 签发未成立：${issued.reason}\n未签发任何授权（零副作用）。`);
						return;
					}
					// M1（diting round2）：接通源②派发链——宿主进程 env 写入后，本会话后续 task 派发
					// 经 task-run.ts 透传自动携带（TTL 10min/单次消费/内容指纹验真兜底，模型无法自造）。
					try { process.env.AMAGI_DISCARD_APPROVAL_REF = issued.ref; } catch { /* env 写入失败仅影响自动透传，显式 export 路径仍可用 */ }
					emit([
						`[amagi·discard-approve] 已签发一次性丢弃授权（ref：${issued.ref}）`,
						`命令：${issued.approval.canonicalCommand}`,
						`仓库：${issued.approval.repoIdentity}`,
						listText,
						`用法：已注入本会话派发链——后续 task 派发与子会话自动携带该授权；也可显式 export AMAGI_DISCARD_APPROVAL_REF=${issued.ref} 后在派发环境执行；有效期 10 分钟、单次消费。`,
						"授权绑定签发时的内容指纹——内容变化即失效；执行时守卫验真后先备份全部影响字节再放行（backupId 见执行回执）。",
					].join("\n"));
					return;
				}
				case "help":
				default:
					tuiLog(helpText());
					return;
			}
		},
	});
}

function cmdDescription(sub: string): string {
	switch (sub) {
		case "board": return "打开 workflow 看板（可带任务前缀直达）";
		case "tasks": return "任务列表 widget 开/关";
		case "review": return "派发 diting 审当前 diff";
		case "discard-approve": return "采集丢弃影响清单并签发一次性丢弃授权（<命令> [--cwd <dir>] [--yes]）";
		case "recovery": return "恢复对账：列表 / show <taskId> 断点明细 / adopt <taskId> 收口 foreign-owner / confirm-exited <taskId> 人工退出确认";
		case "session": return "打开任务完整会话查看器";
		case "stats": return "成本/质量统计（按角色/模型：任务/成功率/token/缓存命中/调用数；附本会话工具调用/isError/软提示/子任务终态——全会话含压缩前；可选天数窗口）";
		case "orphans": return "诊断/清理 amagi 血统孤儿进程（父链已死且 env 带标记）";
		case "debug": return "会话输出采集：on <tag> 默认标签 / off 静默 / clear 清空 / show [tag] 查看聚合 / provider on|off|clear|show 流事件元数据诊断（独立 opt-in 默认关）";
		default: return "帮助";
	}
}
