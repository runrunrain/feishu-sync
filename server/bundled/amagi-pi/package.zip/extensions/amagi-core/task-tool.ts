import { materializeSelectedEvidence } from "./dispatch-handoff.ts";
import type { ContextMode } from "./contracts/task.ts";
/**
 * task-tool.ts — amagi SubAgent 编排工具（sync 模式，加固版）。
 *
 * 官方 examples/extensions/subagent/index.ts 蓝本，按 diting 审核加固：
 *   P0-1 显式超时/abort 保证终止（SIGTERM→3s grace→SIGKILL）；信号退出/provider error 不判 done；终态唯一来源
 *   P0-2 移除公开 tools override（只用 agent.tools 白名单；空数组坑消除）
 *   P1-1 processLine 抽出 + close flush 尾帧；单行/总 stdout/事件/累计 message 字节上限；UTF-8 安全截断；解析错误无有效消息→error
 *   P1-2 try/catch/finally 生命周期；异常→registry error；writePromptTmp 自回滚；timer/listener 用完移除；失败 isError:true
 *   P1-3 env 最小化（白名单 + PI_* + provider 凭据映射 + AMAGI_SUBAGENT；密钥不进日志）
 */

import { spawn, execFileSync } from "node:child_process";
import * as fs from "node:fs";
import * as path from "node:path";
import { Type } from "typebox";
import { sendTaskCompletion } from "./evidence-context.ts";
import { mergeCostSource, type CostSource } from "./cost-source.ts";
import { StringEnum } from "@earendil-works/pi-ai";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { roleIsReadOnly, type AgentConfig } from "./agents-loader.ts";
import { dispatchAcceptableAgentIds, findAgentByRequest, resolveAgentRequest, shouldRunCodeBaseline, codeProductContextOf, withModeHeader, automaticVerificationEnabled } from "./agent-aliases.ts";
import { registry, registryErrorEcho, type TaskRelationMeta } from "./task-registry.ts";
import { resolveModel, resolveModelWithSource, normalizeModelSpec, modelOverrideNote, setKnownAgents, setModelMetaProvider, loadFallbackModels, effectiveModelNote, modelDeviationNote, isModelProviderError, modelFailureAdvice, parseStringifiedModelArray, type ModelRegistryLike } from "./model-resolver.ts";
// ev-20260910-060c3a / ev-20260910-316c6e：模型可观测性四函数——effectiveModelNote（结果回显实际生效模型）、
// modelDeviationNote（子进程实际运行偏离警示）、isModelProviderError/modelFailureAdvice（模型类 4xx 归因候选）。
import { lightVerifyHint, producesProjectCodeOf, type EvidenceReport } from "./evidence.ts";
import { findArtifact } from "./artifact.ts";
import { setupWorktree, worktreeSummary, worktreePatch, attachWorktreeTask, releaseWorktreeOwnership, releaseWorktreeLease, isInsideLinkedWorktree, inspectWorktreeRemoval, type WorktreeSetup } from "./worktree.ts";
import { writeTrace, classifyErrorKind, type TraceEntry, type TraceRunSlice, type TraceModelSubtotal } from "./trace.ts";
import { updateRoutingStats, escalationHint } from "./routing-stats.ts";
import { contractHash, findDuplicate, recordDispatch, recordDispatchResult, isProviderError, isTransientProviderError, isAccountQuotaError, crossProviderDowngrade, isChannelDisconnectError, isRateLimitSignal, resolveDowngrade, buildRetryAdvice, renderRecoveryAdvice, normalizeAutoRetryConfig, implicitAutoRetryConfig, implicitRetryApplicable, nextAutoRetryPlan, isAutoRetryEnabled, getIdempotencyWindowMs, isProviderBreakerEnabled, providerBreakerCheck, providerBreakerPeek, isChainCooldownEnabled, planChainExhaustedCooldown, getStallThresholdMs, type DowngradeDecision, type AutoRetryConfig, type ChainExhaustedCooldownPlan } from "./reliability.ts";
// ev-20260916-2dbc7f/c5ee56（S4 集成）：单一派发预检评估——task-tool 内旧 suggestWorktreeDispatch 的
// 纯评估部分已迁 dispatch-preflight（唯一实现）；此处只保留旧 steer 递送作为 legacy 回滚路径。
import { evaluateDispatch, observeDispatchFacts, worktreePreflightMode, looksLikeLargeChange, looksLikeReadOnlyTask, type DispatchEvaluation } from "./dispatch-preflight.ts";
// ev-20260916-23f4a4（S5 集成）：任务级证据超时——派发侧一次性校验 + 解析冻结，传入 auto-verify 与收尾链。
import { resolveEvidenceTimeouts, readProjectEvidenceTimeouts, type EvidenceTimeouts, type ResolvedEvidenceTimeouts } from "./evidence-options.ts";
import { beginSyncWait, endSyncWait } from "./sync-wait.ts";
import { tryOccupy, waitForGrant, release as releaseAdmission, cancelQueued, admissionStats, admissionPoolNote } from "./admission.ts";
import { authPreflight } from "./auth-preflight.ts";
import { finalizeTerminal, runBaselineVerification } from "./finalizer.ts";
import { renderUsageFooter } from "./usage-footer.ts";
import { journalDispatch, journalRetry } from "./journal.ts";
import { runGroup, submitGroup, waitGroup, cancelGroup, resolveExternalGroup, getGroup, type GroupSpec, type GroupRunDeps, type GroupRunOutcome, type ResultEnvelope, REPORT_PATH_INVALID_RE, resolveNodeAllowedPaths, resolveNodeReportPath, singleReportPathInjectionBlock, whitelistOverflowContractBlock, anchoredResourceDisciplineBlock } from "./group-scheduler.ts";
import { waitTasks, cancelTask, resolveExternalTask, submitTaskKernel, grantStartTask, kernelViewLine, type WorktreeDispatchFacts } from "./task-service.ts";
import { collectWorkspacePreflight, collectSiblingWriterLabels } from "./workspace-preflight.ts";
import { collectCrossSessionWriterLabels } from "./cross-session-writers.ts";
// ev-20260905-7614b1：任务书自包含提示词导出（只导出不派发，详见 task-export.ts 模块头背景事故）
import { exportTaskPrompt, resolveGitRoot } from "./task-export.ts";
import { isToolOrder400, sessionRepairEnabled, repairSessionById, repairSummary, repairAction, transientRepairSummary, transientRetryDelayMs, TRANSIENT_400_NUDGE } from "./session-repair.ts";
// ── P3-B 拆分（2026-08-19 插件进化）：JSONL 解析域 → task-jsonl.ts；context 预算预估 → context-budget.ts ──
import { extractArtifactRefs, type CallUsage } from "./task-jsonl.ts";
import { contextBudgetReject } from "./context-budget.ts";
// 公共面冻结：既有外部 import（tests / guards / mcp-client 等）自 task-tool 取名，re-export 保持不变。
export { bashCommandWritesFile, bashWriteTargets, writeEditTargets } from "./task-jsonl.ts";
export { contextWindowOf, contextBudgetReject, resumeBudgetReject } from "./context-budget.ts";
export { getFinalOutput, extractArtifactRefs, capUtf8HeadTail, looksLikeFinalReport, findReusableTestEvidence } from "./task-jsonl.ts";
// ── P3-C 拆分（2026-08-19 插件进化，第二/三批）：引擎/类型/stats/shutdown → task-run.ts；background → task-background.ts；
// resume 磁盘回填+runResumeTask → task-resume.ts；编排模式库+nodeDeliveryMessage → orchestrate.ts；query_task → task-query.ts ──
import {
	genTaskId, writePromptTmp, providerOfSpec, resolveProtectedPaths, resolveAllowedPaths, resolveAgentTools,
	extractDeliverablePaths, missingDeliverablePaths, matchEquivalentDeliverableWrites, deliverableResolutionNotes, appendCancellationReason, finalizeLaunchFailure, taskCategoryFor, fuseWarningFor,
	runPiTask, writeStats, snapshotForPersist, blockedReplyDirective, stallActivityDigest, hasDoneMarker, diagnoseCompletionContract, completionContractRepairNudge, processLivenessNote,
	planTaskPrompt, applyTaskPromptOffload, currentAssignmentBody, taskTmpRoot, SHARED_TREE_DISCIPLINE,
	AMAGI_DONE_MARKER, EXECUTION_DISCIPLINE_REMINDER, DONE_CONTRACT_REMINDER, formatAmagiClock, type RunResult, type BackgroundStart, type CumulativeStatsEntry,
} from "./task-run.ts";
import { collectResidue, residueNote } from "./residue.ts";
// ev-20260914-9084ee：allowedPaths 白名单共享 matcher（glob/prefix: 语法；预检与守卫同源）
import { parseAllowedPathEntry, resolveAllowedPathEntry, expandGlobPaths, globStaticBaseDir } from "./path-match.ts";
import { wireTerminalPush, markExecuteReturned } from "./terminal-push.ts";
import { shouldAutoContinue, runBackgroundTask } from "./task-background.ts";
import type { PermissionGrant } from "./contracts/permission.ts";
import { normalizeToolArgumentArtifacts } from "./contracts/view.ts"; // ev-20260919+ev-20260920：工具参数伪影归一（null 键与 "null" 字符串）
import { resolveSessionWithBackfill, runResumeTask, recoveryActionOfRecord } from "./task-resume.ts";
// v2.15.0 大发射守卫 prompt 层：子进程 --append-system-prompt 末尾纪律分节（provider 命中才注入）
import { largeEmissionDisciplineLine } from "./large-emission-guard.ts";
import { nodeDeliveryMessage, orchestrate, type OrchestrateRunTask } from "./orchestrate.ts";
export {
	resolveTaskTimeoutMs, resolveProtectedPaths, resolveAllowedPaths, resolveAgentTools, extractDeliverablePaths, missingDeliverablePaths,
	matchEquivalentDeliverableWrites, deliverableResolutionNotes,
	AMAGI_BLOCKED_MARKER, AMAGI_DONE_MARKER, EXECUTION_DISCIPLINE_REMINDER, DONE_CONTRACT_REMINDER, BLOCKED_REGEX,
	blockedReplyDirective, stallActivityDigest, detectBlocked, hasDoneMarker, annotateCompletion, processLivenessNote,
	writeStats, setStatsListener, cleanupChildrenOnShutdown, snapshotForPersist, liveContextTokensOf,
} from "./task-run.ts";
export type { RunResult, BackgroundStart, StatsListenerEntry, CumulativeStatsEntry } from "./task-run.ts";
export { shouldAutoContinue, runBackgroundTask } from "./task-background.ts";
export { runResumeTask } from "./task-resume.ts";
export { createQueryTaskTool, readSessionFinalText } from "./task-query.ts";

// P3-C：orchestrate 注入 sync 主链 runTask（编排模块不得反向 import task-tool；Record→RunTaskOptions 收窄与原编排体内一致）
const _orchRunTask: OrchestrateRunTask = (ag, task, o) => runTask(ag, task, o as unknown as RunTaskOptions);

// ── ev-20260903-263d48：通知层去重（batch 节点/组完成通知键）──
// 背景：同会话 batch 完成通知（batch-52ec1bef、batch-d783c83a）曾重复送达 2-3 次，每次 Leader 花
// ~0.5 轮判真伪（合计约 5 轮注意力税），且有误信噪音引发错误处置的风险；根因是 steer 消息排队
// flush 与节点多次状态迁移重发，而通知层此前没有去重键。此处按 runId+nodeId+status 登记进程内
// Set，同一键只投递一次；粒度到 status——blocked 后 resume 再 done 是不同键，两次状态各自投递。
// 编排模式（fanout/pipeline/tournament/redteam/fork）的通知接线在 orchestrate.ts 内部闭包，
// 不在 task-tool.ts 可控范围（本批不改）；shouldNotify 已导出，编排路径后续接入时复用同一键空间。
const _notifyDedupeKeys = new Set<string>();
/** 通知去重键容量护栏：超限按插入序淘汰最旧一半（runId 每批唯一，被淘汰键重现≈0，不构成漏投风险）。 */
const NOTIFY_DEDUPE_MAX = 4096;

/** 通知去重判断（纯函数，测试直接驱动）：首次见到 key 返回 true 并登记；已登记返回 false（调用方跳过投递）。 */
export function shouldNotify(key: string): boolean {
	if (_notifyDedupeKeys.has(key)) return false;
	if (_notifyDedupeKeys.size >= NOTIFY_DEDUPE_MAX) {
		let evict = Math.ceil(NOTIFY_DEDUPE_MAX / 2);
		for (const oldest of _notifyDedupeKeys) {
			if (evict-- <= 0) break;
			_notifyDedupeKeys.delete(oldest);
		}
	}
	_notifyDedupeKeys.add(key);
	return true;
}

/** 测试隔离：清空通知去重登记表（生产不调用）。 */
export function resetNotifyDedupeForTest(): void {
	_notifyDedupeKeys.clear();
}

// ── sync runTask（调用 runPiTask background=false） ──
// v2（§7.1-A/B）：候选名单统一为 agent-aliases.ts 的 CODE_PRODUCT_AGENTS={luban,luoshen,fuxi}
// （与 evidence DEFAULT_CODE_AGENTS 同一只读定义）；候选不是无条件执行集合——实际触发经
// shouldRunCodeBaseline（候选 && producesProjectCode && (非 fuxi || attack)）；fuxi 按 D1 裁决
// （artifact-only，只给指导性方案）producesProjectCode 恒 false 永不触发，机制保留为未来授权留口。
// producesProjectCode 由任务归一层从 fresh 变更路径分类（producesProjectCodeOf：当前 git status
// 减去派发前快照；非 git/探测失败保守 true——不能因任务声称文档跳过代码验收）。preflight（派发前，
// 无 diff 可分）沿用候选成员判定（仅预检测试命令可用性，不影响结算门）。
// producesProjectCode 由任务归一层从 fresh 变更路径分类（producesProjectCodeOf：当前 git status
// 减去派发前快照；非 git/探测失败保守 true——不能因任务声称文档跳过代码验收）。preflight（派发前，
// 无 diff 可分）沿用候选成员判定（仅预检测试命令可用性，不影响结算门）。门函数 automaticVerificationEnabled
// （ev-20261013 迁至 agent-aliases.ts 单一来源：task-background 同一公式消费，禁止反向 import 本模块）。
export interface RunTaskOptions {
	contextMode?: ContextMode;
	cwd: string;
	model?: string;
	fallbackModel?: string;
	signal?: AbortSignal;
	timeoutMs?: number;
	command?: { command: string; args: string[] };
	modelRegistry?: ModelRegistryLike;
	onStall?: (info: { taskId: string; agent: string; idleMs: number }) => void;
	onUpdate?: (partial: { content: Array<{ type: "text"; text: string }> }) => void;
	/** Test-only clock for event-duration accounting; not exposed as a tool parameter. */
	eventClockForTest?: (event: { type?: string }) => number;
	description?: string;
	/** ed-20260910 diting m-1：journal 派发留档用的原始任务书（缺省 = task）。worktree/子目录派发的
	 *  task 会前置注入 [全仓检出] 标注（271–389 字），吃满 journal 500 字留档预算使 resume 接力包
	 *  回读价值耗尽——标注只应进子进程任务书与回流文案，journal 记录原始任务书。 */
	journalGoal?: string;
	name?: string;
	relation?: TaskRelationMeta;
	/** Trust gates source-content preflight and project-owned baseline execution. */
	trusted?: boolean;
	/** 8月迭代 F5：任务硬边界保护路径（execute 层解析为绝对后传入；子进程 env AMAGI_PROTECTED_PATHS）。 */
	protectedPaths?: string[];
	/** 8月迭代 C3：任务白名单路径（execute 层解析为绝对后传入；子进程 env AMAGI_ALLOWED_PATHS）。 */
	allowedPaths?: string[];
	/** ev-20260907-8abf9a + Leader 验收修正①：显式交付物路径（绝对；batch reportPath 解析后传入）——
	 *  结构化接入 B1 交付物预检验收链（done 判定前 existsSync；缺失→补跑一轮→仍缺 blocked），
	 *  绕过 extractDeliverablePaths/extractArtifactRefs 的正则 token 分词（空格/中文路径无损）。 */
	deliverablePaths?: string[];
	/** ev-20260920-61839b：声明产物契约（task_submit outputs[]）——冻结进 spec.outputs + 结算面产物完整性。
	 *  与 deliverablePaths（落位执法通道）分工：本字段是契约记录面，deliverablePaths 是预检执法面。 */
	outputs?: ReadonlyArray<{ path: string; kind: "file" | "tree"; required: boolean; purpose?: string }>;
	/** Test seam for deterministic verification; production uses gatherEvidenceReport. */
	verification?: (cwd: string) => Promise<EvidenceReport>;
	/** ev-20260916-23f4a4（S5 集成）：派发侧解析冻结后的证据超时预算（auto-verify 链透传；
	 *  收尾链由 execute 层直接携带同一冻结值）。 */
	evidenceTimeouts?: ResolvedEvidenceTimeouts;
	/** ev-20260916-101d8a：复用链尽冷却占位记录（queued/cooldown）作为本次派发记录。 */
	preCreatedTaskId?: string;
	/** P4 §7-1 接缝（M3 生产激活）：四方交集冻结授权——task_submit 分面计算后经此透传，
	 *  submitTaskKernel 冻结进 spec.permission（引擎据此注入 --tools/env/digest 执法链）。
	 *  legacy 调用方缺省不传 → v1 如实占位（零执法，行为不变）。 */
	permission?: Readonly<PermissionGrant>;
	worktreeDispatch?: Readonly<WorktreeDispatchFacts>;
}

/** ev-20260918-2fe431 后续：项目信任回退源。宿主契约里 isProjectTrusted 只在事件 ctx（session_start 等）
 *  提供，工具 execute ctx 不携带——此前 `ctx.isProjectTrusted?.() ?? false` 在工具路径上永远 false，
 *  auto-baseline 检查全体 skipped(unavailable)、autoVerify 静默失效。index.ts 在 session_start 捕获会话信任态
 *  注入本 setter；解析优先级：execute ctx 直给值 > 会话回退 > false（未捕获会话时保持旧 fail-closed 语义）。 */
// B4B 修复轮 R02：三件套原位抽至 trust-context.ts（单一状态源；guard-policy 判定消费同链），
// 此处 import+re-export 保持既有 import 路径（index.ts/task-facets.ts 等）零改动。
import { setTrustFallback, resolveProjectTrusted } from "./trust-context.ts";
export { setTrustFallback, resolveProjectTrusted };

export function shouldAutoVerify(agent: AgentConfig, rr: RunResult, trusted?: boolean, producesProjectCode: boolean = true): boolean {
	return automaticVerificationEnabled(agent.name, trusted, producesProjectCode) && rr.status === "done" && !rr.blocked && hasDoneMarker(rr.output);
}

// ── ev-20260903-780da3：自动验证的并行干扰豁免（P2/friction）──
// 事故链（batch-da11dfaa，2026-09-04）：abi-flip 节点 00:15:20 已完成全部交付并结算 done，finalizer
// 自动基线验证在共享工作树上跑确定性基线，因并行节点 polish-p2 的 evidence.ts ⚠ext 文案改动半途态，
// task-write-log.test.mjs「其中 1 处⚠ext」断言临时失败 → 注入「[amagi 自动验证失败 1/1]」强制续跑
// 38min 追查非本任务缺陷，期间撞上 provider 挂起被看门狗终止 → journal 出现 done→error 二次结算；
// 全部节点落地后同套测试 181/181 绿，证实假失败。结论：同 cwd 并行任务仍在运行时，基线失败可能
// 来自兄弟节点的 in-flight 改动而非本任务缺陷——此时放行结算并注记，由 Leader 集成时全量复核。
/** 同 cwd 活跃兄弟任务判断（纯函数，测试直接驱动）：registry 中存在 taskId≠本任务、running、同 cwd 的记录。 */
export function hasActiveSiblingInCwd(taskId: string, cwd: string): boolean {
	if (!cwd) return false;
	try {
		return registry.list().some((r) => r.taskId !== taskId && r.status === "running" && r.cwd === cwd);
	} catch { /* journal:parallel-cwd-probe-fallback */ 
		return false;
	}
}

/** 豁免开关：代码内常量默认开启（assignment 回退分支）——docs/env-knobs.md 不在本任务白名单，
 * 新增 AMAGI_* env 读取点未登记文档会被 tests/env-knobs-doc.test.mjs 判红，故不引入环境开关。
 * 升级路径：同时新增 env 读取（"0"/"false" 关闭）+ docs/env-knobs.md 登记行，两处必须一起落（单侧落盘同样判红）。 */
const VERIFY_SIBLING_EXEMPT_ENABLED = true;
// ── B0-1（附录 B.1）：deferStats 多轮聚合纯函数（runTask 与测试共用单一实现） ─────
// 一次逻辑任务 = 一条 stats + 一条 trace：分轮求和恰一次；首上下文取第一轮首调用、末上下文取
// 最后轮末调用；分轮身份（runs[]，不落盘）与分模型小计（modelSubtotals，按各轮实际模型拆桶）
// 随聚合行携带；usage 分项全程未观察时保持 undefined（未知，不补 0）；usageCoverage 取各轮
// 并集 + 终态 abnormal-exit。B1 交付物预检/verificationFailure 的终态覆写由 facts.status 表达。

export interface DeferredMergeFacts {
	/** 最终逻辑终态（含 verificationFailure/deliverable 预检的覆写后状态）。 */
	status: string;
	/** 终态错误消息（errorKind 重新分类用）。 */
	errorMessage?: string;
	autoContinueRounds: number;
	autoRepairRounds: number;
	verificationMs: number;
}

function sumDefinedNums(vals: ReadonlyArray<number | undefined>): number | undefined {
	let sum: number | undefined;
	for (const v of vals) if (v !== undefined) sum = (sum ?? 0) + v;
	return sum;
}

function mergeFiguresOf(figs: ReadonlyArray<{ input?: number; output?: number; cacheRead?: number; cacheWrite?: number; cost?: number } | undefined>): { input?: number; output?: number; cacheRead?: number; cacheWrite?: number; cost?: number } | undefined {
	const merged = { input: sumDefinedNums(figs.map((f) => f?.input)), output: sumDefinedNums(figs.map((f) => f?.output)), cacheRead: sumDefinedNums(figs.map((f) => f?.cacheRead)), cacheWrite: sumDefinedNums(figs.map((f) => f?.cacheWrite)), cost: sumDefinedNums(figs.map((f) => f?.cost)) };
	return Object.values(merged).every((v) => v === undefined) ? undefined : merged;
}

/** 读入轮次口径归一（diting Phase E Info）：非零 cost 而缺 costSource 的旧载体按 unknown 参与
 *  join（与 provider 同桶 → mixed，不冒充 provider）；无 cost 观测（cost 缺席或 0）不参与合并。 */
function roundCostSourceOf(cost: number | undefined, costSource: CostSource | undefined): CostSource | undefined {
	if (costSource !== undefined) return costSource;
	return cost !== undefined && cost > 0 ? "unknown" : undefined;
}

export function mergeDeferredUsage(rounds: ReadonlyArray<RunResult>, facts: DeferredMergeFacts): { trace: TraceEntry; stats: CumulativeStatsEntry } | undefined {
	const rr = rounds[rounds.length - 1];
	if (!rr?._tracePayload || !rr._statsPayload) return undefined;
	// F3（diting，附录 B.1）：分轮/分模型字段不补假零——分项保留 undefined（未知），另记
	// usageObserved 覆盖位（该轮是否观察到任何 usage；false=上列分项缺席是未知非零）。
	const traceRuns: TraceRunSlice[] = rounds.map((r) => {
		const p = r._tracePayload;
		const usageObserved = p !== undefined && (p.input !== undefined || p.output !== undefined || p.cacheRead !== undefined || p.cacheWrite !== undefined || p.cost !== undefined);
		const costSource = roundCostSourceOf(p?.cost, p?.costSource);
		return {
			runKey: r.runKey ?? p?.runKey ?? "unknown",
			...(p?.model !== undefined ? { model: p.model } : {}),
			status: r.status,
			...(p?.input !== undefined ? { input: p.input } : {}),
			...(p?.output !== undefined ? { output: p.output } : {}),
			...(p?.cacheRead !== undefined ? { cacheRead: p.cacheRead } : {}),
			...(p?.cacheWrite !== undefined ? { cacheWrite: p.cacheWrite } : {}),
			...(p?.cost !== undefined ? { cost: p.cost } : {}),
			...(costSource !== undefined ? { costSource } : {}),
			assistantCalls: p?.assistantCalls ?? 0,
			usageObserved,
		};
	});
	// 分模型小计：分项只在有定义的轮上求和（全缺=undefined 下界）；coverage 标注桶内是否有未观察轮。
	const modelSubtotalsMap = new Map<string, { input?: number; output?: number; cacheRead?: number; cacheWrite?: number; cost?: number; costSource?: CostSource; assistantCalls: number; runs: number; unknownRounds: number }>();
	for (const s of traceRuns) {
		const mk = s.model ?? "(未知)";
		const acc = modelSubtotalsMap.get(mk) ?? { assistantCalls: 0, runs: 0, unknownRounds: 0 };
		if (s.input !== undefined) acc.input = (acc.input ?? 0) + s.input;
		if (s.output !== undefined) acc.output = (acc.output ?? 0) + s.output;
		if (s.cacheRead !== undefined) acc.cacheRead = (acc.cacheRead ?? 0) + s.cacheRead;
		if (s.cacheWrite !== undefined) acc.cacheWrite = (acc.cacheWrite ?? 0) + s.cacheWrite;
		if (s.cost !== undefined) acc.cost = (acc.cost ?? 0) + s.cost;
		// pi 1.5.0 计费口径逐轮合并（格 join；某轮 unknown/estimate 与 provider 同桶 → mixed，不冒充）。
		acc.costSource = mergeCostSource(acc.costSource, s.costSource);
		acc.assistantCalls += s.assistantCalls;
		acc.runs++;
		if (!s.usageObserved) acc.unknownRounds++;
		modelSubtotalsMap.set(mk, acc);
	}
	const modelSubtotals: TraceModelSubtotal[] = [...modelSubtotalsMap.entries()].map(([model, v]) => ({
		model,
		...(v.input !== undefined ? { input: v.input } : {}),
		...(v.output !== undefined ? { output: v.output } : {}),
		...(v.cacheRead !== undefined ? { cacheRead: v.cacheRead } : {}),
		...(v.cacheWrite !== undefined ? { cacheWrite: v.cacheWrite } : {}),
		...(v.cost !== undefined ? { cost: v.cost } : {}),
		...(v.costSource !== undefined ? { costSource: v.costSource } : {}),
		assistantCalls: v.assistantCalls,
		runs: v.runs,
		coverage: v.unknownRounds > 0 ? "partial" : "complete",
	}));
	const coverageFlags = new Set<string>();
	for (const r of rounds) for (const f of String(r._tracePayload?.usageCoverage ?? "complete").split("|")) if (f !== "complete") coverageFlags.add(f);
	if (facts.status === "error" || facts.status === "truncated") coverageFlags.add("abnormal-exit");
	const usageCoverage = coverageFlags.size > 0 ? [...coverageFlags].join("|") : "complete";
	const nestedUsage = mergeFiguresOf(rounds.map((r) => r._tracePayload?.nestedUsage));
	const compactionUsage = mergeFiguresOf(rounds.map((r) => r._tracePayload?.compactionUsage));
	const usageMissingCalls = sumDefinedNums(rounds.map((r) => r._tracePayload?.usageMissingCalls));
	// F1（diting，附录 B.1）：首上下文显式取第一轮（undefined 也覆写——末轮展开值不得在首轮
	// 字段缺席时残留）；末上下文取最后一次观测到的末调用（末轮无调用时回看前轮）。
	const firstCallContext = rounds[0]?._tracePayload?.firstCallContext;
	let lastCall: CallUsage | undefined;
	for (let i = rounds.length - 1; i >= 0 && lastCall === undefined; i--) lastCall = rounds[i]._tracePayload?.lastCall;
	// pi 1.5.0 计费口径逐轮合并（格 join；任一轮 unknown/estimate → 不再是 provider）。全轮无成本观测 → 字段缺席。
	// diting Phase E Info：旧载体非零 cost 缺 costSource 读入时归一 unknown（roundCostSourceOf）——
	// 与 provider 轮次混合得 mixed，不再以 undefined 参与 join 而冒充 provider。
	const mergedCostSource = rounds.reduce<CostSource | undefined>((acc, r) => mergeCostSource(acc, roundCostSourceOf(r._tracePayload?.cost, r._tracePayload?.costSource)), undefined);
	const mergedTrace: TraceEntry = {
		...rr._tracePayload,
		status: facts.status,
		// P2-A：聚合行 errorKind 以最终 status/errorMessage 重新分类（verificationFailure 会把
		// done 覆写为 error；非 error 终态统一清除，防残留末轮前的旧分类）
		errorKind: facts.status === "error" ? classifyErrorKind(facts.errorMessage) : undefined,
		durationMs: rounds.reduce((s, r) => s + (r._tracePayload?.durationMs || 0), 0),
		toolCalls: rounds.reduce((s, r) => s + (r._tracePayload?.toolCalls || 0), 0),
		input: sumDefinedNums(rounds.map((r) => r._tracePayload?.input)),
		output: sumDefinedNums(rounds.map((r) => r._tracePayload?.output)),
		cacheRead: sumDefinedNums(rounds.map((r) => r._tracePayload?.cacheRead)) || undefined,
		cacheWrite: sumDefinedNums(rounds.map((r) => r._tracePayload?.cacheWrite)) || undefined,
		cost: sumDefinedNums(rounds.map((r) => r._tracePayload?.cost)),
		...(mergedCostSource !== undefined ? { costSource: mergedCostSource } : {}),
		assistantCalls: sumDefinedNums(rounds.map((r) => r._tracePayload?.assistantCalls)) ?? 0,
		...(usageMissingCalls !== undefined ? { usageMissingCalls } : {}),
		firstCallContext,
		...(lastCall !== undefined ? { lastCall } : {}),
		...(nestedUsage !== undefined ? { nestedUsage } : {}),
		...(compactionUsage !== undefined ? { compactionUsage } : {}),
		preflightBytes: sumDefinedNums(rounds.map((r) => r._tracePayload?.preflightBytes)) ?? 0,
		usageCoverage,
		toolNames: [...new Set(rounds.flatMap((r) => r._tracePayload?.toolNames || []))],
		autoContinueRounds: facts.autoContinueRounds,
		autoRepairRounds: facts.autoRepairRounds,
		verificationMs: facts.verificationMs,
		...(rounds.length > 1 ? { runs: traceRuns, modelSubtotals } : {}),
	};
	const mergedStats: CumulativeStatsEntry = {
		...rr._statsPayload,
		status: facts.status,
		durationMs: rounds.reduce((s, r) => s + (r._statsPayload?.durationMs || 0), 0),
		input: sumDefinedNums(rounds.map((r) => r._statsPayload?.input)),
		output: sumDefinedNums(rounds.map((r) => r._statsPayload?.output)),
		cacheRead: sumDefinedNums(rounds.map((r) => r._statsPayload?.cacheRead)) || undefined,
		cacheWrite: sumDefinedNums(rounds.map((r) => r._statsPayload?.cacheWrite)) || undefined,
		cost: sumDefinedNums(rounds.map((r) => r._statsPayload?.cost)),
		...(mergedCostSource !== undefined ? { costSource: mergedCostSource } : {}),
		assistantCalls: sumDefinedNums(rounds.map((r) => r._statsPayload?.assistantCalls)) ?? 0,
		...(usageMissingCalls !== undefined ? { usageMissingCalls } : {}),
		firstCallContext: rounds[0]?._statsPayload?.firstCallContext,
		...(lastCall !== undefined ? { lastCall } : {}),
		...(nestedUsage !== undefined ? { nestedUsage } : {}),
		...(compactionUsage !== undefined ? { compactionUsage } : {}),
		preflightBytes: sumDefinedNums(rounds.map((r) => r._statsPayload?.preflightBytes)) ?? 0,
		usageCoverage,
		...(rounds.length > 1 ? { modelSubtotals } : {}),
		rounds: rounds.length,
	};
	return { trace: mergedTrace, stats: mergedStats };
}

export async function runTask(agent: AgentConfig, task: string, opts: RunTaskOptions): Promise<RunResult> {
	// ev-20260916-101d8a：链尽冷却重派复用冷却开始时建的占位记录（queued/cooldown）。
	const taskId = opts.preCreatedTaskId ?? genTaskId();
	// ev-20260910-060c3a：显式 param 为最高优先级（resolveModelInternal 首行即返回 param）；保留命中来源供结果回显。
	const _modelResolution = resolveModelWithSource(agent, { paramModel: opts.model, fallbackModel: opts.fallbackModel, cwd: opts.cwd });
	const model = _modelResolution.spec;
	const sessionName = `${agent.name}-${taskId.slice(0, 8)}`;
	// v1.5.176: 派发前归一/校验（execute 普通路径已先行拦截，此处兜底编排/resume/直接调用；
	// 幂等：全限定 spec 直通无 note）。失败不建 registry 记录（与 execute 层早错语义一致）。
	const _nm = normalizeModelSpec(model, opts.modelRegistry);
	if (!_nm.ok) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model, errorMessage: _nm.error };
	const effModel = _nm.spec;
	// v1.5.186 T2-7d provider 熔断：Open 冷却期 fail-fast（不 spawn 不烧退避；实战 glm 超时风暴 ~2min/任务）。
	if (isProviderBreakerEnabled()) {
		const _cbProvider = providerOfSpec(effModel);
		const _cb = providerBreakerCheck(_cbProvider);
		if (_cb.open && !_cb.probe) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: `[熔断] provider "${_cbProvider}" 连续 ${_cb.consecutiveFailures} 次瞬时故障，断路器 Open（约 ${Math.ceil((_cb.retryAfterMs ?? 0) / 1000)}s 后半窗探针自动恢复）。故障期盲派只会重复烧退避时间。建议：稍候重试 / 换其他 provider 模型 / AMAGI_CB_ENABLED=0 关闭熔断` };
	}
	// 2026-08-16 复盘 P0-2：派发前 context 预算预估——任务文本超窗预算拒单（sync 主路径；
	// background/resume 各自同检；不建 registry 记录，与模型校验失败同语义）。
	const _ctxReject = contextBudgetReject(task, effModel, opts.modelRegistry);
	if (_ctxReject) return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _ctxReject };
	// 8月迭代 pi-0.84 配合 修复轮（Major-4）：auth 预检上移至准入占位/建档之前——fail-fast 失败
	// 不占并发槽、不留 error 记录（与上方 _ctxReject 同款「无建档无占槽」返回路径）。
	// opts.command（测试 fake runner 注入）跳过：注入的 command 是脚本路径不是 pi，无从 auth check。
	if (!opts.command) {
		try {
			await authPreflight(effModel);
		} catch (e) {
			const _authReject = e instanceof Error ? e.message : String(e);
			return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _authReject };
		}
	}
	// ── K5a 统一 submit 路径（方案 §3.5/§8.1-K5a；与 background 共用——delivery 不分状态机）──
	// 归一化输入 → 冻结真实 TaskSpec → 内核 register（saveSpec+current 清单落盘成功才继续）→ 共享准入
	// → grant-start（launchIntent 持久化先于 spawn）→ 引擎启动。清单失败封闭：明确错误返回，
	// 不占槽、不 spawn（旧路径 registry.create 失败会 throw；统一为结构化错误回流，K5a 验收 1）。
	const _subP = submitTaskKernel({
		taskId, agent: agent.name, assignment: task, goal: opts.description || opts.journalGoal || currentAssignmentBody(task), cwd: opts.cwd, model: effModel, mode: "sync",
		name: opts.name, relation: opts.relation, allowedPaths: opts.allowedPaths,
		artifactRefs: extractArtifactRefs(currentAssignmentBody(task)), upstreamArtifactRefs: extractArtifactRefs(currentAssignmentBody(task)) || [],
		...(opts.contextMode !== undefined ? { contextMode: opts.contextMode } : {}),
		...(opts.outputs !== undefined ? { outputs: opts.outputs } : {}),
		...(opts.permission !== undefined ? { permission: opts.permission } : {}),
		...(opts.worktreeDispatch !== undefined ? { worktreeDispatch: opts.worktreeDispatch } : {}),
		...(opts.preCreatedTaskId === taskId ? { reuseQueued: true } : {}),
	});
	// 内核 register 的同步前缀已建档（内存态+投影）——在此定格登记时刻 revision 作为 dispatch stale 基线
	//（store 提交等待窗口内的取消会 bump revision，但不得改写本值；与旧「create 后即捕获」语义一致）。
	const dispatchRevision = registry.get(taskId)?.revision ?? 0;
	const _sub = await _subP;
	if (!_sub.ok) {
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _sub.message };
	}
	// 仅成功提交进入所有权清理范围：被拒的重复提交不得释放已有同 taskId 的 lease。
	try {
	// P0.5：派发 journal 落盘（中断后有迹可循；失败静默不影响主流程）。
	// ev-20260916-101d8a：冷却占位重派（preCreatedTaskId）在占位建档时已留痕，不重复 journal。
	if (opts.preCreatedTaskId !== taskId) {
		journalDispatch({ taskId, agent: agent.name, name: opts.name, goal: opts.journalGoal ?? task, cwd: opts.cwd || process.cwd(), mode: "sync", model: effModel, ...opts.relation });
	}
	// v2 批次B 共享准入（K5a：清单落盘成功后才占槽——按 effModel 的 provider/model 分池）；
	// 任务全程（含自动续跑各轮）只占一槽（taskId 即槽位键，tryOccupy 幂等）。
	const _occ = tryOccupy(taskId, { modelSpec: effModel, cwd: opts.cwd });
	// K5a 窗口防护：清单落盘（异步 store 提交）与占位之间被取消——记录已 cancelled 时不入队等待/不 spawn，
	// 出队 + 归还槽位后按取消收口（文案与旧同步路径两分支一致：排队中/启动前）。
	if (registry.get(taskId)?.status === "cancelled") {
		const _cancelMsg = _occ === "queued" ? "任务在排队等待执行槽位时被取消" : "任务在启动前被取消";
		if (_occ === "queued") cancelQueued(taskId);
		releaseAdmission(taskId);
		return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: _cancelMsg, completionAnnotation: "", dispatchRevision };
	}
	if (_occ === "queued") {
		// 排队等待晋级：登记 sync-wait。通用工具边界事件不足以表达排队/长等待的持续活性，
		// 与 runPiTask sync 尾段相同地用领域计数豁免。
		beginSyncWait();
		let _grant: "running" | "cancelled";
		try { _grant = await waitForGrant(taskId); } finally { endSyncWait(); }
		const _rec = registry.get(taskId);
		if (_grant !== "running" || !_rec || _rec.status === "cancelled") {
			releaseAdmission(taskId); // 幂等：未占槽 no-op；已晋级但 record 已 cancelled 时回收槽位
			return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: "任务在排队等待执行槽位时被取消", completionAnnotation: "", dispatchRevision };
		}
		// K5a：晋级 = 内核 grant-start 命令（launchIntent 先于 spawn 持久化）；失败封闭（不 spawn，槽位回收）
		const _gs = await grantStartTask(taskId);
		if (!_gs.ok) {
			releaseAdmission(taskId);
			return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: `任务晋级启动失败（未 spawn）：${_gs.message}`, completionAnnotation: "", dispatchRevision };
		}
		try { registry.patch(taskId, { queueMs: Date.now() - (_rec.queuedAt || Date.now()), queueReason: "capacity" }); } catch { /* lint-exempt:排队观测位写入尽力而为 */ }
	} else {
		// 立即占槽：先持久化 launchIntent 再进入 spawn 准备段（§3.5）；失败封闭（不 spawn，槽位回收）。
		// ev-20260916-101d8a：冷却占位记录（queued/cooldown）复用同路径晋级——queueMs 含冷却等待，
		// 取消竞态由内核 grant-start 拒绝非 queued 收口。
		const _gs = await grantStartTask(taskId);
		if (!_gs.ok) {
			releaseAdmission(taskId);
			return { taskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "error", timedOut: false, aborted: false, sessionName, model: effModel, errorMessage: `[submit 拒绝] 启动意图持久化失败（未 spawn）：${_gs.message}` };
		}
		const _qRec = registry.get(taskId);
		if (_qRec?.queuedAt) { try { registry.patch(taskId, { queueMs: Date.now() - _qRec.queuedAt }); } catch { /* lint-exempt:queueMs 观测位写入尽力而为 */ } }
	}
	const tools = resolveAgentTools(agent, opts.cwd);
	const args = ["--mode", "json", "-p", "--name", sessionName];
	if (effModel) args.push("--model", effModel);
	args.push("--tools", tools.join(","));
	// B0-1（附录 B.1）：本次实际注入快照的 UTF-8 字节数（未注入=0；随 stats/trace 落盘供 §7.4 裁剪决策）。
	let preflightBytes = 0;
	let tmpDir: string | null = null, tmpFile: string | null = null;
	try {
		// v2.15.0 大发射守卫 · prompt 层（事前引导）：effModel 的 provider（/ 前段）命中 riskyProviders
		// 时在子进程 system prompt 末尾追加「大发射纪律」分节（maxBytes 动态渲染；工具层硬闸见
		// write/edit-override 挂载的 enforceLarge*Emission——流死在发射阶段，纯工具闸救不了当轮，
		// 必须让模型生成前就知道规矩）。不命中零注入零字节。
		const _emissionLine = largeEmissionDisciplineLine(providerOfSpec(effModel), opts.cwd);
		const _systemPrompt = _emissionLine ? `${agent.systemPrompt}\n\n## 大发射纪律（通道适配）\n${_emissionLine}` : agent.systemPrompt;
		if (_systemPrompt.trim()) { const tmp = await writePromptTmp(agent.name, _systemPrompt); tmpDir = tmp.dir; tmpFile = tmp.file; args.push("--append-system-prompt", tmpFile); }
		const autoVerify = (!!opts.verification || !opts.command) && automaticVerificationEnabled(agent.name, opts.trusted);
		// ev-20261001-4f2a9c：同 cwd 并行归因补齐——会话内兄弟（registry）+ 跨会话任务（机器级 v2-store 只读扫描，
		// 排除本会话全部 taskId）。多会话同仓库时外来文件（如其它会话的任务输入目录）归因不再靠子代理猜时间戳。
		const _regRecs = registry.list();
		const preflight = collectWorkspacePreflight(opts.cwd, currentAssignmentBody(task), {
			trusted: !opts.command && opts.trusted,
			autoVerify,
			delivery: "sync",
			siblingWriters: collectSiblingWriterLabels(opts.cwd, taskId, _regRecs),
			foreignWriters: collectCrossSessionWriterLabels(opts.cwd, [taskId, ..._regRecs.map((r) => r.taskId)]),
		});
		preflightBytes = preflight.text ? Buffer.byteLength(preflight.text, "utf8") : 0;
		// ev-20260914-ce6bd2：超长任务书 argv 降级——拼装完成后按最终 prompt UTF-8 字节分流：
		// >128KB 全文落盘 <cwd>/amagi-task/<taskId>/goal-full.md（argv 只投 [派发降级] 摘要）；
		// >900KB 硬上限拒单（E2BIG 防线，文案与 warnLongTaskTexts 同款建议）。
		const _finalPrompt = `${materializeSelectedEvidence(task, opts.cwd, taskId).trimEnd()}${preflight.text ? `\n\n${preflight.text}` : ""}${SHARED_TREE_DISCIPLINE}${DONE_CONTRACT_REMINDER}`;
		const _pp = planTaskPrompt(_finalPrompt, opts.cwd, taskId);
		if (_pp.action === "reject") {
			releaseAdmission(taskId);
			return finalizeLaunchFailure(taskId, agent, sessionName, _pp.reason ?? "任务书超硬上限");
		}
		if (_pp.action === "offload") {
			try { applyTaskPromptOffload(_pp, _finalPrompt); } catch (e) {
				releaseAdmission(taskId);
				return finalizeLaunchFailure(taskId, agent, sessionName, `任务书落盘降级失败: ${String(e)}`);
			}
			args.push(_pp.prompt);
		} else {
			args.push(_finalPrompt);
		}
	} catch (e) {
		return finalizeLaunchFailure(taskId, agent, sessionName, `prompt tmp 失败: ${String(e)}`);
	}
	try {
		// v1.5.188 自动续跑（模型早停根因修复）：work/expert 子 Agent 以 done 结束但未输出完成契约时，
		// 通常是模型「宣告了下一步工具调用但未发出」导致 agent loop 正常退出——进程 exit 0、无错误信号，
		// 此前只能 Leader 人工发现。现在自动用原 session 续跑最多 AMAGI_AUTO_CONTINUE_ROUNDS 轮，
		// stats/trace 聚合为一条逻辑记录（deferStats），避免路由记忆/成本统计被多轮拆分污染。
		const autoMax = Math.max(0, parseInt(process.env.AMAGI_AUTO_CONTINUE_ROUNDS ?? "2", 10) || 0);
		const repairMax = Math.max(0, parseInt(process.env.AMAGI_AUTO_REPAIR_ROUNDS ?? "1", 10) || 0);
		// B1（Wave B）交付物预检输入：「交付物：」标记路径 ∪ 任务文本 artifact refs（去重有界）。
		// 无标记任务（纯只读调查）空数组 → 后续预检零开销跳过。
		// 显式路径可能含空格/中文；从推断文本中先移除其完整出现，避免正则再造一个截断前缀交付物。
		// be7271（ev-20261020）：计算提前到 baseRunOpts 之前——同一集合作为 declaredOutputPaths 透传
		// （终稿缺 ACHIEVEMENT 标题时告警定位声明报告中的合规段），两消费面同源不重复算。
		const inferenceText = (opts.deliverablePaths || []).reduce((text, p) => text.split(p).join(""), currentAssignmentBody(task));
		const deliverablePaths = [...new Set([...(opts.deliverablePaths || []), ...extractDeliverablePaths(inferenceText), ...(extractArtifactRefs(inferenceText) || [])])].slice(0, 16);
		const baseRunOpts = { cwd: opts.cwd, model: effModel, signal: opts.signal, timeoutMs: opts.timeoutMs, command: opts.command, onStall: opts.onStall, onUpdate: opts.onUpdate, eventClockForTest: opts.eventClockForTest, dispatchTime: Date.now(), dispatchRevision, taskCategory: taskCategoryFor(opts.description, currentAssignmentBody(task)), baselineArtifactRefs: extractArtifactRefs(currentAssignmentBody(task)) || [], fuseWarn: fuseWarningFor(agent.name, effModel, taskCategoryFor(opts.description, currentAssignmentBody(task))), deferStats: true as const, preflightBytes, protectedPaths: opts.protectedPaths, allowedPaths: opts.allowedPaths, declaredOutputPaths: deliverablePaths };
		let rr = await runPiTask(agent, args, baseRunOpts, taskId, sessionName) as RunResult;
		const rounds: RunResult[] = [rr];
		let autoRounds = 0;
		let repairRounds = 0;
		// 2026-08-16 复盘 P0-1：400 tool 消息序自愈轮数（AMAGI_SESSION_REPAIR_ROUNDS 可调，默认 1；0 关闭）。
		let toolOrderRepairRounds = 0;
		const toolOrderRepairMax = Math.max(0, parseInt(process.env.AMAGI_SESSION_REPAIR_ROUNDS ?? "1", 10) || 0);
		let verificationMs = 0;
		let verificationFailure: string | undefined;
		let zeroOutputStreak = 0; // 8月迭代 C2：续跑退避计数
		let deliverableRetryUsed = false;
		let deliverableBlocked = false;
		while (true) {
			// 宿主/控制面已中止本轮：400 自愈、续跑、补交与验证修复都不得自动重开。
			if (rr.aborted) break;
			// 2026-08-16 复盘 P0-1：400 tool 消息序自愈——provider 拒绝会话历史（孤儿 tool 消息）时，
			// 原生恢复副本修正当前投影后重派一轮（源会话保留；
			// 有界 1 次，修复无效果则如实交回 Leader——finalErrorMessage 已带定向提示）。
			if (toolOrderRepairRounds < toolOrderRepairMax && rr.status === "error" && rr.sessionId
				&& sessionRepairEnabled() && isToolOrder400(rr.errorMessage || "")) {
				toolOrderRepairRounds++;
				const repair = repairSessionById(rr.sessionId, { cwd: opts.cwd });
				// 2026-08-19 实测（Kimi 过载窗口）：会话零清除项时 400 仍可能是 provider 端瞬时误拒
				// （sanitize 逐行校验零孤儿、同 payload 稍后原样回放 200）——此时同样原地有界重试一轮。
				const action = repairAction(repair);
				if (action !== "none") {
					if (action === "transient-retry") {
						const delay = transientRetryDelayMs();
						if (delay > 0) await new Promise((res) => setTimeout(res, delay));
					}
					const repairNote = action === "transient-retry"
						? TRANSIENT_400_NUDGE
						: repairSummary(repair);
					const nudge = `${EXECUTION_DISCIPLINE_REMINDER}\n\n[amagi 400 消息序自愈 ${toolOrderRepairRounds}/${toolOrderRepairMax}] ${repairNote}请继续完成原任务：已完成的步骤无需重做，按完成契约输出 ACHIEVEMENT 与末行 ${AMAGI_DONE_MARKER}。`;
					const resumeArgs = ["--session", repair.recoveryFile ?? rr.sessionId, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
					registry.reopenForAutoContinue(taskId, { allowError: true });
					rr = await runPiTask(agent, resumeArgs, baseRunOpts, taskId, sessionName) as RunResult;
					rounds.push(rr);
					rr.completionAnnotation = (rr.completionAnnotation ? `${rr.completionAnnotation}\n` : "") + (action === "transient-retry" ? transientRepairSummary() : repairSummary(repair));
					continue;
				}
			}
			if (autoRounds < autoMax && shouldAutoContinue(agent, rr, { zeroOutputStreak })) {
				autoRounds++;
				// 2026-08-19 glm-5.3 实战：reasoning 与正文共享单响应 max_tokens，推理吃光预算时
				// stopReason=length 且零正文（消息只剩 thinking 块）。通用早停 nudge 会诱导模型
				// 从头重新长推理、再次撞顶（两连 length 后 settle 白烧 2×16k 输出）。此处按截断
				// 形态分流：零正文 → 定向告知截断事实、禁止重推导；有正文 → 从中断处续写。
				const stopNote = rr.stopReason === "length"
					? ((rr.output || "").trim().length < 8
						? "你的上一轮推理已达单次响应输出上限，正文一个字都未发出（消息只剩思考块，非任务失败）。已完成的分析无需重新推导——直接基于已有结论压缩思考，马上产出正文或发出下一个工具调用。"
						: "你的上一轮正文在输出上限处被截断。已输出的部分无需重写，从中断处继续即可。")
					: "通常是模型过早停止（宣告了下一步但未发出工具调用）。";
				// ev-20261021-e476e9：与后台路径同一诊断源——结构缺陷（标题拼错/缺标题/空清单/marker 错位）给定向补正指令，
				// marker 缺失（早停/未完成）才走通用续跑文案。
				const formatNudge = completionContractRepairNudge(diagnoseCompletionContract(rr.output || ""));
				const nudge = formatNudge ? `${EXECUTION_DISCIPLINE_REMINDER}\n\n[amagi 自动续跑 ${autoRounds}/${autoMax}] ${formatNudge}` : `${EXECUTION_DISCIPLINE_REMINDER}\n\n[amagi 自动续跑 ${autoRounds}/${autoMax}] 你的上一轮在未输出完成契约（末行 ${AMAGI_DONE_MARKER} + ACHIEVEMENT 清单）的情况下结束——${stopNote}请接手当前工作状态：未完成就继续做完；已完成就补齐 ACHIEVEMENT 清单（逐项：验收标准→证据→状态）与末行 marker。`;
				const resumeArgs = ["--session", rr.sessionId || sessionName, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
				registry.reopenForAutoContinue(taskId);
				rr = await runPiTask(agent, resumeArgs, baseRunOpts, taskId, sessionName) as RunResult;
				rounds.push(rr);
				zeroOutputStreak = (rr.output || "").trim().length < 8 ? zeroOutputStreak + 1 : 0;
				continue;
			}

			// B1（Wave B）交付物预检：done 判定前逐个 existsSync（「交付物：」标记路径 ∪ artifact refs，
			// 相对任务 cwd 解析）。缺失不判 done——先走既有自动续跑机制补跑一轮（nudge 附缺失清单）；
			// 续跑后仍缺（或续跑不可用）→ blocked（blockReason=needs-handoff，复用 Wave A 语义，
			// 附缺失路径清单）。无标记任务零开销跳过；error/blocked 轮次不预检（如实保留其真实状态）。
			if (deliverablePaths.length > 0 && rr.status === "done" && !rr.blocked) {
				const _missing = missingDeliverablePaths(deliverablePaths, opts.cwd);
				if (_missing.length === 0) {
					rr.completionAnnotation = rr.completionAnnotation
						? `${rr.completionAnnotation}\n[交付物预检] ${deliverablePaths.length}/${deliverablePaths.length} 落盘 ✓`
						: `[交付物预检] ${deliverablePaths.length}/${deliverablePaths.length} 落盘 ✓`;
				} else {
					// ev-20260909-819976：与任务实际落盘轨迹（Wave C2 creditedWritePaths→registry.lastWritePaths）
					// 和解。实战 S3-01 真实交付完整且已实物验收，但声明路径与实际落盘路径不一致（语义性声明），
					// existsSync 永远落空 → 白烧一轮补跑后 blocked 驻留 38 分钟直到人工收口。修复三支：
					// ① 全部缺失项在本任务实际写盘轨迹中有同名等价落盘 →「以实际落盘为准」采信为已交付，
					//    维持 done 且不再烧补跑轮（annotation 列 declared→actual 对照供验收核对）；
					// ② 无等价且补跑可用 → 既有自动补跑一轮（nudge 附缺失清单）不变；
					// ③ 补跑后仍缺/不可用 → blocked，且通知必须带判定明细（声明→解析绝对路径）与最近写盘清单，
					//    Leader 无需深挖即可判断缺失真伪。
					const _writes = registry.get(taskId)?.lastWritePaths ?? [];
					const _equiv = matchEquivalentDeliverableWrites(_missing, _writes);
					if (_equiv.length > 0 && _equiv.length === _missing.length) {
						const _pairs = _equiv.map((e) => `${e.declared}→${e.actual}`).join("；");
						const _equivMsg = `[交付物预检·等价落盘] 声明路径未在原位找到，但本任务实际写入了同名文件，按实际落盘采信为已交付（声明与落盘路径不一致，验收请核对）: ${_pairs}`;
						rr.completionAnnotation = rr.completionAnnotation ? `${rr.completionAnnotation}\n${_equivMsg}` : _equivMsg;
						try { registry.appendActivity(taskId, { type: "deliverable_equiv", summary: `[交付物预检·等价落盘] ${_missing.length} 项按实际写盘采信: ${_pairs}`.slice(0, 400), ts: Date.now() }); } catch { /* lint-exempt:活动日志写入尽力而为 */ }
					} else if (!deliverableRetryUsed && autoMax > 0 && rr.sessionId) {
						deliverableRetryUsed = true;
						const nudge = `${EXECUTION_DISCIPLINE_REMINDER}\n\n[amagi 交付物预检] 以下任务声明的交付物尚未落盘：${_missing.join("、")}。请用 write/edit 真实创建/补齐这些文件（不许只宣告产出），完成后照常输出 ACHIEVEMENT 清单（逐项：验收标准→证据→状态）与末行 ${AMAGI_DONE_MARKER}。`;
						const resumeArgs = ["--session", rr.sessionId, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
						registry.reopenForAutoContinue(taskId);
						rr = await runPiTask(agent, resumeArgs, baseRunOpts, taskId, sessionName) as RunResult;
						rounds.push(rr);
						continue;
					} else {
						deliverableBlocked = true;
						const _detail = deliverableResolutionNotes(_missing, opts.cwd);
						const _writeNote = _writes.length > 0 ? `本任务最近实际写盘 ${_writes.length} 处: ${_writes.join(", ")}` : "本任务零写盘记录（未见任何成功 write/edit/bash 写盘）";
						const _equivNote = _equiv.length > 0 ? `；另有 ${_equiv.length} 项已有同名等价写盘（${_equiv.map((e) => `${e.declared}→${e.actual}`).join("；")}）但非全部缺失项可采信` : "";
						const _precheckMsg = `[交付物预检] 任务声明 ${deliverablePaths.length} 项交付物，缺 ${_missing.length}：${_missing.join(", ")}（判定明细 声明→解析路径: ${_detail}${_equivNote}）${deliverableRetryUsed ? "（已自动补跑 1 轮仍缺）" : ""}。${_writeNote}`;
						rr.status = "blocked";
						rr.blocked = true;
						rr.blockReason = "needs-handoff";
						rr.errorMessage = _precheckMsg;
						rr.completionAnnotation = rr.completionAnnotation ? `${rr.completionAnnotation}\n${_precheckMsg}` : _precheckMsg;
						try {
							registry.reopenForAutoContinue(taskId);
							registry.patch(taskId, { status: "blocked", blockReason: "needs-handoff", errorMessage: _precheckMsg });
						} catch { /* lint-exempt:阻断回流登记尽力而为 */ }
						break;
					}
				}
			}

			if (!shouldAutoVerify(agent, rr, ((!!opts.verification || !opts.command) && opts.trusted), producesProjectCodeOf(agent.name, opts.cwd, rr.gitBaseline))) break;
			try {
				const started = Date.now();
				// ev-20260924-0cf0e7（P1）：验证执行权收归——sync auto-verifier 统一走 runBaselineVerification
				// （runStructuredCheck：绑验证对象 + copy-local 依赖冻结），结构化事实随 RunResult 交接给
				// finalizer（唯一执行事实，不重跑）；旧 gatherEvidenceReport 快照路径无依赖冻结能力，其文本
				// 结果曾整段关掉 finalizer 的结构化检查 → 回执恒 not-run/no-structured-fact、accept 恒 waive。
				// 同时删除 preverifiedTest 复用（ev-20260916-23f4a4 遗留）：子进程自报测试结果非 harness 事实，
				// 不能当基线证据——旧“文本即证据”心智残留。opts.verification 测试注入签名不变（无交接 →
				// finalizer 按“无交接事实”处理，autoDetect 生效，语义自洽）。
				// ev-20260916-23f4a4（S5 集成）：冻结预算透传（task > env > 默认；越界值已在 execute 层拒单）。
				let report: EvidenceReport;
				let handedOutcomes: import("./evidence.ts").StructuredCheckOutcome[] | undefined;
				if (opts.verification) {
					report = await opts.verification(opts.cwd);
				} else {
					const v = await runBaselineVerification(opts.cwd, taskId, { timeouts: opts.evidenceTimeouts, trusted: true });
					report = v.report;
					handedOutcomes = v.outcomes;
				}
				verificationMs += Date.now() - started;
				rr.evidenceText = report.text;
				rr.evidenceReport = report;
				if (handedOutcomes) rr.structuredChecks = handedOutcomes;
				const failed = report.test.status === "failed" || report.test.status === "timed-out" || report.test.status === "error";
				if (!failed) break;
				// ev-20260903-780da3：并行干扰豁免——仅首次失败（repairRounds===0；已进修复轮仍失败则走
				// 原路径，防自身缺陷被掩盖）、豁免常量开启、且同 cwd 有活跃兄弟任务（事故链见
				// hasActiveSiblingInCwd 头注释）时，不注入续跑 nudge，保持 done 原判结算并注记放行原因。
				if (repairRounds === 0 && VERIFY_SIBLING_EXEMPT_ENABLED && hasActiveSiblingInCwd(taskId, opts.cwd)) {
					rr.completionAnnotation = (rr.completionAnnotation ? `${rr.completionAnnotation}\n` : "")
						+ "[自动验证·干扰豁免] 基线未通过，但同 cwd 并行任务仍在运行——失败可能来自并行节点 in-flight 改动，已放行结算；集成时由 Leader 全量复核（ev-20260903-780da3）";
					break;
				}
				if (repairRounds >= repairMax || !rr.sessionId) {
					verificationFailure = `[自动验证失败] ${report.test.label || "项目基线"} 未通过；${repairRounds > 0 ? `自动修复 ${repairRounds} 轮后仍失败` : "未进入自动修复"}。`;
					break;
				}
				repairRounds++;
				const nudge = `[amagi 自动验证失败 ${repairRounds}/${repairMax}] harness 已运行确定性基线，任务尚未结算。请依据以下真实失败定位根因并修复；不要修改/删除测试来换取通过。只做本 assignment 范围内改动，完成后照常输出 ACHIEVEMENT 与末行 ${AMAGI_DONE_MARKER}。harness 会再次运行基线，无需为最终报告重复跑整套。\n\n${report.test.detail}${EXECUTION_DISCIPLINE_REMINDER}`;
				const resumeArgs = ["--session", rr.sessionId, "--mode", "json", "-p", "--name", sessionName, "--tools", tools.join(","), ...(tmpFile ? ["--append-system-prompt", tmpFile] : []), ...(effModel ? ["--model", effModel] : []), nudge];
				registry.reopenForAutoContinue(taskId);
				rr = await runPiTask(agent, resumeArgs, baseRunOpts, taskId, sessionName) as RunResult;
				rounds.push(rr);
			} catch (error) {
				rr.evidenceText = `[自动验证异常] ${error instanceof Error ? error.message : String(error)}`;
				break;
			}
		}
		// 聚合落盘：一次逻辑任务 = 一条 stats + 一条 trace。
		if (verificationFailure) {
			rr.status = "error";
			rr.isError = true;
			rr.errorMessage = verificationFailure;
			try {
				registry.reopenForAutoContinue(taskId);
				registry.patch(taskId, { status: "error", errorMessage: verificationFailure });
			} catch { /* lint-exempt:错误回流登记尽力而为 */ }
		}
		// B0-3：多轮合并的观测载体——各轮 _toolExecutions 汇总到最终 RunResult（finalizer 重复全套
		// 观测按各轮统计；只作观测输入，不改变其它语义；单轮路径零开销跳过）。
		if (rounds.length > 1) rr._toolExecutions = rounds.flatMap((r) => [...(r._toolExecutions || [])]);
		// duration/toolCalls/input/output/cost 逐轮求和；自动验证是 harness 时间，单列 verificationMs。
		// B1：交付物预检强制终态（done→blocked）时同样以 rr.status 覆写聚合记录，防路由记忆把未交付计为成功。
		// B0-1（附录 B.1）：聚合实现收口到 mergeDeferredUsage 纯函数（分轮身份 runs[]/分模型小计/
		// 首末上下文按轮次规则/usageCoverage 并集；条件取旧 trace/stats 两分支并集——单轮且无
		// 验证/预检覆写时零开销透传，聚合行仍是每逻辑任务恰一行）。
		const _deferredMerge = rounds.length > 1 || verificationMs > 0 || !!verificationFailure || deliverableBlocked
			? mergeDeferredUsage(rounds, { status: rr.status, errorMessage: rr.errorMessage, autoContinueRounds: autoRounds, autoRepairRounds: repairRounds, verificationMs })
			: undefined;
		if (rr._tracePayload) {
			const mergedTrace: TraceEntry = _deferredMerge?.trace ?? rr._tracePayload;
			writeTrace(mergedTrace);
			updateRoutingStats(mergedTrace);
		}
		if (rr._statsPayload) {
			writeStats(_deferredMerge?.stats ?? rr._statsPayload);
		}
		if (autoRounds > 0) {
			rr.autoContinued = autoRounds;
			// 8月迭代 C3：逐轮摘要（状态+末事件摘录+契约有无）——通知/回流直接可见，免 query_task 翻 JSONL 取证。
			const roundLines = rounds.map((r, i) => {
				const lastEvent = (r.output || "").split("\n").map((l) => l.trim()).filter(Boolean).pop() ?? "(零产出)";
				const clip = lastEvent.length > 80 ? lastEvent.slice(0, 80) + "…" : lastEvent;
				return `R${i + 1} ${r.status}${r.terminatedBy ? `(${r.terminatedBy})` : ""} 末事件: ${clip}${hasDoneMarker(r.output) ? " [含契约]" : ""}`;
			});
			rr.autoRoundSummary = roundLines.join("\n");
			const backoffNote = zeroOutputStreak >= 1 && !hasDoneMarker(rr.output)
				? `\n[续跑退避] 续跑后仍零产出/无契约，已停止自动续跑（疑似环境/模型侧问题，nudge 不可救）——交回 Leader 判定。`
				: "";
			rr.output = `[自动续跑 第${autoRounds}轮] 检测到上轮未按完成契约结束（疑似模型早停），已自动续跑救场（共 ${autoRounds} 轮）。\n[续跑摘要]\n${rr.autoRoundSummary}${backoffNote}\n\n` + rr.output;
		}
		if (repairRounds > 0) {
			rr.autoRepaired = repairRounds;
			rr.output = `[自动验证修复] 基线首次失败后已将真实失败交回同一会话并修复 ${repairRounds} 轮；最终证据见文末。\n\n` + rr.output;
		}
		if (verificationMs > 0) rr.verificationMs = verificationMs;
		// ev-20260910-060c3a / ev-20260910-316c6e：模型可观测性三件套（每次派发结果回显实际生效模型 /
		// 子进程实际运行偏离警示 / 模型类 provider 报错归因候选）。实战：显式覆盖与缺省派发的结果混在
		// 同一会话，400 报错不归属模型，Leader 误判「覆盖未生效」——此处让每次派发的模型事实随结果回流。
		const _modelNotes: Array<string | undefined> = [
			effectiveModelNote(effModel, _modelResolution.source, _modelResolution.amagiOrigin),
			_nm.note,
			modelDeviationNote({ expectedSpec: effModel, actualSpec: rr.model, override: !!opts.model }),
		];
		if (rr.status === "error" && isModelProviderError(rr.errorMessage || rr.spawnError)) {
			_modelNotes.push(modelFailureAdvice({
				failedSpec: effModel,
				configuredSpec: resolveModel(agent, { fallbackModel: opts.fallbackModel, cwd: opts.cwd }),
				registry: opts.modelRegistry,
				fallbackModels: loadFallbackModels(opts.cwd),
			}));
		}
		const _modelNoteText = _modelNotes.filter(Boolean).join("\n");
		if (_modelNoteText) rr.modelNote = _modelNoteText;
		return rr;
	} finally {
		releaseAdmission(taskId); // v2 批次B：sync 终局归还槽位（含异常/自动续跑全路径）
		if (tmpFile) try { fs.unlinkSync(tmpFile); } catch { /* lint-exempt:临时文件清理尽力而为 */ }
		if (tmpDir) try { fs.rmdirSync(tmpDir); } catch { /* lint-exempt:临时目录清理尽力而为 */ }
	}
	} finally {
		// 逻辑任务（包括 auto-repair 全部轮次）结束才释放，不在中间轮撤销 claim。
		if (opts.worktreeDispatch) releaseWorktreeLease(opts.worktreeDispatch.leaseId, "sync task exited", taskId);
	}
}

// ── T2-6 自动检查点：关键节点 setLabel("checkpoint:...")（dist types.d.ts:917，/tree 可回滚）
// C4 fix: 追加专属 checkpoint entry → 取其 entryId → setLabel（不猜主会话最后 entry）
function checkpoint(pi: ExtensionAPI | undefined, agentName: string, status: string, taskId: string, ctx: any): void {
	if (status === "running" || !pi?.setLabel || !pi?.appendEntry) return;
	try {
		const before = ctx?.sessionManager?.getEntries?.() || [];
		const beforeIds = new Set(before.map((entry: any) => entry?.id).filter(Boolean));
		// C4-R4: appendEntry 在 pi runtime 中同步写入真实 sessionManager。
		pi.appendEntry("amagi:checkpoint", { agent: agentName, status, taskId, ts: Date.now() });
		const entries = ctx?.sessionManager?.getEntries?.() || [];
		const appended = [...entries].reverse().find((entry: any) =>
			entry?.type === "custom"
			&& entry?.customType === "amagi:checkpoint"
			&& entry?.data?.taskId === taskId
			&& entry?.id
			&& !beforeIds.has(entry.id));
		if (appended?.id) pi.setLabel(appended.id, `checkpoint:${agentName}-${status}-${taskId.slice(0, 8)}`);
	} catch { /* lint-exempt:checkpoint 标注尽力而为 */ }
}

/** P1（8月迭代第三轮）：超长任务书预警阈值（字符；AMAGI_TASK_LEN_WARN 可调，<=0 关闭）。 */
export function getTaskLenWarnChars(): number {
	const v = Number(process.env.AMAGI_TASK_LEN_WARN);
	return Number.isFinite(v) && v >= 0 ? v : 6000;
}

/**
 * P1（8月迭代第三轮）：超长任务书预警（软提示不阻断）——实战：T2-01 模型停滞 ~10min
 * 因任务书过长（详尽上下文内联）；长材料应落 artifact 传路径，任务书只保留目标+约束+验收。
 * 覆盖单任务/batch tasks[]/fanout/pipeline/redteam/tournament 全部派发形态。
 */
export function warnLongTaskTexts(
	pi: { sendMessage?: (msg: { customType: string; content: string; display: boolean }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void } | undefined,
	params: { task?: string; tasks?: Array<{ name?: string; agent: string; task: string }>; fanout?: unknown[]; pipeline?: unknown[]; redteam?: unknown[]; tournament?: { task?: string } },
): void {
	const threshold = getTaskLenWarnChars();
	if (threshold <= 0) return;
	const hits: Array<{ label: string; len: number }> = [];
	const check = (label: string, text: unknown) => {
		if (typeof text === "string" && text.length > threshold) hits.push({ label, len: text.length });
	};
	check("单任务", params.task);
	for (const t of params.tasks || []) check(`batch[${t.name || t.agent}]`, t.task);
	for (const t of params.fanout || []) check(`fanout[${(t as { agent?: string })?.agent || "?"}]`, (t as { task?: string })?.task);
	for (const t of params.pipeline || []) check(`pipeline[${(t as { agent?: string })?.agent || "?"}]`, (t as { task?: string })?.task);
	for (const t of params.redteam || []) check(`redteam[${(t as { agent?: string })?.agent || "?"}]`, (t as { task?: string })?.task);
	check("tournament", params.tournament?.task);
	if (hits.length === 0) return;
	const listed = hits.slice(0, 4).map((h) => `${h.label} ${h.len} 字符`).join("；") + (hits.length > 4 ? ` 等 ${hits.length} 处` : "");
	try {
		// v1.5.244 注入安全：{triggerTurn:false} 会把消息原位插进 tool 配对中间（严格后端 400）；
		// 改 { deliverAs: "steer" } 在完整 tool 配对之后注入。
			pi?.sendMessage?.({
				customType: "amagi:task-len-warn",
				content: `[任务书过长] ${listed}（阈值 ${threshold}，AMAGI_TASK_LEN_WARN 可调）——单轮消化成本高，长任务书易致子 Agent 停滞/截断；建议：长材料/文档先落 artifact，任务书只保留目标+约束+验收+artifact 路径。本提示不阻断派发。`,
				display: false,
			}, { deliverAs: "steer" });
	} catch { /* lint-exempt:观测提示失败静默 */ }
}

/**
 * ev-20260909-c00fcb①：契约值域/键集/表结构变更类任务的联动面预检提示（纯函数，软提示不阻断）。
 * 实战（S4-02 shape_kind 值域扩展）：联动改动天然跨四层（解析/物化门禁/消费/持久化分区），
 * 派发白名单只给了目标层目录，节点完成后才在报告中报越界阻塞、Leader 直修收口——若初判时
 * 按联动面核对白名单可一次到位。命中关键词且带写入边界（allowedPaths）时返回预警文本，供
 * Leader 核对白名单覆盖面；未命中/无边界返回 null 零噪音。配套：白名单任务已内置越界处置契约
 * （group-scheduler whitelistOverflowContractBlock），预警文案同步告知该兑底机制存在。
 */
const CONTRACT_LINKAGE_RE = /(值域|键集|键名集|表结构|字段集|契约(变更|扩展|演进|新增键|新增字段)|枚举(值)?(扩展|新增|变更)|schema\s*(变更|扩展|演进|migration)|decode\/encode\s*(扩展|新增))/i;

export function contractLinkageWarning(nodes: ReadonlyArray<{ label: string; task: string }>): string | null {
	const hits = nodes.filter((n) => CONTRACT_LINKAGE_RE.test(n.task));
	if (hits.length === 0) return null;
	const listed = hits.slice(0, 6).map((h) => h.label).join("、") + (hits.length > 6 ? ` 等 ${hits.length} 处` : "");
	return `\n\n[契约联动面预警] ${listed} 的任务书命中契约变更关键词（值域/键集/表结构/schema 等）——此类变更通常联动四层：① 解析层（parse/decode/校验）② 物化门禁（definition/常量/门禁清单）③ 消费层（构造/消费方分支）④ 持久化/状态层（分区守卫/迁移）。请核对对应 allowedPaths 是否覆盖全部联动目录，缺漏的目录在重派前显式加入白名单（白名单任务已内置「越界阻塞报告」契约：确需越界时节点会成段报告补丁要点而非停摆）。`;
}

/** ev-20260909-c00fcb②：单派发任务书装配（worktree 提示 + 白名单越界处置契约；纯函数可测）。
 *  与 batch runGroupNode / resume 续轮同语义：带写入边界的任务一律携带越界处置契约。 */
export function assembleSingleTaskText(task: string, worktreeBlock: string | undefined, allowedPaths: readonly string[] | undefined): string {
	const base = worktreeBlock ? `${task}\n\n${worktreeBlock}` : task;
	return allowedPaths && allowedPaths.length > 0 ? base + whitelistOverflowContractBlock() + anchoredResourceDisciplineBlock(allowedPaths) : base;
}

/** ev-20260910-cc75b2：整仓检出定位标注（仓库根 ≠ 派发 cwd）——Leader 回流 / 子 Agent 任务书前缀 / journal 任务摘要共用。
 *  事故：仓库根 battle-sim 下派发 cwd=battle-simulator，worktree 为整仓检出；Leader 在检出根跑 pnpm install/test
 *  向上解析到主树 workspace（「基线全绿」证据实为主树结果），journal/接力包路径无业务子目录前缀与真实落点混淆。
 *  subdirCheckout 缺失（cwd 即仓库根）→ undefined，不产噪音。 */
export function fullRepoCheckoutNote(wt: WorktreeSetup): string | undefined {
	const s = wt.subdirCheckout;
	if (!s) return undefined;
	const missing = s.projectRootExists ? "" : "（注意：该项目根目录在当前 worktree 中不存在——主树未提交/未跟踪目录不在检出内）";
	return `[全仓检出] 仓库根=${s.repoRoot}；项目根=${s.projectRoot}（cwd 相对仓库根的路径: ${s.cwdRel}）——本 worktree 是整仓检出（含仓库内其他目录）：在检出根跑 pnpm/npm install、测试或 build 会向上解析到主树 workspace，结果不代表本 worktree（证据语义污染）；包管理/测试/diff/写盘请在项目根目录下执行并以它为路径基准。${missing}`;
}

// ── ev-20260914-ce6bd2：batch 汇总单节点行（回向截断标注 + 完整结果指引） ──
// 旧实现 `body.slice(0, 600)` 裸截断无任何标注：节点输出 <4096B 未触发 result-fold 落盘时为
// 纯信息丢失；>4096B 时 body 已是 foldResultText 折叠文本（头部 2048B+折叠说明+完整结果文件
// 路径），再被 600 字切掉会把「完整结果路径」说明一并切掉——Leader 既不知道被截了，也不知道
// 全文去哪拿。修复：截断发生时附①截断标注（节点输出共 N 字）②完整结果指引一行（优先级：
// artifact result.md → 节点 reportPath → 完整 taskId 的 query_task 轨迹）。

/** batch 汇总单节点行 body 保留阈值（字符）。 */
const BATCH_NODE_BODY_KEEP = 600;

/** batch 汇总单节点行（纯函数，正负可测）。 */
export function renderBatchNodeLine(
	item: { name: string; agent: { name: string }; cwd?: string; reportPath?: string },
	env: ResultEnvelope,
	baseCwd?: string,
): string {
	const status = env.display?.status || env.status;
	const body = env.display?.output || env.summary || env.error?.message || "(无输出)";
	// ev-20260910-060c3a：组汇总逐节点带模型回显（只取首行控制体积；完整 note 已在节点/artifact 回流）。
	const _modelFirstLine = env.display?.modelNote ? `\n   ${env.display.modelNote.split("\n")[0]}` : "";
	if (body.length <= BATCH_NODE_BODY_KEEP) {
		return `${item.name} ${item.agent.name}#${env.taskId.slice(0, 8)}: ${status} — ${body}${_modelFirstLine}`;
	}
	// 截断标注 + 完整结果指引（仅截断时附——短输出零噪音）
	return `${item.name} ${item.agent.name}#${env.taskId.slice(0, 8)}: ${status} — ${body.slice(0, BATCH_NODE_BODY_KEEP)}…（已截断，节点输出共 ${body.length} 字）\n   → ${batchFullResultGuide(item, env, baseCwd)}${_modelFirstLine}`;
}

/** 截断节点的完整结果指引（优先级探测，纯读；envelope/display 不携带 foldResultText 的
 *  fullRel——按 taskId 经 findArtifact 权威探测 result.md 存在性，同口径）。 */
function batchFullResultGuide(item: { cwd?: string; reportPath?: string }, env: ResultEnvelope, baseCwd?: string): string {
	try {
		const nodeCwd = item.cwd && item.cwd.trim()
			? (path.isAbsolute(item.cwd) ? item.cwd : path.resolve(baseCwd || process.cwd(), item.cwd))
			: (baseCwd || process.cwd());
		const art = findArtifact(nodeCwd, env.taskId);
		if (art) return `完整结果: read ${art.relResult}（artifact result.md 全文）`;
	} catch { /* lint-exempt:探测失败降级下一优先级 */ }
	if (item.reportPath && item.reportPath.trim()) return `节点报告: ${item.reportPath.trim()}`;
	// 完整 taskId（勿用 8 位短前缀——前缀歧义，ev-20260914-4150dd 刚修过该坑）
	return `完整轨迹 query_task({ session: "${env.taskId}" })`;
}

// ── ev-20260907-8abf9a（ux/P1）：任务书报告路径占位符软提示 ──
// 事故：任务书模板「报告写 …/<节点名>-report.md」的尖括号占位符被 2/11 实现节点解析为截断前缀，
// 落盘单字符路径。结构性修复是 tasks[].reportPath（解析后绝对路径注入 assignment，见
// group-scheduler resolveNodeReportPath）；本软提示覆盖「未用结构化字段而任务书内残留占位符」的
// 场景：行级检测（同一行同时含「报告/report」语义与尖括号/${} 占位符），提醒 Leader 改用结构化
// 字段——不阻断派发，不猜路径（绝不替 Leader 猜占位符应展开成什么）。
const REPORT_LINE_RE = /报告|report/i;
// ev-20260909-957cdf（ux/P3）：占位符检测收窄到路径语义。
// 尖括号占位符仅当 ① 内容含路径分隔符 / 或 \，② 同属该行含路径赋值语义（路径|落盘|写入|写至|写到|保存|输出到|报告写），
// 或 ③ 占位符紧邻路径分隔符（后跟 / 或 \，如「最终报告：<节点名>/final.md」的 <节点名>）才计 hit；
// CLI 形态（--flag 后跟不含分隔符的单尖括号词，如 --demo <id>）跳过。${var} 与 {var} 模板检测维持不变。
// diting 审核 Major-1（ev-20260909-957cdf 复审）：初版收窄只看尖括号内分隔符+行内赋值词，
// 漏掉原始事故措辞「报告写 …/<节点名>-report.md」「报告写 <节点名>-report.md」「最终报告：<节点名>/final.md」
//（路径语义在尖括号外）——补「报告写」关键词与紧邻分隔符条件，CLI 跳过走 isCli 分支不受影响。
const TEMPLATE_VAR_RE = /\$\{[^}\s]{1,64}\}|\{[A-Za-z_][A-Za-z0-9_-]{0,31}\}/;
const PATH_ASSIGN_RE = /路径|落盘|写入|写至|写到|保存|输出到|报告写/;
const ANGLE_BRACKET_RE = /<([^<>\s]{1,64})>/g;
const CLI_FLAG_PREFIX_RE = /(?:^|\s)--[A-Za-z0-9_-]+[=\s]+$/;

export function isReportPathPlaceholderLine(line: string): boolean {
	if (!REPORT_LINE_RE.test(line)) return false;
	if (TEMPLATE_VAR_RE.test(line)) return true;

	const hasPathAssign = PATH_ASSIGN_RE.test(line);
	ANGLE_BRACKET_RE.lastIndex = 0;
	let m: RegExpExecArray | null;
	while ((m = ANGLE_BRACKET_RE.exec(line)) !== null) {
		const inner = m[1];
		const prefix = line.slice(0, m.index);
		const isCli = CLI_FLAG_PREFIX_RE.test(prefix);
		const hasSlash = inner.includes("/") || inner.includes("\\");
		// diting Major-1 ③：占位符紧邻路径上下文（后跟分隔符）也是路径形态——原收窄漏检事故措辞。
		const suffixCh = line[m.index + m[0].length] ?? "";
		const adjacentPath = suffixCh === "/" || suffixCh === "\\";
		if (isCli && !hasSlash) {
			continue;
		}
		if (hasSlash || hasPathAssign || adjacentPath) {
			return true;
		}
	}
	return false;
}

/** 占位符检测（纯函数，可测）：单行同时命中报告语义与收窄后的未展开占位符即计（ev-20260909-957cdf）。 */
export function reportPathPlaceholderHits(
	params: { task?: string; tasks?: Array<{ name?: string; agent: string; task: string; reportPath?: string }> },
): Array<{ label: string; excerpt: string }> {
	const hits: Array<{ label: string; excerpt: string }> = [];
	const check = (label: string, text: unknown) => {
		if (typeof text !== "string") return;
		for (const line of text.split(/\r?\n/)) {
			if (isReportPathPlaceholderLine(line)) {
				hits.push({ label, excerpt: line.trim().slice(0, 120) });
				return;
			}
		}
	};
	check("单任务", params.task);
	for (const t of params.tasks || []) {
		// 已提供结构化 reportPath 的节点不提示（占位符问题已被结构化字段消除）
		if (typeof t.reportPath === "string" && t.reportPath.trim()) continue;
		check(`batch[${t.name || t.agent}]`, t.task);
	}
	return hits;
}

/** 软提示注入（仿 warnLongTaskTexts 形态）：命中占位符行 → steer 提醒改用 tasks[].reportPath。 */
export function warnReportPathPlaceholders(
	pi: { sendMessage?: (msg: { customType: string; content: string; display: boolean }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void } | undefined,
	params: Parameters<typeof reportPathPlaceholderHits>[0],
): void {
	const hits = reportPathPlaceholderHits(params);
	if (hits.length === 0) return;
	const listed = hits.slice(0, 4).map((h) => `${h.label}: “${h.excerpt}”`).join("；") + (hits.length > 4 ? ` 等 ${hits.length} 处` : "");
	try {
		pi?.sendMessage?.({
			customType: "amagi:report-path-hint",
			content: `[报告路径占位符] 检测到任务书报告路径含未展开尖括号占位符（${listed}）——实战事故 ev-20260907-8abf9a：占位符被子 Agent 解析为截断前缀、落盘单字符路径。建议改用结构化字段 tasks[].reportPath（完整具体文件路径，相对节点 cwd 解析为绝对后注入 assignment）；占位符不会被自动展开，派发工具也不猜路径。本提示不阻断派发。`,
			display: false,
		}, { deliverAs: "steer" });
	} catch { /* 观测提示失败静默 */ }
}

// ── ev-20260917-8651a0（P3②）：任务书「报告：<路径>」句式软提示 ──
// 实战：F6d/F6f 任务书正文写了报告绝对路径而未用 reportPath 参数（该参数此前只在 batch
// tasks[].reportPath 存在），两份报告分别落到仓库根 ./evidence/ 与 amagi-task/evidence/，
// Leader 手动 mv 归位两次。派发端检测任务书报告路径句式（报告：/报告落盘到/最终报告保存至…
// + 路径 token）而未用结构化 reportPath 参数时软提示转参（不阻断、不猜路径——仍按任务书原文执行）。
const REPORT_SENTENCE_RE = /(?:最终|完整|产出)?报告\s*(?:[:：]\s*|落盘(?:至|到)\s*|保存(?:至|到)\s*|写(?:入|至|到)\s*)([^\s，。；、,)\]】」\n]{3,})/;

/** 句式检测（纯函数，可测）：单任务任务书命中报告路径句式且未提供结构化 reportPath 参数 → 摘录行。 */
export function reportPathSentenceHits(params: { task?: string; reportPath?: unknown }): Array<{ excerpt: string }> {
	if (typeof params.reportPath === "string" && params.reportPath.trim()) return [];
	if (typeof params.task !== "string") return [];
	const hits: Array<{ excerpt: string }> = [];
	for (const line of params.task.split(/\r?\n/)) {
		const m = REPORT_SENTENCE_RE.exec(line);
		if (m && m[1]) { hits.push({ excerpt: line.trim().slice(0, 120) }); break; }
	}
	return hits;
}

/** 句式软提示注入：命中 → steer 提醒改用 reportPath 参数（单任务面；不阻断派发）。 */
export function warnReportPathSentence(
	pi: { sendMessage?: (msg: { customType: string; content: string; display: boolean }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void } | undefined,
	params: Parameters<typeof reportPathSentenceHits>[0],
): void {
	const hits = reportPathSentenceHits(params);
	if (hits.length === 0) return;
	try {
		pi?.sendMessage?.({
			customType: "amagi:report-path-hint",
			content: `[报告路径句式] 检测到任务书报告路径句式（${hits[0]!.excerpt}）而未用 reportPath 参数——实战 ev-20260917-8651a0：任务书内报告路径与实际落盘位错位，Leader 手工归位两次。建议改用结构化参数 reportPath（完整具体文件路径，相对任务 cwd 解析为绝对后注入任务书并接交付物验收链）。本提示不阻断派发。`,
			display: false,
		}, { deliverAs: "steer" });
	} catch { /* 观测提示失败静默 */ }
}

// ── ev-20260903-a5b662（复盘 §5#2）：大改任务 worktree 引导 ──
// 背景：9 文件半成品直接落在主工作树的事故——大范围重构/迁移类任务在宿主中断/取消后无对账
// 基线，主树污染只能人工回滚。启发式识别任务书大改特征，软建议（不阻断）携带 worktree 派发。
// ev-20260916-2dbc7f/c5ee56（S4/S2 集成）：纯评估（looksLikeLargeChange/looksLikeReadOnlyTask）已迁
// dispatch-preflight.ts（唯一实现，task-tool 旧件已删）；本函数仅作为 AMAGI_WORKTREE_PREFLIGHT=legacy
// 回滚路径的事后 steer 递送器保留——preflight 默认模式下不在派发/终态补发建议（建议经 dryRun 前置返回）。

/** 角色章程只读判定（ev-20260906-d8fcf1①）：只读章程角色（baize/diting）的产出是报告而非树内代码改动，
 *  worktree 隔离建议对它们恒为噪音。唯一据 frontmatter capabilities 章程（charter，缺省按 write 上限）判定
 *  （agents-loader.roleIsReadOnly）——不再匹配 description 措辞，改文案不改判定。非只读角色仍由任务书语义判定。 */
export function agentCharterReadOnly(agent: Pick<AgentConfig, "capabilities" | "capabilitiesError"> | undefined): boolean {
	return roleIsReadOnly(agent);
}

// ── ev-20260905-c0b446（friction/P1）：worktree 建议抑制 ──
// 事故：Database 下非 git 文档目录的目标每次派发都误报“命中大改特征”（7+ 次），全部不适用且无记忆抑制。
// ev-20260907-ac9d12（ux/P2）收紧：旧 ignored≥2 静默改为「同 cwd + 同 git 工作区状态至多提示一次」
//（事故：C0 派发建议后 Leader 已裁定不采纳，C3c 再派同会话又发一次——建议器无记忆）；
// git 脏/干净状态翻转视为「状态改变」可重新提示（新状态是新事实，值得一次新建议）。
interface WorktreeSuggestState { suggested: number; /** 上次建议时刻的 git 脏树状态；null=探测失败（未知，诚实保守：不附注脏树结论，连续失败与连续失败视为同状态去重）。 */ lastDirty: boolean | null; /** ev-20260914-fd8787：该 cwd 已被识别为「主树依赖」工作流（脏树结论至少发过一次）——后续派发不再重复整段建议（记忆粘滞到会话结束：波次间的干净树不重新武装建议器）。 */ mainTreeSeen?: boolean; }
const worktreeSuggestState = new Map<string, WorktreeSuggestState>();

/** 测试注入：清空 worktree 建议状态表（会话级内存，不持久化）。 */
export function resetWorktreeSuggestState(): void { worktreeSuggestState.clear(); }

/** ev-20260910-cfc332：抑制表键规范化（realpath 优先）——同一目录的不同写法（尾部斜杠、macOS /var↔/private/var
 *  符号链接前缀）此前各占一条记录，会把「同 cwd 同状态至多提示一次」的去重绕过。 */
function worktreeSuggestKey(cwd: string): string {
	try { return fs.realpathSync(cwd); } catch { /* journal:realpath-fallback */ return path.resolve(cwd); }
}

function worktreeSuggestEnabled(): boolean {
	const v = process.env.AMAGI_WORKTREE_SUGGEST;
	return !(v === "0" || v === "false" || v === "off");
}

/** ev-20260907-ac9d12：git 工作区脏树探测（有界、低频路径专用）。
 *  安全有界深约：git status --porcelain 本地只读；timeout 2s；maxBuffer 64KiB；输出仅计数不落盘。
 *  失败（非仓库/超时/git 不存在）→ { ok:false }——诚实保守：调用方不得把失败当作干净或脏。 */
export function probeGitDirtyState(cwd: string): { ok: true; dirty: boolean; entries: number } | { ok: false } {
	try {
		const out = execFileSync("git", ["status", "--porcelain"], { cwd, timeout: 2000, maxBuffer: 64 * 1024, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
		const entries = out.split("\n").filter((l) => l.trim().length > 0).length;
		return { ok: true, dirty: entries > 0, entries };
	} catch { /* journal:git-status-probe-fallback */ return { ok: false }; }
}

/** 从 start 向上有界查找 .git（.git 目录或 worktree 链接文件均算 git 仓库；深度 ≤32，止于 fs 根）。 */
function isInsideGitRepo(start: string): boolean {
	let dir = path.resolve(start);
	for (let i = 0; i < 32; i++) {
		if (fs.existsSync(path.join(dir, ".git"))) return true;
		const parent = path.dirname(dir);
		if (parent === dir) return false;
		dir = parent;
	}
	return false;
}

/** 大改任务 worktree 软建议（ev-20260903-a5b662）：仅单任务新派发（agent+task 齐备、无 worktree、
 *  非 resume）且命中大改特征时，向 Leader 注入一次性 steer 提示；不阻断本次派发。
 *  ev-20260905-c0b446：opts.cwd（可选，向后兼容）——非 git 目标跳过（worktree 语义只对 git 仓库成立）。
 *  ev-20260906-d8fcf1：opts.agentReadOnly（可选，派发面按 agentCharterReadOnly 判定后传入）或任务书
 *  只读/审查语义（looksLikeReadOnlyTask）时跳过——审核对象≠改动面；建议文案补依赖隔离限制与缓解。
 *  ev-20260907-ac9d12①：会话级去重收紧为「同 cwd + 同 git 脏/干净状态至多提示一次」——旧 ignored≥2
 *  静默下同会话第二次派发仍会重复建议（事故：C0 建议后已裁定不采纳，C3c 又发一次，建议器无记忆）；
 *  状态翻转（干净→脏 / 脏→干净）视为新事实可重发一次。git 探测失败按「未知(null)」参与同状态去重
 *  （连续失败不刷屏），但不附注脏树结论（诚实保守，不猜测工作区状态）。
 *  ev-20260907-ac9d12②：脏树感知——探测成功且存在未提交改动时，建议附注「worktree 是全新 checkout，
 *  不含主树未提交前置改动；任务书若引用主树未提交产物，新树内不可见、新树直跑验证不能作为前置产物
 *  可用的证据」，阻止给出「未含前置产物树可直接验证」的暗示。AMAGI_WORKTREE_SUGGEST=0 一键关闭。
 *  ev-20260910-cfc332（friction/P2）：派发目标已在独立工作树内（isInsideLinkedWorktree，含不带 worktree
 *  参数、直接以 cwd=<worktree 根> 派发的形态）→ 直接静默——树内未提交改动是本 workflow 前序阶段的合法
 *  半成品（worktree 内累积产出），不是主仓未提交前置产物；对已隔离的派发重复给「建议直接主树作业」不仅
 *  ev-20260914-fd8787（ux/P3）：主树依赖会话级记忆（mainTreeSeen）——同 cwd 一旦识别出「任务书依赖主树
 *  未提交产物」（脏树结论发过一次），后续派发不再重复整段建议（实战：连续单仓波次工程每波都收到建议）；
 *  脏树结论文案改为结论先行（「主树作业更优」），标题不再以 [worktree 建议] 开头自相矛盾。 */
export function suggestWorktreeDispatch(
	pi: { sendMessage?: (msg: { customType: string; content: string; display: boolean }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void } | undefined,
	params: { agent?: string; task?: string; worktree?: string; session?: string; exportPrompt?: boolean | string },
	opts?: { cwd?: string; agentReadOnly?: boolean },
): void {
	if (!worktreeSuggestEnabled()) return;
	if (!params.agent || !params.task || params.worktree || params.session) return;
	// diting 增审 Minor-3（ev20260905 阶段审核）：exportPrompt 为纯导出（不 spawn、产物不落主树），
	// 命中大改特征也不构成 worktree 隔离需求——truthy 时直接跳过。
	if (params.exportPrompt !== undefined && params.exportPrompt !== false) return;
	// ev-20260906-d8fcf1①：只读审查/查询语义不触发——受派角色章程只读（diting/baize…，
	// 派发面按 agentCharterReadOnly 判定后传入）或任务书自带只读/审查指令（书内「重构/迁移」是被审
	// 内容而非改动面）。显式实现指令（实现/修复/先审后改序列…）不受此分支影响，仍走大改判定。
	if (opts?.agentReadOnly || looksLikeReadOnlyTask(params.task)) return;
	if (!looksLikeLargeChange(params.task)) return;
	const cwd = opts?.cwd;
	// cwd 未提供（旧调用面）：无目标目录信息，不做仓库判定与静默记忆（保持向后兼容行为）
	if (cwd !== undefined) {
		// 非 git 仓库直接跳过——实战：文档目录目标 7+ 次建议全部不适用
		if (!isInsideGitRepo(cwd)) return;
		// ev-20260910-cfc332：派发目标已在独立工作树内（含 Leader 预建树 + cwd= 派发）→ 建议不适用，
		// 静默跳过。带 worktree 参数的派发同理由函数头早退覆盖（工作树隔离语义已经成立）。
		if (isInsideLinkedWorktree(cwd)) return;
		// ev-20260907-ac9d12：有界探测当前脏树状态（仅在已命中大改特征、即将发建议的低频路径执行）。
		const probe = probeGitDirtyState(cwd);
		const dirtyState = probe.ok ? probe.dirty : null;
		const key = worktreeSuggestKey(cwd);
		const st = worktreeSuggestState.get(key);
		// ev-20260914-fd8787①：主树依赖会话级记忆——同 cwd 已识别「任务书依赖主树未提交产物」后，后续
		// 派发不再重复整段建议（事故：每波依赖前波未提交产物的单仓工程，几乎每次 sync 派发都收到建议）。
		// 记忆粘滞到会话结束：波次间的干净树（提交清空）不重新武装建议器——该工作流本轮事实已确立（主树作业）。
		if (st?.mainTreeSeen) return;
		// 同 cwd + 同状态（含 探测失败===探测失败 的未知态）已建议过 → 静默；状态翻转 → 重发一次
		if (st && st.lastDirty === dirtyState) return;
		try {
			// ev-20260909-6bb7e3（ux/P3）：脏树两段式噪音合并——git 探测到未提交改动（脏）时直接输出单一结论，
			// 省略通用 worktree 推荐段与通用附注，避免「前脚建议隔离、后脚建议直接主树」的两段矛盾结论。
			let content: string;
			if (probe.ok && probe.dirty) {
				const entries = probe.entries > 99 ? "99+" : String(probe.entries);
				// ev-20260914-fd8787②：脏树依赖文案分流——结论先行（主树作业更优 + 一行依据），标题不以
				// worktree 建议为默认（旧标题「[worktree 建议]…建议直接主树作业」自相矛盾）。
				content = `[worktree 评估·主树优先] 本任务命中大改特征，但派发目标存在 ${entries} 处未提交改动、任务书大概率依赖主树未提交前置产物——主树作业更优（worktree 是全新 checkout，前置产物在新树不可见）；如确需隔离请显式评估前置可见性。本提示不阻断本次派发。`;
			} else {
				const probeNote = !probe.ok
					? " git 工作区状态探测失败（未知）——本建议未基于工作区状态判定（不默认当作干净或脏）；若任务依赖主树未提交前置产物，请自行核对后决策。"
					: "";
				content = `[worktree 建议] 本任务书命中大改特征（重构/迁移/多文件/超长）——建议派发时优先 worktree:true 语义（task 的 worktree 参数传工作树名）在独立工作树作业：半成品不污染主树，宿主中断/取消后可对账合并。依赖隔离限制：worktree 是全新 checkout，不含 node_modules/构建产物等未提交内容——任务若要求自验（typecheck/测试/构建），请在任务书写明验证策略（先把本工作树改动集成/同步回主仓再跑验证并以此为据——未含本次改动的主仓直跑结果不能作为本任务证据；或在新树重装/symlink 依赖后于新树内自验），否则该场景建议直接主树作业。${probeNote}本提示不阻断本次派发。`;
			}
			pi?.sendMessage?.({
				customType: "amagi:worktree-suggest",
				content,
				display: false,
			}, { deliverAs: "steer" });
		} catch { /* 观测提示失败静默 */ }
		worktreeSuggestState.set(key, { suggested: (st?.suggested ?? 0) + 1, lastDirty: dirtyState, mainTreeSeen: (st?.mainTreeSeen || (probe.ok && probe.dirty)) || undefined });
		return;
	}
	try {
		pi?.sendMessage?.({
			customType: "amagi:worktree-suggest",
			content: "[worktree 建议] 本任务书命中大改特征（重构/迁移/多文件/超长）——建议派发时优先 worktree:true 语义（task 的 worktree 参数传工作树名）在独立工作树作业：半成品不污染主树，宿主中断/取消后可对账合并。依赖隔离限制：worktree 是全新 checkout，不含 node_modules/构建产物等未提交内容——任务若要求自验（typecheck/测试/构建），请在任务书写明验证策略（先把本工作树改动集成/同步回主仓再跑验证并以此为据——未含本次改动的主仓直跑结果不能作为本任务证据；或在新树重装/symlink 依赖后于新树内自验），否则该场景建议直接主树作业。本提示不阻断本次派发。",
			display: false,
		}, { deliverAs: "steer" });
	} catch { /* 观测提示失败静默 */ }
}

// ── ev-20260905-c0b446（friction/P1）：停滞告警去重收敛 + 终态过滤加固 ──
// 事故：不朽宗门会话 6 条停滞推送多为噪音——9768769f 已 done 后仍报“静默 542s”（steer 迟投递：
// fire 时 registry 仍 running，消息入队后才终态）；503b960c settled 后仍连收 4 次（settle 收口
// 窗口内进程未退、registry 仍 running，看门狗每阈值窗口一发）。fire 时终态过滤拦不住这两条真实
// 泄漏路径，只能收敛推送量：同任务同 kind 首条照常，第 2/3 条静默累计，超 3× 阈值或 kind 变化
//（exec→no-call 升级）才放行一条升级告警；降档/续跑旧 taskId 告警由 !rec/endedAt 加固兜住。
interface StallDedupeEntry { count: number; pushed: number; firstAt: number; lastPushAt: number; escalated: boolean; }
const stallDedupe = new Map<string, StallDedupeEntry>();
const STALL_DEDUPE_MAX = 64;

/** 测试注入：清空停滞告警去重表（会话级内存，不持久化）。 */
export function resetStallDedupe(): void { stallDedupe.clear(); }

function stallDedupeEnabled(): boolean {
	const v = process.env.AMAGI_STALL_DEDUPE;
	return !(v === "0" || v === "false" || v === "off");
}

/** 去重判定（纯决策）：key = taskId+kind；返回是否放行与升级附注。diting 增审 Minor-2（ev20260905
 *  阶段审核）：附注区分已推送/已静默计数（旧文案“前 N-1 条已静默”把首条已推送的也计入静默数，不实）。 */
function stallDedupeAdmit(taskId: string, kind: string | undefined, idleMs: number): { push: boolean; note?: string } {
	const key = `${taskId}::${kind ?? "default"}`;
	const prefix = `${taskId}::`;
	const taskCount = () => { let n = 0, p = 0; for (const [k, e] of stallDedupe) if (k.startsWith(prefix)) { n += e.count; p += e.pushed; } return { n, p }; };
	const noteOf = (n: number, p: number) => `（本任务累计第 ${n} 条：已推送 ${p} 条、已静默 ${Math.max(0, n - p)} 条）`;
	const entry = stallDedupe.get(key);
	if (!entry) {
		const { n: prior, p: priorPushed } = taskCount();
		// 有界（≤64）：按插入序淘汰最旧条目，防长会话膨胀
		while (stallDedupe.size >= STALL_DEDUPE_MAX) { const oldest = stallDedupe.keys().next().value; if (oldest === undefined) break; stallDedupe.delete(oldest); }
		stallDedupe.set(key, { count: 1, pushed: 1, firstAt: Date.now(), lastPushAt: Date.now(), escalated: false });
		// kind 变化（exec→no-call 等）视为升级：同任务新 kind 首条带累计附注放行一条
		if (prior > 0) return { push: true, note: noteOf(prior + 1, priorPushed + 1) };
		return { push: true };
	}
	entry.count += 1;
	// 静默时长超 3× 阈值：允许一条升级告警（每 kind 一次）
	if (!entry.escalated && idleMs >= getStallThresholdMs() * 3) {
		entry.escalated = true;
		entry.pushed += 1;
		entry.lastPushAt = Date.now();
		const { n: total, p: totalPushed } = taskCount();
		return { push: true, note: noteOf(total, totalPushed) };
	}
	return { push: false };
}

/** C5 统一 onStall 工厂（ev-20260905-c0b446 加固）：终态过滤 + 去重收敛；execute 顶部创建，
 *  resume/orchestrate/sync/background 所有路径共用。 */
export function createStallAlarm(pi: { sendMessage?: (msg: { customType: string; content: string; display: boolean; details?: { taskId?: string } }, opts?: { triggerTurn?: boolean; deliverAs?: "steer" | "followUp" | "nextTurn" }) => void } | undefined): (info: { taskId: string; agent: string; idleMs: number; kind?: "exec" | "no-call" }) => void {
	return (info) => {
		try {
			// 终态后不再告警：终结前排队的消息可能迟到最后才投递（实战：任务已 error 收尾仍连收 stall 警告）。
			// c0b446 加固：rec 缺失（降档/续跑换新 taskId 后的旧 id 告警、未注册 id）与 endedAt 已设
			//（快照回填/重开竞态）同样按终态丢弃。
			const rec = registry.get(info.taskId);
			if (!rec || rec.status !== "running" || rec.endedAt) return;
			// 附检测时刻（steer 排队消息可能延迟投递，时间戳让迟到告警可解释；
			// ev-20260916-804ea3：统一带日期与时区标注，消除与 UTC 时基的混用）
			const at = formatAmagiClock(Date.now(), "local");
			// v1.5.216: 附尾部最近活动摘要，区分健康长命令与真卡死
			const digest = stallActivityDigest(rec);
			// P2（8月迭代第三轮）：kind 分流——执行中静默（工具在飞）标注为正常长命令；
			// 无调用静默（零工具调用）建议精简重派（实战：11 条停滞警告全为合法长命令，0 真停滞）。
			const kindNote = info.kind === "exec"
				? "· 执行中静默（工具在飞：长命令/浏览器验证属正常，本条为 3× 阈值硬上限提示，可忽略）"
				: info.kind === "no-call"
					? "· 无调用静默（全程零工具调用——疑似任务书过长/过载致模型停滞：建议 cancel 后精简任务书重派，或等待首工具调用）"
					: "";
			// ev-20260905-c0b446：去重收敛——同任务同 kind 首条照常；第 2/3 条静默累计不推；
			// 超 3× 阈值或 kind 变化才放行一条升级告警（AMAGI_STALL_DEDUPE=0 恢复逐条推送）
			let dedupeNote = "";
			if (stallDedupeEnabled()) {
				const admit = stallDedupeAdmit(info.taskId, info.kind, info.idleMs);
				if (!admit.push) return;
				dedupeNote = admit.note ?? "";
			}
			// v1.5.244 注入安全：定时器时机不定，steer 在流式/非流式两态都落在完整 tool 配对之后。
			pi?.sendMessage?.({ customType: "amagi:stall-warn", content: `[停滞警告] ${info.agent}/${info.taskId.slice(0, 8)} 静默 ${Math.round(info.idleMs / 1000)}s（检测于 ${at}${digest}）${kindNote}${dedupeNote}；若任务已结束请忽略此条迟到告警`, display: false, details: { taskId: info.taskId } }, { deliverAs: "steer" });
		} catch {}
	};
}

// ── task 工具定义（统一 execute 分发：sync/background/resume/bg-resume） ─────

/** E1: 任务级 cwd 解析——相对 Leader cwd 展开，须为已存在目录。 */
function resolveTaskCwd(param: string | undefined, leaderCwd: string): { ok: true; cwd: string } | { ok: false; message: string } {
	if (!param) return { ok: true, cwd: leaderCwd };
	const resolved = path.resolve(leaderCwd, param);
	let st: fs.Stats;
	try { st = fs.statSync(resolved); } catch { /* journal:cwd-stat-reject */ return { ok: false, message: `[cwd 无效] "${param}"（解析为 ${resolved}）不存在` }; }
	if (!st.isDirectory()) return { ok: false, message: `[cwd 无效] "${param}"（解析为 ${resolved}）不是目录` };
	return { ok: true, cwd: resolved };
}

/** ev-20260908-8d5d8f（P1）+ ev-20260909-f4e896（P1）：allowedPaths 存在性预检——派发准入即校验。
 *  配置错误（漏前缀/typo 的相对路径、逃逸路径）在派发瞬间拒单暴露，不再等子 Agent 跑完数十分钟在写守卫处 blocked；
 *  ev-20260909-f4e896：父链锚定豁免——某项不存在时，沿 path.dirname 向上找最近存在祖先（深度上限 8）；
 *  若该祖先是目录且位于 baseCwd 子树内（path.relative(baseCwd, ancestor) 不以 .. 开头；ancestor===baseCwd 也算在内）
 *  → 视为「任务将创建的目录」合法声明，放行；否则维持拒单（保留原 8d5d8f 拦截漏前缀绝对路径/无关位置路径的动机——
 *  此类路径最近存在祖先在 baseCwd 外）。
 *  逐项错误文案含：①不存在的原始项；②解析基准说明与解析后的绝对路径。
 *  非字符串项/空白项维持既有语义，不在此重复拦截；空数组同样不在本层处理（节点级既有拒单语义保留）。 */
export function allowedPathsExistenceErrors(paths: ReadonlyArray<string>, baseCwd: string, baseLabel: string): string[] {
	const errs: string[] = [];
	// ev-20260909-f4e896：父链锚定豁免——某项不存在时，沿 path.dirname 向上找最近存在祖先（深度上限 8）；
	// 若该祖先是目录且位于 baseCwd 子树内 → 视为「任务将创建的目录」合法声明，放行。
	const anchorExempt = (abs: string): boolean => {
		let cur = abs;
		let nearestExisting: string | null = null;
		for (let depth = 0; depth < 8; depth++) {
			const parent = path.dirname(cur);
			if (parent === cur) break;
			cur = parent;
			if (fs.existsSync(cur)) { nearestExisting = cur; break; }
		}
		if (nearestExisting === null) return false;
		let isDir = false;
		try { isDir = fs.statSync(nearestExisting).isDirectory(); } catch { isDir = false; }
		const rel = path.relative(baseCwd, nearestExisting);
		const inSubtree = nearestExisting === baseCwd || (rel !== ".." && !rel.startsWith(`..${path.sep}`) && !path.isAbsolute(rel));
		return isDir && inSubtree;
	};
	for (const p of paths) {
		if (typeof p !== "string") continue;
		const trimmed = p.trim();
		if (!trimmed) continue;
		const isAbs = path.isAbsolute(trimmed);
		// ev-20260914-9084ee（P1）：白名单三种形态共享 path-match 语义源——①glob（含 */?，如
		// "data/cfg/gds_*.tres"）派发期展开为现存文件集合（零命中时校验静态基目录在 baseCwd 子树内，
		// 任务将创建的匹配文件放行）；②prefix:（如 "prefix:data/cfg/gds_"）派发期校验父目录存在
		//（或父链锚定豁免）；③无语法条目保持「目录或精确文件」既有语义（含 f4e896 豁免），向后兼容。
		// 背景：派发者写 "data/cfg/gds_" 想前缀匹配一组文件，守卫按目录语义判不存在反复拦截达终止阈值。
		const parsed = parseAllowedPathEntry(trimmed);
		if (parsed.invalid) {
			errs.push(`"${p}" 语法无效（${parsed.invalid}）——allowedPaths 支持三种形态：目录/精确文件（默认）、glob 通配（如 data/cfg/gds_*.tres）、显式前缀（prefix:data/cfg/gds_）`);
			continue;
		}
		if (parsed.kind === "glob") {
			const matches = expandGlobPaths(parsed.value, baseCwd);
			if (matches.length > 0) continue; // 展开即现存文件集合，逐项存在性由展开保证
			const staticBase = globStaticBaseDir(parsed.value, baseCwd);
			// diting m-4 同源：基目录存在但非目录（glob 锚到文件上）→ 拒；豁免仅适用于「不存在」的拟建基目录
			let _baseIsDir = false;
			try { _baseIsDir = fs.existsSync(staticBase) && fs.statSync(staticBase).isDirectory(); } catch { _baseIsDir = false; }
			if (_baseIsDir) continue;
			if (fs.existsSync(staticBase)) {
				errs.push(`"${p}"（glob）的基目录 ${staticBase} 存在但不是目录（${isAbs ? "绝对路径形态" : "相对解析"}）——glob 白名单不能锚定到文件上，请核对后重派`);
				continue;
			}
			if (anchorExempt(staticBase)) continue; // 不存在的拟建基目录：目录在子树内 → 任务将创建的匹配文件放行
			errs.push(`"${p}"（glob）未匹配到任何现存文件，且其目录 ${staticBase} 不在${baseLabel} ${baseCwd} 子树内（${isAbs ? "绝对路径形态" : "相对解析"}）——glob 白名单须匹配现存文件或目录位于工作区子树内，请核对后重派`);
			continue;
		}
		if (parsed.kind === "prefix") {
			const valueAbs = path.isAbsolute(parsed.value) ? parsed.value : path.resolve(baseCwd, parsed.value);
			const parent = path.dirname(valueAbs);
			// diting m-4：父路径存在但非目录（文件占据）同样不可锚定——存在≠可用，防 prefix 条目锚到文件上
			let _parentIsDir = false;
			try { _parentIsDir = fs.statSync(parent).isDirectory(); } catch { _parentIsDir = false; }
			if (_parentIsDir) continue; // 父目录真实存在且是目录 → 合法锚定
			if (!fs.existsSync(parent) && anchorExempt(parent)) continue; // 豁免仅适用于「不存在」的拟建父目录（anchorExempt 不看自身存在性，存在文件调之会沿祖先误放行）
			if (fs.existsSync(parent)) errs.push(`"${p}"（显式前缀）的父路径 ${parent} 存在但不是目录（${isAbs ? "绝对路径形态" : `${baseLabel} ${baseCwd} 下解析为 ${valueAbs}`}）——显式前缀须锚定已存在目录（或其祖先在工作区子树内），请核对后重派`);
			else errs.push(`"${p}"（显式前缀）的父目录 ${parent} 不存在（${isAbs ? "绝对路径形态" : `${baseLabel} ${baseCwd} 下解析为 ${valueAbs}`}）——显式前缀须锚定已存在目录（或其祖先在工作区子树内），请核对后重派`);
			continue;
		}
		const abs = isAbs ? trimmed : path.resolve(baseCwd, trimmed);
		if (fs.existsSync(abs)) continue;
		if (anchorExempt(abs)) continue; // 放行拟建子路径
		errs.push(`"${p}" 不存在（${isAbs ? "绝对路径" : `${baseLabel} ${baseCwd} 下解析为 ${abs}`}）——白名单路径须在派发时已存在或其父目录位于工作区子树内，请核对路径前缀后重派`);
	}
	return errs;
}

export interface AllowedPathsOverlapConflict {
	nodeA: string;
	nodeB: string;
	pathA: string;
	pathB: string;
}

/** ev-20260909-f0d3ff（P2）：batch 多节点白名单两两交集写冲突检测（纯函数，可测）。
 *  对 validated 各节点解析后（相对各自 nodeBase）的 allowedPaths 两两做前缀重叠检测（绝对路径相同、或一方目录前缀包含另一方）。
 *  运行时自动附带的 amagi-task/<runId> tmp 目录非用户参数不参与。
 */
/** ev-20260909-f0d3ff（P2）+ ev-20260914-234357（ux/P2）：batch 多节点白名单两两「真写冲突」
 *  静态分析（纯函数，可测）。运行时自动附带的 amagi-task/<runId> tmp 目录非用户参数不参与。
 *
 *  ev-20260914-234357 升级背景：10+ 次 batch 每次都触发交集预警，绝大多数是各节点共享报告目录
 *  （reportPath 各自独立文件）与共享 tests/ 目录（各写不同文件）——天然无冲突，全程仅 1 次真风险。
 *  判定分级（零误杀优先：无法静态判定时维持预警，保守）：
 *  ① WARN（真写冲突）：两节点声明性写入目标存在同一具体文件（相同现存/拟建文件条目、相同
 *     reportPath、或具体文件条目与对方条目相等），或 glob/prefix 模式跨节点相交（如都写
 *     data/cfg/*.tres 同名模式）；
 *  ② 降级不报：两节点白名单都含同一目录（目录能力面前缀重叠），但结合各自 reportPath 与
 *     目录内条目解析后的写入目标互不重叠（append-only 目录/各自独立文件名）→ 天然无冲突；
 *  ③ 保守维持预警：无法静态判定（条目不存在且无法分辨文件/目录、目录包含对方具体文件条目、
 *     模式与对方目录能力面相交等）→ 维持既有预警语义。 */
interface OverlapPatternEntry {
	/** 原始条目（诊断用）。 */
	raw: string;
	kind: "glob" | "prefix";
	/** 解析后绝对模式（glob 保留通配符）。 */
	value: string;
	/** 首个通配符之前的字面前缀（模式相交可判定性的依据；prefix 恒为全串）。 */
	literalPrefix: string;
}
interface OverlapNodeInfo {
	name: string;
	/** 无语法（plain）条目：解析后绝对路径（目录或精确文件语义）。 */
	plains: string[];
	patterns: OverlapPatternEntry[];
	/** 解析后绝对 reportPath（声明性具体写入目标；可选）。 */
	reportPath?: string;
}

/** 模式字面前缀：glob 取首个通配符之前部分（无通配符返回全串）。 */
function patternLiteralPrefix(value: string): string {
	const idx = value.search(/[*?]/);
	return idx < 0 ? value : value.slice(0, idx);
}

/** 模式相交判定（保守：无法证明不相交即视为相交）。字面前缀相同/互为前缀 → 相交；
 *  存在双方均字面的相异字符位 → 不可能命中同一路径 → 不相交。 */
function patternsIntersect(a: OverlapPatternEntry, b: OverlapPatternEntry): boolean {
	const la = a.literalPrefix;
	const lb = b.literalPrefix;
	if (!la || !lb) return true; // 无法证明不相交（通配符在首段）→ 保守相交
	if (la === lb || la.startsWith(lb) || lb.startsWith(la)) return true;
	return false;
}

/** 路径前缀重叠（同串或一方目录前缀包含另一方；与既有 isOverlap 语义一致）。 */
function pathPrefixOverlap(a: string, b: string): boolean {
	if (a === b) return true;
	const relAB = path.relative(a, b);
	if (relAB === "" || (relAB !== ".." && !relAB.startsWith(`..${path.sep}`) && !path.isAbsolute(relAB))) return true;
	const relBA = path.relative(b, a);
	if (relBA === "" || (relBA !== ".." && !relBA.startsWith(`..${path.sep}`) && !path.isAbsolute(relBA))) return true;
	return false;
}

/** 已知目录（存在且为目录；不存在/不可判 → false）。 */
function isKnownDirectory(p: string): boolean {
	try { return fs.existsSync(p) && fs.statSync(p).isDirectory(); } catch { /* journal:directory-probe-fallback */ return false; }
}

/** 模式区域与 plain 条目能力面是否可能相交（保守：无法排除即可能相交）。 */
function patternMayOverlapPlain(p: OverlapPatternEntry, plainPath: string): boolean {
	const lit = p.literalPrefix;
	if (!lit) return true; // 通配符在最前（区域不可限定）→ 保守
	if (pathPrefixOverlap(lit, plainPath)) return true;
	const dirOfLit = path.dirname(lit);
	if (dirOfLit !== lit && pathPrefixOverlap(dirOfLit, plainPath)) return true;
	return false;
}

/** 节点在共享目录内的声明性写入目标（现存/拟建具体文件条目 + reportPath + 目录内模式）。 */
function declaredTargetsIn(n: OverlapNodeInfo, dirAbs: string): { concretes: string[]; patterns: OverlapPatternEntry[] } {
	const concretes: string[] = [];
	for (const p of n.plains) {
		if (p !== dirAbs && pathPrefixOverlap(dirAbs, p) && !isKnownDirectory(p)) concretes.push(p);
	}
	if (n.reportPath && pathPrefixOverlap(dirAbs, n.reportPath)) concretes.push(n.reportPath);
	const patterns = n.patterns.filter((pt) => pathPrefixOverlap(dirAbs, pt.literalPrefix || pt.value));
	return { concretes, patterns };
}

export function detectAllowedPathsOverlap(
	nodes: ReadonlyArray<{ name: string; allowedPaths?: ReadonlyArray<string>; cwd?: string; reportPath?: string }>,
	baseCwd: string,
): AllowedPathsOverlapConflict[] {
	const conflicts: AllowedPathsOverlapConflict[] = [];
	const nodeEntries: OverlapNodeInfo[] = [];

	for (const n of nodes) {
		if (!n.allowedPaths || !Array.isArray(n.allowedPaths) || n.allowedPaths.length === 0) continue;
		const nodeBase = typeof n.cwd === "string" && n.cwd.trim()
			? (path.isAbsolute(n.cwd) ? n.cwd : path.resolve(baseCwd, n.cwd))
			: baseCwd;
		const info: OverlapNodeInfo = { name: n.name, plains: [], patterns: [] };
		for (const p of n.allowedPaths) {
			if (typeof p !== "string" || !p.trim()) continue;
			const parsed = parseAllowedPathEntry(p);
			if (parsed.invalid) continue;
			if (parsed.kind === "glob" || parsed.kind === "prefix") {
				const value = path.isAbsolute(parsed.value) ? parsed.value : path.resolve(nodeBase, parsed.value);
				info.patterns.push({ raw: p.trim(), kind: parsed.kind, value, literalPrefix: patternLiteralPrefix(value) });
			} else {
				info.plains.push(path.isAbsolute(parsed.value) ? parsed.value : path.resolve(nodeBase, parsed.value));
			}
		}
		if (typeof n.reportPath === "string" && n.reportPath.trim()) {
			const rp = n.reportPath.trim();
			info.reportPath = path.isAbsolute(rp) ? rp : path.resolve(nodeBase, rp);
		}
		if (info.plains.length + info.patterns.length > 0) nodeEntries.push(info);
	}

	for (let i = 0; i < nodeEntries.length; i++) {
		for (let j = i + 1; j < nodeEntries.length; j++) {
			const nodeI = nodeEntries[i]!;
			const nodeJ = nodeEntries[j]!;
			const push = (pathA: string, pathB: string): void => {
				conflicts.push({ nodeA: nodeI.name!, nodeB: nodeJ.name!, pathA, pathB });
			};
			// ① 具体文件级真写冲突：双端声明性具体目标相等且非已知目录（相同文件条目/相同 reportPath/交叉相等）
			const concreteI = [...nodeI.plains, ...(nodeI.reportPath ? [nodeI.reportPath] : [])];
			const concreteJ = [...nodeJ.plains, ...(nodeJ.reportPath ? [nodeJ.reportPath] : [])];
			for (const c1 of concreteI) {
				for (const c2 of concreteJ) {
					if (c1 === c2 && !isKnownDirectory(c1)) push(c1, c2);
				}
			}
			// ② 模式相交：glob/prefix 跨节点同名模式相交（无法证明不相交 → 相交，保守）
			for (const p1 of nodeI.patterns) {
				for (const p2 of nodeJ.patterns) {
					if (patternsIntersect(p1, p2)) push(p1.value, p2.value);
				}
			}
			// ③ 模式 × 目录能力面：无法静态判定对方是否真写命中文件 → 保守维持预警
			for (const p of nodeI.patterns) {
				for (const b of nodeJ.plains) {
					if (patternMayOverlapPlain(p, b)) push(p.value, b);
				}
			}
			for (const p of nodeJ.patterns) {
				for (const b of nodeI.plains) {
					if (patternMayOverlapPlain(p, b)) push(b, p.value);
				}
			}
			// ④ plain 两两前缀重叠：相等已知目录/目录包含目录 → 结合声明目标降级判定；
			// 声明的具体文件落在对方已知目录能力面内且对方无同目标声明 → append-only 假设降级；
			// 双方形态均不可判（不存在且无 fs 证据）→ 保守维持预警（与旧语义一致）
			for (const a of nodeI.plains) {
				for (const b of nodeJ.plains) {
					if (!pathPrefixOverlap(a, b)) continue;
				if (a === b) {
						if (isKnownDirectory(a)) {
							// 共享已知目录：目录内双端声明性写入目标互不重叠（或一端/双端无声明目标——
							// append-only 目录/各自独立文件名的常见 batch 形态）→ 降级不报（ev-20260914-234357）
							const tI = declaredTargetsIn(nodeI, a);
							const tJ = declaredTargetsIn(nodeJ, a);
							for (const x of tI.concretes) {
								if (tJ.concretes.includes(x)) push(x, x);
							}
							for (const p1 of tI.patterns) {
								for (const p2 of tJ.patterns) {
									if (patternsIntersect(p1, p2)) push(p1.value, p2.value);
								}
							}
						}
						continue; // 相等：目录形态已判定；非目录形态①已按具体文件冲突覆盖
					}
					const s = pathPrefixOverlap(b, a) && a !== b ? a : b; // 被包含端
					const l = s === a ? b : a; // 包含端
					if (isKnownDirectory(s)) {
						// 目录⊆目录：共享区域为小目录，区域内声明目标互不重叠 → 降级不报
						const tI = declaredTargetsIn(nodeI, s);
						const tJ = declaredTargetsIn(nodeJ, s);
						for (const x of tI.concretes) {
							if (tJ.concretes.includes(x)) push(x, x);
						}
						for (const p1 of tI.patterns) {
							for (const p2 of tJ.patterns) {
								if (patternsIntersect(p1, p2)) push(p1.value, p2.value);
							}
						}
						continue;
					}
					if (isKnownDirectory(l)) {
						// 具体文件（含拟建）落在对方已知目录能力面内：对方无同目标声明 → append-only 假设降级；
						// 双方同目标声明已由①具体文件相等覆盖上报（含条目↔reportPath 交叉形态）
						const lOwner: OverlapNodeInfo = l === a ? nodeI : nodeJ; // 包含端（目录条目）所属节点（diting m-1：原 nodeJ/nodeI 归属反转已纠正）
						const lConcretes = [...lOwner.plains, ...(lOwner.reportPath ? [lOwner.reportPath] : [])];
						if (lConcretes.includes(s)) continue; // 包含端节点也声明了同目标：①已报，不重复
						continue; // 对方目录无同目标声明 → 降级不报
					}
					push(a, b); // 双方形态均不可判（无 fs 证据）→ 保守维持预警
				}
			}
		}
	}
	// 去重：同一（节点对+路径对）可能由①具体文件相等与④共享目录目标碰撞双路径上报
	const seen = new Set<string>();
	const deduped: AllowedPathsOverlapConflict[] = [];
	for (const c of conflicts) {
		const key = `${c.nodeA}\u0000${c.nodeB}\u0000${c.pathA}\u0000${c.pathB}`;
		if (!seen.has(key)) { seen.add(key); deduped.push(c); }
	}
	return deduped;
}

/** 格式化白名单两两交集冲突预警文本（ev-20260909-f0d3ff）。 */
export function formatAllowedPathsOverlapWarning(conflicts: ReadonlyArray<AllowedPathsOverlapConflict>): string {
	if (conflicts.length === 0) return "";
	const lines = conflicts.map((c) =>
		`• 节点对 [${c.nodeA} ↔ ${c.nodeB}] 共享路径: ${c.pathA === c.pathB ? c.pathA : `${c.pathA} ↔ ${c.pathB}`}`
	);
	return `\n\n[白名单交集预警] batch 多节点 allowedPaths 存在重叠，可能引发并发写冲突：\n${lines.join("\n")}\n建议：相关节点错峰作业（最后一步写入/改前重读/单节点汇总合并），或通过串行化以避免写冲突。`;
}
/** 8月迭代 C1：wait 缺省时长按等待对象角色类型自适应（fast 只读 5min；work/expert 编码类 30min；未知/空集维持旧 120s）。 */
export function resolveWaitDefaultMs(agents: ReadonlyArray<{ name: string; type?: string }>, agentNames: Iterable<string>): number {
	const names = [...agentNames];
	if (names.length === 0) return 120_000;
	const heavy = names.some((n) => agents.find((a) => a.name === n)?.type !== "fast");
	return heavy ? 30 * 60_000 : 5 * 60_000;
}

export function createTaskTool(
	agents: AgentConfig[],
	toolName: string,
	pi?: ExtensionAPI,
	testOpts?: { testCommand?: { command: string; args: string[] }; evidence?: (cwd: string) => Promise<string>; orchestrateRun?: (agent: AgentConfig, task: string, opts: { cwd: string; model?: string; onStall?: (info: { taskId: string; agent: string; idleMs: number }) => void }) => Promise<RunResult> },
) {
	const agentList = agents.map((a) => a.name).join(", ");
	// v2 §7.2：枚举兼收八旧 stem 别名（wenqu/taibai/laojun/wukong/cangjie/diting-quick/hongjun/puti），
	// 归一后按 canonical 角色派发；别名兼容只保留一个发布版本。agentList 提示面保持 canonical 五名。
	const AgentEnum = agents.length > 0 ? StringEnum(dispatchAcceptableAgentIds(agents.map((a) => a.name))) : Type.String();
	// ev-20260905-24558f（P0）：settled 后终态回推接线（幂等；pi 可选注入，测试传 mock sink）。
	// 只覆盖单任务 sync/resume（唯一通知通道是 execute 返回体）的迟终态，编排/后台已有自带通知。
	try { wireTerminalPush(pi); } catch { /* 回推接线失败静默 */ }
	// v2 批次B：并发上限由共享准入队列统一承载（admission.ts 按 provider/model 分池；amagi.json
	// `concurrency` 可配，AMAGI_ADMISSION_MAX 覆盖未显式配置池的 default 容量，缺省 4）；
	// sync/background/resume/编排分支全路径排队语义，不再按模式各自拒绝。

	// M1: 注入已知角色列表到 resolver（生产路径诊断 amagi.json 未知角色）
	setKnownAgents(new Set(agents.map((a) => a.name)));
	// M2: model 元数据在 execute 层从 ctx.modelRegistry 注入（见 execute 方法）

	return {
		name: toolName,
		label: "Amagi Task",
		description: [
			"何时调用：派发子 Agent（agent+task / context+tasks[] / session+task / fanout·pipeline·tournament·redteam·fork），或控制任务（cancel/wait）。",
			"会改变什么：spawn 子进程执行并回传终稿（done/blocked/error 即退出）；cancel 真实终止。",
			"怎么传：互斥组同调用只取其一，控制面不与派发混用；选项仅随派发并用。",
			"失败怎么办：互斥/非法整单不执行（isError 附修复样例）；blocked 用 session+task resume。",
			"batch 缺省异步自动通知，无需显式 wait；wait 用于需要在同一轮内同步汇总/阻塞等待的场景。完整参数语义见 amagi_resource({ resource: \"tools-legacy\" })。",
		].join(" "),
		promptSnippet: `task({ agent, task }) / task({ context, tasks:[{ name, agent, task }] }) / task({ session, task })`,
		promptGuidelines: [
			`角色名：${agentList}（兼容别名：wenqu/taibai/laojun/wukong/cangjie/diting-quick/hongjun/puti 归一到 canonical）。独立切片用 context + tasks[] 一次批量派发（1..32），比串行逐个调用更省事。`,
			"按能力成分选主特色，附带成分标“轻”；独立且无共享写入的重成分才并行。",
			"白泽供证据，鲁班闭环交付，洛神作审美判断，谛听独立对抗，伏羲处理路径未知。",
			"fuxi 设计态用于无可复用方向且重大取舍的方向设计；攻坚态、反思态须显式选择。",
			"反思须真实证据、可迁移且无等价条目；态名不授予写权限。",
			"diting 在集成验证后审阶段 diff，quick/full 由任务书选择，不按档位拆角色。",
			"少量明确问题可由 Leader 修复验证，其他 findings 合并一次回派。",
			"仅 Critical/Major 修复或范围实质变化允许一次增量复审；再失败上报，不自动循环。",
			"显式点名优先，但不改变任务边界、只读约束与用户现场保护。",
			"background 返回 taskId 并自动通知；session 会新 spawn 进程续接旧上下文，无常驻/P2P/steer。",
			"wait/cancel/query 使用 taskId、稳定 name 或 runId/name；blocked 已退出，答复后 resume；blocked 已在外部解决时用 task({ cancel: \"<句柄>\", resolve: \"external\" }) 轻量收口（区分放弃语义）。",
		],
		parameters: Type.Object({
			agent: Type.Optional(AgentEnum),
			task: Type.Optional(Type.String({ description: "任务书正文（单任务/resume 必填；batch 用 tasks[].task）" })),
			model: Type.Optional(Type.Union([Type.String(), Type.Array(Type.String())], { description: "覆盖模型；数组=显式降级链（仅单任务）" })),
			autoRetry: Type.Optional(Type.Object({
				retries: Type.Optional(Type.Number({ description: "自动重派最大次数（0..10，缺省 2）" })),
				backoffMs: Type.Optional(Type.Number({ description: "首次退避 ms（指数退避封顶 30min）" })),
			}, { description: "瞬时故障自动重派（opt-in；仅 background 单任务与批量；AMAGI_AUTORETRY_OFF=1 关）" })),
			evidenceTimeouts: Type.Optional(Type.Object({
				testMs: Type.Optional(Type.Number({ description: "单次证据测试命令预算 ms（1000–14400000）" })),
				gitMs: Type.Optional(Type.Number({ description: "证据链 git 探测预算 ms（1000–120000）" })),
				summaryGitMs: Type.Optional(Type.Number({ description: "产物摘要 git 预算 ms（1000–120000）" })),
			}, { description: "任务级证据超时（task > env > 默认；越界拒单）" })),
			workspaceNeeds: Type.Optional(StringEnum(["main-tree", "portable", "unknown"], { description: "依赖可见性声明（建议；完整语义见 amagi_resource tools-legacy）：portable=worktree 可复用主树安装 / main-tree=需自行安装 / unknown=不声明（缺省）" })),
			background: Type.Optional(Type.Boolean({ description: "true=后台模式（完成自动通知）" })),
			asyncGroup: Type.Optional(Type.Boolean({ description: "group 模式：batch 缺省 true（异步），编排缺省 false" })),
			context: Type.Optional(Type.String({ description: "批量派发共享上下文（trim 后非空）" })),
			tasks: Type.Optional(Type.Array(Type.Object({
				name: Type.Optional(Type.String({ description: "稳定节点名（组内唯一）" })),
				agent: AgentEnum,
				task: Type.String({ description: "该节点独立 assignment（非空）" }),
				model: Type.Optional(Type.String()),
				cwd: Type.Optional(Type.String({ description: "节点工作目录（缺省继承顶层 cwd）" })),
				allowedPaths: Type.Optional(Type.Array(Type.String(), { description: "节点级写入白名单：不在清单的写入即阻断；条目支持目录/文件/glob/prefix: 前缀" })),
				reportPath: Type.Optional(Type.String({ description: "节点报告落盘完整路径（须在白名单内）" })),
			}), { minItems: 1, maxItems: 32, description: "独立并行任务列表（1..32）" })),
			reportPath: Type.Optional(Type.String({ description: "单任务报告落盘完整路径（须在白名单内）" })),
			sharedTree: Type.Optional(Type.Boolean({ description: "声明共享树并行写入（归因降噪）" })),
			cwd: Type.Optional(Type.String({ description: "任务工作目录（缺省继承 Leader cwd；resume 不支持）" })),
			protectedPaths: Type.Optional(Type.Array(Type.String(), { description: "保护路径清单（edit/write 命中即阻断）" })),
			allowedPaths: Type.Optional(Type.Array(Type.String(), { description: "任务写入白名单：不在清单的写入即阻断；与 protectedPaths 互斥；条目支持目录/文件/glob/prefix: 前缀" })),
			description: Type.Optional(Type.String({ description: "任务短名（面板/看板显示用）" })),
			worktree: Type.Optional(Type.String({ description: "git worktree 名，独立工作树作业（仅单任务）" })),
			session: Type.Optional(Type.String({ description: "resume 目标：taskId/name 前缀或 runId/name" })),
			dryRun: Type.Optional(Type.Boolean({ description: "true=只解析不派发，返回预检评估（与 exportPrompt 互斥；不支持 resume/编排）" })),
			exportPrompt: Type.Optional(Type.Union([Type.Boolean(), Type.String()], { description: "只导出任务书提示词不派发（与 dryRun 互斥；仅单任务；字符串=显式路径）" })),
			// v2 批次B 控制面（与派发参数互斥，同调用只取其一）
			cancel: Type.Optional(Type.String({ description: "取消任务或 group（运行中 SIGTERM→SIGKILL；runId 级联）" })),
			resolve: Type.Optional(StringEnum(["external"], { description: "与 cancel 并用：收口为已外部处置" })),
			wait: Type.Optional(Type.Object({
				ids: Type.Optional(Type.Array(Type.String(), { description: "等待的任务句柄列表" })),
				group: Type.Optional(Type.String({ description: "group runId（等整组收尾）" })),
				mode: Type.Optional(StringEnum(["any", "all"], { description: "any=首个终态即返（缺省）；all=全部终态" })),
				timeoutMs: Type.Optional(Type.Number({ description: "等待上限 ms（超时只报告不取消）" })),
			}, { description: "等待一组任务/任务组到本轮结算态（同步汇总场景）；batch 缺省异步自动通知，无需显式 wait" })),
			// T2-5 编排模式（§9.6，纯语法糖，内部展开为多次 task 调用，复用 registry/trace/blocked 基建）
			fanout: Type.Optional(Type.Array(Type.Object({
				agent: Type.String({ description: "角色名" }),
				task: Type.String({ description: "分支任务" }),
				model: Type.Optional(Type.String()),
			}), { description: "并行扇出：多角色并行（≤4），全部完成汇总" })),
			pipeline: Type.Optional(Type.Array(Type.Object({
				agent: Type.String(),
				task: Type.String(),
				model: Type.Optional(Type.String()),
			}), { description: "串行链：前序输出作后续输入，blocked 即暂停" })),
			tournament: Type.Optional(Type.Object({
				agent: Type.String({ description: "实现角色" }),
				task: Type.String({ description: "被实现的任务" }),
				n: Type.Optional(Type.Number({ description: "并行实例数（2..4，缺省 3）" })),
				judge: Type.Optional(Type.String({ description: "评审角色（缺省 diting）" })),
			}, { description: "锦标赛：N 实例并行 + 评审择优" })),
			redteam: Type.Optional(Type.Array(Type.Object({
				agent: Type.String(),
				adversarial: Type.Optional(Type.Boolean({ description: "true=对抗审查分支；缺省=实现分支" })),
				task: Type.Optional(Type.String()),
				model: Type.Optional(Type.String()),
			}), { description: "红队：1 实现 + 0..4 对抗审查分支" })),
			fork: Type.Optional(Type.Object({
				session: Type.String({ description: "fork 起点：taskId 或 sessionId" }),
				branches: Type.Array(Type.Object({
					agent: Type.String(),
					task: Type.String(),
					model: Type.Optional(Type.String()),
					readOnly: Type.Optional(Type.Boolean({ description: "true=声明该枝无写副作用（readOnly 枝可并发）" })),
				}), { description: "分叉枝列表（各自独立试验）" }),
			}, { description: "从 session 分叉多枝独立 resume（互不污染）" })),
		}),

		async execute(
			_id: string,
			params: { context?: string; tasks?: Array<{ name?: string; agent: string; task: string; model?: string; cwd?: string; allowedPaths?: string[]; reportPath?: string }>; agent?: string; task?: string; model?: string | string[]; background?: boolean; asyncGroup?: boolean; session?: string; cwd?: string; worktree?: string; description?: string; dryRun?: boolean; exportPrompt?: boolean | string; cancel?: string; resolve?: "external"; wait?: { ids?: string[]; group?: string; mode?: "any" | "all"; timeoutMs?: number }; fanout?: any[]; pipeline?: any[]; tournament?: any; redteam?: any[]; fork?: any; allowedPaths?: string[]; protectedPaths?: string[]; reportPath?: string; sharedTree?: boolean; autoRetry?: { retries?: number; backoffMs?: number }; evidenceTimeouts?: { testMs?: number; gitMs?: number; summaryGitMs?: number }; workspaceNeeds?: "main-tree" | "portable" | "unknown" },
			signal: AbortSignal | undefined,
			_onUpdate: ((partial: any) => void) | undefined,
			// ev-20260905-c4cc4f：ctx.modelRegistry 保持 any 透传——pi 真实 ModelRegistry 自带 getAll()
			// （dist/core/model-registry.d.ts），结构化流入 ModelRegistryLike.getAll（可选）与
			// modelCandidates 枚举，无需断言适配。
			ctx: { cwd: string; model?: { provider: string; id: string }; modelRegistry?: any; isProjectTrusted?: () => boolean; sessionManager?: { getEntries?: () => any[] } },
		) {
			// ev-20260919+ev-20260920：strict 采样伪影归一（宿主路径另经注册接线 prepareArguments 前置剥离）。
			// legacy 面受益位：wait.mode/workspaceNeeds/resolve 等 wait 专属枚举伪影不再拒收；
			// 真 null 的 wait.mode 此前未被剥离（`null ?? "any"` 仍为 null）——一并修复。
			params = normalizeToolArgumentArtifacts(params);
			const _batchRequested = params.context !== undefined || params.tasks !== undefined;
			if (_batchRequested) {
				const _batchExclusive = ["agent", "task", "model", "background", "session", "cwd", "worktree", "description", "dryRun", "exportPrompt", "cancel", "resolve", "wait", "fanout", "pipeline", "tournament", "redteam", "fork", "evidenceTimeouts", "workspaceNeeds", "reportPath"] as const;
				const conflict = _batchExclusive.find((key) => params[key] !== undefined);
				if (conflict) {
					return { content: [{ type: "text" as const, text: `[batch 参数互斥] context/tasks 仅可与 asyncGroup 并用；不能同时提供 ${conflict}。零节点启动。` }], isError: true };
				}
			}
			// 8月迭代 C3：白名单/黑名单互斥——allowedPaths（仅清单内可写）与 protectedPaths（清单内禁写）
			// 语义反向，同传是配置事故（交集语义下易意外全拦/漏拦）；显式拒单让调用方二选一，不静默取其一。
			if (params.allowedPaths !== undefined && params.protectedPaths !== undefined) {
				return { content: [{ type: "text" as const, text: "[参数互斥] allowedPaths（白名单：仅清单内可写）与 protectedPaths（黑名单：清单内禁写）互斥，同传拒单——白名单/黑名单二选一，请只保留其一。零任务启动。" }], isError: true };
			}
			// C3：编排模式不支持 allowedPaths（静默丢弃安全边界比显式拒单更危险）——引导到 tasks[].allowedPaths
			if (params.allowedPaths !== undefined && (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork)) {
				return { content: [{ type: "text" as const, text: "[allowedPaths 不适用] 编排模式（fanout/pipeline/tournament/redteam/fork）不支持 allowedPaths——请改用 context+tasks[] 批量模式（tasks[].allowedPaths 节点级白名单）或单任务派发。" }], isError: true };
			}
			// ── v2 批次B 控制面：cancel/wait 优先于一切派发逻辑（互斥语义：同调用不混入派发） ──
			// ev-20260908-f189e7：resolve(external) 是 cancel 通道的收口语义修饰（目标句柄复用 cancel 参数），
			// 不得脱离 cancel 单独使用；wait 与 resolve 同传无意义（resolve 是收口动作非等待），一并走下方互斥链拒单。
			if (params.resolve !== undefined && !params.cancel) {
				return { content: [{ type: "text" as const, text: "[参数无效] resolve 须与 cancel 并用：task({ cancel: \"<句柄>\", resolve: \"external\" })——把 blocked/排队任务收口为已外部处置终态（不 spawn 不重跑，与取消语义区分）。单独使用 resolve 无效。" }], isError: true };
			}
			if (params.cancel) {
				// ev-20260908-f189e7：cancel+resolve(external)——轻量收口为 resolved-external 终态（镜像 cancel 的
				// 单任务→group 级联两段句柄解析：taskId 未命中时按 group runId 级联；纯状态迁移零 spawn）。
				if (params.resolve === "external") {
					let target = params.cancel.trim();
						// ev-20260914-4150dd：歧义错误含多行可复制候选清单——经 registryErrorEcho 整段透传（160 字截断会砍掉候选行）
					try { const rs = registry.resolveSession(target); if (rs) target = rs.taskId; } catch (e) { return { content: [{ type: "text" as const, text: `[task resolve] ${registryErrorEcho(e)}` }], isError: true }; }
					const rr = resolveExternalTask(target);
					if (!rr.ok) {
						// taskId 未命中时按 group runId（batch-xxx/orch-xxx）级联外部处置（运行中节点跳过）
						const gr = resolveExternalGroup(target);
						if (gr.found) return { content: [{ type: "text" as const, text: `[group resolve ${target}] 级联外部处置 ${gr.resolved.length} 个节点${gr.skipped.length ? `（${gr.skipped.length} 个跳过：运行中/已终态——运行中请另行 cancel）` : ""}——未启动节点不再解锁，无孤儿 worker` }], isError: false };
					}
					return { content: [{ type: "text" as const, text: `[task resolve ${rr.taskId.slice(0, 8)}] ${rr.message}` }], isError: !rr.ok };
				}
				let target = params.cancel.trim();
				// ev-20260914-4150dd：同上——cancel 前缀歧义时候选清单整段透传
				try { const rs = registry.resolveSession(target); if (rs) target = rs.taskId; } catch (e) { return { content: [{ type: "text" as const, text: `[task cancel] ${registryErrorEcho(e)}` }], isError: true }; }
				const cr = cancelTask(target);
				if (!cr.ok) {
					// v2 批次C：taskId 未命中时按 group runId（orch-xxx）尝试级联取消（含未启动节点收口）
					const gr = cancelGroup(target);
					if (gr.found) return { content: [{ type: "text" as const, text: `[group cancel ${target}] 级联取消 ${gr.cancelled.length} 个节点${gr.skippedTerminal.length ? `（${gr.skippedTerminal.length} 个已终态跳过）` : ""}——未启动节点不再解锁，无孤儿 worker` }] };
				}
				return { content: [{ type: "text" as const, text: `[task cancel ${cr.taskId.slice(0, 8)}] ${cr.message}` }], isError: !cr.ok };
			}
			if (params.wait) {
				const mode = params.wait.mode === "all" ? "all" : "any";
				// 8月迭代 C1：缺省 wait 时长按等待对象角色自适应——fast 只读类 5min；work/expert 编码类
				// 30min（复盘实测：开发类子任务两次显式 15min wait 仍超，旧缺省 120s 每任务至少两次 wait）。
				// 未知对象（解析不到 agent）维持旧缺省 120s，不改显式 timeoutMs 语义。
				const adaptiveWaitDefaultMs = (): number => {
					const names = new Set<string>();
					try {
						const g = params.wait?.group?.trim();
						if (g) { for (const n of getGroup(g).nodeStats) { const rec = n.taskId ? registry.get(n.taskId) : undefined; if (rec?.agent) names.add(rec.agent); } }
						else for (const raw of params.wait?.ids || []) { try { const r = registry.resolveSession(String(raw)); if (r?.record?.agent) names.add(r.record.agent); } catch {} }
					} catch {}
					return resolveWaitDefaultMs(agents, names);
				};
				const timeoutMs = Number.isFinite(params.wait.timeoutMs) ? Math.max(0, Number(params.wait.timeoutMs)) : adaptiveWaitDefaultMs();
				const groupId = params.wait.group?.trim();
				if (groupId) {
					// v2 批次C：group 显式等待——all 等 group 收尾（含 skipped 级联明细）；any 任一节点终态
					const wr = await waitGroup(groupId, mode, timeoutMs);
					if (wr.outcome) {
						const lines = Object.values(wr.outcome.envelopes).map((env) => `${env.nodeId || "?"} ${env.taskId.slice(0, 8)}: ${env.status}${env.error ? `（${env.error.code}）` : ""} — ${env.summary.slice(0, 200) || "(无输出)"}`);
						for (const s of wr.outcome.skipped) lines.push(`⚠ ${s.nodeId} 未执行：${s.reason}`);
						return { content: [{ type: "text" as const, text: `[group wait 完成 · ${groupId}]\n${lines.join("\n") || "(无节点)"}` }], isError: wr.outcome.isError };
					}
					if (wr.settled) {
						const lines = wr.settled.settled.map((s) => `${s.taskId.slice(0, 8)} ${s.record?.agent || "?"}: ${s.status}`);
						// 8月迭代 C1：超时未决项附进度（已耗时/最近活动）——区分健康长跑与真卡死
						const pl = (wr.settled.pendingDetails || []).map((p) => `  ${p.taskId.slice(0, 8)} · ${p.admission} · 已 ${Math.round((p.elapsedMs || 0) / 1000)}s${p.lastActivity ? ` · 最近: ${p.lastActivity}` : ""}`);
						return { content: [{ type: "text" as const, text: `[group wait ${wr.timedOut ? "超时" : "完成"} · ${groupId} · ${mode}]\n${lines.join("\n") || "(节点尚未启动)"}${wr.settled.pending.length ? `\n未决 ${wr.settled.pending.length}（超时只报告不取消；可继续 wait 或 cancel）:\n${pl.join("\n") || wr.settled.pending.map((p) => `  ${p.slice(0, 8)}`).join("\n")}` : ""}` }], isError: false };
					}
					return { content: [{ type: "text" as const, text: `[group wait 超时 · ${groupId}] 超时只报告不取消（可继续 wait 或 task({ cancel: "${groupId}" }) 级联取消）` }], isError: false };
				}
				const rawIds = (params.wait.ids || []).map((s) => String(s).trim()).filter(Boolean);
				if (rawIds.length === 0) return { content: [{ type: "text" as const, text: "[task wait] 需要 ids（任务句柄列表）或 group（batch-xxx/orch-xxx）" }], isError: true };
				// 8月迭代 F6b：group id 误传 ids 引导（batch-/orch- 前缀检测）
				const groupish = rawIds.filter((s) => /^(batch-|orch-)/.test(s));
				if (groupish.length > 0) return { content: [{ type: "text" as const, text: `[task wait] 检测到 group id（${groupish.join(", ")}）误传 ids——请用 wait.group：task({ wait: { group: "${groupish[0]}", mode: "all" } })` }], isError: true };
				const ids = rawIds.map((s) => { try { return registry.resolveSession(s)?.taskId || s; } catch { return s; } });
				const wr = await waitTasks(ids, mode, timeoutMs);
				const lines = wr.settled.map((s) => {
					const rec = s.record;
					const dur = rec ? Math.max(0, Math.round(((rec.endedAt || Date.now()) - rec.startedAt) / 1000)) : 0;
					const tail = s.status === "unknown" ? "任务不存在" : rec?.errorMessage ? ` — ${rec.errorMessage.slice(0, 200)}` : rec?.result ? ` — ${rec.result.slice(0, 300)}` : "";
					// Batch 3（§9.5 成本进入 footer）：wait 只读渲染已聚合终值——重复 wait 数值逐字相同（幂等）
					const uf = renderUsageFooter(s.taskId, { inline: true });
					return `${s.taskId.slice(0, 8)} ${rec?.agent || "?"}: ${s.status}（${dur}s）${tail}${uf ? `\n  ${uf}` : ""}`;
				});
				const blockedHints = wr.settled
					.filter((s) => s.status === "blocked")
					.map((s) => s.record?.blockReason === "needs-handoff"
						// diting Major-4：handoff 显示「resume 接手开工」，不要求读取 QUESTIONS/逐项答复。
						? `\n需接手 ${s.taskId.slice(0, 8)}：settle 产出窗口收口（NEEDS_HANDOFF，非提问，无 QUESTIONS）；用 task({ session: "${s.taskId}", task: "接手开工" }) resume 续跑完成交付。`
						: `\n需答复 ${s.taskId.slice(0, 8)}：本轮进程已退出；读取 QUESTIONS 后用 task({ session: "${s.taskId}", task: "逐项答复…" }) 新开续接轮次。`)
					.join("");
				const pendingLines = (wr.pendingDetails || []).map((p) => `  ${p.taskId.slice(0, 8)} · ${p.admission} · 已 ${Math.round((p.elapsedMs || 0) / 1000)}s${p.lastActivity ? ` · 最近: ${p.lastActivity}` : ""}`);
				return { content: [{ type: "text" as const, text: `[task wait ${wr.timedOut ? "超时" : "完成"} · ${mode}]\n${lines.join("\n") || "(无)"}${blockedHints}${wr.pending.length ? `\n未决 ${wr.pending.length}（超时只报告不取消；可继续 wait 或 cancel）:\n${pendingLines.join("\n") || wr.pending.map((p) => `  ${p.slice(0, 8)}`).join("\n")}` : ""}` }], isError: false };
			}
			// ── A1/A2（ev-20260910-d86779）参数预检：autoRetry 适用面 + model 数组降级链归一 ──
			// 控制面（cancel/wait）已在上方各自 return，这里只剩派发参数；两段都在 batch/resume 分支之前，
			// 归一后的标量 params.model 让全部下游路径（resume/bg/sync/dryRun/exportPrompt）零适配。
			// ev-20260914-d88fcf（①）：解除 sync 单任务限制——瞬时错误自动重派扩展到 sync（阻塞退避由声明方
			// 自担；同步重派见 sync 运行区 autoRetry 循环）；resume/worktree/编排/dryRun/exportPrompt 维持拒绝。
			let _autoRetryCfg: AutoRetryConfig | undefined;
			if (params.autoRetry !== undefined) {
				const _arBad: string[] = [];
				if (params.session) _arBad.push("resume（session 显式续接，本就是接手语义；autoRetry 只接管 fresh 派发）");
				if (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork) _arBad.push("编排模式（fanout/pipeline/tournament/redteam/fork）");
				if (params.dryRun) _arBad.push("dryRun（只解析不派发）");
				if (params.exportPrompt !== undefined) _arBad.push("exportPrompt（只导出不派发）");
				if (params.worktree) _arBad.push("worktree（独立工作树的所有权/合并语义由 Leader 收口，不自动重派）");
				if (_arBad.length > 0) {
					return { content: [{ type: "text" as const, text: `[autoRetry 不适用] autoRetry 支持 sync/background 单任务与 context+tasks[] 批量派发，不能与 ${_arBad.join("、")} 并用。去掉 autoRetry 或调整派发形态。零任务启动。` }], isError: true };
				}
				const _arNorm = normalizeAutoRetryConfig(params.autoRetry);
				if (_arNorm.error) return { content: [{ type: "text" as const, text: `[autoRetry 参数无效] ${_arNorm.error}` }], isError: true };
				_autoRetryCfg = _arNorm.config;
			}
			// ev-20260919-226d6f（friction/P1）：未声明 autoRetry 的单任务派发（sync/background）隐式瞬时重试预算。
			// 实战：luoshen 76min 长任务单请求首字节超时（Request timed out，TRANSIENT 类）整单 error 零恢复，
			// 对照同族恢复机制（自动续跑缺省 2 轮、孤儿 400 修复缺省 1 轮均默认开）瞬时传输类是唯一
			//「零声明=零恢复」类。隐式预算缺省 1 轮：AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关隐式；
			// AMAGI_AUTORETRY_OFF=1 全局一键关；仅 sync/background 单任务路径消费（batch/编排/断连链降级
			// 维持各自语义，不消费本变量）；落盘分流/熔断感知退避/journal 留痕与声明式同链。
			const _arImplicitCfg = params.autoRetry === undefined ? implicitAutoRetryConfig() : undefined;
			// ev-20260916-23f4a4（S5 集成）：任务级证据超时——参数错误在派发准入层拒单（与回滚开关无关，
			// 始终校验）；合法则解析冻结（task > env > 默认），随 sync/background/resume/自动重派/链尽冷却
			// 重派全链携带（runTask auto-verify 与 execute 收尾链两条消费端）。
			let _evTimeouts: ResolvedEvidenceTimeouts;
			try {
				// ev-20261011-ad4513（diting F-01）：项目层（任务 cwd/amagi.json）参与派发冻结（task > env >
				// project > 默认）——冻结值会短路 gather/规格侧的项目读取，legacy 派发不接入则项目声明
				// 对其永不生效（cwd 解析失败不阻断：后续 2022 处的正式解析会拒非法 cwd）。
				const _cwdPre = resolveTaskCwd(params.cwd, ctx.cwd);
				_evTimeouts = resolveEvidenceTimeouts(
					params.evidenceTimeouts as EvidenceTimeouts | undefined,
					process.env,
					_cwdPre.ok ? readProjectEvidenceTimeouts(_cwdPre.cwd) : undefined,
				);
			} catch (e) {
				return { content: [{ type: "text" as const, text: `[evidenceTimeouts 参数无效] ${e instanceof Error ? e.message : String(e)}——合法区间 testMs 1000–14400000、gitMs/summaryGitMs 1000–120000（整数毫秒；0 不代表无限）。零任务启动。` }], isError: true };
			}
			let _modelChain: string[] | undefined;
			let _chainDropNote: string | undefined;
			// ev-20260912-90c1ca（bug/P2）：model 收到「字符串化 JSON 数组」（模型序列化事故形态，2026-09-12
			// 实测两次被拒且相近候选自相矛盾）→ 恢复为真数组走链归一；解析失败显式报错，绝不把 JSON 串当
			// 普通 spec 拆解（旧路径产出 garbage provider/model + 误导性相近候选）。
			if (typeof params.model === "string" && params.model.trim().startsWith("[")) {
				const _rec = parseStringifiedModelArray(params.model);
				if (_rec.kind === "invalid") return { content: [{ type: "text" as const, text: `[model 参数无效] ${_rec.error}` }], isError: true };
				if (_rec.kind === "ok") {
					// resume 的 model 为单标量：恢复后单元素数组直接摊平为标量（多元素维持数组 → 由下方数组分支拒单）
					if (params.session && _rec.values.length === 1) params = { ...params, model: _rec.values[0] };
					else params = { ...params, model: _rec.values };
					_chainDropNote = `⚠ model 收到 JSON 字符串（模型序列化形态），已恢复解析为降级链 [${_rec.values.join(", ")}]——后续请直接传数组而非字符串`;
				}
			}
			if (Array.isArray(params.model)) {
				if (params.session) return { content: [{ type: "text" as const, text: `[model 不适用] resume 的 model 为单标量（会话已定型，换模型重派请新任务携带降级链）` }], isError: true };
			if (Array.isArray(params.tasks) && params.tasks.length > 0) return { content: [{ type: "text" as const, text: `[model 不适用] batch 各节点用 tasks[].model，顶层降级链无派发语义（diting-quick F4）——去掉数组或改单任务派发` }], isError: true };
				if (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork) return { content: [{ type: "text" as const, text: `[model 不适用] 编排模式各分支自带 model，顶层降级链无派发语义——请新任务单派或去掉数组` }], isError: true };
				const _chain: string[] = [];
				const _dropped: string[] = [];
				params.model.forEach((el, i) => {
					if (typeof el !== "string" || !el.trim()) { _dropped.push(`model[${i}](非字符串/空)`); return; }
					const nm = normalizeModelSpec(el, ctx.modelRegistry);
					// ev-20260912-90c1ca③：剔除项携带元素级拒绝原因（旧文案只列元素名，Leader 无从得知为何被拒）
					if (!nm.ok || !nm.spec) { _dropped.push(`model[${i}] ${el}${!nm.ok && nm.error ? `（${nm.error.replace(/\n/g, " ").slice(0, 90)}）` : ""}`); return; }
					if (!_chain.includes(nm.spec)) _chain.push(nm.spec);
				});
				if (_chain.length === 0) return { content: [{ type: "text" as const, text: `[model 降级链] 数组经 normalizeModelSpec 校验后为空（${_dropped.join("、") || "空数组"}）——无可用主模型，零任务启动。` }], isError: true };
				if (_dropped.length > 0) _chainDropNote = [_chainDropNote, `⚠ model 降级链剔除 ${_dropped.length} 个无效项: ${_dropped.join("、")}（normalizeModelSpec 拒绝，链按剩余项依次尝试）`].filter(Boolean).join("\n");
				_modelChain = _chain;
				params = { ...params, model: _chain[0] }; // 主模型 = 链首；下游全部按标量处理，链语义由本函数消费
			}
			// 归一后 params.model 恒为标量；TS 无法跨对象再赋值收窄联合类型，取局部标量别名供下游统一消费。
			const paramModel: string | undefined = _modelChain ? _modelChain[0] : (typeof params.model === "string" ? params.model : undefined);
			const fallbackSpec = ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : undefined;

		// P1（8月迭代第三轮）：超长任务书预警（软提示不阻断；覆盖单任务/batch/编排全形态）
		try { warnLongTaskTexts(pi, params); } catch { /* 观测提示失败静默 */ }
		// ev-20260907-8abf9a：任务书报告路径占位符软提示（不阻断；引导改用 tasks[].reportPath 结构化字段）
		try { warnReportPathPlaceholders(pi, params); } catch { /* 观测提示失败静默 */ }
		// C5: 统一 onStall 定义（在 resume/orchestrate/sync/background 之前，所有路径共用）
		// ev-20260905-c0b446：终态过滤加固 + 去重收敛（见模块级 createStallAlarm）
		const _onStall = createStallAlarm(pi);

			// M1 fix: 从 ctx.modelRegistry 注入 model 元数据（生产路径）
			// dist 证据: types.d.ts:220 ExtensionContext.modelRegistry: ModelRegistry
			// dist 证据: model-registry.d.ts:27 find(provider, modelId): Model<Api> | undefined
			if (ctx.modelRegistry?.find) {
				setModelMetaProvider((provider: string, model: string) => {
					try {
						const m = ctx.modelRegistry.find(provider, model);
						return m ? { reasoning: m.reasoning, thinkingLevelMap: m.thinkingLevelMap } : undefined;
					} catch { return undefined; }
				});
			}

			if (_batchRequested) {
				const sharedContext = typeof params.context === "string" ? params.context.trim() : "";
				const rawTasks: unknown[] = Array.isArray(params.tasks) ? params.tasks : [];
				const errors: string[] = [];
				if (!sharedContext) errors.push("context trim 后必须非空");
				// C3：batch 无顶层 cwd（cwd 属 batch 互斥键），顶层 allowedPaths 解析基准不明且会被静默丢弃——拒单引导节点级白名单
				if (params.allowedPaths !== undefined) errors.push("batch 模式不支持顶层 allowedPaths（白名单是安全边界，不静默丢弃）——请用 tasks[].allowedPaths 节点级白名单");
				if (!Array.isArray(params.tasks)) errors.push("tasks 必须是数组");
				else if (rawTasks.length < 1 || rawTasks.length > 32) errors.push(`tasks 数量必须为 1..32（收到 ${rawTasks.length}）`);

				const names = new Set<string>();
				const validated: Array<{ name: string; agent: AgentConfig; task: string; model?: string; cwd?: string; allowedPaths?: string[]; reportPath?: string }> = [];
				if (rawTasks.length >= 1 && rawTasks.length <= 32) {
					rawTasks.forEach((value, index) => {
						const item = value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
						const agentName = typeof item.agent === "string" ? item.agent.trim() : "";
						const assignment = typeof item.task === "string" ? item.task.trim() : "";
						// v2 §7.2：batch 节点同样经集中归一（别名→canonical）+ 解析模式固定首部注入；
						// 未知名沿用既有「未知角色」错误文案（不猜近似名）。
						const _nodeReq = resolveAgentRequest(agentName);
						const _nodeHeader = "modeHeader" in _nodeReq ? _nodeReq.modeHeader : undefined;
						const agent = findAgentByRequest(agents, agentName);
						// 8月迭代 F2：未知键整单拒绝——JSON 键名错乱/typo（如 descripton、"task "带尾随空格）
						// 曾静默受理致节点配置不生效；tasks[] 合法键仅 agent/task/name/model/cwd/allowedPaths（A2 节点级 cwd、C3 节点级白名单）/reportPath（ev-20260907-8abf9a 节点报告路径）。
						const KNOWN_TASK_KEYS = new Set(["agent", "task", "name", "model", "cwd", "allowedPaths", "reportPath"]);
						const unknownKeys = Object.keys(item).filter((k) => !KNOWN_TASK_KEYS.has(k));
						if (unknownKeys.length > 0) errors.push(`tasks[${index}] 含未知键: ${unknownKeys.map((k) => JSON.stringify(k)).join(", ")}（合法键: agent/task/name/model/cwd/allowedPaths/reportPath；疑似键名错乱）`);
						if (!agentName) errors.push(`tasks[${index}].agent trim 后必须非空`);
						else if (!agent) errors.push(`tasks[${index}].agent 未知角色 "${agentName}"`);
						if (!assignment) errors.push(`tasks[${index}].task trim 后必须非空`);
						if (item.model !== undefined && typeof item.model !== "string") errors.push(`tasks[${index}].model 必须是字符串`);
						// A2 节点级 cwd：类型错误整单拒绝；字符串但空/不存在 → group-scheduler 节点级结构化拒单（不连坐整组）
						if (item.cwd !== undefined && typeof item.cwd !== "string") errors.push(`tasks[${index}].cwd 必须是字符串`);
						// C3 节点级 allowedPaths：类型错误整单拒绝；空数组/含非法项 → group-scheduler 节点级拒单（invalid-allowed-paths，不连坐）；
						// 与顶层 protectedPaths 互斥（白/黑名单二选一，与顶层互斥语义一致）
						if (item.allowedPaths !== undefined && (!Array.isArray(item.allowedPaths) || !item.allowedPaths.every((e) => typeof e === "string"))) errors.push(`tasks[${index}].allowedPaths 必须是字符串数组`);
						if (item.allowedPaths !== undefined && params.protectedPaths !== undefined) errors.push(`tasks[${index}].allowedPaths 与顶层 protectedPaths 互斥（白名单/黑名单二选一）`);
						// ev-20260908-8d5d8f（P1）：tasks[].allowedPaths 逐项存在性预检（本整单拒绝层）——漏前缀/typo 的
						// 相对路径在派发瞬间暴露，不再等节点跑完数十分钟在写守卫处 blocked（实战：3/3 节点各 9~11 分钟
						// 后落盘一步被拦）。解析基准与运行时 group-scheduler 一致：节点 cwd（相对 Leader 派发 cwd 解析），
						// 缺省继承 Leader cwd；ev-20260902 运行时自动附带的 amagi-task/<runId> 临时目录非用户参数，不经此处；
						// 空数组维持节点级拒单语义（invalid-allowed-paths），不在此重复拦截。
						if (Array.isArray(item.allowedPaths) && item.allowedPaths.length > 0 && item.allowedPaths.every((e) => typeof e === "string")) {
							const nodeBase = typeof item.cwd === "string" && item.cwd.trim() ? (path.isAbsolute(item.cwd) ? item.cwd : path.resolve(ctx.cwd, item.cwd)) : ctx.cwd;
							for (const apErr of allowedPathsExistenceErrors(item.allowedPaths, nodeBase, "相对节点 cwd")) errors.push(`tasks[${index}].allowedPaths 含不存在路径: ${apErr}`);
						}
						// ev-20260907-8abf9a + ev-20260909-e4d4f2：节点报告路径静态校验与互锁预检（整单拒绝层）
						// ev-20260909-e4d4f2：已存在目录检查与 reportPath↔allowedPaths 互锁预检前置到本整单拒绝层
						// （复用 resolveNodeReportPath，提前暴露配置事故，避免整批跑完在 guard 处全灭）
						if (item.reportPath !== undefined) {
							if (typeof item.reportPath !== "string") errors.push(`tasks[${index}].reportPath 必须是字符串（完整具体文件路径）`);
							else {
								const rpTrimmed = item.reportPath.trim();
								if (!rpTrimmed) errors.push(`tasks[${index}].reportPath 为空串（不注入报告路径请直接省略该键）`);
								if (REPORT_PATH_INVALID_RE.test(rpTrimmed)) errors.push(`tasks[${index}].reportPath 含未展开占位符或控制字符: ${JSON.stringify(rpTrimmed)}——请提供完整具体文件路径（相对节点 cwd 解析，如 reports/c2a-report.md），不要 <节点名> / \${name} / {nodeName} 模板或换行/控制字符（实战事故 ev-20260907-8abf9a：占位符被解析为截断前缀落盘单字符路径）`);
								if (/[\\/]$/.test(rpTrimmed)) errors.push(`tasks[${index}].reportPath 以路径分隔符结尾（目录形态）——报告路径必须是具体文件路径（如 reports/c2a-report.md），不是目录`);

								if (rpTrimmed && !REPORT_PATH_INVALID_RE.test(rpTrimmed) && !/[\\/]$/.test(rpTrimmed)) {
									const nodeBase = typeof item.cwd === "string" && item.cwd.trim()
										? (path.isAbsolute(item.cwd) ? item.cwd : path.resolve(ctx.cwd, item.cwd))
										: ctx.cwd;
									let nodeAllowedPaths: string[] = [];
									if (item.allowedPaths !== undefined) {
										const apRes = resolveNodeAllowedPaths(item.allowedPaths, nodeBase);
										if (apRes.ok) {
											nodeAllowedPaths = apRes.paths;
										}
									}
									const rpRes = resolveNodeReportPath(rpTrimmed, nodeBase, nodeAllowedPaths);
									if (!rpRes.ok) {
										const nodeLabel = item.name ? `tasks[${index}]("${item.name}")` : `tasks[${index}]`;
										errors.push(`${nodeLabel}.reportPath ${rpRes.message}`);
									}
								}
							}
						}

						let name: string;
						if (item.name === undefined) name = `${agentName}-${index + 1}`;
						else if (typeof item.name !== "string" || !/^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(item.name)) {
							errors.push(`tasks[${index}].name 必须匹配 /^[A-Za-z][A-Za-z0-9_-]{0,31}$/`);
							name = "";
						} else name = item.name;
						const nameKey = name.toLowerCase();
						if (name && names.has(nameKey)) errors.push(`tasks[${index}].name 与组内名称大小写不敏感重复: "${name}"`);
						else if (name) names.add(nameKey);

						let normalizedModel: string | undefined;
						if (agent) {
							const resolvedModel = resolveModel(agent, { paramModel: typeof item.model === "string" ? item.model : undefined, fallbackModel: fallbackSpec, cwd: ctx.cwd });
							const normalized = normalizeModelSpec(resolvedModel, ctx.modelRegistry);
							if (!normalized.ok) errors.push(`tasks[${index}].model: ${normalized.error}`);
							else normalizedModel = normalized.spec;
						}
						if (agent && assignment && name && (item.model === undefined || typeof item.model === "string") && (item.cwd === undefined || typeof item.cwd === "string") && (item.allowedPaths === undefined || (Array.isArray(item.allowedPaths) && item.allowedPaths.every((e) => typeof e === "string"))) && (item.reportPath === undefined || (typeof item.reportPath === "string" && item.reportPath.trim() && !REPORT_PATH_INVALID_RE.test(item.reportPath.trim()) && !/[\\/]$/.test(item.reportPath.trim())))) {
							validated.push({ name, agent, task: withModeHeader(_nodeHeader, assignment), model: normalizedModel, cwd: typeof item.cwd === "string" ? item.cwd : undefined, allowedPaths: Array.isArray(item.allowedPaths) ? item.allowedPaths : undefined, reportPath: typeof item.reportPath === "string" ? item.reportPath : undefined });
						}
					});
				}
				if (errors.length > 0) {
					return { content: [{ type: "text" as const, text: `[batch 整单拒绝] ${errors.join("；")}。零节点启动。` }], isError: true };
				}

				const overlapConflicts = detectAllowedPathsOverlap(validated, ctx.cwd);
				const overlapWarning = formatAllowedPathsOverlapWarning(overlapConflicts);
				// ev-20260909-c00fcb①：契约变更类任务书的联动面预警（软提示；仅对带写入边界的节点生效）
				const linkageWarning = contractLinkageWarning(validated
					.filter((t) => (Array.isArray(t.allowedPaths) && t.allowedPaths.length > 0) || (Array.isArray(params.allowedPaths) && params.allowedPaths.length > 0))
					.map((t) => ({ label: `batch[${t.name || t.agent}]`, task: t.task })));

				const batchId = genTaskId().slice(0, 8);
				const runId = `batch-${batchId}`;
				const groupSpec: GroupSpec = {
					runId,
					nodes: validated.map((item) => ({
						nodeId: item.name,
						name: item.name,
						agent: item.agent.name,
						model: item.model,
						cwd: item.cwd,
						allowedPaths: item.allowedPaths,
						reportPath: item.reportPath,
						task: `[batch 共享 context]\n${sharedContext}\n\n[batch 节点 ${item.name} 独立 assignment]\n${item.task}`,
					})),
				};
				const asyncBatch = params.asyncGroup !== false;
				// A2（ev-20260910-d86779）：batch 节点瞬时错误自动重派——退避期不占槽（内层 runTask finally 已
				// 归还），fresh spawn 同任务书重跑（新 taskId/新记录）；journal retry 留痕 + steer 调度通知。
				// batch 缺省异步（asyncBatch），节点重派不阻塞主会话；asyncGroup:false 同步汇总同样适用。
				const _arRunTask = async (agent: AgentConfig, task: string, opts: Record<string, unknown>): Promise<RunResult> => {
					if (!_autoRetryCfg || !isAutoRetryEnabled()) return runTask(agent, task, opts as unknown as Parameters<typeof runTask>[2]);
					let attempt = 0;
					for (;;) {
						const rr = await runTask(agent, task, opts as unknown as Parameters<typeof runTask>[2]);
						if (rr.aborted) return rr;
						const plan = nextAutoRetryPlan({ status: rr.status, errorMessage: rr.errorMessage, spawnError: rr.spawnError, stopReason: rr.stopReason, model: rr.model, attempt, config: _autoRetryCfg });
						if (!plan) return rr;
						attempt++;
						journalRetry({ taskId: rr.taskId, n: plan.n, backoffMs: plan.delayMs, nextModel: plan.nextModel });
						const _retryMsg = `[batch 自动重试] 节点任务 ${rr.taskId.slice(0, 8)} 瞬时 provider 错误，${Math.round(plan.delayMs / 1000)}s 后自动重派（第 ${plan.n}/${_autoRetryCfg.retries} 次，fresh spawn 同任务书）。重派结果随组通知回流。\n[失败根因] ${(rr.errorMessage || rr.spawnError || "").slice(0, 200)}`;
						if (pi?.sendUserMessage) { try { pi.sendUserMessage(_retryMsg, { deliverAs: "steer" }); } catch {} }
						await new Promise((res) => setTimeout(res, plan.delayMs));
					}
				};
				const deps: GroupRunDeps = {
					cwd: ctx.cwd,
					modelRegistry: ctx.modelRegistry,
					command: testOpts?.testCommand,
					onStall: _onStall,
					findAgent: (name) => findAgentByRequest(agents, name),
					runTask: (agent, task, opts) => _arRunTask(agent, task, opts),
					runResume: (agent, resumeParams, opts) => runResumeTask(agent, resumeParams as Parameters<typeof runResumeTask>[1], opts as unknown as Parameters<typeof runResumeTask>[2]),
					testRunNode: testOpts?.orchestrateRun ? (agent, task, opts) => testOpts.orchestrateRun!(agent, task, { cwd: opts.cwd, model: opts.model, onStall: _onStall }) : undefined,
					trusted: resolveProjectTrusted(ctx),
					// ev-20260917-589972：batch 顶层 sharedTree 声明透传（全部节点归因降噪）
					...(params.sharedTree === true ? { evidence: { sharedTree: true } } : {}),
					// ev-20260903-263d48：节点通知去重——同 runId+nodeId+status 只投递一次（steer 排队 flush 与
					// 状态迁移重发造成的重复送达直接跳过）。status 口径与 nodeDeliveryMessage 一致（error.code=blocked
					// 归一为 "blocked"）：blocked 后 resume 再 done 是不同键，两次状态各自投递，不受去重影响。
					onNodeDone: asyncBatch ? (env) => {
						const nodeKey = `notify:${runId}:${env.nodeId || env.taskId}:${env.error?.code === "blocked" ? "blocked" : env.status}`;
						if (!shouldNotify(nodeKey)) return;
						// ev-20260910-060c3a：节点通知附模型回流（runTask 已把「实际生效行/偏离警示/模型类
						// 报错归因」写入 modelNote；nodeDeliveryMessage 正文不含该字段——在此补挂）。
						const _nodeModelNote = env.display?.modelNote ? `\n${env.display.modelNote}` : "";
						const msg = nodeDeliveryMessage("batch 节点完成", env) + _nodeModelNote;
						if (pi?.sendUserMessage) { try { pi.sendUserMessage(msg, { deliverAs: "steer" }); } catch {} }
					} : undefined,
				};
				const renderBatch = (outcome: GroupRunOutcome): string => {
					const lines = validated.map((item) => {
						const env = outcome.envelopes[item.name];
						if (!env) return `${item.name}: skipped`;
						return renderBatchNodeLine(item, env, ctx.cwd);
					});
					for (const skipped of outcome.skipped) lines.push(`${skipped.nodeId}: skipped — ${skipped.reason}`);
					return `[batch ${runId} · ${validated.length} 节点]\n${lines.join("\n")}`;
				};
				if (asyncBatch) {
					submitGroup(groupSpec, deps, {
						onDone: (outcome) => {
							// ev-20260903-263d48：组完成通知去重——同组同档只投递一次。按 outcome.isError 分
							// 「含失败/全部完成」两档（两档是不同事实各发一次；同档重发属重复投递，跳过）。
							if (!shouldNotify(`notify:${runId}:group-done:${outcome.isError ? "isError" : "ok"}`)) return;
							const msg = `[batch 完成 ${runId}] ${outcome.isError ? "含失败/跳过节点" : "全部完成"}\n${renderBatch(outcome)}`;
							if (pi?.sendUserMessage) { try { pi.sendUserMessage(msg, { deliverAs: "steer" }); } catch {} }
						},
					});
					return { content: [{ type: "text" as const, text: `[submitGroup · ${runId} · ${validated.length} 节点] 已受理并异步执行（共享准入 FIFO 排队）。\n节点名单（派发即对账，缺失即参数被丢）: ${groupSpec.nodes.map((n) => n.name).join(", ")}\ntask({ wait: { group: "${runId}", mode: "all" } }) 可显式等待；task({ cancel: "${runId}" }) 可级联取消。${overlapWarning}${linkageWarning}` }] };
				}
				const outcome = await runGroup(groupSpec, deps);
				return { content: [{ type: "text" as const, text: `${renderBatch(outcome)}${overlapWarning}${linkageWarning}` }], isError: outcome.isError };
			}

		// T2-5 编排模式（fanout/pipeline/tournament/redteam，纯语法糖展开为多次 runTask，复用 registry/trace/blocked 基建）
		// E4: dryRun 早守卫——dryRun 仅支持单任务路径，resume/编排模式如实报错
		if (params.dryRun) {
			if (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork) {
				return { content: [{ type: "text" as const, text: "[dryRun 不适用] dryRun 不支持编排模式（fanout/pipeline/tournament/redteam/fork）。请去掉 dryRun 或改用单任务。" }], isError: true };
			}
			if (params.session) {
				return { content: [{ type: "text" as const, text: "[dryRun 不适用] dryRun 不支持 resume 模式（session）。请去掉 dryRun 或 session。" }], isError: true };
			}
			// ev-20260917-8651a0：dryRun 只解析模型/cwd/预检，不组装任务书注入层——reportPath 校验随实际
			// 派发进行（不静默丢弃，显式拒单）。
			if (params.reportPath !== undefined) {
				return { content: [{ type: "text" as const, text: "[reportPath 不适用] dryRun 只解析不派发，不做报告路径注入/校验——去掉 dryRun 后实际派发时 reportPath 生效，或去掉 reportPath。" }], isError: true };
			}
			// ev-20260905-7614b1：dryRun 与 exportPrompt 互斥——同为「不派发」但语义相反（解析预检 vs 落盘导出），同传是参数事故。
			if (params.exportPrompt !== undefined) {
				return { content: [{ type: "text" as const, text: "[参数互斥] dryRun 与 exportPrompt 互斥（同传拒单）——dryRun=只解析不派发（零落盘），exportPrompt=只导出不派发（落盘自包含提示词文件）；请只保留其一。" }], isError: true };
			}
		}
		// ev-20260905-7614b1：exportPrompt 仅单任务——编排模式各分支自带 agent/task 列表，导出语义不成立（显式拒单，不静默丢弃）。
		if (params.exportPrompt !== undefined && (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork)) {
			return { content: [{ type: "text" as const, text: "[exportPrompt 不适用] exportPrompt 仅支持单任务派发（agent+task），不支持编排模式（fanout/pipeline/tournament/redteam/fork）。" }], isError: true };
		}
		// v2 批次C：编排异步 flag（参数优先，AMAGI_GROUP_ASYNC=1 环境级覆盖）
		const _asyncGroup = params.asyncGroup === true || process.env.AMAGI_GROUP_ASYNC === "1";
		// ev-20260916-23f4a4：编排模式各分支自建 runTask 调用（不经过本 execute 的冻结透传链），
		// evidenceTimeouts 无法携带——显式拒单（不静默丢弃），与 batch 互斥拒绝同语义。
		if (params.evidenceTimeouts !== undefined && (params.fanout || params.pipeline || params.tournament || params.redteam || params.fork)) {
			return { content: [{ type: "text" as const, text: "[evidenceTimeouts 不适用] 编排模式（fanout/pipeline/tournament/redteam/fork）分支的收尾链不经本参数——询单任务派发携带，或去掉该参数（batch 亦不支持，节点级无此字段）。零任务启动。" }], isError: true };
		}
		if (params.fanout) return orchestrate("fanout", params.fanout, params.task || "", agents, ctx, testOpts, _onStall, { asyncGroup: _asyncGroup, pi, runTask: _orchRunTask });
		if (params.pipeline) return orchestrate("pipeline", params.pipeline, params.task || "", agents, ctx, testOpts, _onStall, { asyncGroup: _asyncGroup, pi, runTask: _orchRunTask });
		if (params.tournament) return orchestrate("tournament", params.tournament, params.tournament?.task || params.task || "", agents, ctx, testOpts, _onStall, { asyncGroup: _asyncGroup, pi, runTask: _orchRunTask });
		if (params.redteam) return orchestrate("redteam", params.redteam, params.task || "", agents, ctx, testOpts, _onStall, { asyncGroup: _asyncGroup, pi, runTask: _orchRunTask });
		if (params.fork) return orchestrate("fork", params.fork, params.task || "", agents, ctx, testOpts, _onStall, { asyncGroup: _asyncGroup, pi, runTask: _orchRunTask });

		// 单任务/resume 模式需 task（编排模式已在上 return）
		if (!params.task) return { content: [{ type: "text" as const, text: `需要 task（单任务/resume 必填），或使用 fanout/pipeline/tournament/redteam 编排模式。可用角色: ${agentList}` }], isError: true };

		// E1: 任务级 cwd（子进程工作目录/证据采集/git diff 以此为准；resume 会话与原 cwd 绑定，拒绝覆盖）
		const _cwdRes = resolveTaskCwd(params.cwd, ctx.cwd);
		if (!_cwdRes.ok) return { content: [{ type: "text" as const, text: _cwdRes.message }], isError: true };
		if (params.session && params.cwd) return { content: [{ type: "text" as const, text: "[cwd 不适用] resume 会话与原工作目录绑定，不支持 cwd 覆盖（请在原目录发起或重新分派新任务）" }], isError: true };
		if (params.session && params.worktree) return { content: [{ type: "text" as const, text: "[worktree 不适用] resume 会话与原工作目录绑定，不支持 worktree；请新派任务携带 worktree 参数" }], isError: true };
		// ev-20260917-8651a0：reportPath 注入发生在任务书组装层，resume 沿用原会话任务书语义——不受理（不静默丢弃）。
		if (params.session && params.reportPath !== undefined) return { content: [{ type: "text" as const, text: "[reportPath 不适用] resume 沿用原会话任务书与白名单快照，不支持 reportPath 注入——报告路径清请新派任务携带 reportPath 参数（resume 任务书内可用文本引用既有报告路径）。" }], isError: true };
		// ev-20260917-589972：sharedTree 声明未持久化到会话记录，resume 无法继承降噪声明——不受理（不静默丢弃）。
		if (params.session && params.sharedTree !== undefined) return { content: [{ type: "text" as const, text: "[sharedTree 不适用] resume 会话不继承 sharedTree 声明（归因降噪声明属派发时快照；如需降噪请新派任务携带 sharedTree: true）。" }], isError: true };
		// ev-20260905-7614b1：resume 沿用原会话上下文，无「新任务书导出」语义（显式拒单，不静默丢弃）。
		if (params.session && params.exportPrompt !== undefined) return { content: [{ type: "text" as const, text: "[exportPrompt 不适用] exportPrompt 仅支持新派发任务（agent+task）；resume 沿用原会话上下文，无任务书导出语义。请新派任务时导出或直接派发。" }], isError: true };
		let taskCwd = _cwdRes.cwd;

		// ev-20260903-a5b662（复盘 §5#2）：大改任务 worktree 引导（软提示，单任务新派发才命中）。
		// ev-20260905-c0b446：调用点从 schema 校验后移到 cwd 解析后——非 git 目标跳过 + 同 cwd
		// 连续不采纳静默（事故：Database 文档目录目标 7+ 次误报全不适用且无记忆抑制）。
		// ev-20260906-d8fcf1①：受派角色章程只读判定传入——diting/baize 等「禁止修改
		// 代码/纯只读」charter 角色的任务恒无 worktree 隔离需求（审核对象≠改动面），跳过建议。
		const _wtAgent = findAgentByRequest(agents, params.agent ?? "");
		// ev-20260916-2dbc7f/c5ee56（S4 集成）：preflight（默认）——建议经 dryRun 派发预检评估前置返回，
		// 实际派发不做事后 steer（迟到建议改变不了已发出的派发，只产生噪音与矛盾）；未 dryRun 的
		// 派发不补发建议（不能保证模型调过 dryRun，也不为所有任务加一次往返）。legacy 回旧事后 steer 时序。
		if (worktreePreflightMode() === "legacy") {
			try { suggestWorktreeDispatch(pi, params, { cwd: taskCwd, agentReadOnly: agentCharterReadOnly(_wtAgent) }); } catch { /* 观测提示失败静默 */ }
		}

		// ── resume ──
		if (params.session) {
				const resolved = resolveSessionWithBackfill(params.session);
				// v1.5.222：内存未命中先走磁盘回填（Leader 重启后 resume 不再依赖原进程存活）
				if (!resolved) return { content: [{ type: "text" as const, text: `[resume 失败] 未找到会话 "${params.session}"（registry 无记录；磁盘回退亦未命中——会话可能未落 artifact 或 sessionId 不可恢复）` }], isError: true };
				const _bfNote = resolved.backfillNote ? resolved.backfillNote + "\n" : "";
				// C3：resume 沿用原会话派发时的执行环境，本次 allowedPaths 无法注入（子进程 env 在首次 spawn 时已定型）——如实提示，不静默丢弃
				const _apNote = params.allowedPaths !== undefined ? "[allowedPaths 不适用] resume 默认继承原任务派发时白名单快照（本次 allowedPaths 参数已忽略；如需扩展越界补丁授权请新派任务并在其 allowedPaths 声明）\n" : "";
				const agent = findAgentByRequest(agents, resolved.record.agent);
				if (!agent) return { content: [{ type: "text" as const, text: `[resume 失败] 原角色 "${resolved.record.agent}" 不存在（v2 已收敛为五 canonical 角色；旧名经别名归一后仍找不到——请新派任务承接原 artifact）` }], isError: true };
				// resume 与原任务工作目录绑定：子进程落在原 cwd——否则 pi 检测到会话属另一项目会交互式
				// 询问 "Session found in different project…Fork?"，非交互子进程直接卡死（实战事故）。
				// 旧记录无 cwd 字段时回退 Leader cwd（兼容 v1.5.170 前的会话）。
				const _resumeCwd = resolved.record.cwd ?? ctx.cwd;
				if (resolved.record.cwd && !fs.existsSync(resolved.record.cwd))
					return { content: [{ type: "text" as const, text: `[resume 失败] 原任务工作目录已不存在: ${resolved.record.cwd}（会话与原目录绑定；请新派任务）` }], isError: true };
				// v2 批次B：并发上限改为共享准入队列（admission.ts）——超限 FIFO 排队而非整单拒绝（零静默丢失）。
				// P0: onComplete（回流 + 持久化）
				const onComplete = params.background ? (r: any) => {
					snapshotForPersist(pi);
					const _rRounds = registry.get(r.taskId)?.rounds?.length || 0;
					const _rOutput = r.status === "cancelled"
						? appendCancellationReason(r.output, r.errorMessage)
						: r.output || (r.status === "error" ? `[失败根因] ${r.errorMessage || "(未提供根因)"}` : r.errorMessage || "(无输出)");
					const _notify = (_fin?: Awaited<ReturnType<typeof finalizeTerminal>>) => {
						const _rBody = r.blocked ? _rOutput : (_fin?.body || _rOutput);
						const _status = r.blocked ? "blocked" : r.status;
						// ev-20260910-060c3a / 316c6e：后台 resume 完成通知同样回显实际生效模型 + 模型类报错归因。
						// ed-20260910 diting n-3：与 sync resume 路径（_resumeNotes）对齐，补归一化模型注记
						// （task-resume 在 wrappedFinalize 挂载 _nm.note；缺了它后台 resume 的归一提示就断一条通道）。
						const _bgResumeNotes = [
							effectiveModelNote(r.model, paramModel ? "param" : undefined),
							r.modelNote,
							r.status === "error" && isModelProviderError(r.errorMessage || r.spawnError)
								? modelFailureAdvice({ failedSpec: r.model || paramModel, configuredSpec: resolveModel(agent, { fallbackModel: fallbackSpec, cwd: _resumeCwd }), registry: ctx.modelRegistry, fallbackModels: loadFallbackModels(_resumeCwd) })
								: undefined,
						].filter(Boolean).join("\n");
						const msg = `[resume 后台完成 ${r.agent}/${r.taskId.slice(0, 8)}] 状态: ${_status}\n${_bgResumeNotes ? `${_bgResumeNotes}\n` : ""}${_rBody}${r.completionAnnotation || ""}${escalationHint(_rRounds, r.blocked)}${blockedReplyDirective(r.taskId, r.blocked, r.blockReason)}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${r.interruptionReport ? `\n${r.interruptionReport}` : ""}`;
						checkpoint(pi, r.agent, _status, r.taskId, ctx);
						if (pi?.sendUserMessage) { try { pi.sendUserMessage(msg, { deliverAs: "steer" }); } catch {} }
					};
					void finalizeTerminal({ taskId: r.taskId, agent: r.agent, result: { ...r, output: _rOutput }, cwd: _resumeCwd, evidence: { gatherEv: testOpts?.evidence, trusted: resolveProjectTrusted(ctx), baselinePorcelain: r.gitBaseline, timeouts: _evTimeouts }, expectedRevision: r.dispatchRevision }).then(_notify, () => _notify());
				} : undefined;
				// E10: artifact 挂载——上一轮产出落盘存活，引用路径（不复制内容，不占上下文）
			const _prevArt = findArtifact(_resumeCwd, resolved.record.taskId);
			const _resumeTask = _prevArt ? `${params.task}\n\n[amagi artifact 挂载] 上一轮(${resolved.record.taskId.slice(0, 8)})产出已落盘: ${_prevArt.relDir}/（result.md 完整回流 + metadata.json；需要旧上下文时直接 read）` : params.task;
			const res = await runResumeTask(agent, { session: params.session, task: _resumeTask, model: paramModel, background: params.background }, { cwd: _resumeCwd, fallbackModel: fallbackSpec, signal, command: testOpts?.testCommand, modelRegistry: ctx.modelRegistry, onComplete, onStall: _onStall, trusted: resolveProjectTrusted(ctx) });
				if ("status" in res && (res.status === "running" || res.status === "queued")) {
					const _admR = admissionStats();
					return { content: [{ type: "text" as const, text: `${_bfNote}${_apNote}${res.fuseWarning || ""}[resume 后台 ${res.taskId.slice(0, 8)}] ${res.status === "queued" ? `已入队排队（槽位 ${_admR.running}/${_admR.capacity} 在跑 · ${_admR.queued} 排队${admissionPoolNote(_admR)}；晋级后自动启动，完成自动通知；可用 task({ cancel: "${res.taskId}" }) 取消）` : "已派发"}` }] };
				}
				const r = res as RunResult;
				if (!params.background) snapshotForPersist(pi); // background 终结回调已持久化，避免重复 append
			// ev-20260910-060c3a / 316c6e：resume 结果回显实际生效模型（r.model 为子进程流实测）
			// + task-resume 归一 note + 模型类报错归因候选。
			const _resumeNotes = [
				effectiveModelNote(r.model, paramModel ? "param" : undefined),
				r.modelNote,
				r.status === "error" && isModelProviderError(r.errorMessage || r.spawnError)
					? modelFailureAdvice({ failedSpec: r.model || paramModel, configuredSpec: resolveModel(agent, { fallbackModel: fallbackSpec, cwd: _resumeCwd }), registry: ctx.modelRegistry, fallbackModels: loadFallbackModels(_resumeCwd) })
					: undefined,
			].filter(Boolean).join("\n") || undefined;
			const tag = `${_bfNote}${_apNote}[resume ${r.taskId.slice(0, 8)} ${agent.name} · ${r.blocked ? "blocked" : r.status}]`;
			let text = r.status === "cancelled"
				? appendCancellationReason(r.output, r.errorMessage)
				: r.output || (r.status === "error" ? `[失败根因] ${r.errorMessage || `(退出码 ${r.exitCode})`}${r.stderr ? `\n[stderr]\n${r.stderr}` : ""}` : "(无输出)");
			// ev-20260822-872c59：准入前拒绝（未 spawn/未建记录，taskId 为 prev 定位用途）——直接透出根因。
			// 禁入 finalizeTerminal：旧 taskId 的幂等缓存会回放上一轮终稿全文，把失败根因顶掉
			// （实战：resume 已 done 的后台会话两次返回旧终稿并标 error，真实拒单原因完全不可见），
			// 且会把错误结果写进旧任务 artifact 目录。
			if ((r as { rejected?: boolean }).rejected) {
				return { content: [{ type: "text" as const, text: `${r.fuseWarning || ""}${_resumeNotes ? `${_resumeNotes}\n\n` : ""}${tag}\n\n${text}` }], isError: true };
			}
			// v2 批次B：统一收尾链（幂等 + stale 防护 + artifact/折叠/证据 固定序）；
			// enriched text（含 [失败根因]/[已取消] 段）经 output 透传，保持折叠与证据基文与原语义一致。
			// ev-20260905-f51a49：失败残留须在收尾链之前采集（finalizeTerminal 消费完证据后会清理写入登记）。
			const _rsFailed = r.status === "error" || r.status === "cancelled";
			const _rsRec0 = registry.get(r.taskId);
			const _rsResidue = _rsFailed ? collectResidue(r.taskId, { cwd: _rsRec0?.cwd ?? _resumeCwd, startedAt: _rsRec0?.startedAt }) : null;
			const _finR = await finalizeTerminal({ taskId: r.taskId, agent: agent.name, result: { ...r, output: text }, cwd: _resumeCwd, evidence: { gatherEv: testOpts?.evidence, trusted: resolveProjectTrusted(ctx), baselinePorcelain: r.gitBaseline, timeouts: _evTimeouts }, expectedRevision: r.dispatchRevision });
			text = _finR.body;
			text += escalationHint(registry.get(r.taskId)?.rounds?.length || 0, r.blocked);
			text += blockedReplyDirective(r.taskId, r.blocked, r.blockReason);
			// v1.5.188 P1-3②：E1/E3 标注已收口到 runPiTask finalize（r.completionAnnotation）；execute 不再重复接线
			text += r.completionAnnotation || "";
			// ev-20260910-8fbe4e（C）：连接类中断现场报告（error+providerError 终态携带；resume 续轮失败
			// 的现场盘点——有产物时 resume 续接建议恰好是本轮语义）。
			if (r.interruptionReport) text += `\n${r.interruptionReport}`;
			// ev-20260905-24558f：error 返回体附进程实况（finalize 期间已定格的实况在 completionAnnotation 内，不重复追加）。
			if (r.isError) {
				const _rsLive = processLivenessNote(registry.get(r.taskId));
				if (_rsLive && !text.includes("[进程实况]")) text += `\n${_rsLive}`;
			}
			// ev-20260905-f51a49：失败残留附注（N=0 不追加；轻护栏强感知，不清理不阻断）。
			{ const _rsNote = residueNote(_rsResidue); if (_rsNote) text += `\n${_rsNote}`; }
			// K5b：resume 续轮同样读同版内核视图（K5a 验收 4 同源；内核未持有该任务时返回空串，零副作用）
			text += kernelViewLine(r.taskId);
			// Batch 3（§9.5 成本进入 footer）：resume 续轮 footer（同会话续接→本轮+逻辑链合计两截）
			text += renderUsageFooter(r.taskId);
			checkpoint(pi, agent.name, r.blocked ? "blocked" : r.status, r.taskId, ctx);
			markExecuteReturned(r.taskId); // ev-20260905-24558f：登记 execute 返回时刻（迟终态回推判据①）
			return { content: [{ type: "text" as const, text: `${r.fuseWarning || ""}${_resumeNotes ? `${_resumeNotes}\n\n` : ""}${tag}\n\n${text}` }], isError: r.isError };
			}

			// ── 普通 task ──
			if (!params.agent) return { content: [{ type: "text" as const, text: `需要 agent（${agentList}）或 session` }], isError: true };
			// v2 §7.2：集中归一（八旧 stem 别名→canonical）+ 解析模式；未知名沿用既有错误，不猜近似名。
			const _agentReq = resolveAgentRequest(params.agent);
			const agent = findAgentByRequest(agents, params.agent);
			if (!agent) return { content: [{ type: "text" as const, text: `未知角色: "${params.agent}"。可用: ${agentList}（兼容别名 wenqu/taibai/laojun/wukong/cangjie/diting-quick/hongjun/puti 归一到 canonical）` }], isError: true };
			// 解析模式 ≠ 角色默认时任务正文首部注入固定首部（幂等；#hongjun→任务态: attack 等）。
			const _modeHeader = "modeHeader" in _agentReq ? _agentReq.modeHeader : undefined;
			if (_modeHeader && params.task) params = { ...params, task: withModeHeader(_modeHeader, params.task) };

			// v1.5.173: 派发前模型 spec 归一/校验——裸模型名（如 "glm-5.2"）经 --model 传给 pi 会被静默回退
			// 到默认模型（实战：puti 实际跑了 openai-codex/gpt-5.6-sol，registry 记录与实际不符污染路由记忆）。
			// 全限定校验注册；裸名唯一匹配归一并透出 note；歧义/未知/无凭据诚实报错不派发。
			// 覆盖 sync/background/dryRun；编排模式各分支自解析、resume 继承原任务已归一 spec，不在此拦截。
			const _preResolved = resolveModelWithSource(agent, { paramModel, fallbackModel: fallbackSpec, cwd: taskCwd });
			const _norm = normalizeModelSpec(_preResolved.spec, ctx.modelRegistry);
			if (!_norm.ok) return { content: [{ type: "text" as const, text: _norm.error }], isError: true };
			if (_norm.spec && _norm.spec !== paramModel) params = { ...params, model: _norm.spec };
			// v1.5.216: param model 覆盖自省——显式 param 与配置解析值（amagi.json/frontmatter 等）不同时提示，
			// 复用 _norm.note 通道自动流入 dryRun/后台派发/sync 结果三条消息路径；相同不提示
			const _overrideNote = _preResolved.source === "param" ? modelOverrideNote(agent, { paramModel, effectiveSpec: _norm.spec, fallbackModel: fallbackSpec, cwd: taskCwd }) : undefined;
			// ev-20260910-060c3a：派发先行路径（dryRun/exportPrompt/后台启动）统一回显实际生效模型；
			// sync 结果由 runTask 回流 modelNote（已含同一行），此处不重复挂载。
			const _effectiveNote = effectiveModelNote(_norm.spec ?? _preResolved.spec, _preResolved.source, _preResolved.amagiOrigin); // diting F-13：dryRun 面同透传项目/全局层
			const _modelNote = [_effectiveNote, _norm.note, _overrideNote, _chainDropNote].filter(Boolean).join("\n") || undefined;
			// E4 R2：普通 sync/background 的熔断警告由 runTask 计算（fuseWarning 字段回流）；execute 仅 dryRun 分支自查（避免双查，见 Major-4）。

			// C5: _onStall 已在 execute 顶部统一定义（resume/sync/background/orchestrate 共用）

			// ── ev-20260905-7614b1：exportPrompt 只导出不派发 ──
			// 与单任务派发共用上文 agent/task/cwd/model 解析校验（model 归一失败同样拒单——参照模型须诚实），
			// 但零 spawn/零准入槽/零 registry：把任务书组装为五段式自包含提示词落盘（task-export.ts），
			// 供主上复制到外部工具（如 Codex CLI）手动接管（背景事故见 task-export.ts 模块头）。
			if (params.exportPrompt !== undefined && params.exportPrompt !== false) {
				if (params.worktree) return { content: [{ type: "text" as const, text: "[exportPrompt 不适用] 只导出不派发，无子进程作业，worktree 无意义——请去掉 worktree 或改为正常派发。" }], isError: true };
				if (params.background) return { content: [{ type: "text" as const, text: "[exportPrompt 不适用] 只导出不派发，导出即时落盘返回，background 后台语义无意义。" }], isError: true };
				// ev-20260917-8651a0：reportPath 注入属任务书组装层，exportPrompt 只导出不派发（不静默丢弃）。
				if (params.reportPath !== undefined) return { content: [{ type: "text" as const, text: "[reportPath 不适用] exportPrompt 只导出不派发，无报告路径注入/验收语义——请去掉 reportPath 或改为实际派发。" }], isError: true };
				if (typeof params.exportPrompt === "string" && !params.exportPrompt.trim()) {
					return { content: [{ type: "text" as const, text: "[exportPrompt 无效] 显式文件路径为空字符串——传 true 走缺省路径（<cwd>/.amagi-export/），或提供非空文件路径。" }], isError: true };
				}
				const _exp = exportTaskPrompt({
					agent, task: params.task!, taskCwd,
					modelSpec: paramModel ?? _norm.spec,
					gitRoot: resolveGitRoot(taskCwd),
					leaderCwd: ctx.cwd,
					explicitPath: typeof params.exportPrompt === "string" ? params.exportPrompt : undefined,
				});
				if (!_exp.ok) return { content: [{ type: "text" as const, text: _exp.message }], isError: true };
				return { content: [{ type: "text" as const, text: `[导出完成] ${_exp.path}（${_exp.bytes}）——已含角色/环境/纪律/回链，可直接粘贴外部工具${_modelNote ? `\n${_modelNote}` : ""}` }], isError: false };
			}

			// ev-20260908-8d5d8f（P1）：顶层 allowedPaths 逐项存在性预检（sync/background/dryRun 共用派发准入层；
			// resume 在上方分支已按既有语义忽略本参数，exportPrompt 只导出不派发也不适用）。解析基准与运行时
			// resolveAllowedPaths 一致：任务 cwd（相对 Leader cwd 解析后的绝对）。worktree 模式运行时基准是
			// worktree 根（同仓 checkout，此处以任务 cwd 预检为近似——漏前缀类配置错误在两棵树同样不存在）。
			{
				const _apErrs = Array.isArray(params.allowedPaths) && params.allowedPaths.length > 0 ? allowedPathsExistenceErrors(params.allowedPaths, taskCwd, "相对任务 cwd") : [];
				if (_apErrs.length > 0) {
					return { content: [{ type: "text" as const, text: `[allowedPaths 预检] ${_apErrs.join("；")}。零任务启动——配置错误在派发瞬间暴露（fail-fast），核对路径前缀后重派。` }], isError: true };
				}
			}

			// E4: dryRun 短路——agent/taskCwd 已解析，resolveModel 解析后直接返回，不触发 recordDispatch/runTask/registry.create/spawn
			// 覆盖 sync/background 统一路径（在 background 分流之前）
			if (params.dryRun) {
				// E4 dryRun 熔断警告前置（仍不派发；分类源 description || task 与 runTask 一致）
				const _fuseWarn = fuseWarningFor(agent.name, paramModel ?? _preResolved.spec, taskCategoryFor(params.description, params.task!));
				// 来源标注用归一前的 _preResolved.source（归一只改形式 bare→full，不改语义来源）
				const _drySource = _preResolved.source;
				// ev-20260908-8d5d8f：dryRun 同样带出 allowedPaths 预检结果——错误在上方准入层已拒单，此处只输出通过行
				const _dryApNote = Array.isArray(params.allowedPaths) && params.allowedPaths.length > 0 ? `\n[allowedPaths 预检] ${params.allowedPaths.length} 项全部存在（基准 ${taskCwd}）` : "";
				const _srcLabel = _drySource === "param" ? "param(--model)" : _drySource === "amagi.json" ? "amagi.json（全局/项目 amagi.json 角色覆盖）" : _drySource === "profile" ? "profile（profiles/<name>.json）" : _drySource === "frontmatter" ? "frontmatter（agent .md model）" : "fallback（ctx.model）";
				const _dryChainNote = _modelChain ? `\n[降级链] ${_modelChain.length} 级：${_modelChain.join(" → ")}（瞬时错误依次尝试，链尽回退 tier 降档）` : "";
				// ev-20260916-23f4a4：dryRun 回显冻结后的证据超时预算（参数已被上方准入层校验）
				const _dryEvNote = params.evidenceTimeouts !== undefined ? `\n[证据超时] test=${_evTimeouts.testMs}ms · git=${_evTimeouts.gitMs}ms · summaryGit=${_evTimeouts.summaryGitMs}ms（source=${_evTimeouts.source}${_evTimeouts.envWarning ? `；${_evTimeouts.envWarning}` : ""}）` : "";
				// ev-20260916-2dbc7f/c5ee56（S4 集成）：dryRun 附单一派发预检评估（main/worktree/none + 理由 +
				// 待核实项；observeDispatchFacts 只读有界探测 2s，不 spawn/不占 admission/不创建 worktree）。
				// AMAGI_WORKTREE_PREFLIGHT=legacy 时不评估（回旧 steer 时序）；AMAGI_WORKTREE_SUGGEST=0 时
				// 建议关闭但 dryRun 仍做无副作用解析校验（评估照常返回，仅不再影响建议通道）。
				let _dispatchEval: DispatchEvaluation | undefined;
				let _evalNote = "";
				if (worktreePreflightMode() !== "legacy") {
					try {
						const _facts = observeDispatchFacts(taskCwd);
						_dispatchEval = evaluateDispatch({
							cwd: taskCwd, task: params.task,
							explicitWorktree: params.worktree !== undefined,
							resume: false,
							exportPrompt: params.exportPrompt,
							agentReadOnly: agentCharterReadOnly(agent),
							workspaceNeeds: params.workspaceNeeds,
							mainTreeDirty: _facts.mainTreeDirty, insideLinkedWorktree: _facts.insideLinkedWorktree, isGitRepo: _facts.isGitRepo,
						});
						_evalNote = `\n[派发预检评估] recommendation: ${_dispatchEval.recommendation}${_dispatchEval.reasons.length ? `\n  理由: ${_dispatchEval.reasons.join("；")}` : ""}${_dispatchEval.uncertainty.length ? `\n  待核实: ${_dispatchEval.uncertainty.join("；")}` : ""}`;
					} catch { /* 评估失败不阻断 dryRun 解析结果（零副作用路径保持可用） */ }
				}
				return { content: [{ type: "text" as const, text: `${_fuseWarn}[dryRun] ${agent.name}(${agent.type}) → ${paramModel ?? _preResolved.spec ?? "(未解析)"} @ ${taskCwd}\n[解析来源] ${_srcLabel}${_dryApNote}${_dryChainNote}${_dryEvNote}${_evalNote}${_modelNote ? `\n${_modelNote}` : ""}` }], isError: false, dispatchEvaluation: _dispatchEval };
			}

			// E11: worktree 编排（单任务 sync/background；resume 在上游已 return 并拒绝）
			// v2 批次D：lease 唯一所有权（活跃冲突显式拒绝）+ baseCommit 基线 + 终态释放 + patch 产物
			let wtInfo: WorktreeSetup | null = null;
			let wtLease: string | undefined;
			if (params.worktree) {
				wtLease = genTaskId();
				const wt = setupWorktree(taskCwd, params.worktree, { leaseId: wtLease });
				if (!wt.ok) return { content: [{ type: "text" as const, text: wt.message || "[worktree 失败]" }], isError: true };
				wtInfo = wt;
				taskCwd = wt.path!;
			}
			// v2 批次D：worktree 终态收口——patch 产物落 artifact + 释放所有权（幂等，按任务状态记审计原因）
			const finalizeWorktree = (taskId: string, status: string, stale: boolean | undefined): string => {
				if (!wtInfo || !wtLease) return "";
				let patchRef = "";
				try {
					const artDir = registry.get(taskId)?.artifactRefs?.[0];
					if (!stale && artDir) {
						const patch = worktreePatch(wtInfo.path!, wtInfo.baseCommit);
						if (patch) { fs.writeFileSync(path.join(artDir, "worktree.patch"), patch, "utf8"); patchRef = `\n完整 patch: ${path.join(artDir, "worktree.patch")}`; }
					}
				} catch {}
				releaseWorktreeOwnership(wtInfo.root!, params.worktree!, wtLease, `task ${status}`);
				return patchRef;
			};
			const wtLineOf = (taskId: string, status: string, stale: boolean | undefined): string => {
				if (!wtInfo) return "";
				const patchRef = finalizeWorktree(taskId, status, stale);
				// ev-20260910-e3906c：复用既有（非约定路径）工作树时如实标注来源，避免被误读为扩展自建树
				const _reuseNote = wtInfo.reusedOutsideConvention ? "（既有工作树，非 .amagi-worktrees 约定路径）" : "";
				// ev-20260910-cc75b2：整仓检出回流标注（仓库根/项目根/cwd 相对路径 + 主树 workspace 向上解析污染警示）
				const _fullRepoNote = fullRepoCheckoutNote(wtInfo);
				// ev-20260916-07e44a（S4 集成）：真正终态且目录仍存在时附「树内未提交 N 个路径，未自动删除」
				// 提示（复用 inspectWorktreeRemoval；只采该 worktree 自身状态，不混入主树文件；探测失败
				// 写「状态未知」不报 0）。
				let _dirtyNote = "";
				try {
					if (wtInfo.path && fs.existsSync(wtInfo.path)) {
						const _insp = inspectWorktreeRemoval(wtInfo.root!, params.worktree!);
						if (_insp.probeError) {
							_dirtyNote = `\n[worktree 未提交] 状态未知，请检查 ${_insp.path}（探测失败：${_insp.probeError.slice(0, 120)}）——不自动删除，请人工核实。`;
						} else if (_insp.dirtyPaths.length > 0) {
							const _listed = _insp.dirtyPaths.slice(0, 20).join("、");
							_dirtyNote = `\n[worktree 未提交] 树内未提交 ${_insp.dirtyPaths.length} 个路径，未自动删除${_listed ? `（${_listed}${_insp.dirtyPaths.length > 20 ? " 等" : ""}）` : ""}——处置（回流/合并/显式丢弃）前请勿删除工作树。`;
						}
					}
				} catch { /* 探测失败不阻断终态回流（不报 0 也不报未知时静默） */ }
				return `\n\n[worktree ${wtInfo.branch}${wtInfo.reused ? " · 复用" : ""}${_reuseNote}] ${wtInfo.path}${wtInfo.baseCommit ? `（base ${wtInfo.baseCommit.slice(0, 8)}）` : ""}${_fullRepoNote ? `\n${_fullRepoNote}` : ""}${wtInfo.projectRootHint ? `\n[项目根提示] worktree 根无项目标记（package.json 等），检测到真实项目根: ${wtInfo.projectRootHint}——安装/diff/写盘以该目录为基准，不要在 worktree 根操作（会向上命中主仓 workspace 或落错位置）。` : ""}\n${worktreeSummary(wtInfo.path!, { root: wtInfo.root!, baseline: wtInfo.mainBaseline, base: wtInfo.baseCommit })}${patchRef}${_dirtyNote}\n[集成责任] Leader/luban 审查 diff（含 worktree.patch）+ 验证后合并；worktree 现场默认保留（含异常保留），确认合并完成后显式回收。`;
			};
			// ev-20260909-c00fcb②：单派发白名单任务同样注入越界处置契约（与 batch runGroupNode 同语义）；
			// ①配套：契约变更类任务书联动面预警（带 allowedPaths 边界才提示，软提示不阻断）。
			const _singleAllowed = resolveAllowedPaths(params.allowedPaths, taskCwd);
			// ev-20260917-8651a0（P3①）：reportPath 推广到单任务派发（sync/background）——静态校验/路径解析/
			// 目录拒单/白名单互锁复用 resolveNodeReportPath（与 batch 同一实现零分叉）；解析基准 taskCwd
			//（worktree 模式为树内路径，报告落树内由 patch 回流）；注入块接入任务书 + deliverablePaths
			// 接入 B1 交付物预检验收链（与 batch runGroupNode 同语义）。
			let _singleReportAbs: string | undefined;
			if (params.reportPath !== undefined) {
				if (typeof params.reportPath !== "string") return { content: [{ type: "text" as const, text: "[reportPath 无效] reportPath 必须是字符串（完整具体文件路径）。零任务启动。" }], isError: true };
				const _rpTrimmed = params.reportPath.trim();
				if (!_rpTrimmed) return { content: [{ type: "text" as const, text: "[reportPath 无效] reportPath 为空串（不注入报告路径请直接省略该参数）。零任务启动。" }], isError: true };
				if (REPORT_PATH_INVALID_RE.test(_rpTrimmed)) return { content: [{ type: "text" as const, text: `[reportPath 无效] reportPath 含未展开占位符或控制字符: ${JSON.stringify(_rpTrimmed)}——请提供完整具体文件路径（相对任务 cwd 解析，如 reports/final.md），不要 <节点名> / \${name} / {nodeName} 模板或换行/控制字符。零任务启动。` }], isError: true };
				if (/[\\/]$/.test(_rpTrimmed)) return { content: [{ type: "text" as const, text: `[reportPath 无效] reportPath 以路径分隔符结尾（目录形态）: ${JSON.stringify(_rpTrimmed)}——报告路径必须是具体文件路径，不是目录。零任务启动。` }], isError: true };
				const _rpRes = resolveNodeReportPath(_rpTrimmed, taskCwd, _singleAllowed);
				if (!_rpRes.ok) return { content: [{ type: "text" as const, text: `[reportPath 无效] ${_rpRes.message}。零任务启动。` }], isError: true };
				_singleReportAbs = _rpRes.reportPathAbs;
			}
			const _singleDeliverables = _singleReportAbs ? [_singleReportAbs] : undefined;
			const _singleSharedTree = params.sharedTree === true;
			const _wtBlock = wtInfo
				? `[amagi worktree] 你在 git worktree 中作业（分支 ${wtInfo.branch}，路径 ${wtInfo.path}）。不要 git commit——改动留在工作区，由 Leader 汇总 diff 后统一合并。${wtInfo.projectRootHint ? `\n[amagi 项目根提示] 工作树根目录没有 package.json/pnpm-workspace.yaml/go.mod/Cargo.toml/pyproject.toml 等项目标记，真实项目根: ${wtInfo.projectRootHint}——安装/build/git diff/写盘请进入该子目录并以它为路径基准；在 worktree 根操作会向上命中主仓 workspace 或落错位置。` : ""}`
				: undefined;
			// ev-20260910-cc75b2：整仓检出定位标注前置到任务书——子 Agent 任务书与 journal/registry 任务摘要（goal 截断前）
			// 都可见，修复「journal/接力包路径无业务子目录前缀 vs 真实落点有前缀」的归一化混淆。
			const _wtPreNote = wtInfo ? fullRepoCheckoutNote(wtInfo) : undefined;
			const taskText = assembleSingleTaskText(_wtPreNote ? `${_wtPreNote}\n\n${params.task!}` : params.task!, _wtBlock, _singleAllowed) + (_singleReportAbs ? singleReportPathInjectionBlock(_singleReportAbs) : "");
			const _singleLinkWarn = contractLinkageWarning(_singleAllowed && _singleAllowed.length > 0 ? [{ label: "单任务", task: params.task! }] : []);

			// ── background ──
			if (params.background) {
				// v2 批次B：并发上限改为共享准入队列（admission.ts）——超限 FIFO 排队而非整单拒绝。
				// A2（ev-20260910-d86779）：autoRetry 瞬时错误自动重派——槽位由 runBackgroundTask 的
				// onFinalize 链先 release（不在槽内 sleep），主进程定时器指数退避（backoffMs×2^n，熔断
				// Open 时不早于剩余恢复时间）后 fresh spawn 重派原任务书（新 taskId/新记录，非 resume）；
				// 预算用尽或非瞬时错误走正常完成通知（含 A3 重派建议段）。主进程崩溃时定时器随进程消失
				// （与运行中任务同语义，board/journal 有痕）。
				// ev-20260917-9746aa（P1）：声明 model 数组降级链时，通道级断连（Connection error/timeout
				// 类，isChannelDisconnectError）即使未声明 autoRetry 也自动落链下一节点——声明链即降级
				// 意图声明，同模型退避对通道级故障无意义；隐式预算 = 链剩余长度（每节点一次，链尽即停，
				// 退避 1s 起——换通道无需长退避，熔断 Open 时仍由 nextAutoRetryPlan 抬升到剩余恢复时间）；
				// 重派轮继续消费闭包内 _chainRemain（链跨重派继承）。AMAGI_AUTORETRY_OFF=1 同样一键关。
				const _chainAutoOn = _modelChain !== undefined && _modelChain.length > 1;
				// ev-20260919-226d6f：未声明 autoRetry 的单模型 background 派发也纳入隐式瞬时重试（缺省 1 轮）。
				const _arOn = (_autoRetryCfg !== undefined || _chainAutoOn || (_modelChain === undefined && _arImplicitCfg !== undefined)) && isAutoRetryEnabled();
				let _arAttempt = 0;
				let _cdUsed = false; // ev-20260916-101d8a：链尽冷却机会（每逻辑派发最多一次，与 autoRetry 计数独立不混用）
				const _quotaExhaustedProviders = new Set<string>();
				const _chainRemain: string[] = _modelChain ? _modelChain.slice(1) : []; // [0] 已作为主模型派发
				const launchBg = (modelOverride?: string, preCreatedTaskId?: string): Promise<BackgroundStart | RunResult> =>
					runBackgroundTask(agent, taskText, { cwd: taskCwd, model: modelOverride ?? paramModel, fallbackModel: fallbackSpec, onComplete: r => onComplete(r, modelOverride ?? _norm.spec ?? paramModel), command: testOpts?.testCommand, modelRegistry: ctx.modelRegistry, onStall: _onStall, description: params.description, journalGoal: params.task, trusted: resolveProjectTrusted(ctx), protectedPaths: resolveProtectedPaths(params.protectedPaths, taskCwd), allowedPaths: _singleAllowed, preCreatedTaskId });
				const onComplete = (r: any, dispatchModel?: string) => {
					snapshotForPersist(pi);
					const _rRounds = registry.get(r.taskId)?.rounds?.length || 0;
					// v2 批次B：统一收尾链（幂等 + stale 防护 + artifact/折叠/证据 固定序）
					const _rOutput = r.status === "cancelled" ? appendCancellationReason(r.output, r.errorMessage) : r.output;
					void finalizeTerminal({ taskId: r.taskId, agent: r.agent, result: { ...r, output: _rOutput }, cwd: taskCwd, evidence: { gatherEv: testOpts?.evidence, trusted: resolveProjectTrusted(ctx), baselinePorcelain: r.gitBaseline, timeouts: _evTimeouts, sharedTree: _singleSharedTree }, expectedRevision: r.dispatchRevision }).then((_fin) => {
					const _rBody = r.blocked ? (_rOutput || r.errorMessage || "") : _fin.body;
					const _wtLine = wtInfo ? wtLineOf(r.taskId, r.blocked ? "blocked" : r.status, _fin.stale) : "";
					// A2：瞬时 error 且重派预算未用尽 → journal 留痕 + 调度通知，退避后 fresh spawn 重派
					// ev-20260917-9746aa：未声明 autoRetry 但声明了降级链且错误为通道级断连 → 合成隐式链式
					// 预算（retries=链长-1，backoffMs=1s）；声明链即降级意图声明。
					// ev-20260919-226d6f：未声明且未声明链的单模型派发 → 隐式瞬时重试预算（缺省 1 轮；
					// AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关）——优先级：声明式 > 断连链式 > 隐式；声明链时
					// 不叠加隐式（链语义由链自身预算表达）。
					const _cause0 = r.errorMessage || r.spawnError;
					if (isAccountQuotaError(_cause0)) { const p = providerOfSpec(r.model || registry.get(r.taskId)?.model || paramModel || ""); if (p) _quotaExhaustedProviders.add(p); }
				for (let i = _chainRemain.length - 1; i >= 0; i--) { const n = normalizeModelSpec(_chainRemain[i], ctx.modelRegistry); if (n.ok && _quotaExhaustedProviders.has(providerOfSpec(n.spec || ""))) _chainRemain.splice(i, 1); }
					const _arEffCfg: AutoRetryConfig | undefined = _autoRetryCfg ?? ((_chainAutoOn && _chainRemain.length > 0 && (isChannelDisconnectError(_cause0) || isAccountQuotaError(_cause0)))
						? { retries: _modelChain!.length - 1, backoffMs: 1_000 }
						: ((_modelChain === undefined && implicitRetryApplicable(_cause0)) ? _arImplicitCfg : undefined));
					const _arSrcLabel = isAccountQuotaError(_cause0) ? "账号级配额耗尽，转已声明异 provider 候选" : _autoRetryCfg !== undefined ? "瞬时 provider 错误" : ((_chainAutoOn && _chainRemain.length > 0 && (isChannelDisconnectError(_cause0) || isAccountQuotaError(_cause0))) ? "通道级断连（Connection error/timeout 类），自动降级到链中下一 model" : "瞬时 provider 错误（隐式默认重试：未声明 autoRetry，仅限传输类，限流/配额走专属冷却与建议；AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 可关）");
					const _plan = _arOn && r.status === "error" && !r.blocked && !r.aborted && !registry.get(r.taskId)?.aborted && _arEffCfg !== undefined
						? nextAutoRetryPlan({ status: r.status, errorMessage: r.errorMessage, spawnError: r.spawnError, stopReason: r.stopReason, model: r.model || paramModel, attempt: _arAttempt, config: _arEffCfg, nextModel: isAccountQuotaError(r.errorMessage || r.spawnError) ? crossProviderDowngrade(r.model || paramModel, _chainRemain, ctx.modelRegistry, _quotaExhaustedProviders) : _chainRemain[0] })
						: undefined;
					if (_plan) {
						// ev-20260919-226d6f：background 重派补落盘分流（与 sync d88fcf 同语义，声明式/链式/隐式
						// 同等保护）——fresh 重跑可能覆盖半成品；有确认档工作区落盘 → 不自动重派，steer 提示
						// resume 续接，落入下方正常完成通知链（A3 建议段会附 resume 优先指引）。
						const _bgResidue = collectResidue(r.taskId, {});
						const _bgSandbox = path.join(taskTmpRoot(), path.sep);
						const _bgRealWrites = _bgResidue.confirmed.filter((p) => !p.startsWith(_bgSandbox));
						if (_bgRealWrites.length > 0) {
							if (pi?.sendUserMessage) {
								// D2（ev-20260922-727096）：resume 建议单源 renderer（legacy 面渲染）——不再维护第二份
								// task({session}) 文案；事实取 registry 当前记录（无记录时以回调事实兑底）。
								const _bgRecovery = renderRecoveryAdvice(recoveryActionOfRecord(
									registry.get(r.taskId) ?? { taskId: r.taskId, status: r.status, sessionId: r.sessionId, errorMessage: r.errorMessage, model: r.model },
								), { surfaceVersion: 1 });
								try { pi.sendUserMessage(`[后台自动重试放弃 ${r.agent}/${r.taskId.slice(0, 8)}] 中断任务已有落盘产物（${_bgRealWrites.length} 处工作区写入登记）——fresh 重派会从头重跑、可能覆盖半成品${_bgRecovery ? `；建议续接：\n${_bgRecovery}` : "；建议人工续接（详情 query_task）"}`, { deliverAs: "steer" }); } catch {}
							}
						} else {
						_arAttempt++;
						if (_plan.nextModel) { const i = _chainRemain.findIndex(c => { const n = normalizeModelSpec(c, ctx.modelRegistry); return n.ok && n.spec === _plan.nextModel; }); if (i >= 0) _chainRemain.splice(0, i + 1); }
						journalRetry({ taskId: r.taskId, n: _plan.n, backoffMs: _plan.delayMs, nextModel: _plan.nextModel });
						const _retryMsg = `[后台自动重试 ${r.agent}/${r.taskId.slice(0, 8)}] ${_arSrcLabel}，已安排第 ${_plan.n}/${_arEffCfg!.retries} 次自动重派：退避 ${Math.round(_plan.delayMs / 1000)}s 后 fresh spawn${_plan.nextModel ? `（model ${_plan.nextModel}）` : "（同模型退避重试）"}。重派完成后另行通知，无需轮询。\n[失败根因] ${(r.errorMessage || r.spawnError || "").slice(0, 200)}`;
						checkpoint(pi, r.agent, "error", r.taskId, ctx);
						if (pi?.sendUserMessage) { try { pi.sendUserMessage(_retryMsg, { deliverAs: "steer" }); } catch {} }
						// diting-quick F1：重派 launchBg 早拒（归一失败/熔断 Open/预算拒单/auth 失败/registry 异常）不进 deliverComplete 链——
						// 丢弃结果即静默停滞；F2：长退避定时器 unref（仓库惯例 terminal-push/lsp-client/mcp-client）。
						// ev-20260919-226d6f：闭包改用 _arEffCfg（隐式预算时 _autoRetryCfg 为 undefined，旧引用 TypeError）。
						const _retryTimer = setTimeout(() => {
							void launchBg(_plan.nextModel ?? dispatchModel).then((s: any) => {
								if (s?.isError && pi?.sendUserMessage) {
									try { pi.sendUserMessage(`[后台自动重试失败 ${r.agent}/${r.taskId.slice(0, 8)}] 第 ${_plan.n}/${_arEffCfg!.retries} 次重派未启动：${(s.errorMessage || s.content?.[0]?.text || "").slice(0, 200)}——请手动重派或检查模型链。`, { deliverAs: "steer" }); } catch {}
								}
							}).catch(() => {
								if (pi?.sendUserMessage) { try { pi.sendUserMessage(`[后台自动重试失败 ${r.agent}/${r.taskId.slice(0, 8)}] 重派发射异常（内部错误）——请手动重派。`, { deliverAs: "steer" }); } catch {} }
							});
						}, _plan.delayMs);
						_retryTimer.unref?.();
						return;
					}
				}
					// A3：最终 error 且瞬时类（未声明 autoRetry / 已用尽）→ 附重派建议段（reliability.buildRetryAdvice）
					let _adviceNote = "";
					if (r.status === "error" && !r.blocked && (isTransientProviderError(r.errorMessage || r.spawnError) || isAccountQuotaError(r.errorMessage || r.spawnError))) {
						const _adv = buildRetryAdvice({ taskId: r.taskId, agent: r.agent, model: r.model || paramModel, errorMessage: r.errorMessage || r.spawnError, sessionId: r.sessionId, candidates: loadFallbackModels(taskCwd), registry: ctx.modelRegistry, excludeProviders: _quotaExhaustedProviders });
						if (_adv) _adviceNote = `\n${_adv}`;
					}
					// ── ev-20260916-101d8a：链尽 429 单次冷却（background）──
					// A2 计划不再调度（未声明/预算尽）且链尽（无降级链，或 autoRetry 预算已耗尽）、429/限流类
					// 且非账号配额、零残留、未消费 → 占位 queued(cooldown) + 调度通知（替代完成通知），到期以原任务书
					// fresh 重派（不占槽等待；重派轮的 onComplete 交付唯一逻辑终态）。超上限不排队只附接管信息。
					if (r.status === "error" && !r.blocked && !r.aborted && !registry.get(r.taskId)?.aborted && !wtInfo && !_cdUsed && isChainCooldownEnabled()
						&& (!_modelChain || (_autoRetryCfg !== undefined && _arAttempt >= _autoRetryCfg.retries))) {
						const _cdCause = r.errorMessage || r.spawnError || "";
						const _cdResidue = collectResidue(r.taskId, {});
						const _cdSandbox = path.join(taskTmpRoot(), path.sep);
						const _cdRealWrites = _cdResidue.confirmed.filter((p) => !p.startsWith(_cdSandbox));
						const _cdModel = r.model || paramModel;
						const _cdPeek = providerBreakerPeek(providerOfSpec(_cdModel || ""));
						const _cdPlan = planChainExhaustedCooldown({
							providerFailure: _cdCause, lastModel: _cdModel, now: Date.now(),
							breakerUntil: _cdPeek.open && typeof _cdPeek.retryAfterMs === "number" ? Date.now() + _cdPeek.retryAfterMs : undefined,
							writesDetected: _cdRealWrites.length > 0, cancelled: false, cooldownUsed: false, retryPolicy: _autoRetryCfg,
						});
						if (_cdPlan && !_cdPlan.exceedsCap) {
							const cdTaskId = genTaskId();
							// K5a：冷却占位经统一 submit 面冻结真实 spec（清单落盘成功才建占位）——重派到期复用同 taskId
							//（launchBg 传 preCreatedTaskId → reuseQueued），旧失败记录保持历史（新 taskId 关联，验收 3）。
							// 占位建档异步（清单落盘 await）；完成通知已被本次抑制，建档失败时以短通知回落（不吞错）。
							void (async () => {
								let _cdSub: Awaited<ReturnType<typeof submitTaskKernel>> | undefined;
								try {
									_cdSub = await submitTaskKernel({
										taskId: cdTaskId, agent: agent.name, assignment: taskText, goal: params.description || params.task,
										cwd: taskCwd, model: _cdPlan.model, mode: "background", name: params.description,
										allowedPaths: _singleAllowed, queueReason: "cooldown", retryAt: _cdPlan.retryAt,
									});
								} catch { _cdSub = undefined; }
								if (!_cdSub?.ok) {
									// 建档失败：按无冷却终态回落（短通知保留失败根因；原错误完整终稿随本轮 error 结果与 journal 可查）
									if (pi?.sendUserMessage) { try { pi.sendUserMessage(`[链尽冷却失败 ${r.agent}/${cdTaskId.slice(0, 8)}] 冷却占位建档失败，按无冷却终态回落：${_cdSub ? _cdSub.message.slice(0, 160) : "提交异常"}。\n[失败根因] ${_cdCause.slice(0, 200)}`, { deliverAs: "steer" }); } catch {} }
									return;
								}
								journalDispatch({ taskId: cdTaskId, agent: agent.name, goal: params.task!, cwd: taskCwd || process.cwd(), mode: "background", model: String(_cdPlan.model ?? paramModel ?? _norm.spec ?? "") });
								// diting 审核 Minor-4：建档成功才标记冷却已消费——建档失败时冷却机会不被丢（后续轮次仍可再试）。
								_cdUsed = true;
								if (registry.get(cdTaskId)?.status !== "queued") return;
								const _cdMsg = `[链尽冷却 ${r.agent}/${r.taskId.slice(0, 8)}] ${_cdPlan.reason}。冷却期不占并发槽；到期自动以原任务书重派（新 taskId ${cdTaskId.slice(0, 8)}），完成后另行通知，无需轮询；可用 task({ cancel: "${cdTaskId}" }) 取消冷却。\n[失败根因] ${_cdCause.slice(0, 200)}`;
								checkpoint(pi, r.agent, "error", r.taskId, ctx);
								if (pi?.sendUserMessage) { try { pi.sendUserMessage(_cdMsg, { deliverAs: "steer" }); } catch {} }
								const _cdTimer = setTimeout(() => {
									// 到期复核：占位记录被取消（task cancel）则不重派（到期回调失效）
									if (registry.get(cdTaskId)?.status !== "queued") return;
									void launchBg(_cdPlan.model ?? paramModel, cdTaskId).then((s: any) => {
										if (s?.isError && registry.get(cdTaskId)?.status === "queued") {
											try { registry.patch(cdTaskId, { status: "error", errorMessage: String(s.errorMessage || s.content?.[0]?.text || "链尽冷却重派未启动").slice(0, 200) }); } catch {}
											if (pi?.sendUserMessage) { try { pi.sendUserMessage(`[链尽冷却失败 ${r.agent}/${cdTaskId.slice(0, 8)}] 冷却到期重派未启动：${String(s.errorMessage || s.content?.[0]?.text || "").slice(0, 200)}——请手动重派或检查模型链。`, { deliverAs: "steer" }); } catch {} }
										}
									}).catch(() => {
										if (registry.get(cdTaskId)?.status === "queued") {
											try { registry.patch(cdTaskId, { status: "error", errorMessage: "链尽冷却重派发射异常（内部错误）" }); } catch {}
										}
									});
								}, Math.max(0, _cdPlan.retryAt - Date.now()));
								_cdTimer.unref?.();
							})();
							return; // 不发完成通知（调度通知已替代；逻辑终态由重派轮 onComplete 交付）
						}
						if (_cdPlan?.exceedsCap) _adviceNote += `\n[链尽冷却] ${_cdPlan.reason}`;
					}
					// ev-20260910-060c3a / 316c6e：后台单任务完成通知回显实际生效模型 + 模型类报错归因候选
					// （此路径不经 runTask，模型回显需在通知点自建）。
					const _bgModelNotes = [
						effectiveModelNote(r.model, paramModel ? "param" : undefined),
						r.status === "error" && isModelProviderError(r.errorMessage || r.spawnError)
							? modelFailureAdvice({ failedSpec: r.model || paramModel, configuredSpec: resolveModel(agent, { fallbackModel: fallbackSpec, cwd: taskCwd }), registry: ctx.modelRegistry, fallbackModels: loadFallbackModels(taskCwd) })
							: undefined,
					].filter(Boolean).join("\n");
					// ev-20260917-8651a0：background 单任务 reportPath 落盘核检（轻量——不自动补跑；sync 路径由
					// runTask deliverablePaths 走完整预检催交链）。done 态缺失 → 完成通知附核检警示（诚实呈现，不静默）。
					const _rpMissing = (_singleDeliverables && r.status === "done" && !r.blocked) ? missingDeliverablePaths(_singleDeliverables, taskCwd) : [];
					const msg = `[后台子Agent完成 ${r.agent}/${r.taskId.slice(0, 8)}] 状态: ${r.blocked ? "blocked" : r.status}\n${_bgModelNotes ? `${_bgModelNotes}\n` : ""}${_rBody}${_wtLine}${r.completionAnnotation || ""}${escalationHint(_rRounds, r.blocked)}${blockedReplyDirective(r.taskId, r.blocked, r.blockReason)}${_adviceNote}${kernelViewLine(r.taskId)}${renderUsageFooter(r.taskId)}${r.interruptionReport ? `\n${r.interruptionReport}` : ""}${lightVerifyHint(_rBody)}${_rpMissing.length ? `\n[交付物预检] 报告路径未落盘：${_rpMissing.join("、")}——reportPath 声明未兑现，可 task({ session: "${r.taskId}", task: "把最终报告落盘到声明路径" }) resume 催交或人工核对` : ""}`;
					// C4-R: background 也设 checkpoint
					checkpoint(pi, r.agent, r.blocked ? "blocked" : r.status, r.taskId, ctx);
					try { sendTaskCompletion(pi, msg, r.taskId); } catch {}
					});
				};
				const start = await launchBg();
				if (wtInfo) attachWorktreeTask(wtInfo.root!, params.worktree!, wtLease!, start.taskId);
				// v2 批次B：槽位已满 → 排队 handle（FIFO 晋级后自动启动，完成自动通知；显式透出排队语义）
				if (start.status === "queued") {
					const _adm = admissionStats();
					return { content: [{ type: "text" as const, text: `${start.fuseWarning || ""}[后台排队 ${start.taskId.slice(0, 8)} ${agent.name}] 执行槽位已满（${_adm.running}/${_adm.capacity} 在跑 · ${_adm.queued} 排队${admissionPoolNote(_adm)}），已入 FIFO 队列——晋级后自动启动，完成时自动通知；期间无需轮询，可用 task({ cancel: "${start.taskId}" }) 取消。` }] };
				}
				if (start.status !== "running") {
					const failed = start as RunResult;
					return { content: [{ type: "text" as const, text: `[后台派发失败 ${failed.taskId.slice(0, 8)} ${agent.name}] ${failed.errorMessage || failed.spawnError || "启动失败"}` }], isError: true };
				}
				// v1.5.181 反轮询契约（opencode BACKGROUND_STARTED 设计）：通知自动到达，明确禁止 poll/重复劳动
				// A2（ev-20260910-d86779）：autoRetry 状态透出（启用/被 env 关闭都让 Leader 知情）。
				// ev-20260917-9746aa：声明降级链但未声明 autoRetry 时，同样透出链式断连降级已启用。
				// ev-20260919-226d6f：单模型未声明时透出隐式瞬时重试已启用（知情原则：默认动作必须可见）。
				const _arStartNote = _autoRetryCfg !== undefined
					? (isAutoRetryEnabled()
						? `\n[autoRetry] 已启用：瞬时错误至多 ${_autoRetryCfg.retries} 次自动重派（退避 ${Math.round(_autoRetryCfg.backoffMs / 1000)}s 起，指数退避；重派与结果均自动通知）`
						: "\n[autoRetry] 已被 AMAGI_AUTORETRY_OFF=1 全局关闭（本次不自动重派，瞬时错误将附重派建议）")
					: (_chainAutoOn
						? (isAutoRetryEnabled()
							? `\n[降级链] 声明链 ${_modelChain!.length} 级：通道级断连（Connection error/timeout 类）错误将自动落链下一节点（未声明 autoRetry 也会重派，链尽即停）；链尽后的其他瞬时错误按隐式/建议语义收口`
							: "\n[降级链] 已被 AMAGI_AUTORETRY_OFF=1 全局关闭（本次不自动重派，瞬时错误将附重派建议）")
						: ((_modelChain === undefined && _arImplicitCfg !== undefined && isAutoRetryEnabled())
							? `\n[autoRetry·隐式] 已启用默认瞬时重试：未声明 autoRetry 也有至多 ${_arImplicitCfg.retries} 次自动重派（仅限传输类 timeout/断连/5xx；限流/配额走专属冷却与建议。AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关闭；已有落盘产物时不 fresh 重派、改附 resume 建议）`
							: ""));
				return { content: [{ type: "text" as const, text: `${start.fuseWarning || ""}[后台派发 ${start.taskId.slice(0, 8)} ${agent.name}] 已启动${_modelNote ? `\n${_modelNote}` : ""}${_arStartNote}${_singleLinkWarn || ""}\n[后台契约] 完成后会自动通知你（含状态与结果摘要）。通知到达前：不要 sleep 或轮询进度、不要重复分派相同任务、避免编辑与该任务重叠的文件——可并行推进不相关的任务。` }] };
			}

			// ── sync ──
			// T2-7c 幂等分派：同 agent+task+cwd+model 在窗口内 → 返回既有引用，不起新进程
			// C6 fix: hash 用解析后最终 model（含 profile/fallback 解析），非 params.model 原文
			const _resolvedModel = resolveModel(agent, { paramModel, fallbackModel: fallbackSpec, cwd: taskCwd });
			const _hash = contractHash(params.agent!, taskText, taskCwd, _resolvedModel);
			const _dup = findDuplicate(_hash);
			if (_dup) {
				return { content: [{ type: "text" as const, text: `[幂等命中] 同角色+同任务+同 cwd+model 在 ${Math.round(getIdempotencyWindowMs() / 60000)}min 内已分派：${_dup.agent}#${_dup.taskId.slice(0, 8)} 状态 ${_dup.status}${_dup.output ? `\n— 既有输出摘录：${_dup.output.slice(0, 200)}` : ""}\n（如确需重跑：稍后重试 / 换任务表述 / resume 续接既有会话）` }], isError: _dup.status === "error" };
			}
			recordDispatch(_hash, "pending", agent.name);
			// ev-20260914-d88fcf（capability/P1）：sync 单任务 autoRetry——解除旧「sync 不适合定时重派」限制。
			// 瞬时 provider 错误（reliability 瞬时分类）且预算未尽时，按退避计划（nextAutoRetryPlan：
			// backoffMs×2^n，熔断 Open 不早于剩余恢复时间）fresh 重派原任务书（新 taskId/新记录，非 resume；
			// 同 batch _arRunTask 语义）。落盘分流防重放覆盖：重派决策前只读消费 task-write-log 登记经
			// collectResidue 确认档——零落盘 → 自动重派；有落盘 → 不自动重派（fresh 从头重跑可能覆盖/重复
			// 半成品），回流标注建议 resume 续接。resume 语义不变（precheck 拒 session+autoRetry）；
			// worktree 并用维持拒绝（独立树合并语义由 Leader 收口）。
			const _quotaExhaustedProviders = new Set<string>();
			const _chainRemain: string[] = _modelChain ? _modelChain.slice(1) : []; // [0] 已作为主模型跑过；autoRetry 循环与下方降级链共享消费（防链元素被两条恢复路径重复使用）
			// ev-20260919-226d6f：sync 单任务隐式瞬时重试——未声明 autoRetry 时取隐式预算（缺省 1 轮；
			// AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 关；AMAGI_AUTORETRY_OFF=1 全局关）。声明链时不叠加隐式
			//（链语义由链自身/断连降级表达）；限流类（429/配额）有专属冷却/A3 路径，隐式不接管
			//（implicitRetryApplicable 收窄到传输类，防截胡既有链尽冷却语义）。隐式重派行带「隐式」标注。
			let _syncArEff: AutoRetryConfig | undefined;
			let _syncArImplicit = false;
			const _syncArOn = (_autoRetryCfg !== undefined || _arImplicitCfg !== undefined) && isAutoRetryEnabled();
			const _syncArLines: string[] = [];
			let _syncArStopNote = "";
			let _syncArNextModel: string | undefined;
			const _runSyncTask = () => runTask(agent, taskText, { cwd: taskCwd, model: _syncArNextModel ?? paramModel, fallbackModel: fallbackSpec, signal, command: testOpts?.testCommand, modelRegistry: ctx.modelRegistry, onStall: _onStall, onUpdate: _onUpdate, description: params.description, journalGoal: params.task, trusted: resolveProjectTrusted(ctx), protectedPaths: resolveProtectedPaths(params.protectedPaths, taskCwd), allowedPaths: _singleAllowed, deliverablePaths: _singleDeliverables, evidenceTimeouts: _evTimeouts });
			let res: RunResult;
			for (;;) {
				res = await _runSyncTask();
				recordDispatchResult(_hash, res.taskId, res.blocked ? "blocked" : res.status, res.output);
				if (!_syncArOn || res.status !== "error" || res.blocked || res.aborted) break;
				const _causeIter = res.errorMessage || res.spawnError;
				if (isAccountQuotaError(_causeIter)) { const p = providerOfSpec(res.model || registry.get(res.taskId)?.model || paramModel || ""); if (p) _quotaExhaustedProviders.add(p); }
					for (let i = _chainRemain.length - 1; i >= 0; i--) { const n = normalizeModelSpec(_chainRemain[i], ctx.modelRegistry); if (n.ok && _quotaExhaustedProviders.has(providerOfSpec(n.spec || ""))) _chainRemain.splice(i, 1); }
				_syncArEff = _autoRetryCfg ?? ((_modelChain === undefined && implicitRetryApplicable(_causeIter)) ? _arImplicitCfg : undefined);
				_syncArImplicit = _autoRetryCfg === undefined && _syncArEff !== undefined;
				const _plan = nextAutoRetryPlan({ status: res.status, errorMessage: res.errorMessage, spawnError: res.spawnError, stopReason: res.stopReason, model: res.model || paramModel, attempt: _syncArLines.length, config: _syncArEff, nextModel: isAccountQuotaError(res.errorMessage || res.spawnError) ? crossProviderDowngrade(res.model || paramModel, _chainRemain, ctx.modelRegistry, _quotaExhaustedProviders) : _chainRemain[0] });
				if (!_plan) break;
				// ② 落盘分流：确认档登记（子进程 write/edit/bash 成功写盘且文件仍存在）> 0 → 不自动重派；
				// diting m-2：任务沙箱（系统 tmp amagi-task/<runId>/，守卫与契约段引导的探针/验证产物去向）不计入
				// 「落盘产物」——fresh 重派新 runId 新沙箱零覆盖风险，不应借此拦截自动重派（防削弱瞬时错误高频场景）
				const _arResidue = collectResidue(res.taskId, {});
				const _sandboxPrefix = path.join(taskTmpRoot(), path.sep);
				const _arRealWrites = _arResidue.confirmed.filter((p) => !p.startsWith(_sandboxPrefix));
				if (_arRealWrites.length > 0) {
					_syncArStopNote = `[autoRetry] 第 ${_plan.n}/${_syncArEff!.retries} 次重派未执行：中断任务 ${res.taskId.slice(0, 8)} 已有落盘产物（${_arRealWrites.length} 处工作区写入登记）——fresh 重派会从头重跑、可能覆盖既有半成品；建议 resume 续接：task({ session: "${res.taskId}", task: "接手继续完成原任务" })`;
					break;
				}
				if (signal?.aborted) break; // 退避等待前宿主已中止（cancel/超时）——不再自动重派
				if (_plan.nextModel) { const i = _chainRemain.findIndex(c => { const n = normalizeModelSpec(c, ctx.modelRegistry); return n.ok && n.spec === _plan.nextModel; }); if (i >= 0) _chainRemain.splice(0, i + 1); }
				journalRetry({ taskId: res.taskId, n: _plan.n, backoffMs: _plan.delayMs, nextModel: _plan.nextModel });
				checkpoint(pi, agent.name, "error", res.taskId, ctx);
				// 保留本轮冻结的派发策略（包括 virtual 路由），实际响应的物理模型不能替换同模型重试策略。
				_syncArNextModel = _plan.nextModel ?? _syncArNextModel ?? _norm.spec ?? paramModel;
				// diting m-3：退避等待可被宿主中止（cancel/AbortSignal）——最长 30min 退避不应因 sleep 而
				// 对 abort 无响应；中止后不重派（journalRetry/checkpoint 已发生的留痕如实保留，但回流
				// 「第 N 次重派」行只统计真正执行的重派——push 移到退避成功之后，防文案与事实不符）
				await new Promise<void>((r2) => {
					if (signal?.aborted) return r2();
					const _t2 = setTimeout(() => { signal?.removeEventListener("abort", _onAbort); r2(); }, _plan.delayMs);
					const _onAbort = () => { clearTimeout(_t2); r2(); };
					signal?.addEventListener("abort", _onAbort, { once: true });
				});
				if (signal?.aborted) break; // 退避等待期间宿主中止——不再自动重派（留痕不计数）
				_syncArLines.push(`[autoRetry${_syncArImplicit ? "·隐式" : ""}] 第 ${_plan.n}/${_syncArEff!.retries} 次重派（退避 ${Math.round(_plan.delayMs / 1000)}s${_plan.nextModel ? `，model ${_plan.nextModel}` : "，同模型 fresh"}${_syncArImplicit ? "；未声明 autoRetry 的默认瞬时重试，AMAGI_AUTORETRY_IMPLICIT_ROUNDS=0 可关" : ""}）：${res.taskId.slice(0, 8)} ${isAccountQuotaError(res.errorMessage || res.spawnError) ? "账号级配额耗尽" : "瞬时错误"}——${(res.errorMessage || res.spawnError || "").slice(0, 100)}`);
			}
			// 回流标注：有重派发生时注明本结果出自第 N 次重派（含逐次留痕；被落盘分流拦截时注明建议 resume）
			const _syncArNote = _syncArLines.length > 0
				? `[autoRetry] 本结果为第 ${_syncArLines.length} 次自动重派后的最终终态（原派发 + ${_syncArLines.length} 次自动重派${_syncArImplicit ? "；隐式默认预算，未声明 autoRetry" : ""}）。\n${_syncArLines.join("\n")}${_syncArStopNote ? `\n${_syncArStopNote}` : ""}`
				: _syncArStopNote;
		if (wtInfo) attachWorktreeTask(wtInfo.root!, params.worktree!, wtLease!, res.taskId);
			snapshotForPersist(pi);
			// T2-7b provider 失败自动降档 resume（有界）+ A1（ev-20260910-d86779）model 显式降级链：
			// 数组链 = 瞬时错误（isTransientProviderError 判定）依次 resume 链中下一 model；链尽或非瞬时
			// provider 错误 → 回退既有降档决策（账号级限额 → 跨 provider 候选链；普通 provider 错误 → tier
			// 降一档；tier 步有界一次，链尽即终态——防无限降档循环）。降档重派传 budgetScope="fresh-fallback"
			// （原派发为 fresh，预算按任务书口径——677KB 会话史误拒可用降档的实战事故，ev-20260905-fdbb89）。
			// ev-20260905-7614b1：手动接管提示（exportPrompt 通道）——仅 provider 类错误且无可用降档接管时
			// 在失败根因后追加一行（背景：fuxi/503b960c provider 不稳定 85min 零产出，主上要求复制提示词手动接管）。
			// ev-20260916-101d8a：链尽标记与最后失败轮（链尽冷却判定输入）；冷却附注（终态回流可见）。
			let _chainExhausted = false;
			let _chainLast: RunResult | undefined;
			let _chainTraceNote = "";
			let _cooldownNote = "";
			let _takeoverHint = res.status === "error" && isProviderError(res.errorMessage || res.spawnError, res.stopReason) && !res.sessionId;
			if (_takeoverHint) { _chainExhausted = true; _chainLast = res; } // 无 session 不可 resume：候选链无可用接管即链尽
			if (res.status === "error" && !res.aborted && res.sessionId && isProviderError(res.errorMessage || res.spawnError, res.stopReason)) {
				// ctx.model 依赖进程流探测（message.model），缺失时回退 registry create 时解析值
				// （task-run finalize 统计同款回退：ctx.model || rec.model）——否则降档链在无流内模型
				// 信息时静默哑火。
				let _cur: RunResult = res;
				// ev-20260914-d88fcf：_chainRemain 已提升到 sync autoRetry 循环外共享——autoRetry 已消费的链
				// 元素不再被降级链重复使用（此处直接引用外层同名变量，勿再重建）。
				const _chainTotal = _chainRemain.length;
				const _pathModels: string[] = [res.model || registry.get(res.taskId)?.model || "?"]; // 降级链路轨迹（含主模型）
				let _tierTried = false;
				let _chainStepNo = 0;
				for (;;) {
					const _cause = _cur.errorMessage || _cur.spawnError;
					const _failedModel = _cur.model || registry.get(_cur.taskId)?.model;
					if (isAccountQuotaError(_cause)) { const p = providerOfSpec(_failedModel || ""); if (p) _quotaExhaustedProviders.add(p); }
				for (let i = _chainRemain.length - 1; i >= 0; i--) { const n = normalizeModelSpec(_chainRemain[i], ctx.modelRegistry); if (n.ok && _quotaExhaustedProviders.has(providerOfSpec(n.spec || ""))) _chainRemain.splice(i, 1); }
					let _dgDec: DowngradeDecision | undefined;
					let _isChainStep = false;
					if (isAccountQuotaError(_cause) && _chainRemain.length > 0) {
						const next = crossProviderDowngrade(_failedModel, _chainRemain, ctx.modelRegistry, _quotaExhaustedProviders);
						if (next) {
							// The declaration authorizes an alternate provider; same-account entries are exhausted here.
							const index = _chainRemain.findIndex(c => { const n = normalizeModelSpec(c, ctx.modelRegistry); return n.ok && n.spec === next; });
							_chainRemain.splice(0, index + 1); _isChainStep = true; _chainStepNo++;
							_dgDec = { spec: next, crossProvider: true };
						} else { _chainRemain.length = 0; _tierTried = true; _dgDec = resolveDowngrade(_failedModel, _cause, { candidates: loadFallbackModels(taskCwd), registry: ctx.modelRegistry, excludeProviders: _quotaExhaustedProviders }); }
					} else if (isTransientProviderError(_cause) && _chainRemain.length > 0) {
						_isChainStep = true;
						_chainStepNo++;
						const _next = _chainRemain.shift()!;
						_dgDec = { spec: _next, crossProvider: providerOfSpec(_next) !== providerOfSpec(_failedModel || "") };
					} else if (!_tierTried) {
						_tierTried = true;
						_dgDec = resolveDowngrade(_failedModel, _cause, { candidates: loadFallbackModels(taskCwd), registry: ctx.modelRegistry, excludeProviders: _quotaExhaustedProviders });
					}
					if (!_dgDec) { _takeoverHint = true; _chainExhausted = true; _chainLast = _cur; break; } // 无可用降级/降档候选——链尽（冷却判定）；手动接管是兜底
					try {
						// session 传 _cur.taskId（精确命中）：链式多轮 resume 后内存中存在多条同 sessionId 记录，
						// 前缀匹配会歧义抛错；taskId 精确路由到最后一次失败轮的记录（其 sessionId 即待续会话）。
						const _dr = await runResumeTask(agent, { session: _cur.taskId, task: params.task!, model: _dgDec.spec }, { cwd: taskCwd, fallbackModel: fallbackSpec, signal, command: testOpts?.testCommand, modelRegistry: ctx.modelRegistry, onStall: _onStall, trusted: resolveProjectTrusted(ctx), budgetScope: "fresh-fallback", downgradeFromModel: _failedModel });
						if ("status" in _dr && _dr.status === "running") break; // 后台 handle：交回下方原 res 通知路径（旧语义）
						const drr = _dr as RunResult;
						_pathModels.push(_dgDec.spec);
						recordDispatchResult(_hash, drr.taskId, drr.blocked ? "blocked" : drr.status, drr.output);
						checkpoint(pi, agent.name, drr.blocked ? "blocked" : drr.status, drr.taskId, ctx);
						const _trajNote = _pathModels.length > 2 ? `\n[降级链轨迹] ${_pathModels.join("→")}（依次尝试）` : "";
						const dTag = `[task ${res.taskId.slice(0, 8)} ${agent.name} · ${_isChainStep ? `降级链 ${_chainStepNo}/${_chainTotal}` : _dgDec.crossProvider ? "跨 provider 降档（账号级限额）" : "降档"} ${_failedModel || "?"}→${_dgDec.spec} · ${drr.blocked ? "blocked" : drr.status === "done" ? "done" : "error"}]`;
						snapshotForPersist(pi);
						// ev-20260822-872c59：降档 resume 准入前拒绝 → 直接透出根因，不走旧 taskId 幂等缓存（会回放旧终稿）
						if ((drr as { rejected?: boolean }).rejected) {
							// ev-20260905（24558f/f51a49）：降档拒单早退同样附进程实况与失败残留（原任务进程可能仍在收尾/已写入半成品）。
							const _dgRec = registry.get(res.taskId);
							const _dgLive = processLivenessNote(_dgRec);
							const _dgResidue = residueNote(collectResidue(res.taskId, { cwd: _dgRec?.cwd ?? taskCwd, startedAt: _dgRec?.startedAt }));
							markExecuteReturned(res.taskId);
							return { content: [{ type: "text" as const, text: `${drr.fuseWarning || ""}${_syncArNote ? `${_syncArNote}\n` : ""}${dTag}\n\n[原失败: ${_cause}]\n\n[降档未启动] ${drr.output || drr.errorMessage || "(无根因)"}${_trajNote}\n可 task({agent,task,exportPrompt:true}) 导出任务书手动接管${_dgLive ? `\n${_dgLive}` : ""}${_dgResidue ? `\n${_dgResidue}` : ""}` }], isError: true };
						}
						// A1 链式：本步仍 provider 失败且链中还有 model → 继续走下一 model（同会话 resume）
						if (_isChainStep && drr.status === "error" && !drr.aborted && drr.sessionId && isProviderError(drr.errorMessage || drr.spawnError, drr.stopReason)) {
							_cur = drr;
							continue;
						}
						// diting 审核 Minor-1（101d8a 冷却缺口）：tier 步（非链步）429/限流失败 = 降档已用尽
						// ——与「无候选」「resume 异常」同款链尽语义，进冷却判定而非直接终态返回。仅限 429/限流
						// 信号且冷却预判可行（配额/上限/开关关等 plan undefined 时保持原早退路径——降档轨迹与
						// A3 建议段不丢）；此处不 finalize drr（与无候选路径一致）：finalize 会清理写入登记，
						// 污染冷却判定的零残留探测。
						if (!_isChainStep && drr.status === "error" && !drr.blocked && !drr.aborted && isRateLimitSignal(drr.errorMessage || drr.spawnError)) {
							const _preModel = drr.model || registry.get(drr.taskId)?.model;
							const _prePeek = providerBreakerPeek(providerOfSpec(_preModel || ""));
							const _prePlan = planChainExhaustedCooldown({
								providerFailure: drr.errorMessage || drr.spawnError || "", lastModel: _preModel, now: Date.now(),
								breakerUntil: _prePeek.open && typeof _prePeek.retryAfterMs === "number" ? Date.now() + _prePeek.retryAfterMs : undefined,
								cancelled: signal?.aborted === true, cooldownUsed: false, retryPolicy: _syncArEff,
							});
							if (_prePlan && !_prePlan.exceedsCap) { _chainExhausted = true; _chainLast = drr; break; }
						}
						// v2 批次B：统一收尾链（降档新任务同样走幂等 + stale 防护链）
						const _finD = await finalizeTerminal({ taskId: drr.taskId, agent: agent.name, result: drr, cwd: taskCwd, evidence: { gatherEv: testOpts?.evidence, trusted: resolveProjectTrusted(ctx), baselinePorcelain: drr.gitBaseline, timeouts: _evTimeouts }, expectedRevision: drr.dispatchRevision });
						const _dBody = (drr.blocked ? (drr.output || drr.errorMessage || "") : _finD.body) || "(无输出)";
						// A3（ev-20260910-d86779）：最终仍瞬时 error（链尽/tier 步失败）→ 附重派建议段（reliability.buildRetryAdvice）
						let _retryAdvice = "";
						if (drr.status === "error" && (isTransientProviderError(drr.errorMessage || drr.spawnError) || isAccountQuotaError(drr.errorMessage || drr.spawnError))) {
							const _adv = buildRetryAdvice({ taskId: drr.taskId, agent: agent.name, model: drr.model || _dgDec.spec, errorMessage: drr.errorMessage || drr.spawnError, sessionId: drr.sessionId, candidates: loadFallbackModels(taskCwd), registry: ctx.modelRegistry, excludeProviders: _quotaExhaustedProviders });
							if (_adv) _retryAdvice = `\n${_adv}`;
						}
						// Batch 3（§9.5 成本进入 footer）：降档 resume 续接链同会话——footer 两截（本轮+逻辑链合计）
						return { content: [{ type: "text" as const, text: `${drr.fuseWarning || ""}${_syncArNote ? `${_syncArNote}\n` : ""}${dTag}\n\n[原失败: ${_cause}]\n\n${_dBody}${drr.completionAnnotation || ""}${blockedReplyDirective(drr.taskId, drr.blocked, drr.blockReason)}${_trajNote}${_retryAdvice}${renderUsageFooter(drr.taskId)}${drr.interruptionReport ? `\n${drr.interruptionReport}` : ""}` }], isError: drr.isError };
					} catch { _takeoverHint = true; _chainExhausted = true; _chainLast = _cur; break; }
				}
				if (_chainExhausted && _chainLast && _pathModels.length > 1) {
					// 链尽时的结果、模型和收尾对象必须指向最后一次实际失败，不能回放首轮配额错误。
					res = _chainLast;
					_chainTraceNote = `\n[降级链轨迹] ${_pathModels.join("→")}（依次尝试；本结果为最后一次尝试）`;
					recordDispatchResult(_hash, res.taskId, res.blocked ? "blocked" : res.status, res.output);
				}
			}
			// ── ev-20260916-101d8a：链尽 429 单次冷却（sync）──
			// 前提：降档链/候选链已用尽且根因 429/限流类（非账号配额）、零残留、未取消、冷却未消费、
			// autoRetry.retries≠0。冷却期不占并发槽（失败 attempt 的槽位已在 runTask finally 归还、子进程已
			// 收口），未发任何完成通知（sync 返回体尚未构造）——资源回收与逻辑终态区分，不产生双通知。
			// 到期后以原任务书 fresh 重派最后已尝试模型（占位记录即重派记录，携带冻结证据超时；重派不再
			// 进入降档链/二次冷却——最多一次，仍失败则终态 error 附接管信息，既有 A3 段保留）。
			const _syncChainCooldown = async (failed: RunResult): Promise<RunResult | undefined> => {
				if (failed.aborted) return undefined;
				const _cause = failed.errorMessage || failed.spawnError || "";
				// 零残留前提（确认档，排除任务沙箱 amagi-task/<runId>/）——有落盘只给接管，不自动重派
				const _res = collectResidue(failed.taskId, {});
				const _sandboxPrefix = path.join(taskTmpRoot(), path.sep);
				const _realWrites = _res.confirmed.filter((p) => !p.startsWith(_sandboxPrefix));
				const _lastModel = failed.model || registry.get(failed.taskId)?.model || paramModel;
				const _peek = providerBreakerPeek(providerOfSpec(_lastModel || ""));
				const _plan: ChainExhaustedCooldownPlan | undefined = planChainExhaustedCooldown({
					providerFailure: _cause, lastModel: _lastModel, now: Date.now(),
					breakerUntil: _peek.open && typeof _peek.retryAfterMs === "number" ? Date.now() + _peek.retryAfterMs : undefined,
					writesDetected: _realWrites.length > 0, cancelled: signal?.aborted === true, cooldownUsed: false, retryPolicy: _syncArEff,
				});
				if (!_plan) return undefined;
				if (_plan.exceedsCap) { _cooldownNote = `\n[链尽冷却] ${_plan.reason}`; return undefined; }
				// 冷却占位记录（queued/cooldown，不占并发槽；看板/查询可见 retryAt）+ journal 留痕
				// K5a：经统一 submit 面冻结真实 spec（清单落盘成功才建占位；重派复用同 taskId——preCreatedTaskId）
				const cdTaskId = genTaskId();
				let _cdSub: Awaited<ReturnType<typeof submitTaskKernel>> | undefined;
				try {
					_cdSub = await submitTaskKernel({ taskId: cdTaskId, agent: agent.name, assignment: taskText, goal: params.description || params.task, cwd: taskCwd, model: _plan.model, mode: "sync", name: params.description, allowedPaths: _singleAllowed, queueReason: "cooldown", retryAt: _plan.retryAt });
				} catch { _cdSub = undefined; }
				if (!_cdSub?.ok) return undefined;
				journalDispatch({ taskId: cdTaskId, agent: agent.name, goal: params.task!, cwd: taskCwd || process.cwd(), mode: "sync", model: String(_plan.model ?? paramModel ?? _norm.spec ?? "") });
				if (registry.get(cdTaskId)?.status !== "queued") return undefined;
				// 冷却等待（可取消：宿主 abort / task cancel 使占位记录离开 queued）；登记 sync-wait 防看门狗误杀
				const _waitMs = Math.max(0, _plan.retryAt - Date.now());
				beginSyncWait();
				try {
					await new Promise<void>((resolveWait) => {
						const _cleanupWait = () => { clearInterval(_poll); clearTimeout(_t); signal?.removeEventListener("abort", _onAbort); resolveWait(); };
						const _poll = setInterval(() => { if (signal?.aborted || registry.get(cdTaskId)?.status !== "queued") _cleanupWait(); }, 150);
						const _t = setTimeout(_cleanupWait, _waitMs);
						const _onAbort = () => _cleanupWait();
						signal?.addEventListener("abort", _onAbort, { once: true });
						_poll.unref?.(); _t.unref?.();
					});
				} finally { endSyncWait(); }
				const _cdRec = registry.get(cdTaskId);
				if (signal?.aborted || !_cdRec || _cdRec.status !== "queued") {
					try { if (_cdRec?.status === "queued") registry.patch(cdTaskId, { status: "cancelled", errorMessage: "[已取消] 链尽冷却等待期间被取消（未重派）" }); } catch {}
					_cooldownNote = `\n[链尽冷却] 冷却等待被取消，未重派（原计划：${_plan.reason}）。`;
					return { taskId: cdTaskId, output: "", exitCode: -1, stderr: "", blocked: false, isError: true, status: "cancelled", timedOut: false, aborted: true, sessionName: `${agent.name}-${cdTaskId.slice(0, 8)}`, errorMessage: "任务在链尽冷却等待期间被取消", completionAnnotation: "", dispatchRevision: _cdRec?.revision ?? 0 };
				}
				// 到期且记录有效 → 以原任务书 fresh 重派（占位记录即重派记录；携带冻结证据超时；不再进入降档链）
				let rr: RunResult;
				try {
					rr = await runTask(agent, taskText, {
						cwd: taskCwd, model: _plan.model ?? paramModel, fallbackModel: fallbackSpec, signal, command: testOpts?.testCommand,
						modelRegistry: ctx.modelRegistry, onStall: _onStall, onUpdate: _onUpdate, description: params.description, journalGoal: params.task,
						trusted: resolveProjectTrusted(ctx), protectedPaths: resolveProtectedPaths(params.protectedPaths, taskCwd), allowedPaths: _singleAllowed,
						evidenceTimeouts: _evTimeouts, deliverablePaths: _singleDeliverables, preCreatedTaskId: cdTaskId,
					});
				} catch (e) {
					try { registry.patch(cdTaskId, { status: "error", errorMessage: `链尽冷却重派启动失败: ${String(e)}` }); } catch {}
					_cooldownNote = `\n[链尽冷却] 重派发射异常（${String(e)}），冷却机会已消费。`;
					return undefined;
				}
				// runTask 早拒（归一/熔断 Open fail-fast/预算/auth 失败）不建档不 spawn——占位记录收口
				if (registry.get(cdTaskId)?.status === "queued") {
					try { registry.patch(cdTaskId, { status: "error", errorMessage: rr.errorMessage || rr.spawnError || "链尽冷却重派未启动" }); } catch {}
				}
				_cooldownNote = `\n[链尽冷却] 已自动冷却重试 1 次（${_plan.reason}）——冷却机会已消费，本次结果即唯一逻辑终态。`;
				return rr;
			};
			if (res.status === "error" && !res.blocked && !wtInfo && _chainExhausted) {
				const _cd = await _syncChainCooldown(_chainLast ?? res);
				if (_cd) {
					res = _cd;
					recordDispatchResult(_hash, res.taskId, res.blocked ? "blocked" : res.status, res.output);
				}
			}
			const tag = `[task ${res.taskId.slice(0, 8)} ${agent.name} · ${res.blocked ? "blocked" : res.status === "done" ? "done" : res.status === "truncated" ? "truncated（输出截断，非失败）" : res.status === "cancelled" ? "cancelled" : "error"}]`;
			let text = res.output;
			// v2 批次B：取消态显式透出（非 error——不计失败根因，但如实告知未执行/被终止）
			if (res.status === "cancelled") text = appendCancellationReason(res.output, res.errorMessage);
			if (res.status === "error") {
				const cause = res.errorMessage || res.spawnError || (res.stopReason ? `stopReason:${res.stopReason}` : "") || `(退出码 ${res.exitCode})`;
				text = res.output ? `${res.output}\n\n[失败根因] ${cause}${res.stderr ? `\n[stderr]\n${res.stderr}` : ""}` : `[失败根因] ${cause}${res.stderr ? `\n[stderr]\n${res.stderr}` : ""}`;
				// ev-20260905-7614b1：仅 provider 类错误且无可用降档接管时追加（避免常态噪音）。
				if (_takeoverHint) text += `\n可 task({agent,task,exportPrompt:true}) 导出任务书手动接管`;
				// A3（ev-20260910-d86779）：未被降档/链接管的瞬时错误（含无 sessionId 不可 resume 的场景）→ 附重派建议段。
				if (isTransientProviderError(cause) || isAccountQuotaError(cause)) {
					const _adv = buildRetryAdvice({ taskId: res.taskId, agent: agent.name, model: res.model || registry.get(res.taskId)?.model, errorMessage: cause, sessionId: res.sessionId, candidates: loadFallbackModels(taskCwd), registry: ctx.modelRegistry, excludeProviders: _quotaExhaustedProviders });
					if (_adv) text += `\n${_adv}`;
				}
			}
			// v2 批次B：统一收尾链（幂等 + stale 防护 + artifact/折叠/证据 固定序）；
			// enriched text（含 [失败根因]/[已取消] 段）经 output 透传，保持折叠与证据基文与原语义一致。
			// ev-20260905-f51a49：失败残留须在收尾链之前采集（finalizeTerminal 消费完证据后会清理写入登记）。
			const _resFailed = res.status === "error" || res.status === "cancelled";
			const _resRec0 = registry.get(res.taskId);
			const _resResidue = _resFailed ? collectResidue(res.taskId, { cwd: _resRec0?.cwd ?? taskCwd, startedAt: _resRec0?.startedAt }) : null;
			const _fin = await finalizeTerminal({ taskId: res.taskId, agent: agent.name, result: { ...res, output: text }, cwd: taskCwd, evidence: { gatherEv: testOpts?.evidence, trusted: resolveProjectTrusted(ctx), baselinePorcelain: res.gitBaseline, timeouts: _evTimeouts, sharedTree: _singleSharedTree }, expectedRevision: res.dispatchRevision });
			text = _fin.body;
			if (wtInfo) text += wtLineOf(res.taskId, res.blocked ? "blocked" : res.status, _fin.stale);
			text += escalationHint(registry.get(res.taskId)?.rounds?.length || 0, res.blocked);
			text += blockedReplyDirective(res.taskId, res.blocked, res.blockReason);
			// v1.5.188 P1-3②：E1/E3 标注已收口到 runPiTask finalize（res.completionAnnotation）；execute 不再重复接线
			text += res.completionAnnotation || "";
			text += _chainTraceNote;
			// ev-20260916-101d8a：链尽冷却附注（已重试/被取消/超上限接管信息；终态回流可见）
			if (_cooldownNote) text += _cooldownNote;
			// ev-20260910-8fbe4e（C）：连接类中断现场报告——error+providerError 终态携带（finalize 唯一收口
			// 计算）；在 finalizeTerminal 之后追加，避免被大输出折叠截断；与 A3 重派建议段同属 error 通知增强。
			if (res.interruptionReport) text += `\n${res.interruptionReport}`;
			// ev-20260905-24558f：error 返回体附进程实况（仍在运行→query_task/cancel 止损；已退出→endedAt；
			// finalize 期间已定格的实况在 completionAnnotation 内，不重复追加）。
			if (res.isError) {
				const _resLive = processLivenessNote(registry.get(res.taskId));
				if (_resLive && !text.includes("[进程实况]")) text += `\n${_resLive}`;
			}
			// ev-20260905-f51a49：失败残留附注（N=0 不追加；轻护栏强感知，不清理不阻断）。
			{ const _resNote = residueNote(_resResidue); if (_resNote) text += `\n${_resNote}`; }
			// K5a 验收 4：sync 返回携带内核投影版本（与后台完成通知同源同版，不走桥补写）。
			text += kernelViewLine(res.taskId);
			// Batch 3（§9.5 成本进入 footer）：sync 返回 footer（读 writeStats 漏斗已聚合终值——纯 token，缺项未知）
			text += renderUsageFooter(res.taskId);
			checkpoint(pi, agent.name, res.blocked ? "blocked" : res.status, res.taskId, ctx);
			markExecuteReturned(res.taskId); // ev-20260905-24558f：登记 execute 返回时刻（迟终态回推判据①）
			// ev-20260917-8651a0（P3③）：[未自证] done 终稿的轻量核验指引（证据块已含测试 ✓ + own 归因时）
			text += lightVerifyHint(text);
			// ev-20260910-060c3a：sync 结果模型段 = runTask 回流（实际生效行 + 归一 + 偏离警示 + 模型类报错归因）
			// ∪ execute 层覆盖提示/降级链剔除（res.modelNote 已含 _norm.note，不重复拼装）。
			const _syncModelNote = [res.modelNote, _overrideNote, _chainDropNote].filter(Boolean).join("\n") || undefined;
			return { content: [{ type: "text" as const, text: `${res.fuseWarning || ""}${_syncModelNote ? `${_syncModelNote}\n\n` : ""}${_singleLinkWarn || ""}${_syncArNote ? `\n${_syncArNote}\n` : ""}${tag}\n\n${text}` }], isError: res.isError };
		},
	};
}
