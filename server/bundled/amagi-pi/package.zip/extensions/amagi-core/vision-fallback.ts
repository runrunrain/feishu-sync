/**
 * 无视觉模型的图片兜底（context 事件，每次 provider 请求前）。
 *
 * 背景：pi-ai transformMessages 对不支持 image 输入的模型，会把 user/toolResult 中的 image 块替换成
 * "(image omitted: model does not support images)" 占位——图片字节彻底丢失，模型既看不到图也拿不到文件，
 * 自然不会去调 amagi-media-understanding 识图技能。webui /api/input 的入口降级只覆盖「粘贴时探测到模型无视觉」
 * 一种路径；会话中途切换到无视觉模型（历史里的 image 块）、read 工具读到的图片、探测失败等都会漏。
 *
 * 本模块在 context 阶段统一兜底：当前模型确定无 image 输入时，把消息里的 image 块落盘（内容哈希命名，
 * 幂等去重）并替换为带路径与识图技能指引的文本块。仅改本次请求的上下文投影，不改写会话历史；
 * 替换文本由内容哈希决定，逐请求字节稳定（不破坏提示缓存）。落盘失败的图片块原样保留（交给宿主降级）。
 */
import * as crypto from "node:crypto";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

const EXT_BY_MIME: Record<string, string> = {
	"image/png": "png",
	"image/jpeg": "jpg",
	"image/gif": "gif",
	"image/webp": "webp",
};
/** 单张图落盘上限（base64 字符数）：超限不落盘，保持原块交宿主降级。 */
const MAX_IMAGE_B64_CHARS = 24 * 1024 * 1024;

export const VISION_SKILL_NAME = "amagi-media-understanding";

/** 图片已转存的文本指引（webui 入口降级与 context 兜底共用，口径一致）。 */
export function visionFallbackNote(file: string): string {
	return `[图片已保存: ${file}]（当前模型无视觉能力，无法直接看图；需要理解图片内容时，读取并按 ${VISION_SKILL_NAME} 技能把该路径交给视觉模型识别，以其输出为准，禁止猜测或声称已看过图片内容）`;
}

export function visionUploadDir(env: NodeJS.ProcessEnv = process.env): string {
	const agentDir = env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	return path.join(agentDir, "amagi", "webui-uploads");
}

/** 把 base64 图片按内容哈希写入目录（已存在则复用），返回绝对路径；失败返回 undefined。 */
export function persistImageBlock(dir: string, data: string, mimeType: string): string | undefined {
	try {
		if (typeof data !== "string" || data.length === 0 || data.length > MAX_IMAGE_B64_CHARS) return undefined;
		const buf = Buffer.from(data, "base64");
		if (buf.length === 0) return undefined;
		const hash = crypto.createHash("sha256").update(buf).digest("hex").slice(0, 16);
		const file = path.join(dir, `ctx-${hash}.${EXT_BY_MIME[mimeType] ?? "bin"}`);
		if (!fs.existsSync(file)) {
			fs.mkdirSync(dir, { recursive: true });
			fs.writeFileSync(file, buf);
		}
		return file;
	} catch { /* lint-exempt:落盘失败即保持原块，交宿主降级 */
		return undefined;
	}
}

type Block = { type?: string; data?: unknown; mimeType?: unknown; [k: string]: unknown };
type Msg = { role?: string; content?: unknown; [k: string]: unknown };

/** 纯函数：替换消息中的 image 块；无变化返回 undefined。 */
export function replaceImagesWithFiles(messages: readonly Msg[], dir: string): Msg[] | undefined {
	let changed = false;
	const next = messages.map((m): Msg => {
		if ((m?.role !== "user" && m?.role !== "toolResult") || !Array.isArray(m.content)) return m;
		if (!(m.content as Block[]).some((b) => b?.type === "image")) return m;
		let touched = false;
		const content = (m.content as Block[]).map((b): Block => {
			if (b?.type !== "image" || typeof b.data !== "string") return b;
			const file = persistImageBlock(dir, b.data, typeof b.mimeType === "string" ? b.mimeType : "");
			if (!file) return b;
			touched = true;
			return { type: "text", text: visionFallbackNote(file) };
		});
		if (!touched) return m;
		changed = true;
		return { ...m, content };
	});
	return changed ? next : undefined;
}

/** 当前模型是否确定无 image 输入（未知/无声明数组 → false，不干预）。 */
function modelLacksImages(model: unknown): boolean {
	const input = (model as { input?: unknown } | undefined)?.input;
	return Array.isArray(input) && !input.includes("image");
}

export function registerVisionFallback(pi: ExtensionAPI): void {
	pi.on("context", (event: { messages: any[] }, ctx: any): any => {
		try {
			if (!Array.isArray(event?.messages)) return undefined;
			if (!modelLacksImages(ctx?.model)) return undefined;
			const messages = replaceImagesWithFiles(event.messages, visionUploadDir());
			return messages ? { messages } : undefined;
		} catch { /* lint-exempt:兜底绝不影响主请求 */
			return undefined;
		}
	});
}
