/**
 * lsp-diagnostics.ts — LSP 环境噪音识别与抑制（ev-20261007：C/C++ 无编译数据库的 include 误报）。
 *
 * 场景（用户实测：UE/UBT 工程）：clangd 被启用（rootMarker 命中 CMakeLists.txt 等）但项目
 * 缺编译数据库（compile_commands.json / compile_flags.txt / .clangd 均无）——clangd 无法解析
 * include 路径，publishDiagnostics 大面积 `'xxx.h' file not found`（pp_file_not_found）：
 * 这是环境限制而非源码缺陷，逐条透传给模型即「全是缺 UBT 路径的误报」。
 *
 * 口径（与 ev-20260920-508e67「JS checkJs 推送面静默」先例对称的第三例）：
 *  - 抑制三条件同时成立才生效：C/C++ 源文件 ∩ clangd 服务器 ∩ 源文件目录向上
 *    （≤12 层，至 .git 边界或文件系统根）无编译数据库三件套；任一不成立不抑制
 *    （用户有编译数据库仍报 file not found = 真配置/代码问题，原样透传）。
 *  - 仅抑制 include-not-found 形态（message 前缀 `'…' file not found` 或 code `pp_file_not_found`）；
 *    其余诊断（语法/类型——clangd 本地解析仍有效）一律透传。
 *  - 拉取面（lsp diagnostics action）过滤 + 汇总披露一行原因；推送面
 *    （edit-diagnostics 注入）过滤后为空则静默（噪声代价高于漏报，拉取面可显式查全量）。
 *
 * 纯函数层：文件系统探测可注入（hasDatabase），零 pi 依赖；每文件探测结果带模块级缓存
 * （向上 stat ≤12×3 次本就轻量，缓存只为诊断刷高频路径兜底）。
 */

import * as fs from "node:fs";
import * as path from "node:path";

export interface LspDiagnosticLike {
	range?: unknown;
	message: string;
	severity?: number;
	code?: string | number;
	source?: string;
	[k: string]: unknown;
}

export interface EnvironmentNoiseFilterResult<T extends LspDiagnosticLike> {
	/** 原样透传的诊断（非噪音形态，或环境条件不成立时的全部） */
	kept: T[];
	/** 被抑制的条数（0=无抑制发生或无需披露） */
	suppressedCount: number;
	/** 环境抑制条件是否成立（C/C++ ∩ clangd ∩ 无编译数据库） */
	environmental: boolean;
	/** 拉取面披露行（suppressedCount>0 时非空）；推送面忽略 */
	note: string;
}

const CPP_FILE_RE = /\.(?:c|cc|cpp|cxx|h|hpp|hxx|m|mm)$/i;
const CLANGD_SERVER_NAME = "clangd";
/** clangd 发现逻辑：compile_flags.txt / .clangd 只查各级目录本身；compile_commands.json
 *  另查各层的 build/ 子目录（CMake 默认构建目录布局，真实世界最常见形态）。 */
const COMPILE_DB_DIR_FILES = ["compile_flags.txt", ".clangd"];
const COMPILE_DB_COMMANDS = "compile_commands.json";
const SEARCH_UP_LIMIT = 12;
/** clangd 的 file-not-found 诊断：message 形态 `'header.h' file not found`（可带后缀）。 */
const CLANG_FILE_NOT_FOUND_RE = /^'[^']+'\s+file not found/;
const CLANG_FILE_NOT_FOUND_CODE = "pp_file_not_found";

export function isCppSourceFile(file: string): boolean {
	return CPP_FILE_RE.test(file);
}

/** 目录级探测：从目录自身向上（≤12 层，至 .git 边界或文件系统根）探测三件套。 */
export function hasCppCompileDatabaseInDir(dir: string): boolean {
	return hasCppCompileDatabase(path.join(path.resolve(dir), ".amagi-probe"));
}

/** 源文件目录向上（≤12 层，至 .git 边界）探测编译数据库三件套——对齐 clangd 自身的发现逻辑。 */
export function hasCppCompileDatabase(fromAbsFile: string): boolean {
	let dir = path.dirname(path.resolve(fromAbsFile));
	for (let i = 0; i < SEARCH_UP_LIMIT; i++) {
		try {
			if (fs.existsSync(path.join(dir, COMPILE_DB_COMMANDS))) return true;
			if (fs.existsSync(path.join(dir, "build", COMPILE_DB_COMMANDS))) return true;
			for (const name of COMPILE_DB_DIR_FILES) {
				if (fs.existsSync(path.join(dir, name))) return true;
			}
			if (fs.existsSync(path.join(dir, ".git"))) return false; // 仓库根仍未发现：越界即停
		} catch { /* 探测失败按不存在处理 */ }
		const parent = path.dirname(dir);
		if (parent === dir) return false;
		dir = parent;
	}
	return false;
}

function isIncludeNotFoundDiagnostic(d: LspDiagnosticLike): boolean {
	if (d.code === CLANG_FILE_NOT_FOUND_CODE) return true;
	return CLANG_FILE_NOT_FOUND_RE.test(d.message);
}

/**
 * 环境噪音过滤（拉取面/推送面共用）。
 * @param serverName LSP 服务器名（池内 definition.name，如 "clangd"）
 * @param absFile 绝对路径源文件
 * @param diags 待过滤诊断
 * @param opts.hasDatabase 探测注入（测试）；缺省走真实文件系统
 */
export function filterEnvironmentNoise<T extends LspDiagnosticLike>(
	serverName: string,
	absFile: string,
	diags: readonly T[],
	opts?: { hasDatabase?: (absFile: string) => boolean }
): EnvironmentNoiseFilterResult<T> {
	const environmental =
		serverName === CLANGD_SERVER_NAME &&
		isCppSourceFile(absFile) &&
		!(opts?.hasDatabase ?? hasCppCompileDatabase)(absFile);
	if (!environmental || diags.length === 0) {
		return { kept: [...diags], suppressedCount: 0, environmental, note: "" };
	}
	const kept: T[] = [];
	let suppressedCount = 0;
	for (const d of diags) {
		if (isIncludeNotFoundDiagnostic(d)) suppressedCount++;
		else kept.push(d);
	}
	const note =
		suppressedCount > 0
			? `\n[环境降噪] 已抑制 ${suppressedCount} 条 include 未找到类诊断：项目未发现编译数据库（compile_commands.json / compile_flags.txt / .clangd 三者均无，自 ${path.basename(absFile)} 目录向上已探测）——clangd 无法解析 include 路径，属环境限制而非源码缺陷（UE/UBT 等工程典型）。生成编译数据库或配置 .clangd（CompileFlags.Add）后即可恢复透传。`
			: "";
	return { kept, suppressedCount, environmental, note };
}
