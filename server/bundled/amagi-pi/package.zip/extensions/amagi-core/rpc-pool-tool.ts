/**
 * rpc-pool-tool.ts — T2-9 RPC 进程池接线适配器（W1-R1/W2-R1/W4-R1 修复版）。
 *
 * 形态裁定：独立工具 `rpc_task`（非 task mode）。
 *
 * W1-R1/W1-R2：WAL/session 目录按 cwd 哈希 + controller 实例 UUID 二级隔离，
 *   recover 通过 adopted pool 接管 stale sibling，而不是只报告兄弟目录。
 *   裁定理由：hongjun WAL 排他锁（controller.lock）防 split-brain 多写；
 *   同项目多会话不应共享 WAL（否则需分布式锁协议，超出 hongjun 设计）。
 *   会话级子目录（<cwd-hash>/<instance-id>/）是最简安全形态：
 *   - 跨项目隔离（不同 cwd-hash）
 *   - 同项目并发会话隔离（不同 instance-id，无锁竞争）
 *   - 项目身份保留（cwd-hash 层级可供 recover 扫描）
 *   recover action 扫描同 cwd-hash 下兄弟目录：活锁拒绝、死锁由 core stale
 *   lease 路径接管，并继续使用该实例原 session/WAL 目录。
 *
 * W2-R1 修复：answer action 使用类型化答复契约（value/confirmed/cancelled 三字段），
 *   非布尔字符串化；按 request method 校验答复类型。
 *
 * W4-R1 修复：no-op shutdown（pool 为空）不持久化 shutdownPromise；
 *   仅在 pool 存在时设置 shutdownPromise，finally 清理用局部变量引用。
 *
 * K6（amagi-pi v2，方案 §8.1-K6/§3.1/§3.4）：RPC 任务适配对齐共同控制端口。
 *  - 状态迁移改走 K3 内核命令（N1 单写者）：晋级=grant-start（launchIntent 先于 spawn 持久化）、
 *    退出采纳/失败=observe(exited)、session=observe(session)、取消链由 task-service.cancelTask
 *    走内核 cancel 命令（先 revision+1 撤销采纳资格）。池内部 worker 状态（WAL、空闲复用、
 *    per-worker 会话）保持私有，不进 registry/内核。
 *  - 桥残留点（内核命令面不承载，见 K6-report）：记录建档 registry.create（mode/goal 等
 *    legacy 展示字段，桥→register/grant-start 命令）与 result/errorMessage/sessionId/queueMs
 *    字段补写（回执面属 K7）；执行结果文本不进内核命令面。
 *  - WAL 恢复先对账不自动 continuation（N9）：契约存储有记录的在途任务经内核 reconcile 命令标
 *    needs-reconciliation，不自动接管（WAL 原样保留）；无契约记录的遗留任务维持旧恢复器行为。
 *  - 不支持能力返回 unsupported：adjust 对不在池内/worker 不可复用的任务明确报错，不隐式建池伪成功。
 */

import { newRuntimeEventAccumulator, runtimeObservation } from "./runtime-fingerprint.ts";
import * as crypto from "node:crypto";
import * as os from "node:os";
import * as path from "node:path";
import * as fs from "node:fs";
import { Type } from "typebox";
import { StringEnum } from "@earendil-works/pi-ai";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { RpcPool, createUiAskLeaderBridge, type RpcPoolOptions, type RpcTaskResult, type RpcLeaderAnswer, type RpcReconcileResult, type RpcRecoveryDecision, inspectRpcWal } from "./rpc-pool.ts";
// B7（十月迭代 §5.4）：WebUI 远程对话框应答面数据源（controller 汇聚 primary+adopted 两路 broker）。
import type { RpcDialogBroker } from "./rpc-extension-ui.ts";
import { registry } from "./task-registry.ts";
import { tryOccupy, waitForGrant, release as releaseAdmission, admissionStats, admissionPoolNote } from "./admission.ts";
import { finalizeTerminal } from "./finalizer.ts";
import { registerCancelInterceptor, getTaskKernel } from "./task-service.ts";
import { createTaskStore } from "./task-store.ts";
import type { ExecutionCapabilities } from "./execution-port.ts";
import { looksLikeWatchCommand } from "./watch-probe.ts";
// pi 1.3.0 基线适配（P1a/I1）：rpc_task params.model 与其它派发口同源归一——裸模型名在多 provider
// 同 id 环境下 pi 1.2.0 按目录序静默取首、1.3.0 无凭据/多凭据时硬失败；amagi 侧先归一为全限定
// provider/model（歧义列候选清单拒单），与 task/resume/background 各口 normalizeModelSpec 同口径。
import { normalizeModelSpec, type ModelRegistryLike } from "./model-resolver.ts";

// ─────────────────────────────────────────────────────────────────────────────
// v2 批次D：RPC adapter 对齐主控制面（feature flag: AMAGI_RPC_REGISTRY_OFF=1 一键回退）
//  - 主 TaskRegistry：start 即登记（backend:"rpc"，queued/running 与 JSON 路径同状态机），
//    面板/看板/trace 观测对等；
//  - 共享 admission 为唯一产品级准入：start 前 tryOccupy，超容量 FIFO 排队（晋级后异步
//    启动并返回排队 handle）；RPC 池内 FIFO 只承担 worker transport 等待，不做第二份产品计数；
//  - 统一 finalizer：completion 到达 → finalizeTerminal（幂等 + expectedRevision stale
//    防护）→ releaseAdmission 恰好一次（取消竞态时 revision 已 bump → stale 跳写，槽位仍归还）；
//  - 取消对等：task({cancel}) → cancelTask 置 cancelled（revision+1）→ 取消拦截器送达
//    pool.cancelTask（clear_queue 排空 + abort RPC，8月迭代 pi-0.84 配合 P2⑤），
//    不遗留无人管理的 RPC worker 任务。
// ─────────────────────────────────────────────────────────────────────────────

/** 批次D adapter 接线开关（默认开；AMAGI_RPC_REGISTRY_OFF=1 回退为独立 rpc_task 老路径）。 */
function rpcAdapterOn(): boolean {
	return process.env.AMAGI_RPC_REGISTRY_OFF !== "1" && process.env.AMAGI_RPC_REGISTRY_OFF !== "true";
}

const trackedCompletions = new Set<string>();

/** K6：单任务观察序号（kernel observe 的 observationSeq 在单 backendRunId 内递增；
 *  started(0)→session(1)→exited(2+)，取消迟到退出取下一个更高序号）。 */
const rpcObservationSeq = new Map<string, number>();
function nextObservationSeq(taskId: string): number {
	const next = (rpcObservationSeq.get(taskId) ?? -1) + 1;
	rpcObservationSeq.set(taskId, next);
	return next;
}
function rpcBackendRunId(taskId: string): string {
	return `rpc:${taskId}`;
}

/** 测试隔离用复位。 */
export function resetRpcAdapterForTest(): void {
	trackedCompletions.clear();
	rpcObservationSeq.clear();
}

// ── K6：内核命令消费（真实命令；桥仅兜底，残留点见模块头/K6-report） ───────────

/** 启动观察（started[+session]）：后端只报告事实——worker 进程已存活（processState=alive、
 *  首启动 startedAt 定格）；非活跃/已取消任务不回流（观察丢失可接受）。 */
function kernelObserveLaunch(taskId: string, sessionId: string | undefined): void {
	if (!rpcAdapterOn()) return;
	try {
		const kernel = getTaskKernel();
		const view = kernel.get(taskId);
		if (!view || (view.execution !== "running" && view.execution !== "queued")) return;
		const key = { ownerId: view.ownerId, taskId, revision: view.revision };
		const backendRunId = rpcBackendRunId(taskId);
		void kernel.apply({
			type: "observe",
			key,
			backendRunId,
			observationSeq: nextObservationSeq(taskId),
			event: { kind: "started", at: Date.now() },
		}).catch(() => { /* 观察回流失败：WAL/session 仍是证据源 */ });
		if (sessionId) {
			void kernel.apply({
				type: "observe",
				key,
				backendRunId,
				observationSeq: nextObservationSeq(taskId),
				event: { kind: "session", sessionId },
			}).catch(() => { /* 同上 */ });
		}
	} catch { /* 内核不可用：非状态性事实，静默丢弃 */ }
}

/** 退出观察双路（N3/N4）：
 *  - current 为 running/queued：observe(exited)——exitCode 0→done / 非 0→error 由内核语义映射，
 *    结果采纳资格由内核 revision 栅栏把关；
 *  - current 已 cancelled：迟到结果不采纳（工具侧核对 current）——以取消前 revision 报告迟到退出，
 *    走内核 §3.4 例外：仅清理 processState/exitedAt 观察事实，不改 cancelled、不接受结果。 */
async function kernelObserveExit(taskId: string, exitCode: number | null): Promise<void> {
	if (!rpcAdapterOn()) return;
	try {
		const kernel = getTaskKernel();
		const view = kernel.get(taskId);
		if (!view) return;
		if (view.execution === "running" || view.execution === "queued") {
			await kernel.apply({
				type: "observe",
				key: { ownerId: view.ownerId, taskId, revision: view.revision },
				backendRunId: rpcBackendRunId(taskId),
				observationSeq: nextObservationSeq(taskId),
				event: { kind: "exited", exitCode, at: Date.now() },
			}).catch(() => { /* 内核栅栏拒改：以内核为权威（取消竞态下正是期望行为） */ });
			return;
		}
		if (view.execution === "cancelled" && view.run.processState !== "not-started") {
			// 从未启动的取消（FIFO 等待中取消/晋级前取消）无物理退出可确认，不伪造 exited 观察
			await kernel.apply({
				type: "observe",
				key: { ownerId: view.ownerId, taskId, revision: view.revision - 1 },
				backendRunId: rpcBackendRunId(taskId),
				observationSeq: nextObservationSeq(taskId),
				event: { kind: "exited", exitCode, at: Date.now() },
			}).catch(() => { /* 迟到退出观察被拒：物理退出事实以 WAL/进程观察为准 */ });
		}
	} catch { /* 内核观察回流失败：不影响槽位归还（N4）与收尾链 */ }
}

/** completion → 统一收尾链 + 槽位归还（恰好一次；stale 时 finalizer 跳写但槽位照还）。 */
function trackCompletion(pool: RpcPool, taskId: string, cwd: string): void {
	if (trackedCompletions.has(taskId)) return;
	trackedCompletions.add(taskId);
	const revBefore = registry.get(taskId)?.revision ?? 0;
	pool.waitForTask(taskId).then(async (result) => {
		const cancelledMsg = result.state === "error" && /^cancelled:/.test(result.error || "");
		const status = cancelledMsg ? "cancelled" : result.state === "settled" ? "done" : "error";
		// K6：终态迁移走内核 observe(exited)（取消竞态下内核 revision 栅栏拒改 cancelled，
		// 工具侧核对 current 由 kernelObserveExit 承担）；result/errorMessage/sessionId 为 legacy
		// 字段面，须在内核迁移置终态前写入（registry 对终态记录拒绝任何 patch），桥受控字段写入兜底。
		// 槽位归还只在真实退出/隔离后恰好一次（N4）。
		if (rpcAdapterOn()) {
			try {
				const rec0 = registry.get(taskId);
				if (rec0 && (rec0.status === "running" || rec0.status === "queued")) {
					registry.patch(taskId, { runtimeObservation: result.runtimeObservation, result: result.lastAssistantText || undefined, errorMessage: result.error, ...(result.sessionId ? { sessionId: result.sessionId } : {}) });
				}
			} catch {}
			await kernelObserveExit(taskId, status === "done" ? 0 : status === "cancelled" ? null : 1);
		} else {
			try {
				const rec0 = registry.get(taskId);
				if (rec0 && (rec0.status === "running" || rec0.status === "queued")) {
					registry.patch(taskId, { runtimeObservation: result.runtimeObservation, status, endedAt: Date.now(), result: result.lastAssistantText || undefined, errorMessage: result.error, sessionId: result.sessionId });
				}
			} catch {}
		}
		const rr = { runtimeObservation: result.runtimeObservation, taskId, agent: "rpc", status, output: result.lastAssistantText || "", errorMessage: result.error, sessionId: result.sessionId, blocked: false, isError: status === "error" };
		return finalizeTerminal({ taskId, agent: "rpc", result: rr, cwd, expectedRevision: revBefore }).finally(() => releaseAdmission(taskId));
	}).catch(() => { try { releaseAdmission(taskId); } catch {} });
}

/** startTask 失败/取消竞态收口：finalizer 链未挂接时这里是唯一槽位归还点（registry 已被
 *  cancelTask 置 cancelled 的情形同样归还——cancel 不直接 release 的契约仅限 JSON finalize 链）。 */
function rpcStartFailed(taskId: string, e: unknown): void {
	const message = `[rpc 启动失败] ${String(e instanceof Error ? e.message : e).slice(0, 300)}`;
	if (rpcAdapterOn()) {
		// K6：启动失败=后端退出观察（exited 非零→error 由内核映射；取消竞态下内核拒改 cancelled）；
		// errorMessage 为 legacy 字段面，须在内核迁移置终态前写入（registry 终态拒绝任何 patch）。
		// 观察回流后立即归还槽位（未 spawn 成功即无存活进程）。
		void (async () => {
			try {
				const rec = registry.get(taskId);
				if (rec && rec.status !== "cancelled") registry.patch(taskId, { errorMessage: message });
			} catch {}
			await kernelObserveExit(taskId, 1);
		})();
	} else {
		const rec = registry.get(taskId);
		if (rec && rec.status !== "cancelled" && rec.status !== "error") {
			try { registry.patch(taskId, { status: "error", errorMessage: message, endedAt: Date.now() }); } catch {}
		}
	}
	try { releaseAdmission(taskId); } catch {}
}

const RPC_DATA_ROOT = path.join(os.homedir(), ".pi", "agent", "data");

// ── ev-20260903-c1521b②：watch 型常驻任务软感知 ─────────────────────────────
// 实战：rpc_task 启动 pnpm dev 后 worker 持锁挂起不监听，改走 launchctl 又遇三连环境坑
// （绝对路径/PATH/服务目录），试错 6-7 轮。根因是 rpc 池要求任务有完成态（result 等待完成
// 句柄），watch/dev 型 worker 永不退出。2026-09-04 起探测实现收敛到 watch-probe.ts
// looksLikeWatchCommand（ev-20260904-0678c1 误报根治：词边界 + /dev/* 剥离 + 只读白名单
// 短路；任务文本含 node_modules/"watch" 字面量/设备路径不再误报），与 bash-override 同源。

/** watch 型常驻提示段（软感知：仅附在 start 返回体，不阻断启动）。 */
const WATCH_TASK_ADVISORY = "⚠ 疑似 watch 型常驻任务——rpc 池模式要求任务有完成态（result 等待完成句柄），watch/dev 型 worker 永不退出会导致 result 挂起。常驻服务建议 launchctl（macOS，注意绝对路径与 PATH 环境）/ systemd（Linux）或 nohup 独立后台 + 日志轮询；rpc_task 适合一次性/可完成的任务";

/** W1-R1: 按 cwd 哈希 + controller 实例 UUID 二级隔离 WAL/session 目录。 */
function projectHash(cwd: string): string {
	return crypto.createHash("sha256").update(path.resolve(cwd)).digest("hex").slice(0, 16);
}

function rpcDataDir(dataRoot: string, kind: "rpc-wal" | "rpc-sessions", cwd: string, instanceId: string): string {
	return path.join(dataRoot, kind, projectHash(cwd), instanceId);
}

/** W1-R2: 只接受真实目录，不跟随 symlink 扫描 project hash 外数据。 */
function siblingWalDirs(dataRoot: string, cwd: string): string[] {
	const parent = path.join(dataRoot, "rpc-wal", projectHash(cwd));
	try {
		return fs.readdirSync(parent, { withFileTypes: true })
			.filter((entry) => entry.isDirectory() && !entry.isSymbolicLink())
			.map((entry) => path.join(parent, entry.name))
			.sort();
	} catch { return []; }
}

// ── K6（N9）：WAL 恢复对账门 ─────────────────────────────────────────────────

/** 契约存储有记录的任务 = 新契约任务（K6 起 RPC 派发经内核 register）：恢复时不自动接管，
 *  经内核 reconcile 命令标 needs-reconciliation（不猜成功不置 done，证据缺口保留）；
 *  无契约记录（store-not-found）= v2 前遗留任务，旧恢复器行为保留；契约存储不可读/门故障
 *  = fail-closed 不自动接管（N9：不确定不自动重启）。 */
const contractRecoveryGate = async (taskId: string): Promise<RpcRecoveryDecision> => {
	if (!rpcAdapterOn()) return { auto: true };
	try {
		const loaded = await createTaskStore().load(taskId);
		if (!loaded.ok) {
			if (loaded.error.code === "store-not-found") return { auto: true };
			return { auto: false, reason: `K6_N9_NEEDS_RECONCILIATION: 契约存储不可读（${loaded.error.code}）——不自动接管，WAL/session 保留供对账` };
		}
		const kernel = getTaskKernel();
		const inMemory = kernel.get(taskId);
		const revision = inMemory ? inMemory.revision : loaded.value.run.revision;
		const r = await kernel.apply({
			type: "reconcile",
			key: { ownerId: loaded.value.run.ownerId, taskId, revision },
			facts: [{ code: "rpc-wal-inflight", detail: `重启后 WAL 含在途任务（execution=${loaded.value.run.execution}, processState=${loaded.value.run.processState}）——不确定执行不自动重启（N9）` }],
			disposition: "needs-reconciliation",
		});
		if (!r.ok) {
			return { auto: false, reason: `K6_N9_NEEDS_RECONCILIATION: 内核 reconcile 拒绝（${r.error.code}: ${r.error.message.slice(0, 80)}）——不自动接管，WAL/session 保留供对账` };
		}
		return { auto: false, reason: "K6_N9_NEEDS_RECONCILIATION: 新契约任务已标 needs-reconciliation（不自动 continuation/重放；WAL 与 session 保留供对账，重新派发走新 taskId）" };
	} catch (e) {
		return { auto: false, reason: `K6_N9_NEEDS_RECONCILIATION: 对账门故障（${String(e instanceof Error ? e.message : e).slice(0, 80)}）——fail-closed 不自动接管` };
	}
};

// ── Controller（lazy init + shutdown 终结 pending + 实例隔离） ────────────────

export interface RpcPoolController {
	getPool(options: { cwd: string; model?: string; mode?: string; ui?: any; pi?: ExtensionAPI }): RpcPool;
	findTaskPool(taskId: string): RpcPool | undefined;
	snapshots(): Array<{ instanceId: string; role: "primary" | "adopted"; snapshot: ReturnType<RpcPool["snapshot"]> }>;
	answerLeaderQuestion(requestId: string, answer: RpcLeaderAnswer): boolean;
	/** B7（十月迭代 §5.4）：活跃对话框 pending 表汇聚（primary + adopted；WebUI rpc dialog adapter
	 *  的数据源——订阅/列表/应答均经 broker，不另建第二份状态）。 */
	dialogBrokers(): RpcDialogBroker[];
	recover(options: { cwd: string; model?: string; mode?: string; ui?: any; pi?: ExtensionAPI }): Promise<RpcInstanceRecoveryReport[]>;
	/** K6：后端能力声明（共同控制端口/§3.3 ExecutionPort 口径）——resume 不由池提供
	 *  （续接走 task-resume 新 taskId 语义），adjust 支持（steer/idle prompt）。 */
	capabilities(): Readonly<ExecutionCapabilities>;
	readonly initialized: boolean;
	/** 当前 controller 实例 ID（W1-R1 隔离用）。 */
	readonly instanceId: string;
	shutdown(): Promise<void>;
}

export interface RpcPoolControllerConfig {
	/** 测试/嵌入环境覆盖；生产默认 ~/.pi/agent/data。 */
	dataRoot?: string;
	/** worker 命令等底层选项；cwd/model/WAL/session 目录仍由 controller 强制计算。 */
	poolOptions?: Omit<RpcPoolOptions, "cwd" | "model" | "walDir" | "sessionDir"> & { model?: string };
}

export interface RpcInstanceRecoveryReport {
	instanceId: string;
	walDir: string;
	status: "recovered" | "manual" | "locked" | "corrupt" | "empty";
	generation?: number;
	recoverable: number;
	manual: number;
	results: RpcReconcileResult[];
	reason?: string;
}

export function createRpcPoolController(config: RpcPoolControllerConfig = {}): RpcPoolController {
	// W1-R1: 每个 controller 实例分配唯一 ID，用于 WAL/session 目录二级隔离
	const instanceId = crypto.randomUUID().slice(0, 8);
	const dataRoot = path.resolve(config.dataRoot || RPC_DATA_ROOT);
	let pool: RpcPool | undefined;
	const adoptedPools = new Map<string, RpcPool>();
	const taskPools = new Map<string, RpcPool>();
	let shutdownPromise: Promise<void> | undefined;

	const forceSettleAll = (p: RpcPool): void => {
		for (const task of ((p as any).tasks as Map<string, any>).values()) {
			if (!task.deferred?.settled) {
				const result: RpcTaskResult = {
					runtimeObservation: runtimeObservation(task.runtimeEvents ?? newRuntimeEventAccumulator()),
					taskId: task.taskId,
					workerId: task.worker?.id || task.lastWorkerId || "unknown",
					sessionId: task.sessionId,
					sessionFile: task.sessionFile,
					state: "error",
					recovered: task.recovered,
					lastAssistantText: task.lastAssistantText,
					entries: task.entries || [],
					leafId: task.leafId,
					error: "RPC pool shutdown: task interrupted",
				};
				task.deferred?.resolve?.(result);
			}
		}
	};

	const makePool = (options: { cwd: string; model?: string; mode?: string; ui?: any; pi?: ExtensionAPI }, targetInstanceId: string): RpcPool => {
		const poolOptions: RpcPoolOptions = {
			...config.poolOptions,
			cwd: options.cwd,
			model: options.model || config.poolOptions?.model,
			sessionDir: rpcDataDir(dataRoot, "rpc-sessions", options.cwd, targetInstanceId),
			walDir: rpcDataDir(dataRoot, "rpc-wal", options.cwd, targetInstanceId),
			autoRecover: config.poolOptions?.autoRecover ?? true,
			// K6（N9）：WAL 恢复对账门——新契约任务不自动接管（策略见 contractRecoveryGate）
			...(rpcAdapterOn() ? { recoveryGate: contractRecoveryGate } : {}),
		};
		const isTui = options.mode === "tui" || (!options.mode && options.ui && typeof options.ui.select === "function" && typeof options.ui.input === "function");
		if (isTui && options.ui) {
			poolOptions.askLeader = createUiAskLeaderBridge(options.ui);
		} else if (options.pi) {
			poolOptions.notifyLeader = (q) => {
				try {
					// v1.5.244 注入安全：{triggerTurn:false} 会原位插入，流式中可能落在 tool 配对中间（严格后端 400）；
					// steer 两态（流式队列/非流式末尾）都在完整配对之后，且提问当轮可达。
					options.pi!.sendMessage!({
						customType: "amagi:rpc-leader-question",
						content: `[RPC 子 Agent 提问] ${q.title || q.method}${q.message ? ": " + q.message : ""}`,
						details: { requestId: q.requestId, taskId: q.taskId, method: q.method, options: q.options, placeholder: q.placeholder },
						display: false,
					}, { deliverAs: "steer" });
				} catch {}
			};
		}
		return new RpcPool(poolOptions);
	};

	const findTaskPool = (taskId: string): RpcPool | undefined => {
		const indexed = taskPools.get(taskId);
		if (indexed?.getTaskState(taskId) !== undefined) return indexed;
		if (pool?.getTaskState(taskId) !== undefined) return pool;
		for (const adopted of adoptedPools.values()) if (adopted.getTaskState(taskId) !== undefined) return adopted;
		return undefined;
	};

	// v2 批次D：取消对等——task({cancel}) 命中 RPC 任务时送达 pool.cancelTask
	// （clear_queue 排空 + abort RPC，8月迭代 pi-0.84 配合 P2⑤），
	// 不遗留无人管理的 RPC worker 任务（registry cancelled 终态由 task-service 唯一书写）。
	registerCancelInterceptor((taskId) => {
		const p = findTaskPool(taskId);
		if (!p) return false;
		void p.cancelTask(taskId, "task cancel 级联").catch(() => {});
		return true;
	});

	const controller: RpcPoolController = {
		instanceId,
		getPool(options) {
			if (pool) return pool;
			pool = makePool(options, instanceId);
			return pool;
		},
		findTaskPool,
		snapshots() {
			const result: Array<{ instanceId: string; role: "primary" | "adopted"; snapshot: ReturnType<RpcPool["snapshot"]> }> = [];
			if (pool) result.push({ instanceId, role: "primary", snapshot: pool.snapshot() });
			for (const [adoptedId, adopted] of adoptedPools) result.push({ instanceId: adoptedId, role: "adopted", snapshot: adopted.snapshot() });
			return result;
		},
		answerLeaderQuestion(requestId, answer) {
			if (pool?.answerLeaderQuestion(requestId, answer)) return true;
			for (const adopted of adoptedPools.values()) if (adopted.answerLeaderQuestion(requestId, answer)) return true;
			return false;
		},
		dialogBrokers() {
			// 池未初始化时空列表（WebUI 面板显示无待答对话框，不伪数据）。
			const brokers: RpcDialogBroker[] = [];
			if (pool) brokers.push(pool.dialogs);
			for (const adopted of adoptedPools.values()) brokers.push(adopted.dialogs);
			return brokers;
		},
		capabilities(): Readonly<ExecutionCapabilities> {
			// K6：共同控制端口能力声明——不支持的能力（resume）由工具面返回 unsupported
			return { backend: "rpc", resume: false, adjust: true };
		},
		async recover(options) {
			const reports: RpcInstanceRecoveryReport[] = [];
			const scans: Array<{ instanceId: string; walDir: string; recoverable: ReturnType<typeof inspectRpcWal>["recoverable"]; manual: ReturnType<typeof inspectRpcWal>["manual"] }> = [];

			// primary 若已存在，只恢复自己的 generation；不再竞争自己的活锁。
			if (pool && pool.snapshot().tasks.length === 0) {
				const inspection = inspectRpcWal(pool.options.walDir);
				const results = await pool.recoverPendingFromWal();
				for (const result of results) if (pool.getTaskState(result.taskId) !== undefined) taskPools.set(result.taskId, pool);
				if (inspection.recoverable.length || inspection.manual.length || results.length) reports.push({
					instanceId, walDir: pool.options.walDir, status: results.some((item) => item.status !== "manual" && item.status !== "failed") ? "recovered" : "manual",
					generation: pool.snapshot().generation, recoverable: inspection.recoverable.length, manual: inspection.manual.length, results,
				});
			}

			// 第一阶段只读扫描。真正接管仍必须在第二阶段竞争原 instance 的 lease。
			for (const walDir of siblingWalDirs(dataRoot, options.cwd)) {
				const siblingId = path.basename(walDir);
				if (siblingId === instanceId || adoptedPools.has(siblingId)) continue;
				try {
					const inspection = inspectRpcWal(walDir);
					if (inspection.recoverable.length || inspection.manual.length) scans.push({ instanceId: siblingId, walDir, recoverable: inspection.recoverable, manual: inspection.manual });
				} catch (error) {
					reports.push({ instanceId: siblingId, walDir, status: "corrupt", recoverable: 0, manual: 0, results: [], reason: error instanceof Error ? error.message : String(error) });
				}
			}

			// instance generation 彼此独立；跨 instance taskId 冲突没有可比较全序，保守拒绝整目录。
			const owners = new Map<string, string[]>();
			for (const scan of scans) for (const task of scan.recoverable) {
				const ids = owners.get(task.taskId) || [];
				ids.push(scan.instanceId); owners.set(task.taskId, ids);
			}
			const duplicateTasks = new Set([...owners].filter(([, ids]) => ids.length > 1).map(([taskId]) => taskId));

			for (const scan of scans) {
				const conflicts = scan.recoverable.map((item) => item.taskId).filter((taskId) => duplicateTasks.has(taskId) || !!findTaskPool(taskId));
				if (conflicts.length) {
					reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: "manual", recoverable: scan.recoverable.length, manual: scan.manual.length, results: [], reason: `RPC_WAL_CROSS_INSTANCE_AMBIGUOUS: taskId 冲突 ${[...new Set(conflicts)].join(",")}` });
					continue;
				}
				if (!scan.recoverable.length) {
					reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: "manual", recoverable: 0, manual: scan.manual.length, results: [], reason: "WAL 仅含 manual 项，禁止自动接管" });
					continue;
				}

				let adopted: RpcPool;
				try {
					// core constructor 原子竞争 controller.lock：活 PID 拒绝；死 PID token 复核后回收并 generation+1。
					adopted = makePool(options, scan.instanceId);
				} catch (error) {
					const code = (error as NodeJS.ErrnoException).code;
					reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: code === "RPC_WAL_LOCKED" || code === "RPC_WAL_LOCK_UNKNOWN_OWNER" ? "locked" : "corrupt", recoverable: scan.recoverable.length, manual: scan.manual.length, results: [], reason: error instanceof Error ? error.message : String(error) });
					continue;
				}

				try {
					const results = await adopted.recoverPendingFromWal();
					const owned = results.filter((result) => adopted.getTaskState(result.taskId) !== undefined);
					if (!owned.length) {
						await adopted.shutdown();
						// K6：全部在途任务被对账门拦下（新契约 needs-reconciliation）时如实报告，不误报为空目录
						const gated = results.filter((result) => (result.reason || "").startsWith("K6_")).length;
						reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: "empty", generation: adopted.snapshot().generation, recoverable: scan.recoverable.length, manual: scan.manual.length, results, reason: gated ? `K6: ${gated} 项在途任务为新契约任务（needs-reconciliation），不自动接管` : "lease 接管后未重建任何 task" });
						continue;
					}
					adoptedPools.set(scan.instanceId, adopted);
					for (const result of owned) taskPools.set(result.taskId, adopted);
					reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: "recovered", generation: adopted.snapshot().generation, recoverable: scan.recoverable.length, manual: scan.manual.length, results });
				} catch (error) {
					try { await adopted.shutdown(); } catch {}
					reports.push({ instanceId: scan.instanceId, walDir: scan.walDir, status: "corrupt", generation: adopted.snapshot().generation, recoverable: scan.recoverable.length, manual: scan.manual.length, results: [], reason: error instanceof Error ? error.message : String(error) });
				}
			}
			return reports;
		},
		get initialized() { return !!pool || adoptedPools.size > 0; },
		shutdown(): Promise<void> {
			// W4-R1: 进行中的 shutdown 返回同一 Promise
			if (shutdownPromise) return shutdownPromise;
			// W4-R1: pool 不存在时 no-op，不持久化 shutdownPromise（防重建后泄漏）
			const currentPools = [...new Set([...(pool ? [pool] : []), ...adoptedPools.values()])];
			if (currentPools.length === 0) return Promise.resolve();
			const p = (async () => {
				for (const current of currentPools) try { forceSettleAll(current); } catch {}
				await Promise.all(currentPools.map(async (current) => { try { await current.shutdown(); } catch {} }));
			})();
			shutdownPromise = p;
			// W4-R1: finally 用闭包局部变量清理，不依赖外部可变状态同步赋值顺序
			p.then(() => { pool = undefined; adoptedPools.clear(); taskPools.clear(); shutdownPromise = undefined; }).catch(() => { pool = undefined; adoptedPools.clear(); taskPools.clear(); shutdownPromise = undefined; });
			return p;
		},
	};
	return controller;
}

// ── rpc_task 工具 ───────────────────────────────────────────────────────────

export function createRpcPoolTool(controller: RpcPoolController, pi?: ExtensionAPI): any {
	return {
		name: "rpc_task",
		label: "RPC Task",
		description: [
			"在 RPC 常驻进程池中管理长时任务（独立于 sync/background SubAgent）。",
			"actions: start（启动，返回 taskId）、adjust（steer 或重启 idle）、",
			"status（快照）、result（等待并返回结果）、recover（从 WAL 恢复）、",
			"answer（非 TUI 模式答复子 Agent 提问：value/confirmed/cancelled 三种语义）。",
			// ev-20260903-c1521b②：watch 型常驻指引同义补入（软感知，不阻断）
			"watch/dev 型常驻任务（tsx watch/pnpm dev/vite dev 等）不适用本池——worker 无完成态会使 result 挂起；常驻服务走 launchctl/systemd 或 nohup+日志轮询。",
		].join(" "),
		promptSnippet: `rpc_task({ action: "start", task: "..." }) → rpc_task({ action: "result", taskId: "..." })`,
		promptGuidelines: [
			"start 返回 taskId 后用 result 等待完成（异步模型，不阻塞当前 turn）。",
			"answer 答复提问：input/editor 用 value；confirm 用 confirmed:true/false；取消用 cancelled:true。",
		],
		parameters: Type.Object({
			action: StringEnum(["start", "adjust", "status", "result", "recover", "answer"]),
			task: Type.Optional(Type.String({ description: "start=任务 prompt；adjust=调整消息" })),
			taskId: Type.Optional(Type.String({ description: "adjust/status/result 的任务 ID" })),
			model: Type.Optional(Type.String({ description: "覆盖池模型（仅首次 start 创建池时生效）" })),
			requestId: Type.Optional(Type.String({ description: "answer: 请求 ID（来自 amagi:rpc-leader-question）" })),
			value: Type.Optional(Type.String({ description: "answer: input/editor 的文本答复" })),
			confirmed: Type.Optional(Type.Boolean({ description: "answer: confirm 的布尔答复（true/false）" })),
			cancelled: Type.Optional(Type.Boolean({ description: "answer: 取消提问（true）" })),
		}),

		async execute(
			_id: string,
			params: { action: string; task?: string; taskId?: string; model?: string; requestId?: string; value?: string; confirmed?: boolean; cancelled?: boolean },
			signal: AbortSignal | undefined,
			_onUpdate: ((partial: any) => void) | undefined,
			ctx: { cwd: string; model?: { provider: string; id: string }; ui?: any; mode?: string; modelRegistry?: ModelRegistryLike },
		) {
			// pi 1.3.0 适配（I1）：params.model（用户裸名风险面）与其它派发口同源归一——registry 在场时
			// 裸名升全限定 provider/model，歧义/未注册列候选清单拒单（不 spawn 注定歧义失败的 worker）；
			// registry 缺席（旧宿主/注入面）保持原样透传，不新增硬依赖。ctx.model 本为全限定不重复归一。
			// 仅 start 消费 model（schema：仅首次 start 创建池时生效）——answer/status/adjust/result 定位既有
			// 池/任务，不得因无关的 model 覆盖被拒（P3 F01：否则答复送不达、结果读不到）。
			let modelSpec = params.model || (ctx.model ? `${ctx.model.provider}/${ctx.model.id}` : undefined);
			if (params.action === "start" && params.task && params.model && ctx.modelRegistry) {
				const nm = normalizeModelSpec(params.model, ctx.modelRegistry);
				if (!nm.ok) return { content: [{ type: "text" as const, text: `[rpc_task model] ${nm.error}` }], isError: true };
				modelSpec = nm.spec || params.model;
			}

			// W5: 参数校验前于 getPool

			// ── answer（W2-R1: 类型化答复契约）──
			if (params.action === "answer") {
				if (!params.requestId) return { content: [{ type: "text" as const, text: "[rpc_task answer] 需要 requestId" }], isError: true };
				if (!controller.initialized) return { content: [{ type: "text" as const, text: "[rpc_task answer] RPC 池未初始化（先 start 一个任务）" }], isError: true };
				// W2-R1: 按 cancelled > confirmed > value 优先级映射 RpcLeaderAnswer
				let answerValue: RpcLeaderAnswer;
				if (params.cancelled === true) answerValue = { cancelled: true };
				else if (params.confirmed === true) answerValue = { confirmed: true };
				else if (params.confirmed === false) answerValue = { confirmed: false };
				else if (typeof params.value === "string") answerValue = { value: params.value };
				else answerValue = undefined; // 无答复内容 → cancelled
				// adopted recovery pool 也可能发起提问；先跨 controller 路由，测试/旧 mock 再回退 getPool。
				const ok = controller.answerLeaderQuestion(params.requestId, answerValue)
					|| controller.getPool({ cwd: ctx.cwd, model: modelSpec, mode: ctx.mode, ui: ctx.ui, pi }).answerLeaderQuestion(params.requestId, answerValue);
				const desc = params.cancelled ? "已取消" : params.confirmed !== undefined ? `confirmed=${params.confirmed}` : params.value ? `value="${params.value.slice(0, 40)}"` : "cancelled(空)";
				return { content: [{ type: "text" as const, text: ok ? `[rpc_task answer] 已送达 (${desc})` : `[rpc_task answer] requestId 未找到或已超时` }], isError: !ok };
			}

			// ── status（W5: 未初始化时不创建 pool）──
			if (params.action === "status") {
				if (!controller.initialized) return { content: [{ type: "text" as const, text: "[rpc_task status] RPC 池未初始化（uninitialized）" }] };
				const views = controller.snapshots();
				const lines = views.map(({ instanceId: id, role, snapshot: snap }) => `pool ${snap.poolId.slice(0, 8)} instance=${id} ${role} gen=${snap.generation} workers=${snap.size}/${snap.maxWorkers} waiting=${snap.waiting}`);
				if (params.taskId) {
					const ts = controller.findTaskPool(params.taskId)?.getTaskState(params.taskId);
					lines.push(`task ${params.taskId.slice(0, 8)}: ${ts || "not found"}`);
				}
				const tasks = views.flatMap((view) => view.snapshot.tasks);
				for (const t of tasks.slice(0, 20)) {
					lines.push(`  ${t.taskId.slice(0, 8)} ${t.state}${t.recovered ? " recovered" : ""}${t.workerId ? ` worker=${t.workerId.slice(0, 6)}` : ""}`);
				}
				if (tasks.length > 20) lines.push(`  ...另有 ${tasks.length - 20} 个`);
				return { content: [{ type: "text" as const, text: lines.join("\n") }] };
			}

			if (params.action === "start" && !params.task)
				return { content: [{ type: "text" as const, text: "[rpc_task start] 需要 task（prompt）" }], isError: true };
			if (params.action === "adjust" && (!params.taskId || !params.task))
				return { content: [{ type: "text" as const, text: "[rpc_task adjust] 需要 taskId + task" }], isError: true };
			if (params.action === "result" && !params.taskId)
				return { content: [{ type: "text" as const, text: "[rpc_task result] 需要 taskId" }], isError: true };

			try {
				if (params.action === "start") {
					const pool = controller.getPool({ cwd: ctx.cwd, model: modelSpec, mode: ctx.mode, ui: ctx.ui, pi });
					// ev-20260903-c1521b②：watch 型常驻软感知——不阻断启动，仅返回体附提示段
					// （2026-09-04 起用 watch-probe.ts 共享探测，误报根治见 ev-20260904-0678c1）
					const watchAdvisory = looksLikeWatchCommand(params.task!) ? `\n\n${WATCH_TASK_ADVISORY}` : "";
					// v2 批次D：主 registry + 共享 admission 对齐（flag 关 → 老路径不变）；
					// 并发键 = 池模型（池内 worker 统一模型，取 pool.options.model 的 provider）
					if (rpcAdapterOn()) {
						// K6：确保内核桥已安装（registry.create→内核 register/grant-start 命令；状态迁移直走内核命令）
						const kernel = getTaskKernel();
						const taskId = crypto.randomUUID();
						const occ = tryOccupy(taskId, { modelSpec: pool.options.model, cwd: ctx.cwd });
						registry.create("rpc", taskId, modelSpec, "background", { goal: params.task!, cwd: ctx.cwd, startQueued: occ === "queued", backend: "rpc" });
						if (occ === "queued") {
							// 超容量 → FIFO 排队：立即返回排队 handle，晋级后异步启动（不阻塞当前 turn）
							void (async () => {
								const g = await waitForGrant(taskId);
								if (g !== "running") return; // 排队中被取消（cancelQueued 已收口 registry/admission）
								// K6：晋级=内核 grant-start（launchIntent 先于 spawn 持久化）；取消竞态下内核拒绝且零启动（N4）
								const view = kernel.get(taskId);
								if (!view || view.execution !== "queued") { try { releaseAdmission(taskId); } catch {} return; }
								const granted = await kernel.apply({ type: "grant-start", key: { ownerId: view.ownerId, taskId, revision: view.revision }, backend: "rpc", launchIntent: { nonce: `rpc-${crypto.randomUUID()}`, at: Date.now() } });
								if (!granted.ok) { try { releaseAdmission(taskId); } catch {} return; }
								try { registry.patch(taskId, { queueMs: Date.now() - (registry.get(taskId)?.queuedAt || Date.now()) }); } catch {} // 桥字段兜底（排队观测）
								try {
									const handle = await pool.startTask({ taskId, prompt: params.task! });
									kernelObserveLaunch(taskId, handle.sessionId);
									trackCompletion(pool, taskId, ctx.cwd);
								} catch (e) { rpcStartFailed(taskId, e); }
							})();
							const adm = admissionStats();
							return { content: [{ type: "text" as const, text: `[rpc_task 排队 ${taskId.slice(0, 8)}] 执行槽位已满（${adm.running}/${adm.capacity} 在跑 · ${adm.queued} 排队${admissionPoolNote(adm)}），已入 FIFO 队列——晋级后自动启动；用 rpc_task({ action: "result", taskId: "${taskId}" }) 等结果，或 task({ cancel: "${taskId}" }) 取消。${watchAdvisory}` }] };
						}
						try {
							const handle = await pool.startTask({ taskId, prompt: params.task! });
							kernelObserveLaunch(taskId, handle.sessionId);
							trackCompletion(pool, taskId, ctx.cwd);
							return {
								content: [{
									type: "text" as const,
									text: `[rpc_task start ${handle.taskId.slice(0, 8)}] 已在 RPC 池启动（backend:rpc，已登记主任务表）。\n用 rpc_task({ action: "result", taskId: "${handle.taskId}" }) 等待完成。\n用 rpc_task({ action: "adjust", taskId: "${handle.taskId}", task: "..." }) 运行中调整；task({ cancel: "${handle.taskId}" }) 可取消。${watchAdvisory}`,
								}],
							};
						} catch (e) { rpcStartFailed(taskId, e); throw e; }
					}
					const handle = await pool.startTask({ prompt: params.task! });
					return {
						content: [{
							type: "text" as const,
							text: `[rpc_task start ${handle.taskId.slice(0, 8)}] 已在 RPC 池启动。\n用 rpc_task({ action: "result", taskId: "${handle.taskId}" }) 等待完成。\n用 rpc_task({ action: "adjust", taskId: "${handle.taskId}", task: "..." }) 运行中调整。${watchAdvisory}`,
						}],
					};
				}

				if (params.action === "adjust") {
					// K6：不支持能力返回 unsupported——任务不在任何池/worker 不可复用时明确报错，
					// 不再隐式建池伪成功（旧路径对未知 taskId 新建 pool 后才报 not found）
					if (!controller.capabilities().adjust) {
						return { content: [{ type: "text" as const, text: `[rpc_task unsupported] 本池不支持 adjust（capabilities: ${JSON.stringify(controller.capabilities())}）` }], isError: true };
					}
					const pool = controller.findTaskPool(params.taskId!);
					if (!pool) {
						return { content: [{ type: "text" as const, text: `[rpc_task unsupported] RPC task not found: ${params.taskId}；adjust 需要池内任务（若句柄来自 task({background:true}) 的 batch/后台派发，它不是 RPC 任务——等待自动通知或 query_task({session}) 查询）` }], isError: true };
					}
					let adj;
					try {
						adj = await pool.adjustTask(params.taskId!, params.task!);
					} catch (e) {
						const msg = e instanceof Error ? e.message : String(e);
						if (/no reusable worker session|RPC task not found/.test(msg)) {
							return { content: [{ type: "text" as const, text: `[rpc_task unsupported] adjust 不支持该任务当前 worker 状态：${msg}` }], isError: true };
						}
						throw e;
					}
					return { content: [{ type: "text" as const, text: `[rpc_task adjust ${params.taskId!.slice(0, 8)}] ${adj.delivery}：${adj.description}` }] };
				}

				if (params.action === "result") {
					const pool = controller.findTaskPool(params.taskId!) || controller.getPool({ cwd: ctx.cwd, model: modelSpec, mode: ctx.mode, ui: ctx.ui, pi });
					let result: RpcTaskResult;
					if (signal) {
						result = await Promise.race([
							pool.waitForTask(params.taskId!),
							new Promise<never>((_, reject) => {
								if (signal.aborted) reject(new Error("aborted"));
								else signal.addEventListener("abort", () => reject(new Error("aborted")), { once: true });
							}),
						]);
					} else {
						result = await pool.waitForTask(params.taskId!);
					}
					// W3: error 状态优先回传 result.error
					const body = result.state === "error" && result.error
						? `[失败根因] ${result.error}`
						: result.lastAssistantText || "(无输出)";
					const tag = `[rpc_task result ${params.taskId!.slice(0, 8)} ${result.state}${result.recovered ? " recovered" : ""}]`;
					return { content: [{ type: "text" as const, text: `${tag}\n\n${body}` }], isError: result.state === "error" };
				}

				if (params.action === "recover") {
					const reports = await controller.recover({ cwd: ctx.cwd, model: modelSpec, mode: ctx.mode, ui: ctx.ui, pi });
					// v2 批次D：本进程内有主 registry 记录的接管任务补挂统一收尾链（跨重启 WAL
					// 任务无记录——恢复边界如实不补，不占 admission）
					if (rpcAdapterOn()) {
						for (const report of reports) for (const item of report.results) {
							if (!registry.get(item.taskId)) continue;
							const p = controller.findTaskPool(item.taskId);
							if (p) trackCompletion(p, item.taskId, ctx.cwd);
						}
					}
					if (reports.length === 0) return { content: [{ type: "text" as const, text: "[rpc_task recover] WAL 无未终结任务" }] };
					const recovered = reports.reduce((count, report) => count + report.results.filter((item) => item.status !== "manual" && item.status !== "failed").length, 0);
					const lines = reports.map((report) => {
						const tasks = report.results.map((item) => `${item.taskId.slice(0, 8)}:${item.status}`).join(",");
						return `  instance=${report.instanceId} ${report.status}${report.generation ? ` gen=${report.generation}` : ""} recoverable=${report.recoverable} manual=${report.manual}${tasks ? ` tasks=[${tasks}]` : ""}${report.reason ? ` — ${report.reason}` : ""}`;
					});
					const hardFailure = reports.some((report) => report.status === "corrupt");
					return { content: [{ type: "text" as const, text: `[rpc_task recover] ${recovered} 项实际接管\n${lines.join("\n")}` }], isError: hardFailure };
				}

				return { content: [{ type: "text" as const, text: `未知 action: ${params.action}` }], isError: true };
			} catch (e) {
				const msg = e instanceof Error ? e.message : String(e);
				if (msg === "aborted") return { content: [{ type: "text" as const, text: `[rpc_task ${params.action}] 已中止` }] };
				return { content: [{ type: "text" as const, text: `[rpc_task ${params.action}] 错误: ${msg}` }], isError: true };
			}
		},
	};
}
