/** Single-file Codex-style update hunks → native literal edits. No filesystem access or writes. */
interface PatchLine { kind: " " | "+" | "-"; text: string }
interface Hunk { anchor?: string; lines: PatchLine[]; eof: boolean }

export const EDIT_PATCH_GUIDELINE = "For several changes or long blocks, prefer edit({path, patch}) with Codex-style update hunks: @@ followed by lines prefixed with space (unchanged context), - (remove), or + (add). Include about 3 context lines around changes; @@ function signature can disambiguate a block. Omit edits/files. Only single-file updates are supported; no file headers (a lone leading *** Begin Patch / trailing *** End Patch envelope line is tolerated and ignored), add/delete/move operations, or numbered unified-diff headers. Unchanged context is copied from the file; additions are literal text.";

const ENVELOPE_BEGIN = "*** Begin Patch";
const ENVELOPE_END = "*** End Patch";

function fail(message: string): never { throw new Error(`[amagi edit patch] ${message}`); }

/** Strict sampling uses nullable optional fields; XML providers may stringify an unused option. */
export function normalizeEditPatchOptions(input: Record<string, unknown>): void {
	if (input.patch === null || (input.patch === "null" && Array.isArray(input.edits))) delete input.patch;
	if (typeof input.patch === "string") {
		if (input.edits === null) delete input.edits;
		if (input.files === null) delete input.files;
	}
}

/** Validate syntax without reading the target, also used by the tool_call guard. */
export function parseEditPatch(patch: string): Hunk[] {
	if (typeof patch !== "string" || !patch.trim()) fail("patch 必须是非空字符串。");
	const lines = patch.replace(/\r\n?/g, "\n").split("\n");
	if (lines.at(-1) === "") lines.pop();
	// ev-20261021-2b2e3b：Codex 补丁信封边界行（首行 *** Begin Patch / 末行 *** End Patch）不携带内容、
	// 位置固定、与任何合法补丁行不冲突（合法行必带 @@/空格/-/+ 前缀）——在信封位置按语法剥离。
	// 文件头（*** Update/Add/Delete File）、信封出现在中间、多信封仍按非法行拒绝：单文件与唯一性语义不变。
	while (lines.length && lines.at(-1) === "" && lines.at(-2) === ENVELOPE_END) lines.pop();
	if (lines.at(-1) === ENVELOPE_END) lines.pop();
	if (lines[0] === ENVELOPE_BEGIN) lines.shift();
	const hunks: Hunk[] = [];
	let current: Hunk | undefined;
	for (const line of lines) {
		if (line === "@@" || line.startsWith("@@ ")) {
			if (/^@@ -\d/.test(line)) fail("不接受带行号的 unified diff；使用 @@ 或 @@ 函数/标题原文。");
			current = {anchor: line.slice(3) || undefined, lines: [], eof: false}; hunks.push(current);
		} else if (line === "*** End of File" && current && !current.eof) {
			current.eof = true;
		} else if (current && !current.eof && [" ", "+", "-"].includes(line[0] ?? "")) {
			current.lines.push({kind: line[0] as PatchLine["kind"], text: line.slice(1)});
		} else fail(`非法补丁行 ${JSON.stringify(line)}；用 @@ 开始，每行只用空格/-/+ 前缀，空行也须前缀。`);
	}
	if (!hunks.length) fail("至少需要一个 @@ 修改块。");
	for (const [index, hunk] of hunks.entries()) {
		const location = `块 ${index + 1}（${hunk.anchor ? `@@ ${hunk.anchor}` : hunk.lines[0]?.text || "空块"}）`;
		if (!hunk.lines.some(l => l.kind !== " ")) fail(`${location}只有上下文，没有增删行；将定位上下文合并到相邻修改块，或改用 edits[]。`);
		if (!hunk.lines.some(l => l.kind !== "+")) fail(`${location}插入须提供目标附近的上下文；不能仅凭空的锚点插入。`);
	}
	return hunks;
}

/** Exact → trailing-space tolerance → line-edge whitespace tolerance; never fuzzy-match words. */
export function resolveEditPatch(source: string, patch: string): Array<{oldText: string; newText: string}> {
	const hunks = parseEditPatch(patch);
	const text = source.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n");
	const lines = text.split("\n");
	if (text.endsWith("\n")) lines.pop();
	const normalize = [(s: string) => s, (s: string) => s.trimEnd(), (s: string) => s.trim()];
	const ranges: Array<{start: number; end: number}> = [];
	return hunks.map((hunk, index) => {
		let startAt = 0;
		if (hunk.anchor) {
			const anchors = lines.flatMap((line, i) => line.trim() === hunk.anchor!.trim() ? [i] : []);
			if (anchors.length !== 1) fail(`块 ${index + 1} 的 @@ 锚点命中 ${anchors.length} 处；使用唯一函数/标题原文。`);
			startAt = anchors[0]!;
		}
		const oldLines = hunk.lines.filter(l => l.kind !== "+").map(l => l.text);
		let hits: number[] = [];
		for (const norm of normalize) {
			for (let i = startAt; i + oldLines.length <= lines.length; i++) {
				if (hunk.eof && i + oldLines.length !== lines.length) continue;
				if (oldLines.every((line, j) => norm(line) === norm(lines[i + j]!))) hits.push(i);
			}
			if (hits.length) break;
		}
		if (hits.length !== 1) fail(`块 ${index + 1} 上下文命中 ${hits.length} 处${hits.length ? `（行 ${hits.slice(0, 8).map(i => i + 1).join("、")}）` : ""}；请实读目标并添加唯一上下文，不凭记忆改写删除行。`);
		const matchStart = hits[0]!, end = matchStart + oldLines.length;
		// Native edit matches literal text globally. Keep the explicit @@ anchor and intervening
		// original lines in the replacement so a repeated body cannot lose its disambiguation.
		const start = hunk.anchor ? startAt : matchStart;
		if (ranges.some(r => start < r.end && end > r.start)) fail("修改块范围重叠；将相邻修改合并到一个 @@ 块。");
		ranges.push({start, end});
		let cursor = matchStart;
		const replacement: string[] = lines.slice(start, matchStart);
		for (const line of hunk.lines) {
			if (line.kind === "+") replacement.push(line.text);
			else { if (line.kind === " ") replacement.push(lines[cursor]!); cursor++; }
		}
		return {oldText: lines.slice(start, end).join("\n"), newText: replacement.join("\n")};
	});
}
