/**
 * path-drift.ts — ev-20260929-3c5db4（P0）：路径漏层漂移防线（存在性快照 + 同名近邻探测）。
 *
 * 根因（reflect 复盘·battle-sim 三起事故）：路径在「提交→冻结→任务书→子 Agent 凭记忆重构→写盘」
 * 链上只有逐字文本传递、无任何存在性/规范化校验——required 输入缺失在正式提交点放行（子 Agent
 * 运行中才 ENOENT，4 次 blocked/1 次 cancel）；深层中文路径漏层后 write 对缺失中间层自动
 * mkdir 零告警（43 份文档写入错误树，靠人工比对才发现）。
 *
 * 防线设计（不跨层兜底，只在「路径确定性失败」边界给出最早信号）：
 *  - 提交点（task-facets）：required 输入冻结时不存在 = 子进程必然读不到 → 整单拒绝（与工具面
 *    文档「缺失即拒单」语义对齐）；可选输入缺失/产物中间层缺失且项目内存在同名目录 → 附漏层
 *    近邻提示行（dryRun/wait/handle 三出口同文案），不阻断。
 *  - 写盘点（write-override）：成功写盘若新建了中间目录且项目内存在同名目录 → 回执追加
 *    「疑似漏层」advisory（写入已生效，不回滚——本会话即时可核）。
 *
 * 近邻探测是有界扫描（BFS，深度/节点数/结果数三上限，跳过依赖产物目录），仅在「存在缺失中间层」
 * 这一稀有条件下触发；常规写入（父目录存在）零扫描。扫描结果带短 TTL 缓存（脚手架连写防重复扫描）。
 * 全部为纯探测与提示：绝不改写路径、绝不阻断写入——修复动作留给调用方决策。
 *
 * ev-20261006-c8ddde（误报收敛·平行新结构）：新建平行模块仿既有目录约定（Cxx/present/include/
 * m01present ↔ Cxx/content/include/m01content）时，常规结构层名（include 等）在每个库下同名
 * 出现，全树精确同名扫描必然命中 → 误报「疑似漏层」。双修复：①泛化名扩充（include/examples/
 * internal 等多模块工程结构层名——同名命中遍地都是，跳过）；②上下文核验（contextualNearMiss：
 * 漏层的真实形态是少写一层、该段之后更深层仍落在真实位置——候选目录下更深缺失层链须存在，
 * 平行新结构的更深层是新名字、候选下必然不存在 → 抑制；tail 为空退化候选自身存在即通过，
 * 真漏层主形态不受影响）。
 */
import * as fs from "node:fs";
import * as path from "node:path";

/** 探测跳过的目录（依赖/产物/缓存——同名命中无诊断价值且节点数巨大）。 */
const NEAR_MISS_SKIP_DIRS = new Set([
	"node_modules", ".git", ".amagi-worktrees", "dist", "build", "out", ".next", ".turbo",
	".cache", "coverage", ".venv", "venv", "__pycache__", ".pi", "target", ".idea", ".vscode",
]);

/** 泛化目录名（src/docs 等）同名命中遍地都是，提示噪音大于价值——跳过。
 *  ev-20261006-c8ddde：扩充多模块/C++ 工程常规结构层名——include/inc/headers/examples/
 *  internal/common/… 平行新库仿既有约定时这些层名在每个库目录下都同名出现（实战：present
 *  新库仿 content 约定被误提示），属结构约定而非漏层。 */
const GENERIC_DIR_NAMES = new Set([
	"src", "docs", "doc", "lib", "test", "tests", "assets", "config", "conf", "scripts",
	"public", "static", "tmp", "temp", "app", "data", "tools", "utils", "core", "webui",
	"include", "inc", "headers", "examples", "example", "demo", "demos", "sample", "samples",
	"bench", "benchmark", "benchmarks", "internal", "common", "shared", "base", "detail",
	"details", "impl", "cmake", "vendor", "3rdparty", "thirdparty", "third_party", "third-party",
	"external", "extern", "deps", "dependencies", "plugins", "extensions", "modules",
	"packages", "components", "api", "templates", "template",
]);

export interface MissingIntermediates {
	/** 自最深存在祖先到目标父目录之间需新建的中间目录名（按路径顺序；空=父链完整存在）。 */
	missingDirs: string[];
	/** 最深的已存在祖先绝对路径。 */
	deepestExisting: string;
}

/**
 * 计算目标路径（文件或目录）缺失的中间目录链：从 dirname(target) 逐级向上直到已存在目录。
 * 常规写入（父目录已存在）→ missingDirs 为空（零扫描零提示的快路径）。
 * 纯函数（只 stat 不写）；路径不可达（如挂在文件上）按缺失段如实报告。
 */
export function missingIntermediateDirs(cwd: string, target: string): MissingIntermediates {
	const abs = path.resolve(cwd, target);
	const missingDirs: string[] = [];
	let cur = path.dirname(abs);
	let guard = 0;
	while (!fs.existsSync(cur) && cur !== path.parse(cur).root && guard++ < 64) {
		missingDirs.unshift(path.basename(cur));
		cur = path.dirname(cur);
	}
	return { missingDirs, deepestExisting: cur };
}

export interface NearMissResult {
	/** 命中的缺失目录名。 */
	name: string;
	/** root 下同名目录的相对路径（每名至多 2 条，按发现顺序）。 */
	dirs: string[];
}

/** ev-20261002-9aad70：隐形字符等价匹配的名称归一化——去零宽字符（U+200B-200D/U+FEFF/U+00AD）、
 *  全角空格→半角、NFKC 规范化形态（全角字母数字→半角）。字节级不相等但归一化后相等
 *  = 「肉眼相同」的隐形差异——正是深路径手写拒单的根因形态。 */
function normalizeNameForMatch(name: string): string {
	return name
		.normalize("NFKC")
		.replace(/[\u200B-\u200D\uFEFF\u00AD]/g, "")
		.replace(/\u3000/g, " ")
		.trim();
}

export interface EquivalentPathResult {
	/** 归一化等价的真实路径（相对 cwd 回显，可直接复制重提）。 */
	equivalent: string;
	/** 首处差异定位（缺失段名 ↔ 真实段名——肉眼相同、字节不同）。 */
	detail: string;
}

/**
 * ev-20261002-9aad70（friction/P1）：隐形字符差异等价路径探测。
 *
 * 根因：required 路径拒单的近邻探测 findNearMissDirs 按「缺失目录名字节级相等」扫描全树——
 * 手写深路径含不可见差异（零宽字符/全角空格/NFC-NFD 形态，实战 P7/P8a 两次 90+ 字符中文
 * 路径拒单）时目录名永不相等，近邻候选必空，拒单只剩泛化 hint，Leader 需人工字节级比对。
 * 本探测不扫全树：从最深存在祖先起逐段 readdir，按归一化等价匹配缺失段（中间段→目录，
 * 末段→文件/目录），全链命中后 existsSync 核验——返回可直接复制的真实路径与差异定位。
 * 纯探测零写入、异常一律返回 null（advisory 层零故障放大）。
 */
export function equivalentPathHint(cwd: string, target: string): EquivalentPathResult | null {
	try {
		if (typeof target !== "string" || target.trim() === "") return null;
		const abs = path.resolve(cwd, target);
		if (fs.existsSync(abs)) return null;
		const { missingDirs, deepestExisting } = missingIntermediateDirs(cwd, target);
		const segments = [...missingDirs, path.basename(abs)];
		// 实测边界（ev-20261002-9aad70 测试正③实证）：macOS APFS 路径解析做 Unicode 规范化等价，
		// NFC/NFD 目录差异在文件系统层已消解（existsSync 直接命中，不产生拒单）；NFKC 归一化
		// 服务于 Linux ext4 字节严格语义与零宽/全角类非规范化等价差异（APFS 不消解）。
		if (segments.some((seg) => !seg || normalizeNameForMatch(seg) === "")) return null;
		let cur = deepestExisting;
		let firstDiff: string | null = null;
		for (let i = 0; i < segments.length; i++) {
			const seg = segments[i];
			const wanted = normalizeNameForMatch(seg);
			let matched: string | null = null;
			for (const entry of fs.readdirSync(cur, { withFileTypes: true })) {
				if (normalizeNameForMatch(entry.name) !== wanted) continue;
			matched = entry.name;
			break;
		}
			if (matched === null) return null; // 任一段无归一化等价实体 → 探测失败，如实返回
			if (firstDiff === null) firstDiff = `段 "${seg}" ↔ 真实 "${matched}"`;
			cur = path.join(cur, matched);
		}
		if (!fs.existsSync(cur)) return null;
		return { equivalent: path.relative(cwd, cur) || cur, detail: firstDiff ?? "" };
	} catch { return null; /* lint-exempt:探测异常一律否掉——advisory 层零故障放大 */ }
}

interface NearMissOpts {
	/** BFS 最大深度（默认 8）。 */
	maxDepth?: number;
	/** 最大访问节点数（默认 5000——防巨型树拖慢）。 */
	maxNodes?: number;
	/** 每个名字最多收集条数（默认 2）。 */
	perName?: number;
}

/** 短 TTL 扫描缓存（脚手架连写同一批缺失名防重复全树扫描；条目上限防爆内存）。 */
const scanCache = new Map<string, { at: number; value: NearMissResult[] }>();
const SCAN_CACHE_TTL_MS = 5_000;
const SCAN_CACHE_MAX = 64;

function nearMissCacheGet(key: string): NearMissResult[] | undefined {
	const hit = scanCache.get(key);
	if (!hit) return undefined;
	if (Date.now() - hit.at > SCAN_CACHE_TTL_MS) { scanCache.delete(key); return undefined; }
	return hit.value;
}

function nearMissCacheSet(key: string, value: NearMissResult[]): void {
	if (scanCache.size >= SCAN_CACHE_MAX) {
		const oldest = scanCache.keys().next().value;
		if (oldest !== undefined) scanCache.delete(oldest);
	}
	scanCache.set(key, { at: Date.now(), value });
}

/** 清空扫描缓存（测试隔离用）。 */
export function resetPathDriftScanCache(): void {
	scanCache.clear();
}

/**
 * 有界 BFS：在 root 下查找与给定名字同名的已存在目录（漏层近邻候选）。
 * 过滤：空名/单字符名与泛化目录名不参与（噪音大于价值）；跳过依赖产物目录。
 * 任一目录不可读（权限）→ 跳过该子树，不影响其余扫描。纯探测，不抛出。
 */
export function findNearMissDirs(root: string, names: readonly string[], opts: NearMissOpts = {}): NearMissResult[] {
	const usable = [...new Set(names.map((n) => n.trim()).filter((n) => n.length >= 2 && !GENERIC_DIR_NAMES.has(n.toLowerCase())))];
	if (usable.length === 0 || !fs.existsSync(root)) return [];
	const key = `${root}\u0000${[...usable].sort().join("\u0001")}`;
	const cached = nearMissCacheGet(key);
	if (cached) return cached;
	const maxDepth = opts.maxDepth ?? 8;
	const maxNodes = opts.maxNodes ?? 5000;
	const perName = opts.perName ?? 2;
	const wanted = new Map(usable.map((n) => [n, [] as string[]]));
	let nodes = 0;
	const queue: Array<{ dir: string; depth: number }> = [{ dir: root, depth: 0 }];
	while (queue.length > 0 && nodes < maxNodes) {
		const { dir, depth } = queue.shift()!;
		nodes++;
		if (depth >= maxDepth) continue;
		let entries: fs.Dirent[];
		try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; /* lint-exempt:目录不可读子树跳过——近邻探测尽力而为，不算错误 */ }
		for (const e of entries) {
			if (!e.isDirectory() || NEAR_MISS_SKIP_DIRS.has(e.name)) continue;
			const child = path.join(dir, e.name);
			const bucket = wanted.get(e.name);
			const isWanted = bucket !== undefined;
			if (isWanted && bucket.length < perName) bucket.push(path.relative(root, child));
			// 非目标名目录恒下钻（同名命中可能在更深处）；目标名目录未满额时下钻找第二条，满额剪枝。
			if (!isWanted || bucket.length < perName) queue.push({ dir: child, depth: depth + 1 });
		}
		if ([...wanted.values()].every((b) => b.length >= perName)) break;
	}
	const value = [...wanted.entries()].filter(([, dirs]) => dirs.length > 0).map(([name, dirs]) => ({ name, dirs }));
	nearMissCacheSet(key, value);
	return value;
}

/** 提示行构造：漏层近邻候选 → 单行提示（无候选返回 null）。 */
export function nearMissSuffix(nearMiss: readonly NearMissResult[]): string | null {
	if (nearMiss.length === 0) return null;
	return nearMiss.map((m) => `项目内存在同名目录${m.name}：${m.dirs.map((d) => d || ".").join("、")}`).join("；");
}

/** ev-20261006-c8ddde：目录存在性精确判定（statSync 目录——挂同名文件不算，探测异常一律否）。 */
function isDirectory(p: string): boolean {
	try { return fs.statSync(p).isDirectory(); } catch { return false; /* lint-exempt:stat 失败按不存在处理——纯提示层不放大故障 */ }
}

/**
 * ev-20261006-c8ddde（误报收敛·上下文核验）：候选目录下「被写路径中该段之后的更深缺失层链」须存在。
 * 漏层的真实形态是少写一层、剩余更深段仍落在真实位置（真实树自候选层向下完整）；平行新结构中
 * 同名层之下的更深层是新名字（m01present ≠ m01content），候选下必然不存在——同名纯属结构约定
 * 巧合，抑制。tail 为空（该段即最深缺失层）退化为候选自身存在即通过——真漏层主形态（漏掉紧邻
 * 上层的写新文件场景，深层文件尚不存在）不受影响。同名段多次出现时按任一位置核验通过即可。 */
function tailDirsExist(cwd: string, missingDirs: readonly string[], name: string, candidateRel: string): boolean {
	const positions: number[] = [];
	missingDirs.forEach((m, idx) => { if (m === name) positions.push(idx); });
	for (const i of positions) {
		let cur = path.resolve(cwd, candidateRel);
		if (!isDirectory(cur)) continue;
		let ok = true;
		for (let j = i + 1; j < missingDirs.length && ok; j++) {
			cur = path.join(cur, missingDirs[j]);
			ok = isDirectory(cur);
		}
		if (ok) return true;
	}
	return false;
}

/**
 * ev-20261006-c8ddde：上下文核验后的近邻候选（同名 且 候选下更深缺失层链吻合）——提交点与
 * 写盘点两调用方的统一降噪出口；findNearMissDirs 原始扫描保持导出（测试/等价路径探测直接用）。 */
export function contextualNearMiss(cwd: string, target: string): NearMissResult[] {
	try {
		const { missingDirs } = missingIntermediateDirs(cwd, target);
		return findNearMissDirs(cwd, missingDirs)
			.map((m) => ({ name: m.name, dirs: m.dirs.filter((d) => tailDirsExist(cwd, missingDirs, m.name, d)) }))
			.filter((m) => m.dirs.length > 0);
	} catch { return []; /* lint-exempt:探测异常一律否掉——advisory 层零故障放大 */ }
}

/**
 * 提交点路径快照（task-facets 专用）：
 *  - missingRequired：required 输入中冻结时即不存在的路径及其漏层近邻候选（提交点应整单拒绝）；
 *  - advisoryLines：可选输入缺失/产物中间层缺失 且 存在近邻候选 的提示行（≤4 行，不阻断）。
 * 纯探测；路径均为相对 taskCwd 的书写形态回显（与提交参数一致，方便逐字修正）。
 */
export function submitPathDriftHints(
	cwd: string,
	inputs: ReadonlyArray<{ path: string; required?: boolean }>,
	outputs: ReadonlyArray<{ path: string; kind?: string }>,
): {
	missingRequired: ReadonlyArray<{ path: string; nearMiss: string | null; equivalent: EquivalentPathResult | null }>;
	advisoryLines: string[];
} {
	const missingRequired: Array<{ path: string; nearMiss: string | null; equivalent: EquivalentPathResult | null }> = [];
	const advisoryLines: string[] = [];
	for (const inp of inputs) {
		const abs = path.resolve(cwd, inp.path);
		if (fs.existsSync(abs)) continue;
		if (inp.required !== false) {
			// ev-20261002-9aad70：等价路径（隐形字符差异）优先于漏层近邻——定位更精准（同位置真实
			// 路径可直接复制），两者独立探测、可同时给出（等价=同位置隐形差异，漏层=少写一层）。
			missingRequired.push({
				path: inp.path,
			nearMiss: nearMissSuffix(contextualNearMiss(cwd, inp.path)), // ev-20261006-c8ddde：上下文核验降噪（缩进沿用本块既有形态）
				equivalent: equivalentPathHint(cwd, inp.path),
			});
		} else {
			// ev-20261006-c8ddde：近邻探测统一走上下文核验（contextualNearMiss）
			const suffix = nearMissSuffix(contextualNearMiss(cwd, inp.path));
			if (suffix) advisoryLines.push(`[amagi 路径快照·疑似漏层] inputs "${inp.path}"（可选）不存在——${suffix}；若为漏层（少写一层）请修正后提交。`);
		}
	}
	for (const out of outputs) {
		const { missingDirs } = missingIntermediateDirs(cwd, out.path);
		if (missingDirs.length === 0) continue;
		const suffix = nearMissSuffix(contextualNearMiss(cwd, out.path)); // ev-20261006-c8ddde：上下文核验降噪
		if (suffix) advisoryLines.push(`[amagi 路径快照·疑似漏层] outputs "${out.path}" 将新建中间层 ${missingDirs.join("/")}——${suffix}；若为漏层（少写一层）请修正后提交，确认新结构则忽略本提示。`);
	}
	return { missingRequired, advisoryLines: advisoryLines.slice(0, 4) };
}

/** ev-20261005-01c6f2（diting F-10）：同签名（root+新建中间层链）只提示一次——merge/commit 收口流在
 *  预期新建目录层上逐文件写入时同层提示重复轰炸（实战 4 次），保留首建告警、后续同层零噪音。
 *  签名含 cwd（跨项目同名层不互相抑制）；FIFO 有界（512，长会话不无界增长）；会话级去重（模块态），
 *  resetPathDriftDedupe 供测试隔离。 */
const writeDriftWarned = new Set<string>();
const WRITE_DRIFT_WARNED_MAX = 512;

/** 测试隔离：清空写盘漂移提示去重集。 */
export function resetPathDriftDedupe(): void {
	writeDriftWarned.clear();
}

/**
 * 写盘回执注记（write-override 专用）：本次写入需新建中间目录 且 项目内存在同名目录 →
 * 「疑似漏层」advisory 文本；否则 null（父目录存在的常规写入零成本快路径）。
 * 只在写前求值（mkdir 发生在原生 execute 内）；任何探测异常吞掉返回 null，绝不影响写盘。
 * ev-20261005-01c6f2：同中间层链签名只提示一次（首建告警保留，重复写入零噪音）。 */
export function writeDriftNote(cwd: string, targetPath: string): string | null {
	try {
		if (typeof targetPath !== "string" || targetPath.trim() === "") return null;
		const { missingDirs } = missingIntermediateDirs(cwd, targetPath);
		if (missingDirs.length === 0) return null;
		const signature = `${cwd}\u0000${missingDirs.join("/")}`; // diting F-10：签名含 cwd（跨项目同层链不互相抑制）
		if (writeDriftWarned.has(signature)) return null;
		const suffix = nearMissSuffix(contextualNearMiss(cwd, targetPath)); // ev-20261006-c8ddde：上下文核验降噪
		if (!suffix) return null;
		if (writeDriftWarned.size >= WRITE_DRIFT_WARNED_MAX) {
			const first = writeDriftWarned.values().next().value; // diting F-10：FIFO 有界（长会话不无界增长）
			if (first !== undefined) writeDriftWarned.delete(first);
		}
		writeDriftWarned.add(signature);
		return `[amagi write·疑似漏层] 本次写入新建了中间目录 ${missingDirs.join("/")}，且${suffix}——若为路径漏层（少写一层）请核对目标位置；写入已生效，需迁移请移动后核验，确认新结构则忽略本注记（同层后续写入不再重复提示）。`;
	} catch { return null; /* lint-exempt:探测异常一律否掉——advisory 层零故障放大，绝不影响写盘 */ }
}
