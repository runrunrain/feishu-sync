/** selected 的任务交接视图。只从已过滤快照选取原文，不生成新的事实或请求独立授权。 */
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import * as path from "node:path";
import { err, ok, type Result } from "./contracts/view.ts";

export interface ContextEntry {
	id: string; role: string; text: string; paths: string[]; tool?: string; toolCallId?: string; at?: number;
	/** ev-20261101-7fffc6：机器消息来源（仅 role=custom 且投影携带时存在；旧宿主回退的 role=user
	 *  通知无此字段——身份不可结构回源，按既有回退投递并如实披露，不按正文前缀猜）。 */
	customType?: string;
	/** 机器来源任务/组句柄（details 里的真实标识，不互相冒充）。 */
	taskId?: string;
	runId?: string;
}
export interface HandoffEntry extends ContextEntry {
	kind: "user-requirement" | "tool-observation" | "leader-hypothesis" | "summary-unverified";
	sourceDigest: string;
	ranges: Array<{ from: number; to: number }>;
	evidenceFile: string;
	inlineComplete: boolean;
	/** 非空原文片段（工具行/用户句）省略数；不以格式重排冒充缺失。 */
	omittedParts?: number;
	omissionReason?: "selection" | "budget" | "selection+budget";
}
export interface HandoffArchive { version: 1; digest: string; entries: ContextEntry[] }
export interface SelectedHandoff {
	entries: HandoffEntry[]; archive: HandoffArchive;
	omitted: { noiseLines: number; duplicates: number; unselected: number; budget: number; longLinesBudget: number };
	estimatedTokens: number;
}
const START = "\n[Leader 证据原文·存档]\n", END = "\n[Leader 证据原文结束]\n";
const FOOTER = "\n[Leader 上下文快照结束]";
const SOFT_TOKENS = 4000, INLINE_BYTES = 48 * 1024, ARCHIVE_BYTES = 512 * 1024;
const hash = (text: string): string => createHash("sha256").update(text).digest("hex");
/** JSON 数组字节分解：含括号和分隔符，单条使用脱敏后的来源 id，不回显正文。 */
function budgetDescription(entries: ReadonlyArray<{ id: string; role: string }>, limit: number): string {
	const parts = entries.map(e => ({ id: e.id, role: e.role, bytes: Buffer.byteLength(JSON.stringify(e), "utf8") }));
	const total = 2 + Math.max(0, parts.length - 1) + parts.reduce((n, p) => n + p.bytes, 0);
	const largest = parts.toSorted((a, b) => b.bytes - a.bytes);
	return `实际 ${total}B / 上限 ${limit}B（UTF-8 JSON 数组；括号及分隔符 ${2 + Math.max(0, parts.length - 1)}B）；最大来源排序 ${JSON.stringify(largest)}`;
}
const generic = new Set(["the", "and", "for", "with", "this", "that", "task", "fix", "please", "current", "continue", "output", "修复", "问题", "任务", "当前", "继续", "请继续"]);
const requirement = /must|shall|never|do not|don['’]t|preserve|keep|require|acceptance|unchanged|without|禁止|不得|不能|必须|务必|要求|保留|保持|不改|不变|不动|不要|只能|仅允许|限制|只允许|严禁|兼容|验收|约束|撤销|取消|改为|改成|不再|允许|\[(?:constraint|约束):/i;
const routine = /(?:^|\s)(?:DEBUG|TRACE)(?=\s|:)|^\s*(?:\d{1,3}%|heartbeat\b|ping\b|pong\b)/i;
const acknowledgement = /^(?:请?继续|好的[，,]?继续|好|ok|continue)[。.!！\s]*$/i;

export function contextTerms(text: string): Set<string> {
	const terms = new Set(text.toLowerCase().match(/[a-z0-9_./-]{3,}/g) ?? []);
	for (const run of text.match(/[\p{Script=Han}]{2,}/gu) ?? []) for (let i = 0; i < run.length - 1; i++) terms.add(run.slice(i, i + 2));
	for (const word of generic) terms.delete(word);
	return terms;
}
/** 软预算估计，不是模型 tokenizer 计量，也不裁剪必需用户约束；实际用量由原生 usage 统计。 */
export function estimateHandoffTokens(text: string): number {
	const han = text.match(/[\p{Script=Han}]/gu)?.length ?? 0;
	return Math.ceil((text.length - han) / 4 + han * 1.2);
}
function overlap(text: string, query: Set<string>): number {
	return [...contextTerms(text)].filter(t => query.has(t)).length;
}
function units(entry: ContextEntry): Array<{ text: string; sourceLine: number }> {
	return entry.text.split(/\r?\n/).flatMap((line, index) =>
		(entry.role === "toolResult" ? [line] : line.split(/(?<=[。！？；])\s*/u)).map(text => ({ text, sourceLine: index + 1 })));
}
function kindOf(entry: ContextEntry): HandoffEntry["kind"] {
	return entry.role === "user" ? "user-requirement" : entry.role === "toolResult" ? "tool-observation" : entry.role === "assistant" ? "leader-hypothesis" : "summary-unverified";
}
function foreignScope(text: string, sourceCwd: string, query: Set<string>): boolean {
	// 仅识别明确指向其他工作区的要求；无法确定范围的硬约束保守保留，不假装已完成语义判定。
	const scopes = [...text.matchAll(/(?:项目|project|workspace)\s*[:：=]?\s*(\/[^\s，。；;"']+)/gi)].map(m => m[1]!);
	return scopes.length > 0 && scopes.every(p => !p.startsWith(`${sourceCwd}${path.sep}`) && p !== sourceCwd
		&& ![...query].some(q => q === p.toLowerCase() || q.startsWith(`${p.toLowerCase()}/`)));
}

export function buildSelectedHandoff(entries: ContextEntry[], task: string, inputPaths: readonly string[], refs: readonly string[], matches: (entry: ContextEntry, ref: string) => boolean, sourceCwd: string): Result<SelectedHandoff> {
	const query = contextTerms([task, ...inputPaths].join("\n"));
	const omitted = { noiseLines: 0, duplicates: 0, unselected: 0, budget: 0, longLinesBudget: 0 };
	const candidates: Array<{ entry: ContextEntry; lines: string[]; sourceLines: number[]; selected: number[]; score: number; explicit: boolean; mandatory: boolean; position: number }> = [];
	const lastUser = entries.findLastIndex(e => e.role === "user" && !acknowledgement.test(e.text.trim()));
	for (const [position, entry] of entries.entries()) {
		const explicit = refs.some(ref => matches(entry, ref));
		const parts = units(entry), lines = parts.map(p => p.text), score = overlap(entry.text, query);
		const sourceMatch = entry.paths.some(p => inputPaths.some(input => path.resolve(sourceCwd, input) === p));
		let selected = lines.flatMap((line, index) => {
			if (!line.trim()) return [];
			if (entry.role !== "user" && routine.test(line) && !/\b(?:ERROR|FATAL|FAIL(?:ED)?)\b|错误|失败/i.test(line)) { omitted.noiseLines++; return []; }
			if (foreignScope(line, sourceCwd, query)) return [];
			if (entry.role === "user") return explicit || requirement.test(line) || overlap(line, query) > 0 || (position === lastUser && !acknowledgement.test(line.trim())) ? [index] : [];
			if (refs.length && !explicit) return [];
			return overlap(line, query) > 0 || sourceMatch || explicit ? [index] : [];
		});
		// 有效要求中的指代不能脱离紧邻的对象定义，仍只取用户原话，不补写解释。
		if (entry.role === "user") for (const index of [...selected]) {
			if (/^(?:其|该|这些|上述|前述|此|它|this\b|that\b|these\b|those\b)/i.test(lines[index]!.trim()) && lines[index - 1]?.trim() && !foreignScope(lines[index - 1]!, sourceCwd, query)) selected.push(index - 1);
		}
		selected = [...new Set(selected)].sort((a, b) => a - b);
		// 工具观察保留命中行的局部相邻数据和调用范围；不再继承相邻的 assistant 消息。
		if (entry.role === "toolResult" && selected.length) {
			const expanded = new Set(selected.toSorted((a, b) => overlap(lines[b]!, query) - overlap(lines[a]!, query) || a - b).slice(0, 12));
			for (const index of [...expanded]) for (const near of [index - 1, index + 1]) if (lines[near]?.trim() && !routine.test(lines[near]!)) expanded.add(near);
			if (entry.tool) expanded.add(0);
			selected = [...expanded].sort((a, b) => a - b);
		}
		if (!selected.length && !explicit) { omitted.unselected++; continue; }
		candidates.push({ entry, lines, sourceLines: parts.map(p => p.sourceLine), selected, score: score + (sourceMatch ? 8 : 0), explicit, mandatory: entry.role === "user" || explicit, position });
	}
	// 相同的显式约束标识以后一次用户声明为准；不猜测自然语言矛盾的含义，保留来源顺序供判断。
	const latestConstraint = new Map<string, string>();
	for (const c of candidates) if (c.entry.role === "user") for (const i of c.selected) {
		const id = c.lines[i]!.match(/^\s*\[(?:constraint|约束):([^\]]+)\]/i)?.[1];
		if (id) latestConstraint.set(id, `${c.position}:${i}`);
	}
	for (const c of candidates) if (c.entry.role === "user") c.selected = c.selected.filter(i => {
		const id = c.lines[i]!.match(/^\s*\[(?:constraint|约束):([^\]]+)\]/i)?.[1];
		return !id || latestConstraint.get(id) === `${c.position}:${i}`;
	});
	const ranked = candidates.filter(c => c.selected.length || c.explicit).sort((a, b) => Number(b.mandatory) - Number(a.mandatory) || b.score - a.score || b.position - a.position);
	const chosen: typeof candidates = [], seen = new Set<string>();
	let ordinary = 0;
	for (const c of ranked) {
		if (!c.mandatory && ordinary >= 8) { omitted.unselected++; continue; }
		const digest = hash(JSON.stringify([c.entry.role, c.entry.paths, c.entry.text]));
		if (seen.has(digest)) { omitted.duplicates++; continue; }
		seen.add(digest); chosen.push(c); if (!c.mandatory) ordinary++;
	}
	chosen.sort((a, b) => a.position - b.position);
	const originals: ContextEntry[] = [];
	const pending: Array<{ candidate: typeof candidates[number]; full: HandoffEntry; reference: HandoffEntry }> = [];
	for (const c of chosen) {
		if (Buffer.byteLength(JSON.stringify([...originals, c.entry]), "utf8") > ARCHIVE_BYTES) {
			if (c.mandatory) return err("context-too-large", `selected 原文存档超限：${budgetDescription([...originals, c.entry], ARCHIVE_BYTES)}；未截断、未派发，请改用显式输入引用大资料`, ["contextRefs"]);
			omitted.budget++; continue;
		}
		const evidenceFile = `evidence-${String(originals.length + 1).padStart(3, "0")}.txt`;
		originals.push(c.entry);
		const nonempty = c.lines.map((line, i) => line.trim() ? i : -1).filter(i => i >= 0);
		const complete = nonempty.every(i => c.selected.includes(i));
		// 全部内容都在时直接保留原字节（含换行），避免只因分句重排而错误声明“不完整”。
		const text = complete ? c.entry.text : c.selected.map(i => c.lines[i]).join("\n");
		const ranges = complete ? [{ from: 1, to: c.entry.text.split(/\r?\n/).length }]
			: [...new Set(c.selected.map(i => c.sourceLines[i]!))].map(line => ({ from: line, to: line }));
		const omittedParts = nonempty.filter(i => !c.selected.includes(i)).length;
		const base = { ...c.entry, kind: kindOf(c.entry), sourceDigest: hash(c.entry.text), evidenceFile };
		const full: HandoffEntry = { ...base, text: text || "原文已存档；按任务需要读取此条证据。", ranges, inlineComplete: complete,
			...(omittedParts ? { omittedParts, omissionReason: "selection" as const } : {}) };
		const scopeLine = c.entry.tool && c.lines[0]?.startsWith("工具 ") && c.lines[0].length <= 1600 ? c.lines[0] : undefined;
		const reference: HandoffEntry = { ...base, text: `${scopeLine ? scopeLine + "\n" : ""}原文已存档；按任务需要读取此条证据。`, ranges: scopeLine ? [{ from: 1, to: 1 }] : [], inlineComplete: false,
			omittedParts: nonempty.length - (scopeLine ? 1 : 0), omissionReason: omittedParts ? "selection+budget" : "budget" };
		pending.push({ candidate: c, full, reference });
	}
	// 先为用户要求和全部恢复索引留位，再按来源顺序分配剩余预算。用户要求不受软预算裁剪。
	const result = pending.map(p => p.candidate.entry.role === "user" ? p.full : p.reference);
	const sizeOf = (entries: HandoffEntry[]): number => Buffer.byteLength(JSON.stringify(entries), "utf8");
	if (sizeOf(result) > INLINE_BYTES) return err("context-too-large", `selected 用户要求与来源索引超过交接上限：${budgetDescription(result, INLINE_BYTES)}；未截断、未派发，请缩小任务或来源`, ["contextRefs"]);
	for (const [index, p] of pending.entries()) {
		if (p.candidate.entry.role === "user") continue;
		const proposed = result.with(index, p.full);
		// 相关长行按完整片段预算决定是否内联，不按 1600 字符机械剔除，不截断行内事实。
		if (estimateHandoffTokens(JSON.stringify(proposed)) <= SOFT_TOKENS && sizeOf(proposed) <= INLINE_BYTES) result[index] = p.full;
		else {
			omitted.budget++;
			omitted.longLinesBudget += p.candidate.selected.filter(i => p.candidate.lines[i]!.length > 1600).length;
		}
	}
	const tokens = estimateHandoffTokens(JSON.stringify(result));
	const archive = { version: 1 as const, digest: hash(JSON.stringify(originals)), entries: originals };
	return ok({ entries: result, archive, omitted, estimatedTokens: tokens });
}

/** 原文与交接视图一起冻结进 assignment，内核/schema/digest 口径无需新增字段。 */
export function freezeSelectedEvidence(assignment: string, archive?: HandoffArchive): string {
	if (!archive?.entries.length) return assignment;
	const at = assignment.indexOf(FOOTER);
	if (at < 0) throw new Error("selected 缺少交接边界");
	return assignment.slice(0, at) + START + JSON.stringify(archive) + END + assignment.slice(at);
}

/** 只在正式启动时物化冻结原文。预检零写入，子端提示不承载完整原文；失败走原启动失败收口。 */
export function materializeSelectedEvidence(assignment: string, cwd: string, taskId: string): string {
	if (!assignment.startsWith("[Leader 上下文快照·历史资料]\n")) return assignment;
	const start = assignment.indexOf(START), footer = assignment.indexOf(FOOTER);
	if (start < 0 || start > footer) return assignment;
	const end = assignment.indexOf(END, start);
	if (end < 0 || end > footer) throw new Error("selected 原文边界损坏");
	const archive = JSON.parse(assignment.slice(start + START.length, end)) as HandoffArchive;
	if (archive.version !== 1 || !Array.isArray(archive.entries) || archive.digest !== hash(JSON.stringify(archive.entries))) throw new Error("selected 原文指纹不匹配");
	if (!/^[a-zA-Z0-9-]+$/.test(taskId)) throw new Error("非法上下文任务标识");
	const root = fs.realpathSync(cwd);
	let dir = root;
	for (const part of ["amagi-task", taskId, "context-evidence"]) {
		dir = path.join(dir, part);
		try { fs.mkdirSync(dir, { mode: 0o700 }); } catch (e) { if ((e as NodeJS.ErrnoException).code !== "EEXIST") throw e; }
		const stat = fs.lstatSync(dir);
		if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error("上下文存档目录不是安全的工作区目录");
	}
	for (const [i, entry] of archive.entries.entries()) {
		const file = path.join(dir, `evidence-${String(i + 1).padStart(3, "0")}.txt`);
		// ev-20261101-7fffc6：来源元数据含机器来源（customType/taskId/runId，存在才写）——回源不丢。
		const content = `${JSON.stringify({ id: entry.id, role: entry.role, toolCallId: entry.toolCallId, paths: entry.paths, ...(entry.customType ? { customType: entry.customType } : {}), ...(entry.taskId ? { taskId: entry.taskId } : {}), ...(entry.runId ? { runId: entry.runId } : {}), sourceDigest: hash(entry.text) })}\n${entry.text}`;
		let fd: number;
		try { fd = fs.openSync(file, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_EXCL | (fs.constants.O_NOFOLLOW || 0), 0o400); }
		catch (error) {
			if ((error as NodeJS.ErrnoException).code !== "EEXIST" || fs.lstatSync(file).isSymbolicLink() || fs.readFileSync(file, "utf8") !== content) throw error;
			continue;
		}
		try { fs.writeFileSync(fd, content); } finally { fs.closeSync(fd); }
	}
	return assignment.slice(0, start) + `\n[证据存档目录] ${dir}\n仅当当前任务所需信息在片段中缺失时，用 read 读取相应 evidenceFile；inlineComplete=true 无需为补齐格式回读，false 只表示还有 omittedParts 个原文片段未内联，不代表当前答案缺失。首行为来源元数据，后续为派发时原文；ranges 是原文定位（存档文件加1行），行内节选不代表整行全文。sourceDigest 只证明归档观察的身份，不证明当前文件仍未变化；需要当前状态或来源有效性未知时，可按必要范围 fresh read。\n` + assignment.slice(end + END.length);
}
