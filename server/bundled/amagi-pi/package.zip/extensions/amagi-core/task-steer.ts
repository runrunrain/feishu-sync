/**
 * task-steer.ts — v2.8.8：运行中 steer 通道（主上需求：派发后 Leader 可以及时修正子 Agent 方向）。
 * v2.9.x（ev-20260930-0dd26f/R6）：通道文件层（读写/解析/活跃集/精确状态投影/GC）拆出至
 * task-steer-channel.ts（零 registry/kernel/recovery 依赖）；本文件保留 steerTask 编排与子进程注入
 * 注册，并重导出既有公共函数保持消费者兼容（task-facets/tests 的 import 面零变化）。
 *
 * 设计边界（与既有铁律的关系，v2.8.8 原文保留）：
 * - spec 冻结不动摇：任务书仍是契约事实（digest 口径不变）；steer 是**附加通信通道**，不进
 *   TaskSpec、不触发内核状态迁移（执行/结算/接受三轴零变化）——审计事实落在通道文件本身。
 * - 通道文件：`<amagiData>/task-steer/<taskId>.jsonl`（append-only，与 task-writes 同款目录惯例）。
 *   两类行：`{kind:"steer",seq,at,message}`（Leader 写）与 `{kind:"ack",seq,at,pid}`（子进程首注入回执）。
 * - 子进程侧注入：`pi.on("context")`（每 provider 请求前触发）读取通道，把全部活跃 steer 以固定段落
 *   追加到最后一条 user message（与 context-event.ts A2/C2 同款）。注入为 per-request 幂等重写——
 *   调整对模型**持续可见直至本任务结束**。无新消息时零开销（statSync ENOENT 快速路径）。
 * - 送达语义：queued 任务在首个 provider 请求前送达；running 任务在下一个模型请求前送达；
 *   blocked/终态拒绝（那是 task_resume 的领地）。rpc 后端拒绝（rpc_task 已有 adjust 通道）。
 * - env 对齐：AMAGI_DATA_DIR 透传子进程（task-run.ts ENV_WHITELIST）。
 *
 * v2.9.x pending 语义修正（R6 根因）：SteerResult.pending/文案改用精确投影（readSteerChannelSnapshot）
 * ——活跃预算可能淘汰旧未注入 steer，较新 seq 的 ack 不能证明旧 seq 曾注入；成功文案只对
 * pendingActive 承诺「下个模型请求前注入」，inactiveUnacked 明示已被淘汰不会自动注入。
 */

import * as fs from "node:fs";
import { registry, type TaskStatus } from "./task-registry.ts";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import {
	activeSteers,
	appendSteerMessage,
	parseSteerChannel,
	readSteerChannelSnapshot,
	steerChannelFile,
	type AckEntry,
	type SteerChannelEntry,
	type SteerEntry,
} from "./task-steer-channel.ts";

// 重导出既有公共面（消费者兼容：task-facets/tests 直接从本模块 import 的符号零变化），
// 另透出 R6 新面（精确快照/单行渲染/GC 常量与类型）供组合根/查询面消费。
export {
	steerDir,
	steerChannelFile,
	parseSteerChannel,
	parseSteerChannelText,
	appendSteerMessage,
	activeSteers,
	readSteerChannelState,
	readSteerChannelSnapshot,
	formatSteerChannelLine,
	sweepSteerChannels,
	findSteerChannelReclaim,
	steerChannelGcEnabled,
	resetSteerChannelForTest,
	STEER_CHANNEL_MIN_AGE_DEFAULT_MS,
	STEER_CHANNEL_TTL_DEFAULT_MS,
	STEER_CHANNEL_MAX_FILES_DEFAULT,
	STEER_CHANNEL_SWEEP_INTERVAL_MS,
} from "./task-steer-channel.ts";
export type {
	SteerEntry,
	AckEntry,
	SteerChannelEntry,
	SteerChannelState,
	SteerChannelSnapshot,
	SteerChannelLifecycleClass,
	SteerChannelClassifier,
	SteerChannelGcEvent,
	SteerChannelSweepResult,
	SteerChannelSweepOpts,
} from "./task-steer-channel.ts";

// ─────────────────────────────────────────────────────────────────────────────
// Leader 侧：steerTask（task_control steer 动作编排）
// ─────────────────────────────────────────────────────────────────────────────

const STEER_TERMINAL: ReadonlySet<TaskStatus> = new Set(["done", "error", "answered", "cancelled", "truncated", "resolved-external"]);

export interface SteerResult {
	ok: boolean;
	taskId: string;
	status: TaskStatus | "unknown";
	message: string;
	seq?: number;
	/** 未注入合计（精确：未找到对应有效 ack 的 steer 数 = pendingActive + inactiveUnacked）。 */
	pending?: number;
	/** 活跃集中未注入数——只有这部分承诺「下个模型请求前注入」。 */
	pendingActive?: number;
	/** 被活跃字节预算淘汰且从未注入的记录数——不会自动注入（如需传达用 task_resume 新一轮）。 */
	inactiveUnacked?: number;
}

/** 对 queued/running 的 json 后端任务投递运行中调整；blocked/answering/终态/rpc 各自拒绝并给正确去向。 */
export function steerTask(taskId: string, message: string): SteerResult {
	const rec = registry.get(taskId);
	if (!rec) return { ok: false, taskId, status: "unknown", message: `任务不存在: ${taskId}` };
	if (rec.backend === "rpc") {
		return { ok: false, taskId, status: rec.status, message: "RPC 池任务不经此通道——用 rpc_task({ action: \"adjust\", taskId, task }) 运行中调整" };
	}
	if (STEER_TERMINAL.has(rec.status)) {
		return { ok: false, taskId, status: rec.status, message: `任务已终态（${rec.status}），不可 steer；新方向请 task_submit 派发新任务` };
	}
	if (rec.status === "blocked") {
		return { ok: false, taskId, status: rec.status, message: `子进程已退出等待作答（blocked）——steer 无法送达已退出进程；用 task_resume({ handle, message }) 携带调整内容续接（resume 会冻结为新一轮任务书）` };
	}
	if (rec.status === "answering") {
		return { ok: false, taskId, status: rec.status, message: `作答轮运行中（续接轮有自己的新 taskId，本句柄通道无活跃进程）——等本轮终态后对新句柄 steer，或 task_resume 传完整指令` };
	}
	// queued / running：投递（queued = 首个 provider 请求前送达，等价开跑前修正方向）
	const appended = appendSteerMessage(taskId, message);
	if (!appended.ok) return { ok: false, taskId, status: rec.status, message: appended.error };
	// R6：精确投影（旧 seq>maxAckSeq 估算弃用——预算淘汰场景会虚假归零）
	const snap = readSteerChannelSnapshot(taskId);
	const pending = snap.availability === "readable" ? snap.pending : 0;
	const pendingActive = snap.availability === "readable" ? snap.pendingActive : 0;
	const inactiveUnacked = snap.availability === "readable" ? snap.inactiveUnacked : 0;
	return {
		ok: true,
		taskId,
		status: rec.status,
		seq: appended.seq,
		pending,
		pendingActive,
		inactiveUnacked,
		message: rec.status === "queued"
			? `已入通道（#${appended.seq}；任务排队中，将在首个模型请求前注入）`
			: `已入通道（#${appended.seq}；子 Agent 下一模型请求前注入，此后持续可见至本任务结束）`,
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// 子进程侧：context 事件注入（AMAGI_TASK_ID 定位通道）
// ─────────────────────────────────────────────────────────────────────────────

/** 注入段（固定框架；与已完成工作冲突时按调整继续，不重做无冲突部分）。 */
export function formatSteerBlock(steers: readonly SteerEntry[]): string {
	const lines = steers.map((s) => `〔调整 #${s.seq}〕${s.message}`);
	return [
		"--- AMAGI 运行中调整（Leader steer；任务书其余边界与产物要求不变）---",
		...lines,
		"--- 与已完成工作冲突的部分按本调整修正方向继续；无冲突部分不必重做 ---",
	].join("\n");
}

/** 追加注入到最后一条 user message（与 context-event.ts A2/C2 同款：保留 content 结构）。 */
function appendToLastUser(messages: any[], injection: string): any[] {
	const result = [...messages];
	for (let j = result.length - 1; j >= 0; j--) {
		if (result[j]?.role === "user") {
			const orig = result[j];
			if (typeof orig.content === "string") result[j] = { ...orig, content: orig.content + injection };
			else if (Array.isArray(orig.content)) result[j] = { ...orig, content: [...orig.content, { type: "text", text: injection }] };
			else result[j] = { ...orig, content: [{ type: "text", text: String(orig.content ?? "") }, { type: "text", text: injection }] };
			return result;
		}
	}
	result.push({ role: "user", content: injection });
	return result;
}

/**
 * 子进程注册 steer 注入（无 AMAGI_TASK_ID / 非 subagent no-op）。
 * ack 语义：每条 steer 首次注入追加 `{kind:"ack"}` 行（Leader 侧 pending 观测）；
 * ack 写失败不阻断注入（下次 context 事件重试 ack——注入本身幂等重写，无重复风险）。
 * 活跃集与 Leader 侧状态投影共享同一预算函数（task-steer-channel.activeSteers，R6）。
 */
export function registerSteerInjection(pi: ExtensionAPI): void {
	const taskId = process.env.AMAGI_TASK_ID;
	if (!taskId || process.env.AMAGI_SUBAGENT !== "1" || !/^[A-Za-z0-9._-]+$/.test(taskId)) return;
	const file = steerChannelFile(taskId);
	const acked = new Set<number>();
	let ackedHydrated = false;

	pi.on("context", (event: { messages: any[] }, _ctx: unknown): any => {
		const messages = event?.messages;
		if (!Array.isArray(messages)) return undefined;
		try { fs.statSync(file); } catch { /* lint-exempt:无通道文件快速路径（常态零开销） */ return undefined; }
		const { entries } = parseSteerChannel(file);
		if (!ackedHydrated) {
			for (const e of entries) if (e.kind === "ack") acked.add(e.seq);
			ackedHydrated = true;
		}
		const steers = activeSteers(entries);
		if (steers.length === 0) return undefined;
		// ack 新 seq（尽力而为；失败静默——下次重试）
		try {
			for (const s of steers) {
				if (acked.has(s.seq)) continue;
				fs.appendFileSync(file, `${JSON.stringify({ kind: "ack", seq: s.seq, at: Date.now(), pid: process.pid } as AckEntry)}\n`, "utf8");
				acked.add(s.seq);
			}
		} catch { /* lint-exempt:ack 失败不阻断注入 */ }
		const injection = `\n\n${formatSteerBlock(steers)}`;
		return { messages: appendToLastUser(messages, injection) };
	});
}
