/**
 * lsp-types.ts — LSP 支持共享类型（workflow lsp-support §设计契约 A1）。
 *
 * 定义条目对齐 oh-my-pi packages/coding-agent/src/lsp/types.ts 的 ServerConfig 子集：
 * 只保留 amagi V1 需要的字段（command/args/fileTypes/rootMarkers/languageId/initOptions/disabled）。
 * lsp-client.ts 在 A1 落盘前自持同构类型；B1 装配批将其切到本文件的 type import。
 */

export interface LspServerDefinition {
	/** 服务器名（defaults.json key 或用户自定义 key），同时用作池缓存键。 */
	name: string;
	/** 二进制名（PATH/本地 bin 查找）或含路径的可执行文件。 */
	command: string;
	args?: string[];
	/** 关联文件类型（.ts 形式，点前缀；比较时两侧统一点前缀+大小写不敏感）。 */
	fileTypes?: string[];
	/** 项目根标记：与 cwd 直接条目（不递归）交集命中才候选；支持 * 单层通配（如 *.cabal）。 */
	rootMarkers?: string[];
	/** LSP languageId；缺省由客户端回退 plaintext。 */
	languageId?: string;
	/** ev-20260924-895eac：按扩展名的 languageId 映射（键=点前缀扩展名如 ".tsx"，值=languageId）。
	 *  同一服务器登记多种文件类型但 languageId 不同（typescript vs typescriptreact）时必须用它；
	 *  解析链 languageIds[ext] → languageId → plaintext，只配 languageId 的定义行为不变。 */
	languageIds?: Record<string, string>;
	/** initialize 的 initializationOptions。 */
	initializationOptions?: Record<string, unknown>;
	/** true 时该服务器（含默认条目被覆盖为 disabled）从检测中剔除。 */
	disabled?: boolean;
}

/** amagi.json lsp.servers.<name> 覆盖项：任意字段部分覆盖（浅合并，键级优先）。 */
export type LspServerOverride = Partial<Omit<LspServerDefinition, "name">> & {
	disabled?: boolean;
};

/** amagi.json `lsp` 段运行时形态（全局 + 项目合并后）。 */
export interface LspRuntimeConfig {
	enabled: boolean;
	autoDetect: boolean;
	readOnly: boolean;
	idleTimeoutMs: number;
	servers: Record<string, LspServerOverride>;
}

/** detectLspServers 返回的启用服务器：定义 + 二进制解析结果。 */
export interface DetectedLspServer extends LspServerDefinition {
	/** 解析后的绝对可执行路径（spawn 用它，不再依赖 PATH）。 */
	commandPath: string;
}

export const DEFAULT_LSP_CONFIG: LspRuntimeConfig = {
	enabled: true,
	autoDetect: true,
	readOnly: false,
	idleTimeoutMs: 300_000,
	servers: {},
};
