/**
 * workflow-board.ts — T2-1：workflow 看板 overlay（README §8.1；执行计划 T2-1）。
 *
 * `ctx.ui.custom()` 全屏模态看板：角色状态矩阵（12 角色×运行任务）、任务进度
 * （running 滚动窗口末条+时长）、blocked 队列（问题摘要+等待时长）、最近结算区
 * （done/error/cancelled/answered 终态新到旧，最多 8 条）。选择列表顺序固定为
 * running+blocked+settled，Enter 钻取会话面板（终态显示结果/根因/取消原因）。
 * 快捷键 ctrl+shift+w 开合；非 TUI no-op；session 生命周期内状态自清（M5 模式：模块内订阅）。
 *
 * dist 机制证据（node_modules/@earendil-works/pi-coding-agent/dist 与 pi-tui dist）：
 * - types.d.ts L115-130 `custom<T>(factory(tui, theme, keybindings, done), options?)`：
 *   "Show a custom component with keyboard focus"；options { overlay, overlayOptions, onHandle }；
 *   done(result) 关闭并回值（docs/extensions.md L2664-2681）。
 * - 全屏形态：docs/extensions.md L2683-2714 Overlay Mode——`{ overlay: true, overlayOptions }`
 *   浮层不清屏；OverlayOptions（pi-tui tui.d.ts L76-103）：width/maxHeight 支持百分比、anchor、margin。
 * - Component 接口（pi-tui tui.d.ts L10-28）：`render(width): string[]` + `handleInput?(data)`
 *   + `invalidate()`，可选 `dispose()`——本模块以结构对象实现，**不新增 pi-tui 依赖**。
 * - 键盘：handleInput 收原始终端数据，Escape="\x1b"；快捷键组件聚焦期间输入归组件，
 *   故看板自闭合键（Esc/q/r）在组件内处理。
 * - 实时：TUI.requestRender(force?)（pi-tui tui.d.ts L211）+ render() 每次现取 registry；
 *   组件内 unref 定时器驱动重渲，dispose 清理。
 * - 非 TUI：docs/extensions.md L2863——RPC 模式 custom() 返回 undefined；仍以 mode 守卫（M5 约定）。
 * - 键位：docs/keybindings.md L31-139 无 ctrl+shift+w；与已用 ctrl+shift+r/b 不冲突；
 *   dist runner.js getShortcuts() 冲突诊断为兜底。
 * - session 生命周期：interactive-mode.js L268-270/1500-1527——session 失效 pi 自动 resetExtensionUI
 *   （清 widget/overlay）；本模块订阅 session_start/shutdown 复位开合状态（M5-b 同模式）。
 *
 * 接线说明（index.ts 统一接线需要的最小改动，本任务不改 index.ts）：
 *   1) import：import { registerWorkflowBoard } from "./workflow-board.ts";
 *   2) amagiCore() 内（agents 就绪后，与 registerAmagiShortcuts 同处）：
 *        registerWorkflowBoard(pi, { agents, taskRegistry: registry });
 *   无其他接线：session 自清模块内订阅；与 status-ui/shortcuts 仅共享 registry 只读面，模块解耦。
 */

import type { AgentConfig } from "./agents-loader.ts";
import type { TaskRecord, TaskStatus } from "./task-registry.ts";
import { formatDuration, trimDisplay, modelWithThinking } from "./status-ui.ts";
import { fmtKey, type ThemeLike as SharedThemeLike } from "./ui-shared.ts";
import { DEFAULT_UI_KEYS, readUiConfig } from "./ui-config.ts";
import { createViewerComponent } from "./session-viewer.ts";
import { axisLabelOf, NO_RECEIPT_NOTE, safeAxisOf, type TaskAxisOf, type TaskAxes } from "./panel-model.ts";

// ─────────────────────────────────────────────────────────────────────────────
// 类型（结构子集，mock 友好）
// ─────────────────────────────────────────────────────────────────────────────

export interface BoardCtx {
	mode: string;
	ui: {
		custom<T>(
			factory: (tui: unknown, theme: unknown, keybindings: unknown, done: (result: T) => void) => unknown,
			options?: { overlay?: boolean; overlayOptions?: Record<string, unknown> },
		): Promise<T>;
	};
}

export interface BoardPi {
	registerShortcut(shortcut: string, options: { description?: string; handler: (ctx: BoardCtx) => Promise<void> | void }): void;
	on(event: string, handler: (event: unknown, ctx: BoardCtx) => void): void;
}

export interface BoardDeps {
	agents: AgentConfig[];
	taskRegistry: { list(): Readonly<TaskRecord>[]; onChange?(fn: () => void): () => void };
	/** 键位覆盖；默认 ctrl+shift+w。 */
	key?: string;
	/** 看板打开时的实时刷新间隔 ms，默认 2000；测试可注入。 */
	refreshMs?: number;
	/** v1.5.248：amagi.json ui.keys 读取目录（缺省 process.cwd；既有实现已引用但接口漏声明）。 */
	configCwd?: string;
	/** K8c 只读三轴供给（DI）：结算区验收轴标注（执行结束≠已验收）；缺省接 registry 投影（无验收轴→无标签），
	 *  组合根接内核视图。观察面只读，关闭 UI 不影响执行。 */
	axisOf?: TaskAxisOf;
}

/** v1.5.218：主键 ⌥W（mac 可达优先），legacy ctrl+shift+w 兼容注册；amagi.json ui.keys.board 覆盖。 */
export const DEFAULT_BOARD_KEY = DEFAULT_UI_KEYS.board[0];
export const LEGACY_BOARD_KEYS = DEFAULT_UI_KEYS.board.slice(1);
const DEFAULT_REFRESH_MS = 2000;

// ─────────────────────────────────────────────────────────────────────────────
// 数据模型（纯函数，可测）
// ─────────────────────────────────────────────────────────────────────────────

export interface AgentRow {
	name: string;
	agentType: string;
	runningCount: number;
	blockedCount: number;
	/** 最久运行任务的摘要+时长文本（无运行任务时 undefined）。 */
	latest?: string;
}

export interface RunningRow { taskId: string; agent: string; mode?: string; model?: string; summary: string; duration: string; activity: string; runId?: string; nodeId?: string; }
export interface BlockedRow { taskId: string; agent: string; summary: string; wait: string; question: string; runId?: string; nodeId?: string; /** diting 增审 Major-3：needs-handoff 行用 ↻ 待接手展示（非「?」问题语义）。 */ blockReason?: "questions" | "needs-handoff"; /** ev-20260908-f189e7：等待超阈值（BLOCKED_STALE_HINT_MS）时渲染「建议处置」提示（区分正常等待 vs 疑似遗忘/卡死）。 */ stale?: boolean; }
/** 最近结算行：终态（done/error/cancelled/answered/resolved-external）任务摘要，按结算时刻新到旧。 */
export interface SettledRow { taskId: string; agent: string; status: TaskStatus; summary: string; ago: string; runId?: string; nodeId?: string; /** K8c 三轴标签（axisOf 供给可用时携带；「执行结束，待接受」≠已完成验收）。V3：终态而无标签（legacy 无回执）时携 compatNote，不补绿。 */ axisLabel?: string; compatNote?: string; }

export interface BoardModel {
	agentRows: AgentRow[];
	running: RunningRow[];
	blocked: BlockedRow[];
	settled: SettledRow[];
	counts: { running: number; blocked: number; done: number; error: number; cancelled: number; answered: number; truncated: number; resolvedExternal: number };
}

/** 最近结算区行数上限（终态新到旧取前 N 条）。 */
export const MAX_SETTLED_ROWS = 8;
const SETTLED_STATUS: Record<string, true> = { done: true, error: true, cancelled: true, answered: true, truncated: true, "resolved-external": true };

/** ev-20260908-f189e7：blocked 等待超阈值提示线（30 分钟）——超过后看板渲染「建议处置」提示，
 *  让读者区分「正常等待」与「疑似遗忘/卡死」（实战：derived-kb-sync 三节点 blocked 35m+ 驻留，
 *  主上误判插件卡死）。 */
export const BLOCKED_STALE_HINT_MS = 30 * 60_000;

function summaryOf(rec: Readonly<TaskRecord>): string {
	return rec.goal || rec.name || rec.taskId.slice(0, 12);
}

function lastActivityOf(rec: Readonly<TaskRecord>): string {
	const win = rec.activityWindow;
	if (!win || win.length === 0) return "等待首个动作…";
	const last = win[win.length - 1];
	return last.summary && last.summary !== last.type ? `${last.type}: ${last.summary}` : last.type;
}

/** blocked 行动项摘要（diting 增审 Major-3 中性展示）：handoff=待接手（resume，非提问）；
 *  questions=blockedQuestions 首条 > result 截断 > 占位。 */
function blockedQuestionOf(rec: Readonly<TaskRecord>): string {
	if (rec.blockReason === "needs-handoff") return "待接手（resume）：settle 产出窗口收口，本轮零写盘未开工——非提问";
	if (rec.blockedQuestions && rec.blockedQuestions.length > 0) return rec.blockedQuestions[0];
	if (rec.result) return trimDisplay(rec.result.replace(/\s+/g, " ").trim(), 120);
	return "（无问题摘要）";
}

/** 单行摘要：多行 result/error 折叠为单行（终端宽度截断交给 trimDisplay）。 */
function oneLineOf(value?: string): string {
	return value ? value.replace(/\s+/g, " ").trim() : "";
}

export function buildBoardModel(
	agents: AgentConfig[],
	tasks: Readonly<TaskRecord>[],
	now: number = Date.now(),
	opts: { axisOf?: TaskAxisOf } = {},
): BoardModel {
	// v2 批次B：queued（准入排队中）并入 running 桶展示——排队是真实在途状态；行内以 activity 文本区分。
	const running = tasks.filter((r) => r.status === "running" || r.status === "queued").sort((a, b) => a.startedAt - b.startedAt);
	const blocked = tasks.filter((r) => r.status === "blocked").sort((a, b) => (b.blockedAt || b.endedAt || b.startedAt) - (a.blockedAt || a.endedAt || a.startedAt));
	// 最近结算：终态四状态按结算时刻（endedAt > blockedAt > startedAt）新到旧，最多 MAX_SETTLED_ROWS 条（计数仍统计全量）。
	const settled = tasks.filter((r) => SETTLED_STATUS[r.status])
		.sort((a, b) => (b.endedAt || b.blockedAt || b.startedAt) - (a.endedAt || a.blockedAt || a.startedAt))
		.slice(0, MAX_SETTLED_ROWS);
	const done = tasks.filter((r) => r.status === "done").length;
	const error = tasks.filter((r) => r.status === "error").length;
	const cancelled = tasks.filter((r) => r.status === "cancelled").length;
	const answered = tasks.filter((r) => r.status === "answered").length;
	const truncated = tasks.filter((r) => r.status === "truncated").length;
	const resolvedExternal = tasks.filter((r) => r.status === "resolved-external").length;

	const agentRows: AgentRow[] = agents.map((a) => {
		const mine = running.filter((r) => r.agent === a.name);
		const myBlocked = blocked.filter((r) => r.agent === a.name);
		const oldest = mine[0]; // running 已按 startedAt 升序
		return {
			name: a.name,
			agentType: a.type,
			runningCount: mine.length,
			blockedCount: myBlocked.length,
			latest: oldest ? `${summaryOf(oldest)} ${formatDuration(now - oldest.startedAt)}` : undefined,
		};
	});

	return {
		agentRows,
		running: running.map((r) => ({
			taskId: r.taskId,
			agent: r.agent,
			mode: r.mode,
			model: r.model,
			summary: summaryOf(r),
			duration: formatDuration(now - r.startedAt),
			activity: r.status === "queued" ? "排队中（等待执行槽位）" : lastActivityOf(r),
			runId: r.runId,
			nodeId: r.nodeId,
		})),
		blocked: blocked.map((r) => ({
			taskId: r.taskId,
			agent: r.agent,
			summary: summaryOf(r),
			wait: formatDuration(now - (r.blockedAt || r.endedAt || r.startedAt)),
			question: blockedQuestionOf(r),
			blockReason: r.blockReason,
			stale: now - (r.blockedAt || r.endedAt || r.startedAt) >= BLOCKED_STALE_HINT_MS,
			runId: r.runId,
			nodeId: r.nodeId,
		})),
		settled: settled.map((r) => {
			const label = axisLabelOf(safeAxisOf(opts.axisOf, r.taskId));
			return {
				taskId: r.taskId,
				agent: r.agent,
				status: r.status,
				summary: summaryOf(r),
				ago: formatDuration(now - (r.endedAt || r.blockedAt || r.startedAt)),
				runId: r.runId,
				nodeId: r.nodeId,
				...(label !== undefined ? { axisLabel: label } : { compatNote: NO_RECEIPT_NOTE }),
			};
		}),
		counts: { running: running.length, blocked: blocked.length, done, error, cancelled, answered, truncated, resolvedExternal },
	};
}

// ─────────────────────────────────────────────────────────────────────────────
// 渲染（纯函数，可测；theme 可选，缺省无着色）
// ─────────────────────────────────────────────────────────────────────────────

type ThemeLike = { fg?(color: string, text: string): string } | undefined;

function paint(theme: ThemeLike, color: string, text: string): string {
	try { return theme?.fg ? theme.fg(color, text) : text; } catch { return text; }
}

/** 运行图身份紧凑标签：` [runId/nodeId]`（仅编排任务携带；宽度截断交给 trimDisplay）。 */
function graphSeg(runId?: string, nodeId?: string): string {
	if (!runId && !nodeId) return "";
	return ` [${[runId, nodeId].filter(Boolean).join("/")}]`;
}

/** 终态标签（定宽 9 列对齐）与配色。 */
const SETTLED_STYLE: Record<string, { label: string; color: string }> = {
	done: { label: "done", color: "success" },
	answered: { label: "answered", color: "success" },
	error: { label: "error", color: "error" },
	cancelled: { label: "cancelled", color: "muted" },
	truncated: { label: "trunc'd", color: "warning" },
	// ev-20260908-f189e7：已外部处置终态（非放弃——产物已在外部采用，与 cancelled 区分）
	"resolved-external": { label: "✅外部处置", color: "success" },
};

export function renderBoardLines(model: BoardModel, width: number, theme?: ThemeLike, sel?: { index?: number; interactive?: boolean }): string[] {
	const w = Math.max(24, width - 2);
	const lines: string[] = [];
	const hr = "─".repeat(Math.min(w, 60));

	const c = model.counts;
	lines.push(trimDisplay(paint(theme, "accent",
		`amagi workflow 看板 · ${c.running} 运行 · ${c.blocked} blocked · ${c.done} done · ${c.error} error · ${c.cancelled} cancelled · ${c.answered} answered · ${c.truncated} trunc'd${c.resolvedExternal > 0 ? ` · ${c.resolvedExternal} 外部处置` : ""}`), w));

	// ── 角色状态矩阵（12 角色全量，空闲置灰） ──
	lines.push(trimDisplay(paint(theme, "toolTitle", "角色矩阵"), w));
	for (const row of model.agentRows) {
		const name = row.name.padEnd(10).slice(0, 10);
		let cell: string;
		if (row.runningCount > 0) cell = paint(theme, "success", `▶${row.runningCount}`) + (row.latest ? ` ${row.latest}` : "");
		else if (row.blockedCount > 0) cell = paint(theme, "warning", `⏸${row.blockedCount} blocked`);
		else cell = paint(theme, "dim", "·");
		lines.push(trimDisplay(`  ${name} ${cell}`, w));
	}

	// 可选列表 = running + blocked + settled 联合（顺序固定，Enter 可钻取终态）；
	// index 映射：i < running.length → running[i]；次 blocked.length → blocked[j]；其余 → settled[k]
	const selIndex = sel?.index;

	// ── 任务进度（running 全量：滚动窗口末条 + 时长） ──
	lines.push(trimDisplay(paint(theme, "toolTitle", `任务进度（${model.running.length}）`), w));
	if (model.running.length === 0) lines.push(trimDisplay(paint(theme, "dim", "  （无运行中任务）"), w));
	for (const [i, r] of model.running.entries()) {
		const head = r.mode === "background" ? `${r.agent} [bg]` : r.agent;
		const modelSeg = r.model ? `${modelWithThinking(r.model)} · ` : "";
		const cursor = selIndex === i ? "▸ " : "  ";
		lines.push(trimDisplay(`${cursor}${head}${graphSeg(r.runId, r.nodeId)} · ${r.summary} · ${modelSeg}${r.duration}`, w));
		lines.push(trimDisplay(paint(theme, "muted", `    └ ${r.activity}`), w));
	}

	// ── blocked 队列（行动项摘要 + 等待时长；questions=? 待答 / handoff=↻ 待接手） ──
	lines.push(trimDisplay(paint(theme, "toolTitle", `blocked 队列（${model.blocked.length}）`), w));
	if (model.blocked.length === 0) lines.push(trimDisplay(paint(theme, "dim", "  （无待答任务）"), w));
	for (const [j, b] of model.blocked.entries()) {
		const cursor = selIndex === model.running.length + j ? "▸ " : "  ";
		// diting 增审 Major-3：handoff 中性展示——↻ 待接手（resume 接手开工），不用「?」问题语义
		const qSym = b.blockReason === "needs-handoff" ? "↻" : "?";
		lines.push(trimDisplay(paint(theme, "warning", `${cursor}${b.agent}${graphSeg(b.runId, b.nodeId)} · ${b.summary} · 等待 ${b.wait}`), w));
		lines.push(trimDisplay(`    ${qSym} ${b.question}`, w));
		// ev-20260908-f189e7：等待超阈值提示（区分正常等待 vs 疑似遗忘/卡死——实战三节点 blocked 35m+ 驻留被误判插件卡死）
		if (b.stale) lines.push(trimDisplay(paint(theme, "error", `    ⚠ 建议处置：等待答复已超 30m——若已在外部解决可 task({ cancel: "${b.taskId.slice(0, 8)}", resolve: "external" }) 收口，否则答复后 resume`), w));
	}

	// ── 最近结算（终态新到旧，最多 MAX_SETTLED_ROWS 条；定宽状态列 + 结算多久前） ──
	lines.push(trimDisplay(paint(theme, "toolTitle", `最近结算（${model.settled.length}）`), w));
	if (model.settled.length === 0) lines.push(trimDisplay(paint(theme, "dim", "  （暂无结算记录）"), w));
	const settledBase = model.running.length + model.blocked.length;
	for (const [k, s] of model.settled.entries()) {
		const cursor = selIndex === settledBase + k ? "▸ " : "  ";
		const style = SETTLED_STYLE[s.status] ?? { label: s.status, color: "muted" };
		// K8c：验收轴标注（执行结束≠已验收——done+unreviewed 显示「执行结束，待接受」）。
		// V3（§8.5 风险行「旧 UI 把 done 显示成成功」）：颜色随验收轴——已接受=success、检查失败=error、
		// 待接受/待结算/不完整=warning；无标签（legacy 无回执）中性 muted + 明确注记，未知字段不补绿。
		const axisSeg = s.axisLabel ? ` · ${s.axisLabel}` : ` · ${s.compatNote ?? NO_RECEIPT_NOTE}`;
		let axisColor = style.color;
		if (s.axisLabel) {
			if (s.axisLabel.includes("已接受")) axisColor = "success";
			else if (s.axisLabel.includes("已拒绝")) axisColor = "muted";
			else if (s.axisLabel.includes("检查失败")) axisColor = "error";
			else axisColor = "warning";
		} else {
			axisColor = "muted";
		}
		lines.push(trimDisplay(`${cursor}${paint(theme, axisColor, style.label.padEnd(9))} ${s.agent}${graphSeg(s.runId, s.nodeId)} · ${s.summary}${axisSeg} · ${s.ago}前`, w));
	}

	lines.push(trimDisplay(paint(theme, "dim", `${hr}`), w));
	lines.push(trimDisplay(paint(theme, "dim",
		sel?.interactive ? "j/k 选择 · ⏎ 任务面板 · v 完整会话 · r 刷新 · Esc/q 关闭" : "Esc/q 关闭 · r 刷新"), w));
	return lines;
}

/** 与 overlayOptions.maxHeight="85%"、margin=1 相同的可见行预算。 */
export function overlayViewportHeight(rows: unknown): number | undefined {
	if (typeof rows !== "number" || !Number.isFinite(rows) || rows <= 0) return undefined;
	return Math.max(1, Math.min(Math.floor(rows * 0.85), Math.floor(rows) - 2));
}

/**
 * pi 会直接 slice 超高 overlay 的尾部。由插件主动建立视口：始终保留标题/键位提示，
 * 并在选择项移出首屏时滚动到其双行内容，避免光标、blocked 队列和退出提示不可见。
 */
export function fitOverlayViewport(lines: string[], maxHeight: number | undefined, width: number): string[] {
	if (maxHeight === undefined || lines.length <= maxHeight) return lines;
	if (maxHeight === 1) return [lines[0]];
	if (maxHeight === 2) return [lines[0], lines.at(-1) ?? ""];
	const title = lines[0];
	const footer = lines[lines.length - 1];
	const body = lines.slice(1, -1);
	const bodyBudget = maxHeight - 2;
	let contentBudget = Math.max(1, bodyBudget - 1);
	const cursor = body.findIndex((line) => line.includes("▸ "));
	const focusEnd = cursor >= 0 ? Math.min(body.length - 1, cursor + 1) : 0;
	let start = focusEnd < contentBudget ? 0 : Math.max(0, focusEnd - Math.max(1, bodyBudget - 2) + 1);
	if (start > 0) contentBudget = Math.max(1, bodyBudget - 2);
	const end = Math.min(body.length, start + contentBudget);
	const viewport = [title];
	if (start > 0) viewport.push(trimDisplay(`↑ 上方 ${start} 行已隐藏（↑↓继续）`, Math.max(8, width - 2)));
	viewport.push(...body.slice(start, end));
	if (end < body.length) viewport.push(trimDisplay(`↓ 下方 ${body.length - end} 行已隐藏（↑↓继续）`, Math.max(8, width - 2)));
	viewport.push(footer);
	return viewport.length <= maxHeight ? viewport : [...viewport.slice(0, maxHeight - 1), footer];
}

// ─────────────────────────────────────────────────────────────────────────────
// 会话面板（钻取视图：单任务详情 + 最近行为窗口；纯函数，可测）
// ─────────────────────────────────────────────────────────────────────────────

/** HH:MM:SS 本地时刻（activityWindow ts 展示；task-tool safeTime 不可 import——反向依赖环）。 */
function hhmmss(ts: number): string {
	try {
		const d = new Date(ts);
		return [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, "0")).join(":");
	} catch { return "--:--:--"; }
}

export interface SessionViewOpts { width: number; now?: number; maxActivity?: number; /** K8c：三轴快照（供给可用时展示验收轴——执行结束≠已验收）。 */ axes?: Readonly<TaskAxes>; }

/**
 * 会话面板行：header（agent/状态/模型·思考强度/模式/时长）+ 任务 + 会话/轮次 + blocked 问题
 * / 终态详情（done·answered 结果摘要、error 根因、cancelled 取消原因+部分结果）
 * + 最近行为窗口（末 N 条正序，最新在底）+ 返回提示。详略得当：单任务全量关键信息。
 */
export function renderSessionLines(rec: Readonly<TaskRecord>, opts: SessionViewOpts, theme?: ThemeLike): string[] {
	const w = Math.max(40, opts.width - 2); // 与 renderBoardLines 同口径：预留 overlay 边距
	const now = opts.now ?? Date.now();
	const maxAct = opts.maxActivity ?? 12;
	const hr = "─".repeat(Math.min(w, 60));
	const dur = rec.status === "running"
		? formatDuration(now - rec.startedAt)
		: formatDuration((rec.endedAt || now) - rec.startedAt);
	const lines: string[] = [
		trimDisplay(paint(theme, "accent", `agent 会话面板 · ${rec.agent} · ${rec.status}`), w),
		trimDisplay(hr, w),
		trimDisplay(`任务: ${summaryOf(rec)}`, w),
		trimDisplay(`模型: ${modelWithThinking(rec.model) || "（默认/fallback）"} · 模式: ${rec.mode || "sync"} · 时长 ${dur}`, w),
		trimDisplay(`会话: ${rec.sessionId ? `${rec.sessionId.slice(0, 12)}…` : "（未建立）"} · resume 轮次: ${rec.rounds?.length ?? 0}`, w),
	];
	const axisLabel = axisLabelOf(opts.axes);
	if (axisLabel !== undefined) {
		lines.push(trimDisplay(paint(theme, axisLabel.includes("待接受") || axisLabel.includes("待结算") ? "warning" : "success", `三轴: ${axisLabel}（execution=${opts.axes!.execution} settlement=${opts.axes!.settlement} acceptance=${opts.axes!.acceptance}）`), w));
	}
	if (rec.status === "blocked") {
		// diting 增审 Major-3：handoff 中性展示——↻ 待接手，不用「?」问题语义
		const qSym = rec.blockReason === "needs-handoff" ? "↻" : "?";
		lines.push(trimDisplay(paint(theme, "warning", `${qSym} ${blockedQuestionOf(rec)}`), w));
	} else if (rec.status === "done" || rec.status === "answered") {
		lines.push(trimDisplay(paint(theme, "success", `结果: ${oneLineOf(rec.result) || "（无结果记录）"}`), w));
	} else if (rec.status === "resolved-external") {
		// ev-20260908-f189e7：外部处置终态详情（收口注记 + 不可 resume 说明）
		lines.push(trimDisplay(paint(theme, "success", `✅ 已外部处置: ${oneLineOf(rec.resolveNote) || "产物已在外部采用，会话无需再跑"}（终态，不再可 resume）`), w));
	} else if (rec.status === "error") {
		lines.push(trimDisplay(paint(theme, "error", `根因: ${oneLineOf(rec.errorMessage) || oneLineOf(rec.result) || "（无失败根因）"}`), w));
	} else if (rec.status === "truncated") {
		lines.push(trimDisplay(paint(theme, "warning", `截断（非失败）: ${oneLineOf(rec.completionAnnotation) || "终稿帧丢失，会话/产物完整；证据绿则按完成采信，可 resume 拿终稿"}`), w));
	} else if (rec.status === "cancelled") {
		lines.push(trimDisplay(paint(theme, "warning", `取消原因: ${oneLineOf(rec.errorMessage) || oneLineOf(rec.stopReason) || "（未记录取消原因）"}`), w));
		lines.push(trimDisplay(`部分结果: ${oneLineOf(rec.result) || "（无部分产出）"}`, w));
	}
	lines.push(trimDisplay(paint(theme, "toolTitle", `最近行为（末 ${maxAct} 条，最新在底）`), w));
	const win = (rec.activityWindow ?? []).slice(-maxAct);
	if (win.length === 0) lines.push(trimDisplay(paint(theme, "dim", "  等待首个动作…"), w));
	for (const a of win) {
		const body = a.summary && a.summary !== a.type ? `${a.type}: ${a.summary}` : a.type;
		lines.push(trimDisplay(`  ${hhmmss(a.ts)} ${body}`, w));
	}
	lines.push(trimDisplay(paint(theme, "dim", hr), w));
	lines.push(trimDisplay(paint(theme, "dim", "Esc/q/← 返回看板 · v 完整会话 · r 刷新"), w));
	return lines;
}

// ─────────────────────────────────────────────────────────────────────────────
// 注册（开合状态机 + session 自清）
// ─────────────────────────────────────────────────────────────────────────────

export interface BoardController {
	boardKey: string;
	/** 看板当前是否打开（测试观测用）。 */
	isOpen(): boolean;
	/** 程序化关闭（session 复位/测试用）。 */
	close(): void;
	/** session 复位：关闭看板并重置状态。 */
	reset(): void;
	/** v1.5.178: 程序化打开（#board/#panel 路由）；taskIdOrOpts 支持 taskId 前缀解析（taskId/name/sessionId）或 {taskId, initialView:"viewer"} 直达会话查看器（与 openWith 实现一致）。 */
	open(ctx: unknown, taskIdOrOpts?: string | { taskId?: string; initialView?: "viewer" }): Promise<void>;
}

export function registerWorkflowBoard(pi: BoardPi, deps: BoardDeps): BoardController {
	// v1.5.218：amagi.json ui.keys.board（项目优先）→ deps.key 显式注入 → 默认 ⌥W + legacy。
	const cfgKeys = readUiConfig(deps.configCwd ?? process.cwd()).keys.board;
	const boardKeys = deps.key ? [deps.key, ...cfgKeys.filter((k) => k !== deps.key)] : cfgKeys;
	const boardKey = boardKeys[0];
	const refreshMs = deps.refreshMs ?? DEFAULT_REFRESH_MS;
	let open = false;
	let closeFn: (() => void) | undefined;

	function close(): void {
		const fn = closeFn;
		closeFn = undefined;
		open = false;
		if (fn) { try { fn(); } catch {} }
	}

	// M5-b 同模式：session 切换/关闭时复位（dist resetExtensionUI 已清 overlay，此处复位闭包状态）
	pi.on("session_start", () => close());
	pi.on("session_shutdown", () => close());

	// v1.5.178 程序化打开（#board/#panel、/amagi board、/amagi session 路由直达）：
	// viewTaskId 支持前缀解析（taskId/name/sessionId）；initialView=viewer 直达会话查看器。
	let pendingOpen: { taskId: string | null; initialView: "board" | "session" | "viewer" } | null = null;
	function resolveTaskId(prefix: string): string | null {
		const q = prefix.toLowerCase();
		const rec = [...deps.taskRegistry.list()].reverse().find((r) =>
			r.taskId.toLowerCase().startsWith(q) || r.name?.toLowerCase().startsWith(q) || r.sessionId?.toLowerCase().startsWith(q));
		return rec?.taskId ?? null;
	}
	async function openWith(ctx: any, taskIdOrOpts?: string | { taskId?: string; initialView?: "viewer" }): Promise<void> {
		if (ctx.mode !== "tui") return;
		if (open) { close(); await new Promise((r) => setTimeout(r, 0)); } // 已开则先关（重开注入初始视图）
		const taskId = typeof taskIdOrOpts === "string" ? taskIdOrOpts : taskIdOrOpts?.taskId ?? null;
		const initialView = typeof taskIdOrOpts === "object" && taskIdOrOpts?.initialView === "viewer" ? "viewer" : taskId ? "session" : "board";
		pendingOpen = { taskId: taskId ? resolveTaskId(taskId) : null, initialView };
		open = true;
		try {
			await ctx.ui.custom(
				(tui: any, theme: any, _kb: any, done: (result: null) => void) => {
					closeFn = () => { try { done(null); } catch {} };
					const timer = setInterval(() => { try { tui.requestRender(); } catch {} }, refreshMs);
					timer.unref?.();
					// v1.5.185 事件响应：registry 变更立即重渲（主通道）；interval 降为兜底心跳。
					const unsubChange = deps.taskRegistry.onChange?.(() => { try { tui.requestRender(); } catch {} });
					// 三级视图状态机：board(列表) → session(任务面板) → viewer(会话查看器 M4)。
					let view: "board" | "session" | "viewer" = pendingOpen?.initialView ?? "board";
					let selIndex = 0;
					let viewTaskId: string | null = pendingOpen?.taskId ?? null;
					// viewer 返回目标：从 session 进入 → 返回 session；从 board 直入 → 返回 board。
					let viewerBack: "board" | "session" = "board";
					let viewerComp: ReturnType<typeof createViewerComponent> | null = null;
					const selectable = () => {
						const m = buildBoardModel(deps.agents, deps.taskRegistry.list(), Date.now(), { axisOf: deps.axisOf });
						return [...m.running, ...m.blocked, ...m.settled];
					};
					function ensureViewer(): void {
						if (!viewTaskId) return;
						if (viewerComp) viewerComp.dispose();
						const rec = deps.taskRegistry.list().find((r) => r.taskId === viewTaskId);
						viewerComp = createViewerComponent({
							registry: { list: () => deps.taskRegistry.list() },
							query: viewTaskId,
							cwd: rec?.cwd,
							titleNote: rec ? `${rec.agent}` : undefined,
							onExit: () => { view = viewerBack; viewerComp?.dispose(); viewerComp = null; },
							theme,
						});
					}
					if (view === "viewer" && viewTaskId) ensureViewer();
					return {
						render(width: number): string[] {
							const maxHeight = overlayViewportHeight(tui?.terminal?.rows);
							if (view === "viewer" && viewerComp) {
								const vp = Math.max(4, (maxHeight ?? 24) - 4);
								try { viewerComp.handle.setViewport(vp); } catch {}
								return fitOverlayViewport(viewerComp.render(width), maxHeight, width);
							}
							if (view === "session" && viewTaskId) {
								const rec = deps.taskRegistry.list().find((r) => r.taskId === viewTaskId);
								if (rec) {
									const detailLines = rec.status === "cancelled" ? 2 : rec.status === "blocked" || SETTLED_STATUS[rec.status] ? 1 : 0;
									const maxActivity = maxHeight === undefined ? undefined : Math.max(1, maxHeight - 8 - detailLines - 1);
									const sessAxes = safeAxisOf(deps.axisOf, rec.taskId);
								return fitOverlayViewport(renderSessionLines(rec, { width, maxActivity, ...(sessAxes ? { axes: sessAxes } : {}) }, theme), maxHeight, width);
								}
								view = "board"; viewTaskId = null; // 任务记录已清 → 回落看板
							}
							const m = buildBoardModel(deps.agents, deps.taskRegistry.list(), Date.now(), { axisOf: deps.axisOf });
							const total = m.running.length + m.blocked.length + m.settled.length;
							if (selIndex >= total) selIndex = Math.max(0, total - 1); // 任务终结后钳位
							return fitOverlayViewport(renderBoardLines(m, width, theme, { index: selIndex, interactive: true }), maxHeight, width);
						},
						handleInput(data: string): void {
							// ── viewer 视图：键盘全部交给查看器组件（q/Esc → onExit 返回上级） ──
							if (view === "viewer") { try { viewerComp?.handleInput(data); } catch {} return; }
							// ── session（任务面板）视图 ──
							if (view === "session") {
								if (data === "q") { try { done(null); } catch {} }
								else if (data === "\x1b" || data === "\x1b[D" || data === "h") { view = "board"; viewTaskId = null; }
								else if (data === "r") { try { tui.requestRender(); } catch {} }
								else if (data === "v" && viewTaskId) { viewerBack = "session"; view = "viewer"; ensureViewer(); }
								return;
							}
							// ── board（列表）视图 ──
							if (data === "\x1b" || data === "q") { try { done(null); } catch {} }
							else if (data === "r") { try { tui.requestRender(); } catch {} }
							else if (data === "\x1b[A" || data === "k") { selIndex = Math.max(0, selIndex - 1); }
							else if (data === "\x1b[B" || data === "j") { selIndex = Math.min(selIndex + 1, Math.max(0, selectable().length - 1)); }
							else if (data === "g") { selIndex = 0; }
							else if (data === "G") { selIndex = Math.max(0, selectable().length - 1); }
							else if (data === "\r") {
								const t = selectable()[selIndex];
								if (t) { view = "session"; viewTaskId = t.taskId; }
							}
							else if (data === "v") {
								const t = selectable()[selIndex];
								if (t) { viewerBack = "board"; view = "viewer"; viewTaskId = t.taskId; ensureViewer(); }
							}
						},
						invalidate(): void {},
						dispose(): void { clearInterval(timer); unsubChange?.(); viewerComp?.dispose(); viewerComp = null; },
					};
				},
				{
					overlay: true,
					// dist docs L2683-2714 Overlay Mode：浮层不清屏；百分比尺寸+居中+边距（全屏模态感）
					overlayOptions: { width: "95%", maxHeight: "85%", anchor: "center", margin: 1 },
				},
			);
		} catch {
			// custom() 在会话失效等场景可能拒绝——状态复位即可，不影响编排主流程
		} finally {
			open = false;
			closeFn = undefined;
			pendingOpen = null;
		}
	}

	// 主键 ⌥W + legacy 兼容键，同一 toggle handler（R4：描述含 mac 符号与文本命令等价物）
	const boardHandler = async (ctx: any) => {
		if (open) { close(); return; }
		await openWith(ctx);
	};
	for (const key of boardKeys) {
		pi.registerShortcut(key, {
			description: `amagi: workflow 看板（${fmtKey(key)}；或 /amagi board）`,
			handler: boardHandler,
		});
	}

	return { boardKey, isOpen: () => open, close, reset: close, open: openWith };
}
