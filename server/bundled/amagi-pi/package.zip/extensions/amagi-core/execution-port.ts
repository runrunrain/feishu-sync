/**
 * execution-port.ts — 执行后端能力声明端口（amagi-pi v2 K1，方案 §3.1/§3.3）。
 *
 * 纯契约端口模块：只声明后端能力、启动、观察回流与停止；不接受结果、不写任务状态
 * （N1：每个 owner 的 TaskRun 只由一个 TaskKernel 写，后端只能报告观察）。
 * 依赖方向：execution-port → contracts（纯契约）；禁止 import 具体 json/rpc 后端实现
 * （task-run/rpc-pool 等），由 depcruise 规则 v2-execution-port-no-backend 断言。
 * 进程句柄（child/AbortController 等）只留执行适配器私有映射，不进入本端口类型。
 */
import type { ExecutionEvent } from "./contracts/command.ts";
import type { Result, TaskKey } from "./contracts/view.ts";
import type { TaskSpec, TaskView } from "./contracts/task.ts";

/** 后端观察：单次后端内递增 observationSeq；重复序号无副作用，终结事件不可被低序号覆盖（§3.3 observe）。 */
export interface ExecutionObservation {
	key: TaskKey;
	backendRunId: string;
	observationSeq: number;
	event: ExecutionEvent;
}

/** 观察回流：后端只报告观察；TaskView 由内核提交后返回（端口自身无写状态权限）。 */
export type ObservationSink = (event: ExecutionObservation) => Promise<Result<TaskView>>;

/** ev-20261019-06c169：引擎侧观察回流目标（自 task-run 上移至纯契约端口——执行引擎与默认 sink 工厂
 *  （task-service）共构消费，避免引擎↔服务层类型循环）。emit 为 ObservationSink 宽松超集
 *  （允许同步/void 返回——fake sink 可注入）；onProcess 回投进程句柄（spawn 成功后回投、close 后回投
 *  undefined），句柄只留适配器私有映射（§3.2）。 */
export interface RunObservationTarget {
	key: TaskKey;
	backendRunId: string;
	emit: (observation: ExecutionObservation) => Promise<Result<TaskView>> | Result<TaskView> | void;
	/** spawn 成功后回投进程句柄、close 后回投 undefined——句柄只留适配器私有映射（§3.2：不进公开 View/持久化对象）。 */
	onProcess?: (child: unknown | undefined) => void;
}

/** 执行句柄：仅含身份标识；进程句柄在适配器私有映射中（§3.2）。 */
export interface ExecutionHandle {
	key: TaskKey;
	backendRunId: string;
}

/** 后端能力声明（backend:"json"|"rpc"；resume/adjust 是否支持；不支持的能力返回 unsupported）。 */
export interface ExecutionCapabilities {
	backend: "json" | "rpc";
	resume: boolean;
	adjust: boolean;
}

/** 停止观察：requested=已请求停止（不等于已确认退出）；confirmed=已确认退出；unknown=停止结果不可确认（§3.3）。 */
export interface StopObservation {
	status: "requested" | "confirmed" | "unknown";
	at: number;
	exitCode?: number;
	detail?: string;
}

/** 执行端口：启动受控执行并接受观察；停止只请求，退出事实经 observe(exited) 回流。 */
export interface ExecutionPort {
	capabilities(): Readonly<ExecutionCapabilities>;
	start(spec: Readonly<TaskSpec>, key: TaskKey, emit: ObservationSink): Promise<ExecutionHandle>;
	stop(handle: ExecutionHandle, reason: string): Promise<StopObservation>;
}
