import { registerCodemodeRuntime } from "./codemode-runtime.ts";
import { registerAdvisor } from "./advisor-tool.ts";
/**
 * amagi-core — pi extension entry point.
 *
 * P2 装配：guards（主+子进程安全网）+ resource-reader（仅主进程）。
 * 设计裁定：guards 在子进程也注册（保护子 Agent 的 bash 操作）；resource-reader 只在主进程。
 *
 * P4 装配（本接线任务汇合）：
 *   - P4-1 status-ui：TUI 状态栏/widget 渲染编排实况（模块级持有，session_start 创建 / session_shutdown 清理）
 *   - P4-2 input-router：确定性路由 #<角色>/#review（input 事件拦截）
 *   - P4-4 mcp：智谱系 MCP 与通用 mcpServers 配置统一由 mcp-client.ts 承载（v1.5.245 清理：原 mcp-tools.ts 自实现三工具已删，避免与新通道双注册）
 *   （P4-3 evidence 已在 task-tool.ts 内接入，无需此处接线）
 *   - T2-9 rpc-pool：RPC 常驻进程池（独立工具 rpc_task；lazy init + session_shutdown 清理）
 *   - 8月迭代 pi-0.84 配合 P2⑥/P2⑦：ui_prompt_start/end 等待标记（status-ui）+ 路径链接化
 *     显示变换（transform-display；仅主进程）
 */

import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";
import type { ExtensionAPI, ToolDefinition } from "@earendil-works/pi-coding-agent";
import { discoverAgents } from "./agents-loader.ts";
import { registerCompactionModel } from "./compaction-model.ts";
import { findAgentByRequest } from "./agent-aliases.ts";
import { renderRelaySubmitDraft, contextWindowOf } from "./context-budget.ts";
import { createTaskTool, createQueryTaskTool, cleanupChildrenOnShutdown, snapshotForPersist, runTask, runResumeTask, setStatsListener, setTrustFallback, resolveProjectTrusted, liveContextTokensOf } from "./task-tool.ts";
import { createTaskFacetTools, taskFacetSurfaceStamp, TASK_FACET_SURFACE_VERSION } from "./task-facets.ts";
import { createToolSurface, createTaskBatchTool, type SurfaceHost } from "./tool-surface.ts";
import { withArgumentArtifactNormalization } from "./tool-result-adapter.ts"; // ev-20260920：模型面工具注册统一伪影接线
import type { CallerContext } from "./contracts/command.ts";
import { createResourceReaderTool } from "./resource-reader.ts";
import { createEvolutionTool } from "./evolution-tool.ts";
import { createHandbookTool } from "./handbook-tool.ts";
import { codexComputerUseEnabled, createCodexComputerUseTool } from "./codex-computer-use.ts";
import { registerGuards } from "./guards.ts";
import { registerCodexFrontlineModels } from "./codex-models.ts";
import { registerBrowserHeartbeat, startBrowserReaper } from "./browser-reaper.ts";
import { registerEditGuard } from "./edit-guard.ts";
import { registerEmojiGuard, type EmojiGuardPi } from "./emoji-guard.ts";
import { createBashCwdOverrideTool, resetBashAdvisoryDedup } from "./bash-override.ts";
// ev-20260926-bc6ba3（R5）：会话采集生命周期 + P9（寄生设计 §5.3）：provider 流事件受控诊断
import { resetDebugObservation, noteProviderStreamEvent, noteProviderTurn } from "./debug-observation.ts";
import { createCacheWarmingDecisionHandler, resetCacheWarmingSession } from "./cache-warming.ts";
// ev-20260916-99a6cd（P1）：通用后台命令原语 + ev-20260917-7b9298（P2）：孤儿进程诊断回收
import { createRunBgTool, activeRunBgPids } from "./run-bg.ts";
// win_exec（WSL Windows 原生程序受管执行）：仅 WSL 检测命中时注册（win-exec.ts），非 WSL 零开销
import { createWinExecTool, winExecSessionCleanup } from "./win-exec.ts";
import { setWinExecAvailable } from "./win-exec-advisory.ts";
import { runWinDoctor } from "./win-exec-doctor.ts";
import { diagnoseOrphans, reapDiagnosedOrphans } from "./orphan-reaper.ts";
import { registerEditOverrideTool } from "./edit-override.ts";
import { createEditDiagnostics, registerEditDiagnosticsObserver } from "./edit-diagnostics.ts";
import { registerWriteOverrideTool, writeOverrideDriftEnabled } from "./write-override.ts";
import { registerReadOverrideTool } from "./read-override.ts";
import { EditSnapshotStore } from "./edit-snapshot.ts";
import {
	bootstrapFilePermissionContextFromEnv, filePermissionContextActive,
	fileReadPermissionBlockReason,
	PERMISSION_GRANT_ENV,
} from "./file-permission.ts";
import { validatePermissionGrant, type PermissionGrant } from "./contracts/permission.ts";
import { registerLeaderPrompt } from "./leader-prompt.ts";
import { createContinuationState, registerContinuation } from "./continuation.ts";
import { registry } from "./task-registry.ts";
import { getTaskKernel, getLeaderSessionStamp, peekTaskKernel, setLeaderMachineStamp, setLeaderSessionStamp } from "./task-service.ts";
import { captureStartupHostVersion } from "./version-drift.ts";
import { adoptRecoveryRecord, applyTaskRecovery, formatRecoveryReport, formatStartupRecoveryNotice, loadRecoveryAutoConfig, maybeSweepSteerChannels, recoveryActionableSignature, recoveryNoticeAlreadyDelivered, scanTaskRecovery, showRecoveryCheckpoint } from "./task-recovery.ts";
import { attestTaskExited } from "./task-reconcile.ts";
import { getMachineId } from "./data-dir.ts";
import type { TaskAxisOf } from "./panel-model.ts";
import { registerConfiguredMcpServers } from "./mcp-client.ts";
import { resolveSessionMcpHybrid } from "./mcp-host-bridge.ts";
import { createMcpCallCapturePi, registerMcpCallShapeOverride } from "./mcp-override.ts";
import { clearMcpEnvBundle, describeMcpRouteDenial, loadMcpServerConfigs, normalizeMcpPermission, resolveAgentMcpServers, leaderMcpRoute } from "./mcp-config.ts";
import { registerInputRouter } from "./input-router.ts";
import { registerAmagiToolRenderers } from "./tool-renderers.ts";
import { registerWatchdog, type WatchdogPi } from "./watchdog.ts";
import { sweepVerificationTemp } from "./verification-temp-gc.ts";
import { journalSweep, journalSettle, journalRecoveryText, journalLookupByPrefix } from "./journal.ts";
import { createStatusUI, selectPanelTasks, type StatusUI } from "./status-ui.ts";
import { noteFileMutationStart, noteFileMutationEnd, cancelPendingFileMutations, fileMutationSessionId, clearCompletedFileMutations } from "./file-mutation-tracker.ts";
import { registerDisplayTransforms } from "./transform-display.ts";
import { registerAmagiShortcuts } from "./shortcuts.ts";
import { registerWorkflowBoard } from "./workflow-board.ts";
import { registerAmagiCommands, maybeShowShortcutHint } from "./amagi-commands.ts";
// B0-2（§3.4）：/amagi stats 文本供给——累计口径聚合 + 本会话分支可见用量视图。
import { aggregateStats, renderStatsText, aggregateSessionUsage, renderSessionUsageText, renderObservationsText } from "./stats-aggregate.ts";
import { sessionToolStatsSection } from "./session-stats.ts";
import { readTraces, readObservations } from "./trace.ts";
import { harnessInfoEmitter, registerHarnessInfoRenderer } from "./harness-help.ts";
import { explainConfiguration, configurationDoctor, initializeProjectConfiguration, type ConfigurationContext } from "./configuration-diagnostics.ts";
import { activateTuiDiagSink, deactivateTuiDiagSink, tuiWarn, tuiLog } from "./tui-console.ts";
import { readUiConfig } from "./ui-config.ts";
import { registerAnswerQueue, type QueuePi, type AnswerQueueDeps } from "./answer-queue.ts";
import { scheduleChildSettleExit } from "./child-settle-exit.ts";
import { registerChildNetworkRecovery } from "./child-network-recovery.ts";
import { registerLengthContinuation } from "./length-continuation.ts";
import { capabilityEnabledByVersion, detectRunningHostVersion } from "./host-capabilities.ts";
import { registerRuntimeFingerprint } from "./runtime-fingerprint.ts";
import { registerProviderDiagnostics } from "./provider-diagnostics.ts";
import { registerContextHandler } from "./context-event.ts";
import { registerVisionFallback } from "./vision-fallback.ts";
import { registerSteerInjection } from "./task-steer.ts";
import { createRpcPoolController, createRpcPoolTool } from "./rpc-pool-tool.ts";
import { createLspTool } from "./lsp-tool.ts";
import { checkItermBoldColor, checkModelProfile, checkRetrySetting } from "./terminal-doctor.ts";
import { ensureGlobalConfigOnStartup, preflightModels } from "./model-resolver.ts";
import { isWebUiEnabled, registerWebUi, type WebUiOrchAdapter, type WebUiRecoveryAdapter, type WebUiRpcDialogAdapter, type WebUiResumeAdapter } from "./webui/server.ts";
import { buildAgentSessionBody, matchTaskId, readAgentSessionText, resolveAgentSessionFile } from "./webui/agent-session.ts";
import { resolveSessionFile } from "./session-viewer.ts";
import { buildTaskPanel, earliestExpiryAt } from "./webui/task-panel.ts";
import { setPanelContextListener } from "./task-run.ts";
import { sendTaskCompletion, sendMachineNotice, MACHINE_NOTICE_TYPE } from "./evidence-context.ts";

const SUBAGENT = process.env.AMAGI_SUBAGENT === "1";

// ── v2 P4（方案 §5.1/§5.2/§8.3-P4）：子进程权限交付面 ──────────────────────────

/** 从 env 解析冻结授权（子进程 MCP/LSP 执法面构造用）。校验权威 = file-permission bootstrap
 *  （digest/JSON/契约已在启动引导完成，失败即 exit）；此处仅契约形状复核并返回 grant。
 *  未注入（legacy v1 面）→ undefined（MCP/LSP 不注入执法面，v1 行为不变）。 */
function childPermissionGrantFromEnv(env: NodeJS.ProcessEnv = process.env): PermissionGrant | undefined {
	const raw = env[PERMISSION_GRANT_ENV];
	if (raw === undefined || raw.trim() === "") return undefined;
	try {
		const v = validatePermissionGrant(JSON.parse(raw));
		return v.ok ? v.value : undefined;
	} catch { /* journal:permission-injection-parse-fallback */ 
		return undefined; // bootstrap 已对非法注入 exit(1)，此处不可达；防御返回不扩权
	}
}

// 8月迭代 F1 缓解：插件代码新旧检测——源码 mtime 晚于本进程启动（jiti 已缓存旧模块），
// 提示修复需重启生效（实战：settle 误杀修复落盘后，运行中 Leader 仍用旧逻辑杀子进程）。
// 模块加载即执行一次；主进程提示，子进程静默（子进程每次新 spawn 天然加载新码）。
export function detectStaleExtension(moduleDir: string, procStartMs: number): { file: string; mtimeMs: number } | null {
	let newest = 0, newestFile = "";
	for (const f of fs.readdirSync(moduleDir)) {
		if (!/\.(ts|json)$/.test(f)) continue;
		const m = fs.statSync(path.join(moduleDir, f)).mtimeMs;
		if (m > newest) { newest = m; newestFile = f; }
	}
	return newest > procStartMs + 3_000 ? { file: newestFile, mtimeMs: newest } : null;
}
if (!SUBAGENT) {
	try {
		const stale = detectStaleExtension(path.dirname(fileURLToPath(import.meta.url)), Date.now() - process.uptime() * 1000);
		if (stale) console.warn(`[amagi-core] 插件代码在本进程启动后已更新（${stale.file}）——修复可能需重启 pi 才在编排链生效；settle 兜底逃生门：AMAGI_SETTLED_EXIT_MS=0 可关闭。`);
	} catch { /* lint-exempt:stale 检测失败不影响启动 */ }
}

// E4: 模型可达性启动预检——模块级 once flag，每进程只跑一次（不管 session_start reason）
let modelPreflightRan = false;

// P4-1: status-ui 模块级持有（跨 session_start/shutdown 生命周期；extension 单例，amagiCore 调一次）
let statusUI: StatusUI | undefined;

// v1.5.218-f5：Leader 模型面显示随 panel-widget 停用移除（pi footer 底栏已含模型/推理强度）。

// T2-9: RPC 进程池 controller（lazy init on first use；session_shutdown 清理）
let rpcPoolController: ReturnType<typeof createRpcPoolController> | undefined;

// LSP: 单实例句柄（懒：工具注册不 spawn 任何 server；session_shutdown/agent_settled 关池）
let lspToolHandle: ReturnType<typeof createLspTool> | undefined;

// K8c（方案 §3.1/§8.1-K8c）：Leader 逻辑身份（可信来源——组合根注入，模型参数不能构造，N1 单写者栅栏）。
// ev-20261005-055864（diting F-03）：实现下移至 task-service（resume 桥接与生产对账同源 owner），此处 re-export 保持兼容。
import { resolveLeaderOwnerId } from "./task-service.ts";
export { resolveLeaderOwnerId };

// K8c→v2.1：恢复对账按会话键去重——同进程内 /resume 切换到另一会话须再次对账该会话（旧进程级
// 一次性标记会漏掉二次 resume 并让查询缓存陈旧，Leader 直修）；同一会话重复触发不重复应用。
let lastRecoveredSessionKey: string | undefined;

/**
 * 8月迭代 Wave C2：主进程并行写冲突软提示（复盘 §2.6：Lane B 与 Leader 并行改 event.ts，
 * tsc 报错晚到 20 分钟才发现）。订阅主进程 write/edit 工具调用，目标路径命中任一 running
 * 子任务的 lastWritePaths → sendMessage 提醒确认分工边界或串行化；绝不阻断（观测层），
 * 每文件每任务只提示一次（防噪音），session 重启重置。导出供测试注入 stub pi。
 */
export function registerParallelWriteHint(pi: ExtensionAPI): void {
	const hinted = new Set<string>();
	const reset = () => hinted.clear();
	try { pi.on("session_start", reset); pi.on("session_shutdown", reset); } catch { /* lint-exempt:事件不可用防御 */ }
	pi.on("tool_call", (event: any, ctx: any): any => {
		try {
			const toolName = String(event?.toolName || "").toLowerCase();
			if (toolName !== "write" && toolName !== "edit") return undefined;
			const raw = String(event?.input?.file_path || event?.input?.path || "").trim();
			if (!raw) return undefined;
			const base = ctx?.cwd || process.cwd();
			const target = path.isAbsolute(raw) ? path.normalize(raw) : path.resolve(base, raw);
			for (const hit of registry.findRunningWriteConflicts(target)) {
				const key = `${hit.taskId}\n${target}`;
				if (hinted.has(key)) continue; // 每文件每任务只提示一次
				hinted.add(key);
				const label = `${hit.taskId.slice(0, 8)}${hit.name ? `(${hit.name})` : ""}·${hit.agent}`;
				const list = hit.paths.map((p) => path.basename(p)).join(", ");
				try {
					// v1.5.244 注入安全：{triggerTurn:false} 在流式中原位插到 assistant(tool_calls) 与 toolResult 之间，
				// 会使严格 OpenAI 兼容后端（Kimi）400；改 { deliverAs: "steer" } 在完整 tool 配对之后注入。
				pi.sendMessage({ customType: "amagi:write-conflict", content: `[并行冲突风险] ${path.basename(target)} 正被子任务 ${label} 写入（最近写入: ${list}）——确认分工边界或串行化，避免同文件并行修改互相覆盖`, display: false }, { deliverAs: "steer" });
				} catch { /* lint-exempt:sendMessage 不可用静默 */ }
			}
		} catch { /* lint-exempt:观测提示绝不影响工具执行 */ }
		return undefined;
	});
}

export default function amagiCore(pi: ExtensionAPI): void {
	// Leader、JSON 子进程及 RPC worker 共用；必须在子端早退之前注册。
	registerCompactionModel(pi);
	// 工具命令的非交互环境由原生 bash spawnHook 设置，不修改宿主进程的
	// EDITOR/VISUAL/PAGER（pi TUI 与扩展外部编辑器继续消费用户设置）。

	// P4（§5.1/§8.3-P4）：子端启动校验——冻结授权 env 引导（P2 bootstrap 单一实现）：
	// digest/JSON/契约校验失败 → stderr + exit(1)，子端从不从环境变量缺失/非法回退到无限制（fail-closed）。
	// 权限 env 未注入（legacy v1 面）→ 引导返回 undefined，行为零变化。
	// 必须先于 write/edit override 注册（严格任务判定 strictEnforcementActive 消费本上下文）。
	if (SUBAGENT) {
		try {
			bootstrapFilePermissionContextFromEnv(process.env);
		} catch (e) {
			console.error(`[amagi-core] ${e instanceof Error ? e.message : String(e)}`);
			process.exit(1);
		}
	}

	registerAdvisor(pi);
	registerCodemodeRuntime(pi);

	// P2: guards 在主进程和子进程都注册（安全网，保护 bash 操作）。
	// 混合计划沿用既有会话决议，不在此创建第二套 owner/路由。
	let mcpHybrid: ReturnType<typeof resolveSessionMcpHybrid> | undefined;
	if (!SUBAGENT) {
		try { mcpHybrid = resolveSessionMcpHybrid(process.cwd()); }
		catch (e) { console.warn(`[amagi-core] mcpServers 配置加载失败（不影响内置 MCP 工具）: ${e instanceof Error ? e.message : e}`); }
	}
	const nativeMcpGrant = SUBAGENT ? childPermissionGrantFromEnv() : undefined;
	const nativeMcpPermission = nativeMcpGrant ? normalizeMcpPermission(nativeMcpGrant.mcp, { sideEffects: nativeMcpGrant.assurance === "guarded" }) : undefined;
	const nativeMcpRoute = SUBAGENT ? resolveAgentMcpServers(process.cwd(), process.env.AMAGI_AGENT ?? "") : leaderMcpRoute(process.cwd());
	registerGuards(pi, {
		enableSentinel: !SUBAGENT,
		nativeMcp: () => {
			let tools: ReturnType<ExtensionAPI["getAllTools"]> = [];
			let extensionServers: ReturnType<ExtensionAPI["getMcpServers"]> = [];
			try { tools = pi.getAllTools?.() ?? []; } catch { /* lint-exempt:宿主注册表暂不可用，名称缺席按拒绝处理 */ }
			try { extensionServers = pi.getMcpServers?.() ?? []; } catch { /* lint-exempt:旧宿主无注册表，保留配置与 grant 检查 */ }
			const names = new Set(Object.keys(loadMcpServerConfigs(process.cwd()).servers));
			for (const server of Array.isArray(extensionServers) ? extensionServers : []) names.add(server.name);
			for (const tool of Array.isArray(tools) ? tools : []) {
				if (tool.namespace?.name?.startsWith("mcp__")) names.add(tool.namespace.name.slice(5));
			}
			return {
				...(mcpHybrid?.status === "mixed" && mcpHybrid.plan ? { plan: mcpHybrid.plan } : {}),
				permission: nativeMcpPermission, onlyServers: nativeMcpRoute,
				routeDenialHint: (server: string) => describeMcpRouteDenial(process.cwd(), server, SUBAGENT ? { kind: "agent", agent: process.env.AMAGI_AGENT || undefined } : { kind: "leader" }),
				registeredServerNames: [...names],
				natureOf: (server: string, tool: string) => {
					const name = `mcp__${server.replace(/-/g, "_")}__${tool}`;
					return Array.isArray(tools) && tools.find((item) => item.name === name)?.annotations?.readOnlyHint === true ? "read-only" as const : "unknown" as const;
				},
			};
		},
	});
	// v1.5.263 codex 前线模型抢先适配（gpt-6-astra 等 pi.dev 目录未收录模型）：主/子进程
	// 双侧注册（子 Agent 派发同样走各自进程模型目录）；best-effort，失败仅 stderr 单行。
	registerCodexFrontlineModels(pi);
	// v1.5.253 browser-reaper 心跳观测（ev-20260830-52106c）：主进程/子进程双侧注册——
	// 任意 pi 实例经 bash 驱动 agent-browser 即刷新共享心跳，保证并行会话/子 Agent 任务不被
	// 主进程 idle 回收器误杀。纯观测零开销，失败静默。
	try { registerBrowserHeartbeat(pi); } catch { /* lint-exempt:心跳失败静默 */ }
	// v1.5.219：edit 事件护栏——A1（ev-20260921-2e6b4f）职责重排后：形状归一（path/files/旧
	// file_path；冲突报错）+ 字面标题删除检查；匹配/自愈/not-found 全部归 edit-override 的
	// recoverNativeFailure。主/子共用此一次注册（子进程不再重复注册）；仅拦截 edit 工具，零文件 IO。
	try { registerEditGuard(pi); } catch (e) { console.warn(`[amagi-core] edit-guard 注册失败（不影响主功能）: ${e instanceof Error ? e.message : String(e)}`); }
	// v2.7.0：emoji 硬拦截护栏（主/子双侧注册——子 Agent 是文档产出大户；默认关，
	// amagi.json emojiGuard.enabled 或 AMAGI_EMOJI_GUARD=1 开启；配置每次事件现读即时生效）。
	// diting F4：cast 为窄接口会掩盖 ExtensionAPI 事件签名漂移（如 pi 升级改 input 形状）——
	// 补偿：tests/emoji-guard.test.mjs 夹具用 pi 0.86.0 真实 schema 形状（path/files+edits），
	// 形状漂移时测试先行变红（F1 正是这样漏入又被夹具失真掩盖，现已按真实形状重铸）。
	try { registerEmojiGuard(pi as unknown as EmojiGuardPi); } catch (e) { console.warn(`[amagi-core] emoji-guard 注册失败（不影响主功能）: ${e instanceof Error ? e.message : String(e)}`); }
	// 8月迭代 A2（ev-20260815-0877b0）：同名覆盖内置 bash 新增 cwd 参数——主进程 Leader 与
	// AMAGI_SUBAGENT 子进程统一受益（子 Agent 同样踩 cd 前缀坑）。注册在 guards 之后：守卫走
	// pi beforeExecution 事件链（按 toolName=bash 驱动），覆盖实现不影响拦截；失败静默回退原生 bash。
	try { pi.registerTool(withArgumentArtifactNormalization(createBashCwdOverrideTool(process.cwd())) as unknown as ToolDefinition); } catch { /* lint-exempt:静默降级：原生 bash 不受影响 */ }
	// ev-20261031-a25f7a（P3，复盘 §2.6）：bash 软提示计次/去重的会话生命周期复位——模块级
	// advisoryRepeat/advisoryDedup 此前无 session 接线，Leader 主进程跨会话沿用旧计数（新会话首报
	// 直接从折叠态开始）。现随 session_start/shutdown 复位：新会话首次提示重新全文。子进程每任务
	// 独立进程本就归零，接线幂等无害。gitRootCache 一并清理（会话切换 cwd 后重新探测，无语义损害）。
	try { pi.on("session_start", () => { resetBashAdvisoryDedup(); }); pi.on("session_shutdown", () => { resetBashAdvisoryDedup(); }); } catch { /* lint-exempt:事件不可用防御 */ }
	// ev-20260926-bc6ba3（R5）：/amagi debug 会话采集生命周期——会话启动/切换/重载/退出时释放采集内存
	// 并失效迟到采集（generation++；纯内存态零文件副作用）。主/子进程双侧注册（bash debugTag 参数两侧可用；
	// /amagi 命令仅主进程，子代理经显式 debugTag 参数采集本进程缓冲，不跨进程查询）。
	try { pi.on("session_start", () => { resetDebugObservation(); }); pi.on("session_shutdown", () => { resetDebugObservation(); }); } catch { /* lint-exempt:事件不可用防御 */ }
	// P9（寄生设计 §5.3）：provider 流事件受控诊断——订阅常驻（未开启时零记录零开销，不阻塞流消费：
	// 回调同步纯内存写入）；/amagi debug provider on 独立 opt-in（默认关，不随 bash 采集开关）。白名单
	// 元数据采集与上限/迟到失效见 debug-observation.ts；主/子进程双侧注册（子代理无 /amagi 命令面，
	// 实际观测面在主进程；订阅存在不扩张任何权限）。不照搬宿主 debug-provider 示例的原文持久化。
	try {
		registerRuntimeFingerprint(pi, TASK_FACET_SURFACE_VERSION);
		registerProviderDiagnostics(pi);
		// 无视觉模型图片兜底：context 阶段把 image 块转存文件并附识图技能指引（主/子进程双侧；仅改本次请求投影）。
		registerVisionFallback(pi);
		pi.on("provider_stream_event", (event: unknown) => { noteProviderStreamEvent(event); });
		pi.on("turn_start", (event: unknown) => { noteProviderTurn((event as { turnIndex?: unknown } | null)?.turnIndex); });
	} catch { /* lint-exempt:事件不可用防御 */ }
	// ev-20260916-99a6cd（P1）：run_bg 通用后台命令原语——主进程 Leader 与 AMAGI_SUBAGENT 子进程统一注册
	// （实战场景正是子代理识图 CLI 长任务被前台超时后被迫手工 nohup 编排）。独立进程组 + 日志落盘 +
	// 句柄查询（跨会话经 index.ndjson 恢复）；完成/超时通知经 sendMessage steer 通道尽力而为（子进程
	// print 模式退出时发不出，但落盘状态仍在，list 可查）。注册失败静默（不影响其它工具）。
	try {
		pi.registerTool(withArgumentArtifactNormalization(createRunBgTool({
			notify: (text) => { try { pi.sendMessage({ customType: "amagi:run-bg", content: text, display: false }, { deliverAs: "steer" }); } catch { /* lint-exempt:通知失败静默 */ } },
		})) as unknown as ToolDefinition);
	} catch { /* lint-exempt:静默降级 */ }
	// win_exec：WSL 会话内受管执行 Windows 原生程序（白名单/路径翻译/Job Object 杀树/编码解码）。
	// 仅 WSL 检测命中且 windows.exec.enabled !== false 时注册（createWinExecTool 否则返回 undefined，
	// 非 WSL 环境零开销）；主/子进程双侧注册（子 Agent 同样需要 cmake/UBT 中转）。bash 的 drvfs
	// 慢路径软提示随注册置位（win-exec-advisory）。
	try {
		const winExecTool = createWinExecTool();
		if (winExecTool) {
			pi.registerTool(withArgumentArtifactNormalization(winExecTool) as unknown as ToolDefinition);
			setWinExecAvailable(true);
		}
	} catch (e) { console.warn(`[amagi-core] win_exec 注册失败（不影响主功能）: ${e instanceof Error ? e.message : String(e)}`); }
	// m3（diting 审核轮）：会话退出尽力释放 win_exec 持有的互斥锁与临时启动脚本（后台任务的
	// relay 仍由锁的 relay 存活校验保护——pi 退出但 relay 在跑不判陈旧）。
	try { pi.on("session_shutdown", () => { winExecSessionCleanup(); }); } catch { /* lint-exempt:事件不可用防御 */ }
	// 8月迭代 B3（复盘 §2.2：edit 失败 7 次、5 次批量修改全部退化 python heredoc）：同名覆盖内置
	// edit——edits[].regex 正则替换 / files 多文件模式 / 跨文件错发提示。与 bash-override 同构：
	// 非扩展路径委托原生定义（BOM/行尾/fuzzy/diff/patch/变更队列全原生），edit-guard 兼容经直接复用
	// locateEdit/editGuardReason 导出（event 链注册保持不动）；失败静默回退原生 edit。
	// P1-D（插件进化8.19）：LSP 推送式诊断注入——edit/write 成功写盘后自动附加被改文件 error 级
	// diagnostics（有界：仅命中服务器的文件、≤8 条、单次 ~3s 整体竞速；不可用/超时/熔断静默跳过，
	// 绝不阻断写入路径与结果返回；AMAGI_EDIT_DIAGNOSTICS=0 关闭，默认开；无 LSP 项目检测为空零
	// 开销——env/检测/路由三层门全部先于任何 spawn）。注册在 SUBAGENT 分支之前 → 主进程与子进程
	// 两侧一致生效；复用 lsp-client 池/熔断（下方 createLspTool 传 sharedPool()，与 lsp 拉取工具
	// 同项目同 server 单进程）。
	let editDiagnostics: ReturnType<typeof createEditDiagnostics> | undefined;
	const diagnosticsGrant = childPermissionGrantFromEnv();
	const diagnosticsAt = (cwd: string) => createEditDiagnostics({ cwd, lsp: diagnosticsGrant?.lsp,
		canRead: (target) => fileReadPermissionBlockReason(cwd, target, false) === null });
	try { editDiagnostics = diagnosticsAt(process.cwd()); } catch { /* lint-exempt:静默降级：注入缺席不影响 edit/write */ }
	const diagnosticsByCwd = new Map<string, ReturnType<typeof createEditDiagnostics>>();
	if (editDiagnostics) diagnosticsByCwd.set(process.cwd(), editDiagnostics);
	const closeDiagnostics = async () => { await Promise.all([...diagnosticsByCwd.values()].map((diag) => diag.close())); };
	let resultDiagnostics = false;
	if (process.platform !== "win32") {
		try {
			registerEditDiagnosticsObserver(pi, (cwd) => {
				if (!diagnosticsByCwd.has(cwd)) diagnosticsByCwd.set(cwd, diagnosticsAt(cwd));
				return diagnosticsByCwd.get(cwd);
			});
			resultDiagnostics = true;
		} catch { /* lint-exempt:旧宿主事件注册不可用，保留执行点诊断 */ }
	}
	const inlineDiagnostics = resultDiagnostics ? undefined : editDiagnostics;
	if (SUBAGENT) {
		try { pi.on("agent_settled", async () => { await closeDiagnostics(); }); } catch { /* lint-exempt:旧宿主事件不可用 */ }
		try { pi.on("session_shutdown", async () => { await closeDiagnostics(); }); } catch { /* lint-exempt:旧宿主事件不可用 */ }
	}
	const editSnapshots = new EditSnapshotStore();
	pi.on("session_start", async () => { editSnapshots.clear(); });
	pi.on("session_shutdown", async () => { editSnapshots.clear(); });
	try { registerEditOverrideTool(pi, { cwd: process.cwd(), editDiagnostics: inlineDiagnostics, snapshots: editSnapshots }); } catch { /* lint-exempt:静默降级：原生 edit 不受影响 */ }
	// write 同名覆盖（官方 Overriding Built-in Tools 机制，全参数委托原生）：P1-D 诊断注入 +
	// ev-20260830-e115cb 跨运行时路径防线（回执回显实际落盘路径；win32 宿主收到 POSIX 绝对路径时
	// 附 WSL bash 跨文件系统告警，防「write /tmp/x.py 成功、bash 看不到」实战复发）。注册门（diting-M3-A1
	// 加严：诊断关闭不再豁免 guarded 任务——write 通道权限校验是执法点，只要存在活动权限上下文（严格或
	// guarded）就必须注册，诊断开关只降级诊断不降级执法）：win32 宿主 或 活动权限上下文（严格/guarded）；
	// ev-20260929-3c5db4（P0）加宽：类 Unix 无活动上下文也默认注册——漏层防线（深层路径漏层后
	// write 自动 mkdir 零告警，43 份文档入错误树的实战事故）是全场景安全网，不只执法上下文需要；
	// 常规写入零扫描零成本，AMAGI_WRITE_OVERRIDE=0 逃生舱恢复旧行为。注册失败由
	// registerWriteOverrideTool fail-closed exit 1。
	if (process.platform === "win32" || filePermissionContextActive() || writeOverrideDriftEnabled()) {
		try { registerWriteOverrideTool(pi, { cwd: process.cwd(), editDiagnostics: inlineDiagnostics }); } catch { /* lint-exempt:静默降级：原生 write 不受影响（严格任务由注册器 fail-closed exit） */ }
	}
	// read 同名覆盖（ev-20260925-287e93 双宿主根治 §2.2 收口）：win32 宿主时把 POSIX 绝对路径
	// 重定向到 bash 运行时（WSL）侧可见路径（与 write/edit 同源映射：/mnt/<盘>↔盘符、WSL 内部
	// 路径→\\wsl.localhost UNC）——被重定向落盘到 WSL 文件系统的文件回读不再错位，三件套同口径
	// 闭环。普通读取继续直接委托原生；所有宿主注册显式 editReference，与 edit 共享会话缓存。
	try { registerReadOverrideTool(pi, { cwd: process.cwd(), snapshots: editSnapshots }); } catch { /* lint-exempt:静默降级：原生 read 不受影响 */ }

	// 子进程（AMAGI_SUBAGENT=1）跳过 task/query/L0/continuation/P4（防递归 + 无编排需求），
	// 但注册两类只读/外部工具（实战事故修复：旧调研岗位子进程无联网工具可用、skills 引用的
	// amagi_resource 在子进程不存在）：
	//   - amagi_resource：角色卡与多个 SKILL.md 都指示"调用 amagi_resource 取 canonical 细则"；
	//     只读资源读取，对子 Agent 安全。实际可用性仍由 spawn --tools 白名单门控。
	//   - 智谱 MCP 五工具（web_search/web_reader/zread×3）：按 mcp.agents 角色白名单启用（如 baize 等调研/识图角色）；
	//     凭据按 MCP 配置引用、角色路由与冻结授权最小交付。
	// B8（十月迭代 M3，设计 §5.5）：宿主缓存保温——订阅 1.0.2 cache_warming_decision，
	// idle 相位按 amagi 窗口 lease 决策（默认 delegate=不干预；managed 见 amagi.json cacheWarming 节）。
	// 会话启动/切换/关闭清空旧代 lease（generation 隔离）。仅主进程：子进程无 task 编排面，
	// 订阅只会恒 delegate 空转。「最后一个返回 action 的 handler 获胜」为宿主语义（多扩展后位可覆盖，
	// 诊断可观测）。事件在宿主每次保温刷新前触发：返回 {action} 覆盖、undefined 接受宿主决策。
	if (!SUBAGENT) {
		try {
			pi.on("cache_warming_decision", createCacheWarmingDecisionHandler() as never);
			pi.on("session_start", () => resetCacheWarmingSession());
			pi.on("session_shutdown", () => resetCacheWarmingSession());
		} catch { /* lint-exempt:事件不可用防御（<1.0.2 宿主无该事件面） */ }
	}
	// P0.5（8月迭代第三轮）：派发 journal 落盘——「在途无痕」→「有迹可循」。仅主进程（Leader）
	// 写 journal：dispatch 行在 task-tool spawn 侧 append，settle 行在此处订阅 registry 状态变更；
	// 启动清扫（7 天有界）+ 首次 session_start 检测上次会话中断在途任务并通知（恢复指引）。
	// journal 是可观测性而非正确性依赖：全部失败静默。
	if (!SUBAGENT) {
		try {
			journalSweep();
			const _journalSeen = new Map<string, string>();
			const _JOURNAL_TERMINAL = new Set(["done", "error", "answered", "cancelled", "truncated", "resolved-external"]);
			registry.onChange(() => {
				try {
					for (const rec of registry.list()) {
						if (_journalSeen.get(rec.taskId) === rec.status) continue;
						_journalSeen.set(rec.taskId, rec.status);
						if (_JOURNAL_TERMINAL.has(rec.status)) journalSettle(rec.taskId, rec.status);
					}
				} catch { /* lint-exempt:journal 观察面失败不反噬 */ }
			});
			let _journalNotified = false;
			try {
				pi.on("session_start", () => {
					if (_journalNotified) return;
					_journalNotified = true;
					try {
						const text = journalRecoveryText(undefined, { cwd: process.cwd(), markNotified: true });
						if (text) pi.sendMessage({ customType: "amagi:journal-recovery", content: text, display: false }, { deliverAs: "steer" });
					} catch { /* lint-exempt:sendMessage 不可用静默 */ }
				});
			} catch { /* lint-exempt:事件不可用防御 */ }
		} catch { /* lint-exempt:journal 失败静默 */ }
	}

	// Both leader and child use the same continuation and original tool authorization chain.
	if (capabilityEnabledByVersion("lengthContinuation", detectRunningHostVersion())) {
		try { registerLengthContinuation(pi); } catch (e) { console.warn(`[amagi-core] 续传注册失败: ${e instanceof Error ? e.message : String(e)}`); }
	}
	// 两者注册失败不崩子会话（静默降级，与主进程容错策略一致）。
	if (SUBAGENT) {
		registerChildNetworkRecovery(pi);
		// v1.5.197：子进程必须注册活性看门狗——它正是"pi --print 模型请求挂起"的当事场景
		// （实战：fuxi 子进程模型挂起 784s 无任何事件，主进程侧无法观测只能等 30min 硬超时）。
		// 子进程 json/print 无 UI → 沉默 abort + 宽限后 exit(3) 硬退出，父进程按结构化 error 快速收口。
		// 子进程正常长工具执行有 tool_execution_start/end 配平豁免，模型流式有 message 事件活性，不误杀。
		try { registerWatchdog(pi as unknown as WatchdogPi); } catch { /* lint-exempt:静默降级 */ }
		// v1.5.219：edit 自愈护栏——上方主路径已无条件注册（主/子共用一次）；
		// A1（ev-20260921-2e6b4f）：旧分支曾在此二次注册同一 handler（事件链重复执行），已删。
		// emoji 守卫在上方共同路径只注册一次，子进程不重复订阅。
		const subPackageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
		try { pi.registerTool(withArgumentArtifactNormalization(createResourceReaderTool(subPackageRoot)) as unknown as ToolDefinition); } catch { /* lint-exempt:静默降级 */ }
		// v1.5.245：原 registerMcpTools（智谱三件套零配置自实现）已删——统一由下方 mcp-client 通道承载
		// （用户 ~/.pi/agent/mcp.json 或 ~/.agents/.mcp.json 已配智谱 server；旧通道双注册纯冗余）。
		// v1.5.198 通用 mcpServers 配置消费：子 Agent 按角色路由过滤（默认智谱系，baize 额外全部），
		// 避免所有 server 全量拖进每个子进程。
		// v1.5.218 双修复（实战：baize settle 后挂 16min 被主上手杀）：
		//  ① lazyDiscovery——跳过注册期 discovery：stdio server 的 tools/list 会 spawn npx 常驻子进程，
		//    管道挂住 print 模式事件循环导致 turn 完成后进程永不退出；子进程 discovery 本就不可达
		//    （v1.5.250 后台发现仅刷缓存供 mcp_list_tools 展示，不再注册直连工具）。
		//  ② agent_settled → close()——mcp_call 真用过的 stdio server 在 turn 结束即收口，事件循环可空、进程自然退出。
		// C3（复盘 2026-08-20 跨仓webui六连修：mcp_call 错形连败 4 次）：注册流捕获原生 mcp_call 后
		// 同名覆盖为形状纠错包装——错形调用（业务字段放顶层/嵌 arguments 但缺 server/tool）拿到含
		// 实际字段名的可复制形状示例，而非裸 Validation failed；
		// 正确形状原样透传原生 execute；捕获/覆盖失败静默保持原生（零行为变化）。
		// v1.5.250：MCP 单通道化——远端工具不再直连注册（识图链 read→skill→mcp_call 的优先级
		// 被一等直连工具短路，实战 2026-08-25）；mcp_call/mcp_list_tools 为 MCP 唯一工具面。
		try {
			const onlyServers = resolveAgentMcpServers(process.cwd(), process.env.AMAGI_AGENT);
			// P4（§5.2/§8.3-P4）：子进程 MCP 执法面——冻结 grant.mcp 派生（P1 占位 server 自动归一为 "*"；
			// server 级收窄由路由承担）；sideEffects 由保证等级推导（缺省只读执法：未知工具性质不得当只读）。
			const childGrant = childPermissionGrantFromEnv();
			const mcpCapture = createMcpCallCapturePi(pi);
			const mcpHandle = registerConfiguredMcpServers(mcpCapture.pi, {
				cwd: process.cwd(), onlyServers, lazyDiscovery: true, route: { kind: "agent", agent: process.env.AMAGI_AGENT || undefined },
				...(childGrant !== undefined ? { permission: normalizeMcpPermission(childGrant.mcp, { sideEffects: childGrant.assurance === "guarded" }) } : {}),
			});
			registerMcpCallShapeOverride(pi, mcpCapture.takeNative());
			try { pi.on("agent_settled", () => { try { mcpHandle.close(); } catch { /* lint-exempt:close 尽力而为 */ } }); } catch { /* lint-exempt:事件不可用防御 */ }
		} catch { /* lint-exempt:静默降级 */ }
		finally { clearMcpEnvBundle(); }
		// LSP：子进程同注册（懒：首次调用才检测/起 server）；agent_settled + session_shutdown 双重关池
		// （v1.5.218 教训：stdio 子进程挂事件循环导致 print 模式不退出）。
		// v1.5.220 审核加固：baize 纯只读角色强制 lsp 只读（rename 拒绝）；其余角色走用户 lsp.readOnly 配置。
		try {
			// P4（§5.2/§8.3-P4）：子进程 LSP 执法面——冻结 grant.lsp/write/deny 派生
			//（rename 全目标授权才应用；无写面一律拒绝）；未注入=legacy（v1 行为不变）。
			const childGrantLsp = childPermissionGrantFromEnv();
			// ev-20260919（LSP 降级配套）：预检剥除后 lsp 名单为空——不注册 lsp 工具（子 Agent 免见拒），
			// 降级事实已在 Leader 侧 completionAnnotation 透出。
			if (childGrantLsp !== undefined && childGrantLsp.lsp.length === 0) {
				lspToolHandle = undefined;
			} else {
			lspToolHandle = createLspTool({
				cwd: process.cwd(), readOnlyOverride: process.env.AMAGI_AGENT === "baize", pool: editDiagnostics?.sharedPool(),
				...(childGrantLsp !== undefined ? { permission: { lsp: childGrantLsp.lsp, writeRules: childGrantLsp.write, denyRules: childGrantLsp.deny } } : {}),
			});
			}
			if (lspToolHandle) pi.registerTool(withArgumentArtifactNormalization(lspToolHandle) as unknown as ToolDefinition);
			try { pi.on("agent_settled", () => { try { void lspToolHandle?.close(); } catch { /* lint-exempt:close 尽力而为 */ } }); } catch { /* lint-exempt:事件不可用防御 */ }
			try { pi.on("session_shutdown", () => { try { void lspToolHandle?.close(); } catch { /* lint-exempt:close 尽力而为 */ } }); } catch { /* lint-exempt:事件不可用防御 */ }
		} catch { /* lint-exempt:静默降级 */ }

		// v2.8.8：运行中 steer 注入——Leader 经 task_control steer 写入通道文件（task-steer/<taskId>.jsonl），
		// 本子进程在每次模型请求前把活跃调整注入 messages（持续可见至任务结束；AMAGI_TASK_ID 定位通道，
		// 无任务上下文/无通道文件零开销 no-op）。
		try { registerSteerInjection(pi); } catch { /* lint-exempt:静默降级（不影响任务执行） */ }
		// v1.5.222 settle 权威自退：终稿交付（agent_settled）后由子进程自己收口——
		// 上方 MCP/LSP close 清理句柄，宽限 stdout flush 后仍未自然退出（未知句柄泄漏挂住
		// 事件循环）则 exit(0)。父进程 25s 猜测式兜底由此降级为最后防线（且只认真终稿帧）。
		// 实战（cbc75699）：父进程靠帧间隙猜 "已 settle" 误杀 SDK 退避重试中的子进程并误标 done。
		// 幂等：agent_settled 多次触发只调度首个计时器。AMAGI_CHILD_SELF_EXIT_MS 可调/0 关闭。
		try {
			let settleExitScheduled = false;
			pi.on("agent_settled", () => {
				if (settleExitScheduled) return;
				settleExitScheduled = true;
				scheduleChildSettleExit();
			});
		} catch { /* lint-exempt:事件不可用防御 */ }
		return;
	}

	const moduleDir = path.dirname(fileURLToPath(import.meta.url));
	const packageRoot = path.resolve(moduleDir, "..", "..");
	const agentsDir = path.join(packageRoot, "agents");
	const { agents } = discoverAgents(agentsDir);

	// ── K8c 组合根：唯一 owner 接线（方案 §3.1/§3.3/§8.1-K8c；子进程分支已在上方提前返回） ──
	// 实例化进程级唯一内核（FileTaskStore + createTaskKernel 经 task-service 单例，首个创建者生效），
	// ownerId 从可信来源注入；GC 缺省已拆（K3 裁量⑤）：onSettle 注入等价清理适配器（registry.settleGc），
	// legacy 直写路径同步注入回调。内核实例化不写盘（无 register 命令零 CAS），失败降级为惰性路径。
	//
	// H2（§8.4-H2 条目9）reload/switch owner 生命周期（宿主行为依据——H1 host-capabilities
	// CAPABILITY_FACTS.reloadSwitchLifecycle + 宿主 dist 实证）：reload 时宿主先发
	// session_shutdown(reason="reload")，再 oldRunner.invalidate()（旧 ctx 置 stale，任何再提交
	// 抛错——旧 realm 不可能再写状态），随后 clearExtensionCache + jiti moduleCache:false 重求值
	// 扩展模块（旧 realm 模块级单例随旧运行时整体废弃，新 realm 冷启动重建）。因此不生第二 owner：
	// ①跨 realm：旧 ctx 已失效，新 realm 走本接线重新创建内核（ownerId 稳定同源：user@hostname
	// 派生，磁盘 store 同根幂等重建）；②同 realm（宿主未来若改为复用模块 realm，防御）：
	// getTaskKernel 单例幂等（首建者生效，二次调用返回同一实例，不双建内核/store、不重装桥）。
	// 下方 session_shutdown 收尾同步释放进程级句柄（见 handler 内 H2 注记）。
	const leaderOwnerId = resolveLeaderOwnerId();
	// v2.1-A1：机器身份注入——①派发冻结面（task-service 冻结 spec.machineId：新记录携带本机标识）；
	// ②恢复对账（machineId 匹配的记录识别为本机历史，不再误报 foreign-owner）。getMachineId 永不变更
	// （machine.json 持久 UUID；损坏回退 hostname 派生并告警，见 data-dir.ts）。
	const leaderMachineId = getMachineId();
	try { setLeaderMachineStamp(leaderMachineId); } catch { /* lint-exempt:注入失败=不盖章，对账保守 foreign-owner 报告 */ }
	/** 启动对账报告缓存（query_task({recovery:true}) 可查询；启动后异步填充）。 */
	let startupRecoveryReport: { scannedAt: number; text: string; sessionKey?: string } | undefined;
	try {
		getTaskKernel({ ownerId: leaderOwnerId, onSettle: (taskId) => registry.settleGc(taskId) });
		registry.installSettleHook((taskId) => registry.settleGc(taskId));
	} catch (e) {
		console.warn(`[amagi-core] 任务内核 owner 实例化失败（降级为首个提交时惰性创建）: ${e instanceof Error ? e.message : String(e)}`);
	}
	// K8c 只读三轴供给（DI）：TUI 看板/webui 面板/三轴查询共用的验收轴数据源——默认接 registry
	// 投影（无验收轴→无标签），组合根接内核视图；只读 peek，关闭 UI 不影响执行。
	const kernelAxisOf: TaskAxisOf = (taskId: string) => {
		try {
			const view = peekTaskKernel()?.get(taskId);
			return view ? { execution: view.execution, settlement: view.settlement, acceptance: view.acceptance } : undefined;
		} catch { /* journal:kernel-peek-fallback */ return undefined; }
	};

	// ── ev-20260918：会话级项目信任捕获 ──
	// 宿主契约 isProjectTrusted 只在事件 ctx（session_start 等）提供，工具 execute ctx 不携带；
	// 在此捕获会话信任态作为 setTrustFallback 回退源（auto-baseline 检查/autoVerify 不再全体失效）。
	// 未捕获会话（首帧前/无事件环境）保持旧 fail-closed（false）语义，不猜。
	let sessionTrustCtx: { isProjectTrusted?: () => boolean } | undefined;
	pi.on("session_start", (_event: unknown, ctx: unknown) => {
		sessionTrustCtx = ctx as typeof sessionTrustCtx;
	});
	setTrustFallback(() => sessionTrustCtx?.isProjectTrusted?.());

	if (agents.length === 0) {
		console.warn(`[amagi-core] 未在 ${agentsDir} 发现可用 agents`);
	}

	// ── I2 组合根（方案 §4.1/§4.2/§4.3/§8.2-I2）：v2 分面工具面接线 ────────────────
	// 共存策略（I1 建议① → W1.2 单轨翻转）：四稳定分面（task_submit/resume/control/query）注册即常驻；
	// legacy task/query_task 注册面保留、模型面单轨翻转——新会话从活跃集剔除（onSessionStart 经
	// setActiveTools，见 tool-surface.ts），双轨留档（surfaceVersion=1）会话 resume 或
	// AMAGI_SURFACE_LEGACY=1 逃生舱保留；#agent 硬路由/amagi-commands/shortcuts/WebUI resume
	// 等内部链路不经模型面零影响。task_batch 高级
	// 分面仅显式 enableFacet 可见（amagi_resource({resource:"tools",enableFacet:"batch"})），
	// 会话面只追加不减、surfaceVersion 会话内固定（amagi:tool-surface 留档）。CallerContext
	// 只在此构造（模型参数不能伪造，N8）；受信 profile 名单 = model-resolver 受信配置名。
	// W1.2：legacy 模型面工具名——task 名随 AMAGI_TASK_TOOL_NAME，query_task 固定；注入 tool-surface
	const legacyTaskToolName = process.env.AMAGI_TASK_TOOL_NAME || "task";
	const leaderCaller: CallerContext = {
		ownerId: leaderOwnerId,
		actor: "leader",
		actorId: leaderOwnerId,
		authority: { maxAssurance: "guarded", profiles: ["tiered", "inherit"], facets: ["batch"] },
	};
	const facetNotify = (msg: string, opts?: { deliverAs?: "steer" | "followUp" | "nextTurn" }): void => {
		// 宿主 sendUserMessage 仅接 steer/followUp；nextTurn（分面依赖声明里的宽容位，实际调用均 steer）退宿主缺省投递
		const deliverAs = opts?.deliverAs === "nextTurn" ? undefined : opts?.deliverAs;
		try { pi.sendUserMessage(msg, deliverAs === undefined ? undefined : { deliverAs }); } catch { /* lint-exempt:通知失败不回滚任务/组状态 */ }
	};
	const facetSink = { sendUserMessage: facetNotify,
		...(typeof pi.sendMessage === "function" ? { sendMessage: pi.sendMessage.bind(pi) } : {}) };
	let toolSurface: ReturnType<typeof createToolSurface> | undefined;
	try {
		// ev-20261101-cbf452：完成通知经 sendMessage（custom 消息通道，customType=amagi:task-completion，
		// details 携带 taskId/采集证明——evidence-context 的采集降噪投影也只认这个通道）。此前只接
		// sendUserMessage，通知以无标记 role=user 进入会话，被 L1 关键词供给当新用户请求逐条命中
		//（M01 实测 4/4 次通知各注入 2-3k 无关片段）；机器消息回到机器通道，真实用户消息不受影响。
		// legacy 兼容：旧宿主无 sendMessage 时 sendTaskCompletion 自动退 sendUserMessage，行为不变。
		for (const tool of createTaskFacetTools({ agents, caller: leaderCaller, pi: facetSink })) {
			pi.registerTool(withArgumentArtifactNormalization(tool) as unknown as ToolDefinition);
		}
		toolSurface = createToolSurface(pi as unknown as SurfaceHost, {
			subagent: false,
			caller: leaderCaller,
			surfaceVersion: TASK_FACET_SURFACE_VERSION,
			baseStamp: taskFacetSurfaceStamp(),
			legacyToolNames: [legacyTaskToolName, "query_task"],
		});
		toolSurface.registerFacets({
			batch: { tools: () => [createTaskBatchTool({ agents, caller: leaderCaller, pi: facetSink })] },
		});
	} catch (e) {
		console.warn(`[amagi-core] v2 分面工具面接线失败（不影响 legacy task 工具）: ${e instanceof Error ? e.message : String(e)}`);
	}

	// M1 WebUI server: lifecycle registration only. The factory remains side-effect free;
	// session_start binds loopback, while the AMAGI_SUBAGENT branch returned above.
	if (isWebUiEnabled()) {
		try {
			// v1.0.15 子 Agent 会话查询/交互 adapter（协议 docs/webui-protocol.md §4.8/§4.9）：webui
			// 子树不得 import 主扩展模块（depcruise webui-isolated），registry 匹配、会话文件定位
			// （session-viewer.resolveSessionFile）与 resume 派发（task-tool.runResumeTask）全在本闭包装配。
			// ctx 来源与 answer-queue 装配同源：session_start 捕获 pi 传入的 ctx（cwd/项目信任门控/模型表）。
			// 会话 JSONL 由子进程实时落盘，侧边栏轮询尾读即见实时增量（无需子进程内推通道）。
			let orchCtx: {
				cwd?: string;
				isProjectTrusted?: () => boolean;
				modelRegistry?: Parameters<typeof runResumeTask>[2]["modelRegistry"];
			} | undefined;
			pi.on("session_start", (_event: unknown, ctx: unknown) => { orchCtx = ctx as typeof orchCtx; });
			const orch: WebUiOrchAdapter = {
				async agentSession(taskId) {
					const records = registry.list();
					const record = matchTaskId(records, taskId);
					if (!record) return { ok: false, error: "task_not_found" };
					// 会话文件定位（含运行中兜底，2026-09-11 真机「未找到会话文件」修复）：
					// registry 的 record.sessionId 于任务终结时才回填，running/queued 期间为空；
					// resolveAgentSessionFile 在其缺失时经 journal 首帧 session 见证行（spawn ~首帧落盘）
					// 补读映射，使运行中任务也能实时读取会话（侧边栏轮询场景）。
					// 子会话落盘目录按任务 cwd 编码（resume 与原目录绑定）；无记录 cwd 时回退 Leader cwd
					// （resolveSessionFile 内部还有跨 sessions 子目录的全局兜底）。
					const file = resolveAgentSessionFile(record, {
						records,
						cwd: record.cwd || orchCtx?.cwd || process.cwd(),
					}, {
						resolveFile: resolveSessionFile,
						findJournalSessionId: (tid) => journalLookupByPrefix(tid)?.sessionId,
					});
					if (!file) {
						// 有 sessionId 仍找不到 = 文件缺失/被清理；无 sessionId（且 journal 无见证行，通常为刚派发）
						// = 会话尚未创建——文案区分，避免误导为「读取异常」。
						const reason = record.sessionId
							? "未找到会话文件（可能已被清理）"
							: "会话尚未创建（任务刚启动且首帧未落盘，稍后重试）";
						return { ok: true, body: buildAgentSessionBody(record, null, null, `${reason}（taskId=${record.taskId}）`) };
					}
					try {
						return { ok: true, body: buildAgentSessionBody(record, file, await readAgentSessionText(file)) };
					} catch (error) {
						// 文件存在但读失败（权限/竞态删除）：降级为 200 + entries:[] + error，前端自行提示。
						const message = error instanceof Error ? error.message : String(error);
						return { ok: true, body: buildAgentSessionBody(record, file, null, `读取会话失败：${message}`) };
					}
				},
				async interact(taskId, text) {
					const records = registry.list();
					const record = matchTaskId(records, taskId);
					if (!record) return { ok: false, error: "task_not_found" };
					// 子 Agent 是独立 pi 进程，运行中无 steer 管道：可交互面 = blocked 待答/接手 + 终态续跑
					// （决策②，与 answer-queue 同链路）。running/queued/answering 一律拒绝。
					if (record.status === "running" || record.status === "queued" || record.status === "answering") {
						return { ok: false, error: "not_interactable", message: `任务 ${record.taskId} 当前状态 ${record.status}，运行中不可交互` };
					}
					if (record.status === "resolved-external") {
						return { ok: false, error: "resolved_external", message: record.resolveNote ? `任务已外部处置收口：${record.resolveNote}` : "任务已外部处置收口" };
					}
					if (!record.sessionId) return { ok: false, error: "no_session", message: `任务 ${record.taskId} 无 sessionId` };
					const agent = findAgentByRequest(agents, record.agent);
					if (!agent) return { ok: false, error: "not_interactable", message: `角色 ${record.agent} 未注册` };
					// 只扇出 background:true（协议硬约束）：sync 会阻塞 HTTP 请求直到子任务跑完。
					const res = await runResumeTask(agent, { session: record.taskId, task: text, background: true }, {
						cwd: record.cwd || orchCtx?.cwd || process.cwd(),
						modelRegistry: orchCtx?.modelRegistry,
						trusted: resolveProjectTrusted(orchCtx),
					});
					// 准入前拒绝（rejected：未 spawn/未建记录）映射 409：外部处置/无 sessionId 精确归一，
					// 其余（运行中竞态/lease 占用/预算拒单/熔断/模型校验）归 not_interactable，message 带真实根因。
					if ((res as { rejected?: boolean }).rejected) {
						const message = (res as { errorMessage?: string }).errorMessage || "resume 被拒绝";
						if (message.includes("已外部处置")) return { ok: false, error: "resolved_external", message };
						if (message.includes("无 sessionId")) return { ok: false, error: "no_session", message };
						return { ok: false, error: "not_interactable", message };
					}
					return { ok: true, taskId: res.taskId, status: "running" };
				},
			};
			// v1.0.17 /api/recovery 数据源（协议 §4.10）：scanTaskRecovery 只读模式（零写入零 spawn）
			// 经注入 adapter 承载——webui 子树不 import task-recovery（depcruise webui-isolated），
			// 扫描本体在本闭包装配；sessionKey 取当前会话盖章（A1 语义如实：本会话绑定 vs pull-only
			// 标注、actionable 计数只计本会话可行动项；盖章缺席时不过滤=全量视图）。每次请求即时重扫
			// （只读），报告 scannedAt 即扫描时刻。
			const recoveryAdapter: WebUiRecoveryAdapter = {
				scan: () => scanTaskRecovery({
					ownerId: leaderOwnerId,
					machineId: leaderMachineId,
					sessionKey: getLeaderSessionStamp(),
				}),
			};
			// B7（十月迭代 M3）链路①：RPC 活跃对话框应答面（broker 汇聚 primary+adopted）。
			// 已知限制：订阅挂接当前已存在的 broker（池 lazy 创建后新 broker 不追溯挂接）——
			// 前端 2s 轮询兑底刷新（rpc_dialog 事件仅加速，不是正确性依赖）。
			const rpcDialogsAdapter: WebUiRpcDialogAdapter = {
				dialogs: () => (rpcPoolController ? rpcPoolController.dialogBrokers().flatMap((b) => b.list()) : []),
				respond: async (key, answer) => {
					for (const broker of rpcPoolController?.dialogBrokers() ?? []) {
						const r = broker.submit(key, answer);
						if (r.ok || r.code !== "not-found") return { ok: r.ok, code: r.code, ...(r.message ? { message: r.message } : {}) };
					}
					return { ok: false, code: "not-found", message: "对话不存在（未发起/已收口/键不匹配）" };
				},
				subscribe: (listener) => {
					const offs = (rpcPoolController?.dialogBrokers() ?? []).map((b) => b.subscribe(listener));
					return () => { for (const off of offs) off(); };
				},
				onClientsEmpty: () => {
					for (const broker of rpcPoolController?.dialogBrokers() ?? []) broker.cancelDangerous("webui-last-client-closed");
				},
			};
			// B7 链路②：blocked 远程恢复（nonce 由 server 签发消费；重查状态走既有 resume 链）
			const resumeAdapter: WebUiResumeAdapter = {
				entry: async (taskId) => {
					const record = matchTaskId(registry.list(), taskId);
					if (!record) return { ok: false, error: "task_not_found" };
					if (record.status !== "blocked") return { ok: false, error: "not_blocked", message: `任务 ${record.taskId} 当前状态 ${record.status}（仅 blocked 可远程恢复）` };
					if (!record.sessionId) return { ok: false, error: "no_session", message: `任务 ${record.taskId} 无 sessionId` };
					const cap = (t: string, n: number) => (t.length <= n ? t : t.slice(0, n));
					return { ok: true, entry: {
						taskId: record.taskId, agent: record.agent, status: "blocked",
						blockReason: record.blockReason === "needs-handoff" || record.blockReason === "questions" ? record.blockReason : null,
						questions: (record.blockedQuestions ?? []).slice(0, 5).map((q) => cap(String(q).replace(/\s+/g, " "), 200)),
						resumeDraft: renderRelaySubmitDraft(record),
					} };
				},
				answer: async (taskId, answerText) => {
					const record = matchTaskId(registry.list(), taskId);
					if (!record) return { ok: false, error: "task_not_found" };
					if (record.status !== "blocked") return { ok: false, error: "conflict", message: `任务 ${record.taskId} 当前状态 ${record.status}，仅 blocked 可恢复（状态已改变）` };
					const agent = findAgentByRequest(agents, record.agent);
					if (!agent) return { ok: false, error: "rejected", message: `角色 ${record.agent} 未注册` };
					const res = await runResumeTask(agent, { session: record.taskId, task: answerText, background: true }, {
						cwd: record.cwd || orchCtx?.cwd || process.cwd(),
						modelRegistry: orchCtx?.modelRegistry,
						trusted: resolveProjectTrusted(orchCtx),
					});
					if ((res as { rejected?: boolean }).rejected) {
						return { ok: false, error: "rejected", message: (res as { errorMessage?: string }).errorMessage || "resume 被拒绝（未启动）" };
					}
					return { ok: true, taskId: record.taskId, successorTaskId: res.taskId, status: "running" };
				},
			};
			const webui = registerWebUi(pi, { orch, recovery: recoveryAdapter, rpcDialogs: rpcDialogsAdapter, resume: resumeAdapter });
			// v1.0.4 usage 数据面（源 b/c）：writeStats 是子任务 usage 落盘唯一漏斗——模块级
			// 监听器把 entry 喂进 registerWebUi 闭包的 UsageStore（有限数值才累计；server 未
			// 启动时暂存闭包、创建时经构造注入），scope 用 task-registry 快照计算（active 口径
			// 对齐 status-ui selectPanelTasks 的 running/queued，另含 answering 的 resume 在途
			// 态），每次更新后立即发布 usage_stats。
			// 幂等权衡：同一任务 resume 多轮会多次 writeStats——usage 是累计仪表盘，接受重复累计。
			setStatsListener((entry) => {
				try {
					webui.usage.recordChild(entry);
					const records = registry.list();
					webui.usage.setScope(records.length > 0 ? {
						tasks: records.length,
						active: records.filter((r) => r.status === "running" || r.status === "queued" || r.status === "answering").length,
					} : null);
					webui.current()?.updateUsage(webui.usage.snapshot());
				} catch { /* lint-exempt:usage 观测面绝不反噬任务主流程 */ }
			});
			// v1.0.5 编排实况面板数据面（与 usage 同型）：registry.onChange → buildTaskPanel（选择/排序/裁剪
			// 语义权威=status-ui）→ webui.panel.update（server 未启动时闭包暂存，session_start 创建时构造注入
			// hello；已创建时立即发布 task_panel）。TTL 过期消失：onChange 只在变更时触发，结算项到期需
			// 时间驱动——最新快照含 settled 项时安排一次性 setTimeout（最早过期时刻+25ms 守护，含等边界
			// `now-endedAt<=TTL` 在恰到期时刻仍含，守护避免空转补发）再发一次快照；新快照无 settled 项时
			// 清旧 timer；每次发布后重算。timer unref 不阻止进程退出，面板观测面绝不反噬任务主流程。
			let panelTimer: ReturnType<typeof setTimeout> | undefined;
			const publishTaskPanel = (): void => {
				const now = Date.now();
				const records = registry.list();
				// B0-2 上下文占比（只读 DI）：tokens 来自 consumeLine 的 lastCall 三分项和；上限经宿主
				// modelRegistry 只读解析（未注册/无字段=undefined→前端「上限未知」，不编造）。两者均不
				// 回流 registry/内核（纯观测面）；面板发布时机不变（registry.onChange 驱动）。
				webui.panel.update(buildTaskPanel(records, now, {
					axisOf: kernelAxisOf,
					contextTokensOf: liveContextTokensOf,
					contextWindowOf: (model) => contextWindowOf(orchCtx?.modelRegistry, model),
				}));
				if (panelTimer) { clearTimeout(panelTimer); panelTimer = undefined; }
				const expiry = earliestExpiryAt(records, now);
				if (expiry !== null) {
					panelTimer = setTimeout(() => {
						panelTimer = undefined;
						try { publishTaskPanel(); } catch { /* lint-exempt:观测面绝不反噬主流程 */ }
					}, Math.max(0, expiry - Date.now()) + 25);
					panelTimer.unref?.();
				}
			};
			// B0-2 补链：子任务上下文 token 观测驱动面板重发——publishTaskPanel 此前仅 registry.onChange
			// 触发，running 长任务上下文持续增长而状态不变 → 占比环不动/迟现（codebox 实战反馈）。
			// 观测点每次 assistant 完结帧触发（多任务并发更高频），trailing 节流 600ms 合并；
			// 观测面异常绝不反噬任务主流程（webui 未启用时本段不装配，listener 缺席无害）。
			const PANEL_CTX_REFRESH_MS = 600;
			let panelCtxTimer: ReturnType<typeof setTimeout> | undefined;
			setPanelContextListener(() => {
				if (panelCtxTimer) return;
				panelCtxTimer = setTimeout(() => {
					panelCtxTimer = undefined;
					try { publishTaskPanel(); } catch { /* lint-exempt:观测面绝不反噬主流程 */ }
				}, PANEL_CTX_REFRESH_MS);
				panelCtxTimer.unref?.();
			});
			registry.onChange(() => { try { publishTaskPanel(); } catch { /* lint-exempt:观测面绝不反噬主流程 */ } });
			pi.on("session_shutdown", () => {
				try {
					if (panelTimer) { clearTimeout(panelTimer); panelTimer = undefined; }
					if (panelCtxTimer) { clearTimeout(panelCtxTimer); panelCtxTimer = undefined; }
				} catch { /* lint-exempt:清理尽力而为 */ }
			});
		}
		catch (e) { console.warn(`[amagi-core] webui 注册失败（不影响主功能）: ${e instanceof Error ? e.message : String(e)}`); }
	}

	pi.registerTool(withArgumentArtifactNormalization(createTaskTool(agents, legacyTaskToolName, pi)) as unknown as ToolDefinition);
	// K8c：startupRecovery 供给注入（v2.1 会话精确绑定：resume 会话预热缓存；其余会话懒扫描——
	// 只读零应用，查询面在任何会话都可用）
	pi.registerTool(withArgumentArtifactNormalization(createQueryTaskTool({
		agents,
		startupRecovery: async () => {
			// 缓存按会话键失效：/resume 切换会话后旧缓存不再命中，重扫全量（只读零应用）
			if (startupRecoveryReport && startupRecoveryReport.sessionKey === getLeaderSessionStamp()) return startupRecoveryReport;
			try {
				const report = await scanTaskRecovery({ ownerId: leaderOwnerId, machineId: leaderMachineId });
				startupRecoveryReport = { scannedAt: report.scannedAt, text: formatRecoveryReport(report), sessionKey: getLeaderSessionStamp() };
			} catch { /* lint-exempt:懒扫描失败 → 报告不可用（如实返回 undefined，不猜） */ }
			return startupRecoveryReport;
		},
	})) as unknown as ToolDefinition);
	// P2-3: amagi_resource 工具（主进程 + 子进程均注册，见上方 SUBAGENT 分支）
	// v2-I2（§4.3）：enableFacet="batch" 通道（仅 resource=tools 时有效；子进程/未接线明确拒绝）
	pi.registerTool(withArgumentArtifactNormalization(createResourceReaderTool(packageRoot, {
		onEnableFacet: (facet) => toolSurface
			? toolSurface.enableFacet(facet)
			: { ok: false, code: "surface-unavailable", message: "工具面治理器未初始化（接线失败或会话未就绪）——本次启用被拒，稍后重试或使用 legacy task 工具" },
	})) as unknown as ToolDefinition);
	// v1.5.174: amagi_evolution 工具（插件自进化日志：沉淀摩擦点 / 取未解决项迭代 / 标记解决自动迁移）
	pi.registerTool(withArgumentArtifactNormalization(createEvolutionTool({ packageRoot })) as unknown as ToolDefinition);
	// v1.5.193: amagi_handbook 工具（战术手册查询接口 + dormant 生命周期执行，sidecar 持久）
	pi.registerTool(withArgumentArtifactNormalization(createHandbookTool({ packageRoot })) as unknown as ToolDefinition);
	// 十月迭代原生应用控制：codex_computer_use——官方 Codex App Server 自有实例的原生 Computer Use
	// 模型委托（新合法 source，非 Desktop 复用）。Leader-only：仅在非 AMAGI_SUBAGENT 分支且
	// AMAGI_CODEX_COMPUTER_USE=1 显式启用时注册（禁用即不注册且 execute 拒绝；SubAgent 永不开放）。
	// 源 CU 许可只经真实人工 elicitation 转交（ctx.ui），不自动授权；边界详见模块头注释。
	if (codexComputerUseEnabled()) {
		try {
			pi.registerTool(withArgumentArtifactNormalization(createCodexComputerUseTool()) as unknown as ToolDefinition);
		} catch (e) {
			console.warn(`[amagi-core] codex_computer_use 注册失败: ${e instanceof Error ? e.message : String(e)}`);
		}
	}
	// v1.5.198: 通用 mcpServers 配置消费（http+stdio；智谱视觉理解 MCP 等 Local server 的唯一接入路径）
	// v1.5.245：原 P4-4 registerMcpTools（智谱三件套自实现 web_search/zread×3/web_reader）已删——
	// 与本通道功能重复且双注册占用工具名；协议件（rpcRequest/isSessionError/truncateMcpText/
	// resolveMcpCallTimeoutMs）已并入 mcp-client.ts。
	// C3（同 SUBAGENT 分支注释）：mcp_call 形状纠错包装——错形调用拿纠错示例而非裸 Validation failed；
	// 正确形状透传原生；捕获/覆盖失败静默保持原生。
	try {
		const mcpCapture = createMcpCallCapturePi(pi);
		// 与默认 registerGuards 共用本次装配的会话混合决议（拒绝时内部已告警）。
		// v2.8.2：Leader 侧 mcp.leader 白名单（amagi.json；缺省未配置 = ["*"] 全量，行为不变）——
		// 复用子 Agent 角色路由同款 onlyServers 过滤与告警降噪链路；装配时读一次，改动需重启 pi 生效。
		registerConfiguredMcpServers(mcpCapture.pi, { cwd: process.cwd(), onlyServers: leaderMcpRoute(process.cwd()), route: { kind: "leader" }, ownershipPlan: mcpHybrid?.status === "mixed" ? mcpHybrid.plan : undefined });
		registerMcpCallShapeOverride(pi, mcpCapture.takeNative());
	} catch (e) { console.warn(`[amagi-core] mcpServers 配置加载失败（不影响内置 MCP 工具）: ${e instanceof Error ? e.message : e}`); }
	// LSP：主进程同注册（懒：首次调用才检测/起 server；session_shutdown 关池；P1-D 与诊断注入共享池）
	try {
		lspToolHandle = createLspTool({ cwd: process.cwd(), pool: editDiagnostics?.sharedPool() });
		pi.registerTool(withArgumentArtifactNormalization(lspToolHandle) as unknown as ToolDefinition);
	} catch (e) { console.warn(`[amagi-core] lsp 工具注册失败（不影响主功能）: ${e instanceof Error ? e.message : e}`); }
	// P4-2: 确定性路由 #<角色> <任务> / #review（input 事件拦截，不经 Leader LLM 路由）
	// T2-1: workflow 看板 overlay（角色状态矩阵/任务进度/blocked 队列）；v1.5.178: 提前创建供 input-router #board/#panel 复用
	// v1.5.218 M3: 三级视图（board→task→viewer）+ ⌥W 键位组（ui.keys 覆盖）
	const boardCtl = registerWorkflowBoard(pi, { agents, taskRegistry: registry, axisOf: kernelAxisOf });
	// P4-2 + v1.5.178: #board 开看板 / #panel <n> 直达第 n 个 running 任务会话面板（序号与常驻面板编号一致：startedAt 升序）
	// 活性看门狗（非 TUI 普通静默默认保留 30min，超时→abort→子进程硬退出兜底；
	// TUI 只告警、绝不中断；模型/turn/工具 start-update-end 每个新动作都会重置静默窗口，
	// 工具在飞不再无限豁免。同步 SubAgent 由子进程 watchdog 监视；已知交互式命令由 guards 预先拦截）
	registerWatchdog(pi as unknown as WatchdogPi);
	// B4（十月迭代 M2）：工具卡统一语义投影——能力门内注册（1.0.1+ registerToolRenderer），
	// 旧宿主零注册零报错；子进程分支不注册（渲染仅交互 TUI）。
	const b4Renderers = registerAmagiToolRenderers(pi as unknown as Parameters<typeof registerAmagiToolRenderers>[0]);
	if (!b4Renderers.registered) tuiWarn(`B4 工具卡未启用：${b4Renderers.reason ?? "能力门未过"}`);
	registerInputRouter(pi, {
		agents, runTask,
		openBoard: (ctx, opts) => boardCtl.open(ctx, opts?.taskId),
		listRunning: () => selectPanelTasks(registry.list()),
	});
	// P4-5: amagi 快捷键（v1.5.218 键位迁移：⌥R 审 diff / ⌥T 任务列表 + legacy 兼容键），无 session 生命周期依赖
	const shortcutsCtl = registerAmagiShortcuts(pi, { agents, runTask, taskRegistry: registry });
	// ev-20260930-08a8e7 切片2：冻结进程启动时宿主包版本（升级窗口提示基准；失败=未知定格，不猜）
	try { captureStartupHostVersion(); } catch { /* lint-exempt:探测失败=未知态，提示面如实缺席 */ }
	// v1.5.218 M1-02: /amagi 命令层（L1 必达交互通道）——board/session 复用 boardCtl.open（支持 viewer 直达），tasks 复用任务列表 widget toggle，review 复用 shortcuts 派发路径。
	let harnessInfoRenderer = false;
	try { harnessInfoRenderer = registerHarnessInfoRenderer(pi); } catch { /* lint-exempt:旧宿主只降级用户展示，不进入模型上下文 */ }
	registerAmagiCommands(pi as never, {
		showInfo: (text, ctx) => harnessInfoEmitter(pi, harnessInfoRenderer)(text, ctx as { mode?: string }),
		configuration: {
			explain: (ctx, agent) => explainConfiguration(agents, { ...(ctx as ConfigurationContext), isProjectTrusted: (ctx as { isProjectTrusted?: () => boolean }).isProjectTrusted }, agent),
			doctor: (ctx) => configurationDoctor(agents, pi, ctx as ConfigurationContext),
			initialize: (ctx, preset) => initializeProjectConfiguration((ctx as ConfigurationContext).cwd, preset),
		},
		taskRegistry: registry,
		// ev-20260917-7b9298（P2）：/amagi orphans 诊断入口——列出/清理 amagi 血统孤儿进程
		//（父链已死 ppid=1 且 env 带标记；排除 run_bg 活跃句柄防误杀托管后台任务）
		diagnoseOrphans: () => diagnoseOrphans({ keepPids: activeRunBgPids() }),
		// ev-20261008-30e744 F-01 切片 A：clean 以诊断锚点为期望，并在清理时复核 run_bg 活跃句柄（I6）
		reapDiagnosedOrphans: (orphans) => reapDiagnosedOrphans(orphans, { keepPids: activeRunBgPids() }),
		// v2.1-A1：foreign-owner 历史记录确认收口通道（用户显式确认后写 adopted 注记并归并对账流）
		adoptRecoveryTask: async (taskId) => adoptRecoveryRecord(taskId, { ownerId: leaderOwnerId, machineId: leaderMachineId }),
		// ev-20261021-a8de95：无启动锚点记录的人工退出确认（只写注记；收口仍经 task_control reconcile 的退出证明）
		attestRecoveryExit: async (taskId) => attestTaskExited(taskId, { ownerId: leaderOwnerId }),
		// ev-20260930-08a8e7：恢复对账列表（scan 只读零写入；会话盖章绑定标注如实——清单任何会话可查）
		scanRecoveryReport: async () => {
			const report = await scanTaskRecovery({
				ownerId: leaderOwnerId,
				machineId: leaderMachineId,
				sessionKey: getLeaderSessionStamp(),
			});
			return { ok: true, message: formatRecoveryReport(report) };
		},
		// ev-20260930-08a8e7：单任务断点明细（store 精确查 + 重新观测 + 完整声明清单；显式拉取按原身份/安全规则只读展开）
		showRecoveryTask: async (taskId) => {
			const r = await showRecoveryCheckpoint(taskId, { ownerId: leaderOwnerId, machineId: leaderMachineId });
			return { ok: r.ok, message: r.message };
		},
		// B0-2（§3.4）：/amagi stats [days] 文本供给（只读聚合；Leader 分支用量经 ctx.sessionManager
		// getBranch() 投影——分支可见口径，与 pi 原生全会话口径可能不同；输出只进用户界面不进模型上下文）。
		// win_exec 自检（/amagi win-doctor）：真实探测（WSL/interop/程序解析/编码/Job Object 冒烟）
		winDoctor: () => runWinDoctor(),
		statsSummary: (days, ctxRaw) => {
			const model = aggregateStats({ days });
			let sessionText: string;
			try {
				const branch = (ctxRaw as { sessionManager?: { getBranch?: () => unknown[] } } | null)?.sessionManager?.getBranch?.();
				const view = aggregateSessionUsage(Array.isArray(branch) ? branch : [], readTraces(), getLeaderSessionStamp());
				sessionText = renderSessionUsageText(view);
			} catch { /* lint-exempt:会话面缺席如实降级文案——统计聚合主段不受影响 */
				sessionText = "本会话用量：不可用（无会话面——非交互模式下 Leader 分支视图缺席；子任务统计见上方聚合）";
			}
			return `${renderStatsText(model)}\n\n${sessionText}\n\n${sessionToolStatsSection(ctxRaw, readTraces(), getLeaderSessionStamp())}\n\n${renderObservationsText(readObservations(), readTraces(), { days, now: Date.now() })}`;
		},
		openBoard: (ctx, opts) => boardCtl.open(ctx, opts as { taskId?: string; initialView?: "viewer" }),
		toggleTasks: (ctx) => {
			// 任务列表 toggle 语义与 ⌥T 快捷键一致：由 shortcuts 内部状态机管理。
			// 此处经注册键 handler 不可直接触达（closure），改为轻量直写：开/关由 widget 当前态决定不可得，
			// 因此直接走 shortcuts 的公开面：重复注册场景由 reset+setWidget 等价实现（见 shortcutsCtl.reset）。
			void ctx; shortcutsCtl.reset(ctx as never);
			// reset 会清列表；再次按键语义由用户经 ⌥T 恢复——初版简化：命令层先保证可关闭/复位，不承担开态。
		},
		runReview: (p, ctx) => {
			const diting = agents.find((a) => a.name === "diting");
			if (!diting) { try { sendMachineNotice(p, MACHINE_NOTICE_TYPE, "[/amagi review] diting 角色未注册"); } catch { /* lint-exempt:sendMessage 尽力而为 */ } return; }
			try { (ctx as { ui?: { notify?(m: string, l?: string): void } }).ui?.notify?.("amagi: 已派发 diting 审核当前 diff，完成后自动回流", "info"); } catch { /* lint-exempt:ui.notify 尽力而为 */ }
			void (async () => {
				try {
					const { buildReviewTask } = await import("./input-router.ts");
					const res = await runTask(diting, buildReviewTask(""), { cwd: ctx.cwd });
					const status = res.blocked ? "blocked" : res.status;
					// ev-20261101-7fffc6：review 回流通 custom 机器通道（amagi:task-completion + details.taskId）。
					const notice = `${res.fuseWarning || ""}[/amagi review · ${status}]\n\n${res.output || res.errorMessage || "(无输出)"}${res.completionAnnotation || ""}`;
					if (res.taskId) sendTaskCompletion(p, notice, res.taskId);
					else sendMachineNotice(p, MACHINE_NOTICE_TYPE, notice);
				} catch (e) {
					try { sendMachineNotice(p, MACHINE_NOTICE_TYPE, `[/amagi review] 异常：${e instanceof Error ? e.message : String(e)}`); } catch { /* lint-exempt:sendMessage 尽力而为 */ }
				}
			})();
		},
	});
	// v1.5.218-f5：模型/推理强度切换即时刷新 status-ui（实况行含模型·思考强度段）。
	pi.on("model_select", () => { try { statusUI?.refresh(); } catch { /* lint-exempt:状态栏刷新尽力而为（轮询兜底） */ } });
	pi.on("thinking_level_select", () => { try { statusUI?.refresh(); } catch { /* lint-exempt:状态栏刷新尽力而为（轮询兜底） */ } });
	// 8月迭代 pi-0.84 配合 P2⑥：ui_prompt_start/ui_prompt_end——ctx.ui.select/confirm/input/
	// editor/custom 阻塞等待用户时，状态栏前置「⏸等输入」短标记（嵌套提示 pi 已合并为外层
	// span；事件 best-effort 不 await）。setUiPromptWaiting 内部自带 refresh 即时上屏。
	// 本仓库 node_modules 类型表（pi 0.83.0）尚无该事件重载 → 经 unknown 结构化订阅（continuation.ts P1③ 先例）；
	// 旧版 pi 运行时 on 对未知事件仅注册不抛错、事件永不触发，即零成本降级。
	(pi as unknown as { on(event: "ui_prompt_start", handler: (event: any) => void): void })
		.on("ui_prompt_start", (e: any) => { try { statusUI?.setUiPromptWaiting(true, e?.title); } catch { /* lint-exempt:状态栏刷新尽力而为 */ } });
	(pi as unknown as { on(event: "ui_prompt_end", handler: () => void): void })
		.on("ui_prompt_end", () => { try { statusUI?.setUiPromptWaiting(false); } catch { /* lint-exempt:状态栏刷新尽力而为 */ } });
	// 8月迭代 pi-0.84 配合 P2⑦：绝对路径链接化显示变换（仅主进程；SUBAGENT 分支已在上方
	// return）。pi 渲染层原生渲染 markdown 链接并做终端 hyperlink 能力检测（无 OSC8 自动降级
	// 纯文本），不裸发转义码零垃圾风险。registerMarkdownTransformer 同为 0.84 新面 →
	// 经 unknown 传入（transform-display 内部可选链 + 静默降级）；注册失败静默。
	try { registerDisplayTransforms(pi as unknown as Parameters<typeof registerDisplayTransforms>[0]); } catch { /* lint-exempt:显示增强失败不影响主流程 */ }
	// （看板已在上文提前注册供 input-router 复用）
	// T2-2: blocked 待答队列（ctrl+shift+a → select/input 回答 → 自动 resume）
	registerAnswerQueue(pi as unknown as QueuePi, { agents, taskRegistry: registry, runResumeTask: runResumeTask as AnswerQueueDeps["runResumeTask"] });
	const continuationState = createContinuationState();
	// P2-2/P2-4: L0 每轮注入；continuation 仅在 compact 成功后单次消费。
	registerLeaderPrompt(pi, continuationState);
	// T2-4: 上下文自动供给（关键词匹配注入 L1 资源 + 陈腐 tool 输出裁剪 + token 预算）
	registerContextHandler(pi, packageRoot);
	registerContinuation(pi, continuationState);
	// T2-9: RPC 常驻进程池（独立工具 rpc_task；lazy init + session_shutdown 清理；不改 sync/background/resume 默认路径）
	rpcPoolController = createRpcPoolController();
	pi.registerTool(withArgumentArtifactNormalization(createRpcPoolTool(rpcPoolController, pi)) as unknown as ToolDefinition);

	// P4-1（可选）: 事件驱动加速 status 刷新（轮询已兜底，事件仅降低感知延迟；不加也正确）
	pi.on("tool_execution_end", () => { try { statusUI?.refresh(); } catch { /* lint-exempt:状态栏刷新尽力而为（轮询兜底） */ } });
	pi.on("agent_end", () => { try { statusUI?.refresh(); } catch { /* lint-exempt:状态栏刷新尽力而为（轮询兜底） */ } });
	// taskFile 与同文件 Write/Edit 自动串行：登记在途写入（同批 start 全部先于 execute 发出），task_submit/task_batch
	// 读 taskFile 前等待同文件写入结束（file-mutation-tracker.ts）。
	pi.on("tool_execution_start", (event, ctx) => { try { noteFileMutationStart(event, ctx.cwd, fileMutationSessionId(ctx, ctx.cwd)); } catch { /* lint-exempt:登记失败仅失去自动等待，不影响工具执行 */ } });
	pi.on("tool_execution_end", (event, ctx) => { try { noteFileMutationEnd(event, fileMutationSessionId(ctx, ctx.cwd)); } catch { /* lint-exempt:注销失败由等待超时兜底 */ } });
	pi.on("turn_start", (_event, ctx) => { clearCompletedFileMutations(fileMutationSessionId(ctx, ctx.cwd)); });
	pi.on("turn_end", (_event, ctx) => { clearCompletedFileMutations(fileMutationSessionId(ctx, ctx.cwd)); });
	pi.on("session_shutdown", (_event, ctx) => { cancelPendingFileMutations(fileMutationSessionId(ctx, ctx.cwd)); });
	// 8月迭代 Wave C2：Leader 与 running 子任务并行写同文件的冲突软提示（不阻断；每文件每任务一次）
	registerParallelWriteHint(pi);
	// v1.5.253 browser-reaper idle 回收器（ev-20260830-52106c）：仅主进程——5min 节拍扫描共享
	// 心跳，超 30min idle 且存在残留无头 Chrome（user-data-dir 特征匹配，不碰日常浏览器）则
	// 自动回收。零模型负担（不追加任何提示）；AMAGI_BROWSER_REAPER=0 逃生舱。
	try { startBrowserReaper(pi); } catch { /* lint-exempt:回收器失败静默 */ }

	pi.on("session_shutdown", async () => {
		registry.setShuttingDown(true);
		await cleanupChildrenOnShutdown();
		snapshotForPersist(pi);
		// T2-9: 清理 RPC 进程池（释放 worker + WAL lease）
		try { await rpcPoolController?.shutdown(); } catch { /* lint-exempt:关停清理尽力而为 */ }
		// LSP: 关闭语言服务器池（懒起真用过才存在）
		try { await lspToolHandle?.close(); } catch { /* lint-exempt:关停清理尽力而为 */ }
		// P1-D：edit/write 诊断注入共享池收口（与 lsp 池共有时幂等）
		try { await closeDiagnostics(); } catch { /* lint-exempt:关停清理尽力而为 */ }
		// P4-1: 清理 status-ui 与 panel-widget（与既有子进程 SIGTERM 清理独立并存）
		try { statusUI?.stop(); } catch { /* lint-exempt:关停清理尽力而为 */ }
		statusUI = undefined;
		// A1b：会话收尾卸载诊断 sink（未冲刷诊断立即冲刷；此后 tuiWarn/tuiLog 回退 console 语义）
		try { deactivateTuiDiagSink(); } catch { /* lint-exempt:卸载尽力而为 */ }
		// H2（§8.4-H2 条目9）owner 生命周期收尾：reload/switch 重建扩展运行时后旧 ctx 失效
		//（宿主 runner.invalidate 置 stale，任何再提交抛错），本 realm 进程级句柄在此释放——同
		// realm 二次装配时走惰性新建而非复用已关闭句柄（跨 realm 重求值时模块级单例本就随旧
		// 运行时废弃，见上方 K8c 接线注记）。
		rpcPoolController = undefined;
		lspToolHandle = undefined;
	});
	pi.on("session_start", async (event: any, ctx: any) => {
		registry.setShuttingDown(false);
		// A1b（pi 1.0.2 fullscreen 兼容）：TUI 会话安装诊断 sink——后续 tuiWarn/tuiLog 经 ctx.ui.notify
		// + 落盘呈现，不再以 console 裸字节写入 fullscreen 渲染器持有的 pty（实测会覆盖 editor/footer
		// 且差分渲染器永不修复）。非 TUI 模式不安装，console 语义学不变（rpc/json/print 冒烟断言不受影响）。
		try { if (ctx?.mode === "tui" && ctx?.ui?.notify) activateTuiDiagSink(ctx.ui); } catch { /* lint-exempt:sink 安装失败回退 console 语义 */ }
		// v2.1 会话盖章：捕获当前会话标识（sessionFile 路径优先，回退 sessionId——与 leader-prompt/
		// continuation 同源口径；两者皆无 = 内存会话防御缺省→不盖章，对账侧按 pull-only 处理）。
		// 派发路径经 task-service 冻结进 spec.leaderSession；恢复对账按此把在途记录精确绑定到原会话。
		const sf = ctx?.sessionManager?.getSessionFile?.();
		const sid = ctx?.sessionManager?.getSessionId?.();
		const sessionKey = typeof sf === "string" && sf ? sf : typeof sid === "string" && sid ? sid : undefined;
		try { setLeaderSessionStamp(sessionKey); } catch { /* lint-exempt:盖章失败=不盖章（pull-only），不影响派发 */ }
		// I2（§4.2/§4.3）：会话工具面定版——过滤未启用分面工具出 active 集、按留档恢复旧会话面、
		// surfaceVersion 留档（旧会话旧 schema；版本不匹配不自动迁移，回归默认面）。
		try {
			toolSurface?.onSessionStart((ctx?.sessionManager?.getEntries?.() || []) as Array<{ customType?: string; data?: unknown }>);
		} catch (e) { tuiWarn(`[amagi-core] 工具面会话定版失败（默认面继续）: ${e instanceof Error ? e.message : String(e)}`); }
		// 全局 amagi.json 首跑自动创建（extension 加载即触发，不等首次模型解析；失败不阻塞 session）
		try { ensureGlobalConfigOnStartup(); } catch { /* lint-exempt:配置创建失败不阻塞 session */ }
		// E4: 模型可达性启动预检（每进程一次；防启动时序未刷新先 await refresh；任何失败仅 stderr，绝不阻塞启动）
		if (!modelPreflightRan) {
			modelPreflightRan = true;
			try {
				try { await ctx?.modelRegistry?.refresh?.(); } catch { /* lint-exempt:refresh 失败不阻塞预检 */ }
				const pfItems = preflightModels(agents, { cwd: ctx?.cwd, modelRegistry: ctx?.modelRegistry });
				for (const it of pfItems) {
					if (it.reachable !== "ok" && it.reachable !== "skip") {
						tuiWarn(`[amagi-core] 模型预检警告: ${it.agent}(${it.type}) ${it.modelSpec ?? "(无 model)"} → ${it.reachable}${it.note ? `；${it.note}` : ""}（修复建议: 检查 provider 注册 / OAuth 登录 / 模型 ID 拼写）`);
					}
				}
			} catch (e) {
				tuiWarn(`[amagi-core] 模型预检失败（不影响启动）: ${e instanceof Error ? e.message : String(e)}`);
			}
		}
		// v1.5.175: iTerm2 Bold 色板过暗检测（实战：markdown 粗体被 #101010 色板渲染不可读；
		// pi 的 bold=chalk.bold 硬编码不可经主题修复，插件提供强感知+一键修复脚本指引）。
		try {
			const boldCheck = checkItermBoldColor();
			if (boldCheck.checked && !boldCheck.ok) {
				tuiWarn(`[amagi-core] 终端渲染警告: ${boldCheck.reason}\n  修复: node ${path.join(packageRoot, "scripts", "fix-terminal-bold-color.mjs")}（写 Dynamic Profile 热生效）或 iTerm2 → Settings → Profiles → Colors → Bold 色板改亮`);
			}
		} catch { /* lint-exempt:检测失败静默，不阻塞启动 */ }
		// v1.5.177: pi retry 关闭检测（实战：retry.enabled=false 导致 Connection error 瞬时错误杀会话）
		try {
			const retryCheck = checkRetrySetting();
			if (retryCheck.checked && !retryCheck.ok) {
				tuiWarn(`[amagi-core] 会话韧性警告: ${retryCheck.reason}`);
			}
			// v1.5.185 非阻断韧性提示（provider 超时偏短等）
			for (const w of retryCheck.warnings ?? []) tuiWarn(`[amagi-core] 会话韧性提示: ${w}`);
		} catch { /* lint-exempt:检测失败静默，不阻塞启动 */ }
		// P2-B: 默认模型近 7 日错误分类画像（traces 尾扫有界；error 占比>20% 且样本≥10 才提示）
		try {
			const profileCheck = checkModelProfile();
			if (profileCheck.checked && !profileCheck.ok) {
				tuiWarn(`[amagi-core] 启动画像警告: ${profileCheck.reason}`);
			}
		} catch { /* lint-exempt:检测失败静默，不阻塞启动 */ }
		let restored = false;
		try {
			// ev-20261019-06c169：优先 getBranch()（当前分支状态恢复入口——getEntries 是全会话口径，弃枝上的
			// 旧快照不得覆盖当前分支；压缩不删原始 entries，分支可见性才是恢复真相）；旧宿主缺该 API 回退 getEntries。
			const sm = ctx?.sessionManager as { getBranch?: () => Array<{ customType?: string; data?: unknown }> | undefined; getEntries?: () => Array<{ customType?: string; data?: unknown }> } | undefined;
			const entries = (typeof sm?.getBranch === "function" ? sm.getBranch() : undefined) ?? sm?.getEntries?.() ?? [];
			for (let i = entries.length - 1; i >= 0; i--) {
				if (entries[i].customType === "amagi:task-registry") {
					const warnings = registry.restoreFromSnapshot(entries[i].data || []);
					if (warnings.length > 0) tuiWarn(`[amagi-core] registry 恢复 ${warnings.length} 条跳过: ${warnings.join("; ")}`);
					restored = true;
					break;
				}
			}
		} catch { /* lint-exempt:快照恢复失败回退空快照 */ }
		if (!restored) registry.restoreFromSnapshot([]);
		// K8c/K8a + v2.1 会话精确绑定：恢复对账只在唤起原会话（reason=resume）时发生——扫描+应用+
		// 横幅只针对 leaderSession 盖章匹配本会话的记录（actionable>0 才 steer）；new/fork/startup 一律
		// 静默（不被其他会话的在途任务记录污染）。按会话键去重：同进程 /resume 切到新会话会再次对账，
		// 同会话重复触发不重复应用；无会话键（内存会话防御）不应用——不猜。query_task({recovery:true})
		// 查询面在任何会话可用：缓存按会话键失效，未预热时懒扫描（只读零应用）。
		if (event?.reason === "resume" && sessionKey && lastRecoveredSessionKey !== sessionKey) {
			lastRecoveredSessionKey = sessionKey;
			void (async () => {
				try {
					// v2.x 自动收口配置（env > amagi.json recovery 节 > 默认）：非法值回退下一层有效值并 bounded 提示
					const recoveryAuto = loadRecoveryAutoConfig(process.cwd());
					for (const w of recoveryAuto.warnings) tuiWarn(`[amagi-core] 恢复对账配置回退：${w}`);
					const report = await applyTaskRecovery({ ownerId: leaderOwnerId, sessionKey, machineId: leaderMachineId, autoReconcile: { enabled: recoveryAuto.enabled, staleHours: recoveryAuto.staleHours } });
					if (getLeaderSessionStamp() !== sessionKey) return; // 异步扫描期间已切会话，旧报告不注入新上下文。
					startupRecoveryReport = { scannedAt: report.scannedAt, text: formatRecoveryReport(report), sessionKey };
					// v2.x 上下文纪律：自动收口的残痕不再逐条列断点明细——本会话实际发生了自动收口才注入
					// 一行汇总；无事发生（sidecar 已在、无新候选）则零注入。仍需人工的条目保留清单（收敛格式）。
					const autoClosedNow = report.summary.autoClosed ?? 0;
					// ev-20261026-165da9：重启退出证明自动关闭的在途记录也计入注入判定（无人值守启动恢复）
					const rebootClosedNow = report.summary.rebootClosed ?? 0;
					if (autoClosedNow > 0 || rebootClosedNow > 0 || report.summary.actionable > 0) {
						// 同清单不重发：以宿主当前可见的已送达通知为凭，跨进程恢复去重事实。
						// 同签名静默；语义事实变化或压缩后信息不再可见才注入摘要。全量：/amagi recovery。
						const signature = recoveryActionableSignature(report);
						// 公共宿主投影尊重 firstKeptEntryId/弃枝/context_edit，保留在压缩窗口中的通知也可去重。
						const visible = ctx?.sessionManager?.buildSessionProjection?.().messages ?? ctx?.sessionManager?.getBranch?.() ?? [];
						const unchanged = recoveryNoticeAlreadyDelivered(visible, sessionKey, signature);
						try {
							// v2.x 收敛渲染：任务行一行/条（不再逐条断点/缺口轰炸），明细退到显式拉取面。
							if (!unchanged) {
								const autoLine = autoClosedNow > 0
									? `已自动收口 ${autoClosedNow} 条历史残痕（终态/陈旧记账缺口，不改三轴不猜成功；明细 /amagi recovery list）。`
									: "";
								// ev-20261026-165da9：重启退出证明自动关闭的在途记录（无人值守启动恢复；接受轴不变）
								const rebootLine = rebootClosedNow > 0
									? `已按重启退出证明自动关闭 ${rebootClosedNow} 条在途记录（设备重启后统一退出证明：确认退出+按未完成关闭，接受轴不变；明细 /amagi recovery list）。`
									: "";
								const manualLine = report.summary.actionable > 0
									? `${report.summary.actionable} 项待人工对账（不猜成功不自动启动；收口：本机记录用 task_control({ action: "reconcile", handles: [taskId], reason })——按启动锚点证明运行实体退出后按未完成关闭，仍存活/证据不足则拒绝（无锚点旧记录先 /amagi recovery confirm-exited <taskId> 人工确认）；foreign-owner 须主上 /amagi recovery adopt <taskId>；断点明细：/amagi recovery show <taskId>）。清单与建议动作：\n${formatStartupRecoveryNotice(report)}`
									: "";
								pi.sendMessage({ customType: "amagi:recovery", content: `[amagi-core] 恢复对账（本会话绑定）：${autoLine}${rebootLine}${manualLine}`, details: { sessionKey, signature }, display: false }, { deliverAs: "steer" });
							}
						} catch { /* lint-exempt:sendMessage 不可用静默 */ }
					}
				} catch (e) {
					tuiWarn(`[amagi-core] 恢复对账失败（不影响主功能；可重试会话唤起或用 /amagi recovery adopt <taskId> 收口已确认记录）: ${e instanceof Error ? e.message : String(e)}`);
				}
			})();
		}
		// ev-20260930-0dd26f（R6）：steer 通道生命周期 GC——启动（含上方恢复对账）完成后低频触发
		// （30 分钟节流、无后台定时器；新 steer 写入后同节流器触发，见 task-facets steer）。分类保护由
		// task-recovery 从全局契约 store + 本进程 registry 构造（不只本会话）；失败仅计入返回值，
		// 不影响会话/投递/结算。
		try { void maybeSweepSteerChannels(); } catch { /* lint-exempt:GC 失败不影响会话 */ }
		// ev-20261105-0a2e43：验证对象临时目录（amagi-vo-*/-cache-*/amagi-gomod-*）启动期清扫——6h 回收内容镜像、7d 整删；
		// 检查结束即时回收在 runStructuredCheck 出口，此处兜底历史残留与异常中断遗留。仅 Leader（子进程不清扫他人目录）。
		if (!SUBAGENT) { try { void sweepVerificationTemp().catch(() => { /* lint-exempt:GC 失败不影响会话 */ }); } catch { /* lint-exempt:GC 失败不影响会话 */ } }
		// P4-1: registry restore 之后创建 status-ui（依赖 restore 后的 registry 状态；非 TUI 模式 start() no-op）
		const uiCfg = readUiConfig(process.cwd());
		// v1.5.218-f5 主上裁定：常驻面板回退旧版 status-ui（v1.5.217 双行实况）；
		// panel-widget 分块面板停用（模块保留，ui.panel 误配置不再生效）。
		try {
			statusUI?.stop();
			statusUI = createStatusUI({ taskRegistry: registry, ctx });
			statusUI.start();
		} catch (e) {
			tuiWarn(`[amagi-core] status-ui 初始化失败（不影响主功能）: ${e instanceof Error ? e.message : String(e)}`);
		}
		// R7: 能力横幅（版本变更一次；ui.shortcutHint 开关）——out 走 tuiLog（TUI 下经 notify 呈现，
		// 避免 console.log 裸字节写入 fullscreen 渲染器持有的 pty——A1b 实测会破坏底部 UI 恢复）
		try { maybeShowShortcutHint({ hintEnabled: uiCfg.shortcutHint, out: (s: string) => tuiLog(s) }); } catch { /* lint-exempt:横幅失败不影响 session */ }
	});
}
