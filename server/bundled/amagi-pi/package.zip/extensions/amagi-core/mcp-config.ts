/**
 * mcp-config.ts — MCP 配置加载、角色路由与凭据引用解析（纯配置层）。
 *
 * 与 transport/TypeBox/pi Extension API 解耦，供 task-tool 在 spawn 前计算最小环境，
 * 也供 mcp-client 在子进程 extension 装配时消费同一份配置语义。
 *
 * 凭据引用两种形态（v1.5.251）：
 *   ${VAR} / ${VAR:-default}      — 从 env / 子进程凭据包解析（原有行为）
 *   ${PI_PROVIDER_KEY:<id>}       — 从 pi 预设配置 models.json providers[id].apiKey 解析，
 *                                   单一事实源，key 轮换自动跟随；典型：智谱 MCP 三件套挂
 *                                   amagi-glm 的 coding key（实战 2026-08-26：ZHIPU_API_KEY 失效，
 *                                   三个 HTTP server 工具发现全挂，改挂预设 key 后恢复）。
 */

import { adaptStdioForWsl, commandOnPath, isWslHost, windowsHomeDir } from "./wsl-windows-home.ts";
import { wslMntRoot } from "./win-exec-mnt.ts";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

export const MCP_ENV_BUNDLE_VAR = "AMAGI_MCP_ENV_B64";
const childMcpEnvKeys = new Set<string>();

export interface McpServerConfig {
	name: string;
	type: "http" | "stdio";
	url?: string;
	headers?: Record<string, string>;
	command?: string;
	args?: string[];
	env?: Record<string, string>;
	description?: string;
	/** false：HTTP tools/call 失败后不重放；有副作用的界面控制 server 应显式关闭。 */
	retryToolCalls?: boolean;
	/** 配置值中引用的 ${VAR} 名称；用于子 Agent 按实际路由最小透传凭据。 */
	envRefs: string[];
	/** 来源配置文件（诊断用）。 */
	source: string;
	/** 原生配置定义及其来源；兼容配置注册给 pi，原生文件留给宿主读取。 */
	nativeConfig?: Record<string, unknown>;
	nativeManaged?: boolean;
	projectSource?: boolean;
}

export interface McpConfigWarning {
	/** 来源配置文件（诊断用）。 */
	file: string;
	/** 告警所属 server 名（无 server 上下文时缺省，如 JSON 解析失败）。 */
	server?: string;
	/** 告警文本（不含 file 前缀；输出方拼 `${file}: ${message}` 保持旧格式）。 */
	message: string;
}

export interface McpConfigLoadResult {
	servers: Record<string, McpServerConfig>;
	warnings: McpConfigWarning[];
}

/** 子 Agent 启动时携带的 MCP 专用凭据包；只在 extension 装配期间解码。 */
function bundledMcpEnv(): Record<string, string> {
	const encoded = process.env[MCP_ENV_BUNDLE_VAR];
	if (!encoded) return {};
	try {
		const parsed = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
		return Object.fromEntries(Object.entries(parsed).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
	} catch { return {}; }
}

/** MCP 配置完成插值后立即清除凭据包，避免后续模型 bash 继承可读凭据。 */
export function clearMcpEnvBundle(): void {
	for (const key of Object.keys(bundledMcpEnv())) childMcpEnvKeys.add(key);
	delete process.env[MCP_ENV_BUNDLE_VAR];
}

/** 原生连接按需读取进程环境；模型 shell 不继承专用于 MCP 的凭据（不改宿主环境）。 */
export function stripChildMcpEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
	const next = { ...env };
	delete next[MCP_ENV_BUNDLE_VAR];
	for (const key of childMcpEnvKeys) delete next[key];
	return next;
}

/**
 * v1.5.251 ${PI_PROVIDER_KEY:<providerId>}：从 pi 预设配置（<PI_CODING_AGENT_DIR || ~/.pi/agent>/models.json
 * 的 providers[id].apiKey）解析凭据。单一事实源：key 在 models.json 轮换后 MCP 配置自动跟随；
 * 值不写入 env、不进子进程凭据包（父/子进程同机同 HOME，各自按需读取）。内容缓存防重复 JSON.parse。
 */
let providerKeyCache: { raw: string; json: any } | null = null;
export function resolvePiProviderKey(providerId: string): string | undefined {
	const dir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const file = path.join(dir, "models.json");
	try {
		// 缓存键为内容而非 mtime（ev-20260830-710713）：DrvFS/WSL 下 mtime 精度/语义不可靠——
		// utimes 回拨后同毫秒重写，statSync 可返回与缓存时逐位相同的 mtime；同长度 key 轮换连 size 也不变，
		// mtime / mtime+size 键都会误命中旧 JSON。models.json 为 KB 级小文件，每次读原文比对、
		// 未变化即复用已解析 JSON——省的是重复 JSON.parse，代价只是一次有界小读。
		const raw = fs.readFileSync(file, "utf8");
		if (!providerKeyCache || providerKeyCache.raw !== raw) {
			providerKeyCache = { raw, json: JSON.parse(raw) };
		}
		const key = providerKeyCache.json?.providers?.[providerId]?.apiKey;
		return typeof key === "string" && key !== "" ? key : undefined;
	} catch { return undefined; }
}

/** ${VAR} / ${VAR:-default} / ${PI_PROVIDER_KEY:<providerId>} 插值；未解析且无默认返回 undefined。 */
export function interpolateEnv(value: string): string | undefined {
	let missing = false;
	const bundle = bundledMcpEnv();
	const out = value.replace(/\$\{(PI_PROVIDER_KEY:[^}:]+|[A-Za-z_][A-Za-z0-9_]*(?::-[^}]*)?)\}/g, (_m, ref: string) => {
		if (ref.startsWith("PI_PROVIDER_KEY:")) {
			const v = resolvePiProviderKey(ref.slice("PI_PROVIDER_KEY:".length));
			if (v !== undefined) return v;
			missing = true;
			return "";
		}
		const idx = ref.indexOf(":-");
		const name = idx >= 0 ? ref.slice(0, idx) : ref;
		const def = idx >= 0 ? ref.slice(idx + 2) : undefined;
		const v = bundle[name] ?? process.env[name];
		if (v !== undefined && v !== "") return v;
		if (def !== undefined) return def;
		missing = true;
		return "";
	});
	return missing ? undefined : out;
}

/** 提取配置字符串中的 ${VAR}/${VAR:-default} 引用（仅 env 键名；${PI_PROVIDER_KEY:} 形态不经 env 透传，不返回）。 */
export function envReferences(value: string): string[] {
	return [...value.matchAll(/\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-[^}]*)?\}/g)].map((m) => m[1]);
}

function readConfigMap(file: string, warnings: McpConfigWarning[], settingsOnly = false): Record<string, unknown> {
	let raw: string;
	try { raw = fs.readFileSync(file, "utf8"); } catch { return {}; }
	// Windows 编辑器/PowerShell（Out-File、Set-Content -Encoding utf8）常写 UTF-8 BOM，JSON.parse 直接失败。
	if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
	let json: any;
	try { json = JSON.parse(raw); } catch (e) { warnings.push({ file, message: `JSON 解析失败（${e instanceof Error ? e.message : e}）` }); return {}; }
	if (settingsOnly && !(json?.mcpServers && typeof json.mcpServers === "object")) return {};
	const map = json?.mcpServers && typeof json.mcpServers === "object" ? json.mcpServers : json;
	if (!map || typeof map !== "object" || Array.isArray(map)) return {};
	return map;
}

function parseConfigFile(file: string, warnings: McpConfigWarning[], settingsOnly = false, providedMap?: Record<string, unknown>, nativeManaged = false): Record<string, McpServerConfig> {
	const map = providedMap ?? readConfigMap(file, warnings, settingsOnly);
	const out: Record<string, McpServerConfig> = {};
	for (const [name, cfg] of Object.entries<any>(map)) {
		if (!cfg || typeof cfg !== "object" || cfg.disabled === true || cfg.enabled === false) continue;
		const type: "http" | "stdio" | undefined = cfg.type === "http" || cfg.type === "stdio" ? cfg.type : cfg.url ? "http" : cfg.command ? "stdio" : undefined;
		if (!type) { warnings.push({ file, server: name, message: `server "${name}" 无法推断类型（无 type/url/command），跳过` }); continue; }
		const referenced = new Set<string>();
		const rememberRefs = (value: unknown) => {
			if (typeof value !== "string") return;
			if (!nativeManaged) for (const ref of envReferences(value)) referenced.add(ref);
			if (nativeManaged && !value.startsWith("!")) {
				// pi 同时支持 $VAR、${VAR} 与 $$/$! 转义；这里只采集引用，不执行配置命令。
				for (const match of value.matchAll(/\$\$|\$!|\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g)) {
					if (match[1] || match[2]) referenced.add(match[1] || match[2]);
				}
			}
		};
		const entry: McpServerConfig = { name, type, description: typeof cfg.description === "string" ? cfg.description : undefined, envRefs: [], source: file };
		if (cfg.retryToolCalls !== undefined) {
			if (typeof cfg.retryToolCalls !== "boolean") {
				warnings.push({ file, server: name, message: `server "${name}" retryToolCalls 必须是 boolean，跳过` });
				continue;
			}
			entry.retryToolCalls = cfg.retryToolCalls;
		}
		if (type === "http") {
			if (typeof cfg.url !== "string" || !cfg.url) { warnings.push({ file, server: name, message: `http server "${name}" 缺 url，跳过` }); continue; }
			rememberRefs(cfg.url);
			const url = nativeManaged ? cfg.url : interpolateEnv(cfg.url);
			if (url === undefined) { warnings.push({ file, server: name, message: `http server "${name}" url 引用的 env 未设置，跳过` }); continue; }
			entry.url = url;
			const headers: Record<string, string> = {};
			for (const [key, value] of Object.entries(cfg.headers || {})) {
				if (typeof value !== "string") continue;
				rememberRefs(value);
				const interpolated = nativeManaged ? value : interpolateEnv(value);
				if (interpolated === undefined) warnings.push({ file, server: name, message: `server "${name}" header "${key}" 引用的 env 未设置，已省略` });
				else headers[key] = interpolated;
			}
			entry.headers = headers;
		} else {
			if (typeof cfg.command !== "string" || !cfg.command) { warnings.push({ file, server: name, message: `stdio server "${name}" 缺 command，跳过` }); continue; }
			entry.command = cfg.command;
			entry.args = Array.isArray(cfg.args) ? cfg.args.filter((arg: unknown) => typeof arg === "string") : [];
			const env: Record<string, string> = {};
			for (const [key, value] of Object.entries(cfg.env || {})) {
				if (typeof value !== "string") continue;
				rememberRefs(value);
				const interpolated = nativeManaged ? value : interpolateEnv(value);
				if (interpolated === undefined) warnings.push({ file, server: name, message: `server "${name}" env "${key}" 引用的变量未设置，已省略` });
				else env[key] = interpolated;
			}
			entry.env = env;
			// WSL：Windows 侧配置里的盘符路径/`cmd /c` 壳换算为 WSL 可执行形态（非 WSL 零开销、不改动）。
			if (isWslHost()) {
				const adapted = adaptStdioForWsl({ command: entry.command!, args: entry.args!, env }, wslMntRoot());
				if (adapted.changed) { entry.command = adapted.command; entry.args = adapted.args; entry.env = adapted.env; }
				if (adapted.windowsTarget && adapted.wslenvKeys.length > 0) {
					// Windows 程序经 interop 启动：配置 env 键须列入 WSLENV 才会进入 Windows 进程环境。
					const keys = [...new Set([...(process.env.WSLENV ?? "").split(":").filter(Boolean), ...adapted.wslenvKeys.filter((k) => !k.includes(":") && k !== "WSLENV")])];
					entry.env = { ...entry.env, WSLENV: keys.join(":") };
				}
				if (!nativeManaged && !entry.command!.includes("/") && !commandOnPath(entry.command!)) {
					warnings.push({ file, server: name, message: `WSL 的 PATH 中找不到命令 "${entry.command}"（Windows 程序需写成 /mnt/<盘>/… 路径或盘符路径；Linux 命令需已安装）——该 server 将无法启动` });
				}
			}
		}
		entry.envRefs = [...referenced];
		// 原生协议/认证/exposure 字段由 pi 自己校验和执行；仅兼容来源的已解析凭据交给注册。
		const nativeConfig: Record<string, unknown> = {};
		for (const key of ["enabled", "exposure", "toolExposure", "timeout", "description", "oauth", "auth", "cwd"]) {
			if (cfg[key] !== undefined) nativeConfig[key] = cfg[key];
		}
		if (typeof nativeConfig.cwd === "string" && isWslHost()) nativeConfig.cwd = adaptStdioForWsl({ command: "", args: [nativeConfig.cwd], env: {} }, wslMntRoot()).args[0];
		if (type === "http") Object.assign(nativeConfig, { url: entry.url, headers: entry.headers });
		else Object.assign(nativeConfig, { command: entry.command, args: entry.args, env: entry.env });
		rememberRefs(cfg.oauth?.clientSecret);
		entry.envRefs = [...referenced];
		if (!nativeManaged) {
			// 兼容来源已经插值的值须作为字面量交给 pi，避免二次插值或把 !secret 当配置命令执行。
			const literal = (v: string) => v.replaceAll("$", () => "$$").replace(/^!/, "$!");
			if (entry.headers) nativeConfig.headers = Object.fromEntries(Object.entries(entry.headers).map(([k, v]) => [k, literal(v)]));
			if (entry.env) nativeConfig.env = Object.fromEntries(Object.entries(entry.env).map(([k, v]) => [k, literal(v)]));
		}
		entry.nativeConfig = nativeConfig;
		out[name] = entry;
	}
	return out;
}

function candidateConfigFiles(cwd: string): { file: string; settingsOnly: boolean }[] {
	const files: { file: string; settingsOnly: boolean }[] = [];
	const home = os.homedir();
	files.push({ file: path.join(process.env.PI_CODING_AGENT_DIR || path.join(home, ".pi", "agent"), "settings.json"), settingsOnly: true });
	// WSL：Windows 用户目录的 .agents/.mcp.json 先加载（优先级低于 Linux 家目录同名 server）。
	const winHome = windowsHomeDir();
	if (winHome) files.push({ file: path.posix.join(winHome, ".agents", ".mcp.json"), settingsOnly: false });
	files.push({ file: path.join(home, ".agents", ".mcp.json"), settingsOnly: false });
	const chain: string[] = [];
	let dir = path.resolve(cwd);
	for (;;) {
		chain.unshift(dir);
		const parent = path.dirname(dir);
		if (fs.existsSync(path.join(dir, ".git")) || parent === dir) break;
		dir = parent;
	}
	for (const current of chain) files.push({ file: path.join(current, ".mcp.json"), settingsOnly: false });
	for (const current of chain) files.push({ file: path.join(current, ".agents", ".mcp.json"), settingsOnly: false });
	for (const current of chain) files.push({ file: path.join(current, ".pi", "settings.json"), settingsOnly: true });
	return files;
}

/** 加载并合并全部配置来源（同名后者覆盖前者）。 */
export function loadMcpServerConfigs(cwd: string, options: { projectTrusted?: boolean } = {}): McpConfigLoadResult {
	const warnings: McpConfigWarning[] = [];
	const servers: Record<string, McpServerConfig> = {};
	if (process.env.AMAGI_MCP_DISABLE === "1") return { servers, warnings };
	const agentDir = path.resolve(process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent"));
	const canonical = (name: string) => name.replace(/-/g, "_");
	const definitions = new Map<string, { name: string; cfg: Record<string, unknown>; file: string; nativeManaged: boolean; projectSource: boolean }>();
	const nativeNames = new Map<string, string>();
	const winHomeDir = windowsHomeDir();
	const winAgentsDir = winHomeDir ? path.posix.join(winHomeDir, ".agents") : undefined;
	for (const { file, settingsOnly } of candidateConfigFiles(cwd)) {
		const projectSource = !file.startsWith(`${agentDir}${path.sep}`) && !file.startsWith(`${path.join(os.homedir(), ".agents")}${path.sep}`)
			&& !(winAgentsDir !== undefined && file.startsWith(`${winAgentsDir}/`));
		if (projectSource && options.projectTrusted === false) continue;
		for (const [name, raw] of Object.entries(readConfigMap(file, warnings, settingsOnly))) {
			if (!raw || typeof raw !== "object" || Array.isArray(raw)) continue;
			if (projectSource && (raw as Record<string, unknown>).auth !== undefined) {
				warnings.push({ file, server: name, message: "项目兼容 MCP 配置不能指定 auth.provider，跳过（不能借扩展注册绕过宿主认证边界）" });
				continue;
			}
			definitions.set(canonical(name), { name, cfg: raw as Record<string, unknown>, file, nativeManaged: false, projectSource });
		}
	}
	// 原生 mcp.json 优先于兼容来源；项目浅覆写只改变宿主支持的三项。
	for (const [file, projectSource] of [[path.join(agentDir, "mcp.json"), false], [path.join(path.resolve(cwd), ".pi", "mcp.json"), true]] as const) {
		if (projectSource && options.projectTrusted === false) continue;
		let structured = false;
		try { const json = JSON.parse(fs.readFileSync(file, "utf8")); structured = !!json?.mcpServers; } catch { /* lint-exempt:统一读取器报告 JSON 错误 */ }
		for (const [name, raw] of Object.entries(readConfigMap(file, warnings))) {
			if (!raw || typeof raw !== "object" || Array.isArray(raw)) continue;
			const cfg = raw as Record<string, unknown>;
			const key = canonical(name);
			const base = definitions.get(key);
			if (structured && !/^[A-Za-z0-9_-]+$/.test(name)) {
				warnings.push({ file, server: name, message: "原生 server 名仅允许字母数字_-，跳过" });
				continue;
			}
			const shallow = projectSource && cfg.command === undefined && cfg.url === undefined && cfg.type === undefined;
			if (shallow) {
				if (!base || base.name !== name || !base.nativeManaged || Object.keys(cfg).some((field) => !["enabled", "exposure", "toolExposure"].includes(field))) {
					warnings.push({ file, server: name, message: "项目 MCP 浅覆写仅允许 enabled/exposure/toolExposure，且须有精确同名的全局原生 server 定义，跳过" });
					continue;
				}
				definitions.set(key, { ...base, cfg: { ...base.cfg, ...cfg }, projectSource: true });
			} else {
				if (projectSource && cfg.auth !== undefined) {
					warnings.push({ file, server: name, message: "项目 MCP 配置不能指定 auth.provider，跳过（沿用宿主认证边界）" });
					continue;
				}
				const clash = nativeNames.get(key);
				if (structured && clash && clash !== name) {
					warnings.push({ file, server: name, message: `原生 server "${name}" 与 "${clash}" 的命名空间冲突，跳过` });
					continue;
				}
				if (structured) nativeNames.set(key, name);
				definitions.set(key, { name, cfg, file, nativeManaged: structured, projectSource });
			}
		}
	}
	for (const definition of definitions.values()) {
		const parsed = parseConfigFile(definition.file, warnings, false, { [definition.name]: definition.cfg }, definition.nativeManaged);
		const config = parsed[definition.name];
		if (config) servers[definition.name] = { ...config, nativeManaged: definition.nativeManaged, projectSource: definition.projectSource };
	}
	return { servers, warnings };
}

export interface McpRoutingConfig {
	default: string[];
	agents: Record<string, string[]>;
	/** v2.8.2：Leader 主进程加载名单（缺省未配置 = ["*"] 全量，行为不变）；
	 *  与角色路由不同面——扩展装配时读一次，改动需重启 pi 生效。 */
	leader?: string[];
	/** v1.5.246：常规调用超时（ms）；项目 amagi.json 优先于全局。 */
	callTimeoutMs?: number;
	/** v1.5.246：视觉类调用超时（ms）。 */
	visionCallTimeoutMs?: number;
}

/** 正整数归一（非 number 类型（含 bool——Number(true)===1）/非正数/非有限数 → undefined，忽略）。 */
function positiveIntMs(value: unknown): number | undefined {
	if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return undefined;
	return Math.floor(value);
}

/** 读取全局+项目 amagi.json 的 MCP 路由与超时；项目键优先（每次读盘，改动即时生效）。 */
export function loadMcpRouting(cwd: string): McpRoutingConfig {
	const routing: McpRoutingConfig = { default: ["*"], agents: {} };
	const globalDir = process.env.PI_CODING_AGENT_DIR || path.join(os.homedir(), ".pi", "agent");
	const files = [path.join(globalDir, "amagi.json"), path.join(path.resolve(cwd), "amagi.json")];
	const stringList = (value: unknown): string[] => Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
	for (const file of files) {
		let json: any;
		try { json = JSON.parse(fs.readFileSync(file, "utf8")); } catch { continue; }
		const mcp = json?.mcp;
		if (!mcp || typeof mcp !== "object") continue;
		if (Array.isArray(mcp.default)) routing.default = stringList(mcp.default);
		// v2.8.2：mcp.leader——Leader 主进程加载名单（装配时读一次，改动需重启 pi；非角色路由的即时读盘面）
		if (Array.isArray(mcp.leader)) routing.leader = stringList(mcp.leader);
		if (mcp.agents && typeof mcp.agents === "object" && !Array.isArray(mcp.agents)) {
			for (const [name, list] of Object.entries(mcp.agents)) {
				if (Array.isArray(list)) routing.agents[name] = stringList(list);
			}
		}
		// v1.5.246 超时配置：合法正数才覆盖（项目键优先于全局，同名后者胜）
		const c = positiveIntMs(mcp.callTimeoutMs);
		if (c !== undefined) routing.callTimeoutMs = c;
		const vc = positiveIntMs(mcp.visionCallTimeoutMs);
		if (vc !== undefined) routing.visionCallTimeoutMs = vc;
	}
	return routing;
}

/** 计算某角色实际可加载的 server 名集合。 */
export function resolveAgentMcpServers(cwd: string, agentName: string | undefined): string[] {
	const { servers } = loadMcpServerConfigs(cwd);
	const names = Object.keys(servers);
	const routing = loadMcpRouting(cwd);
	// ev-20260916-9daa55：加载路由配置时做名单存在性校验（未命中条目结构化告警，见下方模块段）。
	warnRoutingEntryMismatches(names, routing);
	const pick = (list?: string[]): string[] => !list?.length ? [] : list.includes("*") ? names : list.filter((name) => names.includes(name));
	const extra = agentName ? pick(routing.agents[agentName]) : [];
	return [...new Set([...pick(routing.default), ...extra])];
}

/** 计算主进程（Leader）实际加载的 server 名集合：amagi.json `mcp.leader`（v2.8.2）。
 *  缺省未配置 = ["*"] 全量（行为不变）；"*" = 全部；显式空数组 = 不加载任何；
 *  未命中条目跳过并结构化告警（同角色路由语义，定位 mcp.leader）。
 *  与角色路由不同面：Leader 在扩展装配时读一次（改动需重启 pi 生效）。 */
/** Leader 路由（装配/会话用）：未限制（缺省或含 "*"）时返回 ["*"]，**不**展开为装配时 cwd 的 server 名快照——
 *  会话 cwd 与进程 cwd 不一致（/resume、/new 进入另一项目）时，新项目根 .mcp.json 的 server 才不会被旧快照拒绝。 */
export function leaderMcpRoute(cwd: string): string[] {
	const routing = loadMcpRouting(cwd);
	if (!routing.leader || routing.leader.includes("*")) return ["*"];
	return resolveLeaderMcpServers(cwd);
}

export function resolveLeaderMcpServers(cwd: string): string[] {
	const { servers } = loadMcpServerConfigs(cwd);
	const names = Object.keys(servers);
	const routing = loadMcpRouting(cwd);
	warnRoutingEntryMismatches(names, routing);
	const list = routing.leader ?? ["*"];
	return list.includes("*") ? names : list.filter((name) => names.includes(name));
}

/** MCP 路由身份：Leader 主进程（mcp.leader）或子 Agent 角色（mcp.default ∪ mcp.agents.<role>）。 */
export type McpRouteIdentity = { kind: "leader" } | { kind: "agent"; agent?: string };

/**
 * ev-20261019-a50ce4：路由拒绝的可行动说明（只读配置，不改变路由/授权判定）。
 * 根因：拒绝点只知道「不在名单内」，不携带名单来源——Leader 与子 Agent 走不同配置键、生效时机不同
 * （mcp.leader 装配时读一次需重启；角色路由子进程启动时读，对新派发生效），调用方只能自行排查。
 * 本函数把「当前路由键 + 生效名单 + 该 server 所在路由 + 修改哪个键/是否重启」拼成一句。
 */
export function describeMcpRouteDenial(cwd: string, server: string, route: McpRouteIdentity): string {
	const canon = (n: string) => n.replace(/-/g, "_");
	const names = Object.keys(loadMcpServerConfigs(cwd).servers);
	const routing = loadMcpRouting(cwd);
	const defined = names.find((n) => canon(n) === canon(server));
	const covers = (list: string[] | undefined) => !!defined && !!list && (list.includes("*") || list.some((n) => canon(n) === canon(defined)));
	const leaderList = routing.leader ?? ["*"];
	const holders: string[] = [];
	if (covers(leaderList)) holders.push(routing.leader ? "mcp.leader（Leader 主进程）" : "mcp.leader 缺省全量（Leader 主进程）");
	if (covers(routing.default)) holders.push("mcp.default（全部子 Agent）");
	for (const [role, list] of Object.entries(routing.agents)) if (covers(list)) holders.push(`mcp.agents.${role}（${role} 子 Agent）`);
	const preview = (list: string[]) => list.length ? list.join("、") : "（空）";
	const current = route.kind === "leader"
		? `当前为 Leader 主进程，路由键 mcp.leader${routing.leader ? `=[${preview(routing.leader)}]` : "（未配置=全量）"}`
		: `当前为子 Agent${route.agent ? ` ${route.agent}` : ""}，路由键 mcp.default=[${preview(routing.default)}]${route.agent ? ` ∪ mcp.agents.${route.agent}=[${preview(routing.agents[route.agent] ?? [])}]` : ""}`;
	if (!defined) {
		return `${current}；server "${server}" 未在任何 MCP 配置中定义（已定义：${preview(names)}）——先在 mcp.json/mcpServers 定义该 server。`;
	}
	const where = holders.length ? `该 server 当前仅在 ${holders.join("、")}路由中可用` : "该 server 未被任何路由名单收录";
	const fix = route.kind === "leader"
		? `Leader 直连：在 amagi.json 的 mcp.leader 加入 "${defined}"（或 "*"），装配时读取——需重启 pi 生效${holders.some((h) => h.startsWith("mcp.default") || h.startsWith("mcp.agents")) ? "；或派发已路由该 server 的子 Agent 调用（仍受任务 scope.mcp 授权约束）" : ""}`
		: `子 Agent 路由：在 amagi.json 的 mcp.default 或 mcp.agents.${route.agent ?? "<role>"} 加入 "${defined}"——子进程启动时读取，对新派发任务生效（无需重启 Leader）`;
	return `${current}；${where}。${fix}。`;
}

// ─────────────────────────────────────────────────────────────────────────────
// ev-20260916-9daa55（capability/P2）：mcp.agents.<role> 路由名单存在性校验。
// 实战：名单条目拼错 / 全角逗号串接（"a，b，c" 整串被当一个 server 名）经
// `list.filter(name => names.includes(name))` 静默丢弃——baize 实际长期只 1 个 server 生效，
// 全程零告警。落地：resolveAgentMcpServers 加载路由时逐条存在性校验，未命中任何已定义
// mcpServers 名 → console.warn 结构化告警（角色名 / 条目原文 / 相近名建议 top1-2）。
// 丢弃语义本身保留（告警后仍不路由——不扩大权限面）；告警有界去重（同 key 一次，
// 已定义名集合变化后同 key 重新可提示）。回滚：AMAGI_MCP_ROUTING_WARN=0/false/off。
// ─────────────────────────────────────────────────────────────────────────────

export interface McpRoutingEntryWarning {
	/** 名单所属（"default" 或角色名）。 */
	role: string;
	/** 未命中条目原文。 */
	entry: string;
	/** 相近已定义 server 名（top1-2；无可信相近名时为空，不硬凑误导）。 */
	suggestions: string[];
	/** 附加说明（如全角逗号串接的拆分指引）。 */
	note?: string;
}

/** Levenshtein 编辑距离（server 名为个位数~十位数短名，O(nm) 足够；仅告警建议用）。 */
function editDistance(a: string, b: string): number {
	const m = a.length;
	const n = b.length;
	if (!m) return n;
	if (!n) return m;
	let prev: number[] = Array.from({ length: n + 1 }, (_, i) => i);
	for (let i = 1; i <= m; i++) {
		const curr: number[] = new Array<number>(n + 1);
		curr[0] = i;
		for (let j = 1; j <= n; j++) {
			const substitution = prev[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1);
			curr[j] = Math.min(prev[j]! + 1, curr[j - 1]! + 1, substitution);
		}
		prev = curr;
	}
	return prev[n]!;
}

/** 相近名建议：全角分隔符（，、；）串接 → 拆 token 精确命中优先（附数组拆分说明）；
 *  否则前缀/包含（0 档）+ 编辑距离（长度 ≥6 容差 2、短名容差 1）排序取 top2。纯函数导出供测试。 */
export function suggestMcpServerNames(entry: string, names: readonly string[]): { suggestions: string[]; note?: string } {
	const raw = String(entry ?? "");
	if (!raw.trim()) return { suggestions: [], note: "空字符串条目（将被忽略）" };
	const valid = names.filter((name) => typeof name === "string" && name !== "");
	const suggestions: string[] = [];
	let note: string | undefined;
	if (/[，、；]/.test(raw)) {
		note = "条目疑似被全角逗号/顿号串接成单个字符串——amagi.json 名单须写成 JSON 数组多个条目，不能用逗号串接";
		for (const token of raw.split(/[，、；]/)) {
			const trimmed = token.trim();
			if (trimmed && valid.includes(trimmed)) suggestions.push(trimmed);
		}
	}
	if (!suggestions.length) {
		const lower = raw.toLowerCase();
		const tolerance = Math.max(lower.length, 3) >= 6 ? 2 : 1;
		const scored = valid
			.map((name) => {
				const nl = name.toLowerCase();
				const score = (nl.startsWith(lower) || lower.startsWith(nl) || nl.includes(lower) || lower.includes(nl))
					? 0
					: editDistance(lower, nl);
				return { name, score };
			})
			.filter((s) => s.score <= tolerance)
			.sort((a, b) => a.score - b.score || a.name.localeCompare(b.name));
		suggestions.push(...scored.slice(0, 2).map((s) => s.name));
	}
	return { suggestions: [...new Set(suggestions)].slice(0, 2), ...(note ? { note } : {}) };
}

/** 路由名单存在性校验（纯函数，供测试直接断言）：default 与各角色名单中未命中 names 的
 *  条目 → 告警对象。names 为空（未定义任何 server，含 AMAGI_MCP_DISABLE=1）时零告警——
 *  名单全部未命中属环境预期而非笔误，不为噪音买单。含 "*" 的名单整体跳过（通配已展开全部）。 */
export function routingEntryWarnings(names: readonly string[], routing: McpRoutingConfig): McpRoutingEntryWarning[] {
	if (!names.length) return [];
	const out: McpRoutingEntryWarning[] = [];
	const check = (role: string, list: string[] | undefined): void => {
		if (!list?.length || list.includes("*")) return;
		for (const entry of list) {
			if (names.includes(entry)) continue;
			const { suggestions, note } = suggestMcpServerNames(entry, names);
			out.push({ role, entry, suggestions, ...(note ? { note } : {}) });
		}
	};
	check("default", routing.default);
	check("leader", routing.leader);
	for (const [role, list] of Object.entries(routing.agents)) check(role, list);
	return out;
}

const ROUTING_WARN_CACHE_MAX = 128;
const routingWarnSeen = new Set<string>();

/** 仅供测试复位路由告警去重缓存（生产不调用）。 */
export function _resetRoutingWarnCacheForTest(): void {
	routingWarnSeen.clear();
}

function routingWarnEnabled(): boolean {
	const v = process.env.AMAGI_MCP_ROUTING_WARN?.trim().toLowerCase();
	return !(v === "0" || v === "false" || v === "off");
}

/** 路由告警落警（console.warn，结构化单行）；有界去重键 = role + entry + 已定义名集合指纹
 *  （配置变化后同 key 重新可提示，FIFO 上界防长驻会话无界增长）。 */
function warnRoutingEntryMismatches(names: readonly string[], routing: McpRoutingConfig): void {
	if (!routingWarnEnabled()) return;
	const fingerprint = [...names].sort().join("\u0000");
	for (const w of routingEntryWarnings(names, routing)) {
		const key = `${w.role}\u0000${w.entry}\u0000${fingerprint}`;
		if (routingWarnSeen.has(key)) continue;
		if (routingWarnSeen.size >= ROUTING_WARN_CACHE_MAX) {
			const oldest = routingWarnSeen.keys().next().value;
			if (oldest !== undefined) routingWarnSeen.delete(oldest);
		}
		routingWarnSeen.add(key);
		const namesPreview = `${names.slice(0, 8).join("、")}${names.length > 8 ? ` 等 ${names.length} 个` : ""}`;
		const suggestionText = w.suggestions.length ? `相近候选：${w.suggestions.join("、")}` : "无可信相近名";
		const where = w.role === "default" ? "mcp.default" : w.role === "leader" ? "mcp.leader" : `mcp.agents.${w.role}`;
		console.warn(`[amagi-mcp] 路由名单告警：${where} 条目 "${w.entry}" 未命中任何已定义 mcpServers（已定义 ${names.length} 个：${namesPreview}），已跳过不路由（不扩大权限面）。${suggestionText}。${w.note ?? ""}`.trim());
	}
}

/** 返回某角色命中 server 所引用的环境变量名，不返回凭据值。 */
export function resolveAgentMcpEnvKeys(cwd: string, agentName: string | undefined, permission?: McpPermission): string[] {
	const { servers } = loadMcpServerConfigs(cwd);
	const keys = new Set<string>();
	for (const name of resolveAgentMcpServers(cwd, agentName)) {
		if (permission && !permission.allow.some((grant) => grant.server === "*" || grant.server.replace(/-/g, "_") === name.replace(/-/g, "_"))) continue;
		for (const key of servers[name]?.envRefs || []) keys.add(key);
	}
	return [...keys];
}

/** JSON/RPC 共用的最小凭据交付；包仅含实际路由且获授权的 server 引用。 */
export function appendMcpCredentialEnv(env: Record<string, string>, cwd: string, agentName?: string, permission?: McpPermission): void {
	const configs = loadMcpServerConfigs(cwd).servers;
	const nativeKeys = new Set(resolveAgentMcpServers(cwd, agentName).flatMap((name) => configs[name]?.nativeManaged ? configs[name].envRefs : []));
	const bundle: Record<string, string> = {};
	for (const key of resolveAgentMcpEnvKeys(cwd, agentName, permission)) {
		const value = env[key] ?? process.env[key];
		if (value === undefined) continue;
		bundle[key] = value;
		if (nativeKeys.has(key)) env[key] = value;
	}
	if (Object.keys(bundle).length) env[MCP_ENV_BUNDLE_VAR] = Buffer.from(JSON.stringify(bundle), "utf8").toString("base64");
}

// ─────────────────────────────────────────────────────────────────────────────
// v2 P3（方案 §5.2 MCP 行 / §8.3-P3）：MCP 调用权限面——按具体 server/tool 执法。
// 纯逻辑层：不读配置、不碰 transport；mcp-client 在 server 路由、发现（list_tools）与
// call 前逐次消费（call 重验防 TOCTOU）。注入面由 P4 从 P1 冻结 grant.mcp 构造（子进程按任务
// 名单、主进程按用户/角色名单）；未注入=legacy 无执法面（v1 行为不变）。
// ─────────────────────────────────────────────────────────────────────────────

/** P1 冻结 grant 的统一通道占位 server 名（computeEffectiveGrant 把授予条目的 server 统一冻为该值；
 *  P3 按真实 server/tool 收紧：占位归一化为 "*"=任意已路由 server，server 级收窄由路由承担）。 */
export const MCP_UNIFIED_CHANNEL_SERVER = "amagi-mcp";

export interface McpPermissionEntry {
	/** 真实 server 名；"*"=任意 server（含 P1 "amagi-mcp" 占位的归一化结果）。 */
	server: string;
	/** 真实工具名；"*"=该 server 全部工具（通配——须副作用授权或只读证明才放行）。 */
	tool: string;
}

export interface McpPermission {
	allow: readonly McpPermissionEntry[];
	/** 副作用授权（guarded/显式写面）：true 时通配条目放行未知性质工具；缺省 false=只读执法
	 *  （§5.2「未知工具性质不得当只读」——无 readOnlyHint 证据一律按有副作用拒绝）。 */
	sideEffects?: boolean;
}

/** 权限名单归一化：P1 统一通道占位 server（"amagi-mcp"）→ "*"；非法条目丢弃；去重。
 *  接受 P1 冻结 McpToolGrant 形状（{server,tool,policyDigest}——多余字段结构性忽略）。 */
export function normalizeMcpPermission(
	entries: ReadonlyArray<{ server: string; tool: string }>,
	opts?: { sideEffects?: boolean },
): McpPermission {
	const seen = new Set<string>();
	const allow: McpPermissionEntry[] = [];
	for (const e of entries) {
		if (!e || typeof e.server !== "string" || typeof e.tool !== "string" || !e.server.trim() || !e.tool.trim()) continue;
		const server = e.server === MCP_UNIFIED_CHANNEL_SERVER ? "*" : e.server;
		const key = `${server}\u0000${e.tool}`;
		if (seen.has(key)) continue;
		seen.add(key);
		allow.push({ server, tool: e.tool });
	}
	return { allow, sideEffects: opts?.sideEffects === true };
}

function entryMatches(entry: Readonly<McpPermissionEntry>, server: string, tool: string): boolean {
	return (entry.server === "*" || entry.server.replace(/-/g, "_") === server.replace(/-/g, "_")) && (entry.tool === "*" || entry.tool === tool);
}

export interface McpPermissionDecision {
	allowed: boolean;
	/** 拒绝原因（allowed=false 时给模型的具体说明）。 */
	reason?: string;
}

/** call 前重验（§5.2：不信任发现面过滤，每次调用重新校验——防 TOCTOU）。
 *  语义矩阵（server 路由≠副作用授权：只命中 server 不放行，工具必须显式声明或满足通配条件）：
 *  - 显式工具条目（tool≠"*"）命中 → 放行（四方向交集已审计该具体工具）；
 *  - 通配工具条目（tool="*"）命中 → 须 sideEffects 授权，或 natureOf 证明只读（readOnlyHint）；
 *  - 无条目命中 → 拒绝（未声明工具）。 */
export function checkMcpCallPermission(
	perm: McpPermission | undefined,
	server: string,
	tool: string,
	natureOf?: (server: string, tool: string) => "read-only" | "unknown",
): McpPermissionDecision {
	if (!perm) return { allowed: true }; // 未注入执法面=legacy 通道（v1 行为）
	// 显式条目优先于通配（条目顺序不影响判定）：显式声明即审计结论，通配才需性质/副作用证明
	const hit = perm.allow.find((e) => e.tool !== "*" && entryMatches(e, server, tool))
		?? perm.allow.find((e) => entryMatches(e, server, tool));
	if (!hit) {
		const granted = perm.allow.map((e) => `${e.server}/${e.tool}`).join(", ") || "（空名单）";
		return {
			allowed: false,
			reason: `${server}/${tool} 未在任务授权名单（已授权: ${granted}；server 路由不等于工具授权）`,
		};
	}
	if (hit.tool !== "*") return { allowed: true };
	if (perm.sideEffects === true) return { allowed: true };
	const nature = natureOf?.(server, tool) ?? "unknown";
	if (nature === "read-only") return { allowed: true };
	return {
		allowed: false,
		reason: `${server}/${tool} 工具性质未知（发现面无 readOnlyHint 证据），只读授权下不得当只读放行；需任务显式声明该工具或授权副作用`,
	};
}

/** 发现面筛选（§5.2「未声明工具拒绝，发现面不泄漏未授权能力」）：返回可展示工具与被隐藏数。
 *  只读执法（sideEffects≠true）下通配条目仅展示可证明只读的工具（annotations.readOnlyHint）。 */
export function filterDiscoveredToolsForPermission<T extends { name: string; annotations?: { readOnlyHint?: boolean } }>(
	perm: McpPermission | undefined,
	server: string,
	tools: readonly T[],
): { visible: T[]; hidden: number } {
	if (!perm) return { visible: [...tools], hidden: 0 };
	const visible: T[] = [];
	let hidden = 0;
	for (const t of tools) {
		const nature: "read-only" | "unknown" = t.annotations?.readOnlyHint === true ? "read-only" : "unknown";
		if (checkMcpCallPermission(perm, server, t.name, () => nature).allowed) visible.push(t);
		else hidden++;
	}
	return { visible, hidden };
}

/** 权限面引用的具体 server 集合（用于收窄 server 路由）；存在通配 server 条目（"*"）时返回
 *  null=不收窄（通配引用全部已路由 server）。 */
export function concreteServersReferenced(perm: McpPermission | undefined): string[] | null {
	if (!perm) return null;
	const concrete = new Set<string>();
	for (const e of perm.allow) {
		if (e.server === "*") return null;
		concrete.add(e.server);
	}
	return [...concrete];
}
