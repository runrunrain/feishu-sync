/**
 * cost-source.ts — 计费口径标注（pi 1.5.0 Usage.cost.totalFromProvider 消费面，v1.0.23 wire）。
 *
 * 背景：pi 1.5.0 起 Usage.cost携带 totalFromProvider（true=供应商计费总额；false=目录价估算；
 * 组合 usage 仅当全部组成部分都是 provider-reported 才为 true）。amagi 的 usage 汇总链
 * （task-jsonl 解析 → stats/trace 行 → writeStats 漏斗 → webui UsageStore → wire → 前端统计）
 * 此前只保留 cost.total 数值、丢弃口径——本模块提供单一合并语义，把口径随行累计到前端。
 *
 * 合并语义（格上的 join，幂等且结合）：
 * - provider ⊕ provider = provider；estimate ⊕ estimate = estimate；
 * - unknown ⊕ unknown = unknown（成本值存在但口径字段缺失——旧宿主 <1.5.0，不冒充 provider）；
 * - 任意两个不同原子（provider/estimate/unknown）⊕ = mixed；mixed 吸收一切。
 * 观测缺席（无 cost 值）不参与合并：undefined ⊕ x = x。
 * 与 pi 语义一致：一行只在**全部**已观测成本都是 provider-reported 时才标 provider；
 * 部分缺失口径（字段缺席/估算混杂）如实降级，绝不上抬。
 *
 * 纯模块：零依赖（不 import pi/fs/UI），被 task-jsonl / task-run / task-tool / webui-usage-store
 * 共用（depcruise webui-isolated 门禁不受影响）。
 */

/** 一行/一桶成本的口径标注（wire 冻结字符串；undefined=无成本观测，读侧按 unknown 呈现）。 */
export type CostSource = "provider" | "estimate" | "mixed" | "unknown";

/**
 * 单次观测 → 口径原子。cost 缺席或为 0（=通道未上报——与 stats-aggregate/usage-footer 既有口径
 * 一致：cost===0 且 token>0 提示「无单价」而非免费）不参与口径合并（返回 undefined）；
 * cost 存在但 totalFromProvider 字段缺席（旧宿主/标量 cost 形态）→ "unknown"（不冒充 provider）。
 */
export function costSourceOfObservation(cost: number | undefined, fromProvider: boolean | undefined): CostSource | undefined {
	if (cost === undefined || cost === 0) return undefined;
	return fromProvider === true ? "provider" : fromProvider === false ? "estimate" : "unknown";
}

/** 口径合并（格 join；任一侧 undefined 取另一侧；两侧皆 undefined 返回 undefined）。 */
export function mergeCostSource(a: CostSource | undefined, b: CostSource | undefined): CostSource | undefined {
	if (a === undefined) return b;
	if (b === undefined) return a;
	return a === b ? a : "mixed";
}

/** 读侧归一：非四枚举值（含旧行/坏数据）→ undefined（=未知，不入账不冒充）。 */
export function normalizeCostSource(value: unknown): CostSource | undefined {
	return value === "provider" || value === "estimate" || value === "mixed" || value === "unknown" ? value : undefined;
}
