/** 异步咨询：开始即返回句柄；结果沿原会话队列注入，查询不重复记账。 */
import { randomUUID } from "node:crypto";
import { VERSION } from "@earendil-works/pi-coding-agent";
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
type Tool = Parameters<ExtensionAPI["registerTool"]>[0];
type Result = Awaited<ReturnType<Tool["execute"]>>;
interface Consultation { sessionId: string; controller: AbortController; done: Promise<Result>; result?: Result; delivered: boolean; syncConsumer?: boolean; notification?: { customType: string; content: string; display: boolean; details: unknown } }
export function registerBackgroundAdvisor(api: ExtensionAPI, synchronous: Tool): void {
	const records = new Map<string, Consultation>();
	const version = String(VERSION ?? "").match(/^(\d+)\.(\d+)/);
	const supportsAsync = !!version && (Number(version[1]) > 1 || (Number(version[1]) === 1 && Number(version[2]) >= 3));
	const ending = new Set<string>();
	api.on("agent_start", (_event, ctx) => { ending.delete(ctx.sessionManager.getSessionId()); });
	api.on("agent_end", (_event, ctx) => { ending.add(ctx.sessionManager.getSessionId()); });
	// 原生结算前边界能原子追加资料并保证下一次模型请求，避免 agent_end 中重入 run 死锁。
	if (supportsAsync) api.on("agent_before_settle", async (event, ctx) => {
		const sessionId = ctx.sessionManager.getSessionId();
		const own = [...records.values()].filter(r => r.sessionId === sessionId);
		if (event.outcome === "aborted") { for (const r of own) if (!r.result) r.controller.abort(); return; }
		await Promise.allSettled(own.map(r => r.done));
		const completed = own.filter(r => r.notification && !r.delivered && !r.controller.signal.aborted);
		if (!completed.length) return;
		for (const r of completed) r.delivered = true;
		return { entries: completed.map(r => ({ type: "custom_message" as const, ...r.notification! })), continue: true };
	});
	api.on("session_shutdown", async () => {
		for (const r of records.values()) if (!r.result) r.controller.abort();
		await Promise.allSettled([...records.values()].map(r => r.done));
		records.clear();
	});
	api.registerTool({ name: synchronous.name, label: synchronous.label,
		description: synchronous.description + " 默认 delivery=handle 异步返回，建议完成后自动注入原会话；先继续独立工作。需要答案才能决策时 action=wait；query/cancel 使用返回的 handle。delivery=wait 可显式同步咨询。",
		parameters: Type.Object({ action: Type.Optional(Type.Union([Type.Literal("consult"), Type.Literal("query"), Type.Literal("wait"), Type.Literal("cancel")])),
			question: Type.Optional(Type.String({ minLength: 1, maxLength: 32768 })), handle: Type.Optional(Type.String()),
			delivery: Type.Optional(Type.Union([Type.Literal("handle"), Type.Literal("wait")])),
			contextMode: Type.Optional(Type.Union([Type.Literal("isolated"), Type.Literal("selected"), Type.Literal("fork")])),
			contextRefs: Type.Optional(Type.Array(Type.String(), { maxItems: 32 })) }),
		async execute(callId, p, signal, onUpdate, ctx) {
			const text = (value: string, isError = false) => ({ content: [{ type: "text" as const, text: value }], details: {}, ...(isError ? { isError } : {}) });
			const sessionId = ctx.sessionManager.getSessionId(), action = p.action ?? "consult";
			if (action !== "consult") {
				const r = records.get(p.handle ?? "");
				if (!r || r.sessionId !== sessionId) return text("Advisor 句柄不存在或属于其他会话；恢复后请查看原会话已交付建议。", true);
				if (action === "cancel") { r.controller.abort(); return { ...text(`Advisor ${p.handle} 已请求取消；原任务继续。`), details: { handle: p.handle, status: "cancelled" } }; }
				if (action === "wait" && !r.result) { r.syncConsumer = true; await waitForConsultation(r.done, signal); }
				if (!r.result) return text(`Advisor ${p.handle} 仍在咨询；继续不依赖建议的工作。`);
				// 用量只在自动完成通知入账；查询与等待均是只读，不返第二份 usage。
				const includeUsage = action === "wait" && !r.delivered;
				if (includeUsage) r.delivered = true;
				return { ...r.result, details: { ...(r.result.details as any), advisor: { ...(r.result.details as any)?.advisor, accountUsage: includeUsage } }, usage: includeUsage ? r.result.usage : undefined };
			}
			if (typeof p.question !== "string" || !p.question.trim()) return text("Advisor consult 必须提供 question", true);
			if (p.delivery === "wait") return synchronous.execute(callId, p, signal, onUpdate, ctx);
			if (!supportsAsync) return text("当前宿主的异步咨询需 pi 1.3+；可升级宿主，或显式使用 delivery=wait。未启动咨询。", true);
			// 总记录有界；进行中的条目从不逐出。已交付的全文仍在原生会话中。
			if (records.size >= 128) for (const [key, r] of records) { if (r.result) records.delete(key); if (records.size < 128) break; }
			if (records.size >= 128) return text("Advisor 在途咨询过多", true);
			const handle = `advisor-${randomUUID()}`, controller = new AbortController();
			const abort = () => controller.abort();
			if (signal?.aborted) return text("Advisor 已取消", true);
			signal?.addEventListener("abort", abort, { once: true });
			const record: Consultation = { sessionId, controller, delivered: false, done: Promise.resolve(text("pending")) };
			records.set(handle, record);
			record.done = Promise.resolve(synchronous.execute(callId, p, controller.signal, onUpdate, ctx)).then(result => {
				record.result = result;
				if (controller.signal.aborted) return result;
				// followUp 由宿主在完整工具对之后注入；不会打断当前工具或替换工作模型。
				record.notification = { customType: "amagi:advisor-result", content: `咨询 ${handle} 已完成。结合当前进展判断是否采纳；咨询不是新任务；继续原任务。如已完成，仍须按原任务交付契约给出终稿和完成标记。\n` + result.content.filter(c => c.type === "text").map(c => c.text).join("\n"),
					display: true, details: { advisor: { ...(result.details as any)?.advisor, callId, usage: result.usage ?? (result.details as any)?.advisor?.usage, handle } } };
				if (!ending.has(sessionId) && !record.syncConsumer) {
					api.sendMessage(record.notification, { deliverAs: "followUp", triggerTurn: true });
					record.delivered = true;
				}
				return result;
			}).finally(() => signal?.removeEventListener("abort", abort));
			return { content: [{ type: "text" as const, text: `Advisor 咨询已开始：${handle}。继续独立工作；建议就绪后自动注入。依赖建议时 amagi_advisor({ action: "wait", handle: "${handle}" })。` }], details: { handle, status: "running", startedAt: Date.now() } };
		},
	});
}
async function waitForConsultation<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T> {
	if (!signal) return promise;
	signal.throwIfAborted();
	let abort = () => {};
	try { return await Promise.race([promise, new Promise<never>((_resolve, reject) => { abort = () => reject(new Error("Advisor 等待已取消；咨询可通过 cancel 单独终止")); signal.addEventListener("abort", abort, { once: true }); })]); }
	finally { signal.removeEventListener("abort", abort); }
}
