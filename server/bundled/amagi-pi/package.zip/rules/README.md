# rules/

pi 不会自动加载本目录。amagi 的规则权威源在 `resources/core/`，请用 `amagi_resource` 按 canonical ID 读取（如 quality、tools、workflow、baseline）。
本目录保留，仅为兼容 `amagi_resource` 的读取沙箱。
