# 设备与部署定位资料

以下从旧 prompt 的 2026-10 快照及迁移记录整理。本次只整理文档，未连接验证。地址、版本、账号、安装位置和运行状态须在执行时核查，用户参数与当前可信配置优先。

## Windows 工作机

- 历史设备名 DESKTOP-NAALPFC，Tailscale 名 desktop-naalpfc，地址 `100.92.3.34`；旧局域网地址 `192.168.5.11`。
- 历史账号毛润，密钥路径 `~/.ssh/id_ed25519_winpc`。管理员账号不表示每个命令均已提权，须核对实际会话。
- 旧客户端入口：`~/tools/sshvenv/bin/python ~/tools/win_ssh.py`。曾因中文用户名被当时的 OpenSSH 客户端拒绝而采用 paramiko；使用前核对封装的目标、主机身份验证、超时与退出码。
- 旧远端为 Windows 11 / PowerShell；SSH 22，WSL sshd 候选 2222，代理候选 `127.0.0.1:5800`。
- Tailscale 曾使用服务级代理及 unattended。当前故障需要诊断，不据历史直接重写注册表或重装。

## Mac mini

- 历史别名 `macmini`、`macmini-lan`；Tailscale 名 run，地址 `100.92.24.117`；旧局域网地址 `192.168.5.3`。
- 历史密钥路径 `~/.ssh/id_ed25519`，屏幕共享候选端口 5900；v2rayN 候选 `/Applications/v2rayN.app`，代理候选 `127.0.0.1:5800`。
- 系统版本、硬件、pi/Homebrew 安装情况按任务需要检测，旧快照不能直接填入新报告。
- 优先通过已认证通道查询局域网地址；无法连接时查可信设备配置或用户提供的新地址，不自动扫描旧网段。

## sub2api / FRP / CLIProxyAPI

历史宿主为 Mac mini，执行前核对实际本地或远端宿主。

| 组件 | 候选配置与标识 |
|---|---|
| Compose | `~/sub2api/docker-compose.yml`；历史服务 sub2api / postgres / redis，版本以当前配置为准 |
| Docker Desktop | `/Applications/Docker.app`；CLI 曾位于 `~/.local/bin/` |
| FRP | `~/frp/frpc`、`~/frp/frpc.toml`；launchd `com.sub2api.frpc` |
| CLIProxyAPI | `~/cliproxyapi/`；launchd `com.cliproxyapi`；候选端口 8317 |
| 健康端点 | 历史本地 `http://127.0.0.1:8080/health`，公网 `http://47.103.109.56:8081/health` |
| 隧道 | 历史 frps `47.103.109.56:7000`；sub2api-http：8080→8081；cc-switch-remote：8680→8680 |

8680 曾用于 amagi-codebox 远程 API，当前归属和访问方式需核对。备份旧路径为 `~/s2a-mig/` 和本机 `/tmp/s2a-mig/`，不能假定仍存在或可恢复。旧 Windows 部署是否停止需实际检查。

## battle-simulator 内网部署

- 历史 Mac 路径 `/Users/maorun/maorun-workpace/battle-sim/battle-simulator`，仅作定位线索。
- 目标文件：`deploy/intranet.env`、`deploy/production.sh`、`docs/内网部署指南（macOS 与 Windows）.md`。
- 历史配置键：INTRANET_HOST、INTRANET_BIND_ADDRESS、PUBLIC_ORIGIN、INTRANET_HTTP_PORT。端口及容器名以当前有效配置为准。
- 历史发布入口为 `release --profile intranet`，先核对当前参数、备份及排空流程。换网络不自动同步内置场景或删除卷。
