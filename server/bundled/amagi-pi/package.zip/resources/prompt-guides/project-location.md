# 项目与工作区定位

供会话记忆与批量仓库命令引用。相对资源路径以引用它的文件所在目录解析，不以用户项目 cwd 解析。

1. 当前请求指定的项目或路径优先，复用本会话已核实的定位。
2. 需要 registry 时，从工作目录逐级查找 `{WORKSPACE_ROOT}/projects-memory/projects/registry.json`。WORKSPACE_ROOT 是包含 projects-memory 的目录；registry 所在的 projects 目录为 PROJECTS_DIR。
3. 读取 activeProject 与 projects[activeProject].projectPath：
   - PROJECT_META_ROOT = PROJECTS_DIR / activeProject
   - PROJECT_CODE_PATH = 对应 projectPath
   - TODOS_DIR = WORKSPACE_ROOT / projects-memory / todos
4. registry 存在但无效、项目未注册或与当前任务冲突时，报告具体问题，不另猜一个项目覆盖。任务显式提供的完整路径无需为缺少 registry 再创建注册表。
5. 已配置的 AMAGI_WORKSPACE_ROOT 可用于定位候选 registry，使用前验证目录及项目归属；不把环境变量当作绕过错误配置的依据。

批量仓库操作：按显式路径或已确认工作区扫描直接子目录及 registry 注册路径，同时考虑扫描根自身是否为仓库；按真实仓库根去重。范围不明确时先列出候选并确认范围，不向整个磁盘扩展。会话记忆操作依赖明确的 PROJECT_META_ROOT；缺少定位时只报告缺口。
