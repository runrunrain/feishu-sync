# 发布单元与版本规则

从现有仓库声明与远端基线确定发布单元和版本，操作已完成时不重复递增。已有发布版本不能被改写。

## 插件仓库的版本同步

在 fetch 和远端关系核对之后、提交之前执行；GitHub Release 也复用版本字段规则。识别插件仓库看信号，不按仓库名写死；出现以下任一信号即视为插件类仓库：

- 根目录或 `plugins/<name>/` 下有 `.claude-plugin/plugin.json` 或 `.codex-plugin/plugin.json`；
- 有 `.claude-plugin/marketplace.json` 或 `.agents/plugins/marketplace.json`；
- 根 `package.json` 声明 `pi-package` 关键词及 `pi` 资源清单；
- 根 `package.json` 的名称、exports/files、OpenCode 依赖或仓库说明明确表明它是独立的 OpenCode/npm 插件。

普通的 npm 应用、库，或只是恰好有个无关 `package.json` 的仓库，跳过本节。

### 1. 建立远端基线和完整变更集

以 fetch 后核对的推送目标远端分支作为 `BASE_REF`，不假定它与本地分支同名。变更路径要覆盖全：

- `git diff --name-status "$BASE_REF" --`：包含本地已提交未推送、已暂存和未暂存的变更；
- `git ls-files --others --exclude-standard`：补上未跟踪的文件。

被删除的源文件也算受影响——只看当前还存在的文件，会漏掉删除型变更。

从变更集里识别发布单元：

- marketplace 仓库：变更命中 `plugins/<name>/` 时，这个 `<name>` 是一个发布单元；
- 独立插件仓库：根插件入口、prompt/agent/command/skill/resource/rule/hook/MCP、转换器、测试或发布文件有变化时，根包是一个发布单元；`npm pack --dry-run` 或发布清单会包含的 README 等文件也算发布物；
- 只改了仓库级 CI、通用文档或和插件包无关的工具时，不提升插件版本；拿不准归属时，跳过该仓库并报告。

同一个发布单元在一次执行中只更新一次版本。

### 2. 找到所有版本字段

对每个发布单元，读取实际存在、且属于同一发布物的版本字段：

- `.claude-plugin/plugin.json` 的 `version`；
- `.codex-plugin/plugin.json` 的 `version`；
- `.claude-plugin/marketplace.json` 中对应 `plugins[]` 条目的 `version`；
- 独立 npm/OpenCode/pi 插件的根 `package.json`，以及 `package-lock.json` 的根 `version` 和 `packages[""].version`；
- 仓库发布文档里明确声明的其他 release manifest/lock 字段。

`.agents/plugins/marketplace.json` 目前没有版本字段时，不要新增。`manifest/upstream.json` 之类的上游来源版本记录的是出处，不是目标包的版本，除非目标仓库明确规定二者同步。

读写都用 JSON 解析器，精确写回并保留未知字段。不要用正则或全局字符串替换来改版本号——会误伤依赖版本等相似的数字。涉及凭据的字段不输出。

### 3. 以远端版本为基准确定目标版本

对已有的发布单元，从 `BASE_REF` 读出上述字段作为 `base_version`（看字段的值，而不只是看文件是否出现在 diff 里）：

1. 基线的各版本字段应一致，且符合严格的 `MAJOR.MINOR.PATCH`；不一致或解析不了就跳过该仓库并报告。
2. 未指定版本时默认目标为 `PATCH + 1`；明确的用户版本或仓库发布约定优先，先核对合法性与发布基线。
3. 当前各字段仍等于 `base_version`：自动写成确定的目标版本。
4. 当前各字段已经等于目标版本：说明改动者已经正确升级过，保留，不再递增。
5. 当前版本高于基线、但不等于目标版本：核对用户参数与仓库发布规范；无法确定时报告歧义，不擅自覆盖已准备的版本。
6. 当前版本低于或等于远端基线、且各字段互不一致：跳过并报告。不要擅自挑一个文件当作准。

新插件在 `BASE_REF` 里还不存在时，保留它显式声明且彼此一致的初始 SemVer，首次推送前不再自动加 PATCH；缺少版本或缺少相应的 registry 条目时，跳过并报告。

注意：「版本文件被修改了」不等于「版本已经提升了」，判断要比较 JSON 字段的基线值和当前值。

### 4. Marketplace 自身的版本

当 `.claude-plugin/marketplace.json` 有 `metadata.version`，并且这次新增/删除了插件、修改了插件条目或更新了任一插件版本时，把 marketplace 当作一个独立的发布单元：

- 以 `BASE_REF` 的 `metadata.version` 为基线，按同样的 PATCH 规则更新一次；
- 多个插件同时变化，也只递增一次；
- 已经手工提升到正确目标的，保留，不再递增。

仓库明确声明 metadata 不随插件更新时，遵循仓库的发布规范，并在报告里说明依据。

### 5. 版本更新后的检查

1. 重新解析 JSON，逐字段核对同一发布单元的所有版本字段一致；
2. 确认 package-lock 只改了根包版本，没有误改依赖版本；
3. 按版本及锁文件实际变化追加受影响的验证；已通过且内容未变的验证可复用，失败停止该仓库；
4. 复查完整 diff、敏感文件和 staged 范围，确保新改的版本文件进入同一个提交；
5. 在报告里写清每个发布单元的 `base -> target`，属于自动更新、已预先更新还是新插件保留，以及 marketplace metadata 的变化。


GitHub Release 的显式 tag 与目标版本须一致；已有 tag 同提交且版本相符时可恢复未完成发布，目标冲突时报告。预先完成的版本更新应复用，不再按当前版本额外加 PATCH。
