# 天城任务分面工具规范（tools-facets）

本文档说明 amagi v2 的任务工具：四个常驻的稳定工具，加一个按需启用的批次工具 `task_batch`。会话启动时，当前工具面的版本会留档（`amagi:tool-surface`），旧会话续接时据此恢复同一套工具。

**最常用的流程只有三步**：`task_submit` 派发 → 读返回的终稿与回执 → `task_control accept` 接受（或 `reject` 后重派）。下面先讲三轴状态和错误格式，再逐个讲工具；第四节有可直接照抄的完整示例。

---

## 一、核心概念

### 1. 三轴状态：执行、结算、接受各自独立
一个任务的状态分在三条轴上，分开看才不会误判“跑完了就算通过”：

- **`execution`（执行轴）**：子进程生命周期。`queued`（排队）、`running`（运行中）、`done`（正常退出）、`blocked`（提问挂起）、`cancelled`（已取消）、`error`（异常退出）。
- **`settlement`（结算轴）**：终稿与回执是否落盘齐全。`pending`（等待结算）、`ready`（结算就绪、回执完整）、`failed`（结算失败、证据不合规）、`incomplete`（部分交付）。
- **`acceptance`（接受轴）**：语义验收。`unreviewed`（初始，未决策）、`accepted`（已接受）、`rejected`（已拒绝）。

执行完成不等于结算就绪，更不等于验收通过。只有 `task_control` 的 `accept` 会记录语义验收；没有 accept 的任务会一直处于待验收状态。

### 2. 权限：你声明意图，插件按交集授予
任务参数里的 `scope`、`profile`、`inputs`、`outputs`、`workspace` 都是**请求面**——表达“这个任务想要什么”。实际授权是请求、角色卡、用户配置和执行后端四方的交集，请求不会放大权限。

**省力的默认值**：
- `scope.write` 不填时，写入范围缺省取角色卡的 `capabilities.write`。派发内置角色通常不必逐任务授权写入；显式填写只用于收窄或留档。注意 `[]` 空数组表示显式收紧为不可写，不会回退到角色卡。
- 读取不设执行期限制，只有 `deny` 禁入会拒绝。
- 路径条目不含通配符时会自动按目录感知归一：指向文件就精确匹配；指向目录（或尚不存在的路径）就扩为整棵子树。

**声明性 vs 硬执法**：`read`、`write`、`reportFiles` 主要是**声明性**的——冻结进授权记录（grant），供回执和审计展示，guarded 模式下不逐次拦截写入。真正会被拦下的只有这几项：
- `deny` 禁入：读写都拒；按字面路径或符号链接真实落点，任一命中即拒。
- 写入契约存储区域、跨文件系统根。
- shell 通道、mcp/lsp 名单超出授权。
- tool-enforced 角色（无 bash）写工作区外：需要被 `scope.write` / `scope.reportFiles` 显式覆盖，或落在真实的 agent-outputs 报告目录。角色卡的写入范围以任务 cwd 为基准，覆盖不到工作区外；符号链接按真实落点检查。

误写的兜底靠 git worktree 可回滚、evidence diff 归因和审核链，而不是事前多设门禁。（来由：ev-20260919、ev-20261016）

**会整单拒绝的情形**：角色能力声明缺失，或必需通道超出角色上限时，整单拒绝（`effects=none`，不启动任何子进程）。`outputs` 只声明产物位置，不自动授予写入；未被写入范围覆盖的外部产物只给出派发提示，不拒单也不扩权，运行期围栏照常生效。`profile` 需要是受信配置中的名称，不接受任意覆盖字典。

### 3. 错误格式 ContractError 与可选参数的 null
所有状态变更由内核单写者（Single-Writer Fence）串行处理。参数不符或业务校验失败时，返回结构化的 `ContractError`：

- `code`：错误分类码，如 `unknown-field`、`invalid-field`、`stale-receipt`、`stale-revision`。
- `message`：具体原因。
- `fields`：出错字段路径。
- `effects`：副作用状态；`"none"` 表示没有写入任何状态、也没有启动进程，可以放心修正重发。
- `repairExamples`：合法的最小修复示例。照着示例改参数再发一次，通常就能通过。

**可选参数不必填 null**：部分后端在严格采样（constrainedSampling strict）下会把所有可选字段都带上。值为 `null` 的键、以及被写成字符串 `"null"` 的字符串/枚举字段，一律当作没传（在宿主 schema 校验前由 prepareArguments 剥离；数组元素不剥）。唯一的副作用：如果某个字段的合法值恰好就是字符串 `"null"`，它会被当作缺失而拒绝——这种情况会给出可修复的错误，而不是卡死。（来由：ev-20260919、ev-20260920）

---

## 二、四个稳定工具（常驻）

### 1. `task_submit`：提交任务
冻结任务契约（spec）并启动执行。最简单的调用只需要 `agent` 和 `task`：
`task_submit({agent:"baize",task:"查明问题并给出可复核证据"})`。

#### 必填与任务书
- `agent` (string, 必填): 目标角色名，需在角色名册（agents-loader）内，如 `luban`、`luoshen`、`fuxi`、`diting`。
- `task` (string, 与 `taskFile` 二选一): 新任务书完整正文（assignment），长短都直接提交。写清目标、边界与验收方式。harness 会先冻结并持久化进 spec，再入队/启动子 Agent——一次调用完成派发，不需要先用 Write 保存任务书。
- `taskFile` (string, 与 `task` 二选一): 已经写好的 UTF-8 任务书文件（普通文件，≤1MiB），适合复用现成的任务书，免得转写原文。
  - 相对**调用者 cwd** 解析，不随 `workspace.cwd` 或 worktree 重定位。
  - 提交时读取快照并冻结进 assignment（原文保留 Unicode、引号和换行），之后再改文件不影响已提交的任务；来源路径自动加入输入清单。
  - 工具自动等待同文件已登记的 Write/Edit 完成后再读取（路径按真实落点归一）；默认最多等 30 秒，超时或同轮写入失败（包括 schema/tool_call 预检阶段已拒绝的写调用）会拒绝派发，`AMAGI_TASKFILE_WRITE_WAIT_MS` 可调上限。
  - 当前 pi 并行批次会先登记全部调用再执行，因此 Write/Edit 在调用列表前后均可。尚未登记的未来调用、外部进程和 bash/MCP 写入无法预测，不在自动等待范围内；旧宿主若无批内登记屏障也受此边界约束。
  - 文件缺失、空白、不是有效 UTF-8 或命中 deny（含符号链接真实落点）时，在创建工作树/入队前拒单。只读取正文，frontmatter 不会被解析为配置、权限或命令。

#### 交付方式
- `delivery` (string, 可选):
  - `"wait"`（缺省）：等到本轮终态，直接返回终稿正文与三轴状态。
  - `"handle"`：立即返回任务句柄（taskId），任务在后台或 FIFO 队列运行；到达终态时自动向会话发送通知。
- `dryRun` (boolean, 可选): 预检模式——完整校验契约、角色、授权、服务可用性（mcp/lsp 检测）与输入存在性，但不 spawn、不入队（`effects=none`），返回预检摘要。确认无误后去掉 `dryRun` 正式提交。

#### 输入与产物
- `inputPaths` (string[], 可选): 必读输入的快捷写法，自动展开为 `inputs` 对象（用途为「任务参考输入」、`required=true`）；与 `inputs` 二选一。
- `outputPaths` (string[], 可选): 必需文件产物的快捷写法，自动展开为 `outputs` 对象（`kind=file`、`required=true`）；与 `outputs` 二选一。目录树或可选产物用 `outputs` 对象声明。
- `inputs` (array, 可选): 输入清单，自动注入任务正文（不必在 `task` 里重复），路径按任务 cwd 解析。可以混用路径字符串与对象：`"docs/spec.md"` 等价于 `{path:"docs/spec.md",purpose:"任务参考输入",required:true}`。需要写明用途或允许缺失时用对象：
  - `path` (string, 必填): 输入文件或目录路径。
  - `purpose` (string, 必填): 用途说明。
  - `required` (boolean, 可选): 缺省视为 `true`。非 `false` 且路径不存在时，执行前整单拒绝（与 outputs 的 `required ?? true` 同口径）。
- `outputs` (array, 可选): 预期产物清单，自动注入任务书并冻结产物契约。同样可混用：`"out/report.md"` 等价于 `{path:"out/report.md",kind:"file",required:true}`。插件不根据路径猜形态，目录树/可选产物请用对象显式声明：
  - `path` (string, 必填): 预期产物路径。
  - `kind` (string, 可选): `"file"`（缺省）或 `"tree"`（目录树）。
  - `required` (boolean, 可选): 是否为验收必需项。
  - `purpose` (string, 可选): 产物用途说明。

让模型生成纯路径清单时，`inputPaths/outputPaths` 最省事。混合写法在宿主校验前经 `prepareArguments` 展开，直接 execute 也走同一逻辑。

#### 权限请求 scope
- `scope` (object, 可选): 权限请求，取值与角色上限求交集：
  - `read` (string[], 可选): 预期读取范围。声明性，只记录意图；读取只受 deny 限制。
  - `write` (string[], 可选): 写入范围。不填时取角色卡 `capabilities.write`，显式填写用于收窄或留档。guarded 为声明性；tool-enforced 写工作区外时需要被 write/reportFiles 覆盖；deny、契约存储、跨根优先于它；目录自动归一为子树。
  - `deny` (string[], 可选): 禁入路径。
  - `reportFiles` (string[], 可选): 仅报告可写的路径。
  - `shell` (string, 可选): shell 通道三种取值：
    - `"deny"`（缺省）：不请求。
    - `"guarded"`：必需。四方交集（角色 ∩ 用户 ∩ 请求 ∩ 后端）为空时整任务拒绝。
    - `"optional"`：希望有、但不是必需。交集为空时自动降级为 deny，并在提交回执/dryRun 摘要中提示，不拒单。
    - 五个内置角色都允许 `guarded`。只有自定义的受限角色（上限 `shell=deny`）会因请求 `guarded` 被拒——对这类角色改用 `optional` 或不请求即可。（来由：ev-20260930-c703e3）
  - `mcp` (string[], 可选): 请求开放的 MCP 工具名。
  - `lsp` (string[], 可选): 请求的 LSP 能力，可选 `"diagnostics"`、`"definition"`、`"references"`、`"hover"`、`"rename"`。
- `profile` (string, 可选): 受信 profile 名称（如 `"tiered"`、`"inherit"`），需在受信配置名单中。
- `model` (string, 可选): 本次派发临时模型覆盖，单个 `"provider/model[:thinking]"` spec（来由：ev-20261031）。沿既有解析/归一/冻结链执行：仅本轮生效，不改 amagi.json/角色配置，不改变权限；未注册模型会被诚实拒绝（附相近候选），不会静默回退默认模型。provider 限流/配额恢复场景使用——失败恢复指引会直接给出可复制的换模调用。

#### 工作区 workspace
- `workspace` (object, 可选):
  - `cwd` (string, 可选): 任务工作目录，绝对路径或相对 Leader cwd；不填继承 Leader cwd。
  - `mode` (string, 可选): `"existing"`（缺省，用现有目录）或 `"worktree"`（独立 git 工作树）。
  - `worktreeName` (string, 可选): `mode="worktree"` 时的工作树标识。
  - `dependencyVisibility` (string, 可选): 依赖可见性，通常不用填。`"portable"`（依赖可移植，worktree 可复用主树安装）、`"main-tree"`（依赖只在主树可见，worktree 需自行安装）、`"unknown"`（缺省）。
  - `base` (string, 可选): worktree 的检出基线，只对新建的树生效：
    - `"head"`（缺省）：仓库当前 HEAD；主树未提交/未跟踪的内容不带入。
    - `"dirty-snapshot"`：把主树当前**Git 可见**的未提交/未跟踪内容冻结为一个快照 commit 再检出。用临时 index 构建，不扰动主树，排除 `.amagi-worktrees`。
      - 遵守 `.gitignore`：被忽略的路径不进快照，可按调用者侧路径跨树读取。
      - 快照不是主树某一原子时刻的状态；构建期间的并发写入只给漂移提示。体积无上限。
    - 复用已有的树或分支时，按树自身 HEAD 检出并披露差异，不会静默换基线。（来由：ev-20261017-cd233f、ev-20261021）

**声明路径怎么解析**（来由：ev-20261017-348337、ev-20261021）：
- `taskFile` 始终按真实调用者 cwd 解析。
- `inputs/outputs` 的相对路径：`existing` 模式按任务工作目录；`worktree` 模式按**真实调用者 cwd**（`workspace.cwd` 只用于定位项目和建树根，不参与声明路径解析）。解析为绝对路径后再校验、冻结。
- worktree 模式下，树内可达的输入会换算成工作树内路径注入（建树后按实际内容复验）；仓库外或被 `.gitignore` 覆盖的输入，以绝对路径跨树读取，并在回执中披露。需要它们出现在树内时改用 `base="dirty-snapshot"`（被 ignore 的路径仍不进快照）。
- 产物相对路径在冻结时换算为工作树内的落点，子 Agent 在树内落盘，隔离与回流不变。
- 以上口径适用于四个稳定工具。legacy `task` 工具的 allowedPaths/reportPath 仍按树内基准解析（旧会话 resume 或 `AMAGI_SURFACE_LEGACY=1` 才会用到，属已知遗留）。

#### 派发示例
新任务直接提交完整正文，由 harness 保存并派发：
```javascript
task_submit({
  agent: "luban",
  task: "目标：实现需求。\n范围：按现有模块接入。\n验收：执行相关测试并报告证据。",
  inputPaths: ["docs/需求.md"],
  outputPaths: ["out/实现报告.md"],
  scope: { shell: "guarded" }, // 任务要求自行执行验证命令时，仍需明确申请
  delivery: "handle"
})
```
- 已有完整任务书时，把 `task` 换成 `taskFile:"tasks/实现任务.md"`；派发新任务不需要专门再建任务书文件。批次同理，使用 `nodes[].task`。
- 简写只展开参数：不会自动选角色、授予 shell、创建 worktree 或执行 accept。
- 输入清单冻结的是引用和用途，文件内容由执行者自己读取；`task` 和 `taskFile` 的正文在提交时冻结。
- 最终任务提示超过 128KiB 时，harness 自动保存全文并把读取指引交给子 Agent，Leader 不用额外 Write。提示总量仍有 900KiB 硬上限，超出时拆分任务，把参考材料放进输入文件。

**跨仓库写产物**（例如在源库 cwd 中更新外部知识库）：派发前比较一下**任务实际 cwd** 与目标的真实落点。`outputs/outputPaths` 只冻结落位，不代替写入声明，所以 tool-enforced 任务需要显式带上准确的 `scope.write` 或 `scope.reportFiles` 外部路径；文档任务也可以把 `workspace.cwd` 设为目标库，源库用绝对路径作为输入。先用 dryRun 看一下 `[产物写面提示]`，修正后再正式派发。wait、handle 和 batch 节点都会给出这个提示；提示不改变授权，也不能绕过 deny/跨根/契约存储限制。只有确实选择中转时才让 Leader 代为落盘，这不是未声明写入的默认流程。

#### 返回信息
返回文本首行是摘要：
`[task_submit <taskId 前 8 位> <agent> · <statusLabel>]`
details 中包含 `taskId`、`revision`、`execution`、`settlement`、`acceptance`、`receiptRef` 等标识。

### 1a. 上下文交接：contextMode 与 contextRefs
默认情况下子 Agent 只看到任务书和显式输入。需要把当前对话里的信息交给它时，用这两个参数，不必手抄进任务书：

- `contextMode` (`isolated` | `selected` | `fork`, 可选):
  - `isolated`（缺省，兼容旧调用）：只收任务书和显式输入。适合独立审核、全新探索。
  - `selected`：普通承接任务的推荐选择。交付用户要求、相关工具观察、待核验的判断，以及按需读取的原文引用。
  - `fork`：继承当前可见的文本历史，适合复杂攻坚。
  - 两种继承模式都在本次调用内快照、冻结、派发，不额外调用模型做摘要，也不需要 Write。
- `contextRefs` (string[], 可选): 仅 `selected` 可用，最多 16 个来源锚点（文件路径、历史工具调用 id、消息 id 或原文片段）。指定后用匹配的来源代替自动相关性选择，同时保留可识别的用户要求。锚点不在当前可继承历史中时会拒单，不会猜测替代来源。大段来源交付节选，并附完整原文的读取引用。

**快照取什么**：宿主当前分支的公开投影，尊重原生压缩、`context_edit` 和弃枝；在本轮派发的 assistant 消息之前切断，避免把本次提交参数再带进去。来源会话/切点/工作目录、捕获时刻、内容摘要指纹及过滤数量随历史原文一起冻结进 `spec.assignment`，模式冻结进 `spec.contextMode`。不重放工具，不继承 Leader 的系统提示、工具定义、权限、thinking 或图片等二进制内容；跨模型不保证提示缓存共享。历史中 assistant 的判断保留“判断”身份，执行边界以当前任务书和子角色约束为准。

**`selected` 怎么挑**：使用原文片段，不调用模型生成摘要。
- 用户要求与最新的实质用户消息优先保留；普通相关记录最多 8 条。去掉重复观察、常规 DEBUG/TRACE/心跳行、无关的相邻计划和摘要，不拿无关记录凑数。
- 每条用 `kind` 标明身份：`user-requirement`、`tool-observation`、`leader-hypothesis`、`summary-unverified`。工具观察只代表当时读取的范围；assistant 即使自称“已确认”，也保持待核验身份。
- 每条附来源指纹、原文行号、完整性标记和 `evidenceFile`。

**预算**：交接视图软预算约 4,000 tokens（按序列化视图估算，含来源索引；实际用量以模型 usage 为准），硬上限 48KiB。先给用户要求和全部恢复索引留位，再按来源顺序分配余量；相关长行能完整放下就内联，不按固定字符数排除，也不截断行尾。放不下的普通来源保留原文引用；用户要求可以超过软预算，连硬上限都放不下时明确拒单。原文最多 512KiB，冻结进同一 `spec.assignment`，正式启动前写入 `amagi-task/<taskId>/context-evidence/`；初始提示只含视图和目录，原文按需读取。预检不写存档；存档写入失败按原启动失败路径收口。`fork` 同样以 512KiB 为上限，超限拒单。宿主缺少会话投影时，继承模式会明确拒绝，不会悄悄变成 isolated。

**子 Agent 怎么读交接条目**：
- `inlineComplete=true`：这条历史原文完整、保持原字节；但不代表源文件全文，也不代表文件仍是最新。
- `inlineComplete=false`：看 `omittedParts`（非空工具行或用户句的省略数）和 `omissionReason`（selection/budget/selection+budget）了解缺了什么。只有当前问题需要的内容缺失时才回读对应的 `evidenceFile`，格式或无关片段不必补读。
- `ranges` 定位历史原文；存档文件首行是元数据，所以行号要加 1。行内节选不代表整行全文。
- `sourceDigest` 证明原文身份，不证明文件当前没变；需要当前状态、或来源有效性不明时，按需读取必要范围。

**能力边界**：相关性和用户约束识别是确定性规则，不能保证任意自然语言历史“零噪音、零遗漏”。明确属于其他项目的内容会被剔除；同一 `[constraint:id]` / `[约束:id]` 以后一次用户要求为准，无法判断的自然语言冲突按来源顺序保留，交给执行者判断。所以关键要求最好直接写进本次 `task`，特殊来源用 `contextRefs` 指定；已经看不见的原始约束，系统不会从摘要里猜回来。`amagi_advisor` 不使用这套交接，保持原有的文本选取方式（咨询模型不能读文件，文件引用对它无效）。

**安全过滤**：继承内容按本节点冻结的授权检查来源文件和符号链接真实落点，并核对来源相对执行工作区的位置。常见凭据文件（如 auth.json、.env、私钥）不会自动继承，明确的凭据赋值会脱敏。存在 deny 时，只自动交付来源可核验的文件 read 结果；来源不明的工具/通知/摘要及其后续推断会被省略，回执给出数量。文件修改时间晚于历史观察时，该结果也会省略（这只是时间比较，不是内容版本证明）。已交付的资料仍是派发时的历史观察：工作树或验证基线变化后，只需复核受影响的部分。Leader 后续的决定用 steer 补充；同一任务续接用 task_resume，它沿原子会话继续，不重新抓取 Leader 历史。

单任务的模型 schema 保留完整对象与路径快捷字段，维持既有的约束采样行为。

---

### 2. `task_resume`：续接会话
答复 `blocked` 任务的提问，或给已有任务追加下一步指令。

#### 参数
- `handle` (string, 必填): 目标任务句柄。支持完整 `taskId`、前 8 位前缀、sessionId 或稳定 name。
- `message` (string, 必填): 续接消息——回答子 Agent 的提问，或给出下一步指令。冻结为新任务的 assignment。
- `delivery` (`wait` | `handle`, 可选): 缺省 `wait` 同步等待；`handle` 立即返回新任务句柄，完成后自动通知，同样支持查询、取消与运行中调整。连续纯等待超时时会提示你已有完成通知可用；超时不会取消任务。
- `model` (string, 可选): 本轮续接临时模型覆盖，单个 `"provider/model[:thinking]"` spec（来由：ev-20261031）。仅模型覆盖——不改 amagi.json、不扩权限、不换范围；父链连续配额类失败时恢复指引会给出可直接复制的换模续接调用（含从当前配置枚举的候选与 registry 注册/凭据探测状态；额度不可探测，首次换模即真实探测）。

#### 继承规则
- **继承不扩权**：续接会新建一个关联的子 taskId（父链可见），继承父任务的写入范围与工作目录。模型按当前项目/全局配置、profile 和角色定义重新解析，父轮模型只作 fallback；可选 `model` 参数做一次恢复性覆盖（仅模型，不改配置、不扩权）；返回中会写明本轮实际模型与来源，发生切换时同时标注父轮模型。
- **不接受权限覆盖**：`scope`、`allowedPaths`、`workspace` 等参数在续接时不可用。需要扩权或换目录时，用 `task_submit` 新派任务。
- **原目录需存在**：原任务的 `cwd` 已丢失时以 `workspace-missing` 拒单。
- **引用继承**：只带直接父任务的终稿归档入口和本轮明确输入（路径去重）；更早祖先的详情可通过父归档按需追溯。权限、声明产物和父链保持原契约。

---

### 3. `task_control`：控制、运行中调整与验收
对已提交的任务做等待、取消、运行中调整、语义验收或恢复对账。

#### 七个动作与各自的参数
`task_control` 按 `action` 区分动作，每个动作只接受自己的参数；带了其他动作的参数会整单拒绝（`effects=none`），去掉多余字段重发即可。值为 `null` 的字段视为没带——严格采样下模型带全部字段是正常的，不算混用。

| action | 必需参数 | 可选参数 | 不可同传的参数 |
|---|---|---|---|
| `wait` | `handles` | `mode`, `timeoutMs` | `handle`, `reason`, `message`, `receiptId`, `expectedRevision`, `waivedCheckIds` |
| `cancel` | `handles`, `reason` | 无 | `handle`, `mode`, `timeoutMs`, `message`, `receiptId`, `expectedRevision`, `waivedCheckIds` |
| `resolve-external` | `handles`, `reason` | 无 | `handle`, `mode`, `timeoutMs`, `message`, `receiptId`, `expectedRevision`, `waivedCheckIds` |
| `steer` | `handle`, `message` | 无 | `handles`, `mode`, `timeoutMs`, `reason`, `receiptId`, `expectedRevision`, `waivedCheckIds` |
| `accept` | `handle`, `receiptId`, `expectedRevision`, `reason` | `waivedCheckIds` | `handles`, `mode`, `timeoutMs`, `message` |
| `reject` | `handle`, `receiptId`, `expectedRevision`, `reason` | 无 | `handles`, `mode`, `timeoutMs`, `message`, `waivedCheckIds` |
| `reconcile` | `handles`, `reason` | 无 | `handle`, `mode`, `timeoutMs`, `message`, `receiptId`, `expectedRevision`, `waivedCheckIds` |

#### 参数说明
- `action` (string, 必填): `"wait"` | `"cancel"` | `"resolve-external"` | `"steer"` | `"accept"` | `"reject"` | `"reconcile"`。
- `handles` (string[], wait/cancel/resolve-external/reconcile 必填): 非空的任务句柄数组。
- `handle` (string, accept/reject/steer 必填): 单个任务句柄。
- `mode` (string, 仅 wait): `"any"`（首个终态即返回，缺省）或 `"all"`（全部终态才返回）。
- `timeoutMs` (number, 仅 wait): 等待上限毫秒数，缺省 120000（120s）。超时只返回当前进度，不会取消任务。
- `reason` (string, cancel/resolve-external/reconcile/accept/reject 必填): 决策或控制的理由，留作追溯。
- `message` (string, steer 必填): 运行中调整指令（见下文 steer）。
- `receiptId` (string, accept/reject 必填): 当前回执 ID，需与内核最新回执一致。
- `expectedRevision` (number, accept/reject 必填): 当前任务版本号（revision），用来防止基于过时状态做决策。
- `waivedCheckIds` (string[], 仅 accept): 显式豁免的机器检查项 ID，需是回执中 `missing` ∪ `checks` 的子集。接受 `error` 终态的任务时必须包含 `"error-execution-coverage"`（表示你接受的是“产物已在外部核实采用”这一事实），缺少时会被拒绝。

**wait 返回什么**：当前三轴状态、终态/未决进度；blocked 任务会附上待答问题正文或 NEEDS_HANDOFF 接手指引。终稿和自动采集的详情通过 `task_query` 的归档引用按需读取；重复 wait 不会重新采集或结算。

#### reconcile：收口跨会话遗留的任务
用于本会话**不持有运行实体**的契约任务——跨重启/跨会话残留、启动恢复清单中的 needs-reconciliation 项、`task_query` 的 nextActions 中含 reconcile 的项。cancel/steer/wait/task_resume 遇到这类历史记录时，会返回 `historical-task` 错误并附上 reconcile 修复示例，照着调用即可。

reconcile 用派发时持久化的启动锚点（子进程 rootPid/进程组/内核出生令牌 + 原 Leader pid）只读判断运行实体是否已退出，不发送任何信号：
- **已退出（stale）**：确认物理退出，按未完成关闭——queued 且无启动意图的关为未执行；blocked 只补记退出事实、保留可续接。不猜测成功、不改接受轴、不重放副作用；已写产物以磁盘为准，后续用 `task_resume` 续接。
- **仍存活（live）**：子进程出生令牌一致、进程组仍有成员（如孙进程）、原 Leader 仍存活或环境血统命中——拒绝并列出 pid。
- **证据不足（unknown）**：无锚点、契约记录的最新运行未锚定、未启用进程组、令牌无法比对、ps 不可用，或存在启动于运行之后、父链经收养者断开的同用户进程（疑似 setsid 逃逸的后代，无法归因就不能证明已退出）——拒绝并列出疑似 pid。环境标签缺席本身不算退出证据。此时请主上人工核对，在 TUI 中执行 `/amagi recovery confirm-exited <taskId>`（只覆盖确认时刻之前的运行），之后再 reconcile。
- **foreign-owner**：拒绝，需要主上执行 `/amagi recovery adopt`。
- **本会话持有运行实体**：拒绝，改用 wait/cancel。

关闭走不触发 settle 钩子的恢复路径，只同步本会话已有的投影。

#### steer：给运行中的任务调整方向
任务书（spec）派发后冻结不变；`steer` 是附加的沟通通道，不构成新契约，也不改变三轴状态。
1. **适用状态**：`queued`（在首个模型请求前送达，相当于开跑前修正方向）和 `running`（在下一次模型请求前注入）。子进程在每次模型请求前注入全部有效的调整，**持续可见直到任务结束**。与已完成工作冲突的部分按调整修正，不冲突的部分不重做。
2. **其他状态去哪**：`blocked`（子进程已退出）→ 用 `task_resume` 带上调整内容续接；`answering` → 等本轮终态后对新句柄 steer 或 `task_resume`；终态 → 新方向用 `task_submit` 派发；`rpc` 后端 → `rpc_task({ action: "adjust" })`。
3. **记录与上限**：调整写入 `<amagiData>/task-steer/<taskId>.jsonl`（只追加；子进程首次注入时回写 ack 行）。单条上限 8KB（与有效注入预算一致，避免写得进去却注入不了），空白消息会被拒绝；有效注入总预算 8KB（超出时淘汰最旧的）；通道总行数上限 256。
4. **steer 与 resume 怎么选**：steer 修正**运行中**任务的方向——轻量、即时、不改契约；resume 为 blocked/error 任务开**新一轮**——消息冻结为新 assignment，重新结算与验收。需求大改或范围变更时用 resume 或重新派发。

#### 验收：防过时决策与依赖解锁
1. **防过时**：`receiptId` 与当前回执不一致时报 `stale-receipt`；`expectedRevision` 与当前版本不一致时报 `stale-revision`。两种情况都只需用 `task_query` 取最新的 receiptId 和 revision 后重发（见第四节示例 2），不必盲目重试。
2. **依赖解锁**：`accept` 成功后，如果该任务属于一个暂停中的批次组（batch），内核会自动 `resumeGroup`，唤醒所有 `requires="accepted"` 的下游节点。

---

### 4. `task_query`：只读查询三轴与回执
只观察任务状态与回执详情，不触发任何状态迁移、结算或恢复，可以随时放心调用。

#### 参数
- `handle` (string, 可选): 任务句柄。指定时查单个任务；省略时按时间倒序列出契约任务。
- `view` (string, 可选): 查询档位，缺省 `"summary"`。
  - `"summary"`：三轴轻量标签（`execution`、`settlement`、`acceptance`、`stateSeq`、`revision`）。
  - `"receipt"`：当前回执详情，包括 `receiptId`、机器检查项 `checks`（ID、状态、退出码）、产物归档路径及 digest。accept 前用它取决策依据。
  - `"output"`：产物列表与引用元数据，以及实际存在的 `result.md` / `evidence.md` 归档路径；不展开正文，需要时再 `read`。
- `cursor` (string, 可选): 分页游标（取上一页返回的 `nextCursor`）。
- `limit` (number, 可选): 每页条数，1..500，缺省 20。

---

## 三、批次工具 task_batch（按需启用）

### 1. 启用方式
```json
amagi_resource({ resource: "tools", enableFacet: "batch" })
```
- 启用本身只在当前会话激活 `task_batch` 工具，不创建子进程，也不写任务状态。
- 只有 Leader 会话可以启用和调度；子进程环境（`AMAGI_SUBAGENT=1`）调用会被拒绝（SubAgent 不能再派发任务）。
- **节点授权与产物**：提交时先校验全部节点的角色、调用者和 JSON 后端授权交集，再冻结交付给子进程；沿用角色派发的通道申请，`allowedPaths` 进一步收窄写面，角色 deny 始终执行。共享输入或任务书落在禁入区、角色能力声明缺失时整单拒绝，零节点启动。产物未获写/报告覆盖时披露节点 `[产物写面提示]`，不因覆盖缺失拒单、不扩权；运行期仍由真实围栏检查。节点 `outputs` 同时冻结进 TaskSpec 和候选回执，执行完成仍须分别判断结算与显式接受。

### 2. 参数
- `contextMode` / `contextRefs` (可选): 批次的上下文交接缺省值，语义同单任务。所有节点在本次调用内共用同一个 Leader 快照，各自按角色授权过滤；等待依赖的节点也不会重新抓取之后的历史。
- `nodes` (array, 必填): 批次节点（1..32 个）。每个节点：
  - `id` (string, 必填): 批次内唯一的节点标识。
  - `agent` (string, 必填): 节点执行角色。
  - `task` (string, 与 `taskFile` 二选一): 节点任务书正文，随批次直接提交，不需要先 Write。
  - `taskFile` (string, 可选): 已有任务书文件，语义同 `task_submit`（相对调用者 cwd，与节点 cwd 无关）。全图结构、依赖、共享输入和全部任务书文件都校验/快照成功后才启动任何节点（包括等待依赖的节点）。
  - `contextMode` / `contextRefs` (可选): 覆盖批次的上下文设置。节点显式换了模式时不继承批次的 contextRefs，避免把 selected 的来源锚点带进 isolated/fork。
  - `model` (string, 可选): 节点模型覆盖。
  - `name` (string, 可选): 节点稳定别名。
  - `cwd` (string, 可选): 节点工作目录（相对调用者 cwd，缺省继承）。
  - `allowedPaths` (string[], 可选): 节点写入白名单。
  - `reportPath` (string, 可选): 节点报告落盘路径。
  - `outputs` (array, 可选): 节点预期产物，支持与单任务相同的字符串/对象简写。产物路径在批次内需全局唯一，冲突时整单拒绝。
  - `dependsOn` (array, 可选): 依赖边（每个节点 ≤32 条），可混用字符串与对象；`"impl"` 等价于 `{nodeId:"impl",requires:"accepted"}`。对象字段：
    - `nodeId` (string, 必填): 上游节点 `id`。
    - `requires` (string, 可选): 解锁条件：
      - `"accepted"`（缺省）：上游回执经 Leader `task_control accept` 后解锁。
      - `"ready"`：上游 `settlement="ready"` 即解锁，适合审查型节点。
      - `"settled"`：上游回执发布即解锁，适合诊断型节点。
    - 同一节点的所有依赖边，`requires` 需保持一致。
- `sharedInputs` (array, 可选): 批次共享输入，写法与 `inputs` 相同，对象含 `path`、`purpose`、`required`（缺省 `true`）。按调用者 cwd 解析，以绝对路径注入全部节点任务书，节点换 cwd 也不会读错。必读输入不存在时整单拒绝，零节点启动。

```javascript
task_batch({
  sharedInputs: ["docs/需求.md"],
  nodes: [
    {id:"impl",agent:"luban",task:"按现有模块实现需求并交付报告",outputs:["out/实现.md"]},
    {id:"review",agent:"diting",task:"审核实现与验证证据，报告问题及依据",dependsOn:["impl"]}
  ]
})
```
简写在宿主预处理和直接 execute 中走同一套展开逻辑；格式错误的非数组依赖不会被当作“无依赖”放行。`ready`/`settled` 需要用对象显式声明。

---

## 四、常用流程示例

### 1. 派发并验收
```
1. 提交任务
   task_submit({ agent: "luban", task: "实现用户密码哈希算法" })
   ↳ 返回: taskId="a1b2c3d4-...", revision=1, execution="done", settlement="ready"

2. 查询回执，获取决策依据
   task_query({ handle: "a1b2c3d4", view: "receipt" })
   ↳ 确认: receiptId="rcpt-99887766", revision=1, checks 全部 pass

3. 接受任务
   task_control({
     action: "accept",
     handle: "a1b2c3d4",
     receiptId: "rcpt-99887766",
     expectedRevision: 1,
     reason: "单元测试全部通过，哈希算法符合预期"
   })
   ↳ 返回: acceptance="accepted"
```

### 2. accept 遇到 stale 错误时
提交 accept 时任务恰好发生了变化（例如后台补跑或重新结算）：
```
1. accept 被拒:
   task_control({ action: "accept", handle: "a1b2c3d4", receiptId: "rcpt-old", expectedRevision: 1, reason: "ok" })
   ↳ 报错: code="stale-revision", message="expectedRevision 失效（当前 revision=2，收到 1）"

2. 查询最新回执:
   task_query({ handle: "a1b2c3d4", view: "receipt" })
   ↳ 当前 receiptId="rcpt-new", revision=2

3. 用新值重新 accept:
   task_control({
     action: "accept",
     handle: "a1b2c3d4",
     receiptId: "rcpt-new",
     expectedRevision: 2,
     reason: "已核对最新版本，验收通过"
   })
```

### 3. 答复 blocked 任务
子 Agent 遇到关键歧义，退出并提问：
```
1. 收到提问:
   [task_submit a1b2c3d4 blocked] STATUS: blocked + QUESTIONS: 需要使用 argon2 还是 bcrypt?

2. 对原句柄续接（保留上下文与权限）:
   task_resume({
     handle: "a1b2c3d4",
     message: "使用 argon2id，内存开销设为 64MB"
   })
   ↳ 返回新 taskId，继承原会话配置继续工作
```


## 执行中咨询：amagi_advisor

需要第二意见时（比如已定位问题、想确认哪个修法更稳），可以向另一个模型咨询，不必派一个完整任务。

**谁能用**：Leader 在受信 `amagi.json` 中启用即可。子任务需要同时满足：角色 `capabilities.advisor: consult`、tools 含 `amagi_advisor`、本次 `scope.advisor: "consult"`、受信配置的角色名单、JSON 后端支持；模型与预算冻结进原 TaskSpec。缺省不授予；resume 继承原授权，不会自动扩权。

```js
amagi_advisor({ question: "已定位此竞态，哪个修法能保住这些不变量？", contextMode: "selected" })
// 立即拿到 handle，原执行者先推进独立工作；完成后建议自动返回原会话。
amagi_advisor({ action: "query", handle: "advisor-..." })
amagi_advisor({ action: "wait", handle: "advisor-..." }) // 后续决策依赖答案时再等
amagi_advisor({ action: "cancel", handle: "advisor-..." })
```

- `contextMode` 支持 isolated/selected/fork；`contextRefs` 是已观察资料的来源锚点，不代替文件读取。
- 咨询不创建任务、不切换工作模型、不改变三轴状态，也不替代 diting 的独立审查。
- **后端**：pi 后端单轮、无工具，认证和模型目录沿用宿主。Codex 后端使用本机已有登录，默认创建专用咨询会话并自动续接；调用者、工作目录、冻结授权和账户目录各自隔离。指定已有桌面会话需要共享连接；不可用或忙碌时明确失败，不接管其他任务。Codex 子任务只支持无 deny 的 guarded 授权；有受控工具或禁入要求时用 pi 后端。
- **异步与计量**：默认异步需要 pi 1.3+；`delivery: "wait"` 为显式同步。失败的尝试计入会话次数预算，取消与超时会保留原任务。原执行者结束独立工作时，会在原生结算前接收在途建议并继续；父进程不会在冻结的咨询时限内误判终稿收口。用量独立于执行者计量，query/wait 不重复入账。配置字段见 config-reference 的 advisor 节。
