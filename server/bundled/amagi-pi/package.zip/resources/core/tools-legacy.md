# 天城遗留任务工具与编排模板规范（tools-legacy）

本文档说明 legacy `task` 与 `query_task` 工具的参数语义、互斥规则、路径边界和五种编排模板。

**什么时候需要读它**：新会话默认使用四个稳定工具（`task_submit` / `task_resume` / `task_control` / `task_query`，见 `tools-facets`），通常用不到本档。只有在续接旧会话（留档为 legacy 工具面）或设置了 `AMAGI_SURFACE_LEGACY=1` 时，模型面上才会出现 `task` 工具，这时按本档调用即可。编排模板部分也可作为协作拓扑的参考。

---

## 一、参数互斥组

`task` 的参数分成几组，同一次调用只用其中一组。不同组的字段同传会被整单拒绝（零任务启动）——遇到这类拒绝，去掉多余的那组字段重发即可。

1. **派发形态（四选一）**：
   - 单任务派发：`agent` + `task`
   - 批量并行派发：`context` + `tasks`
   - 续接已有会话：`session` + `task`
   - 编排模板：`fanout` / `pipeline` / `tournament` / `redteam` / `fork` 五选一，也不与 `tasks` 同传
2. **控制动作**：`cancel`（取消）或 `wait`（等待），单独调用，不与任何派发参数同传。
3. **白名单与黑名单**：`allowedPaths`（只允许写清单内）与 `protectedPaths`（不允许写清单内）语义相反，同传属于配置矛盾，会被拒绝；二者选一。
4. **仅限单任务派发的选项**：
   - `background`（后台异步执行）、`worktree`（独立工作树）只用于单任务派发。
   - `dryRun`（预检评估）与 `exportPrompt`（导出提示词）只用于单任务派发，且二者选一。
   - 反过来，`asyncGroup` 只在批次/编排模式下生效。

---

## 二、参数详解（28 个顶层参数）

### 1. 核心单任务参数
- `agent` (string): 目标角色名，取自角色名册（如 `luban`、`luoshen`、`fuxi`、`diting`）。单任务必填。
- `task` (string): 任务正文（assignment），写清目标、工作边界与验收标准。单任务和 `session` 续接时必填；批量模式改用 `tasks[].task`。
- `model` (string | string[]): 模型覆盖。
  - 可传单个模型名。
  - 可传降级链数组（如 `["prov-a/m1:max", "prov-b/m2:max"]`）：遇到瞬时故障时按顺序换下一个模型，链用完后回退到系统 tier 降级链。
- `cwd` (string): 任务工作目录，绝对路径或相对 Leader cwd。子进程作业、测试执行和证据采集（git diff/status）都以它为准。缺省继承 Leader cwd；`session` 模式下沿用原任务目录，不能覆盖。
- `description` (string): 任务短名（≤8 词），用于 TUI 面板、状态栏、看板和完成通知；不填时自动截取任务正文前缀。
- `background` (boolean): `true` 时后台异步执行，立即返回 `taskId` 句柄、不占用当前对话；任务完成、挂起（blocked）或出错时会自动发系统消息通知。

### 2. 批量模式参数（Batch）
- `context` (string): 批量派发的共享背景（trim 后非空），注入该批次所有子任务。
- `tasks` (array): 并行任务列表（1..32 个节点）。每个元素：
  - `name` (string, 可选): 节点稳定标识。字母开头、≤32 字符，批次内大小写不敏感唯一。
  - `agent` (string, 必填): 节点执行角色。
  - `task` (string, 必填): 该节点的任务正文。
  - `model` (string, 可选): 节点模型覆盖。
  - `cwd` (string, 可选): 节点工作目录，相对顶层 cwd 解析，缺省继承。
  - `allowedPaths` (string[], 可选): 节点级写入白名单。
  - `reportPath` (string, 可选): 节点报告落盘路径。
- `asyncGroup` (boolean): 批次执行方式。`context` + `tasks` 批量模式下缺省为 `true`（异步返回 handle，每个节点和整组完成时自动通知）；设为 `false` 则同步阻塞、汇总返回。五种编排模板中缺省为 `false`。

### 3. 会话续接参数（Resume）
- `session` (string): 续接目标句柄。支持 `taskId` 前缀、`sessionId` 前缀、稳定 `name` 或精确 `runId/name`。
  - 续接时派生新进程，接着原会话历史继续；legacy 面没有常驻进程、P2P 或运行中 steer。
  - 自动继承原任务的工作目录、模型配置及白名单快照，续接时不能覆盖这些配置；需要不同的目录或权限时，改为新派一个任务。

### 4. 控制与收口参数
- `cancel` (string): 取消任务或任务组。传 `taskId`、`sessionId`、稳定 `name` 或 group `runId`。
  - 排队中的任务直接出队，没有副作用；运行中的任务先收到 SIGTERM，2s 后升级为 SIGKILL；传 group `runId` 会级联取消整组。
- `resolve` (string): 外部处置标志，取值固定为 `"external"`，与 `cancel` 一起用：`task({ cancel: "<句柄>", resolve: "external" })`。
  - 把目标任务标记为已在外部解决（`resolved-external` 终态）。适合 blocked 任务的产物已在外部采用、不需要重跑或杀进程的场景；它表示“已处理”，不是“放弃”。
- `wait` (object): 等待一组任务或 group 到达本轮结算态（显式同步点）：
  - `ids` (string[], 可选): 要等待的任务句柄列表。
  - `group` (string, 可选): 要等待的 group `runId`（如 `batch-xxx` 或 `orch-xxx`）。
  - `mode` (string, 可选): `"any"`（首个到达终态即返回，缺省）或 `"all"`（全部到达终态才返回）。
  - `timeoutMs` (number, 可选): 等待上限毫秒数。缺省按角色类型自适应（fast 类 5min、work/expert 类 30min、未知 120s）。超时只报告未决状态和各节点进度，不会取消任务，可以放心再等。

### 5. 路径边界与文件安全
- `protectedPaths` (string[]): 写入黑名单。子进程内 `edit` / `write` 命中清单路径会被阻断。适合保护用户未提交的工作或公共核心配置。
- `allowedPaths` (string[]): 写入白名单。子进程只能写清单内的路径，其余写入会被阻断。
  - **三种写法**：
    1. **精确文件或目录**（默认）：如 `src/index.ts`、`docs/`。目录按前缀匹配其下所有文件。
    2. **Glob 通配**：含 `*` 或 `?`，如 `data/cfg/gds_*.tres`。
    3. **显式前缀**：以 `prefix:` 开头，如 `prefix:data/cfg/gds_`，匹配该前缀下的一组文件。
  - **派发预检**：相对任务 cwd 检查路径是否存在；路径还不存在但其父目录位于 cwd 子树内时照常放行（方便声明待新建的文件）。
  - **自动临时验证目录**：白名单任务自动获得系统临时目录下 `amagi-task/<runId>` 的写权限，子 Agent 的测试脚本、stub server 或中间验证数据可以写在这里，24 小时后自动回收。
  - **需要改范围外文件时**：白名单任务会自动注入说明——子 Agent 在最终报告中成段列出补丁建议，由 Leader 直接修改，子 Agent 不必停下来等待。
- `reportPath` (string): 报告落盘的具体文件路径。
  - 相对任务 cwd 解析为绝对路径后自动注入任务书。
  - 需要是具体文件路径：`<节点名>` 这类尖括号占位符、尾斜杠或已存在的目录会被拒绝。
  - 配置了 `allowedPaths` 时，`reportPath` 需落在白名单范围内（不会自动扩权）。
  - 接入交付物验收链：任务终态时若文件未落盘，会自动催交。
- `sharedTree` (boolean): 声明任务在共享工作树上作业，与其他并行进程（主上或其他 Agent）共存。
  - 开启后，归因报告会把外部并行写入折叠为“预期的外部写入”，避免大量误报。

### 6. 工作树与预检选项
- `worktree` (string): git worktree 标识名。
  - 自动执行 `git worktree add <root>/.amagi-worktrees/<name>`（分支 `amagi/<name>`），子 Agent 在隔离的工作树中作业。
  - 任务结束后回流 diff 汇总，并标注树内未提交的文件。
  - 仅单任务派发可用；`session` 续接和编排模板不支持。
- `dryRun` (boolean): `true` 时只解析不派发。
  - 校验派发参数、解析角色与模型，输出 `dispatchEvaluation`（建议用 main、worktree 还是 none，附理由与待核实项）。
  - 不 spawn、不占准入槽、不建 registry 记录。与 `exportPrompt` 二选一。
- `exportPrompt` (boolean | string): 导出自包含提示词文件。
  - 把任务书组装为自包含 prompt（含角色设定、工作目录、纪律规范与交接规格），供用户复制到外部无头工具手动执行。
  - 传 `true` 导出到 `<cwd>/.amagi-export/task-<agent>-<时间戳>.md`；传字符串则写到指定路径。
  - 不 spawn、不占槽、不记 registry。与 `dryRun` 二选一，仅用于单任务。
- `workspaceNeeds` (string): 依赖可见性声明，供 `dryRun` 评估：
  - `"main-tree"`：任务依赖主树中未提交的产物或无法复制的运行环境。
  - `"portable"`：依赖可移植，新工作树中能正常构建与运行。
  - `"unknown"`（缺省）：不确定。

### 7. 容灾重试与超时控制
- `autoRetry` (object): 瞬时故障自动重派（需显式开启，缺省关闭）。仅单任务后台模式与 batch 模式支持：
  - `retries` (number): 最大自动重试次数（0..10，缺省 2）。
  - `backoffMs` (number): 首次退避毫秒数（1..3600000，缺省 90000，即 90s）。指数退避，上限 30 分钟；退避期间释放并发槽位。
- `evidenceTimeouts` (object): 任务级证据采集命令超时（优先级：task > 环境变量 > 默认配置）：
  - `testMs` (number): 单次证据测试命令预算（1000..14400000 ms，上限 4 小时）。
  - `gitMs` (number): 证据链 git status/diff 探测预算（1000..120000 ms）。
  - `summaryGitMs` (number): 产物摘要块 git 预算（1000..120000 ms）。

---

## 三、五种编排模板

编排模板是常见协作拓扑的快捷写法：一次调用自动展开为多次派发，状态追踪与阻断处理和普通派发相同。

### 1. `fanout`：并行扇出
- **Schema**：`Array<{ agent: string, task: string, model?: string }>`
- **规则**：并发执行 2..4 个分支（不同角色或同角色均可），超出数量会被拒绝；全部完成后统一汇总。
- **适合**：同一方案请不同专家从多个角度调研，或同时修改多个互不依赖的模块。

### 2. `pipeline`：串行流水线
- **Schema**：`Array<{ agent: string, task: string, model?: string }>`
- **规则**：按数组顺序串行执行，前一节点的输出自动成为后一节点的输入上下文；任一节点 `blocked` 时整条流水线暂停。
- **适合**：设计 → 实现 → 测试验证这类前后依赖的链路。

### 3. `tournament`：锦标赛择优
- **Schema**：`{ agent: string, task: string, n?: number, judge?: string }`
- **规则**：
  - `n`：并行实例数（2..4，缺省 3）。
  - `agent`：实现角色。
  - `judge`：评审角色（缺省 `diting`）。
- **流程**：N 个实例并行实现，全部完成后交给评审角色对比各分支产物，输出胜出方案。

### 4. `redteam`：红队对抗审查
- **Schema**：`Array<{ agent: string, adversarial?: boolean, task?: string, model?: string }>`
- **规则**：恰好 1 个实现分支（`adversarial` 为 false 或省略），加 0..4 个对抗审查分支（`adversarial: true`）。
- **流程**：实现分支先产出，红队分支随后针对它寻找破绽、边界漏洞与安全盲点，最后汇总为对抗报告。

### 5. `fork`：分叉 A/B 试验
- **Schema**：`{ session: string, branches: Array<{ agent: string, task: string, model?: string, readOnly?: boolean }> }`
- **规则**：
  - `session`：分叉起点的 `taskId` 或 `sessionId`。
  - `branches`：分支清单（≤4 枝）。
  - `readOnly`：`true` 表示分支没有写副作用。相邻的 `readOnly` 分支会真正并发执行；未声明的分支按有写操作处理，串行执行以避免冲突。
- **流程**：从同一基线会话派生多个独立子会话，分别试验不同策略；分支之间互不影响，各自都能继续续接。
