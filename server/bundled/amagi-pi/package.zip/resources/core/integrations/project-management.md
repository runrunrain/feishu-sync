# 项目管理集成

projects-memory 工作区的路径体系、目录结构与维护约定。本文件就是路径体系的完整规范；知识模块的细节见 `resources/core/integrations/project-knowledge-system.md`。

这些都是 Agent 按约定读写文件的规范，插件代码不解析这些路径，也不对其中的文件做权限执法。路径推导清楚了，派发任务时就能把「范围」「必读」「输出」写成准确的绝对路径。

---

## 一、工作路径要求

路径体系从当前工作路径推导，不依赖额外的环境变量：从当前工作目录逐级向上查找，找到 `projects-memory/projects/registry.json` 时，它所在的目录就是 `WORKSPACE_ROOT`。

| 名称 | 必需 | 说明 |
|------|------|------|
| WORKSPACE_ROOT | 是 | 由当前工作路径向上定位得到的工作区根目录 |

---

## 二、路径体系

### 术语对照表

| 术语 | 含义 | 如何获取 |
|------|------|----------|
| **WORKSPACE_ROOT** | 工作区根目录 | 从当前工作路径向上查找 `projects-memory/projects/registry.json` |
| **PROJECTS_MEMORY_ROOT** | 项目记忆系统根目录 | `{WORKSPACE_ROOT}/projects-memory` |
| **PROJECTS_DIR** | 项目元数据目录 | `{PROJECTS_MEMORY_ROOT}/projects` |
| **PROJECT_META_ROOT** | 单项目元数据 | `{PROJECTS_DIR}/{activeProject}` |
| **PROJECT_CODE_PATH** | 项目真实代码 | 从 registry.json 读取 projectPath |
| **TODOS_DIR** | 待办事项目录 | `{PROJECTS_MEMORY_ROOT}/todos` |
| **LEGACY_PROJECTS_DIR** | 旧版项目元数据目录（已弃用） | `{WORKSPACE_ROOT}/projects` |

### 目录结构

```
{WORKSPACE_ROOT}/
├── projects-memory/              # 项目记忆系统根目录
│   ├── projects/                 # 项目元数据目录
│   │   ├── registry.json        # 全局注册表
│   │   └── {project-id}/
│   │       ├── context.json
│   │       ├── memory-map.json   # 精简版（7 sections，<200行）
│   │       ├── task-index.json   # 活跃任务索引（按需加载）
│   │       ├── task-archive.json # 已完成任务归档（仅显式请求时加载）
│   │       ├── tasks/            # 任务详情目录（按需选择性加载）
│   │       └── ...
│   └── todos/                    # 待办事项目录
│       └── 待办事项概览.md
└── {project-code}/               # 项目代码目录（与元数据同级）
```

### 操作分类指南

元数据和代码分在两处，最常见的错误是把报告写进代码目录、或在元数据目录里跑测试。按下表选路径即可：

| 操作类型 | 使用路径 | 模板 |
|---------|---------|------|
| 保存 Agent 报告 | PROJECT_META_ROOT | `{PROJECTS_DIR}/{activeProject}/agent-outputs/{角色 ID}/{timestamp}-{task-brief}/`（角色 ID：baize/luban/luoshen/diting/fuxi；细则见 agent-document-output 技能） |
| 运行测试 | PROJECT_CODE_PATH | `cd {PROJECT_CODE_PATH} && pytest` |
| 修改代码 | PROJECT_CODE_PATH | 编辑 `{PROJECT_CODE_PATH}/app/main.py` |
| 读取项目配置 | PROJECT_META_ROOT | 读取 `{PROJECTS_DIR}/{activeProject}/context.json` |
| 查看任务列表 | PROJECT_META_ROOT | 读取 `{PROJECTS_DIR}/{activeProject}/task-index.json`（按需） |
| 查看任务详情 | PROJECT_META_ROOT | 读取 `{PROJECTS_DIR}/{activeProject}/tasks/task-{id}.json`（按需） |
| 加载领域知识 | PROJECT_META_ROOT | 读取 `knowledge-base/domains/index.json` 后按需读取具体领域 |
| 查看历史任务 | PROJECT_META_ROOT | 读取 `{PROJECTS_DIR}/{activeProject}/task-archive.json` |

---

## 三、项目热插拔

项目切换与注册信息维护由 `switch-project` 技能承接。用户可以用下面的约定写法表达意图——这些不是框架内置命令，插件代码不解析它们，由模型按技能中的对应流程执行：

| 写法 | 说明 |
|------|------|
| `[@hotswap:switch:project-id]` | 切换项目（更新 registry 的 activeProject 并加载项目上下文） |
| `[@hotswap:list]` | 列出已注册项目 |
| `[@hotswap:active]` | 显示当前活跃项目信息 |
| `[@hotswap:sync:project-id]` | 让 memory-map.json 的项目根路径与 registry 对齐，并列出失效路径 |
| `[@hotswap:validate:project-id]` | 只读校验项目路径与入口文件 |

各写法的具体步骤、会改哪些文件以技能为准。

---

## 四、项目目录结构

```
{PROJECTS_DIR}/
├── registry.json              # 全局注册表
└── {project-id}/              # 项目独立目录
    ├── context.json           # 项目上下文入口
    ├── memory-map.json        # 记忆地图（精简版，7 sections，<200行）
    ├── task-index.json        # 活跃任务索引（按需加载）
    ├── task-archive.json      # 已完成任务归档（仅显式请求时加载）
    ├── tasks/                 # 任务详情目录（按 task-{YYYYMMDD}-{seq}.json 命名）
    ├── development-checklist.json  # 开发清单
    ├── knowledge-base/        # 项目知识库
    │   ├── index.json
    │   ├── glossary.json      # 项目术语中心（高优先级自动加载）
    │   ├── development-specs.json
    │   ├── conventions.json
    │   ├── architecture.json
    │   ├── api-reference.json
    │   └── domains/           # 领域知识
    │       ├── index.json     # 领域注册表
    │       └── {domain-id}/   # 各领域独立目录
    ├── tactical-book/         # 项目战术手册
    └── agent-outputs/         # Agent 工作报告（按角色 ID 分子目录）
```

### memory-map.json 结构（7个sections，精简版）

memory-map.json 只保留静态/半静态的项目信息，动态任务数据放在 task-index.json 和 tasks/ 目录。Section 编号沿用模板中的键名（如 `6_technicalPoints`），编号不连续是正常的，不需要补齐或重新编号。

| Section | 名称 | 内容 | 性质 |
|---------|------|------|------|
| 1 | basicInfo | 项目定位 | 静态 |
| 2 | paths | 核心路径 | 静态 |
| 3 | systemStatus | 系统状态（含 featureFlags） | 半静态 |
| 6 | technicalPoints | 技术要点 | 半静态 |
| 7 | insights | 洞察和风险 | 半静态 |
| 8 | quickStart | 快速启动（含 debugTools） | 静态 |
| 9 | collaboration | 协作规范 | 静态 |

### task-index.json 与 tasks/ 目录

| 文件/目录 | 说明 | 加载时机 |
|----------|------|---------|
| `task-index.json` | 活跃任务的轻量级索引（仅 in-progress/blocked/planned） | 按需加载（需要查看活跃任务时） |
| `task-archive.json` | 已完成/已取消任务的归档索引 | 仅显式请求时加载 |
| `tasks/task-{YYYYMMDD}-{seq}.json` | 单个任务的完整详情 | 按索引选择性加载（需要特定任务详情时） |

---

## 五、知识体系引用

详细规范见 `resources/core/integrations/project-knowledge-system.md`。

| 知识类型 | 说明 |
|---------|------|
| knowledge-base | 开发规范和项目约定 |
| domains | 项目特定领域的深度知识（按模块/子系统隔离） |
| tactical-book | 精妙技巧和方法 |
| error-book | 问题记录和解决方案 |

---

## 六、文件维护约定

下表是协作约定（插件不做执法），目的是让共享的规范文件有一个明确的维护者，避免多人同时改出冲突：

| 目录/文件 | 读取 | 维护 |
|----------|------|------|
| core/ | 所有 Agent | 知识沉淀流程（伏羲反思态，旧称 Thinker） |
| projects/ | 所有 Agent | 所有 Agent |
| registry/config | 所有 Agent | 知识沉淀流程（伏羲反思态，旧称 Thinker） |
| 项目代码 | 所有 Agent | 承接执行任务的角色（如 luban、luoshen） |

---

## 七、路径出问题时怎么办

| 场景 | 常见表现 | 建议做法 |
|------|---------|---------|
| 无法定位工作区 | 从当前工作路径向上未找到 projects-memory/projects/registry.json | 确认当前目录是否在工作区内；不在 projects-memory 工作区时，按普通仓库工作，不引入这些路径概念 |
| 路径不存在 | 工作区或 projectPath 指向的目录不存在 | 报告具体缺失的路径，请用户确认或更新 registry |
| registry 不存在或无效 | 项目注册表缺失或 JSON 无法解析 | 报告缺失/错误位置；不要凭猜测重建，猜出来的路径可能指向别的项目 |
| 项目不存在 | activeProject 或指定 project-id 未注册 | 列出 registry 中已注册的项目供用户选择 |

能继续的部分照常推进，并在报告里写明哪些上下文没能加载、对结果可能有什么影响——如实说明缺口，比带着猜测的路径继续更有价值。
