# 任务书写法（单节点委派）

> Source Status: canonical
> Scope: 单节点任务书：何时单节点、任务书模板、四类型变体、路径展开、观测与续接。多节点编排见 `agent-teams-mode.md`；路由、Task Contract 分档与审核规则见 `workflow-rules.md`。

一份好的任务书，能让子 Agent 一上手就知道做什么、做到什么程度算完成、结果放在哪里。下面的模板和做法都是为了让这件事更省力。

## 何时单节点

一个专业角色能独立完成、只需把结果交回 Leader 的任务，用单节点就够了。只读探索不需要 worktree。

这些情况改用逻辑 Agent Team（见 `agent-teams-mode.md`「何时多节点」）：多个角色之间有明确的依赖 DAG、需要并行产出独立产物，或需要跨阶段的 artifact Gate。单节点任务没有持续讨论或成员间消息这类能力。

## 任务书模板

```markdown
[TASK_TIER: simple|medium|complex]（可选，缺省 medium）
task_id: {task_id}
主特色: {承接角色的能力成分；附带成分标「轻」（只做与本任务直接相关的部分）并写边界}
任务态/审核档: {仅 fuxi/diting 非缺省时写 attack/reflect 或 quick；不授予额外权限}
目标: {要达成的、可观察的结果}
背景: {为什么做；已知事实与已排除的方向}
范围: {允许修改的文件或模块；明确不许碰的部分}
必读: {required_artifacts 完整路径；无则写无}
输出: {output_artifact 完整路径（派发前展开为具体文件名，如 reports/c2a-report.md），或"对话摘要"（simple 档）}
验收: {逐条可验证的完成条件}
验证: {层级 L1/L2/L3 + 重点风险 + 验收命令（如有）；未注明时功能变更默认 L1+L2、simple 默认 L1}
起手式: {建议的第一步（可选）}
```

**提交方式**：新任务书直接放进 `task_submit({agent, task, ...})` 的 `task` 正文，不论长短一次提交即可。harness 会先把它冻结并持久化到任务契约，再启动子 Agent，所以不需要先 Write 成文件。批次同理，把各节点的任务书直接放进 `nodes[].task`。

复用已有任务书时用 `taskFile`。工具会先等待同文件已登记的 Write/Edit 完成再读取，超时或写入失败会拒绝派发；尚未登记的未来写入、外部进程和 bash/MCP 写入不在等待范围（详见 `tools-facets.md`）。

**不用写进任务书的内容**：执行纪律、结果协议和产物落位，harness 会自动追加到任务末尾；不派发、不递归这类约束已在子 Agent 公共基座里。`inputPaths`/`outputPaths` 分别声明「必读」「输出」，工具会把路径和用途注入正文，正文里不必重复。

**选择上下文模式（`contextMode`）**：

- `selected`：普通承接任务的推荐选择，传递用户要求、相关观察、待核验判断和按需原文引用。同一次调用里可以用 `contextRefs` 指向已读过的来源，不必手写摘要或额外 Write；关键约束仍写进 task。
- `fork`：复杂攻坚，带上当前可见的文本历史。
- `isolated`：独立审核或全新探索。省略 `contextMode` 时就是 isolated。

交接时会去掉常规调试行、重复观察和无关计划，保留来源与读取范围；原文可以从交接标明的证据目录恢复。交接里 assistant 自称“已确认”的内容，对接收方仍是待核验的判断。上下文模式不改变子角色权限；来源或执行基线变了时，只需复核受影响的部分。同一任务要继续时，优先用 task_resume。

## 四类型变体

| 类型 | 对应角色 | prompt 附加要求 |
|---|---|---|
| work | luban / luoshen | 指令完整、验收条目可细、文件边界明确；返回须含"验证/自检结果 + 建议下一步" |
| expert | diting / fuxi | 精确问题、充分上下文、锁定范围：不重新规划、不扩大战场；产出证据充分的结论，决策权留 Leader；fuxi 任务态与 diting 审核档在任务书首部显式标注；对上游证据包，非决策关键的观察项直接采信，决策关键项、推断与未覆盖项回源核验一次，未经核验不作方案前提 |
| fast | baize | 写得最细最具体。交付客观资料包（看过什么、在哪看到、原文出处）与带证据锚点的事实结论；不做方案裁决、建议与下一步推荐，判断留给下游。拿不准的标【待核验】，不猜测 |

## 路径展开

路径占位符必须在派发前展开为具体值（如 `reports/c2a-report.md`）。这样做的原因：曾有子 Agent 把未展开的 `<节点名>` 占位符解析成截断前缀，落盘成单字符路径，又花了好几轮补救。

batch 派发可以直接用 `nodes[].reportPath`（相对节点 cwd 解析，不突破该节点 allowedPaths）注入规范报告路径，省去手工展开。

## 观测与续接

- **层级**：Leader 是深度 0，它分派的所有角色都是深度 1，没有更深的层级。深度 1 的角色不调用其他 Agent 或 task 系列工具（运行时也不给它们注册这些工具），所以不会递归派发。
- **每轮一个独立进程**：task_submit 每轮 spawn 一个独立进程，到 `done`、`blocked` 或 `error` 即退出。task_resume 由 Leader 沿旧 session 发起，会新 spawn 一轮进程——续接是新的一轮，不是把同一个成员留着复用。
- **观测是只读的**：task_query 用来看状态，不传递指令。后台任务在完成或 blocked 时会自动通知，所以不需要轮询进度；节点之间也没有经工具互发的消息。
- **运行中调整是单向的**：Leader 用 `task_control({ action: "steer", handle, message })` 注入，子 Agent 在下一次模型请求前看到，任务书边界不变。子 Agent 想主动沟通时走 blocked 提问，Leader 用 task_resume 作答续接。rpc 池任务的对应通道是 `rpc_task adjust`。

## 反重复与待反思

- 已经委派出去的探索、检索、分析，Leader 不必再做一遍，以 SubAgent 返回的 artifact 为准；有疑问时派 fast 型复核，或请原 Agent 补充。已审核过的 diff 部分也不必复读重审（审核一次原则，见 `workflow-rules.md`）。
- SubAgent 遇到踩坑、新模式或重复问题时，可以在返回中打【待反思】标记，写上触发角色、场景描述和必要上下文。这个标记只是候选证据，不会自动触发任何任务：沉淀由 fuxi 反思态承担，满足门槛（真实证据、可迁移、无等价条目）才立反思任务，是否派发由 Leader/主上决定。

## projects-memory 工作区

在 projects-memory 工作区（代码与产物分目录存放）中派发时，「范围」「必读」「输出」按 `paths`（integrations/project-management.md）的路径术语展开成具体绝对路径；不在这类工作区时不需要引入这些概念。
