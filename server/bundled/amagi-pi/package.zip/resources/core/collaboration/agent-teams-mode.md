# Agent Teams 模式

> Source Status: canonical
> Scope: 逻辑 Team：Leader 以 group / DAG 和 artifact Phase Gate 编排多个一次性任务轮次；不引入常驻成员或成员间通信。
> 指针：Task Contract / Artifact Contract / 审核链见 `workflow-rules.md`；任务书模板与四类型变体见 `subagent-mode.md`；职责与类型标注见 `resources/core/agent-responsibility-matrix.md`。本文件不复制其中表格。

这里的 Team 是 Leader 用 group / DAG 做的**逻辑编排**：每个节点是一轮独立的一次性任务，节点之间靠落盘的 artifact 衔接，而不是一个能持续对话的成员池。理解了这一点，下面的做法都顺理成章。

## 何时多节点

多节点值得用的条件：任务需要多个专业角色、能画出清楚的依赖 DAG，而且 artifact Gate 能降低协调风险——协作带来的价值要大于多花的令牌成本。单点实现、只读探索、串行依赖或同一文件的小改动，用单节点任务更省事（见 `subagent-mode.md`）。

| 场景 | 触发条件 | 执行方式 |
|---|---|---|
| 阶段级多维审核 | 已完成并集成一个高风险大阶段，且多个审核维度确实独立 | 同一个审核批次内分维度并行，Leader 汇总一次；不对叶子任务重复审 |
| 系统性证据分片 | 大范围调查可切成互不依赖的证据面 | 多个 baize 节点并行分片，汇总为一份带锚点的事实包 |
| 显式攻坚假设分片 | 已显式授权的攻坚存在多个独立假设 | 按假设划分 fuxi 攻坚态任务（每任务边界与 artifact 输入明确）；竞争假设本身不自动触发多个专家 |
| 跨层协调 | 多层能力成分都很重，且存在可明确的依赖 DAG | 按文件边界与 artifact 依赖定义节点 DAG，不以「前端/后端/测试」标签强拆 |
| 多角度研究 | 需要从多个角度调查 | 并行探索节点 → Leader 汇总 → 后续设计节点 |
| 有依赖的串行任务 | 后续任务需要前置任务的输出 | 单节点串行执行 |
| 同一文件多次修改 | 需要多次或并行修改同一文件 | 无 worktree 则串行执行避免冲突；需并行先显式创建 worktree 并传绝对路径，完成后合并 |
| 独立任务/模块并行 | 任务间无依赖、模块文件无交叉 | 单节点批量并行后汇总；如需隔离先显式创建 worktree 并传绝对路径 |

## 与 workflow 的关系

- Agent Teams 是 workflow 里多角色、多节点那几步的编排方式：workflow 管全局阶段、Gate 与审核位；Teams 用 group / DAG 描述本地任务节点和依赖。
- 成员之间没有持续讨论。需要“讨论”时，由 Leader 读取已落盘的 artifact、做出判断，再把必要上下文写进后续任务的 prompt；artifact 化解不了的决策交回主上。
- 两者共用同一条 Artifact Contract 与审核链。Teams 内部的 Phase Gate 是 workflow Gate 的细化，由 Leader 按 artifact 落盘情况核对。

## Leader 工作循环

1. 构建依赖 DAG，划分 Phase。创建前确认三件事：文件能独立分配、瓶颈能分散、每个任务都有验证标准。
2. 只分配当前 Phase，不提前 spawn 未来 Phase 的任务。
3. 等待 = 只读观测：batch / background 缺省异步自动通知，无需显式 `wait`——派发后继续推进其他工作，通知到达再处理，不要轮询或逐节点同步等待；`wait` 只用于确需在同一轮内同步汇总或阻塞等待的场景（如 Phase 收口前一次性取齐全部节点结果）。task_query 可以查状态，但它不是消息或控制通道。
4. Phase Gate 检查：按下方映射表核对必产 artifact 是否落盘，并核对跨边界链路清单（文件边界≠调用链边界，定义见 `workflow-rules.md`）——有跨界链路时须含真实用户入口（UI/CLI/API）端到端用例，只有内部直驱证据不得通过。全部就绪就开下一 Phase；有缺失就打回修复。
5. 节点 blocked / error 时，依据 artifact 与错误证据选择：task_resume 续接旧 session，或 task_submit 创建新任务。两种选择都会新 spawn 一轮。
6. 循环直到所有 Phase 完成。

整个过程尽量自主推进：成员能完成的事，不中断去请主上手动执行；确实超出全部工具能力时，标明阻塞原因，先做没有依赖的步骤，最后统一汇报。

## 行动前自检

相机行事的条件与升级触发器以 `workflow-rules.md`「执行路由」为准。Teams 场景每次行动前只需问一个问题：**这是规划/协调/决策，还是执行？**

- 规划（`read` / `find` / `grep` 了解情况、分析 artifact、制定计划）→ 直接做。
- 协调（维护 group / DAG、更新 Gate、为下一轮任务补充上下文）→ 直接做；成员是一次性轮次，没有可以发消息或催促的常驻对象。
- 决策（方案取舍、Gate 判定、验收）→ 直接做。
- 执行（写代码/改文件/跑测试/提交）→ 默认分派成员。信息完备、工作量小、风险低时可以直做，并一行披露 `Leader 直接处理：{原因}`；一旦出现范围扩张、未知信息或高风险路径，就停手转分派，而不是把任务拆小继续自己做。

为什么这样分：Leader“顺手”执行时，上下文很快被实现细节占满，后续的规划与验收质量就会下降。Leader 的上下文是整个团队的战略资源，值得留给只有它能做的判断。

## Phase Gate artifact 映射

Phase Gate 是 artifact 流转检查，不是固定的角色流水线。方向和审核 Gate 都是可选积木，触发条件成立才放进 workflow。fuxi 攻坚态/反思态不设强制 Gate，只在任务显式需要、边界与 artifact 输入明确时，作为普通 DAG 节点出现。

| Gate | 主责 | 必产 artifact | 适用条件 |
|---|---|---|---|
| G0 方向（可选） | fuxi（设计态） | `phase-direction.md` | 仅无可复用方向且存在重大跨模块取舍；按质量需要调用（不设次数预算），方向基线全任务共享 |
| G1 事实（可选） | baize | 探索或调研资料包 | 仅现有证据不足；系统性证据分片可多个 baize 节点并行 |
| G2 产物 | luban 或 luoshen | 当前大阶段合并后的 `implementation-report.md` | 阶段内多个完整执行切片共享 G0 方向，不逐模块重做设计 |
| G3 验证 | 产物节点承担（鲁班/洛神自验闭环） | `validation-report.md` | 与阶段风险相称；独立测试确有价值时是新的 luban 契约，不另设测试角色 |
| G4 审核（可选） | diting | `phase-review-report.md` | 当前大阶段已集成且验证完成，并且 review_mode=diting；按质量需要调用；quick/full 由任务书选 |
| G5 交付 | Leader；确需产物收尾则 luban | 最终报告或提交报告 | 按用户要求裁剪 |

- 已选中的 Gate 缺少 required artifact 时先补齐再推进；没选中的可选 Gate 不需要占位 artifact，也不用补派角色。
- G0 的方向 artifact 由整个父任务/大阶段复用，局部功能不必各自再开 fuxi 节点。
- G4 审的是阶段集成后的 diff，而不是每个 G2 节点各自的 diff。findings 合并修复后，只有 Critical/Major 高风险或范围实质变化才做一次增量复审。
- Gate 按任务裁剪。“artifact 存在才推进”只针对已选的 Gate，不需要为了凑齐骨架而新增 Agent。

## 团队任务书增量

团队节点任务书以 `subagent-mode.md` 的单节点模板为底，只增加以下字段：

```markdown
phase: P{n}-{phase_name}
文件边界: 负责 {files}；禁止修改 {其他成员负责的文件}
协作关系: {同 Phase 逻辑节点与其 artifact 依赖；无则写"无"}
输出: {output_artifact 完整路径（派发前展开为具体文件名，如 …/c2a-report.md；禁止未展开占位符）；报告必须落盘到此路径，任务终态返回注明路径}
通信: 标准 task 无 P2P；运行中调整只能由 Leader 经 task_control steer 注入（子 Agent 下一模型请求前可见）。跨节点信息仅能由 Leader 读取 artifact 后写入后续 task prompt
```

必填项：task_id / phase / 角色 / 任务 / 验收 / 输出路径；有上游依赖时，必读输入必填；多节点并行时，文件边界与协作关系必填——缺了文件边界，是节点互相覆盖文件最常见的原因。不阻塞、不等用户输入、不造假数据这类安全约束已由子 Agent 公共基座承载；尝试次数上限按需写进任务书正文（见文末「时间盲视对策」）。

## 交接规则与常见反模式

**轮次模型**：`Leader 创建节点 → 本轮独立进程执行 → done / blocked / error 后退出 → Leader 读取终态与 artifact → Gate 判定 → 新任务或 task_resume 下一轮`。

- 终态之后没有可以联系、释放或复用的成员，能读的只有它留下的 artifact。
- 前序 artifact 可读且验收通过，再创建下游节点（Gate 先行）。
- task_resume 只由 Leader 发起，会新 spawn 一轮；新一轮保留原轮次的 artifact 证据，不覆盖它。

**通信方向**：标准任务没有 P2P 或 broadcast。运行中调整是单向注入——Leader 用 task_control steer 送入，子 Agent 不经工具回消息；子 Agent 主动沟通只有 blocked 提问一条路，Leader 用 task_resume 作答续接。Leader 在收到终态结果后读取 artifact，再把必要上下文写进后续任务书。

成员 → Leader 的触发：

| 触发 | 内容要点 |
|---|---|
| 发现风险 | 写入中间 artifact，并在任务终态结果中返回风险 + 影响评估 + 建议方案 |
| 遇到阻塞 | 阻塞原因 + 已尝试方案 + 请求协助；尽早报告，不默默卡住 |
| 任务完成 | 交付摘要 + 验证结果 + 残留问题 + artifact 完整路径 |

Leader → 后续节点：通过新的 task_submit 或 task_resume 续接，传递方向修正、上下文补充、Phase 推进（附前序 artifact 完整路径）与质量反馈。单次方向修正用 `task_control steer`；确实需要抢占式 steer 或多轮交互时，显式选用独立的 `rpc_task` backend，在它的协议里处理 adjust/result。

常见反模式（遇到时按右侧做法纠正）：

- 任务遇到问题却没写进终态结果与 artifact → Leader 无法基于证据判断；问题与证据随终态一起交回。
- 节点假设能直接联系其他节点，或把 task_query 当消息/控制通道 → 跨节点信息一律经 Leader 读 artifact 中转。
- Leader 假设有常驻空闲成员、可释放/复用成员，或用运行中催促代替 artifact Gate → 按轮次模型重新建节点或续接。
- Leader 没读前序 artifact，只凭摘要启动下游 → 先读要据以决策的章节，再派发。
- 把 G0/G4 复制到每个小功能，形成 fuxi→diting→luban→diting 的叶子级循环 → 方向共享一次、审核放在阶段集成后。
- 阶段审核发现 Minor 后立即复审 → 纳入一次修复批次，由 Leader 验证并关闭。

## 文件分配与 worktree 决策

**文件分配**：每个节点独立负责自己的文件，彼此不重叠；共享配置/接口只读；边界写进任务书。并行度由写边界与数据依赖决定，而不是由角色数量决定——文件、状态、依赖真正独立时并行才有效；多个节点卡在同一瓶颈上，等于白花 N-1 份成本，这时改为切分输入空间或串行集中攻克。跨边界链路保留唯一的端到端责任人。所有显式 worktree/Git 动作由 Leader 或已授权的 luban 执行。

**worktree 决策**：

- 适合用：多个节点可能修改相同或相关文件；独立模块开发且改动范围明确；希望隔离并保护主工作区状态。注意未合并的 worktree 不等于可以直接丢弃，清理时遵守用户现场与授权。
- 可以跳过：只读探索；单节点没有并发冲突风险；需要实时看到其他节点的修改（worktree 之间互不可见）。pi SubAgent 是独立进程，但这不等于文件天然隔离，所以写操作要明确文件边界。
- 合并流程：worktree 节点完成 → 报告 worktree 路径和分支名 → 由 Leader/已授权 luban 合并（子 Agent 不自行 commit/merge）。

## 时间盲视对策

Agent 感知不到时间流逝，容易在没有进展的尝试上空耗。分派时顺手配上对策，对成员也是一种保护：

| 策略 | 说明 |
|---|---|
| 限定尝试次数 | 任务书写明“尝试 N 次无进展就报告并说明卡点”，如实报告本身就是有价值的产出 |
| 快速验证优先 | 先跑快速子集（如 10% 随机样本），通过后再全量 |
| 失败文档化 | 请成员记录已失败的方案与原因，后续成员可以直接避开 |
