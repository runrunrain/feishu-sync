# 不可妥协底线

> Source Status: canonical
> Scope: 所有 profile、task tier 和 runtime 均不可放松的约束；分档只放松流程开销，不放松本清单语义。

## 守卫最小安全网与执行纪律

执行前拦截只用于下列安全红线，此外不设流程型门禁——你的普通读写与命令不会被流程卡住：

| 守卫 | 拦截对象 |
|---|---|
| 危险/交互命令阻断（guards.ts） | 危险命令与无 TTY 必挂起的交互式命令 |
| 敏感文件提交守卫（guards.ts） | 敏感文件提交（.env / 密钥 / 凭据 / node_modules / 超大文件） |

JSON 校验是 `tool_result` 写后诊断：只检查不超过 5 MB 的 `.json`，非法时追加错误，但不阻止、不回滚已经发生的写入。高风险路径哨兵同样只提醒、不阻塞。

状态文件门禁与重编排拦截已退役：受控由编排审核链实现（见 `resources/core/collaboration/workflow-rules.md`）。“定位→读取→修改”和 Bash 失败诊断属于 L0、角色公共约束、task/resume prompt 与自检中的软纪律，不跟踪调用历史，不阻断普通 `edit`/`write`/`bash`。

守卫最小化条款——评审任何新拦截提案问两句：

1. 它拦的是不是明确不该发生的安全红线？
2. 能否用 prompt、自检或非阻断诊断解决？

任一答案不对，就改用 prompt、自检或非阻断诊断。计划、审核、文档状态或固定工作流都不做成新门禁。

## 语义底线（全 tier 生效）

- 禁假数据：不交付假数据、mock 数据、占位实现、Demo/MVP 骨架、TODO/FIXME/HACK 伪完成项（测试专用内容除外）。
- 自行验证：不要求主上手动验证；自行运行与改动/风险相称的验证，先验证再交付、验证失败不交付（如实报告失败与缺口）——L1 冒烟（构建通过/启动正常/关键路径验证）任何 tier 不可省，层级与限度见 workflow-rules.md"分场景证据要求"。
- 错误诊断基于代码与证据；怀疑环境因素时先用进程、端口、配置或日志证明，不无证据归咎于“缓存/未重启/浏览器状态”——那会把真正的缺陷掩盖掉。
- Web 测试不降级：需要交互或前端验证时，使用当前任务已获准且适用的工具完成真实浏览器交互，工具按任务选择；API 测试只能补充不能替代；视觉模型须读截图确认，只存不看视为未验证。
- SubAgent 隔离：SubAgent 不调用其他 Agent 或 task 系列工具，不形成直接、双向或同类型循环调用。amagi 子进程不注册 task 工具；没有内置隔离的 harness 靠这条 prompt 语义兜底，所以任何档位都保留它。

## Artifact 与提交底线

- AC-6 全 tier 生效：关键依据缺失时报告缺口，不猜测补齐（Artifact Contract 全文见 workflow-rules.md）。
- 提交侧不审核：git 提交不需要任何审核状态文件；敏感文件提交守卫（guards.ts）是唯一提交拦截。

## 改动协议

- 本清单由 fuxi 反思态维护，每次模型基线校准时评审。
- 改动需经 diting 审核（语义不放松）+ fuxi 反思态评估（沉淀经验）。
- 实现真相源：`extensions/amagi-core/guards.ts`；编排流程见 `resources/core/collaboration/workflow-rules.md`。
