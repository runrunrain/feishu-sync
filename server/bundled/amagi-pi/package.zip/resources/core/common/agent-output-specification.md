# Agent 输出规范

> Source Status: canonical
> Scope: artifact 规则、统一报告字段、验证证据记录格式

统一所有 Agent 的产物落盘规则、报告字段与验证证据记录；产物落位路径由任务书给出。同一套格式让下游不必猜你做了什么、证据在哪，也让你的工作能被准确复核。

---

## Artifact 规则

| 规则 | 要求 |
|------|------|
| 必产 artifact | 分析、设计、实现、测试、审核、调研、反思等会被下游消费的输出都落盘 |
| 主文档必写 | 每次持久化输出写入一份主报告文件（如 `implementation-report.md`、`review-report.md`），路径为具体文件名，不含未展开的占位符 |
| metadata 派发链托管 | 派发链的 `metadata.json` 由 harness 托管，不手写；手动产出与归档场景按 `agent-document-output` 技能执行 |
| 必传路径 | 返回 Leader 时附 artifact 完整路径 |
| 必引上游 | 输出 artifact 列出所有读取并作为依据的上游 artifact 路径 |
| 传路径不只转述 | Leader 分派下游时传递 required_artifacts，不只转述摘要——摘要会丢细节 |
| 缺失即报告 | 下游发现 required_artifacts 缺失时报告缺失清单，不凭记忆补齐 |

对话返回格式按各角色类型的返回格式段（随 spawn prompt 注入），本文件不重复。

---

## 统一报告字段

每份主报告按任务类型裁剪，在对应场景覆盖以下字段。

| 字段 | 必填场景 | 说明 |
|------|----------|------|
| task_id / phase | Task Contract 存在时 | 保持链路可追踪 |
| changed_files | 有文件变更时 | 列出绝对或仓库相对路径与变更类型 |
| upstream_artifact_references | 所有 artifact | 引用完整路径，不能只写摘要 |
| decisions | 设计、实现、优化、审核 | 记录关键选择、理由和替代方案 |
| validation_results | 所有交付 | 命令/检查、结果、失败处理、未覆盖范围 |
| rollback_notes | 有文件变更时 | 说明回滚粒度和可恢复路径 |
| remaining_risks | 所有交付 | 标注延期项、风险和原因 |
| suggested_next_step | 所有交付 | 写给 Leader 判断的后续动作 |

---

## 验证证据记录格式

验证结果要能被人复核：写清做了什么、看到了什么，比一句“已验证”有用得多。

| 类型 | 记录方式 |
|------|----------|
| 命令 | 写明命令、工作目录、退出状态、关键输出摘要 |
| 结构检查 | 写明检查脚本、匹配规则、命中数量 |
| 浏览器验证 | 写明页面、操作步骤、观察结果、截图路径（如有） |
| 只读调研 | 写明读取路径、行号或 URL、未覆盖范围 |
| 禁止变更检查 | 写明禁止文件匹配结果，如 hooks/schema/plugin/frontmatter 是否被触碰 |

---

## 计划类产物

requirement-analysis / execution-plan 与 plan-registry 的产出与注册按对应技能执行。

---

## 路径

产物路径以任务书给出的为准；projects-memory 工作区的路径术语见 `paths` 资源。
