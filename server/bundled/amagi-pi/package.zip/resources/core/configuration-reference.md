# amagi 配置字段参考

<!-- generated: schemas/amagi-config.json; node scripts/generate-harness-reference.mjs -->

字段与说明从配置 schema 生成。修改源 schema 后重新生成；CI 检查文档是否同步。

用 `/amagi config explain [角色]` 查看当前选模来源，`/amagi doctor` 检查文件字段、模型目录与认证配置。两者只读且不发模型或 MCP 请求。

`/amagi config init inherit` 创建 `{"profile":"inherit","agents":{}}`，适合继承当前 pi 模型；`init tiered` 创建分层预设。已有文件或符号链接均不覆盖。未创建项目预设时沿用既有默认 tiered。

pi settings/models/auth/MCP 的设置与登录仍由宿主管理。amagi.json 表达协作策略；起步预设不重置权限、身份或恢复数据。

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `$schema` | string | JSON Schema 引用（文档用途），首次运行自动写入 |
| `profile` | string | 选择 profiles/tiered.json 或 profiles/inherit.json，默认 tiered。项目级 > 全局级 > 默认。tiered 即角色分层策略（fast/work/expert 各 tier 绑定模型与 thinking level，见所选 profiles 文件） |
| `agents` | object | 角色级 model 覆盖与可选技能 allowlist，key 为角色文件名。项目级与全局级合并（项目键整项优先），最高优先级用户配置 |
| `agents.[名称].model` | string | provider/model[:thinking]，如 zhipuai/glm-5.2:max。thinking 合法值: off\|minimal\|low\|medium\|high\|xhigh\|max（B5 采样分层）：amagi 只选物理模型与 thinking level（分层策略由 profiles/<profile>.json 的 tier 档与本字段表达，fast 档宜低档位低温、expert 档宜高档位），采样参数（temperature/top_p 等）由宿主 models.json 的 samplingParams/samplingParamsByThinkingLevel 管辖（仅 openai-completions/openai-responses/azure-openai-responses 三类 API 生效），不得在本配置塞宿主采样字段 |
| `agents.[名称].skills` | array | 可选技能 allowlist（§9.5 G20）：配置后该角色子代理以 --no-skills + --skill 逐项注入，只收到清单内技能描述（宿主实证：CLI --skill 路径在 --no-skills 下仍加载，自动/设置发现全剥离）。未配置（缺省）= 不注入任何旗标 = 现状全量技能发现，行为零变化；空数组 = 该角色不接收任何技能描述。任务书仍可直接以 read 工具读任意 SKILL.md 文件——allowlist 只影响系统提示里的技能描述清单，不限制文件读取。项目级整项覆盖全局级（与 model 同合并规则） |
| `evidenceTimeouts` | object | 证据链超时预算（项目级声明，ev-20261011-ad4513）：优先级 task evidenceTimeouts > env AMAGI_EVIDENCE_{TEST,GIT,SUMMARY_GIT}_TIMEOUT_MS > 本段 > 默认（test 120000 / git 10000 / summaryGit 5000 ms）。全量测试超 120s 的仓库在此声明 testMs，免自动基线检查恒超时记 unavailable → settlement=incomplete 逐任务 waive。非法字段忽略回退（不阻断派发） |
| `evidenceTimeouts.testMs` | integer | 单次证据测试命令预算 ms（合法区间 1000–14400000，即 4h 上限；0 不代表无限） |
| `evidenceTimeouts.gitMs` | integer | 证据链 git 探测/diff/status 预算 ms（1000–120000） |
| `evidenceTimeouts.summaryGitMs` | integer | 产物摘要块 git（execFileSync）预算 ms（1000–120000） |
| `verification` | object | 验证链项目级声明（ev-20261020-c8ca99）：verification.testCommand 声明项目真实测试命令，声明优先于一切探测（探测是猜测，声明是权威）——C++/CMake/ctest 等 非 JS 栈项目在此声明，免自动基线恒「未探测到测试命令」→ settlement=incomplete 逐任务 waive。与 evidenceTimeouts 同层；全局级不参与（命令与项目布局绑定）。声明存在但形状非法时自动检查记 unavailable、不退回探测链（ev-20261021-54b4e3：退回的全量探测命令可能违背项目声明的 guarded 入口与资源约束；doctor 报字段问题）。声明入口为权威执行面，写面感知子集不替换声明 argv |
| `verification.testCommand` | object | 项目测试命令：argv 数组不经 shell（逐元素 spawn，无注入面；如 ["ctest","--test-dir","Cxx/build"]）；cwd 相对项目根（缺省根，须存在）。声明后自动基线检查（首派与 resume 同口径）执行此命令；首 token 在 shell.pathPrepend ∪ 系统 PATH 不可解析时准确记 unavailable 并提示修正 |
| `verification.testCommand.argv` | array | 完整命令 argv（不经 shell 拼接；首 token 须可解析） |
| `verification.testCommand.cwd` | string | 执行目录，相对 amagi.json 所在目录（非绝对、不含 ..；缺省 = 项目根） |
| `verification.testCommand.env` | object | 执行期环境（ev-20261021-54b4e3）：资源预算与 runner 并发等（如 NODE_OPTIONS=--max-old-space-size=1024）。自动检查 env 白名单不继承宿主 NODE_OPTIONS，资源约束只能经此到达实际执行；进检查策略 digest 并记入检查 notes。保留键（PATH/HOME、缓存重定向与 Go 离线变量、LD_*/DYLD_* 装载器变量）不可声明，声明即整段非法 |
| `verification.autoBaseline` | string | 自动基线入口策略（ev-20261021-54b4e3）：probe（缺省）=无 testCommand 声明时走探测链；declared-only=只执行项目声明入口，无声明即 unavailable（不探测、不退回全量测试命令——项目有 guarded 串行入口/资源约束而暂无可映射命令时使用） |
| `shell` | object | shell 执行环境项目级声明（ev-20261020-d56baa）：shell.pathPrepend 声明用户级工具链目录（如 pip --user 装的 cmake/ctest 所在 bin），amagi 控制的四个 spawn 点（bash 工具、run_bg、子 Agent 进程、自动基线测试命令）同源前置注入 PATH——免逐命令 export、免任务书抄写 PATH。非 amagi 控制的进程（手工终端等）不受影响；宿主 process.env 不改写。非法条目跳过并记 doctor 问题（不阻断） |
| `shell.pathPrepend` | array | PATH 前置目录（绝对路径且须存在；≤16 条；幂等去重）。按执行 cwd 读项目 amagi.json（每次 spawn 现读，改动即时生效） |
| `recovery` | object | 启动恢复对账自动收口（v2.x）：早前中断/取消/外部收口任务遗留的 launchIntent 未闭环残痕（无实际未交付产物）自动关闭对账环——只写任务目录注记与追溯日志，不改执行/结算/接受三轴、不猜成功、不自动启动进程，仅省去逐会话的上下文轰炸。仅适用于 launch-intent-unconfirmed 类：条件A 终态记账缺口（execution 已是 cancelled/resolved-external/done/error）恒收口；条件B 陈旧死进程（running 无退出事实且 launchIntent 时龄超 staleHours 且无声明产物或声明产物全部在盘）才收口；声明产物有 missing/unreadable 的保持人工。优先级 env AMAGI_RECOVERY_AUTORECONCILE / AMAGI_RECOVERY_STALE_HOURS > 本段（项目覆盖全局）> 默认（开、24h） |
| `recovery.autoReconcile` | boolean | 自动收口总开关（缺省 true）：关闭后 launch-intent 残痕全走人工（启动清单 + /amagi recovery adopt/show） |
| `recovery.staleHours` | number | 条件B 陈旧阈值小时数（默认 24，最小 1）：running 且无退出事实且 launchIntent 时龄超过该值且产物面干净（无声明或全部在盘）才自动收口；时龄不超阈值的 running 记录可能是真在途，保持人工 |
| `advisor` | object | 按需单轮咨询；原执行者保留工作模型。受信项目优先于全局；model:null 禁用。子任务的模型及预算随四方授权冻结。 |
| `advisor.model` | string,null | provider/model[:thinking]；不指定默认模型，使用 pi 原生认证。 |
| `advisor.leader` | boolean | 允许 Leader 咨询。 |
| `advisor.roles` | array | 可申请咨询的 canonical 子角色；仍需角色能力、tools 和 scope.advisor=consult。 |
| `advisor.maxCalls` | integer | 每个原生会话的尝试次数；失败计次，落盘恢复。 |
| `advisor.maxTokens` | integer | pi 为请求输出上限；Codex 为提示预算，超过已观察输出用量时中断，不能保证精确 token 硬上限。 |
| `advisor.timeoutMs` | integer | 每次咨询的总时限，含认证及模型等待。 |
| `advisor.backend` | string | pi 内模型或本机 Codex/Work 咨询；codex-chat 是兼容配置名，不是普通 ChatGPT Chat。 |
| `advisor.codex` | object | 默认 managed：使用 GPT-6-Astra/high 首次新建专用 Work 咨询会话，以调用者及冻结授权隔离并自动续接；existing 才使用桌面同一服务的共享连接及聊天 ID。 |
| `advisor.codex.socketPath` | string | auto 使用 Codex 官方代理的默认共享连接；或指定 codex app-server proxy --sock 可访问的本机绝对路径。 |
| `advisor.codex.threadId` | string | 用户授权接收咨询的指定桌面聊天 ID；沿用该聊天模型与上下文。 |
| `advisor.codex.mode` | string | managed 新建并自动续接自有咨询；existing 连接指定桌面聊天。 |
| `advisor.codex.model` | string | 仅 managed：可选 Codex 原生模型 ID；省略使用 gpt-6-astra。existing 不覆盖聊天模型。 |
| `advisor.codex.reasoningEffort` | string | 仅 managed：咨询思考档位，默认 high；新建、续接及每轮请求均显式传递。existing 不覆盖已有会话。 |
| `compaction` | object | Leader 与 JSON/RPC 子 Agent 的统一压缩模型；沿用 pi 原生手动、阈值与溢出压缩生命周期。项目配置优先于全局；每次压缩读取，子 Agent 沿用派发者配置目录。 |
| `compaction.model` | string,null | provider/model[:thinking]；供应商、认证和采样参数由 pi 原生模型运行时解析。未设置沿用 pi 当前模型；null 显式禁用继承的统一模型。配置、认证、摘要失败或窗口不足会取消本次压缩，不静默改用工作模型；插件不为适配窗口额外裁剪原生摘要输入。 |
| `fallbackModels` | array | 跨 provider 降档候选链（ev-20260905-fdbb89）：账号级限额错误（workspace/account 配额族 429，同 provider 必然复现）时按序取首个与失败模型不同 provider 且 registry 可用的候选全量降档；候选不可用回退同模型 tier 降档。env AMAGI_FALLBACK_MODELS（逗号分隔）优先于本字段；全局与项目合并（全局在前、项目追加去重） |
| `mcp` | object | MCP 路由与超时配置：子 Agent 按角色、Leader 主进程按名单加载哪些 MCP server（server 名来自 .mcp.json，此处只引用，代码不写死）；调用超时按工具分类可配。leader = Leader 主进程加载名单（缺省不限制 = 全部；扩展装配时读一次，改动需重启 pi）；default = 所有子 Agent 默认基线（缺省不限制 = 全部；每次派发现读盘即时生效）；agents.<角色名> = 额外追加（与 default 取并集）；星号(*) = 全部；显式空数组 = 不加载任何 |
| `mcp.default` | array | 所有子 Agent 默认加载的 server 名；星号(*) = 全部 |
| `mcp.agents` | object |  |
| `mcp.leader` | array | Leader 主进程加载的 server 名（缺省不限制 = 全部；扩展装配时读一次，改动需重启 pi 生效）；星号(*) = 全部；显式空数组 = 不加载任何 |
| `mcp.callTimeoutMs` | integer | 常规 MCP 工具单次调用超时（ms，默认 60000）；项目 amagi.json 优先于全局，改动即时生效（每次调用读盘） |
| `mcp.visionCallTimeoutMs` | integer | 视觉类 MCP 工具（analyze_image/ui_diff_check 等）单次调用超时（ms，默认 90000；服务端实测 ~36s） |
| `concurrency` | object | 任务准入并发分池限流（admission.ts）：任务按最终模型 spec 分池——models 精确命中（去 thinking 档后缀）→ 独立模型池；否则按 provider 分池；各池独立 FIFO，互不阻塞。全局与项目合并，项目键优先（providers/models 逐键合并）；每次派发读盘即时生效。非法值仅诊断忽略 |
| `concurrency.default` | integer | 未显式配置容量的池的缺省并发（默认 4；环境变量 AMAGI_ADMISSION_MAX 优先于本值） |
| `concurrency.providers` | object | 按 provider 分池容量（键 = model spec 的 / 前缀，如 zhipuai） |
| `concurrency.models` | object | 按 provider/model 精确分池容量（键如 "zhipuai/glm-5.2"，必须含 /；优先于 providers） |
| `ui` | object | v1.5.218 TUI 交互配置：键位覆盖 / 面板行预算 / 能力横幅开关。 |
| `ui.keys` | object | 快捷键覆盖（pi KeyId 数组；首元素为主键，其余为兼容键；默认 ⌥W/⌥T/⌥R + ctrl+shift+*） |
| `ui.keys.board` | array | 看板键位；默认 ["alt+w","ctrl+shift+w"] |
| `ui.keys.tasks` | array | 任务列表键位；默认 ["alt+t","ctrl+shift+b"] |
| `ui.keys.review` | array | 审 diff 键位；默认 ["alt+r","ctrl+shift+r"] |
| `ui.panel` | object |  |
| `ui.panel.maxLines` | number | 常驻分块面板行预算（默认 12） |
| `ui.shortcutHint` | boolean | 版本升级后首启能力横幅（默认 true） |
| `lsp` | object | LSP 语言服务器支持：内置目录（lsp-defaults.json）按项目 rootMarkers + 二进制可解析性动态检测；此处可覆盖/禁用/新增服务器。全局与项目合并，项目键优先，servers 逐 key 浅合并。 |
| `lsp.enabled` | boolean | 总开关（默认 true）；false 时检测返回空，lsp 工具报告 0 可用服务器 |
| `lsp.autoDetect` | boolean | 按项目语言自动检测内置服务器（默认 true） |
| `lsp.readOnly` | boolean | true 时拒绝 rename 等写盘操作（默认 false） |
| `lsp.idleTimeoutMs` | number | 语言服务器空闲回收阈值（默认 300000） |
| `lsp.servers` | object | 逐服务器覆盖：key 为内置名（如 typescript-language-server）或自定义名；同 key 与内置条目浅合并（覆盖字段优先） |
| `lsp.servers.[名称].command` | string | 二进制名（PATH/项目本地 bin 查找）或含路径可执行文件 |
| `lsp.servers.[名称].args` | array | 命令行参数（如 [--stdio]） |
| `lsp.servers.[名称].fileTypes` | array | 关联文件类型（.ts 点前缀形式） |
| `lsp.servers.[名称].rootMarkers` | array | 项目根标记（cwd 直接条目交集；支持 * 单层通配） |
| `lsp.servers.[名称].languageId` | string | LSP languageId（缺省 plaintext） |
| `lsp.servers.[名称].languageIds` | object | 按扩展名的 languageId 映射（键=点前缀扩展名如 .tsx，值=languageId；同一服务器多文件类型不同 languageId 时必须用它，如 .tsx→typescriptreact）。解析链 languageIds[ext] → languageId → plaintext |
| `lsp.servers.[名称].initializationOptions` | object | initialize 请求的 initializationOptions |
| `lsp.servers.[名称].disabled` | boolean | true 时从检测中剔除（含内置同名条目） |
| `decision` | object | 已移除（Jev 决策旁路 2.21.x 起整体删除）；旧配置残留的该节被忽略，仅为兼容保留，可安全删除 |
| `cacheWarming` | object | B8 宿主缓存保温策略（cache-warming.ts，设计 §5.5，十月迭代 M3）：订阅 pi 1.0.2 cache_warming_decision 事件，idle 相位的 amagi 窗口化保温管理。默认 delegate（不干预，复用宿主默认 streaming 保温与经济裁决）；显式 managed 后：在窗 lease（task_control wait 未决期/handle 后台运行期/finalizer 验证期）内按 lease 置信概率重算期望节省达标时返回 warm（覆盖宿主 idle 相位 P=0.15 的悲观估计），无在窗 lease/预算到期/会话切换返回 stop（限制无效保温+待机预算兑底）。经济字段不可计算时恒 delegate（不猜测内部字段）。前提：宿主全局 settings 需 cacheWarming=idle（idle 相位事件才会到达；用户 off 时宿主不启动 warming，事件不会到达，amagi 不绕过）。全局与项目合并，项目键优先 |
| `cacheWarming.idleStrategy` | string | idle 相位策略：delegate=不干预（默认，宿主决策原样生效）；managed=窗口化管理（在窗 warm/窗外 stop） |
| `cacheWarming.idleBudgetMs` | integer | 单次 idle 等待预算毫秒（默认 600000=10 分钟，设计提议的试点策略值）：lease 在窗超过预算后返回 stop 并记录一次性提示诊断；每次显式 wait/验证起点重置预算 |
| `cacheWarming.minExpectedSavingsUsd` | number | warm 注入的期望节省阈值美元（默认 0.05，对齐宿主 CACHE_WARMING_MINIMUM_EXPECTED_SAVINGS 口径）：P_eff=max(事件 continuationProbability, leaseContinuationProbability) 的期望节省 ≥ 阈值才 warm，否则 delegate |
| `cacheWarming.leaseContinuationProbability` | number | lease 在窗时 amagi 采信的续跑概率（默认 0.9）：子任务完成/验证结束将触发续跑，但可能超出 TTL/预算，故不取 1.0 |
| `codemode` | object | codemode 是已有工具组合方式，无独立角色/scope 授权；模型自行决定是否及如何使用。preference 是选择偏好，budget 提供可由脚本自行覆盖的默认输出与时限。旧 mode/roles/rpc/聚合预算只为历史配置兼容保留，不再参与准入。 |
| `codemode.mode` | string | 旧版独立授权字段，兼容保留，不再控制 codemode 准入。 |
| `codemode.roles` | object | 旧版独立授权字段，兼容保留，不再控制 codemode 准入。 |
| `codemode.rpc` | string | 旧版独立授权字段，兼容保留，不再控制 codemode 准入。 |
| `codemode.budget` | object | 脚本可覆盖的输出/时限默认值；旧次数和聚合预算不再参与准入。 |
| `codemode.budget.maxScriptsPerSession` | integer | 旧版聚合预算，兼容保留，不再限制模型使用。 |
| `codemode.budget.maxOutputTokensPerScript` | integer | 脚本未声明时采用的运行默认值，不是授权上限，模型可用 @options 覆盖。 |
| `codemode.budget.maxTimeoutMsPerScript` | integer | 脚本未声明时采用的运行默认值，不是授权上限，模型可用 @options 覆盖。 |
| `codemode.budget.maxTotalOutputTokens` | integer | 旧版聚合预算，兼容保留，不再限制模型使用。 |
| `codemode.budget.maxTotalTimeoutMs` | integer | 旧版聚合预算，兼容保留，不再限制模型使用。 |
| `codemode.preference` | string | auto=模型自行选择；prefer=适用时优先考虑，模型仍自行决策。 |
| `guards` | object | 护栏规则投影与判定消费（B4A/B4B/B4C，ev-20261012-af58eb 设计 §8 批A+批B+批C；guard-policy.ts）：批B 起 D5—D10、批C 起 D1—D3/D11 rule 值驱动判定（检测照常，阻断按值转披露；受信配置可收紧回 block；D1/D2 disclose 需有有限执行兑底，无界调用保持 block）；D4 powershell.executionPolicy（平台未验证）与 command.remoteExecution 维持 block 现状（表外/未批）。/amagi config explain 逐条展示有效值与来源（含 env 归一与项目/角色覆盖投影）。值域只有 block/disclose（没有 off）；L-不可逆防线（凭据/AMAGI_PROTECTED_PATHS/跨根/契约存储、敏感文件提交拦截、.git/ 禁入、deny 运行期硬拒、hard 危险段扫描）不在规则命名空间内，不受本节影响；配置解释不是授权证明。全局与项目逐字段覆盖（项目仅受信时消费）；非法/未知键只产生诊断（该规则维持内建默认，不回落 allow） |
| `guards.rules` | object | 规则名→执法模式（键封闭：command.interactive/command.wait/command.opaque/command.remoteExecution/powershell.executionPolicy/commit.largeFile/commit.generatedPaths/edit.headingDeletion/edit.regexSpan/task.assignmentDenyMention/bash.rgReplace/bash.wholeScan；D5—D10（commit.largeFile/commit.generatedPaths/edit.headingDeletion/edit.regexSpan/task.assignmentDenyMention/bash.rgReplace）批B 起默认 disclose，D1—D3/D11（command.interactive/command.wait/command.opaque/bash.wholeScan）批C 起默认 disclose（前提=有界执行/零执行实测），其余默认 block=现状执法） |
| `guards.rules.command.interactive` | string | 交互命令族（D1；编辑器/分页器/TUI/REPL 裸启动/ssh 无 BatchMode/PS 交互旗标）。批C 起默认 disclose：放行+披露（实际时限/非交互替代）；前提=有有限兑底（显式 timeout 或子代理默认超时），无界调用保持 block；powershell 工具通道（仅 Windows，平台未验证）保持 block |
| `guards.rules.command.wait` | string | 长等待形态（D2；sleep≥1000/无限循环/read -p/stdin 等待）。批C 起默认 disclose：放行+披露（拆批/run_bg/有界退出建议）；前提=有有限兑底，无界调用保持 block |
| `guards.rules.command.opaque` | string | 无法安全展开/解析深度（D3）。批C 起默认 disclose：放行+披露；已识别不可逆段（remoteExecution/终止进程/递归删除根/eval 远程载荷）不因解析失败放行。未闭合替换恒 block：真实 bash 报语法错误零成功执行，放行收益≈0，而该子翻转连续四轮被构造出 Critical 凭据底线绕过（B4C 修复轮四 Leader 裁定收回） |
| `guards.rules.command.remoteExecution` | string | 远程下载即执行（curl\|sh、eval 下载载荷、PS iex 远程内容；设计 §4 表外单列）。默认 block；disclose 为操作者受信出口（说明未检查下载体、网络执行不可回滚），不提供给模型自授权 |
| `guards.rules.powershell.executionPolicy` | string | set-executionpolicy（D4；可持久影响主机安全配置，单独批准）。默认 block；B4·批C：本机无 PowerShell 平台，行为未实测，不翻转（平台验证后另行裁定） |
| `guards.rules.commit.largeFile` | string | >10MB 文件提交（D5；凭据检查照常执行、不自动回退 index）。批B 起默认 disclose：放行提交+成功结果首部披露（列路径与字节数）；block=现状拦截 |
| `guards.rules.commit.generatedPaths` | string | node_modules/ 提交（D6；仅 node_modules/ 路径——.git/ 属不可逆底线恒拒、敏感内容不受本开关控制）。批B 起默认 disclose：放行+披露（列路径）；block=现状拦截 |
| `guards.rules.edit.headingDeletion` | string | markdown 标题吞噬（D7；最小化删除逃生门内建）。批B 起默认 disclose：放行+结果披露（含行范围；diff 提供反向恢复路径）；block=现状硬阻断 |
| `guards.rules.edit.regexSpan` | string | regex 替换字节阈值（D8；阈值经 guards.limits.regexReplaceBytes 配置缺省 102400；恰一命中与权限校验契约不变）。批B 起默认 disclose：超阈值放行+披露（字节数/行范围）；block=现状硬阻断 |
| `guards.rules.task.assignmentDenyMention` | string | 任务书正文 deny 路径词法扫描（D9；「禁止访问」类表述不再误读为必读。结构化 inputs/outputs 落 deny 仍整任务拒单、运行期 deny 不放松）。批B 起默认 disclose：放行提交+补 inputs 声明提示；block=现状拒单 |
| `guards.rules.bash.rgReplace` | string | rg 无参旗标粘连簇（D10；-rn/-rln）自动去掉 -r 后执行（rg 默认递归），结果首行说明；block/disclose 均先自动修正。合法粘连替换文本 -rfoo 及显式 -r <替换串>/--replace 不改；有意替换为 n/ln 等同形文本时用 -r n/--replace=ln。无法安全改写的命中形态（heredoc 等）由本规则兜底：默认 disclose 前置警示，block 执行前拒绝。旧 env AMAGI_RG_REPLACE_BLOCK 归一映射本规则且优先于配置（冲突在 config explain 披露） |
| `guards.rules.bash.wholeScan` | string | 子代理无超时兑底的全盘 find（D11；Leader 侧为软提示；有限 timeout 兑底照常优先）。批C 起默认 disclose：放行+披露（实际时限/限定目录建议；前提=子代理默认超时实测生效）；旧 env AMAGI_SUBAGENT_FIND_BLOCK 归一映射本规则且优先于配置（冲突在 config explain 披露），肯定值收紧回执行前拒绝 |
| `guards.roles` | object | 受信操作者 per-role 覆盖（canonical 角色名 baize/luban/luoshen/diting/fuxi，旧 stem 名归一；不是另一套 capabilities）；角色优先于 rules 基线，env 归一仍优先于角色 |
| `guards.roles.[名称].rules` | object | 该角色的规则覆盖（键/值域同 guards.rules） |
| `guards.limits` | object | 阈值参数（不改变 regex 匹配次数契约；批A 仅投影，生效属批B） |
| `guards.limits.regexReplaceBytes` | integer | regex 单次替换字节阈值（safe integer 1024—10485760；当前为 edit-override 常量 100×1024，批A 配置仅投影） |
| `inProcessAdvisory` | object | C15 进程内模型辅助解释通道（in-process-advisory.ts，设计 §6.5，十月迭代 M4，默认关闭）：finalizer 收尾链内经宿主 ctx.modelRegistry.streamSimple 的无工具 advisory 解释（结构化检查 id/status/exitCode 摘要 → 固定提示解释文本，永不参与 settlement/acceptance 判定）。配置节与 loader 同源（loadInProcessAdvisoryConfig）：全局 ~/.pi/agent/amagi.json（或 PI_CODING_AGENT_DIR）打底、项目 cwd/amagi.json 覆盖；环境变量 AMAGI_INPROCESS_ADVISORY_ENABLED=1/0 逃生舱翻转 enabled |
| `inProcessAdvisory.enabled` | boolean | 总开关（默认 false；关闭时零调用零构造开销） |
| `inProcessAdvisory.model` | string | 显式物理模型名 provider/model（默认空 = 未配置不调用——不猜默认模型；loader 仅接受非空字符串） |
| `inProcessAdvisory.timeoutMs` | integer | 单次调用超时毫秒（默认 15000；loader 边界 500..120000，超出范围的值被忽略回退默认） |
| `inProcessAdvisory.maxOutputTokens` | integer | 单次调用输出 token 上限（默认 512；loader 边界 16..8192，超出范围的值被忽略回退默认） |
| `emojiGuard` | object | emoji 硬拦截护栏（v2.7.0，emoji-guard.ts）：默认关闭；开启后 write/edit 写入内容与 assistant 会话文本中的 emoji 被剥离（strip）或拦截（block）。全局与项目合并：标量项目优先；allow 项目级声明即完整替换（显式空数组 = 连技术符号也全禁）；excludePaths 拼接去重；环境变量 AMAGI_EMOJI_GUARD=1/0 强制开/关 |
| `emojiGuard.enabled` | boolean | 总开关（默认 false） |
| `emojiGuard.mode` | string | 文件面执法模式：strip=原地剥离放行并在工具结果附注记（默认）；block=拦截并给字符级诊断，模型去 emoji 后重试 |
| `emojiGuard.allow` | array | 白名单字符（逐字符；默认技术符号集 ⚠ ↔ ↩ ⏸ ⏱ ⏳ ▶ ⌨ ✖；项目级声明即完整替换，显式空数组 = 全禁） |
| `emojiGuard.excludePaths` | array | 排除路径（plain 前缀 / glob / prefix: 三形态，语义同任务授权 path-match） |
| `emojiGuard.conversation` | boolean | assistant 会话文本剥离（默认 true；恒为剥离语义） |
| `emojiGuard.files` | boolean | write/edit 工具面（默认 true） |
| `largeEmissionGuard` | object | 大发射守卫（v2.15.0，large-emission-guard.ts）：风险模型通道（riskyProviders 命中）的单次 write 内容/单段 edit newText 超 maxBytes 时拦截并给拆段指引（骨架 + heredoc 追加），同时子进程派发与 Leader L0 注入同一行纪律文案（prompt 层事前引导）。全局与项目合并：enabled/maxBytes 标量项目优先；riskyProviders/skipPatterns 项目级声明即完整替换；环境变量 AMAGI_LARGE_EMISSION_GUARD=1/0 强制开/关（全关含 prompt 层） |
| `largeEmissionGuard.enabled` | boolean | 总开关（默认 true） |
| `largeEmissionGuard.maxBytes` | integer | 单次发射字节上限（默认 24576 = 24KB；provider 解 PI_PROVIDER → PI_MODEL / 前段，未知通道不拦截） |
| `largeEmissionGuard.riskyProviders` | array | 风险 provider 名单（model spec 的 / 前段，如 amagi-glm；项目级声明即完整替换） |
| `largeEmissionGuard.skipPatterns` | array | 豁免路径模式（glob：* 单段、** 跨段，不含 / 按 basename；默认 ["*.lock","*.min.js","*.min.css","dist/**","node_modules/**","*.snap"]；≥5000 连续 base64 游程内容自动豁免） |
