# 项目知识体系模板

本目录包含 Amagi 项目知识体系的 JSON 模板文件。新项目从这里复制一套，就能得到 `/load-session` 等流程预期的目录结构；结构约定详见 `resources/core/integrations/project-knowledge-system.md`。

## 目录结构

```
project-knowledge-system/
├── README.md                              # 本文件
├── context.json                           # 项目上下文汇总
├── memory-map.json                        # 项目静态/半静态信息
├── task-index.json                        # 活跃任务索引（仅 in-progress/blocked/planned）
├── task-archive.json                      # 已完成任务归档
├── tasks/                                 # 任务详情目录
│   └── task-template.json
├── knowledge-base/                        # 知识库模板
│   ├── index.json                         # 知识库索引
│   ├── development-specs.json             # 开发规范
│   ├── conventions.json                   # 项目约定
│   ├── architecture.json                  # 架构设计
│   ├── api-reference.json                 # API 参考
│   ├── deployment.json                    # 部署指南
│   ├── glossary.json                      # 项目术语中心
│   └── domains/                           # 领域知识
│       ├── index.json                     # 领域注册表
│       └── domain-template/               # 领域模板
│           ├── index.json
│           ├── specs.json
│           ├── architecture.json
│           ├── api-reference.json
│           └── internals.json
├── tactical-book/                         # 战术手册模板
│   ├── index.json                         # 战术手册索引
│   ├── techniques.json                    # 技巧集
│   ├── patterns.json                      # 设计模式
│   ├── snippets.json                      # 代码片段
│   ├── checklists.json                    # 检查清单
│   └── usage-stats.json                   # 使用统计
└── error-book/                            # 错误手册模板
    ├── index.json                         # 错误手册索引
    ├── problems.json                      # 问题记录
    ├── solutions.json                     # 解决方案
    └── preventions.json                   # 预防措施
```

## 使用方法

### 1. 初始化项目知识体系

对于新项目，把模板复制到 `{PROJECTS_DIR}/{project-id}/`（`{PROJECTS_DIR}` 即 `{WORKSPACE_ROOT}/projects-memory/projects`，推导方法见 `resources/core/integrations/project-management.md`）。下面的 `TPL` 指本插件内的模板目录：

```bash
TPL=resources/templates/project-knowledge-system
DEST={PROJECTS_DIR}/{project-id}

# 创建项目知识体系目录
mkdir -p $DEST/knowledge-base/domains $DEST/tactical-book $DEST/error-book $DEST/tasks

# 复制模板文件
cp $TPL/context.json $TPL/memory-map.json $TPL/task-index.json $TPL/task-archive.json $DEST/
cp $TPL/knowledge-base/*.json $DEST/knowledge-base/
cp -r $TPL/knowledge-base/domains/. $DEST/knowledge-base/domains/
cp $TPL/tactical-book/*.json $DEST/tactical-book/
cp $TPL/error-book/*.json $DEST/error-book/
```

### 2. 更新项目配置

在 `context.json` 中替换占位符：
- `{project-id}` → 项目 ID
- `{YYYY-MM-DD}` → 当前日期
- 其他项目特定信息

### 3. 迁移现有 MD 文档

已有的 Markdown 规范文档，可以先把要点摘录进 `knowledge-base/conventions.json` 或 `development-specs.json`；模块级的深度内容放进对应领域目录。需要从源码系统性构建知识时，可使用 `project-knowledge-builder` 技能。

## 数据结构说明

### knowledge-base（知识库）

- **index.json**: 知识库索引，定义知识分类和加载优先级
- **development-specs.json**: 开发规范和注意事项
- **conventions.json**: 项目约定（命名、架构等）
- **architecture.json**: 系统架构设计
- **api-reference.json**: API 接口文档
- **deployment.json**: 部署和运维文档
- **glossary.json**: 项目术语中心，统一定义跨文件共享的概念
- **domains/**: 领域知识目录，按模块/子系统隔离存储深度领域知识
  - **domains/index.json**: 领域注册表，列出所有已构建的领域知识模块（启动时加载）
  - **domains/domain-template/**: 新领域的模板文件，包含 index.json、specs.json、architecture.json、api-reference.json、internals.json

### task-index.json（活跃任务索引）

仅包含活跃任务（status: in-progress / blocked / planned），已完成任务归档至 task-archive.json。

### task-archive.json（已完成任务归档）

存储所有 completed 和 cancelled 状态的任务，包含 completedDate 字段。

### tactical-book（战术手册）

- **index.json**: 战术手册索引
- **techniques.json**: 精妙技巧和方法
- **patterns.json**: 设计模式应用
- **snippets.json**: 代码片段库
- **checklists.json**: 各类检查清单
- **usage-stats.json**: 使用频率统计

### error-book（错误手册）

- **index.json**: 错误手册索引
- **problems.json**: 问题记录
- **solutions.json**: 解决方案
- **preventions.json**: 预防措施

### context.json（项目上下文）

主 Agent 加载入口，定义自动加载策略：
- **高优先级**（knowledge-base）→ 全部加载
- **中优先级**（tactical-book）→ 渐进式加载
- **低优先级**（error-book）→ 按需加载
- **领域知识**（domains）→ 启动时仅加载注册表，具体领域按任务匹配按需加载

## 自动加载机制

会话开始时（例如执行 `/load-session`），主 Agent 依次：

1. 读取项目注册表：`{PROJECTS_DIR}/registry.json`
2. 读取项目上下文：`{PROJECTS_DIR}/{activeProject}/context.json`
3. 根据配置自动加载：
   - 高优先级内容 → 全部加载
   - 战术手册 → 加载高频内容（使用统计前 30%）
   - 错误手册 → 按需加载
   - task-index.json → 仅加载活跃任务（in-progress/blocked/planned）
   - 领域知识注册表 → 启动时加载 domains/index.json，具体领域文件按需加载

## 维护规范

- 本目录的模板由知识沉淀流程（伏羲反思态，旧称 Thinker）维护，改动模板会影响所有新建项目，建议集中修改
- 每个项目可以有自己的扩展字段
- 保持 JSON 格式有效性
- 更新时同步更新 `lastUpdated` 字段

## 相关文档

- [项目知识体系规范](../../core/integrations/project-knowledge-system.md)
- [项目管理集成（路径体系）](../../core/integrations/project-management.md)
- [AGENTS.md](../../../AGENTS.md)
