# amagi-pi (v2.15.0)

> 历史上源自 Claude Code 插件 [amagi](https://github.com/runrunrain/amagi-opencode-plugins-marketplace) 1.5.165 的 **pi coding agent** 移植；现在作为独立插件演进。
> 当前版本: `v2.15.0` · 历史来源 commit: `25ec0fe7` · 最低兼容 pi `0.99.1+`，开发与本轮验证 `1.3.0`（未逐版本重测；图片准入见 AGENTS.md） · License: MIT

amagi-pi 是天城协作框架的 pi 实现——一个多角色 Agent 编排 harness，将"攻坚型"多模型协作（五个特色中心角色 baize/luban/luoshen/diting/fuxi、轻护栏、可续接子会话、确定性路由、证据自动化）落在 pi 的 extension 体系中。

### 执行中咨询（Advisor）

Leader 和获授权的子 Agent 可以调用 `amagi_advisor`，默认异步返回句柄，原执行者继续工作；建议完成后经原会话队列注入。`selected` 承接相关资料，`fork` 传全部可见文本，`isolated` 只传问题。模型不自动切换，咨询不创建子任务，也不改变任务验收状态。

```json
{
  "advisor": {
    "backend": "pi",
    "model": "openai-codex/gpt-5.6-sol:high",
    "leader": true,
    "roles": ["luban", "baize"],
    "maxCalls": 5,
    "maxTokens": 4096,
    "timeoutMs": 120000
  }
}
```

首次启用后重载 Leader；子任务须同时具备角色 `capabilities.advisor: consult`、工具名单 `amagi_advisor` 以及本次 `scope.advisor: "consult"`，模型和预算随原契约冻结。旧任务与 resume 不会自动扩权。配置未设置时无咨询工具；`model: null` 禁用 pi 后端。失败尝试也计次，计次保存在原生会话，压缩或恢复不会重置。

```js
amagi_advisor({ question: "这个并发方案还有哪些竞态？", contextMode: "selected" })
// 原执行者继续实现和验证；若此后的决策依赖答案：
amagi_advisor({ action: "wait", handle: "advisor-..." })
// 也可 query / cancel；delivery: "wait" 显式同步咨询。
task_submit({ agent: "luban", task: "实现并验证…", scope: { advisor: "consult", shell: "guarded" } })
```

pi 后端单轮、无工具，复用 pi 原生模型目录和认证；不同供应商的环境凭据按冻结模型专门交付，扩展装配后从环境清除。用量在独立的工具内嵌模型栏计量，查询和等待不重复入账。原 agent 结束独立工作时才等待在途咨询，以免 JSON 子进程提前退出；总时限和取消仍生效。

Codex 后端通过本机已登录的 Codex 会话服务创建专用 **Work** 咨询会话，后续自动续接；这不是普通 ChatGPT Chat，`codex-chat` 仅保留为兼容配置名。默认使用 **GPT-6-Astra / high**。原生聊天记录可在 Codex 桌面端读取，不需要额外复制 API key：

```json
{
  "advisor": {
    "backend": "codex-chat",
    "codex": { "mode": "managed", "model": "gpt-6-astra", "reasoningEffort": "high" },
    "roles": ["luban"],
    "timeoutMs": 120000
  }
}
```

`codex.model`、`codex.reasoningEffort` 可选，分别默认 `gpt-6-astra` 和 `high`，解析配置时随授权冻结。新建、续接和每轮请求均显式应用；服务返回的模型或思考档位不一致则失败，不自动回退。咨询会话按调用者、工作目录、原冻结授权、Codex 账户目录及 Advisor 配置分别索引；并发访问有独占锁，恢复只续接自己创建的咨询。原生认证和历史保留在 Codex；amagi 只存会话 ID。使用 Pi 实际运行设备上的 Codex，远端/WSL 环境须各自安装并登录。

已有桌面聊天可选 `codex: { "mode": "existing", "socketPath": "auto", "threadId": "指定聊天 ID" }`；该模式要求桌面端同一 app-server 的可访问共享连接。只连接已载入且空闲的目标，不接管其他任务，不自动改建会话。当前设备实测完成的是 managed 新建及续接；existing 的协议正反路径通过隔离测试，本机没有该共享入口。

Codex 使用原生只读咨询并拒绝外部审批请求。子任务仅支持无 deny 的 guarded 承诺；受控工具/禁入要求使用 pi 无工具后端。Codex 输出预算通过提示及已观察用量中断约束；未报告的金额保持未知。

CodeBox 的 **Provider Center → Pi → Agent 配置 → 执行中咨询** 提供后端选择、pi/Codex 模型、会话方式、已有聊天连接检测与选择、角色及预算编辑。连接检测只读，不发送咨询。异步咨询首版要求 pi 1.3+；旧宿主可显式 `delivery: "wait"`，扩展最低兼容版本不变。

## v2 任务契约内核（v2.0.0+）

v2 起，任务生命周期建立在**契约内核**上：TaskSpec 冻结派发、单写者内核驱动状态迁移、不可变存储落盘、回执（receipt）携带结构化检查证据。

- **三轴语义**：执行（execution）/ 结算（settlement）/ 接受（acceptance）三轴分离——执行完成 ≠ 结算就绪 ≠ 验收通过；展示面统一带验收轴标注（「执行结束，待接受」/「已接受」/「检查失败，须拒绝重派」）。
- **四稳定工具**：`task_submit`（提交任务，冻结 spec）、`task_resume`（续接 blocked 会话）、`task_control`（wait/cancel/resolve-external/**accept/reject**——验收引用当前 receiptId+revision，防陈旧决策）、`task_query`（summary/receipt/output 三档只读查询）。`task_batch` 高级分面经 `amagi_resource({ resource: "tools", enableFacet: "batch" })` 显式启用。
- **权限层**：任务权限四方交集冻结（请求 ∩ 角色授权 ∩ profile ∩ 后端配置），五通道逐次执法，请求不放大权限。
- **稳定身份与对账**（v2.1）：ownerId 由 `machine.json` 持久化 machineId 派生（hostname 漂移免疫）；恢复对账只在唤起原会话时发生；历史 foreign-owner 记录可经 `/amagi recovery adopt <taskId>` 确认收口；`/amagi recovery` 随时只读查看对账报告。

本包以**一个 TypeScript Extension（amagi-core）承载编排逻辑**，子 Agent 通过 spawn 独立 pi 进程实现，每个角色可运行不同 provider 的模型。保留任务契约内核，普通工具与 MCP 优先复用 pi 的公开能力；amagi 增补编排、策略、验证和交接。

---

## 目录

- [功能特性](#功能特性)
- [环境要求](#环境要求)
- [安装](#安装)
- [配置](#配置)
- [快速开始](#快速开始)
- [架构概述](#架构概述)
- [开发](#开发)
- [限制与已知风险](#限制与已知风险)

---

## 功能特性

### 五个特色中心角色

特色中心路由：角色 = 思维模式 + 质量标杆，不按场景查岗位；旧八岗位 stem（wenqu/taibai/laojun/wukong/cangjie/diting-quick/hongjun/puti）经 `agent-aliases` 归一到 canonical（兼容一个发布版本）。每一轮都以独立 pi 进程 spawn（进程级隔离），回流只取最终摘要文本。角色定义见 `agents/*.md`（frontmatter 含 `type`/`tools` 字段，`model` 由 profiles 动态解析）。

| 角色 | 类型 | 主特色（场景例证非边界） |
|------|------|------|
| baize（白泽） | fast | 证据链：可复核的事实供给（代码定位、依赖分析、外部调研、日志排查） |
| luban（鲁班） | work | 工匠闭环：规格→产物→验证→证据（编码、测试、文档、迁移、Git 收尾） |
| luoshen（洛神） | work | 审美判断：用户感知×信息层级×状态真实可用（UI 实现、视觉走查、图像判断） |
| diting（谛听） | expert | 对抗检验：独立门控（代码/方案/文档/证据审核；quick/full 两档，低频） |
| fuxi（伏羲） | expert | 第一性原理：设计/攻坚/反思三态（方向设计、疑难根因、经验沉淀，低频） |

### task 工具：四种派发模式

```
task_submit({ agent, task })                 // wait：同步等待本轮执行（默认）
task_submit({ agent, task, delivery: "handle" }) // 正文自动保存，立即返回句柄，完成自动通知
task_resume({ handle, message })             // blocked/error 任务沿原会话续接，新 taskId
task_control({ action: "wait", handles, mode: "all" }) // 超时只观察，不取消
task_control({ action: "cancel", handles, reason })
task_query({ handle, view: "summary" })       // summary / receipt / output 只读
task_control({ action: "accept", handle, receiptId, expectedRevision, reason })
// 高级批次先经 amagi_resource({ resource: "tools", enableFacet: "batch" }) 启用
task_batch({ nodes: [{ id, agent, task }], sharedInputs: [path] })
```

- **sync**：spawn 子 pi 进程执行，stdout JSONL 事件流解析取最终文本，会话落盘并注册到 task-registry。
- **background**：立即返回 taskId，done 或 blocked 后自动通知 Leader（不阻塞 Leader）；sync/background/resume/batch/RPC 共用 admission FIFO。
- **resume**：新进程沿原会话执行，生成新 taskId；`handle` 可用任务前缀、稳定 name 或精确 `runId/name`。原权限、模型与工作目录继承，不接受参数重新扩权。需要历史修复时独立 fork，源会话树保留。
- **batch**：显式启用后一次派发 1..32 个节点，`nodes[]` 声明任务与依赖，`sharedInputs` 注入共享资料。`dependsOn:["impl"]` 缺省等待上游显式 accepted；ready/settled 用对象指定。图、任务书、必需输入与产物冲突全部通过预检后才启动节点。并发仍由共享 admission 分池限制。
- **wait/cancel**：稳定控制面接受节点任务句柄，组句柄提示改用节点；超时不取消。cancel 可移除排队任务或终止运行进程。blocked/error 会话可续接。
- **task_query**：summary 给决策摘要，receipt 给当前回执及 revision，output 显式读取输出；采集详情归档按需展开。旧 `task/query_task` 只用于历史兼容或显式 `AMAGI_SURFACE_LEGACY=1`，字段见 [旧面规范](resources/core/tools-legacy.md)。

逻辑 Agent Team 是 Leader 管理的 depth=1 兄弟任务/DAG，通过契约回执接力。queued/running 任务可用 `task_control steer` 传递补充指令，冻结任务书不变；blocked 任务改用 `task_resume`。独立通用 `rpc_task` 仍供需要常驻会话的场景使用。

专家 Agent 采用阶段级低频预算：fuxi 只在父任务无可复用方向且存在重大跨模块取舍时调用一次，产物供全部实现节点共享；diting 只在高风险大阶段全部实现、集成与验证完成后审核一次。Leader 验收中发现少量明显问题时直接修并验证；问题较多时才合并为一个批次交执行 Agent。禁止按小功能形成 fuxi↔diting 或实现↔diting 循环。

### blocked 提问协议

信息不足时，子 Agent 输出阻塞信号后正常结束（而非假设硬做）：

```
<!--AMAGI:BLOCKED-->

STATUS: blocked
QUESTIONS:
  1. ...
  2. ...
PARTIAL:（已完成的可复用中间产物，如有）
```

Leader 收到后用 `task_resume({ handle: "<taskId>", message: "答复..." })` 新开续接轮次；新进程带原会话上下文继续。

### 安全守卫 + 执行纪律软引导 + 高风险哨兵

| 守卫 | 事件 | 行为 |
|------|------|------|
| 危险命令守卫 | `tool_call`（Bash） | 拦截 `rm -rf`、`chmod 777`、fork bomb 等模式，返回 `{ block: true }` |
| 敏感文件提交守卫 | `tool_call`（git commit） | 阻止 `.env`、`*.pem`、`*.key`、`credentials*`、`*secret*`、`id_rsa*`、`node_modules/`、`.git/`、>10 MB 文件进入提交 |
| 交互式命令守卫 | `tool_call`（Bash） | 阻止会在无 TTY 环境挂起的编辑器、分页器、REPL 与交互式 SSH |
| 先定位再读取（软引导） | L0、角色公共约束、每次 task/resume prompt | 要求先 `grep/find/ls` 定位，再 `read` 每个已有目标文件，看到结果后下一轮才修改；不建立调用历史状态，不阻断 edit/write |
| Bash 失败诊断（软引导） | prompt + 失败 `tool_result` | 保留原始错误并追加 cwd/路径、环境/依赖、参数、代码四类诊断建议；不阻止重试，由 Agent 根据证据修正 |
| JSON 文件校验 | `tool_result` | write/edit 完成后检查不超过 5 MB 的 JSON；非法时追加错误提示，**不会阻止或自动回滚已经发生的写入** |
| 高风险路径哨兵 | `tool_call` | 检测 `.env`、`.ssh`、`migrations/`、`.sql`、`schema/`、`.pi/settings` 等模式时**不阻塞**，仅注入提醒（每会话上限 5 条） |

> 危险命令、交互式命令和敏感提交守卫在主进程与子进程都注册。执行纪律是软引导，不通过 hook 阻断普通 edit/write/Bash。

### L0 Leader 系统提示注入

`before_agent_start` 事件每轮动态注入 L0 系统提示：persona + 不可变基线（内联展开）+ 质量三支柱原则 + 角色池速查 + 当前 profiles 摘要。L1 细则通过 `amagi_resource` 工具按需读取。

显式读取的指南、规则、任务资料和工具返回正文完整保留，原生分页与压缩继续由 pi 管理。历史降噪只缩减有当前任务来源证明及有效归档的自动采集范围，范围与正文摘要随 pi 原生结果/后台 custom message 保存，重启和 fork 恢复后可验证；按已完成的 assistant 轮计龄。详见 [上下文正文保全与采集降噪](docs/context-integrity.md)。

### compact 续接

压缩前暂存任务续接状态，只有 pi 确认压缩落盘后才提交续接快照；失败和取消不会留下伪压缩边界。任务目标、运行中子 Agent、产物路径及 blocked 问答经原生会话记录恢复。

可在现有项目或全局 `amagi.json` 中选择统一压缩模型，与 `agents` 配置并存：

```json
{
  "profile": "inherit",
  "agents": {},
  "compaction": {
    "model": "openai/gpt-4o-mini"
  }
}
```

把示例替换成已在 pi 注册并配置认证的 `provider/model[:thinking]`。Leader、JSON 子 Agent 与 RPC worker 的 `/compact`、阈值自动压缩及上下文溢出恢复均使用该模型；工作模型不切换。项目配置优先于全局，每次压缩重新读取；子 Agent 沿用派发者的配置目录，任务工作树不另选策略。未配置时完全委托 pi 默认压缩；项目 `"model": null` 可禁用全局继承。`/amagi config explain` 和 `/amagi doctor` 显示来源及模型/认证状态。

适配器调用 pi 公开 `compact()` 与原生模型运行时，保留原生摘要提示、前摘要更新、split turn、历史切点、文件列表、用量、落盘及失败/取消事件。原生摘要器的工具结果节选策略仍保留；显式读取正文和源历史不被插件改写。认证、采样及供应商配置继续由 pi 管理，不在 `amagi.json` 存放密钥；子端专用压缩凭据不进入模型 shell 环境。子进程启动时交付环境凭据快照，新增供应商或新的环境引用后需新建子进程；认证与 `models.json` 的加载和刷新遵循 pi 原生行为。

配置无效、模型未注册、认证/摘要失败或摘要请求超出目标模型窗口时，取消本次压缩并保留历史；不会静默改用工作模型或额外裁剪原生摘要请求。加载这次扩展改动需在 pi 空闲时 `/reload`，已经启动的子进程需重新派发。

### 分档模型解析

优先级链（从高到低）：

```
参数 --model → 项目 amagi.json (cwd/amagi.json) → 全局 amagi.json (~/.pi/agent/amagi.json)
            → profile (tiered.json) → agent frontmatter model → ctx fallback
```

项目级与全局级 `agents` 合并（项目键优先）；`profile` 选择：项目 > 全局 > 默认 `tiered`。全局文件首次运行不存在时自动创建自描述默认内容。

默认 tiered 分档（`profiles/tiered.json`）：

| 档 | 模型 | 说明 |
|----|------|------|
| leader | `null` | 继承用户 pi 默认模型 |
| fast | `deepseek/deepseek-v4-flash:max` | baize |
| work | `zhipuai/glm-5.2:max` | luban / luoshen |
| expert | `openai-codex/gpt-5.6-sol:high` | diting / fuxi |

角色级覆盖：`luoshen` → `kimi-coding/k3-256k:high`（视觉特化档）。

thinking 档位校验：`provider/model:level` 中的 `level` 必须属于 `off | minimal | low | medium | high | xhigh | max`；非法值自动修正（Levenshtein ≤2 近似匹配）。

### 确定性路由

| 输入 | 行为 |
|------|------|
| `#<角色名> <任务>` | 直接派发该角色子 Agent，**绕过 Leader LLM 路由**（零延迟零歧义） |
| `#review [关注点]` | 直接派发 diting 审当前 `git diff HEAD` |
| 其他 `#xxx` 或无 `#` | 放行，交 Leader 正常处理 |

角色名匹配 `agents/*.md` 文件名（大小写不敏感）。

### 界面与交互（v1.5.218 三层可达体系）

交互主通道是 **`/amagi` 命令层**（任何终端必达，含自动补全）：

| 命令 | 行为 |
| --- | --- |
| `/amagi board [任务前缀]` | 打开看板；带前缀直达该任务面板 |
| `/amagi tasks` | 任务列表 widget 开/关 |
| `/amagi review` | 派发 diting 审当前 diff（结果自动回流） |
| `/amagi session <任务前缀>` | 直接打开该任务**完整会话查看器** |
| `/amagi help` | 交互帮助（含各终端 ⌥ 键开启指引） |

快捷键层（mac 键位显示；alt 系在 Terminal.app/iTerm2/codebox 需开启 Option 作 Meta 键，见 `/amagi help`）：

- `⌥W`（alt+w，兼容 `ctrl+shift+w`）：workflow 看板。
- `⌥T`（alt+t，兼容 `ctrl+shift+b`）：任务列表 widget 开/关。
- `⌥R`（alt+r，兼容 `ctrl+shift+r`）：一键派发 diting 审当前 diff。

看板三级键盘流：列表（`j/k` 选择 · `g/G` 首尾）→ `⏎` 任务面板（模型/思考强度、结果或根因、最近行为窗口）→ `v` **会话查看器**（完整转录：user/assistant/toolCall/toolResult，`j/k/d/u` 滚动，>2MB 自动尾载）；`q/Esc` 逐级返回，`r` 刷新。`#panel <n>` 按状态栏稳定编号直达任务面板。

**常驻分块面板**（`panel-widget.ts`，editor 上方）：概要条（含 Leader 模型面 `provider/model:思考强度`）→ 角色矩阵 → 任务流 → 最近结算四块；行预算默认 12 行（`amagi.json ui.panel.maxLines`），空态收敛为单行，窄终端自动降级。状态栏（footer）同步概要与 Leader 模型面。blocked 待答常驻，结算 15s TTL 驻留。

**键位自定义**：`amagi.json` → `"ui": { "keys": { "board": ["alt+w", "ctrl+shift+w"], ... } }`；能力横幅 `ui.shortcutHint`（默认开，版本升级后首启提示一次）。

session compact 后的 continuation 摘要会恢复 queued/running、blocked 问题、artifact 引用，并按 runId 输出组内节点状态与依赖进度，避免压缩后重复派发同一批任务。摘要优先保留在途任务与近期产物，问题、目标和引用列表限幅并给出省略数量及查询入口；结果正文与自动采集详情通过归档按需读取。

恢复启动通知只展示本会话可行动任务、交付计数和异常产物；历史干净任务与其他会话记录由 `/amagi recovery` 显式查询。通知去重随当前会话分支留档，重启后相同事实不重复注入；缺口或产物状态变化仍会通知。相同插件快照在 provider 上下文中去重，用户正文保留原文。

子 Agent 的 JSON/RPC 会话默认在原生重试耗尽后补救瞬时断连、请求超时和服务端临时错误：保留会话与已执行工具结果，额外最多续跑 3 次，分别退避 5、15、30 秒。从首个错误起 2 分钟内才允许追加恢复尝试，原生重试耗时也计入；已发出的请求仍受宿主请求超时控制。预算耗尽后返回原错误，沿用现有失败回传与显式重派策略。成功收到模型响应会清零连续故障预算；鉴权、配额、限流、上下文超限及取消不走此补救。恢复记录以 `amagi:network-recovery` 留在原生会话中；`AMAGI_AUTORETRY_OFF=1` 同时关闭此补救和任务级自动重派，不改变宿主原生重试配置。

### 工作区预检与确定性收尾

受信任的同步编码任务在派发时由 harness 生成有界工作区快照：根目录、候选文件索引、已解析的测试命令；小型工作区还会内联非敏感目标源码，替代子 Agent 的 `pwd` / 目录枚举 / 重复首读。扫描默认最多 240 项、深度 4、提示预算 24 KiB，跳过依赖、构建产物、symlink、`.env`、凭据和 `agent-outputs/.amagi`；未完整扫描时会明确标记“截断”，不声称完整索引。未信任项目只注入元数据，不读取源码、不运行项目脚本。

`luban`、`luoshen` 的受信任同步任务由 harness 在结算前确认 `package.json` scripts / `Makefile` / `Cargo.toml` 中探测到的确定性基线，并采集 `git diff --stat`。同步验证的结构化检查事实交给收尾链复用，避免为展示证据再次执行相同基线；若基线失败，默认把原始失败尾部交回同一会话修复一次，修复预算耗尽后任务以 `error` 结算，不会把失败包装成完成。其他编码类完成态仍按原证据策略附加测试与 diff。

完成回流默认将自动采集部分压缩为检查结论、失败线索与一次变更摘要；清理展示副本中的终端控制码、回车进度和重复行，本任务登记路径最多列 5 处，其他来源保留计数及归因边界。采集详情与命令日志保存到任务 artifact 目录的 `evidence.md`，通知给出可直接 `read` 的路径；子 Agent 原始终稿仍保存为 `result.md`，结构化检查、结算和显式验收保持原口径。若详情无法落盘则回退完整采集回流；`AMAGI_EVIDENCE_VIEW=legacy` 可恢复旧展示。

`task_query({ handle, view: "output" })` 同时提供确实存在的终稿和采集归档路径，三档查询均不展开采集正文。旧查询的 error 终稿兜底与结果预览相同时只展示一次，新增诊断仍带回。

`task_control wait` 返回当前三轴与进度，blocked 时提供待答问题正文或 NEEDS_HANDOFF 接手指引，不重放终稿和采集详情。续接只继承直接父任务的终稿入口及本轮明确输入；批次下游只接收直接前序节点的终稿入口、摘要与固定回执，祖先引用通过归档按需追溯。没有终稿归档时交接保留实际输出节选、失败原因及完整结果查询入口；普通产物引用不会被当作完整终稿。

开关：`AMAGI_WORKSPACE_PREFLIGHT_OFF=1` 关闭快照；`AMAGI_PREFLIGHT_MAX_BYTES` 调整 4–64 KiB 预算；`AMAGI_AUTO_VERIFY_OFF=1` 关闭确定性收尾；`AMAGI_AUTO_REPAIR_ROUNDS` 调整自动修复轮数。

### MCP 工具（通用 mcpServers 配置消费）

宿主提供原生 MCP 注册 API 且未明确禁用内置 MCP 时，默认由 pi 管理连接、认证、发现、资源与退出收尾。amagi 通过公开 `registerMcpServer` 接入兼容来源，用事件层执行角色路由和冻结授权，不另建后台连接或发现缓存。

- 权威配置为 `<PI_CODING_AGENT_DIR || ~/.pi/agent>/mcp.json`，可信项目的 `<cwd>/.pi/mcp.json` 按宿主规则覆盖。项目无 command/url/type 时仅浅覆写 `enabled/exposure/toolExposure`；项目不能指定 provider 认证。原生配置优先于同名兼容来源；`enabled:false` 不会被旧 `.mcp.json` 重新启用。
- 旧 `settings.json` 的 mcpServers、`~/.agents/.mcp.json`、项目 `.mcp.json/.agents/.mcp.json/.pi/settings.json` 继续补充未被原生文件定义的 server。项目兼容配置经宿主信任确认后才注册。原生文件不重复注册，其他扩展的同名注册不接管。
- CodeMode 对普通 Leader 和子任务默认可用，由模型按任务选择直接调用或脚本组合。无需角色开关或 `scope.codemode`；嵌套调用继续经过现有工具权限和事件链。批量读取、筛选聚合和依赖调用可在一次脚本中完成，任务派发仍一次提交完整正文并经契约内核保存、启动。
- `amagi.json` 可设 `codemode.preference: "auto" | "prefer"`，默认 `auto`；`prefer` 仅建议适用时优先考虑。`codemode.budget.maxOutputTokensPerScript`（默认 2000）和 `maxTimeoutMsPerScript`（默认 60000）自动补齐脚本选项，模型可用 `// @options: {...}` 覆盖。旧 `mode/roles/rpc` 和次数、聚合预算保留兼容，不再限制使用。CodeBox 的 CodeMode 配置卡与这些字段一致。
- `codemode` 无需额外配置：amagi 用宿主公开工厂装配自己的 `codemode`（默认值、使用统计和原工具权限链）。Pi 内置 `builtin:codemode` 可能加载时（默认），amagi 改在会话绑定后注册，不触发宿主的同名替换警告，并按扩展顺序优先于内置实例生效；内置已在 `pi config` 或 `settings.json` 中以 `"-builtin:codemode"` 关闭时则在装载期注册。若最终生效的仍是宿主实例（如 CLI 显式 `-e builtin:codemode`），amagi 沿用宿主实现，以事件补齐默认输出/时限与使用统计。两种方式都不影响原生 MCP。
- 原生 `/mcp`、codemode、deferred 与资源工具均保留。`mcp_call` 为兼容入口，通过 `ctx.executeTool` 委托已发现的原生工具；`mcp_list_tools` 展示当前授权内可见的宿主工具。尚未发现的工具明确报错，不借失败另开连接。业务 arguments 原样传递，包括字符串 `"null"`。
- 非空和空冻结授权均覆盖原生工具/资源；授权与连接所有权独立，通配只读授权须有 `readOnlyHint`。按宿主已注册工具段匹配授权，带 hash 的名称缺少原名映射时拒绝猜测；要求按复杂远端原名精确授权时使用明确禁用原生后的兼容后端。JSON/RPC 凭据按路由与授权交付，MCP 专用凭据不进入模型 bash/run_bg 环境。
- 宿主缺少注册 API，或明确使用 `-builtin:mcp`/`--no-mcp` 时保留自研兼容后端；显式 mixed 计划保持逐 server 分工。兼容后端不实现 pi 的 provider 认证/OAuth，遇到这些配置明确拒绝降级。该后端的按远端工具分类超时：视觉类默认 90s，其余 60s；在 amagi.json 的 `mcp` 段配置：

```json
{ "mcp": { "callTimeoutMs": 60000, "visionCallTimeoutMs": 90000 } }
```

  以上超时配置仅作用于自研兼容后端；原生后端使用 pi 的 MCP timeout 配置。
- 历史：P4-4 曾以 `mcp-tools.ts` 硬编码重实现智谱三 server（零配置），v1.5.198 引入通用通道后双注册冗余，v1.5.245 清理删除（协议件并入 mcp-client.ts）。

浏览器任务直接使用已经可用且获准的 CLI、skill、MCP 或宿主工具。v2.13.6 补齐通用 MCP 图片回传与 stdio 取消，call wire v2 带 `data.images`；HTTP 控制 server 应配置 `retryToolCalls: false` 避免自动重放。取消通知不表示后端输入已停止。

**Codex Computer Use 指 Codex 自身控制非浏览器应用，浏览器成功不算此验收。** pi 的 `openai-codex` provider 不提供 Codex 原生工具。官方 CLI 已真实加载 Sky，原生 fixture 观察请求因源应用许可缺失被拒绝；尚未完成原生控制。继续核验合法源批准/委托接口，不以默认 Desktop socket 失败判整个能力不可用。额外 Codex 模型与用量必须披露，不伪造轮次或批准。当前状态与验证边界见 [Codex Computer Use 接入说明](docs/computer-use.md)。

### 长文本编辑与版本范围引用

长段整行重写可先取得工具签发的范围引用，随后只提交新内容，减少重复抄写 `oldText` 的错误：

```js
read({ path: "design.md", offset: 82, limit: 7, editReference: true })
// 从结果取得真实 snapshotId，坐标为该快照中一基、含端点的文件行号。
edit({
  path: "design.md",
  selection: { snapshotId: "<read 返回的 s_...>", startLine: 82, endLine: 88 },
  newText: "替换后的整行内容。\n"
})
```

引用绑定当前会话、工作目录、授权上下文、真实路径和完整文件版本，仅能选择工具完整展示过的行。文件任意位置发生变化后须重新读取；非 EOF 的非空替换必须以换行结尾，空串表示删除整行。第一版支持有效 UTF-8、可选 BOM 和统一 LF/CRLF；截断内容、空文件、混合行尾或不支持的编码不签发引用。普通 `read` 及既有 `edits`、`patch`、`regex`、`files` 继续可用；`selection` 每次只替换一处，不能与这些分面混用。

快照只在内存保留，最多 8 个、总计 8 MiB、10 分钟过期，重载或切换会话后失效。完整文件超过缓存限额时使用原有编辑方式。匹配失败会区分取消、I/O、歧义和未命中；只有确认尚未写入的未命中进入恢复。完整展示的唯一候选可附带引用，由模型在下一次调用中显式选择；不自动合并语义差异，也不再生成无版本校验的按行号 Python 覆盖模板。

范围写入沿用原生编辑队列、diff、写入归因和 LSP 反馈，在读取及落盘前复核完整字节。它不能提供针对任意外部进程的文件系统 CAS；并行开发仍应使用独立工作树。`/amagi doctor` 显示当前增强工具注册、快照缓存和原生失败分类，已打开会话须重新加载扩展才获得新能力。

### LSP 语言服务器支持（按项目语言动态启用）

单工具 `lsp` 暴露语言智能：`status / capabilities / diagnostics / definition / type_definition / implementation / references / hover / symbols / rename`。参考 oh-my-pi 的 LSP 集成模式：

- **动态启用**：内置 8 服务器目录（`lsp-defaults.json`：typescript-language-server、pyright、gopls、rust-analyzer、clangd、lua-language-server、bash-language-server、marksman），按项目 rootMarkers（cwd 直接条目，支持 `*` 单层通配）∩ 服务器二进制可解析（`node_modules/.bin`、`.venv/bin` 等项目本地 bin 优先，再 PATH）检测；无对应语言的项目 0 启用，工具不报错。
- **生命周期**：懒 spawn（首次真实请求才起进程）、单请求超时 + `$/cancelRequest`、60s 启动熔断、空闲回收（默认 5min）；主进程与子进程均注册，`agent_settled` + `session_shutdown` 双重关池。
- **rename 安全**：默认 preview 返回编辑摘要，`apply:true` 才写盘；`lsp.readOnly=true` 或服务器未声明 renameProvider 时拒绝。
- **配置**：`amagi.json` `lsp` 段（enabled / autoDetect / readOnly / idleTimeoutMs / servers 覆盖/禁用/自定义），全局+项目合并，项目键优先；schema 同步在 `schemas/amagi-config.json`。

角色卡白名单：baize / luban / luoshen 的 `tools` 含 `lsp`。已知边界（V1）：无 lspmux 共享 broker；WorkspaceEdit 仅 `changes` 形态；无 code_actions。

### emoji 硬拦截护栏（v2.7.0）

提示词里禁止 emoji 是概率性的——模型仍会偶尔把 emoji 写进会话或文档（skill/规则文档重灾区）。本护栏用代码确定性地拦：

- **文件面**：`write` 的 content、`edit` 的 edits[].newText 与 selection 的 newText（oldText 及选区外原文永不触碰）；`strip` 模式（默认）原地剥离并在工具结果尾附移除清单，`block` 模式拦截并给字符级诊断（码点/行号/等效文字替换指引）。
- **会话面**：assistant 消息 text 块替换式剥离（带 textSignature 的块与 thinking 块跳过——签名重放约束；用户消息不动）。
- **检测口径**：`\p{Extended_Pictographic}` 表情序列（ZWJ 链/旗帜）+ 键帽（1️⃣）+ 肤色修饰符；默认白名单为框架自用文本呈现技术符号（⚠ ↔ ↩ ⏸ ⏱ ⏳ ▶ ⌨ ✖）；多码点组合恒不放行。edit 多文件模式（files: string[]）排除粒度为「任一目标命中排除路径即整调用保守放行」。
- **配置**（默认关，主/子进程双侧生效）：

```json
{
  "emojiGuard": {
    "enabled": true,
    "mode": "strip",
    "excludePaths": ["assets/**/*.svg"],
    "allow": ["⚠", "↔"],
    "conversation": true,
    "files": true
  }
}
```

环境变量 `AMAGI_EMOJI_GUARD=1/0` 强制开/关；改动 amagi.json 即时生效（无需重启）。已知边界：bash heredoc 写文件不在拦截面内。

### amagi-dark 主题

`themes/amagi-dark.json`：金色调暗色主题，含语法高亮、thinking 档位配色、diff 着色、导出页配色。在 pi 中通过主题选择器切换。

### WebUI 与实时看板

插件内置轻量 WebUI 服务端与独立前端单页应用（SPA）：

- **服务端**（`extensions/amagi-core/webui/`）：基于 Node.js 原生 HTTP + WebSocket 实现，默认随主进程启动（随机空闲端口，通过 `~/.pi/agent/amagi/webui/runs/<pid>.json` 注册，支持 Bearer capability token 鉴权）；提供 `/api/info`、`/api/history`（历史会话分页与用量快照）、`/api/input`（用户输入注入，支持 auto/steer/prompt 档位与斜杠命令展开）、`/api/draft`（草稿暂存）、`/api/commands`（命令选择面）及 `/api/recovery`（v1.0.17：任务对账报告只读暴露——actionable/sessionBinding/machineId 如实透传）。
- **前端 SPA**（`webui/`）：基于原生 TypeScript + Vite 构建（零 React/Vue 等重依赖），提供实时任务看板（对齐 TUI 四块面板与 15s TTL 结算驻留；v2.1 起任务面板带**三轴标注**——待接受项醒目徽标 + 标题「⏳N 待接受」计数，accept 后翻转「已接受」）、Token 用量与缓存命中率统计、事件信封断线回放与命令交互。生产构建执行 `npm run build:webui`。
- **协议契约**：遵循独立版本化协议规范，详见 `docs/webui-protocol.md`（协议契约版本 `v: 1`，当前文档规范 `v1.0.17`）。

### 会话导出揭示边界与 /login 须知（v2.11.0）

- **HTML 导出揭示边界（审阅须知）**：pi 会话 HTML 导出对隐藏消息（`display:false`，如注入的系统层内容）默认仅视觉隐藏——导出页提供一键揭示操作，收件人可自行展开查看。把导出页用于分享/归档审阅时须知：视觉隐藏不等于内容不可达，隐藏消息不应被视为对收件人保密的边界。
- **`/login openai` 不自动迁移 codex OAuth**：pi 的 `openai` 与 `openai-codex` 是两个独立 provider，凭据在 `~/.pi/agent/auth.json` 中各占独立条目。执行 `/login openai` 只完成 openai（ChatGPT）OAuth，不会迁移或复用已有的 openai-codex（Codex 订阅）凭据；需要 Codex 系模型时须单独执行 `/login openai-codex`。amagi 侧不自建登录、不复制 auth 文件给子进程（登录为宿主运维动作，用户交互 opt-in）。

---

## 环境要求

| 依赖 | 版本 | 说明 |
|------|------|------|
| Node.js | >= 22.19.0 | `package.json` engines 声明；测试建议 Node 24 |
| pi coding agent | >= 0.99.1 | 开发类型基线与本轮验证 1.3.0；较旧宿主按公开能力降级 |
| typebox | `typebox` | peerDependency；工具参数 schema |

---

## 安装

### 前置：安装 pi

```bash
# 按官方文档安装 pi coding agent
# https://github.com/earendil-works/pi-coding-agent
```

### 方式一：从 Git 仓库安装（推荐）

```bash
# HTTPS（公开仓库；私有仓库需本机已有 GitHub 凭据，见下）
pi install git:https://github.com/runrunrain/amagi-pi.git

# SSH（私有仓库推荐，走 ~/.ssh/config 密钥）
pi install git:git@github.com:runrunrain/amagi-pi.git

# 钉版（tag 或 commit hash；pinned 包不被 pi update 批量移动）
pi install git:github.com/runrunrain/amagi-pi@v1.5.164-pi.1
```

**私有仓库的 HTTPS 凭据**：pi install 走系统 git，HTTPS clone 私有仓库时依赖 git 凭据助手。macOS 上若已通过 `gh auth login` 登录 GitHub CLI，token 存于 Keychain，git 会自动取用，无需额外配置；其他系统可先执行 `gh auth setup-git` 将 gh 注册为 git 凭据助手。无凭据环境（CI/新机器）可改用 SSH 方式或配置 `GIT_TERMINAL_PROMPT=0` 快速失败。

### 方式二：从本地路径安装

```bash
git clone https://github.com/runrunrain/amagi-pi.git
cd amagi-pi
pi install .
```

日常开发建议直接安装工作区绝对路径，例如 `pi install /absolute/path/to/amagi-pi`。pi 会在配置中引用这个磁盘目录而不复制，后续新会话直接加载工作区改动；若此前装过 Git 来源版本，先通过 `pi list` 核对并移除旧 Git 包，避免同一插件以两个来源重复加载。这样无需向 `~/.pi/agent/git/...` 手工覆盖文件。

验证安装：

```bash
pi list              # 应显示 amagi-pi 包
```

> npm 发布预留：包结构已适配 npm（`package.json` 含 `files` 白名单），暂未发布到 registry。发布后可 `pi install npm:amagi-pi`。

### 安装后验证

在 pi 交互会话中：

```text
# 验证 skills 可加载
/skill:workflow

# 验证 prompts 出现
/                  # 斜杠菜单应显示 prompts/ 下全部 prompt template（init、load-session、save-session、fetch-feishu-doc 等）

# 验证 task 工具可用
# （直接让 Leader 派发一个任务，或用确定性路由）
#luban 写一个 hello world
```

---

## 配置

### 1. Provider 凭据（`~/.pi/agent/auth.json`）

pi 的 provider 凭据管理。每个 provider 一条 `api_key` 记录：

```json
{
  "zhipuai": {
    "type": "api_key",
    "key": "<your-zhipu-api-key>"
  },
  "tbrouter": {
    "type": "api_key",
    "key": "<your-tbrouter-api-key>"
  },
  "kimi-coding": {
    "type": "api_key",
    "key": "<your-kimi-api-key>"
  }
}
```

本包涉及的 provider（按 `profiles/tiered.json` 默认配置）：

| Provider | 用途 | pi env 变量（子进程注入） |
|----------|------|--------------------------|
| `zhipuai` | fast/work 档（glm-5.2） | `ZHIPU_API_KEY` |
| `tbrouter` | expert 档（grok-4.5） | `TBROUTER_API_KEY` |
| `kimi-coding` | luoshen 覆盖（k3-256k） | `KIMI_API_KEY` |

> 子进程 env 经最小化过滤：只放行 `PATH`/`HOME` 等基础变量 + `PI_*` 前缀变量 + **解析后实际 provider 的凭据**（不兜底全量）。配置驱动 MCP 的凭据按角色实际命中的 server 提取 `${VAR}` 引用，经一次性专用凭据包交给 extension 插值后立即清除，不进入模型可直接读取的 bash env。密钥值不进日志。

> 若在 MCP 配置中引用了第三方/智谱系 MCP server，其 key 可直接通过环境变量（如 `ZHIPU_API_KEY`）引用，与上述 provider 凭据共享。

### 2. amagi.json（全局 + 项目级）

amagi 配置分两层，均名为 `amagi.json`，结构相同：

| 层级 | 路径 | 说明 |
|------|------|------|
| 全局 | `~/.pi/agent/amagi.json`（或 `PI_CODING_AGENT_DIR` 环境变量覆盖的目录） | 跨项目默认；首次运行不存在时**自动创建**自描述默认内容 |
| 项目 | `<cwd>/amagi.json`（当前工作目录） | 项目内覆盖；需手动放置，不自动创建 |

```json
{
  "$schema": "./schemas/amagi-config.json",
  "profile": "tiered",
  "agents": {
    "luban": { "model": "zhipuai/glm-5.2:max" },
    "diting": { "model": "tbrouter/grok-4.5:high" }
  },
  "mcp": {
    "default": ["web-search-prime", "zread", "web-reader"],
    "agents": {
      "baize": ["tavily-mcp", "firecrawl-mcp"]
    }
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `$schema` | `string` | JSON Schema 引用（文档用途），全局文件自动写入 |
| `profile` | `"tiered" \| "inherit"` | 选择内置 profile（默认 `tiered`）；`inherit` 全部继承用户 pi 默认模型。项目级 > 全局级 > 默认 |
| `agents` | `Record<string, { model: string }>` | 角色级 model 覆盖，key 为角色文件名。项目级与全局级**合并**（项目键优先），为最高优先级用户配置 |
| `mcp.default` | `string[]` | 所有子 Agent 默认加载的 configured MCP server；`*` 表示全部，显式空数组表示不加载 |
| `mcp.agents` | `Record<string, string[]>` | 角色额外加载的 server，与 default 取并集；server 名来自 MCP 配置，不写死在代码里 |

MCP server 优先定义在 pi 原生 `mcp.json`（全局数据目录或可信项目 `.pi/`）；旧配置来源继续补缺。原生连接由宿主管理，子 Agent 的调用同时受角色路由与冻结任务授权约束；发现 `mcp_list_tools` 与兼容调用 `mcp_call` 沿用角色工具面。

**优先级链**（高 → 低）：参数 `--model` → 项目 `agents[name]` → 全局 `agents[name]` → profile `agentOverrides`/tier → agent frontmatter `model` → ctx fallback。

**自动创建**：全局 `~/.pi/agent/amagi.json` 在首次模型解析时若不存在则自动写入 `{"$schema":...,"profile":"tiered","agents":{}}`（目录递归创建，权限 `0700`）；已存在则不覆盖。项目级文件不自动创建。

Schema 校验：`schemas/amagi-config.json`。损坏 JSON、未知键、未知角色名、非法 profile 值会在 stderr 输出诊断提示（含文件路径），不崩溃。

模型格式：`provider/model[:thinkingLevel]`，如 `zhipuai/glm-5.2:max`、`tbrouter/grok-4.5:high`。

### 3. 内置 profiles

| 文件 | 说明 |
|------|------|
| `profiles/tiered.json` | 分档配置（默认）：fast → deepseek-v4-flash，work → glm-5.2，expert → gpt-5.6-sol，角色覆盖 luoshen（视觉特化档） |
| `profiles/inherit.json` | 全部 `null`，继承用户 pi 默认模型 |

> **快速开始**：如果不想配置多 provider，在 `~/.pi/agent/amagi.json` 中设 `"profile": "inherit"` 即可让所有角色使用你 pi 的默认模型。只需 pi 已配置好至少一个可用 provider。

---

## 快速开始

安装后先运行 `/amagi doctor`，再用 `/amagi config explain luban` 查看选模来源。需要继承当前 pi 模型时运行 `/amagi config init inherit`；保留分层模型可选 `init tiered`。预设只创建项目 `amagi.json`，已有配置不覆盖。用户侧帮助 `/amagi guide tasks|config|mcp|recovery` 使用原生 custom entry 展示，不重复进入模型上下文；模型需要时显式读取 `amagi_resource({resource:"guide-tasks"})`。

模型目录、认证、普通工具和 MCP 管理沿用 pi。字段参考见 [配置参考](resources/core/configuration-reference.md)，从 schema 自动生成。SDK 仅在独立进程做执行、取消、恢复和权限验证，生产仍使用 JSON/RPC 子进程。

新任务书无论长短直接传正文，harness 自动冻结保存后启动子 Agent，一次调用完成派发：

```javascript
task_submit({
  agent: "luban",
  task: "目标：实现需求。\n范围：按现有模块接入。\n验收：执行相关测试并报告证据。",
  inputPaths: ["docs/需求.md"],
  outputPaths: ["out/实现报告.md"],
  scope: { shell: "guarded" },
  delivery: "handle"
})
```

`task` 与 `taskFile` 恰选一个；已有完整任务书可用 `taskFile:"tasks/实现任务.md"` 引用，文件相对调用者 cwd，原文在提交时冻结。不要为新任务先 Write 再提交；引用已有文件时，须等待其写入成功，不能把 Write 和提交并行发出。`inputPaths/outputPaths` 与完整的 `inputs/outputs` 分别互斥，模型生成简写时仍保留约束采样。批次 `sharedInputs/outputs` 同样支持路径字符串，`dependsOn:["impl"]` 表示须显式接受上游后才解锁。可缺输入、目录产物和 `ready/settled` 依赖仍用完整对象声明，详见 [分面工具规范](resources/core/tools-facets.md)。

### 场景一：派发编码任务

Leader 可在同次提交中选择上下文模式，避免执行者重新调查已经查明的事实：

```javascript
task_submit({ agent: "luban", task: "按已查明的调用链修复并验证", contextMode: "selected" })
task_submit({ agent: "fuxi", task: "结合讨论背景分析跨模块根因", contextMode: "fork" })
task_submit({ agent: "diting", task: "独立审核变更与证据", contextMode: "isolated" })
```

`selected` 交付用户要求、相关观察和待核验判断，去除重复读结果、常规调试日志及无关相邻计划；也可用 `contextRefs:["src/router.ts"]` 指定已读来源。每条保留来源与读取范围；相关长行按剩余预算完整传入，完整性标记与省略原因指导按需回读。历史指纹不代替当前新鲜度证明。大段原文随任务冻结，子 Agent 按需从 `amagi-task/<taskId>/context-evidence/` 回读。assistant 自称“已确认”仍属于待核验判断。自动识别不能保证任意历史零遗漏，关键约束应写入本次任务书；详见 [交接规则](resources/core/tools-facets.md)。`fork` 继承当前可见文本历史，省略模式保持 `isolated`。快照和模式沿现有契约冻结，子角色权限不变；来源已改变或不满足授权的资料会过滤并披露。`task_batch` 支持批次缺省和节点覆盖，延迟节点沿提交时快照启动。同一任务继续优先 `task_resume`。此阶段不改变 Advisor 的文本上下文路径。

真实模型对照使用 `node scripts/eval-dispatch-context.mjs --model <provider/model> --runs 3 --out <新输出目录>`，比较三模式的正确性、已读文件重复读取次数、完整派发墙钟时间及用量；场景是合成调查任务，结果不能直接当作真实项目的固定提速比例。

```text
# 让 Leader 自然路由（Leader 用 LLM 判断角色）
帮我实现一个用户登录接口

# 或确定性路由（绕过 LLM，零延迟）
#luban 实现一个用户登录接口，JWT 鉴权
```

回流示例：

```text
[task 3f2a91eb luban · execution=done · settlement=ready · acceptance=unreviewed]

## 摘要
已在 src/auth/login.ts 实现 JWT 登录接口...

## Artifact 路径
./agent-outputs/luban/self-test-report.md

## 验证/自检结果
- 构建：PASS，npm run build
- test：PASS，npm test（3 passed）

📋 证据（自动采集·摘要）
• 测试 npm test → ✓ 通过（0.2s）
• 归因：任务期间新增/变化 1 处；own 1，multi 0，窗口内未归因 0，↔sib 0，⚠ext 0
  登记路径：src/auth/login.ts
• diff（任务写面登记 1 处，登记覆盖有限）：1 file changed, 85 insertions(+)
[采集详情] <任务 artifact 目录>/evidence.md（按需 read）
```

### 场景二：阶段级审核与“少改多返”

```text
# 1. 同一父任务的独立实现切片一次批量派发
amagi_resource({ resource: "tools", enableFacet: "batch" })
task_batch({ nodes: [
  { id: "backend", agent: "luban", task: "完整实现并自验后端切片" },
  { id: "frontend", agent: "luoshen", task: "完整实现并浏览器验证前端切片" }
] })

# 2. Leader 等整批完成并集成验证；高风险阶段只审核一次
#review 审核当前阶段的集成 diff 与验证证据

# 3. 少量明显 finding：Leader 直接修并验证，不再开 Agent 回合
#    findings 较多：合并成一个修复批次，resume 原 Agent 一次处理
task_resume({ handle: "3f2a91eb", message: "一次处理以下合并 findings，完成后针对性自测：..." })
```

### 场景三：后台并行调研

```text
# 后台派发，不阻塞 Leader

task_submit({ agent: "baize", task: "探索 src/ 目录结构，输出模块依赖图", delivery: "handle" })
task_submit({ agent: "baize", task: "调研 pi extension API 最新文档，结论附来源锚点", delivery: "handle" })

# Leader 继续读 artifact / 写计划...
# 后台完成时自动回流：
# [后台子Agent完成 baize/91bc...] ...
```

### 场景四：blocked 提问

```text
# 派发一个信息不足的任务
#luban 实现支付功能

# luban 输出 blocked（因为缺少支付渠道、金额逻辑等关键信息）：
<!--AMAGI:BLOCKED-->

STATUS: blocked
QUESTIONS:
  1. 支持哪些支付渠道（微信/支付宝/银行卡）？
  2. 金额计算是否含税？
PARTIAL: 已创建 src/payment/ 目录结构

# Leader 答复后续接：
task_resume({ handle: "3f2a91eb", message: "答复：1. 微信+支付宝 2. 含税。请继续" })
```

### 场景五：查看子 Agent 工作

```text
# 查看某个任务的状态和最近活动
task_query({ handle: "3f2a91eb", view: "summary" })

# 按需读取输出；完整会话用 /amagi session <任务前缀>
task_query({ handle: "3f2a91eb", view: "output" })
```

---

## 架构概述

```
amagi-pi/
├── package.json                      # pi manifest（extensions/skills/prompts/themes）与 scripts 门禁
├── tsconfig.json                     # TypeScript 编译期检查配置（target es2023 / nodenext）
├── .dependency-cruiser.cjs           # 架构分层防循环与隔离依赖断言配置
├── extensions/
│   └── amagi-core/                   # 核心扩展（jiti 运行时加载，严格类型与依赖门禁）
│       ├── index.ts                  # 单一装配入口：主进程全量；子进程最小化注册
│       ├── task-tool.ts              # task 工具（sync/background/resume/batch/wait/cancel）+ query_task
│       ├── task-service.ts           # 任务控制面薄服务层（统筹同步与异步子任务）
│       ├── task-run.ts               # 子 pi 进程 spawn 引擎、环境变量最小化与生命周期管理
│       ├── task-background.ts        # 异步后台任务链（准入占位与自动续跑门控）
│       ├── task-resume.ts            # 会话恢复执行链（磁盘回填与断路器检查）
│       ├── group-scheduler.ts        # batch/DAG 编排调度器（每批最多 32 节点）
│       ├── orchestrate.ts            # 高级编排模式展开器（fanout/pipeline/fork 等）
│       ├── admission.ts              # 共享 FIFO 准入队列（按 provider/model 分池，默认每池 4 并发，跨所有派发模式）
│       ├── answer-queue.ts           # blocked 提问协议（答复后 resume 续接）
│       ├── task-registry.ts          # taskId→sessionId/状态/结果 注册表（快照与持久化）
│       ├── agents-loader.ts          # agents/*.md frontmatter 发现与 symlink 防御
│       ├── model-resolver.ts         # 多级覆盖模型解析 + thinking 档位近似纠错
│       ├── guards.ts                 # 阻断式安全守卫 + 探针引导 + 保护路径检查
│       ├── edit-guard.ts             # exact match 失败内容自愈与模糊替换护栏
│       ├── edit-diagnostics.ts       # edit/write 写盘成功后 LSP 推送式诊断注入
│       ├── edit-override.ts          # 内置 edit 工具同名覆盖（正则替换与多文件提示）
│       ├── write-override.ts         # 内置 write 工具同名覆盖（写盘后联动 LSP 诊断）
│       ├── bash-override.ts          # 内置 bash 工具同名覆盖（原生 cwd 参数支持与耗时提示）
│       ├── shell-lexer.ts            # 纯函数零依赖 Shell 词法解析器
│       ├── resource-reader.ts        # amagi_resource 工具（沙箱读取 canonical 资源）
│       ├── leader-prompt.ts          # L0 system prompt 装配器（before_agent_start）
│       ├── continuation.ts           # compact 续接高保真摘要（session_before_compact）
│       ├── context-event.ts          # L1 自动供给与已归档采集降噪（保护显式正文）
│       ├── context-budget.ts         # 派发前 Token 预算与上下文超限预估器
│       ├── input-router.ts           # 确定性路由 #角色 / #review / #board（input 事件）
│       ├── routing-stats.ts          # 路由记忆增量聚合与断路器熔断管理
│       ├── status-ui.ts              # TUI 状态栏/widget 渲染器（任务实况）
│       ├── panel-model.ts            # 常驻四块面板纯函数模型（概要/角色/任务/结算）
│       ├── panel-widget.ts           # 常驻面板交互组件与 ANSI 分块渲染
│       ├── shortcuts.ts              # 快捷键（⌥R diff 审查 / ⌥T 任务部件，兼容 ctrl+shift+r/b）
│       ├── amagi-commands.ts         # /amagi 斜杠命令层（board/tasks/review/session/help）
│       ├── ui-config.ts              # amagi.json ui 段配置读取器（键位覆盖/面板预算）
│       ├── ui-shared.ts              # TUI 共享工具（按键符号、ANSI 盒子与纯函数布局）
│       ├── mcp-client.ts             # MCP 后端选择与 http/stdio 兼容 transport
│       ├── mcp-native.ts             # 公开宿主 API 的原生 MCP 接入与兼容工具入口
│       ├── mcp-config.ts             # configured MCP 配置解析、角色路由与凭据安全传递
│       ├── mcp-override.ts           # mcp_call 工具参数形状自动纠错拦截器
│       ├── workspace-preflight.ts    # 受信任工作区有界快照（240 项 / 深度 4 / 24 KiB）
│       ├── finalizer.ts              # 确定性收尾（基线复跑 + 一次自动修复；truncated 证据升级 done）
│       ├── evidence.ts               # 证据自动化（基线命令探测执行 + git diff --stat 采集）
│       ├── artifact.ts               # 任务交付物全局标准化落盘管理（~/.pi/agent/amagi/artifacts/）
│       ├── result-fold.ts            # 旧独立折叠 helper（生产收尾链已停用）
│       ├── worktree.ts               # Git worktree 隔离执行环境生命周期管理
│       ├── journal.ts                # 派发事务日志落盘 + 中断恢复（dispatch/settle 差集追踪）
│       ├── reliability.ts            # 可靠性组件（停滞看门狗、断路器、幂等去重）
│       ├── watchdog.ts               # 进程活性看门狗与静默无事件兜底
│       ├── terminal-doctor.ts        # 终端健康检查（色板、模型画像与超时修复提示）
│       ├── session-viewer.ts         # 子会话 JSONL 只读查看器
│       ├── session-backfill.ts       # 重启后的磁盘会话元数据回填器
│       ├── session-repair.ts         # 400 孤儿 tool 消息序自愈修复器
│       ├── child-settle-exit.ts      # 子进程结算后权威自我退出调度器
│       ├── evolution-log.ts          # 框架自进化摩擦点全局持久化日志
│       ├── evolution-tool.ts         # amagi_evolution 工具入口
│       ├── handbook-tool.ts          # amagi_handbook 战术手册生命周期淘汰工具
│       ├── rpc-pool.ts               # 通用常驻子进程池（WAL 日志、RPC 协议）
│       ├── rpc-pool-tool.ts          # 独立 rpc_task 工具与控制面适配器（支持 adjust）
│       ├── lsp-client.ts             # 动态 stdio JSON-RPC LSP 客户端与连接池
│       ├── lsp-tool.ts               # 单工具 lsp 入口（diagnostics/definition/hover/symbols 等）
│       ├── lsp-config.ts             # LSP 语言服务器动态探测与配置合并
│       ├── lsp-types.ts              # LSP 共享类型定义
│       ├── lsp-defaults.json         # 内置 8 种主流语言服务器探测配置
│       ├── workflow-board.ts         # ⌥W 全屏工作流看板（支持三级下钻会话面板，兼容 ctrl+shift+w）
│       ├── data-dir.ts               # 运行数据目录解析（~/.pi/agent/amagi/data/）
│       └── webui/                    # WebUI 服务端实现（8 个 TS 模块）
│           ├── server.ts             # 扩展内 HTTP + WebSocket 服务端
│           ├── agent-session.ts      # 子 Agent 会话查询与交互数据面
│           ├── round-tracker.ts      # 本轮用时数据面（round_state 事件）
│           ├── events.ts             # WebSocket 下行事件信封流与断线回放
│           ├── history.ts            # 历史会话 JSONL 分页解析与凭据脱敏
│           ├── registry.ts           # 进程端口与 capability 注册表
│           ├── task-panel.ts         # WebUI 常驻编排实况面板数据面
│           └── usage-store.ts        # Token 用量与缓存命中率内存聚合器
├── webui/                            # WebUI 前端 SPA 应用（原生 TS + Vite 构建，零框架依赖）
│   ├── package.json                  # 前端构建配置（npm run build:webui）
│   ├── src/                          # 前端源码（17 个 TS 模块 + 2 个 CSS 样式）
│   └── tests/                        # 前端单元与集成测试（Vitest）
├── agents/                           # 五个特色中心角色定义（baize/luban/luoshen/diting/fuxi）
├── prompts/                          # 19 个 pi prompt templates（init、load-session、save-session 等）
├── skills/                           # 10 个 SKILL.md（Agent Skills standard）
├── resources/                        # canonical 规则/模板/知识库（含唯一的 L0 模板 core/l0-template.md）
├── rules/                            # 兼容说明（规则权威源在 resources/core/）
├── profiles/                         # 模型分档（tiered.json / inherit.json）
├── themes/                           # amagi-dark 主题（themes/amagi-dark.json）
├── schemas/                          # amagi.json JSON Schema（schemas/amagi-config.json）
├── docs/                             # 协议与架构文档（含 docs/adr/ 架构决策记录）
├── scripts/                          # 辅助工程脚本
│   ├── fix-terminal-bold-color.mjs   # iTerm2 粗体过暗色板一键修复
│   ├── journal-abandon.mjs           # 残留单条 journal 清理工具
│   └── generate-harness-reference.mjs # 由配置 schema 生成 configuration-reference.md（docs:check 防漂移）
└── tests/                            # node:test 隔离回归与原生 SDK 验证
```

Extension 装配逻辑（`index.ts`）：

- **子进程**（`AMAGI_SUBAGENT=1`）：注册 guards、watchdog、`amagi_resource` 和通用 MCP 元工具（mcp_call/mcp_list_tools）；跳过 task/query/L0/路由等编排能力以防递归。
- **主进程**：guards + 四稳定工具/amagi_resource + 按需 batch 分面 + 通用 MCP 元工具 + 确定性路由 + 命令/快捷键 + L0 注入 + compact 续接 + status-ui；legacy 面只为旧会话兼容。

### 静态资源统计

| 资源 | 数量 | 来源 |
|------|------|------|
| agents | 5 | `agents/*.md`（baize/luban/luoshen/diting/fuxi 五特色角色） |
| prompts | 19 | `prompts/*.md` |
| skills | 10 | `skills/*/SKILL.md` |
| resources | 58 | `resources/`（amagi-pi 自主管理的 canonical 规则/模板/知识库，文件数） |
| rules | 1 | `rules/README.md`（兼容说明，规则权威源在 `resources/core/`） |

---

## 开发

### 开发命令与工程门禁

工程配置了完整的 TypeScript 类型检查、依赖架构合规与测试门禁（参见 `package.json` scripts 及 `docs/adr/0001-typecheck-gate.md`）：

```bash
# 运行全部默认单测（排除需要真实模型的静态资源冒烟）
npm test
# 所有默认单测与 CI 使用相同集合

# 运行单测试文件
node --test tests/task-tool.test.mjs

# TypeScript 类型检查（扩展与测试类型契约严格门禁）
npm run typecheck

# 架构依赖合规检查（扫描 extensions/amagi-core，防止循环依赖与反向依赖）
npm run depcruise

# CI 综合质量门（串行执行 typecheck → depcruise → node --test 排除冒烟）
npm run test:ci

# WebUI 前端生产构建（npm --prefix webui run build）
npm run build:webui
```

测试覆盖 agents 加载、registry、admission 准入与取消、group-scheduler 批量/DAG、task 工具（含 batch/wait/cancel）、guards 正反例、resource 沙箱、profiles/model-resolver、blocked 检测与 answer-queue、input-router、status-ui/workflow-board/shortcuts、MCP 原生 SDK 与兼容后端、原生会话树恢复、工具环境与元数据、workspace-preflight、evidence/finalizer、rpc-pool、watchdog、worktree、webui、lsp 等。文件数与用例数按当前门禁结果统计。测试用 `mkdtemp` 隔离，不触碰真实 `~/.pi/` 数据。

### 架构决策记录（ADR）

重大架构调整与工程门禁遵循 ADR 记录规范，详见 `docs/adr/`：
- `ADR-0001`：编译期类型门禁（`npm run typecheck`）与依赖方向机器断言（`npm run depcruise`）
- `ADR-0002`：L0 注入面预算护栏与 token 上限约束

### 运行数据与统计

运行时数据（traces / routing-stats.json / agent-stats.ndjson / rpc-sessions / rpc-wal）默认写入 `<PI_CODING_AGENT_DIR || ~/.pi/agent>/amagi/data/`，与包生命周期解耦（`pi update` 重装不再清空路由记忆等数据资产）；首次解析时自动把包内 legacy `data/` 的已知条目复制到新目录。`AMAGI_DATA_DIR` 可整体覆盖数据目录；单项环境变量 `AMAGI_TRACES_PATH` / `AMAGI_ROUTING_PATH` / `AMAGI_STATS_PATH` / `AMAGI_RPC_SESSION_DIR` / `AMAGI_RPC_WAL_DIR` 优先级更高。token/cost 统计为每任务一行 NDJSON（taskId / agent / model / status / input / output / cost / durationMs）。

---

## 限制与已知风险

### 平台

- **Windows / NFS 未验证**：在 Windows 和网络文件系统（NFS）上的行为未经测试。会话 JSONL 落盘路径（`~/.pi/agent/sessions/`）在 Windows 上可能需要调整。
- **macOS / Linux** 为主要开发和测试平台。

### pi 引擎限制

| 限制 | 影响 | 缓解 |
|------|------|------|
| MCP 接入与授权须区分 | 连接所有权不等于任务授权；复杂名称无法从公开元数据反推原名 | 默认由 pi 原生管理连接，事件层执行路由与冻结授权；`mcp_call` 为兼容入口，自研后端仅用于明确兼容情形 |
| `--name` 不是 SessionHeader 字段（pi 0.83.0） | 名称以 `session_info` 条目持久化，picker 可按名筛选；程序接口不宜把显示名当稳定 ID | resume 使用 task-registry 的 taskId→sessionId 映射 |
| 人设不落盘 | resume 时角色 system prompt 不随会话恢复 | 每次 resume 自动重传角色 prompt（`--append-system-prompt`） |
| 角色进程没有兄弟间 P2P | Leader 负责契约接力与任务调整 | queued/running 用 `task_control steer`，blocked/error 用 `task_resume`；冻结任务书与权限不改变 |

### 已知损失（相对 Claude Code 源插件）

- **SubagentStop sync-project-docs**：依赖 Claude transcript 格式，pi 侧放弃。用显式 artifact 契约替代。
- **强制审核链**：源插件的强制审核链（实现→审核→Git 提交）改为阶段级风险驱动——高风险大阶段在全部实现、集成与验证后由 diting 合并审核一次；低风险阶段由 Leader 验收。少量明显问题 Leader 直接修，问题多才合并回派；不建立实现↔审核自动循环。这是设计决策，非缺陷。

### 防御边界声明

命令与提交守卫是**有界 lexer 安全网**，不是系统安全边界；刻意对抗仍可能绕过。执行纪律只通过 prompt 和失败结果提示引导，不阻断普通工具调用。JSON 校验发生在写后，不提供事务或自动回滚。深度防御依赖系统层沙箱（二期 T3-1 计划，当前未实现）。

---

## 致谢

- 起源：[amagi](https://github.com/runrunrain/amagi-opencode-plugins-marketplace) 1.5.165（Claude Code 插件；移植后两者独立演进，不再同步）
- 引擎：[pi coding agent](https://github.com/earendil-works/pi-coding-agent)
