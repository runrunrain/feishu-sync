# Metadata Schema 参考

先确认你在哪种场景：派发链内的 metadata 由 harness 自动写，你只需知道字段含义；手动/归档场景才需要按「通用 Schema」手写。

## Harness 托管 artifact metadata（派发链内自动落盘，不必手写）

amagi task 派发链在任务终态自动落盘 `result.md + metadata.json` 到全局 artifacts 目录（`<agentDir>/amagi/artifacts/<taskId>/`）。该 metadata.json 由 harness（amagi-core artifact/finalizer）写入，字段以实现为准：

```json
{
  "formatVersion": 1,
  "taskId": "string",
  "agent": "agent 名称（如 luban）",
  "model": "实际解析的模型 spec（可缺省）",
  "status": "done|error|blocked|cancelled|truncated",
  "blocked": false,
  "blockReason": "questions|needs-handoff（仅 blocked 时）",
  "sessionId": "子会话 id（可缺省）",
  "durationMs": 12345,
  "startedAt": 1760000000000,
  "endedAt": 1760000012345,
  "rounds": 1,
  "outputBytes": 1024,
  "cwd": "任务工作目录（项目归属）",
  "upstreamArtifactReferences": ["派发契约中的上游 artifact 引用"]
}
```

`upstreamArtifactReferences`：harness 在派发时从任务文本中的 artifact 引用自动采集（resume 轮次合并父记录的引用），无引用时为空数组 `[]`。Leader 必须在派发文本中提供路径；报告正文列出实际使用的上游引用，不会事后改变托管 metadata 的采集结果。同一 taskId 重复收尾不会重复写（幂等）。

## 通用 Schema（手动/归档场景）

不在派发链内、或 Leader 要求落盘到 projects-memory 归档树时，按下述 schema 手写。各角色的 metadata.json 都包含这些基础字段（`upstreamArtifactReferences` 同样必填，见 SKILL.md）：

```json
{
  "taskId": "string (必须)",
  "timestamp": "ISO 8601格式 (必须)",
  "agent": "角色 ID：baize|luban|luoshen|diting|fuxi (必须)",
  "projectId": "项目ID (必须)",
  "taskBrief": "任务简述 (必须)",
  "status": "completed|in-progress|failed (必须)",
  "upstreamArtifactReferences": [],
  "tags": ["标签数组 (可选)"],
  "relatedFiles": ["相关文件数组 (可选)"],
  "nextSteps": {
    "suggestedAgent": "下一个Agent (可选)",
    "suggestedAction": "建议行动 (可选)"
  }
}
```

手动 `status` 只说明该产物的完成状态，不等同于运行时状态或语义验收。无上游时 `upstreamArtifactReferences` 为 `[]`。未知项目归属先定位，不填示例项目 ID。

验证可增加 `validationEvidence`：`buildStatus` / `testStatus` 用 `passed|failed|not_run|not_applicable`，`browserVerification` 用 `verified|failed|not_run|not_applicable`；`commands` 保存实际的 `command`、`cwd`、`exitCode`、`summary`。未执行项写原因，不造 exitCode。此扩展仅用于手动归档，不改 harness schema；旧字段和值保持读取兼容。

角色扩展字段按实际任务选择，不因模板存在就必填；`butterflyRounds` 为可选整数，只填写实际分析轮数，示例中的 1 不是要求；历史 `butterflyRounds` 与 delta action 继续可读，新反思遵循手册真实操作策略。

## Agent特定字段（v2 五角色，按角色 ID 归档）

### 白泽（baize）
```json
{
  "discoveredFiles": ["发现的关键文件"],
  "dependencyGraph": "依赖关系描述"
}
```

### 伏羲（fuxi；设计/攻坚/反思三态）
```json
{
  "designVersion": "v1.0",
  "recommendedSolution": "推荐方案",
  "alternatives": ["备选方案"],
  "reflection": {
    "reflectionId": "REF-20260107-103000",
    "triggerSource": "触发Agent",
    "triggerScenario": "触发场景",
    "priority": "P0|P1|P2",
    "butterflyRounds": 1,
    "extractedInsights": [{ "id": "INS-001", "category": "分类", "value": "高/中/低" }],
    "deltaUpdates": [{ "action": "add|update-count|deprecate", "target": "目标文件", "section": "章节" }]
  }
}
```

### 鲁班（luban）
```json
{
  "changedFiles": ["变更文件列表"],
  "testResults": {
    "compilation": "passed|failed|not_run|not_applicable",
    "functionality": "passed|failed|not_run|not_applicable",
    "boundary": "passed|failed|not_run|not_applicable",
    "performance": "passed|failed|not_run|not_applicable"
  }
}
```

### 洛神（luoshen）
```json
{
  "changedFiles": ["变更文件列表"],
  "stateCoverage": "loading/empty/error/disabled/success/长内容/窄宽/焦点覆盖情况",
  "visualVerification": {"method": "真实浏览器交互验证（工具按任务选择）/读图确认", "result": "通过情况与盲区声明"}
}
```

### 谛听（diting）
```json
{
  "reviewResult": "approved|rejected|conditional",
  "reviewMode": "quick|full",
  "reviewRound": 1,
  "totalIssues": 5,
  "criticalIssues": 1,
  "relatedCoderTask": "20260107-160000-skill-system"
}
```

## 历史归档字段（旧岗位 artifact，读侧兼容，不迁移）

以下字段出现于旧岗位历史归档（thinker/manager/tester/researcher 等 name 目录），读侧继续按原 schema 解析；新产出不再写入这些目录（manager/tester 归鲁班、researcher 归白泽、thinker 归伏羲反思态）：

```json
{
  "gitOperation": "commit|push|merge|revert（旧 manager/太白金星）",
  "testStrategy": "测试策略（旧 tester/孙悟空）",
  "researchTopic": "调研主题（旧 researcher/文曲星）"
}
```
