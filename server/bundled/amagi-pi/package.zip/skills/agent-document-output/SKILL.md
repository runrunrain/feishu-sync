---
name: agent-document-output
description: |
  Agent文档输出与 artifact 持久化规范。任何 Agent 完成任务、阶段交接、失败中止、报告产出、implementation report、review report、handoff note、save output、document artifact、persist output、metadata.json 写入时都应使用本技能。用于把主文档、metadata、路径命名和索引更新统一落盘。不要用于普通聊天回复、未形成可复用 artifact 的临时说明，或替代具体业务技能的执行流程。
version: "3.2"
author: amagi
allowed-tools: write read bash
compatibility: pi
---

# Agent 文档输出

负责主文档落盘、元数据、上游引用与交接；内容结构由任务或对应业务技能决定。普通聊天无需生成 artifact。文字遵循 [共用规则](reference/writing-rules.md)。

## 托管与手动归档

| 场景 | 处理 |
|---|---|
| task 派发链内 | 主文档写到任务指定路径；终稿返回路径、实际引用和验证摘要。harness 在终态自动写入 `<agentDir>/amagi/artifacts/<taskId>/result.md` 与 `metadata.json`，不手工覆盖托管元数据。 |
| 链外任务或另行要求归档 | 按下方路径规则保存主文档，按 [metadata schema](reference/metadata-schema.md) 写手动元数据。 |

托管引用来自派发任务文本，不是事后从报告正文提取。Leader 在派发时提供完整上游路径；执行者在产出中列明实际使用的引用。运行时结束、产物归档、任务验收是不同状态，`done` 或文件存在不等于验收通过。

## 路径与命名

1. 用户或任务指定的路径优先，其次使用 execution-plan、workflow 等技能明确的产物路径。
2. 需要项目归档定位时，从工作目录向上查找 `{WORKSPACE_ROOT}/projects-memory/projects/registry.json`。`WORKSPACE_ROOT` 是包含 `projects-memory` 的目录；`PROJECTS_DIR` 是 registry 所在的 `projects` 目录。
3. 读取 `activeProject` 及对应 `projectPath`，归档根为 `{PROJECTS_DIR}/{activeProject}`。registry 不存在时，使用已确认的项目根；字段损坏或项目归属不明时先报告，不能误写其他项目。
4. 默认手动归档路径：`{PROJECT_META_ROOT}/agent-outputs/{角色ID}/{task-id}/`。复用已提供的任务 ID；否则生成 `YYYYMMDD-HHmmss-{kebab-case简述}`。

| 角色 ID | 常用主文档 |
|---|---|
| baize | research-report.md |
| luban | self-test-report.md；任务需要时用 document.md 等 |
| luoshen | design-impl-report.md |
| diting | review-report.md |
| fuxi | design-doc.md / reflection-report.md |

历史别名目录保留读取兼容；新归档使用这五个角色 ID。详见 [命名约定](reference/naming-conventions.md)。

## 落盘程度

按 canonical `resources/core/collaboration/workflow-rules.md` 的 Task / Artifact Contract 执行；pi 中通过 `amagi_resource` 按资源 ID 读取。

| task_tier | 输出要求 |
|---|---|
| simple | 默认不强制落盘；显式要求 `output_form=落盘` 时保存。 |
| medium | 主文档与元数据；链内元数据由 harness 写入。 |
| complex | 主文档、元数据及计划；仅 requirement-analysis / execution-plan 产物按下节维护计划注册表。 |

缺失 tier 按 medium 处理。手动 metadata 的基础字段在 schema 中统一定义，simple 被要求归档时也使用同一最小字段集，不复制另一套格式。

## 上游与验证

- 先读取任务指定的 `required_artifacts`。缺失时停止依赖它的工作，保存已完成部分、缺失清单与恢复条件；不凭摘要猜出关键依据。可继续无依赖的工作。
- 主文档列出实际使用的上游路径，无上游时说明无；手动元数据用空数组。托管元数据保留派发契约引用，与实际使用清单可能不同。
- 命令验证写命令、工作目录、退出结果和关键观察；浏览器验证写页面、操作与观察；只读调研写来源及覆盖范围。
- 未运行的检查写“未执行”及原因；不适用说明为何不需要。模板不得预填成功，不要求每个任务都构建、压测或浏览器验证。
- 状态和证据如实保留；已完成实现但尚未验收时，不将两者合并成“全部通过”。

可选模板：[调研报告](templates/explorer-report.md)、[实现自检](templates/coder-self-test.md)。按任务裁剪，技术结论和证据不能因精简而丢失。

## 计划注册表

仅 complex 档的 requirement-analysis / execution-plan，或任务显式要求时，更新 `{PROJECT_META_ROOT}/agent-outputs/plan-registry.json`；其他输出不创建空注册表。

1. 读取现有数组；不存在时新建空数组。
2. 仅将本次明确替代的同类型、同任务范围条目标为 `superseded`，不覆盖其他范围的 active 计划。无法确定替代关系时保留原条目。
3. 追加条目并回读 JSON：

```json
{
  "id": "{type}-{timestamp}",
  "type": "requirement-analysis | execution-plan",
  "path": "主文档所在的实际目录",
  "timestamp": "ISO 8601 时间",
  "status": "active",
  "summary": "目标、范围及关键结论",
  "phases": [],
  "relatedPlanId": ""
}
```

需求稿 `phases` 为 `[]`；执行计划使用 `[{"phase":"阶段名","taskCount":1,"status":"pending"}]`，数量按真实计划填写。`relatedPlanId` 只引用同一任务范围的相关计划。摘要用于定位，不复制任务全文、不编造工时；详细执行状态以 workflow 为准。

主报告按 canonical `resources/core/common/agent-output-specification.md` 覆盖适用的任务 ID、变更文件、决策、上游引用、验证、回滚和剩余项；可合并表达，不能省掉影响交接的信息。无后续动作时写明无需追加，不虚构建议。

## 返回与检查

对话返回完成情况、主文档路径、上游引用、验证摘要与必要的后续动作。simple 未落盘可省路径；不存在的下一步不凑段落。

交付前确认：指定文件可读、引用能定位、手动 JSON 可解析、验证结果有依据、未完成项清楚。托管产物写入失败时报告实际状态，不宣称已持久化。

元数据字段只维护在 [schema](reference/metadata-schema.md)；派发模板与验收依据分别为 canonical `resources/core/collaboration/subagent-mode.md`、`resources/core/common/quality-standards.md`。
