# 视频分析工具选择策略

按平台和任务类型选工具；`video_subtitle_extractor.py` 位于技能目录根。

## 工具选择策略

```
视频分析任务
    │
    ├─ B站/YouTube视频
    │   └─ 使用 video_subtitle_extractor.py
    │       ├─ 有字幕 → 直接提取
    │       └─ 无字幕 → --whisper 转写
    │
    ├─ 论文检索
    │   └─ 直接抓取（bash curl 等；pi 无内置 WebFetch）
    │       ├─ arXiv HTML: https://arxiv.org/html/{id}v1
    │       └─ arXiv 搜索: https://arxiv.org/search/?query=
    │
    └─ 其他网页
        ├─ 首选: 直接抓取
        ├─ 备选: mcp_call(web-reader/webReader)
        └─ 最后: mcp_call(web-search-prime/web_search_prime)
```
