---
name: amagi-video-analysis-enhanced
description: |
  增强版视频分析技能。用户要求分析视频、总结 B站/YouTube/网页视频、提取字幕/音频内容、处理无字幕视频、生成视频学习笔记、视频内容提取、video analysis、transcribe video、summarize a talk/lecture 时应使用；支持 yt-dlp、字幕、Whisper 转写、论文/官方资料补足和高质量中文技术文档。不要用于纯文本文章总结、普通 PDF/电子书转换，或未提供视频/音频/可访问链接的任务。
version: 3.1
author: 天城
compatibility: pi
---

> pi 适配：canonical 资源用 `amagi_resource` 工具按资源 ID 读取（pi 不自动展开 `@` 引用）。

# 视频内容分析技能

根据用户用途提取视频内容，产出摘要、学习笔记或深度分析。默认先满足视频本身的阅读需求；外部研究按任务需要补充。文字遵循 [共用规则](../agent-document-output/reference/writing-rules.md)，证据与结构见 [输出规则](references/output-quality-rules.md)。

## 能力

| 能力 | 说明 |
|-----|------|
| 多平台适配 | B站、YouTube、网页视频等平台差异化处理 |
| 字幕提取 | 优先使用作者字幕、CC 或 AI 字幕；弹幕属于观众评论，不能替代讲话内容 |
| 音频转写 | 无字幕时使用 Whisper 兜底 |
| 论文补足 | 用户需要深度研究、核实关键主张或理解必要背景时，读取论文及官方资料并单独标注 |
| 高质量输出 | 先说明核心内容，再按读者需要展开；表格和图按关系需要使用 |

## 工具与依赖

| 工具 | 用途 | 使用原则 |
|-----|------|---------|
| 直接抓取（bash `curl` 等） | 获取普通网页内容 | 适合可直接访问的文章/页面（pi 没有内置 WebFetch 工具） |
| mcp_call（server: web-reader / tool: webReader） | 增强网页读取 | 直接抓取失败或内容不完整时使用 |
| mcp_call（server: web-search-prime / tool: web_search_prime） | 搜索补足 | 直接访问失败、论文/资料补足时使用 |
| `<SKILL_ROOT>/video_subtitle_extractor.py` | 视频字幕/音频提取 | 视频链接优先路径；参数详见下方 |
| yt-dlp | 视频/字幕下载 | `pip install yt-dlp` |
| whisper | 音频转写 | `pip install openai-whisper`，仅无字幕时启用 |

`video_subtitle_extractor.py` 位于本技能目录根（与 SKILL.md 同级），基本用法：

```bash
python "<SKILL_ROOT>/video_subtitle_extractor.py" "<视频URL>" --cookie "<私有Cookie文件路径>"
python "<SKILL_ROOT>/video_subtitle_extractor.py" "<视频URL>" --whisper -o "output.txt"
```

其余参数：`--whisper-model`（默认 base）、`--no-cleanup`（保留临时文件）。

平台选择见 `references/tool-routing.md`；提取命令见上例，错误切换见下方工作流。

### B站 Cookie 的存放

Cookie 等同登录凭据，请用户把它放在插件仓库和插件安装目录之外（如个人配置目录或临时工作目录），这样它不会被打包或误提交。插件包本身不带真实浏览器 Cookie；需要登录态时，通过 `--cookie` 显式传入本机私有 Netscape cookie 文件路径。

## 核心工作流

### 1. 初始评估

1. 接收视频/音频链接与输出要求。
2. 识别平台、可访问性、字幕/转写可能性与风险。
3. 选择提取路径：平台字幕/yt-dlp -> Whisper -> 直接抓取/web-reader -> 搜索补足。
4. 选择摘要、学习笔记或深度研究；长任务维护必要进度，提取失败影响覆盖时说明限制。

### 2. 内容提取

| 平台 | 首选策略 | 兜底策略 |
|-----|---------|---------|
| B站 | yt-dlp + Cookie 下载 AI/CC 字幕 | 音频提取 + Whisper |
| YouTube | yt-dlp 下载字幕 | Whisper 转写 |
| 其他网页视频 | 直接抓取 / web-reader | 搜索相关资料并标注局限 |

每个工具最多重试 2 次，切换工具前记一笔失败原因。报告简述字幕/转写来源、覆盖范围和影响结论的限制；不逐条抄写工具尝试。未获取字幕或音频时，页面简介和相关论文只能作为外部资料，不能声称已分析视频全文。

### 3. 内容分析

- 识别核心主题、主要话题、关键概念和技术细节。
- 提取结构化信息（概念、流程、实验数据、实践原则）。
- 保留事实出处：视频时间线、字幕片段、外部资料链接。
- 缺失或不确定的内容显式标注出来；如实写“视频未提及/未能确认”，比补一段看似合理的内容更有价值。

### 4. 论文检索与资料补足

用户要求研究或核实，或某项关键结论无法仅从视频判断时，再读取对应论文、官方文档或配套代码。按具体问题检索；不因视频涉及技术就自动展开完整论文综述。

将“视频所述”“外部资料补充”“分析判断”分开，分别保留时间戳、来源链接或推断依据。保留影响结论的实验条件、单位、基线及不利结果，不凭需要填入准确率或提升幅度。

### 5. 输出组织

- **摘要**：核心主题、必要要点、来源与覆盖限制；不强制背景、实验、展望等章节。
- **学习笔记**：围绕概念和过程组织，按需补关键例子、时间戳及术语说明。
- **深度研究**：按研究问题组织方法、证据、比较和局限；使用 [可裁剪模板](templates/analysis-report-template.md)。没有材料的章节省略，未知事项不补造。

## 输出保存

按任务指定的形式和路径交付。仅要求口头摘要时不强制生成文件；需要 artifact 时按 [归档规则](../agent-document-output/SKILL.md) 保存。标题使用具体主题，默认不写宣传性副标题。

已安装并配置的 `amagi-file-organizer` 可在授权范围内使用；缺少整理工具不影响直接保存，也不需要在内容正文中写“未整理”。

## 常见错误处理

| 错误 | 处理 |
|-----|------|
| yt-dlp 失败 | 检查 Cookie/字幕列表；失败则 Whisper |
| 字幕为空 | 切换音频转写 |
| 直接抓取 403 | 切换 web-reader 或浏览器/搜索补足 |
| Whisper 失败 | 尝试更大模型或报告音频质量限制 |

## 使用示例与参考

| 资源 | 用途 |
|-----|------|
| `references/tool-routing.md` | 平台路由、yt-dlp/Whisper 命令、失败切换 |
| `templates/analysis-report-template.md` | 深度分析报告模板 |
| `references/examples.md` | B站 Cookie、论文补足、无字幕处理示例 |
| `references/output-quality-rules.md` | 文档质量、保存整理、错误回退和参考标准 |
