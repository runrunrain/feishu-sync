# 迭代深化协议

本文件只维护探索任务、证据交接和深化判断。输出文件选择与验收统一见 [output-generation-rules](output-generation-rules.md)，字段见 [output-schema](output-schema.md)，不在委派模板中复制整套规则。

Leader 将占位符展开成实际路径和范围后派发；explorer 对应 baize，writer 对应 luban。下游读取明确列出的 required artifacts，不能以摘要替代或扫描混有旧任务的整目录。

## Round 0 Explorer Prompt 模板

```text
角色：白泽 baize，负责只读探索项目代码。
目标：为 {PROJECT_CODE_PATH} 的 {SCOPE} 建立可回源的知识依据。
输入：{当前需求、现有索引及其他 required_artifacts 的完整路径}
输出：{本轮报告完整路径}
权限：项目代码只读；仅允许写上述报告，不改源码或知识库。

按任务范围核对技术栈与构建、组件布局、架构与数据流、API 与接口、项目约定、导航与证据候选。
检索线索见 {SKILL_PATH}/references/detection-patterns.md；关键结论需读取命中上下文。
多语言按实际职责覆盖，规范只写有证据的内容，不凑类别或样本数量。

报告包括：
- 能回答任务问题的发现及来源；区分直接证据、间接证据和推断。
- 已读范围、采样方式与未覆盖项。
- 需要深化的问题、影响、已有证据及建议入手点；没有关键缺口时说明，无需凑建议。
- 实际使用的上游 artifact 路径。

完整发现落盘，返回结论摘要、路径、覆盖限制及必要的下一步。
```

## Round N 定向深化 Prompt 模板

```text
角色：白泽 baize。
项目：{PROJECT_CODE_PATH}；轮次：{ROUND_NUMBER}。
问题：{DIRECTION_NAME}，需要核实 {SPECIFIC_QUESTION}，影响 {IMPACT}。
范围：{模块、入口及允许读取的直接依赖}。
required_artifacts：{前序报告的完整路径}。
输出：{本轮报告完整路径}。

先读取前序证据，再补全指定缺口；不重复扫描已覆盖范围。
报告给出新增发现、来源、对旧判断的修正及理由、仍未解决的问题。
证据冲突时核对版本和适用条件，不因为本轮较新就自动覆盖。
源码只读，仅写指定报告。缺少必需输入时停止依赖该输入的工作并报告。
```

## 收敛评估指南

Leader 读取报告和证据后，合并重复问题，判断哪些缺口会影响知识准确性或当前查询。探索者自报“已覆盖”不是充分证据；检查关键入口、关系和未决项。

- 尚有高影响且可补证的缺口：定向深化，独立方向可同批派发。
- 关键问题已解答：结束探索并生成知识。
- 剩余内容重复、超出范围或不影响任务：说明理由后停止。
- 达到预算：全局 Round 0 后最多 3 轮；领域 Round 0 后最多 2 轮。保留未覆盖清单，不能称为完全收敛。

不以报告长度或“信息增量百分比”判断价值。配置、测试、fixture 是否需要深入，取决于它是否决定待验证行为。

判断摘要按需写：本轮解决的问题、剩余缺口、继续或停止的理由、下一步及其输入。实际轮次和预算来自任务，不凑满轮数。

## 知识累积规则

按 artifact 契约保存各轮报告，Leader 在对话中只保留结论和路径。整合报告保留来源映射和未决分歧，不能用缺少来源的摘要替代原证据。

- 补充细节：合并到对应问题并保留来源。
- 修正旧结论：注明新证据及旧结论失效范围。
- 无法判断的冲突：保留双方来源与补证要求。

`_intermediate/` 可存放本次报告，但委派时给明确文件清单。被知识引用或承担审计依据的文件保留；不在生成完成后自动删除。

## 输出生成委派

standard 可由 Leader 生成或委派 luban；deep 交接还需遵循 [Team 协议](agent-team-protocol.md)。

```text
角色：鲁班 luban，负责知识文件生成与自检。
项目 ID：{PROJECT_ID}；代码根：{PROJECT_CODE_PATH}。
输出根：{OUTPUT_PATH}；scope：{full / incremental / domain}。
required_artifacts：{已通过阶段检查的探索报告完整路径清单}。
允许写入：{本任务输出范围}。

先读 required_artifacts 与以下规则：
{SKILL_PATH}/references/output-generation-rules.md
{SKILL_PATH}/references/output-schema.md
{SKILL_PATH}/references/path-normalization.md
领域输出另读 {SKILL_PATH}/references/domain-and-catalog-rules.md。

按范围生成或更新知识，已有文件先读再合并。内容来自证据；缺口写明，不能补造。
可选文件与索引同步处理，不制造悬空引用；保留人工内容和旧任务证据。
输入缺失则停止依赖工作并报告；需要补证时交给 Leader，不自行扩大源码调查范围。
交付文件清单、实际检查结果、查询抽查证据与未覆盖项。
```

## Domain Explorer Prompt 模板

用此内容替代 Round 0 的全局范围，其他交接要求相同：

```text
领域：{DOMAIN_ID / DOMAIN_NAME}。
代码范围：{DOMAIN_MODULES} 及任务允许的直接依赖。
required_artifacts：{领域索引、已有详情、相关全局架构的完整路径}。
输出：{领域探索报告完整路径}。

核对领域组件、数据流、公共 API、使用方、特有约定、核心实现及外部交互。
只引用已有全局规范，不重复抄写；指出领域特有差异。
说明关键文件及其职责、重要结论的来源、覆盖缺口。
若同类实体需要独立查找、或不同关注点已难以共存于一份详情，提出 Catalog / runtime / 子目录建议；不为达到数量阈值拆文件。
```

## 领域深化收敛评估

沿用上述停止规则，重点核对组件、API、主要数据流、外部交互与领域特有约定。只对已检查范围声明覆盖，未知部分保留查询入口。

## 领域输出生成委派

复用“输出生成委派”，设置 scope=domain，列明领域 ID、允许的领域目录及 `knowledge-base/domains/index.json`。按照领域规则生成或增量更新五类基础文件及必要扩展；更新注册表，不重建其他领域或全局知识。
