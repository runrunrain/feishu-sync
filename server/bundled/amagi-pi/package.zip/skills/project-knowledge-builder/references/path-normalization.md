# 项目知识路径规范化规则

知识库要能在别的机器、别的用户目录下直接加载，所以输出文件里的路径统一写成相对路径、用正斜杠。输出生成后按本文件自检一遍即可。

## 避免写入的路径

这些写法换一台机器就失效：

- 绝对路径（如 `D:\workspace\project\src\`、`C:\Users\user\`、`/home/user/project/`、`/Users/user/project/`）
- 带盘符的 Windows 路径（如 `E:\workpace\...`）
- 含用户名或机器名的路径

## 改用相对路径

**项目源码引用**：相对于项目代码根目录（`PROJECT_CODE_PATH`）

```
正确：_res_tables/01_Creature/
正确：src/modules/auth/
错误：D:\workspace\project\_res_tables\01_Creature\
错误：/home/user/project/src/modules/auth/
```

**知识库内部引用**：相对于知识库根目录

```
正确：knowledge-base/domains/config-tables/
正确：domains/auth-system/index.json
错误：/home/user/.amagi/projects/my-project/knowledge-base/domains/config-tables/
错误：D:\workpace\amagi\projects\my-project\knowledge-base\domains\
```

**Eval 测试路径**：用占位符变量，不写实际机器路径

```
正确：{EVAL_CODE_PATH}/src/
正确：{EVAL_OUTPUT_PATH}/knowledge-base/
错误：D:\workpace-test\project\src\
```

## 路径分隔符

统一用正斜杠 `/`，不用反斜杠 `\`。

## 构建完成后的自检

在 knowledge-base/ 目录下：

```
grep "[A-Z]:\\"        → 应返回 0 结果
grep "/home/|/Users/"  → 应返回 0 结果
```

有命中时，按上面的示例把它改成相对路径即可。

## 涉及的字段

以下 JSON 字段的值使用相对路径：

- `memory-map.json` → `sections.2_paths` 中除 `projectRoot` 外的所有路径字段
- `domains/index.json` → `domains[].path`、`domains[].modules[]`
- `domain/index.json` → `keyFiles`、`entryPoints`、`evidenceRefs` 中的路径
- `internals.json` → `keyFiles[].path`
- `chains/*.json` → `corePath`、`evidenceRefs` 中的路径引用
- `relations.json` → `nodes[].evidenceRefs`、`edges[].evidenceRefs`

**例外**：`context.json` 的 `projectPath`（以及与之对应的 `memory-map.json` 的 `sections.2_paths.projectRoot`）使用绝对路径——运行时要靠它定位代码仓库。
