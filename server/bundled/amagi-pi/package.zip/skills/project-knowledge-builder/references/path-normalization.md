# 项目知识路径规范

本文件统一维护输出路径的基准与验证要求；output-schema.md 定义字段形状。使用正斜杠，不把源码根、项目知识输出根和具体领域目录混成一个基准。

## 定位字段

`context.json.projectPath` 和 `memory-map.json.sections.2_paths.projectRoot` 允许绝对路径，运行时靠它们定位源码。其他知识路径使用相对路径。

## 相对基准

| 路径用途 / 字段 | 基准 | 示例 |
|---|---|---|
| modules、entryPoints、源码 keyFiles、development-specs 的模块 path | 项目代码根 PROJECT_CODE_PATH | `src/auth/index.ts` |
| 输出根级文件指向知识文件 | OUTPUT_PATH | `knowledge-base/domains/auth/index.json` |
| knowledge-base 索引、domains/index 的 domains[].path | OUTPUT_PATH/knowledge-base | `domains/auth/index.json` |
| domain/index 的 files[].path、领域内部文件引用 | 该领域目录 | `specs.json` |
| 任务与中间报告的证据引用 | 项目知识输出根，或字段已明确的基准 | `agent-outputs/baize/task/report.md` |

evidenceRefs、链路和关系图中的引用按其来源类型与已有字段约定解释；同一字段保持一致。已有合法相对基准保留兼容。无法判断来源类型时补明来源及基准，不简单截掉绝对路径前缀。

跨仓库证据需要可解析的仓库定位约定，不能删掉仓库身份后伪装成本项目路径。任务未提供定位方式时保留为待补证项，不编造能解析的引用。

## 验证

- 从实际字段基准解析路径，确认目标文件存在；有片段或 ID 的引用还需核对目标内容。
- 检索盘符、用户目录和反斜杠只是预筛选，不能替代逐字段检查。定位字段的合法绝对路径除外。
- 生成 glossary、chains、Catalog 或移动分片时同步更新入口，检查引用闭环。
- Eval 使用 `{EVAL_CODE_PATH}` / `{EVAL_OUTPUT_PATH}` 等明确夹具变量；实际知识文件不能保留未展开占位符。

只检测字符串里是否出现绝对路径不足以证明可移植性；至少沿一个实际查询走通入口、详情和证据。
