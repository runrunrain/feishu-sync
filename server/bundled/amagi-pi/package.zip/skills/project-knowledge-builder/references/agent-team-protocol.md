# Agent Team 协议（deep 模式专用）

deep 模式下，Leader 协调一个“逻辑 Team”：用 group / DAG 组织多个普通任务，用 artifact 和 Phase Gate 串起各阶段。SKILL.md 选定 deep 策略后读本文件。

先记住 pi 里这几条运行事实，后面的流程都建立在它们之上：

- 每个 SubAgent 是一次性的独立 pi 进程，`done` / `blocked` / `error` 后就退出；`task_resume` 是沿旧会话再起一个进程，不是常驻成员复用。
- 所有角色都是 Leader 直接派出的兄弟节点（depth=1），SubAgent 不能再派发任务。
- SubAgent 之间不直接通信。跨节点信息写进 artifact，由 Leader 在下一条任务书里传递。

## 目录

- [为什么 deep 模式需要 Agent Team](#为什么-deep-模式需要-agent-team)
- [完整流程](#完整流程)
- [建立逻辑协作组](#建立逻辑协作组)
- [Explorer SubAgent Spawn](#explorer-subagent-spawn)
- [Writer SubAgent Spawn](#writer-subagent-spawn)
- [Leader 行为准则](#leader-行为准则)
- [Phase Gate 检查](#phase-gate-检查)

---

## 为什么 deep 模式需要 Agent Team

如果每轮都由 Leader 亲自读完报告、评估、再派下一轮，多轮下来 Leader 的上下文会越积越大，判断质量随之下降。

逻辑 Team 的做法是：explorer 完成一轮并退出后，Leader 只读它的 artifact 和精简报告，再派下一轮 explorer 或 writer 接力。writer 读取已通过 Gate 的中间 artifact，不和 explorer 并行交换消息。Leader 专注于 Phase Gate 判断、方向修正和 artifact 传递。

复杂项目里，Team 还要顺带回答几个问题：

- 哪些高频概念值得进 glossary，并承担 first-hop（第一跳入口）作用；
- 哪些主链路值得沉淀为 `chains/index.json` 和 `chains/{chain-id}.json`；
- 哪些跨领域共享的枢纽和依赖边值得进 `relations.json`；
- 关键结论能附上哪些 evidenceRefs 和 confidence，而不只是抽象描述。

---

## 完整流程

```
[1] Leader 建立逻辑协作组（group / DAG + artifact 清单，无需单独的工具调用）
    │
[2] Phase 1：全面扫描
    ├─ 派 explorer（baize）执行阶段 1-6
    └─ Gate：explorer 返回报告 → Leader 评估收敛
         │
         ├─ 有高价值建议 → Phase 2
         └─ 无高价值建议 → 跳到 Phase 3
    │
[3] Phase 2：定向深化（可多轮，最多 3 轮）
    ├─ 每个高价值方向派一个 explorer（互相独立的方向可并行）
    │   └─ 跨领域发现先落 artifact，由 Leader 写进后续任务书
    └─ Gate：所有 explorer 返回 → Leader 评估收敛
         │
         ├─ 有新高价值建议 → 继续深化（Round N+1）
         └─ 收敛 → Phase 3
    │
[4] Phase 3：输出生成
    ├─ 派 writer（luban，新的一次性任务）
    │   └─ writer 读取所有 explorer 中间文件 → 生成基础知识文件；复杂项目额外生成 relations/chains
    └─ Gate：writer 返回 → Leader 验证输出质量
    │
[5] Leader 结束逻辑协作组 → 完成
```

---

## 建立逻辑协作组

pi 里不需要创建原生 Team。Leader 自己记录 Phase、group / DAG 节点、依赖和 artifact 清单，用多次 `task_submit` 派发 SubAgent：互相独立的方向可以并行，有依赖的方向放到后一个 Phase 串行。

运行期间可用的手段：

- 用 `delivery: "handle"` 派发后，任务完成或 blocked 时会自动通知，不需要轮询；
- `task_query` 可以只读查看任务状态、回执和输出；
- 发现某个 explorer 方向跑偏，可以用 `task_control({ action: "steer", handle, message })` 给 queued / running 的任务注入调整（任务书边界不变）；已 blocked 的任务改用 `task_resume`。

---

## Explorer SubAgent Spawn

Phase 1 和 Phase 2 派 explorer（`agent: "baize"`）。prompt 用 `references/deepening-protocol.md` 的 Round 0 / Round N 模板，再在末尾追加下面的交接协议：

```
## 交接协议

你是 knowledge-build-{PROJECT_ID} 逻辑 Team 的 explorer。本轮没有运行中的消息往来，任务结束后进程退出，你的成果靠 artifact 和终态报告交给 Leader。

工作习惯：写文件前先用 `grep` / `find` 定位；编辑或覆写已有文件前先 `read`；Bash 失败时先看 cwd、路径、依赖和参数，再决定怎么改，原样重试通常不会有新结果。

### 交给 Leader 的内容
- 每完成一个维度：把进度（如"3/5 维度完成"）写进中间 artifact，万一中途中断，Leader 也能接着用
- 发现风险或异常结构：写进中间 artifact，并在终态报告里置顶说明
- 识别到高频概念、主链路、枢纽节点或证据源：写进中间 artifact，供 Leader 决定是否需要 relations/chains
- 任务完成：交付物摘要 + 下一步建议

### 跨节点信息（经 artifact 和 Leader 中转）
- 发现跨领域关联：在报告与 artifact 中标注目标方向，Leader 会决定是否为它另派任务
- 发现共享枢纽或可复用链路：在报告与 artifact 中注明，Leader 会写进下一个节点的任务书
- 某个结论证据不足：在终态报告里写出补证需求，Leader 会新建或 resume 后续任务
- 同一 Phase 的其他 explorer 和 writer 联系不到，需要传递的信息都写进 artifact 即可

### 复杂项目额外产出
- 在报告中列出：候选 first-hop 概念、候选领域入口、候选主链路、候选枢纽节点、候选证据源
- 你负责的方向与已有链路重复时，优先建议"修正现有链路"，而不是新建一条
- 还没闭环的推断标注 low/medium confidence，和已验证事实分开写——这样知识库不会把猜测当事实传下去
```

---

## Writer SubAgent Spawn

Phase 3 派 writer（`agent: "luban"`）。writer 是本流程的岗位名，鲁班的工匠闭环（规格 → 产物 → 验证 → 证据）正好覆盖知识文件的生成与自检。

```
## 角色与身份
你是 knowledge-build-{PROJECT_ID} 团队的 writer，负责把探索成果落成知识文件，并自检质量。

## 任务
基于白泽（baize）产出的所有中间文件，生成项目知识文件。

## 中间文件位置
读取 {OUTPUT_PATH}/_intermediate/ 下的所有文件（explorer 报告汇总）

## 输出要求
先读 {SKILL_PATH}/references/output-schema.md 获取精确的 JSON 结构。
按 schema 生成基础的 9 项输出：
1. {OUTPUT_PATH}/context.json
2. {OUTPUT_PATH}/memory-map.json
3. {OUTPUT_PATH}/tasks/（空目录）
4. {OUTPUT_PATH}/knowledge-base/glossary.json（术语中心：从报告中提取跨文件重复概念；潜在术语 <5 个的简单项目可跳过）
5. {OUTPUT_PATH}/knowledge-base/index.json（含 summary/keyQuestions/moduleRelations/glossary 入口）
6. {OUTPUT_PATH}/knowledge-base/development-specs.json（重复概念用 $ref 引用 glossary）
7. {OUTPUT_PATH}/knowledge-base/conventions.json（重复概念用 $ref 引用 glossary）
8. {OUTPUT_PATH}/knowledge-base/architecture.json（重复概念用 $ref 引用 glossary）
9. {OUTPUT_PATH}/knowledge-base/api-reference.json

explorer 报告显示项目有复杂领域边界、明显主链路、共享枢纽或跨文件高频概念时，再生成：

10. {OUTPUT_PATH}/knowledge-base/relations.json
11. {OUTPUT_PATH}/knowledge-base/chains/index.json
12+. {OUTPUT_PATH}/knowledge-base/chains/{chain-id}.json

复杂项目还可以增强现有输出：

- memory-map.json：增加 4_firstRead、5_decisionTree、topChains、topHubs
- glossary.json：高流量术语增加 firstHop、relatedChains、relatedDomains、hubLevel、seeAlso、evidenceRefs
- knowledge-base/index.json：增加 recommendedFirstHop、entryByQuestion、entryByLayer、entryByChain、hubNodes、nextHopRules
- domains/index.json：增加 navigationAssets、entryScenes、domainModel.primaryDomains、domainModel.supplementaryTopicDossiers，以及各领域的 role/layerPosition/relatedChains/relatedHubs/commonTransitions
- domain/index.json：增加 startHere、questionMap、chainRefs、upstreamInputs、downstreamConsumers、evidenceRefs，以及 `quickStart.directoryLayout`

### 按体量触发的扩展输出

explorer 报告标记了以下情况时，生成对应文件：

- 字段/参数/文件实体数 > 50 → Catalog 系统（catalog.json + catalog-{shard}.json）
  - 路径：`{OUTPUT_PATH}/knowledge-base/domains/{DOMAIN_ID}/field-catalog/` 或 `param-specs/`
- 存在运行时决策/命令知识 → runtime/ 子目录文件
  - 路径：`{OUTPUT_PATH}/knowledge-base/domains/{DOMAIN_ID}/runtime/{topic}.json`
- 架构/内部实现文件体量大且分层清晰 → architecture/ 和 internals/ 子目录化
  - 路径：`{OUTPUT_PATH}/knowledge-base/domains/{DOMAIN_ID}/architecture/` 和 `internals/`
- 别名歧义明显或存在未验证声明 → terminology/ 目录（colloquial-normalization.json、verified-chain-routes.json 等）
  - 路径：`{OUTPUT_PATH}/terminology/`（与 knowledge-base/ 同级）
- 知识库已较完整（3+ 个领域）→ KNOWLEDGE-BASE-QUICK-REFERENCE.md
  - 路径：`{OUTPUT_PATH}/KNOWLEDGE-BASE-QUICK-REFERENCE.md`

这些扩展输出的 schema 见 `references/output-schema.md` 中对应各节。

## 交接协议

你是 knowledge-build-{PROJECT_ID} 逻辑 Team 的 writer。本轮没有运行中的消息往来，任务结束后进程退出。

工作习惯：写文件前先用 `grep` / `find` 定位；编辑或覆写已有文件前先 `read`；Bash 失败时先看 cwd、路径、依赖和参数，再决定怎么改。

### 交给 Leader 的内容
- 每生成 2 个文件：把进度写进中间 artifact
- explorer 报告信息不足：在终态报告中写明缺什么
- 发现链路冲突、关系图冲突或证据不足：在终态报告中说明，并给出建议的处理方式
- 任务完成：文件清单 + 各文件大小 + 质量自检结果；没做完或拿不准的部分照实写出来，Leader 可以据此补派任务

### 与 explorer 的协作（经 Leader 中转）
- 某个维度信息不足：在终态报告里写出缺口，Leader 会启动补充任务
- 多个 explorer 对同一主链路结论不一：报告冲突，Leader 会启动对齐或补证任务
- 只读取任务书里列出的 explorer artifact；运行中的 explorer 联系不到，缺什么写进报告即可

### 复杂项目额外职责
- 先决定是否需要 relations.json 和 chains/，再决定写多少条主链路，避免过度碎片化
- relations.json 的关键节点/边、chains 文件的关键转换点，优先补 evidenceRefs 与 confidence
- 已验证事实和待补证问题分开写，推断不放进 verifiedFacts
- 待补证问题只写入 pending-evidence.json 的 items；新的已验证事实、历史 rollout 说明和已闭环限制，写到权威详情文件或 archive/report 文件
```

---

## Leader 行为准则

| 做法 | 原因 |
|------|------|
| 不直接读项目代码文件 | 保护 Leader 上下文，交给 explorer |
| 不亲自执行分析阶段 | 由 explorer 完成 |
| 不亲自生成输出文件 | 由 writer 完成 |
| 小型配置文件（<50 行，如 registry.json、context.json）可直接读 | 开销小 |
| 评估建议价值，而不是亲自探索 | Leader 的价值在调度和门控 |
| 每个 SubAgent 的终态结果都要读并回应 | 风险、blocked 和补证请求只有 Leader 能接住 |
| 上一个 Phase 的 Gate 通过后再启动下一个 | 下游依赖上游 artifact，Gate 没过就开工容易返工 |
| 累积知识变大时写中间文件 | 存到 `{OUTPUT_PATH}/_intermediate/round-N.md` |
| 复杂项目重点判断“要不要关系层 / 链路层” | 避免只生成树状目录式知识库 |
| 未闭环的结论要求标注置信度 | 防止推测混进知识库被当作事实 |

---

## Phase Gate 检查

每个 Phase 结束时，Leader 用下面的清单判断能否进入下一阶段。不满足时，补派或 resume 一个针对性的任务通常比重跑整轮更省。

**Phase 1 Gate**（全面扫描完成）：
- explorer 报告已收到且非空
- 报告覆盖全部 6 个分析维度（含导航与证据候选）
- “下一步建议”有明确结论（有建议，或“已充分覆盖”）
- 中间文件已存到 `_intermediate/`
- 复杂项目已识别候选 first-hop、主链路、枢纽节点、证据源

**Phase 2 Gate**（定向深化完成）：
- 所有高价值方向的 explorer 报告已收到
- 已完成收敛评估（见 SKILL.md「收敛判定」）
- 累积知识已合并到中间文件
- 复杂项目已决定哪些链路进 chains/、哪些共享节点进 relations.json

**Phase 3 Gate**（输出生成完成）：
- 基础输出全部生成（9 项；简单项目跳过 glossary.json 时为 8 项）
- 项目满足复杂项目条件时，relations.json 与 chains/ 已生成且相互引用闭环
- 所有 JSON 可解析
- 通过 SKILL.md「输出质量检查清单」，包括渐进式披露和知识密度检查
- 有 evidenceRefs / confidence 字段时，引用路径存在且置信度语义一致
- **路径格式**：在 knowledge-base/ 目录下 `grep` 以下模式，结果都应为 0 个匹配（命中说明有路径换机后会失效）：
  - `[A-Z]:\\`（Windows 盘符绝对路径）
  - `/home/`（Linux 用户目录）
  - `/Users/`（macOS 用户目录）
  - 例外：context.json 的 projectPath 和 memory-map.json 的 projectRoot 允许绝对路径
