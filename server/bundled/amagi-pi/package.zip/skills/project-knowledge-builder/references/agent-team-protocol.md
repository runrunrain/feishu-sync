# Agent Team 协议（deep 模式）

Leader 用 group / DAG 组织多轮探索、定向补证与知识生成。本文件只补充 pi 运行与阶段交接；探索及生成任务统一复用 [deepening-protocol](deepening-protocol.md)。

## 运行与分工

- explorer 为 baize，writer 为 luban，均由 Leader 直接派发。SubAgent 不能递归派发，也不能直接互通。
- 每个 SubAgent 为独立 pi 进程，终态后退出；task_resume 沿旧会话启动进程，不表示常驻成员。
- Leader 维护依赖、范围、报告清单与验收，不重复读取已由证据充分回答的代码；需要核查关键争议时可定向读源。
- 所有生成任务从明确的上游 artifact 路径读取，不读取整个 `_intermediate/` 目录猜测当前输入。
- 任务运行结束、artifact 落盘、阶段验收分开判断，done 不能直接作为 Gate 通过依据。

## 完整流程

1. 建立逻辑协作组：记录范围、节点依赖、允许写入路径和输出报告；不需要创建常驻 Team。
2. Phase 1：派 baize 执行 Round 0，读取报告及关键证据，识别缺口。
3. Phase 2：有高价值缺口时定向探索；独立方向同批，有输入依赖则等待上游。按深化协议的预算停止，未覆盖项保留。
4. Phase 3：将通过检查的证据清单交给 luban，生成或更新知识并自检。
5. Leader 核对内容、引用与查询路径，返回结果和缺口。

无关键缺口可跳过 Phase 2，不为保持流程外形增加轮次。

## 建立逻辑协作组

- 使用 task_submit 或当前任务批量工具派发；遵循 canonical workflow-rules / subagent-mode / agent-teams-mode，pi 中通过 amagi_resource 读取。
- `delivery: "handle"` 的任务终态会通知；需要时用 task_query 只读核对状态。
- queued / running 的任务可用 `task_control({ action:"steer", handle, message })` 调整边界内工作；blocked 后用 task_resume。
- 生成任务有写冲突时明确文件所有权和集成节点。不能让多个 writer 同时覆写同一索引。

## Explorer SubAgent Spawn

复用深化协议 Round 0 / Round N / Domain 模板，再补充：

```text
你的角色是 knowledge-build-{PROJECT_ID} 的 explorer。
源码只读，仅允许写任务指定的报告 artifact。
遇到中断、未决分歧或高影响缺口时保存已有发现及证据路径。
跨领域发现写入报告，由 Leader 转交相关节点；不直接联系或派发其他 Agent。
报告区分事实与推断，并列出实际使用的上游引用及未覆盖范围。
完成时返回报告路径、主要结论、验证情况及必要的下一步。
```

## Writer SubAgent Spawn

复用深化协议“输出生成委派”，再补充：

```text
你的角色是 knowledge-build-{PROJECT_ID} 的 writer。
只读取任务列明的已通过检查的探索报告，已有知识先读后改。
输出范围：{允许写入的目录、文件及索引所有权}。
按 output-generation-rules.md 选择文件并检查内容，按 output-schema.md 写字段；不要复制另一套文件数量或证据标准。
缺失输入、报告冲突或新证据需求写入交接报告，由 Leader 组织补证。
只将有对应证据的事实写入 verifiedFacts；不把生成完成当作知识已全部验证。
交付实际变更清单、查询抽查结果、检查证据与未完成项。
```

## Phase Gate 检查

**Phase 1**：报告可读，分析范围明确，关键判断能定位来源；未覆盖维度有说明，下一步针对真实缺口。

**Phase 2**：各指定方向有结果或明确阻塞；冲突已解决或隔离为未定；停止理由及剩余缺口明确。达到预算不等于覆盖完整。

**Phase 3**：按 [输出验收](output-generation-rules.md#输出验收) 检查字段、内容、路径、引用和查询路由；可选文件的索引一致；人工内容与历史证据保留。

必需 artifact 缺失时阻止依赖它的节点；可以继续无依赖工作。验收失败时针对具体缺口修正，不重跑整轮或仅检查文件非空。
