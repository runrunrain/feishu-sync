# 项目知识输出生成规则

阶段 6 输出生成时读本文件：先确定要生成哪些文件，再按各文件的生成规则落笔。精确 JSON 结构见 `output-schema.md`。

## 基础输出与增强文件

full 首次构建保留以下基础结构；glossary 按复用需要选用，tasks 仅在不存在时创建，不清空已有目录。domain / incremental 只更新目标范围。

| 文件 | 内容来源 |
|------|---------|
| **context.json** | 阶段 1 身份+技术栈，阶段 2 组件 |
| **memory-map.json** | 所有阶段 → 7 段式精简记忆地图 |
| **tasks/**（空目录） | 首次构建仅创建空目录 |
| **knowledge-base/glossary.json**（可选） | 跨文件重复概念 → 术语中心（见下方生成规则） |
| **knowledge-base/index.json** | 索引，引用下方所有知识文件，含 summary/keyQuestions |
| **knowledge-base/development-specs.json** | 阶段 1+2：构建系统、依赖、模块 |
| **knowledge-base/conventions.json** | 阶段 5：命名、文件组织、错误处理、测试等 |
| **knowledge-base/architecture.json** | 阶段 3+4：层次、依赖、模式、数据流 |
| **knowledge-base/api-reference.json** | 阶段 4：外部 API 面、内部接口 |

当项目具备复杂领域边界、重复跨文件概念或明确主链路时，额外生成以下导航增强文件：

| 文件 | 内容来源 |
|------|---------|
| **knowledge-base/relations.json** | 阶段 2-4：跨领域概念、枢纽节点、依赖边 |
| **knowledge-base/chains/index.json** | 阶段 2-4：主链路注册表 |
| **knowledge-base/chains/{chain-id}.json** | 阶段 2-4：具体链路、转换点、上下游引用、下一跳规则 |

存在反复使用的跨领域查询、且现有入口不足以快速定位时，可生成快查表：

| 文件 | 位置 | 格式 | 用途 |
|------|------|------|------|
| KNOWLEDGE-BASE-QUICK-REFERENCE.md | 项目根级别 | Markdown | 综合导览，含场景化阅读路径 |
| {topic}_quick_reference.json | 领域子目录 | JSON | 高频问题即时答案，无需读详情 |

快查表内容要求：
- 每个场景提供完整的阅读顺序（从哪个文件开始 → 读哪个 → 执行什么）
- 比较或映射关系可用对照表，简单解释用文字
- 说明影响查询的覆盖缺口；不以文件数量宣称知识库完整

## task-index 兼容

`task-index.json` 首次构建时**不创建**——任务历史是运行时数据，由会话中的 `/save-session` 维护。

- 项目已有 `task-index.json` 时，可以增量补充知识维护类证据字段（如 `evidencePolicy`、`relatedDomains`、`relatedChains`）；不虚构不存在的任务历史，否则后续会话会把它当真。
- 新建项目的目标格式是 active-only task-index + task-archive.json。
- incremental 刷新时，现有 task-index 里承载证据的 completed/cancelled 条目原样保留、继续兼容读取，不为了贴合理想 schema 而清空、归档或重写——这些条目往往是唯一的证据来源。

## 各文件生成规则

**glossary.json 生成规则**：
1. 从 explorer 报告中识别在 2 个以上输出文件中需要描述的概念
2. 为每个概念创建术语条目（id/term/definition/aliases/category/relatedFiles）
3. 在其他输出文件中，将重复描述替换为 `"$ref": "glossary#termId"` 引用
4. 无需跨文件复用或独立导航时可跳过；同步省略 glossary 入口和 $ref，不生成悬空引用
5. 对高频术语（高流量入口概念）补充 `firstHop`、`relatedChains`、`relatedDomains`、`hubLevel`、`seeAlso`

**index.json 增强规则**：
- 每个 entry 必须包含 `summary`（1-2 句核心价值概括）和 `keyQuestions`（实际能回答的问题）
- 存在 glossary.json 时，增加 `glossary` 入口字段
- 对复杂项目，增加 `recommendedFirstHop`、`entryByQuestion`、`entryByLayer`、`entryByChain`、`hubNodes`、`nextHopRules`
- 可选增加 `moduleRelations`（知识文件间引用关系图）

**memory-map.json 增强规则**：

- 对复杂项目，增加 `4_firstRead` 和 `5_decisionTree` 两个 section
- `4_firstRead` 用于回答“我现在先读哪一个文件”
- `5_decisionTree` 用于回答“接下来该按概念、领域还是链路下钻”
- 可在 `6_technicalPoints` 中补充 `topChains` 与 `topHubs`

**relations.json 生成规则**：

1. 提取跨领域共享概念、枢纽对象、桥接机制、核心表/服务/模块
2. 使用轻量 JSON 图模型输出 `nodes`、`edges`、`views`、`centralHubs`
3. 对关键节点和边尽量增加 `evidenceRefs` 和 `confidence`
4. 不引入图数据库或过度复杂建模，保持可人工维护

**chains/{chain-id}.json 生成规则**：

1. 为项目中重要的数据流转链、配置桥接链、调用链生成独立链路文件
2. 每条链至少包含：`goal`、`entryQuestions`、`corePath`、`transitionPoints`、`relatedDomains`、`upstreamRefs`、`downstreamRefs`、`nextHop`
3. 若已有证据来源，增加 `validationChecks`、`evidenceRefs`、`verifiedFacts`
4. 链路数量应精简，只保留开发者会重复使用的主链路

chains 文件类型：

1. 线性链路（标准）：A → B → C，每步指向知识库文件或领域
2. 矩阵型链路（conversion-matrix）：多种输入类型 × 多种输出类型的转换规则表
   - 适用场景：存在配置-运行时桥接层时（如跨层映射机制）
   - 结构：nodes（输入/输出节点）+ edges（转换规则）+ matrix（完整映射矩阵）

chains/index.json 必须包含：
- `startQuestions`：必要的分流问题，帮助 Agent 在进入前确定方向
- `entryRules`：每类问题对应哪条链路
- `crossLinks`：链路间推荐跳转（from/to/reason）

**terminology/ 目录生成规则（按需创建）**：

当项目满足以下任一条件时，在项目根级别（与 knowledge-base/ 同级）创建 terminology/ 目录：

- 存在大量别名或非正式叫法，可能导致 Agent 搜索失败
- 知识库中存在置信度不足的声明，需要显式标记为"待验证"
- 已积累足够多的验证执行链路，值得系统化记录

| 文件 | 用途 | 生成时机 |
|------|------|---------|
| colloquial-normalization.json | 别名归一化规则（含 confidence 等级门控） | 存在命名歧义时 |
| alias-dictionary.json | 全量别名字典（支持别名搜索） | 别名需要集中检索时 |
| verified-chain-routes.json | 已验证执行链路（step-by-step + evidence） | 已有验证链路时 |
| pending-evidence.json | 待验证声明清单（items-only） | 存在不确定知识时 |

confidence 依据下方统一证据语义。别名 A 可按已证明的映射使用，B 仅作检索入口并核对，C 保持未定，不输出未经证实的正式名称。

**路由能力抽查**：上游的 `resolve:chain` 命令（`rage_cli.js`）没有随本插件打包，可以用 `read`/`grep` 直接抽查 JSON 索引：

1. 别名命中：挑几个常用口语叫法，`grep` `terminology/colloquial-normalization.json`、`alias-dictionary.json`，确认能归一到正式名称；
2. 链路命中：对同样的词，`grep` `knowledge-base/chains/index.json` 的 `entryRules` 与 `terminology/verified-chain-routes.json` 的 `triggerWords`，确认能落到预期链路。

查不到预期结果，说明知识库在这里还有缺口，可以记入 pending-evidence 或再深化一轮。

**evidence 追踪三层级**：

1. 内联证据：在 relations.json 边/节点和 chains 关键点上使用 evidenceRefs + confidence
2. 链路证据（terminology/verified-chain-routes.json）：当声明涉及的所有关键跳转均有直接证据时，
   在此文件记录 step-by-step 路径和对应证据，confidence 设为 A；注明是静态关系核对还是实际运行验证，不混用两者
3. 待证清单（terminology/pending-evidence.json）：知识库中置信度低的声明，
   显式列出待补充的证据，防止把推断误当事实传播；历史 rollout 说明、已闭环限制和 verified operational facts 不应继续写入此文件

**confidence 等级**（统一证据语义，保留既有字段取值兼容）：
- A：直接证据支持该具体声明。源码可证明定义与分支关系，运行成功还需对应运行证据；已确认设计文档只证明设计意图。
- B：有间接证据，尚不能直接证明该声明。
- C：待验证推断，不能作为确定事实继续传播。

`relations.json` 沿用其 schema 的 `high|medium|low`，分别对应上述 A/B/C 的证据要求；terminology 沿用 `A|B|C`。不迁移已有枚举。评级作用于具体节点、边或声明，不能由一个文件命中提升整条链路。发现旧评级缺少证据时补证或降级，不仅换标签。

verified-chain-routes.json 的 step 字段规范：
`{ "order": N, "table": "表名", "file": "文件名", "dir": "目录名", "keyField": "字段名", "description": "说明", "fileType": "xlsx/xml/ast/res_xml/mixed", "nodeRole": "config_entry/config_relay/res_mapping/res_carrier/res_terminal", "writeMode": "modify/add/verify/read_only", "plannerBoundary": false }`


## 输出验收

- JSON 可解析，必需字段完整；无材料的内容按 schema 允许写 unknown、空集合或省略，并说明缺口，不填示例数据。
- 索引只引用实际存在的文件；按字段基准核查路径和锚点。glossary、relations、chains 等可选文件的生成与入口引用保持一致。
- 重要组件、API、主路径和项目特有约定有来源；扫描或采样范围可识别，不要求规范条数、主链路条数、信息行比例或固定行数。
- 索引保留路由信息，详情集中维护；是否分片取决于独立查询与维护需要，避免因数字阈值制造空目录。
- 用实际问题抽查“入口 → 详情 → 证据”，确认能找到答案。图关系、链路和 confidence 与具体证据一致。
- 保留人工内容、旧任务证据和被引用的中间文件；没有验证的知识不得写入 verifiedFacts。
