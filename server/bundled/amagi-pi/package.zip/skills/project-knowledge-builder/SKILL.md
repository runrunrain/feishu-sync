---
name: project-knowledge-builder
description: |
  Builds persistent projects-memory knowledge datasets by analyzing source code. Trigger when the user asks to build/refresh/index/register project knowledge, scan a repo into project memory, deep dive a module/domain, create progressive disclosure knowledge, relation graphs, chains, or evidence-backed routing. Chinese triggers: 构建知识库、索引代码库、扫描项目、项目记忆、刷新知识库、深化模块知识、领域知识、知识路由。Do NOT trigger for one-time code exploration, code review, session saving, or ordinary implementation tasks.
compatibility: pi
---

# 项目知识构建器

把授权范围内的代码与项目资料整理为可导航、可回源的 projects-memory 知识。负责既有项目的知识提取，不代替架构决策或一次性代码探索。文字遵循 [共用规则](../agent-document-output/reference/writing-rules.md)。

## 输入与范围

| 输入 | 来源 |
|---|---|
| 代码路径 | 用户提供，或 registry 中当前项目的 `projectPath` |
| 输出路径 | 用户提供，或 `{PROJECTS_DIR}/{project-id}/` |
| 项目 ID | 用户提供，或 registry 的 `activeProject` |
| scope | `full` / `incremental` / `domain`，按用户任务选择 |
| depth | `quick` / `standard` / `deep`，用户指定优先，否则按目标和证据缺口选择 |
| 领域 | domain 模式下提供 id、name、modules；自然语言范围先在项目内定位 |

未给路径时，从当前目录向上查找 `projects-memory/projects/registry.json`；其所在 `projects/` 目录为 `PROJECTS_DIR`。读取 `activeProject` 与 `projects[activeProject].projectPath`。无法确定目标或输出位置时再询问；不猜项目归属。

只写任务授权的输出范围。额外仓库和镜像不是默认写入目标；增量更新保留人工内容与历史证据。

## 深度与执行

| 深度 | 适用情况 | 执行方式 |
|---|---|---|
| quick | 范围小、关系明确，或用户要求快速建立入口 | Leader 直接分析并生成 |
| standard | 需要系统扫描，主要关系可在一轮中覆盖 | baize 探索，Leader 判断缺口后生成或委派 luban |
| deep | 跨模块关系复杂，需要多轮定向补证 | Leader 用 group/DAG 组织探索、补证与生成 |

文件数量只帮助估算成本，不决定深度。standard / deep 的探索模板见 [深化协议](references/deepening-protocol.md)，deep 的交接见 [Team 协议](references/agent-team-protocol.md)。

pi 中 explorer 派 baize、writer 派 luban；SubAgent 是独立进程，不能再派发或直接互通，信息由 Leader 通过 artifact 传递。canonical 规则通过 `amagi_resource` 读取。上游 `rage_cli.js` 未打包，直接读取 JSON 索引核查，不假设配套 CLI 存在。

## 分析内容

1. **技术栈与构建**：从真实配置读取语言、版本、依赖、构建目标和平台。按职责覆盖重要语言，包括文件少但承担关键接口的部分。
2. **结构与组件**：排除构建产物、依赖和缓存；从入口、目录、项目清单定位组件，覆盖范围内的重要脚本、工具和插件。采样时说明未读范围。
3. **架构与数据流**：沿入口、核心模型、配置及代表性路径核对模块职责和依赖；检索命中后读取上下文，不能只凭类名推断架构。
4. **API 与接口**：说明外部 HTTP/CLI/SDK 入口及重要内部契约，保留参数、结果、错误和调用关系。
5. **项目约定**：提取有证据的命名、组织、错误处理、日志、测试等约定；区分项目明确规范与代码样本习惯，不凑类别数量。
6. **导航与证据**：识别术语、领域入口、主链路、枢纽与来源。每项关键判断说明证据支持到哪一步，静态源码不自动证明运行成功。

检测线索见 [detection-patterns](references/detection-patterns.md)，它提供检索入口，不替代实际阅读。

## 深化与停止

每轮根据未解问题决定是否继续。重要入口、接口关系或高影响结论仍缺证据时定向探索；重复信息或不影响当前任务的方向不展开。配置与测试文件若决定实际行为，同样是重要证据。

默认预算：全局 Round 0 后最多 3 轮深化；domain Round 0 后最多 2 轮。没有关键缺口可提前结束；达到预算上限只表示停止探索，不能写成覆盖完整。交付保留未覆盖范围和继续入口，不用未定义的“信息增量百分比”判断收敛。

后续发现与旧结论冲突时，核对版本、路径和适用条件，以更直接的证据修正；无法判定时保留分歧，不因轮次较新就覆盖。

## 输出与维护职责

- [输出生成规则](references/output-generation-rules.md)：唯一维护文件选择、可选增强、证据等级和内容验收规则。
- [output-schema](references/output-schema.md)：精确 JSON 字段与兼容形状；示例值不是项目事实。
- [领域与 Catalog](references/domain-and-catalog-rules.md)：领域文件、目录拆分和分片导航。
- [路径规则](references/path-normalization.md)：各字段相对基准与定位例外。

索引回答从哪读，摘要回答该文件能解决什么，详情保存完整知识，证据说明结论来源。重复概念集中维护并引用，避免为减少行数压缩 JSON 或删除必要条件。

### domain

先读取现有 `knowledge-base/domains/index.json`，新领域追加、旧领域增量更新。生成该领域的 index、specs、architecture、api-reference、internals，按需要增加 runtime 或 Catalog；更新领域注册表。不重建全局知识，不删除其他领域。

### incremental

读取已有知识与可靠变更范围，更新受影响的文件和引用。mtime 仅作线索，不能独自证明内容变化。保留人工维护内容；需要修正时依据新证据说明变化。更新 `lastUpdated`，不虚构任务历史，不为理想 schema 清空 completed/cancelled 的旧任务证据。

### 本机补证

可从 `RAGE_PROJECT_CODE_ROOTS` 或任务资料发现候选仓库，先确认与当前问题的关系及访问范围。知识库已有索引先查，缺口再定向读源码。按输出规则对具体声明评级，不把一次唯一命中扩展为整条链路已验证。弱线索写入 pending-evidence；仅在任务包含镜像同步时更新 `resources/knowledge-overlay/` 等镜像。

## 交付检查

按输出规则检查 JSON、字段、路径、引用、证据和覆盖范围。至少从实际读者问题出发，验证入口能指向相应详情与来源；不能只检查文件存在。

返回生成或更新清单、实际检查结果、未覆盖项及必要的后续入口。中间报告按 [artifact 规则](../agent-document-output/SKILL.md) 留存，不能删除仍被证据引用的文件。deep 长任务可用 [workflow](../workflow/SKILL.md) 维护状态。

`change-catalog.md` 是历史提案存档，不作为当前执行规则；knowledge-navigator / cli-guide 是未随本插件提供的可选工具。
