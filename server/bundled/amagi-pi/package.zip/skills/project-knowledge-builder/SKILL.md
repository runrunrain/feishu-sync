---
name: project-knowledge-builder
description: |
  Builds persistent projects-memory knowledge datasets by analyzing source code. Trigger when the user asks to build/refresh/index/register project knowledge, scan a repo into project memory, deep dive a module/domain, create progressive disclosure knowledge, relation graphs, chains, or evidence-backed routing. Chinese triggers: 构建知识库、索引代码库、扫描项目、项目记忆、刷新知识库、深化模块知识、领域知识、知识路由。Do NOT trigger for one-time code exploration, code review, session saving, or ordinary implementation tasks.
compatibility: pi
---

# 项目知识构建器

这个技能把一次深入的代码分析沉淀成持久化的结构化知识（projects-memory 格式），之后任何 Agent 都能直接加载，不必每次会话重新探索代码库、反复消耗上下文。

单轮扫描通常只能看到表层结构，所以这里采用**迭代深化**：每轮探索后看一看 explorer 给出的“下一步建议”，对有价值的方向再做一轮定向探索，直到知识收敛。

## 在 pi 中运行

- **角色分工**：explorer 是逻辑岗位名，派给白泽（`baize`）；writer 派给鲁班（`luban`）。用 `task_submit({ agent: "baize", task: "<prompt>" })` 派发，每个 SubAgent 是独立的 pi 进程，跑完一轮就退出。
- **协作方式**：SubAgent 之间不直接通信，信息经 artifact 文件和 Leader 的下一条任务书传递；SubAgent 也不能再派发任务。
- **canonical 资源**：需要时调用 `amagi_resource` 传资源 ID（pi 不会自动展开 `@` 引用）。
- **上游 CLI 不可用**：上游的 `rage_cli.js`（含 `resolve:chain`、`probe` 等命令）没有随本插件打包。需要核验别名、行为或链路时，直接用 `read`/`grep` 查 projects-memory 里的 JSON 索引即可。

## 快速开始

1. **解析参数**（见下方「输入参数」，大多能自动推断）。
2. **选择深度**：`quick` / `standard` / `deep`（缺省 deep）。
3. **探索**：quick 由你直接做；standard/deep 委派 explorer。
4. **评估收敛**：按「收敛判定」决定是否再深化一轮。
5. **生成输出**：读 `references/output-generation-rules.md` 与 `references/output-schema.md`，写入知识文件。
6. **自检**：过一遍「输出质量检查清单」和 `references/path-normalization.md`。

## 输入参数

| 参数 | 必填 | 来源 | 说明 |
|------|------|------|------|
| 代码路径 | 是 | 用户提供或 registry → `projectPath` | 项目源代码的绝对路径 |
| 输出路径 | 是 | 用户提供或 `{PROJECTS_DIR}/{project-id}/` | projects-memory 文件写入位置 |
| 项目 ID | 是 | 用户提供或 registry → `activeProject` | 项目标识符 |
| 范围 | 否 | 用户指定 | `full`（缺省）/ `incremental` / `domain`（领域深化） |
| 深度 | 否 | 用户指定或自动判断 | `quick` / `standard` / `deep`（缺省） |
| 领域 | 仅 domain 模式 | 用户描述或结构化指定 | 如 `"auth 模块"` 或 `{ id, name, modules }` |

用户没给全时，可以这样自动解析（与 `/save-session` 的定位方式一致）：

1. 从当前目录逐级向上找到 `projects-memory/projects/registry.json`；它所在的 `projects/` 目录就是 `{PROJECTS_DIR}`。
2. 项目 ID 取 `activeProject`。
3. 代码路径取 `projects[activeProject].projectPath`。
4. 输出路径取 `{PROJECTS_DIR}/{activeProject}/`。

找不到 registry 或字段缺失时，直接向用户确认路径，比猜一个更省事。

## 知识组织目标

除了基础的代码理解，复杂项目里还值得主动构建这几种能力：

1. **渐进式披露**：Agent 先看入口层，再看导航层，按需进入详情层。
2. **链路关联**：把“配置 → 映射 → 运行时消费”这类主链路表达成可导航对象，而不是散落在多个文件里。
3. **图状结构**：跨领域共享的概念、枢纽和依赖关系，用轻量关系图表达。
4. **证据挂载**：关键结论尽量指向具体的知识文件、领域文件或任务记录，避免“只有结论没有来源”。
5. **文件分片**：单文件超过 500 行时，按 ID 范围、编号范围或语义分片，并在同目录维护一个索引文件做路由。分片文件本身属于详情层，三层披露结构不变。

推荐的知识层次：

- L0 入口层：`context.json`、`memory-map.json`
- L1 导航层：`knowledge-base/index.json`、`knowledge-base/domains/index.json`
- L2 关系层：`knowledge-base/glossary.json`、`knowledge-base/relations.json`、`knowledge-base/chains/`
- L3 详情层：`development-specs.json`、`conventions.json`、`architecture.json`、`api-reference.json`、`domains/*`
- L4 证据层：`task-index.json`、`tasks/`、`_intermediate/`、`agent-outputs/`（若存在）

项目满足以下任一条件时，建议生成 L2 关系层：

- 有 2 个以上领域或子系统；
- 有反复跨文件出现的概念，适合抽成 first-hop 术语（Agent 进入知识库时第一跳该去的概念）；
- 有明显的数据流转链、配置桥接链或跨层依赖链；
- 有高中心度节点，即“枢纽文件 / 枢纽表 / 枢纽服务”。

---

## 执行模型

### 深度策略选择

| 策略 | 适用场景 | 行为 |
|------|---------|------|
| `quick` | 小型项目（<50 文件）或用户指定 | Leader 直接执行阶段 1-6 |
| `standard` | 中型项目（50-500 文件） | 委派 explorer 单轮扫描 → 生成输出 |
| `deep`（缺省） | 大型项目（500+ 文件）或用户指定 | 用逻辑 Agent Team（group/DAG）按 Phase Gate 迭代深化 |

**standard 和 deep 的 Round 0 交给 explorer**，即使项目看起来很小也一样。原因有两个：explorer 返回之前，你其实还不知道项目的真实规模；而亲自扫描会先吃掉你自己的上下文。explorer 回给你的通常只是几百字的精简报告，Leader 的上下文留给调度和判断更值。想自己动手做全流程时，选 `quick` 即可。

### standard 模式

委派 explorer 执行阶段 1-5，拿回发现摘要和下一步建议。没有值得深化的建议就收敛，进入阶段 6 生成输出。prompt 模板在 `references/deepening-protocol.md`。

### deep 模式

读 `references/agent-team-protocol.md`，里面有 group/DAG 的组织方式、explorer 与 writer 的派发模板、经 Leader 中转的交接协议和 Phase Gate。

核心流程：建立逻辑协作组 → Phase 1 全面扫描 → Phase 2 定向深化（最多 3 轮）→ Phase 3 writer 生成输出 → 结束协作组（没有需要释放的常驻成员）。

### 领域深化（scope: domain）

聚焦一个目标领域，**不重建全局知识**。深度策略的选择与全面模式相同。

1. **解析领域**：结构化输入直接用；自然语言就提取 id/name/modules。
2. **查看现有领域知识**：读 `{OUTPUT_PATH}/knowledge-base/domains/index.json`。
   - 文件不存在 → 全新构建（创建 domains/index.json 和领域目录）；
   - 领域已注册 → 增量更新；
   - 领域未注册 → 全新构建，并追加到注册表。
3. **探索并生成**：用 `references/deepening-protocol.md` 的「Domain Explorer Prompt 模板」，生成 5 个领域知识文件并更新 domains/index.json。

| 用户输入 | 解析结果 |
|---------|---------|
| "深化 auth 模块知识" | id: auth-system，modules 靠推断（搜索 auth 相关目录） |
| "deep dive into src/payment/" | id: payment, modules: ["src/payment/"] |
| 结构化 `{ id: 'order-service', modules: ['src/orders/'] }` | 直接使用 |

### 收敛判定

满足**任一**条件即可收敛：

| 条件 | 说明 |
|------|------|
| 无新建议 | 最新一轮 explorer 没有提出新方向 |
| 全部已覆盖 | 建议的方向都已被之前轮次覆盖 |
| 到达上限 | 已完成 3 轮深化（Round 0 + 3 = 共 4 轮） |
| 边际递减 | 新发现相比已有知识增量不足 20% |

拿不准时宁可少探索一轮：知识库之后可以用 incremental 或 domain 模式继续补，而多跑的轮次消耗的 token 收不回来。

### 建议价值评估

**值得深化**：未覆盖的模块/子系统、复杂的内部接口或数据流、项目特有的设计模式、explorer 标为“高”或“中”增量价值的方向。

**不必深化**：纯配置/环境差异、已覆盖的重复方向、第三方库内部实现、explorer 标为“低”增量价值的方向。

### Leader 的分工（standard / deep）

| 做法 | 原因 |
|------|------|
| Round 0 交给 explorer | 见上文：规模未知、保护上下文 |
| 不直接读项目代码，交给 explorer 代读 | 你的上下文留给评估和调度 |
| 小型配置文件（<50 行，如 registry.json、context.json）可以直接读 | 开销小，且解析参数需要 |
| 评估建议价值，而不是亲自探索 | Leader 的价值在判断方向 |
| 累积知识变大时写中间文件 | 存到 `{OUTPUT_PATH}/_intermediate/round-N.md`，后续任务直接引用路径 |
| deep 模式下想动手时，改为派一个后续 task | 在任务书里传入已通过 Gate 的 artifact 路径 |

---

## 分析阶段

下面定义代码分析的具体内容：

- **quick**：Leader 直接执行阶段 1-6；
- **standard / deep**：阶段 1-5 写进 explorer 的 prompt（模板已包含）。

### 阶段 1：技术栈检测

识别语言、框架、构建系统和关键依赖。文件模式映射表见 `references/detection-patterns.md`「技术栈特征」。

从特征文件入手，读构建配置提取：框架版本、按类别分组的前 15-20 个依赖、构建目标、支持平台。

**多语言项目**：若没有单一语言占 60% 以上，列出所有占比超 20% 的语言及百分比。

### 阶段 2：结构扫描

绘制目录树，理解模块布局，估算代码库规模。

- **2a 排除规则**：读 `.gitignore`，并与默认噪声目录合并（`node_modules`、`.git`、`bin`、`obj`、`dist`、`build`、`__pycache__`、`.vs`、`.idea`、`target`、`vendor`、`.next`、`out`）。
- **2b 目录树**：用 `find` 的 `*/` 和 `*/*/` 模式取前两层；`find` 返回空时退回 `ls -d */`。顺带检测 Monorepo（packages/、apps/、lerna.json 等）。
- **2c 文件分布**：用 `find` 统计前 10 种文件类型，采样 5-10 个文件估算行数。
- **2d 模块与组件识别**：知识库质量取决于能否找到*全部*重要组件，这一步值得多花点心思。除了按目录识别模块，也留意单个目录里逻辑独立的组件：
  1. 用 `find` 搜所有源文件，而不只看目录；
  2. 判断每个文件是否构成独立功能单元；
  3. 查找 `src/` 之外的项目文件（脚本、工具、插件）；
  4. 读 README 或入口文件，拿到项目自己的组件列表；
  5. 目标：开发者介绍项目时会提到的组件，都能在这里找到。

### 阶段 3：架构分析

`grep` 模式见 `references/detection-patterns.md`「架构指标」。搜完后读 3-5 个关键文件：入口点、核心领域模型、配置加载器、一个典型功能实现。

### 阶段 4：API 与接口清单

`grep` 模式见 `references/detection-patterns.md`「API 检测模式」。

编目外部 API（HTTP/CLI/SDK）和内部模块接口。每个端点记录：方法/路由/命令名、参数与返回类型、简要用途。内部接口关注共享类型/DTO、事件系统、跨模块调用、依赖注入。

### 阶段 5：编码规范检测

领域列表见 `references/detection-patterns.md`「规范检测」。目标是 **10+ 个不同的规范类别**，每类附上代码库里的真实示例；不适用的类别省略并说明原因即可。

自查：

1. 有 10+ 个不同类别吗？
2. 每个类别都有来自代码库的具体示例吗？
3. 命名规范按实体类型（类、函数、常量、文件……）细分了吗？
4. 捕获到语言特有的惯用法了吗？

### 阶段 6：输出生成

把发现写成 projects-memory 格式。开始前读两份参考：

- `references/output-generation-rules.md`：生成哪些文件、导航增强、快查表、task-index 兼容、glossary/relations/chains/terminology 与 evidence 规则；
- `references/output-schema.md`：每个文件的精确 JSON 结构。

谁来生成：

- **quick**：Leader 直接生成；
- **standard**：可以委派 luban（模板见 `references/deepening-protocol.md`「输出生成委派」）；
- **deep**：交给 writer（luban），见 `references/agent-team-protocol.md`「Writer SubAgent Spawn」。

### 阶段 7-8：领域知识与 Catalog 构建

scope=domain，或领域规模较大（大量字段/文件/参数）时，读 `references/domain-and-catalog-rules.md`：领域输出文件、runtime 子目录、领域子目录化、复杂领域导航字段和 Catalog 分片都在那里。

---

## 输出质量检查清单

收尾前逐项过一遍。某项做不到时，在交付说明里写明原因就好——如实标注比硬凑更有用。

### 基础质量

- [ ] 所有 JSON 文件可解析
- [ ] context.json 的必填字段都已填写
- [ ] memory-map.json 包含全部必需 section；复杂项目可额外有 `4_firstRead`、`5_decisionTree`
- [ ] knowledge-base/index.json 引用了所有生成的知识文件
- [ ] 没有占位文本（TODO/TBD）；不确定的写 `"unknown"` 或省略
- [ ] 路径都是相对路径（不含盘符、`/home/`、`/Users/` 前缀），细则见 `references/path-normalization.md`
- [ ] 依赖列表来自真实构建配置
- [ ] 架构描述与实际代码结构一致
- [ ] 多语言项目对每种主要语言都有规范覆盖
- [ ] conventions.json 有 10+ 个非空规范类别
- [ ] 若项目使用 ks:schema 格式的 Schema 系统（如 Rage 引擎），knowledge-base 中记录了 Schema 仓库路径和默认值省略语义规则

### 渐进式披露（三层模型：索引 → 摘要 → 详情）

- [ ] **索引层**（<100 行看清全貌）：index.json 的每个 entry 有 summary 和 keyQuestions
- [ ] **摘要层**（200-300 行内拿到决策信息）：有 2+ 个跨文件重复概念时，glossary.json 存在
- [ ] **详情层**（按需深入）：详情文件通过 `$ref` 引用 glossary，没有大段重复
- [ ] **跨文件冗余率** < 10%：同一概念的完整描述只出现一次，其他地方引用它
- [ ] **导航层**：复杂项目的 index.json 至少有 `recommendedFirstHop`、`entryByQuestion` 之一
- [ ] **关系层**：复杂项目有 `relations.json` 或 `chains/index.json`
- [ ] **术语可导航**：高频术语有 `firstHop` 或 `relatedDomains` / `relatedChains`

### 知识密度

- [ ] 每个 JSON 文件的有效信息行占比 > 70%（不计 `{}`、`[]`、空行等纯结构行）
- [ ] memory-map.json < 200 行（启动入口保持精简）
- [ ] index.json < 100 行（便于快速扫描）
- [ ] glossary.json 中每个术语至少被 2 个文件引用（否则不必单独抽成术语）
- [ ] 复杂项目的主链路控制在 3-8 条，避免过度碎片化
- [ ] 项目有明显枢纽时，relations.json 的 `centralHubs` 不为空

### domain 模式额外检查

- [ ] domains/index.json 已注册新领域（id、name、summary、modules、tags、quickAnswers 完整）
- [ ] 多领域时，domains/index.json 有 crossDomainRelations
- [ ] domain/index.json 有 quickStart、crossReferences、commonQueries
- [ ] 复杂领域的 domain/index.json 有 `startHere`、`questionMap`、`chainRefs`
- [ ] specs.json 至少 5 条领域特定规范
- [ ] architecture.json 有 components 和 dataFlow
- [ ] internals.json 有 keyFiles 清单和 coreLogic 说明

---

## 增量模式（scope: incremental）

1. 读现有 memory-map.json 和 knowledge-base 文件；
2. 检测变更（git diff 或文件修改时间）；
3. 只重新分析受影响的模块/文件；
4. 把新发现合并进现有知识，保留手动添加的内容；
5. 更新 `lastUpdated`；
6. `task-index.json` 已存在时，可以补充知识维护相关的证据字段；不新建虚构的活跃任务，以免误导后续会话；
7. 人工维护的 `questionMap`、`entryScenes`、`evidenceRefs` 保持原样，除非有更强的证据需要修正。

## 大型代码库（10,000+ 文件）

- 采样目录而不是全量扫描，优先 `src/`、`lib/`、`app/`；
- 按模块采样代表性文件；
- 用具体的 `find` 模式，避免 `**/*`；
- 必要时分批处理，并优先选 `deep` 策略迭代深化。

## 本机代码仓库补证

现有知识库对某个术语、别名、行为名或配置链给不出稳定结论时，与其停在“待补证”，不如先看看本机有没有相关代码仓库，做一次定向补证：

1. 候选代码仓库根目录可以从环境变量 `RAGE_PROJECT_CODE_ROOTS` 获取；
2. 先用 `read`/`grep` 查知识库里已有的 alias、behavior 与 chain JSON 索引（如 `terminology/` 下的文件），确认是否已有结论，避免重复补证；
3. 在代码仓库里命中唯一且上下文一致的源码证据时，可以把这条知识升级为 B 级，写回知识库中对应的文件（若项目另维护了 `resources/knowledge-overlay/` 镜像，同步更新镜像）；
4. 只得到弱匹配时，记入 `{OUTPUT_PATH}/terminology/pending-evidence.json` 的 `items`，并在 evidence 字段里挂上命中的文件线索。

这套做法适用于知识库刷新、领域深化和测试回归后的知识库修复；配置表真值仍以配置表本身的校验为准。

## 路径规范化

知识库输出里的路径用相对路径、正斜杠——这样换一台机器也能直接加载。禁用写法、各字段的相对基准和验证命令见 `references/path-normalization.md`，输出生成后按它自检一遍。

---

## 参考资源

| 文件 | 内容 | 何时读 |
|------|------|-------|
| `references/output-generation-rules.md` | 生成哪些文件，以及 glossary/index/memory-map/relations/chains/terminology/evidence 规则 | 阶段 6 |
| `references/output-schema.md` | 所有输出文件的精确 JSON 结构（含 glossary、domains/、task-archive） | 阶段 6-8 |
| `references/domain-and-catalog-rules.md` | 领域文件、runtime、子目录化、Catalog 分片 | 阶段 7-8（domain 模式或大规模领域） |
| `references/detection-patterns.md` | 技术栈特征、架构与 API 的 `grep` 模式、规范检测方法、体量检测 | 阶段 1-5 |
| `references/deepening-protocol.md` | explorer prompt 模板（Round 0 / Round N / Domain）、收敛评估、输出委派模板 | standard / deep / domain |
| `references/agent-team-protocol.md` | 逻辑 Team 的 group/DAG、派发模板、Leader 中转交接、Phase Gate | 仅 deep 模式 |
| `references/path-normalization.md` | 路径规则与验证命令 | 输出生成后自检 |

`change-catalog.md` 是本技能早期迭代的提案存档，内容已全部并入上表文件，执行时不需要读。

## 相关 Skill

| Skill | 关联 |
|-------|------|
| [workflow](../workflow/SKILL.md) | deep 模式的长步骤可以纳入 workflow 统一编排 |
| knowledge-navigator / cli-guide | 上游配套技能，本插件未附带。已安装时可用它们消费知识库；未安装时用 `read`/`grep` 直接读 JSON 索引即可 |
