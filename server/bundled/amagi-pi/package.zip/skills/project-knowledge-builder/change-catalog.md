# 改进提案存档（已全部落地）

这是本技能早期迭代时的 18 项改进提案目录（2026-03，依据真实项目知识库的演化模式整理）。所有提案都已并入现行的 SKILL.md 与 references/，**执行本技能时不需要读本文件**；它只用于追溯某条规则的来由。原始全文可在 Git 历史中查看。

## 当时识别的三类新能力

1. **知识分片**：单文件超过合理规模时按 ID 范围 / 语义 / 编号分片，配合索引层按需加载（file/field/module catalog）。
2. **证据与术语管理**：独立的 terminology/ 目录管理别名、已验证链路和待补证问题，把“知识是否可信”显式化。
3. **领域深度子目录化**：领域知识超出 5 个标准文件的承载量时，按关注点拆成 architecture/、api/、internals/、runtime/ 等子目录。

## 18 项提案的落点

| # | 提案 | 现行位置 |
|---|------|---------|
| 1 | Catalog 系统 | `references/domain-and-catalog-rules.md`「阶段 8」 |
| 2 | terminology/ 目录 | `references/output-generation-rules.md`「terminology/ 目录生成规则」 |
| 3 | 文件分片策略 | SKILL.md「知识组织目标」第 5 条；`domain-and-catalog-rules.md` 分片策略表 |
| 4 | 快查表系统 | `output-generation-rules.md`「基础输出与增强文件」 |
| 5 | 领域深度子目录化 | `domain-and-catalog-rules.md`「领域深度子目录化」 |
| 6 | runtime 知识类别 | `domain-and-catalog-rules.md`「阶段 7」runtime/ |
| 7 | 证据追踪三层级 | `output-generation-rules.md`「evidence 追踪三层级」 |
| 8 | architecture 多维拆分 | `domain-and-catalog-rules.md`「architecture 多维拆分」 |
| 9 | internals 按层拆分 | `domain-and-catalog-rules.md`「internals 按层拆分」 |
| 10 | chains 增强（矩阵型链路、分流问题） | `output-generation-rules.md`「chains 文件类型」 |
| 11 | 领域子目录化 schema | `references/output-schema.md`「domains/{domain-id}/{subdir}/」 |
| 12 | Catalog 文件 schema | `output-schema.md`「field-catalog/ 和 param-specs/」 |
| 13 | terminology schema | `output-schema.md`「terminology/」 |
| 14 | chains/index.json 的 startQuestions / entryRules / crossLinks | `output-schema.md`「chains/index.json」 |
| 15 | Domain Explorer 体量评估 | `references/deepening-protocol.md`「维度 1.5」 |
| 16 | 领域输出委派的扩展输出 | `deepening-protocol.md`「领域输出生成委派」 |
| 17 | 领域知识体量检测模式 | `references/detection-patterns.md`「领域知识体量检测」 |
| 18 | writer 扩展任务 | `references/agent-team-protocol.md`「Writer SubAgent Spawn」 |
