---
name: switch-project
description: |
  项目切换技能，用于多项目环境的上下文切换与项目注册信息维护。用户要求切换项目、进入/激活另一个项目、列出项目、查看当前活跃项目、同步项目记忆地图路径、校验项目路径、加载某项目记忆、更新 activeProject，或写出 [@hotswap:switch/list/active/sync/validate]、switch project、change workspace 时应使用；负责读取 registry、加载项目上下文并输出结果。不要用于同一项目内的分支/任务切换、git checkout、普通目录 cd，或未涉及项目记忆/上下文的操作。
version: "1.1"
author: amagi
tags:
  - P1
  - core
  - utility
compatibility: pi
---

> pi 适配：canonical 资源用 `amagi_resource` 工具按资源 ID 读取（pi 不自动展开 `@` 引用）。下面的步骤由你按顺序执行；插件代码不解析 `[@hotswap:...]` 写法，也不自动执行这些步骤。

# switch-project 技能

## 概述

在多项目环境里切换当前活动项目，并加载目标项目的配置和知识库，让后续任务读写的都是正确项目的元数据。路径体系（WORKSPACE_ROOT、PROJECTS_DIR 等）的完整说明见 `resources/core/integrations/project-management.md`。

## 什么时候用

- 用户写了 `[@hotswap:...]` 中的任一写法（见下方「命令写法」；这是表达意图的约定写法，由你按对应流程执行）
- 用户明确请求切换到其他项目、列出项目、查看当前项目或校验项目路径
- 任务属于非当前活动项目

## 切换项目（switch）

1. 记下当前项目状态（当前 activeProject 和未完成事项），方便切回时接续。
2. 从当前路径向上找到 `projects-memory/projects/registry.json`，读取它。
3. 确认目标项目已在 registry 中注册。
4. 更新 registry 的 `activeProject`。
5. 加载目标项目配置。
6. 按需加载项目专属知识库和战术手册。
7. 输出切换确认。

## 需要的信息

| 参数 | 说明 |
|------|------|
| project_id | 目标项目 ID（没给就先列出已注册项目请用户选） |

## 命令写法

| 写法 | 做什么 | 是否写文件 |
|------|--------|-----------|
| `[@hotswap:switch:project-id]` | 切换到指定项目（上文「切换项目」流程） | 改 registry 的 `activeProject` |
| `[@hotswap:list]` | 列出已注册项目 | 只读 |
| `[@hotswap:active]` | 显示当前活跃项目 | 只读 |
| `[@hotswap:sync:project-id]` | 让记忆地图的项目根路径与 registry 对齐 | 只改 `memory-map.json` 的路径字段与 `lastUpdated` |
| `[@hotswap:validate:project-id]` | 校验项目路径与入口文件 | 只读 |

省略 `project-id` 时默认用 registry 的 `activeProject`。以下流程的第一步都是：从当前路径向上找到 `projects-memory/projects/registry.json` 并读取；找不到就告诉用户当前不在 projects-memory 工作区，停止。

### 列出项目（list）

列出 registry 中每个项目的 ID、名称和 `projectPath`，标出哪个是当前 `activeProject`。

### 当前项目（active）

读 registry 的 `activeProject`，再读 `{id}/context.json` 的 `projectInfo`（名称、类型、状态、技术栈），连同 `projectPath` 一起输出。`activeProject` 为空或未注册时如实说明，并附上 list 结果供用户选择。

### 同步记忆地图（sync）

1. 读 registry 中该项目的 `projectPath`，读 `{id}/memory-map.json`。
2. 对比 `sections.2_paths.content.projectRoot` 与 `projectPath`：不一致时以 registry 为准改写 `projectRoot`，并把顶层 `lastUpdated` 更新为今天。
3. 检查 `2_paths` 里其余相对路径（`entryPoint`、`config`、`buildOutput` 等，值为 `N/A` 的跳过）在 `projectPath` 下是否存在，不存在的逐条列出，不自动改写——路径失效往往意味着代码结构变了，需要人判断。
4. 输出改了哪些字段、哪些路径失效。记忆地图内容本身（技术要点、洞察等）过时需要重新生成时，改用 `project-knowledge-builder` 技能做增量刷新。

### 校验项目（validate）

只读检查，逐项给出通过/失败：

1. 项目 ID 已在 registry 注册；
2. `projectPath` 存在且是目录；
3. `{id}/` 元数据目录存在；
4. `{id}/context.json`、`{id}/memory-map.json` 存在且是合法 JSON；
5. `memory-map.json` 的 `projectRoot` 与 `projectPath` 一致（不一致提示用 sync 修正）。

失败项写明具体路径，不自动修复。

## 切换后可加载的资源

路径相对 `projects-memory/projects/`：

| 资源 | 路径 |
|------|------|
| 项目配置 | {id}/context.json |
| 项目知识库 | {id}/knowledge-base/ |
| 项目战术手册 | {id}/tactical-book/ |
| 项目输出目录 | {id}/agent-outputs/ |

按需读取即可；目录不存在说明该项目没建这部分，跳过并在确认信息里注明。

## 切换确认

```
【项目切换成功】
- 从: {old_project_name}
- 到: {new_project_name}
- 项目路径: {project_path}
- 已加载知识库: {knowledge_base_count}项
```

## 补充

- 目标项目不在 registry 里时，告诉用户并提议先注册新项目。
- 切换只改项目上下文，对话本身照常延续。
