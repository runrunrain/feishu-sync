---
name: update-tactical-book
description: |
  战术手册更新技能，用于把已验证经验沉淀到 tactical-book。用户要求“更新战术手册”“经验沉淀”“复盘这次教训”“记录到 handbook”“【待反思】”“postmortem to tactical book”时应触发；按 Delta 规则追加/合并条目，维护触发条件、证据和生命周期。不要用于普通任务报告、未验证猜想、代码修改，或需要整体重写/删除手册历史的操作。
version: "1.0"
author: amagi
tags:
  - P1
  - core
  - thinker
  - reflection
compatibility: pi
---

> pi 适配：canonical 资源用 `amagi_resource` 工具按资源 ID 读取（pi 不自动展开 `@` 引用）。下面的流程由你按步骤完成，插件不会自动触发。

# update-tactical-book 技能

## 概述

把一次真实踩坑或成功经验，沉淀成战术手册里一条可复用的条目。手册会被后续任务按需检索，一条写清“何时适用、怎么做、证据在哪”的条目，能让之后的 Agent 少走同一段弯路。

通常由 Leader 派 fuxi（伏羲）反思态执行（旧 puti 岗位已并入 fuxi 反思态，puti 名会自动归一）。你如果就是 fuxi，直接按下面的流程做；写入范围以任务授权为准（任务给定的 artifact 与手册增量条目）。

## 什么时候用

- 有 Agent 在报告里标了【待反思】
- 发现了可复用的问题解决模式
- 遇到意外问题或踩坑经历
- 需要更新最佳实践

只沉淀已验证的经验；还是猜想的，先留在报告里，等有证据再来。

## 需要准备的信息

| 信息 | 说明 |
|------|------|
| trigger_source | 触发来源（哪个 Agent、什么场景） |
| context | 相关上下文与证据路径 |
| expected_vs_actual | 预期结果 vs 实际结果 |

缺哪一项，就在报告里写明缺什么，用已有材料继续分析。

## 执行流程

1. **收集反思上下文**：读触发报告、相关 artifact 与执行轨迹。
2. **蝴蝶循环分析**（5 轮逐层深入，每轮建立在上一轮结论上）：
   - 第 1 轮：现象——到底发生了什么
   - 第 2 轮：根本原因——为什么会发生
   - 第 3 轮：解决方案——当时怎样能避免或修复
   - 第 4 轮：抽象规则——剥离项目细节后，哪条规律可迁移
   - 第 5 轮：验证精炼——规则的适用边界与反例
3. **查重**：`amagi_handbook({ action:"query", keyword })` 看是否已有同类条目，决定新增还是合并到已有条目（更新 usageCount）。
4. **增量更新手册**（规则见下）。
5. **写反思报告**（格式见下）。

## 手册怎么读、怎么改

手册文件是插件包内的 `resources/tactical-book/handbook.json`，随条目增长会越来越大。读取统一经 `amagi_handbook` 工具按需取片段，不必把整个文件读进上下文：

| 需要 | 调用 |
|------|------|
| 写入前查重 | `amagi_handbook({ action:"query", keyword })`（可加 `section`/`status` 过滤；默认不含 dormant/deprecated，需要时加 `includeDormant:true`） |
| 单条全文 | `amagi_handbook({ action:"show", id })` |
| 分布与陈旧候选 | `amagi_handbook({ action:"stats" })`（含 usageCount=0 且超 60 天的候选队列） |
| 状态迁移 | `amagi_handbook({ action:"lifecycle", id, to, note })`，`to` 为 candidate/active/dormant/deprecated |

改动遵循增量（Delta）原则：

| 操作 | 怎么做 |
|------|------|
| 添加新条目 | 编辑 handbook.json，追加到对应 `sections.<section>.entries` 末尾 |
| 更新使用计数 | 编辑该条目的 `usageCount` |
| 标记废弃/降级/晋升 | 用 `lifecycle` 动作，不手改 JSON——迁移记录写在 sidecar 覆盖层，插件更新时不会丢 |
| 删除条目、整体重写 | 不做。废弃的条目用 `deprecated` 保留迁移说明；整体重写会丢失历史语义，手册的 `updatePolicy` 也只允许 add / update-count / deprecate |

新增条目需要随插件发布才会对其他安装生效。

## 条目格式

现有 section：`framework-prompt-governance`、`task-management`、`thinking-patterns`、`error-patterns`、`tool-usage`、`collaboration`、`startup-sequence`。新条目参照已有条目的字段：

```json
{
  "id": "TM-XXX-YYYYMMDD",
  "title": "一句话标题",
  "insight": "具体洞见：何时适用、怎么做、为什么",
  "example": "真实案例",
  "source": "反思报告路径",
  "usageCount": 0,
  "addedDate": "YYYY-MM-DD",
  "status": "candidate",
  "defaultLoad": false
}
```

新条目一般从 `candidate` 起步（有证据但样本少）；再经一个额外成功案例和审核证据后，可用 `lifecycle` 晋升为 `active`。

反思报告里用 Delta 记录本次改动，方便追溯：

```json
{
  "timestamp": "2026-01-15T10:00:00Z",
  "source": "fuxi",
  "trigger": "【待反思】xxx",
  "operations": [
    { "action": "add", "section": "error-patterns", "id": "EP-XXX-20260115" }
  ]
}
```

## 反思报告

按 `agent-document-output` 技能的归档约定写到 `{PROJECT_META_ROOT}/agent-outputs/fuxi/{timestamp}-{task-brief}/reflection-report.md`（不在 projects-memory 工作区时落 `<项目根>/agent-outputs/fuxi/...`；任务书给了路径就以任务书为准；历史 thinker/、puti/、architect/ 目录仍可读，不必迁移）。结构：

```
reflection-report.md
├── 触发来源
├── 事件描述
├── 蝴蝶循环分析（5 轮）
├── 提取洞见
├── Delta 更新
└── 验证计划
```

分析到一半证据不够、或拿不准规则能否迁移时，如实写进报告并把条目留在 candidate——这比勉强下结论更有价值。
