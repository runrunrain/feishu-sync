# workflow.md 模板

> 按任务事实改写；删除不适用字段。建议路径：`agent-outputs/workflow/{task-brief}/workflow.md`（相对项目根；projects-memory 工作区为 `{PROJECT_META_ROOT}/…`）。

# 目标与验收

- 计划基线：{已有 execution-plan 路径或本文件；复用节点 ID}
- 目标：{用户可观察的最终状态}
- 范围：{包含}
- 非目标：{不包含}
- 总验收：{可运行场景/命令与预期}

# 阶段

## Phase 1：{名称}

目标：{阶段结束时的可观察状态}

| ID | 完整切片 / Agent | 前置依赖与 required artifacts | 输出 | 验收与验证 | 状态 |
|---|---|---|---|---|---|
| P1-A | {任务} / {agent} | {无或完整路径} | {changed files + 报告如 reports/c2a-report.md} | {真实命令/场景与预期} | pending |
| P1-B | {可并行任务} / {agent} | {共享 context} | {输出} | {验收} | pending |

- 调度：{P1-A、P1-B 同批并行 | A → B，原因：B 消费 A 的…}
- 隔离：{无需 | worktree，冲突边界：…}
- Gate：{进入下一 Phase 前必须存在的 artifact、集成状态和验证证据}
- 报告路径：派发前展开为具体路径（如 reports/c2a-report.md），不留未展开的占位符；batch 可用 nodes[].reportPath（相对节点 cwd，不突破该节点 allowedPaths）

## Phase 2：{名称}

{同上；只保留真实需要的阶段。}

# 跨边界链路清单

> 文件边界（写冲突面）≠调用链边界（集成缝隙面）；无跨界链路填「不适用：{一句理由}」。

| 链路 | 谁→谁 | 传什么（关键身份/状态） | 失败路径 | 端到端责任 | 真实用户入口验收证据 |
|---|---|---|---|---|---|
| {node_id 链} | {c1a→c3b→c3a} | {battle_prep→battle→settle 的 node_id} | {任一环丢失→玩家路径记账断链} | {c1a；Leader 集成批端到端验收} | {真实 UI 布阵→战斗→结算断言一致，非 App 直驱} |

# 专家预算

| 父任务/大阶段 | fuxi 方向 Gate | diting 审核 Gate | 触发证据 |
|---|---|---|---|
| {范围} | {无 / 一次，artifact} | {无 / 集成验证后一次} | {重大取舍或高风险路径} |

> 不为叶子切片复制专家节点。fuxi 三态：方向 Gate 只算设计态；攻坚/反思须显式、不自动触发（攻坚落地派 luban）。少量 findings 由 Leader 直修；问题多合并一个修复批次。

# 风险与决策

| 时间 | 事实/风险 | 决策 | 影响的节点 |
|---|---|---|---|
| {时间} | {内容} | {选择与理由} | {ID} |

# 自治级别

`interactive` | `unattended`

unattended 时记录授权范围内影响结果的自主选择及依据；不扩大操作授权。缺少授权且无安全替代的动作标 blocked，继续无依赖工作。

# 修订日志

- {时间}：{变更；证据/原因；受影响节点}

# 最终验收

> 验收状态依据实际检查填写，不从任务 done 推断。尚未验证的项标为未验证并说明原因。

| 验收项 | met / partial / missed / 未验证 | 证据 |
|---|---|---|
| {初始需求} | {状态} | {命令、场景或 artifact} |
| 真实用户入口端到端 | {状态或不适用理由} | {从 UI/CLI/API 入口贯穿全链的用例} |
